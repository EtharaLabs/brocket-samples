//! Port of sequencer.c (cherry-pick / revert machinery; rebase -i support
//! is added on top of the same structures).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const refs = @import("refs.zig");
const revparse = @import("revparse.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const objects = @import("objects.zig");
const cn = @import("commitnode.zig");
const index_mod = @import("index.zig");
const pathspec_mod = @import("pathspec.zig");
const ut = @import("unpacktrees.zig");
const mo = @import("merge_ort.zig");
const advice = @import("advice.zig");
const hook = @import("hook.zig");
const commit_mod = @import("commit.zig");
const wtstatus = @import("wtstatus.zig");
const trailer = @import("pretty_trailer.zig");
const pretty = @import("pretty.zig");
const revision = @import("revision.zig");
const summary = @import("summary.zig");
const proc = @import("proc.zig");
const lockfile = @import("lockfile.zig");
const date_mod = @import("date.zig");
const branchstate = @import("branchstate.zig");
const c_commit = @import("cmd/commit.zig");
const Oid = hash.Oid;
const Commit = cn.Commit;
const gpa = util.gpa;

pub const Cleanup = c_commit.Cleanup;

pub const Action = enum { revert, pick, rebase_i };

pub const RERERE_AUTOUPDATE: i32 = 1;
pub const RERERE_NOAUTOUPDATE: i32 = 2;

pub const Opts = struct {
    action: Action = .pick,
    edit: i32 = -1,
    record_origin: bool = false,
    no_commit: bool = false,
    signoff: bool = false,
    allow_ff: bool = false,
    allow_rerere_auto: i32 = 0,
    allow_empty: bool = false,
    allow_empty_message: bool = false,
    drop_redundant_commits: bool = false,
    keep_redundant_commits: bool = false,
    verbose: bool = false,
    quiet: bool = false,
    reschedule_failed_exec: bool = false,
    committer_date_is_author_date: bool = false,
    ignore_date: bool = false,
    commit_use_reference: bool = false,
    trailer_args: std.ArrayList([]const u8) = .empty,
    mainline: i32 = 0,
    gpg_sign: ?[]const u8 = null,
    default_msg_cleanup: Cleanup = .none,
    explicit_cleanup: bool = false,
    default_strategy: ?[]const u8 = null,
    strategy: ?[]const u8 = null,
    xopts: std.ArrayList([]const u8) = .empty,
    reflog_action: ?[]const u8 = null,
    squash_onto: Oid = hash.zero,
    have_squash_onto: bool = false,
    revs: ?*revision.RevInfo = null,
    // replay_ctx
    message: util.Buf = .empty,
    current_fixups: util.Buf = .empty,
    current_fixup_count: i32 = 0,
    have_message: bool = false,
};

// ---------------------------------------------------------------------------
// paths

fn gitPath(name: []const u8) []const u8 {
    return repo_mod.repo().gitPath(name);
}
fn seqDir() []const u8 {
    return gitPath("sequencer");
}
fn todoFile() []const u8 {
    return gitPath("sequencer/todo");
}
fn optsFile() []const u8 {
    return gitPath("sequencer/opts");
}
fn headFile() []const u8 {
    return gitPath("sequencer/head");
}
fn abortSafetyFile() []const u8 {
    return gitPath("sequencer/abort-safety");
}
pub fn rebasePath(name: []const u8) []const u8 {
    if (name.len == 0) return gitPath("rebase-merge");
    return gitPath(util.concat(&.{ "rebase-merge/", name }));
}
fn mergeMsgPath() []const u8 {
    return gitPath("MERGE_MSG");
}

fn isRebaseI(opts: *const Opts) bool {
    return opts.action == .rebase_i;
}
fn getDir(opts: *const Opts) []const u8 {
    return if (isRebaseI(opts)) rebasePath("") else seqDir();
}
fn getTodoPath(opts: *const Opts) []const u8 {
    return if (isRebaseI(opts)) rebasePath("git-rebase-todo") else todoFile();
}

// ---------------------------------------------------------------------------
// config

fn cleanupFromConfig(opts: *Opts, v: []const u8) void {
    if (util.eql(v, "verbatim")) {
        opts.default_msg_cleanup = .none;
        opts.explicit_cleanup = true;
    } else if (util.eql(v, "whitespace")) {
        opts.default_msg_cleanup = .space;
        opts.explicit_cleanup = true;
    } else if (util.eql(v, "strip")) {
        opts.default_msg_cleanup = .all;
        opts.explicit_cleanup = true;
    } else if (util.eql(v, "scissors")) {
        opts.default_msg_cleanup = .scissors;
        opts.explicit_cleanup = true;
    } else {
        util.warn("invalid commit message cleanup mode '{s}'", .{v});
    }
}

/// sequencer_init_config()
pub fn initConfig(opts: *Opts) void {
    opts.default_msg_cleanup = .none;
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        if (util.eql(k, "commit.cleanup")) {
            const v = e.value orelse util.die("missing value for '{s}'", .{k});
            cleanupFromConfig(opts, v);
        } else if (util.eql(k, "commit.gpgsign")) {
            opts.gpg_sign = if (config.configBool(k, e.value)) "" else null;
        } else if (opts.default_strategy == null and util.eql(k, "pull.twohead")) {
            const v = e.value orelse util.die("missing value for '{s}'", .{k});
            opts.default_strategy = if (std.mem.indexOfScalar(u8, v, ' ')) |sp| v[0..sp] else v;
        } else if (opts.action == .revert and util.eql(k, "revert.reference")) {
            opts.commit_use_reference = config.configBool(k, e.value);
        }
    }
}

fn describeCleanupMode(m: Cleanup) []const u8 {
    return switch (m) {
        .space => "whitespace",
        .none => "verbatim",
        .scissors => "scissors",
        .all => "strip",
    };
}

// ---------------------------------------------------------------------------
// small helpers

pub fn actionName(opts: *const Opts) []const u8 {
    return switch (opts.action) {
        .revert => "revert",
        .pick => "cherry-pick",
        .rebase_i => "rebase",
    };
}

fn shortCommitName(c: *Commit) []const u8 {
    return revparse.abbrev(c.oid(), revparse.defaultAbbrev());
}

fn commitOutputEncoding() []const u8 {
    return commit_mod.commitEncoding() orelse "UTF-8";
}

/// find_commit_subject(): returns the message from the subject on, and the
/// length of the subject line.
pub fn findCommitSubject(buf: []const u8) struct { rest: []const u8, len: usize } {
    var p: usize = 0;
    while (p < buf.len and (buf[p] != '\n' or p + 1 >= buf.len or buf[p + 1] != '\n')) {
        if (buf[p] == '\n' and p + 1 >= buf.len) {
            p += 1;
            break;
        }
        p += 1;
    }
    if (p < buf.len) {
        p = skipBlankLines(buf, p + 2);
        const eol = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse buf.len;
        return .{ .rest = buf[p..], .len = eol - p };
    }
    return .{ .rest = buf[buf.len..], .len = 0 };
}

fn skipBlankLines(buf: []const u8, start: usize) usize {
    var p = start;
    while (p < buf.len) {
        var q = p;
        while (q < buf.len and buf[q] != '\n' and std.ascii.isWhitespace(buf[q])) q += 1;
        if (q < buf.len and buf[q] == '\n') {
            p = q + 1;
            continue;
        }
        if (q >= buf.len) return q;
        break;
    }
    return p;
}

/// commit_subject_length()
pub fn commitSubjectLength(body: []const u8) usize {
    var p: usize = 0;
    while (p < body.len) {
        const next = skipBlankLines(body, p);
        if (next != p) break;
        p = std.mem.indexOfScalarPos(u8, body, p, '\n') orelse body.len;
        if (p < body.len) p += 1;
    }
    return p;
}

const CommitMessage = struct {
    parent_label: []const u8,
    label: []const u8,
    subject: []const u8,
    message: []const u8,
};

fn getMessage(commit: *Commit) CommitMessage {
    const msg = pretty.logmsgReencode(commit, commitOutputEncoding()).msg;
    const abbrev = shortCommitName(commit);
    const s = findCommitSubject(msg);
    const subject = s.rest[0..s.len];
    const label = util.fmt("{s} ({s})", .{ abbrev, subject });
    return .{
        .message = msg,
        .subject = subject,
        .label = label,
        .parent_label = util.fmt("parent of {s}", .{label}),
    };
}

pub const rebase_resolvemsg =
    "Resolve all conflicts manually, mark them as resolved with\n" ++
    "\"git add/rm <conflicted_files>\", then run \"git rebase --continue\".\n" ++
    "You can instead skip this commit: run \"git rebase --skip\".\n" ++
    "To abort and get back to the state before \"git rebase\", run " ++
    "\"git rebase --abort\".";

fn printAdvice(show_hint: bool, opts: *Opts) void {
    const msg: ?[]const u8 = if (isRebaseI(opts)) rebase_resolvemsg else os.getenv("GIT_CHERRY_PICK_HELP");
    if (msg) |m| {
        advice.adviseIfEnabled("mergeConflict", m);
        refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "") catch {};
        return;
    }
    if (show_hint) {
        if (opts.no_commit) {
            advice.adviseIfEnabled("mergeConflict", "after resolving the conflicts, mark the corrected paths\nwith 'git add <paths>' or 'git rm <paths>'");
        } else if (opts.action == .pick) {
            advice.adviseIfEnabled("mergeConflict", "After resolving the conflicts, mark them with\n" ++
                "\"git add/rm <pathspec>\", then run\n" ++
                "\"git cherry-pick --continue\".\n" ++
                "You can instead skip this commit with \"git cherry-pick --skip\".\n" ++
                "To abort and get back to the state before \"git cherry-pick\",\n" ++
                "run \"git cherry-pick --abort\".");
        } else if (opts.action == .revert) {
            advice.adviseIfEnabled("mergeConflict", "After resolving the conflicts, mark them with\n" ++
                "\"git add/rm <pathspec>\", then run\n" ++
                "\"git revert --continue\".\n" ++
                "You can instead skip this commit with \"git revert --skip\".\n" ++
                "To abort and get back to the state before \"git revert\",\n" ++
                "run \"git revert --abort\".");
        }
    }
}

/// write_message(): returns 0 or -1 (error printed).
pub fn writeMessage(buf: []const u8, filename: []const u8, append_eol: bool) i32 {
    const l = switch (lockfile.tryLock(filename)) {
        .ok => |l| l,
        .err => {
            util.err("could not lock '{s}': {s}", .{ filename, os.lastErr() });
            return -1;
        },
    };
    l.write(buf);
    if (append_eol) l.write("\n");
    if (!l.commit()) {
        util.err("failed to finalize '{s}'", .{filename});
        return -1;
    }
    return 0;
}

/// write_file(): writes `data` (dies on error).
fn writeFile(path: []const u8, data: []const u8) void {
    os.writeFile(path, data, 0o666) catch util.dieErrno("could not open '{s}' for writing", .{path});
}

/// read_oneliner()
pub fn readOneliner(path: []const u8, warn_missing: bool, skip_if_empty: bool) ?[]const u8 {
    const data = os.readFile(path) orelse {
        const e = os.errno();
        if (warn_missing or (e != os.ENOENT and e != os.ENOTDIR))
            util.warn("could not read '{s}': {s}", .{ path, os.strErr(e) });
        return null;
    };
    var s: []const u8 = data;
    if (s.len > 0 and s[s.len - 1] == '\n') {
        s = s[0 .. s.len - 1];
        if (s.len > 0 and s[s.len - 1] == '\r') s = s[0 .. s.len - 1];
    }
    if (skip_if_empty and s.len == 0) return null;
    return s;
}

fn errorDirtyIndex(opts: *Opts) i32 {
    if (ut.readIndexUnmerged(index_mod.get())) {
        advice.errorResolveConflict(actionName(opts));
        return -1;
    }
    util.err("your local changes would be overwritten by {s}.", .{actionName(opts)});
    if (advice.enabled("commitBeforeMerge")) advice.advise("commit your changes or stash them to proceed.");
    return -1;
}

fn updateAbortSafetyFile() void {
    if (!os.exists(seqDir())) return;
    if (revparse.getOid("HEAD")) |h| {
        writeFile(abortSafetyFile(), &hash.hex(h));
    } else writeFile(abortSafetyFile(), "");
}

/// checkout_fast_forward() (merge.c), overwrite_ignore = 1
pub fn checkoutFastForward(head: Oid, remote: Oid) bool {
    const idx = index_mod.lockAndRead();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
    const t1 = objects.peelTo(head, .tree) orelse {
        idx.rollback();
        return false;
    };
    const t2 = objects.peelTo(remote, .tree) orelse {
        idx.rollback();
        return false;
    };
    var o = ut.Options{};
    o.preserve_ignored = false;
    o.head_idx = 1;
    o.src_index = idx;
    o.dst_index = idx;
    o.update = true;
    o.verbose_update = true;
    o.merge = true;
    o.func = &ut.twowayMerge;
    ut.setupPorcelain(&o, "merge");
    if (ut.unpackTrees(&.{ t1, t2 }, &o) != 0) {
        index_mod.get().rollback();
        idx.rollback();
        return false;
    }
    index_mod.get().write();
    return true;
}

fn fastForwardTo(to: Oid, from: Oid, unborn: bool, opts: *Opts) i32 {
    index_mod.discard();
    if (!checkoutFastForward(from, to)) return -1;
    const msg = util.fmt("{s}: fast-forward", .{actionName(opts)});
    const old: Oid = if (unborn and !isRebaseI(opts)) hash.zero else from;
    refs.update("HEAD", to, old, msg, false) catch {
        util.err("{s}", .{refs.last_error});
        return -1;
    };
    updateAbortSafetyFile();
    return 0;
}

fn commentedAdd(buf: *util.Buf, text: []const u8) void {
    const incomplete = buf.items.len > 0 and buf.items[buf.items.len - 1] != '\n';
    wtstatus.addCommentedLines(buf, trailer.commentLineStr(), text);
    if (incomplete) buf.items.len -= 1;
}

/// append_conflicts_hint()
pub fn appendConflictsHint(msgbuf: *util.Buf, mode: Cleanup) void {
    const cs = trailer.commentLineStr();
    if (mode == .scissors) {
        util.bufByte(msgbuf, '\n');
        wtstatus.appendCutLine(msgbuf);
        util.bufAppend(msgbuf, cs);
    }
    util.bufByte(msgbuf, '\n');
    commentedAdd(msgbuf, "Conflicts:\n");
    const ents = index_mod.get().entries.items;
    var i: usize = 0;
    while (i < ents.len) {
        const ce = ents[i];
        i += 1;
        if (ce.stage() != 0) {
            commentedAdd(msgbuf, util.fmt("\t{s}\n", .{ce.path}));
            while (i < ents.len and util.eql(ce.path, ents[i].path)) i += 1;
        }
    }
}

fn commitTreeOid(c: ?*Commit) Oid {
    const cc = c orelse return hash.fromHex(hash.empty_tree_hex).?;
    _ = cn.parse(cc);
    return cc.tree;
}

fn doRecursiveMerge(base: ?*Commit, next: ?*Commit, base_label: []const u8, next_label: []const u8, head: Oid, msgbuf: *util.Buf, opts: *Opts) i32 {
    const idx = index_mod.lockAndRead();
    _ = idx;
    var o = mo.initMergeOptions(true);
    o.ancestor = if (base != null) base_label else "(empty tree)";
    o.branch1 = "HEAD";
    o.branch2 = if (next != null) next_label else "(empty tree)";
    o.show_rename_progress = true;
    const head_tree = objects.peelTo(head, .tree) orelse {
        index_mod.get().rollback();
        util.err("unable to read tree ({s})", .{hash.hex(head)});
        return -1;
    };
    const next_tree = commitTreeOid(next);
    const base_tree = commitTreeOid(base);
    for (opts.xopts.items) |x| _ = mo.parseMergeOpt(&o, x);
    var result = mo.Result{};
    mo.mergeIncoreNonrecursive(&o, base_tree, head_tree, next_tree, &result);
    const show_output = !isRebaseI(opts) or result.clean == 0;
    mo.mergeSwitchToResult(&o, head_tree, &result, true, show_output);
    const clean = result.clean;
    if (clean < 0) {
        index_mod.get().rollback();
        return clean;
    }
    index_mod.get().write();
    if (clean == 0) appendConflictsHint(msgbuf, opts.default_msg_cleanup);
    return if (clean == 0) 1 else 0;
}

/// is_index_unchanged(): 1 if the index tree equals HEAD's tree, 0 if not, -1 on error.
fn isIndexUnchanged() i32 {
    var head_tree: Oid = undefined;
    if (refs.readOid("HEAD")) |h| {
        const c = cn.lookupCommit(h) orelse return -1;
        if (!cn.parse(c)) return -1;
        head_tree = c.tree;
    } else {
        const sym = refs.readSymbolic("HEAD");
        if (sym == null or !util.startsWith(sym.?, "refs/heads/")) {
            util.err("could not resolve HEAD commit", .{});
            return -1;
        }
        head_tree = hash.fromHex(hash.empty_tree_hex).?;
    }
    const t = index_mod.get().writeTree(false) orelse {
        util.err("unable to update cache tree", .{});
        return -1;
    };
    return if (hash.eql(t, head_tree)) 1 else 0;
}

// ---------------------------------------------------------------------------
// author-script

fn writeAuthorScript(message: []const u8) i32 {
    var m = message;
    while (true) {
        if (m.len == 0 or m[0] == '\n') {
            _ = os.unlink(rebasePath("author-script"));
            return 0;
        } else if (util.skipPrefix(m, "author ")) |rest| {
            m = rest;
            break;
        } else if (std.mem.indexOfScalar(u8, m, '\n')) |eol| {
            m = m[eol + 1 ..];
        } else {
            _ = os.unlink(rebasePath("author-script"));
            return 0;
        }
    }
    var b: util.Buf = .empty;
    var i: usize = 0;
    util.bufAppend(&b, "GIT_AUTHOR_NAME='");
    while (i < m.len and m[i] != '\n' and m[i] != '\r') {
        if (util.startsWith(m[i..], " <")) {
            i += 2;
            break;
        } else if (m[i] != '\'') {
            util.bufByte(&b, m[i]);
            i += 1;
        } else {
            util.bufPrint(&b, "'\\{c}'", .{m[i]});
            i += 1;
        }
    }
    util.bufAppend(&b, "'\nGIT_AUTHOR_EMAIL='");
    while (i < m.len and m[i] != '\n' and m[i] != '\r') {
        if (util.startsWith(m[i..], "> ")) {
            i += 2;
            break;
        } else if (m[i] != '\'') {
            util.bufByte(&b, m[i]);
            i += 1;
        } else {
            util.bufPrint(&b, "'\\{c}'", .{m[i]});
            i += 1;
        }
    }
    util.bufAppend(&b, "'\nGIT_AUTHOR_DATE='@");
    while (i < m.len and m[i] != '\n' and m[i] != '\r') {
        if (m[i] != '\'') {
            util.bufByte(&b, m[i]);
        } else {
            util.bufPrint(&b, "'\\{c}'", .{m[i]});
        }
        i += 1;
    }
    util.bufByte(&b, '\'');
    return writeMessage(b.items, rebasePath("author-script"), true);
}

/// sq_dequote()
fn sqDequote(s: []const u8) ?[]const u8 {
    if (s.len == 0 or s[0] != '\'') return null;
    var b: util.Buf = .empty;
    var i: usize = 1;
    while (true) {
        if (i >= s.len) return null;
        const c = s[i];
        i += 1;
        if (c != '\'') {
            util.bufByte(&b, c);
            continue;
        }
        // closing quote
        if (i >= s.len) return b.items;
        if (s[i] == '\\' and i + 2 < s.len and s[i + 2] == '\'') {
            const ch = s[i + 1];
            if (ch == '\'' or ch == '!') {
                util.bufByte(&b, ch);
                i += 3;
                continue;
            }
        }
        return null;
    }
}

pub const AuthorScript = struct { name: []const u8, email: []const u8, date: []const u8 };

/// read_author_script(); null on error (messages printed). If allow_missing and
/// the file does not exist, returns an empty struct with missing=true.
pub fn readAuthorScript(path: []const u8, allow_missing: bool) union(enum) { ok: AuthorScript, missing, err } {
    const data = os.readFile(path) orelse {
        if (os.errno() == os.ENOENT and allow_missing) return .missing;
        util.err("could not open '{s}' for reading: {s}", .{ path, os.lastErr() });
        return .err;
    };
    if (data.len == 0) {
        util.err("could not open '{s}' for reading: {s}", .{ path, "Success" });
        return .err;
    }
    var name: ?[]const u8 = null;
    var email: ?[]const u8 = null;
    var date: ?[]const u8 = null;
    var bad = false;
    var p: []const u8 = data;
    while (p.len > 0) {
        const eq = std.mem.indexOfScalar(u8, p, '=') orelse {
            const np = std.mem.indexOfScalar(u8, p, '\n') orelse p.len;
            util.err("no key present in '{s}'", .{p[0..np]});
            return .err;
        };
        const key = p[0..eq];
        const np = std.mem.indexOfScalarPos(u8, p, eq, '\n') orelse p.len;
        const val = sqDequote(p[eq + 1 .. np]) orelse {
            util.err("unable to dequote value of '{s}'", .{key});
            return .err;
        };
        p = if (np < p.len) p[np + 1 ..] else p[p.len..];
        if (util.eql(key, "GIT_AUTHOR_NAME")) {
            if (name != null) {
                util.err("'GIT_AUTHOR_NAME' already given", .{});
                bad = true;
            } else name = val;
        } else if (util.eql(key, "GIT_AUTHOR_EMAIL")) {
            if (email != null) {
                util.err("'GIT_AUTHOR_EMAIL' already given", .{});
                bad = true;
            } else email = val;
        } else if (util.eql(key, "GIT_AUTHOR_DATE")) {
            if (date != null) {
                util.err("'GIT_AUTHOR_DATE' already given", .{});
                bad = true;
            } else date = val;
        } else {
            util.err("unknown variable '{s}'", .{key});
            bad = true;
        }
    }
    if (name == null) util.err("missing 'GIT_AUTHOR_NAME'", .{});
    if (email == null) util.err("missing 'GIT_AUTHOR_EMAIL'", .{});
    if (date == null) util.err("missing 'GIT_AUTHOR_DATE'", .{});
    if (name == null or email == null or date == null or bad) return .err;
    return .{ .ok = .{ .name = name.?, .email = email.?, .date = date.? } };
}

fn getAuthor(message: []const u8) ?[]const u8 {
    return cn.findHeader(message, "author");
}

// ---------------------------------------------------------------------------
// committing

pub const ALLOW_EMPTY: u32 = 1 << 0;
pub const EDIT_MSG: u32 = 1 << 1;
pub const AMEND_MSG: u32 = 1 << 2;
pub const CLEANUP_MSG: u32 = 1 << 3;
pub const VERIFY_MSG: u32 = 1 << 4;
pub const CREATE_ROOT_COMMIT: u32 = 1 << 5;

const staged_changes_advice =
    "you have staged changes in your working tree\n" ++
    "If these changes are meant to be squashed into the previous commit, run:\n" ++
    "\n" ++
    "  git commit --amend {s}\n" ++
    "\n" ++
    "If they are meant to go into a new commit, run:\n" ++
    "\n" ++
    "  git commit {s}\n" ++
    "\n" ++
    "In both cases, once you're done, continue with:\n" ++
    "\n" ++
    "  git rebase --continue\n";

fn gpgSignOptQuoted(opts: *const Opts) []const u8 {
    var b: util.Buf = .empty;
    if (opts.gpg_sign) |g| util.sqQuote(&b, util.concat(&.{ "-S", g }));
    return b.items;
}

fn runGitCommit(defmsg: ?[]const u8, reflog_action: []const u8, opts: *Opts, flags: u32) i32 {
    var env: std.ArrayList([2][]const u8) = .empty;
    if (isRebaseI(opts) and ((opts.committer_date_is_author_date and !opts.ignore_date) or
        !(defmsg == null and flags & AMEND_MSG != 0)))
    {
        switch (readAuthorScript(rebasePath("author-script"), false)) {
            .ok => |a| {
                env.append(gpa, .{ "GIT_AUTHOR_NAME", a.name }) catch util.oom();
                env.append(gpa, .{ "GIT_AUTHOR_EMAIL", a.email }) catch util.oom();
                env.append(gpa, .{ "GIT_AUTHOR_DATE", a.date }) catch util.oom();
            },
            else => {
                const g = gpgSignOptQuoted(opts);
                util.err(staged_changes_advice, .{ g, g });
                return -1;
            },
        }
    }
    env.append(gpa, .{ "GIT_REFLOG_ACTION", reflog_action }) catch util.oom();
    if (opts.committer_date_is_author_date) {
        var d: []const u8 = "";
        if (!opts.ignore_date) {
            for (env.items) |e| {
                if (util.eql(e[0], "GIT_AUTHOR_DATE")) d = e[1];
            }
        }
        env.append(gpa, .{ "GIT_COMMITTER_DATE", d }) catch util.oom();
    }
    if (opts.ignore_date) env.append(gpa, .{ "GIT_AUTHOR_DATE", "" }) catch util.oom();

    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.append(gpa, "commit") catch util.oom();
    if (flags & VERIFY_MSG == 0) argv.append(gpa, "-n") catch util.oom();
    if (flags & AMEND_MSG != 0) argv.append(gpa, "--amend") catch util.oom();
    if (opts.gpg_sign) |g| argv.append(gpa, util.concat(&.{ "-S", g })) catch util.oom() else argv.append(gpa, "--no-gpg-sign") catch util.oom();
    if (defmsg) |d| {
        argv.append(gpa, "-F") catch util.oom();
        argv.append(gpa, d) catch util.oom();
    } else if (flags & EDIT_MSG == 0) {
        argv.append(gpa, "-C") catch util.oom();
        argv.append(gpa, "HEAD") catch util.oom();
    }
    if (flags & CLEANUP_MSG != 0) argv.append(gpa, "--cleanup=strip") catch util.oom();
    if (flags & EDIT_MSG != 0) {
        argv.append(gpa, "-e") catch util.oom();
    } else if (flags & CLEANUP_MSG == 0 and !opts.signoff and !opts.record_origin and !opts.explicit_cleanup) {
        argv.append(gpa, "--cleanup=verbatim") catch util.oom();
    }
    if (flags & ALLOW_EMPTY != 0) argv.append(gpa, "--allow-empty") catch util.oom();
    if (flags & EDIT_MSG == 0) argv.append(gpa, "--allow-empty-message") catch util.oom();

    index_mod.discard();
    if (isRebaseI(opts) and flags & EDIT_MSG == 0) {
        // run_command_silent_on_success
        const r = os.run(argv.items, .{ .env = env.items, .capture_stdout = true, .stdout_to_stderr = false });
        index_mod.discard();
        if (r.status != 0 or r.signaled) {
            util.ewrite(r.stdout);
            return if (r.signaled) -1 else @intCast(r.status);
        }
        return 0;
    }
    const r = os.run(argv.items, .{ .env = env.items });
    index_mod.discard();
    if (r.signaled) return -1;
    return @intCast(r.status);
}

/// update_head_with_reflog()
pub fn updateHeadWithReflog(old_head: ?*Commit, new_head: Oid, action: ?[]const u8, msg: []const u8) bool {
    var sb: util.Buf = .empty;
    if (action) |a| {
        util.bufAppend(&sb, a);
        util.bufAppend(&sb, ": ");
    }
    if (std.mem.indexOfScalar(u8, msg, '\n')) |nl| {
        util.bufAppend(&sb, msg[0 .. nl + 1]);
    } else {
        util.bufAppend(&sb, msg);
        util.bufByte(&sb, '\n');
    }
    const old: Oid = if (old_head) |h| h.oid() else hash.zero;
    refs.update("HEAD", new_head, old, sb.items, false) catch {
        util.err("{s}", .{refs.last_error});
        return false;
    };
    return true;
}

fn runRewriteHook(oldoid: Oid, newoid: Oid) void {
    const data = util.fmt("{s} {s}\n", .{ hash.hex(oldoid), hash.hex(newoid) });
    _ = hook.run("post-rewrite", &.{"amend"}, .{ .stdin_data = data });
}

fn runPrepareCommitMsgHook(msg: []const u8, commit: ?[]const u8) i32 {
    const name = gitPath("COMMIT_EDITMSG");
    if (writeMessage(msg, name, false) != 0) return -1;
    const r = repo_mod.repo();
    const rc = if (commit) |c|
        hook.runCommitHook(false, r.indexPath(), null, "prepare-commit-msg", &.{ name, "commit", c })
    else
        hook.runCommitHook(false, r.indexPath(), null, "prepare-commit-msg", &.{ name, "message" });
    if (rc != 0) {
        util.err("'prepare-commit-msg' hook failed", .{});
        return -1;
    }
    return 0;
}

fn parseHead(head: *?*Commit) i32 {
    const oid = revparse.getOid("HEAD") orelse {
        head.* = null;
        return 0;
    };
    const c = cn.lookupCommitReference(oid) orelse {
        util.err("could not parse HEAD", .{});
        return -1;
    };
    if (!hash.eql(oid, c.oid())) util.warn("HEAD {s} is not a commit!", .{hash.hex(oid)});
    if (!cn.parse(c)) {
        util.err("could not parse HEAD commit", .{});
        return -1;
    }
    head.* = c;
    return 0;
}

/// read_commit_extra_headers() excluding gpgsig
fn readExtraHeaders(c: *Commit) []const u8 {
    _ = cn.parse(c);
    const buf = c.buffer;
    var b: util.Buf = .empty;
    var pos: usize = 0;
    var keep = false;
    while (pos < buf.len) {
        const eol = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse buf.len;
        const line = buf[pos..eol];
        if (line.len == 0) break;
        if (line[0] == ' ') {
            if (keep) {
                util.bufAppend(&b, line);
                util.bufByte(&b, '\n');
            }
        } else {
            const sp = std.mem.indexOfScalar(u8, line, ' ') orelse line.len;
            const key = line[0..sp];
            keep = !(util.eql(key, "tree") or util.eql(key, "parent") or util.eql(key, "author") or
                util.eql(key, "committer") or util.eql(key, "encoding") or util.eql(key, "gpgsig") or
                util.eql(key, "gpgsig-sha256"));
            if (keep) {
                util.bufAppend(&b, line);
                util.bufByte(&b, '\n');
            }
        }
        pos = eol + 1;
    }
    return b.items;
}

/// Split "Name <email> date tz" into parts.
fn splitIdent(id: []const u8) ?struct { name: []const u8, email: []const u8, date: []const u8 } {
    const lt = std.mem.indexOfScalar(u8, id, '<') orelse return null;
    const gt = std.mem.indexOfScalarPos(u8, id, lt, '>') orelse return null;
    const name = util.trim(id[0..lt]);
    const email = id[lt + 1 .. gt];
    const date = util.trim(id[gt + 1 ..]);
    return .{ .name = name, .email = email, .date = date };
}

/// try_to_commit(): -1 error, 0 success, 1 run 'git commit'
fn tryToCommit(msg_in: ?[]const u8, author_in: ?[]const u8, reflog_action: []const u8, opts: *Opts, flags: u32, oid_out: *Oid) i32 {
    const ident = @import("ident.zig");
    var current_head: ?*Commit = null;
    var msg: []const u8 = msg_in orelse "";
    var author = author_in;
    var parents: std.ArrayList(Oid) = .empty;
    var extra: []const u8 = "";
    var hook_commit: ?[]const u8 = null;
    var committer: ?[]const u8 = null;

    if (parseHead(&current_head) != 0) return -1;

    if (flags & AMEND_MSG != 0) {
        const ch = current_head.?;
        const message = pretty.logmsgReencode(ch, commitOutputEncoding()).msg;
        if (msg_in == null) {
            msg = findCommitSubject(message).rest;
            hook_commit = "HEAD";
        }
        author = getAuthor(message);
        if (author == null) {
            util.err("unable to parse commit author", .{});
            return -1;
        }
        var p = ch.parents;
        while (p) |n| : (p = n.next) parents.append(gpa, n.item.oid()) catch util.oom();
        extra = readExtraHeaders(ch);
    } else if (current_head != null and (flags & CREATE_ROOT_COMMIT == 0 or flags & AMEND_MSG != 0)) {
        parents.append(gpa, current_head.?.oid()) catch util.oom();
    }

    const tree = index_mod.get().writeTree(false) orelse {
        util.err("git write-tree failed to write a tree", .{});
        return -1;
    };

    if (flags & ALLOW_EMPTY == 0) {
        var first_parent = current_head;
        if (flags & AMEND_MSG != 0) {
            if (current_head.?.parents) |pl| {
                first_parent = pl.item;
                if (!cn.parse(pl.item)) {
                    util.err("could not parse HEAD commit", .{});
                    return -1;
                }
            } else first_parent = null;
        }
        if (hash.eql(commitTreeOid(first_parent), tree)) return 1;
    }

    if (hook.find("prepare-commit-msg") != null) {
        if (runPrepareCommitMsgHook(msg, hook_commit) != 0) return -1;
        msg = os.readFile(gitPath("COMMIT_EDITMSG")) orelse {
            util.err("unable to read commit message from '{s}': {s}", .{ gitPath("COMMIT_EDITMSG"), os.lastErr() });
            return -1;
        };
    }

    var cleanup: Cleanup = undefined;
    if (flags & CLEANUP_MSG != 0) {
        cleanup = .all;
    } else if ((opts.signoff or opts.record_origin) and !opts.explicit_cleanup) {
        cleanup = .space;
    } else cleanup = opts.default_msg_cleanup;

    if (cleanup != .none) msg = util.stripspace(msg, if (cleanup == .all) trailer.commentLineStr() else null);
    if (flags & EDIT_MSG != 0 and messageIsEmpty(msg, cleanup)) return 1;

    if (opts.committer_date_is_author_date) {
        var d: ?[]const u8 = null;
        if (!opts.ignore_date) {
            const sp = splitIdent(author.?) orelse {
                util.err("invalid author identity '{s}'", .{author.?});
                return -1;
            };
            if (sp.date.len == 0) {
                util.err("corrupt author: missing date information", .{});
                return -1;
            }
            d = util.concat(&.{ "@", sp.date });
        }
        const cname = ident.getName(.committer) orelse "";
        const cemail = ident.getEmail(.committer) orelse "";
        if (d) |dd| {
            const parsed = date_mod.parseDateString(dd) orelse dd;
            committer = util.fmt("{s} <{s}> {s}", .{ ident.sanitize(cname), ident.sanitize(cemail), parsed });
        } else {
            committer = util.fmt("{s} <{s}> {s}", .{ ident.sanitize(cname), ident.sanitize(cemail), nowDate() });
        }
    }

    if (opts.ignore_date) {
        const sp = splitIdent(author.?) orelse {
            util.err("invalid author identity '{s}'", .{author.?});
            return -1;
        };
        author = util.fmt("{s} <{s}> {s}", .{ sp.name, sp.email, nowDate() });
    }

    const oid = commit_mod.create(.{
        .tree = tree,
        .parents = parents.items,
        .message = msg,
        .author = author,
        .committer = committer,
        .extra_headers = extra,
    });
    oid_out.* = oid;

    if (!updateHeadWithReflog(current_head, oid, reflog_action, msg)) return -1;

    _ = hook.runCommitHook(false, repo_mod.repo().indexPath(), null, "post-commit", &.{});
    if (flags & AMEND_MSG != 0) runRewriteHook(current_head.?.oid(), oid);
    return 0;
}

fn nowDate() []const u8 {
    return date_mod.datestamp();
}

fn restIsEmpty(sb: []const u8, start: usize) bool {
    const sign_off_header = "Signed-off-by: ";
    var i = start;
    while (i < sb.len) : (i += 1) {
        const eol = std.mem.indexOfScalarPos(u8, sb, i, '\n') orelse sb.len;
        if (sign_off_header.len <= eol - i and util.startsWith(sb[i..], sign_off_header)) {
            i = eol;
            continue;
        }
        while (i < eol) {
            if (!std.ascii.isWhitespace(sb[i])) return false;
            i += 1;
        }
    }
    return true;
}

fn messageIsEmpty(sb: []const u8, mode: Cleanup) bool {
    if (mode == .none and sb.len > 0) return false;
    return restIsEmpty(sb, 0);
}

fn writeRebaseHead(oid: Oid) i32 {
    refs.update("REBASE_HEAD", oid, null, "rebase", true) catch {
        util.err("{s}", .{refs.last_error});
        util.err("could not update {s}", .{"REBASE_HEAD"});
        return -1;
    };
    return 0;
}

fn doCommit(msg_file: ?[]const u8, author: ?[]const u8, reflog_action: []const u8, opts: *Opts, flags: u32, oid: ?Oid) i32 {
    var res: i32 = 1;
    if (flags & EDIT_MSG == 0 and flags & VERIFY_MSG == 0) {
        var new_oid: Oid = undefined;
        var sb: ?[]const u8 = null;
        if (msg_file) |f| {
            sb = os.readFile(f) orelse {
                util.err("unable to read commit message from '{s}': {s}", .{ f, os.lastErr() });
                return -1;
            };
        }
        res = tryToCommit(sb, author, reflog_action, opts, flags, &new_oid);
        if (res == 0) {
            refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "") catch {};
            _ = os.unlink(mergeMsgPath());
            if (!isRebaseI(opts)) summary.printCommitSummary(new_oid, summary.SUMMARY_SHOW_AUTHOR_DATE);
            return res;
        }
    }
    if (res == 1) {
        if (isRebaseI(opts)) {
            if (oid) |o| if (writeRebaseHead(o) != 0) return -1;
        }
        return runGitCommit(msg_file, reflog_action, opts, flags);
    }
    return res;
}

fn isOriginalCommitEmpty(commit: *Commit) i32 {
    if (!cn.parse(commit)) {
        util.err("could not parse commit {s}", .{hash.hex(commit.oid())});
        return -1;
    }
    var ptree: Oid = undefined;
    if (commit.parents) |p| {
        if (!cn.parse(p.item)) {
            util.err("could not parse parent commit {s}", .{hash.hex(p.item.oid())});
            return -1;
        }
        ptree = p.item.tree;
    } else ptree = hash.fromHex(hash.empty_tree_hex).?;
    return if (hash.eql(ptree, commit.tree)) 1 else 0;
}

fn allowEmpty(opts: *Opts, commit: *Commit) i32 {
    const index_unchanged = isIndexUnchanged();
    if (index_unchanged < 0) return index_unchanged;
    if (index_unchanged == 0) return 0;
    const originally_empty = isOriginalCommitEmpty(commit);
    if (originally_empty < 0) return originally_empty;
    if (originally_empty != 0) return if (opts.allow_empty) 1 else 0;
    if (opts.keep_redundant_commits) return 1;
    if (opts.drop_redundant_commits) return 2;
    return 0;
}

// ---------------------------------------------------------------------------
// todo list

pub const Command = enum(u8) {
    pick = 0,
    revert,
    edit,
    reword,
    fixup,
    squash,
    exec,
    break_,
    label,
    reset,
    merge,
    update_ref,
    noop,
    drop,
    comment,
    invalid,
};

const CmdInfo = struct { c: u8, str: []const u8 };
const todo_command_info = [_]CmdInfo{
    .{ .c = 'p', .str = "pick" },
    .{ .c = 0, .str = "revert" },
    .{ .c = 'e', .str = "edit" },
    .{ .c = 'r', .str = "reword" },
    .{ .c = 'f', .str = "fixup" },
    .{ .c = 's', .str = "squash" },
    .{ .c = 'x', .str = "exec" },
    .{ .c = 'b', .str = "break" },
    .{ .c = 'l', .str = "label" },
    .{ .c = 't', .str = "reset" },
    .{ .c = 'm', .str = "merge" },
    .{ .c = 'u', .str = "update-ref" },
    .{ .c = 0, .str = "noop" },
    .{ .c = 'd', .str = "drop" },
};

pub fn commandToString(c: Command) []const u8 {
    const i = @intFromEnum(c);
    if (i < @intFromEnum(Command.comment)) return todo_command_info[i].str;
    if (c == .comment) return trailer.commentLineStr();
    util.die("unknown command: {d}", .{i});
}

pub fn commandToChar(c: Command) u8 {
    const i = @intFromEnum(c);
    if (i < @intFromEnum(Command.comment)) return todo_command_info[i].c;
    return 0;
}

pub fn isNoop(c: Command) bool {
    return @intFromEnum(c) >= @intFromEnum(Command.noop);
}
pub fn isFixup(c: Command) bool {
    return c == .fixup or c == .squash;
}
fn isPickOrSimilar(c: Command) bool {
    return switch (c) {
        .pick, .revert, .edit, .reword, .fixup, .squash => true,
        else => false,
    };
}

pub const TODO_EDIT_MERGE_MSG: u32 = 1 << 0;
pub const TODO_REPLACE_FIXUP_MSG: u32 = 1 << 1;
pub const TODO_EDIT_FIXUP_MSG: u32 = 1 << 2;

pub const Item = struct {
    command: Command,
    commit: ?*Commit = null,
    flags: u32 = 0,
    arg_len: usize = 0,
    offset_in_buf: usize = 0,
    arg_offset: usize = 0,
};

pub const TodoList = struct {
    buf: util.Buf = .empty,
    items: std.ArrayList(Item) = .empty,
    current: usize = 0,
    done_nr: i32 = 0,
    total_nr: i32 = 0,

    pub fn getArg(self: *const TodoList, item: *const Item) []const u8 {
        return self.buf.items[item.arg_offset .. item.arg_offset + item.arg_len];
    }
    fn lineOffset(self: *const TodoList, index: usize) usize {
        return if (index < self.items.items.len) self.items.items[index].offset_in_buf else self.buf.items.len;
    }
    pub fn line(self: *const TodoList, index: usize) []const u8 {
        return self.buf.items[self.lineOffset(index)..self.lineOffset(index + 1)];
    }
};

/// is_command(): returns the rest after the command if bol starts with it.
fn isCommand(cmd: Command, bol: []const u8) ?[]const u8 {
    const info = todo_command_info[@intFromEnum(cmd)];
    var p: []const u8 = undefined;
    if (util.skipPrefix(bol, info.str)) |r| {
        p = r;
    } else if (info.c != 0 and bol.len > 0 and bol[0] == info.c) {
        p = bol[1..];
    } else if (info.c != 0 and bol.len > 0) {
        return null;
    } else return null;
    if (p.len == 0 or p[0] == ' ' or p[0] == '\t' or p[0] == '\n' or p[0] == '\r') return p;
    return null;
}

/// sequencer_parse_todo_command()
pub fn parseTodoCommand(p: []const u8) ?struct { cmd: Command, rest: []const u8 } {
    var i: u8 = 0;
    while (i < @intFromEnum(Command.comment)) : (i += 1) {
        const c: Command = @enumFromInt(i);
        if (isCommand(c, p)) |r| return .{ .cmd = c, .rest = r };
    }
    if (util.startsWith(p, trailer.commentLineStr())) return .{ .cmd = .comment, .rest = p };
    if (p.len == 0 or p[0] == '\n' or (p[0] == '\r' and p.len > 1 and p[1] == '\n')) return .{ .cmd = .comment, .rest = p };
    return null;
}

fn spanSpaces(s: []const u8) usize {
    var i: usize = 0;
    while (i < s.len and (s[i] == ' ' or s[i] == '\t')) i += 1;
    return i;
}

fn checkLabelOrRefArg(cmd: Command, arg: []const u8) i32 {
    switch (cmd) {
        .label => {
            if (util.eql(arg, "#") or !refs.checkRefnameFormat(arg, refs.ALLOW_ONELEVEL)) {
                util.err("'{s}' is not a valid label", .{arg});
                return -1;
            }
        },
        .update_ref => {
            if (!refs.checkRefnameFormat(arg, refs.ALLOW_ONELEVEL)) {
                util.err("'{s}' is not a valid refname", .{arg});
                return -1;
            }
            if (!refs.checkRefnameFormat(arg, 0)) {
                util.err("update-ref requires a fully qualified refname e.g. refs/heads/{s}", .{arg});
                return -1;
            }
        },
        else => {},
    }
    return 0;
}

fn checkMergeCommitInsn(cmd: Command) i32 {
    switch (cmd) {
        .pick => {
            util.err("'{s}' does not accept merge commits", .{"pick"});
            advice.adviseIfEnabled("rebaseTodoError", "'pick' does not take a merge commit. If you wanted to\nreplay the merge, use 'merge -C' on the commit.");
            return -1;
        },
        .reword => {
            util.err("'{s}' does not accept merge commits", .{"reword"});
            advice.adviseIfEnabled("rebaseTodoError", "'reword' does not take a merge commit. If you wanted to\nreplay the merge and reword the commit message, use\n'merge -c' on the commit");
            return -1;
        },
        .edit => {
            util.err("'{s}' does not accept merge commits", .{"edit"});
            advice.adviseIfEnabled("rebaseTodoError", "'edit' does not take a merge commit. If you wanted to\nreplay the merge, use 'merge -C' on the commit, and then\n'break' to give the control back to you so that you can\ndo 'git commit --amend && git rebase --continue'.");
            return -1;
        },
        .fixup, .squash => {
            util.err("cannot squash merge commit into another commit", .{});
            return -1;
        },
        else => return 0,
    }
}

/// parse_insn_line(); `bol`/`eol` are offsets into buf.
fn parseInsnLine(opts: *const Opts, item: *Item, buf: []const u8, bol0: usize, eol: usize) i32 {
    item.flags = 0;
    var bol = bol0 + spanSpaces(buf[bol0..eol]);
    const pr = parseTodoCommand(buf[bol..]) orelse {
        var e = bol;
        while (e < buf.len and buf[e] != ' ' and buf[e] != '\t' and buf[e] != '\r' and buf[e] != '\n') e += 1;
        util.err("invalid command '{s}'", .{buf[bol..e]});
        return -1;
    };
    item.command = pr.cmd;
    bol = buf.len - pr.rest.len;
    if (item.command == .comment) {
        item.commit = null;
        item.arg_offset = bol;
        item.arg_len = eol - bol;
        return 0;
    }
    const padding = spanSpaces(buf[bol..eol]);
    bol += padding;
    if (item.command == .noop or item.command == .break_) {
        if (bol != eol) {
            util.err("{s} does not accept arguments: '{s}'", .{ commandToString(item.command), buf[bol..eol] });
            return -1;
        }
        item.commit = null;
        item.arg_offset = bol;
        item.arg_len = 0;
        return 0;
    }
    if (padding == 0) {
        util.err("missing arguments for {s}", .{commandToString(item.command)});
        return -1;
    }
    if (item.command == .exec or item.command == .label or item.command == .reset or item.command == .update_ref) {
        item.commit = null;
        item.arg_offset = bol;
        item.arg_len = eol - bol;
        if (item.command == .label or item.command == .update_ref)
            return checkLabelOrRefArg(item.command, buf[bol..eol]);
        return 0;
    }
    if (item.command == .fixup) {
        if (util.startsWith(buf[bol..eol], "-C")) {
            bol += 2;
            bol += spanSpaces(buf[bol..eol]);
            item.flags |= TODO_REPLACE_FIXUP_MSG;
        } else if (util.startsWith(buf[bol..eol], "-c")) {
            bol += 2;
            bol += spanSpaces(buf[bol..eol]);
            item.flags |= TODO_EDIT_FIXUP_MSG;
        }
    }
    if (item.command == .merge) {
        if (util.startsWith(buf[bol..eol], "-C")) {
            bol += 2;
            bol += spanSpaces(buf[bol..eol]);
        } else if (util.startsWith(buf[bol..eol], "-c")) {
            bol += 2;
            bol += spanSpaces(buf[bol..eol]);
            item.flags |= TODO_EDIT_MERGE_MSG;
        } else {
            item.flags |= TODO_EDIT_MERGE_MSG;
            item.commit = null;
            item.arg_offset = bol;
            item.arg_len = eol - bol;
            return 0;
        }
    }
    var end = bol;
    while (end < buf.len and buf[end] != ' ' and buf[end] != '\t' and buf[end] != '\n') end += 1;
    const name = buf[bol..end];
    const oid = revparse.getOid(name);
    if (oid == null) util.err("could not parse '{s}'", .{name});
    bol = end + spanSpaces(buf[end..@max(end, eol)]);
    item.arg_offset = bol;
    item.arg_len = if (eol > bol) eol - bol else 0;
    if (oid == null) return -1;
    item.commit = cn.lookupCommitReference(oid.?);
    if (item.commit == null) return -1;
    if (isRebaseI(opts)) {
        _ = cn.parse(item.commit.?);
        if (item.commit.?.parents) |p| if (p.next != null) return checkMergeCommitInsn(item.command);
    }
    return 0;
}

pub const LastAction = enum { pick, revert };

/// sequencer_get_last_command()
pub fn getLastCommand() ?LastAction {
    const data = os.readFile(todoFile()) orelse return null;
    var i: usize = 0;
    while (i < data.len and (data[i] == ' ' or data[i] == '\t' or data[i] == '\r' or data[i] == '\n')) i += 1;
    const bol = data[i..];
    if (isCommand(.pick, bol)) |r| {
        if (r.len > 0 and (r[0] == ' ' or r[0] == '\t')) return .pick;
        return null;
    }
    if (isCommand(.revert, bol)) |r| {
        if (r.len > 0 and (r[0] == ' ' or r[0] == '\t')) return .revert;
    }
    return null;
}

/// todo_list_parse_insn_buffer(); returns 0 or -1.
pub fn parseInsnBuffer(opts: *const Opts, todo: *TodoList) i32 {
    const buf = todo.buf.items;
    var res: i32 = 0;
    var fixup_okay = os.exists(rebasePath("done"));
    todo.current = 0;
    todo.items = .empty;
    todo.total_nr = 0;
    var p: usize = 0;
    var lineno: usize = 1;
    while (p < buf.len) : (lineno += 1) {
        var eol = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse buf.len;
        const next_p = if (eol < buf.len) eol + 1 else eol;
        if (p != eol and buf[eol - 1] == '\r') eol -= 1;
        var item = Item{ .command = .comment, .offset_in_buf = p };
        if (parseInsnLine(opts, &item, buf, p, eol) != 0) {
            util.err("invalid line {d}: {s}", .{ lineno, buf[p..eol] });
            res = -1;
            item.command = .invalid;
            item.arg_offset = p;
            item.arg_len = eol - p;
            item.commit = null;
        }
        if (item.command != .comment) todo.total_nr += 1;
        if (fixup_okay) {} else if (isFixup(item.command)) {
            util.err("cannot '{s}' without a previous commit", .{commandToString(item.command)});
            res = -1;
        } else if (!isNoop(item.command)) fixup_okay = true;
        todo.items.append(gpa, item) catch util.oom();
        p = next_p;
    }
    return res;
}

fn countCommands(todo: *const TodoList) i32 {
    var n: i32 = 0;
    for (todo.items.items) |it| {
        if (it.command != .comment) n += 1;
    }
    return n;
}

fn readPopulateTodo(todo: *TodoList, opts: *Opts) i32 {
    const todo_file = getTodoPath(opts);
    todo.buf = .empty;
    const data = os.readFile(todo_file) orelse {
        util.err("could not open '{s}': {s}", .{ todo_file, os.lastErr() });
        return -1;
    };
    todo.buf.appendSlice(gpa, data) catch util.oom();
    if (parseInsnBuffer(opts, todo) != 0) {
        if (isRebaseI(opts)) {
            util.err("please fix this using 'git rebase --edit-todo'.", .{});
            return -1;
        }
        util.err("unusable instruction sheet: '{s}'", .{todo_file});
        return -1;
    }
    if (todo.items.items.len == 0 and (!isRebaseI(opts) or !os.exists(rebasePath("done")))) {
        util.err("no commits parsed.", .{});
        return -1;
    }
    if (!isRebaseI(opts)) {
        const valid: Command = if (opts.action == .pick) .pick else .revert;
        for (todo.items.items) |it| {
            if (it.command == valid) continue;
            if (valid == .pick) {
                util.err("cannot cherry-pick during a revert.", .{});
            } else util.err("cannot revert during a cherry-pick.", .{});
            return -1;
        }
    }
    if (isRebaseI(opts)) {
        var done = TodoList{};
        if (os.readFile(rebasePath("done"))) |d| {
            if (d.len > 0) {
                done.buf.appendSlice(gpa, d) catch util.oom();
                todo.done_nr = if (parseInsnBuffer(opts, &done) == 0) countCommands(&done) else 0;
            } else todo.done_nr = 0;
        } else todo.done_nr = 0;
        todo.total_nr = todo.done_nr + countCommands(todo);
        writeFile(rebasePath("end"), util.fmt("{d}\n", .{todo.total_nr}));
    }
    return 0;
}

// ---------------------------------------------------------------------------
// options sheet

const PopulateCtx = struct { opts: *Opts };

fn populateOptsCb(ctxp: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo) i32 {
    const ctx: *PopulateCtx = @ptrCast(@alignCast(ctxp));
    const opts = ctx.opts;
    var is_bool = false;
    var error_flag = true;
    const v = value orelse {
        util.err("invalid value for '{s}': '{s}'", .{ key, "" });
        return -1;
    };
    _ = &is_bool;
    if (util.eql(key, "options.no-commit")) {
        opts.no_commit = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.edit")) {
        opts.edit = if (boolOrInt(key, v, kvi, &error_flag)) 1 else 0;
    } else if (util.eql(key, "options.allow-empty")) {
        opts.allow_empty = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.allow-empty-message")) {
        opts.allow_empty_message = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.drop-redundant-commits")) {
        opts.drop_redundant_commits = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.keep-redundant-commits")) {
        opts.keep_redundant_commits = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.signoff")) {
        opts.signoff = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.record-origin")) {
        opts.record_origin = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.allow-ff")) {
        opts.allow_ff = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.mainline")) {
        opts.mainline = config.configInt(key, v, kvi);
    } else if (util.eql(key, "options.strategy")) {
        opts.strategy = util.dupe(v);
    } else if (util.eql(key, "options.gpg-sign")) {
        opts.gpg_sign = util.dupe(v);
    } else if (util.eql(key, "options.strategy-option")) {
        opts.xopts.append(gpa, util.dupe(v)) catch util.oom();
    } else if (util.eql(key, "options.allow-rerere-auto")) {
        opts.allow_rerere_auto = if (boolOrInt(key, v, kvi, &error_flag)) RERERE_AUTOUPDATE else RERERE_NOAUTOUPDATE;
    } else if (util.eql(key, "options.default-msg-cleanup")) {
        opts.explicit_cleanup = true;
        opts.default_msg_cleanup = c_commit.getCleanupMode(v, true);
    } else {
        util.err("invalid key: {s}", .{key});
        return -1;
    }
    if (!error_flag) {
        util.err("invalid value for '{s}': '{s}'", .{ key, v });
        return -1;
    }
    return 0;
}

fn boolOrInt(key: []const u8, v: []const u8, kvi: *const config.KvInfo, ok: *bool) bool {
    var is_bool = false;
    const r = config.configBoolOrInt(key, v, kvi, &is_bool);
    ok.* = true;
    return r != 0;
}

fn parseStrategyOpts(opts: *Opts, raw: []const u8) void {
    var s = raw;
    if (s.len > 0 and s[0] == ' ') s = s[1..];
    const argv = @import("commands.zig").splitCmdline(s) orelse util.die("could not split '{s}'", .{s});
    for (argv) |a| {
        const arg = util.skipPrefix(a, "--") orelse a;
        opts.xopts.append(gpa, arg) catch util.oom();
    }
}

fn readStrategyOpts(opts: *Opts) void {
    const s = readOneliner(rebasePath("strategy"), false, false) orelse return;
    opts.strategy = s;
    const o = readOneliner(rebasePath("strategy_opts"), false, false) orelse return;
    parseStrategyOpts(opts, o);
}

fn readTrailers(opts: *Opts) i32 {
    const data = os.readFile(rebasePath("trailer")) orelse {
        if (os.errno() != os.ENOENT) {
            util.err("cannot read trailers files", .{});
            return -1;
        }
        return 0;
    };
    if (data.len == 0) {
        util.err("trailers file is empty", .{});
        return -1;
    }
    var p: []const u8 = data;
    while (std.mem.indexOfScalar(u8, p, '\n')) |nl| {
        if (nl == 0) {
            util.err("trailers file contains empty line", .{});
            return -1;
        }
        opts.trailer_args.append(gpa, p[0..nl]) catch util.oom();
        p = p[nl + 1 ..];
    }
    return 0;
}

pub fn readPopulateOpts(opts: *Opts) i32 {
    if (isRebaseI(opts)) {
        if (readOneliner(rebasePath("gpg_sign_opt"), false, true)) |b| {
            if (util.startsWith(b, "-S")) opts.gpg_sign = b[2..];
        }
        if (readOneliner(rebasePath("allow_rerere_autoupdate"), false, true)) |b| {
            if (util.eql(b, "--rerere-autoupdate")) {
                opts.allow_rerere_auto = RERERE_AUTOUPDATE;
            } else if (util.eql(b, "--no-rerere-autoupdate")) opts.allow_rerere_auto = RERERE_NOAUTOUPDATE;
        }
        if (os.exists(rebasePath("verbose"))) opts.verbose = true;
        if (os.exists(rebasePath("quiet"))) opts.quiet = true;
        if (os.exists(rebasePath("signoff"))) {
            opts.allow_ff = false;
            opts.signoff = true;
        }
        if (os.exists(rebasePath("cdate_is_adate"))) {
            opts.allow_ff = false;
            opts.committer_date_is_author_date = true;
        }
        if (os.exists(rebasePath("ignore_date"))) {
            opts.allow_ff = false;
            opts.ignore_date = true;
        }
        if (os.exists(rebasePath("reschedule-failed-exec"))) {
            opts.reschedule_failed_exec = true;
        } else if (os.exists(rebasePath("no-reschedule-failed-exec"))) opts.reschedule_failed_exec = false;
        if (os.exists(rebasePath("drop_redundant_commits"))) opts.drop_redundant_commits = true;
        if (os.exists(rebasePath("keep_redundant_commits"))) opts.keep_redundant_commits = true;
        readStrategyOpts(opts);
        if (readTrailers(opts) != 0) return -1;
        if (readOneliner(rebasePath("current-fixups"), false, true)) |cf| {
            opts.current_fixups = .empty;
            opts.current_fixups.appendSlice(gpa, cf) catch util.oom();
            opts.current_fixup_count = 1;
            var i: usize = 0;
            while (std.mem.indexOfScalarPos(u8, cf, i, '\n')) |nl| {
                if (nl + 1 < cf.len and cf[nl + 1] != '\n') opts.current_fixup_count += 1;
                i = nl + 1;
            }
        }
        if (readOneliner(rebasePath("squash-onto"), false, false)) |so| {
            opts.squash_onto = revparse.getOidCommittish(so) orelse {
                util.err("unusable squash-onto", .{});
                return -1;
            };
            opts.have_squash_onto = true;
        }
        return 0;
    }
    if (!os.exists(optsFile())) return 0;
    var ctx = PopulateCtx{ .opts = opts };
    if (config.fromFile(.{ .f = populateOptsCb, .ctx = &ctx }, optsFile(), .local, null, null) < 0) {
        util.err("malformed options sheet: '{s}'", .{optsFile()});
        return -1;
    }
    return 0;
}

fn saveOpts(opts: *Opts) i32 {
    const f = optsFile();
    var res: i32 = 0;
    if (opts.no_commit) res |= config.setInFileGently(f, "options.no-commit", null, "true");
    if (opts.edit >= 0) res |= config.setInFileGently(f, "options.edit", null, if (opts.edit != 0) "true" else "false");
    if (opts.allow_empty) res |= config.setInFileGently(f, "options.allow-empty", null, "true");
    if (opts.allow_empty_message) res |= config.setInFileGently(f, "options.allow-empty-message", null, "true");
    if (opts.drop_redundant_commits) res |= config.setInFileGently(f, "options.drop-redundant-commits", null, "true");
    if (opts.keep_redundant_commits) res |= config.setInFileGently(f, "options.keep-redundant-commits", null, "true");
    if (opts.signoff) res |= config.setInFileGently(f, "options.signoff", null, "true");
    if (opts.record_origin) res |= config.setInFileGently(f, "options.record-origin", null, "true");
    if (opts.allow_ff) res |= config.setInFileGently(f, "options.allow-ff", null, "true");
    if (opts.mainline != 0) res |= config.setInFileGently(f, "options.mainline", null, util.fmt("{d}", .{opts.mainline}));
    if (opts.strategy) |s| res |= config.setInFileGently(f, "options.strategy", null, s);
    if (opts.gpg_sign) |g| res |= config.setInFileGently(f, "options.gpg-sign", null, g);
    for (opts.xopts.items) |x| res |= config.setMultivarInFile(f, "options.strategy-option", x, .{ .pattern = "^$" }, null, .{});
    if (opts.allow_rerere_auto != 0) res |= config.setInFileGently(f, "options.allow-rerere-auto", null, if (opts.allow_rerere_auto == RERERE_AUTOUPDATE) "true" else "false");
    if (opts.explicit_cleanup) res |= config.setInFileGently(f, "options.default-msg-cleanup", null, describeCleanupMode(opts.default_msg_cleanup));
    return res;
}

// ---------------------------------------------------------------------------
// state

fn removeTree(path: []const u8) bool {
    const st = os.lstatPath(path) orelse return true;
    if (st.isDir()) {
        if (os.listDir(path)) |ents| {
            for (ents) |de| _ = removeTree(util.concat(&.{ path, "/", de.name }));
        }
        return os.rmdir(path);
    }
    return os.unlink(path);
}

/// sequencer_remove_state()
pub fn removeState(opts: *Opts) i32 {
    var ret: i32 = 0;
    if (isRebaseI(opts)) {
        if (os.readFile(rebasePath("refs-to-delete"))) |data| {
            var it = std.mem.splitScalar(u8, data, '\n');
            while (it.next()) |p| {
                if (p.len == 0) continue;
                refs.deleteRef(p, null, 0, "(rebase) cleanup") catch {
                    util.warn("could not delete '{s}'", .{p});
                    ret = -1;
                };
            }
        }
    }
    const dir = getDir(opts);
    if (os.exists(dir) and !removeTree(dir)) {
        util.err("could not remove '{s}'", .{dir});
        ret = -1;
    }
    return ret;
}

fn walkRevsPopulateTodo(todo: *TodoList, opts: *Opts) i32 {
    const command: Command = if (opts.action == .pick) .pick else .revert;
    const command_string = todo_command_info[@intFromEnum(command)].str;
    const revs = opts.revs.?;
    if (opts.action == .pick and !revs.no_walk) revs.reverse = !revs.reverse;
    if (!revision.prepareRevisionWalk(revs)) {
        util.err("revision walk setup failed", .{});
        return -1;
    }
    const encoding = pretty.logOutputEncoding();
    while (revision.getRevision(revs)) |commit| {
        const buf = pretty.logmsgReencode(commit, encoding).msg;
        const s = findCommitSubject(buf);
        const item = Item{ .command = command, .commit = commit, .offset_in_buf = todo.buf.items.len };
        util.bufPrint(&todo.buf, "{s} {s} {s}\n", .{ command_string, shortCommitName(commit), s.rest[0..s.len] });
        todo.items.append(gpa, item) catch util.oom();
    }
    if (todo.items.items.len == 0) {
        util.err("empty commit set passed", .{});
        return -1;
    }
    return 0;
}

fn createSeqDir() i32 {
    const advise_skip = refs.exists("REVERT_HEAD") or refs.exists("CHERRY_PICK_HEAD");
    const skip_s: []const u8 = if (advise_skip) "--skip | " else "";
    if (getLastCommand()) |action| {
        switch (action) {
            .revert => {
                util.err("revert is already in progress", .{});
                if (advice.enabled("sequencerInUse")) advice.advise(util.fmt("try \"git revert (--continue | {s}--abort | --quit)\"", .{skip_s}));
            },
            .pick => {
                util.err("cherry-pick is already in progress", .{});
                if (advice.enabled("sequencerInUse")) advice.advise(util.fmt("try \"git cherry-pick (--continue | {s}--abort | --quit)\"", .{skip_s}));
            },
        }
        return -1;
    }
    if (!os.mkdir(seqDir(), 0o777)) {
        util.err("could not create sequencer directory '{s}': {s}", .{ seqDir(), os.lastErr() });
        return -1;
    }
    return 0;
}

fn saveHead(head: []const u8) i32 {
    return writeMessage(head, headFile(), true);
}

fn rollbackIsSafe() bool {
    var expected: Oid = hash.zero;
    if (os.readFile(abortSafetyFile())) |data| {
        const t = util.trim(data);
        expected = hash.fromHex(t) orelse blk: {
            if (t.len == 0) util.die("could not parse {s}", .{abortSafetyFile()});
            util.die("could not parse {s}", .{abortSafetyFile()});
            break :blk hash.zero;
        };
    } else if (os.errno() != os.ENOENT) {
        util.dieErrno("could not read '{s}'", .{abortSafetyFile()});
    }
    const actual = revparse.getOid("HEAD") orelse hash.zero;
    return hash.eql(actual, expected);
}

fn resetMerge(oid: Oid) i32 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "reset", "--merge" }) catch util.oom();
    if (!hash.isZero(oid)) argv.append(gpa, hash.hexAlloc(oid)) catch util.oom();
    index_mod.discard();
    const r = os.run(argv.items, .{});
    index_mod.discard();
    return if (r.status != 0 or r.signaled) 1 else 0;
}

fn rollbackSinglePick() i32 {
    if (!refs.exists("CHERRY_PICK_HEAD") and !refs.exists("REVERT_HEAD")) {
        util.err("no cherry-pick or revert in progress", .{});
        return -1;
    }
    const head = refs.readOid("HEAD") orelse {
        if (refs.readSymbolic("HEAD") != null) {
            util.err("cannot abort from a branch yet to be born", .{});
            return -1;
        }
        util.err("cannot resolve HEAD", .{});
        return -1;
    };
    return resetMerge(head);
}

fn skipSinglePick() i32 {
    const head = refs.readOid("HEAD") orelse {
        util.err("cannot resolve HEAD", .{});
        return -1;
    };
    return resetMerge(head);
}

/// sequencer_rollback()
pub fn rollback(opts: *Opts) i32 {
    const data = os.readFile(headFile()) orelse {
        if (os.errno() == os.ENOENT) return rollbackSinglePick();
        util.err("cannot open '{s}': {s}", .{ headFile(), os.lastErr() });
        return -1;
    };
    if (data.len == 0) {
        util.err("cannot read '{s}': {s}", .{ headFile(), "unexpected end of file" });
        return -1;
    }
    const line = if (std.mem.indexOfScalar(u8, data, '\n')) |nl| data[0..nl] else data;
    const oid = (if (line.len == 40) hash.fromHex(line) else null) orelse {
        util.err("stored pre-cherry-pick HEAD file '{s}' is corrupt", .{headFile()});
        return -1;
    };
    if (hash.isZero(oid)) {
        util.err("cannot abort from a branch yet to be born", .{});
        return -1;
    }
    if (!rollbackIsSafe()) {
        util.warn("You seem to have moved HEAD. Not rewinding, check your HEAD!", .{});
    } else if (resetMerge(oid) != 0) return -1;
    return removeState(opts);
}

/// sequencer_skip()
pub fn skip(opts: *Opts) i32 {
    const action = getLastCommand();
    var give_advice = false;
    switch (opts.action) {
        .revert => {
            if (!refs.exists("REVERT_HEAD")) {
                if (action != .revert) {
                    util.err("no revert in progress", .{});
                    return -1;
                }
                if (!rollbackIsSafe()) give_advice = true;
            }
        },
        .pick => {
            if (!refs.exists("CHERRY_PICK_HEAD")) {
                if (action != .pick) {
                    util.err("no cherry-pick in progress", .{});
                    return -1;
                }
                if (!rollbackIsSafe()) give_advice = true;
            }
        },
        else => unreachable,
    }
    if (give_advice) {
        util.err("there is nothing to skip", .{});
        if (advice.enabled("resolveConflict")) {
            advice.advise(util.fmt("have you committed already?\ntry \"git {s} --continue\"", .{if (action == .revert) "revert" else "cherry-pick"}));
        }
        return -1;
    }
    if (skipSinglePick() != 0) {
        util.err("failed to skip the commit", .{});
        return -1;
    }
    if (!os.isDir(seqDir())) return 0;
    return sequencerContinue(opts);
}

fn saveTodo(todo: *TodoList, opts: *Opts, reschedule: bool) i32 {
    const todo_path = getTodoPath(opts);
    var next = todo.current;
    if (isRebaseI(opts) and !reschedule) next += 1;
    const l = switch (lockfile.tryLock(todo_path)) {
        .ok => |l| l,
        .err => {
            util.err("could not lock '{s}': {s}", .{ todo_path, os.lastErr() });
            return -1;
        },
    };
    const offset = todo.lineOffset(next);
    l.write(todo.buf.items[offset..]);
    if (!l.commit()) {
        util.err("failed to finalize '{s}'", .{todo_path});
        return -1;
    }
    if (isRebaseI(opts) and !reschedule and next > 0) {
        const done = rebasePath("done");
        const prev = os.readFile(done) orelse "";
        os.writeFile(done, util.concat(&.{ prev, todo.line(next - 1) }), 0o666) catch {
            util.err("could not write to '{s}'", .{done});
            return -1;
        };
    }
    return 0;
}

// ---------------------------------------------------------------------------
// picking

fn shouldEdit(opts: *const Opts) bool {
    if (opts.edit < 0) return opts.action == .revert and os.isatty(0);
    return opts.edit != 0;
}

fn referToCommit(msgbuf: *util.Buf, commit: *Commit, use_ref: bool) void {
    if (use_ref) {
        const ctx = pretty.Context{ .abbrev = revparse.defaultAbbrev(), .date_mode = date_mod.DateMode.of(.short) };
        pretty.formatCommitMessage(commit, "%h (%s, %ad)", msgbuf, &ctx);
    } else {
        util.bufAppend(msgbuf, &hash.hex(commit.oid()));
    }
}

pub fn reflogAction(opts: *Opts) []const u8 {
    if (opts.reflog_action == null) {
        opts.reflog_action = os.getenv("GIT_REFLOG_ACTION") orelse actionName(opts);
    }
    return opts.reflog_action.?;
}

pub fn reflogMessage(opts: *Opts, sub_action: ?[]const u8, msg: ?[]const u8) []const u8 {
    var b: util.Buf = .empty;
    util.bufAppend(&b, reflogAction(opts));
    if (sub_action) |s| util.bufPrint(&b, " ({s})", .{s});
    if (msg) |m| {
        util.bufAppend(&b, ": ");
        util.bufAppend(&b, m);
    }
    return b.items;
}

/// sequencer_format_revert_message()
pub fn formatRevertMessage(subject: []const u8, commit: *Commit, parent: ?*Commit, use_ref: bool, message: *util.Buf) void {
    if (use_ref) {
        commentedAdd(message, "*** SAY WHY WE ARE REVERTING ON THE TITLE LINE ***");
        if (message.items.len == 0 or message.items[message.items.len - 1] != '\n') util.bufByte(message, '\n');
    } else if (util.skipPrefix(subject, "Revert \"")) |orig| {
        if (!util.startsWith(orig, "Revert \"")) {
            util.bufAppend(message, "Reapply \"");
            util.bufAppend(message, orig);
            util.bufAppend(message, "\n");
        } else {
            util.bufAppend(message, "Revert \"");
            util.bufAppend(message, subject);
            util.bufAppend(message, "\"\n");
        }
    } else {
        util.bufAppend(message, "Revert \"");
        util.bufAppend(message, subject);
        util.bufAppend(message, "\"\n");
    }
    util.bufAppend(message, "\nThis reverts commit ");
    referToCommit(message, commit, use_ref);
    if (commit.parents) |p| {
        if (p.next != null) {
            util.bufAppend(message, ", reversing\nchanges made to ");
            referToCommit(message, parent.?, use_ref);
        }
    }
    util.bufAppend(message, ".\n");
}

const cherry_picked_prefix = "(cherry picked from commit ";

pub const PickResult = enum { err, ok, conflicts, dropped };

fn tryMergeCommand(strategy: []const u8, xopts: []const []const u8, base: ?*Commit, head: Oid, remote: ?*Commit) i32 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.append(gpa, util.concat(&.{ "merge-", strategy })) catch util.oom();
    for (xopts) |x| argv.append(gpa, util.concat(&.{ "--", x })) catch util.oom();
    argv.append(gpa, if (base) |b| hash.hexAlloc(b.oid()) else hash.empty_tree_hex) catch util.oom();
    argv.append(gpa, "--") catch util.oom();
    argv.append(gpa, hash.hexAlloc(head)) catch util.oom();
    argv.append(gpa, if (remote) |r| hash.hexAlloc(r.oid()) else hash.empty_tree_hex) catch util.oom();
    index_mod.discard();
    const r = os.run(argv.items, .{});
    index_mod.discard();
    if (r.signaled) return -1;
    return @intCast(r.status);
}

/// Hook for rebase -i (squash message handling); set by the rebase module.
pub var update_squash_messages_fn: ?*const fn (cmd: Command, commit: *Commit, opts: *Opts, flag: u32) i32 = null;

fn doPickCommit(item: *Item, opts: *Opts, final_fixup: bool, check_todo: *bool) PickResult {
    var flags: u32 = if (shouldEdit(opts)) EDIT_MSG else 0;
    var msg_file: ?[]const u8 = if (shouldEdit(opts)) null else mergeMsgPath();
    var head: Oid = undefined;
    var unborn = false;
    var reword = false;
    var drop_commit = false;
    var author: ?[]const u8 = null;
    const command = item.command;
    const commit = item.commit.?;
    var res: i32 = 0;

    const reflog_action = if (isRebaseI(opts)) reflogMessage(opts, commandToString(command), null) else reflogAction(opts);

    if (opts.no_commit) {
        head = index_mod.get().writeTree(false) orelse {
            util.err("your index file is unmerged.", .{});
            return .err;
        };
    } else {
        const h = revparse.getOid("HEAD");
        unborn = h == null;
        if (h) |hh| head = hh;
        if (isPickOrSimilar(command) and opts.have_squash_onto and h != null and hash.eql(head, opts.squash_onto)) {
            if (isFixup(command)) {
                util.err("cannot fixup root commit", .{});
                return .err;
            }
            flags |= CREATE_ROOT_COMMIT;
            unborn = true;
        } else if (unborn) head = hash.fromHex(hash.empty_tree_hex).?;
        const cmp_tree = objects.peelTo(head, .tree) orelse head;
        if (mo.indexChangesAgainst(cmp_tree).len > 0) {
            if (errorDirtyIndex(opts) < 0) return .err;
        }
    }
    index_mod.discard();

    _ = cn.parse(commit);
    var parent: ?*Commit = null;
    if (commit.parents == null) {
        parent = null;
    } else if (commit.parents.?.next != null) {
        if (opts.mainline == 0) {
            util.err("commit {s} is a merge but no -m option was given.", .{hash.hex(commit.oid())});
            return .err;
        }
        var cnt: i32 = 1;
        var p = commit.parents;
        while (cnt != opts.mainline and p != null) : (cnt += 1) p = p.?.next;
        if (cnt != opts.mainline or p == null) {
            util.err("commit {s} does not have parent {d}", .{ hash.hex(commit.oid()), opts.mainline });
            return .err;
        }
        parent = p.?.item;
    } else if (1 < opts.mainline) {
        util.err("commit {s} does not have parent {d}", .{ hash.hex(commit.oid()), opts.mainline });
        return .err;
    } else parent = commit.parents.?.item;

    const msg = getMessage(commit);

    leave: {
        if (opts.allow_ff and !isFixup(command) and
            ((parent != null and hash.eql(parent.?.oid(), head)) or (parent == null and unborn)))
        {
            if (isRebaseI(opts)) _ = writeAuthorScript(msg.message);
            res = fastForwardTo(commit.oid(), head, unborn, opts);
            if (res != 0 or command != .reword) break :leave;
            reword = true;
            msg_file = null;
            // fast_forward_edit
            flags = EDIT_MSG | VERIFY_MSG | AMEND_MSG | ALLOW_EMPTY;
            res = runGitCommit(null, reflog_action, opts, flags);
            check_todo.* = true;
            res = if (res != 0) 1 else 0;
            if (res == 0 and final_fixup) finalFixupCleanup(opts);
            break :leave;
        }
        if (parent) |p| {
            if (!cn.parse(p)) {
                util.err("{s}: cannot parse parent commit {s}", .{ commandToString(command), hash.hex(p.oid()) });
                return .err;
            }
        }

        var base: ?*Commit = undefined;
        var next: ?*Commit = undefined;
        var base_label: []const u8 = undefined;
        var next_label: []const u8 = undefined;
        if (command == .revert) {
            base = commit;
            base_label = msg.label;
            next = parent;
            next_label = msg.parent_label;
            formatRevertMessage(msg.subject, commit, parent, opts.commit_use_reference, &opts.message);
        } else {
            base = parent;
            base_label = msg.parent_label;
            next = commit;
            next_label = msg.label;
            const s = findCommitSubject(msg.message);
            util.bufAppend(&opts.message, s.rest);
            if (opts.record_origin) {
                if (opts.message.items.len > 0 and opts.message.items[opts.message.items.len - 1] != '\n') util.bufByte(&opts.message, '\n');
                if (c_commit.hasConformingFooter(opts.message.items, "\x00", 0) == 0) util.bufByte(&opts.message, '\n');
                util.bufAppend(&opts.message, cherry_picked_prefix);
                util.bufAppend(&opts.message, &hash.hex(commit.oid()));
                util.bufAppend(&opts.message, ")\n");
            }
            if (!isFixup(command)) author = getAuthor(msg.message);
        }
        opts.have_message = true;

        if (command == .reword) {
            reword = true;
        } else if (isFixup(command)) {
            const f = update_squash_messages_fn orelse {
                res = -1;
                break :leave;
            };
            if (f(command, commit, opts, item.flags) != 0) {
                res = -1;
                break :leave;
            }
            flags |= AMEND_MSG;
            if (!final_fixup) {
                msg_file = rebasePath("message-squash");
            } else if (os.exists(rebasePath("message-fixup"))) {
                msg_file = rebasePath("message-fixup");
            } else {
                const dest = gitPath("SQUASH_MSG");
                _ = os.unlink(dest);
                const data = os.readFile(rebasePath("message-squash")) orelse {
                    util.err("could not copy '{s}' to '{s}'", .{ rebasePath("message-squash"), dest });
                    res = -1;
                    break :leave;
                };
                os.writeFile(dest, data, 0o666) catch {
                    util.err("could not copy '{s}' to '{s}'", .{ rebasePath("message-squash"), dest });
                    res = -1;
                    break :leave;
                };
                _ = os.unlink(mergeMsgPath());
                msg_file = dest;
                flags |= EDIT_MSG;
            }
        }

        if (opts.signoff and !isFixup(command)) c_commit.appendSignoff(&opts.message, 0, false);
        if (opts.trailer_args.items.len > 0 and !isFixup(command)) amendWithTrailers(&opts.message, opts.trailer_args.items);

        if (isRebaseI(opts) and writeAuthorScript(msg.message) < 0) {
            res = -1;
        } else if (opts.strategy == null or util.eql(opts.strategy.?, "recursive") or util.eql(opts.strategy.?, "ort") or command == .revert) {
            res = doRecursiveMerge(base, next, base_label, next_label, head, &opts.message, opts);
            if (res < 0) break :leave;
            res |= writeMessage(opts.message.items, mergeMsgPath(), false);
        } else {
            if (writeMessage(opts.message.items, mergeMsgPath(), false) != 0) {
                res = -1;
                break :leave;
            }
            res = tryMergeCommand(opts.strategy.?, opts.xopts.items, base, head, next);
            if (res != 0 and res != 1) res = -1;
        }

        if ((command == .pick or command == .reword or command == .edit) and !opts.no_commit and (res == 0 or res == 1)) {
            refs.update("CHERRY_PICK_HEAD", commit.oid(), null, "", true) catch {
                util.err("{s}", .{refs.last_error});
                res = -1;
            };
        }
        if (command == .revert and ((opts.no_commit and res == 0) or res == 1)) {
            refs.update("REVERT_HEAD", commit.oid(), null, "", true) catch {
                util.err("{s}", .{refs.last_error});
                res = -1;
            };
        }

        if (res != 0) {
            if (command == .revert) {
                util.err("could not revert {s}... {s}", .{ shortCommitName(commit), msg.subject });
            } else util.err("could not apply {s}... {s}", .{ shortCommitName(commit), msg.subject });
            printAdvice(res == 1, opts);
            _ = @import("rerere.zig").rerere(@intCast(opts.allow_rerere_auto));
            break :leave;
        }

        const allow = allowEmpty(opts, commit);
        if (allow < 0) {
            res = allow;
            break :leave;
        } else if (allow == 1) {
            flags |= ALLOW_EMPTY;
        } else if (allow == 2) {
            drop_commit = true;
            refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "") catch {};
            _ = os.unlink(mergeMsgPath());
            refs.deleteRef("AUTO_MERGE", null, refs.F_NO_DEREF, "") catch {};
            util.eprint("dropping {s} {s} -- patch contents already upstream\n", .{ hash.hex(commit.oid()), msg.subject });
        }
        if (!opts.no_commit and !drop_commit) {
            if (author != null or command == .revert or flags & AMEND_MSG != 0) {
                res = doCommit(msg_file, author, reflog_action, opts, flags, commit.oid());
            } else {
                util.err("unable to parse commit author", .{});
                res = -1;
            }
            check_todo.* = flags & EDIT_MSG != 0;
            if (res == 0 and reword) {
                flags = EDIT_MSG | VERIFY_MSG | AMEND_MSG | ALLOW_EMPTY;
                res = runGitCommit(null, reflog_action, opts, flags);
                check_todo.* = true;
            }
            res = if (res != 0) 1 else 0;
        }
        if (res == 0 and final_fixup) finalFixupCleanup(opts);
    }

    updateAbortSafetyFile();
    if (res < 0) return .err;
    if (res > 0) return .conflicts;
    if (drop_commit) return .dropped;
    return .ok;
}

fn finalFixupCleanup(opts: *Opts) void {
    _ = os.unlink(rebasePath("message-fixup"));
    _ = os.unlink(rebasePath("message-squash"));
    _ = os.unlink(rebasePath("current-fixups"));
    opts.current_fixups = .empty;
    opts.current_fixup_count = 0;
}

/// amend_strbuf_with_trailers(): run interpret-trailers over the message.
pub fn amendWithTrailers(buf: *util.Buf, args: []const []const u8) void {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "interpret-trailers" }) catch util.oom();
    for (args) |a| argv.append(gpa, util.concat(&.{ "--trailer=", a })) catch util.oom();
    const r = os.run(argv.items, .{ .stdin_data = buf.items, .capture_stdout = true });
    if (r.status != 0 or r.signaled) util.die("failed to add trailers", .{});
    buf.* = .empty;
    buf.appendSlice(gpa, r.stdout) catch util.oom();
}

fn readAndRefreshCache(opts: *Opts) i32 {
    index_mod.discard();
    const idx = switch (lockfile.tryLock(repo_mod.repo().indexPath())) {
        .ok => |l| blk: {
            l.rollback();
            break :blk index_mod.lockAndRead();
        },
        .err => index_mod.get(),
    };
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET | index_mod.REFRESH_UNMERGED, @as(?*const pathspec_mod.Pathspec, null), null);
    if (idx.lock != null) {
        if (idx.changed) idx.write() else idx.rollback();
    }
    _ = opts;
    return 0;
}

/// Hook for rebase -i: the full per-item loop is implemented there.
pub var pick_commits_fn: ?*const fn (todo: *TodoList, opts: *Opts) i32 = null;

fn pickCommits(todo: *TodoList, opts: *Opts) i32 {
    if (isRebaseI(opts)) {
        if (pick_commits_fn) |f| return f(todo, opts);
    }
    if (readAndRefreshCache(opts) != 0) return -1;
    while (todo.current < todo.items.items.len) {
        const item = &todo.items.items[todo.current];
        var check_todo = false;
        if (saveTodo(todo, opts, false) != 0) return -1;
        opts.message = .empty;
        opts.have_message = false;
        if (@intFromEnum(item.command) <= @intFromEnum(Command.squash)) {
            const r = doPickCommit(item, opts, false, &check_todo);
            switch (r) {
                .err => return -1,
                .conflicts => return 1,
                else => {},
            }
        } else if (!isNoop(item.command)) {
            util.err("unknown command {d}", .{@intFromEnum(item.command)});
            return -1;
        }
        todo.current += 1;
    }
    return removeState(opts);
}

fn continueSinglePick(opts: *Opts) i32 {
    if (!refs.exists("CHERRY_PICK_HEAD") and !refs.exists("REVERT_HEAD")) {
        util.err("no cherry-pick or revert in progress", .{});
        return -1;
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "commit" }) catch util.oom();
    if (opts.edit == 0 or (opts.edit < 0 and !os.isatty(0)))
        argv.appendSlice(gpa, &.{ "--no-edit", "--cleanup=strip" }) catch util.oom();
    index_mod.discard();
    const r = os.run(argv.items, .{});
    index_mod.discard();
    if (r.signaled) return -1;
    return @intCast(r.status);
}

/// Hook for rebase -i --continue (commit_staged_changes etc).
pub var continue_rebase_fn: ?*const fn (todo: *TodoList, opts: *Opts) i32 = null;

/// sequencer_continue()
pub fn sequencerContinue(opts: *Opts) i32 {
    if (readAndRefreshCache(opts) != 0) return -1;
    if (readPopulateOpts(opts) != 0) return -1;
    var todo = TodoList{};
    if (isRebaseI(opts)) {
        if (readPopulateTodo(&todo, opts) != 0) return -1;
        if (continue_rebase_fn) |f| {
            const r = f(&todo, opts);
            if (r != 0) return r;
        }
    } else if (!os.exists(getTodoPath(opts))) {
        return continueSinglePick(opts);
    } else if (readPopulateTodo(&todo, opts) != 0) {
        return -1;
    }
    if (!isRebaseI(opts)) {
        if (refs.exists("CHERRY_PICK_HEAD") or refs.exists("REVERT_HEAD")) {
            const r = continueSinglePick(opts);
            if (r != 0) return r;
        }
        index_mod.discard();
        const ht = objects.peelTo(revparse.getOid("HEAD") orelse hash.zero, .tree) orelse hash.fromHex(hash.empty_tree_hex).?;
        if (mo.indexChangesAgainst(ht).len > 0) return errorDirtyIndex(opts);
        todo.current += 1;
    }
    return pickCommits(&todo, opts);
}

fn singlePick(cmit: *Commit, opts: *Opts) i32 {
    var check_todo = false;
    var item = Item{ .command = if (opts.action == .pick) .pick else .revert, .commit = cmit };
    return switch (doPickCommit(&item, opts, false, &check_todo)) {
        .err => -1,
        .conflicts => 1,
        else => 0,
    };
}

/// sequencer_pick_revisions()
pub fn pickRevisions(opts: *Opts) i32 {
    const revs = opts.revs.?;
    if (readAndRefreshCache(opts) != 0) return -1;
    for (revs.pending.items) |pe| {
        const name = pe.name;
        if (name.len == 0) continue;
        if (revparse.getOid(name)) |oid| {
            if (cn.lookupCommitReference(oid) == null) {
                const t = objects.typeOf(oid);
                util.err("{s}: can't cherry-pick a {s}", .{ name, if (t) |tt| @tagName(tt) else "bad object" });
                return -1;
            }
        } else {
            util.err("{s}: bad revision", .{name});
            return -1;
        }
    }
    if (revs.cmdline.items.len == 1 and revs.cmdline.items[0].whence == .rev and revs.no_walk and revs.cmdline.items[0].flags == 0) {
        if (!revision.prepareRevisionWalk(revs)) {
            util.err("revision walk setup failed", .{});
            return -1;
        }
        const cmit = revision.getRevision(revs) orelse {
            util.err("empty commit set passed", .{});
            return -1;
        };
        return singlePick(cmit, opts);
    }
    var todo = TodoList{};
    if (walkRevsPopulateTodo(&todo, opts) != 0 or createSeqDir() < 0) return -1;
    const head = revparse.getOid("HEAD");
    if (head == null and opts.action == .revert) {
        util.err("can't revert as initial commit", .{});
        return -1;
    }
    if (saveHead(&hash.hex(head orelse hash.zero)) != 0) return -1;
    if (saveOpts(opts) != 0) return -1;
    updateAbortSafetyFile();
    return pickCommits(&todo, opts);
}

/// sequencer_post_commit_cleanup()
pub fn postCommitCleanup(verbose: bool) void {
    branchstate.sequencerPostCommitCleanup(verbose);
}
