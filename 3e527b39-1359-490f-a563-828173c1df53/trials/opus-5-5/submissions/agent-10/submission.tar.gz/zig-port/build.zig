const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.option(std.builtin.OptimizeMode, "optimize", "Prioritize performance, safety, or binary size") orelse .safe;

    // Zig 0.15 moved linkage onto the module, so link_libc is a module option and system
    // libraries are linked through the module rather than the compile step.
    const root = b.createModule(.{
        .root_source_file = b.path("src/main.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    root.linkSystemLibrary("z", .{});

    const exe = b.addExecutable(.{
        .name = "git",
        .root_module = root,
    });
    const install = b.addInstallArtifact(exe, .{});
    b.getInstallStep().dependOn(&install.step);

    // Like git's own install, provide dashed git-<cmd> entries next to the binary
    // (git dispatches on argv[0]); fake-ssh/--upload-pack style tests exec these.
    // Only done for the default prefix; never fails the build.
    const links = b.addSystemCommand(&.{
        "/bin/sh", "-c",
        \\d=zig-out/bin; [ -x "$d/git" ] || exit 0; cd "$d" || exit 0
        \\for c in $(./git --list-cmds=builtins 2>/dev/null) upload-pack receive-pack upload-archive shell; do
        \\  [ -e "git-$c" ] || ln -s git "git-$c" 2>/dev/null
        \\done
        \\exit 0
    });
    links.setCwd(b.path("."));
    links.has_side_effects = true;
    links.step.dependOn(&install.step);
    b.getInstallStep().dependOn(&links.step);
}
