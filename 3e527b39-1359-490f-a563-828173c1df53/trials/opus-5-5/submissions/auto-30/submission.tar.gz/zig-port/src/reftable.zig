//! The reftable format (reftable/*.c): records, blocks, table writer and
//! reader, and the tables.list stack with geometric auto-compaction.
//! Byte-compatible with the C implementation (format version 1, SHA-1).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const zlib = @import("zlib.zig");
const hash = @import("hash.zig");
const lockfile = @import("lockfile.zig");

const Oid = hash.Oid;
const gpa = util.gpa;
const Buf = util.Buf;

pub const HEADER_SIZE = 24;
pub const FOOTER_SIZE = 68;
const HASH_SIZE = 20;
const MAX_RESTARTS = 65535;

pub const BLOCK_REF = 'r';
pub const BLOCK_LOG = 'g';
pub const BLOCK_OBJ = 'o';
pub const BLOCK_INDEX = 'i';

pub const Error = error{ Io, Format, NotExist, Lock, Api, Zlib, EmptyTable, Refname, EntryTooBig, Outdated };

pub fn errStr(e: anyerror) []const u8 {
    return switch (e) {
        error.Io => "I/O error",
        error.Format => "corrupt reftable file",
        error.NotExist => "file does not exist",
        error.Lock => "data is locked",
        error.Api => "misuse of the reftable API",
        error.Zlib => "zlib failure",
        error.EmptyTable => "wrote empty table",
        error.Refname => "invalid refname",
        error.EntryTooBig => "entry too large",
        error.Outdated => "data concurrently modified",
        else => "general error",
    };
}

// ---------------------------------------------------------------- records

pub const RefValue = union(enum) {
    deletion,
    val1: Oid,
    val2: struct { oid: Oid, peeled: Oid },
    symref: []const u8,
};

pub const RefRecord = struct {
    name: []const u8,
    update_index: u64 = 0,
    value: RefValue,

    pub fn isDeletion(self: RefRecord) bool {
        return self.value == .deletion;
    }
    pub fn oid(self: RefRecord) ?Oid {
        return switch (self.value) {
            .val1 => |o| o,
            .val2 => |v| v.oid,
            else => null,
        };
    }
};

pub const LogUpdate = struct {
    old: Oid = hash.zero,
    new: Oid = hash.zero,
    name: []const u8 = "",
    email: []const u8 = "",
    time: u64 = 0,
    tz: i16 = 0,
    message: []const u8 = "",
};

pub const LogValue = union(enum) {
    deletion,
    update: LogUpdate,
};

pub const LogRecord = struct {
    name: []const u8,
    update_index: u64,
    value: LogValue,

    pub fn isDeletion(self: LogRecord) bool {
        return self.value == .deletion;
    }
};

const ObjRec = struct { prefix: []const u8, offsets: []const u64 };
const IdxRec = struct { key: []const u8, offset: u64 };

const Rec = union(enum) {
    ref: RefRecord,
    log: LogRecord,
    obj: ObjRec,
    idx: IdxRec,

    fn typ(self: Rec) u8 {
        return switch (self) {
            .ref => BLOCK_REF,
            .log => BLOCK_LOG,
            .obj => BLOCK_OBJ,
            .idx => BLOCK_INDEX,
        };
    }

    fn key(self: Rec, out: *Buf) void {
        out.clearRetainingCapacity();
        switch (self) {
            .ref => |r| util.bufAppend(out, r.name),
            .log => |l| {
                util.bufAppend(out, l.name);
                util.bufByte(out, 0);
                var b: [8]u8 = undefined;
                std.mem.writeInt(u64, &b, ~@as(u64, 0) - l.update_index, .big);
                util.bufAppend(out, &b);
            },
            .obj => |o| util.bufAppend(out, o.prefix),
            .idx => |i| util.bufAppend(out, i.key),
        }
    }

    fn valType(self: Rec) u8 {
        return switch (self) {
            .ref => |r| switch (r.value) {
                .deletion => 0,
                .val1 => 1,
                .val2 => 2,
                .symref => 3,
            },
            .log => |l| switch (l.value) {
                .deletion => 0,
                .update => 1,
            },
            .obj => |o| if (o.offsets.len > 0 and o.offsets.len < 8) @intCast(o.offsets.len) else 0,
            .idx => 0,
        };
    }

    fn encode(self: Rec, out: *Buf) void {
        switch (self) {
            .ref => |r| {
                putVarint(out, r.update_index);
                switch (r.value) {
                    .deletion => {},
                    .val1 => |o| util.bufAppend(out, &o),
                    .val2 => |v| {
                        util.bufAppend(out, &v.oid);
                        util.bufAppend(out, &v.peeled);
                    },
                    .symref => |s| putString(out, s),
                }
            },
            .log => |l| switch (l.value) {
                .deletion => {},
                .update => |u| {
                    util.bufAppend(out, &u.old);
                    util.bufAppend(out, &u.new);
                    putString(out, u.name);
                    putString(out, u.email);
                    putVarint(out, u.time);
                    var b: [2]u8 = undefined;
                    std.mem.writeInt(u16, &b, @bitCast(u.tz), .big);
                    util.bufAppend(out, &b);
                    putString(out, u.message);
                },
            },
            .obj => |o| {
                if (o.offsets.len == 0 or o.offsets.len >= 8) putVarint(out, o.offsets.len);
                if (o.offsets.len == 0) return;
                putVarint(out, o.offsets[0]);
                var last = o.offsets[0];
                for (o.offsets[1..]) |off| {
                    putVarint(out, off - last);
                    last = off;
                }
            },
            .idx => |i| putVarint(out, i.offset),
        }
    }
};

pub fn putVarint(b: *Buf, v0: u64) void {
    var tmp: [10]u8 = undefined;
    var pos: usize = tmp.len - 1;
    var v = v0;
    tmp[pos] = @intCast(v & 0x7f);
    while (true) {
        v >>= 7;
        if (v == 0) break;
        v -= 1;
        pos -= 1;
        tmp[pos] = 0x80 | @as(u8, @intCast(v & 0x7f));
    }
    util.bufAppend(b, tmp[pos..]);
}

pub fn getVarint(data: []const u8, pos: *usize) ?u64 {
    if (pos.* >= data.len) return null;
    var c = data[pos.*];
    pos.* += 1;
    var val: u64 = c & 0x7f;
    while (c & 0x80 != 0) {
        val +%= 1;
        if (val == 0 or (val >> (64 - 7)) != 0) return null;
        if (pos.* >= data.len) return null;
        c = data[pos.*];
        pos.* += 1;
        val = (val << 7) + (c & 0x7f);
    }
    return val;
}

fn putString(b: *Buf, s: []const u8) void {
    putVarint(b, s.len);
    util.bufAppend(b, s);
}

fn commonPrefix(a: []const u8, b: []const u8) usize {
    var i: usize = 0;
    while (i < a.len and i < b.len and a[i] == b[i]) i += 1;
    return i;
}

fn putBe24(dst: []u8, v: u32) void {
    dst[0] = @intCast((v >> 16) & 0xff);
    dst[1] = @intCast((v >> 8) & 0xff);
    dst[2] = @intCast(v & 0xff);
}

fn getBe24(src: []const u8) u32 {
    return (@as(u32, src[0]) << 16) | (@as(u32, src[1]) << 8) | src[2];
}

// ---------------------------------------------------------------- block writer

const BlockWriter = struct {
    buf: []u8,
    block_size: u32,
    header_off: u32,
    next: u32,
    restart_interval: u32,
    entries: u32 = 0,
    restarts: std.ArrayList(u32) = .empty,
    last_key: Buf = .empty,
    scratch: Buf = .empty,
    enc: Buf = .empty,

    fn init(self: *BlockWriter, btyp: u8, buf: []u8, block_size: u32, header_off: u32, restart_interval: u32) void {
        self.buf = buf;
        self.block_size = block_size;
        self.header_off = header_off;
        self.buf[header_off] = btyp;
        self.next = header_off + 4;
        self.restart_interval = restart_interval;
        self.entries = 0;
        self.restarts.clearRetainingCapacity();
        self.last_key.clearRetainingCapacity();
    }

    fn typ(self: *const BlockWriter) u8 {
        return self.buf[self.header_off];
    }

    fn add(self: *BlockWriter, rec: Rec) Error!void {
        rec.key(&self.scratch);
        if (self.scratch.items.len == 0) return error.Api;
        const last: []const u8 = if (self.entries % self.restart_interval == 0) "" else self.last_key.items;
        self.enc.clearRetainingCapacity();
        const prefix_len = commonPrefix(last, self.scratch.items);
        const suffix_len = self.scratch.items.len - prefix_len;
        putVarint(&self.enc, prefix_len);
        var is_restart = prefix_len == 0;
        putVarint(&self.enc, (@as(u64, suffix_len) << 3) | rec.valType());
        util.bufAppend(&self.enc, self.scratch.items[prefix_len..]);
        rec.encode(&self.enc);
        const n = self.enc.items.len;
        const avail = self.block_size - self.next;
        if (n > avail) return error.EntryTooBig;

        var rlen: u64 = self.restarts.items.len;
        if (rlen >= MAX_RESTARTS) is_restart = false;
        if (is_restart) rlen += 1;
        if (2 + 3 * rlen + n > avail) return error.EntryTooBig;
        @memcpy(self.buf[self.next..][0..n], self.enc.items);
        if (is_restart) util.append(u32, &self.restarts, self.next);
        self.next += @intCast(n);
        self.last_key.clearRetainingCapacity();
        util.bufAppend(&self.last_key, self.scratch.items);
        self.entries += 1;
    }

    /// Returns the raw bytes of the finished block (header area included).
    fn finish(self: *BlockWriter) []u8 {
        for (self.restarts.items) |r| {
            putBe24(self.buf[self.next..], r);
            self.next += 3;
        }
        std.mem.writeInt(u16, self.buf[self.next..][0..2], @intCast(self.restarts.items.len), .big);
        self.next += 2;
        putBe24(self.buf[1 + self.header_off ..], self.next);
        if (self.typ() == BLOCK_LOG) {
            const skip = 4 + self.header_off;
            const compressed = zlib.compress(self.buf[skip..self.next], 9);
            const out = gpa.alloc(u8, skip + compressed.len) catch util.oom();
            @memcpy(out[0..skip], self.buf[0..skip]);
            @memcpy(out[skip..], compressed);
            gpa.free(compressed);
            return out;
        }
        return self.buf[0..self.next];
    }
};

// ---------------------------------------------------------------- table writer

pub const WriteOpts = struct {
    block_size: u32 = 4096,
    restart_interval: u32 = 16,
    skip_index_objects: bool = false,
    exact_log_message: bool = false,
};

const BlockStats = struct {
    offset: u64 = 0,
    blocks: u32 = 0,
    index_blocks: u32 = 0,
    index_offset: u64 = 0,
};

const ObjEntry = struct { offsets: std.ArrayList(u64) = .empty };

pub const Writer = struct {
    opts: WriteOpts,
    min: u64 = 0,
    max: u64 = 0,
    out: Buf = .empty,
    next: u64 = 0,
    pending_padding: usize = 0,
    block: []u8,
    bw: BlockWriter = undefined,
    bw_active: bool = false,
    last_key: Buf = .empty,
    scratch: Buf = .empty,
    index: std.ArrayList(IdxRec) = .empty,
    obj_index: hash.OidMap(ObjEntry) = .empty,
    ref_stats: BlockStats = .{},
    obj_stats: BlockStats = .{},
    idx_stats: BlockStats = .{},
    log_stats: BlockStats = .{},
    object_id_len: u64 = 0,

    pub fn init(opts0: WriteOpts, min: u64, max: u64) Writer {
        var opts = opts0;
        if (opts.restart_interval == 0) opts.restart_interval = 16;
        if (opts.block_size == 0) opts.block_size = 4096;
        const blk = gpa.alloc(u8, opts.block_size) catch util.oom();
        @memset(blk, 0);
        var w = Writer{ .opts = opts, .min = min, .max = max, .block = blk };
        w.bw = .{ .buf = blk, .block_size = opts.block_size, .header_off = 0, .next = 0, .restart_interval = 16 };
        w.reinit(BLOCK_REF);
        return w;
    }

    fn stats(self: *Writer, typ: u8) *BlockStats {
        return switch (typ) {
            BLOCK_REF => &self.ref_stats,
            BLOCK_OBJ => &self.obj_stats,
            BLOCK_INDEX => &self.idx_stats,
            else => &self.log_stats,
        };
    }

    fn writeHeader(self: *Writer, dest: []u8) void {
        @memcpy(dest[0..4], "REFT");
        dest[4] = 1;
        putBe24(dest[5..], self.opts.block_size);
        std.mem.writeInt(u64, dest[8..16], self.min, .big);
        std.mem.writeInt(u64, dest[16..24], self.max, .big);
    }

    fn reinit(self: *Writer, typ: u8) void {
        const start: u32 = if (self.next == 0) HEADER_SIZE else 0;
        self.last_key.clearRetainingCapacity();
        self.bw.init(typ, self.block, self.opts.block_size, start, self.opts.restart_interval);
        self.bw_active = true;
    }

    fn paddedWrite(self: *Writer, data: []const u8, padding: usize) void {
        if (self.pending_padding > 0) {
            self.out.appendNTimes(gpa, 0, self.pending_padding) catch util.oom();
            self.pending_padding = 0;
        }
        self.pending_padding = padding;
        util.bufAppend(&self.out, data);
    }

    fn addRecord(self: *Writer, rec: Rec) Error!void {
        rec.key(&self.scratch);
        if (std.mem.order(u8, self.last_key.items, self.scratch.items) != .lt) return error.Api;
        self.last_key.clearRetainingCapacity();
        util.bufAppend(&self.last_key, self.scratch.items);
        if (!self.bw_active) self.reinit(rec.typ());
        if (self.bw.typ() != rec.typ()) return error.Api;
        self.bw.add(rec) catch |e| {
            if (e != error.EntryTooBig) return e;
            self.flushBlock();
            self.reinit(rec.typ());
            try self.bw.add(rec);
        };
    }

    fn flushBlock(self: *Writer) void {
        if (!self.bw_active) return;
        if (self.bw.entries == 0) return;
        const typ = self.bw.typ();
        const raw = self.bw.finish();
        var padding: usize = 0;
        if (typ != BLOCK_LOG) padding = self.opts.block_size - raw.len;
        const bs = self.stats(typ);
        if (bs.blocks == 0 and self.next > 0) bs.offset = self.next;
        bs.blocks += 1;
        if (self.next == 0) self.writeHeader(raw[0..HEADER_SIZE]);
        self.paddedWrite(raw, padding);
        util.append(IdxRec, &self.index, .{ .key = util.dupe(self.bw.last_key.items), .offset = self.next });
        self.next += padding + raw.len;
        if (typ == BLOCK_LOG) gpa.free(raw);
        self.bw_active = false;
    }

    fn finishSection(self: *Writer) Error!void {
        const typ = self.bw.typ();
        var index_start: u64 = 0;
        const before = self.idx_stats.blocks;
        self.flushBlock();
        while (self.index.items.len > 3) {
            index_start = self.next;
            self.reinit(BLOCK_INDEX);
            const idx = self.index.items;
            self.index = .empty;
            for (idx) |r| try self.addRecord(.{ .idx = r });
            self.flushBlock();
        }
        self.index.clearRetainingCapacity();
        const bs = self.stats(typ);
        bs.index_blocks = self.idx_stats.blocks - before;
        bs.index_offset = index_start;
        self.last_key.clearRetainingCapacity();
    }

    fn dumpObjectIndex(self: *Writer) Error!void {
        var keys: std.ArrayList(Oid) = .empty;
        var it = self.obj_index.keyIterator();
        while (it.next()) |k| util.append(Oid, &keys, k.*);
        std.mem.sort(Oid, keys.items, {}, hash.lessThan);
        var max: usize = 1;
        var i: usize = 1;
        while (i < keys.items.len) : (i += 1) {
            const n = commonPrefix(&keys.items[i], &keys.items[i - 1]);
            if (n > max) max = n;
        }
        self.object_id_len = max + 1;
        self.reinit(BLOCK_OBJ);
        for (keys.items) |*k| {
            const e = self.obj_index.getPtr(k.*).?;
            var rec = ObjRec{ .prefix = k[0..self.object_id_len], .offsets = e.offsets.items };
            self.bw.add(.{ .obj = rec }) catch |e1| {
                if (e1 != error.EntryTooBig) return e1;
                self.flushBlock();
                self.reinit(BLOCK_OBJ);
                self.bw.add(.{ .obj = rec }) catch |e2| {
                    if (e2 != error.EntryTooBig) return e2;
                    rec.offsets = &.{};
                    try self.bw.add(.{ .obj = rec });
                };
            };
        }
        try self.finishSection();
    }

    fn finishPublicSection(self: *Writer) Error!void {
        if (!self.bw_active) return;
        const typ = self.bw.typ();
        try self.finishSection();
        if (typ == BLOCK_REF and !self.opts.skip_index_objects and self.ref_stats.index_blocks > 0)
            try self.dumpObjectIndex();
        self.obj_index.clearRetainingCapacity();
        self.bw_active = false;
    }

    fn indexHash(self: *Writer, h: Oid) void {
        const off = self.next;
        const gop = self.obj_index.getOrPut(gpa, h) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = .{};
        const offs = &gop.value_ptr.offsets;
        if (offs.items.len > 0 and offs.items[offs.items.len - 1] == off) return;
        util.append(u64, offs, off);
    }

    pub fn addRef(self: *Writer, ref: RefRecord) Error!void {
        if (ref.update_index < self.min or ref.update_index > self.max) return error.Api;
        var r = ref;
        r.update_index -= self.min;
        try self.addRecord(.{ .ref = r });
        if (!self.opts.skip_index_objects) {
            switch (ref.value) {
                .val1 => |o| self.indexHash(o),
                .val2 => |v| {
                    self.indexHash(v.oid);
                    self.indexHash(v.peeled);
                },
                else => {},
            }
        }
    }

    fn addLogVerbatim(self: *Writer, log: LogRecord) Error!void {
        if (self.bw_active and self.bw.typ() == BLOCK_REF) try self.finishPublicSection();
        self.next -= self.pending_padding;
        self.pending_padding = 0;
        try self.addRecord(.{ .log = log });
    }

    pub fn addLog(self: *Writer, log: LogRecord) Error!void {
        switch (log.value) {
            .deletion => return self.addLogVerbatim(log),
            .update => |u| {
                if (log.update_index > self.max) return error.Api;
                var l = log;
                if (!self.opts.exact_log_message) {
                    var m = u.message;
                    while (m.len > 0 and m[m.len - 1] == '\n') m = m[0 .. m.len - 1];
                    if (std.mem.indexOfScalar(u8, m, '\n') != null) return error.Api;
                    var upd = u;
                    upd.message = util.concat(&.{ m, "\n" });
                    l.value = .{ .update = upd };
                }
                return self.addLogVerbatim(l);
            },
        }
    }

    /// Finish the table. Returns null for an empty table.
    pub fn close(self: *Writer) Error!?[]u8 {
        try self.finishPublicSection();
        const empty = self.next == 0;
        self.pending_padding = 0;
        if (empty) {
            var hdr: [HEADER_SIZE]u8 = undefined;
            self.writeHeader(&hdr);
            self.paddedWrite(&hdr, 0);
        }
        var footer: [FOOTER_SIZE]u8 = undefined;
        self.writeHeader(footer[0..HEADER_SIZE]);
        std.mem.writeInt(u64, footer[24..32], self.ref_stats.index_offset, .big);
        std.mem.writeInt(u64, footer[32..40], (self.obj_stats.offset << 5) | self.object_id_len, .big);
        std.mem.writeInt(u64, footer[40..48], self.obj_stats.index_offset, .big);
        std.mem.writeInt(u64, footer[48..56], self.log_stats.offset, .big);
        std.mem.writeInt(u64, footer[56..64], self.log_stats.index_offset, .big);
        std.mem.writeInt(u32, footer[64..68], zlib.crc(0, footer[0..64]), .big);
        self.paddedWrite(&footer, 0);
        if (empty) return null;
        return self.out.items;
    }
};

fn refLess(_: void, a: RefRecord, b: RefRecord) bool {
    return std.mem.order(u8, a.name, b.name) == .lt;
}

fn logLess(_: void, a: LogRecord, b: LogRecord) bool {
    const c = std.mem.order(u8, a.name, b.name);
    if (c != .eq) return c == .lt;
    return a.update_index > b.update_index;
}

pub fn sortLogs(logs: []LogRecord) void {
    std.mem.sort(LogRecord, logs, {}, logLess);
}

/// Write a whole table: refs are sorted by name, logs by (name, update_index desc).
pub fn writeTable(opts: WriteOpts, min: u64, max: u64, refs: []RefRecord, logs: []LogRecord) Error!?[]u8 {
    var w = Writer.init(opts, min, max);
    std.mem.sort(RefRecord, refs, {}, refLess);
    for (refs) |r| try w.addRef(r);
    sortLogs(logs);
    for (logs) |l| try w.addLog(l);
    return w.close();
}

// ---------------------------------------------------------------- reader

pub const Table = struct {
    name: []const u8 = "",
    min: u64 = 0,
    max: u64 = 0,
    /// file size minus footer
    size: u64 = 0,
    block_size: u32 = 0,
    refs: []RefRecord = &.{},
    logs: []LogRecord = &.{},
};

pub fn parseTable(data: []const u8) Error!Table {
    if (data.len < HEADER_SIZE + FOOTER_SIZE) return error.Format;
    if (!std.mem.eql(u8, data[0..4], "REFT")) return error.Format;
    if (data[4] != 1) return error.Format;
    var t = Table{};
    t.size = data.len - FOOTER_SIZE;
    const f = data[t.size..];
    if (!std.mem.eql(u8, f[0..HEADER_SIZE], data[0..HEADER_SIZE])) return error.Format;
    if (zlib.crc(0, f[0..64]) != std.mem.readInt(u32, f[64..68], .big)) return error.Format;
    t.block_size = getBe24(data[5..]);
    t.min = std.mem.readInt(u64, data[8..16], .big);
    t.max = std.mem.readInt(u64, data[16..24], .big);
    const log_offset = std.mem.readInt(u64, f[48..56], .big);
    const first = data[HEADER_SIZE];

    var refs: std.ArrayList(RefRecord) = .empty;
    var logs: std.ArrayList(LogRecord) = .empty;
    if (first == BLOCK_REF) try readSection(data, &t, 0, BLOCK_REF, &refs, &logs);
    if (first == BLOCK_LOG or log_offset > 0) try readSection(data, &t, log_offset, BLOCK_LOG, &refs, &logs);
    t.refs = refs.items;
    t.logs = logs.items;
    return t;
}

fn isBlockType(c: u8) bool {
    return c == BLOCK_REF or c == BLOCK_LOG or c == BLOCK_OBJ or c == BLOCK_INDEX;
}

fn readSection(data: []const u8, t: *Table, start: u64, want: u8, refs: *std.ArrayList(RefRecord), logs: *std.ArrayList(LogRecord)) Error!void {
    var off: u64 = start;
    while (off < t.size) {
        const header_off: usize = if (off == 0) HEADER_SIZE else 0;
        const o: usize = @intCast(off);
        if (o + header_off + 4 > data.len) return error.Format;
        const btyp = data[o + header_off];
        if (!isBlockType(btyp)) return error.Format;
        if (btyp != want) return;
        const block_len = getBe24(data[o + header_off + 1 ..]);
        if (block_len < header_off + 4 + 2) return error.Format;
        var block: []const u8 = undefined;
        var full: u64 = undefined;
        if (btyp == BLOCK_LOG) {
            const skip = header_off + 4;
            const res = zlib.decompress(data[o + skip ..], block_len - skip) orelse return error.Zlib;
            if (res.data.len + skip != block_len) return error.Format;
            const b = gpa.alloc(u8, block_len) catch util.oom();
            @memcpy(b[0..skip], data[o..][0..skip]);
            @memcpy(b[skip..], res.data);
            block = b;
            full = skip + res.consumed;
        } else {
            if (o + block_len > data.len) return error.Format;
            block = data[o..][0..block_len];
            full = t.block_size;
            if (t.block_size == 0) {
                full = block_len;
            } else if (block_len < t.block_size and o + block_len < data.len and data[o + block_len] != 0) {
                full = block_len;
            }
        }
        try decodeBlock(block, header_off, btyp, t, refs, logs);
        off += full;
    }
}

fn getString(data: []const u8, pos: *usize) Error![]const u8 {
    const n = getVarint(data, pos) orelse return error.Format;
    if (pos.* + n > data.len) return error.Format;
    const s = util.dupe(data[pos.*..][0..@intCast(n)]);
    pos.* += @intCast(n);
    return s;
}

fn decodeBlock(block: []const u8, header_off: usize, btyp: u8, t: *Table, refs: *std.ArrayList(RefRecord), logs: *std.ArrayList(LogRecord)) Error!void {
    const rc = std.mem.readInt(u16, block[block.len - 2 ..][0..2], .big);
    if (block.len < 2 + 3 * @as(usize, rc)) return error.Format;
    const restart_off = block.len - 2 - 3 * @as(usize, rc);
    if (restart_off < header_off + 4) return error.Format;
    const recs = block[0..restart_off];
    var pos: usize = header_off + 4;
    var last_key: Buf = .empty;
    while (pos < restart_off) {
        const prefix_len = getVarint(recs, &pos) orelse return error.Format;
        const se = getVarint(recs, &pos) orelse return error.Format;
        const suffix_len: usize = @intCast(se >> 3);
        const extra: u8 = @intCast(se & 7);
        if (prefix_len > last_key.items.len or pos + suffix_len > recs.len) return error.Format;
        last_key.shrinkRetainingCapacity(@intCast(prefix_len));
        util.bufAppend(&last_key, recs[pos..][0..suffix_len]);
        pos += suffix_len;
        const key = last_key.items;
        switch (btyp) {
            BLOCK_REF => {
                const ui = getVarint(recs, &pos) orelse return error.Format;
                var r = RefRecord{ .name = util.dupe(key), .update_index = ui + t.min, .value = .deletion };
                switch (extra) {
                    0 => {},
                    1 => {
                        if (pos + 20 > recs.len) return error.Format;
                        r.value = .{ .val1 = recs[pos..][0..20].* };
                        pos += 20;
                    },
                    2 => {
                        if (pos + 40 > recs.len) return error.Format;
                        r.value = .{ .val2 = .{ .oid = recs[pos..][0..20].*, .peeled = recs[pos + 20 ..][0..20].* } };
                        pos += 40;
                    },
                    3 => r.value = .{ .symref = try getString(recs, &pos) },
                    else => return error.Format,
                }
                util.append(RefRecord, refs, r);
            },
            BLOCK_LOG => {
                if (key.len <= 9 or key[key.len - 9] != 0) return error.Format;
                const ts = std.mem.readInt(u64, key[key.len - 8 ..][0..8], .big);
                var l = LogRecord{ .name = util.dupe(key[0 .. key.len - 9]), .update_index = ~ts, .value = .deletion };
                if (extra != 0) {
                    var u = LogUpdate{};
                    if (pos + 40 > recs.len) return error.Format;
                    u.old = recs[pos..][0..20].*;
                    u.new = recs[pos + 20 ..][0..20].*;
                    pos += 40;
                    u.name = try getString(recs, &pos);
                    u.email = try getString(recs, &pos);
                    u.time = getVarint(recs, &pos) orelse return error.Format;
                    if (pos + 2 > recs.len) return error.Format;
                    u.tz = @bitCast(std.mem.readInt(u16, recs[pos..][0..2], .big));
                    pos += 2;
                    u.message = try getString(recs, &pos);
                    l.value = .{ .update = u };
                }
                util.append(LogRecord, logs, l);
            },
            else => return error.Format,
        }
    }
}

// ---------------------------------------------------------------- locking

extern "c" fn usleep(us: c_uint) c_int;

fn randU32() u32 {
    var b: [4]u8 = undefined;
    const fd = os.openFile("/dev/urandom", os.O_RDONLY, 0);
    if (fd >= 0) {
        const n = std.c.read(fd, &b, 4);
        os.close(fd);
        if (n == 4) return std.mem.readInt(u32, &b, .little);
    }
    const t: u64 = @bitCast(os.nowMicros());
    return @truncate(t *% 2654435761 ^ @as(u64, @intCast(std.c.getpid())));
}

/// hold_lock_file_for_update_timeout(): timeout_ms < 0 waits forever.
pub fn lockWithTimeout(path: []const u8, timeout_ms: i64) Error!*lockfile.Lock {
    var remaining: i64 = timeout_ms;
    var multiplier: i64 = 1;
    var n: i64 = 1;
    while (true) {
        switch (lockfile.tryLock(path)) {
            .ok => |l| return l,
            .err => |e| {
                if (e != os.EEXIST) return error.Io;
                if (timeout_ms == 0) return error.Lock;
                if (timeout_ms > 0 and remaining <= 0) return error.Lock;
                const backoff: i64 = multiplier;
                var wait: i64 = @divTrunc((750 + @as(i64, randU32() % 500)) * backoff, 1000);
                if (wait < 1) wait = 1;
                if (timeout_ms > 0 and wait > remaining) wait = remaining;
                _ = usleep(@intCast(wait * 1000));
                remaining -= wait;
                multiplier += 2 * n + 1;
                if (multiplier > 1000) multiplier = 1000 else n += 1;
            },
        }
    }
}

// ---------------------------------------------------------------- stack

pub const StackOpts = struct {
    write: WriteOpts = .{},
    lock_timeout_ms: i64 = 0,
    default_permissions: c_uint = 0,
    disable_auto_compact: bool = false,
    auto_compaction_factor: u8 = 0,
};

pub fn formatName(min: u64, max: u64) []u8 {
    return util.fmt("0x{x:0>12}-0x{x:0>12}-{x:0>8}", .{ min, max, randU32() });
}

pub const Stack = struct {
    dir: []const u8,
    list_file: []const u8,
    opts: StackOpts,
    names: [][]const u8 = &.{},
    tables: []Table = &.{},
    merged_refs: ?[]RefRecord = null,
    merged_logs: ?[]LogRecord = null,

    pub fn open(dir: []const u8, opts: StackOpts) Error!*Stack {
        const st = gpa.create(Stack) catch util.oom();
        st.* = .{ .dir = util.dupe(dir), .list_file = util.concat(&.{ dir, "/tables.list" }), .opts = opts };
        try st.reload();
        return st;
    }

    fn readList(self: *Stack) [][]const u8 {
        const data = os.readFile(self.list_file) orelse return &.{};
        var list: std.ArrayList([]const u8) = .empty;
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line| {
            if (line.len == 0) continue;
            util.append([]const u8, &list, line);
        }
        return list.items;
    }

    pub fn reload(self: *Stack) Error!void {
        const names = self.readList();
        var tables: std.ArrayList(Table) = .empty;
        for (names) |nm| {
            // reuse already-loaded tables
            var found: ?Table = null;
            for (self.tables) |t| {
                if (util.eql(t.name, nm)) found = t;
            }
            if (found) |t| {
                util.append(Table, &tables, t);
                continue;
            }
            const path = util.concat(&.{ self.dir, "/", nm });
            const data = os.readFile(path) orelse return error.NotExist;
            var t = try parseTable(data);
            t.name = nm;
            util.append(Table, &tables, t);
        }
        self.names = names;
        self.tables = tables.items;
        self.merged_refs = null;
        self.merged_logs = null;
    }

    /// >0 if tables.list differs from the loaded state.
    fn upToDate(self: *Stack) bool {
        const names = self.readList();
        if (names.len != self.tables.len) return false;
        for (names, self.tables) |a, t| if (!util.eql(a, t.name)) return false;
        return true;
    }

    pub fn nextUpdateIndex(self: *Stack) u64 {
        if (self.tables.len > 0) return self.tables[self.tables.len - 1].max + 1;
        return 1;
    }

    pub fn maxUpdateIndex(self: *Stack) u64 {
        var m: u64 = 0;
        for (self.tables) |t| m = @max(m, t.max);
        return m;
    }

    /// All refs (including deletions) of tables[first..last], newest record per name.
    fn mergeRefs(tables: []const Table) []RefRecord {
        const Item = struct { r: RefRecord, ti: usize };
        var all: std.ArrayList(Item) = .empty;
        for (tables, 0..) |t, ti| for (t.refs) |r| util.append(Item, &all, .{ .r = r, .ti = ti });
        const Ctx = struct {
            fn less(_: void, a: Item, b: Item) bool {
                const c = std.mem.order(u8, a.r.name, b.r.name);
                if (c != .eq) return c == .lt;
                return a.ti > b.ti;
            }
        };
        std.mem.sort(Item, all.items, {}, Ctx.less);
        var out: std.ArrayList(RefRecord) = .empty;
        for (all.items) |it| {
            if (out.items.len > 0 and util.eql(out.items[out.items.len - 1].name, it.r.name)) continue;
            util.append(RefRecord, &out, it.r);
        }
        return out.items;
    }

    fn mergeLogs(tables: []const Table) []LogRecord {
        const Item = struct { l: LogRecord, ti: usize };
        var all: std.ArrayList(Item) = .empty;
        for (tables, 0..) |t, ti| for (t.logs) |l| util.append(Item, &all, .{ .l = l, .ti = ti });
        const Ctx = struct {
            fn less(_: void, a: Item, b: Item) bool {
                const c = std.mem.order(u8, a.l.name, b.l.name);
                if (c != .eq) return c == .lt;
                if (a.l.update_index != b.l.update_index) return a.l.update_index > b.l.update_index;
                return a.ti > b.ti;
            }
        };
        std.mem.sort(Item, all.items, {}, Ctx.less);
        var out: std.ArrayList(LogRecord) = .empty;
        for (all.items) |it| {
            if (out.items.len > 0) {
                const p = out.items[out.items.len - 1];
                if (util.eql(p.name, it.l.name) and p.update_index == it.l.update_index) continue;
            }
            util.append(LogRecord, &out, it.l);
        }
        return out.items;
    }

    /// Merged view of all refs, deletions included, sorted by name.
    pub fn refs(self: *Stack) []RefRecord {
        if (self.merged_refs == null) self.merged_refs = mergeRefs(self.tables);
        return self.merged_refs.?;
    }

    /// Merged view of all logs, deletions included, sorted by key.
    pub fn logs(self: *Stack) []LogRecord {
        if (self.merged_logs == null) self.merged_logs = mergeLogs(self.tables);
        return self.merged_logs.?;
    }

    fn lowerBound(items: []RefRecord, name: []const u8) usize {
        var lo: usize = 0;
        var hi: usize = items.len;
        while (lo < hi) {
            const mid = (lo + hi) / 2;
            if (std.mem.order(u8, items[mid].name, name) == .lt) lo = mid + 1 else hi = mid;
        }
        return lo;
    }

    /// Newest non-deleted record for `name`.
    pub fn readRef(self: *Stack, name: []const u8) ?RefRecord {
        const items = self.refs();
        const i = lowerBound(items, name);
        if (i < items.len and util.eql(items[i].name, name) and !items[i].isDeletion()) return items[i];
        return null;
    }

    /// Index of the first ref with name >= prefix.
    pub fn seekRef(self: *Stack, prefix: []const u8) usize {
        return lowerBound(self.refs(), prefix);
    }

    /// All log records (deletions included) for `name`, newest first.
    pub fn logsFor(self: *Stack, name: []const u8) []LogRecord {
        const items = self.logs();
        var lo: usize = 0;
        var hi: usize = items.len;
        while (lo < hi) {
            const mid = (lo + hi) / 2;
            if (std.mem.order(u8, items[mid].name, name) == .lt) lo = mid + 1 else hi = mid;
        }
        var e = lo;
        while (e < items.len and util.eql(items[e].name, name)) e += 1;
        return items[lo..e];
    }

    pub fn newAddition(self: *Stack) Error!Addition {
        return Addition.init(self, self.opts);
    }

    fn writeTempTable(self: *Stack, data: []const u8, min: u64, max: u64) Error![]const u8 {
        const prefix = util.concat(&.{ formatName(min, max), ".temp." });
        const tf = os.tmpFile(self.dir, prefix);
        if (tf.fd < 0) return error.Io;
        if (self.opts.default_permissions != 0) _ = os.chmod(tf.path, self.opts.default_permissions);
        os.writeAll(tf.fd, data) catch {
            os.close(tf.fd);
            _ = os.unlink(tf.path);
            return error.Io;
        };
        os.close(tf.fd);
        return tf.path;
    }

    fn writeList(lock: *lockfile.Lock, names: []const []const u8) Error!void {
        var b: Buf = .empty;
        for (names) |n| {
            util.bufAppend(&b, n);
            util.bufByte(&b, '\n');
        }
        os.writeAll(lock.fd, b.items) catch return error.Io;
        if (!lock.commit()) return error.Io;
    }

    pub fn compactAll(self: *Stack) Error!void {
        const last = if (self.tables.len > 0) self.tables.len - 1 else 0;
        return self.compactRange(0, last, false);
    }

    pub fn compactRange(self: *Stack, first0: usize, last: usize, best_effort: bool) Error!void {
        var first = first0;
        if (first >= last) return;
        var list_lock = try lockWithTimeout(self.list_file, self.opts.lock_timeout_ms);
        defer list_lock.rollback();
        if (!self.upToDate()) return error.Outdated;

        var table_locks: std.ArrayList(*lockfile.Lock) = .empty;
        defer for (table_locks.items) |l| l.rollback();
        var i: usize = last + 1;
        while (i > first) : (i -= 1) {
            const p = util.concat(&.{ self.dir, "/", self.tables[i - 1].name });
            switch (lockfile.tryLock(p)) {
                .ok => |l| {
                    os.close(l.fd);
                    l.fd = -1;
                    util.append(*lockfile.Lock, &table_locks, l);
                },
                .err => |e| {
                    if (e == os.EEXIST and last - (i - 1) >= 2 and best_effort) {
                        first = i;
                        break;
                    }
                    return if (e == os.EEXIST) error.Lock else error.Io;
                },
            }
        }
        list_lock.rollback();

        // write the compacted table
        const sub = self.tables[first .. last + 1];
        var w = Writer.init(self.opts.write, sub[0].min, sub[sub.len - 1].max);
        for (mergeRefs(sub)) |r| {
            if (first == 0 and r.isDeletion()) continue;
            try w.addRef(r);
        }
        for (mergeLogs(sub)) |l| {
            if (first == 0 and l.isDeletion()) continue;
            try w.addLog(l);
        }
        const data = try w.close();
        var tmp_path: ?[]const u8 = null;
        if (data) |d| tmp_path = try self.writeTempTable(d, sub[0].min, sub[sub.len - 1].max);
        errdefer if (tmp_path) |p| {
            _ = os.unlink(p);
        };

        list_lock = try lockWithTimeout(self.list_file, self.opts.lock_timeout_ms);
        if (self.opts.default_permissions != 0) _ = os.chmod(list_lock.lock_path, self.opts.default_permissions);

        var names: []const []const u8 = undefined;
        var first_to_replace: usize = first;
        var last_to_replace: usize = last;
        if (!self.upToDate()) {
            names = self.readList();
            var new_offset: ?usize = null;
            for (names, 0..) |n, ni| {
                if (!util.eql(n, self.tables[first].name)) continue;
                var j: usize = 1;
                while (j < last - first + 1) : (j += 1) {
                    if (first + j >= self.tables.len or ni + j >= names.len or !util.eql(self.tables[first + j].name, names[ni + j]))
                        return error.Outdated;
                }
                new_offset = ni;
                break;
            }
            const no = new_offset orelse return error.Outdated;
            first_to_replace = no;
            last_to_replace = last + no - first;
        } else {
            names = self.names;
        }

        var new_name: ?[]const u8 = null;
        if (tmp_path) |p| {
            const nm = util.concat(&.{ formatName(sub[0].min, sub[sub.len - 1].max), ".ref" });
            if (!os.rename(p, util.concat(&.{ self.dir, "/", nm }))) return error.Io;
            tmp_path = null;
            new_name = nm;
        }
        var list: std.ArrayList([]const u8) = .empty;
        for (names[0..first_to_replace]) |n| util.append([]const u8, &list, n);
        if (new_name) |n| util.append([]const u8, &list, n);
        if (last_to_replace + 1 < names.len)
            for (names[last_to_replace + 1 ..]) |n| util.append([]const u8, &list, n);
        writeList(list_lock, list.items) catch |e| {
            if (new_name) |n| _ = os.unlink(util.concat(&.{ self.dir, "/", n }));
            return e;
        };
        try self.reload();
        for (table_locks.items) |l| _ = os.unlink(l.path);
    }

    pub fn compactionRequired(self: *Stack, use_heuristics: bool) bool {
        if (self.tables.len < 2) return false;
        if (!use_heuristics) return true;
        const seg = self.suggestSegment();
        return seg.end > seg.start;
    }

    const Segment = struct { start: usize = 0, end: usize = 0 };

    fn suggestSegment(self: *Stack) Segment {
        const n = self.tables.len;
        var seg = Segment{};
        if (n <= 1) return seg;
        const factor: u64 = if (self.opts.auto_compaction_factor == 0) 2 else self.opts.auto_compaction_factor;
        const sizes = gpa.alloc(u64, n) catch util.oom();
        for (self.tables, 0..) |t, ti| sizes[ti] = t.size - (HEADER_SIZE - 1);
        var bytes: u64 = 0;
        var i: usize = n - 1;
        while (i > 0) : (i -= 1) {
            if (sizes[i - 1] < sizes[i] * factor) {
                seg.end = i + 1;
                bytes = sizes[i];
                break;
            }
        }
        while (i > 0) : (i -= 1) {
            const curr = bytes;
            bytes += sizes[i - 1];
            if (sizes[i - 1] < curr * factor) seg.start = i - 1;
        }
        return seg;
    }

    pub fn autoCompact(self: *Stack) Error!void {
        if (!self.compactionRequired(true)) return;
        const seg = self.suggestSegment();
        return self.compactRange(seg.start, seg.end - 1, true);
    }

    /// reftable_stack_clean(): remove stale tables not referenced by tables.list.
    pub fn clean(self: *Stack) Error!void {
        var opts = self.opts;
        opts.lock_timeout_ms = 0;
        var add = try Addition.init(self, opts);
        defer add.close();
        const max = self.maxUpdateIndex();
        const ents = os.listDir(self.dir) orelse return error.Io;
        for (ents) |e| {
            if (!util.endsWith(e.name, ".ref")) continue;
            var found = false;
            for (self.tables) |t| {
                if (util.eql(t.name, e.name)) found = true;
            }
            if (found) continue;
            const p = util.concat(&.{ self.dir, "/", e.name });
            const data = os.readFile(p) orelse continue;
            const t = parseTable(data) catch continue;
            if (t.max <= max) _ = os.unlink(p);
        }
    }
};

pub const Addition = struct {
    st: *Stack,
    opts: StackOpts,
    lock: ?*lockfile.Lock,
    next_update_index: u64,
    new_tables: std.ArrayList([]const u8) = .empty,

    fn init(st: *Stack, opts: StackOpts) Error!Addition {
        const l = try lockWithTimeout(st.list_file, opts.lock_timeout_ms);
        if (opts.default_permissions != 0) {
            if (!os.chmod(l.lock_path, opts.default_permissions)) {
                l.rollback();
                return error.Io;
            }
        }
        st.reload() catch |e| {
            l.rollback();
            return e;
        };
        return .{ .st = st, .opts = opts, .lock = l, .next_update_index = st.nextUpdateIndex() };
    }

    /// Add a written table (as produced by writeTable; null = empty table).
    pub fn addTable(self: *Addition, data: ?[]const u8, min: u64, max: u64) Error!void {
        const d = data orelse return;
        if (min < self.next_update_index) return error.Api;
        const tmp = try self.st.writeTempTable(d, self.next_update_index, self.next_update_index);
        const nm = util.concat(&.{ formatName(min, max), ".ref" });
        if (!os.rename(tmp, util.concat(&.{ self.st.dir, "/", nm }))) {
            _ = os.unlink(tmp);
            return error.Io;
        }
        util.append([]const u8, &self.new_tables, nm);
    }

    /// Write refs/logs as a table with limits [min, max] and add it.
    pub fn add(self: *Addition, min: u64, max: u64, refs: []RefRecord, logs: []LogRecord) Error!void {
        var wo = self.opts.write;
        _ = &wo;
        const data = try writeTable(wo, min, max, refs, logs);
        try self.addTable(data, min, max);
    }

    pub fn commit(self: *Addition) Error!void {
        defer self.close();
        if (self.new_tables.items.len == 0) return;
        var list: std.ArrayList([]const u8) = .empty;
        for (self.st.tables) |t| util.append([]const u8, &list, t.name);
        for (self.new_tables.items) |n| util.append([]const u8, &list, n);
        const l = self.lock.?;
        self.lock = null;
        Stack.writeList(l, list.items) catch |e| {
            l.rollback();
            return e;
        };
        self.new_tables.clearRetainingCapacity();
        try self.st.reload();
        if (!self.opts.disable_auto_compact) {
            self.st.autoCompact() catch |e| {
                if (e != error.Lock and e != error.Outdated) return e;
            };
        }
    }

    pub fn close(self: *Addition) void {
        for (self.new_tables.items) |n| _ = os.unlink(util.concat(&.{ self.st.dir, "/", n }));
        self.new_tables.clearRetainingCapacity();
        if (self.lock) |l| l.rollback();
        self.lock = null;
    }
};

/// reftable/fsck.c table_has_valid_name()
pub fn validTableName(name: []const u8) bool {
    var p = name;
    var k: usize = 0;
    while (k < 3) : (k += 1) {
        var s = p;
        if (s.len >= 2 and s[0] == '0' and (s[1] == 'x' or s[1] == 'X')) s = s[2..];
        var j: usize = 0;
        while (j < s.len and std.ascii.isHex(s[j])) j += 1;
        // strtoull accepts an empty number (endptr == ptr), which we mimic
        p = s[j..];
        if (k < 2) {
            if (p.len == 0 or p[0] != '-') return false;
            p = p[1..];
        }
    }
    return util.eql(p, ".ref") or util.eql(p, ".log");
}
