//! Bidirectional child process spawning (subset of run-command.c) used by the
//! transport layer.

const std = @import("std");
const c = std.c;
const util = @import("util.zig");
const os = @import("os.zig");
const main = @import("main.zig");
const gpa = util.gpa;

extern "c" fn fork() c_int;
extern "c" fn execvp(file: [*:0]const u8, argv: [*:null]const ?[*:0]const u8) c_int;
extern "c" fn execv(file: [*:0]const u8, argv: [*:null]const ?[*:0]const u8) c_int;
extern "c" fn setenv(name: [*:0]const u8, value: [*:0]const u8, overwrite: c_int) c_int;
extern "c" fn unsetenv(name: [*:0]const u8) c_int;
extern "c" fn pipe2(fds: *[2]c_int, flags: c_int) c_int;
extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn getpid() c_int;
extern "c" fn gethostname(name: [*]u8, len: usize) c_int;

pub const Child = struct {
    pid: c_int,
    /// write end connected to child's stdin (or -1)
    in: c_int = -1,
    /// read end connected to child's stdout (or -1)
    out: c_int = -1,
    /// read end connected to child's stderr (or -1)
    err: c_int = -1,
};

pub const Opts = struct {
    pipe_in: bool = false,
    pipe_out: bool = false,
    pipe_err: bool = false,
    /// use this fd as the child's stdin (dup'ed); -1 = inherit
    in_fd: c_int = -1,
    /// use this fd as the child's stdout; -1 = inherit
    out_fd: c_int = -1,
    /// use this fd as the child's stderr; -1 = inherit
    err_fd: c_int = -1,
    stdout_to_stderr: bool = false,
    no_stdin: bool = false,
    cwd: ?[]const u8 = null,
    env: []const [2][]const u8 = &.{},
    unset_env: []const []const u8 = &.{},
    /// argv[0] is a path, don't search PATH
    no_path_search: bool = false,
    /// trace2 child_class ("?" when null)
    trace2_class: ?[]const u8 = null,
};

pub fn getPid() c_int {
    return getpid();
}

pub fn hostname() []const u8 {
    var buf: [256]u8 = undefined;
    if (gethostname(&buf, buf.len) != 0) return "localhost";
    const n = std.mem.indexOfScalar(u8, &buf, 0) orelse buf.len;
    return util.dupe(buf[0..n]);
}

pub fn ignoreSigpipe() void {
    _ = signal(13, 1);
}

fn mkpipe() [2]c_int {
    var p: [2]c_int = .{ -1, -1 };
    if (pipe2(&p, os.O_CLOEXEC) != 0) util.die("cannot create pipe: {s}", .{os.lastErr()});
    return p;
}

/// Path of our own git binary (used to spawn helpers like upload-pack).
pub fn gitBinary() []const u8 {
    const p = util.joinPath(main.exec_path, "git");
    if (os.access(p, 1)) return p;
    return "git";
}

pub fn spawn(argv: []const []const u8, o: Opts) Child {
    util.flushStdout();
    const t2 = @import("trace2.zig");
    var t2_child: t2.Child = .{};
    if (t2.enabled) {
        var info = t2.childInfoFor(argv);
        info.class = o.trace2_class;
        info.dir = o.cwd;
        t2_child = t2.childStart(info);
    }
    const cargv = gpa.allocSentinel(?[*:0]const u8, argv.len, null) catch util.oom();
    for (argv, 0..) |a, i| cargv[i] = os.z(a);
    var pin: [2]c_int = .{ -1, -1 };
    var pout: [2]c_int = .{ -1, -1 };
    var perr: [2]c_int = .{ -1, -1 };
    if (o.pipe_in) pin = mkpipe();
    if (o.pipe_out) pout = mkpipe();
    if (o.pipe_err) perr = mkpipe();
    const pid = fork();
    if (pid < 0) util.die("fork failed: {s}", .{os.lastErr()});
    if (pid == 0) {
        _ = signal(13, 0);
        if (o.pipe_in) {
            _ = c.dup2(pin[0], 0);
        } else if (o.in_fd >= 0) {
            _ = c.dup2(o.in_fd, 0);
        } else if (o.no_stdin) {
            const fd = os.openFile("/dev/null", 0, 0);
            _ = c.dup2(fd, 0);
        }
        if (o.pipe_err) {
            _ = c.dup2(perr[1], 2);
        } else if (o.err_fd >= 0) {
            _ = c.dup2(o.err_fd, 2);
        }
        if (o.pipe_out) {
            _ = c.dup2(pout[1], 1);
        } else if (o.out_fd >= 0) {
            _ = c.dup2(o.out_fd, 1);
        } else if (o.stdout_to_stderr) {
            _ = c.dup2(2, 1);
        }
        if (o.cwd) |d| {
            if (d.len > 0 and c.chdir(os.z(d)) != 0) c._exit(127);
        }
        for (o.unset_env) |n| _ = unsetenv(os.z(n));
        for (o.env) |kv| _ = setenv(os.z(kv[0]), os.z(kv[1]), 1);
        if (o.no_path_search or std.mem.indexOfScalar(u8, argv[0], '/') != null)
            _ = execv(cargv[0].?, cargv.ptr)
        else
            _ = execvp(cargv[0].?, cargv.ptr);
        util.eprint("fatal: cannot run {s}: {s}\n", .{ argv[0], os.lastErr() });
        c._exit(127);
    }
    @import("trace2.zig").registerPid(t2_child, pid);
    var ch = Child{ .pid = pid };
    if (o.pipe_in) {
        _ = c.close(pin[0]);
        ch.in = pin[1];
    }
    if (o.pipe_out) {
        _ = c.close(pout[1]);
        ch.out = pout[0];
    }
    if (o.pipe_err) {
        _ = c.close(perr[1]);
        ch.err = perr[0];
    }
    return ch;
}

/// Spawn a git subcommand of ourselves.
pub fn spawnGit(args: []const []const u8, o: Opts) Child {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return spawn(argv.items, o);
}

/// Wait for a child; returns exit code (128+sig if signaled).
pub fn wait(pid: c_int) u8 {
    var status: c_int = 0;
    while (true) {
        const r = c.waitpid(pid, &status, 0);
        if (r < 0 and os.errno() == 4) continue;
        if (r < 0) return 255;
        break;
    }
    const st: u32 = @bitCast(status);
    const code: u8 = if (st & 0x7f == 0) @intCast((st >> 8) & 0xff) else @intCast(128 + (st & 0x7f));
    @import("trace2.zig").childExitPid(pid, code);
    return code;
}

pub fn closeFd(fd: *c_int) void {
    if (fd.* >= 0) _ = c.close(fd.*);
    fd.* = -1;
}
