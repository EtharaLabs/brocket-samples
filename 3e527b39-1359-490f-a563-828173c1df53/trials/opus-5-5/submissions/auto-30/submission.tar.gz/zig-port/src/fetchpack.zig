//! Client side of the pack fetch protocol (subset of fetch-pack.c):
//! negotiate with upload-pack (v0 or v2) and store the received pack via
//! index-pack / unpack-objects subprocesses.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const hash = @import("hash.zig");
const pkt = @import("pktline.zig");
const proc = @import("proc.zig");
const objects = @import("objects.zig");
const transport = @import("transport.zig");
const fsck = @import("fsck.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Transport = transport.Transport;
const Ref = transport.Ref;

const MAX_HAVES: usize = 4096;

/// fetch_pack_fsck_objects()
fn fetchFsckObjects() bool {
    const cfg = repo_mod.cfg;
    if (cfg.getBool("fetch.fsckobjects")) |b| return b;
    if (cfg.getBool("transfer.fsckobjects")) |b| return b;
    return false;
}

/// fetch_pack_fsck_config(): fetch.fsck.* -> "=id=type,skiplist=path"
fn fetchFsckMsgTypes() []const u8 {
    const config = @import("config.zig");
    var out: util.Buf = .empty;
    for (repo_mod.cfg.entries.items) |e| {
        const sep: u8 = if (out.items.len > 0) ',' else '=';
        if (util.eql(e.key, "fetch.fsck.skiplist")) {
            switch (config.configPathname(e.key, e.value)) {
                .ok => |p| if (p) |path| util.bufPrint(&out, "{c}skiplist={s}", .{ sep, path }),
                .err => fsck.dieConfig(e),
            }
            continue;
        }
        if (util.skipPrefix(e.key, "fetch.fsck.")) |id| {
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                fsck.dieConfig(e);
            };
            if (fsck.parseMsgId(id) != null) {
                if (!util.eql(v, "error") and !util.eql(v, "warn") and !util.eql(v, "ignore"))
                    util.die("Unknown fsck message type: '{s}'", .{v});
                util.bufPrint(&out, "{c}{s}={s}", .{ sep, id, v });
            } else util.warn("Skipping unknown msg id '{s}'", .{id});
        }
    }
    return out.items;
}

fn printMissingGitmodules(o: *fsck.Options, oid: ?Oid, typ: @import("odb.zig").ObjType, mt: fsck.MsgType, id: fsck.MsgId, msg: []const u8) i32 {
    if (id == .gitmodules_missing) {
        if (oid) |x| util.outf("{s}\n", .{&hash.hex(x)});
        return 0;
    }
    return fsck.objectsErrorFunction(o, oid, typ, mt, id, msg);
}

fn unpackLimit() u32 {
    const cfg = repo_mod.cfg;
    if (cfg.get("fetch.unpacklimit")) |v| {
        if (util.parseInt(u32, v)) |n| return n;
    }
    if (cfg.get("transfer.unpacklimit")) |v| {
        if (util.parseInt(u32, v)) |n| return n;
    }
    return 100;
}

const HeapItem = struct { oid: Oid, time: i64 };

fn heapLess(_: void, a: HeapItem, b: HeapItem) std.math.Order {
    return std.math.order(b.time, a.time);
}

/// Collect "have" commits: walk local refs by commit date.
fn collectHaves() []Oid {
    var out: std.ArrayList(Oid) = .empty;
    var seen: hash.OidSet = .empty;
    var pq = std.PriorityQueue(HeapItem, void, heapLess).initContext({});
    const tips = refs.iterate("", .{ .check_objects = false });
    for (tips) |r| {
        const c_oid = objects.peelTo(r.oid, .commit) orelse continue;
        if (seen.contains(c_oid)) continue;
        seen.put(gpa, c_oid, {}) catch util.oom();
        const cm = objects.readCommit(c_oid) orelse continue;
        pq.push(gpa, .{ .oid = c_oid, .time = cm.commitTime() }) catch util.oom();
    }
    while (pq.pop()) |it| {
        if (out.items.len >= MAX_HAVES) break;
        out.append(gpa, it.oid) catch util.oom();
        const cm = objects.readCommit(it.oid) orelse continue;
        for (cm.parents) |p| {
            if (seen.contains(p)) continue;
            seen.put(gpa, p, {}) catch util.oom();
            const pc = objects.readCommit(p) orelse continue;
            pq.push(gpa, .{ .oid = p, .time = pc.commitTime() }) catch util.oom();
        }
    }
    return out.items;
}

/// Pack data source: either sideband-demuxed or raw from the reader.
const PackSource = struct {
    rd: *pkt.Reader,
    sideband: bool,
    demux: pkt.Demux = .{},
    ended: bool = false,
    pending: []const u8 = &.{},
    pending_buf: util.Buf = .empty,

    /// Returns next chunk of pack data, or null at end.
    fn next(self: *PackSource) ?[]const u8 {
        if (self.ended) return null;
        if (!self.sideband) {
            var buf: [65536]u8 = undefined;
            const n = self.rd.readRaw(&buf);
            if (n == 0) {
                self.ended = true;
                return null;
            }
            self.pending_buf.clearRetainingCapacity();
            util.bufAppend(&self.pending_buf, buf[0..n]);
            return self.pending_buf.items;
        }
        pkt.in_async = true;
        defer pkt.in_async = false;
        while (true) {
            _ = self.rd.read();
            switch (self.demux.handle(self.rd, "fetch-pack")) {
                .data => |d| return d,
                .consumed => {},
                .end => {
                    self.ended = true;
                    return null;
                },
            }
        }
    }
};

pub const Options = struct {
    quiet: bool = false,
    no_progress: bool = true,
    thin: bool = true,
    include_tag: bool = false,
    keep_pack: bool = false,
    filter: ?[]const u8 = null,
    from_promisor: bool = false,
};

fn receivePack(src: *PackSource, o: Options) void {
    // read the pack header (12 bytes)
    var head: util.Buf = .empty;
    while (head.items.len < 12) {
        const d = src.next() orelse util.die("protocol error: bad pack header", .{});
        util.bufAppend(&head, d);
    }
    if (!std.mem.eql(u8, head.items[0..4], "PACK")) util.die("protocol error: bad pack header", .{});
    const nr = std.mem.readInt(u32, head.items[8..12], .big);
    const limit = unpackLimit();
    var do_keep = o.keep_pack or o.from_promisor;
    if (!o.keep_pack and limit != 0) do_keep = nr >= limit;
    var args: std.ArrayList([]const u8) = .empty;
    const fsck_objects = fetchFsckObjects();
    const use_index_pack = do_keep or fsck_objects;
    const cmd_name: []const u8 = if (use_index_pack) "index-pack" else "unpack-objects";
    if (use_index_pack) {
        args.appendSlice(gpa, &.{ "index-pack", "--stdin" }) catch util.oom();
        if (!o.quiet and !o.no_progress) args.append(gpa, "-v") catch util.oom();
        if (o.thin) args.append(gpa, "--fix-thin") catch util.oom();
        if (o.from_promisor) args.append(gpa, "--promisor") catch util.oom();
    } else {
        args.append(gpa, "unpack-objects") catch util.oom();
        if (o.quiet or o.no_progress) args.append(gpa, "-q") catch util.oom();
    }
    if (fsck_objects) {
        // --strict would also check links, which a promisor pack lacks
        if (o.from_promisor) {
            args.append(gpa, "--fsck-objects") catch util.oom();
        } else args.append(gpa, util.concat(&.{ "--strict", fetchFsckMsgTypes() })) catch util.oom();
    }
    proc.ignoreSigpipe();
    var ch = proc.spawnGit(args.items, .{ .pipe_in = true, .pipe_out = use_index_pack });
    var write_ok = true;
    os.writeAll(ch.in, head.items) catch {
        write_ok = false;
    };
    while (src.next()) |d| {
        if (write_ok) os.writeAll(ch.in, d) catch {
            write_ok = false;
        };
    }
    proc.closeFd(&ch.in);
    var gitmodules: std.ArrayList(Oid) = .empty;
    if (use_index_pack) {
        // "pack\t<hash>\n" (or keep), then missing .gitmodules oids
        var outb: util.Buf = .empty;
        var buf: [4096]u8 = undefined;
        while (true) {
            const n = std.c.read(ch.out, &buf, buf.len);
            if (n <= 0) break;
            util.bufAppend(&outb, buf[0..@intCast(n)]);
        }
        proc.closeFd(&ch.out);
        if (fsck_objects) {
            if (outb.items.len < 46 or outb.items[45] != '\n') util.die("fetch-pack: invalid index-pack output", .{});
            var rest = outb.items[46..];
            while (rest.len > 0) {
                if (rest.len < 41) util.die("invalid length read {d}", .{rest.len});
                if (rest[40] != '\n') util.die("invalid hash", .{});
                const oid = hash.fromHex(rest[0..40]) orelse util.die("invalid hash", .{});
                gitmodules.append(gpa, oid) catch util.oom();
                rest = rest[41..];
            }
        }
    }
    const rc = proc.wait(ch.pid);
    if (rc != 0) util.die("{s} failed", .{cmd_name});
    repo_mod.repo().odb().reloadPacks();
    if (fsck_objects) {
        var fo = fsck.Options{ .strict = true, .error_func = printMissingGitmodules };
        for (gitmodules.items) |g| fo.gitmodules_found.insert(g);
        if (fsck.fsckFinish(&fo) != 0) util.die("fsck failed", .{});
    }
}

var complete_set: ?hash.OidSet = null;

/// Is `oid` reachable from a local ref (COMPLETE in fetch-pack.c)?
fn isComplete(oid: Oid) bool {
    if (complete_set == null) {
        var set: hash.OidSet = .empty;
        var stack: std.ArrayList(Oid) = .empty;
        for (refs.iterate("", .{ .check_objects = false })) |r| {
            set.put(gpa, r.oid, {}) catch util.oom();
            const c_oid = objects.peelTo(r.oid, .commit) orelse continue;
            stack.append(gpa, c_oid) catch util.oom();
        }
        var seen: hash.OidSet = .empty;
        while (stack.pop()) |o| {
            if (seen.contains(o)) continue;
            seen.put(gpa, o, {}) catch util.oom();
            set.put(gpa, o, {}) catch util.oom();
            const cm = objects.readCommit(o) orelse continue;
            for (cm.parents) |p| stack.append(gpa, p) catch util.oom();
        }
        complete_set = set;
    }
    return complete_set.?.contains(oid);
}

fn computeWants(sought: []const *Ref, deepen: bool) []Oid {
    var wants: std.ArrayList(Oid) = .empty;
    var seen: hash.OidSet = .empty;
    const odb = repo_mod.repo().odb();
    for (sought) |r| {
        if (seen.contains(r.old_oid)) continue;
        seen.put(gpa, r.old_oid, {}) catch util.oom();
        if (!deepen and odb.has(r.old_oid) and isComplete(r.old_oid)) continue;
        wants.append(gpa, r.old_oid) catch util.oom();
    }
    return wants.items;
}

fn repoIsShallow() bool {
    return objects.shallowList().len > 0;
}

/// Shallow-related request lines (add_shallow_requests / find_common).
fn addShallowRequests(req: *util.Buf, t: *Transport, v2: bool) void {
    for (objects.shallowList()) |s| pkt.bufFmt(req, "shallow {s}\n", .{hash.hex(s)});
    if (t.depth > 0) pkt.bufFmt(req, "deepen {d}", .{t.depth});
    if (t.deepen_since) |s| pkt.bufFmt(req, "deepen-since {d}", .{@import("date.zig").approxidate(s)});
    for (t.deepen_not) |n| pkt.bufFmt(req, "deepen-not {s}", .{n});
    if (v2 and t.deepen_relative) pkt.bufWrite(req, "deepen-relative\n");
}

fn handleShallowLine(line: []const u8) bool {
    if (util.skipPrefix(line, "shallow ")) |a| {
        const o = hash.fromHex(a) orelse util.die("invalid shallow line: {s}", .{line});
        objects.registerShallow(o);
        return true;
    }
    if (util.skipPrefix(line, "unshallow ")) |a| {
        const o = hash.fromHex(a) orelse util.die("invalid unshallow line: {s}", .{line});
        if (!repo_mod.repo().odb().has(o)) util.die("object not found: {s}", .{line});
        if (!objects.unregisterShallow(o)) util.die("no shallow found: {s}", .{line});
        return true;
    }
    return false;
}

fn writeShallowFile(list: []const Oid) void {
    const path = repo_mod.repo().commonPath("shallow");
    if (list.len == 0) {
        _ = os.unlink(path);
    } else {
        var b: util.Buf = .empty;
        for (list) |s| util.bufPrint(&b, "{s}\n", .{hash.hex(s)});
        const lk = @import("lockfile.zig").lockOrDie(path);
        lk.write(b.items);
        if (!lk.commit()) util.die("unable to write shallow file", .{});
    }
    objects.resetCaches();
}

fn sortOids(l: []Oid) void {
    std.mem.sort(Oid, l, {}, struct {
        fn lt(_: void, a: Oid, b: Oid) bool {
            return std.mem.order(u8, &a, &b) == .lt;
        }
    }.lt);
}

/// update_shallow(): after the pack has been received.
fn updateShallow(t: *Transport, sought: []const *Ref, remote_shallow: []const Oid) void {
    if (t.deepen) {
        writeShallowFile(objects.shallowList());
        return;
    }
    if (remote_shallow.len == 0) return;
    const odb = repo_mod.repo().odb();
    if (t.cloning) {
        var extra: std.ArrayList(Oid) = .empty;
        for (remote_shallow) |s| {
            if (odb.has(s)) extra.append(gpa, s) catch util.oom();
        }
        if (extra.items.len > 0) {
            for (objects.shallowList()) |s| extra.append(gpa, s) catch util.oom();
            sortOids(extra.items);
            writeShallowFile(extra.items);
        }
        return;
    }
    // ours: present and not already shallow; theirs: now present
    var roots: hash.OidSet = .empty;
    for (remote_shallow) |s| {
        if (!odb.has(s)) continue;
        if (objects.isShallow(s)) continue;
        roots.put(gpa, s, {}) catch util.oom();
    }
    if (roots.count() == 0) return;
    // commits reachable from our existing refs
    var local: hash.OidSet = .empty;
    var stack: std.ArrayList(Oid) = .empty;
    for (refs.iterate("", .{ .check_objects = false })) |r| {
        const c_oid = objects.peelTo(r.oid, .commit) orelse continue;
        stack.append(gpa, c_oid) catch util.oom();
    }
    while (stack.pop()) |o| {
        if (local.contains(o)) continue;
        local.put(gpa, o, {}) catch util.oom();
        if (roots.contains(o)) continue;
        const cm = objects.readCommit(o) orelse continue;
        for (cm.parents) |p| stack.append(gpa, p) catch util.oom();
    }
    var used: hash.OidSet = .empty;
    var status: std.ArrayList(bool) = .empty;
    for (sought) |r| {
        var hit = false;
        const start = objects.peelTo(r.old_oid, .commit);
        var seen: hash.OidSet = .empty;
        if (start) |s0| stack.append(gpa, s0) catch util.oom();
        while (stack.pop()) |o| {
            if (seen.contains(o) or local.contains(o)) continue;
            seen.put(gpa, o, {}) catch util.oom();
            if (roots.contains(o)) {
                hit = true;
                used.put(gpa, o, {}) catch util.oom();
                continue;
            }
            const cm = objects.readCommit(o) orelse continue;
            for (cm.parents) |p| stack.append(gpa, p) catch util.oom();
        }
        status.append(gpa, hit) catch util.oom();
    }
    if (used.count() == 0) return;
    if (t.update_shallow) {
        var extra: std.ArrayList(Oid) = .empty;
        var it = used.keyIterator();
        while (it.next()) |k| extra.append(gpa, k.*) catch util.oom();
        for (objects.shallowList()) |s| extra.append(gpa, s) catch util.oom();
        sortOids(extra.items);
        writeShallowFile(extra.items);
        return;
    }
    for (sought, status.items) |r, st| {
        if (st) r.status = .reject_shallow;
    }
}

fn checkShallowCaps(t: *Transport) void {
    if (t.version == 2) return;
    if (!t.serverSupportsV0("shallow")) {
        if (t.depth > 0 or repoIsShallow()) util.die("Server does not support shallow clients", .{});
    }
    if (!t.serverSupportsV0("deepen-since") and t.deepen_since != null) util.die("Server does not support --shallow-since", .{});
    if (!t.serverSupportsV0("deepen-not") and t.deepen_not.len > 0) util.die("Server does not support --shallow-exclude", .{});
    if (!t.serverSupportsV0("deepen-relative") and t.deepen_relative) util.die("Server does not support --deepen", .{});
}

/// Fetch the objects for `sought` refs over the (already connected) transport.
pub fn fetchPack(t: *Transport, sought: []const *Ref, o: Options) void {
    complete_set = null;
    if (t.child == null) transport.connect(t, false);
    if (t.hd != null) {
        if (@import("transport_helper.zig").fetchRefs(t, sought, .{ .filter = o.filter }) != 0) util.die("remote transport reported error", .{});
        return;
    }
    t.deepen = t.depth > 0 or t.deepen_since != null or t.deepen_not.len > 0;
    checkShallowCaps(t);
    if (t.version == 2) return fetchV2(t, sought, o);
    return fetchV0(t, sought, o);
}

/// send_filter()
fn sendFilter(req: *util.Buf, filter: ?[]const u8, supported: bool) void {
    const t2 = @import("trace2.zig");
    if (filter) |fs| {
        if (supported) {
            pkt.bufFmt(req, "filter {s}\n", .{fs});
            t2.dataString("fetch", true, "filter/effective", fs);
        } else {
            util.warn("filtering not recognized by server, ignoring", .{});
            t2.dataString("fetch", true, "filter/unsupported", fs);
        }
    } else t2.dataString("fetch", true, "filter/none", "");
}

fn fetchV0(t: *Transport, sought: []const *Ref, o: Options) void {
    const wants = computeWants(sought, t.deepen);
    const remote_shallow = t.remote_shallow.items;
    if (wants.len == 0) {
        _ = transport.disconnect(t);
        t.got_remote_heads = false;
        updateShallow(t, sought, remote_shallow);
        return;
    }
    const sideband = t.serverSupportsV0("side-band-64k") or t.serverSupportsV0("side-band");
    var caps: util.Buf = .empty;
    if (t.serverSupportsV0("side-band-64k")) {
        util.bufAppend(&caps, " side-band-64k");
    } else if (t.serverSupportsV0("side-band")) util.bufAppend(&caps, " side-band");
    if (t.deepen_relative) util.bufAppend(&caps, " deepen-relative");
    if (o.thin and t.serverSupportsV0("thin-pack")) util.bufAppend(&caps, " thin-pack");
    if (o.no_progress and t.serverSupportsV0("no-progress")) util.bufAppend(&caps, " no-progress");
    if (o.include_tag and t.serverSupportsV0("include-tag")) util.bufAppend(&caps, " include-tag");
    if (t.serverSupportsV0("ofs-delta")) util.bufAppend(&caps, " ofs-delta");
    if (o.filter != null) {
        if (t.serverSupportsV0("filter")) {
            util.bufAppend(&caps, " filter");
        } else util.warn("filtering not recognized by server, ignoring", .{});
    }
    if (t.serverSupportsV0("deepen-since")) util.bufAppend(&caps, " deepen-since");
    if (t.serverSupportsV0("deepen-not")) util.bufAppend(&caps, " deepen-not");
    if (t.serverSupportsV0("agent")) {
        util.bufAppend(&caps, " agent=");
        util.bufAppend(&caps, @import("cmd/uploadpack.zig").agentSanitized());
    }
    var req: util.Buf = .empty;
    for (wants, 0..) |w, i| {
        if (i == 0) {
            pkt.bufFmt(&req, "want {s}{s}\n", .{ hash.hex(w), caps.items });
        } else pkt.bufFmt(&req, "want {s}\n", .{hash.hex(w)});
    }
    addShallowRequests(&req, t, false);
    sendFilter(&req, o.filter, t.serverSupportsV0("filter"));
    pkt.bufFlush(&req);
    if (t.deepen) {
        os.writeAll(t.fd_out, req.items) catch util.die("unable to write request to remote: {s}", .{os.lastErr()});
        req.clearRetainingCapacity();
        while (t.rd.read() == .normal) {
            const line = t.rd.line;
            if (handleShallowLine(line)) continue;
            util.die("expected shallow/unshallow, got {s}", .{line});
        }
    }
    const t2 = @import("trace2.zig");
    t2.regionEnter("fetch-pack", "negotiation_v0_v1", true);
    const v0_haves = collectHaves();
    for (v0_haves) |h| pkt.bufFmt(&req, "have {s}\n", .{hash.hex(h)});
    // find_common() flushes (one negotiation round) every INITIAL_FLUSH haves
    const v0_rounds: i64 = if (v0_haves.len >= 16) 1 else 0;
    if (v0_rounds > 0) {
        t2.regionEnterMsg("negotiation_v0_v1", "round", true, "1");
        t2.dataInt("negotiation_v0_v1", true, "haves_added", @intCast(v0_haves.len));
        t2.dataInt("negotiation_v0_v1", true, "in_vain", @intCast(v0_haves.len));
        t2.regionLeaveMsg("negotiation_v0_v1", "round", true, "1");
    }
    t2.regionLeave("fetch-pack", "negotiation_v0_v1", true);
    t2.dataInt("negotiation_v0_v1", true, "total_rounds", v0_rounds);
    pkt.bufWrite(&req, "done\n");
    os.writeAll(t.fd_out, req.items) catch util.die("unable to write request to remote: {s}", .{os.lastErr()});
    // one ACK or NAK line
    const st = t.rd.read();
    if (st != .normal) util.die("git fetch-pack: expected ACK/NAK, got a flush packet", .{});
    const line = t.rd.line;
    if (!util.eql(line, "NAK") and !util.startsWith(line, "ACK ")) {
        if (util.skipPrefix(line, "ERR ")) |e| util.die("remote error: {s}", .{e});
        util.die("git fetch-pack: expected ACK/NAK, got '{s}'", .{line});
    }
    if (util.eql(line, "NAK") and !o.keep_pack and v0_haves.len > 0) util.warn("no common commits", .{});
    if (!t.deepen and remote_shallow.len > 0 and t.reject_shallow) {
        var any = false;
        for (remote_shallow) |s| {
            if (!objects.isShallow(s)) any = true;
        }
        if (any) util.die("source repository is shallow, reject to clone.", .{});
    }
    var src = PackSource{ .rd = t.rd, .sideband = sideband };
    t.rd.chomp = false;
    receivePack(&src, o);
    t.rd.chomp = true;
    _ = transport.finish(t);
    t.got_remote_heads = false;
    updateShallow(t, sought, remote_shallow);
}

fn fetchV2(t: *Transport, sought: []const *Ref, o: Options) void {
    const wants = computeWants(sought, t.deepen);
    if (wants.len == 0) return;
    if (!t.serverSupportsV2("fetch")) util.die("server doesn't support '{s}'", .{"fetch"});
    const t2 = @import("trace2.zig");
    t2.regionEnter("fetch-pack", "negotiation_v2", true);
    t2.regionEnterMsg("negotiation_v2", "round", true, "1");
    transport.sendCommandV2(t, "fetch");
    var req: util.Buf = .empty;
    if (o.thin) pkt.bufWrite(&req, "thin-pack");
    if (o.no_progress) pkt.bufWrite(&req, "no-progress");
    if (o.include_tag) pkt.bufWrite(&req, "include-tag");
    pkt.bufWrite(&req, "ofs-delta");
    if (t.serverSupportsFeature("fetch", "shallow")) {
        addShallowRequests(&req, t, true);
    } else if (repoIsShallow() or t.deepen) util.die("Server does not support shallow requests", .{});
    sendFilter(&req, o.filter, t.serverSupportsFeature("fetch", "filter"));
    for (wants) |w| pkt.bufFmt(&req, "want {s}\n", .{hash.hex(w)});
    const v2_haves = collectHaves();
    for (v2_haves) |h| pkt.bufFmt(&req, "have {s}\n", .{hash.hex(h)});
    if (t2.enabled) {
        t2.dataInt("negotiation_v2", true, "haves_added", @intCast(v2_haves.len));
        t2.dataInt("negotiation_v2", true, "in_vain", @intCast(v2_haves.len));
    }
    t2.regionLeaveMsg("negotiation_v2", "round", true, "1");
    t2.regionLeave("fetch-pack", "negotiation_v2", true);
    t2.dataInt("negotiation_v2", true, "total_rounds", 1);
    pkt.bufWrite(&req, "done\n");
    pkt.bufFlush(&req);
    os.writeAll(t.fd_out, req.items) catch util.die("unable to write request to remote: {s}", .{os.lastErr()});
    var remote_shallow: std.ArrayList(Oid) = .empty;
    // read sections until "packfile"
    while (true) {
        const st = t.rd.read();
        if (st == .eof) util.die("the remote end hung up unexpectedly", .{});
        if (st != .normal) util.die("error processing acks: {d}", .{@intFromEnum(st)});
        const sect = util.dupe(t.rd.line);
        if (util.eql(sect, "packfile")) break;
        if (util.eql(sect, "shallow-info")) {
            var unshallow_received = false;
            var shallows: std.ArrayList(Oid) = .empty;
            while (t.rd.read() == .normal) {
                const line = t.rd.line;
                if (util.skipPrefix(line, "shallow ")) |a| {
                    const so = hash.fromHex(a) orelse util.die("invalid shallow line: {s}", .{line});
                    shallows.append(gpa, so) catch util.oom();
                    continue;
                }
                if (util.startsWith(line, "unshallow ")) {
                    _ = handleShallowLine(line);
                    unshallow_received = true;
                    continue;
                }
                util.die("expected shallow/unshallow, got {s}", .{line});
            }
            if (t.rd.status != .delim) util.die("error processing shallow info: {d}", .{@intFromEnum(t.rd.status)});
            if (t.deepen or unshallow_received) {
                for (shallows.items) |so| objects.registerShallow(so);
                t.deepen = true;
            } else if (shallows.items.len > 0) {
                remote_shallow = shallows;
                if (t.reject_shallow) {
                    for (shallows.items) |so| {
                        if (!objects.isShallow(so)) util.die("source repository is shallow, reject to clone.", .{});
                    }
                }
            }
            continue;
        }
        // skip the section body
        while (true) {
            const s2 = t.rd.read();
            if (s2 == .delim) break;
            if (s2 == .normal) continue;
            if (s2 == .flush) return;
            util.die("the remote end hung up unexpectedly", .{});
        }
    }
    var src = PackSource{ .rd = t.rd, .sideband = true };
    t.rd.chomp = false;
    receivePack(&src, o);
    t.rd.chomp = true;
    @import("transport_helper.zig").checkStatelessDelimiter(t, "git fetch-pack: expected response end packet");
    updateShallow(t, sought, remote_shallow.items);
}
