//! A few of git's t/helper test-tool subcommands that inspect on-disk
//! index state (reached when the binary is invoked as "test-tool").

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");

pub fn main(all: []const []const u8) u8 {
    if (all.len < 2) util.die("usage: test-tool <cmd> [args]", .{});
    const cmd = all[1];
    const args = all[2..];
    if (util.eql(cmd, "dump-split-index")) return dumpSplitIndex(args);
    util.die("There is no test named '{s}'", .{cmd});
}

fn dumpSplitIndex(args: []const []const u8) u8 {
    repo_mod.setup(false);
    if (args.len < 1) util.die("usage: test-tool dump-split-index <file>", .{});
    const idx = index_mod.readRawFile(args[0]);
    util.outf("own {s}\n", .{&hash.hex(idx.oid)});
    const si = idx.split orelse {
        util.out("not a split index\n");
        return 0;
    };
    util.outf("base {s}\n", .{&hash.hex(si.base_oid)});
    for (idx.entries.items) |e| {
        util.outf("{o:0>6} {s} {d}\t{s}\n", .{ e.mode, &hash.hex(e.oid), e.stage(), e.path });
    }
    util.out("replacements:");
    if (si.replace_bm) |*bm| for (bm.bits()) |b| util.outf(" {d}", .{b});
    util.out("\ndeletions:");
    if (si.delete_bm) |*bm| for (bm.bits()) |b| util.outf(" {d}", .{b});
    util.out("\n");
    return 0;
}
