//! git diff / diff-files / diff-index / diff-tree
//! (port of builtin/diff.c, builtin/diff-files.c, builtin/diff-index.c,
//! builtin/diff-tree.c and diff-no-index.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const lockfile = @import("../lockfile.zig");
const pathspec_mod = @import("../pathspec.zig");
const revparse = @import("../revparse.zig");
const revision = @import("../revision.zig");
const logtree = @import("../logtree.zig");
const cn = @import("../commitnode.zig");
const commitreach = @import("../commitreach.zig");
const diff = @import("../diff.zig");
const treediff = @import("../treediff.zig");
const combined = @import("../combined.zig");
const pretty = @import("../pretty.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const RevInfo = revision.RevInfo;
const DiffOptions = diff.DiffOptions;

const COMMON_DIFF_OPTIONS_HELP =
    "\ncommon diff options:\n" ++
    "  -z            output diff-raw with lines terminated with NUL.\n" ++
    "  -p            output patch format.\n" ++
    "  -u            synonym for -p.\n" ++
    "  --patch-with-raw\n" ++
    "                output both a patch and the diff-raw format.\n" ++
    "  --stat        show diffstat instead of patch.\n" ++
    "  --numstat     show numeric diffstat instead of patch.\n" ++
    "  --patch-with-stat\n" ++
    "                output a patch and prepend its diffstat.\n" ++
    "  --name-only   show only names of changed files.\n" ++
    "  --name-status show names and status of changed files.\n" ++
    "  --full-index  show full object name on index lines.\n" ++
    "  --abbrev=<n>  abbreviate object names in diff-tree header and diff-raw.\n" ++
    "  -R            swap input file pairs.\n" ++
    "  -B            detect complete rewrites.\n" ++
    "  -M            detect renames.\n" ++
    "  -C            detect copies.\n" ++
    "  --find-copies-harder\n" ++
    "                try unchanged files as candidate for copy detection.\n" ++
    "  -l<n>         limit rename attempts up to <n> paths.\n" ++
    "  -O<file>      reorder diffs according to the <file>.\n" ++
    "  -S<string>    find filepair whose only one side contains the string.\n" ++
    "  --pickaxe-all\n" ++
    "                show all files diff when -S is used and hit is found.\n" ++
    "  -a  --text    treat all files as text.\n";

const diff_tree_usage =
    "git diff-tree [--stdin] [-m] [-s] [-v] [--no-commit-id] [--pretty]\n" ++
    "              [-t] [-r] [-c | --cc] [--combined-all-paths] [--root] [--merge-base]\n" ++
    "              [<common-diff-options>] <tree-ish> [<tree-ish>] [<path>...]\n" ++
    "\n" ++
    "  -r            diff recursively\n" ++
    "  -c            show combined diff for merge commits\n" ++
    "  --cc          show combined diff for merge commits removing uninteresting hunks\n" ++
    "  --combined-all-paths\n" ++
    "                show name of file in all parents for combined diffs\n" ++
    "  --root        include the initial commit as diff against /dev/null\n" ++
    COMMON_DIFF_OPTIONS_HELP;

const diff_files_usage =
    "git diff-files [-q] [-0 | -1 | -2 | -3 | -c | --cc] [<common-diff-options>] [<path>...]" ++
    "\n" ++ COMMON_DIFF_OPTIONS_HELP;

const diff_cache_usage =
    "git diff-index [-m] [--cached] [--merge-base] " ++
    "[<common-diff-options>] <tree-ish> [<path>...]" ++
    "\n" ++ COMMON_DIFF_OPTIONS_HELP;

const builtin_diff_usage =
    "git diff [<options>] [<commit>] [--] [<path>...]\n" ++
    "   or: git diff [<options>] --cached [--merge-base] [<commit>] [--] [<path>...]\n" ++
    "   or: git diff [<options>] [--merge-base] <commit> [<commit>...] <commit> [--] [<path>...]\n" ++
    "   or: git diff [<options>] <commit>...<commit> [--] [<path>...]\n" ++
    "   or: git diff [<options>] <blob> <blob>\n" ++
    "   or: git diff [<options>] --no-index [--] <path> <path> [<pathspec>...]" ++
    "\n" ++ COMMON_DIFF_OPTIONS_HELP;

fn usage(u: []const u8) noreturn {
    util.flushStdout();
    util.eprint("usage: {s}\n", .{u});
    os.exit(129);
}

fn showUsageIfAsked(args: []const []const u8, u: []const u8) void {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.out("usage: ");
        util.out(u);
        util.out("\n");
        util.flushStdout();
        os.exit(0);
    }
}

const Setup = struct { revs: *RevInfo, o: *DiffOptions };

fn initRevs(o: *DiffOptions) Setup {
    const revs = gpa.create(RevInfo) catch util.oom();
    const prefix = if (repo_mod.repo_) |r| r.prefix else "";
    revs.* = RevInfo.init(prefix);
    revs.format_hook = pretty.getCommitFormatOpt;
    diff.setupRevDiffWith(revs, o);
    o.rotate_to_strict = true;
    return .{ .revs = revs, .o = o };
}

fn plumbingSetup() Setup {
    const o = gpa.create(DiffOptions) catch util.oom();
    o.* = DiffOptions.initBasic();
    const s = initRevs(o);
    s.revs.abbrev = 0;
    return s;
}

/// set output format on both the diff options and the rev_info mirror
fn setFormat(s: Setup, fmt_bits: u32) void {
    s.o.output_format = fmt_bits;
    s.revs.output_format = fmt_bits;
}

fn resultCode(s: Setup) u8 {
    return diff.resultCodeOpts(s.o);
}

// ---------------------------------------------------------------------------
// merge base (diff_get_merge_base)

fn getMergeBase(revs: *RevInfo) Oid {
    for (revs.pending.items) |pe| {
        if (pe.item.flags != 0) util.die("--merge-base does not work with ranges", .{});
    }
    var mb_child: [2]?*cn.Commit = .{ null, null };
    for (revs.pending.items, 0..) |pe, i| {
        if (i >= 2) break;
        mb_child[i] = cn.lookupCommitReference(pe.item.oid);
    }
    if (revs.pending.items.len == 1) {
        const oid = revparse.getOid("HEAD") orelse util.die("unable to get HEAD", .{});
        mb_child[1] = cn.lookupCommitReference(oid);
    }
    const a = mb_child[0] orelse util.die("--merge-base only works with commits", .{});
    const b = mb_child[1] orelse util.die("--merge-base only works with commits", .{});
    const bases = commitreach.getMergeBases(a, b) orelse util.die("no merge base found", .{});
    if (bases.next != null) util.die("multiple merge bases found", .{});
    return bases.item.obj.oid;
}

fn runDiffIndexRevs(s: Setup, cached: bool, merge_base: bool, match_missing: bool) void {
    const revs = s.revs;
    if (revs.pending.items.len != 1) util.die("BUG: run_diff_index must be passed exactly one tree", .{});
    var oid: Oid = undefined;
    var name: []const u8 = undefined;
    if (merge_base) {
        oid = getMergeBase(revs);
        name = hash.hexAlloc(oid);
    } else {
        oid = revs.pending.items[0].item.oid;
        name = revs.pending.items[0].name;
    }
    diff.runDiffIndexWith(s.o, oid, name, cached, .{ .match_missing = match_missing });
}

fn runDiffFilesRevs(s: Setup, silent_on_removed: bool) void {
    diff.runDiffFilesWith(s.o, .{
        .unmerged_stage = s.revs.max_count,
        .combine_merges = s.revs.combine_merges,
        .dense_combined_merges = s.revs.dense_combined_merges,
        .silent_on_removed = silent_on_removed,
    });
}

// ---------------------------------------------------------------------------
// diff-files

pub fn cmdDiffFiles(args: []const []const u8) u8 {
    showUsageIfAsked(args, diff_files_usage);
    const s = plumbingSetup();
    s.o.ita_invisible_in_index = true;
    var rest = revision.setupRevisions(s.revs, args, .{});
    var silent = false;
    while (rest.len > 1 and rest[1].len > 0 and rest[1][0] == '-') {
        const a = rest[1];
        if (util.eql(a, "--base")) {
            s.revs.max_count = 1;
        } else if (util.eql(a, "--ours")) {
            s.revs.max_count = 2;
        } else if (util.eql(a, "--theirs")) {
            s.revs.max_count = 3;
        } else if (util.eql(a, "-q")) {
            silent = true;
        } else usage(diff_files_usage);
        rest = rest[1..];
    }
    if (s.o.output_format == 0) setFormat(s, diff.FMT_RAW);
    if (s.revs.pending.items.len != 0 or s.revs.min_age != revision.UNSET_TIME or
        s.revs.max_age != revision.UNSET_TIME or 3 < s.revs.max_count)
        usage(diff_files_usage);
    if (s.revs.max_count == -1 and s.o.output_format & diff.FMT_PATCH != 0)
        revision.diffMergesSetDenseCombinedIfUnset(s.revs);
    runDiffFilesRevs(s, silent);
    return resultCode(s);
}

// ---------------------------------------------------------------------------
// diff-index

pub fn cmdDiffIndex(args: []const []const u8) u8 {
    showUsageIfAsked(args, diff_cache_usage);
    const s = plumbingSetup();
    revision.suppress_m_parsing = true;
    const rest = revision.setupRevisions(s.revs, args, .{});
    var cached = false;
    var merge_base = false;
    var match_missing = false;
    for (rest[1..]) |a| {
        if (util.eql(a, "--cached")) {
            cached = true;
        } else if (util.eql(a, "--merge-base")) {
            merge_base = true;
        } else if (util.eql(a, "-m")) {
            match_missing = true;
        } else usage(diff_cache_usage);
    }
    if (s.o.output_format == 0) setFormat(s, diff.FMT_RAW);
    if (s.revs.pending.items.len != 1 or s.revs.max_count != -1 or
        s.revs.min_age != revision.UNSET_TIME or s.revs.max_age != revision.UNSET_TIME)
        usage(diff_cache_usage);
    if (!cached) _ = repo_mod.requireWorkTree("diff-index");
    runDiffIndexRevs(s, cached, merge_base, match_missing);
    return resultCode(s);
}

// ---------------------------------------------------------------------------
// diff-tree

var tweak_dense_target: ?*DiffOptions = null;

fn diffTreeTweakRev(revs: *RevInfo) void {
    if (revs.output_format == 0) {
        revs.output_format = if (revs.dense_combined_merges) diff.FMT_PATCH else diff.FMT_RAW;
    }
}

fn parseOidHex(p: []const u8) ?Oid {
    if (p.len < 40) return null;
    return hash.fromHex(p[0..40]);
}

fn isSpaceC(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r' or c == 0x0b or c == 0x0c;
}

fn stdinDiffCommit(revs: *RevInfo, commit: *cn.Commit, p0: []const u8) void {
    cn.parseOrDie(commit);
    var p = p0;
    var replaced = false;
    var tail: ?*cn.CommitList = null;
    while (p.len > 0 and isSpaceC(p[0])) {
        p = p[1..];
        const oid = parseOidHex(p) orelse break;
        p = p[40..];
        const parent = cn.lookupCommit(oid);
        if (!replaced) {
            commit.parents = null;
            replaced = true;
        }
        if (parent) |par| {
            const node = gpa.create(cn.CommitList) catch util.oom();
            node.* = .{ .item = par };
            if (tail) |t| t.next = node else commit.parents = node;
            tail = node;
        }
    }
    _ = logtree.logTreeCommit(revs, commit);
}

fn stdinDiffTrees(s: Setup, tree1: Oid, p: []const u8) void {
    if (p.len < 1 or !isSpaceC(p[0])) {
        util.err("Need exactly two trees, separated by a space", .{});
        return;
    }
    const rest = p[1..];
    const oid = parseOidHex(rest) orelse {
        util.err("Need exactly two trees, separated by a space", .{});
        return;
    };
    if (rest.len != 40) {
        util.err("Need exactly two trees, separated by a space", .{});
        return;
    }
    if (objectsReadTree(oid) == false) return;
    util.outf("{s} {s}\n", .{ hash.hexAlloc(tree1), hash.hexAlloc(oid) });
    treediff.diffTreeOid(tree1, oid, "", s.o);
    _ = logtree.logTreeDiffFlush(s.revs);
}

fn objectsReadTree(oid: Oid) bool {
    const obj = cn.parseObject(oid) orelse return false;
    return obj.typ == .tree;
}

fn diffTreeStdin(s: Setup, line0: []const u8) void {
    if (line0.len == 0 or line0[line0.len - 1] != '\n') return;
    const line = line0[0 .. line0.len - 1];
    const oid = parseOidHex(line) orelse return;
    const p = line[40..];
    const obj = cn.parseObject(oid) orelse return;
    switch (obj.typ) {
        .commit => {
            const c = cn.lookupCommit(oid) orelse return;
            stdinDiffCommit(s.revs, c, p);
        },
        .tree => stdinDiffTrees(s, oid, p),
        else => util.err("Object {s} is a {s}, not a commit or tree", .{ hash.hexAlloc(oid), @tagName(obj.typ) }),
    }
}

pub fn cmdDiffTree(args: []const []const u8) u8 {
    showUsageIfAsked(args, diff_tree_usage);
    const s = plumbingSetup();
    _ = index_mod.get();
    s.revs.diff = true;
    s.revs.disable_stdin = true;
    const rest = revision.setupRevisions(s.revs, args, .{ .tweak = diffTreeTweakRev });
    var read_stdin = false;
    var merge_base = false;
    for (rest[1..]) |a| {
        if (util.eql(a, "--stdin")) {
            read_stdin = true;
            continue;
        }
        if (util.eql(a, "--merge-base")) {
            merge_base = true;
            continue;
        }
        usage(diff_tree_usage);
    }
    if (read_stdin and merge_base)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--stdin", "--merge-base" });
    if (merge_base and s.revs.pending.items.len != 2)
        util.die("--merge-base only works with two commits", .{});

    const pend = s.revs.pending.items;
    switch (pend.len) {
        0 => if (!read_stdin) usage(diff_tree_usage),
        1 => {
            if (cn.lookupCommitReference(pend[0].item.oid)) |c| _ = logtree.logTreeCommit(s.revs, c);
        },
        2 => {
            var t1 = pend[0].item.oid;
            var t2 = pend[1].item.oid;
            if (merge_base) {
                t1 = getMergeBase(s.revs);
            } else if (pend[1].item.flags & cn.UNINTERESTING != 0) {
                std.mem.swap(Oid, &t1, &t2);
            }
            treediff.diffTreeOid(t1, t2, "", s.o);
            _ = logtree.logTreeDiffFlush(s.revs);
        },
        else => {},
    }

    if (read_stdin) {
        const data = os.readAllFd(0) catch "";
        var saved_nrl: i32 = 0;
        var saved_dcctc = false;
        var start: usize = 0;
        while (start < data.len) {
            const nl = std.mem.indexOfScalarPos(u8, data, start, '\n');
            const end = if (nl) |n| n + 1 else data.len;
            const line = data[start..end];
            start = end;
            if (parseOidHex(line) == null) {
                util.out(line);
                util.flushStdout();
            } else {
                diffTreeStdin(s, line);
                if (saved_nrl < s.o.needed_rename_limit) saved_nrl = s.o.needed_rename_limit;
                if (s.o.degraded_cc_to_c) saved_dcctc = true;
            }
        }
        s.o.degraded_cc_to_c = saved_dcctc;
        s.o.needed_rename_limit = saved_nrl;
    }
    return resultCode(s);
}

// ---------------------------------------------------------------------------
// git diff --no-index

const Special = enum { none, stdin, pipe };
const STDIN_NAME: []const u8 = "-";

fn isFifo(mode: u32) bool {
    return mode & 0o170000 == 0o010000;
}

fn createCeMode(mode: u32) u32 {
    if (mode & 0o170000 == 0o120000) return 0o120000;
    if (mode & 0o170000 == 0o040000) return 0o040000;
    if (mode & 0o170000 == 0o160000) return 0o160000;
    return 0o100000 | (if (mode & 0o100 != 0) @as(u32, 0o755) else 0o644);
}

fn getMode(path: ?[]const u8, is_stdin: bool, mode: *u32, special: ?*Special) bool {
    if (path == null or util.eql(path.?, "/dev/null")) {
        mode.* = 0;
    } else if (is_stdin) {
        mode.* = createCeMode(0o666);
        special.?.* = .stdin;
    } else if (os.lstatPath(path.?)) |st| {
        mode.* = st.mode;
    } else {
        util.err("Could not access '{s}'", .{path.?});
        return false;
    }
    if (special) |sp| {
        var fifo = isFifo(mode.*);
        if (!fifo and mode.* & 0o170000 == 0o120000) {
            if (os.statPath(path.?)) |st2| fifo = isFifo(st2.mode);
        }
        if (fifo) {
            mode.* = createCeMode(0o666);
            sp.* = .pipe;
        }
    }
    return true;
}

fn noindexFilespec(name: ?[]const u8, mode: u32, special: Special) *diff.Filespec {
    const s = diff.allocFilespec(name orelse "/dev/null", hash.zero, false, mode);
    switch (special) {
        .stdin => {
            const d = os.readAllFd(0) catch util.die("error while reading from stdin", .{});
            s.data = d;
            s.size = d.len;
            s.is_stdin = true;
        },
        .pipe => {
            const d = os.readFile(s.path) orelse util.die("error while reading from '{s}'", .{s.path});
            s.data = d;
            s.size = d.len;
            s.is_stdin = true;
        },
        .none => {},
    }
    return s;
}

fn readDirectoryContents(path: []const u8, ps: ?*const pathspec_mod.Pathspec, match: *util.Buf) ?[][]const u8 {
    const names = os.listDir(path) orelse {
        util.err("Could not open directory {s}", .{path});
        return null;
    };
    var list: std.ArrayList([]const u8) = .empty;
    const len = match.items.len;
    for (names) |de| {
        const n = de.name;
        if (util.eql(n, ".") or util.eql(n, "..")) continue;
        if (ps) |p| {
            match.shrinkRetainingCapacity(len);
            util.bufAppend(match, n);
            const full = util.concat(&.{ path, if (path.len > 0 and path[path.len - 1] == '/') "" else "/", n });
            const is_dir = if (os.statPath(full)) |st| st.isDir() else false;
            if (p.matchLeading(match.items, is_dir, null) == 0) continue;
        }
        list.append(gpa, util.dupe(n)) catch util.oom();
    }
    match.shrinkRetainingCapacity(len);
    std.mem.sort([]const u8, list.items, {}, struct {
        fn lt(_: void, a: []const u8, b: []const u8) bool {
            return std.mem.order(u8, a, b) == .lt;
        }
    }.lt);
    // string_list_insert: dedupe
    var out: std.ArrayList([]const u8) = .empty;
    for (list.items) |n| {
        if (out.items.len > 0 and util.eql(out.items[out.items.len - 1], n)) continue;
        out.append(gpa, n) catch util.oom();
    }
    return out.items;
}

fn completeSlash(b: *util.Buf) void {
    if (b.items.len > 0 and b.items[b.items.len - 1] != '/') util.bufByte(b, '/');
}

fn queueDiffNoIndex(o: *DiffOptions, name1_0: ?[]const u8, name2_0: ?[]const u8, stdin1: bool, stdin2: bool, recursing: bool, ps: ?*const pathspec_mod.Pathspec, m1: *util.Buf, m2: *util.Buf) bool {
    var name1 = name1_0;
    var name2 = name2_0;
    var mode1: u32 = 0;
    var mode2: u32 = 0;
    var sp1: Special = .none;
    var sp2: Special = .none;
    if (!getMode(name1, stdin1, &mode1, if (recursing) null else &sp1) or
        !getMode(name2, stdin2, &mode2, if (recursing) null else &sp2)) return false;
    const dir1 = mode1 & 0o170000 == 0o040000;
    const dir2 = mode2 & 0o170000 == 0o040000;
    if (mode1 != 0 and mode2 != 0 and dir1 != dir2) {
        var d1: *diff.Filespec = undefined;
        var d2: *diff.Filespec = undefined;
        if (dir1) {
            d1 = noindexFilespec(null, 0, .none);
            d2 = noindexFilespec(name2, mode2, sp2);
            name2 = null;
            mode2 = 0;
        } else {
            d1 = noindexFilespec(name1, mode1, sp1);
            d2 = noindexFilespec(null, 0, .none);
            name1 = null;
            mode1 = 0;
        }
        _ = diff.queuePair(d1, d2);
    }
    if (mode1 & 0o170000 == 0o040000 or mode2 & 0o170000 == 0o040000) {
        const ml1 = m1.items.len;
        const ml2 = m2.items.len;
        var p1: [][]const u8 = &.{};
        var p2: [][]const u8 = &.{};
        if (name1) |n| p1 = readDirectoryContents(n, ps, m1) orelse return false;
        if (name2) |n| p2 = readDirectoryContents(n, ps, m2) orelse return false;
        var b1: util.Buf = .empty;
        var b2: util.Buf = .empty;
        if (name1) |n| {
            util.bufAppend(&b1, n);
            completeSlash(&b1);
        }
        if (name2) |n| {
            util.bufAppend(&b2, n);
            completeSlash(&b2);
        }
        const len1 = b1.items.len;
        const len2 = b2.items.len;
        var ix1: usize = 0;
        var ix2: usize = 0;
        while (ix1 < p1.len or ix2 < p2.len) {
            b1.shrinkRetainingCapacity(len1);
            b2.shrinkRetainingCapacity(len2);
            if (ps != null) {
                m1.shrinkRetainingCapacity(ml1);
                m2.shrinkRetainingCapacity(ml2);
            }
            const comp: std.math.Order = if (ix1 == p1.len) .gt else if (ix2 == p2.len) .lt else std.mem.order(u8, p1[ix1], p2[ix2]);
            var n1: ?[]const u8 = null;
            var n2: ?[]const u8 = null;
            if (comp != .gt) {
                util.bufAppend(&b1, p1[ix1]);
                if (ps != null) {
                    util.bufAppend(m1, p1[ix1]);
                    completeSlash(m1);
                }
                n1 = util.dupe(b1.items);
                ix1 += 1;
            }
            if (comp != .lt) {
                util.bufAppend(&b2, p2[ix2]);
                if (ps != null) {
                    util.bufAppend(m2, p2[ix2]);
                    completeSlash(m2);
                }
                n2 = util.dupe(b2.items);
                ix2 += 1;
            }
            if (!queueDiffNoIndex(o, n1, n2, false, false, true, ps, m1, m2)) return false;
        }
        return true;
    }
    if (o.flags.reverse) {
        std.mem.swap(u32, &mode1, &mode2);
        std.mem.swap(?[]const u8, &name1, &name2);
        std.mem.swap(Special, &sp1, &sp2);
    }
    const d1 = noindexFilespec(name1, mode1, sp1);
    const d2 = noindexFilespec(name2, mode2, sp2);
    _ = diff.queuePair(d1, d2);
    return true;
}

fn appendBasename(dir: []const u8, file: []const u8) []const u8 {
    var b: util.Buf = .empty;
    util.bufAppend(&b, dir);
    while (b.items.len > 0 and b.items[b.items.len - 1] == '/') b.items.len -= 1;
    util.bufByte(&b, '/');
    const tail = if (std.mem.lastIndexOfScalar(u8, file, '/')) |k| file[k + 1 ..] else file;
    util.bufAppend(&b, tail);
    return b.items;
}

const no_index_usage = "git diff --no-index [<options>] <path> <path> [<pathspec>...]";

fn noIndexUsage() noreturn {
    util.flushStdout();
    util.eprint("usage: {s}\n\n", .{no_index_usage});
    os.exit(129);
}

fn diffNoIndex(s: Setup, implicit: bool, args: []const []const u8) u8 {
    const o = s.o;
    var pos: std.ArrayList([]const u8) = .empty;
    var i: usize = 1;
    while (i < args.len) {
        const a = args[i];
        if (util.eql(a, "--")) {
            pos.appendSlice(gpa, args[i + 1 ..]) catch util.oom();
            break;
        }
        if (util.eql(a, "--no-index")) {
            i += 1;
            continue;
        }
        if (util.eql(a, "-h")) {
            util.out("usage: " ++ no_index_usage ++ "\n\n");
            util.flushStdout();
            os.exit(129);
        }
        if (a.len > 1 and a[0] == '-') {
            const n = o.parseOpt(args, i);
            if (n == 0) {
                if (a.len > 2 and a[1] == '-') {
                    util.err("unknown option `{s}'", .{a[2..]});
                } else util.err("unknown switch `{c}'", .{a[1]});
                noIndexUsage();
            }
            i += n;
            continue;
        }
        pos.append(gpa, a) catch util.oom();
        i += 1;
    }
    const argv = pos.items;
    if (argv.len < 2) {
        if (implicit) util.warn("Not a git repository. Use --no-index to compare two paths outside a working tree", .{});
        noIndexUsage();
    }
    var paths: [2][]const u8 = .{ argv[0], argv[1] };
    const is_stdin = [2]bool{ util.eql(argv[0], "-"), util.eql(argv[1], "-") };

    // fixup_paths()
    var isdir: [2]bool = .{ false, false };
    var ispipe: [2]bool = .{ false, false };
    for (0..2) |k| {
        if (is_stdin[k]) continue;
        if (os.statPath(paths[k])) |st| {
            isdir[k] = st.isDir();
            ispipe[k] = isFifo(st.mode);
        }
    }
    if ((is_stdin[0] and isdir[1]) or (isdir[0] and is_stdin[1]))
        util.die("cannot compare stdin to a directory", .{});
    if ((isdir[0] and ispipe[1]) or (ispipe[0] and isdir[1]))
        util.die("cannot compare a named pipe to a directory", .{});
    var ps_storage: pathspec_mod.Pathspec = .{};
    var ps: ?*const pathspec_mod.Pathspec = null;
    if (isdir[0] and isdir[1]) {
        if (argv.len > 2) {
            ps_storage = pathspec_mod.parse("", argv[2..], .{});
            if (ps_storage.items.len > 0) ps = &ps_storage;
        }
    } else {
        if (isdir[0]) {
            paths[0] = appendBasename(paths[0], paths[1]);
        } else if (isdir[1]) {
            paths[1] = appendBasename(paths[1], paths[0]);
        }
        if (argv.len > 2) {
            util.warn("Limiting comparison with pathspecs is only supported if both paths are directories.", .{});
            noIndexUsage();
        }
    }

    o.skip_stat_unmatch = 1;
    if (o.output_format == 0) o.output_format = diff.FMT_PATCH;
    o.flags.no_index = true;
    o.no_index_paths = true;
    o.flags.relative_name = true;
    o.prefix = null;
    o.prefix_length = 0;
    s.revs.max_count = -2;
    o.setupDone();
    o.flags.exit_with_status = true;

    var m1: util.Buf = .empty;
    var m2: util.Buf = .empty;
    if (!queueDiffNoIndex(o, paths[0], paths[1], is_stdin[0], is_stdin[1], false, ps, &m1, &m2)) return 1;
    o.setMnemonicPrefix("1/", "2/");
    diff.diffcoreStd(o);
    diff.flush(o);
    return diff.resultCodeOpts(o);
}

// ---------------------------------------------------------------------------
// git diff

fn pathInsideRepo(path: []const u8) bool {
    return repo_mod.prefixPath(path) != null;
}

fn refreshIndexQuietly() void {
    const path = repo_mod.repo().indexPath();
    switch (lockfile.tryLock(path)) {
        .ok => |l| {
            index_mod.discard();
            const idx = index_mod.get();
            _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET | index_mod.REFRESH_UNMERGED, null, null);
            idx.lock = l;
            if (idx.changed) idx.write() else idx.rollback();
        },
        .err => {},
    }
}

const Ent = struct { oid: Oid, name: []const u8, flags: u32 };

fn stuffChange(o: *DiffOptions, old_mode0: u32, new_mode0: u32, old_oid0: Oid, new_oid0: Oid, old_valid0: bool, new_valid0: bool, old_path0: []const u8, new_path0: []const u8) void {
    var old_mode = old_mode0;
    var new_mode = new_mode0;
    var old_oid = old_oid0;
    var new_oid = new_oid0;
    var old_valid = old_valid0;
    var new_valid = new_valid0;
    var old_path = old_path0;
    var new_path = new_path0;
    if (!hash.isZero(old_oid) and !hash.isZero(new_oid) and hash.eql(old_oid, new_oid) and old_mode == new_mode) return;
    if (o.flags.reverse) {
        std.mem.swap(u32, &old_mode, &new_mode);
        std.mem.swap(Oid, &old_oid, &new_oid);
        std.mem.swap([]const u8, &old_path, &new_path);
        // C swaps the oids but not the validity flags
        _ = &old_valid;
        _ = &new_valid;
    }
    if (o.prefix) |p| {
        const pl = p[0..o.prefix_length];
        if (!util.startsWith(old_path, pl) or !util.startsWith(new_path, pl)) return;
    }
    const one = diff.allocFilespec(old_path, old_oid, old_valid, old_mode);
    const two = diff.allocFilespec(new_path, new_oid, new_valid, new_mode);
    _ = diff.queuePair(one, two);
}

fn canonMode(mode: u32) u32 {
    return createCeMode(mode);
}

fn blobPath(e: revision.PendingEntry) []const u8 {
    return e.path orelse e.name;
}

pub fn cmdDiff(args: []const []const u8) u8 {
    showUsageIfAsked(args, builtin_diff_usage);
    var no_index: u8 = 0; // 1 explicit, 2 implicit
    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        if (util.eql(args[i], "--")) {
            i += 1;
            break;
        }
        if (util.eql(args[i], "--no-index")) no_index = 1;
        if (args[i].len == 0 or args[i][0] != '-') break;
    }
    const nongit = repo_mod.repo_ == null;
    if (no_index == 0) {
        if (nongit or (args.len == i + 2 and (!pathInsideRepo(args[i]) or !pathInsideRepo(args[i + 1]))))
            no_index = 2;
    }
    const o = gpa.create(DiffOptions) catch util.oom();
    o.* = DiffOptions.init();
    if (no_index != 0) {
        if (repo_mod.repo_) |r| {
            if (r.prefix.len > 0) {
                if (!os.chdir(r.prefix)) util.die("cannot come back to cwd", .{});
            }
            r.prefix = "";
        }
        o.prefix = null;
        o.prefix_length = 0;
    }
    const s = initRevs(o);
    o.stat_width = -1;
    o.stat_name_width = -1;
    o.stat_graph_width = -1;
    o.flags.allow_external = true;
    o.flags.allow_textconv = true;
    if (no_index != 0) os.exit(diffNoIndex(s, no_index == 2, args));

    o.skip_stat_unmatch = if (diff.diff_auto_refresh_index) 1 else 0;
    o.ita_invisible_in_index = true;
    if (nongit) util.die("Not a git repository", .{});
    const revs = s.revs;
    const rest = revision.setupRevisions(revs, args, .{});
    if (o.output_format == 0) {
        setFormat(s, diff.FMT_PATCH);
        o.setupDone();
    }
    o.flags.recursive = true;

    if (revs.pending.items.len == 0) {
        for (rest[1..]) |a| {
            if (util.eql(a, "--")) break;
            if (util.eql(a, "--cached") or util.eql(a, "--staged")) {
                revision.addHeadToPending(revs);
                if (revs.pending.items.len == 0) {
                    const et = hash.fromHex(hash.empty_tree_hex).?;
                    const tobj = cn.lookup(et, .tree) orelse util.die("unable to create empty tree", .{});
                    revs.addPendingObject(tobj, "HEAD");
                }
                break;
            }
        }
    }

    // symdiff_prepare()
    var skip: ?[]bool = null;
    var sym_warn = false;
    var sym_left: []const u8 = "";
    var sym_right: []const u8 = "";
    var sym_base: []const u8 = "";
    {
        var is_symdiff = false;
        var basecount: usize = 0;
        var othercount: usize = 0;
        var lpos: ?usize = null;
        var rpos: ?usize = null;
        var basepos: ?usize = null;
        const map = gpa.alloc(bool, revs.pending.items.len + 1) catch util.oom();
        @memset(map, false);
        for (revs.cmdline.items, 0..) |ce, k| {
            if (k >= revs.pending.items.len) break;
            const obj = revs.pending.items[k].item;
            switch (ce.whence) {
                .merge_base => {
                    if (basepos == null) basepos = k;
                    basecount += 1;
                },
                .left => {
                    if (lpos != null) usage(builtin_diff_usage);
                    lpos = k;
                    if (obj.flags & cn.SYMMETRIC_LEFT == 0) continue;
                    is_symdiff = true;
                },
                .right => {
                    if (rpos != null) usage(builtin_diff_usage);
                    rpos = k;
                    continue;
                },
                else => {
                    othercount += 1;
                    continue;
                },
            }
            map[k] = true;
        }
        if (lpos != null and othercount > 0) usage(builtin_diff_usage);
        if (is_symdiff) {
            sym_left = revs.pending.items[lpos.?].name;
            sym_right = revs.pending.items[rpos.?].name;
            if (basecount == 0) util.die("{s}...{s}: no merge base", .{ sym_left, sym_right });
            sym_base = revs.pending.items[basepos.?].name;
            map[basepos.?] = false;
            sym_warn = basecount > 1;
            skip = map;
        }
    }

    var ents: std.ArrayList(Ent) = .empty;
    var first_non_parent: ?usize = null;
    var blobs: [2]revision.PendingEntry = undefined;
    var nblobs: usize = 0;
    for (revs.pending.items, 0..) |entry, k| {
        var obj = entry.item;
        const name = entry.name;
        const flags = obj.flags & cn.UNINTERESTING;
        if (!obj.parsed) obj = cn.parseObject(obj.oid) orelse util.die("invalid object '{s}' given.", .{name});
        obj = cn.derefTag(obj) orelse util.die("invalid object '{s}' given.", .{name});
        var tree_oid: ?Oid = null;
        if (obj.typ == .commit) {
            const c = cn.lookupCommit(obj.oid) orelse util.die("unable to read tree object for commit '{s}'", .{name});
            cn.parseOrDie(c);
            tree_oid = c.tree;
        } else if (obj.typ == .tree) {
            tree_oid = obj.oid;
        }
        if (tree_oid) |t| {
            if (skip) |m| {
                if (m[k]) continue;
            }
            ents.append(gpa, .{ .oid = t, .name = name, .flags = flags }) catch util.oom();
            if (first_non_parent == null and (k >= revs.cmdline.items.len or revs.cmdline.items[k].whence != .parents_only))
                first_non_parent = ents.items.len - 1;
        } else if (obj.typ == .blob) {
            if (2 <= nblobs) util.die("more than two blobs given: '{s}'", .{name});
            blobs[nblobs] = entry;
            blobs[nblobs].item = obj;
            nblobs += 1;
        } else {
            util.die("unhandled object '{s}' given.", .{name});
        }
    }
    const paths = revs.prune_data.items.len;

    if (ents.items.len == 0) {
        switch (nblobs) {
            0 => builtinDiffFiles(s, rest),
            1 => {
                if (paths != 1) usage(builtin_diff_usage);
                builtinDiffBF(s, rest, &blobs[0]);
            },
            2 => {
                if (paths != 0) usage(builtin_diff_usage);
                builtinDiffBlobs(s, rest, &blobs);
            },
            else => usage(builtin_diff_usage),
        }
    } else if (nblobs != 0) {
        usage(builtin_diff_usage);
    } else if (ents.items.len == 1) {
        builtinDiffIndex(s, rest);
    } else if (ents.items.len == 2) {
        if (sym_warn) util.warn("{s}...{s}: multiple merge bases, using {s}", .{ sym_left, sym_right, sym_base });
        builtinDiffTree(s, rest, ents.items[0], ents.items[1]);
    } else {
        builtinDiffCombined(s, rest, ents.items, first_non_parent);
    }
    const result = resultCode(s);
    if (1 < o.skip_stat_unmatch) refreshIndexQuietly();
    return result;
}

fn builtinDiffBF(s: Setup, rest: []const []const u8, blob: *revision.PendingEntry) void {
    if (rest.len > 1) usage(builtin_diff_usage);
    const path = s.revs.prune_data.items[0].match;
    const st = os.lstatPath(path) orelse util.dieErrno("failed to stat '{s}'", .{path});
    const fmt_bits = st.mode & 0o170000;
    if (!(fmt_bits == 0o100000 or fmt_bits == 0o120000)) util.die("'{s}': not a regular file or symlink", .{path});
    s.o.setMnemonicPrefix("o/", "w/");
    if (blob.mode == 0o170000) blob.mode = canonMode(st.mode);
    stuffChange(s.o, blob.mode, canonMode(st.mode), blob.item.oid, hash.zero, true, false, blob.path orelse path, path);
    diff.diffcoreStd(s.o);
    diff.flush(s.o);
}

fn builtinDiffBlobs(s: Setup, rest: []const []const u8, blob: *[2]revision.PendingEntry) void {
    if (rest.len > 1) usage(builtin_diff_usage);
    const mode = canonMode(0o100644);
    if (blob[0].mode == 0o170000) blob[0].mode = mode;
    if (blob[1].mode == 0o170000) blob[1].mode = mode;
    stuffChange(s.o, blob[0].mode, blob[1].mode, blob[0].item.oid, blob[1].item.oid, true, true, blobPath(blob[0]), blobPath(blob[1]));
    diff.diffcoreStd(s.o);
    diff.flush(s.o);
}

fn builtinDiffIndex(s: Setup, rest: []const []const u8) void {
    var cached = false;
    var merge_base = false;
    for (rest[1..]) |a| {
        if (util.eql(a, "--cached") or util.eql(a, "--staged")) {
            cached = true;
        } else if (util.eql(a, "--merge-base")) {
            merge_base = true;
        } else usage(builtin_diff_usage);
    }
    const revs = s.revs;
    if (revs.pending.items.len != 1 or revs.max_count != -1 or revs.min_age != revision.UNSET_TIME or revs.max_age != revision.UNSET_TIME)
        usage(builtin_diff_usage);
    if (!cached) _ = repo_mod.requireWorkTree("diff");
    runDiffIndexRevs(s, cached, merge_base, false);
}

fn builtinDiffTree(s: Setup, rest: []const []const u8, ent0: Ent, ent1: Ent) void {
    var merge_base = false;
    for (rest[1..]) |a| {
        if (util.eql(a, "--merge-base")) {
            merge_base = true;
        } else usage(builtin_diff_usage);
    }
    var oid0: Oid = undefined;
    var oid1: Oid = undefined;
    if (merge_base) {
        oid0 = getMergeBase(s.revs);
        oid1 = ent1.oid;
        // C uses the second pending object itself (a commit); diff_tree_oid peels it
        oid1 = s.revs.pending.items[1].item.oid;
    } else {
        if (ent1.flags & cn.UNINTERESTING != 0) {
            oid0 = ent1.oid;
            oid1 = ent0.oid;
        } else {
            oid0 = ent0.oid;
            oid1 = ent1.oid;
        }
    }
    treediff.diffTreeOid(oid0, oid1, "", s.o);
    _ = logtree.logTreeDiffFlush(s.revs);
}

fn builtinDiffCombined(s: Setup, rest: []const []const u8, ents: []const Ent, first_non_parent: ?usize) void {
    if (rest.len > 1) usage(builtin_diff_usage);
    const fnp = first_non_parent orelse util.die("no merge given, only parents.", .{});
    revision.diffMergesSetDenseCombinedIfUnset(s.revs);
    var parents: std.ArrayList(Oid) = .empty;
    for (ents, 0..) |e, k| {
        if (k != fnp) parents.append(gpa, e.oid) catch util.oom();
    }
    const c = combined.Ctx{ .o = s.o, .revs = s.revs, .dense = s.revs.dense_combined_merges, .all_paths = s.revs.combined_all_paths };
    combined.diffTreeCombined(ents[fnp].oid, parents.items, &c);
}

fn builtinDiffFiles(s: Setup, rest0: []const []const u8) void {
    var rest = rest0;
    var silent = false;
    const revs = s.revs;
    while (rest.len > 1 and rest[1].len > 0 and rest[1][0] == '-') {
        const a = rest[1];
        if (util.eql(a, "--base")) {
            revs.max_count = 1;
        } else if (util.eql(a, "--ours")) {
            revs.max_count = 2;
        } else if (util.eql(a, "--theirs")) {
            revs.max_count = 3;
        } else if (util.eql(a, "-q")) {
            silent = true;
        } else if (util.eql(a, "-h")) {
            usage(builtin_diff_usage);
        } else {
            util.err("invalid option: {s}", .{a});
            usage(builtin_diff_usage);
        }
        rest = rest[1..];
    }
    if (revs.max_count == -1 and s.o.output_format & diff.FMT_PATCH != 0)
        revision.diffMergesSetDenseCombinedIfUnset(revs);
    _ = repo_mod.requireWorkTree("diff");
    runDiffFilesRevs(s, silent);
}
