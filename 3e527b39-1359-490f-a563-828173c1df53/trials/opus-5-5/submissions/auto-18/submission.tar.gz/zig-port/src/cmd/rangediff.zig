//! git range-diff (builtin/range-diff.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const diff = @import("../diff.zig");
const revparse = @import("../revparse.zig");
const color = @import("../color.zig");
const rd = @import("../rangediff.zig");
const gpa = util.gpa;

const usage_str =
    "usage: git range-diff [<options>] <old-base>..<old-tip> <new-base>..<new-tip>\n" ++
    "   or: git range-diff [<options>] <old-tip>...<new-tip>\n" ++
    "   or: git range-diff [<options>] <base> <old-tip> <new-tip>\n";

const opts_help =
    "\n" ++
    "    --[no-]creation-factor <n>\n" ++
    "                          percentage by which creation is weighted\n" ++
    "    --no-dual-color       use simple diff colors\n" ++
    "    --dual-color          opposite of --no-dual-color\n" ++
    "    --[no-]notes[=<notes>]\n" ++
    "                          passed to 'git log'\n" ++
    "    --[no-]diff-merges <style>\n" ++
    "                          passed to 'git log'\n" ++
    "    --[no-]max-memory <size>\n" ++
    "                          maximum memory for cost matrix (default 4G)\n" ++
    "    --[no-]remerge-diff   passed to 'git log'\n" ++
    "    --[no-]left-only      only emit output related to the first range\n" ++
    "    --[no-]right-only     only emit output related to the second range\n";

fn usageExit(to_err: bool) noreturn {
    util.flushStdout();
    if (to_err) util.eprint("{s}{s}\n", .{ usage_str, opts_help }) else {
        util.out(usage_str);
        util.out(opts_help);
        util.out("\n");
    }
    os.exit(if (to_err) 129 else 0);
}

fn usageMsg(comptime f: []const u8, args: anytype) noreturn {
    util.flushStdout();
    util.eprint("error: " ++ f ++ "\n\n", args);
    usageExit(true);
}

fn parseSize(s: []const u8) ?u64 {
    if (s.len == 0) return null;
    var end: usize = 0;
    while (end < s.len and std.ascii.isDigit(s[end])) end += 1;
    if (end == 0) return null;
    var v = std.fmt.parseInt(u64, s[0..end], 10) catch return null;
    const unit = s[end..];
    var mult: u64 = 1;
    if (unit.len == 0) {} else if (std.ascii.eqlIgnoreCase(unit, "k")) {
        mult = 1024;
    } else if (std.ascii.eqlIgnoreCase(unit, "m")) {
        mult = 1024 * 1024;
    } else if (std.ascii.eqlIgnoreCase(unit, "g")) {
        mult = 1024 * 1024 * 1024;
    } else return null;
    v = std.math.mul(u64, v, mult) catch return null;
    return v;
}

fn longArg(args: []const []const u8, i: *usize, name: []const u8) ?[]const u8 {
    const a = args[i.*];
    if (util.skipPrefix(a, "--")) |rest| {
        if (util.skipPrefix(rest, name)) |r2| {
            if (r2.len > 0 and r2[0] == '=') return r2[1..];
            if (r2.len == 0) {
                if (i.* + 1 >= args.len) {
                    util.err("option `{s}' requires a value", .{name});
                    usageExit(true);
                }
                i.* += 1;
                return args[i.*];
            }
        }
    }
    return null;
}

pub fn cmdRangeDiff(args: []const []const u8) u8 {
    if (args.len == 2 and util.eql(args[1], "-h")) usageExit(false);
    var o = diff.DiffOptions.init();
    var log_arg: std.ArrayList([]const u8) = .empty;
    var diff_merges_arg: std.ArrayList([]const u8) = .empty;
    var ro = rd.Options{};
    var simple_color: i32 = -1;
    var left_only = false;
    var right_only = false;
    var pos: std.ArrayList([]const u8) = .empty;

    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (util.eql(a, "--")) {
            pos.appendSlice(gpa, args[i..]) catch util.oom();
            break;
        }
        if (a.len < 2 or a[0] != '-') {
            pos.append(gpa, a) catch util.oom();
            continue;
        }
        if (util.eql(a, "--end-of-options")) {
            pos.appendSlice(gpa, args[i + 1 ..]) catch util.oom();
            break;
        }
        if (util.eql(a, "-h") or util.eql(a, "--help-all")) usageExit(false);
        if (util.eql(a, "--no-dual-color")) {
            simple_color = 1;
            continue;
        }
        if (util.eql(a, "--dual-color")) {
            simple_color = 0;
            continue;
        }
        if (util.eql(a, "--left-only")) {
            left_only = true;
            continue;
        }
        if (util.eql(a, "--no-left-only")) {
            left_only = false;
            continue;
        }
        if (util.eql(a, "--right-only")) {
            right_only = true;
            continue;
        }
        if (util.eql(a, "--no-right-only")) {
            right_only = false;
            continue;
        }
        if (util.eql(a, "--no-creation-factor")) {
            ro.creation_factor = 0;
            continue;
        }
        if (longArg(args, &i, "creation-factor")) |v| {
            ro.creation_factor = std.fmt.parseInt(i32, v, 10) catch {
                util.err("option `creation-factor' expects an integer value with an optional k/m/g suffix", .{});
                usageExit(true);
            };
            continue;
        }
        if (util.eql(a, "--notes") or util.eql(a, "--no-notes") or util.startsWith(a, "--notes=")) {
            log_arg.append(gpa, a) catch util.oom();
            continue;
        }
        if (util.eql(a, "--no-diff-merges")) {
            diff_merges_arg.append(gpa, a) catch util.oom();
            continue;
        }
        if (longArg(args, &i, "diff-merges")) |v| {
            diff_merges_arg.append(gpa, util.concat(&.{ "--diff-merges=", v })) catch util.oom();
            continue;
        }
        if (util.eql(a, "--remerge-diff") or util.eql(a, "--no-remerge-diff")) {
            diff_merges_arg.append(gpa, a) catch util.oom();
            continue;
        }
        if (util.eql(a, "--no-max-memory")) continue;
        if (longArg(args, &i, "max-memory")) |v| {
            ro.max_memory = parseSize(v) orelse {
                util.err("invalid max-memory value: {s}", .{v});
                os.exit(129);
            };
            continue;
        }
        const n = o.parseOpt(args, i);
        if (n == 0) {
            if (a[1] == '-') util.err("unknown option `{s}'", .{a[2..]}) else util.err("unknown switch `{c}'", .{a[1]});
            usageExit(true);
        }
        i += n - 1;
    }
    o.setupDone();

    if (simple_color == 0) o.use_color = .always;
    if (diff_merges_arg.items.len > 0) {
        ro.include_merges = true;
        log_arg.appendSlice(gpa, diff_merges_arg.items) catch util.oom();
    }

    const argv = pos.items;
    var dash_dash: i32 = -1;
    for (argv, 0..) |a, k| {
        if (util.eql(a, "--")) {
            dash_dash = @intCast(k);
            break;
        }
    }
    var range1: []const u8 = undefined;
    var range2: []const u8 = undefined;
    var rest_start: usize = 0;
    if (dash_dash == 3 or (dash_dash < 0 and argv.len > 2 and
        revparse.getOidCommittish(argv[0]) != null and
        revparse.getOidCommittish(argv[1]) != null and
        revparse.getOidCommittish(argv[2]) != null))
    {
        if (dash_dash >= 0) {
            for (argv[0..3]) |a| {
                if (revparse.getOidCommittish(a) == null) usageMsg("not a revision: '{s}'", .{a});
            }
        }
        range1 = util.fmt("{s}..{s}", .{ argv[0], argv[1] });
        range2 = util.fmt("{s}..{s}", .{ argv[0], argv[2] });
        rest_start = if (dash_dash < 0) 3 else @intCast(dash_dash);
    } else if (dash_dash == 2 or (dash_dash < 0 and argv.len > 1 and
        rd.isRangeDiffRange(argv[0]) and rd.isRangeDiffRange(argv[1])))
    {
        if (dash_dash >= 0) {
            for (argv[0..2]) |a| {
                if (!rd.isRangeDiffRange(a)) usageMsg("not a commit range: '{s}'", .{a});
            }
        }
        range1 = argv[0];
        range2 = argv[1];
        rest_start = if (dash_dash < 0) 2 else @intCast(dash_dash);
    } else if (dash_dash == 1 or (dash_dash < 0 and argv.len > 0 and std.mem.indexOf(u8, argv[0], "...") != null)) {
        const td = std.mem.indexOf(u8, argv[0], "...") orelse usageMsg("not a symmetric range: '{s}'", .{argv[0]});
        const a = if (td == 0) "HEAD" else argv[0][0..td];
        const b = if (td + 3 < argv[0].len) argv[0][td + 3 ..] else "HEAD";
        range1 = util.fmt("{s}..{s}", .{ b, a });
        range2 = util.fmt("{s}..{s}", .{ a, b });
        rest_start = if (dash_dash < 0) 1 else @intCast(dash_dash);
    } else usageMsg("need two commit ranges", .{});
    log_arg.appendSlice(gpa, argv[rest_start..]) catch util.oom();

    ro.dual_color = simple_color < 1;
    ro.left_only = left_only;
    ro.right_only = right_only;
    ro.diffopt = &o;
    ro.log_arg = log_arg.items;
    return rd.show(range1, range2, &ro);
}
