//! git hook run / list (builtin/hook.c)

const std = @import("std");
const util = @import("../util.zig");
const po = @import("../parseopt.zig");
const hook = @import("../hook.zig");

const run_usage_str = "git hook run [--allow-unknown-hook-name] [--ignore-missing] [--to-stdin=<path>] [(-j|--jobs) <n>]\n" ++
    "<hook-name> [-- <hook-args>]";
const list_usage_str = "git hook list [--allow-unknown-hook-name] [-z] [--show-scope] <hook-name>";

const all_usage = [_][]const u8{ run_usage_str, list_usage_str };
const run_usage = [_][]const u8{run_usage_str};
const list_usage = [_][]const u8{list_usage_str};

fn unknownHook(name: []const u8) u8 {
    util.err("unknown hook event '{s}';\nuse --allow-unknown-hook-name to allow non-native hook names", .{name});
    return 1;
}

fn cmdList(args: []const []const u8) u8 {
    var term: i32 = '\n';
    var show_scope = false;
    var allow_unknown = false;
    const opts = [_]po.Opt{
        po.setInt('z', "", &term, 0, "use NUL as line terminator"),
        po.boolean(0, "show-scope", &show_scope, "show the config scope that defined each hook"),
        po.boolean(0, "allow-unknown-hook-name", &allow_unknown, "allow running a hook with a non-native hook name"),
    };
    const rest = po.parse(args[1..], &opts, &list_usage, .{});
    if (rest.len != 1) {
        util.eprint("fatal: you must specify a hook event name to list\n\n", .{});
        po.usageWithOptions(&list_usage, &opts);
    }
    const name = rest[0];
    if (!allow_unknown and !hook.isKnown(name)) return unknownHook(name);
    const hooks = hook.list(name);
    if (hooks.len == 0) {
        util.warn("no hooks found for event '{s}'", .{name});
        return 1;
    }
    const t: u8 = @intCast(term);
    for (hooks) |h| {
        switch (h.kind) {
            .traditional => util.outf("{s}{c}", .{ "hook from hookdir", t }),
            .configured => {
                const dis: []const u8 = if (h.event_disabled) "event-disabled\t" else if (h.disabled) "disabled\t" else "";
                if (show_scope) {
                    util.outf("{s}\t{s}{s}{c}", .{ h.scope.name(), dis, h.name, t });
                } else util.outf("{s}{s}{c}", .{ dis, h.name, t });
            },
        }
    }
    return 0;
}

fn cmdRun(args: []const []const u8) u8 {
    var allow_unknown = false;
    var ignore_missing = false;
    var to_stdin: ?[]const u8 = null;
    var jobs: i32 = 0;
    const opts = [_]po.Opt{
        po.boolean(0, "allow-unknown-hook-name", &allow_unknown, "allow running a hook with a non-native hook name"),
        po.boolean(0, "ignore-missing", &ignore_missing, "silently ignore missing requested <hook-name>"),
        po.string(0, "to-stdin", &to_stdin, "path", "file to read into hooks' stdin"),
        po.integer('j', "jobs", &jobs, "n", "run up to <n> hooks simultaneously (-1 for CPU count)"),
    };
    const rest = po.parse(args[1..], &opts, &run_usage, .{ .keep_dashdash = true });
    var njobs: u32 = 0;
    if (jobs == -1) {
        njobs = @intCast(std.Thread.getCpuCount() catch 1);
    } else if (jobs < 0) {
        util.die("invalid value for -j: {d} (use -1 for CPU count or a positive integer)", .{jobs});
    } else njobs = @intCast(jobs);
    if (rest.len == 0) po.usageWithOptions(&run_usage, &opts);
    if (rest.len > 1 and !util.eql(rest[1], "--") and !util.eql(rest[1], "--end-of-options"))
        po.usageWithOptions(&run_usage, &opts);
    const hook_args: []const []const u8 = if (rest.len > 2) rest[2..] else &.{};
    const name = rest[0];
    if (!allow_unknown and !hook.isKnown(name)) return unknownHook(name);
    const ret = hook.runOpt(name, hook_args, .{
        .path_to_stdin = to_stdin,
        .error_if_missing = !ignore_missing,
        .jobs = njobs,
    });
    if (ret < 0) return 1;
    return @intCast(ret);
}

pub fn cmdHook(args: []const []const u8) u8 {
    const opts = [_]po.Opt{};
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&all_usage, &opts);
    }
    const sub = args[1];
    if (util.eql(sub, "-h")) po.usageExit(&all_usage, &opts, false);
    if (util.eql(sub, "run")) return cmdRun(args[1..]);
    if (util.eql(sub, "list")) return cmdList(args[1..]);
    if (sub.len > 0 and sub[0] == '-') {
        util.err("unknown option `{s}'", .{std.mem.trimStart(u8, sub, "-")});
    } else util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&all_usage, &opts);
}
