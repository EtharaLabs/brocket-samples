//! git merge-tree (port of builtin/merge-tree.c; --write-tree mode)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const repo_mod = @import("../repo.zig");
const objects = @import("../objects.zig");
const cn = @import("../commitnode.zig");
const creach = @import("../commitreach.zig");
const wt = @import("../wtstatus.zig");
const mo = @import("../merge_ort.zig");
const Oid = hash.Oid;

const usage = [_][]const u8{
    "git merge-tree [--write-tree] [<options>] <branch1> <branch2>",
    "git merge-tree [--trivial-merge] <base-tree> <branch1> <branch2>",
};

const MODE_UNKNOWN = 0;
const MODE_TRIVIAL = 1;
const MODE_REAL = 2;

var mode: i32 = MODE_UNKNOWN;
var line_termination: u8 = '\n';
var allow_unrelated = false;
var name_only = false;
var use_stdin = false;
var show_messages: i32 = -1;
var base_opts: mo.Options = .{};

fn setMode(m: i32, name: []const u8) void {
    if (mode != MODE_UNKNOWN and mode != m) {
        const other = if (mode == MODE_REAL) "--write-tree" else "--trivial-merge";
        util.err("options '--{s}' and '{s}' cannot be used together", .{ name, other });
        os.exit(129);
    }
    mode = m;
}
fn cbWrite(_: ?[]const u8, _: bool) void {
    setMode(MODE_REAL, "write-tree");
}
fn cbTrivial(_: ?[]const u8, _: bool) void {
    setMode(MODE_TRIVIAL, "trivial-merge");
}
var msgs_set = false;
var msgs_val = false;
fn cbMessages(_: ?[]const u8, unset: bool) void {
    show_messages = if (unset) 0 else 1;
}
fn cbZ(_: ?[]const u8, _: bool) void {
    line_termination = 0;
}

fn getMergeParent(name: []const u8) *cn.Commit {
    if (revparse.getOid(name)) |oid| {
        if (cn.lookupCommitReference(oid)) |c| {
            if (cn.parse(c)) return c;
        }
    }
    util.die("merge-tree: {s} - not something we can merge", .{name});
}

fn treeOf(name: []const u8) Oid {
    const oid = revparse.getTreeish(name) orelse util.die("could not parse as tree '{s}'", .{name});
    return objects.peelTo(oid, .tree) orelse util.die("unable to read tree ({s})", .{hash.hex(oid)});
}

fn writeName(name: []const u8, prefix: []const u8) void {
    const rel = if (prefix.len > 0) wt.relativePathC(name, prefix) else name;
    if (line_termination != 0) util.out(util.cquote(rel)) else util.out(rel);
    util.stdout.byte(line_termination);
}

fn realMerge(merge_base: ?[]const u8, branch1: []const u8, branch2: []const u8, prefix: []const u8) i32 {
    var opt = base_opts;
    opt.show_rename_progress = false;
    opt.branch1 = branch1;
    opt.branch2 = branch2;
    var result = mo.Result{};
    if (merge_base) |mb| {
        const base_tree = treeOf(mb);
        const t1 = treeOf(branch1);
        const t2 = treeOf(branch2);
        opt.ancestor = mb;
        mo.mergeIncoreNonrecursive(&opt, base_tree, t1, t2, &result);
    } else {
        const p1 = getMergeParent(branch1);
        const p2 = getMergeParent(branch2);
        const bases = creach.getMergeBases(p1, p2);
        if (bases == null and !allow_unrelated) util.die("refusing to merge unrelated histories", .{});
        mo.mergeIncoreRecursive(&opt, cn.listReverse(bases), p1, p2, &result);
    }
    if (result.clean < 0) util.die("failure to merge", .{});
    if (opt.mergeability_only) return if (result.clean != 0) 0 else 1;
    var show = show_messages;
    if (show == -1) show = if (result.clean != 0) 0 else 1;
    if (use_stdin) util.outf("{d}{c}", .{ result.clean, line_termination });
    util.outf("{s}{c}", .{ hash.hex(result.tree), line_termination });
    if (result.clean == 0) {
        const files = mo.getConflictedFiles(&result);
        var last: ?[]const u8 = null;
        for (files) |c| {
            if (!name_only) {
                util.outf("{o:0>6} {s} {d}\t", .{ c.mode, hash.hex(c.oid), c.stage });
            } else if (last != null and util.eql(last.?, c.path)) continue;
            writeName(c.path, prefix);
            last = c.path;
        }
    }
    if (show != 0) {
        util.stdout.byte(line_termination);
        mo.displayUpdateMessages(&opt, line_termination == 0, &result);
    }
    if (use_stdin) util.stdout.byte(line_termination);
    return if (result.clean != 0) 0 else 1;
}

pub fn cmdMergeTree(args: []const []const u8) u8 {
    var quiet = false;
    var merge_base: ?[]const u8 = null;
    var xopts: std.ArrayList([]const u8) = .empty;
    const opts = [_]po.Opt{
        .{ .long = "write-tree", .kind = .callback, .cb = cbWrite, .noarg = true, .noneg = true, .help = "do a real merge instead of a trivial merge" },
        .{ .long = "trivial-merge", .kind = .callback, .cb = cbTrivial, .noarg = true, .noneg = true, .help = "do a trivial merge only" },
        .{ .long = "messages", .kind = .callback, .cb = cbMessages, .noarg = true, .help = "also show informational/conflict messages" },
        .{ .long = "quiet", .kind = .boolean, .b = &quiet, .noneg = true, .help = "suppress all output; only exit status wanted" },
        .{ .short = 'z', .kind = .callback, .cb = cbZ, .noarg = true, .noneg = true, .help = "separate paths with the NUL character" },
        .{ .long = "name-only", .kind = .boolean, .b = &name_only, .noneg = true, .help = "list filenames without modes/oids/stages" },
        .{ .long = "allow-unrelated-histories", .kind = .boolean, .b = &allow_unrelated, .noneg = true, .help = "allow merging unrelated histories" },
        .{ .long = "stdin", .kind = .boolean, .b = &use_stdin, .noneg = true, .help = "perform multiple merges, one per line of input" },
        po.string(0, "merge-base", &merge_base, "tree-ish", "specify a merge-base for the merge"),
        po.list('X', "strategy-option", &xopts, "option=value", "option for selected merge strategy"),
    };
    var original_argc = args.len - 1;
    const rest = po.parse(args[1..], &opts, &usage, .{ .stop_at_non_option = true });

    if (quiet and show_messages == -1) show_messages = 0;
    base_opts.mergeability_only = quiet;
    if (quiet and show_messages > 0) po.dieExclusive("--quiet", "--messages");
    if (quiet and name_only) po.dieExclusive("--quiet", "--name-only");
    if (quiet and use_stdin) po.dieExclusive("--quiet", "--stdin");
    if (quiet and line_termination == 0) po.dieExclusive("--quiet", "-z");

    if (xopts.items.len > 0 and mode == MODE_TRIVIAL) util.die("--trivial-merge is incompatible with all other options", .{});
    for (xopts.items) |x| {
        if (!mo.parseMergeOpt(&base_opts, x)) util.die("unknown strategy option: -X{s}", .{x});
    }
    const prefix: []const u8 = repo_mod.repo().prefix;

    if (use_stdin) {
        if (mode == MODE_TRIVIAL) util.die("--trivial-merge is incompatible with all other options", .{});
        if (merge_base != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--merge-base", "--stdin" });
        line_termination = 0;
        const input = os.readAllFd(0) catch "";
        var it = std.mem.splitScalar(u8, input, '\n');
        while (it.next()) |line0| {
            if (it.index == null and line0.len == 0) break;
            var split: std.ArrayList([]const u8) = .empty;
            var sp = std.mem.splitScalar(u8, line0, ' ');
            while (sp.next()) |w| split.append(util.gpa, std.mem.trim(u8, w, " ")) catch util.oom();
            if (split.items.len < 2) util.die("malformed input line: '{s}'.", .{line0});
            const imb: ?[]const u8 = if (util.eql(split.items[1], "--")) split.items[0] else null;
            if (imb != null and split.items.len == 4) {
                _ = realMerge(imb, split.items[2], split.items[3], prefix);
            } else if (imb == null and split.items.len == 2) {
                _ = realMerge(null, split.items[0], split.items[1], prefix);
            } else util.die("malformed input line: '{s}'.", .{line0});
            util.flushStdout();
        }
        return 0;
    }

    var expected: usize = 0;
    switch (mode) {
        MODE_UNKNOWN => {
            switch (rest.len) {
                2 => mode = MODE_REAL,
                3 => mode = MODE_TRIVIAL,
                else => po.usageWithOptions(&usage, &opts),
            }
            expected = rest.len;
        },
        MODE_REAL => expected = 2,
        else => {
            expected = 3;
            original_argc -= 1;
        },
    }
    if (mode == MODE_TRIVIAL and rest.len < original_argc) util.die("--trivial-merge is incompatible with all other options", .{});
    if (rest.len != expected) po.usageWithOptions(&usage, &opts);

    if (mode == MODE_REAL) {
        const r = realMerge(merge_base, rest[0], rest[1], prefix);
        return @intCast(r);
    }
    return trivialMerge(rest[0], rest[1], rest[2]);
}

// ---------------------------------------------------------------------------
// trivial merge (legacy mode)

const ML = struct {
    next: ?*ML = null,
    link: ?*ML = null,
    stage: u2,
    mode: u32,
    path: []const u8,
    oid: Oid,
};
var merge_result: std.ArrayList(*ML) = .empty;

fn createEntry(stage: u2, m: u32, oid: Oid, path: []const u8) *ML {
    const r = util.gpa.create(ML) catch util.oom();
    r.* = .{ .stage = stage, .mode = m, .oid = oid, .path = path };
    return r;
}

const NE = struct { mode: u32 = 0, oid: Oid = hash.zero, name: []const u8 = "" };

fn isDir(m: u32) bool {
    return m & os.S_IFMT == os.S_IFDIR;
}
fn sameEntry(a: NE, b: NE) bool {
    return !hash.eql(a.oid, hash.zero) and !hash.eql(b.oid, hash.zero) and hash.eql(a.oid, b.oid) and a.mode == b.mode;
}
fn bothEmpty(a: NE, b: NE) bool {
    return hash.eql(a.oid, hash.zero) and hash.eql(b.oid, hash.zero);
}
fn tpath(base: []const u8, n: NE) []const u8 {
    return if (base.len == 0) n.name else util.concat(&.{ base, "/", n.name });
}
fn resolveT(base: []const u8, ours: ?NE, res: NE) void {
    const o = ours orelse return;
    const path = tpath(base, res);
    const orig = createEntry(2, o.mode, o.oid, path);
    const fin = createEntry(0, res.mode, res.oid, path);
    fin.link = orig;
    merge_result.append(util.gpa, fin) catch util.oom();
}
fn linkEntry(stage: u2, base: []const u8, n: NE, entry: ?*ML) ?*ML {
    if (n.mode == 0) return entry;
    const path = if (entry) |e| e.path else tpath(base, n);
    const l = createEntry(stage, n.mode, n.oid, path);
    l.link = entry;
    return l;
}
fn unresolved(base: []const u8, n: [3]NE) void {
    var dirmask: u32 = 0;
    for (0..3) |i| {
        if (n[i].mode == 0 or isDir(n[i].mode)) dirmask |= @as(u32, 1) << @intCast(i);
    }
    // unresolved_directory
    var p: ?usize = null;
    for (0..3) |i| {
        if (n[i].mode != 0 and isDir(n[i].mode)) {
            p = i;
            break;
        }
    }
    if (p) |pi| {
        const nb = tpath(base, n[pi]);
        var t: [3]?Oid = undefined;
        for (0..3) |i| t[i] = if (n[i].mode != 0 and isDir(n[i].mode)) n[i].oid else null;
        trivialMergeTrees(t, nb);
    }
    if (dirmask == 7) return;
    var entry: ?*ML = null;
    if (n[2].mode != 0 and !isDir(n[2].mode)) entry = linkEntry(3, base, n[2], entry);
    if (n[1].mode != 0 and !isDir(n[1].mode)) entry = linkEntry(2, base, n[1], entry);
    if (n[0].mode != 0 and !isDir(n[0].mode)) entry = linkEntry(1, base, n[0], entry);
    merge_result.append(util.gpa, entry.?) catch util.oom();
}

fn threeway(base: []const u8, e: [3]NE) void {
    if (sameEntry(e[1], e[2]) or bothEmpty(e[1], e[2])) return;
    if (sameEntry(e[0], e[1])) {
        if (!hash.eql(e[2].oid, hash.zero) and !isDir(e[2].mode)) {
            resolveT(base, e[1], e[2]);
            return;
        }
    }
    if (sameEntry(e[0], e[2]) or bothEmpty(e[0], e[2])) return;
    unresolved(base, e);
}

fn trivialMergeTrees(t: [3]?Oid, base: []const u8) void {
    var ents: [3][]const objects.TreeEntry = undefined;
    for (0..3) |i| ents[i] = if (t[i]) |o| (objects.readTree(o) orelse &.{}) else &.{};
    var idx: [3]usize = .{ 0, 0, 0 };
    while (true) {
        // find the smallest name (traverse_trees ordering: dirs compare as name + '/')
        var first: ?objects.TreeEntry = null;
        for (0..3) |i| {
            if (idx[i] >= ents[i].len) continue;
            const e = ents[i][idx[i]];
            if (first == null or objects.baseNameCompare(e.name, e.mode, first.?.name, first.?.mode) == .lt or
                (std.mem.eql(u8, e.name, first.?.name) and false))
            {
                first = e;
            }
        }
        const f = first orelse break;
        var n: [3]NE = .{ .{}, .{}, .{} };
        for (0..3) |i| {
            if (idx[i] >= ents[i].len) continue;
            const e = ents[i][idx[i]];
            if (util.eql(e.name, f.name)) {
                n[i] = .{ .mode = e.mode, .oid = e.oid, .name = e.name };
                idx[i] += 1;
            }
        }
        for (0..3) |i| {
            if (n[i].mode == 0) n[i].name = f.name;
        }
        threeway(base, n);
    }
}

fn explanation(e0: *ML) []const u8 {
    switch (e0.stage) {
        0 => return "merged",
        3 => return "added in remote",
        2 => return if (e0.link != null) "added in both" else "added in local",
        else => {},
    }
    const e = e0.link orelse return "removed in both";
    if (e.link != null) return "changed in both";
    if (e.stage == 3) return "removed in local";
    return "removed in remote";
}

fn readBlob(oid: Oid) []const u8 {
    const o = repo_mod.repo().odb().read(oid) orelse return "";
    return o.data;
}

fn resultOf(entry0: *ML) []const u8 {
    if (entry0.stage == 0) return readBlob(entry0.oid);
    var entry: ?*ML = entry0;
    var base: ?Oid = null;
    if (entry.?.stage == 1) {
        base = entry.?.oid;
        entry = entry.?.link;
    }
    var our: ?Oid = null;
    if (entry != null and entry.?.stage == 2) {
        our = entry.?.oid;
        entry = entry.?.link;
    }
    var their: ?Oid = null;
    if (entry) |e| their = e.oid;
    // merge_blobs()
    if (our == null or their == null) {
        if (base != null) return "";
        return readBlob(our orelse their.?);
    }
    const b = if (base) |bo| readBlob(bo) else "";
    const lo = mo.LlOpts{};
    const r = mo.llMerge(entry0.path, b, null, readBlob(our.?), ".our", readBlob(their.?), ".their", &lo);
    if (r.status == .binary_conflict) util.warn("Cannot merge binary files: {s} ({s} vs. {s})", .{ entry0.path, ".our", ".their" });
    return r.result orelse "";
}

fn origin(entry0: *ML) []const u8 {
    var e: ?*ML = entry0;
    while (e) |x| {
        if (x.stage == 2) return readBlob(x.oid);
        e = x.link;
    }
    return "";
}

fn trivialMerge(base: []const u8, b1: []const u8, b2: []const u8) u8 {
    var t: [3]?Oid = undefined;
    for ([_][]const u8{ base, b1, b2 }, 0..) |rev, i| {
        const oid = revparse.getOid(rev) orelse util.die("unknown rev {s}", .{rev});
        t[i] = objects.peelTo(oid, .tree) orelse util.die("{s} is not a tree", .{rev});
    }
    trivialMergeTrees(t, "");
    const xdiff = @import("../xdiff.zig");
    const desc = [4][]const u8{ "result", "base", "our", "their" };
    for (merge_result.items) |walk| {
        util.outf("{s}\n", .{explanation(walk)});
        var e: ?*ML = walk;
        while (e) |x| {
            util.outf("  {s: <6} {o} {s} {s}\n", .{ desc[x.stage], x.mode, hash.hex(x.oid), x.path });
            e = x.link;
        }
        const src = origin(walk);
        const dst = resultOf(walk);
        const d = xdiff.unifiedDiff(src, dst, .{ .algorithm = .myers, .indent_heuristic = false }, .{ .context = 3, .funcnames = false }) catch util.die("unable to generate diff", .{});
        util.out(d);
    }
    return 0;
}
