//! git rm

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const dir_mod = @import("../dir.zig");
const advice = @import("../advice.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const sparse = @import("../sparse.zig");
const config = @import("../config.zig");
const wtstatus = @import("../wtstatus.zig");
const add_cmd = @import("add.zig");
const proc = @import("../proc.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git rm [-f | --force] [-n] [-r] [--cached] [--ignore-unmatch]\n" ++
        "       [--quiet] [--pathspec-from-file=<file> [--pathspec-file-nul]]\n" ++
        "       [--] [<pathspec>...]",
};

var show_only = false;
var force: i32 = 0;
var index_only = false;
var recursive = false;
var quiet: i32 = 0;
var ignore_unmatch = false;
var include_sparse = false;
var pathspec_from_file: ?[]const u8 = null;
var pathspec_file_nul = false;

const options = [_]po.Opt{
    po.boolean('n', "dry-run", &show_only, "dry run"),
    .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet, .help = "do not list removed files" },
    po.boolean(0, "cached", &index_only, "only remove from the index"),
    po.counter('f', "force", &force, "override the up-to-date check"),
    po.boolean('r', "", &recursive, "allow recursive removal"),
    po.boolean(0, "ignore-unmatch", &ignore_unmatch, "exit with a zero status even if nothing matched"),
    po.boolean(0, "sparse", &include_sparse, "allow updating entries outside of the sparse-checkout cone"),
    po.filename(0, "pathspec-from-file", &pathspec_from_file, "file", "read pathspec from file"),
    po.boolean(0, "pathspec-file-nul", &pathspec_file_nul, "with --pathspec-from-file, pathspec elements are separated with NUL character"),
};

const Item = struct { name: []const u8, is_submodule: bool };

fn oursPos(idx: *index_mod.Index, path: []const u8) ?usize {
    var p = idx.firstPos(path);
    while (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, path)) : (p += 1) {
        if (idx.entries.items[p].stage() == 2) return p;
    }
    return null;
}

fn printErrorFiles(files: []const []const u8, main_msg: []const u8, hints: []const u8, errs: *bool) void {
    if (files.len == 0) return;
    var b: util.Buf = .empty;
    util.bufAppend(&b, main_msg);
    for (files) |f| util.bufPrint(&b, "\n    {s}", .{f});
    if (advice.enabled("rmHints")) util.bufAppend(&b, hints);
    util.err("{s}", .{b.items});
    errs.* = true;
}

fn checkLocalMod(idx: *index_mod.Index, head_tree: ?hash.Oid, list: []const Item) bool {
    var staged: std.ArrayList([]const u8) = .empty;
    var cached: std.ArrayList([]const u8) = .empty;
    var local: std.ArrayList([]const u8) = .empty;
    for (list) |item| {
        const name = item.name;
        const pos = idx.findPos(name) orelse blk: {
            const p = oursPos(idx, name) orelse continue;
            if (idx.entries.items[p].mode != 0o160000 or dir_mod.isEmptyDir(name)) continue;
            break :blk p;
        };
        const ce = &idx.entries.items[pos];
        const st = os.lstatPath(ce.path) orelse continue;
        if (st.isDir() and ce.mode != 0o160000) continue;
        const local_changes = idx.matchStat(ce, st, false) != 0 or
            (ce.mode == 0o160000 and badToRemoveSubmodule(ce.path));
        var staged_changes = true;
        if (head_tree) |t| {
            if (objects.treeLookup(t, name)) |te| {
                if (te.mode == ce.mode and hash.eql(te.oid, ce.oid)) staged_changes = false;
            }
        }
        if (local_changes and staged_changes) {
            if (!index_only or !ce.intentToAdd()) staged.append(gpa, name) catch util.oom();
        } else if (!index_only) {
            if (staged_changes) cached.append(gpa, name) catch util.oom();
            if (local_changes) local.append(gpa, name) catch util.oom();
        }
    }
    var errs = false;
    printErrorFiles(staged.items, if (staged.items.len == 1)
        "the following file has staged content different from both the\nfile and the HEAD:"
    else
        "the following files have staged content different from both the\nfile and the HEAD:", "\n(use -f to force removal)", &errs);
    printErrorFiles(cached.items, if (cached.items.len == 1)
        "the following file has changes staged in the index:"
    else
        "the following files have changes staged in the index:", "\n(use --cached to keep the file, or -f to force removal)", &errs);
    printErrorFiles(local.items, if (local.items.len == 1)
        "the following file has local modifications:"
    else
        "the following files have local modifications:", "\n(use --cached to keep the file, or -f to force removal)", &errs);
    return errs;
}

pub fn cmdRm(args: []const []const u8) u8 {
    const rest = po.parse(args[1..], &options, &usage, .{});
    const r = repo_mod.repo();
    const ps_flags = pathspec_mod.Flags{ .prefer_cwd = true };
    var ps = pathspec_mod.parse(r.prefix, rest, ps_flags);
    if (pathspec_from_file) |pf| {
        if (ps.items.len > 0) util.die("'{s}' and pathspec arguments cannot be used together", .{"--pathspec-from-file"});
        ps = pathspec_mod.parse(r.prefix, pathspec_mod.readPathspecFile(pf, pathspec_file_nul), ps_flags);
    } else if (pathspec_file_nul) {
        util.die("the option '{s}' requires '{s}'", .{ "--pathspec-file-nul", "--pathspec-from-file" });
    }
    if (ps.items.len == 0) util.die("No pathspec was given. Which files should I remove?", .{});
    if (!index_only) _ = repo_mod.requireWorkTree("rm");

    const idx = index_mod.lockAndRead();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET | index_mod.REFRESH_UNMERGED, @as(?*const pathspec_mod.Pathspec, &ps), null);
    const seen = ps.newSeen();
    var list: std.ArrayList(Item) = .empty;
    for (idx.entries.items) |*e| {
        if (!include_sparse and (e.skipWorktree() or !sparse.pathInSparseCheckout(e.path))) continue;
        if (ps.matchSeen(e.path, e.mode == 0o160000, seen) == 0) continue;
        list.append(gpa, .{ .name = e.path, .is_submodule = e.mode == 0o160000 }) catch util.oom();
        if (e.mode == 0o160000 and !isStagingGitmodulesOk(idx))
            util.die("please stage your changes to .gitmodules or stash them to proceed", .{});
    }
    var ret: u8 = 0;
    {
        var seen_any = false;
        var sw_seen: ?[]u8 = null;
        var only_sw: std.ArrayList([]const u8) = .empty;
        for (ps.items, 0..) |it, i| {
            const original = it.original;
            if (seen[i] != 0) {
                seen_any = true;
            } else if (ignore_unmatch) {
                continue;
            } else if (!include_sparse and (sw_seen orelse blk: {
                sw_seen = add_cmd.skipWorktreeSeen(idx, &ps);
                break :blk sw_seen.?;
            })[i] != 0) {
                only_sw.append(gpa, original) catch util.oom();
            } else {
                util.die("pathspec '{s}' did not match any files", .{original});
            }
            if (!recursive and seen[i] == pathspec_mod.MATCHED_RECURSIVELY)
                util.die("not removing '{s}' recursively without -r", .{if (original.len > 0) original else "."});
        }
        if (only_sw.items.len > 0) {
            add_cmd.adviseOnUpdatingSparsePaths(only_sw.items);
            ret = 1;
        }
        if (!seen_any) {
            idx.rollback();
            os.exit(ret);
        }
    }
    if (!index_only) absorbGitdirsIfNeeded(idx, list.items);

    if (force == 0) {
        var head_tree: ?hash.Oid = null;
        if (revparse.getCommit("HEAD")) |h| {
            if (objects.readCommit(h)) |c| head_tree = c.tree;
        }
        if (checkLocalMod(idx, head_tree, list.items)) {
            idx.rollback();
            os.exit(1);
        }
    }
    for (list.items) |item| {
        if (quiet == 0) util.outf("rm '{s}'\n", .{item.name});
        _ = idx.removePath(item.name);
        idx.invalidatePath(item.name);
        idx.changed = true;
    }
    if (show_only) {
        idx.rollback();
        return 0;
    }
    if (!index_only) {
        var removed = false;
        var gitmodules_modified = false;
        for (list.items) |item| {
            if (item.is_submodule) {
                if (os.lstatPath(item.name)) |st| {
                    if (st.isDir()) os.removeTree(item.name);
                    if (os.lstatPath(item.name) != null) util.die("could not remove '{s}'", .{item.name});
                }
                removed = true;
                if (removePathFromGitmodules(idx, item.name)) gitmodules_modified = true;
                continue;
            }
            if (index_mod.removeWorktreePath(item.name)) {
                removed = true;
                continue;
            }
            if (!removed) util.dieErrno("git rm: '{s}'", .{item.name});
        }
        if (gitmodules_modified) stageUpdatedGitmodules(idx);
    }
    if (idx.changed) idx.write() else idx.rollback();
    return ret;
}

// ---------------------------------------------------------------------------
// Minimal .gitmodules helpers (submodule.c), shared with mv.

fn gitmodulesUnmerged(idx: *index_mod.Index) bool {
    var p = idx.firstPos(".gitmodules");
    while (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, ".gitmodules")) : (p += 1) {
        if (idx.entries.items[p].stage() != 0) return true;
    }
    return false;
}

/// is_staging_gitmodules_ok()
pub fn isStagingGitmodulesOk(idx: *index_mod.Index) bool {
    const pos = idx.findPos(".gitmodules") orelse return true;
    const st = os.lstatPath(".gitmodules") orelse return true;
    return !idx.modified(&idx.entries.items[pos], st);
}

/// submodule_from_path(null_oid, path)->name, reading the worktree .gitmodules.
fn submoduleNameForPath(path: []const u8) ?[]const u8 {
    var c: config.Config = .{};
    _ = config.readFileInto(&c, ".gitmodules", .local);
    var name: ?[]const u8 = null;
    for (c.entries.items) |e| {
        if (!std.mem.startsWith(u8, e.key, "submodule.") or !std.mem.endsWith(u8, e.key, ".path")) continue;
        if (e.key.len <= "submodule.".len + ".path".len) continue;
        const v = e.value orelse continue;
        if (util.eql(v, path)) name = e.key["submodule.".len .. e.key.len - ".path".len];
    }
    return name;
}

/// remove_path_from_gitmodules(); returns true on success (C returns 0).
pub fn removePathFromGitmodules(idx: *index_mod.Index, path: []const u8) bool {
    if (os.lstatPath(".gitmodules") == null) return false;
    if (gitmodulesUnmerged(idx)) util.die("Cannot change unmerged .gitmodules, resolve merge conflicts first", .{});
    const name = submoduleNameForPath(path) orelse {
        util.warn("Could not find section in .gitmodules where path={s}", .{path});
        return false;
    };
    if (config.renameSection(".gitmodules", util.concat(&.{ "submodule.", name }), null) < 0) {
        util.warn("Could not remove .gitmodules entry for {s}", .{path});
        return false;
    }
    return true;
}

/// update_path_in_gitmodules(); returns true on success (C returns 0).
pub fn updatePathInGitmodules(idx: *index_mod.Index, oldpath: []const u8, newpath: []const u8) bool {
    if (os.lstatPath(".gitmodules") == null) return false;
    if (gitmodulesUnmerged(idx)) util.die("Cannot change unmerged .gitmodules, resolve merge conflicts first", .{});
    const name = submoduleNameForPath(oldpath) orelse {
        util.warn("Could not find section in .gitmodules where path={s}", .{oldpath});
        return false;
    };
    const key = util.concat(&.{ "submodule.", name, ".path" });
    if (config.setInFileGently(".gitmodules", key, null, newpath) < 0) {
        util.warn("Could not update .gitmodules entry {s}", .{key});
        return false;
    }
    return true;
}

/// stage_updated_gitmodules()
pub fn stageUpdatedGitmodules(idx: *index_mod.Index) void {
    if (index_mod.addFileToIndex(idx, ".gitmodules", 0)) util.die("staging updated .gitmodules failed", .{});
    idx.changed = true;
}

/// connect_work_tree_and_git_dir()
pub fn connectWorkTreeAndGitDir(wt_in: []const u8, gd_in: []const u8) void {
    const gitfile = util.concat(&.{ wt_in, "/.git" });
    if (!os.mkdirLeading(gitfile)) util.die("could not create directories for {s}", .{gitfile});
    const cfg_file = util.concat(&.{ gd_in, "/config" });
    if (!os.mkdirLeading(cfg_file)) util.die("could not create directories for {s}", .{cfg_file});
    const gd = repo_mod.realPathDup(gd_in, true) orelse gd_in;
    const wt = repo_mod.realPathDup(wt_in, true) orelse wt_in;
    os.writeFile(gitfile, util.concat(&.{ "gitdir: ", wtstatus.relativePathC(gd, wt), "\n" }), 0o666) catch
        util.dieErrno("could not write to '{s}'", .{gitfile});
    const rel = wtstatus.relativePathC(wt, gd);
    if (config.setInFileGently(cfg_file, "core.worktree", null, rel) < 0)
        util.die("could not set 'core.worktree' to '{s}'", .{rel});
}

const sub_env_unset = [_][]const u8{
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CONFIG",    "GIT_OBJECT_DIRECTORY",
    "GIT_DIR",                          "GIT_WORK_TREE", "GIT_IMPLICIT_WORK_TREE",
    "GIT_GRAFT_FILE",                   "GIT_INDEX_FILE", "GIT_NO_REPLACE_OBJECTS",
    "GIT_REPLACE_REF_BASE",             "GIT_PREFIX",    "GIT_SHALLOW_FILE",
    "GIT_COMMON_DIR",
};

fn submoduleUsesGitfile(path: []const u8) bool {
    return repo_mod.readGitfile(util.concat(&.{ path, "/.git" })) != null;
}

/// bad_to_remove_submodule(path, SUBMODULE_REMOVAL_DIE_ON_ERROR |
/// SUBMODULE_REMOVAL_IGNORE_IGNORED_UNTRACKED)
fn badToRemoveSubmodule(path: []const u8) bool {
    if (!os.exists(path) or dir_mod.isEmptyDir(path)) return false;
    if (!submoduleUsesGitfile(path)) return true;
    const res = os.run(&.{ proc.gitBinary(), "status", "--porcelain", "--ignore-submodules=none", "-uall" }, .{
        .capture_stdout = true,
        .no_stdin = true,
        .cwd = path,
        .env = &.{.{ "GIT_DIR", ".git" }},
        .unset_env = &sub_env_unset,
    });
    if (res.signaled or res.status != 0) util.die("could not run 'git status' in submodule '{s}'", .{path});
    return res.stdout.len > 2;
}

/// submodules_absorb_gitdir_if_needed()
fn absorbGitdirsIfNeeded(idx: *index_mod.Index, list: []const Item) void {
    for (list) |item| {
        const name = item.name;
        const pos = idx.findPos(name) orelse (oursPos(idx, name) orelse continue);
        const ce = &idx.entries.items[pos];
        if (ce.mode != 0o160000 or !os.exists(name) or dir_mod.isEmptyDir(name)) continue;
        if (submoduleUsesGitfile(name)) continue;
        const res = os.run(&.{ proc.gitBinary(), "submodule--helper", "absorbgitdirs", "--", util.concat(&.{ ":(literal)", name }) }, .{ .no_stdin = true });
        if (res.signaled or res.status != 0) os.exit(if (res.signaled) 128 else res.status);
    }
}
