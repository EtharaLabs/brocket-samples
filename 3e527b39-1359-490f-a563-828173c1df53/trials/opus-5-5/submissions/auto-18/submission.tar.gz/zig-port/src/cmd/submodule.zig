//! git submodule (git-submodule.sh) and git submodule--helper
//! (builtin/submodule--helper.c, submodule.c, submodule-config.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const config = @import("../config.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const pathspec_mod = @import("../pathspec.zig");
const wildmatch = @import("../wildmatch.zig");
const wtstatus = @import("../wtstatus.zig");
const proc = @import("../proc.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const StrList = std.ArrayList([]const u8);

const GITLINK: u32 = 0o160000;

fn isGitlink(mode: u32) bool {
    return mode & 0o170000 == GITLINK;
}

// ---------------------------------------------------------------------------
// subprocesses

const sub_env_unset = [_][]const u8{
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CONFIG",             "GIT_OBJECT_DIRECTORY",
    "GIT_DIR",                          "GIT_WORK_TREE",          "GIT_IMPLICIT_WORK_TREE",
    "GIT_GRAFT_FILE",                   "GIT_INDEX_FILE",         "GIT_NO_REPLACE_OBJECTS",
    "GIT_REPLACE_REF_BASE",             "GIT_PREFIX",             "GIT_SHALLOW_FILE",
    "GIT_COMMON_DIR",
};

const RunOpts = struct {
    cwd: ?[]const u8 = null,
    /// prepare_submodule_repo_env()
    sub_env: bool = true,
    /// set GIT_DIR=.git (part of prepare_submodule_repo_env)
    set_git_dir: bool = true,
    capture: bool = false,
    no_stderr: bool = false,
    no_stdin: bool = false,
    stdout_to_stderr: bool = false,
    extra_env: []const [2][]const u8 = &.{},
    shell: bool = false,
};

fn runCmd(args: []const []const u8, o: RunOpts, git_cmd: bool) os.ChildResult {
    var argv: StrList = .empty;
    if (git_cmd) argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    var env: std.ArrayList([2][]const u8) = .empty;
    if (o.sub_env and o.set_git_dir) env.append(gpa, .{ "GIT_DIR", ".git" }) catch util.oom();
    env.appendSlice(gpa, o.extra_env) catch util.oom();
    return os.run(argv.items, .{
        .capture_stdout = o.capture,
        .no_stderr = o.no_stderr,
        .no_stdin = o.no_stdin,
        .stdout_to_stderr = o.stdout_to_stderr,
        .cwd = o.cwd,
        .env = env.items,
        .unset_env = if (o.sub_env) &sub_env_unset else &.{},
        .use_shell = o.shell,
    });
}

fn git(args: []const []const u8, o: RunOpts) os.ChildResult {
    return runCmd(args, o, true);
}

fn ok(r: os.ChildResult) bool {
    return r.status == 0 and !r.signaled;
}

fn code(r: os.ChildResult) u8 {
    if (r.signaled) return r.status;
    return r.status;
}

/// die_message(): print "fatal: ..." and return 128
fn dieMessage(comptime f: []const u8, args: anytype) u8 {
    util.eprint("fatal: " ++ f ++ "\n", args);
    return 128;
}

fn firstLine(s: []const u8) []const u8 {
    const e = std.mem.indexOfScalar(u8, s, '\n') orelse s.len;
    return s[0..e];
}

fn stripNl(s: []const u8) []const u8 {
    var e = s.len;
    if (e > 0 and s[e - 1] == '\n') e -= 1;
    return s[0..e];
}

// ---------------------------------------------------------------------------
// small path helpers

fn isAbs(p: []const u8) bool {
    return p.len > 0 and p[0] == '/';
}

fn absolutePath(p: []const u8) []const u8 {
    if (isAbs(p)) return p;
    return util.concat(&.{ os.getcwd(), "/", p });
}

fn realPath(p: []const u8) []const u8 {
    return repo_mod.realPathDup(p, true) orelse p;
}

fn relativePath(in: []const u8, prefix: []const u8) []const u8 {
    return wtstatus.relativePathC(in, prefix);
}

fn displayPath(path: []const u8, prefix: []const u8, super_prefix: ?[]const u8) []const u8 {
    if (prefix.len > 0) return util.dupe(relativePath(path, prefix));
    if (super_prefix) |sp| return util.concat(&.{ sp, path });
    return path;
}

fn countSlashes(s: []const u8) usize {
    var n: usize = 0;
    for (s) |ch| {
        if (ch == '/') n += 1;
    }
    return n;
}

fn getUpPath(path: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (i < countSlashes(path)) : (i += 1) util.bufAppend(&b, "../");
    if (path.len == 0 or path[path.len - 1] != '/') util.bufAppend(&b, "../");
    return b.items;
}

fn isEmptyDir(path: []const u8) bool {
    const ents = os.listDir(path) orelse return true;
    for (ents) |e| {
        if (util.eql(e.name, ".") or util.eql(e.name, "..")) continue;
        return false;
    }
    return true;
}

/// validate_submodule_path(): no symlinks along the path
fn validateSubmodulePath(path: []const u8) bool {
    var i: usize = 0;
    while (i < path.len) : (i += 1) {
        if (path[i] != '/') continue;
        if (os.lstatPath(path[0..i])) |st| {
            if (st.isLnk()) {
                util.err("expected '{s}' in submodule path '{s}' not to be a symbolic link", .{ path[0..i], path[0..i] });
                return false;
            }
        }
    }
    if (os.lstatPath(path)) |st| {
        if (st.isLnk()) {
            util.err("expected submodule path '{s}' not to be a symbolic link", .{path});
            return false;
        }
    }
    return true;
}

fn validatePathOrExit(path: []const u8) void {
    if (!validateSubmodulePath(path)) os.exit(128);
}

// ---------------------------------------------------------------------------
// URL helpers

fn startsWithDotSlash(s: []const u8) bool {
    return s.len >= 2 and s[0] == '.' and (s[1] == '/' or s[1] == '\\');
}

fn startsWithDotDotSlash(s: []const u8) bool {
    return s.len >= 3 and s[0] == '.' and s[1] == '.' and (s[2] == '/' or s[2] == '\\');
}

fn startsWithDotSlashNative(s: []const u8) bool {
    return s.len >= 2 and s[0] == '.' and s[1] == '/';
}

fn startsWithDotDotSlashNative(s: []const u8) bool {
    return s.len >= 3 and s[0] == '.' and s[1] == '.' and s[2] == '/';
}

fn isRelativeUrl(s: []const u8) bool {
    return startsWithDotSlash(s) or startsWithDotDotSlash(s);
}

fn urlIsLocalNotSsh(url: []const u8) bool {
    const colon = std.mem.indexOfScalar(u8, url, ':') orelse return true;
    if (std.mem.indexOfScalar(u8, url, '/')) |slash| return slash < colon;
    return false;
}

/// relative_url() (remote.c)
pub fn relativeUrl(remote_url: []const u8, url_in: []const u8, up_path: ?[]const u8) []const u8 {
    if (!urlIsLocalNotSsh(url_in) or isAbs(url_in)) return url_in;
    var remoteurl: []const u8 = remote_url;
    if (remoteurl.len > 0 and remoteurl[remoteurl.len - 1] == '/') remoteurl = remoteurl[0 .. remoteurl.len - 1];
    var is_relative = false;
    if (!urlIsLocalNotSsh(remoteurl) or isAbs(remoteurl)) {
        is_relative = false;
    } else {
        is_relative = true;
        if (!startsWithDotSlashNative(remoteurl) and !startsWithDotDotSlashNative(remoteurl))
            remoteurl = util.concat(&.{ "./", remoteurl });
    }
    var url = url_in;
    var colonsep = false;
    while (url.len > 0) {
        if (startsWithDotDotSlashNative(url)) {
            url = url[3..];
            // chop_last_dir
            if (std.mem.lastIndexOfScalar(u8, remoteurl, '/')) |i| {
                remoteurl = remoteurl[0..i];
            } else if (std.mem.lastIndexOfScalar(u8, remoteurl, ':')) |i| {
                remoteurl = remoteurl[0..i];
                colonsep = true;
            } else {
                if (is_relative or util.eql(remoteurl, "."))
                    util.die("cannot strip one component off url '{s}'", .{remoteurl});
                remoteurl = ".";
            }
        } else if (startsWithDotSlashNative(url)) {
            url = url[2..];
        } else break;
    }
    var sb: []const u8 = util.concat(&.{ remoteurl, if (colonsep) ":" else "/", url });
    if (util.endsWith(url, "/")) sb = sb[0 .. sb.len - 1];
    const out: []const u8 = if (startsWithDotSlashNative(sb)) sb[2..] else sb;
    if (up_path == null or !is_relative) return out;
    return util.concat(&.{ up_path.?, out });
}

/// remote names configured in cfg, in order of first appearance
fn remoteNames(c: *const config.Config) StrList {
    var l: StrList = .empty;
    for (c.entries.items) |e| {
        const rest = util.skipPrefix(e.key, "remote.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse continue;
        const name = rest[0..dot];
        var seen = false;
        for (l.items) |n| {
            if (util.eql(n, name)) {
                seen = true;
                break;
            }
        }
        if (!seen) l.append(gpa, name) catch util.oom();
    }
    return l;
}

/// repo_default_remote()
fn defaultRemoteOf(c: *const config.Config, head_branch: ?[]const u8) []const u8 {
    if (head_branch) |b| {
        if (c.get(util.concat(&.{ "branch.", b, ".remote" }))) |r| {
            if (r.len > 0) return r;
        }
    }
    const names = remoteNames(c);
    if (names.items.len == 1) return names.items[0];
    return "origin";
}

fn getDefaultRemote() []const u8 {
    return defaultRemoteOf(&repo_mod.cfg, repo_mod.currentBranchForConfig());
}

/// resolve_relative_url()
fn resolveRelativeUrl(rel_url: []const u8, up_path: ?[]const u8, quiet: bool) []const u8 {
    const remote = getDefaultRemote();
    const key = util.concat(&.{ "remote.", remote, ".url" });
    const remoteurl = repo_mod.cfg.get(key) orelse blk: {
        if (!quiet) util.warn("could not look up configuration '{s}'. Assuming this repository is its own authoritative upstream.", .{key});
        break :blk os.getcwd();
    };
    return relativeUrl(remoteurl, rel_url, up_path);
}

// ---------------------------------------------------------------------------
// .gitmodules cache (submodule-config.c)

const UpdateType = enum { unspecified, checkout, rebase, merge, none, command };

const UpdateStrategy = struct {
    typ: UpdateType = .unspecified,
    command: ?[]const u8 = null,
};

fn parseUpdateType(v: []const u8) ?UpdateType {
    if (util.eql(v, "none")) return .none;
    if (util.eql(v, "checkout")) return .checkout;
    if (util.eql(v, "rebase")) return .rebase;
    if (util.eql(v, "merge")) return .merge;
    if (v.len > 0 and v[0] == '!') return .command;
    return null;
}

fn parseUpdateStrategy(v: []const u8) ?UpdateStrategy {
    const t = parseUpdateType(v) orelse return null;
    return .{ .typ = t, .command = if (t == .command) v[1..] else null };
}

fn updateTypeToString(t: UpdateType) []const u8 {
    return switch (t) {
        .checkout => "checkout",
        .rebase => "rebase",
        .merge => "merge",
        .none => "none",
        else => "",
    };
}

const Submodule = struct {
    name: []const u8,
    path: ?[]const u8 = null,
    url: ?[]const u8 = null,
    branch: ?[]const u8 = null,
    ignore: ?[]const u8 = null,
    update: UpdateStrategy = .{},
    recommend_shallow: i8 = -1,
};

var cache_loaded = false;
var cache_subs: std.ArrayList(*Submodule) = .empty;
/// submodules in the order their path was (last) set; lookups scan backwards
var cache_paths: std.ArrayList(*Submodule) = .empty;

fn resetCache() void {
    cache_loaded = false;
    cache_subs = .empty;
    cache_paths = .empty;
}

/// check_submodule_name()
pub fn checkSubmoduleName(name: []const u8) bool {
    if (name.len == 0) return false;
    var i: usize = 0;
    var at_start = true;
    while (i <= name.len) : (i += 1) {
        if (at_start) {
            const rest = name[i..];
            if (rest.len >= 2 and rest[0] == '.' and rest[1] == '.' and
                (rest.len == 2 or rest[2] == '/' or rest[2] == '\\')) return false;
            at_start = false;
        }
        if (i < name.len and (name[i] == '/' or name[i] == '\\')) at_start = true;
    }
    return true;
}

fn lookupOrCreate(name: []const u8) *Submodule {
    for (cache_subs.items) |s| {
        if (util.eql(s.name, name)) return s;
    }
    const s = gpa.create(Submodule) catch util.oom();
    s.* = .{ .name = util.dupe(name) };
    cache_subs.append(gpa, s) catch util.oom();
    return s;
}

fn warnCmdlineOption(key: []const u8, value: []const u8) void {
    util.warn("ignoring '{s}' which may be interpreted as a command-line option: {s}", .{ key, value });
}

fn parseGitmodulesEntry(e: config.Entry) void {
    const rest = util.skipPrefix(e.key, "submodule.") orelse return;
    const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse return;
    const name = rest[0..dot];
    const item = rest[dot + 1 ..];
    if (!checkSubmoduleName(name)) {
        util.warn("ignoring suspicious submodule name: {s}", .{name});
        return;
    }
    const sub = lookupOrCreate(name);
    if (util.eql(item, "path")) {
        const v = e.value orelse {
            util.err("missing value for '{s}'", .{e.key});
            return;
        };
        if (v.len > 0 and v[0] == '-') return warnCmdlineOption(e.key, v);
        var i: usize = 0;
        while (i < cache_paths.items.len) {
            if (cache_paths.items[i] == sub) {
                _ = cache_paths.orderedRemove(i);
            } else i += 1;
        }
        sub.path = v;
        cache_paths.append(gpa, sub) catch util.oom();
    } else if (util.eql(item, "ignore")) {
        const v = e.value orelse {
            util.err("missing value for '{s}'", .{e.key});
            return;
        };
        if (!util.eql(v, "untracked") and !util.eql(v, "dirty") and !util.eql(v, "all") and !util.eql(v, "none")) {
            util.warn("Invalid parameter '{s}' for config option 'submodule.{s}.ignore'", .{ v, name });
        } else sub.ignore = v;
    } else if (util.eql(item, "url")) {
        const v = e.value orelse {
            util.err("missing value for '{s}'", .{e.key});
            return;
        };
        if (v.len > 0 and v[0] == '-') return warnCmdlineOption(e.key, v);
        sub.url = v;
    } else if (util.eql(item, "update")) {
        const v = e.value orelse {
            util.err("missing value for '{s}'", .{e.key});
            return;
        };
        const st = parseUpdateStrategy(v);
        if (st == null or st.?.typ == .command) util.die("invalid value for '{s}'", .{e.key});
        sub.update = st.?;
    } else if (util.eql(item, "shallow")) {
        sub.recommend_shallow = if (config.configBool(e.key, e.value)) 1 else 0;
    } else if (util.eql(item, "branch")) {
        const v = e.value orelse {
            util.err("missing value for '{s}'", .{e.key});
            return;
        };
        sub.branch = v;
    }
}

fn gitmodulesUnmerged() bool {
    const idx = index_mod.get();
    for (idx.entries.items) |*e| {
        if (e.removed) continue;
        if (util.eql(e.path, ".gitmodules") and e.stage() != 0) return true;
    }
    return false;
}

fn loadCache() void {
    if (cache_loaded) return;
    cache_loaded = true;
    if (repo_mod.repo().work_tree == null) return;
    if (gitmodulesUnmerged()) return;
    var c: config.Config = .{};
    if (os.lstatPath(".gitmodules") != null) {
        _ = config.readFileInto(&c, ".gitmodules", .local);
    } else {
        var oid: ?Oid = null;
        const idx = index_mod.get();
        if (idx.get(".gitmodules")) |e| {
            if (e.stage() == 0 and !e.removed) oid = e.oid;
        }
        if (oid == null) oid = revparse.getOid("HEAD:.gitmodules");
        const o = oid orelse return;
        const obj = repo_mod.repo().odb().read(o) orelse return;
        _ = config.readBlobInto(&c, obj.data, ".gitmodules", .local);
    }
    for (c.entries.items) |e| parseGitmodulesEntry(e);
}

fn submoduleFromPath(path: []const u8) ?*Submodule {
    loadCache();
    var i = cache_paths.items.len;
    while (i > 0) {
        i -= 1;
        const s = cache_paths.items[i];
        if (s.path) |p| {
            if (util.eql(p, path)) return s;
        }
    }
    return null;
}

fn submoduleFromName(name: []const u8) ?*Submodule {
    loadCache();
    for (cache_subs.items) |s| {
        if (util.eql(s.name, name)) return s;
    }
    return null;
}

// ---------------------------------------------------------------------------
// config writes

fn cfgGet(key: []const u8) ?[]const u8 {
    return repo_mod.cfg.get(key);
}

fn cfgHas(key: []const u8) bool {
    return repo_mod.cfg.getEntry(key) != null;
}

/// repo_config_set_gently()
fn setRepoConfig(key: []const u8, value: ?[]const u8) i32 {
    const r = config.setInFileGently(repo_mod.repo().commonPath("config"), key, null, value);
    repo_mod.loadConfig();
    return r;
}

fn setConfigInFile(file: []const u8, key: []const u8, value: ?[]const u8) i32 {
    return config.setInFileGently(file, key, null, value);
}

/// is_writing_gitmodules_ok()
fn isWritingGitmodulesOk() bool {
    if (os.lstatPath(".gitmodules") != null) return true;
    if (index_mod.get().get(".gitmodules") != null) return false;
    if (revparse.getOid("HEAD:.gitmodules") != null) return false;
    return true;
}

/// config_set_in_gitmodules_file_gently()
fn setInGitmodules(key: []const u8, value: ?[]const u8) i32 {
    const r = config.setInFileGently(".gitmodules", key, null, value);
    if (r < 0) util.warn("Could not update .gitmodules entry {s}", .{key});
    resetCache();
    return r;
}

// ---------------------------------------------------------------------------
// activity, listing

/// is_submodule_active()
fn isSubmoduleActive(path: []const u8) bool {
    const sub = submoduleFromPath(path) orelse return false;
    const key = util.concat(&.{ "submodule.", sub.name, ".active" });
    if (repo_mod.cfg.getEntry(key)) |e| return config.configBool(e.key, e.value);
    const pats = repo_mod.cfg.getAll("submodule.active");
    if (pats.len > 0) {
        const ps = pathspec_mod.parse("", pats, .{});
        return ps.matches(path, true);
    }
    return cfgHas(util.concat(&.{ "submodule.", sub.name, ".url" }));
}

const ListEntry = struct {
    path: []const u8,
    oid: Oid,
    mode: u32,
    stage: u32,
};

fn moduleListCompute(args: []const []const u8, prefix: []const u8, ps_out: ?*pathspec_mod.Pathspec) ?[]ListEntry {
    const ps = pathspec_mod.parse(prefix, args, .{ .prefer_full = true });
    if (ps_out) |p| p.* = ps;
    const seen = ps.newSeen();
    var l: std.ArrayList(ListEntry) = .empty;
    const idx = index_mod.get();
    const ents = idx.entries.items;
    var i: usize = 0;
    while (i < ents.len) : (i += 1) {
        const e = &ents[i];
        if (e.removed) continue;
        if (ps.matchSeen(e.path, true, seen) == 0 or !isGitlink(e.mode)) continue;
        l.append(gpa, .{ .path = e.path, .oid = e.oid, .mode = e.mode, .stage = e.stage() }) catch util.oom();
        while (i + 1 < ents.len and util.eql(e.path, ents[i + 1].path)) i += 1;
    }
    if (ps.items.len > 0 and ps.reportPathError(seen) > 0) return null;
    return l.items;
}

fn moduleListActive(list: []ListEntry) []ListEntry {
    var l: std.ArrayList(ListEntry) = .empty;
    for (list) |e| {
        if (isSubmoduleActive(e.path)) l.append(gpa, e) catch util.oom();
    }
    return l.items;
}

// ---------------------------------------------------------------------------
// git dirs

/// submodule_name_to_gitdir()
fn nameToGitdir(name: []const u8) []const u8 {
    const gd = repo_mod.repo().gitPath(util.concat(&.{ "modules/", name }));
    if (!validateGitdir(gd, name)) {
        util.eprint("hint: enabling extensions.submodulePathConfig might fix the following error, if it's not already enabled.\n", .{});
        util.die("refusing to create/use '{s}' in another submodule's  git dir.", .{gd});
    }
    return gd;
}

/// validate_submodule_legacy_git_dir()
fn validateGitdir(gd: []const u8, name: []const u8) bool {
    if (gd.len <= name.len) return true;
    const start = gd.len - name.len;
    var i = start;
    while (i < gd.len) : (i += 1) {
        if (gd[i] == '/') {
            if (repo_mod.isGitDirectory(gd[0..i])) {
                util.err("submodule git dir '{s}' is inside git dir '{s}'", .{ gd, gd[0..i] });
                return false;
            }
        }
    }
    return true;
}

/// submodule_to_gitdir()
fn submoduleToGitdir(path: []const u8) ?[]const u8 {
    validatePathOrExit(path);
    var buf: []const u8 = if (util.endsWith(path, "/")) util.concat(&.{ path, ".git" }) else util.concat(&.{ path, "/.git" });
    if (repo_mod.readGitfile(buf)) |g| buf = g;
    if (!repo_mod.isGitDirectory(buf)) {
        const sub = submoduleFromPath(path) orelse return null;
        buf = nameToGitdir(sub.name);
    }
    return buf;
}

fn isPopulated(path: []const u8) bool {
    return repo_mod.resolveGitdir(util.concat(&.{ path, "/.git" })) != null;
}

/// is_nonbare_repository_dir()
fn isNonbareRepoDir(path: []const u8) bool {
    const p = util.concat(&.{ path, "/.git" });
    var e: repo_mod.GitfileErr = .none;
    if (repo_mod.readGitfileGently(p, &e) != null) return true;
    if (repo_mod.isGitDirectory(p)) return true;
    return e == .open_failed or e == .read_failed;
}

/// connect_work_tree_and_git_dir()
fn connectWorkTreeAndGitDir(wt_in: []const u8, gd_in: []const u8) void {
    const gitfile = util.concat(&.{ wt_in, "/.git" });
    if (!os.mkdirLeading(gitfile)) util.die("could not create directories for {s}", .{gitfile});
    const cfg_file = util.concat(&.{ gd_in, "/config" });
    if (!os.mkdirLeading(cfg_file)) util.die("could not create directories for {s}", .{cfg_file});
    const gd = realPath(gd_in);
    const wt = realPath(wt_in);
    os.writeFile(gitfile, util.concat(&.{ "gitdir: ", relativePath(gd, wt), "\n" }), 0o666) catch
        util.dieErrno("could not write to '{s}'", .{gitfile});
    if (config.setInFileGently(cfg_file, "core.worktree", null, relativePath(wt, gd)) < 0)
        util.die("could not set 'core.worktree' to '{s}'", .{relativePath(wt, gd)});
}

fn submoduleUsesWorktrees(path: []const u8) bool {
    const gd = submoduleToGitdir(path) orelse return false;
    const ents = os.listDir(util.concat(&.{ gd, "/worktrees" })) orelse return false;
    for (ents) |e| {
        if (util.eql(e.name, ".") or util.eql(e.name, "..")) continue;
        return true;
    }
    return false;
}

fn relocateSingleGitDir(path: []const u8, super_prefix: ?[]const u8) void {
    validatePathOrExit(path);
    if (submoduleUsesWorktrees(path))
        util.die("relocate_gitdir for submodule '{s}' with more than one worktree not supported", .{path});
    const old_git_dir = util.concat(&.{ path, "/.git" });
    if (repo_mod.readGitfile(old_git_dir) != null) return;
    const real_old = realPath(old_git_dir);
    const sub = submoduleFromPath(path) orelse util.die("could not lookup name for submodule '{s}'", .{path});
    const new_gitdir = nameToGitdir(sub.name);
    if (!os.mkdirLeading(new_gitdir)) util.die("could not create directory '{s}'", .{new_gitdir});
    const real_new = realPath(new_gitdir);
    util.eprint("Migrating git directory of '{s}{s}' from\n'{s}' to\n'{s}'\n", .{ super_prefix orelse "", path, real_old, real_new });
    if (!os.rename(real_old, real_new))
        util.dieErrno("could not migrate git directory from '{s}' to '{s}'", .{ real_old, real_new });
    connectWorkTreeAndGitDir(path, real_new);
}

/// absorb_git_dir_into_superproject()
fn absorbGitDir(path: []const u8, super_prefix: ?[]const u8) void {
    validatePathOrExit(path);
    const gitdir = util.concat(&.{ path, "/.git" });
    var sub_git_dir: ?[]const u8 = null;
    var ecode: repo_mod.GitfileErr = .none;
    if (repo_mod.isGitDirectory(gitdir)) {
        sub_git_dir = gitdir;
    } else {
        sub_git_dir = repo_mod.readGitfileGently(gitdir, &ecode);
    }
    if (sub_git_dir == null) {
        if (ecode == .missing) return;
        if (ecode != .not_a_repo) {
            repo_mod.readGitfileErrorDie(ecode, path);
            return;
        }
        const sub = submoduleFromPath(path) orelse util.die("could not lookup name for submodule '{s}'", .{path});
        connectWorkTreeAndGitDir(path, nameToGitdir(sub.name));
    } else {
        const real_sub = realPath(sub_git_dir.?);
        const real_common = realPath(repo_mod.repo().common_dir);
        if (!util.startsWith(real_sub, real_common)) relocateSingleGitDir(path, super_prefix);
    }
    // recurse
    const sp = util.concat(&.{ "--super-prefix=", super_prefix orelse "", path, "/" });
    const r = git(&.{ "submodule--helper", "absorbgitdirs", sp }, .{ .cwd = path, .no_stdin = true });
    if (!ok(r)) util.die("could not recurse into submodule '{s}'", .{path});
}

// ---------------------------------------------------------------------------
// misc lookups in a submodule

fn subHeadOid(path: []const u8) ?Oid {
    return subResolve(path, "HEAD");
}

fn subResolve(path: []const u8, ref: []const u8) ?Oid {
    if (!isPopulated(path)) return null;
    const r = git(&.{ "rev-parse", "--verify", "-q", ref }, .{ .cwd = path, .capture = true, .no_stderr = true });
    if (!ok(r)) return null;
    return hash.fromHex(util.trim(r.stdout));
}

fn subrepoConfig(path: []const u8) ?struct { cfg: config.Config, gitdir: []const u8 } {
    const gd = submoduleToGitdir(path) orelse return null;
    if (!repo_mod.isGitDirectory(gd)) return null;
    var c: config.Config = .{};
    _ = config.readFileInto(&c, util.concat(&.{ gd, "/config" }), .local);
    return .{ .cfg = c, .gitdir = gd };
}

fn headBranchOf(gitdir: []const u8) ?[]const u8 {
    const data = os.readFile(util.concat(&.{ gitdir, "/HEAD" })) orelse return null;
    const rest = util.skipPrefix(data, "ref: refs/heads/") orelse return null;
    return util.trimRight(rest);
}

/// get_default_remote_submodule()
fn getDefaultRemoteSubmodule(path: []const u8) union(enum) { ok: []const u8, err: u8 } {
    var url: ?[]const u8 = null;
    if (submoduleFromPath(path)) |sub| {
        if (sub.url) |u| {
            url = if (isRelativeUrl(u)) resolveRelativeUrl(u, null, true) else u;
        }
    }
    const sr = subrepoConfig(path) orelse
        return .{ .err = dieMessage("could not get a repository handle for submodule '{s}'", .{path}) };
    if (url) |u| {
        for (remoteNames(&sr.cfg).items) |n| {
            for (sr.cfg.getAll(util.concat(&.{ "remote.", n, ".url" }))) |v| {
                if (util.eql(v, u)) return .{ .ok = n };
            }
        }
    }
    // the submodule's gitdir might be a worktree gitdir; HEAD lives there
    return .{ .ok = defaultRemoteOf(&sr.cfg, headBranchOf(sr.gitdir)) };
}

/// compute_rev_name()
fn computeRevName(sub_path: []const u8, oid_hex: []const u8) ?[]const u8 {
    const variants = [_][]const []const u8{
        &.{},
        &.{"--tags"},
        &.{"--contains"},
        &.{ "--all", "--always" },
    };
    for (variants) |v| {
        var args: StrList = .empty;
        args.append(gpa, "describe") catch util.oom();
        args.appendSlice(gpa, v) catch util.oom();
        args.append(gpa, oid_hex) catch util.oom();
        const r = git(args.items, .{ .cwd = sub_path, .capture = true, .no_stderr = true });
        if (ok(r)) return stripNl(r.stdout);
    }
    return null;
}

// ---------------------------------------------------------------------------
// foreach

fn cmdForeach(args: []const []const u8, prefix: []const u8) u8 {
    var super_prefix: ?[]const u8 = null;
    var quiet: i32 = 0;
    var recursive = false;
    const usage = [_][]const u8{"git submodule foreach [--quiet] [--recursive] [--] <command>"};
    const opts = [_]po.Opt{
        .{ .long = "super-prefix", .kind = .string, .s = &super_prefix, .argh = "path", .hidden = true, .help = "prefixed path to initial superproject" },
        po.counter('q', "quiet", &quiet, "suppress output of entering each submodule command"),
        po.boolean(0, "recursive", &recursive, "recurse into nested submodules"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{ .stop_at_non_option = true });
    const list = moduleListCompute(&.{}, prefix, null) orelse return 1;
    for (list) |le| {
        const path = le.path;
        validatePathOrExit(path);
        const dp = displayPath(path, prefix, super_prefix);
        const sub = submoduleFromPath(path) orelse util.die("No url found for submodule path '{s}' in .gitmodules", .{dp});
        if (!isPopulated(path)) continue;
        var cmd_args: StrList = .empty;
        var env: std.ArrayList([2][]const u8) = .empty;
        if (rest.len == 1) {
            const hx = hash.hexAlloc(le.oid);
            env.append(gpa, .{ "name", sub.name }) catch util.oom();
            env.append(gpa, .{ "sm_path", path }) catch util.oom();
            env.append(gpa, .{ "displaypath", dp }) catch util.oom();
            env.append(gpa, .{ "sha1", hx }) catch util.oom();
            env.append(gpa, .{ "toplevel", os.getcwd() }) catch util.oom();
            var sb: util.Buf = .empty;
            util.sqQuote(&sb, path);
            cmd_args.append(gpa, util.concat(&.{ "path=", sb.items, "; ", rest[0] })) catch util.oom();
        } else {
            cmd_args.appendSlice(gpa, rest) catch util.oom();
        }
        if (quiet <= 0) util.outf("Entering '{s}'\n", .{dp});
        if (rest.len > 0) {
            const r = runCmd(cmd_args.items, .{ .cwd = path, .shell = true, .extra_env = env.items }, false);
            if (!ok(r)) util.die("run_command returned non-zero status for {s}\n.", .{dp});
        }
        if (recursive) {
            var ra: StrList = .empty;
            ra.appendSlice(gpa, &.{ "submodule--helper", "foreach", "--recursive", util.concat(&.{ "--super-prefix=", dp, "/" }) }) catch util.oom();
            if (quiet > 0) ra.append(gpa, "--quiet") catch util.oom();
            ra.append(gpa, "--") catch util.oom();
            ra.appendSlice(gpa, rest) catch util.oom();
            const r = git(ra.items, .{ .cwd = path });
            if (!ok(r)) util.die("run_command returned non-zero status while recursing in the nested submodules of {s}\n.", .{dp});
        }
    }
    return 0;
}

// ---------------------------------------------------------------------------
// init

fn initSubmodule(path: []const u8, prefix: []const u8, super_prefix: ?[]const u8, quiet: bool) void {
    const dp = displayPath(path, prefix, super_prefix);
    const sub = submoduleFromPath(path) orelse util.die("No url found for submodule path '{s}' in .gitmodules", .{dp});
    if (!isSubmoduleActive(path)) {
        _ = setRepoConfig(util.concat(&.{ "submodule.", sub.name, ".active" }), "true");
    }
    const url_key = util.concat(&.{ "submodule.", sub.name, ".url" });
    if (cfgGet(url_key) == null) {
        var url = sub.url orelse util.die("No url found for submodule path '{s}' in .gitmodules", .{dp});
        if (isRelativeUrl(url)) url = resolveRelativeUrl(url, null, false);
        if (setRepoConfig(url_key, url) < 0)
            util.die("Failed to register url for submodule path '{s}'", .{dp});
        if (!quiet) util.eprint("Submodule '{s}' ({s}) registered for path '{s}'\n", .{ sub.name, url, dp });
    }
    const upd_key = util.concat(&.{ "submodule.", sub.name, ".update" });
    if (cfgGet(upd_key) == null and sub.update.typ != .unspecified) {
        var upd: []const u8 = undefined;
        if (sub.update.typ == .command) {
            util.eprint("warning: command update mode suggested for submodule '{s}'\n", .{sub.name});
            upd = "none";
        } else upd = updateTypeToString(sub.update.typ);
        if (setRepoConfig(upd_key, upd) < 0)
            util.die("Failed to register update mode for submodule path '{s}'", .{dp});
    }
}

fn cmdInit(args: []const []const u8, prefix: []const u8) u8 {
    var quiet: i32 = 0;
    const usage = [_][]const u8{"git submodule init [<options>] [<path>]"};
    const opts = [_]po.Opt{
        po.counter('q', "quiet", &quiet, "suppress output for initializing a submodule"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    var list = moduleListCompute(rest, prefix, null) orelse return 1;
    if (rest.len == 0 and cfgHas("submodule.active")) list = moduleListActive(list);
    for (list) |le| initSubmodule(le.path, prefix, null, quiet > 0);
    return 0;
}

// ---------------------------------------------------------------------------
// status

fn printStatus(quiet: bool, state: u8, path: []const u8, oid: Oid, dp: []const u8) void {
    if (quiet) return;
    const hx = hash.hex(oid);
    util.outf("{c}{s} {s}", .{ state, &hx, dp });
    if (state == ' ' or state == '+') {
        if (computeRevName(path, &hx)) |n| util.outf(" ({s})", .{n});
    }
    util.out("\n");
}

fn statusSubmodule(le: ListEntry, prefix: []const u8, super_prefix: ?[]const u8, quiet: bool, cached: bool, recursive: bool) void {
    const path = le.path;
    validatePathOrExit(path);
    if (submoduleFromPath(path) == null)
        util.die("no submodule mapping found in .gitmodules for path '{s}'", .{path});
    const dp = displayPath(path, prefix, super_prefix);
    if (le.stage != 0) {
        printStatus(quiet, 'U', path, hash.zero, dp);
        return;
    }
    const buf = util.concat(&.{ path, "/.git" });
    const gd = repo_mod.readGitfile(buf) orelse buf;
    if (!isSubmoduleActive(path) or !repo_mod.isGitDirectory(gd)) {
        printStatus(quiet, '-', path, le.oid, dp);
        return;
    }
    const head = subHeadOid(path);
    if (head != null and hash.eql(head.?, le.oid)) {
        printStatus(quiet, ' ', path, le.oid, dp);
    } else if (!cached) {
        printStatus(quiet, '+', path, head orelse hash.zero, dp);
    } else {
        printStatus(quiet, '+', path, le.oid, dp);
    }
    if (recursive) {
        var ra: StrList = .empty;
        ra.appendSlice(gpa, &.{ "submodule--helper", "status", "--recursive", util.concat(&.{ "--super-prefix=", dp, "/" }) }) catch util.oom();
        if (cached) ra.append(gpa, "--cached") catch util.oom();
        if (quiet) ra.append(gpa, "--quiet") catch util.oom();
        const r = git(ra.items, .{ .cwd = path });
        if (r.signaled and r.status == 128 + 13) os.exit(141);
        if (!ok(r)) util.die("failed to recurse into submodule '{s}'", .{path});
    }
}

fn cmdStatus(args: []const []const u8, prefix: []const u8) u8 {
    var super_prefix: ?[]const u8 = null;
    var quiet: i32 = 0;
    var cached = false;
    var recursive = false;
    const usage = [_][]const u8{"git submodule status [--quiet] [--cached] [--recursive] [<path>...]"};
    const opts = [_]po.Opt{
        .{ .long = "super-prefix", .kind = .string, .s = &super_prefix, .argh = "path", .hidden = true, .help = "prefixed path to initial superproject" },
        po.counter('q', "quiet", &quiet, "suppress submodule status output"),
        po.boolean(0, "cached", &cached, "use commit stored in the index instead of the one stored in the submodule HEAD"),
        po.boolean(0, "recursive", &recursive, "recurse into nested submodules"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    const list = moduleListCompute(rest, prefix, null) orelse return 1;
    for (list) |le| statusSubmodule(le, prefix, super_prefix, quiet > 0, cached, recursive);
    return 0;
}

// ---------------------------------------------------------------------------
// summary

const ModuleCb = struct {
    mod_src: u32,
    mod_dst: u32,
    oid_src: Oid,
    oid_dst: Oid,
    status: u8,
    sm_path: []const u8,
};

const SummaryInfo = struct {
    prefix: []const u8,
    cached: bool,
    for_status: bool,
    files: bool,
    summary_limit: i32,
};

fn verifySubmoduleCommittish(sm_path: []const u8, committish: []const u8) ?[]const u8 {
    const r = git(&.{ "rev-parse", "-q", "--short", util.concat(&.{ committish, "^0" }), "--" }, .{ .cwd = sm_path, .capture = true });
    if (!ok(r)) return null;
    return firstLine(r.stdout);
}

fn printSubmoduleSummary(info: *const SummaryInfo, errmsg: ?[]const u8, total: i64, dp: []const u8, src_abbrev: []const u8, dst_abbrev: []const u8, p: *const ModuleCb) void {
    if (p.status == 'T') {
        if (isGitlink(p.mod_dst)) {
            util.outf("* {s} {s}(blob)->{s}(submodule)", .{ dp, src_abbrev, dst_abbrev });
        } else util.outf("* {s} {s}(submodule)->{s}(blob)", .{ dp, src_abbrev, dst_abbrev });
    } else util.outf("* {s} {s}...{s}", .{ dp, src_abbrev, dst_abbrev });
    if (total < 0) util.out(":\n") else util.outf(" ({d}):\n", .{total});
    if (errmsg) |m| {
        util.out(m);
    } else if (total > 0) {
        var la: StrList = .empty;
        la.append(gpa, "log") catch util.oom();
        if (isGitlink(p.mod_src) and isGitlink(p.mod_dst)) {
            if (info.summary_limit > 0) la.append(gpa, util.fmt("-{d}", .{info.summary_limit})) catch util.oom();
            la.appendSlice(gpa, &.{ "--pretty=  %m %s", "--first-parent", util.concat(&.{ src_abbrev, "...", dst_abbrev }) }) catch util.oom();
        } else if (isGitlink(p.mod_dst)) {
            la.appendSlice(gpa, &.{ "--pretty=  > %s", "-1", dst_abbrev }) catch util.oom();
        } else {
            la.appendSlice(gpa, &.{ "--pretty=  < %s", "-1", src_abbrev }) catch util.oom();
        }
        _ = git(la.items, .{ .cwd = p.sm_path });
    }
    util.out("\n");
}

fn hashFileBlob(path: []const u8, mode: u32) ?Oid {
    const data = if (mode & 0o170000 == 0o120000) (os.readLink(path) orelse return null) else (os.readFile(path) orelse return null);
    var h = hash.Hasher.init(.{});
    const hdr = util.fmt("blob {d}", .{data.len});
    h.update(hdr);
    h.update(&[_]u8{0});
    h.update(data);
    var out: Oid = undefined;
    h.final(&out);
    return out;
}

fn generateSubmoduleSummary(info: *const SummaryInfo, p: *ModuleCb) void {
    if (!info.cached and hash.isZero(p.oid_dst)) {
        if (isGitlink(p.mod_dst)) {
            if (subHeadOid(p.sm_path)) |o| p.oid_dst = o;
        } else if (p.mod_dst & 0o170000 == 0o120000 or p.mod_dst & 0o170000 == 0o100000) {
            if (hashFileBlob(p.sm_path, p.mod_dst)) |o| {
                p.oid_dst = o;
            } else util.err("couldn't hash object from '{s}'", .{p.sm_path});
        } else if (p.mod_dst != 0) {
            util.warn("unexpected mode {o}", .{p.mod_dst});
        }
    }
    var missing_src = false;
    var missing_dst = false;
    const src_hex = hash.hexAlloc(p.oid_src);
    const dst_hex = hash.hexAlloc(p.oid_dst);
    var src_abbrev: []const u8 = undefined;
    if (isGitlink(p.mod_src)) {
        var a: ?[]const u8 = null;
        if (p.status != 'D') a = verifySubmoduleCommittish(p.sm_path, src_hex);
        if (a) |x| src_abbrev = x else {
            missing_src = true;
            src_abbrev = src_hex[0..7];
        }
    } else src_abbrev = src_hex[0..7];
    var dst_abbrev: []const u8 = undefined;
    if (isGitlink(p.mod_dst)) {
        if (verifySubmoduleCommittish(p.sm_path, dst_hex)) |x| dst_abbrev = x else {
            missing_dst = true;
            dst_abbrev = dst_hex[0..7];
        }
    } else dst_abbrev = dst_hex[0..7];

    const dp = displayPath(p.sm_path, info.prefix, null);
    var total: i64 = -1;
    var errmsg: ?[]const u8 = null;
    if (!missing_src and !missing_dst) {
        var ra: StrList = .empty;
        ra.appendSlice(gpa, &.{ "rev-list", "--first-parent", "--count" }) catch util.oom();
        if (isGitlink(p.mod_src) and isGitlink(p.mod_dst)) {
            ra.append(gpa, util.concat(&.{ src_abbrev, "...", dst_abbrev })) catch util.oom();
        } else ra.append(gpa, if (isGitlink(p.mod_src)) src_abbrev else dst_abbrev) catch util.oom();
        ra.append(gpa, "--") catch util.oom();
        const r = git(ra.items, .{ .cwd = p.sm_path, .capture = true });
        if (ok(r)) total = std.fmt.parseInt(i64, util.trim(r.stdout), 10) catch 0;
    } else if (isGitlink(p.mod_dst)) {
        if (missing_src and missing_dst) {
            errmsg = util.fmt("  Warn: {s} doesn't contain commits {s} and {s}\n", .{ dp, src_hex, dst_hex });
        } else {
            errmsg = util.fmt("  Warn: {s} doesn't contain commit {s}\n", .{ dp, if (missing_src) src_hex else dst_hex });
        }
    }
    printSubmoduleSummary(info, errmsg, total, dp, src_abbrev, dst_abbrev, p);
}

fn parseOctal(s: []const u8) u32 {
    return std.fmt.parseInt(u32, s, 8) catch 0;
}

fn cmdSummary(args: []const []const u8, prefix: []const u8) u8 {
    var cached = false;
    var for_status = false;
    var files = false;
    var summary_limit: i32 = -1;
    const usage = [_][]const u8{"git submodule summary [<options>] [<commit>] [--] [<path>]"};
    const opts = [_]po.Opt{
        po.boolean(0, "cached", &cached, "use the commit stored in the index instead of the submodule HEAD"),
        po.boolean(0, "files", &files, "compare the commit in the index with that in the submodule HEAD"),
        po.boolean(0, "for-status", &for_status, "skip submodules with 'ignore_config' value set to 'all'"),
        po.integer('n', "summary-limit", &summary_limit, "n", "limit the summary size"),
    };
    var rest = po.parse(args[1..], &opts, &usage, .{});
    if (summary_limit == 0) return 0;
    var head_hex: []const u8 = undefined;
    if (revparse.getOid(if (rest.len > 0) rest[0] else "HEAD")) |o| {
        head_hex = hash.hexAlloc(o);
        if (rest.len > 0) rest = rest[1..];
    } else if (rest.len == 0 or util.eql(rest[0], "HEAD")) {
        head_hex = hash.empty_tree_hex;
        if (rest.len > 0) rest = rest[1..];
    } else {
        const o = revparse.getOid("HEAD") orelse util.die("could not fetch a revision for HEAD", .{});
        head_hex = hash.hexAlloc(o);
    }
    if (files and cached) util.die("options '{s}' and '{s}' cannot be used together", .{ "--cached", "--files" });
    const info = SummaryInfo{ .prefix = prefix, .cached = cached, .for_status = for_status, .files = files, .summary_limit = summary_limit };

    var da: StrList = .empty;
    da.append(gpa, if (files) "diff-files" else "diff-index") catch util.oom();
    if (cached) da.append(gpa, "--cached") catch util.oom();
    da.appendSlice(gpa, &.{ "--ignore-submodules=dirty", "--raw", "-z" }) catch util.oom();
    if (!files) da.append(gpa, head_hex) catch util.oom();
    da.append(gpa, "--") catch util.oom();
    da.appendSlice(gpa, rest) catch util.oom();
    const r = git(da.items, .{ .sub_env = false, .cwd = if (prefix.len > 0) prefix else null, .capture = true });
    if (!ok(r)) return 1;

    var list: std.ArrayList(ModuleCb) = .empty;
    const outp = r.stdout;
    var pos: usize = 0;
    while (pos < outp.len) {
        if (outp[pos] != ':') break;
        const hend = std.mem.indexOfScalarPos(u8, outp, pos, 0) orelse break;
        const header = outp[pos + 1 .. hend];
        pos = hend + 1;
        var it = std.mem.splitScalar(u8, header, ' ');
        const m1 = it.next() orelse break;
        const m2 = it.next() orelse break;
        const o1 = it.next() orelse break;
        const o2 = it.next() orelse break;
        const st = it.next() orelse break;
        const pend = std.mem.indexOfScalarPos(u8, outp, pos, 0) orelse outp.len;
        const path = outp[pos..pend];
        pos = @min(pend + 1, outp.len);
        if (st.len > 0 and (st[0] == 'R' or st[0] == 'C')) {
            const p2 = std.mem.indexOfScalarPos(u8, outp, pos, 0) orelse outp.len;
            pos = @min(p2 + 1, outp.len);
        }
        const mod_src = parseOctal(m1);
        const mod_dst = parseOctal(m2);
        if (!isGitlink(mod_src) and !isGitlink(mod_dst)) continue;
        list.append(gpa, .{
            .mod_src = mod_src,
            .mod_dst = mod_dst,
            .oid_src = hash.fromHex(o1) orelse hash.zero,
            .oid_dst = hash.fromHex(o2) orelse hash.zero,
            .status = if (st.len > 0) st[0] else 'M',
            .sm_path = path,
        }) catch util.oom();
    }

    for (list.items) |*p| {
        if (p.status == 'D' or p.status == 'T') {
            generateSubmoduleSummary(&info, p);
            continue;
        }
        if (for_status and p.status != 'A') {
            if (submoduleFromPath(p.sm_path)) |sub| {
                var ignore_all = false;
                if (cfgGet(util.concat(&.{ "submodule.", sub.name, ".ignore" }))) |v| {
                    ignore_all = util.eql(v, "all");
                } else if (sub.ignore) |v| ignore_all = util.eql(v, "all");
                if (ignore_all) continue;
            }
        }
        if (isNonbareRepoDir(p.sm_path)) generateSubmoduleSummary(&info, p);
    }
    return 0;
}

// ---------------------------------------------------------------------------
// sync

fn syncSubmodule(path: []const u8, prefix: []const u8, super_prefix: ?[]const u8, quiet: bool, recursive: bool) void {
    if (!isSubmoduleActive(path)) return;
    validatePathOrExit(path);
    const sub = submoduleFromPath(path) orelse return;
    var sub_origin_url: []const u8 = "";
    var super_config_url: []const u8 = "";
    if (sub.url) |u| {
        if (isRelativeUrl(u)) {
            sub_origin_url = resolveRelativeUrl(u, getUpPath(path), true);
            super_config_url = resolveRelativeUrl(u, null, true);
        } else {
            sub_origin_url = u;
            super_config_url = u;
        }
    }
    const dp = displayPath(path, prefix, super_prefix);
    if (!quiet) util.outf("Synchronizing submodule url for '{s}'\n", .{dp});
    if (setRepoConfig(util.concat(&.{ "submodule.", sub.name, ".url" }), super_config_url) < 0)
        util.die("failed to register url for submodule path '{s}'", .{dp});
    if (!isPopulated(path)) return;
    const remote = switch (getDefaultRemoteSubmodule(path)) {
        .ok => |r| r,
        .err => |c| os.exit(c),
    };
    const gd = submoduleToGitdir(path) orelse util.die("failed to update remote for submodule '{s}'", .{path});
    if (setConfigInFile(util.concat(&.{ gd, "/config" }), util.concat(&.{ "remote.", remote, ".url" }), sub_origin_url) < 0)
        util.die("failed to update remote for submodule '{s}'", .{path});
    if (recursive) {
        var ra: StrList = .empty;
        ra.appendSlice(gpa, &.{ "submodule--helper", "sync", "--recursive", util.concat(&.{ "--super-prefix=", dp, "/" }) }) catch util.oom();
        if (quiet) ra.append(gpa, "--quiet") catch util.oom();
        const r = git(ra.items, .{ .cwd = path });
        if (!ok(r)) util.die("failed to recurse into submodule '{s}'", .{path});
    }
}

fn cmdSync(args: []const []const u8, prefix: []const u8) u8 {
    var super_prefix: ?[]const u8 = null;
    var quiet: i32 = 0;
    var recursive = false;
    const usage = [_][]const u8{"git submodule sync [--quiet] [--recursive] [<path>]"};
    const opts = [_]po.Opt{
        .{ .long = "super-prefix", .kind = .string, .s = &super_prefix, .argh = "path", .hidden = true, .help = "prefixed path to initial superproject" },
        po.counter('q', "quiet", &quiet, "suppress output of synchronizing submodule url"),
        po.boolean(0, "recursive", &recursive, "recurse into nested submodules"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    const list = moduleListCompute(rest, prefix, null) orelse return 1;
    for (list) |le| syncSubmodule(le.path, prefix, super_prefix, quiet > 0, recursive);
    return 0;
}

// ---------------------------------------------------------------------------
// deinit

fn deinitSubmodule(path: []const u8, prefix: []const u8, quiet: bool, force: bool) void {
    validatePathOrExit(path);
    const sub = submoduleFromPath(path) orelse return;
    const dp = displayPath(path, prefix, null);
    const sub_git_dir = util.concat(&.{ path, "/.git" });
    if (os.isDir(path)) {
        if (os.isDir(sub_git_dir)) {
            if (!quiet) util.warn("Submodule work tree '{s}' contains a .git directory. This will be replaced with a .git file by using absorbgitdirs.", .{dp});
            absorbGitDir(path, null);
        }
        if (!force) {
            const r = git(&.{ "rm", "-qn", path }, .{ .sub_env = false });
            if (!ok(r)) util.die("Submodule work tree '{s}' contains local modifications; use '-f' to discard them", .{dp});
        }
        os.removeTree(path);
        const removed = os.lstatPath(path) == null;
        if (!quiet) {
            if (removed) util.outf("Cleared directory '{s}'\n", .{dp}) else util.outf("Could not remove submodule work tree '{s}'\n", .{dp});
        }
        // submodule_unset_core_worktree()
        const cfg_path = util.concat(&.{ nameToGitdir(sub.name), "/config" });
        if (setConfigInFile(cfg_path, "core.worktree", null) != 0)
            util.warn("Could not unset core.worktree setting in submodule '{s}'", .{path});
    }
    if (!os.mkdir(path, 0o777)) util.outf("could not create empty submodule directory {s}", .{dp});

    const pfx = util.concat(&.{ "submodule.", sub.name, "." });
    var found = false;
    for (repo_mod.cfg.entries.items) |e| {
        if (util.startsWith(e.key, pfx)) {
            found = true;
            break;
        }
    }
    if (found) {
        _ = config.renameSectionInFile(repo_mod.repo().commonPath("config"), util.concat(&.{ "submodule.", sub.name }), null, false);
        repo_mod.loadConfig();
        if (!quiet) util.outf("Submodule '{s}' ({s}) unregistered for path '{s}'\n", .{ sub.name, sub.url orelse "(null)", dp });
    }
}

fn cmdDeinit(args: []const []const u8, prefix: []const u8) u8 {
    var quiet: i32 = 0;
    var force: i32 = 0;
    var all = false;
    const usage = [_][]const u8{"git submodule deinit [--quiet] [-f | --force] [--all | [--] [<path>...]]"};
    const opts = [_]po.Opt{
        po.counter('q', "quiet", &quiet, "suppress submodule status output"),
        po.counter('f', "force", &force, "remove submodule working trees even if they contain local changes"),
        po.boolean(0, "all", &all, "unregister all submodules"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (all and rest.len > 0) {
        util.err("pathspec and --all are incompatible", .{});
        po.usageWithOptions(&usage, &opts);
    }
    if (rest.len == 0 and !all) util.die("Use '--all' if you really want to deinitialize all submodules", .{});
    const list = moduleListCompute(rest, prefix, null) orelse return 1;
    for (list) |le| deinitSubmodule(le.path, prefix, quiet > 0, force > 0);
    return 0;
}

// ---------------------------------------------------------------------------
// clone

const CloneData = struct {
    prefix: ?[]const u8 = null,
    path: []const u8 = "",
    name: []const u8 = "",
    url: []const u8 = "",
    depth: i32 = 0,
    ref_format: ?[]const u8 = null,
    filter: ?[]const u8 = null,
    quiet: bool = false,
    progress: bool = false,
    dissociate: bool = false,
    require_init: bool = false,
    single_branch: i32 = -1,
};

fn dirContainsOnlyDotgit(path: []const u8) bool {
    const ents = os.listDir(path) orelse return false;
    var first: ?[]const u8 = null;
    for (ents) |e| {
        if (util.eql(e.name, ".") or util.eql(e.name, "..")) continue;
        if (first == null) {
            first = e.name;
            if (!util.eql(e.name, ".git")) {
                util.err("unexpected item '{s}' in '{s}'", .{ e.name, path });
                return false;
            }
        } else {
            util.err("unexpected item '{s}' in '{s}'", .{ e.name, path });
            return false;
        }
    }
    return first != null;
}

fn cloneSubmodule(cd: *const CloneData, reference: []const []const u8) void {
    const sm_gitdir = absolutePath(nameToGitdir(cd.name));
    validatePathOrExit(cd.path);
    const path = if (isAbs(cd.path)) cd.path else util.concat(&.{ repo_mod.repo().work_tree orelse os.getcwd(), "/", cd.path });
    if (!os.exists(sm_gitdir)) {
        if (cd.require_init and os.statPath(path) != null and !isEmptyDir(path))
            util.die("directory not empty: '{s}'", .{path});
        if (!os.mkdirLeading(sm_gitdir)) util.die("could not create directory '{s}'", .{sm_gitdir});
        var refs: StrList = .empty;
        refs.appendSlice(gpa, reference) catch util.oom();
        preparePossibleAlternates(cd.name, &refs);
        var a: StrList = .empty;
        a.appendSlice(gpa, &.{ "clone", "--no-checkout" }) catch util.oom();
        if (cd.quiet) a.append(gpa, "--quiet") catch util.oom();
        if (cd.progress) a.append(gpa, "--progress") catch util.oom();
        if (cd.depth > 0) a.append(gpa, util.fmt("--depth={d}", .{cd.depth})) catch util.oom();
        for (refs.items) |r| a.appendSlice(gpa, &.{ "--reference", r }) catch util.oom();
        if (cd.ref_format) |f| a.append(gpa, util.concat(&.{ "--ref-format=", f })) catch util.oom();
        if (cd.dissociate) a.append(gpa, "--dissociate") catch util.oom();
        a.appendSlice(gpa, &.{ "--separate-git-dir", sm_gitdir }) catch util.oom();
        if (cd.filter) |f| a.append(gpa, util.concat(&.{ "--filter=", f })) catch util.oom();
        if (cd.single_branch >= 0) a.append(gpa, if (cd.single_branch > 0) "--single-branch" else "--no-single-branch") catch util.oom();
        a.appendSlice(gpa, &.{ "--", cd.url, path }) catch util.oom();
        const r = git(a.items, .{ .set_git_dir = false, .no_stdin = true });
        if (!ok(r)) util.die("clone of '{s}' into submodule path '{s}' failed", .{ cd.url, path });
        if (cd.require_init and os.statPath(path) != null and !dirContainsOnlyDotgit(path)) {
            _ = os.unlink(util.concat(&.{ path, "/.git" }));
            util.die("directory not empty: '{s}'", .{path});
        }
    } else {
        if (cd.require_init and os.statPath(path) != null and !isEmptyDir(path))
            util.die("directory not empty: '{s}'", .{path});
        if (!os.mkdirLeading(path)) util.die("could not create directory '{s}'", .{path});
        const ip = util.concat(&.{ sm_gitdir, "/index" });
        if (!os.unlink(ip) and os.errno() != os.ENOENT) util.warn("unable to unlink '{s}': {s}", .{ ip, os.lastErr() });
    }
    if (!validateGitdir(sm_gitdir, cd.name)) {
        _ = os.unlink(util.concat(&.{ sm_gitdir, "/HEAD" }));
        util.die("refusing to create/use '{s}' in another submodule's git dir. Enabling extensions.submodulePathConfig should fix this.", .{sm_gitdir});
    }
    connectWorkTreeAndGitDir(path, sm_gitdir);
    const p = util.concat(&.{ sm_gitdir, "/config" });
    if (cfgGet("submodule.alternateLocation")) |v| _ = setConfigInFile(p, "submodule.alternateLocation", v);
    if (cfgGet("submodule.alternateErrorStrategy")) |v| _ = setConfigInFile(p, "submodule.alternateErrorStrategy", v);
}

fn preparePossibleAlternates(sm_name: []const u8, refs: *StrList) void {
    const loc = cfgGet("submodule.alternateLocation") orelse return;
    const strategy = cfgGet("submodule.alternateErrorStrategy") orelse "die";
    const mode: u8 = if (util.eql(strategy, "die")) 0 else if (util.eql(strategy, "info")) 1 else if (util.eql(strategy, "ignore")) 2 else util.die("Value '{s}' for submodule.alternateErrorStrategy is not recognized", .{strategy});
    if (util.eql(loc, "no")) return;
    if (!util.eql(loc, "superproject")) util.die("Value '{s}' for submodule.alternateLocation is not recognized", .{loc});
    // iterate the superproject's alternates
    const alt_file = util.concat(&.{ repo_mod.repo().common_dir, "/objects/info/alternates" });
    const data = os.readFile(alt_file) orelse return;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        const line = util.trimRight(line0);
        if (line.len == 0 or line[0] == '#') continue;
        const alt = if (isAbs(line)) line else util.concat(&.{ repo_mod.repo().common_dir, "/objects/", line });
        if (!util.endsWith(alt, "/objects")) continue;
        const base = alt[0 .. alt.len - "/objects".len];
        const cand = util.concat(&.{ base, "/modules/", sm_name, "/" });
        if (repo_mod.isGitDirectory(cand)) {
            refs.append(gpa, cand) catch util.oom();
        } else {
            const msg = util.fmt("path '{s}' does not exist", .{cand});
            switch (mode) {
                0 => {
                    util.eprint("hint: An alternate computed from a superproject's alternate is invalid.\nhint: To allow Git to clone without an alternate in such a case, set\nhint: submodule.alternateErrorStrategy to 'info' or, equivalently, clone with\nhint: '--reference-if-able' instead of '--reference'.\n", .{});
                    util.die("submodule '{s}' cannot add alternate: {s}", .{ sm_name, msg });
                },
                1 => util.eprint("submodule '{s}' cannot add alternate: {s}\n", .{ sm_name, msg }),
                else => {},
            }
        }
    }
}

fn cmdClone(args: []const []const u8, prefix: []const u8) u8 {
    _ = prefix;
    var cd = CloneData{};
    var cprefix: ?[]const u8 = null;
    var path: ?[]const u8 = null;
    var name: ?[]const u8 = null;
    var url: ?[]const u8 = null;
    var reference: StrList = .empty;
    var ref_format: ?[]const u8 = null;
    var dissociate = false;
    var quiet: i32 = 0;
    var progress = false;
    var require_init = false;
    var filter: ?[]const u8 = null;
    const usage = [_][]const u8{"git submodule--helper clone [--prefix=<path>] [--quiet] [--reference <repository>] [--name <name>] [--depth <depth>] [--single-branch] [--filter <filter-spec>] --url <url> --path <path>"};
    const opts = [_]po.Opt{
        po.string(0, "prefix", &cprefix, "path", "alternative anchor for relative paths"),
        po.string(0, "path", &path, "path", "where the new submodule will be cloned to"),
        po.string(0, "name", &name, "string", "name of the new submodule"),
        po.string(0, "url", &url, "string", "url where to clone the submodule from"),
        po.list(0, "reference", &reference, "repo", "reference repository"),
        po.string(0, "ref-format", &ref_format, "format", "specify the reference format to use"),
        po.boolean(0, "dissociate", &dissociate, "use --reference only while cloning"),
        po.integer(0, "depth", &cd.depth, "n", "depth for shallow clones"),
        po.counter('q', "quiet", &quiet, "suppress output for cloning a submodule"),
        po.boolean(0, "progress", &progress, "force cloning progress"),
        po.boolean(0, "require-init", &require_init, "disallow cloning into non-empty directory"),
        po.setInt(0, "single-branch", &cd.single_branch, 1, "clone only one branch, HEAD or --branch"),
        po.string(0, "filter", &filter, "args", "object filtering"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (ref_format) |f| {
        if (!util.eql(f, "files") and !util.eql(f, "reftable")) util.die("unknown ref storage format '{s}'", .{f});
    }
    if (rest.len > 0 or url == null or path == null or path.?.len == 0) po.usageWithOptions(&usage, &opts);
    cd.prefix = cprefix;
    cd.path = path.?;
    cd.name = name orelse path.?;
    cd.url = url.?;
    cd.ref_format = ref_format;
    cd.filter = filter;
    cd.quiet = quiet > 0;
    cd.progress = progress;
    cd.dissociate = dissociate;
    cd.require_init = require_init;
    cloneSubmodule(&cd, reference.items);
    return 0;
}

// ---------------------------------------------------------------------------
// update

const UpdateData = struct {
    prefix: []const u8 = "",
    super_prefix: ?[]const u8 = null,
    displaypath: []const u8 = "",
    update_default: UpdateType = .unspecified,
    references: StrList = .empty,
    ref_format: ?[]const u8 = null,
    filter: ?[]const u8 = null,
    depth: i32 = 0,
    max_jobs: i32 = 1,
    single_branch: i32 = -1,
    recommend_shallow: i32 = -1,
    require_init: bool = false,
    force: bool = false,
    quiet: bool = false,
    nofetch: bool = false,
    remote: bool = false,
    progress: bool = false,
    dissociate: bool = false,
    init: bool = false,
    warn_if_uninitialized: bool = false,
    recursive: bool = false,
    // per submodule
    oid: Oid = hash.zero,
    suboid: Oid = hash.zero,
    just_cloned: bool = false,
    sm_path: []const u8 = "",
    strategy: UpdateStrategy = .{},
};

const CloneTask = struct {
    sub: *Submodule,
    oid: Oid,
    just_cloned: bool,
};

/// prepare_to_clone_next_submodule(): returns clone argv if cloning is needed
fn prepareToClone(le: ListEntry, ud: *const UpdateData, tasks: *std.ArrayList(CloneTask)) ?[]const []const u8 {
    const dp = displayPath(le.path, ud.prefix, ud.super_prefix);
    if (le.stage != 0) {
        util.eprint("Skipping unmerged submodule {s}\n", .{dp});
        return null;
    }
    const sub = submoduleFromPath(le.path) orelse {
        if (ud.warn_if_uninitialized) util.eprint("Submodule path '{s}' not initialized\nMaybe you want to use 'update --init'?\n", .{dp});
        return null;
    };
    var update_type: UpdateType = sub.update.typ;
    if (cfgGet(util.concat(&.{ "submodule.", sub.name, ".update" }))) |v| {
        update_type = parseUpdateType(v) orelse .unspecified;
    }
    if (ud.update_default == .none or (ud.update_default == .unspecified and update_type == .none)) {
        util.eprint("Skipping submodule '{s}'\n", .{dp});
        return null;
    }
    if (!isSubmoduleActive(le.path)) {
        if (ud.warn_if_uninitialized) util.eprint("Submodule path '{s}' not initialized\nMaybe you want to use 'update --init'?\n", .{dp});
        return null;
    }
    var url: ?[]const u8 = cfgGet(util.concat(&.{ "submodule.", sub.name, ".url" }));
    if (url == null) {
        if (sub.url) |u| {
            url = if (isRelativeUrl(u)) resolveRelativeUrl(u, null, false) else u;
        }
    }
    const the_url = url orelse util.die("cannot clone submodule '{s}' without a URL", .{sub.name});
    const needs_cloning = !os.exists(util.concat(&.{ le.path, "/.git" }));
    tasks.append(gpa, .{ .sub = sub, .oid = le.oid, .just_cloned = needs_cloning }) catch util.oom();
    if (!needs_cloning) return null;
    var a: StrList = .empty;
    a.appendSlice(gpa, &.{ "submodule--helper", "clone" }) catch util.oom();
    if (ud.progress) a.append(gpa, "--progress") catch util.oom();
    if (ud.quiet) a.append(gpa, "--quiet") catch util.oom();
    if (ud.prefix.len > 0) a.appendSlice(gpa, &.{ "--prefix", ud.prefix }) catch util.oom();
    if (ud.recommend_shallow != 0 and sub.recommend_shallow == 1) {
        a.append(gpa, "--depth=1") catch util.oom();
    } else if (ud.depth != 0) a.append(gpa, util.fmt("--depth={d}", .{ud.depth})) catch util.oom();
    if (ud.filter) |f| a.append(gpa, util.concat(&.{ "--filter=", f })) catch util.oom();
    if (ud.require_init) a.append(gpa, "--require-init") catch util.oom();
    if (ud.ref_format) |f| a.append(gpa, util.concat(&.{ "--ref-format=", f })) catch util.oom();
    a.appendSlice(gpa, &.{ "--path", sub.path.?, "--name", sub.name, "--url", the_url }) catch util.oom();
    for (ud.references.items) |r| a.appendSlice(gpa, &.{ "--reference", r }) catch util.oom();
    if (ud.dissociate) a.append(gpa, "--dissociate") catch util.oom();
    if (ud.single_branch >= 0) a.append(gpa, if (ud.single_branch > 0) "--single-branch" else "--no-single-branch") catch util.oom();
    return a.items;
}

fn isTipReachable(path: []const u8, oid: Oid) bool {
    const hx = hash.hexAlloc(oid);
    const r = git(&.{ "rev-list", "-n", "1", hx, "--not", "--all" }, .{ .cwd = path, .capture = true, .no_stderr = true });
    return ok(r) and r.stdout.len == 0;
}

fn fetchInSubmodule(path: []const u8, depth: i32, quiet: bool, oid: ?Oid) u8 {
    var a: StrList = .empty;
    a.append(gpa, "fetch") catch util.oom();
    if (quiet) a.append(gpa, "--quiet") catch util.oom();
    if (depth != 0) a.append(gpa, util.fmt("--depth={d}", .{depth})) catch util.oom();
    if (oid) |o| {
        const remote = switch (getDefaultRemoteSubmodule(path)) {
            .ok => |r| r,
            .err => |c| return c,
        };
        a.appendSlice(gpa, &.{ remote, hash.hexAlloc(o) }) catch util.oom();
    }
    return code(git(a.items, .{ .cwd = path }));
}

fn runUpdateCommand(ud: *const UpdateData, subforce: bool) u8 {
    const hx = hash.hexAlloc(ud.oid);
    var a: StrList = .empty;
    var git_cmd = true;
    switch (ud.strategy.typ) {
        .checkout => {
            a.appendSlice(gpa, &.{ "checkout", "-q" }) catch util.oom();
            if (subforce) a.append(gpa, "-f") catch util.oom();
        },
        .rebase => {
            a.append(gpa, "rebase") catch util.oom();
            if (ud.quiet) a.append(gpa, "--quiet") catch util.oom();
        },
        .merge => {
            a.append(gpa, "merge") catch util.oom();
            if (ud.quiet) a.append(gpa, "--quiet") catch util.oom();
        },
        .command => {
            git_cmd = false;
            a.append(gpa, ud.strategy.command.?) catch util.oom();
        },
        else => unreachable,
    }
    a.append(gpa, hx) catch util.oom();
    const r = runCmd(a.items, .{ .cwd = ud.sm_path, .shell = !git_cmd }, git_cmd);
    if (!ok(r)) {
        const ret = code(r);
        switch (ud.strategy.typ) {
            .checkout => {
                _ = dieMessage("Unable to checkout '{s}' in submodule path '{s}'", .{ hx, ud.displaypath });
                return ret;
            },
            .rebase => return dieMessage("Unable to rebase '{s}' in submodule path '{s}'", .{ hx, ud.displaypath }),
            .merge => return dieMessage("Unable to merge '{s}' in submodule path '{s}'", .{ hx, ud.displaypath }),
            .command => return dieMessage("Execution of '{s} {s}' failed in submodule path '{s}'", .{ ud.strategy.command.?, hx, ud.displaypath }),
            else => unreachable,
        }
    }
    if (ud.quiet) return 0;
    switch (ud.strategy.typ) {
        .checkout => util.outf("Submodule path '{s}': checked out '{s}'\n", .{ ud.displaypath, hx }),
        .rebase => util.outf("Submodule path '{s}': rebased into '{s}'\n", .{ ud.displaypath, hx }),
        .merge => util.outf("Submodule path '{s}': merged in '{s}'\n", .{ ud.displaypath, hx }),
        .command => util.outf("Submodule path '{s}': '{s} {s}'\n", .{ ud.displaypath, ud.strategy.command.?, hx }),
        else => unreachable,
    }
    return 0;
}

fn runUpdateProcedure(ud: *const UpdateData) u8 {
    const subforce = hash.isZero(ud.suboid) or ud.force;
    if (!ud.nofetch) {
        if (!isTipReachable(ud.sm_path, ud.oid) and fetchInSubmodule(ud.sm_path, ud.depth, ud.quiet, null) != 0 and !ud.quiet)
            util.eprint("Unable to fetch in submodule path '{s}'; trying to directly fetch {s}:\n", .{ ud.displaypath, hash.hexAlloc(ud.oid) });
        if (!isTipReachable(ud.sm_path, ud.oid) and fetchInSubmodule(ud.sm_path, ud.depth, ud.quiet, ud.oid) != 0)
            return dieMessage("Fetched in submodule path '{s}', but it did not contain {s}. Direct fetching of that commit failed.", .{ ud.displaypath, hash.hexAlloc(ud.oid) });
    }
    return runUpdateCommand(ud, subforce);
}

fn remoteSubmoduleBranch(path: []const u8) union(enum) { ok: []const u8, err: u8 } {
    const sub = submoduleFromPath(path) orelse return .{ .err = dieMessage("could not initialize submodule at path '{s}'", .{path}) };
    const branch = cfgGet(util.concat(&.{ "submodule.", sub.name, ".branch" })) orelse sub.branch orelse return .{ .ok = "HEAD" };
    if (util.eql(branch, ".")) {
        const head = os.readFile(repo_mod.repo().gitPath("HEAD")) orelse return .{ .err = dieMessage("No such ref: {s}", .{"HEAD"}) };
        const ref = util.skipPrefix(head, "ref: ") orelse
            return .{ .err = dieMessage("Submodule ({s}) branch configured to inherit branch from superproject, but the superproject is not on any branch", .{sub.name}) };
        const refname = util.trimRight(ref);
        const b = util.skipPrefix(refname, "refs/heads/") orelse return .{ .err = dieMessage("Expecting a full ref name, got {s}", .{refname}) };
        return .{ .ok = b };
    }
    return .{ .ok = branch };
}

/// ensure_core_worktree()
fn ensureCoreWorktree(path: []const u8) u8 {
    const sr = subrepoConfig(path) orelse return dieMessage("could not get a repository handle for submodule '{s}'", .{path});
    if (sr.cfg.get("core.worktree") != null) {
        const gd = realPath(sr.gitdir);
        const abs = absolutePath(path);
        _ = setConfigInFile(util.concat(&.{ gd, "/config" }), "core.worktree", relativePath(abs, gd));
    }
    return 0;
}

fn determineStrategy(ud: *UpdateData) u8 {
    const sub = submoduleFromPath(ud.sm_path).?;
    if (ud.update_default != .unspecified) {
        ud.strategy = .{ .typ = ud.update_default };
    } else if (cfgGet(util.concat(&.{ "submodule.", sub.name, ".update" }))) |v| {
        ud.strategy = parseUpdateStrategy(v) orelse
            return dieMessage("Invalid update mode '{s}' configured for submodule path '{s}'", .{ v, ud.sm_path });
    } else if (sub.update.typ != .unspecified) {
        ud.strategy = sub.update;
    } else ud.strategy = .{ .typ = .checkout };
    if (ud.just_cloned and (ud.strategy.typ == .merge or ud.strategy.typ == .rebase or ud.strategy.typ == .none))
        ud.strategy = .{ .typ = .checkout };
    return 0;
}

fn updateDataToArgs(ud: *const UpdateData, a: *StrList) void {
    a.appendSlice(gpa, &.{ "submodule--helper", "update", "--recursive" }) catch util.oom();
    a.append(gpa, util.concat(&.{ "--super-prefix=", ud.displaypath, "/" })) catch util.oom();
    a.append(gpa, util.fmt("--jobs={d}", .{ud.max_jobs})) catch util.oom();
    if (ud.quiet) a.append(gpa, "--quiet") catch util.oom();
    if (ud.force) a.append(gpa, "--force") catch util.oom();
    if (ud.init) a.append(gpa, "--init") catch util.oom();
    if (ud.remote) a.append(gpa, "--remote") catch util.oom();
    if (ud.nofetch) a.append(gpa, "--no-fetch") catch util.oom();
    if (ud.dissociate) a.append(gpa, "--dissociate") catch util.oom();
    if (ud.progress) a.append(gpa, "--progress") catch util.oom();
    if (ud.require_init) a.append(gpa, "--require-init") catch util.oom();
    if (ud.depth != 0) a.append(gpa, util.fmt("--depth={d}", .{ud.depth})) catch util.oom();
    switch (ud.update_default) {
        .checkout => a.append(gpa, "--checkout") catch util.oom(),
        .merge => a.append(gpa, "--merge") catch util.oom(),
        .rebase => a.append(gpa, "--rebase") catch util.oom(),
        else => {},
    }
    for (ud.references.items) |r| a.appendSlice(gpa, &.{ "--reference", r }) catch util.oom();
    if (ud.ref_format) |f| a.append(gpa, util.concat(&.{ "--ref-format=", f })) catch util.oom();
    if (ud.filter) |f| a.append(gpa, util.concat(&.{ "--filter=", f })) catch util.oom();
    if (ud.recommend_shallow == 0) a.append(gpa, "--no-recommend-shallow") catch util.oom() else if (ud.recommend_shallow == 1) a.append(gpa, "--recommend-shallow") catch util.oom();
    if (ud.single_branch >= 0) a.append(gpa, if (ud.single_branch > 0) "--single-branch" else "--no-single-branch") catch util.oom();
}

fn updateSubmodule(ud: *UpdateData) u8 {
    if (!validateSubmodulePath(ud.sm_path)) return 255;
    const c1 = determineStrategy(ud);
    if (c1 != 0) return c1;
    if (ud.just_cloned) {
        ud.suboid = hash.zero;
    } else {
        ud.suboid = subHeadOid(ud.sm_path) orelse
            return dieMessage("Unable to find current revision in submodule path '{s}'", .{ud.displaypath});
    }
    if (ud.remote) {
        const remote_name = switch (getDefaultRemoteSubmodule(ud.sm_path)) {
            .ok => |r| r,
            .err => |c| return c,
        };
        const branch = switch (remoteSubmoduleBranch(ud.sm_path)) {
            .ok => |b| b,
            .err => |c| return c,
        };
        const remote_ref = util.concat(&.{ "refs/remotes/", remote_name, "/", branch });
        if (!ud.nofetch) {
            if (fetchInSubmodule(ud.sm_path, ud.depth, false, null) != 0)
                return dieMessage("Unable to fetch in submodule path '{s}'", .{ud.sm_path});
        }
        ud.oid = subResolve(ud.sm_path, remote_ref) orelse
            return dieMessage("Unable to find {s} revision in submodule path '{s}'", .{ remote_ref, ud.sm_path });
    }
    if (!hash.eql(ud.oid, ud.suboid) or ud.force) {
        const r = runUpdateProcedure(ud);
        if (r != 0) return r;
    }
    if (ud.recursive) {
        var a: StrList = .empty;
        updateDataToArgs(ud, &a);
        const r = git(a.items, .{ .cwd = ud.sm_path });
        const rc = code(r);
        if (rc != 0) _ = dieMessage("Failed to recurse into submodule path '{s}'", .{ud.displaypath});
        return rc;
    }
    return 0;
}

fn updateSubmodules(ud: *UpdateData, list: []ListEntry) u8 {
    var tasks: std.ArrayList(CloneTask) = .empty;
    var failed: std.ArrayList(ListEntry) = .empty;
    for (list) |le| {
        const argv = prepareToClone(le, ud, &tasks) orelse continue;
        const r = git(argv, .{ .sub_env = false, .no_stdin = true, .stdout_to_stderr = true });
        if (!ok(r)) {
            util.eprint("Failed to clone '{s}'. Retry scheduled\n", .{le.path});
            failed.append(gpa, le) catch util.oom();
        }
    }
    for (failed.items) |le| {
        const argv = prepareToClone(le, ud, &tasks) orelse {
            util.eprint("BUG: submodule considered for cloning, doesn't need cloning any more?\n", .{});
            continue;
        };
        const r = git(argv, .{ .sub_env = false, .no_stdin = true, .stdout_to_stderr = true });
        if (!ok(r)) {
            util.eprint("Failed to clone '{s}' a second time, aborting\n", .{le.path});
            return 1;
        }
    }
    var ret: u8 = 0;
    for (tasks.items) |t| {
        ud.oid = t.oid;
        ud.just_cloned = t.just_cloned;
        ud.sm_path = t.sub.path.?;
        var rc: u8 = 128;
        if (validateSubmodulePath(ud.sm_path)) {
            rc = ensureCoreWorktree(ud.sm_path);
            if (rc == 0) {
                ud.displaypath = displayPath(ud.sm_path, ud.prefix, ud.super_prefix);
                rc = updateSubmodule(ud);
            }
        }
        if (rc == 0) continue;
        ret = rc;
        if (ret == 128) break;
    }
    return ret;
}

fn cmdUpdate(args: []const []const u8, prefix: []const u8) u8 {
    var ud = UpdateData{ .prefix = prefix };
    var force: i32 = 0;
    var upd: i32 = 0;
    var quiet: i32 = 0;
    const usage = [_][]const u8{"git submodule [--quiet] update [--init [--filter=<filter-spec>]] [--remote] [-N|--no-fetch] [-f|--force] [--checkout|--merge|--rebase] [--[no-]recommend-shallow] [--reference <repository>] [--recursive] [--[no-]single-branch] [--] [<path>...]"};
    // submodule.fetchJobs
    if (cfgGet("submodule.fetchjobs")) |v| ud.max_jobs = @intCast(std.fmt.parseInt(i32, v, 10) catch 1);
    const opts = [_]po.Opt{
        .{ .long = "super-prefix", .kind = .string, .s = &ud.super_prefix, .argh = "path", .hidden = true, .help = "prefixed path to initial superproject" },
        po.counter('f', "force", &force, "force checkout updates"),
        po.boolean('i', "init", &ud.init, "initialize uninitialized submodules before update"),
        po.boolean(0, "remote", &ud.remote, "use SHA-1 of submodule's remote tracking branch"),
        po.boolean(0, "recursive", &ud.recursive, "traverse submodules recursively"),
        po.boolean('N', "no-fetch", &ud.nofetch, "don't fetch new objects from the remote site"),
        po.setInt(0, "checkout", &upd, 1, "use the 'checkout' update strategy (default)"),
        po.setInt('m', "merge", &upd, 2, "use the 'merge' update strategy"),
        po.setInt('r', "rebase", &upd, 3, "use the 'rebase' update strategy"),
        po.list(0, "reference", &ud.references, "repo", "reference repository"),
        po.string(0, "ref-format", &ud.ref_format, "format", "specify the reference format to use"),
        po.boolean(0, "dissociate", &ud.dissociate, "use --reference only while cloning"),
        po.integer(0, "depth", &ud.depth, "n", "create a shallow clone truncated to the specified number of revisions"),
        po.integer('j', "jobs", &ud.max_jobs, "n", "parallel jobs"),
        po.setInt(0, "recommend-shallow", &ud.recommend_shallow, 1, "whether the initial clone should follow the shallow recommendation"),
        po.counter('q', "quiet", &quiet, "don't print cloning progress"),
        po.boolean(0, "progress", &ud.progress, "force cloning progress"),
        po.boolean(0, "require-init", &ud.require_init, "disallow cloning into non-empty directory, implies --init"),
        po.setInt(0, "single-branch", &ud.single_branch, 1, "clone only one branch, HEAD or --branch"),
        po.string(0, "filter", &ud.filter, "args", "object filtering"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    ud.force = force > 0;
    ud.quiet = quiet > 0;
    ud.update_default = switch (upd) {
        1 => .checkout,
        2 => .merge,
        3 => .rebase,
        else => .unspecified,
    };
    if (ud.require_init) ud.init = true;
    if (ud.filter != null and !ud.init) po.usageWithOptions(&usage, &opts);
    if (ud.ref_format) |f| {
        if (!util.eql(f, "files") and !util.eql(f, "reftable")) util.die("unknown ref storage format '{s}'", .{f});
    }
    var ps: pathspec_mod.Pathspec = .{};
    const list = moduleListCompute(rest, prefix, &ps) orelse return 1;
    if (ps.items.len > 0) ud.warn_if_uninitialized = true;
    if (ud.init) {
        var ilist = moduleListCompute(rest, prefix, null) orelse return 1;
        if (rest.len == 0 and cfgHas("submodule.active")) ilist = moduleListActive(ilist);
        for (ilist) |le| initSubmodule(le.path, prefix, ud.super_prefix, ud.quiet);
    }
    return updateSubmodules(&ud, list);
}

// ---------------------------------------------------------------------------
// absorbgitdirs, set-url, set-branch, gitdir, get-default-remote

fn cmdAbsorbGitDirs(args: []const []const u8, prefix: []const u8) u8 {
    var super_prefix: ?[]const u8 = null;
    const usage = [_][]const u8{"git submodule absorbgitdirs [<options>] [<path>...]"};
    const opts = [_]po.Opt{
        .{ .long = "super-prefix", .kind = .string, .s = &super_prefix, .argh = "path", .hidden = true, .help = "prefixed path to initial superproject" },
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    const list = moduleListCompute(rest, prefix, null) orelse return 1;
    for (list) |le| absorbGitDir(le.path, super_prefix);
    return 0;
}

fn cmdSetUrl(args: []const []const u8, prefix: []const u8) u8 {
    var quiet: i32 = 0;
    const usage = [_][]const u8{"git submodule set-url [--quiet] <path> <newurl>"};
    const opts = [_]po.Opt{
        po.counter('q', "quiet", &quiet, "suppress output for setting url of a submodule"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len != 2) po.usageWithOptions(&usage, &opts);
    const sub = submoduleFromPath(rest[0]) orelse util.die("no submodule mapping found in .gitmodules for path '{s}'", .{rest[0]});
    const sub_path = sub.path.?;
    const ret = setInGitmodules(util.concat(&.{ "submodule.", sub.name, ".url" }), rest[1]);
    if (ret == 0) syncSubmodule(sub_path, prefix, null, quiet > 0, false);
    return if (ret != 0) 1 else 0;
}

fn cmdSetBranch(args: []const []const u8, prefix: []const u8) u8 {
    _ = prefix;
    var opt_default = false;
    var opt_branch: ?[]const u8 = null;
    var noop = false;
    const usage = [_][]const u8{
        "git submodule set-branch [-q|--quiet] (-d|--default) <path>",
        "git submodule set-branch [-q|--quiet] (-b|--branch) <branch> <path>",
    };
    const opts = [_]po.Opt{
        .{ .short = 'q', .long = "quiet", .kind = .boolean, .b = &noop, .help = "no-op (backward compatibility)" },
        po.boolean('d', "default", &opt_default, "set the default tracking branch to master"),
        po.string('b', "branch", &opt_branch, "branch", "set the default tracking branch"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (opt_branch == null and !opt_default) util.die("--branch or --default required", .{});
    if (opt_branch != null and opt_default) util.die("options '{s}' and '{s}' cannot be used together", .{ "--branch", "--default" });
    if (rest.len != 1) po.usageWithOptions(&usage, &opts);
    const sub = submoduleFromPath(rest[0]) orelse util.die("no submodule mapping found in .gitmodules for path '{s}'", .{rest[0]});
    const ret = setInGitmodules(util.concat(&.{ "submodule.", sub.name, ".branch" }), opt_branch);
    return if (ret != 0) 1 else 0;
}

fn cmdGitdir(args: []const []const u8) u8 {
    if (args.len != 2) {
        util.eprint("usage: git submodule--helper gitdir <name>\n", .{});
        os.exit(129);
    }
    util.outf("{s}\n", .{nameToGitdir(args[1])});
    return 0;
}

fn cmdGetDefaultRemote(args: []const []const u8, prefix: []const u8) u8 {
    const usage = [_][]const u8{"git submodule--helper get-default-remote <path>"};
    const opts = [_]po.Opt{};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len != 1) po.usageWithOptions(&usage, &opts);
    var path = rest[0];
    if (prefix.len > 0 and !isAbs(path)) path = util.concat(&.{ prefix, path });
    switch (getDefaultRemoteSubmodule(path)) {
        .ok => |r| util.outf("{s}\n", .{r}),
        .err => |c| return c,
    }
    return 0;
}

// ---------------------------------------------------------------------------
// add

const AddData = struct {
    prefix: []const u8 = "",
    branch: ?[]const u8 = null,
    reference_path: ?[]const u8 = null,
    ref_format: ?[]const u8 = null,
    sm_path: []const u8 = "",
    sm_name: []const u8 = "",
    repo: []const u8 = "",
    realrepo: []const u8 = "",
    depth: i32 = -1,
    force: bool = false,
    quiet: bool = false,
    progress: bool = false,
    dissociate: bool = false,
};

/// git_url_basename() (dir.c)
fn gitUrlBasename(repo: []const u8) []const u8 {
    var start: usize = 0;
    var end: usize = repo.len;
    if (std.mem.indexOf(u8, repo, "://")) |i| start = i + 3;
    var p = start;
    while (p < end and repo[p] != '/') : (p += 1) {
        if (repo[p] == '@') start = p + 1;
    }
    while (start < end and (repo[end - 1] == '/' or std.ascii.isWhitespace(repo[end - 1]))) end -= 1;
    if (end - start > 5 and repo[end - 5] == '/' and std.mem.eql(u8, repo[end - 4 .. end], ".git")) {
        end -= 5;
        while (start < end and repo[end - 1] == '/') end -= 1;
    }
    const seg = repo[start..end];
    if (std.mem.indexOfScalar(u8, seg, '/') == null and std.mem.indexOfScalar(u8, seg, ':') != null) {
        var q = end;
        while (start < q and std.ascii.isDigit(repo[q - 1]) and repo[q - 1] != ':') q -= 1;
        if (start < q and repo[q - 1] == ':') end = q - 1;
    }
    var q = end;
    while (start < q and repo[q - 1] != '/' and repo[q - 1] != ':') q -= 1;
    start = q;
    var name = repo[start..end];
    if (util.endsWith(name, ".git")) name = name[0 .. name.len - 4];
    if (name.len == 0 or (name.len == 1 and name[0] == '/'))
        util.die("No directory name could be guessed.\nPlease specify a directory on the command line", .{});
    var out: util.Buf = .empty;
    var prev_space = true;
    for (name) |ch| {
        if (std.ascii.isWhitespace(ch) or ch < 0x20) {
            if (!prev_space) {
                util.bufByte(&out, ' ');
                prev_space = true;
            }
        } else {
            util.bufByte(&out, ch);
            prev_space = false;
        }
    }
    var res = out.items;
    if (res.len > 0 and res[res.len - 1] == ' ') res = res[0 .. res.len - 1];
    return res;
}

fn appendFetchRemotes(msg: *util.Buf, git_dir_path: []const u8) void {
    const r = git(&.{ "remote", "-v" }, .{ .sub_env = false, .capture = true, .extra_env = &.{ .{ "GIT_DIR", git_dir_path }, .{ "GIT_WORK_TREE", "." } } });
    if (!ok(r)) return;
    var it = std.mem.splitScalar(u8, r.stdout, '\n');
    while (it.next()) |line| {
        if (util.endsWith(line, " (fetch)")) {
            util.bufAppend(msg, "  ");
            util.bufAppend(msg, line[0 .. line.len - " (fetch)".len]);
            util.bufAppend(msg, "\n");
        }
    }
}

fn addSubmodule(ad: *const AddData) void {
    if (os.isDir(ad.sm_path)) {
        if (isNonbareRepoDir(ad.sm_path)) {
            util.outf("Adding existing repo at '{s}' to the index\n", .{ad.sm_path});
        } else util.die("'{s}' already exists and is not a valid git repo", .{ad.sm_path});
        return;
    }
    const gd = nameToGitdir(ad.sm_name);
    if (os.isDir(gd)) {
        if (!ad.force) {
            var msg: util.Buf = .empty;
            util.bufAppend(&msg, util.fmt("A git directory for '{s}' is found locally with remote(s):\n", .{ad.sm_name}));
            appendFetchRemotes(&msg, gd);
            util.bufAppend(&msg, util.fmt("If you want to reuse this local git directory instead of cloning again from\n  {s}\nuse the '--force' option. If the local git directory is not the correct repo\nor you are unsure what this means choose another name with the '--name' option.", .{ad.realrepo}));
            util.die("{s}", .{msg.items});
        } else util.outf("Reactivating local git directory for submodule '{s}'\n", .{ad.sm_name});
    }
    var cd = CloneData{
        .prefix = ad.prefix,
        .path = ad.sm_path,
        .name = ad.sm_name,
        .url = ad.realrepo,
        .quiet = ad.quiet,
        .progress = ad.progress,
        .ref_format = ad.ref_format,
        .dissociate = ad.dissociate,
    };
    if (ad.depth >= 0) cd.depth = ad.depth;
    var refs: StrList = .empty;
    if (ad.reference_path) |r| refs.append(gpa, r) catch util.oom();
    cloneSubmodule(&cd, refs.items);
    var a: StrList = .empty;
    a.appendSlice(gpa, &.{ "checkout", "-f", "-q" }) catch util.oom();
    if (ad.branch) |b| a.appendSlice(gpa, &.{ "-B", b, util.concat(&.{ "origin/", b }) }) catch util.oom();
    if (!ok(git(a.items, .{ .cwd = ad.sm_path }))) util.die("unable to checkout submodule '{s}'", .{ad.sm_path});
}

fn configSubmoduleInGitmodules(name: []const u8, item: []const u8, value: []const u8) i32 {
    if (!isWritingGitmodulesOk()) util.die("please make sure that the .gitmodules file is in the working tree", .{});
    return setInGitmodules(util.concat(&.{ "submodule.", name, ".", item }), value);
}

fn configureAddedSubmodule(ad: *const AddData) void {
    _ = setRepoConfig(util.concat(&.{ "submodule.", ad.sm_name, ".url" }), ad.realrepo);
    var a: StrList = .empty;
    a.appendSlice(gpa, &.{ "add", "--no-warn-embedded-repo" }) catch util.oom();
    if (ad.force) a.append(gpa, "--force") catch util.oom();
    a.appendSlice(gpa, &.{ "--", ad.sm_path }) catch util.oom();
    if (!ok(git(a.items, .{ .sub_env = false }))) util.die("Failed to add submodule '{s}'", .{ad.sm_path});
    if (configSubmoduleInGitmodules(ad.sm_name, "path", ad.sm_path) != 0 or
        configSubmoduleInGitmodules(ad.sm_name, "url", ad.repo) != 0)
        util.die("Failed to register submodule '{s}'", .{ad.sm_path});
    if (ad.branch) |b| {
        if (configSubmoduleInGitmodules(ad.sm_name, "branch", b) != 0)
            util.die("Failed to register submodule '{s}'", .{ad.sm_path});
    }
    if (!ok(git(&.{ "add", "--force", "--", ".gitmodules" }, .{ .sub_env = false })))
        util.die("Failed to register submodule '{s}'", .{ad.sm_path});
    const pats = repo_mod.cfg.getAll("submodule.active");
    var matched = false;
    for (pats) |pat| {
        if (wildmatch.match(pat, ad.sm_path, 0)) {
            matched = true;
            break;
        }
    }
    if (!matched) _ = setRepoConfig(util.concat(&.{ "submodule.", ad.sm_name, ".active" }), "true");
}

fn dieOnIndexMatch(path: []const u8, force: bool) void {
    const ps = pathspec_mod.parse("", &.{path}, .{ .prefer_cwd = true });
    if (ps.items.len == 0) return;
    const seen = ps.newSeen();
    const idx = index_mod.get();
    for (idx.entries.items) |*e| {
        if (e.removed) continue;
        _ = ps.matchSeen(e.path, isGitlink(e.mode), seen);
        if (seen[0] != 0) {
            if (!force) util.die("'{s}' already exists in the index", .{path});
            if (!isGitlink(e.mode)) util.die("'{s}' already exists in the index and is not a submodule", .{path});
            break;
        }
    }
}

fn cmdAdd(args: []const []const u8, prefix: []const u8) u8 {
    var ad = AddData{};
    var force: i32 = 0;
    var quiet: i32 = 0;
    var name: ?[]const u8 = null;
    const usage = [_][]const u8{"git submodule add [<options>] [--] <repository> [<path>]"};
    const opts = [_]po.Opt{
        po.string('b', "branch", &ad.branch, "branch", "branch of repository to add as submodule"),
        po.counter('f', "force", &force, "allow adding an otherwise ignored submodule path"),
        po.counter('q', "quiet", &quiet, "print only error messages"),
        po.boolean(0, "progress", &ad.progress, "force cloning progress"),
        po.string(0, "reference", &ad.reference_path, "repository", "reference repository"),
        po.string(0, "ref-format", &ad.ref_format, "format", "specify the reference format to use"),
        po.boolean(0, "dissociate", &ad.dissociate, "borrow the objects from reference repositories"),
        po.string(0, "name", &name, "name", "sets the submodule's name to the given string instead of defaulting to its path"),
        po.integer(0, "depth", &ad.depth, "n", "depth for shallow clones"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (!isWritingGitmodulesOk()) util.die("please make sure that the .gitmodules file is in the working tree", .{});
    if (prefix.len > 0) {
        if (ad.reference_path) |r| {
            if (!isAbs(r)) ad.reference_path = util.concat(&.{ prefix, r });
        }
    }
    if (rest.len == 0 or rest.len > 2) po.usageWithOptions(&usage, &opts);
    if (ad.ref_format) |f| {
        if (!util.eql(f, "files") and !util.eql(f, "reftable")) util.die("unknown ref storage format '{s}'", .{f});
    }
    ad.repo = rest[0];
    var sm_path: []const u8 = if (rest.len == 1) gitUrlBasename(ad.repo) else rest[1];
    if (prefix.len > 0 and !isAbs(sm_path)) sm_path = util.concat(&.{ prefix, sm_path });

    if (startsWithDotDotSlash(ad.repo) or startsWithDotSlash(ad.repo)) {
        if (prefix.len > 0) util.die("Relative path can only be used from the toplevel of the working tree", .{});
        ad.realrepo = resolveRelativeUrl(ad.repo, null, true);
    } else if ((ad.repo.len > 0 and ad.repo[0] == '/') or std.mem.indexOfScalar(u8, ad.repo, ':') != null) {
        ad.realrepo = ad.repo;
    } else util.die("repo URL: '{s}' must be absolute or begin with ./|../", .{ad.repo});

    // normalize_path_copy + strip_dir_trailing_slashes
    sm_path = normalizePathCopy(sm_path) orelse sm_path;
    while (sm_path.len > 1 and sm_path[sm_path.len - 1] == '/') sm_path = sm_path[0 .. sm_path.len - 1];
    ad.sm_path = sm_path;
    if (!validateSubmodulePath(ad.sm_path)) os.exit(128);
    dieOnIndexMatch(ad.sm_path, force > 0);
    if (isNonbareRepoDir(ad.sm_path)) {
        if (subHeadOid(ad.sm_path) == null) util.die("'{s}' does not have a commit checked out", .{ad.sm_path});
    }
    if (force == 0) {
        const r = git(&.{ "add", "--dry-run", "--ignore-missing", "--no-warn-embedded-repo", ad.sm_path }, .{ .sub_env = false, .capture = true });
        if (!ok(r)) return code(r);
    }
    ad.sm_name = name orelse ad.sm_path;
    if (submoduleFromName(ad.sm_name)) |existing| {
        if (existing.path) |ep| {
            if (!util.eql(ep, ad.sm_path)) {
                if (force == 0) util.die("submodule name '{s}' already used for path '{s}'", .{ ad.sm_name, ep });
                var i: usize = 1;
                while (true) : (i += 1) {
                    const cand = util.fmt("{s}{d}", .{ ad.sm_name, i });
                    if (submoduleFromName(cand) == null) {
                        ad.sm_name = cand;
                        break;
                    }
                }
            }
        }
    }
    if (!checkSubmoduleName(ad.sm_name)) util.die("'{s}' is not a valid submodule name", .{ad.sm_name});
    ad.prefix = prefix;
    ad.force = force > 0;
    ad.quiet = quiet > 0;
    addSubmodule(&ad);
    configureAddedSubmodule(&ad);
    return 0;
}

/// normalize_path_copy(): collapse "//", "./" and "dir/.."; null if the
/// path escapes above its root. Keeps a trailing slash.
fn normalizePathCopy(src: []const u8) ?[]const u8 {
    var out: util.Buf = .empty;
    var i: usize = 0;
    if (src.len > 0 and src[0] == '/') {
        util.bufByte(&out, '/');
        i = 1;
    }
    const root_len = out.items.len;
    while (i < src.len) {
        while (i < src.len and src[i] == '/') i += 1;
        if (i >= src.len) break;
        var j = i;
        while (j < src.len and src[j] != '/') j += 1;
        const comp = src[i..j];
        const has_slash = j < src.len;
        if (util.eql(comp, ".")) {
            i = j + @intFromBool(has_slash);
            continue;
        }
        if (util.eql(comp, "..")) {
            if (out.items.len <= root_len) return null;
            // drop last component
            var k = out.items.len - 1; // trailing '/' or end of component
            if (out.items[k] == '/') {
                if (k == 0) return null;
                k -= 1;
            }
            while (k > root_len and out.items[k - 1] != '/') k -= 1;
            out.items.len = k;
            i = j + @intFromBool(has_slash);
            continue;
        }
        util.bufAppend(&out, comp);
        if (has_slash) util.bufByte(&out, '/');
        i = j + @intFromBool(has_slash);
    }
    return out.items;
}

// ---------------------------------------------------------------------------
// submodule--helper dispatcher

fn dispatchHelper(args: []const []const u8, prefix: []const u8) u8 {
    const sub = args[0];
    if (util.eql(sub, "clone")) return cmdClone(args, prefix);
    if (util.eql(sub, "add")) return cmdAdd(args, prefix);
    if (util.eql(sub, "update")) return cmdUpdate(args, prefix);
    if (util.eql(sub, "foreach")) return cmdForeach(args, prefix);
    if (util.eql(sub, "init")) return cmdInit(args, prefix);
    if (util.eql(sub, "status")) return cmdStatus(args, prefix);
    if (util.eql(sub, "sync")) return cmdSync(args, prefix);
    if (util.eql(sub, "deinit")) return cmdDeinit(args, prefix);
    if (util.eql(sub, "summary")) return cmdSummary(args, prefix);
    if (util.eql(sub, "absorbgitdirs")) return cmdAbsorbGitDirs(args, prefix);
    if (util.eql(sub, "set-url")) return cmdSetUrl(args, prefix);
    if (util.eql(sub, "set-branch")) return cmdSetBranch(args, prefix);
    if (util.eql(sub, "gitdir")) return cmdGitdir(args);
    if (util.eql(sub, "get-default-remote")) return cmdGetDefaultRemote(args, prefix);
    return 255;
}

const helper_usage = [_][]const u8{"git submodule--helper <command>"};

pub fn cmdSubmoduleHelper(args: []const []const u8) u8 {
    const opts = [_]po.Opt{};
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&helper_usage, &opts);
    }
    const sub = args[1];
    if (util.eql(sub, "-h")) po.usageExit(&helper_usage, &opts, false);
    const r = dispatchHelper(args[1..], repo_mod.repo().prefix);
    if (r == 255 and !isKnownHelper(sub)) {
        if (sub.len > 0 and sub[0] == '-') {
            util.err("unknown option `{s}'", .{std.mem.trimStart(u8, sub, "-")});
        } else util.err("unknown subcommand: `{s}'", .{sub});
        po.usageWithOptions(&helper_usage, &opts);
    }
    return r;
}

fn isKnownHelper(s: []const u8) bool {
    const known = [_][]const u8{ "clone", "add", "update", "foreach", "init", "status", "sync", "deinit", "summary", "absorbgitdirs", "set-url", "set-branch", "gitdir", "get-default-remote" };
    for (known) |k| {
        if (util.eql(k, s)) return true;
    }
    return false;
}

// ---------------------------------------------------------------------------
// git submodule (git-submodule.sh)

const sh_usage =
    "usage: git submodule [--quiet] [--cached]\n" ++
    "   or: git submodule [--quiet] add [-b <branch>] [-f|--force] [--name <name>] [--reference <repository>] [--] <repository> [<path>]\n" ++
    "   or: git submodule [--quiet] status [--cached] [--recursive] [--] [<path>...]\n" ++
    "   or: git submodule [--quiet] init [--] [<path>...]\n" ++
    "   or: git submodule [--quiet] deinit [-f|--force] (--all| [--] <path>...)\n" ++
    "   or: git submodule [--quiet] update [--init [--filter=<filter-spec>]] [--remote] [-N|--no-fetch] [-f|--force] [--checkout|--merge|--rebase] [--[no-]recommend-shallow] [--reference <repository>] [--recursive] [--[no-]single-branch] [--] [<path>...]\n" ++
    "   or: git submodule [--quiet] set-branch (--default|--branch <branch>) [--] <path>\n" ++
    "   or: git submodule [--quiet] set-url [--] <path> <newurl>\n" ++
    "   or: git submodule [--quiet] summary [--cached|--files] [--summary-limit <n>] [commit] [--] [<path>...]\n" ++
    "   or: git submodule [--quiet] foreach [--recursive] <command>\n" ++
    "   or: git submodule [--quiet] sync [--recursive] [--] [<path>...]\n" ++
    "   or: git submodule [--quiet] absorbgitdirs [--] [<path>...]\n";

fn shUsage() noreturn {
    util.eprint("{s}", .{sh_usage});
    os.exit(1);
}

const ShState = struct {
    quiet: ?[]const u8 = null,
    cached: ?[]const u8 = null,
};

fn isOneOf(a: []const u8, list: []const []const u8) bool {
    for (list) |x| {
        if (util.eql(a, x)) return true;
    }
    return false;
}

/// Parse "$1" "$2" for options with a separate value: returns the value
/// and advances. Dies with usage if the value is empty or missing.
fn shValue(args: []const []const u8, i: *usize) []const u8 {
    if (i.* + 1 >= args.len or args[i.* + 1].len == 0) shUsage();
    i.* += 1;
    return args[i.*];
}

fn runHelper(cmd: []const u8, flags: []const []const u8, rest: []const []const u8) u8 {
    var a: StrList = .empty;
    a.append(gpa, cmd) catch util.oom();
    a.appendSlice(gpa, flags) catch util.oom();
    a.append(gpa, "--") catch util.oom();
    a.appendSlice(gpa, rest) catch util.oom();
    return dispatchHelper(a.items, repo_mod.repo().prefix);
}

fn shAdd(st: *ShState, args: []const []const u8) u8 {
    var quiet = st.quiet;
    var force: ?[]const u8 = null;
    var progress: ?[]const u8 = null;
    var branch: ?[]const u8 = null;
    var reference: ?[]const u8 = null;
    var ref_format: ?[]const u8 = null;
    var dissociate: ?[]const u8 = null;
    var name: ?[]const u8 = null;
    var depth: ?[]const u8 = null;
    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (util.eql(a, "-b") or util.eql(a, "--branch")) {
            branch = util.concat(&.{ "--branch=", shValue(args, &i) });
        } else if (util.startsWith(a, "-b") or util.startsWith(a, "--branch=")) {
            branch = a;
        } else if (util.eql(a, "-f") or util.eql(a, "--force")) {
            force = a;
        } else if (util.eql(a, "-q") or util.eql(a, "--quiet")) {
            quiet = a;
        } else if (util.eql(a, "--progress")) {
            progress = a;
        } else if (util.eql(a, "--reference")) {
            reference = util.concat(&.{ "--reference=", shValue(args, &i) });
        } else if (util.startsWith(a, "--reference=")) {
            reference = a;
        } else if (util.eql(a, "--ref-format")) {
            ref_format = util.concat(&.{ "--ref-format=", shValue(args, &i) });
        } else if (util.startsWith(a, "--ref-format=")) {
            ref_format = a;
        } else if (util.eql(a, "--dissociate")) {
            dissociate = a;
        } else if (util.eql(a, "--name")) {
            name = util.concat(&.{ "--name=", shValue(args, &i) });
        } else if (util.startsWith(a, "--name=")) {
            name = a;
        } else if (util.eql(a, "--depth")) {
            depth = util.concat(&.{ "--depth=", shValue(args, &i) });
        } else if (util.startsWith(a, "--depth=")) {
            depth = a;
        } else if (util.eql(a, "--")) {
            i += 1;
            break;
        } else if (a.len > 0 and a[0] == '-') {
            shUsage();
        } else break;
    }
    const rest = args[@min(i, args.len)..];
    if (rest.len == 0 or rest[0].len == 0) shUsage();
    var f: StrList = .empty;
    for ([_]?[]const u8{ quiet, force, progress, branch, reference, ref_format, dissociate, name, depth }) |x| {
        if (x) |v| f.append(gpa, v) catch util.oom();
    }
    return runHelper("add", f.items, rest);
}

/// Generic parser for the simple subcommands: `flags` are accepted as-is,
/// returns the index of the first non-option argument.
fn shSimple(args: []const []const u8, flags: []const []const u8, out: *StrList, allow_dashdash: bool) usize {
    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (isOneOf(a, flags)) {
            out.append(gpa, a) catch util.oom();
        } else if (allow_dashdash and util.eql(a, "--")) {
            return i + 1;
        } else if (a.len > 0 and a[0] == '-') {
            shUsage();
        } else break;
    }
    return i;
}

fn dedupFlags(st: *ShState, l: []const []const u8, quiet_names: []const []const u8) StrList {
    // shell variables hold only the last value given; emulate by keeping
    // each distinct option once, with quiet taken from global state
    var out: StrList = .empty;
    var have_quiet = st.quiet != null;
    for (l) |x| {
        if (isOneOf(x, quiet_names)) {
            have_quiet = true;
            continue;
        }
        var dup = false;
        for (out.items) |y| {
            if (util.eql(x, y)) dup = true;
        }
        if (!dup) out.append(gpa, x) catch util.oom();
    }
    if (have_quiet) out.insert(gpa, 0, "--quiet") catch util.oom();
    return out;
}

fn shForeach(st: *ShState, args: []const []const u8) u8 {
    var l: StrList = .empty;
    const i = shSimple(args, &.{ "-q", "--quiet", "--recursive" }, &l, false);
    const f = dedupFlags(st, l.items, &.{ "-q", "--quiet" });
    return runHelper("foreach", f.items, args[i..]);
}

fn shInit(st: *ShState, args: []const []const u8) u8 {
    var l: StrList = .empty;
    const i = shSimple(args, &.{ "-q", "--quiet" }, &l, true);
    const f = dedupFlags(st, l.items, &.{ "-q", "--quiet" });
    return runHelper("init", f.items, args[i..]);
}

fn shDeinit(st: *ShState, args: []const []const u8) u8 {
    var l: StrList = .empty;
    const i = shSimple(args, &.{ "-f", "--force", "-q", "--quiet", "--all" }, &l, true);
    var norm: StrList = .empty;
    for (l.items) |x| norm.append(gpa, if (util.eql(x, "-f")) "--force" else x) catch util.oom();
    const f = dedupFlags(st, norm.items, &.{ "-q", "--quiet" });
    return runHelper("deinit", f.items, args[i..]);
}

fn shUpdate(st: *ShState, args: []const []const u8) u8 {
    var quiet = st.quiet;
    var f: StrList = .empty;
    var vals = std.StringHashMap([]const u8).init(gpa);
    var order: StrList = .empty;
    const setv = struct {
        fn put(m: *std.StringHashMap([]const u8), o: *StrList, k: []const u8, v: []const u8) void {
            if (!m.contains(k)) o.append(gpa, k) catch util.oom();
            m.put(k, v) catch util.oom();
        }
    }.put;
    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (util.eql(a, "-q") or util.eql(a, "--quiet")) {
            quiet = a;
        } else if (util.eql(a, "-v") or util.eql(a, "--verbose")) {
            quiet = null;
        } else if (util.eql(a, "--progress")) {
            setv(&vals, &order, "progress", a);
        } else if (util.eql(a, "-i") or util.eql(a, "--init")) {
            setv(&vals, &order, "init", a);
        } else if (util.eql(a, "--require-init")) {
            setv(&vals, &order, "require_init", a);
        } else if (util.eql(a, "--remote")) {
            setv(&vals, &order, "remote", a);
        } else if (util.eql(a, "-N") or util.eql(a, "--no-fetch")) {
            setv(&vals, &order, "no_fetch", a);
        } else if (util.eql(a, "-f") or util.eql(a, "--force")) {
            setv(&vals, &order, "force", a);
        } else if (util.eql(a, "-r") or util.eql(a, "--rebase")) {
            setv(&vals, &order, "rebase", a);
        } else if (util.eql(a, "--ref-format")) {
            setv(&vals, &order, "ref_format", util.concat(&.{ "--ref-format=", shValue(args, &i) }));
        } else if (util.startsWith(a, "--ref-format=")) {
            setv(&vals, &order, "ref_format", a);
        } else if (util.eql(a, "--reference")) {
            setv(&vals, &order, "reference", util.concat(&.{ "--reference=", shValue(args, &i) }));
        } else if (util.startsWith(a, "--reference=")) {
            setv(&vals, &order, "reference", a);
        } else if (util.eql(a, "--dissociate")) {
            setv(&vals, &order, "dissociate", a);
        } else if (util.eql(a, "-m") or util.eql(a, "--merge")) {
            setv(&vals, &order, "merge", a);
        } else if (util.eql(a, "--recursive")) {
            setv(&vals, &order, "recursive", a);
        } else if (util.eql(a, "--checkout")) {
            setv(&vals, &order, "checkout", a);
        } else if (util.eql(a, "--recommend-shallow") or util.eql(a, "--no-recommend-shallow")) {
            setv(&vals, &order, "recommend_shallow", a);
        } else if (util.eql(a, "--depth")) {
            setv(&vals, &order, "depth", util.concat(&.{ "--depth=", shValue(args, &i) }));
        } else if (util.startsWith(a, "--depth=")) {
            setv(&vals, &order, "depth", a);
        } else if (util.eql(a, "-j") or util.eql(a, "--jobs")) {
            setv(&vals, &order, "jobs", util.concat(&.{ "--jobs=", shValue(args, &i) }));
        } else if (util.startsWith(a, "-j") or util.startsWith(a, "--jobs=")) {
            setv(&vals, &order, "jobs", a);
        } else if (util.eql(a, "--single-branch") or util.eql(a, "--no-single-branch")) {
            setv(&vals, &order, "single_branch", a);
        } else if (util.eql(a, "--filter")) {
            setv(&vals, &order, "filter", util.concat(&.{ "--filter=", shValue(args, &i) }));
        } else if (util.startsWith(a, "--filter=")) {
            setv(&vals, &order, "filter", a);
        } else if (util.eql(a, "--")) {
            i += 1;
            break;
        } else if (a.len > 0 and a[0] == '-') {
            shUsage();
        } else break;
    }
    if (quiet) |q| f.append(gpa, q) catch util.oom();
    const fixed = [_][]const u8{ "force", "progress", "remote", "recursive", "init", "no_fetch", "rebase", "merge", "checkout", "ref_format", "reference", "dissociate", "depth", "require_init", "single_branch", "recommend_shallow", "jobs", "filter" };
    for (fixed) |k| {
        if (vals.get(k)) |v| f.append(gpa, v) catch util.oom();
    }
    return runHelper("update", f.items, args[@min(i, args.len)..]);
}

fn shSetBranch(st: *ShState, args: []const []const u8) u8 {
    var branch: ?[]const u8 = null;
    var default: ?[]const u8 = null;
    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (util.eql(a, "-q") or util.eql(a, "--quiet")) {
            // accepted, nothing to do
        } else if (util.eql(a, "-d") or util.eql(a, "--default")) {
            default = a;
        } else if (util.eql(a, "-b") or util.eql(a, "--branch")) {
            branch = util.concat(&.{ "--branch=", shValue(args, &i) });
        } else if (util.startsWith(a, "-b") or util.startsWith(a, "--branch=")) {
            branch = a;
        } else if (util.eql(a, "--")) {
            i += 1;
            break;
        } else if (a.len > 0 and a[0] == '-') {
            shUsage();
        } else break;
    }
    var f: StrList = .empty;
    if (st.quiet) |q| f.append(gpa, q) catch util.oom();
    if (branch) |b| f.append(gpa, b) catch util.oom();
    if (default) |d| f.append(gpa, d) catch util.oom();
    return runHelper("set-branch", f.items, args[@min(i, args.len)..]);
}

fn shSetUrl(st: *ShState, args: []const []const u8) u8 {
    var l: StrList = .empty;
    const i = shSimple(args, &.{ "-q", "--quiet" }, &l, true);
    const f = dedupFlags(st, l.items, &.{ "-q", "--quiet" });
    return runHelper("set-url", f.items, args[i..]);
}

fn shSummary(st: *ShState, args: []const []const u8) u8 {
    var cached = st.cached;
    var files: ?[]const u8 = null;
    var for_status: ?[]const u8 = null;
    var limit: ?[]const u8 = null;
    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (util.eql(a, "--cached")) {
            cached = a;
        } else if (util.eql(a, "--files")) {
            files = a;
        } else if (util.eql(a, "--for-status")) {
            for_status = a;
        } else if (util.eql(a, "-n") or util.eql(a, "--summary-limit")) {
            limit = util.concat(&.{ "--summary-limit=", shValue(args, &i) });
        } else if (util.startsWith(a, "-n") or util.startsWith(a, "--summary-limit=")) {
            limit = a;
        } else if (util.eql(a, "--")) {
            i += 1;
            break;
        } else if (a.len > 0 and a[0] == '-') {
            shUsage();
        } else break;
    }
    var f: StrList = .empty;
    for ([_]?[]const u8{ files, cached, for_status, limit }) |x| {
        if (x) |v| f.append(gpa, v) catch util.oom();
    }
    return runHelper("summary", f.items, args[@min(i, args.len)..]);
}

fn shStatus(st: *ShState, args: []const []const u8) u8 {
    var quiet = st.quiet;
    var cached = st.cached;
    var recursive: ?[]const u8 = null;
    var i: usize = 0;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (util.eql(a, "-q") or util.eql(a, "--quiet")) {
            quiet = a;
        } else if (util.eql(a, "--cached")) {
            cached = a;
        } else if (util.eql(a, "--recursive")) {
            recursive = a;
        } else if (util.eql(a, "--")) {
            i += 1;
            break;
        } else if (a.len > 0 and a[0] == '-') {
            shUsage();
        } else break;
    }
    var f: StrList = .empty;
    for ([_]?[]const u8{ quiet, cached, recursive }) |x| {
        if (x) |v| f.append(gpa, v) catch util.oom();
    }
    return runHelper("status", f.items, args[@min(i, args.len)..]);
}

fn shSync(st: *ShState, args: []const []const u8) u8 {
    var l: StrList = .empty;
    const i = shSimple(args, &.{ "-q", "--quiet", "--recursive" }, &l, true);
    const f = dedupFlags(st, l.items, &.{ "-q", "--quiet" });
    return runHelper("sync", f.items, args[i..]);
}

pub fn cmdSubmodule(args: []const []const u8) u8 {
    if (args.len >= 2 and util.eql(args[1], "-h")) {
        util.out(sh_usage);
        return 0;
    }
    var st = ShState{};
    var command: ?[]const u8 = null;
    const cmds = [_][]const u8{ "add", "foreach", "init", "deinit", "update", "set-branch", "set-url", "status", "summary", "sync", "absorbgitdirs" };
    var i: usize = 1;
    while (i < args.len and command == null) {
        const a = args[i];
        if (isOneOf(a, &cmds)) {
            command = a;
        } else if (util.eql(a, "-q") or util.eql(a, "--quiet")) {
            st.quiet = a;
        } else if (util.eql(a, "--cached")) {
            st.cached = a;
        } else if (util.eql(a, "--")) {
            break;
        } else if (a.len > 0 and a[0] == '-') {
            shUsage();
        } else break;
        i += 1;
    }
    const rest = args[i..];
    if (command == null) {
        if (rest.len == 0) command = "status" else shUsage();
    }
    const c = command.?;
    if (st.cached != null and !util.eql(c, "status") and !util.eql(c, "summary")) shUsage();
    if (util.eql(c, "add")) return shAdd(&st, rest);
    if (util.eql(c, "foreach")) return shForeach(&st, rest);
    if (util.eql(c, "init")) return shInit(&st, rest);
    if (util.eql(c, "deinit")) return shDeinit(&st, rest);
    if (util.eql(c, "update")) return shUpdate(&st, rest);
    if (util.eql(c, "set-branch")) return shSetBranch(&st, rest);
    if (util.eql(c, "set-url")) return shSetUrl(&st, rest);
    if (util.eql(c, "summary")) return shSummary(&st, rest);
    if (util.eql(c, "status")) return shStatus(&st, rest);
    if (util.eql(c, "sync")) return shSync(&st, rest);
    // absorbgitdirs passes its arguments straight through
    var a: StrList = .empty;
    a.append(gpa, "absorbgitdirs") catch util.oom();
    a.appendSlice(gpa, rest) catch util.oom();
    return dispatchHelper(a.items, repo_mod.repo().prefix);
}
