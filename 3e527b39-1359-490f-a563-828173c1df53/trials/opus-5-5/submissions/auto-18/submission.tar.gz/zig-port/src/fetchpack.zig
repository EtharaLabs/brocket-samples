//! Client side of the pack fetch protocol (subset of fetch-pack.c):
//! negotiate with upload-pack (v0 or v2) and store the received pack via
//! index-pack / unpack-objects subprocesses.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const hash = @import("hash.zig");
const pkt = @import("pktline.zig");
const proc = @import("proc.zig");
const objects = @import("objects.zig");
const transport = @import("transport.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Transport = transport.Transport;
const Ref = transport.Ref;

const MAX_HAVES: usize = 4096;

fn unpackLimit() u32 {
    const cfg = repo_mod.cfg;
    if (cfg.get("fetch.unpacklimit")) |v| {
        if (util.parseInt(u32, v)) |n| return n;
    }
    if (cfg.get("transfer.unpacklimit")) |v| {
        if (util.parseInt(u32, v)) |n| return n;
    }
    return 100;
}

const HeapItem = struct { oid: Oid, time: i64 };

fn heapLess(_: void, a: HeapItem, b: HeapItem) std.math.Order {
    return std.math.order(b.time, a.time);
}

/// Collect "have" commits: walk local refs by commit date.
fn collectHaves() []Oid {
    var out: std.ArrayList(Oid) = .empty;
    var seen: hash.OidSet = .empty;
    var pq = std.PriorityQueue(HeapItem, void, heapLess).initContext({});
    const tips = refs.iterate("", .{ .check_objects = false });
    for (tips) |r| {
        const c_oid = objects.peelTo(r.oid, .commit) orelse continue;
        if (seen.contains(c_oid)) continue;
        seen.put(gpa, c_oid, {}) catch util.oom();
        const cm = objects.readCommit(c_oid) orelse continue;
        pq.push(gpa, .{ .oid = c_oid, .time = cm.commitTime() }) catch util.oom();
    }
    while (pq.pop()) |it| {
        if (out.items.len >= MAX_HAVES) break;
        out.append(gpa, it.oid) catch util.oom();
        const cm = objects.readCommit(it.oid) orelse continue;
        for (cm.parents) |p| {
            if (seen.contains(p)) continue;
            seen.put(gpa, p, {}) catch util.oom();
            const pc = objects.readCommit(p) orelse continue;
            pq.push(gpa, .{ .oid = p, .time = pc.commitTime() }) catch util.oom();
        }
    }
    return out.items;
}

/// Pack data source: either sideband-demuxed or raw from the reader.
const PackSource = struct {
    rd: *pkt.Reader,
    sideband: bool,
    demux: pkt.Demux = .{},
    ended: bool = false,
    pending: []const u8 = &.{},
    pending_buf: util.Buf = .empty,

    /// Returns next chunk of pack data, or null at end.
    fn next(self: *PackSource) ?[]const u8 {
        if (self.ended) return null;
        if (!self.sideband) {
            var buf: [65536]u8 = undefined;
            const n = self.rd.readRaw(&buf);
            if (n == 0) {
                self.ended = true;
                return null;
            }
            self.pending_buf.clearRetainingCapacity();
            util.bufAppend(&self.pending_buf, buf[0..n]);
            return self.pending_buf.items;
        }
        while (true) {
            _ = self.rd.read();
            switch (self.demux.handle(self.rd, "fetch-pack")) {
                .data => |d| return d,
                .consumed => {},
                .end => {
                    self.ended = true;
                    return null;
                },
            }
        }
    }
};

pub const Options = struct {
    quiet: bool = false,
    no_progress: bool = true,
    thin: bool = true,
    include_tag: bool = false,
    keep_pack: bool = false,
};

fn receivePack(src: *PackSource, o: Options) void {
    // read the pack header (12 bytes)
    var head: util.Buf = .empty;
    while (head.items.len < 12) {
        const d = src.next() orelse util.die("protocol error: bad pack header", .{});
        util.bufAppend(&head, d);
    }
    if (!std.mem.eql(u8, head.items[0..4], "PACK")) util.die("protocol error: bad pack header", .{});
    const nr = std.mem.readInt(u32, head.items[8..12], .big);
    const limit = unpackLimit();
    var do_keep = o.keep_pack;
    if (!o.keep_pack and limit != 0) do_keep = nr >= limit;
    var args: std.ArrayList([]const u8) = .empty;
    const cmd_name: []const u8 = if (do_keep) "index-pack" else "unpack-objects";
    if (do_keep) {
        args.appendSlice(gpa, &.{ "index-pack", "--stdin" }) catch util.oom();
        if (!o.quiet and !o.no_progress) args.append(gpa, "-v") catch util.oom();
        if (o.thin) args.append(gpa, "--fix-thin") catch util.oom();
    } else {
        args.append(gpa, "unpack-objects") catch util.oom();
        if (o.quiet or o.no_progress) args.append(gpa, "-q") catch util.oom();
    }
    proc.ignoreSigpipe();
    var ch = proc.spawnGit(args.items, .{ .pipe_in = true, .pipe_out = do_keep });
    var write_ok = true;
    os.writeAll(ch.in, head.items) catch {
        write_ok = false;
    };
    while (src.next()) |d| {
        if (write_ok) os.writeAll(ch.in, d) catch {
            write_ok = false;
        };
    }
    proc.closeFd(&ch.in);
    if (do_keep) {
        // drain "pack\t<hash>" output
        var buf: [4096]u8 = undefined;
        while (true) {
            const n = std.c.read(ch.out, &buf, buf.len);
            if (n <= 0) break;
        }
        proc.closeFd(&ch.out);
    }
    const rc = proc.wait(ch.pid);
    if (rc != 0) util.die("{s} failed", .{cmd_name});
    repo_mod.repo().odb().reloadPacks();
}

fn computeWants(sought: []const *Ref) []Oid {
    var wants: std.ArrayList(Oid) = .empty;
    var seen: hash.OidSet = .empty;
    const odb = repo_mod.repo().odb();
    for (sought) |r| {
        if (seen.contains(r.old_oid)) continue;
        seen.put(gpa, r.old_oid, {}) catch util.oom();
        if (odb.has(r.old_oid)) continue;
        wants.append(gpa, r.old_oid) catch util.oom();
    }
    return wants.items;
}

/// Fetch the objects for `sought` refs over the (already connected) transport.
pub fn fetchPack(t: *Transport, sought: []const *Ref, o: Options) void {
    if (t.child == null) transport.connect(t, false);
    if (t.version == 2) return fetchV2(t, sought, o);
    return fetchV0(t, sought, o);
}

fn fetchV0(t: *Transport, sought: []const *Ref, o: Options) void {
    const wants = computeWants(sought);
    if (wants.len == 0) {
        _ = transport.disconnect(t);
        t.got_remote_heads = false;
        return;
    }
    const sideband = t.serverSupportsV0("side-band-64k") or t.serverSupportsV0("side-band");
    var caps: util.Buf = .empty;
    if (t.serverSupportsV0("side-band-64k")) {
        util.bufAppend(&caps, " side-band-64k");
    } else if (t.serverSupportsV0("side-band")) util.bufAppend(&caps, " side-band");
    if (o.thin and t.serverSupportsV0("thin-pack")) util.bufAppend(&caps, " thin-pack");
    if (o.no_progress and t.serverSupportsV0("no-progress")) util.bufAppend(&caps, " no-progress");
    if (o.include_tag and t.serverSupportsV0("include-tag")) util.bufAppend(&caps, " include-tag");
    if (t.serverSupportsV0("ofs-delta")) util.bufAppend(&caps, " ofs-delta");
    if (t.serverSupportsV0("agent")) {
        util.bufAppend(&caps, " agent=");
        util.bufAppend(&caps, @import("cmd/uploadpack.zig").agentSanitized());
    }
    var req: util.Buf = .empty;
    for (wants, 0..) |w, i| {
        if (i == 0) {
            pkt.bufFmt(&req, "want {s}{s}\n", .{ hash.hex(w), caps.items });
        } else pkt.bufFmt(&req, "want {s}\n", .{hash.hex(w)});
    }
    util.bufAppend(&req, "0000");
    for (collectHaves()) |h| pkt.bufFmt(&req, "have {s}\n", .{hash.hex(h)});
    pkt.bufWrite(&req, "done\n");
    os.writeAll(t.fd_out, req.items) catch util.die("unable to write request to remote: {s}", .{os.lastErr()});
    // one ACK or NAK line
    const st = t.rd.read();
    if (st != .normal) util.die("git fetch-pack: expected ACK/NAK, got a flush packet", .{});
    const line = t.rd.line;
    if (!util.eql(line, "NAK") and !util.startsWith(line, "ACK ")) {
        if (util.skipPrefix(line, "ERR ")) |e| util.die("remote error: {s}", .{e});
        util.die("git fetch-pack: expected ACK/NAK, got '{s}'", .{line});
    }
    var src = PackSource{ .rd = t.rd, .sideband = sideband };
    t.rd.chomp = false;
    receivePack(&src, o);
    t.rd.chomp = true;
    _ = transport.finish(t);
    t.got_remote_heads = false;
}

fn fetchV2(t: *Transport, sought: []const *Ref, o: Options) void {
    const wants = computeWants(sought);
    if (wants.len == 0) return;
    if (!t.serverSupportsV2("fetch")) util.die("server doesn't support '{s}'", .{"fetch"});
    transport.sendCommandV2(t, "fetch");
    var req: util.Buf = .empty;
    if (o.thin) pkt.bufWrite(&req, "thin-pack");
    if (o.no_progress) pkt.bufWrite(&req, "no-progress");
    if (o.include_tag) pkt.bufWrite(&req, "include-tag");
    pkt.bufWrite(&req, "ofs-delta");
    for (wants) |w| pkt.bufFmt(&req, "want {s}\n", .{hash.hex(w)});
    for (collectHaves()) |h| pkt.bufFmt(&req, "have {s}\n", .{hash.hex(h)});
    pkt.bufWrite(&req, "done\n");
    util.bufAppend(&req, "0000");
    os.writeAll(t.fd_out, req.items) catch util.die("unable to write request to remote: {s}", .{os.lastErr()});
    // read sections until "packfile"
    while (true) {
        const st = t.rd.read();
        if (st == .eof) util.die("the remote end hung up unexpectedly", .{});
        if (st != .normal) util.die("error processing acks: {d}", .{@intFromEnum(st)});
        const sect = util.dupe(t.rd.line);
        if (util.eql(sect, "packfile")) break;
        // skip the section body
        while (true) {
            const s2 = t.rd.read();
            if (s2 == .delim) break;
            if (s2 == .normal) continue;
            if (s2 == .flush) return;
            util.die("the remote end hung up unexpectedly", .{});
        }
    }
    var src = PackSource{ .rd = t.rd, .sideband = true };
    t.rd.chomp = false;
    receivePack(&src, o);
    t.rd.chomp = true;
}
