//! Small builtins: get-tar-commit-id, url-parse.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const config = @import("../config.zig");
const credential = @import("../credential.zig");
const gpa = util.gpa;

// ---------------------------------------------------------------------------
// get-tar-commit-id

const tar_usage = "git get-tar-commit-id";

fn readFull(fd: c_int, buf: []u8) isize {
    var got: usize = 0;
    while (got < buf.len) {
        const n = std.c.read(fd, buf[got..].ptr, buf.len - got);
        if (n < 0) {
            if (os.errno() == 4) continue;
            return -1;
        }
        if (n == 0) break;
        got += @intCast(n);
    }
    return @intCast(got);
}

pub fn cmdGetTarCommitId(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.outf("usage: {s}\n", .{tar_usage});
        util.flushStdout();
        os.exit(129);
    }
    if (args.len != 1) {
        util.eprint("usage: {s}\n", .{tar_usage});
        os.exit(129);
    }
    var buffer: [1024]u8 = undefined;
    const n = readFull(0, &buffer);
    if (n < 0) util.dieErrno("git get-tar-commit-id: read error", .{});
    if (n != 1024) util.dieErrno("git get-tar-commit-id: EOF before reading tar header", .{});
    // ustar typeflag is at offset 156; 'g' = global extended header
    if (buffer[156] != 'g') return 1;
    const content = buffer[512..];
    var i: usize = 0;
    while (i < content.len and (content[i] == ' ' or (content[i] >= '\t' and content[i] <= '\r'))) i += 1;
    var neg = false;
    if (i < content.len and (content[i] == '+' or content[i] == '-')) {
        neg = content[i] == '-';
        i += 1;
    }
    const digits_start = i;
    var len: i64 = 0;
    while (i < content.len and content[i] >= '0' and content[i] <= '9') : (i += 1) {
        len = std.math.mul(i64, len, 10) catch return 1;
        len = std.math.add(i64, len, content[i] - '0') catch return 1;
    }
    if (i == digits_start) return 1;
    if (neg) len = -len;
    if (len < 0) return 1;
    const prefix = " comment=";
    if (!util.startsWith(content[i..], prefix)) return 1;
    const comment_off = i + prefix.len;
    len -= @intCast(comment_off);
    if (len < 1 or @mod(len, 2) == 0) return 1;
    const hexlen = @divTrunc(len - 1, 2);
    if (hexlen != 20 and hexlen != 32) return 1;
    const end = @min(content.len, comment_off + @as(usize, @intCast(len)));
    util.out(content[comment_off..end]);
    util.flushStdout();
    return 0;
}

// ---------------------------------------------------------------------------
// url-parse

const url_usage = [_][]const u8{"git url-parse [-c <component>] [--] <url>..."};

fn isUrl(url: []const u8) bool {
    if (url.len == 0 or !std.ascii.isAlphanumeric(url[0])) return false;
    var i: usize = 1;
    while (i < url.len and url[i] != ':') : (i += 1) {
        const ch = url[i];
        if (!(std.ascii.isAlphanumeric(ch) or ch == '+' or ch == '-' or ch == '.')) return false;
    }
    return i + 2 < url.len and url[i] == ':' and url[i + 1] == '/' and url[i + 2] == '/';
}

fn urlIsLocalNotSsh(url: []const u8) bool {
    const colon = std.mem.indexOfScalar(u8, url, ':') orelse return true;
    if (std.mem.indexOfScalar(u8, url, '/')) |s| {
        if (s < colon) return true;
    }
    return false;
}

const Scheme = enum { local, file, ssh, git, unknown };

fn urlGetScheme(name: []const u8) Scheme {
    if (util.eql(name, "ssh") or util.eql(name, "git+ssh") or util.eql(name, "ssh+git")) return .ssh;
    if (util.eql(name, "git")) return .git;
    if (util.eql(name, "file")) return .file;
    return .unknown;
}

const ParseResult = union(enum) { ok: config.UrlInfo, err: []const u8 };

/// url_parse() from urlmatch.c
fn urlParse(url_orig: []const u8) ParseResult {
    var url: std.ArrayList(u8) = .empty;
    url.appendSlice(gpa, if (isUrl(url_orig)) credential.urlDecodeMem(url_orig) else url_orig) catch util.oom();
    var scheme: Scheme = .local;
    var scp_syntax = false;
    var host: usize = 0;
    if (std.mem.indexOf(u8, url.items, "://")) |h| {
        scheme = urlGetScheme(url.items[0..h]);
        host = h + 3;
    } else if (!urlIsLocalNotSsh(url.items)) {
        scp_syntax = true;
        scheme = .ssh;
        url.insertSlice(gpa, 0, "ssh://") catch util.oom();
        host = "ssh://".len;
    }
    if (scp_syntax) {
        const user_at = std.mem.indexOfScalarPos(u8, url.items, host, '@');
        const host_start = if (user_at) |u| u + 1 else host;
        var separator: ?usize = null;
        if (host_start < url.items.len and url.items[host_start] == '[') {
            const bracket_end = std.mem.indexOfScalarPos(u8, url.items, host_start, ']');
            var inner: usize = 0;
            if (bracket_end) |be| {
                for (url.items[host_start + 1 .. be]) |ch| {
                    if (ch == ':') inner += 1;
                }
            }
            if (bracket_end != null and inner <= 1) {
                const close_off = bracket_end.?;
                _ = url.orderedRemove(close_off);
                _ = url.orderedRemove(host_start);
                separator = close_off - 1;
            } else if (bracket_end) |be| {
                separator = std.mem.indexOfScalarPos(u8, url.items, be + 1, ':');
            } else {
                separator = std.mem.indexOfScalarPos(u8, url.items, host_start, ':');
            }
        } else {
            separator = std.mem.indexOfScalarPos(u8, url.items, host_start, ':');
        }
        if (separator) |s| {
            if (s < url.items.len) {
                if (s + 1 < url.items.len and url.items[s + 1] == '/') {
                    _ = url.orderedRemove(s);
                } else url.items[s] = '/';
            }
        }
    }
    switch (config.urlNormalize(url.items, false)) {
        .err => |e| return .{ .err = e },
        .ok => |info0| {
            var info = info0;
            if (scheme == .git or scheme == .ssh) {
                if (info.path_off + 1 < info.url.len and info.url[info.path_off + 1] == '~') {
                    info.path_off += 1;
                    info.path_len -= 1;
                }
            }
            return .{ .ok = info };
        },
    }
}

pub fn cmdUrlParse(args: []const []const u8) u8 {
    var component: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.string('c', "component", &component, "component", "which URL component to extract"),
    };
    const rest = po.parse(args[1..], &options, &url_usage, .{});
    if (rest.len == 0) po.usageWithOptions(&url_usage, &options);
    const Comp = enum { none, scheme, user, password, host, port, path };
    var sel: Comp = .none;
    if (component) |c| {
        if (util.eql(c, "path")) {
            sel = .path;
        } else if (util.eql(c, "host")) {
            sel = .host;
        } else if (util.eql(c, "scheme")) {
            sel = .scheme;
        } else if (util.eql(c, "user")) {
            sel = .user;
        } else if (util.eql(c, "password")) {
            sel = .password;
        } else if (util.eql(c, "port")) {
            sel = .port;
        } else util.die("invalid git URL component '{s}'", .{c});
    }
    for (rest) |url| {
        if (urlIsLocalNotSsh(url)) {
            if (url.len > 0 and url[0] == '/')
                util.die("'{s}' is not a URL; if you meant a local repository, use 'file://{s}'", .{ url, url });
            util.die("'{s}' is not a URL; if you meant a local repository, use a 'file://' URL with an absolute path", .{url});
        }
        const info = switch (urlParse(url)) {
            .ok => |i| i,
            .err => |e| util.die("invalid git URL '{s}': {s}", .{ url, e }),
        };
        const off_len: [2]usize = switch (sel) {
            .none => continue,
            .scheme => .{ 0, info.scheme_len },
            .user => .{ info.user_off, info.user_len },
            .password => .{ info.passwd_off, info.passwd_len },
            .host => .{ info.host_off, info.host_len },
            .port => .{ info.port_off, info.port_len },
            .path => .{ info.path_off, info.path_len },
        };
        const s = info.url[@min(off_len[0], info.url.len)..@min(off_len[0] + off_len[1], info.url.len)];
        util.outf("{s}\n", .{s});
    }
    return 0;
}

// ---------------------------------------------------------------------------
// diff-pairs

const diff = @import("../diff.zig");
const revision = @import("../revision.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");

const diff_pairs_usage = "git diff-pairs -z [<diff-options>]";

fn usageMsg(msg: []const u8) noreturn {
    util.flushStdout();
    util.eprint("usage: {s}\n", .{msg});
    os.exit(129);
}

/// parse_mode(): octal digits followed by a space.
fn parseMode(s: []const u8, mode: *u32) ?[]const u8 {
    var i: usize = 0;
    var m: u32 = 0;
    while (i < s.len and s[i] != ' ') : (i += 1) {
        if (s[i] < '0' or s[i] > '7') return null;
        m = (m << 3) + (s[i] - '0');
    }
    if (i == 0 or i >= s.len) return null;
    mode.* = m;
    return s[i + 1 ..];
}

fn parseModeOrDie(s: []const u8, mode: *u32) []const u8 {
    return parseMode(s, mode) orelse util.die("unable to parse mode: {s}", .{s});
}

fn parseOidOrDie(s: []const u8, oid: *hash.Oid) []const u8 {
    if (s.len < hash.HEXSZ + 1 or s[hash.HEXSZ] != ' ') util.die("unable to parse object id: {s}", .{s});
    oid.* = hash.fromHex(s[0..hash.HEXSZ]) orelse util.die("unable to parse object id: {s}", .{s});
    return s[hash.HEXSZ + 1 ..];
}

const S_IFMT: u32 = 0o170000;
const S_IFDIR: u32 = 0o040000;

pub fn cmdDiffPairs(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.outf("usage: {s}\n", .{diff_pairs_usage});
        util.flushStdout();
        os.exit(129);
    }
    const o = gpa.create(diff.DiffOptions) catch util.oom();
    o.* = diff.DiffOptions.initBasic();
    const revs = gpa.create(revision.RevInfo) catch util.oom();
    revs.* = revision.RevInfo.init(repo_mod.repo().prefix);
    diff.setupRevDiffWith(revs, o);
    revs.disable_stdin = true;
    revs.abbrev = 0;
    revs.diff = true;
    const rest = revision.setupRevisions(revs, args, .{});
    if (rest.len > 1) usageMsg(util.fmt("unrecognized argument: {s}", .{rest[1]}));
    if (o.line_termination != 0) usageMsg("working without -z is not supported");
    if (revs.prune_data.items.len > 0) usageMsg("pathspec arguments not supported");
    if (revs.pending.items.len > 0 or revs.max_count != -1 or revs.min_age != revision.UNSET_TIME or revs.max_age != revision.UNSET_TIME)
        usageMsg("revision arguments not allowed");
    if (o.output_format == 0) {
        o.output_format = diff.FMT_PATCH;
        revs.output_format = diff.FMT_PATCH;
    }
    if (o.detect_rename == 0) o.skip_resolving_statuses = true;

    const data = os.readAllFd(0) catch "";
    var pos: usize = 0;
    const Rd = struct {
        fn next(d: []const u8, p: *usize) ?[]const u8 {
            if (p.* >= d.len) return null;
            const end = std.mem.indexOfScalarPos(u8, d, p.*, 0) orelse d.len;
            const rec = d[p.*..end];
            p.* = if (end < d.len) end + 1 else d.len;
            return rec;
        }
    };
    while (Rd.next(data, &pos)) |meta| {
        if (meta.len == 0) {
            diff.diffcoreStd(o);
            diff.flush(o);
            util.out("\x00");
            util.flushStdout();
            continue;
        }
        if (meta[0] != ':') util.die("invalid raw diff input", .{});
        var p = meta[1..];
        var mode_a: u32 = 0;
        var mode_b: u32 = 0;
        p = parseModeOrDie(p, &mode_a);
        p = parseModeOrDie(p, &mode_b);
        if (mode_a & S_IFMT == S_IFDIR or mode_b & S_IFMT == S_IFDIR) util.die("tree objects not supported", .{});
        var oid_a: hash.Oid = undefined;
        var oid_b: hash.Oid = undefined;
        p = parseOidOrDie(p, &oid_a);
        p = parseOidOrDie(p, &oid_b);
        const status: u8 = if (p.len > 0) p[0] else 0;
        if (p.len > 0) p = p[1..];
        const path = Rd.next(data, &pos) orelse util.die("got EOF while reading path", .{});
        const before = diff.queue.items.len;
        switch (status) {
            'A' => {
                diff.addRemove(o, '+', mode_b, oid_b, true, path, 0);
                if (diff.queue.items.len > before) diff.queue.items[diff.queue.items.len - 1].status = status;
            },
            'D' => {
                diff.addRemove(o, '-', mode_a, oid_a, true, path, 0);
                if (diff.queue.items.len > before) diff.queue.items[diff.queue.items.len - 1].status = status;
            },
            'T', 'M' => {
                diff.change(o, mode_a, mode_b, oid_a, oid_b, true, true, path, 0, 0);
                if (diff.queue.items.len > before) diff.queue.items[diff.queue.items.len - 1].status = status;
            },
            'R', 'C' => {
                const dst = Rd.next(data, &pos) orelse util.die("got EOF while reading destination path", .{});
                const a = diff.allocFilespec(path, oid_a, true, mode_a);
                const b = diff.allocFilespec(dst, oid_b, true, mode_b);
                const pair = diff.queuePair(a, b);
                const score = std.fmt.parseInt(u32, p, 10) catch util.die("unable to parse rename/copy score: {s}", .{p});
                pair.score = @intCast(@as(u64, score) * diff.MAX_SCORE / 100);
                pair.status = status;
                pair.renamed_pair = true;
            },
            else => util.die("unknown diff status: {c}", .{status}),
        }
    }
    diff.diffcoreStd(o);
    diff.flush(o);
    return diff.resultCodeOpts(o);
}
