//! merge-index, merge-one-file, merge-octopus, merge-resolve, unpack-file
//! (ports of builtin/merge-index.c, builtin/unpack-file.c and the
//! git-merge-{one-file,octopus,resolve}.sh scripts)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const revparse = @import("../revparse.zig");
const index_mod = @import("../index.zig");
const proc = @import("../proc.zig");
const gpa = util.gpa;

fn git(args: []const []const u8) u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return os.run(argv.items, .{}).status;
}

fn gitOut(args: []const []const u8, quiet_err: bool) struct { status: u8, out: []const u8 } {
    var argv: std.ArrayList([]const u8) = .empty;
    if (quiet_err) {
        argv.append(gpa, "/bin/sh") catch util.oom();
        argv.append(gpa, "-c") catch util.oom();
        argv.append(gpa, "\"$0\" \"$@\" 2>/dev/null") catch util.oom();
    }
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    const r = os.run(argv.items, .{ .capture_stdout = true });
    return .{ .status = r.status, .out = std.mem.trimEnd(u8, r.stdout, "\n") };
}

// ---------------------------------------------------------------------------
// unpack-file

pub fn cmdUnpackFile(args: []const []const u8) u8 {
    if (args.len != 2 or util.eql(args[1], "-h")) {
        util.eprint("usage: git unpack-file <blob>\n", .{});
        os.exit(129);
    }
    const oid = revparse.getOid(args[1]) orelse util.die("Not a valid object name {s}", .{args[1]});
    util.outf("{s}\n", .{createTempFile(oid)});
    return 0;
}

fn createTempFile(oid: hash.Oid) []const u8 {
    const o = repo_mod.repo().odb().read(oid) orelse util.die("unable to read blob object {s}", .{&hash.hex(oid)});
    if (o.typ != .blob) util.die("unable to read blob object {s}", .{&hash.hex(oid)});
    const t = os.tmpFile(".", ".merge_file_");
    if (t.fd < 0) util.dieErrno("unable to create temp-file", .{});
    os.writeAll(t.fd, o.data) catch util.dieErrno("unable to write temp-file", .{});
    os.close(t.fd);
    return t.path[2..];
}

// ---------------------------------------------------------------------------
// merge-index

var mi_pgm: []const u8 = "";
var mi_one_shot = false;
var mi_quiet = false;
var mi_err: u8 = 0;

fn runPgm(argv: []const []const u8) u8 {
    if (util.skipPrefix(argv[0], "git-")) |sub| {
        if (os.getenv("PATH")) |p| {
            var it = std.mem.splitScalar(u8, p, ':');
            while (it.next()) |d| {
                if (d.len > 0 and os.access(util.concat(&.{ d, "/", argv[0] }), 1)) return os.run(argv, .{}).status;
            }
        }
        var a: std.ArrayList([]const u8) = .empty;
        a.append(gpa, proc.gitBinary()) catch util.oom();
        a.append(gpa, sub) catch util.oom();
        a.appendSlice(gpa, argv[1..]) catch util.oom();
        return os.run(a.items, .{}).status;
    }
    return os.run(argv, .{}).status;
}

fn mergeEntry(pos0: usize, path: []const u8) usize {
    const ents = index_mod.get().entries.items;
    if (pos0 >= ents.len) util.die("git merge-index: {s} not in the cache", .{path});
    var arguments = [_][]const u8{ mi_pgm, "", "", "", path, "", "", "" };
    var found: usize = 0;
    var pos = pos0;
    while (pos < ents.len) : (pos += 1) {
        const ce = ents[pos];
        if (!util.eql(ce.path, path)) break;
        found += 1;
        const st = ce.stage();
        arguments[st] = util.dupe(&hash.hex(ce.oid));
        arguments[st + 4] = util.fmt("{o}", .{ce.mode});
    }
    if (found == 0) util.die("git merge-index: {s} not in the cache", .{path});
    if (runPgm(&arguments) != 0) {
        if (mi_one_shot) {
            mi_err +|= 1;
        } else {
            if (!mi_quiet) util.die("merge program failed", .{});
            os.exit(1);
        }
    }
    return found;
}

pub fn cmdMergeIndex(args: []const []const u8) u8 {
    const usage_string = "git merge-index [-o] [-q] <merge-program> (-a | [--] [<filename>...])";
    if (args.len == 2 and util.eql(args[1], "-h")) {
        util.outf("usage: {s}\n", .{usage_string});
        os.exit(129);
    }
    if (args.len < 3) {
        util.eprint("usage: {s}\n", .{usage_string});
        os.exit(129);
    }
    const idx = index_mod.get();
    var i: usize = 1;
    if (util.eql(args[i], "-o")) {
        mi_one_shot = true;
        i += 1;
    }
    if (i < args.len and util.eql(args[i], "-q")) {
        mi_quiet = true;
        i += 1;
    }
    if (i >= args.len) {
        util.eprint("usage: {s}\n", .{usage_string});
        os.exit(129);
    }
    mi_pgm = args[i];
    i += 1;
    var force_file = false;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (!force_file and arg.len > 0 and arg[0] == '-') {
            if (util.eql(arg, "--")) {
                force_file = true;
                continue;
            }
            if (util.eql(arg, "-a")) {
                var j: usize = 0;
                while (j < idx.entries.items.len) : (j += 1) {
                    const ce = idx.entries.items[j];
                    if (ce.stage() == 0) continue;
                    j += mergeEntry(j, ce.path) - 1;
                }
                continue;
            }
            util.die("git merge-index: unknown option {s}", .{arg});
        }
        switch (idx.pos(arg, 0)) {
            .found => {},
            .missing => |p| _ = mergeEntry(p, arg),
        }
    }
    if (mi_err != 0 and !mi_quiet) util.die("merge program failed", .{});
    return mi_err;
}

// ---------------------------------------------------------------------------
// merge-one-file

fn rmdirP(path: []const u8) void {
    var p = path;
    while (true) {
        const slash = std.mem.lastIndexOfScalar(u8, p, '/') orelse return;
        p = p[0..slash];
        if (!os.rmdir(p)) return;
    }
}

pub fn cmdMergeOneFile(args: []const []const u8) u8 {
    if (args.len != 8) {
        util.out("usage: git merge-one-file <orig blob> <our blob> <their blob> <path> <orig mode> <our mode> <their mode>\n\nBlob ids and modes should be empty for missing files.\n");
        return 1;
    }
    const a1 = args[1];
    const a2 = args[2];
    const a3 = args[3];
    const path = args[4];
    const m5 = args[5];
    const m6 = args[6];
    const m7 = args[7];
    const d1: []const u8 = if (a1.len > 0) a1 else ".";
    const d2: []const u8 = if (a2.len > 0) a2 else ".";
    const d3: []const u8 = if (a3.len > 0) a3 else ".";
    const key = util.concat(&.{ d1, d2, d3 });
    const eqk = struct {
        fn f(k: []const u8, parts: []const []const u8) bool {
            return util.eql(k, util.concat(parts));
        }
    }.f;

    // Deleted in both or deleted in one and unchanged in the other
    if (a1.len > 0 and (eqk(key, &.{ a1, ".." }) or eqk(key, &.{ a1, ".", a1 }) or eqk(key, &.{ a1, a1, "." }))) {
        if ((m6.len == 0 and !util.eql(m5, m7)) or (m7.len == 0 and !util.eql(m5, m6))) {
            util.eprint("ERROR: File {s} deleted on one branch but had its\nERROR: permissions changed on the other.\n", .{path});
            return 1;
        }
        if (a2.len > 0) {
            util.outf("Removing {s}\n", .{path});
        } else {
            return git(&.{ "update-index", "--remove", "--", path });
        }
        if (os.isFile(path)) {
            _ = os.unlink(path);
            rmdirP(path);
        }
        return git(&.{ "update-index", "--remove", "--", path });
    }
    // Added in one
    if (a1.len == 0 and a2.len > 0 and a3.len == 0) {
        return git(&.{ "update-index", "--add", "--cacheinfo", m6, a2, path });
    }
    if (a1.len == 0 and a2.len == 0 and a3.len > 0) {
        util.outf("Adding {s}\n", .{path});
        if (os.isFile(path)) {
            util.eprint("ERROR: untracked {s} is overwritten by the merge.\n", .{path});
            return 1;
        }
        if (git(&.{ "update-index", "--add", "--cacheinfo", m7, a3, path }) != 0) return 1;
        return git(&.{ "checkout-index", "-u", "-f", "--", path });
    }
    // Added in both, identically
    if (a1.len == 0 and a2.len > 0 and util.eql(a2, a3)) {
        if (!util.eql(m6, m7)) {
            util.eprint("ERROR: File {s} added identically in both branches,\nERROR: but permissions conflict {s}->{s}.\n", .{ path, m6, m7 });
            return 1;
        }
        util.outf("Adding {s}\n", .{path});
        if (git(&.{ "update-index", "--add", "--cacheinfo", m6, a2, path }) != 0) return 1;
        return git(&.{ "checkout-index", "-u", "-f", "--", path });
    }
    // Modified in both, but differently
    if (a2.len > 0 and a3.len > 0) {
        if (util.eql(m6, "120000") or util.eql(m7, "120000")) {
            util.eprint("ERROR: {s}: Not merging symbolic link changes.\n", .{path});
            return 1;
        }
        if (util.eql(m6, "160000") or util.eql(m7, "160000")) {
            util.eprint("ERROR: {s}: Not merging conflicting submodule changes.\n", .{path});
            return 1;
        }
        const o2 = hash.fromHex(a2) orelse util.die("Not a valid object name {s}", .{a2});
        const o3 = hash.fromHex(a3) orelse util.die("Not a valid object name {s}", .{a3});
        const src1 = createTempFile(o2);
        const src2 = createTempFile(o3);
        var orig: []const u8 = undefined;
        if (a1.len == 0) {
            util.outf("Added {s} in both, but differently.\n", .{path});
            orig = createTempFile(hash.fromHex(hash.empty_blob_hex).?);
        } else {
            util.outf("Auto-merging {s}\n", .{path});
            orig = createTempFile(hash.fromHex(a1) orelse util.die("Not a valid object name {s}", .{a1}));
        }
        var ret = git(&.{ "merge-file", src1, orig, src2 });
        var msg: []const u8 = "";
        if (ret != 0 or a1.len == 0) {
            msg = "content conflict";
            ret = 1;
        }
        if (git(&.{ "checkout-index", "-f", "--stage=2", "--", path }) != 0) return 1;
        const merged = os.readFile(src1) orelse return 1;
        os.writeFile(path, merged, 0o666) catch return 1;
        _ = os.unlink(orig);
        _ = os.unlink(src1);
        _ = os.unlink(src2);
        if (!util.eql(m6, m7)) {
            if (msg.len > 0) msg = util.concat(&.{ msg, ", " });
            msg = util.fmt("{s}permissions conflict: {s}->{s},{s}", .{ msg, m5, m6, m7 });
            ret = 1;
        }
        if (ret != 0) {
            util.eprint("ERROR: {s} in {s}\n", .{ msg, path });
            return 1;
        }
        return git(&.{ "update-index", "--", path });
    }
    util.eprint("ERROR: {s}: Not handling case {s} -> {s} -> {s}\n", .{ path, a1, a2, a3 });
    return 1;
}

// ---------------------------------------------------------------------------
// merge-octopus / merge-resolve

const Split = struct { bases: [][]const u8, head: ?[]const u8, remotes: [][]const u8 };

fn splitArgs(args: []const []const u8) Split {
    var bases: std.ArrayList([]const u8) = .empty;
    var remotes: std.ArrayList([]const u8) = .empty;
    var head: ?[]const u8 = null;
    var sep = false;
    for (args[1..]) |a| {
        if (!sep and util.eql(a, "--")) {
            sep = true;
        } else if (sep and head == null) {
            head = a;
        } else if (sep) {
            remotes.append(gpa, a) catch util.oom();
        } else bases.append(gpa, a) catch util.oom();
    }
    return .{ .bases = bases.items, .head = head, .remotes = remotes.items };
}

fn checkIndexMatchesHead() bool {
    if (git(&.{ "diff-index", "--quiet", "--cached", "HEAD", "--" }) == 0) return true;
    util.out("Error: Your local changes to the following files would be overwritten by merge\n");
    const r = gitOut(&.{ "diff-index", "--cached", "--name-only", "HEAD", "--" }, false);
    var it = std.mem.splitScalar(u8, r.out, '\n');
    while (it.next()) |l| {
        if (l.len > 0) util.outf("    {s}\n", .{l});
    }
    return false;
}

pub fn cmdMergeResolve(args: []const []const u8) u8 {
    if (!checkIndexMatchesHead()) return 2;
    const s = splitArgs(args);
    if (s.remotes.len > 1) return 2;
    if (s.bases.len == 0) return 2;
    _ = git(&.{ "update-index", "-q", "--refresh" });
    var rt: std.ArrayList([]const u8) = .empty;
    rt.appendSlice(gpa, &.{ "read-tree", "-u", "-m", "--aggressive" }) catch util.oom();
    rt.appendSlice(gpa, s.bases) catch util.oom();
    if (s.head) |h| rt.append(gpa, h) catch util.oom();
    rt.appendSlice(gpa, s.remotes) catch util.oom();
    if (git(rt.items) != 0) return 2;
    util.out("Trying simple merge.\n");
    if (gitOut(&.{"write-tree"}, true).status == 0) return 0;
    util.out("Simple merge failed, trying Automatic merge.\n");
    if (git(&.{ "merge-index", "-o", "git-merge-one-file", "-a" }) == 0) return 0;
    return 1;
}

pub fn cmdMergeOctopus(args: []const []const u8) u8 {
    const s = splitArgs(args);
    if (s.remotes.len < 2) return 2;
    if (!checkIndexMatchesHead()) return 2;
    const head = s.head orelse "";
    var mrc: std.ArrayList([]const u8) = .empty;
    const hr = gitOut(&.{ "rev-parse", "--verify", "-q", head }, false);
    mrc.append(gpa, hr.out) catch util.oom();
    var mrt = gitOut(&.{"write-tree"}, false).out;
    var non_ff = false;
    var failure: u8 = 0;
    for (s.remotes) |sha1| {
        if (failure == 1) {
            util.out("Automated merge did not work.\nShould not be doing an octopus.\n");
            return 2;
        }
        var pretty_name = os.getenv(util.concat(&.{ "GITHEAD_", sha1 })) orelse sha1;
        if (util.eql(pretty_name, sha1)) {
            const up = util.dupe(sha1);
            for (up) |*ch| ch.* = std.ascii.toUpper(ch.*);
            pretty_name = os.getenv(util.concat(&.{ "GITHEAD_", up })) orelse pretty_name;
        }
        var mb: std.ArrayList([]const u8) = .empty;
        mb.appendSlice(gpa, &.{ "merge-base", "--all", sha1 }) catch util.oom();
        mb.appendSlice(gpa, mrc.items) catch util.oom();
        const cr = gitOut(mb.items, false);
        if (cr.status != 0) util.die("Unable to find common commit with {s}", .{pretty_name});
        const common = cr.out;
        var up_to_date = false;
        var it = std.mem.splitScalar(u8, common, '\n');
        while (it.next()) |l| {
            if (util.eql(l, sha1)) up_to_date = true;
        }
        if (up_to_date) {
            util.outf("Already up to date with {s}\n", .{pretty_name});
            continue;
        }
        if (!non_ff and mrc.items.len == 1 and util.eql(common, mrc.items[0])) {
            util.outf("Fast-forwarding to: {s}\n", .{pretty_name});
            const r = git(&.{ "read-tree", "-u", "-m", head, sha1 });
            if (r != 0) return r;
            mrc.items[0] = sha1;
            mrt = gitOut(&.{"write-tree"}, false).out;
            continue;
        }
        non_ff = true;
        util.outf("Trying simple merge with {s}\n", .{pretty_name});
        var rt: std.ArrayList([]const u8) = .empty;
        rt.appendSlice(gpa, &.{ "read-tree", "-u", "-m", "--aggressive" }) catch util.oom();
        var cit = std.mem.splitScalar(u8, common, '\n');
        while (cit.next()) |l| {
            if (l.len > 0) rt.append(gpa, l) catch util.oom();
        }
        rt.append(gpa, mrt) catch util.oom();
        rt.append(gpa, sha1) catch util.oom();
        if (git(rt.items) != 0) return 2;
        var next = gitOut(&.{"write-tree"}, true);
        if (next.status != 0) {
            util.out("Simple merge did not work, trying automatic merge.\n");
            if (git(&.{ "merge-index", "-o", "git-merge-one-file", "-a" }) != 0) failure = 1;
            next = gitOut(&.{"write-tree"}, true);
        }
        mrc.append(gpa, sha1) catch util.oom();
        mrt = next.out;
    }
    return failure;
}
