//! git commit-graph (builtin/commit-graph.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const hash = @import("../hash.zig");
const objects = @import("../objects.zig");
const odb_mod = @import("../odb.zig");
const repo_mod = @import("../repo.zig");
const progress = @import("../progress.zig");
const date = @import("../date.zig");
const cg = @import("../commitgraph.zig");
const gpa = util.gpa;

const verify_usage_str = "git commit-graph verify [--object-dir <dir>] [--shallow] [--[no-]progress]";
const write_usage_str = "git commit-graph write [--object-dir <dir>] [--append]\n" ++
    "                       [--split[=<strategy>]] [--reachable | --stdin-packs | --stdin-commits]\n" ++
    "                       [--changed-paths] [--[no-]max-new-filters <n>] [--[no-]progress]\n" ++
    "                       <split-options>";
const main_usage = [_][]const u8{ verify_usage_str, write_usage_str };
const verify_usage = [_][]const u8{verify_usage_str};
const write_usage = [_][]const u8{write_usage_str};

var obj_dir: ?[]const u8 = null;
var enable_changed_paths: i32 = -1;
var split_set = false;
var split_flags: cg.SplitFlags = .unspecified;
var max_new_filters: i32 = -1;
var expire_str: ?[]const u8 = null;

fn cbChangedPaths(_: ?[]const u8, unset: bool) void {
    enable_changed_paths = if (unset) 0 else 1;
}

fn cbSplit(arg: ?[]const u8, _: bool) void {
    split_set = true;
    const a = arg orelse return;
    if (util.eql(a, "no-merge")) {
        split_flags = .merge_prohibited;
    } else if (util.eql(a, "replace")) {
        split_flags = .replace;
    } else util.die("unrecognized --split argument, {s}", .{a});
}

fn cbMaxNewFilters(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        max_new_filters = -1;
        return;
    }
    const a = arg orelse "";
    // strtol semantics: leading number, nothing after
    var i: usize = 0;
    while (i < a.len and std.ascii.isWhitespace(a[i])) i += 1;
    var j = i;
    if (j < a.len and (a[j] == '-' or a[j] == '+')) j += 1;
    const ds = j;
    while (j < a.len and std.ascii.isDigit(a[j])) j += 1;
    if (j == ds) j = 0;
    const v: i64 = if (j > 0) (std.fmt.parseInt(i64, a[i..j], 10) catch std.math.maxInt(i32)) else 0;
    max_new_filters = @truncate(v);
    if (j != a.len) {
        util.err("option `max-new-filters' expects a numerical value", .{});
        os.exit(129);
    }
}

fn findSource(dir: ?[]const u8) []const u8 {
    const dirs = repo_mod.repo().odb().allDirs();
    const want = dir orelse return dirs[0];
    const rw = os.realPath(want);
    for (dirs) |d| {
        if (rw) |r| {
            if (os.realPath(d)) |rd| {
                if (util.eql(r, rd)) return d;
            }
        }
    }
    util.die("could not find object directory matching {s}", .{want});
}

fn readStdinLines() [][]const u8 {
    const data = os.readAllFd(0) catch return &.{};
    var out: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |l0| {
        var l = l0;
        if (it.peek() == null and l.len == 0) break;
        if (l.len > 0 and l[l.len - 1] == '\r') l = l[0 .. l.len - 1];
        out.append(gpa, l) catch util.oom();
    }
    return out.items;
}

fn cmdVerify(args: []const []const u8) u8 {
    var shallow = false;
    var prog = os.isatty(2);
    const opts = [_]po.Opt{
        po.string(0, "object-dir", &obj_dir, "dir", "the object directory to store the graph"),
        po.boolean(0, "shallow", &shallow, "if the commit-graph is split, only verify the tip file"),
        po.boolean(0, "progress", &prog, "force progress reporting"),
    };
    const rest = po.parse(args[1..], &opts, &verify_usage, .{});
    if (rest.len > 0) po.usageWithOptions(&verify_usage, &opts);
    const source = findSource(obj_dir);
    const graph_name = cg.graphFilename(source);
    const chain_name = cg.chainFilename(source);
    const dirs = repo_mod.repo().odb().allDirs();
    var graph: ?*cg.Graph = null;
    var incomplete = false;
    if (os.statPath(graph_name)) |_| {
        const data = os.readFile(graph_name) orelse util.dieErrno("Could not open commit-graph '{s}'", .{graph_name});
        graph = cg.loadOne(graph_name, source);
        _ = data;
    } else if (os.errno() != 2) {
        util.dieErrno("Could not open commit-graph '{s}'", .{graph_name});
    } else if (os.statPath(chain_name)) |st| {
        const data = os.readFile(chain_name) orelse util.dieErrno("could not open commit-graph chain '{s}'", .{chain_name});
        if (st.size < hash.HEXSZ) {
            if (st.size == 0) return 0;
            util.warn("commit-graph chain file too small", .{});
            util.dieErrno("could not open commit-graph chain '{s}'", .{chain_name});
        }
        const r = cg.loadChainData(data, dirs);
        graph = r.g;
        incomplete = r.incomplete;
    } else if (os.errno() != 2) {
        util.dieErrno("could not open commit-graph chain '{s}'", .{chain_name});
    } else return 0;
    const g = graph orelse return 1;
    var ret = cg.verify(g, shallow, prog);
    if (incomplete) {
        util.err("one or more commit-graph chain files could not be loaded", .{});
        ret |= 1;
    }
    return ret;
}

fn cmdWrite(args: []const []const u8) u8 {
    var reachable = false;
    var stdin_packs = false;
    var stdin_commits = false;
    var append = false;
    var prog = os.isatty(2);
    var max_commits: i32 = 0;
    var size_multiple: i32 = 2;
    enable_changed_paths = -1;
    max_new_filters = -1;
    if (repo_mod.cfg.getInt("commitgraph.maxnewfilters")) |v| max_new_filters = @truncate(v);
    if (repo_mod.cfg.getBool("commitgraph.changedpaths")) |b| enable_changed_paths = if (b) 1 else -1;
    const opts = [_]po.Opt{
        po.string(0, "object-dir", &obj_dir, "dir", "the object directory to store the graph"),
        po.boolean(0, "reachable", &reachable, "start walk at all refs"),
        po.boolean(0, "stdin-packs", &stdin_packs, "scan pack-indexes listed by stdin for commits"),
        po.boolean(0, "stdin-commits", &stdin_commits, "start walk at commits listed by stdin"),
        po.boolean(0, "append", &append, "include all commits already in the commit-graph file"),
        po.callbackNoArg(0, "changed-paths", cbChangedPaths, "enable computation for changed paths"),
        .{ .long = "split", .kind = .callback, .cb = cbSplit, .optarg = true, .noneg = true, .help = "allow writing an incremental commit-graph file" },
        po.integer(0, "max-commits", &max_commits, "n", "maximum number of commits in a non-base split commit-graph"),
        po.integer(0, "size-multiple", &size_multiple, "n", "maximum ratio between two levels of a split commit-graph"),
        po.string(0, "expire-time", &expire_str, "expiry-date", "only expire files older than a given date-time"),
        po.callback(0, "max-new-filters", cbMaxNewFilters, "n", "maximum number of changed-path Bloom filters to compute"),
        po.boolean(0, "progress", &prog, "force progress reporting"),
    };
    const rest = po.parse(args[1..], &opts, &write_usage, .{});
    if (rest.len > 0) po.usageWithOptions(&write_usage, &opts);
    if (@as(u8, @intFromBool(reachable)) + @intFromBool(stdin_packs) + @intFromBool(stdin_commits) > 1)
        util.die("use at most one of --reachable, --stdin-commits, or --stdin-packs", .{});
    var wo = cg.WriteOpts{
        .append = append,
        .progress = prog,
        .split = split_set,
        .split_flags = split_flags,
        .max_commits = max_commits,
        .size_multiple = size_multiple,
        .max_new_filters = max_new_filters,
    };
    if (expire_str) |e| {
        wo.expire_time = date.parseExpiryDate(e) orelse util.die("malformed expiration date '{s}'", .{e});
    }
    if (enable_changed_paths == 0) wo.no_write_bloom = true;
    if (enable_changed_paths == 1 or envBool("GIT_TEST_COMMIT_GRAPH_CHANGED_PATHS")) wo.write_bloom = true;
    const source = findSource(obj_dir);
    if (reachable) return if (cg.writeReachable(source, wo) != 0) 1 else 0;

    var packs: ?[]const []const u8 = null;
    var commits: ?[]const hash.Oid = null;
    if (stdin_packs) {
        packs = readStdinLines();
    } else if (stdin_commits) {
        var p: ?*progress.Progress = null;
        if (prog) p = progress.startDelayed("Collecting commits from input", 0);
        var set: hash.OidSet = .empty;
        var list: std.ArrayList(hash.Oid) = .empty;
        const odb = repo_mod.repo().odb();
        for (readStdinLines()) |line| {
            const oid = (if (line.len >= hash.HEXSZ) hash.fromHex(line[0..hash.HEXSZ]) else null) orelse {
                util.err("unexpected non-hex object ID: {s}", .{line});
                progress.stop(&p);
                return 1;
            };
            if (!odb.has(oid)) {
                util.err("invalid object: {s}", .{line});
                progress.stop(&p);
                return 1;
            }
            const pe = objects.peel(oid) orelse {
                util.err("invalid object: {s}", .{line});
                progress.stop(&p);
                return 1;
            };
            if (pe.typ == .commit) {
                const gop = set.getOrPut(gpa, pe.oid) catch util.oom();
                if (!gop.found_existing) list.append(gpa, pe.oid) catch util.oom();
            }
            progress.update(p, set.count());
        }
        progress.stop(&p);
        commits = list.items;
    }
    return if (cg.write(source, packs, commits, wo) != 0) 1 else 0;
}

fn envBool(name: []const u8) bool {
    const v = os.getenv(name) orelse return false;
    return @import("../config.zig").configBool(name, v);
}

pub fn cmdCommitGraph(args: []const []const u8) u8 {
    odb_mod.disableReplaceRefs();
    const opts = [_]po.Opt{
        po.string(0, "object-dir", &obj_dir, "dir", "the object directory to store the graph"),
    };
    const rest = po.parse(args[1..], &opts, &main_usage, .{ .stop_at_non_option = true });
    if (rest.len == 0) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&main_usage, &opts);
    }
    const sub = rest[0];
    if (util.eql(sub, "verify")) return cmdVerify(rest);
    if (util.eql(sub, "write")) return cmdWrite(rest);
    util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&main_usage, &opts);
}
