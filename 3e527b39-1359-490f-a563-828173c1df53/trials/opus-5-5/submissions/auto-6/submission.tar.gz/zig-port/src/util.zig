//! Shared helpers: allocation, output, diagnostics, string utilities.

const std = @import("std");
const os = @import("os.zig");

pub const gpa = std.heap.c_allocator;

pub fn oom() noreturn {
    eprint("fatal: out of memory\n", .{});
    std.c.exit(128);
}

// ---------------- output ----------------

pub const Out = struct {
    fd: c_int,
    buf: std.ArrayList(u8) = .empty,
    broken: bool = false,

    pub fn write(self: *Out, data: []const u8) void {
        self.buf.appendSlice(gpa, data) catch oom();
        if (self.buf.items.len >= 65536) self.flush();
    }
    pub fn print(self: *Out, comptime f: []const u8, args: anytype) void {
        self.buf.print(gpa, f, args) catch oom();
        if (self.buf.items.len >= 65536) self.flush();
    }
    pub fn byte(self: *Out, b: u8) void {
        self.buf.append(gpa, b) catch oom();
    }
    pub fn flush(self: *Out) void {
        if (self.buf.items.len == 0) return;
        if (!self.broken) {
            os.writeAll(self.fd, self.buf.items) catch {
                self.broken = true;
            };
        }
        self.buf.clearRetainingCapacity();
    }
};

pub var stdout = Out{ .fd = 1 };

pub fn out(data: []const u8) void {
    stdout.write(data);
}
pub fn outf(comptime f: []const u8, args: anytype) void {
    stdout.print(f, args);
}
pub fn flushStdout() void {
    stdout.flush();
}

pub fn eprint(comptime f: []const u8, args: anytype) void {
    stdout.flush();
    const s = std.fmt.allocPrint(gpa, f, args) catch oom();
    os.writeAll(2, s) catch {};
}
pub fn ewrite(s: []const u8) void {
    stdout.flush();
    os.writeAll(2, s) catch {};
}

pub fn die(comptime f: []const u8, args: anytype) noreturn {
    eprint("fatal: " ++ f ++ "\n", args);
    os.exit(128);
}
pub fn dieErrno(comptime f: []const u8, args: anytype) noreturn {
    const e = os.lastErr();
    eprint("fatal: " ++ f ++ ": {s}\n", args ++ .{e});
    os.exit(128);
}
pub fn err(comptime f: []const u8, args: anytype) void {
    eprint("error: " ++ f ++ "\n", args);
}
pub fn warn(comptime f: []const u8, args: anytype) void {
    eprint("warning: " ++ f ++ "\n", args);
}
pub fn hint(comptime f: []const u8, args: anytype) void {
    eprint("hint: " ++ f ++ "\n", args);
}
pub fn usageDie(comptime f: []const u8, args: anytype) noreturn {
    eprint(f ++ "\n", args);
    os.exit(129);
}

// ---------------- strings ----------------

pub fn fmt(comptime f: []const u8, args: anytype) []u8 {
    return std.fmt.allocPrint(gpa, f, args) catch oom();
}

pub fn dupe(s: []const u8) []u8 {
    return gpa.dupe(u8, s) catch oom();
}

pub fn concat(parts: []const []const u8) []u8 {
    return std.mem.concat(gpa, u8, parts) catch oom();
}

pub fn joinPath(a: []const u8, b: []const u8) []u8 {
    if (a.len == 0) return dupe(b);
    if (a[a.len - 1] == '/') return concat(&.{ a, b });
    return concat(&.{ a, "/", b });
}

pub fn eql(a: []const u8, b: []const u8) bool {
    return std.mem.eql(u8, a, b);
}
pub fn startsWith(a: []const u8, b: []const u8) bool {
    return std.mem.startsWith(u8, a, b);
}
pub fn endsWith(a: []const u8, b: []const u8) bool {
    return std.mem.endsWith(u8, a, b);
}
pub fn skipPrefix(a: []const u8, p: []const u8) ?[]const u8 {
    if (std.mem.startsWith(u8, a, p)) return a[p.len..];
    return null;
}
pub fn trim(s: []const u8) []const u8 {
    return std.mem.trim(u8, s, " \t\r\n");
}
pub fn trimRight(s: []const u8) []const u8 {
    return std.mem.trimEnd(u8, s, " \t\r\n");
}
pub fn lower(s: []const u8) []u8 {
    const r = dupe(s);
    for (r) |*ch| ch.* = std.ascii.toLower(ch.*);
    return r;
}

pub fn parseInt(comptime T: type, s: []const u8) ?T {
    return std.fmt.parseInt(T, s, 10) catch null;
}

pub const Buf = std.ArrayList(u8);

pub fn bufAppend(b: *Buf, s: []const u8) void {
    b.appendSlice(gpa, s) catch oom();
}
pub fn bufByte(b: *Buf, ch: u8) void {
    b.append(gpa, ch) catch oom();
}
pub fn bufPrint(b: *Buf, comptime f: []const u8, args: anytype) void {
    b.print(gpa, f, args) catch oom();
}

pub fn List(comptime T: type) type {
    return std.ArrayList(T);
}

pub fn append(comptime T: type, l: *std.ArrayList(T), v: T) void {
    l.append(gpa, v) catch oom();
}

/// Split into lines (without the trailing newline). A final line without newline is included.
pub fn splitLines(data: []const u8) [][]const u8 {
    var list: std.ArrayList([]const u8) = .empty;
    var start: usize = 0;
    var i: usize = 0;
    while (i < data.len) : (i += 1) {
        if (data[i] == '\n') {
            list.append(gpa, data[start..i]) catch oom();
            start = i + 1;
        }
    }
    if (start < data.len) list.append(gpa, data[start..]) catch oom();
    return list.items;
}

// ---------------- quoting ----------------

fn needsCQuote(ch: u8) bool {
    return ch < 0x20 or ch == '"' or ch == '\\' or ch == 0x7f or ch >= 0x80;
}

pub var quote_path_fully: bool = true;

/// git's quote_c_style: returns the name quoted if needed, else as is.
pub fn cquote(name: []const u8) []const u8 {
    var need = false;
    for (name) |ch| {
        if (needsCQuote(ch) and (quote_path_fully or ch < 0x80)) {
            need = true;
            break;
        }
    }
    if (!need) return name;
    var b: Buf = .empty;
    bufByte(&b, '"');
    cquoteInto(&b, name);
    bufByte(&b, '"');
    return b.items;
}

pub fn cquoteInto(b: *Buf, name: []const u8) void {
    for (name) |ch| {
        if (needsCQuote(ch) and (quote_path_fully or ch < 0x80)) {
            bufByte(b, '\\');
            switch (ch) {
                7 => bufByte(b, 'a'),
                8 => bufByte(b, 'b'),
                12 => bufByte(b, 'f'),
                '\n' => bufByte(b, 'n'),
                '\r' => bufByte(b, 'r'),
                '\t' => bufByte(b, 't'),
                11 => bufByte(b, 'v'),
                '\\' => bufByte(b, '\\'),
                '"' => bufByte(b, '"'),
                else => bufPrint(b, "{o:0>3}", .{ch}),
            }
        } else bufByte(b, ch);
    }
}

pub fn needsQuote(name: []const u8) bool {
    for (name) |ch| {
        if (needsCQuote(ch) and (quote_path_fully or ch < 0x80)) return true;
    }
    return false;
}

/// Unquote a C-style quoted string (starting with "). Returns the content and remaining.
pub fn cunquote(s: []const u8) ?struct { value: []u8, rest: []const u8 } {
    if (s.len == 0 or s[0] != '"') return null;
    var b: Buf = .empty;
    var i: usize = 1;
    while (i < s.len) {
        const ch = s[i];
        if (ch == '"') return .{ .value = b.items, .rest = s[i + 1 ..] };
        if (ch == '\\') {
            i += 1;
            if (i >= s.len) return null;
            const e = s[i];
            switch (e) {
                'a' => bufByte(&b, 7),
                'b' => bufByte(&b, 8),
                'f' => bufByte(&b, 12),
                'n' => bufByte(&b, '\n'),
                'r' => bufByte(&b, '\r'),
                't' => bufByte(&b, '\t'),
                'v' => bufByte(&b, 11),
                '\\' => bufByte(&b, '\\'),
                '"' => bufByte(&b, '"'),
                '0'...'3' => {
                    if (i + 2 >= s.len) return null;
                    const v = (@as(u32, e - '0') << 6) | (@as(u32, s[i + 1] - '0') << 3) | (s[i + 2] - '0');
                    bufByte(&b, @intCast(v & 0xff));
                    i += 2;
                },
                else => return null,
            }
            i += 1;
            continue;
        }
        bufByte(&b, ch);
        i += 1;
    }
    return null;
}

/// Shell single-quote (sq_quote).
pub fn sqQuote(b: *Buf, s: []const u8) void {
    bufByte(b, '\'');
    for (s) |ch| {
        if (ch == '\'' or ch == '!') {
            bufAppend(b, "'\\");
            bufByte(b, ch);
            bufByte(b, '\'');
        } else bufByte(b, ch);
    }
    bufByte(b, '\'');
}

pub fn isHex(s: []const u8) bool {
    for (s) |ch| {
        if (!std.ascii.isHex(ch)) return false;
    }
    return true;
}

/// Compute relative path from `base` dir (both relative to same root, no trailing slash) to `path`.
pub fn relativePath(path: []const u8, prefix: []const u8) []const u8 {
    // prefix is like "a/b/" (cwd relative to worktree, with trailing slash) or ""
    if (prefix.len == 0) return path;
    var common: usize = 0;
    var i: usize = 0;
    while (i < path.len and i < prefix.len and path[i] == prefix[i]) : (i += 1) {
        if (path[i] == '/') common = i + 1;
    }
    if (i == prefix.len and prefix[prefix.len - 1] == '/') common = i;
    var b: Buf = .empty;
    var j = common;
    while (j < prefix.len) : (j += 1) {
        if (prefix[j] == '/') bufAppend(&b, "../");
    }
    bufAppend(&b, path[common..]);
    if (b.items.len == 0) return "./";
    return b.items;
}

/// Normalize a path: collapse //, ., and .. components. Returns null if it escapes above root.
pub fn normalizePath(path: []const u8) ?[]u8 {
    var parts: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, path, '/');
    const absolute = path.len > 0 and path[0] == '/';
    while (it.next()) |p| {
        if (p.len == 0 or eql(p, ".")) continue;
        if (eql(p, "..")) {
            if (parts.items.len == 0) return null;
            _ = parts.pop();
            continue;
        }
        parts.append(gpa, p) catch oom();
    }
    var b: Buf = .empty;
    if (absolute) bufByte(&b, '/');
    for (parts.items, 0..) |p, i| {
        if (i > 0) bufByte(&b, '/');
        bufAppend(&b, p);
    }
    if (path.len > 0 and path[path.len - 1] == '/' and parts.items.len > 0) bufByte(&b, '/');
    return b.items;
}

pub fn dirname(path: []const u8) []const u8 {
    if (std.mem.lastIndexOfScalar(u8, path, '/')) |i| return path[0..i];
    return "";
}
pub fn basename(path: []const u8) []const u8 {
    if (std.mem.lastIndexOfScalar(u8, path, '/')) |i| return path[i + 1 ..];
    return path;
}

pub fn sortStrings(items: [][]const u8) void {
    std.mem.sort([]const u8, items, {}, struct {
        fn lt(_: void, a: []const u8, b: []const u8) bool {
            return std.mem.order(u8, a, b) == .lt;
        }
    }.lt);
}

pub fn strLess(_: void, a: []const u8, b: []const u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

/// strbuf_stripspace: drop comment lines (if comment_prefix), trailing whitespace,
/// and collapse/trim empty lines; every line ends with '\n'.
pub fn stripspace(s: []const u8, comment_prefix: ?[]const u8) []u8 {
    var out_b: Buf = .empty;
    var empties: usize = 0;
    var i: usize = 0;
    while (i < s.len) {
        const eol = std.mem.indexOfScalarPos(u8, s, i, '\n');
        const end = if (eol) |e| e + 1 else s.len;
        const line = s[i..end];
        i = end;
        if (comment_prefix) |cp| {
            if (startsWith(line, cp)) continue;
        }
        const t = std.mem.trimEnd(u8, line, " \t\n\r\x0b\x0c");
        if (t.len > 0) {
            if (empties > 0 and out_b.items.len > 0) bufByte(&out_b, '\n');
            empties = 0;
            bufAppend(&out_b, t);
            bufByte(&out_b, '\n');
        } else empties += 1;
    }
    return out_b.items;
}
