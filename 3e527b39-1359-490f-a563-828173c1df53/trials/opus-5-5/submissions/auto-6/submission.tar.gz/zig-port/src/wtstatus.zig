//! Port of wt-status.c (status machinery) from git v2.56.1.
//!
//! Public API (used by `git status` and `git commit`):
//!   prepare() Status                 wt_status_prepare
//!   initConfig(*Status)              git_status_config + determine_whence + hints
//!   finalizeDeferredConfig(*Status, Format)  builtin/commit.c finalize_deferred_config
//!   collect(*Status)                 wt_status_collect
//!   print(*Status)                   wt_status_print
//!   printfLn / printf                status_printf_ln / status_printf
//!   addCutLine / appendCutLine / locateEnd
//!   determineWhence() Whence
//!   getState(get_detached_from) State   wt_status_get_state
//!   hasUnstagedChanges / hasUncommittedChanges / requireCleanWorkTree

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const pathspec_mod = @import("pathspec.zig");
const hash = @import("hash.zig");
const index_mod = @import("index.zig");
const dir_mod = @import("dir.zig");
const refs = @import("refs.zig");
const revparse = @import("revparse.zig");
const objects = @import("objects.zig");
const cn = @import("commitnode.zig");
const commitreach = @import("commitreach.zig");
const color_mod = @import("color.zig");
const advice = @import("advice.zig");
const config = @import("config.zig");
const lockfile = @import("lockfile.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Index = index_mod.Index;

pub const Format = enum { unspecified, none, long, short, porcelain, porcelain_v2 };
pub const Whence = enum { commit, merge, cherry_pick_single, cherry_pick_multi, rebase_pick };
pub const UntrackedMode = enum(u8) { err, no, normal, all };
pub const IgnoredMode = enum(u8) { no, traditional, matching };
pub const AheadBehind = enum { unspecified, quick, full };

pub const DIRTY_SUBMODULE_UNTRACKED: u32 = 1;
pub const DIRTY_SUBMODULE_MODIFIED: u32 = 2;

pub const DETECT_RENAME: i32 = 1;
pub const DETECT_COPY: i32 = 2;

const cut_line = "------------------------ >8 ------------------------\n";

pub const Slot = enum(u8) { header = 0, updated, changed, untracked, nobranch, unmerged, local_branch, remote_branch, onbranch };
const NIL = "NIL";

const default_palette = [9][]const u8{
    "", // header (GIT_COLOR_NORMAL)
    color_mod.GREEN, // updated
    color_mod.RED, // changed
    color_mod.RED, // untracked
    color_mod.RED, // nobranch
    color_mod.RED, // unmerged
    color_mod.GREEN, // local branch
    color_mod.RED, // remote branch
    NIL, // onbranch
};

/// struct wt_status_change_data
pub const Change = struct {
    path: []const u8,
    worktree_status: u8 = 0,
    index_status: u8 = 0,
    stagemask: u32 = 0,
    mode_head: u32 = 0,
    mode_index: u32 = 0,
    mode_worktree: u32 = 0,
    oid_head: Oid = hash.zero,
    oid_index: Oid = hash.zero,
    rename_status: u8 = 0,
    rename_score: i32 = 0,
    rename_source: ?[]const u8 = null,
    dirty_submodule: u32 = 0,
    new_submodule_commits: bool = false,
};

/// struct wt_status_state
pub const State = struct {
    merge_in_progress: bool = false,
    am_in_progress: bool = false,
    am_empty_patch: bool = false,
    rebase_in_progress: bool = false,
    rebase_interactive_in_progress: bool = false,
    cherry_pick_in_progress: bool = false,
    bisect_in_progress: bool = false,
    revert_in_progress: bool = false,
    detached_at: bool = false,
    branch: ?[]const u8 = null,
    onto: ?[]const u8 = null,
    detached_from: ?[]const u8 = null,
    bisecting_from: ?[]const u8 = null,
    detached_oid: Oid = hash.zero,
    revert_head_oid: Oid = hash.zero,
    cherry_pick_head_oid: Oid = hash.zero,
    /// -1: disabled, -2: sparse index, else percentage
    sparse_checkout_percentage: i32 = -1,
};

pub const Status = struct {
    is_initial: bool = false,
    /// full ref of HEAD ("refs/heads/x"), "HEAD" if detached, null if unresolvable
    branch: ?[]const u8 = null,
    reference: []const u8 = "HEAD",
    pathspec: pathspec_mod.Pathspec = .{},
    verbose: i32 = 0,
    amend: bool = false,
    whence: Whence = .commit,
    nowarn: bool = false,
    /// false disables color entirely (commit sets it when writing to a file)
    use_color: bool = true,
    /// status.color / color.status config value
    color_bool: color_mod.ColorBool = .unknown,
    no_gettext: bool = false,
    display_comment_prefix: bool = false,
    relative_paths: bool = true,
    submodule_summary: i32 = 0,
    show_ignored_mode: IgnoredMode = .no,
    show_untracked_files: UntrackedMode = .normal,
    ignore_submodule_arg: ?[]const u8 = null,
    color_palette: [9][]const u8 = default_palette,
    colopts: u32 = 0,
    null_termination: bool = false,
    commit_template: bool = false,
    show_branch: i32 = -1,
    show_stash: bool = false,
    hints: bool = true,
    ahead_behind_flags: AheadBehind = .unspecified,
    detect_rename: i32 = -1,
    rename_score: i32 = -1,
    rename_limit: i32 = -1,
    status_format: Format = .unspecified,
    state: State = .{},
    added_cut_line: bool = false,
    oid_commit: Oid = hash.zero,
    committable: bool = false,
    workdir_dirty: bool = false,
    index_file: []const u8 = "",
    out: *util.Out = &util.stdout,
    /// true when `out` is the real stdout (C: s->fp == stdout)
    out_is_stdout: bool = true,
    prefix: ?[]const u8 = null,
    untracked_in_ms: u64 = 0,
    /// index to inspect; if null, collect() loads it (from index_file if set)
    idx: ?*Index = null,

    // deferred config (builtin/commit.c status_deferred_config), set by initConfig
    deferred_format: Format = .unspecified,
    deferred_show_branch: i32 = -1,
    deferred_ahead_behind: AheadBehind = .unspecified,

    change: std.ArrayList(*Change) = .empty,
    change_map: std.StringHashMapUnmanaged(*Change) = .empty,
    untracked: std.ArrayList([]const u8) = .empty,
    ignored: std.ArrayList([]const u8) = .empty,
};

// ---------------------------------------------------------------------------
// colors and printing

fn wantColor(cb0: color_mod.ColorBool) bool {
    var cb = cb0;
    if (cb == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| cb = color_mod.configColorBool("color.ui", e.value);
    }
    return color_mod.wantColorBool(cb, null);
}

fn color(slot: Slot, s: *Status) []const u8 {
    var c: []const u8 = "";
    if (s.use_color and wantColor(s.color_bool)) c = s.color_palette[@intFromEnum(slot)];
    if (slot == .onbranch and util.eql(c, NIL)) c = s.color_palette[@intFromEnum(Slot.header)];
    if (util.eql(c, NIL)) c = "";
    return c;
}

fn colorWrite(o: *util.Out, col: []const u8, text: []const u8) void {
    if (col.len > 0) o.write(col);
    o.write(text);
    if (col.len > 0) o.write(color_mod.RESET);
}

/// color_fprintf_ln: colored text followed by a newline.
fn colorWriteLn(o: *util.Out, col: []const u8, text: []const u8) void {
    colorWrite(o, col, text);
    o.write("\n");
}

/// The comment string (core.commentChar / core.commentString), default "#".
pub fn commentStr() []const u8 {
    const v = repo_mod.cfg.get("core.commentstring") orelse repo_mod.cfg.get("core.commentchar") orelse return "#";
    if (v.len == 0) return "#";
    if (util.eql(v, "auto")) return "#";
    return v;
}

fn vprintf(s: *Status, at_bol0: bool, col: []const u8, text: []const u8, trail: ?[]const u8) void {
    var at_bol = at_bol0;
    const o = s.out;
    if (text.len == 0) {
        var sb: util.Buf = .empty;
        if (s.display_comment_prefix) {
            util.bufAppend(&sb, commentStr());
            if (trail == null) util.bufByte(&sb, ' ');
        }
        colorWrite(o, col, sb.items);
        if (trail) |t| o.write(t);
        return;
    }
    var line_start: usize = 0;
    var linebuf: util.Buf = .empty;
    while (line_start < text.len) {
        const line = text[line_start..];
        const eol = std.mem.indexOfScalar(u8, line, '\n');
        linebuf.clearRetainingCapacity();
        if (at_bol and s.display_comment_prefix) {
            util.bufAppend(&linebuf, commentStr());
            if (line[0] != '\n' and line[0] != '\t') util.bufByte(&linebuf, ' ');
        }
        if (eol) |e| util.bufAppend(&linebuf, line[0..e]) else util.bufAppend(&linebuf, line);
        colorWrite(o, col, linebuf.items);
        if (eol) |e| {
            o.write("\n");
            line_start += e + 1;
        } else break;
        at_bol = true;
    }
    if (trail) |t| o.write(t);
}

pub fn printfLn(s: *Status, col: []const u8, comptime f: []const u8, args: anytype) void {
    vprintf(s, true, col, util.fmt(f, args), "\n");
}

pub fn printf(s: *Status, col: []const u8, comptime f: []const u8, args: anytype) void {
    vprintf(s, true, col, util.fmt(f, args), null);
}

fn printfMore(s: *Status, col: []const u8, comptime f: []const u8, args: anytype) void {
    vprintf(s, false, col, util.fmt(f, args), null);
}

fn lineOut(s: *Status, col: []const u8, text: []const u8) void {
    vprintf(s, true, col, text, "\n");
}

// ---------------------------------------------------------------------------
// prepare / config

/// wt_status_prepare()
pub fn prepare() Status {
    var s = Status{};
    s.branch = resolveHeadRefdup();
    s.reference = "HEAD";
    s.index_file = repo_mod.repo().indexPath();
    return s;
}

/// refs_resolve_refdup("HEAD", 0): full ref name HEAD points to (even if
/// unborn), "HEAD" when detached, null on error.
fn resolveHeadRefdup() ?[]const u8 {
    var name: []const u8 = "HEAD";
    var depth: usize = 0;
    while (depth < 6) : (depth += 1) {
        switch (refs.readRawFull(name)) {
            .symref => |t| name = t,
            .oid => return name,
            .missing => return if (util.eql(name, "HEAD")) null else name,
            else => return null,
        }
    }
    return null;
}

fn parseStatusSlot(slot: []const u8) ?Slot {
    const names = [_]struct { n: []const u8, s: Slot }{
        .{ .n = "header", .s = .header },
        .{ .n = "updated", .s = .updated },
        .{ .n = "changed", .s = .changed },
        .{ .n = "untracked", .s = .untracked },
        .{ .n = "nobranch", .s = .nobranch },
        .{ .n = "unmerged", .s = .unmerged },
        .{ .n = "localbranch", .s = .local_branch },
        .{ .n = "remotebranch", .s = .remote_branch },
        .{ .n = "branch", .s = .onbranch },
        .{ .n = "added", .s = .updated },
    };
    for (names) |n| if (std.ascii.eqlIgnoreCase(slot, n.n)) return n.s;
    return null;
}

fn configBool(k: []const u8, v: ?[]const u8) bool {
    const val = v orelse return true;
    return config.parseBool(val) orelse util.die("bad boolean config value '{s}' for '{s}'", .{ val, k });
}

fn configInt(k: []const u8, v: ?[]const u8) i32 {
    const val = v orelse util.die("bad numeric config value '' for '{s}': invalid unit", .{k});
    const n = config.parseInt(val) orelse util.die("bad numeric config value '{s}' for '{s}': invalid unit", .{ val, k });
    return @intCast(std.math.clamp(n, std.math.minInt(i32), std.math.maxInt(i32)));
}

/// git_config_rename()
pub fn configRename(k: []const u8, v: ?[]const u8) i32 {
    const val = v orelse return DETECT_RENAME;
    if (std.ascii.eqlIgnoreCase(val, "copies") or std.ascii.eqlIgnoreCase(val, "copy")) return DETECT_COPY;
    return if (configBool(k, val)) DETECT_RENAME else 0;
}

/// parse_untracked_setting_name()
pub fn parseUntrackedSetting(name: []const u8) UntrackedMode {
    var u = name;
    if (config.parseBool(u)) |b| u = if (b) "normal" else "no";
    if (util.eql(u, "no")) return .no;
    if (util.eql(u, "normal")) return .normal;
    if (util.eql(u, "all")) return .all;
    return .err;
}

/// Apply one config entry (git_status_config). Returns false for unknown keys.
pub fn applyConfig(s: *Status, k: []const u8, v: ?[]const u8) bool {
    if (util.startsWith(k, "column.")) {
        columnConfig(s, k, v);
        return true;
    }
    if (util.eql(k, "status.submodulesummary")) {
        if (v) |val| {
            if (config.parseBool(val)) |b| {
                // bool or int: a plain integer is an int
                if (config.parseInt(val)) |n| {
                    s.submodule_summary = @intCast(std.math.clamp(n, std.math.minInt(i32), std.math.maxInt(i32)));
                } else s.submodule_summary = if (b) -1 else 0;
            } else util.die("bad boolean config value '{s}' for '{s}'", .{ val, k });
        } else s.submodule_summary = -1;
        return true;
    }
    if (util.eql(k, "status.short")) {
        s.deferred_format = if (configBool(k, v)) .short else .none;
        return true;
    }
    if (util.eql(k, "status.branch")) {
        s.deferred_show_branch = if (configBool(k, v)) 1 else 0;
        return true;
    }
    if (util.eql(k, "status.aheadbehind")) {
        s.deferred_ahead_behind = if (configBool(k, v)) .full else .quick;
        return true;
    }
    if (util.eql(k, "status.showstash")) {
        s.show_stash = configBool(k, v);
        return true;
    }
    if (util.eql(k, "status.color") or util.eql(k, "color.status")) {
        s.color_bool = color_mod.configColorBool(k, v);
        return true;
    }
    if (util.eql(k, "status.displaycommentprefix")) {
        s.display_comment_prefix = configBool(k, v);
        return true;
    }
    const slot_name = util.skipPrefix(k, "status.color.") orelse util.skipPrefix(k, "color.status.");
    if (slot_name) |sn| {
        const slot = parseStatusSlot(sn) orelse return true;
        const val = v orelse util.die("missing value for '{s}'", .{k});
        const c = color_mod.parseColor(val) orelse util.die("invalid color value: {s}", .{val});
        s.color_palette[@intFromEnum(slot)] = c;
        return true;
    }
    if (util.eql(k, "status.relativepaths")) {
        s.relative_paths = configBool(k, v);
        return true;
    }
    if (util.eql(k, "status.showuntrackedfiles")) {
        const u = parseUntrackedSetting(v orelse "");
        if (u == .err) {
            util.err("Invalid untracked files mode '{s}'", .{v orelse ""});
            util.die("bad config variable '{s}'", .{k});
        }
        s.show_untracked_files = u;
        return true;
    }
    if (util.eql(k, "diff.renamelimit")) {
        if (s.rename_limit == -1) s.rename_limit = configInt(k, v);
        return true;
    }
    if (util.eql(k, "status.renamelimit")) {
        s.rename_limit = configInt(k, v);
        return true;
    }
    if (util.eql(k, "diff.renames")) {
        if (s.detect_rename == -1) s.detect_rename = configRename(k, v);
        return true;
    }
    if (util.eql(k, "status.renames")) {
        s.detect_rename = configRename(k, v);
        return true;
    }
    return false;
}

/// status_init_config() minus wt_status_prepare: read config into s,
/// determine whence, and set hints.
pub fn initConfig(s: *Status) void {
    for (repo_mod.cfg.entries.items) |e| {
        _ = applyConfig(s, e.key, e.value);
    }
    s.whence = determineWhence();
    s.hints = advice.enabled("statusHints");
}

/// finalize_deferred_config() from builtin/commit.c; `fmt` is the format
/// selected on the command line (or .unspecified). Sets s.status_format.
pub fn finalizeDeferredConfig(s: *Status, fmt0: Format) void {
    var fmt = fmt0;
    const use_deferred = fmt != .porcelain and fmt != .porcelain_v2 and !s.null_termination;
    if (s.null_termination) {
        if (fmt == .none or fmt == .unspecified) {
            fmt = .porcelain;
        } else if (fmt == .long) {
            util.die("options '{s}' and '{s}' cannot be used together", .{ "--long", "-z" });
        }
    }
    if (use_deferred and fmt == .unspecified) fmt = s.deferred_format;
    if (fmt == .unspecified) fmt = .none;
    if (use_deferred and s.show_branch < 0) s.show_branch = s.deferred_show_branch;
    if (s.show_branch < 0) s.show_branch = 0;
    if (use_deferred and s.ahead_behind_flags == .unspecified) s.ahead_behind_flags = s.deferred_ahead_behind;
    if (s.ahead_behind_flags == .unspecified) s.ahead_behind_flags = .full;
    s.status_format = fmt;
}

/// determine_whence() + sequencer_determine_whence()
pub fn determineWhence() Whence {
    const r = repo_mod.repo();
    if (os.exists(r.gitPath("MERGE_HEAD"))) return .merge;
    if (refs.exists("CHERRY_PICK_HEAD")) {
        var w: Whence = .cherry_pick_single;
        if (os.exists(r.gitPath("sequencer"))) w = .cherry_pick_multi;
        const rebase_head = revparse.getOid("REBASE_HEAD");
        const cp_head = revparse.getOid("CHERRY_PICK_HEAD");
        if (os.exists(r.gitPath("rebase-merge")) and rebase_head != null and cp_head != null and hash.eql(rebase_head.?, cp_head.?)) {
            w = .rebase_pick;
        } else w = .cherry_pick_single;
        return w;
    }
    return .commit;
}

// ---------------------------------------------------------------------------
// column support (port of the parts of column.c used by status)

const COL_LAYOUT_MASK: u32 = 0x000F;
const COL_COLUMN: u32 = 0;
const COL_ROW: u32 = 1;
const COL_PLAIN: u32 = 15;
const COL_ENABLE_MASK: u32 = 0x0030;
const COL_ENABLED: u32 = 0x0010;
const COL_AUTO: u32 = 0x0020;
const COL_DISABLED: u32 = 0x0000;
const COL_PARSEOPT: u32 = 0x0040;
const COL_DENSE: u32 = 0x0080;

fn columnActive(colopts: u32) bool {
    return colopts & COL_ENABLE_MASK == COL_ENABLED;
}

/// parse_option() / parse_config() for column options; returns false on error.
pub fn parseColumnOption(value: []const u8, colopts: *u32) bool {
    var it = std.mem.tokenizeAny(u8, value, " ,");
    var group_set: u32 = 0;
    while (it.next()) |word0| {
        var word = word0;
        var set = true;
        if (util.skipPrefix(word, "no")) |r| {
            if (util.eql(r, "dense")) {
                set = false;
                word = r;
            }
        }
        const Entry = struct { n: []const u8, mask: u32, v: u32 };
        const table = [_]Entry{
            .{ .n = "always", .mask = COL_ENABLE_MASK, .v = COL_ENABLED },
            .{ .n = "never", .mask = COL_ENABLE_MASK, .v = COL_DISABLED },
            .{ .n = "auto", .mask = COL_ENABLE_MASK, .v = COL_AUTO },
            .{ .n = "plain", .mask = COL_LAYOUT_MASK, .v = COL_PLAIN },
            .{ .n = "column", .mask = COL_LAYOUT_MASK, .v = COL_COLUMN },
            .{ .n = "row", .mask = COL_LAYOUT_MASK, .v = COL_ROW },
            .{ .n = "dense", .mask = COL_DENSE, .v = COL_DENSE },
        };
        var found = false;
        for (table) |t| {
            if (!util.eql(word, t.n)) continue;
            found = true;
            if (t.mask == COL_DENSE) {
                if (set) colopts.* |= COL_DENSE else colopts.* &= ~COL_DENSE;
            } else {
                if (t.mask == COL_LAYOUT_MASK) group_set |= 1;
                if (t.mask == COL_ENABLE_MASK) group_set |= 2;
                colopts.* = (colopts.* & ~t.mask) | t.v;
            }
        }
        if (!found) {
            util.err("unsupported option '{s}'", .{word0});
            return false;
        }
    }
    // a layout option implies "always" when no enable option was given
    if (group_set & 1 != 0 and group_set & 2 == 0) colopts.* = (colopts.* & ~COL_ENABLE_MASK) | COL_ENABLED;
    return true;
}

fn columnConfig(s: *Status, k: []const u8, v: ?[]const u8) void {
    const name = k["column.".len..];
    if (util.eql(name, "ui") or util.eql(name, "status")) {
        const val = v orelse util.die("missing value for '{s}'", .{k});
        if (!parseColumnOption(val, &s.colopts)) util.die("invalid column.{s} mode {s}", .{ name, val });
    }
}

/// finalize_colopts(): resolve "auto" against stdout being a terminal.
pub fn finalizeColopts(colopts: *u32, stdout_is_tty: i32) void {
    if (colopts.* & COL_ENABLE_MASK == COL_AUTO) {
        var tty = stdout_is_tty;
        if (tty < 0) tty = if (os.isatty(1)) 1 else 0;
        colopts.* &= ~COL_ENABLE_MASK;
        if (tty != 0 or color_mod.pagerInUse()) colopts.* |= COL_ENABLED;
    }
}

extern "c" fn ioctl(fd: c_int, req: c_ulong, ...) c_int;

fn termColumns() usize {
    if (os.getenv("COLUMNS")) |c| {
        if (std.fmt.parseInt(usize, c, 10)) |n| {
            if (n > 0) return n;
        } else |_| {}
    }
    var ws: [4]u16 = .{ 0, 0, 0, 0 };
    if (ioctl(1, 0x5413, &ws) == 0 and ws[1] > 0) return ws[1];
    return 80;
}

fn strWidth(str: []const u8) usize {
    // utf8_strwidth, ignoring ANSI color sequences
    var w: usize = 0;
    var i: usize = 0;
    while (i < str.len) {
        const ch = str[i];
        if (ch == 0x1b and i + 1 < str.len and str[i + 1] == '[') {
            i += 2;
            while (i < str.len and (std.ascii.isDigit(str[i]) or str[i] == ';')) i += 1;
            if (i < str.len and str[i] == 'm') i += 1;
            continue;
        }
        if (ch < 0x80) {
            w += 1;
            i += 1;
            continue;
        }
        const len = std.unicode.utf8ByteSequenceLength(ch) catch {
            w += 1;
            i += 1;
            continue;
        };
        if (i + len > str.len) {
            w += 1;
            i += 1;
            continue;
        }
        const cp = std.unicode.utf8Decode(str[i .. i + len]) catch {
            w += 1;
            i += 1;
            continue;
        };
        w += if (isWide(cp)) 2 else 1;
        i += len;
    }
    return w;
}

fn isWide(cp: u21) bool {
    return (cp >= 0x1100 and cp <= 0x115f) or (cp >= 0x2e80 and cp <= 0xa4cf and cp != 0x303f) or
        (cp >= 0xac00 and cp <= 0xd7a3) or (cp >= 0xf900 and cp <= 0xfaff) or (cp >= 0xfe30 and cp <= 0xfe6f) or
        (cp >= 0xff00 and cp <= 0xff60) or (cp >= 0xffe0 and cp <= 0xffe6) or (cp >= 0x20000 and cp <= 0x3fffd);
}

const ColumnOpts = struct { width: usize = 0, padding: usize = 1, indent: []const u8 = "", nl: []const u8 = "\n" };

const ColData = struct {
    n: usize,
    layout: u32,
    rows: usize = 0,
    cols: usize = 0,
    len: []usize,
    width: ?[]usize = null,
    fn linear(d: *const ColData, x: usize, y: usize) usize {
        if (d.layout == COL_COLUMN) return x * d.rows + y;
        return y * d.cols + x;
    }
    fn computeColumnWidth(d: *ColData) void {
        const w = d.width.?;
        for (0..d.cols) |x| {
            w[x] = d.linear(x, 0);
            for (0..d.rows) |y| {
                const i = d.linear(x, y);
                if (i < d.n and d.len[w[x]] < d.len[i]) w[x] = i;
            }
        }
    }
};

/// print_columns() (column.c)
fn printColumns(o: *util.Out, list: []const []const u8, colopts: u32, copts: ColumnOpts) void {
    if (list.len == 0) return;
    const width: usize = if (copts.width > 0) copts.width else termColumns() - 1;
    if (!columnActive(colopts)) {
        for (list) |item| {
            o.write(item);
            o.write("\n");
        }
        return;
    }
    const layout = colopts & COL_LAYOUT_MASK;
    if (layout == COL_PLAIN) {
        for (list) |item| {
            o.write(copts.indent);
            o.write(item);
            o.write(copts.nl);
        }
        return;
    }
    var d = ColData{ .n = list.len, .layout = layout, .len = gpa.alloc(usize, list.len) catch util.oom() };
    for (list, 0..) |item, i| d.len[i] = strWidth(item);
    // layout()
    var initial_width: usize = 0;
    for (d.len) |l| if (initial_width < l) {
        initial_width = l;
    };
    initial_width += copts.padding;
    const avail: usize = if (width > copts.indent.len) width - copts.indent.len else 0;
    d.cols = avail / initial_width;
    if (d.cols == 0) d.cols = 1;
    d.rows = (d.n + d.cols - 1) / d.cols;
    if (colopts & COL_DENSE != 0) {
        // shrink_columns()
        d.width = gpa.alloc(usize, d.cols) catch util.oom();
        while (d.rows > 1) {
            const rows = d.rows;
            const cols = d.cols;
            d.rows -= 1;
            d.cols = (d.n + d.rows - 1) / d.rows;
            if (d.cols != cols) d.width = gpa.realloc(d.width.?, d.cols) catch util.oom();
            d.computeColumnWidth();
            var total: usize = copts.indent.len;
            for (0..d.cols) |x| total += d.len[d.width.?[x]] + copts.padding;
            if (total > width) {
                d.rows = rows;
                d.cols = cols;
                break;
            }
        }
        if (d.width.?.len < d.cols) d.width = gpa.realloc(d.width.?, d.cols) catch util.oom();
        d.computeColumnWidth();
    }
    for (0..d.rows) |y| {
        for (0..d.cols) |x| {
            // display_cell()
            const i = d.linear(x, y);
            if (i >= d.n) break;
            var len: isize = @intCast(d.len[i]);
            if (d.width) |w| {
                const cw = d.len[w[x]];
                if (cw < initial_width) {
                    len += @as(isize, @intCast(initial_width - cw));
                    len -= @as(isize, @intCast(copts.padding));
                }
            }
            const newline = if (layout == COL_COLUMN) i + d.rows >= d.n else (x == d.cols - 1 or i == d.n - 1);
            if (x == 0) o.write(copts.indent);
            o.write(list[i]);
            if (newline) {
                o.write(copts.nl);
            } else {
                var pad: isize = @as(isize, @intCast(initial_width)) - len;
                while (pad > 0) : (pad -= 1) o.byte(' ');
            }
        }
    }
}

// ---------------------------------------------------------------------------
// TEMPORARY STUBS (being replaced)

pub fn collect(s: *Status) void {
    _ = s;
}
pub fn print(s: *Status) void {
    _ = s;
}
pub fn addCutLine(s: *Status) void {
    if (s.added_cut_line) return;
    s.added_cut_line = true;
    var sb: util.Buf = .empty;
    appendCutLine(&sb);
    s.out.write(sb.items);
}
pub fn appendCutLine(buf: *util.Buf) void {
    const explanation = "Do not modify or remove the line above.\nEverything below it will be ignored.";
    const cs = commentStr();
    addCommentedLines(buf, cs, cut_line);
    addCommentedLines(buf, cs, explanation);
}

/// strbuf_add_commented_lines()
pub fn addCommentedLines(buf: *util.Buf, cs: []const u8, text: []const u8) void {
    var it = text;
    while (it.len > 0) {
        const nl = std.mem.indexOfScalar(u8, it, '\n');
        const line = if (nl) |n| it[0..n] else it;
        util.bufAppend(buf, cs);
        if (line.len > 0 and line[0] != '\t') util.bufByte(buf, ' ');
        util.bufAppend(buf, line);
        util.bufByte(buf, '\n');
        it = if (nl) |n| it[n + 1 ..] else it[it.len..];
    }
}

/// wt_status_locate_end()
pub fn locateEnd(buf: []const u8) usize {
    const pattern = util.concat(&.{ "\n", commentStr(), " ", cut_line });
    if (util.startsWith(buf, pattern[1..])) return 0;
    if (std.mem.indexOf(u8, buf, pattern)) |p| {
        if (p + 1 < buf.len) return p + 1;
    }
    return buf.len;
}
