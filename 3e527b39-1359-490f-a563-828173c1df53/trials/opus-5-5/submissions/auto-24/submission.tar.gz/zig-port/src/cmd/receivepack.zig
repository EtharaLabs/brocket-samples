//! git receive-pack (port of builtin/receive-pack.c, without push
//! certificates and shallow updates).

const std = @import("std");
const c = std.c;
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const objects = @import("../objects.zig");
const pkt = @import("../pktline.zig");
const proc = @import("../proc.zig");
const hook = @import("../hook.zig");
const worktree = @import("../worktree.zig");
const up = @import("uploadpack.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

extern "c" fn fork() c_int;
extern "c" fn _exit(code: c_int) noreturn;
extern "c" fn mkdtemp(template: [*:0]u8) ?[*:0]u8;

const DenyAction = enum { unconfigured, ignore, warn, refuse, update_instead };

var deny_deletes = false;
var deny_non_fast_forwards = false;
var deny_current_branch: DenyAction = .unconfigured;
var deny_delete_current: DenyAction = .unconfigured;
var receive_fsck_objects: i32 = -1;
var transfer_fsck_objects: i32 = -1;
var advertise_atomic_push = true;
var advertise_push_options = false;
var prefer_ofs_delta = true;
var auto_update_server_info = false;
var unpack_limit: u32 = 100;

var report_status = false;
var report_status_v2 = false;
var use_sideband = false;
var use_atomic = false;
var use_push_options = false;
var quiet = false;
var reject_thin = false;
var skip_connectivity_check = false;
var stateless_rpc = false;
var advertise_refs = false;
var sent_capabilities = false;

const Report = struct {
    ref_name: ?[]const u8 = null,
    old: ?Oid = null,
    new: ?Oid = null,
    forced_update: bool = false,
};

const RUN_PROC_RECEIVE_SCHEDULED: u2 = 1;
const RUN_PROC_RECEIVE_RETURNED: u2 = 2;

const Command = struct {
    old: Oid,
    new: Oid,
    name: []const u8,
    error_string: ?[]const u8 = null,
    skip_update: bool = false,
    did_not_exist: bool = false,
    run_proc_receive: u2 = 0,
    reports: std.ArrayList(*Report) = .empty,
};

const ProcReceiveRef = struct {
    want_add: bool = false,
    want_delete: bool = false,
    want_modify: bool = false,
    negative: bool = false,
    prefix: []const u8 = "",
};

var proc_receive_refs: std.ArrayList(ProcReceiveRef) = .empty;
var fsck_msg_types: util.Buf = .empty;

fn procReceiveRefAppend(value: []const u8) void {
    var r: ProcReceiveRef = .{};
    var prefix = value;
    if (std.mem.indexOfScalar(u8, value, ':')) |colon| {
        for (value[0..colon]) |ch| switch (ch) {
            'a' => r.want_add = true,
            'd' => r.want_delete = true,
            'm' => r.want_modify = true,
            '!' => r.negative = true,
            else => {},
        };
        prefix = value[colon + 1 ..];
    } else {
        r.want_add = true;
        r.want_delete = true;
        r.want_modify = true;
    }
    var len = prefix.len;
    while (len > 0 and prefix[len - 1] == '/') len -= 1;
    r.prefix = util.dupe(prefix[0..len]);
    proc_receive_refs.append(gpa, r) catch util.oom();
}

fn procReceiveRefMatches(cmd: *const Command) bool {
    for (proc_receive_refs.items) |p| {
        if (!p.want_add and hash.isZero(cmd.old)) continue;
        if (!p.want_delete and hash.isZero(cmd.new)) continue;
        if (!p.want_modify and !hash.isZero(cmd.old) and !hash.isZero(cmd.new)) continue;
        const m = if (util.skipPrefix(cmd.name, p.prefix)) |rem| (rem.len == 0 or rem[0] == '/') else false;
        if (m) {
            if (!p.negative) return true;
        } else if (p.negative) return true;
    }
    return false;
}

fn parseDenyAction(key: []const u8) ?DenyAction {
    const v = repo_mod.cfg.get(key) orelse {
        if (repo_mod.cfg.getEntry(key) != null) return .refuse; // bare "key" = true
        return null;
    };
    if (std.ascii.eqlIgnoreCase(v, "ignore")) return .ignore;
    if (std.ascii.eqlIgnoreCase(v, "warn")) return .warn;
    if (std.ascii.eqlIgnoreCase(v, "refuse")) return .refuse;
    if (std.ascii.eqlIgnoreCase(v, "updateinstead")) return .update_instead;
    if (repo_mod.cfg.getBool(key) orelse false) return .refuse;
    return .ignore;
}

fn loadConfig() void {
    const cfg = repo_mod.cfg;
    if (cfg.getBool("receive.denydeletes")) |b| deny_deletes = b;
    if (cfg.getBool("receive.denynonfastforwards")) |b| deny_non_fast_forwards = b;
    if (parseDenyAction("receive.denycurrentbranch")) |d| deny_current_branch = d;
    if (parseDenyAction("receive.denydeletecurrent")) |d| deny_delete_current = d;
    if (cfg.getBool("receive.fsckobjects")) |b| receive_fsck_objects = @intFromBool(b);
    if (cfg.getBool("transfer.fsckobjects")) |b| transfer_fsck_objects = @intFromBool(b);
    if (cfg.getBool("repack.usedeltabaseoffset")) |b| prefer_ofs_delta = b;
    if (cfg.getBool("receive.updateserverinfo")) |b| auto_update_server_info = b;
    if (cfg.getBool("receive.advertiseatomic")) |b| advertise_atomic_push = b;
    if (cfg.getBool("receive.advertisepushoptions")) |b| advertise_push_options = b;
    if (cfg.get("transfer.unpacklimit")) |v| {
        if (util.parseInt(u32, v)) |n| unpack_limit = n;
    }
    if (cfg.get("receive.unpacklimit")) |v| {
        if (util.parseInt(u32, v)) |n| unpack_limit = n;
    }
    const config = @import("../config.zig");
    const fsck = @import("../fsck.zig");
    for (cfg.entries.items) |e| {
        if (util.eql(e.key, "receive.procreceiverefs")) {
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                fsck.dieConfig(e);
            };
            procReceiveRefAppend(v);
            continue;
        }
        if (util.eql(e.key, "receive.fsck.skiplist")) {
            switch (config.configPathname(e.key, e.value)) {
                .ok => |p| if (p) |path| {
                    util.bufPrint(&fsck_msg_types, "{c}skiplist={s}", .{ @as(u8, if (fsck_msg_types.items.len > 0) ',' else '='), path });
                },
                .err => fsck.dieConfig(e),
            }
            continue;
        }
        if (util.skipPrefix(e.key, "receive.fsck.")) |id| {
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                fsck.dieConfig(e);
            };
            if (fsck.parseMsgId(id) != null) {
                if (!util.eql(v, "error") and !util.eql(v, "warn") and !util.eql(v, "ignore"))
                    util.die("Unknown fsck message type: '{s}'", .{v});
                util.bufPrint(&fsck_msg_types, "{c}{s}={s}", .{ @as(u8, if (fsck_msg_types.items.len > 0) ',' else '='), id, v });
            } else util.warn("skipping unknown msg id '{s}'", .{id});
        }
    }
}

// ---------------- messages ----------------

/// rp_error / rp_warning: when the sideband muxer is active, fd 2 is
/// already redirected into it.
fn rpError(comptime f: []const u8, args: anytype) void {
    util.ewrite(util.fmt("error: " ++ f ++ "\n", args));
}

fn rpWarning(comptime f: []const u8, args: anytype) void {
    util.ewrite(util.fmt("warning: " ++ f ++ "\n", args));
}

/// Sideband muxer: a forked helper copies everything written to our fd 2
/// (and our children's) onto band 2 of fd 1.
const Muxer = struct {
    pid: c_int = -1,
    saved_err: c_int = -1,

    fn start(self: *Muxer) void {
        if (!use_sideband) return;
        util.flushStdout();
        var fds: [2]c_int = undefined;
        if (c.pipe(&fds) != 0) return;
        const pid = fork();
        if (pid < 0) {
            os.close(fds[0]);
            os.close(fds[1]);
            return;
        }
        if (pid == 0) {
            os.close(fds[1]);
            var buf: [128]u8 = undefined;
            while (true) {
                const n = c.read(fds[0], &buf, buf.len);
                if (n < 0 and os.errno() == 4) continue;
                if (n <= 0) break;
                const len: usize = @intCast(n);
                var hdr: [5]u8 = undefined;
                _ = std.fmt.bufPrint(hdr[0..4], "{x:0>4}", .{len + 5}) catch unreachable;
                hdr[4] = 2;
                os.writeAll(1, &hdr) catch break;
                os.writeAll(1, buf[0..len]) catch break;
            }
            _exit(0);
        }
        os.close(fds[0]);
        self.saved_err = c.dup(2);
        _ = c.dup2(fds[1], 2);
        os.close(fds[1]);
        self.pid = pid;
    }

    fn finish(self: *Muxer) void {
        if (self.pid < 0) return;
        if (self.saved_err >= 0) {
            _ = c.dup2(self.saved_err, 2);
            os.close(self.saved_err);
            self.saved_err = -1;
        }
        _ = proc.wait(self.pid);
        self.pid = -1;
    }
};

// ---------------- advertisement ----------------

fn showRef(path: []const u8, oid: Oid) void {
    if (sent_capabilities) {
        pkt.writeFmt(1, "{s} {s}\n", .{ hash.hex(oid), path });
        return;
    }
    var cap: util.Buf = .empty;
    util.bufAppend(&cap, "report-status report-status-v2 delete-refs side-band-64k quiet");
    if (advertise_atomic_push) util.bufAppend(&cap, " atomic");
    if (prefer_ofs_delta) util.bufAppend(&cap, " ofs-delta");
    if (advertise_push_options) util.bufAppend(&cap, " push-options");
    util.bufAppend(&cap, " object-format=sha1");
    util.bufAppend(&cap, " agent=");
    util.bufAppend(&cap, up.agentSanitized());
    pkt.writeFmt(1, "{s} {s}\x00{s}\n", .{ hash.hex(oid), path, cap.items });
    sent_capabilities = true;
}

fn writeHeadInfo() void {
    var seen: hash.OidSet = .empty;
    for (refs.iterate("refs/", .{ .check_objects = false })) |r| {
        if (up.refIsHidden("receive", r.name)) continue;
        seen.put(gpa, r.oid, {}) catch util.oom();
        showRef(r.name, r.oid);
    }
    // alternates' refs are advertised as ".have"
    for (alternateRefTips()) |oid| {
        if (seen.contains(oid)) continue;
        seen.put(gpa, oid, {}) catch util.oom();
        showRef(".have", oid);
    }
    if (!sent_capabilities) showRef("capabilities^{}", hash.zero);
    pkt.flush(1);
}

/// Tips of refs in repositories we borrow objects from (objects/info/alternates).
fn alternateRefTips() []Oid {
    var out: std.ArrayList(Oid) = .empty;
    const r = repo_mod.repo();
    const data = os.readFile(util.concat(&.{ r.odb().objects_dir, "/info/alternates" })) orelse return out.items;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        const line = util.trimRight(line0);
        if (line.len == 0 or line[0] == '#') continue;
        var path = line;
        if (path[0] != '/') path = util.concat(&.{ r.odb().objects_dir, "/", path });
        // ref tips of the alternate repository: run for-each-ref there
        const repo_dir = std.fs.path.dirname(path) orelse continue;
        const res = os.run(&.{ proc.gitBinary(), "--git-dir", repo_dir, "for-each-ref", "--format=%(objectname)" }, .{
            .capture_stdout = true,
            .no_stdin = true,
            .unset_env = &@import("../transport.zig").local_repo_env,
        });
        if (res.status != 0) continue;
        var lit = std.mem.splitScalar(u8, res.stdout, '\n');
        while (lit.next()) |l| {
            if (hash.fromHex(util.trim(l))) |o| out.append(gpa, o) catch util.oom();
        }
    }
    return out.items;
}

// ---------------- reading commands ----------------

fn featureRequested(list: []const u8, name: []const u8) bool {
    return @import("../transport.zig").capValue(list, name) != null;
}

fn readHeadInfo(rd: *pkt.Reader) []*Command {
    var cmds: std.ArrayList(*Command) = .empty;
    while (true) {
        if (rd.read() != .normal) break;
        const full = rd.line;
        if (full.len > 8 and util.startsWith(full, "shallow ")) {
            if (hash.fromHex(full[8..]) == null) util.die("protocol error: expected shallow sha, got '{s}'", .{full[8..]});
            continue;
        }
        var line = full;
        if (std.mem.indexOfScalar(u8, full, 0)) |nul| {
            line = full[0..nul];
            const features = full[nul + 1 ..];
            if (featureRequested(features, "report-status")) report_status = true;
            if (featureRequested(features, "report-status-v2")) report_status_v2 = true;
            if (featureRequested(features, "side-band-64k")) use_sideband = true;
            if (featureRequested(features, "quiet")) quiet = true;
            if (advertise_atomic_push and featureRequested(features, "atomic")) use_atomic = true;
            if (advertise_push_options and featureRequested(features, "push-options")) use_push_options = true;
            const fmt_ = @import("../transport.zig").capValue(features, "object-format") orelse "sha1";
            if (!util.eql(fmt_, "sha1")) util.die("error: unsupported object format '{s}'", .{fmt_});
        }
        if (util.eql(line, "push-cert")) util.die("protocol error: push certificates are not supported", .{});
        if (line.len < 83 or line[40] != ' ' or line[81] != ' ')
            util.die("protocol error: expected old/new/ref, got '{s}'", .{line});
        const old = hash.fromHex(line[0..40]) orelse util.die("protocol error: expected old/new/ref, got '{s}'", .{line});
        const new = hash.fromHex(line[41..81]) orelse util.die("protocol error: expected old/new/ref, got '{s}'", .{line});
        const cmd = gpa.create(Command) catch util.oom();
        cmd.* = .{ .old = old, .new = new, .name = util.dupe(line[82..]) };
        cmds.append(gpa, cmd) catch util.oom();
    }
    return cmds.items;
}

fn readPushOptions(rd: *pkt.Reader) [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    while (rd.read() == .normal) l.append(gpa, util.dupe(rd.line)) catch util.oom();
    return l.items;
}

// ---------------- quarantine + unpack ----------------

const Quarantine = struct {
    path: []const u8,
    env: std.ArrayList([2][]const u8) = .empty,
    keep_files: std.ArrayList([]const u8) = .empty,
};

var quarantine: ?*Quarantine = null;

fn quarantineCreate() ?*Quarantine {
    const r = repo_mod.repo();
    const objdir = worktree.absolutePath(r.odb().objects_dir);
    const tmpl = util.concat(&.{ objdir, "/tmp_objdir-incoming-XXXXXX\x00" });
    const buf = util.dupe(tmpl);
    if (mkdtemp(@ptrCast(buf.ptr)) == null) return null;
    const p: []const u8 = buf[0 .. buf.len - 1];
    _ = os.mkdir(util.concat(&.{ p, "/pack" }), 0o777);
    const q = gpa.create(Quarantine) catch util.oom();
    q.* = .{ .path = util.dupe(p) };
    const alt = if (os.getenv("GIT_ALTERNATE_OBJECT_DIRECTORIES")) |old| util.concat(&.{ old, ":", objdir }) else objdir;
    q.env.append(gpa, .{ "GIT_ALTERNATE_OBJECT_DIRECTORIES", alt }) catch util.oom();
    q.env.append(gpa, .{ "GIT_OBJECT_DIRECTORY", q.path }) catch util.oom();
    q.env.append(gpa, .{ "GIT_QUARANTINE_PATH", q.path }) catch util.oom();
    return q;
}

fn packCopyPriority(name: []const u8) u8 {
    if (!util.startsWith(name, "pack")) return 0;
    if (util.endsWith(name, ".keep")) return 1;
    if (util.endsWith(name, ".pack")) return 2;
    if (util.endsWith(name, ".rev")) return 3;
    if (util.endsWith(name, ".idx")) return 4;
    return 5;
}

fn lessPack(_: void, a: os.DirEntry, b: os.DirEntry) bool {
    const pa = packCopyPriority(a.name);
    const pb = packCopyPriority(b.name);
    if (pa != pb) return pa < pb;
    return std.mem.lessThan(u8, a.name, b.name);
}

fn migrateDir(src: []const u8, dst: []const u8) bool {
    const ents = os.listDir(src) orelse return true;
    std.mem.sort(os.DirEntry, ents, {}, lessPack);
    var ok = true;
    for (ents) |e| {
        const s = util.concat(&.{ src, "/", e.name });
        const d = util.concat(&.{ dst, "/", e.name });
        if (os.isDir(s)) {
            if (!os.isDir(d)) _ = os.mkdir(d, 0o777);
            if (!migrateDir(s, d)) ok = false;
            continue;
        }
        if (os.exists(d)) {
            _ = os.unlink(s);
            continue;
        }
        if (!os.rename(s, d)) ok = false;
    }
    return ok;
}

fn quarantineMigrate(q: *Quarantine) bool {
    const r = repo_mod.repo();
    const ok = migrateDir(q.path, r.odb().objects_dir);
    os.removeTree(q.path);
    quarantine = null;
    r.odb().reloadPacks();
    return ok;
}

fn quarantineDestroy() void {
    if (quarantine) |q| {
        os.removeTree(q.path);
        quarantine = null;
    }
}

fn dieHook(_: []const u8) void {
    quarantineDestroy();
}

/// Read the pack from the client and store it via unpack-objects or
/// index-pack. Returns an error string, or null on success.
fn unpack(rd: *pkt.Reader) ?[]const u8 {
    var head: [12]u8 = undefined;
    var got: usize = 0;
    while (got < 12) {
        const n = rd.readRaw(head[got..]);
        if (n == 0) return "eof before pack header was fully read";
        got += n;
    }
    if (!std.mem.eql(u8, head[0..4], "PACK")) return "protocol error (pack signature mismatch detected)";
    const ver = std.mem.readInt(u32, head[4..8], .big);
    if (ver != 2 and ver != 3) return "protocol error (pack version unsupported)";
    const nr = std.mem.readInt(u32, head[8..12], .big);
    const fsck = if (receive_fsck_objects >= 0) receive_fsck_objects == 1 else transfer_fsck_objects == 1;
    var args: std.ArrayList([]const u8) = .empty;
    const use_unpack = nr < unpack_limit;
    if (use_unpack) {
        args.append(gpa, "unpack-objects") catch util.oom();
        if (quiet) args.append(gpa, "-q") catch util.oom();
        if (fsck) args.append(gpa, util.concat(&.{ "--strict", fsck_msg_types.items })) catch util.oom();
    } else {
        args.appendSlice(gpa, &.{ "index-pack", "--stdin" }) catch util.oom();
        args.append(gpa, util.fmt("--keep=receive-pack {d} on {s}", .{ proc.getPid(), proc.hostname() })) catch util.oom();
        if (fsck) args.append(gpa, util.concat(&.{ "--strict", fsck_msg_types.items })) catch util.oom();
        if (!reject_thin) args.append(gpa, "--fix-thin") catch util.oom();
    }
    const env: []const [2][]const u8 = if (quarantine) |q| q.env.items else &.{};
    proc.ignoreSigpipe();
    var ch = proc.spawnGit(args.items, .{ .pipe_in = true, .pipe_out = !use_unpack, .env = env });
    var write_ok = true;
    os.writeAll(ch.in, &head) catch {
        write_ok = false;
    };
    var buf: [65536]u8 = undefined;
    while (write_ok) {
        const n = rd.readRaw(&buf);
        if (n == 0) break;
        os.writeAll(ch.in, buf[0..n]) catch {
            write_ok = false;
        };
    }
    proc.closeFd(&ch.in);
    if (!use_unpack) {
        var out: util.Buf = .empty;
        while (true) {
            const n = c.read(ch.out, &buf, buf.len);
            if (n <= 0) break;
            util.bufAppend(&out, buf[0..@intCast(n)]);
        }
        proc.closeFd(&ch.out);
        if (util.skipPrefix(out.items, "keep\t")) |rest| {
            const h = util.trimRight(rest);
            if (quarantine) |q| {
                _ = q;
                keep_hash = util.dupe(h);
            }
        }
    }
    const rc = proc.wait(ch.pid);
    if (rc != 0) return if (use_unpack) "unpack-objects abnormal exit" else "index-pack abnormal exit";
    return null;
}

var keep_hash: ?[]const u8 = null;

fn removeKeepFile() void {
    const h = keep_hash orelse return;
    const r = repo_mod.repo();
    _ = os.unlink(util.concat(&.{ r.odb().objects_dir, "/pack/pack-", h, ".keep" }));
    keep_hash = null;
}

// ---------------- hooks ----------------

fn pushOptionEnv(env: *std.ArrayList([2][]const u8), push_options: []const []const u8) void {
    for (push_options, 0..) |o, i| env.append(gpa, .{ util.fmt("GIT_PUSH_OPTION_{d}", .{i}), o }) catch util.oom();
    env.append(gpa, .{ "GIT_PUSH_OPTION_COUNT", util.fmt("{d}", .{push_options.len}) }) catch util.oom();
}

fn runReceiveHook(cmds: []const *Command, name: []const u8, skip_broken: bool, push_options: []const []const u8) u8 {
    if (hook.find(name) == null) return 0;
    var input: util.Buf = .empty;
    var any = false;
    for (cmds) |cmd| {
        if (skip_broken and (cmd.error_string != null or cmd.did_not_exist)) continue;
        any = true;
        if (cmd.reports.items.len > 0) {
            for (cmd.reports.items) |r| {
                util.bufPrint(&input, "{s} {s} {s}\n", .{ hash.hex(r.old orelse cmd.old), hash.hex(r.new orelse cmd.new), r.ref_name orelse cmd.name });
            }
        } else util.bufPrint(&input, "{s} {s} {s}\n", .{ hash.hex(cmd.old), hash.hex(cmd.new), cmd.name });
    }
    if (!any) return 0;
    var env: std.ArrayList([2][]const u8) = .empty;
    pushOptionEnv(&env, push_options);
    if (quarantine) |q| env.appendSlice(gpa, q.env.items) catch util.oom();
    const res = os.run(&.{hook.find(name).?}, .{ .env = env.items, .stdin_data = input.items, .stdout_to_stderr = true });
    return res.status;
}

fn runUpdateHook(cmd: *const Command) u8 {
    if (hook.find("update") == null) return 0;
    return hook.run("update", &.{ cmd.name, &hash.hex(cmd.old), &hash.hex(cmd.new) }, .{});
}

fn runUpdatePostHook(cmds: []const *Command) void {
    if (hook.find("post-update") == null) return;
    var args: std.ArrayList([]const u8) = .empty;
    for (cmds) |cmd| {
        if (cmd.error_string != null or cmd.did_not_exist) continue;
        args.append(gpa, cmd.name) catch util.oom();
    }
    if (args.items.len == 0) return;
    _ = hook.run("post-update", args.items, .{});
}

// ---------------- proc-receive ----------------

fn findCommandByRefname(cmds: []const *Command, start: usize, name: []const u8) ?usize {
    var i = start;
    while (i < cmds.len) : (i += 1) {
        if (util.eql(cmds[i].name, name)) return i;
    }
    return null;
}

fn readProcReceiveReport(rd: *pkt.Reader, cmds: []const *Command, errmsg: *util.Buf) i32 {
    var hint: ?usize = null;
    var report: ?*Report = null;
    var new_report = false;
    var code: i32 = 0;
    var once = false;
    var response: usize = 0;
    while (true) {
        const st = rd.read();
        if (st != .normal) {
            if (st == .eof and response == 0) {
                util.bufAppend(errmsg, "proc-receive exited abnormally");
                return -1;
            }
            break;
        }
        response += 1;
        var line = rd.line;
        if (std.mem.indexOfScalar(u8, line, 0)) |nul| line = line[0..nul];
        const sp = std.mem.indexOfScalar(u8, line, ' ') orelse {
            util.bufPrint(errmsg, "proc-receive reported incomplete status line: '{s}'\n", .{line});
            code = -1;
            continue;
        };
        const head = line[0..sp];
        const rest = line[sp + 1 ..];
        if (util.eql(head, "option")) {
            if (hint == null or !(report != null or new_report)) {
                if (!once) util.bufAppend(errmsg, "proc-receive reported 'option' without a matching 'ok/ng' directive\n");
                once = true;
                code = -1;
                continue;
            }
            const h = cmds[hint.?];
            if (new_report) {
                const r = gpa.create(Report) catch util.oom();
                r.* = .{};
                h.reports.append(gpa, r) catch util.oom();
                report = r;
                new_report = false;
            }
            var key = rest;
            var val: ?[]const u8 = null;
            if (std.mem.indexOfScalar(u8, rest, ' ')) |p| {
                key = rest[0..p];
                val = rest[p + 1 ..];
            }
            if (util.eql(key, "refname")) {
                report.?.ref_name = if (val) |v| util.dupe(v) else null;
            } else if (util.eql(key, "old-oid") and val != null and val.?.len >= 40 and hash.fromHex(val.?[0..40]) != null) {
                report.?.old = hash.fromHex(val.?[0..40]);
            } else if (util.eql(key, "new-oid") and val != null and val.?.len >= 40 and hash.fromHex(val.?[0..40]) != null) {
                report.?.new = hash.fromHex(val.?[0..40]);
            } else if (util.eql(key, "forced-update")) {
                report.?.forced_update = true;
            } else if (util.eql(key, "fall-through")) {
                h.run_proc_receive = 0;
            }
            continue;
        }
        report = null;
        new_report = false;
        var refname = rest;
        var msg: ?[]const u8 = null;
        if (std.mem.indexOfScalar(u8, rest, ' ')) |p| {
            refname = rest[0..p];
            msg = rest[p + 1 ..];
        }
        if (!util.eql(head, "ok") and !util.eql(head, "ng")) {
            util.bufPrint(errmsg, "proc-receive reported bad status '{s}' on ref '{s}'\n", .{ head, refname });
            code = -1;
            continue;
        }
        if (hint) |h| hint = findCommandByRefname(cmds, h, refname);
        if (hint == null) hint = findCommandByRefname(cmds, 0, refname);
        const hi = hint orelse {
            util.bufPrint(errmsg, "proc-receive reported status on unknown ref: {s}\n", .{refname});
            code = -1;
            continue;
        };
        const h = cmds[hi];
        if (h.run_proc_receive == 0) {
            util.bufPrint(errmsg, "proc-receive reported status on unexpected ref: {s}\n", .{refname});
            code = -1;
            continue;
        }
        h.run_proc_receive |= RUN_PROC_RECEIVE_RETURNED;
        if (util.eql(head, "ng")) {
            h.error_string = if (msg) |m| util.dupe(m) else "failed";
            code = -1;
            continue;
        }
        new_report = true;
    }
    for (cmds) |cmd| {
        if (cmd.run_proc_receive != 0 and cmd.error_string == null and cmd.run_proc_receive & RUN_PROC_RECEIVE_RETURNED == 0) {
            cmd.error_string = "proc-receive failed to report status";
            code = -1;
        }
    }
    return code;
}

fn writePktGently(fd: c_int, data: []const u8) bool {
    var b: util.Buf = .empty;
    pkt.bufWrite(&b, data);
    os.writeAll(fd, b.items) catch return false;
    return true;
}

fn runProcReceiveHook(cmds: []const *Command, push_options: []const []const u8) i32 {
    const hook_path = hook.find("proc-receive") orelse {
        rpError("cannot find hook 'proc-receive'", .{});
        return -1;
    };
    proc.ignoreSigpipe();
    var ch = proc.spawn(&.{hook_path}, .{ .pipe_in = true, .pipe_out = true, .no_path_search = true });
    var errmsg: util.Buf = .empty;
    var code: i32 = 0;
    var version: i64 = 0;
    var hook_use_push_options = false;
    const rd = gpa.create(pkt.Reader) catch util.oom();
    rd.* = pkt.Reader.init(ch.out);
    rd.gentle_eof = true;
    rd.die_on_err_packet = false;
    blk: {
        var cap: util.Buf = .empty;
        if (use_atomic) util.bufAppend(&cap, " atomic");
        if (use_push_options) util.bufAppend(&cap, " push-options");
        var ok = if (cap.items.len > 0)
            writePktGently(ch.in, util.fmt("version=1\x00{s}\n", .{cap.items[1..]}))
        else
            writePktGently(ch.in, "version=1\n");
        if (ok) ok = writePktGently0(ch.in);
        if (ok) {
            while (true) {
                const st = rd.read();
                if (st != .normal) {
                    if (st == .eof) ok = false;
                    break;
                }
                const l = rd.line;
                if (l.len > 8 and util.startsWith(l, "version=")) {
                    const nul = std.mem.indexOfScalar(u8, l, 0);
                    const vstr = l[8..(nul orelse l.len)];
                    version = atoi(vstr);
                    if (nul) |n| {
                        if (featureRequested(l[n + 1 ..], "push-options")) hook_use_push_options = true;
                    }
                }
            }
        }
        if (!ok) {
            code = -1;
            util.bufAppend(&errmsg, "fail to negotiate version with proc-receive hook");
            break :blk;
        }
        if (version != 0 and version != 1) {
            util.bufPrint(&errmsg, "proc-receive version '{d}' is not supported", .{version});
            code = -1;
            break :blk;
        }
        for (cmds) |cmd| {
            if (cmd.run_proc_receive == 0 or cmd.skip_update or cmd.error_string != null) continue;
            ok = writePktGently(ch.in, util.fmt("{s} {s} {s}", .{ hash.hex(cmd.old), hash.hex(cmd.new), cmd.name }));
            if (!ok) break;
        }
        if (ok) ok = writePktGently0(ch.in);
        if (!ok) {
            code = -1;
            util.bufAppend(&errmsg, "fail to write commands to proc-receive hook");
            break :blk;
        }
        if (hook_use_push_options) {
            for (push_options) |o| {
                ok = writePktGently(ch.in, o);
                if (!ok) break;
            }
            if (ok) ok = writePktGently0(ch.in);
            if (!ok) {
                code = -1;
                util.bufAppend(&errmsg, "fail to write push-options to proc-receive hook");
                break :blk;
            }
        }
        code = readProcReceiveReport(rd, cmds, &errmsg);
    }
    proc.closeFd(&ch.in);
    proc.closeFd(&ch.out);
    if (proc.wait(ch.pid) != 0) code = -1;
    if (errmsg.items.len > 0) {
        var m = errmsg.items;
        if (m[m.len - 1] == '\n') m = m[0 .. m.len - 1];
        rpError("{s}", .{m});
    }
    return code;
}

fn writePktGently0(fd: c_int) bool {
    os.writeAll(fd, "0000") catch return false;
    return true;
}

fn atoi(s: []const u8) i64 {
    var i: usize = 0;
    while (i < s.len and std.ascii.isWhitespace(s[i])) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '-' or s[i] == '+')) {
        neg = s[i] == '-';
        i += 1;
    }
    var v: i64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) v = v *% 10 +% (s[i] - '0');
    return if (neg) -v else v;
}

// ---------------- updating refs ----------------

const refuse_unconfigured_deny_msg =
    "By default, updating the current branch in a non-bare repository\n" ++
    "is denied, because it will make the index and work tree inconsistent\n" ++
    "with what you pushed, and will require 'git reset --hard' to match\n" ++
    "the work tree to HEAD.\n" ++
    "\n" ++
    "You can set the 'receive.denyCurrentBranch' configuration variable\n" ++
    "to 'ignore' or 'warn' in the remote repository to allow pushing into\n" ++
    "its current branch; however, this is not recommended unless you\n" ++
    "arranged to update its work tree to match what you pushed in some\n" ++
    "other way.\n" ++
    "\n" ++
    "To squelch this message and still keep the default behaviour, set\n" ++
    "'receive.denyCurrentBranch' configuration variable to 'refuse'.";

const refuse_unconfigured_deny_delete_current_msg =
    "By default, deleting the current branch is denied, because the next\n" ++
    "'git clone' won't result in any file checked out, causing confusion.\n" ++
    "\n" ++
    "You can set 'receive.denyDeleteCurrent' configuration variable to\n" ++
    "'warn' or 'ignore' in the remote repository to allow deleting the\n" ++
    "current branch, with or without a warning message.\n" ++
    "\n" ++
    "To squelch this message, you can set it to 'refuse'.";

var head_name: ?[]const u8 = null;
var worktrees: []*worktree.Worktree = &.{};

fn findCheckedOut(name: []const u8) ?*worktree.Worktree {
    return worktree.findSharedSymref(worktrees, "HEAD", name);
}

fn runGitIn(dir: ?[]const u8, args: []const []const u8, env: []const [2][]const u8, no_stdout: bool) u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    var o: proc.Opts = .{ .no_stdin = true, .cwd = dir, .env = env, .unset_env = &.{ "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE" } };
    var devnull: c_int = -1;
    if (no_stdout) {
        devnull = c.open("/dev/null", .{ .ACCMODE = .WRONLY });
        o.out_fd = devnull;
    } else o.stdout_to_stderr = true;
    const ch = proc.spawn(argv.items, o);
    if (devnull >= 0) os.close(devnull);
    return proc.wait(ch.pid);
}

fn pushToDeploy(new: Oid, env: []const [2][]const u8, wt: *worktree.Worktree) ?[]const u8 {
    if (runGitIn(wt.path, &.{ "update-index", "-q", "--ignore-submodules", "--refresh" }, env, false) != 0)
        return "Up-to-date check failed";
    if (runGitIn(wt.path, &.{ "diff-files", "--quiet", "--ignore-submodules", "--" }, env, false) != 0)
        return "Working directory has unstaged changes";
    const base: []const u8 = if (!hash.isZero(wt.head_oid)) "HEAD" else "4b825dc642cb6eb9a060e54bf8d69288fbee4904";
    if (runGitIn(null, &.{ "diff-index", "--quiet", "--cached", "--ignore-submodules", base, "--" }, env, true) != 0)
        return "Working directory has staged changes";
    if (runGitIn(wt.path, &.{ "read-tree", "-u", "-m", &hash.hex(new) }, env, true) != 0)
        return "Could not update working tree to new HEAD";
    return null;
}

fn updateWorktree(new: Oid, wt: *worktree.Worktree) ?[]const u8 {
    if (wt.is_bare) return "denyCurrentBranch = updateInstead needs a worktree";
    const gd = worktree.absolutePath(wt.gitDir());
    var env: std.ArrayList([2][]const u8) = .empty;
    env.append(gpa, .{ "GIT_DIR", gd }) catch util.oom();
    var invoked = false;
    var henv: std.ArrayList([2][]const u8) = .empty;
    henv.appendSlice(gpa, env.items) catch util.oom();
    henv.append(gpa, .{ "GIT_WORK_TREE", worktree.absolutePath(wt.path) }) catch util.oom();
    var ret: ?[]const u8 = null;
    if (hook.run("push-to-checkout", &.{&hash.hex(new)}, .{ .env = henv.items, .invoked = &invoked }) != 0)
        ret = "push-to-checkout hook declined";
    if (!invoked) ret = pushToDeploy(new, env.items, wt);
    return ret;
}

fn update(cmd: *Command, tx: *refs.Transaction) ?[]const u8 {
    const name = cmd.name;
    const wt = findCheckedOut(name);
    var do_update_worktree = false;
    if (!util.startsWith(name, "refs/") or
        !refs.checkRefnameFormat(name[5..], if (hash.isZero(cmd.new)) refs.ALLOW_ONELEVEL else 0))
    {
        rpError("refusing to update funny ref '{s}' remotely", .{name});
        return "funny refname";
    }
    if (wt != null and !wt.?.is_bare) {
        switch (deny_current_branch) {
            .ignore => {},
            .warn => rpWarning("updating the current branch", .{}),
            .refuse, .unconfigured => {
                rpError("refusing to update checked out branch: {s}", .{name});
                if (deny_current_branch == .unconfigured) rpError("{s}", .{refuse_unconfigured_deny_msg});
                return "branch is currently checked out";
            },
            .update_instead => do_update_worktree = true,
        }
    }
    const odb = repo_mod.repo().odb();
    if (!hash.isZero(cmd.new) and !odb.has(cmd.new)) {
        util.err("unpack should have generated {s}, but I can't find it!", .{hash.hex(cmd.new)});
        return "bad pack";
    }
    if (!hash.isZero(cmd.old) and hash.isZero(cmd.new)) {
        if (deny_deletes and util.startsWith(name, "refs/heads/")) {
            rpError("denying ref deletion for {s}", .{name});
            return "deletion prohibited";
        }
        if (wt != null or (head_name != null and util.eql(name, head_name.?))) {
            switch (deny_delete_current) {
                .ignore => {},
                .warn => rpWarning("deleting the current branch", .{}),
                else => {
                    if (deny_delete_current == .unconfigured) rpError("{s}", .{refuse_unconfigured_deny_delete_current_msg});
                    rpError("refusing to delete the current branch: {s}", .{name});
                    return "deletion of the current branch prohibited";
                },
            }
        }
    }
    if (deny_non_fast_forwards and !hash.isZero(cmd.new) and !hash.isZero(cmd.old) and util.startsWith(name, "refs/heads/")) {
        const ot = objects.typeOf(cmd.old);
        const nt = objects.typeOf(cmd.new);
        if (ot != .commit or nt != .commit) {
            util.err("bad sha1 objects for {s}", .{name});
            return "bad ref";
        }
        if (!@import("../commitreach.zig").refNewer(cmd.new, cmd.old)) {
            rpError("denying non-fast-forward {s} (you should pull first)", .{name});
            return "non-fast-forward";
        }
    }
    if (runUpdateHook(cmd) != 0) {
        rpError("hook declined to update {s}", .{name});
        return "hook declined";
    }
    if (do_update_worktree) {
        if (updateWorktree(cmd.new, wt.?)) |e| return e;
    }
    if (hash.isZero(cmd.new)) {
        var old: ?Oid = cmd.old;
        if (objects.typeOf(cmd.old) == null) {
            old = null;
            if (refs.exists(name)) {
                rpWarning("allowing deletion of corrupt ref", .{});
            } else {
                rpWarning("deleting a non-existent ref", .{});
                cmd.did_not_exist = true;
            }
        }
        if (tx.delete(name, old, null, 0, "push") != .ok) {
            rpError("{s}", .{tx.errMsg()});
            return "failed to delete";
        }
        return null;
    }
    const e = tx.update(name, cmd.new, cmd.old, null, null, 0, "push");
    if (e != .ok) {
        rpError("{s}", .{tx.errMsg()});
        return if (e == .generic) "failed to update ref" else e.msg();
    }
    return null;
}

fn checkAliasedUpdates(cmds: []const *Command) void {
    for (cmds) |cmd| {
        if (cmd.error_string != null) continue;
        const rr = refs.resolveFull(cmd.name, false);
        if (rr.flags & refs.REF_ISSYMREF == 0) continue;
        const dst_name = rr.name;
        if (rr.broken) {
            rpError("refusing update to broken symref '{s}'", .{cmd.name});
            cmd.skip_update = true;
            cmd.error_string = "broken symref";
            continue;
        }
        var dst: ?*Command = null;
        for (cmds) |o| {
            if (util.eql(o.name, dst_name)) {
                dst = o;
                break;
            }
        }
        const d = dst orelse continue;
        cmd.skip_update = true;
        if (hash.eql(cmd.old, d.old) and hash.eql(cmd.new, d.new)) continue;
        d.skip_update = true;
        const rp = @import("../revparse.zig");
        rpError("refusing inconsistent update between symref '{s}' ({s}..{s}) and its target '{s}' ({s}..{s})", .{
            cmd.name, rp.abbrev(cmd.old, 0), rp.abbrev(cmd.new, 0),
            d.name,   rp.abbrev(d.old, 0),   rp.abbrev(d.new, 0),
        });
        cmd.error_string = "inconsistent aliased update";
        d.error_string = "inconsistent aliased update";
    }
}

fn shouldProcess(cmd: *const Command) bool {
    return cmd.error_string == null and !cmd.skip_update;
}

fn executeNonAtomic(cmds: []const *Command) void {
    // deletions first, then everything else
    for ([_]bool{ true, false }) |deletions| {
        var tx: ?*refs.Transaction = null;
        for (cmds) |cmd| {
            if (!shouldProcess(cmd) or cmd.run_proc_receive != 0) continue;
            if (deletions != hash.isZero(cmd.new)) continue;
            if (tx == null) {
                tx = refs.Transaction.init();
                tx.?.allow_failures = true;
            }
            cmd.error_string = update(cmd, tx.?);
        }
        const t = tx orelse continue;
        if (t.commit() != .ok) {
            rpError("{s}", .{t.errMsg()});
            for (cmds) |cmd| cmd.error_string = "failed to update refs";
            continue;
        }
        for (t.rejected()) |u| {
            if (u.rejection_details.len > 0) rpError("{s}", .{u.rejection_details});
            for (cmds) |cmd| {
                if (util.eql(cmd.name, u.refname)) cmd.error_string = u.rejection.msg();
            }
        }
    }
}

fn executeAtomic(cmds: []const *Command) void {
    var reported_error: []const u8 = "atomic push failure";
    const tx = refs.Transaction.init();
    var failed = false;
    for (cmds) |cmd| {
        if (!shouldProcess(cmd) or cmd.run_proc_receive != 0) continue;
        cmd.error_string = update(cmd, tx);
        if (cmd.error_string != null) {
            failed = true;
            break;
        }
    }
    if (!failed) {
        if (tx.commit() != .ok) {
            rpError("{s}", .{tx.errMsg()});
            reported_error = "atomic transaction failed";
            failed = true;
        }
    } else tx.abort();
    if (failed) {
        for (cmds) |cmd| {
            if (cmd.error_string == null) cmd.error_string = reported_error;
        }
    }
}

fn checkConnected(cmds: []const *Command) void {
    if (skip_connectivity_check) return;
    // every new tip must exist (and be fully connected) after unpacking
    var input: util.Buf = .empty;
    var any = false;
    for (cmds) |cmd| {
        if (hash.isZero(cmd.new) or cmd.skip_update) continue;
        util.bufPrint(&input, "{s}\n", .{hash.hex(cmd.new)});
        any = true;
    }
    if (!any) return;
    util.bufAppend(&input, "--not\n");
    const env: []const [2][]const u8 = if (quarantine) |q| q.env.items else &.{};
    const res = os.run(&.{ proc.gitBinary(), "rev-list", "--objects", "--stdin", "--not", "--all", "--quiet" }, .{
        .capture_stdout = true,
        .stdin_data = input.items,
        .env = env,
    });
    if (res.status == 0) return;
    // find which ones are broken
    for (cmds) |cmd| {
        if (hash.isZero(cmd.new) or cmd.skip_update) continue;
        const one = util.fmt("{s}\n--not\n", .{hash.hex(cmd.new)});
        const r1 = os.run(&.{ proc.gitBinary(), "rev-list", "--objects", "--stdin", "--not", "--all", "--quiet" }, .{
        .capture_stdout = true,
            .stdin_data = one,
            .env = env,
        });
        if (r1.status != 0) cmd.error_string = "missing necessary objects";
    }
}

fn rejectUpdatesToHidden(cmds: []const *Command) void {
    for (cmds) |cmd| {
        if (cmd.error_string != null) continue;
        if (!up.refIsHidden("receive", cmd.name)) continue;
        cmd.error_string = if (hash.isZero(cmd.new)) "deny deleting a hidden ref" else "deny updating a hidden ref";
    }
}

fn executeCommands(cmds: []const *Command, unpack_err: bool, push_options: []const []const u8) void {
    if (unpack_err) {
        for (cmds) |cmd| cmd.error_string = "unpacker error";
        return;
    }
    checkConnected(cmds);
    rejectUpdatesToHidden(cmds);
    var run_proc_receive = false;
    if (proc_receive_refs.items.len > 0) {
        for (cmds) |cmd| {
            if (!shouldProcess(cmd)) continue;
            if (procReceiveRefMatches(cmd)) {
                cmd.run_proc_receive = RUN_PROC_RECEIVE_SCHEDULED;
                run_proc_receive = true;
            }
        }
    }
    if (runReceiveHook(cmds, "pre-receive", false, push_options) != 0) {
        for (cmds) |cmd| {
            if (cmd.error_string == null) cmd.error_string = "pre-receive hook declined";
        }
        return;
    }
    var any = false;
    for (cmds) |cmd| {
        if (cmd.error_string == null) any = true;
    }
    if (!any) return;
    if (quarantine) |q| {
        if (!quarantineMigrate(q)) {
            for (cmds) |cmd| {
                if (cmd.error_string == null) cmd.error_string = "unable to migrate objects to permanent storage";
            }
            return;
        }
    }
    checkAliasedUpdates(cmds);
    head_name = if (refs.resolve("HEAD")) |h| util.dupe(h.name) else null;
    // main worktree bareness as in get_main_worktree()
    worktrees = worktree.getAll();
    if (worktrees.len > 0) {
        const r = repo_mod.repo();
        worktrees[0].is_bare = repo_mod.cfg.getBool("core.bare") orelse (r.work_tree == null);
    }
    if (run_proc_receive and runProcReceiveHook(cmds, push_options) != 0) {
        for (cmds) |cmd| {
            if (cmd.error_string == null and cmd.run_proc_receive & RUN_PROC_RECEIVE_RETURNED == 0 and
                (cmd.run_proc_receive != 0 or use_atomic))
                cmd.error_string = "fail to run proc-receive hook";
        }
    }
    if (use_atomic) executeAtomic(cmds) else executeNonAtomic(cmds);
}

// ---------------- report ----------------

fn report(cmds: []const *Command, unpack_status: ?[]const u8) void {
    var b: util.Buf = .empty;
    pkt.bufFmt(&b, "unpack {s}\n", .{unpack_status orelse "ok"});
    for (cmds) |cmd| {
        if (cmd.error_string) |e| {
            pkt.bufFmt(&b, "ng {s} {s}\n", .{ cmd.name, e });
            continue;
        }
        pkt.bufFmt(&b, "ok {s}\n", .{cmd.name});
        if (!report_status_v2) continue;
        for (cmd.reports.items, 0..) |r, i| {
            if (i > 0) pkt.bufFmt(&b, "ok {s}\n", .{cmd.name});
            if (r.ref_name) |n| pkt.bufFmt(&b, "option refname {s}\n", .{n});
            if (r.old) |o| pkt.bufFmt(&b, "option old-oid {s}\n", .{hash.hex(o)});
            if (r.new) |o| pkt.bufFmt(&b, "option new-oid {s}\n", .{hash.hex(o)});
            if (r.forced_update) pkt.bufWrite(&b, "option forced-update\n");
        }
    }
    util.bufAppend(&b, "0000");
    if (use_sideband) {
        pkt.sendSideband(1, 1, b.items, pkt.LARGE_PACKET_MAX);
    } else os.writeAll(1, b.items) catch {};
}

fn deleteOnly(cmds: []const *Command) bool {
    for (cmds) |cmd| {
        if (!hash.isZero(cmd.new)) return false;
    }
    return true;
}

// ---------------- command ----------------

var opt_quiet = false;
const usage = [_][]const u8{"git receive-pack <git-dir>"};
const options = [_]po.Opt{
    po.boolean('q', "quiet", &opt_quiet, "quiet"),
    .{ .long = "skip-connectivity-check", .kind = .boolean, .b = &skip_connectivity_check, .hidden = true },
    .{ .long = "stateless-rpc", .kind = .boolean, .b = &stateless_rpc, .hidden = true },
    .{ .long = "http-backend-info-refs", .kind = .boolean, .b = &advertise_refs, .hidden = true },
    .{ .long = "advertise-refs", .kind = .boolean, .b = &advertise_refs, .hidden = true },
    .{ .long = "reject-thin-pack-for-testing", .kind = .boolean, .b = &reject_thin, .hidden = true },
};

fn usageMsgOpt(msg: []const u8) noreturn {
    util.ewrite(util.fmt("fatal: {s}\n\n", .{msg}));
    po.usageExit(&usage, &options, true);
}

pub fn cmdReceivePack(args: []const []const u8) u8 {
    const rest = po.parse(args[1..], &options, &usage, .{});
    quiet = opt_quiet;
    if (rest.len > 1) usageMsgOpt("too many arguments");
    if (rest.len == 0) usageMsgOpt("you must specify a directory");
    const dir = rest[0];
    if (!up.enterRepo(dir, false)) util.die("'{s}' does not appear to be a git repository", .{dir});
    loadConfig();
    proc.ignoreSigpipe();
    if (up.protocolVersionServer() == 1) {
        if (advertise_refs or !stateless_rpc) pkt.write(1, "version 1\n");
    }
    if (advertise_refs or !stateless_rpc) writeHeadInfo();
    if (advertise_refs) return 0;

    var rd = gpa.create(pkt.Reader) catch util.oom();
    rd.* = pkt.Reader.init(0);
    rd.gentle_eof = true;
    const cmds = readHeadInfo(rd);
    if (cmds.len > 0) {
        var push_options: []const []const u8 = &.{};
        if (use_push_options) push_options = readPushOptions(rd);
        var mux: Muxer = .{};
        mux.start();
        var unpack_status: ?[]const u8 = null;
        util.die_hook = &dieHook;
        if (!deleteOnly(cmds)) {
            quarantine = quarantineCreate();
            if (quarantine == null) {
                unpack_status = "unable to start object transaction";
            } else unpack_status = unpack(rd);
        }
        executeCommands(cmds, unpack_status != null, push_options);
        quarantineDestroy();
        removeKeepFile();
        mux.finish();
        if (report_status_v2 or report_status) report(cmds, unpack_status);
        mux.start();
        _ = runReceiveHook(cmds, "post-receive", true, push_options);
        runUpdatePostHook(cmds);
        if (auto_update_server_info) _ = os.run(&.{ proc.gitBinary(), "update-server-info" }, .{ .no_stdin = true });
        mux.finish();
    }
    if (use_sideband) pkt.flush(1);
    return 0;
}
