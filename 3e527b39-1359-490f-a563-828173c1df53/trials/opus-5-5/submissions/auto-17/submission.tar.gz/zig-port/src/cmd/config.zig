//! `git config` (port of builtin/config.c).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const config = @import("../config.zig");
const color = @import("../color.zig");
const parseopt = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const date = @import("../date.zig");
const regex = @import("../regex.zig");
const gpa = util.gpa;
const Opt = parseopt.Opt;

const builtin_config_usage = [_][]const u8{
    "git config list [<file-option>] [<display-option>] [--includes]",
    "git config get [<file-option>] [<display-option>] [--includes] [--all] [--regexp] [--value=<pattern>] [--fixed-value] [--default=<default>] [--url=<url>] <name>",
    "git config set [<file-option>] [--type=<type>] [--all] [--value=<pattern>] [--fixed-value] <name> <value>",
    "git config unset [<file-option>] [--all] [--value=<pattern>] [--fixed-value] <name>",
    "git config rename-section [<file-option>] <old-name> <new-name>",
    "git config remove-section [<file-option>] <name>",
    "git config edit [<file-option>]",
    "git config [<file-option>] --get-colorbool <name> [<stdout-is-tty>]",
};
const list_usage = [_][]const u8{"git config list [<file-option>] [<display-option>] [--includes]"};
const get_usage = [_][]const u8{"git config get [<file-option>] [<display-option>] [--includes] [--all] [--regexp=<regexp>] [--value=<pattern>] [--fixed-value] [--default=<default>] <name>"};
const set_usage = [_][]const u8{"git config set [<file-option>] [--type=<type>] [--comment=<message>] [--all] [--value=<pattern>] [--fixed-value] <name> <value>"};
const unset_usage = [_][]const u8{"git config unset [<file-option>] [--all] [--value=<pattern>] [--fixed-value] <name>"};
const rename_usage = [_][]const u8{"git config rename-section [<file-option>] <old-name> <new-name>"};
const remove_usage = [_][]const u8{"git config remove-section [<file-option>] <name>"};
const edit_usage = [_][]const u8{"git config edit [<file-option>]"};

// ---------------------------------------------------------------------------
// option state (one invocation per process)

const TYPE_NONE: i32 = 0;
const TYPE_BOOL: i32 = 1;
const TYPE_INT: i32 = 2;
const TYPE_BOOL_OR_INT: i32 = 3;
const TYPE_PATH: i32 = 4;
const TYPE_EXPIRY_DATE: i32 = 5;
const TYPE_COLOR: i32 = 6;
const TYPE_BOOL_OR_STR: i32 = 7;

// location
var use_global = false;
var use_system = false;
var use_local = false;
var use_worktree = false;
var src_file: ?[]const u8 = null;
var src_blob: ?[]const u8 = null;
var use_stdin = false;
var src_scope: config.Scope = .unknown;
var includes_opt: i32 = -1;
var loc: config.Options = .{};

// display
var end_nul = false;
var omit_values = false;
var show_origin = false;
var show_scope = false;
var show_keys = false;
var type_: i32 = TYPE_NONE;
var default_value: ?[]const u8 = null;
var term: u8 = '\n';
var delim: u8 = '=';
var key_delim: u8 = ' ';

// legacy / subcommand extras
var actions: i32 = 0;
var action_name: []const u8 = "";
var comment_arg: ?[]const u8 = null;
var fixed_value_flag: i32 = 0;
var get_value_flags: i32 = 0;
var value_pattern: ?[]const u8 = null;
var url_arg: ?[]const u8 = null;
var set_flags: i32 = 0;
var append_flag = false;

const FLAG_FIXED_VALUE: i32 = 1 << 0;
const FLAG_MULTI_REPLACE: i32 = 1 << 1;
const GET_VALUE_ALL: i32 = 1 << 0;
const GET_VALUE_KEY_REGEXP: i32 = 1 << 1;

const ACTION_GET: i32 = 1 << 0;
const ACTION_GET_ALL: i32 = 1 << 1;
const ACTION_GET_REGEXP: i32 = 1 << 2;
const ACTION_REPLACE_ALL: i32 = 1 << 3;
const ACTION_ADD: i32 = 1 << 4;
const ACTION_UNSET: i32 = 1 << 5;
const ACTION_UNSET_ALL: i32 = 1 << 6;
const ACTION_RENAME_SECTION: i32 = 1 << 7;
const ACTION_REMOVE_SECTION: i32 = 1 << 8;
const ACTION_LIST: i32 = 1 << 9;
const ACTION_EDIT: i32 = 1 << 10;
const ACTION_SET: i32 = 1 << 11;
const ACTION_SET_ALL: i32 = 1 << 12;
const ACTION_GET_COLOR: i32 = 1 << 13;
const ACTION_GET_COLORBOOL: i32 = 1 << 14;
const ACTION_GET_URLMATCH: i32 = 1 << 15;

fn typeCb(o: *const Opt, arg: ?[]const u8, unset: bool) void {
    if (unset) {
        type_ = TYPE_NONE;
        return;
    }
    var new_type = o.val;
    if (new_type == 0) {
        const a = arg orelse "";
        if (util.eql(a, "bool")) {
            new_type = TYPE_BOOL;
        } else if (util.eql(a, "int")) {
            new_type = TYPE_INT;
        } else if (util.eql(a, "bool-or-int")) {
            new_type = TYPE_BOOL_OR_INT;
        } else if (util.eql(a, "bool-or-str")) {
            new_type = TYPE_BOOL_OR_STR;
        } else if (util.eql(a, "path")) {
            new_type = TYPE_PATH;
        } else if (util.eql(a, "expiry-date")) {
            new_type = TYPE_EXPIRY_DATE;
        } else if (util.eql(a, "color")) {
            new_type = TYPE_COLOR;
        } else util.die("unrecognized --type argument, {s}", .{a});
    }
    if (type_ != 0 and type_ != new_type) {
        util.err("only one type at a time", .{});
        os.exit(129);
    }
    type_ = new_type;
}

fn modeCb(o: *const Opt, _: ?[]const u8, _: bool) void {
    const name = if (o.long.len > 0) util.concat(&.{ "--", o.long }) else util.fmt("-{c}", .{o.short});
    if (actions != 0 and actions != o.val) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ name, action_name });
        os.exit(129);
    }
    actions = o.val;
    action_name = name;
}

fn typeValue(long: []const u8, v: i32, help: []const u8) Opt {
    return .{ .long = long, .kind = .callback, .noarg = true, .noneg = true, .cbx = typeCb, .val = v, .help = help };
}

fn cmdmode(short: u8, long: []const u8, v: i32, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .callback, .noarg = true, .noneg = true, .cbx = modeCb, .val = v, .help = help };
}

/// A hidden short-only twin so that the conflict message names "-l" vs "--list".
fn cmdmodeShort(short: u8, v: i32) Opt {
    return .{ .short = short, .kind = .callback, .noarg = true, .noneg = true, .hidden = true, .cbx = modeCb, .val = v };
}

const location_opts = [_]Opt{
    parseopt.group("Config file location"),
    parseopt.boolean(0, "global", &use_global, "use global config file"),
    parseopt.boolean(0, "system", &use_system, "use system config file"),
    parseopt.boolean(0, "local", &use_local, "use repository config file"),
    parseopt.boolean(0, "worktree", &use_worktree, "use per-worktree config file"),
    parseopt.string('f', "file", &src_file, "file", "use given config file"),
    parseopt.string(0, "blob", &src_blob, "blob-id", "read config from given blob object"),
};

const type_opts = [_]Opt{
    parseopt.group("Type"),
    .{ .short = 't', .long = "type", .kind = .callback, .cbx = typeCb, .val = 0, .argh = "type", .help = "value is given this type" },
    typeValue("bool", TYPE_BOOL, "value is \"true\" or \"false\""),
    typeValue("int", TYPE_INT, "value is decimal number"),
    typeValue("bool-or-int", TYPE_BOOL_OR_INT, "value is --bool or --int"),
    typeValue("bool-or-str", TYPE_BOOL_OR_STR, "value is --bool or string"),
    typeValue("path", TYPE_PATH, "value is a path (file or directory name)"),
    typeValue("expiry-date", TYPE_EXPIRY_DATE, "value is an expiry date"),
};

const display_opts = [_]Opt{
    parseopt.group("Display options"),
    parseopt.boolean('z', "null", &end_nul, "terminate values with NUL byte"),
    parseopt.boolean(0, "name-only", &omit_values, "show variable names only"),
    parseopt.boolean(0, "show-origin", &show_origin, "show origin of config (file, standard input, blob, command line)"),
    parseopt.boolean(0, "show-scope", &show_scope, "show scope of config (worktree, local, global, system, command)"),
    parseopt.boolean(0, "show-names", &show_keys, "show config keys in addition to their values"),
} ++ type_opts;

const includes_opt_def = parseopt.setInt(0, "includes", &includes_opt, 1, "respect include directives on lookup");

const legacy_opts = location_opts ++ [_]Opt{
    parseopt.group("Action"),
    cmdmode(0, "get", ACTION_GET, "get value: name [<value-pattern>]"),
    cmdmode(0, "get-all", ACTION_GET_ALL, "get all values: key [<value-pattern>]"),
    cmdmode(0, "get-regexp", ACTION_GET_REGEXP, "get values for regexp: name-regex [<value-pattern>]"),
    cmdmode(0, "get-urlmatch", ACTION_GET_URLMATCH, "get value specific for the URL: section[.var] URL"),
    cmdmode(0, "replace-all", ACTION_REPLACE_ALL, "replace all matching variables: name value [<value-pattern>]"),
    cmdmode(0, "add", ACTION_ADD, "add a new variable: name value"),
    cmdmode(0, "unset", ACTION_UNSET, "remove a variable: name [<value-pattern>]"),
    cmdmode(0, "unset-all", ACTION_UNSET_ALL, "remove all matches: name [<value-pattern>]"),
    cmdmode(0, "rename-section", ACTION_RENAME_SECTION, "rename section: old-name new-name"),
    cmdmode(0, "remove-section", ACTION_REMOVE_SECTION, "remove a section: name"),
    cmdmodeShort('l', ACTION_LIST),
    cmdmode('l', "list", ACTION_LIST, "list all"),
    cmdmodeShort('e', ACTION_EDIT),
    cmdmode('e', "edit", ACTION_EDIT, "open an editor"),
    cmdmode(0, "get-color", ACTION_GET_COLOR, "find the color configured: slot [<default>]"),
    cmdmode(0, "get-colorbool", ACTION_GET_COLORBOOL, "find the color setting: slot [<stdout-is-tty>]"),
} ++ display_opts ++ [_]Opt{
    parseopt.group("Other"),
    parseopt.string(0, "default", &default_value, "value", "with --get, use default value when missing entry"),
    parseopt.string(0, "comment", &comment_arg, "value", "human-readable comment string (# will be prepended as needed)"),
    parseopt.bit(0, "fixed-value", &fixed_value_flag, FLAG_FIXED_VALUE, "use string equality when comparing values to value pattern"),
    includes_opt_def,
};

const list_opts = location_opts ++ display_opts ++ [_]Opt{
    parseopt.group("Other"),
    includes_opt_def,
};

const get_opts = location_opts ++ [_]Opt{
    parseopt.group("Filter options"),
    parseopt.bit(0, "all", &get_value_flags, GET_VALUE_ALL, "return all values for multi-valued config options"),
    parseopt.bit(0, "regexp", &get_value_flags, GET_VALUE_KEY_REGEXP, "interpret the name as a regular expression"),
    parseopt.string(0, "value", &value_pattern, "pattern", "show config with values matching the pattern"),
    parseopt.bit(0, "fixed-value", &fixed_value_flag, FLAG_FIXED_VALUE, "use string equality when comparing values to value pattern"),
    parseopt.string(0, "url", &url_arg, "URL", "show config matching the given URL"),
} ++ display_opts ++ [_]Opt{
    parseopt.group("Other"),
    includes_opt_def,
    parseopt.string(0, "default", &default_value, "value", "use default value when missing entry"),
};

const set_opts = location_opts ++ type_opts ++ [_]Opt{
    parseopt.group("Filter"),
    parseopt.bit(0, "all", &set_flags, FLAG_MULTI_REPLACE, "replace multi-valued config option with new value"),
    parseopt.string(0, "value", &value_pattern, "pattern", "show config with values matching the pattern"),
    parseopt.bit(0, "fixed-value", &set_flags, FLAG_FIXED_VALUE, "use string equality when comparing values to value pattern"),
    parseopt.group("Other"),
    parseopt.string(0, "comment", &comment_arg, "value", "human-readable comment string (# will be prepended as needed)"),
    parseopt.boolean(0, "append", &append_flag, "add a new line without altering any existing values"),
};

const unset_opts = location_opts ++ [_]Opt{
    parseopt.group("Filter"),
    parseopt.bit(0, "all", &set_flags, FLAG_MULTI_REPLACE, "unset all multi-valued config options"),
    parseopt.string(0, "value", &value_pattern, "pattern", "unset multi-valued config options with matching values"),
    parseopt.bit(0, "fixed-value", &set_flags, FLAG_FIXED_VALUE, "use string equality when comparing values to value pattern"),
};

// ---------------------------------------------------------------------------
// helpers

fn parseArgs(args: []const []const u8, opts: []const Opt, usage: []const []const u8, stop: bool) [][]const u8 {
    return parseopt.parse(args, opts, usage, .{ .stop_at_non_option = stop });
}

fn checkArgc(argc: usize, min: usize, max: usize) void {
    if (argc >= min and argc <= max) return;
    if (min == max) {
        util.err("wrong number of arguments, should be {d}", .{min});
    } else {
        util.err("wrong number of arguments, should be from {d} to {d}", .{ min, max });
    }
    os.exit(129);
}

fn dieMissingSetValue(arg: []const u8) noreturn {
    const last_dot = std.mem.lastIndexOfScalar(u8, arg, '.');
    var prefix: ?[]const u8 = null;
    var eq_rest: []const u8 = "";
    if (last_dot) |d| {
        if (std.mem.indexOfScalarPos(u8, arg, d + 1, '=')) |eq| {
            prefix = arg[0..eq];
            eq_rest = arg[eq + 1 ..];
        }
    }
    if (prefix != null and config.keyIsValid(prefix.?)) {
        util.err("missing value to set to the variable '{s}'", .{arg});
        util.hint("did you mean \"git config set {s} {s}\"?", .{ prefix.?, eq_rest });
    } else if (config.keyIsValid(arg)) {
        util.err("missing value to set to the variable '{s}'", .{arg});
    } else {
        util.err("missing value to set to a variable with an invalid name '{s}'", .{arg});
    }
    os.exit(129);
}

fn haveRepo() bool {
    return repo_mod.repo_ != null;
}

fn hasMultipleWorktrees(r: *repo_mod.Repo) bool {
    const entries = os.listDir(r.commonPath("worktrees")) orelse return false;
    for (entries) |e| {
        if (util.eql(e.name, ".") or util.eql(e.name, "..")) continue;
        return true;
    }
    return false;
}

fn locationInit() void {
    if (src_file == null) src_file = os.getenv("GIT_CONFIG");
    const n = @as(u32, @intFromBool(use_global)) + @intFromBool(use_system) + @intFromBool(use_local) +
        @intFromBool(use_worktree) + @intFromBool(src_file != null) + @intFromBool(src_blob != null);
    if (n > 1) {
        util.err("only one config file at a time", .{});
        os.exit(129);
    }
    if (!haveRepo()) {
        if (use_local) util.die("--local can only be used inside a git repository", .{});
        if (src_blob != null) util.die("--blob can only be used inside a git repository", .{});
        if (use_worktree) util.die("--worktree can only be used inside a git repository", .{});
    }
    if (src_file) |f| {
        if (util.eql(f, "-")) {
            src_file = null;
            use_stdin = true;
            src_scope = .command;
        }
    }
    if (use_global) {
        src_file = config.globalConfigFile() orelse util.die("$HOME not set", .{});
        src_scope = .global;
    } else if (use_system) {
        src_file = config.systemConfigPath();
        src_scope = .system;
    } else if (use_local) {
        src_file = repo_mod.repo().commonPath("config");
        src_scope = .local;
    } else if (use_worktree) {
        const r = repo_mod.repo();
        if (r.worktree_config) {
            src_file = r.gitPath("config.worktree");
        } else if (hasMultipleWorktrees(r)) {
            util.die("--worktree cannot be used with multiple working trees unless the config\n" ++
                "extension worktreeConfig is enabled. Please read \"CONFIGURATION FILE\"\n" ++
                "section in \"git help worktree\" for details", .{});
        } else {
            src_file = r.commonPath("config");
        }
        src_scope = .local;
    } else if (src_file) |f| {
        if (f.len > 0 and f[0] != '/' and parseopt.prefix.len > 0) src_file = util.concat(&.{ parseopt.prefix, f });
        src_scope = .command;
    } else if (src_blob != null) {
        src_scope = .command;
    }
    loc = if (haveRepo()) config.repoOptions() else .{};
    if (includes_opt == -1) {
        loc.respect_includes = src_file == null;
    } else {
        loc.respect_includes = includes_opt != 0;
    }
}

fn displayInit() void {
    if (end_nul) {
        term = 0;
        delim = '\n';
        key_delim = '\n';
    }
}

fn displayInitList() void {
    show_keys = true;
    if (end_nul) {
        displayInit();
    } else {
        term = '\n';
        delim = ' ';
        key_delim = '=';
    }
}

fn readConfig(cb: config.Callback) i32 {
    const spec: config.SourceSpec = if (use_stdin)
        .stdin
    else if (src_file) |f|
        .{ .file = f }
    else if (src_blob) |b|
        .{ .blob = b }
    else
        .sequence;
    return config.configWithOptionsScoped(spec, src_scope, cb, &loc);
}

fn setupAutoPager() void {
    const main = @import("../main.zig");
    if (main.use_pager != null or color.pagerInUse()) return;
    if (repo_mod.cfg.getEntry("pager.config")) |e| {
        const v = config.parseMaybeBool(e.value);
        if (v == 0) return;
    }
    @import("../commands.zig").setupPager();
}

fn checkWrite() void {
    if (src_file == null and !haveRepo()) util.die("not in a git directory", .{});
    if (use_stdin) util.die("writing to stdin is not supported", .{});
    if (src_blob != null) util.die("writing config blobs is not supported", .{});
}

fn writeFile() []const u8 {
    return src_file orelse repo_mod.repo().commonPath("config");
}

fn exitCode(ret: i32) u8 {
    return @truncate(@as(u32, @bitCast(ret)));
}

// ---------------------------------------------------------------------------
// formatting

fn showScope(b: *util.Buf, kvi: *const config.KvInfo) void {
    util.bufAppend(b, kvi.scope.name());
    util.bufByte(b, if (end_nul) 0 else '\t');
}

fn showOrigin(b: *util.Buf, kvi: *const config.KvInfo) void {
    util.bufAppend(b, kvi.origin_type.name());
    util.bufByte(b, ':');
    const f = kvi.filename orelse "";
    if (end_nul) util.bufAppend(b, f) else util.bufAppend(b, util.cquote(f));
    util.bufByte(b, if (end_nul) 0 else '\t');
}

fn formatInt64(b: *util.Buf, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo, gently: bool) i32 {
    var v: i64 = 0;
    if (gently) {
        switch (config.parseSigned(value, std.math.maxInt(i64))) {
            .ok => |n| v = n,
            .err => return -1,
        }
    } else {
        v = config.configInt64(key, value orelse "", kvi);
    }
    util.bufPrint(b, "{d}", .{v});
    return 0;
}

fn formatBool(b: *util.Buf, key: []const u8, value: ?[]const u8, gently: bool) i32 {
    var v: bool = false;
    if (gently) {
        const r = config.parseMaybeBool(value);
        if (r < 0) return -1;
        v = r != 0;
    } else {
        v = config.configBool(key, value);
    }
    util.bufAppend(b, if (v) "true" else "false");
    return 0;
}

fn formatBoolOrInt(b: *util.Buf, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo, gently: bool) i32 {
    var is_bool = false;
    var v: i64 = 0;
    if (gently) {
        const t = config.parseMaybeBoolText(value);
        if (t >= 0) {
            is_bool = true;
            v = t;
        } else switch (config.parseSigned(value, std.math.maxInt(i32))) {
            .ok => |n| v = n,
            .err => return -1,
        }
    } else {
        v = config.configBoolOrInt(key, value, kvi, &is_bool);
    }
    if (is_bool) {
        util.bufAppend(b, if (v != 0) "true" else "false");
    } else util.bufPrint(b, "{d}", .{v});
    return 0;
}

fn formatBoolOrStr(b: *util.Buf, value: ?[]const u8) i32 {
    const v = config.parseMaybeBool(value);
    if (v < 0) {
        util.bufAppend(b, value orelse "");
    } else util.bufAppend(b, if (v != 0) "true" else "false");
    return 0;
}

fn formatPath(b: *util.Buf, key: []const u8, value: ?[]const u8, gently: bool) i32 {
    switch (config.configPathname(key, value)) {
        .err => return -1,
        .ok => |p| {
            if (p) |s| {
                util.bufAppend(b, s);
                return 0;
            }
            return if (gently) -1 else 1;
        },
    }
}

fn printTimestamp(b: *util.Buf, t: i64) void {
    if (t == std.math.maxInt(i64)) {
        util.bufAppend(b, "18446744073709551615");
    } else util.bufPrint(b, "{d}", .{@as(u64, @bitCast(t))});
}

fn formatExpiry(b: *util.Buf, key: []const u8, value: ?[]const u8, quietly: bool) i32 {
    var t: i64 = 0;
    if (quietly) {
        const v = value orelse return -1;
        t = date.parseExpiryDate(v) orelse return -1;
    } else {
        const v = value orelse return config.errorNonbool(key);
        t = date.parseExpiryDate(v) orelse {
            util.err("'{s}' for '{s}' is not a valid timestamp", .{ v, key });
            return -1;
        };
    }
    printTimestamp(b, t);
    return 0;
}

fn formatColor(b: *util.Buf, key: []const u8, value: ?[]const u8, gently: bool) i32 {
    var c: []const u8 = undefined;
    if (gently) {
        c = color.parseColor(value orelse return -1) orelse return -1;
    } else {
        const v = value orelse return config.errorNonbool(key);
        c = color.parseColorOrError(v) orelse return -1;
    }
    util.bufAppend(b, c);
    return 0;
}

/// format_config(): <0 failure, 0 success, 1 missing optional value.
fn formatConfig(b: *util.Buf, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo, gently: bool, keys: bool) i32 {
    var res: i32 = 0;
    if (show_scope) showScope(b, kvi);
    if (show_origin) showOrigin(b, kvi);
    if (keys) util.bufAppend(b, key);
    if (!omit_values) {
        if (keys) util.bufByte(b, key_delim);
        switch (type_) {
            TYPE_INT => res = formatInt64(b, key, value, kvi, gently),
            TYPE_BOOL => res = formatBool(b, key, value, gently),
            TYPE_BOOL_OR_INT => res = formatBoolOrInt(b, key, value, kvi, gently),
            TYPE_BOOL_OR_STR => res = formatBoolOrStr(b, value),
            TYPE_PATH => res = formatPath(b, key, value, gently),
            TYPE_EXPIRY_DATE => res = formatExpiry(b, key, value, gently),
            TYPE_COLOR => res = formatColor(b, key, value, gently),
            else => {
                if (value) |v| {
                    util.bufAppend(b, v);
                } else if (keys) {
                    b.items.len -= 1;
                }
            },
        }
    }
    util.bufByte(b, term);
    return res;
}

fn showAllFn(_: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo) i32 {
    var b: util.Buf = .empty;
    if (formatConfig(&b, key, value, kvi, true, show_keys) >= 0) util.out(b.items);
    return 0;
}

fn doList() void {
    var dummy: u8 = 0;
    if (readConfig(.{ .f = showAllFn, .ctx = &dummy }) < 0) {
        if (src_file) |f| util.dieErrno("unable to read config file '{s}'", .{f});
        util.die("error processing config file(s)", .{});
    }
}

// ---------------------------------------------------------------------------
// get_value

const CollectData = struct {
    values: std.ArrayList([]const u8) = .empty,
    fixed_pattern: ?[]const u8 = null,
    key: []const u8 = "",
    regexp: ?regex.Regex = null,
    key_regexp: ?regex.Regex = null,
    do_not_match: bool = false,
    keys: bool,
};

fn collectFn(ctx: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo) i32 {
    const d: *CollectData = @ptrCast(@alignCast(ctx));
    if (d.key_regexp) |kr| {
        if (!kr.isMatch(key)) return 0;
    } else if (!util.eql(key, d.key)) return 0;
    if (d.fixed_pattern) |p| {
        if (!util.eql(p, value orelse "")) return 0;
    }
    if (d.regexp) |re| {
        const m = re.isMatch(value orelse "");
        if (d.do_not_match == m) return 0;
    }
    var b: util.Buf = .empty;
    const status = formatConfig(&b, key, value, kvi, false, d.keys);
    if (status < 0) return status;
    if (status == 0) d.values.append(gpa, b.items) catch util.oom();
    return 0;
}

fn getValue(key_: []const u8, regex_: ?[]const u8, gv_flags: i32, flags: i32) i32 {
    var d = CollectData{ .keys = show_keys };
    if (gv_flags & GET_VALUE_KEY_REGEXP != 0) {
        const key = util.dupe(key_);
        var i: usize = key.len;
        while (i > 0 and key[i - 1] != '.') : (i -= 1) key[i - 1] = std.ascii.toLower(key[i - 1]);
        var j: usize = 0;
        while (j < key.len and key[j] != '.') : (j += 1) key[j] = std.ascii.toLower(key[j]);
        switch (regex.Regex.compile(key, .{ .extended = true })) {
            .ok => |re| d.key_regexp = re,
            .err => {
                util.err("invalid key pattern: {s}", .{key_});
                return config.CONFIG_INVALID_PATTERN;
            },
        }
    } else {
        switch (config.parseKeyFull(key_, false)) {
            .ok => |k| d.key = k.key,
            .err => return config.CONFIG_INVALID_KEY,
        }
    }
    if (regex_) |r0| {
        if (flags & FLAG_FIXED_VALUE != 0) {
            d.fixed_pattern = r0;
        } else {
            var r = r0;
            if (r.len > 0 and r[0] == '!') {
                d.do_not_match = true;
                r = r[1..];
            }
            switch (regex.Regex.compile(r, .{ .extended = true })) {
                .ok => |re| d.regexp = re,
                .err => {
                    util.err("invalid pattern: {s}", .{r});
                    return config.CONFIG_INVALID_PATTERN;
                },
            }
        }
    }
    _ = readConfig(.{ .f = collectFn, .ctx = &d });

    if (d.values.items.len == 0) {
        if (default_value) |dv| {
            var b: util.Buf = .empty;
            const status = formatConfig(&b, key_, dv, &config.kvi_param, false, d.keys);
            if (status < 0) util.die("failed to format default config value: {s}", .{dv});
            if (status == 0) d.values.append(gpa, b.items) catch util.oom();
        }
    }
    const n = d.values.items.len;
    for (d.values.items, 0..) |v, i| {
        if (gv_flags & GET_VALUE_ALL != 0 or i == n - 1) util.out(v);
    }
    return @intFromBool(n == 0);
}

fn normalizeValue(key: []const u8, value: []const u8, typ: i32) []const u8 {
    const kvi = config.KvInfo{};
    switch (typ) {
        TYPE_INT => return util.fmt("{d}", .{config.configInt64(key, value, &kvi)}),
        TYPE_BOOL => return if (config.configBool(key, value)) "true" else "false",
        TYPE_BOOL_OR_INT => {
            var is_bool = false;
            const v = config.configBoolOrInt(key, value, &kvi, &is_bool);
            if (!is_bool) return util.fmt("{d}", .{v});
            return if (v != 0) "true" else "false";
        },
        TYPE_BOOL_OR_STR => {
            const v = config.parseMaybeBool(value);
            if (v < 0) return value;
            return if (v != 0) "true" else "false";
        },
        TYPE_COLOR => {
            if (color.parseColorOrError(value) == null) util.die("cannot parse color '{s}'", .{value});
            return value;
        },
        else => return value,
    }
}

// ---------------------------------------------------------------------------
// colors

const ColorData = struct {
    found: bool = false,
    slot: []const u8,
    parsed: []const u8 = "",
};

fn getColorFn(ctx: *anyopaque, key: []const u8, value: ?[]const u8, _: *const config.KvInfo) i32 {
    const d: *ColorData = @ptrCast(@alignCast(ctx));
    if (util.eql(key, d.slot)) {
        const v = value orelse {
            _ = config.errorNonbool(key);
            // color_parse(NULL) in git would crash; treat as failure
            return -1;
        };
        d.parsed = color.parseColorOrError(v) orelse return -1;
        d.found = true;
    }
    return 0;
}

fn getColor(slot: []const u8, def: ?[]const u8) i32 {
    var d = ColorData{ .slot = slot };
    _ = readConfig(.{ .f = getColorFn, .ctx = &d });
    var ret: i32 = 0;
    if (!d.found) {
        if (def) |dc| {
            if (color.parseColorOrError(dc)) |c| {
                d.parsed = c;
            } else {
                util.err("unable to parse default color value", .{});
                ret = -1;
            }
        }
    }
    util.out(d.parsed);
    return ret;
}

const ColorBoolData = struct {
    slot: []const u8,
    found: color.ColorBool = .unknown,
    diff_found: color.ColorBool = .unknown,
    ui_found: color.ColorBool = .unknown,
};

fn getColorBoolFn(ctx: *anyopaque, key: []const u8, value: ?[]const u8, _: *const config.KvInfo) i32 {
    const d: *ColorBoolData = @ptrCast(@alignCast(ctx));
    if (util.eql(key, d.slot)) {
        d.found = color.configColorBool(key, value);
    } else if (util.eql(key, "diff.color")) {
        d.diff_found = color.configColorBool(key, value);
    } else if (util.eql(key, "color.ui")) {
        d.ui_found = color.configColorBool(key, value);
    }
    return 0;
}

fn getColorBool(slot: []const u8, tty: ?bool, print: bool) i32 {
    var d = ColorBoolData{ .slot = slot };
    _ = readConfig(.{ .f = getColorBoolFn, .ctx = &d });
    if (d.found == .unknown) {
        if (util.eql(slot, "color.diff")) d.found = d.diff_found;
        if (d.found == .unknown) d.found = d.ui_found;
    }
    if (d.found == .unknown) d.found = .auto;
    const result = color.wantColorBool(d.found, tty);
    if (print) {
        util.out(if (result) "true\n" else "false\n");
        return 0;
    }
    return if (result) 0 else 1;
}

// ---------------------------------------------------------------------------
// urlmatch

const UrlCand = struct { value: ?[]const u8, kvi: config.KvInfo };

const UrlCollect = struct {
    map: std.StringHashMapUnmanaged(UrlCand) = .empty,
};

fn urlCollectFn(ctx: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo) i32 {
    const d: *UrlCollect = @ptrCast(@alignCast(ctx));
    const gop = d.map.getOrPut(gpa, util.dupe(key)) catch util.oom();
    gop.value_ptr.* = .{ .value = if (value) |v| util.dupe(v) else null, .kvi = kvi.* };
    return 0;
}

fn getUrlmatch(var_: []const u8, url: []const u8) i32 {
    const info = switch (config.urlNormalize(url, false)) {
        .ok => |i| i,
        .err => |e| util.die("{s}", .{e}),
    };
    const section_full = util.lower(var_);
    var section: []const u8 = section_full;
    var key: ?[]const u8 = null;
    var keys: bool = undefined;
    if (std.mem.indexOfScalar(u8, section_full, '.')) |dot| {
        section = section_full[0..dot];
        key = section_full[dot + 1 ..];
        keys = false;
    } else {
        keys = true;
    }
    var values = UrlCollect{};
    var umc = config.UrlMatchConfig{
        .url = info,
        .section = section,
        .key = key,
        .collect = .{ .f = urlCollectFn, .ctx = &values },
    };
    _ = readConfig(umc.callback());

    var names: std.ArrayList([]const u8) = .empty;
    var it = values.map.keyIterator();
    while (it.next()) |k| names.append(gpa, k.*) catch util.oom();
    util.sortStrings(names.items);
    for (names.items) |name| {
        const cand = values.map.get(name).?;
        var b: util.Buf = .empty;
        const status = formatConfig(&b, name, cand.value, &cand.kvi, false, keys);
        if (status == 0) util.out(b.items);
    }
    return @intFromBool(names.items.len == 0);
}

// ---------------------------------------------------------------------------
// editor

const Passwd = extern struct {
    pw_name: ?[*:0]const u8,
    pw_passwd: ?[*:0]const u8,
    pw_uid: u32,
    pw_gid: u32,
    pw_gecos: ?[*:0]const u8,
    pw_dir: ?[*:0]const u8,
    pw_shell: ?[*:0]const u8,
};
extern "c" fn getpwuid(uid: u32) ?*Passwd;
extern "c" fn getuid() u32;

fn pwName() []const u8 {
    if (getpwuid(getuid())) |pw| {
        if (pw.pw_name) |p| return util.dupe(std.mem.span(p));
    }
    return "unknown";
}

/// ident_default_name(): user.name, else the gecos name.
fn defaultIdentName() []const u8 {
    if (repo_mod.cfg.get("user.name")) |n| return n;
    const pw = getpwuid(getuid()) orelse return "Unknown";
    const name: []const u8 = if (pw.pw_name) |p| std.mem.span(p) else "";
    const gecos: []const u8 = if (pw.pw_gecos) |p| std.mem.span(p) else name;
    var b: util.Buf = .empty;
    for (gecos) |ch| {
        if (ch == ',') break;
        if (ch != '&') {
            util.bufByte(&b, ch);
        } else if (name.len > 0) {
            util.bufByte(&b, std.ascii.toUpper(name[0]));
            util.bufAppend(&b, name[1..]);
        }
    }
    return std.mem.trim(u8, b.items, " \t\n\r");
}

/// ident_default_email(): user.email, $EMAIL, else <user>@<host>.
fn defaultIdentEmail() []const u8 {
    if (repo_mod.cfg.get("user.email")) |e| return e;
    if (os.getenv("EMAIL")) |e| {
        if (e.len > 0) return std.mem.trim(u8, e, " \t\n\r");
    }
    const user = pwName();
    if (os.readFile("/etc/mailname")) |mn| {
        return util.concat(&.{ user, "@", mn[0 .. std.mem.indexOfScalar(u8, mn, '\n') orelse mn.len] });
    }
    var buf: [256]u8 = undefined;
    if (std.c.gethostname(&buf, buf.len) != 0) return util.concat(&.{ user, "@(none)" });
    buf[buf.len - 1] = 0;
    const host = util.dupe(std.mem.sliceTo(&buf, 0));
    if (std.mem.indexOfScalar(u8, host, '.') != null) return util.concat(&.{ user, "@", host });
    return util.concat(&.{ user, "@", host, ".(none)" });
}

fn showEditor() i32 {
    if (src_file == null and !haveRepo()) util.die("not in a git directory", .{});
    if (use_stdin) util.die("editing stdin is not supported", .{});
    if (src_blob != null) util.die("editing blobs is not supported", .{});
    const file = src_file orelse repo_mod.repo().commonPath("config");
    if (use_global) {
        const fd = std.c.open(os.z(file), .{ .ACCMODE = .WRONLY, .CREAT = true, .EXCL = true }, @as(std.c.mode_t, 0o666));
        if (fd >= 0) {
            const content = util.fmt("# This is Git's per-user configuration file.\n[user]\n# Please adapt and uncomment the following lines:\n#\tname = {s}\n#\temail = {s}\n", .{ defaultIdentName(), defaultIdentEmail() });
            os.writeAll(fd, content) catch {};
            _ = std.c.close(fd);
        } else if (os.errno() != os.EEXIST) {
            util.dieErrno("cannot create configuration file {s}", .{file});
        }
    }
    const editor = @import("../editor.zig");
    if (editor.launchSpecified(editor.gitEditor(), file, &.{})) return -1;
    return 0;
}

// ---------------------------------------------------------------------------
// writing helpers

fn patternFrom(p: ?[]const u8) config.ValuePattern {
    return if (p) |s| .{ .pattern = s } else .any;
}

fn setFlagsFrom(flags: i32) config.SetFlags {
    return .{ .fixed_value = flags & FLAG_FIXED_VALUE != 0, .multi_replace = flags & FLAG_MULTI_REPLACE != 0 };
}

fn renameOrRemove(old: []const u8, new: ?[]const u8) i32 {
    const ret = config.renameSectionInFile(writeFile(), old, new, false);
    if (ret < 0) return ret;
    if (ret == 0) util.die("no such section: {s}", .{old});
    return 0;
}

// ---------------------------------------------------------------------------
// subcommands

fn cmdList(args: []const []const u8) i32 {
    const rest = parseArgs(args, &list_opts, &list_usage, false);
    checkArgc(rest.len, 0, 0);
    locationInit();
    displayInitList();
    setupAutoPager();
    doList();
    return 0;
}

fn cmdGet(args: []const []const u8) i32 {
    const rest = parseArgs(args, &get_opts, &get_usage, true);
    checkArgc(rest.len, 1, 1);
    if (fixed_value_flag & FLAG_FIXED_VALUE != 0 and value_pattern == null)
        util.die("--fixed-value only applies with 'value-pattern'", .{});
    if (default_value != null and (get_value_flags & GET_VALUE_ALL != 0 or url_arg != null))
        util.die("--default= cannot be used with --all or --url=", .{});
    if (url_arg != null and (get_value_flags & (GET_VALUE_ALL | GET_VALUE_KEY_REGEXP) != 0 or value_pattern != null))
        util.die("--url= cannot be used with --all, --regexp or --value", .{});
    locationInit();
    displayInit();
    if (type_ != TYPE_COLOR) setupAutoPager();
    if (url_arg) |u| return getUrlmatch(rest[0], u);
    if (type_ == TYPE_COLOR and rest[0].len == 0 and default_value != null)
        return getColor("", default_value);
    return getValue(rest[0], value_pattern, get_value_flags, fixed_value_flag);
}

fn cmdSet(args: []const []const u8) i32 {
    const rest = parseArgs(args, &set_opts, &set_usage, true);
    if (rest.len == 1) dieMissingSetValue(rest[0]);
    checkArgc(rest.len, 2, 2);
    if (set_flags & FLAG_FIXED_VALUE != 0 and value_pattern == null)
        util.die("--fixed-value only applies with --value=<pattern>", .{});
    if (append_flag and value_pattern != null)
        util.die("--append cannot be used with --value=<pattern>", .{});
    const comment: ?[]const u8 = if (comment_arg) |c| config.prepareComment(c) else null;
    locationInit();
    checkWrite();
    const value = normalizeValue(rest[0], rest[1], type_);
    if (set_flags & FLAG_MULTI_REPLACE != 0 or value_pattern != null or append_flag) {
        const pat: config.ValuePattern = if (append_flag) .none else patternFrom(value_pattern);
        return config.setMultivarInFile(writeFile(), rest[0], value, pat, comment, setFlagsFrom(set_flags));
    }
    const ret = config.setInFileGently(writeFile(), rest[0], comment, value);
    if (ret == config.CONFIG_NOTHING_SET)
        util.err("cannot overwrite multiple values with a single value\n       Use --value=<pattern>, --append or --all to change {s}.", .{rest[0]});
    return ret;
}

fn cmdUnset(args: []const []const u8) i32 {
    const rest = parseArgs(args, &unset_opts, &unset_usage, true);
    checkArgc(rest.len, 1, 1);
    if (set_flags & FLAG_FIXED_VALUE != 0 and value_pattern == null)
        util.die("--fixed-value only applies with 'value-pattern'", .{});
    locationInit();
    checkWrite();
    if (set_flags & FLAG_MULTI_REPLACE != 0 or value_pattern != null)
        return config.setMultivarInFile(writeFile(), rest[0], null, patternFrom(value_pattern), null, setFlagsFrom(set_flags));
    return config.setInFileGently(writeFile(), rest[0], null, null);
}

fn cmdRenameSection(args: []const []const u8) i32 {
    const rest = parseArgs(args, &location_opts, &rename_usage, true);
    checkArgc(rest.len, 2, 2);
    locationInit();
    checkWrite();
    return renameOrRemove(rest[0], rest[1]);
}

fn cmdRemoveSection(args: []const []const u8) i32 {
    const rest = parseArgs(args, &location_opts, &remove_usage, true);
    checkArgc(rest.len, 1, 1);
    locationInit();
    checkWrite();
    return renameOrRemove(rest[0], null);
}

fn cmdEdit(args: []const []const u8) i32 {
    const rest = parseArgs(args, &location_opts, &edit_usage, false);
    checkArgc(rest.len, 0, 0);
    locationInit();
    checkWrite();
    return showEditor();
}

// ---------------------------------------------------------------------------
// legacy mode

fn cmdActions(args: []const []const u8) i32 {
    const argv = parseArgs(args, &legacy_opts, &builtin_config_usage, true);
    const argc = argv.len;
    const arg1: ?[]const u8 = if (argc > 1) argv[1] else null;
    const arg2: ?[]const u8 = if (argc > 2) argv[2] else null;

    locationInit();
    displayInit();

    if (actions & (ACTION_GET_COLOR | ACTION_GET_COLORBOOL) != 0 and type_ != 0) {
        util.err("--get-color and variable type are incoherent", .{});
        os.exit(129);
    }

    const implicit = actions == 0;
    if (implicit) {
        switch (argc) {
            1 => actions = ACTION_GET,
            2 => actions = ACTION_SET,
            3 => actions = ACTION_SET_ALL,
            else => {
                util.err("no action specified", .{});
                os.exit(129);
            },
        }
    }
    if (implicit and argc == 1) {
        if (std.mem.lastIndexOfScalar(u8, argv[0], '.')) |d| {
            if (std.mem.indexOfScalarPos(u8, argv[0], d + 1, '=') != null) dieMissingSetValue(argv[0]);
        }
    }
    if (omit_values and !(actions == ACTION_LIST or actions == ACTION_GET_REGEXP)) {
        util.err("--name-only is only applicable to --list or --get-regexp", .{});
        os.exit(129);
    }
    if (show_origin and actions & (ACTION_GET | ACTION_GET_ALL | ACTION_GET_REGEXP | ACTION_LIST) == 0) {
        util.err("--show-origin is only applicable to --get, --get-all, --get-regexp, and --list", .{});
        os.exit(129);
    }
    if (default_value != null and actions & ACTION_GET == 0) {
        util.err("--default is only applicable to --get", .{});
        os.exit(129);
    }
    if (comment_arg != null and actions & (ACTION_ADD | ACTION_SET | ACTION_SET_ALL | ACTION_REPLACE_ALL) == 0) {
        util.err("--comment is only applicable to add/set/replace operations", .{});
        os.exit(129);
    }
    const flags = fixed_value_flag;
    if (flags & FLAG_FIXED_VALUE != 0) {
        const allowed = switch (actions) {
            ACTION_GET, ACTION_GET_ALL, ACTION_GET_REGEXP, ACTION_UNSET, ACTION_UNSET_ALL => argc > 1,
            ACTION_SET_ALL, ACTION_REPLACE_ALL => argc > 2,
            else => false,
        };
        if (!allowed) {
            util.err("--fixed-value only applies with 'value-pattern'", .{});
            os.exit(129);
        }
    }
    const comment: ?[]const u8 = if (comment_arg) |c| config.prepareComment(c) else null;

    if (actions & (ACTION_LIST | ACTION_GET_ALL | ACTION_GET_REGEXP | ACTION_GET_URLMATCH) != 0) setupAutoPager();

    var ret: i32 = 0;
    switch (actions) {
        ACTION_LIST => {
            checkArgc(argc, 0, 0);
            displayInitList();
            doList();
        },
        ACTION_EDIT => ret = showEditor(),
        ACTION_SET => {
            checkWrite();
            checkArgc(argc, 2, 2);
            const value = normalizeValue(argv[0], argv[1], type_);
            ret = config.setInFileGently(writeFile(), argv[0], comment, value);
            if (ret == config.CONFIG_NOTHING_SET)
                util.err("cannot overwrite multiple values with a single value\n       Use a regexp, --add or --replace-all to change {s}.", .{argv[0]});
        },
        ACTION_SET_ALL => {
            checkWrite();
            checkArgc(argc, 2, 3);
            const value = normalizeValue(argv[0], argv[1], type_);
            ret = config.setMultivarInFile(writeFile(), argv[0], value, patternFrom(arg2), comment, setFlagsFrom(flags));
        },
        ACTION_ADD => {
            checkWrite();
            checkArgc(argc, 2, 2);
            const value = normalizeValue(argv[0], argv[1], type_);
            ret = config.setMultivarInFile(writeFile(), argv[0], value, .none, comment, setFlagsFrom(flags));
        },
        ACTION_REPLACE_ALL => {
            checkWrite();
            checkArgc(argc, 2, 3);
            const value = normalizeValue(argv[0], argv[1], type_);
            ret = config.setMultivarInFile(writeFile(), argv[0], value, patternFrom(arg2), comment, setFlagsFrom(flags | FLAG_MULTI_REPLACE));
        },
        ACTION_GET => {
            checkArgc(argc, 1, 2);
            ret = getValue(argv[0], arg1, 0, flags);
        },
        ACTION_GET_ALL => {
            checkArgc(argc, 1, 2);
            ret = getValue(argv[0], arg1, GET_VALUE_ALL, flags);
        },
        ACTION_GET_REGEXP => {
            show_keys = true;
            checkArgc(argc, 1, 2);
            ret = getValue(argv[0], arg1, GET_VALUE_ALL | GET_VALUE_KEY_REGEXP, flags);
        },
        ACTION_GET_URLMATCH => {
            checkArgc(argc, 2, 2);
            ret = getUrlmatch(argv[0], argv[1]);
        },
        ACTION_UNSET => {
            checkWrite();
            checkArgc(argc, 1, 2);
            if (argc == 2) {
                ret = config.setMultivarInFile(writeFile(), argv[0], null, patternFrom(argv[1]), null, setFlagsFrom(flags));
            } else {
                ret = config.setInFileGently(writeFile(), argv[0], null, null);
            }
        },
        ACTION_UNSET_ALL => {
            checkWrite();
            checkArgc(argc, 1, 2);
            ret = config.setMultivarInFile(writeFile(), argv[0], null, patternFrom(arg1), null, setFlagsFrom(flags | FLAG_MULTI_REPLACE));
        },
        ACTION_RENAME_SECTION => {
            checkWrite();
            checkArgc(argc, 2, 2);
            ret = renameOrRemove(argv[0], argv[1]);
        },
        ACTION_REMOVE_SECTION => {
            checkWrite();
            checkArgc(argc, 1, 1);
            ret = renameOrRemove(argv[0], null);
        },
        ACTION_GET_COLOR => {
            checkArgc(argc, 1, 2);
            ret = getColor(argv[0], arg1);
        },
        ACTION_GET_COLORBOOL => {
            checkArgc(argc, 1, 2);
            var tty: ?bool = null;
            if (argc == 2) tty = config.configBool("command line", argv[1]);
            ret = getColorBool(argv[0], tty, argc == 2);
        },
        else => {},
    }
    return ret;
}

pub fn cmdConfig(args: []const []const u8) u8 {
    const rest = args[1..];
    if (rest.len == 1 and util.eql(rest[0], "-h")) {
        parseopt.printUsage(&builtin_config_usage, &.{}, false);
        os.exit(129);
    }
    if (rest.len > 0) {
        const sub = rest[0];
        const sargs = rest[1..];
        const r: ?i32 = if (util.eql(sub, "list"))
            cmdList(sargs)
        else if (util.eql(sub, "get"))
            cmdGet(sargs)
        else if (util.eql(sub, "set"))
            cmdSet(sargs)
        else if (util.eql(sub, "unset"))
            cmdUnset(sargs)
        else if (util.eql(sub, "rename-section"))
            cmdRenameSection(sargs)
        else if (util.eql(sub, "remove-section"))
            cmdRemoveSection(sargs)
        else if (util.eql(sub, "edit"))
            cmdEdit(sargs)
        else
            null;
        if (r) |code| return exitCode(code);
    }
    return exitCode(cmdActions(rest));
}
