//! Sparse index (sparse-index.c): "sdir" extension, sparse directory entries.
//! STUB: full port pending.

const std = @import("std");
const util = @import("util.zig");
const index_mod = @import("index.zig");

/// !command_requires_full_index: set by sparse-aware commands before reading.
pub var keep_sparse: bool = false;

/// convert_to_sparse()
pub fn convertToSparse(idx: *index_mod.Index) void {
    _ = idx;
}

/// ensure_full_index()
pub fn ensureFull(idx: *index_mod.Index) void {
    _ = idx;
}
