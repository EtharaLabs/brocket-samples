//! git blame / git annotate (port of blame.c and builtin/blame.c)

const std = @import("std");
const util = @import("../util.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const refs = @import("../refs.zig");
const cn = @import("../commitnode.zig");
const revision = @import("../revision.zig");
const po = @import("../parseopt.zig");
const xdiff = @import("../xdiff.zig");
const linerange = @import("../linerange.zig");
const date = @import("../date.zig");
const mailmap = @import("../mailmap.zig");
const pretty = @import("../pretty.zig");
const index_mod = @import("../index.zig");
const os = @import("../os.zig");
const convert = @import("../convert.zig");
const color = @import("../color.zig");
const odb_mod = @import("../odb.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Commit = cn.Commit;
const Buf = util.Buf;

const METAINFO_SHOWN: u32 = 1 << 12;
const MORE_THAN_ONE_PATH: u32 = 1 << 13;
const INT_MAX: i32 = std.math.maxInt(i32);

const S_IFMT: u32 = 0o170000;
const S_IFREG: u32 = 0o100000;

// ---------------------------------------------------------------------------
// scoreboard data structures

const Origin = struct {
    refcnt: i32 = 1,
    previous: ?*Origin = null,
    next: ?*Origin = null,
    commit: *Commit,
    suspects: ?*Entry = null,
    file: ?[]const u8 = null,
    blob_oid: Oid = hash.zero,
    mode: u32 = 0,
    guilty: bool = false,
    path: []const u8,
};

const Entry = struct {
    next: ?*Entry = null,
    lno: i32 = 0,
    num_lines: i32 = 0,
    suspect: ?*Origin = null,
    s_lno: i32 = 0,
    score: u32 = 0,
    ignored: bool = false,
    unblamable: bool = false,
};

var suspects_slab = cn.Slab(?*Origin).init(null);

fn getSuspects(c: *Commit) ?*Origin {
    const p = suspects_slab.peek(c) orelse return null;
    return p.*;
}
fn setSuspects(c: *Commit, o: ?*Origin) void {
    suspects_slab.at(c).* = o;
}

fn incref(o: ?*Origin) ?*Origin {
    if (o) |x| x.refcnt += 1;
    return o;
}

fn decref(o0: ?*Origin) void {
    const o = o0 orelse return;
    o.refcnt -= 1;
    if (o.refcnt > 0) return;
    if (o.previous) |p| decref(p);
    o.file = null;
    var l: ?*Origin = null;
    var p = getSuspects(o.commit);
    while (p) |x| : ({
        l = x;
        p = x.next;
    }) {
        if (x == o) {
            if (l) |ll| ll.next = x.next else setSuspects(o.commit, x.next);
            return;
        }
    }
    util.die("internal error in blame_origin_decref", .{});
}

fn makeOrigin(commit: *Commit, path: []const u8) *Origin {
    const o = gpa.create(Origin) catch util.oom();
    o.* = .{ .commit = commit, .path = util.dupe(path) };
    o.next = getSuspects(commit);
    setSuspects(commit, o);
    return o;
}

fn getOrigin(commit: *Commit, path: []const u8) *Origin {
    var l: ?*Origin = null;
    var p = getSuspects(commit);
    while (p) |o| : ({
        l = o;
        p = o.next;
    }) {
        if (util.eql(o.path, path)) {
            if (l) |ll| {
                ll.next = o.next;
                o.next = getSuspects(commit);
                setSuspects(commit, o);
            }
            return incref(o).?;
        }
    }
    return makeOrigin(commit, path);
}

// scoreboard state
var sb_revs: *revision.RevInfo = undefined;
var sb_reverse = false;
var sb_show_root = false;
var sb_no_whole_file_rename = false;
var sb_xflags: xdiff.Flags = .{};
var sb_commits: cn.PrioQueue = .{ .compare = cn.compareByCommitDate };
var sb_ent: ?*Entry = null;
var sb_final_buf: []const u8 = "";
var sb_lineno: []usize = &.{};
var sb_num_lines: i32 = 0;
var sb_path: []const u8 = "";
var sb_num_read_blob: i32 = 0;
var sb_num_get_patch: i32 = 0;
var sb_num_commits: i32 = 0;

fn compareReverseCommitDate(a: *Commit, b: *Commit, d: ?*anyopaque) i32 {
    return -cn.compareByCommitDate(a, b, d);
}

fn fillOriginBlob(o: *Origin) []const u8 {
    if (o.file) |f| return f;
    sb_num_read_blob += 1;
    if (hash.isZero(o.blob_oid)) {
        o.file = "";
        return "";
    }
    const obj = repo_mod.repo().odb().read(o.blob_oid) orelse
        util.die("unable to read {s}", .{hash.hex(o.blob_oid)});
    o.file = obj.data;
    return obj.data;
}

// ---------------------------------------------------------------------------
// entry list helpers

fn blameMerge(list1: ?*Entry, list2: ?*Entry) ?*Entry {
    var p1 = list1 orelse return list2;
    var p2 = list2 orelse return list1;
    var head: ?*Entry = list1;
    var tail: *?*Entry = &head;
    if (p1.s_lno <= p2.s_lno) {
        while (true) {
            tail = &p1.next;
            p1 = tail.* orelse {
                tail.* = p2;
                return head;
            };
            if (!(p1.s_lno <= p2.s_lno)) break;
        }
    }
    while (true) {
        tail.* = p2;
        while (true) {
            tail = &p2.next;
            p2 = tail.* orelse {
                tail.* = p1;
                return head;
            };
            if (!(p1.s_lno > p2.s_lno)) break;
        }
        tail.* = p1;
        while (true) {
            tail = &p1.next;
            p1 = tail.* orelse {
                tail.* = p2;
                return head;
            };
            if (!(p1.s_lno <= p2.s_lno)) break;
        }
    }
}

fn sortEntries(head: *?*Entry, comptime lessFn: fn (void, *Entry, *Entry) bool) void {
    var arr: std.ArrayList(*Entry) = .empty;
    var e = head.*;
    while (e) |x| : (e = x.next) arr.append(gpa, x) catch util.oom();
    std.mem.sort(*Entry, arr.items, {}, lessFn);
    var tail: *?*Entry = head;
    for (arr.items) |x| {
        tail.* = x;
        tail = &x.next;
    }
    tail.* = null;
}

fn lessFinal(_: void, a: *Entry, b: *Entry) bool {
    return a.lno < b.lno;
}

fn lessSuspect(_: void, a: *Entry, b: *Entry) bool {
    const pa = @intFromPtr(a.suspect);
    const pb = @intFromPtr(b.suspect);
    if (pa != pb) return pa < pb;
    return a.s_lno < b.s_lno;
}

fn reverseBlame(head0: ?*Entry, tail0: ?*Entry) ?*Entry {
    var head = head0;
    var tail = tail0;
    while (head) |h| {
        const next = h.next;
        h.next = tail;
        tail = h;
        head = next;
    }
    return tail;
}

fn splitBlameAt(e: *Entry, len: i32, new_suspect: ?*Origin) *Entry {
    const n = gpa.create(Entry) catch util.oom();
    n.* = .{
        .suspect = new_suspect,
        .ignored = e.ignored,
        .unblamable = e.unblamable,
        .lno = e.lno + len,
        .s_lno = e.s_lno + len,
        .num_lines = e.num_lines - len,
    };
    e.num_lines = len;
    e.score = 0;
    return n;
}

fn queueBlames(porigin: *Origin, sorted: ?*Entry) void {
    if (porigin.suspects != null) {
        porigin.suspects = blameMerge(porigin.suspects, sorted);
    } else {
        var o = getSuspects(porigin.commit);
        while (o) |x| : (o = x.next) {
            if (x.suspects != null) {
                porigin.suspects = sorted;
                return;
            }
        }
        porigin.suspects = sorted;
        sb_commits.put(porigin.commit);
    }
}

fn blameCoalesce() void {
    var ent = sb_ent;
    while (ent) |e| {
        const next = e.next orelse break;
        if (e.suspect == next.suspect and
            e.s_lno + e.num_lines == next.s_lno and
            e.lno + e.num_lines == next.lno and
            e.ignored == next.ignored and
            e.unblamable == next.unblamable)
        {
            e.num_lines += next.num_lines;
            e.next = next.next;
            decref(next.suspect);
            e.score = 0;
            continue;
        }
        ent = next;
    }
}

// ---------------------------------------------------------------------------
// finding origins in parents

const ChildFile = struct { oid: Oid, mode: u32 };

/// The (blob, mode) of origin.path on the "child" side (commit tree or the
/// fake index for the working tree commit).
fn fillBlobOidAndMode(o: *Origin) bool {
    if (!hash.isZero(o.blob_oid)) return true;
    if (!cn.parse(o.commit)) return false;
    const te = objects.treeLookup(o.commit.tree, o.path) orelse return false;
    if (cn.objType(te.oid) != .blob) return false;
    o.blob_oid = te.oid;
    o.mode = te.mode;
    return true;
}

fn findOrigin(parent: *Commit, origin: *Origin) ?*Origin {
    var it = getSuspects(parent);
    while (it) |p| : (it = p.next) {
        if (util.eql(p.path, origin.path)) return incref(p);
    }
    const pe = objects.treeLookup(parent.tree, origin.path) orelse return null;
    if (pe.mode == 0o040000) return null; // added (directory in parent)
    if (hash.eql(pe.oid, origin.blob_oid) and pe.mode == origin.mode) {
        const porigin = getOrigin(parent, origin.path);
        porigin.blob_oid = origin.blob_oid;
        porigin.mode = origin.mode;
        return porigin;
    }
    if (pe.mode & S_IFMT != origin.mode & S_IFMT) return null; // type change
    const porigin = getOrigin(parent, origin.path);
    porigin.blob_oid = pe.oid;
    porigin.mode = pe.mode;
    return porigin;
}

// --- rename detection (diffcore-rename / diffcore-delta subset) ---

const MAX_SCORE: u64 = 60000;
const MIN_SCORE: u64 = 30000;
const HASHBASE: u32 = 107927;

fn hashChars(buf: []const u8) std.AutoHashMap(u32, u32) {
    var m = std.AutoHashMap(u32, u32).init(gpa);
    const check = buf[0..@min(buf.len, 8000)];
    const is_text = std.mem.indexOfScalar(u8, check, 0) == null;
    var n: u32 = 0;
    var accum1: u32 = 0;
    var accum2: u32 = 0;
    var i: usize = 0;
    while (i < buf.len) {
        const c: u32 = buf[i];
        i += 1;
        const old_1 = accum1;
        if (is_text and c == '\r' and i < buf.len and buf[i] == '\n') continue;
        accum1 = (accum1 << 7) ^ (accum2 >> 25);
        accum2 = (accum2 << 7) ^ (old_1 >> 25);
        accum1 +%= c;
        n += 1;
        if (n < 64 and c != '\n') continue;
        const hv = (accum1 +% accum2 *% 0x61) % HASHBASE;
        const gop = m.getOrPut(hv) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = 0;
        gop.value_ptr.* += n;
        n = 0;
        accum1 = 0;
        accum2 = 0;
    }
    if (n > 0) {
        const hv = (accum1 +% accum2 *% 0x61) % HASHBASE;
        const gop = m.getOrPut(hv) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = 0;
        gop.value_ptr.* += n;
    }
    return m;
}

fn estimateSimilarity(src: []const u8, src_mode: u32, dst: []const u8, dst_mode: u32, minimum_score: u64) u64 {
    if (src_mode & S_IFMT != S_IFREG or dst_mode & S_IFMT != S_IFREG) return 0;
    const max_size: u64 = @max(src.len, dst.len);
    const base_size: u64 = @min(src.len, dst.len);
    const delta_size = max_size - base_size;
    if (max_size * (MAX_SCORE - minimum_score) < delta_size * MAX_SCORE) return 0;
    var sm = hashChars(src);
    defer sm.deinit();
    var dm = hashChars(dst);
    defer dm.deinit();
    var sc: u64 = 0;
    var itr = sm.iterator();
    while (itr.next()) |kv| {
        const dc = dm.get(kv.key_ptr.*) orelse 0;
        sc += @min(kv.value_ptr.*, dc);
    }
    if (dst.len == 0) return 0;
    return sc * MAX_SCORE / max_size;
}

fn basenameOf(p: []const u8) []const u8 {
    if (std.mem.lastIndexOfScalar(u8, p, '/')) |i| return p[i + 1 ..];
    return p;
}

fn basenameSame(a: []const u8, b: []const u8) bool {
    return util.eql(basenameOf(a), basenameOf(b));
}

var fake_index: ?*index_mod.Index = null;
var fake_entry_path: []const u8 = "";

/// List of (path -> blob) on the child side of the diff for `origin`.
fn childFiles(origin: *Origin) std.StringHashMap(ChildFile) {
    var m = std.StringHashMap(ChildFile).init(gpa);
    if (hash.isZero(origin.commit.obj.oid)) {
        if (fake_index) |idx| {
            for (idx.entries.items) |e| m.put(e.path, .{ .oid = e.oid, .mode = e.mode }) catch util.oom();
        }
        m.put(origin.path, .{ .oid = origin.blob_oid, .mode = origin.mode }) catch util.oom();
    } else {
        var l: std.ArrayList(objects.FlatEntry) = .empty;
        objects.flattenTree(origin.commit.tree, "", &l);
        for (l.items) |e| m.put(e.path, .{ .oid = e.oid, .mode = e.mode }) catch util.oom();
    }
    return m;
}

fn readBlobData(oid: Oid) []const u8 {
    const obj = repo_mod.repo().odb().read(oid) orelse return "";
    return obj.data;
}

fn findRename(parent: *Commit, origin: *Origin) ?*Origin {
    // the destination must be an addition
    if (objects.treeLookup(parent.tree, origin.path)) |pe| {
        if (pe.mode != 0o040000) return null;
    }
    var child = childFiles(origin);
    defer child.deinit();
    var plist: std.ArrayList(objects.FlatEntry) = .empty;
    objects.flattenTree(parent.tree, "", &plist);
    // sources: deleted files
    var srcs: std.ArrayList(objects.FlatEntry) = .empty;
    for (plist.items) |e| {
        if (child.get(e.path) == null) srcs.append(gpa, e) catch util.oom();
    }
    if (srcs.items.len == 0) return null;

    var chosen: ?objects.FlatEntry = null;
    // exact renames
    {
        var best_score: i32 = -1;
        for (srcs.items) |s| {
            if (!hash.eql(s.oid, origin.blob_oid)) continue;
            if (s.mode & S_IFMT != S_IFREG or origin.mode & S_IFMT != S_IFREG) {
                if (s.mode != origin.mode) continue;
            }
            const score: i32 = 1 + @as(i32, @intFromBool(basenameSame(s.path, origin.path)));
            if (score > best_score) {
                chosen = s;
                best_score = score;
                if (score == 2) break;
            }
        }
    }
    if (chosen == null) {
        const dst = fillOriginBlob(origin);
        // basename-guided matching
        const base = basenameOf(origin.path);
        var nbase: usize = 0;
        var bsrc: ?objects.FlatEntry = null;
        for (srcs.items) |s| {
            if (util.eql(basenameOf(s.path), base)) {
                nbase += 1;
                bsrc = s;
            }
        }
        if (nbase == 1) {
            const min_basename_score = MIN_SCORE + (MAX_SCORE - MIN_SCORE) / 2;
            const s = bsrc.?;
            const score = estimateSimilarity(readBlobData(s.oid), s.mode, dst, origin.mode, min_basename_score);
            if (score >= min_basename_score) chosen = s;
        }
        if (chosen == null) {
            var best: u64 = 0;
            var best_name = false;
            for (srcs.items) |s| {
                if (s.mode & S_IFMT != S_IFREG) continue;
                const score = estimateSimilarity(readBlobData(s.oid), s.mode, dst, origin.mode, MIN_SCORE);
                if (score < MIN_SCORE) continue;
                const ns = basenameSame(s.path, origin.path);
                if (chosen == null or score > best or (score == best and ns and !best_name)) {
                    chosen = s;
                    best = score;
                    best_name = ns;
                }
            }
        }
    }
    const c = chosen orelse return null;
    const porigin = getOrigin(parent, c.path);
    porigin.blob_oid = c.oid;
    porigin.mode = c.mode;
    return porigin;
}

// ---------------------------------------------------------------------------
// passing blame

fn blameChunk(dstq: **?*Entry, srcq: **?*Entry, tlno: i32, offset: i32, same: i32, parent: *Origin) void {
    var e = srcq.*.*;
    var samep: ?*Entry = null;
    var diffp: ?*Entry = null;
    while (e) |ee| {
        if (ee.s_lno >= tlno) break;
        const next = ee.next;
        if (ee.s_lno + ee.num_lines > tlno) {
            const n = splitBlameAt(ee, tlno - ee.s_lno, ee.suspect);
            n.next = diffp;
            diffp = n;
        } else decref(ee.suspect);
        ee.suspect = incref(parent);
        ee.s_lno += offset;
        ee.next = samep;
        samep = ee;
        e = next;
    }
    if (samep) |sp| {
        dstq.*.* = reverseBlame(sp, dstq.*.*);
        dstq.* = &sp.next;
    }
    e = reverseBlame(diffp, e);
    samep = null;
    diffp = null;
    while (e) |ee| {
        if (ee.s_lno >= same) break;
        const next = ee.next;
        if (ee.s_lno + ee.num_lines > same) {
            const n = splitBlameAt(ee, same - ee.s_lno, incref(ee.suspect));
            n.next = samep;
            samep = n;
        }
        ee.next = diffp;
        diffp = ee;
        e = next;
    }
    srcq.*.* = reverseBlame(diffp, reverseBlame(samep, e));
    if (diffp) |dp| srcq.* = &dp.next;
}

const ChunkCtx = struct {
    parent: *Origin,
    target: *Origin,
    offset: i32 = 0,
    dstq: *?*Entry,
    srcq: *?*Entry,
};

fn blameChunkCb(ctx: ?*anyopaque, start_a: isize, count_a: isize, start_b: isize, count_b: isize) void {
    const d: *ChunkCtx = @ptrCast(@alignCast(ctx.?));
    const sa: i32 = @intCast(start_a);
    const ca: i32 = @intCast(count_a);
    const sbb: i32 = @intCast(start_b);
    const cb: i32 = @intCast(count_b);
    if (sa - sbb != d.offset) util.die("internal error in blame::blame_chunk_cb", .{});
    blameChunk(&d.dstq, &d.srcq, sbb, sa - sbb, sbb + cb, d.parent);
    d.offset = sa + ca - (sbb + cb);
}

fn passBlameToParent(target: *Origin, parent: *Origin) void {
    if (target.suspects == null) return;
    var newdest: ?*Entry = null;
    var d = ChunkCtx{ .parent = parent, .target = target, .dstq = &newdest, .srcq = &target.suspects };
    const fp = fillOriginBlob(parent);
    const fo = fillOriginBlob(target);
    sb_num_get_patch += 1;
    const t = xdiff.trimCommonTail(fp, fo);
    var df = xdiff.diff(t.a, t.b, sb_xflags) catch
        util.die("unable to generate diff ({s} -> {s})", .{ hash.hex(parent.commit.obj.oid), hash.hex(target.commit.obj.oid) });
    defer df.deinit();
    xdiff.forEachHunkRange(&df, .{ .context = 0 }, &d, blameChunkCb);
    blameChunk(&d.dstq, &d.srcq, INT_MAX, d.offset, INT_MAX, parent);
    d.dstq.* = null;
    queueBlames(parent, newdest);
}

fn passWholeBlame(origin: *Origin, porigin: *Origin) void {
    if (porigin.file == null and origin.file != null) {
        porigin.file = origin.file;
        origin.file = null;
    }
    const suspects = origin.suspects;
    origin.suspects = null;
    var e = suspects;
    while (e) |x| : (e = x.next) {
        _ = incref(porigin);
        decref(x.suspect);
        x.suspect = porigin;
    }
    queueBlames(porigin, suspects);
}

fn firstScapegoat(commit: *Commit) ?*cn.CommitList {
    if (!sb_reverse) {
        if (sb_revs.first_parent_only) {
            if (commit.parents) |p| p.next = null;
        }
        return commit.parents;
    }
    return revision.getChildren(sb_revs, commit);
}

fn passBlame(origin: *Origin) void {
    const commit = origin.commit;
    const num_sg = cn.listCount(firstScapegoat(commit));
    if (num_sg == 0) return;
    const sg_origin = gpa.alloc(?*Origin, num_sg) catch util.oom();
    @memset(sg_origin, null);
    defer {
        for (sg_origin) |o| {
            if (o) |x| decref(x);
        }
    }
    const passes: usize = if (sb_no_whole_file_rename) 1 else 2;
    for (0..passes) |pass| {
        var i: usize = 0;
        var sg = firstScapegoat(commit);
        while (sg) |s| : ({
            sg = s.next;
            i += 1;
        }) {
            if (i >= num_sg) break;
            const p = s.item;
            if (sg_origin[i] != null) continue;
            if (!cn.parse(p)) continue;
            const porigin = (if (pass == 0) findOrigin(p, origin) else findRename(p, origin)) orelse continue;
            if (hash.eql(porigin.blob_oid, origin.blob_oid)) {
                passWholeBlame(origin, porigin);
                decref(porigin);
                return;
            }
            var same = false;
            for (0..i) |j| {
                if (sg_origin[j]) |o| {
                    if (hash.eql(o.blob_oid, porigin.blob_oid)) {
                        same = true;
                        break;
                    }
                }
            }
            if (!same) sg_origin[i] = porigin else decref(porigin);
        }
    }
    sb_num_commits += 1;
    var i: usize = 0;
    var sg = firstScapegoat(commit);
    while (sg) |s| : ({
        sg = s.next;
        i += 1;
    }) {
        if (i >= num_sg) break;
        const porigin = sg_origin[i] orelse continue;
        if (origin.previous == null) {
            _ = incref(porigin);
            origin.previous = porigin;
        }
        passBlameToParent(origin, porigin);
        if (origin.suspects == null) return;
    }
}

fn assignBlame() void {
    var commit_opt = sb_commits.get();
    while (commit_opt) |commit| {
        var suspect = getSuspects(commit);
        while (suspect) |s| {
            if (s.suspects != null) break;
            suspect = s.next;
        }
        const sus = suspect orelse {
            commit_opt = sb_commits.get();
            continue;
        };
        _ = incref(sus);
        _ = cn.parse(commit);
        if (sb_reverse or (commit.obj.flags & cn.UNINTERESTING == 0 and
            !(sb_revs.max_age != revision.UNSET_TIME and commit.date < sb_revs.max_age)))
        {
            passBlame(sus);
        } else {
            commit.obj.flags |= cn.UNINTERESTING;
            if (commit.obj.parsed) revision.markParentsUninteresting(sb_revs, commit);
        }
        if (commit.parents == null and !sb_show_root) commit.obj.flags |= cn.UNINTERESTING;

        if (sus.suspects) |first| {
            sus.guilty = true;
            var ent = first;
            while (true) {
                const next = ent.next;
                if (incremental) foundGuiltyEntry(ent);
                if (next) |n| {
                    ent = n;
                    continue;
                }
                ent.next = sb_ent;
                sb_ent = sus.suspects;
                sus.suspects = null;
                break;
            }
        }
        decref(sus);
    }
}

// ---------------------------------------------------------------------------
// setup

fn derefPending(e: revision.PendingEntry) ?*Commit {
    const o = cn.derefTag(e.item) orelse return null;
    if (o.typ != .commit) return null;
    return Commit.fromObj(o);
}

fn findSingleFinal(name_p: ?*?[]const u8) ?*Commit {
    var found: ?*Commit = null;
    var name: ?[]const u8 = null;
    for (sb_revs.pending.items) |e| {
        if (e.item.flags & cn.UNINTERESTING != 0) continue;
        const c = derefPending(e) orelse util.die("Non commit {s}?", .{e.name});
        if (found != null) util.die("More than one commit to dig from {s} and {s}?", .{ e.name, name.? });
        found = c;
        name = e.name;
    }
    if (name_p) |np| np.* = name;
    return found;
}

fn dwimReverseInitial(name_p: *?[]const u8) ?*Commit {
    if (sb_revs.pending.items.len != 1) return null;
    const e = sb_revs.pending.items[0];
    const o = cn.derefTag(e.item) orelse return null;
    if (o.typ != .commit) return null;
    const head = refs.readOid("HEAD") orelse return null;
    const head_commit = cn.lookupCommitReference(head) orelse return null;
    o.flags |= cn.UNINTERESTING;
    sb_revs.addPendingObject(&head_commit.obj, "HEAD");
    name_p.* = e.name;
    return Commit.fromObj(o);
}

fn findSingleInitial(name_p: *?[]const u8) ?*Commit {
    var found: ?*Commit = null;
    var name: ?[]const u8 = null;
    for (sb_revs.pending.items) |e| {
        if (e.item.flags & cn.UNINTERESTING == 0) continue;
        const c = derefPending(e) orelse util.die("Non commit {s}?", .{e.name});
        if (found != null) util.die("More than one commit to dig up from, {s} and {s}?", .{ e.name, name.? });
        found = c;
        name = e.name;
    }
    if (name == null) found = dwimReverseInitial(&name);
    if (name == null) util.die("No commit to dig up from?", .{});
    name_p.* = name;
    return found;
}

fn appendParent(tail: *?*cn.CommitList, oid: Oid) *?*cn.CommitList {
    const parent = cn.lookupCommitReference(oid) orelse util.die("no such commit {s}", .{hash.hex(oid)});
    return cn.listAppend(parent, tail);
}

fn fakeWorkingTreeCommit(path: []const u8, contents_from: ?[]const u8, oid: Oid) *Commit {
    const r = repo_mod.repo();
    const idx = index_mod.readFrom(r.indexPath());
    fake_index = idx;
    const now = os.now();
    const commit = cn.lookupCommit(hash.zero).?;
    commit.obj.parsed = true;
    commit.date = @intCast(now);
    commit.parents = null;
    var tail = appendParent(&commit.parents, oid);
    // MERGE_HEAD
    const mh_path = r.gitPath("MERGE_HEAD");
    if (os.readFile(mh_path)) |data| {
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line| {
            if (line.len == 0 and it.index == null) break;
            const o = (if (line.len >= 40) hash.fromHex(line[0..40]) else null) orelse
                util.die("unknown line in '{s}': {s}\n", .{ mh_path, line });
            tail = appendParent(tail, o);
        }
    }
    // verify_working_tree_path
    verify: {
        var p = commit.parents;
        while (p) |x| : (p = x.next) {
            if (!cn.parse(x.item)) continue;
            if (objects.treeLookup(x.item.tree, path)) |te| {
                if (cn.objType(te.oid) == .blob) break :verify;
            }
        }
        const pos = idx.firstPos(path);
        if (pos < idx.entries.items.len and util.eql(idx.entries.items[pos].path, path)) break :verify;
        util.die("no such path '{s}' in HEAD", .{path});
    }

    const origin = makeOrigin(commit, path);
    const ident = if (contents_from != null)
        util.fmt("External file (--contents) <external.file> {s}", .{date.datestamp()})
    else
        util.fmt("Not Committed Yet <not.committed.yet> {s}", .{date.datestamp()});
    var msg: Buf = .empty;
    util.bufAppend(&msg, "tree 0000000000000000000000000000000000000000\n");
    var p = commit.parents;
    while (p) |x| : (p = x.next) util.bufPrint(&msg, "parent {s}\n", .{hash.hex(x.item.obj.oid)});
    const from = if (contents_from) |cf| (if (util.eql(cf, "-")) "standard input" else cf) else path;
    util.bufPrint(&msg, "author {s}\ncommitter {s}\n\nVersion of {s} from {s}\n", .{ ident, ident, path, from });
    commit.buffer = msg.items;

    var mode: u32 = 0;
    var buf: []const u8 = "";
    if (contents_from == null or !util.eql(contents_from.?, "-")) {
        var read_from: []const u8 = undefined;
        var st: os.Stat = undefined;
        if (contents_from) |cf| {
            st = os.statPath(cf) orelse util.dieErrno("Cannot stat '{s}'", .{cf});
            read_from = cf;
        } else {
            st = os.lstatPath(path) orelse util.dieErrno("Cannot lstat '{s}'", .{path});
            read_from = path;
        }
        mode = index_mod.canonMode(st.mode);
        if (st.isReg()) {
            buf = os.readFile(read_from) orelse util.dieErrno("cannot open or read '{s}'", .{read_from});
        } else if (st.isLnk()) {
            buf = os.readLink(read_from) orelse util.dieErrno("cannot readlink '{s}'", .{read_from});
        } else util.die("unsupported file type {s}", .{read_from});
    } else {
        buf = os.readAllFd(0) catch util.dieErrno("failed to read from stdin", .{});
    }
    buf = convert.toGit(path, buf);
    origin.file = buf;
    origin.blob_oid = odb_mod.hashObject(.blob, buf);
    if (mode == 0) {
        if (idx.findPos(path)) |pos| mode = idx.entries.items[pos].mode else mode = S_IFREG | 0o644;
    }
    origin.mode = mode;
    fake_entry_path = path;
    return commit;
}

// ---------------------------------------------------------------------------
// output

const OUTPUT_ANNOTATE_COMPAT: u32 = 1 << 0;
const OUTPUT_LONG_OBJECT_NAME: u32 = 1 << 1;
const OUTPUT_RAW_TIMESTAMP: u32 = 1 << 2;
const OUTPUT_PORCELAIN: u32 = 1 << 3;
const OUTPUT_SHOW_NAME: u32 = 1 << 4;
const OUTPUT_SHOW_NUMBER: u32 = 1 << 5;
const OUTPUT_SHOW_SCORE: u32 = 1 << 6;
const OUTPUT_NO_AUTHOR: u32 = 1 << 7;
const OUTPUT_SHOW_EMAIL: u32 = 1 << 8;
const OUTPUT_LINE_PORCELAIN: u32 = 1 << 9;
const OUTPUT_COLOR_LINE: u32 = 1 << 10;
const OUTPUT_SHOW_AGE_WITH_COLOR: u32 = 1 << 11;

var longest_file: usize = 0;
var longest_author: i64 = 0;
var max_orig_digits: usize = 0;
var max_digits: usize = 0;
var max_score_digits: usize = 0;
var blank_boundary = false;
var incremental = false;
var abbrev: i32 = -1;
var blame_date_mode: date.DateMode = date.DateMode.of(.iso8601);
var blame_date_width: usize = 0;
var mark_unblamable_lines = false;
var mark_ignored_lines = false;
var repeated_meta_color: []const u8 = "";
var the_mailmap: ?*mailmap.Map = null;

const ColorField = struct { hop: i64, col: []const u8 };
var colorfield: std.ArrayList(ColorField) = .empty;

const CommitInfo = struct {
    author: []const u8 = "",
    author_mail: []const u8 = "",
    author_time: u64 = 0,
    author_tz: []const u8 = "",
    committer: []const u8 = "",
    committer_mail: []const u8 = "",
    committer_time: u64 = 0,
    committer_tz: []const u8 = "",
    summary: []const u8 = "",
};

const AcLine = struct { name: []const u8, mail: []const u8, time: u64, tz: []const u8 };

fn isSpace(c: u8) bool {
    return c == ' ' or (c >= 9 and c <= 13);
}

fn getAcLine(inbuf: []const u8, what: []const u8) AcLine {
    const unknown = AcLine{ .name = "(unknown)", .mail = "(unknown)", .time = 0, .tz = "(unknown)" };
    const pos = std.mem.indexOf(u8, inbuf, what) orelse return unknown;
    const tmp = inbuf[pos + what.len ..];
    const len = std.mem.indexOfScalar(u8, tmp, '\n') orelse tmp.len;
    const line = tmp[0..len];
    // split_ident_line
    const lt = std.mem.indexOfScalar(u8, line, '<') orelse return unknown;
    const mail_begin = lt + 1;
    var name_end: usize = 0;
    {
        var cp: isize = @as(isize, @intCast(mail_begin)) - 2;
        while (cp >= 0) : (cp -= 1) {
            if (!isSpace(line[@intCast(cp)])) {
                name_end = @as(usize, @intCast(cp)) + 1;
                break;
            }
        }
    }
    const mail_end = std.mem.indexOfScalarPos(u8, line, mail_begin, '>') orelse return unknown;
    var time: u64 = 0;
    var tz: []const u8 = "(unknown)";
    person: {
        var cp = (std.mem.lastIndexOfScalar(u8, line, '>') orelse break :person) + 1;
        while (cp < line.len and isSpace(line[cp])) cp += 1;
        if (cp >= line.len) break :person;
        const db = cp;
        while (cp < line.len and std.ascii.isDigit(line[cp])) cp += 1;
        if (cp == db) break :person;
        const de = cp;
        while (cp < line.len and isSpace(line[cp])) cp += 1;
        if (cp >= line.len or (line[cp] != '+' and line[cp] != '-')) break :person;
        const tb = cp;
        cp += 1;
        while (cp < line.len and std.ascii.isDigit(line[cp])) cp += 1;
        if (cp == tb + 1) break :person;
        time = std.fmt.parseInt(u64, line[db..de], 10) catch std.math.maxInt(u64);
        tz = line[tb..cp];
    }
    var name = line[0..name_end];
    var mail = line[mail_begin..mail_end];
    if (the_mailmap) |m| {
        if (m.mapUser(name, mail)) |mapped| {
            name = mapped.name;
            mail = mapped.email;
        }
    }
    return .{ .name = name, .mail = util.fmt("<{s}>", .{mail}), .time = time, .tz = tz };
}

fn findCommitSubjectC(msg: []const u8) []const u8 {
    var p: usize = 0;
    while (p < msg.len and !(msg[p] == '\n' and p + 1 < msg.len and msg[p + 1] == '\n')) p += 1;
    if (p < msg.len) {
        p = pretty.skipBlankLines(msg, p + 2);
        const eol = std.mem.indexOfScalarPos(u8, msg, p, '\n') orelse msg.len;
        return msg[p..eol];
    }
    return "";
}

fn getCommitInfo(commit: *Commit) CommitInfo {
    const message = pretty.logmsgReencode(commit, pretty.logOutputEncoding()).msg;
    const a = getAcLine(message, "\nauthor ");
    const c = getAcLine(message, "\ncommitter ");
    const subj = findCommitSubjectC(message);
    return .{
        .author = a.name,
        .author_mail = a.mail,
        .author_time = a.time,
        .author_tz = a.tz,
        .committer = c.name,
        .committer_mail = c.mail,
        .committer_time = c.time,
        .committer_tz = c.tz,
        .summary = if (subj.len > 0) subj else util.fmt("({s})", .{hash.hex(commit.obj.oid)}),
    };
}

fn writeNameQuoted(b: *Buf, name: []const u8) void {
    util.bufAppend(b, util.cquote(name));
    util.bufByte(b, '\n');
}

fn writeFilenameInfo(b: *Buf, suspect: *Origin) void {
    if (suspect.previous) |prev| {
        util.bufPrint(b, "previous {s} ", .{hash.hex(prev.commit.obj.oid)});
        writeNameQuoted(b, prev.path);
    }
    util.bufAppend(b, "filename ");
    writeNameQuoted(b, suspect.path);
}

fn emitOneSuspectDetail(b: *Buf, suspect: *Origin, repeat: bool) bool {
    const c = suspect.commit;
    if (!repeat and c.obj.flags & METAINFO_SHOWN != 0) return false;
    c.obj.flags |= METAINFO_SHOWN;
    const ci = getCommitInfo(c);
    util.bufPrint(b, "author {s}\nauthor-mail {s}\nauthor-time {d}\nauthor-tz {s}\n", .{ ci.author, ci.author_mail, ci.author_time, ci.author_tz });
    util.bufPrint(b, "committer {s}\ncommitter-mail {s}\ncommitter-time {d}\ncommitter-tz {s}\n", .{ ci.committer, ci.committer_mail, ci.committer_time, ci.committer_tz });
    util.bufPrint(b, "summary {s}\n", .{ci.summary});
    if (c.obj.flags & cn.UNINTERESTING != 0) util.bufAppend(b, "boundary\n");
    return true;
}

fn foundGuiltyEntry(ent: *Entry) void {
    const suspect = ent.suspect.?;
    var b: Buf = .empty;
    util.bufPrint(&b, "{s} {d} {d} {d}\n", .{ hash.hex(suspect.commit.obj.oid), ent.s_lno + 1, ent.lno + 1, ent.num_lines });
    _ = emitOneSuspectDetail(&b, suspect, false);
    writeFilenameInfo(&b, suspect);
    util.out(b.items);
    util.flushStdout();
}

fn formatTime(time: u64, tz_str: []const u8, show_raw: bool) []const u8 {
    var b: Buf = .empty;
    if (show_raw) {
        util.bufPrint(&b, "{d} {s}", .{ time, tz_str });
    } else {
        const tz = atoi(tz_str);
        const s = date.showDate(@intCast(@min(time, @as(u64, std.math.maxInt(i64)))), tz, blame_date_mode);
        util.bufAppend(&b, s);
        var w: usize = @intCast(@max(pretty.utf8Strwidth(s), 0));
        while (w < blame_date_width) : (w += 1) util.bufByte(&b, ' ');
    }
    return b.items;
}

fn atoi(s: []const u8) i32 {
    var i: usize = 0;
    while (i < s.len and isSpace(s[i])) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    var v: i32 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) v = v *% 10 +% @as(i32, s[i] - '0');
    return if (neg) -v else v;
}

fn printMarks(b: ?*Buf, ent: *const Entry, opt: u32) usize {
    var len: usize = 0;
    if (ent.suspect.?.commit.obj.flags & cn.UNINTERESTING != 0 and !blank_boundary and opt & OUTPUT_ANNOTATE_COMPAT == 0) {
        if (b) |bb| util.bufByte(bb, '^');
        len += 1;
    }
    if (mark_unblamable_lines and ent.unblamable) {
        if (b) |bb| util.bufByte(bb, '*');
        len += 1;
    }
    if (mark_ignored_lines and ent.ignored) {
        if (b) |bb| util.bufByte(bb, '?');
        len += 1;
    }
    return len;
}

fn nthLine(lno: i32) usize {
    const n: usize = @intCast(lno);
    if (n >= sb_lineno.len) return sb_final_buf.len;
    return sb_lineno[n];
}

fn emitPorcelainDetails(b: *Buf, suspect: *Origin, repeat: bool) void {
    if (emitOneSuspectDetail(b, suspect, repeat) or suspect.commit.obj.flags & MORE_THAN_ONE_PATH != 0)
        writeFilenameInfo(b, suspect);
}

fn emitPorcelainPerLine(b: *Buf, ent: *const Entry) void {
    if (mark_unblamable_lines and ent.unblamable) util.bufAppend(b, "unblamable\n");
    if (mark_ignored_lines and ent.ignored) util.bufAppend(b, "ignored\n");
}

fn emitPorcelain(ent: *Entry, opt: u32) void {
    const repeat = opt & OUTPUT_LINE_PORCELAIN != 0;
    const suspect = ent.suspect.?;
    const hex = hash.hex(suspect.commit.obj.oid);
    var b: Buf = .empty;
    util.bufPrint(&b, "{s} {d} {d} {d}\n", .{ hex, ent.s_lno + 1, ent.lno + 1, ent.num_lines });
    emitPorcelainDetails(&b, suspect, repeat);
    emitPorcelainPerLine(&b, ent);
    var cp = nthLine(ent.lno);
    const buf = sb_final_buf;
    var cnt: i32 = 0;
    while (cnt < ent.num_lines) : (cnt += 1) {
        if (cnt != 0) {
            util.bufPrint(&b, "{s} {d} {d}\n", .{ hex, ent.s_lno + 1 + cnt, ent.lno + 1 + cnt });
            if (repeat) emitPorcelainDetails(&b, suspect, true);
            emitPorcelainPerLine(&b, ent);
        }
        util.bufByte(&b, '\t');
        cp = copyLine(&b, buf, cp);
    }
    if (buf.len > 0 and cp > 0 and buf[cp - 1] != '\n') util.bufByte(&b, '\n');
    util.out(b.items);
}

/// copy one line (including '\n') from buf at cp; returns the new position
fn copyLine(b: *Buf, buf: []const u8, cp0: usize) usize {
    var cp = cp0;
    while (true) {
        const ch: u8 = if (cp < buf.len) buf[cp] else 0;
        cp += 1;
        util.bufByte(b, ch);
        if (ch == '\n' or cp >= buf.len) break;
    }
    return cp;
}

fn determineLineHeat(ci: *const CommitInfo) []const u8 {
    var i: usize = 0;
    while (i + 1 < colorfield.items.len and @as(i64, @intCast(@min(ci.author_time, @as(u64, std.math.maxInt(i64))))) > colorfield.items[i].hop) i += 1;
    return colorfield.items[i].col;
}

fn emitOther(ent: *Entry, opt: u32, prev_ent: ?*Entry) void {
    const suspect = ent.suspect.?;
    const ci = getCommitInfo(suspect.commit);
    var hex = hash.hex(suspect.commit.obj.oid);
    const show_raw = opt & OUTPUT_RAW_TIMESTAMP != 0;
    var default_color: ?[]const u8 = null;
    var col: ?[]const u8 = null;
    var reset: ?[]const u8 = null;
    if (opt & OUTPUT_SHOW_AGE_WITH_COLOR != 0) {
        default_color = determineLineHeat(&ci);
        col = default_color;
        reset = color.RESET;
    }
    var b: Buf = .empty;
    var cp = nthLine(ent.lno);
    const buf = sb_final_buf;
    var cnt: i32 = 0;
    while (cnt < ent.num_lines) : (cnt += 1) {
        var length: usize = if (opt & OUTPUT_LONG_OBJECT_NAME != 0) 40 else @intCast(abbrev);
        if (opt & OUTPUT_COLOR_LINE != 0) {
            if (cnt > 0 or (prev_ent != null and hash.eql(suspect.commit.obj.oid, prev_ent.?.suspect.?.commit.obj.oid))) {
                col = repeated_meta_color;
                reset = color.RESET;
            } else {
                col = default_color;
                reset = if (default_color != null) color.RESET else null;
            }
        }
        if (col) |cc| util.bufAppend(&b, cc);
        if (suspect.commit.obj.flags & cn.UNINTERESTING != 0 and blank_boundary) @memset(&hex, ' ');
        length -|= printMarks(&b, ent, opt);
        util.bufAppend(&b, hex[0..@min(length, 40)]);
        if (opt & OUTPUT_ANNOTATE_COMPAT != 0) {
            const name = if (opt & OUTPUT_SHOW_EMAIL != 0) ci.author_mail else ci.author;
            util.bufByte(&b, '\t');
            util.bufByte(&b, '(');
            padLeft(&b, name, 10);
            util.bufByte(&b, '\t');
            padLeft(&b, formatTime(ci.author_time, ci.author_tz, show_raw), 10);
            util.bufPrint(&b, "\t{d})", .{ent.lno + 1 + cnt});
        } else {
            if (opt & OUTPUT_SHOW_SCORE != 0) {
                util.bufByte(&b, ' ');
                padLeft(&b, util.fmt("{d}", .{ent.score}), max_score_digits);
                util.bufPrint(&b, " {d:0>2}", .{@as(u32, @intCast(@max(suspect.refcnt, 0)))});
            }
            if (opt & OUTPUT_SHOW_NAME != 0) {
                util.bufByte(&b, ' ');
                const p = suspect.path[0..@min(suspect.path.len, longest_file)];
                util.bufAppend(&b, p);
                var k = p.len;
                while (k < longest_file) : (k += 1) util.bufByte(&b, ' ');
            }
            if (opt & OUTPUT_SHOW_NUMBER != 0) {
                util.bufByte(&b, ' ');
                padLeft(&b, util.fmt("{d}", .{ent.s_lno + 1 + cnt}), max_orig_digits);
            }
            if (opt & OUTPUT_NO_AUTHOR == 0) {
                const name = if (opt & OUTPUT_SHOW_EMAIL != 0) ci.author_mail else ci.author;
                const pad = longest_author - pretty.utf8Strwidth(name);
                util.bufAppend(&b, " (");
                util.bufAppend(&b, name);
                var k: i64 = 0;
                while (k < pad) : (k += 1) util.bufByte(&b, ' ');
                util.bufByte(&b, ' ');
                padLeft(&b, formatTime(ci.author_time, ci.author_tz, show_raw), 10);
            }
            util.bufByte(&b, ' ');
            padLeft(&b, util.fmt("{d}", .{ent.lno + 1 + cnt}), max_digits);
            util.bufAppend(&b, ") ");
        }
        if (reset) |rr| util.bufAppend(&b, rr);
        cp = copyLine(&b, buf, cp);
    }
    if (buf.len > 0 and cp > 0 and buf[cp - 1] != '\n') util.bufByte(&b, '\n');
    util.out(b.items);
}

fn padLeft(b: *Buf, s: []const u8, width: usize) void {
    var k = s.len;
    while (k < width) : (k += 1) util.bufByte(b, ' ');
    util.bufAppend(b, s);
}

fn output(option: u32) void {
    if (option & OUTPUT_PORCELAIN != 0) {
        var ent = sb_ent;
        while (ent) |e| : (ent = e.next) {
            const commit = e.suspect.?.commit;
            if (commit.obj.flags & MORE_THAN_ONE_PATH != 0) continue;
            var count: usize = 0;
            var s = getSuspects(commit);
            while (s) |x| : (s = x.next) {
                if (x.guilty) {
                    count += 1;
                    if (count > 1) {
                        commit.obj.flags |= MORE_THAN_ONE_PATH;
                        break;
                    }
                }
            }
        }
    }
    var prev: ?*Entry = null;
    var ent = sb_ent;
    while (ent) |e| : (ent = e.next) {
        if (option & OUTPUT_PORCELAIN != 0) {
            emitPorcelain(e, option);
        } else {
            emitOther(e, option, prev);
            prev = e;
        }
    }
}

fn decimalWidth(n0: i64) usize {
    var n = n0;
    var w: usize = 1;
    while (n >= 10) : (n = @divTrunc(n, 10)) w += 1;
    return w;
}

fn entryScore(e: *Entry) u32 {
    if (e.score != 0) return e.score;
    var score: u32 = 1;
    const a = nthLine(e.lno);
    const z = nthLine(e.lno + e.num_lines);
    for (sb_final_buf[a..z]) |ch| {
        if (std.ascii.isAlphanumeric(ch)) score += 1;
    }
    e.score = score;
    return score;
}

fn findAlignment(option: *u32) void {
    var longest_src_lines: i64 = 0;
    var longest_dst_lines: i64 = 0;
    var largest_score: u32 = 0;
    const compute_auto_abbrev = abbrev < 0;
    var auto_abbrev: usize = revparse.defaultAbbrev();
    var max_marks_count: usize = 0;
    var ent = sb_ent;
    while (ent) |e| : (ent = e.next) {
        const suspect = e.suspect.?;
        const marks = printMarks(null, e, option.*);
        if (max_marks_count < marks) max_marks_count = marks;
        if (compute_auto_abbrev) {
            const u = revparse.abbrev(suspect.commit.obj.oid, auto_abbrev).len;
            if (auto_abbrev < u) auto_abbrev = u;
        }
        if (!util.eql(suspect.path, sb_path)) option.* |= OUTPUT_SHOW_NAME;
        if (longest_file < suspect.path.len) longest_file = suspect.path.len;
        if (suspect.commit.obj.flags & METAINFO_SHOWN == 0) {
            suspect.commit.obj.flags |= METAINFO_SHOWN;
            const ci = getCommitInfo(suspect.commit);
            const num = if (option.* & OUTPUT_SHOW_EMAIL != 0) pretty.utf8Strwidth(ci.author_mail) else pretty.utf8Strwidth(ci.author);
            if (longest_author < num) longest_author = num;
        }
        const ns = e.s_lno + e.num_lines;
        if (longest_src_lines < ns) longest_src_lines = ns;
        const nd = e.lno + e.num_lines;
        if (longest_dst_lines < nd) longest_dst_lines = nd;
        const sc = entryScore(e);
        if (largest_score < sc) largest_score = sc;
    }
    max_orig_digits = decimalWidth(longest_src_lines);
    max_digits = decimalWidth(longest_dst_lines);
    max_score_digits = decimalWidth(largest_score);
    if (compute_auto_abbrev) abbrev = @intCast(auto_abbrev);
    if (abbrev < 40) {
        abbrev += @intCast(max_marks_count);
        if (abbrev > 40) abbrev = 40;
    }
}

// ---------------------------------------------------------------------------
// options

var xdl_minimal = false;
var algo: xdiff.Algorithm = .myers;
var opt_pickaxe: i32 = 0;

fn cbDiffAlgorithm(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse return;
    if (parseAlgorithm(a)) |al| {
        algo = al;
    } else {
        util.err("option diff-algorithm accepts \"myers\", \"minimal\", \"patience\" and \"histogram\"", .{});
        os.exit(129);
    }
}

fn parseAlgorithm(a: []const u8) ?xdiff.Algorithm {
    if (std.ascii.eqlIgnoreCase(a, "myers") or std.ascii.eqlIgnoreCase(a, "default")) return .myers;
    if (std.ascii.eqlIgnoreCase(a, "minimal")) return .minimal;
    if (std.ascii.eqlIgnoreCase(a, "patience")) return .patience;
    if (std.ascii.eqlIgnoreCase(a, "histogram")) return .histogram;
    return null;
}

fn cbMinimal(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    algo = if (unset) .myers else .minimal;
}

fn cbCopy(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    opt_pickaxe |= 1;
}

fn cbMove(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    opt_pickaxe |= 2;
}

fn cbAbbrev(arg: ?[]const u8, unset: bool) void {
    if (arg) |a| {
        if (a.len == 0) {
            util.err("option `abbrev' expects a numerical value", .{});
            os.exit(129);
        }
        var v = std.fmt.parseInt(i32, a, 10) catch {
            util.err("option `abbrev' expects a numerical value", .{});
            os.exit(129);
        };
        if (v != 0 and v < 4) v = 4 else if (v > 40) v = 40;
        abbrev = v;
    } else {
        abbrev = if (unset) 0 else -1;
    }
}

fn parseColorFields(s: []const u8) void {
    colorfield = .empty;
    var expect_color = true;
    var cur: ColorField = .{ .hop = 0, .col = "" };
    var it = std.mem.splitScalar(u8, s, ',');
    while (it.next()) |item| {
        if (expect_color) {
            cur.col = color.parseColor(item) orelse util.die("expecting a color: {s}", .{item});
            expect_color = false;
        } else {
            cur.hop = date.approxidate(item);
            colorfield.append(gpa, cur) catch util.oom();
            expect_color = true;
        }
    }
    if (expect_color) util.die("must end with a color", .{});
    cur.hop = std.math.maxInt(i64);
    colorfield.append(gpa, cur) catch util.oom();
}

const blame_usage_str = "git blame [<options>] [<rev-opts>] [<rev>] [--] <file>";
const annotate_usage_str = "git annotate [<options>] [<rev-opts>] [<rev>] [--] <file>";

fn isARev(name: []const u8) bool {
    const r = revparse.resolve(name, .{ .quiet = true }) orelse return false;
    return cn.objType(r.oid) != null;
}

pub fn cmdAnnotate(args: []const []const u8) u8 {
    // cmd_annotate() runs blame with "-c" prepended, so a lone helper
    // argument reaches diff_opt_parse() via parse_revision_opt().
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").diff_options);
    return cmdBlame(args);
}

pub fn cmdBlame(args: []const []const u8) u8 {
    const cmd_is_annotate = util.eql(args[0], "annotate");
    const usage: []const []const u8 = if (cmd_is_annotate)
        &.{ annotate_usage_str, "", "<rev-opts> are documented in git-rev-list(1)" }
    else
        &.{ blame_usage_str, "", "<rev-opts> are documented in git-rev-list(1)" };
    const str_usage = if (cmd_is_annotate) annotate_usage_str else blame_usage_str;
    const r = repo_mod.repo();
    const cfg = &repo_mod.cfg;

    var output_option: i32 = 0;
    var show_root = false;
    var coloring_mode: u32 = 0;
    var ignore_ws = false;
    var indent_heuristic = true;

    // config
    parseColorFields("blue,12 month ago,white,1 month ago,red");
    if (cfg.getBool("blame.showroot")) |v| show_root = v;
    if (cfg.getBool("blame.blankboundary")) |v| blank_boundary = v;
    if (cfg.getBool("blame.showemail")) |v| {
        if (v) output_option |= @intCast(OUTPUT_SHOW_EMAIL) else output_option &= ~@as(i32, @intCast(OUTPUT_SHOW_EMAIL));
    }
    if (cfg.get("blame.date")) |v| {
        if (date.parseDateFormat(v)) |m| blame_date_mode = m;
    }
    if (cfg.getBool("blame.markunblamablelines")) |v| mark_unblamable_lines = v;
    if (cfg.getBool("blame.markignoredlines")) |v| mark_ignored_lines = v;
    if (cfg.get("color.blame.repeatedlines")) |v| {
        if (color.parseColor(v)) |c| repeated_meta_color = c else util.warn("invalid value for '{s}': '{s}'", .{ "color.blame.repeatedLines", v });
    }
    if (cfg.get("color.blame.highlightrecent")) |v| parseColorFields(v);
    for (cfg.getAll("blame.coloring")) |v| {
        if (util.eql(v, "repeatedLines")) {
            coloring_mode |= OUTPUT_COLOR_LINE;
        } else if (util.eql(v, "highlightRecent")) {
            coloring_mode |= OUTPUT_SHOW_AGE_WITH_COLOR;
        } else if (util.eql(v, "none")) {
            coloring_mode &= ~(OUTPUT_COLOR_LINE | OUTPUT_SHOW_AGE_WITH_COLOR);
        } else util.warn("invalid value for '{s}': '{s}'", .{ "blame.coloring", v });
    }
    if (cfg.get("diff.algorithm")) |v| {
        if (parseAlgorithm(v)) |a| algo = a else util.die("unknown value for config 'diff.algorithm': {s}", .{v});
    }
    if (cfg.getBool("diff.indentheuristic")) |v| indent_heuristic = v;

    var revs = revision.RevInfo.init(r.prefix);
    revs.date_mode = blame_date_mode;
    sb_revs = &revs;

    var incremental_b = false;
    var show_stats = false;
    var show_progress = false;
    var range_list: std.ArrayList([]const u8) = .empty;
    var ignore_rev_list: std.ArrayList([]const u8) = .empty;
    var ignore_revs_file_list: std.ArrayList([]const u8) = .empty;
    var revs_file: ?[]const u8 = null;
    var contents_from: ?[]const u8 = null;
    var blank_b = blank_boundary;
    var ws_i: i32 = 0;

    const options = [_]po.Opt{
        po.boolean(0, "incremental", &incremental_b, "show blame entries as we find them, incrementally"),
        po.boolean('b', "", &blank_b, "do not show object names of boundary commits (Default: off)"),
        po.boolean(0, "root", &show_root, "do not treat root commits as boundaries (Default: off)"),
        po.boolean(0, "show-stats", &show_stats, "show work cost statistics"),
        po.boolean(0, "progress", &show_progress, "force progress reporting"),
        po.bit(0, "score-debug", &output_option, OUTPUT_SHOW_SCORE, "show output score for blame entries"),
        po.bit('f', "show-name", &output_option, OUTPUT_SHOW_NAME, "show original filename (Default: auto)"),
        po.bit('n', "show-number", &output_option, OUTPUT_SHOW_NUMBER, "show original linenumber (Default: off)"),
        po.bit('p', "porcelain", &output_option, OUTPUT_PORCELAIN, "show in a format designed for machine consumption"),
        po.bit(0, "line-porcelain", &output_option, OUTPUT_PORCELAIN | OUTPUT_LINE_PORCELAIN, "show porcelain format with per-line commit information"),
        po.bit('c', "", &output_option, OUTPUT_ANNOTATE_COMPAT, "use the same output mode as git-annotate (Default: off)"),
        po.bit('t', "", &output_option, OUTPUT_RAW_TIMESTAMP, "show raw timestamp (Default: off)"),
        po.bit('l', "", &output_option, OUTPUT_LONG_OBJECT_NAME, "show long commit SHA1 (Default: off)"),
        po.bit('s', "", &output_option, OUTPUT_NO_AUTHOR, "suppress author name and timestamp (Default: off)"),
        po.bit('e', "show-email", &output_option, OUTPUT_SHOW_EMAIL, "show author email instead of name (Default: off)"),
        po.bit('w', "", &ws_i, 1, "ignore whitespace differences"),
        .{ .long = "diff-algorithm", .kind = .callback, .cb = cbDiffAlgorithm, .argh = "algorithm", .noneg = true, .help = "choose a diff algorithm" },
        po.list(0, "ignore-rev", &ignore_rev_list, "rev", "ignore <rev> when blaming"),
        po.list(0, "ignore-revs-file", &ignore_revs_file_list, "file", "ignore revisions from <file>"),
        po.bit(0, "color-lines", &output_option, OUTPUT_COLOR_LINE, "color redundant metadata from previous line differently"),
        po.bit(0, "color-by-age", &output_option, OUTPUT_SHOW_AGE_WITH_COLOR, "color lines by age"),
        .{ .long = "minimal", .kind = .callback, .cb = cbMinimal, .noarg = true, .hidden = true, .help = "spend extra cycles to find a better match" },
        po.string('S', "", &revs_file, "file", "use revisions from <file> instead of calling git-rev-list"),
        po.string(0, "contents", &contents_from, "file", "use <file>'s contents as the final image"),
        .{ .short = 'C', .kind = .callback, .cb = cbCopy, .optarg = true, .noneg = true, .argh = "score", .help = "find line copies within and across files" },
        .{ .short = 'M', .kind = .callback, .cb = cbMove, .optarg = true, .noneg = true, .argh = "score", .help = "find line movements within and across files" },
        po.list('L', "", &range_list, "range", "process only line range <start>,<end> or function :<funcname>"),
        .{ .long = "abbrev", .kind = .callback, .cb = cbAbbrev, .optarg = true, .argh = "n", .help = "use <n> digits to display object names" },
    };

    const rest = po.parse(args[1..], &options, usage, .{ .keep_unknown = true, .keep_dashdash = true });
    blank_boundary = blank_b;
    incremental = incremental_b;
    ignore_ws = ws_i != 0;

    // walk the remaining arguments: revision options are consumed here,
    // pseudo-options and non-options kept.
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, args[0]) catch util.oom();
    var reverse = false;
    var dashdash_pos: usize = 0;
    {
        var i: usize = 0;
        while (i < rest.len) {
            var a = rest[i];
            if (util.eql(a, "--")) {
                dashdash_pos = argv.items.len;
                argv.appendSlice(gpa, rest[i..]) catch util.oom();
                break;
            }
            if (a.len < 2 or a[0] != '-') {
                argv.append(gpa, a) catch util.oom();
                i += 1;
                continue;
            }
            var sub: std.ArrayList([]const u8) = .empty;
            sub.appendSlice(gpa, rest[i..]) catch util.oom();
            if (util.eql(a, "--reverse")) {
                a = "--children";
                sub.items[0] = a;
                reverse = true;
            }
            var unk: std.ArrayList([]const u8) = .empty;
            const n = revision.handleRevisionOptUnk(&revs, sub.items, &unk);
            if (n < 0) os.exit(128);
            if (n == 0) {
                util.err("unknown option `{s}'", .{if (util.startsWith(a, "--")) a[2..] else a});
                po.usageWithOptions(usage, &options);
            }
            argv.appendSlice(gpa, unk.items) catch util.oom();
            i += @intCast(n);
        }
    }
    revision.revisionOptsFinish(&revs);
    const no_whole_file_rename = false;

    if (incremental or output_option & @as(i32, @intCast(OUTPUT_PORCELAIN)) != 0) {
        if (show_progress) util.die("--progress can't be used with --incremental or porcelain formats", .{});
    }
    if (abbrev == 0) abbrev = 40;
    if (revs_file != null) {}

    if (cmd_is_annotate) {
        output_option |= @intCast(OUTPUT_ANNOTATE_COMPAT);
        blame_date_mode = date.DateMode.of(.iso8601);
    } else {
        blame_date_mode = revs.date_mode;
    }
    blame_date_width = switch (blame_date_mode.mode) {
        .rfc2822 => "Thu, 19 Oct 2006 16:00:04 -0700".len,
        .iso8601_strict => "2006-10-19T16:00:04-07:00".len,
        .iso8601 => "2006-10-19 16:00:04 -0700".len,
        .raw => "1161298804 -0700".len,
        .unix => "1161298804".len,
        .short => "2006-10-19".len,
        .relative => "4 years, 11 months ago".len,
        .human => "Thu Oct 19 16:00".len,
        .normal => "Thu Oct 19 16:00:04 2006 -0700".len,
        .strftime => date.showDate(0, 0, blame_date_mode).len,
    };

    // path / revision disambiguation
    var path: []const u8 = undefined;
    var argc = argv.items.len;
    const add_prefix = struct {
        fn f(p: []const u8) []const u8 {
            return repo_mod.prefixPath(p) orelse
                util.die("'{s}' is outside repository at '{s}'", .{ p, repo_mod.repo().work_tree orelse "" });
        }
    }.f;
    if (dashdash_pos != 0) {
        switch (argc - dashdash_pos - 1) {
            2 => {
                if (argc != 4) po.usageWithOptions(usage, &options);
                const a3 = argv.items[3];
                argv.items[3] = argv.items[2];
                argv.items[2] = "--";
                argv.items[1] = a3;
                argc -= 1;
                path = add_prefix(argv.items[argc]);
                argv.items.len = argc;
            },
            1 => {
                argc -= 1;
                path = add_prefix(argv.items[argc]);
                argv.items.len = argc;
            },
            else => po.usageWithOptions(usage, &options),
        }
    } else {
        if (argc < 2) po.usageWithOptions(usage, &options);
        if (argc == 3 and isARev(argv.items[argc - 1])) {
            path = add_prefix(argv.items[1]);
            argv.items[1] = argv.items[2];
        } else {
            if (argc == 2 and isARev(argv.items[1]) and r.work_tree == null)
                util.die("missing <path> to blame", .{});
            path = add_prefix(argv.items[argc - 1]);
        }
        argv.items[argc - 1] = "--";
    }

    revs.disable_stdin = true;
    _ = revision.setupRevisions(&revs, argv.items, .{});
    if (revs.pending.items.len == 0 and r.bare) {
        const head = refs.readOid("HEAD") orelse util.die("no such ref: HEAD", .{});
        const hc = cn.lookupCommitReference(head) orelse util.die("no such ref: HEAD", .{});
        revs.addPendingObject(&hc.obj, "HEAD");
    }

    sb_reverse = reverse;
    sb_path = path;
    if (ignore_rev_list.items.len > 0 or ignore_revs_file_list.items.len > 0) {
        for (ignore_rev_list.items) |rv| {
            const o = revparse.getOidCommittish(rv) orelse util.die("cannot find revision {s} to ignore", .{rv});
            _ = o;
        }
    }

    // setup_scoreboard
    if (reverse and contents_from != null) util.die("--contents and --reverse do not blend well.", .{});
    var final_commit_name: ?[]const u8 = null;
    var final: ?*Commit = null;
    if (!reverse) {
        final = findSingleFinal(&final_commit_name);
        sb_commits.compare = cn.compareByCommitDate;
    } else {
        final = findSingleInitial(&final_commit_name);
        sb_commits.compare = compareReverseCommitDate;
    }
    const fp_reverse = reverse and revs.first_parent_only;
    if (fp_reverse) revs.children_enabled = false;

    if (contents_from != null or final == null) {
        var parent_oid: Oid = undefined;
        if (final) |f| {
            parent_oid = f.obj.oid;
        } else {
            parent_oid = refs.readOid("HEAD") orelse util.die("no such ref: HEAD", .{});
        }
        if (contents_from == null) _ = repo_mod.requireWorkTree("blame");
        final = fakeWorkingTreeCommit(path, contents_from, parent_oid);
        revs.addPendingObject(&final.?.obj, ":");
    }
    var fp_final: ?*Commit = null;
    if (fp_reverse) {
        fp_final = findSingleFinal(null) orelse
            util.die("--reverse and --first-parent together require specified latest commit", .{});
    }
    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    if (fp_reverse) {
        revs.children = cn.Slab(?*cn.CommitList).init(null);
        revs.children_enabled = true;
        var c = fp_final.?;
        while (true) {
            _ = cn.parse(c);
            const pl = c.parents orelse break;
            if (hash.eql(c.obj.oid, final.?.obj.oid)) break;
            revs.children.at(pl.item).* = cn.newNode(c, null);
            c = pl.item;
        }
        if (!hash.eql(c.obj.oid, final.?.obj.oid))
            util.die("--reverse --first-parent together require range along first-parent chain", .{});
    }

    const fc = final.?;
    var o: *Origin = undefined;
    if (hash.isZero(fc.obj.oid)) {
        o = getSuspects(fc).?;
        sb_final_buf = o.file.?;
    } else {
        o = getOrigin(fc, path);
        if (!fillBlobOidAndMode(o)) util.die("no such path {s} in {s}", .{ path, final_commit_name orelse "" });
        const obj = r.odb().read(o.blob_oid) orelse
            util.die("cannot read blob {s} for path {s}", .{ hash.hex(o.blob_oid), path });
        sb_final_buf = obj.data;
        o.file = obj.data;
    }
    sb_num_read_blob += 1;
    sb_lineno = linerange.findLineStarts(sb_final_buf);
    const lno: i64 = @as(i64, @intCast(sb_lineno.len)) - 1;
    sb_num_lines = @intCast(lno);

    if (lno != 0 and range_list.items.len == 0) range_list.append(gpa, "1") catch util.oom();
    var anchor: i64 = 1;
    var ranges: std.ArrayList(linerange.RangeSpan) = .empty;
    const lines = linerange.Lines{ .buf = sb_final_buf, .starts = sb_lineno };
    for (range_list.items) |spec| {
        const rg = linerange.parseRangeArg(spec, lines, anchor, path) orelse {
            util.eprint("usage: {s}\n", .{str_usage});
            os.exit(129);
        };
        var bottom = rg.begin;
        var top = rg.end;
        if ((lno == 0 and (top != 0 or bottom != 0)) or lno < bottom)
            util.die("file {s} has only {d} line{s}", .{ path, lno, if (lno == 1) "" else "s" });
        if (bottom < 1) bottom = 1;
        if (top < 1 or lno < top) top = lno;
        bottom -= 1;
        ranges.append(gpa, .{ .start = bottom, .end = top }) catch util.oom();
        anchor = top + 1;
    }
    linerange.sortAndMerge(&ranges);
    var ent: ?*Entry = null;
    var ri = ranges.items.len;
    while (ri > 0) {
        ri -= 1;
        const rr = ranges.items[ri];
        const e = gpa.create(Entry) catch util.oom();
        e.* = .{ .lno = @intCast(rr.start), .num_lines = @intCast(rr.end - rr.start), .suspect = o, .s_lno = @intCast(rr.start), .next = ent };
        _ = incref(o);
        ent = e;
    }
    o.suspects = ent;
    sb_commits.put(o.commit);
    decref(o);
    sb_ent = null;

    sb_show_root = show_root;
    sb_no_whole_file_rename = no_whole_file_rename;
    sb_xflags = .{ .algorithm = algo, .ignore_ws = ignore_ws, .indent_heuristic = indent_heuristic };
    the_mailmap = mailmap.readMailmap();

    assignBlame();

    if (incremental) {
        util.flushStdout();
        return 0;
    }
    if (@import("../main.zig").use_pager orelse (cfg.getBool("pager.blame") orelse true))
        @import("../commands.zig").setupPager();

    sortEntries(&sb_ent, lessFinal);
    blameCoalesce();

    var oopt: u32 = @intCast(output_option);
    if (oopt & (OUTPUT_COLOR_LINE | OUTPUT_SHOW_AGE_WITH_COLOR) == 0) oopt |= coloring_mode;
    if (oopt & OUTPUT_PORCELAIN == 0) {
        findAlignment(&oopt);
        if (repeated_meta_color.len == 0 and oopt & OUTPUT_COLOR_LINE != 0) repeated_meta_color = color.CYAN;
    }
    if (oopt & OUTPUT_ANNOTATE_COMPAT != 0) oopt &= ~(OUTPUT_COLOR_LINE | OUTPUT_SHOW_AGE_WITH_COLOR);
    output(oopt);
    if (show_stats) {
        util.outf("num read blob: {d}\n", .{sb_num_read_blob});
        util.outf("num get patch: {d}\n", .{sb_num_get_patch});
        util.outf("num commits: {d}\n", .{sb_num_commits});
    }
    return 0;
}
