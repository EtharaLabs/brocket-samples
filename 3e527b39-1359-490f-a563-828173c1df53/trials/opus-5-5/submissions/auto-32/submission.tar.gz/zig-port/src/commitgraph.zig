//! commit-graph files: loading (commit-graph.c parse_commit_graph and chain
//! loading), writing (write_commit_graph and split chains), verification and
//! changed-path Bloom filters (bloom.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const objects = @import("objects.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const progress = @import("progress.zig");
const lockfile = @import("lockfile.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const GRAPH_SIGNATURE: u32 = 0x43475048;
const CH_OIDFANOUT: u32 = 0x4f494446;
const CH_OIDLOOKUP: u32 = 0x4f49444c;
const CH_DATA: u32 = 0x43444154;
const CH_GENDATA: u32 = 0x47444132;
const CH_GENOVERFLOW: u32 = 0x47444f32;
const CH_EXTRAEDGES: u32 = 0x45444745;
const CH_BLOOMINDEXES: u32 = 0x42494458;
const CH_BLOOMDATA: u32 = 0x42444154;
const CH_BASE: u32 = 0x42415345;

const GRAPH_EXTRA_EDGES_NEEDED: u32 = 0x80000000;
const GRAPH_EDGE_LAST_MASK: u32 = 0x7fffffff;
const GRAPH_PARENT_NONE: u32 = 0x70000000;
const GRAPH_LAST_EDGE: u32 = 0x80000000;
const HEADER_SIZE = 8;
const FANOUT_SIZE = 1024;
const TOC_ENTRY = 12;
const RAWSZ = 20;
const DATA_WIDTH = RAWSZ + 16;
const OFFSET_OVERFLOW: u64 = 1 << 31;
const V1_MAX: u64 = 0x3FFFFFFF;
const V2_OFFSET_MAX: u64 = (1 << 31) - 1;
pub const GEN_INFINITY: u64 = (1 << 63) - 1;
const BLOOM_HEADER = 12;
const DEFAULT_MAX_CHANGES = 512;

fn be32(b: []const u8, off: usize) u32 {
    return std.mem.readInt(u32, b[off..][0..4], .big);
}
fn be64(b: []const u8, off: usize) u64 {
    return std.mem.readInt(u64, b[off..][0..8], .big);
}

pub const BloomSettings = struct {
    hash_version: u32 = 1,
    num_hashes: u32 = 7,
    bits_per_entry: u32 = 10,
    max_changed_paths: u32 = DEFAULT_MAX_CHANGES,
};

pub const Graph = struct {
    data: []const u8,
    filename: []const u8 = "",
    source: []const u8 = "",
    oid: Oid = hash.zero,
    num_chunks: u8 = 0,
    num_commits: u32 = 0,
    num_in_base: u32 = 0,
    fanout: []const u8 = "",
    oid_lookup: []const u8 = "",
    commit_data: []const u8 = "",
    gen_data: ?[]const u8 = null,
    gen_overflow: ?[]const u8 = null,
    extra_edges: ?[]const u8 = null,
    base_graphs: ?[]const u8 = null,
    bloom_idx: ?[]const u8 = null,
    bloom_data: ?[]const u8 = null,
    bloom_settings: ?BloomSettings = null,
    read_generation_data: bool = false,
    base: ?*Graph = null,

    pub fn lexOid(self: *const Graph, i: u32) Oid {
        return self.oid_lookup[@as(usize, i) * RAWSZ ..][0..RAWSZ].*;
    }

    fn bsearch(self: *const Graph, oid: Oid) ?u32 {
        var lo: u32 = if (oid[0] == 0) 0 else be32(self.fanout, (@as(usize, oid[0]) - 1) * 4);
        var hi: u32 = be32(self.fanout, @as(usize, oid[0]) * 4);
        if (hi > self.num_commits) hi = self.num_commits;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            switch (hash.order(oid, self.lexOid(mid))) {
                .eq => return mid,
                .lt => hi = mid,
                .gt => lo = mid + 1,
            }
        }
        return null;
    }
};

// ---------------------------------------------------------------- settings

pub fn generationVersion() i64 {
    return repo_mod.cfg.getInt("commitgraph.generationversion") orelse 2;
}

pub fn changedPathsVersion() i64 {
    const rcp = repo_mod.cfg.getBool("commitgraph.readchangedpaths") orelse true;
    return repo_mod.cfg.getInt("commitgraph.changedpathsversion") orelse (if (rcp) -1 else 0);
}

fn envBool(name: []const u8, def: bool) bool {
    const v = os.getenv(name) orelse return def;
    const config = @import("config.zig");
    return config.configBool(name, v);
}

pub fn graphFilename(dir: []const u8) []u8 {
    return util.concat(&.{ dir, "/info/commit-graph" });
}
pub fn chainFilename(dir: []const u8) []u8 {
    return util.concat(&.{ dir, "/info/commit-graphs/commit-graph-chain" });
}
fn splitFilename(dir: []const u8, hex: []const u8) []u8 {
    return util.concat(&.{ dir, "/info/commit-graphs/graph-", hex, ".graph" });
}

// ---------------------------------------------------------------- loading

pub const Chunk = struct { id: u32, start: usize, size: usize };

pub fn readToc(data: []const u8, toc_off: usize, n: usize, out: *std.ArrayList(Chunk)) bool {
    return readTocAligned(data, toc_off, n, 1, out);
}

pub fn readTocAligned(data: []const u8, toc_off: usize, n: usize, alignment: u64, out: *std.ArrayList(Chunk)) bool {
    var p = toc_off;
    var k: usize = 0;
    while (k < n) : (k += 1) {
        if (p + 2 * TOC_ENTRY > data.len) {
            util.err("improper chunk offset(s) {x} and {x}", .{ p, data.len });
            return false;
        }
        const id = be32(data, p);
        const off = be64(data, p + 4);
        if (id == 0) {
            util.err("terminating chunk id appears earlier than expected", .{});
            return false;
        }
        if (off % alignment != 0) {
            util.err("chunk id {x} not {d}-byte aligned", .{ id, alignment });
            return false;
        }
        p += TOC_ENTRY;
        const next = be64(data, p + 4);
        if (next < off or next > data.len - RAWSZ) {
            util.err("improper chunk offset(s) {x} and {x}", .{ off, next });
            return false;
        }
        for (out.items) |c| {
            if (c.id == id) {
                util.err("duplicate chunk ID {x} found", .{id});
                return false;
            }
        }
        out.append(gpa, .{ .id = id, .start = @intCast(off), .size = @intCast(next - off) }) catch util.oom();
    }
    const last = be32(data, p);
    if (last != 0) {
        util.err("final chunk has non-zero id {x}", .{last});
        return false;
    }
    return true;
}

pub fn findChunk(chunks: []const Chunk, id: u32) ?Chunk {
    for (chunks) |c| if (c.id == id) return c;
    return null;
}

const min_size = HEADER_SIZE + 4 * TOC_ENTRY + FANOUT_SIZE + RAWSZ;

/// parse_commit_graph(): returns null (after printing an error) on failure.
pub fn parseGraph(data: []const u8) ?*Graph {
    if (data.len < min_size) return null;
    const sig = be32(data, 0);
    if (sig != GRAPH_SIGNATURE) {
        util.err("commit-graph signature {X} does not match signature {X}", .{ sig, GRAPH_SIGNATURE });
        return null;
    }
    if (data[4] != 1) {
        util.err("commit-graph version {X} does not match version {X}", .{ data[4], 1 });
        return null;
    }
    if (data[5] != 1) {
        util.err("commit-graph hash version {X} does not match version {X}", .{ data[5], 1 });
        return null;
    }
    const g = gpa.create(Graph) catch util.oom();
    g.* = .{ .data = data, .num_chunks = data[6] };
    if (data.len < HEADER_SIZE + (@as(usize, g.num_chunks) + 1) * TOC_ENTRY + FANOUT_SIZE + RAWSZ) {
        util.err("commit-graph file is too small to hold {d} chunks", .{g.num_chunks});
        return null;
    }
    var chunks: std.ArrayList(Chunk) = .empty;
    if (!readToc(data, HEADER_SIZE, g.num_chunks, &chunks)) return null;

    // OID fanout
    fanout: {
        if (findChunk(chunks.items, CH_OIDFANOUT)) |c| {
            if (c.size != FANOUT_SIZE) {
                util.err("commit-graph oid fanout chunk is wrong size", .{});
            } else {
                g.fanout = data[c.start..][0..FANOUT_SIZE];
                g.num_commits = be32(g.fanout, 255 * 4);
                var i: usize = 0;
                var ok = true;
                while (i < 255) : (i += 1) {
                    if (be32(g.fanout, i * 4) > be32(g.fanout, i * 4 + 4)) {
                        util.err("commit-graph fanout values out of order", .{});
                        ok = false;
                        break;
                    }
                }
                if (ok) break :fanout;
            }
        }
        util.err("commit-graph required OID fanout chunk missing or corrupted", .{});
        return null;
    }
    lookup: {
        if (findChunk(chunks.items, CH_OIDLOOKUP)) |c| {
            g.oid_lookup = data[c.start..][0..c.size];
            if (c.size / RAWSZ == g.num_commits) break :lookup;
            util.err("commit-graph OID lookup chunk is the wrong size", .{});
        }
        util.err("commit-graph required OID lookup chunk missing or corrupted", .{});
        return null;
    }
    cdat: {
        if (findChunk(chunks.items, CH_DATA)) |c| {
            if (c.size / DATA_WIDTH == g.num_commits) {
                g.commit_data = data[c.start..][0..c.size];
                break :cdat;
            }
            util.err("commit-graph commit data chunk is wrong size", .{});
        }
        util.err("commit-graph required commit data chunk missing or corrupted", .{});
        return null;
    }
    if (findChunk(chunks.items, CH_EXTRAEDGES)) |c| g.extra_edges = data[c.start..][0..c.size];
    if (findChunk(chunks.items, CH_BASE)) |c| g.base_graphs = data[c.start..][0..c.size];

    if (generationVersion() >= 2) {
        if (findChunk(chunks.items, CH_GENDATA)) |c| {
            if (c.size / 4 != g.num_commits) {
                util.err("commit-graph generations chunk is wrong size", .{});
            } else g.gen_data = data[c.start..][0..c.size];
        }
        if (findChunk(chunks.items, CH_GENOVERFLOW)) |c| g.gen_overflow = data[c.start..][0..c.size];
        if (g.gen_data != null) g.read_generation_data = true;
    }
    if (changedPathsVersion() != 0) {
        if (findChunk(chunks.items, CH_BLOOMINDEXES)) |c| {
            if (c.size / 4 != g.num_commits) {
                util.warn("commit-graph changed-path index chunk is too small", .{});
            } else g.bloom_idx = data[c.start..][0..c.size];
        }
        if (findChunk(chunks.items, CH_BLOOMDATA)) |c| {
            if (c.size < BLOOM_HEADER) {
                util.warn("ignoring too-small changed-path chunk ({d} < {d}) in commit-graph file", .{ c.size, BLOOM_HEADER });
            } else {
                const d = data[c.start..][0..c.size];
                g.bloom_data = d;
                g.bloom_settings = .{ .hash_version = be32(d, 0), .num_hashes = be32(d, 4), .bits_per_entry = be32(d, 8) };
            }
        }
    }
    if (g.bloom_idx == null or g.bloom_data == null) {
        g.bloom_idx = null;
        g.bloom_data = null;
        g.bloom_settings = null;
    }
    g.oid = data[data.len - RAWSZ ..][0..RAWSZ].*;
    return g;
}

/// load_commit_graph_one(): null when missing or invalid.
pub fn loadOne(path: []const u8, source: []const u8) ?*Graph {
    const data = os.readFile(path) orelse return null;
    if (data.len < min_size) {
        util.err("commit-graph file is too small", .{});
        return null;
    }
    const g = parseGraph(data) orelse return null;
    g.filename = path;
    g.source = source;
    return g;
}

fn addGraphToChain(g: *Graph, chain: ?*Graph, oids: []const Oid, n0: usize) bool {
    var n = n0;
    if (n > 0 and g.base_graphs == null) {
        util.warn("commit-graph has no base graphs chunk", .{});
        return false;
    }
    const bsz = if (g.base_graphs) |b| b.len else 0;
    if (bsz / RAWSZ < n) {
        util.warn("commit-graph base graphs chunk is too small", .{});
        return false;
    }
    var cur = chain;
    while (n > 0) {
        n -= 1;
        const c = cur orelse {
            util.warn("commit-graph chain does not match", .{});
            return false;
        };
        if (!hash.eql(oids[n], c.oid) or !std.mem.eql(u8, &oids[n], g.base_graphs.?[n * RAWSZ ..][0..RAWSZ])) {
            util.warn("commit-graph chain does not match", .{});
            return false;
        }
        cur = c.base;
    }
    if (chain) |c| g.num_in_base = c.num_commits + c.num_in_base;
    g.base = chain;
    return true;
}

fn validateMixedGeneration(g0: ?*Graph) bool {
    var p = g0;
    while (p) |g| : (p = g.base) {
        if (!g.read_generation_data) {
            var q = g0;
            while (q) |x| : (q = x.base) x.read_generation_data = false;
            return false;
        }
    }
    return true;
}

fn validateMixedBloom(g0: ?*Graph) void {
    var settings: ?BloomSettings = null;
    var p = g0;
    while (p) |g| : (p = g.base) {
        const s = g.bloom_settings orelse continue;
        if (settings) |t| {
            if (s.bits_per_entry != t.bits_per_entry or s.num_hashes != t.num_hashes or s.hash_version != t.hash_version) {
                g.bloom_idx = null;
                g.bloom_data = null;
                g.bloom_settings = null;
                util.warn("disabling Bloom filters for commit-graph layer '{s}' due to incompatible settings", .{hash.hex(g.oid)});
            }
        } else settings = s;
    }
}

pub const ChainResult = struct { g: ?*Graph, incomplete: bool };

/// load_commit_graph_chain_fd_st() on already-read chain file contents.
pub fn loadChainData(data: []const u8, dirs: []const []const u8) ChainResult {
    var chain: ?*Graph = null;
    const count = data.len / (hash.HEXSZ + 1);
    var oids = gpa.alloc(Oid, count) catch util.oom();
    var valid = true;
    var lines = std.mem.splitScalar(u8, data, '\n');
    var i: usize = 0;
    while (i < count) : (i += 1) {
        var line = lines.next() orelse break;
        if (i + 1 == count and lines.peek() == null and line.len == 0) break;
        _ = &line;
        const o = if (line.len >= hash.HEXSZ) hash.fromHex(line[0..hash.HEXSZ]) else null;
        if (o == null) {
            util.warn("invalid commit-graph chain: line '{s}' not a hash", .{line});
            valid = false;
            break;
        }
        oids[i] = o.?;
        valid = false;
        for (dirs) |dir| {
            const name = splitFilename(dir, line);
            if (loadOne(name, dir)) |g| {
                if (addGraphToChain(g, chain, oids, i)) {
                    chain = g;
                    valid = true;
                }
                break;
            }
        }
        if (!valid) {
            util.warn("unable to find all commit-graph files", .{});
            break;
        }
    }
    _ = validateMixedGeneration(chain);
    validateMixedBloom(chain);
    return .{ .g = chain, .incomplete = !valid };
}

fn loadChain(dir: []const u8, dirs: []const []const u8) ?*Graph {
    const data = os.readFile(chainFilename(dir)) orelse return null;
    if (data.len < hash.HEXSZ) {
        if (data.len != 0) util.warn("commit-graph chain file too small", .{});
        return null;
    }
    return loadChainData(data, dirs).g;
}

pub fn readGraphOne(dir: []const u8, dirs: []const []const u8) ?*Graph {
    if (loadOne(graphFilename(dir), dir)) |g| return g;
    return loadChain(dir, dirs);
}

/// commit_graph_compatible()
pub fn compatible() bool {
    const r = repo_mod.repo();
    if (odb_mod.replaceRefsEnabled()) {
        var n: usize = 0;
        for (refs.iterate(odb_mod.replaceRefBase(), .{ .check_objects = false })) |_| n += 1;
        if (n > 0) return false;
    }
    const gpath = os.getenv("GIT_GRAFT_FILE") orelse r.commonPath("info/grafts");
    if (os.readFile(gpath)) |d| {
        var it = std.mem.splitScalar(u8, d, '\n');
        while (it.next()) |line| {
            if (line.len == 0 or line[0] == '#') continue;
            if (hash.fromHex(if (line.len >= 40) line[0..40] else line) != null) return false;
        }
    }
    if (os.readFile(r.commonPath("shallow"))) |d| {
        if (d.len > 0) return false;
    }
    return true;
}

var prepared = false;
var prepared_graph: ?*Graph = null;

/// prepare_commit_graph(): the graph of the first object source that has one.
pub fn prepare() ?*Graph {
    if (prepared) return prepared_graph;
    prepared = true;
    if (!envBool("GIT_TEST_COMMIT_GRAPH", false) and !(repo_mod.cfg.getBool("core.commitgraph") orelse true)) return null;
    if (!compatible()) return null;
    const dirs = repo_mod.repo().odb().allDirs();
    for (dirs) |d| {
        if (readGraphOne(d, dirs)) |g| {
            prepared_graph = g;
            return g;
        }
    }
    return null;
}

pub fn resetPrepared() void {
    prepared = false;
    prepared_graph = null;
}

// ---------------------------------------------------------------- lookups

fn layerOf(g0: *Graph, pos: u32) *Graph {
    var g = g0;
    while (pos < g.num_in_base) g = g.base.?;
    return g;
}

pub fn oidAtPos(g0: *Graph, pos: u32) Oid {
    const g = layerOf(g0, pos);
    if (pos >= g.num_commits + g.num_in_base) util.die("invalid commit position. commit-graph is likely corrupt", .{});
    return g.lexOid(pos - g.num_in_base);
}

pub fn findPos(g0: *Graph, oid: Oid) ?u32 {
    var cur: ?*Graph = g0;
    while (cur) |g| : (cur = g.base) {
        if (g.bsearch(oid)) |lex| return lex + g.num_in_base;
    }
    return null;
}

pub const Info = struct {
    tree: Oid,
    parents: []u32,
    date: u64,
    generation: u64,
    topo: u32,
};

/// fill_commit_graph_info + parent decoding of fill_commit_in_graph.
/// Returns null (after an error) if the extra-edges list is out of bounds;
/// `partial` then still holds date and generation.
pub fn fill(g0: *Graph, pos: u32, partial: ?*Info) ?Info {
    const g = layerOf(g0, pos);
    if (pos >= g.num_commits + g.num_in_base) util.die("invalid commit position. commit-graph is likely corrupt", .{});
    const lex = pos - g.num_in_base;
    const cd = g.commit_data[@as(usize, lex) * DATA_WIDTH ..][0..DATA_WIDTH];
    const w2 = be32(cd, RAWSZ + 8);
    const date: u64 = (@as(u64, w2 & 3) << 32) | be32(cd, RAWSZ + 12);
    var info = Info{ .tree = cd[0..RAWSZ].*, .parents = &.{}, .date = date, .generation = 0, .topo = w2 >> 2 };
    if (g.read_generation_data) {
        const off: u64 = be32(g.gen_data.?, @as(usize, lex) * 4);
        if (off & OFFSET_OVERFLOW != 0) {
            const ov = g.gen_overflow orelse util.die("commit-graph requires overflow generation data but has none", .{});
            const opos = off ^ OFFSET_OVERFLOW;
            if (ov.len / 8 <= opos) util.die("commit-graph overflow generation data is too small", .{});
            info.generation = date +% be64(ov, @intCast(8 * opos));
        } else info.generation = date + off;
    } else info.generation = w2 >> 2;
    if (partial) |p| p.* = info;

    var parents: std.ArrayList(u32) = .empty;
    const total = g.num_commits + g.num_in_base;
    var ev = be32(cd, RAWSZ);
    if (ev == GRAPH_PARENT_NONE) return info;
    if (ev >= total) util.die("invalid parent position {d}", .{ev});
    parents.append(gpa, ev) catch util.oom();
    ev = be32(cd, RAWSZ + 4);
    if (ev != GRAPH_PARENT_NONE) {
        if (ev & GRAPH_EXTRA_EDGES_NEEDED == 0) {
            if (ev >= total) util.die("invalid parent position {d}", .{ev});
            parents.append(gpa, ev) catch util.oom();
        } else {
            var pdp: usize = ev & GRAPH_EDGE_LAST_MASK;
            const ee = g.extra_edges orelse "";
            while (true) {
                if (ee.len / 4 <= pdp) {
                    util.err("commit-graph extra-edges pointer out of bounds", .{});
                    return null;
                }
                ev = be32(ee, pdp * 4);
                const p = ev & GRAPH_EDGE_LAST_MASK;
                if (p >= total) util.die("invalid parent position {d}", .{p});
                parents.append(gpa, p) catch util.oom();
                pdp += 1;
                if (ev & GRAPH_LAST_EDGE != 0) break;
            }
        }
    }
    info.parents = parents.items;
    return info;
}

pub const Filter = struct { data: []const u8, version: u32 };

/// load_bloom_filter_from_graph()
pub fn loadBloom(g0: *Graph, pos: u32) ?Filter {
    const g = layerOf(g0, pos);
    const idx = g.bloom_idx orelse return null;
    const bd = g.bloom_data.?;
    const lex = pos - g.num_in_base;
    const end = be32(idx, @as(usize, lex) * 4);
    const start: u32 = if (lex > 0) be32(idx, (@as(usize, lex) - 1) * 4) else 0;
    const limit = bd.len - BLOOM_HEADER;
    if (end > limit) {
        util.warn("ignoring out-of-range offset ({d}) for changed-path filter at pos {d} of {s} (chunk size: {d})", .{ end, lex, g.filename, bd.len });
        return null;
    }
    if (start > limit) {
        util.warn("ignoring out-of-range offset ({d}) for changed-path filter at pos {d} of {s} (chunk size: {d})", .{ start, lex -% 1, g.filename, bd.len });
        return null;
    }
    if (end < start) {
        util.warn("ignoring decreasing changed-path index offsets ({d} > {d}) for positions {d} and {d} of {s}", .{ start, end, lex -% 1, lex, g.filename });
        return null;
    }
    return .{ .data = bd[BLOOM_HEADER + start .. BLOOM_HEADER + end], .version = g.bloom_settings.?.hash_version };
}

// ---------------------------------------------------------------- bloom

fn rotl(v: u32, c: u5) u32 {
    return std.math.rotl(u32, v, c);
}

fn murmur3(seed0: u32, data: []const u8, v2: bool) u32 {
    const c1: u32 = 0xcc9e2d51;
    const c2: u32 = 0x1b873593;
    var seed = seed0;
    const len4 = data.len / 4;
    var i: usize = 0;
    while (i < len4) : (i += 1) {
        var k: u32 = 0;
        var j: usize = 0;
        while (j < 4) : (j += 1) k |= byteVal(data[4 * i + j], v2) << @intCast(8 * j);
        k *%= c1;
        k = rotl(k, 15);
        k *%= c2;
        seed ^= k;
        seed = rotl(seed, 13) *% 5 +% 0xe6546b64;
    }
    const tail = data[len4 * 4 ..];
    var k1: u32 = 0;
    switch (data.len & 3) {
        3 => {
            k1 ^= byteVal(tail[2], v2) << 16;
            k1 ^= byteVal(tail[1], v2) << 8;
            k1 ^= byteVal(tail[0], v2);
        },
        2 => {
            k1 ^= byteVal(tail[1], v2) << 8;
            k1 ^= byteVal(tail[0], v2);
        },
        1 => k1 ^= byteVal(tail[0], v2),
        else => {},
    }
    if (data.len & 3 != 0) {
        k1 *%= c1;
        k1 = rotl(k1, 15);
        k1 *%= c2;
        seed ^= k1;
    }
    seed ^= @truncate(data.len);
    seed ^= seed >> 16;
    seed *%= 0x85ebca6b;
    seed ^= seed >> 13;
    seed *%= 0xc2b2ae35;
    seed ^= seed >> 16;
    return seed;
}

/// v1 hashes treat bytes as signed char (sign-extended), v2 as unsigned.
fn byteVal(b: u8, v2: bool) u32 {
    if (v2) return b;
    const s: i8 = @bitCast(b);
    const w: i32 = s;
    return @bitCast(w);
}

pub fn bloomKey(path: []const u8, s: BloomSettings) []u32 {
    const h0 = murmur3(0x293ae76f, path, s.hash_version == 2);
    const h1 = murmur3(0x7e646e2c, path, s.hash_version == 2);
    const keys = gpa.alloc(u32, s.num_hashes) catch util.oom();
    for (keys, 0..) |*k, i| k.* = h0 +% @as(u32, @intCast(i)) *% h1;
    return keys;
}

pub fn filterContains(f: []const u8, keys: []const u32) i32 {
    const mod: u64 = @as(u64, f.len) * 8;
    if (mod == 0) return -1;
    for (keys) |k| {
        const hm = k % mod;
        if (f[@intCast(hm / 8)] & (@as(u8, 1) << @intCast(hm & 7)) == 0) return 0;
    }
    return 1;
}

/// Collect changed paths between two trees (recursive tree diff without
/// renames). Returns false when more than `max` changes were found.
fn diffPaths(a: ?Oid, b: ?Oid, prefix: []const u8, out: *std.ArrayList([]const u8), max: u32) bool {
    const ea: []objects.TreeEntry = if (a) |o| (objects.readTree(o) orelse &.{}) else &.{};
    const eb: []objects.TreeEntry = if (b) |o| (objects.readTree(o) orelse &.{}) else &.{};
    var i: usize = 0;
    var j: usize = 0;
    while (i < ea.len or j < eb.len) {
        if (out.items.len > max) return false;
        var cmp: std.math.Order = undefined;
        if (i >= ea.len) cmp = .gt else if (j >= eb.len) cmp = .lt else cmp = objects.baseNameCompare(ea[i].name, ea[i].mode, eb[j].name, eb[j].mode);
        switch (cmp) {
            .lt => {
                if (!changedEntry(ea[i], null, prefix, out, max)) return false;
                i += 1;
            },
            .gt => {
                if (!changedEntry(null, eb[j], prefix, out, max)) return false;
                j += 1;
            },
            .eq => {
                const x = ea[i];
                const y = eb[j];
                i += 1;
                j += 1;
                if (x.mode == y.mode and hash.eql(x.oid, y.oid)) continue;
                const xd = x.mode & 0o170000 == 0o040000;
                const yd = y.mode & 0o170000 == 0o040000;
                if (xd and yd) {
                    if (!diffPaths(x.oid, y.oid, util.concat(&.{ prefix, x.name, "/" }), out, max)) return false;
                } else if (xd or yd) {
                    if (!changedEntry(x, null, prefix, out, max)) return false;
                    if (!changedEntry(null, y, prefix, out, max)) return false;
                } else {
                    out.append(gpa, util.concat(&.{ prefix, x.name })) catch util.oom();
                }
            },
        }
    }
    return out.items.len <= max;
}

fn changedEntry(x: ?objects.TreeEntry, y: ?objects.TreeEntry, prefix: []const u8, out: *std.ArrayList([]const u8), max: u32) bool {
    const e = x orelse y.?;
    if (e.mode & 0o170000 == 0o040000) {
        const sub = util.concat(&.{ prefix, e.name, "/" });
        return if (x != null) diffPaths(e.oid, null, sub, out, max) else diffPaths(null, e.oid, sub, out, max);
    }
    out.append(gpa, util.concat(&.{ prefix, e.name })) catch util.oom();
    return out.items.len <= max;
}

const BLOOM_NOT_COMPUTED: u32 = 1;
const BLOOM_COMPUTED: u32 = 2;
const BLOOM_TRUNC_LARGE: u32 = 4;
const BLOOM_TRUNC_EMPTY: u32 = 8;
const BLOOM_UPGRADED: u32 = 16;

/// Compute a fresh filter for a commit given its first parent's tree.
fn computeFilter(tree: Oid, parent_tree: ?Oid, has_parent: bool, s: BloomSettings, flags: *u32) []u8 {
    var paths: std.ArrayList([]const u8) = .empty;
    const empty_tree = hash.fromHex(hash.empty_tree_hex).?;
    const pa: ?Oid = if (has_parent) (parent_tree orelse empty_tree) else null;
    const ok = diffPaths(pa, tree, "", &paths, s.max_changed_paths);
    if (!ok) {
        flags.* |= BLOOM_TRUNC_LARGE;
        const d = gpa.alloc(u8, 1) catch util.oom();
        d[0] = 0xff;
        return d;
    }
    var set = std.StringHashMap(void).init(gpa);
    for (paths.items) |p0| {
        var p = p0;
        while (p.len > 0) {
            set.put(p, {}) catch util.oom();
            const sl = std.mem.lastIndexOfScalar(u8, p, '/') orelse break;
            p = p[0..sl];
        }
    }
    const n = set.count();
    if (n > s.max_changed_paths) {
        flags.* |= BLOOM_TRUNC_LARGE;
        const d = gpa.alloc(u8, 1) catch util.oom();
        d[0] = 0xff;
        return d;
    }
    var len: usize = (n * s.bits_per_entry + 7) / 8;
    if (len == 0) {
        flags.* |= BLOOM_TRUNC_EMPTY;
        len = 1;
    }
    const d = gpa.alloc(u8, len) catch util.oom();
    @memset(d, 0);
    const mod: u64 = @as(u64, len) * 8;
    var it = set.keyIterator();
    while (it.next()) |k| {
        const keys = bloomKey(k.*, s);
        for (keys) |h| {
            const hm = h % mod;
            d[@intCast(hm / 8)] |= @as(u8, 1) << @intCast(hm & 7);
        }
    }
    return d;
}

var high_bit_memo: hash.OidMap(bool) = .empty;

fn treeHasHighBit(t: Oid) bool {
    if (high_bit_memo.get(t)) |v| return v;
    const ents = objects.readTree(t) orelse return true;
    var res = false;
    for (ents) |e| {
        for (e.name) |ch| {
            if (ch & 0x80 != 0) {
                res = true;
                break;
            }
        }
        if (res) break;
        if (e.mode & 0o170000 == 0o040000 and treeHasHighBit(e.oid)) {
            res = true;
            break;
        }
    }
    high_bit_memo.put(gpa, t, res) catch util.oom();
    return res;
}

// ---------------------------------------------------------------- trace2

fn trace2Data(category: []const u8, key: []const u8, value: []const u8, json: bool) void {
    const t2 = @import("trace2.zig");
    if (json) t2.dataJson(category, true, key, value) else t2.dataString(category, true, key, value);
}

// ---------------------------------------------------------------- writing

pub const SplitFlags = enum { unspecified, merge_prohibited, replace };

pub const WriteOpts = struct {
    append: bool = false,
    progress: bool = false,
    split: bool = false,
    split_flags: SplitFlags = .unspecified,
    write_bloom: bool = false,
    no_write_bloom: bool = false,
    max_commits: i32 = 0,
    size_multiple: i32 = 2,
    expire_time: i64 = 0,
    max_new_filters: i32 = -1,
};

const Node = struct {
    oid: Oid,
    tree: Oid = hash.zero,
    parents: []Oid = &.{},
    date: u64 = 0,
    parsed: bool = false,
    graph_pos: ?u32 = null,
    topo: u32 = 0,
    gen: u64 = 0,
    reachable: bool = false,
    pack_pos: i32 = 0,
    bloom: ?Filter = null,
    bloom_loaded: bool = false,
};

/// parse_commit_date(): committer timestamp as strtoumax would parse it.
pub fn parseCommitDate(data: []const u8) u64 {
    var pos: usize = 0;
    // skip tree and parent lines
    while (pos < data.len) {
        const rest = data[pos..];
        if (!(util.startsWith(rest, "tree ") or util.startsWith(rest, "parent "))) break;
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n') orelse return 0;
        pos = nl + 1;
    }
    const buf = data[pos..];
    if (buf.len <= 6 or !util.startsWith(buf, "author")) return 0;
    const nl1 = std.mem.indexOfScalar(u8, buf, '\n') orelse return 0;
    const b2 = buf[nl1 + 1 ..];
    if (b2.len <= 9 or !util.startsWith(b2, "committer")) return 0;
    const eol = std.mem.indexOfScalar(u8, b2, '\n') orelse return 0;
    var d = eol;
    while (d > 0 and b2[d - 1] != '>') d -= 1;
    if (d == 0) return 0;
    while (d < eol and std.ascii.isWhitespace(b2[d])) d += 1;
    if (d >= eol) return 0;
    var neg = false;
    if (b2[d] == '-') {
        neg = true;
        d += 1;
    } else if (!std.ascii.isDigit(b2[d])) return 0;
    var v: u64 = 0;
    var overflow = false;
    while (d < eol and std.ascii.isDigit(b2[d])) : (d += 1) {
        const m = @mulWithOverflow(v, 10);
        const a = @addWithOverflow(m[0], b2[d] - '0');
        if (m[1] != 0 or a[1] != 0) overflow = true;
        v = a[0];
    }
    if (overflow) return std.math.maxInt(u64);
    return if (neg) 0 -% v else v;
}

const Writer = struct {
    opts: WriteOpts,
    dir: []const u8,
    dirs: []const []const u8,
    g: ?*Graph = null,
    nodes: hash.OidMap(*Node) = .empty,
    oids: std.ArrayList(Oid) = .empty,
    commits: std.ArrayList(*Node) = .empty,
    num_extra_edges: u32 = 0,
    num_overflows: u32 = 0,
    order_by_pack: bool = false,
    write_generation_data: bool = true,
    changed_paths: bool = false,
    bloom: BloomSettings = .{},
    before: std.ArrayList(*Graph) = .empty, // bottom first
    num_after: usize = 0,
    filenames_after: [][]const u8 = &.{},
    hash_after: [][]const u8 = &.{},
    new_base: ?*Graph = null,
    new_num_in_base: u32 = 0,
    base_graph_name: ?[]const u8 = null,
    pack_counter: i32 = 0,
    die_on_parse: bool = false,

    fn node(self: *Writer, oid: Oid) *Node {
        const gop = self.nodes.getOrPut(gpa, oid) catch util.oom();
        if (!gop.found_existing) {
            const n = gpa.create(Node) catch util.oom();
            n.* = .{ .oid = oid };
            gop.value_ptr.* = n;
        }
        return gop.value_ptr.*;
    }

    fn parseNoGraph(_: *Writer, n: *Node) bool {
        if (n.parsed) return true;
        const odb = repo_mod.repo().odb();
        const obj = odb.read(n.oid) orelse {
            util.err("Could not read {s}", .{hash.hex(n.oid)});
            return false;
        };
        if (obj.typ != .commit) {
            util.err("Object {s} not a commit", .{hash.hex(n.oid)});
            return false;
        }
        const c = objects.parseCommit(n.oid, obj.data) orelse {
            util.err("bogus commit object {s}", .{hash.hex(n.oid)});
            return false;
        };
        n.tree = c.tree;
        n.parents = c.parents;
        n.date = parseCommitDate(obj.data);
        n.parsed = true;
        return true;
    }

    fn parseWithGraph(self: *Writer, n: *Node) bool {
        if (n.parsed) return true;
        if (self.g) |g| {
            if (self.die_on_parse) util.die("dying as requested by the 'GIT_TEST_COMMIT_GRAPH_DIE_ON_PARSE' variable on commit-graph parse!", .{});
            const pos = n.graph_pos orelse findPos(g, n.oid);
            if (pos) |p| {
                if (fill(g, p, null)) |info| {
                    n.graph_pos = p;
                    n.tree = info.tree;
                    n.date = info.date;
                    n.topo = info.topo;
                    n.gen = info.generation;
                    const ps = gpa.alloc(Oid, info.parents.len) catch util.oom();
                    for (info.parents, 0..) |pp, k| {
                        ps[k] = oidAtPos(g, pp);
                        const pn = self.node(ps[k]);
                        if (pn.graph_pos == null) pn.graph_pos = pp;
                    }
                    n.parents = ps;
                    n.parsed = true;
                    return true;
                }
            }
        }
        return self.parseNoGraph(n);
    }

    fn parseAny(self: *Writer, n: *Node) bool {
        return if (self.opts.split) self.parseWithGraph(n) else self.parseNoGraph(n);
    }

    fn startProgress(self: *Writer, title: []const u8, total: u64) ?*progress.Progress {
        if (!self.opts.progress) return null;
        return progress.startDelayed(title, total);
    }

    fn addMissingParents(self: *Writer, n: *Node) void {
        for (n.parents) |p| {
            const pn = self.node(p);
            if (!pn.reachable) {
                self.oids.append(gpa, p) catch util.oom();
                pn.reachable = true;
            }
        }
    }

    fn closeReachable(self: *Writer) void {
        var p = self.startProgress("Loading known commits in commit graph", self.oids.items.len);
        for (self.oids.items, 0..) |o, i| {
            progress.update(p, i + 1);
            self.node(o).reachable = true;
        }
        progress.stop(&p);
        p = self.startProgress("Expanding reachable commits in commit graph", 0);
        var i: usize = 0;
        while (i < self.oids.items.len) : (i += 1) {
            progress.update(p, i + 1);
            const n = self.node(self.oids.items[i]);
            if (self.opts.split) {
                const ok = self.parseWithGraph(n);
                if ((ok and n.graph_pos == null) or self.opts.split_flags == .replace) self.addMissingParents(n);
            } else if (self.parseNoGraph(n)) self.addMissingParents(n);
        }
        progress.stop(&p);
        p = self.startProgress("Clearing commit marks in commit graph", self.oids.items.len);
        for (self.oids.items, 0..) |o, k| {
            progress.update(p, k + 1);
            self.node(o).reachable = false;
        }
        progress.stop(&p);
    }

    fn copyOidsToCommits(self: *Writer) void {
        self.num_extra_edges = 0;
        var p = self.startProgress("Finding extra edges in commit graph", self.oids.items.len);
        std.mem.sort(Oid, self.oids.items, {}, hash.lessThan);
        var i: usize = 0;
        while (i < self.oids.items.len) : (i += 1) {
            progress.update(p, i + 1);
            if (i > 0 and hash.eql(self.oids.items[i - 1], self.oids.items[i])) continue;
            const n = self.node(self.oids.items[i]);
            if (self.opts.split and self.opts.split_flags != .replace and n.graph_pos != null) continue;
            if (self.opts.split and self.opts.split_flags == .replace) {
                _ = self.parseWithGraph(n);
            } else _ = self.parseNoGraph(n);
            if (n.parents.len > 2) self.num_extra_edges += @intCast(n.parents.len - 1);
            self.commits.append(gpa, n) catch util.oom();
        }
        progress.stop(&p);
    }

    fn fillFromPacks(self: *Writer, names: []const []const u8) bool {
        const title = util.fmt("Finding commits for commit graph in {d} pack{s}", .{ names.len, if (names.len == 1) "" else "s" });
        var p = self.startProgress(title, 0);
        defer progress.stop(&p);
        var done: u64 = 0;
        for (names) |name| {
            const path = util.concat(&.{ self.dir, "/pack/", name });
            if (!util.endsWith(path, ".idx")) {
                util.err("error adding pack {s}", .{path});
                return false;
            }
            const pack_path = util.concat(&.{ path[0 .. path.len - 4], ".pack" });
            if (!os.exists(pack_path)) {
                util.err("error adding pack {s}", .{path});
                return false;
            }
            const pk = odb_mod.openIdx(path, pack_path) orelse {
                util.err("error opening index for {s}", .{path});
                return false;
            };
            self.addPackCommits(pk, &done, p);
        }
        return true;
    }

    fn addPackCommits(self: *Writer, pk: *odb_mod.Pack, done: *u64, p: ?*progress.Progress) void {
        const data = os.readFile(pk.pack_path) orelse util.die("packfile {s} cannot be accessed", .{pk.pack_path});
        // pack order: sort entries by offset
        const Ent = struct { off: u64, idx: u32 };
        const ents = gpa.alloc(Ent, pk.num) catch util.oom();
        var k: u32 = 0;
        while (k < pk.num) : (k += 1) ents[k] = .{ .off = pk.offsetAt(k), .idx = k };
        std.mem.sort(Ent, ents, {}, struct {
            fn lt(_: void, a: Ent, b: Ent) bool {
                return a.off < b.off;
            }
        }.lt);
        for (ents) |e| {
            done.* += 1;
            progress.update(p, done.*);
            const oid = pk.oidAt(e.idx);
            const t = packedType(pk, data, e.off, 0) orelse util.die("unable to get type of object {s}", .{hash.hex(oid)});
            if (t != .commit) continue;
            self.oids.append(gpa, oid) catch util.oom();
            const n = self.node(oid);
            n.pack_pos = self.pack_counter;
            self.pack_counter += 1;
        }
    }

    fn fillFromAllPacks(self: *Writer) void {
        var p = self.startProgress("Finding commits for commit graph among packed objects", 0);
        const odb = repo_mod.repo().odb();
        odb.reloadPacks();
        var done: u64 = 0;
        for (odb.packs.items) |pk| self.addPackCommits(pk, &done, p);
        progress.stop(&p);
    }

    // ---- split strategy

    fn splitStrategy(self: *Writer) void {
        var num_commits: u64 = self.commits.items.len;
        const before = self.before.items.len;
        const size_mult: u64 = if (self.opts.size_multiple != 0) @intCast(@max(self.opts.size_multiple, 0)) else 2;
        const max_commits: u64 = @intCast(@max(self.opts.max_commits, 0));
        self.num_after = if (self.opts.split_flags == .replace) 1 else before + 1;
        var gg = self.g;
        if (self.opts.split_flags != .merge_prohibited and self.opts.split_flags != .replace) {
            while (gg) |x| {
                if (!(x.num_commits <= size_mult * num_commits or (max_commits != 0 and num_commits > max_commits))) break;
                if (!util.eql(x.source, self.dir)) break;
                num_commits += x.num_commits;
                gg = x.base;
                self.num_after -= 1;
            }
        }
        if (self.opts.split_flags != .replace) self.new_base = gg;
        if (self.num_after == 2) {
            const x = gg.?;
            if (util.eql(x.filename, graphFilename(x.source)) and !util.eql(x.source, self.dir)) {
                self.num_after = 1;
                self.new_base = null;
            }
        }
        self.filenames_after = gpa.alloc([]const u8, self.num_after) catch util.oom();
        self.hash_after = gpa.alloc([]const u8, self.num_after) catch util.oom();
        for (self.filenames_after) |*f| f.* = "";
        for (self.hash_after) |*h| h.* = "";
        var i: usize = 0;
        while (i < self.num_after and i < before) : (i += 1) self.filenames_after[i] = self.before.items[i].filename;
        var idx: isize = @as(isize, @intCast(before)) - 1;
        gg = self.g;
        while (gg) |x| : (gg = x.base) {
            if (idx >= 0 and idx < self.num_after) self.hash_after[@intCast(idx)] = hash.hexAlloc(x.oid);
            if (idx == @as(isize, @intCast(self.num_after)) - 2) self.write_generation_data = x.gen_data != null;
            idx -= 1;
        }
    }

    fn mergeGraphs(self: *Writer) void {
        var cur = self.before.items.len;
        var gg = self.g;
        while (gg) |x| {
            if (cur < self.num_after) break;
            cur -%= 1;
            var p = self.startProgress("Merging commit-graph", 0);
            var i: u32 = 0;
            const paranoia = envBool("GIT_COMMIT_GRAPH_PARANOIA", false);
            while (i < x.num_commits) : (i += 1) {
                progress.update(p, i + 1);
                const oid = oidAtPos(x, i + x.num_in_base);
                if (paranoia and !repo_mod.repo().odb().has(oid)) continue;
                const n = self.node(oid);
                if (!self.parseWithGraph(n)) continue;
                self.commits.append(gpa, n) catch util.oom();
            }
            progress.stop(&p);
            gg = x.base;
            if (cur == 0) break;
        }
        if (gg) |x| {
            self.new_base = x;
            self.new_num_in_base = x.num_commits + x.num_in_base;
        }
        if (self.new_base) |b| self.base_graph_name = b.filename;
        // sort_and_scan_merged_commits
        var p = self.startProgress("Scanning merged commits", self.commits.items.len);
        std.mem.sort(*Node, self.commits.items, {}, struct {
            fn lt(_: void, a: *Node, b: *Node) bool {
                return hash.order(a.oid, b.oid) == .lt;
            }
        }.lt);
        self.num_extra_edges = 0;
        var w: usize = 0;
        for (self.commits.items, 0..) |n, i| {
            progress.update(p, i + 1);
            if (i > 0 and hash.eql(self.commits.items[i - 1].oid, n.oid)) continue;
            self.commits.items[w] = n;
            w += 1;
            if (n.parents.len > 2) self.num_extra_edges += @intCast(n.parents.len - 1);
        }
        self.commits.items.len = w;
        progress.stop(&p);
    }

    // ---- generations

    fn computeReachable(self: *Writer, comptime topo: bool) void {
        const title = if (topo) "Computing commit graph topological levels" else "Computing commit graph generation numbers";
        var p = self.startProgress(title, self.commits.items.len);
        if (!topo) {
            if (!(self.g == null or self.g.?.read_generation_data)) {
                for (self.commits.items) |c| c.gen = 0;
            }
        }
        var stack: std.ArrayList(*Node) = .empty;
        for (self.commits.items, 0..) |c, i| {
            progress.update(p, i + 1);
            const v: u64 = if (topo) c.topo else c.gen;
            if (v != 0 and v != GEN_INFINITY) continue;
            stack.append(gpa, c) catch util.oom();
            while (stack.items.len > 0) {
                const cur = stack.items[stack.items.len - 1];
                var all = true;
                var max: u64 = 0;
                for (cur.parents) |po| {
                    const pn = self.node(po);
                    _ = self.parseAny(pn);
                    const pg: u64 = if (topo) pn.topo else pn.gen;
                    if (pg == 0) {
                        all = false;
                        stack.append(gpa, pn) catch util.oom();
                        break;
                    }
                    if (pg > max) max = pg;
                }
                if (all) {
                    stack.items.len -= 1;
                    if (topo) {
                        if (max > V1_MAX - 1) max = V1_MAX - 1;
                        cur.topo = @intCast(max + 1);
                    } else {
                        if (cur.date != 0 and cur.date > max) max = cur.date - 1;
                        cur.gen = max + 1;
                    }
                }
            }
        }
        if (!topo) {
            for (self.commits.items) |c| {
                if (genOffset(c) > V2_OFFSET_MAX) self.num_overflows += 1;
            }
        }
        progress.stop(&p);
    }

    // ---- bloom

    fn loadedFilter(self: *Writer, n: *Node) ?Filter {
        if (!n.bloom_loaded) {
            n.bloom_loaded = true;
            if (self.g) |g| {
                const pos = n.graph_pos orelse findPos(g, n.oid);
                if (pos) |ps| n.bloom = loadBloom(g, ps);
            }
        }
        return n.bloom;
    }

    fn computeBloom(self: *Writer) void {
        var p = self.startProgress("Computing commit changed paths Bloom filters", self.commits.items.len);
        const sorted = gpa.dupe(*Node, self.commits.items) catch util.oom();
        if (self.order_by_pack) {
            std.mem.sort(*Node, sorted, {}, struct {
                fn lt(_: void, a: *Node, b: *Node) bool {
                    return a.pack_pos < b.pack_pos;
                }
            }.lt);
        } else {
            std.mem.sort(*Node, sorted, {}, struct {
                fn lt(_: void, a: *Node, b: *Node) bool {
                    if (a.gen != b.gen) return a.gen < b.gen;
                    return a.date < b.date;
                }
            }.lt);
        }
        const max_new: usize = if (self.opts.max_new_filters >= 0) @intCast(self.opts.max_new_filters) else sorted.len;
        var computed_n: usize = 0;
        var not_computed: usize = 0;
        var trunc_empty: usize = 0;
        var trunc_large: usize = 0;
        var upgraded: usize = 0;
        for (sorted, 0..) |c, i| {
            var flags: u32 = BLOOM_NOT_COMPUTED;
            const allowed = computed_n < max_new;
            blk: {
                if (self.loadedFilter(c)) |f| {
                    if (f.data.len > 0) {
                        if (f.version == self.bloom.hash_version) break :blk;
                        if (allowed and envBool("GIT_TEST_UPGRADE_BLOOM_FILTERS", true)) {
                            if (self.canUpgrade(c)) {
                                c.bloom = .{ .data = f.data, .version = self.bloom.hash_version };
                                flags |= BLOOM_UPGRADED;
                                break :blk;
                            }
                        }
                    }
                }
                if (!allowed) break :blk;
                _ = self.parseAny(c);
                var ptree: ?Oid = null;
                if (c.parents.len > 0) {
                    const pn = self.node(c.parents[0]);
                    if (self.parseAny(pn)) ptree = pn.tree;
                }
                const d = computeFilter(c.tree, ptree, c.parents.len > 0, self.bloom, &flags);
                c.bloom = .{ .data = d, .version = self.bloom.hash_version };
                flags |= BLOOM_COMPUTED;
            }
            if (flags & BLOOM_COMPUTED != 0) {
                computed_n += 1;
                if (flags & BLOOM_TRUNC_EMPTY != 0) trunc_empty += 1;
                if (flags & BLOOM_TRUNC_LARGE != 0) trunc_large += 1;
            } else if (flags & BLOOM_UPGRADED != 0) {
                upgraded += 1;
            } else not_computed += 1;
            progress.update(p, i + 1);
        }
        if (os.getenv("GIT_TRACE2_EVENT") != null) {
            trace2Data("commit-graph", "filter-computed", util.fmt("{d}", .{computed_n}), false);
            trace2Data("commit-graph", "filter-not-computed", util.fmt("{d}", .{not_computed}), false);
            trace2Data("commit-graph", "filter-trunc-empty", util.fmt("{d}", .{trunc_empty}), false);
            trace2Data("commit-graph", "filter-trunc-large", util.fmt("{d}", .{trunc_large}), false);
            trace2Data("commit-graph", "filter-upgraded", util.fmt("{d}", .{upgraded}), false);
        }
        progress.stop(&p);
    }

    fn canUpgrade(self: *Writer, c: *Node) bool {
        if (!self.parseAny(c)) return false;
        if (treeHasHighBit(c.tree)) return false;
        if (c.parents.len > 0) {
            const pn = self.node(c.parents[0]);
            if (!self.parseAny(pn)) return false;
            if (treeHasHighBit(pn.tree)) return false;
        }
        return true;
    }

    fn writtenFilter(self: *Writer, n: *Node) []const u8 {
        const f = self.loadedFilter(n) orelse return "";
        if (f.data.len == 0) return "";
        const v = changedPathsVersion();
        if (!(v == -1 or v == f.version)) return "";
        return f.data;
    }

    // ---- file layout

    fn parentPos(self: *Writer, parent: Oid, child: Oid) u32 {
        var lo: usize = 0;
        var hi: usize = self.commits.items.len;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            switch (hash.order(parent, self.commits.items[mid].oid)) {
                .eq => return @as(u32, @intCast(mid)) + self.new_num_in_base,
                .lt => hi = mid,
                .gt => lo = mid + 1,
            }
        }
        if (self.new_base) |b| {
            if (self.node(parent).graph_pos) |gp| {
                if (gp < b.num_commits + b.num_in_base) return gp;
            }
            if (findPos(b, parent)) |ps| return ps;
        }
        util.die("BUG: missing parent {s} for commit {s}", .{ hash.hex(parent), hash.hex(child) });
    }

    fn buildFile(self: *Writer) []u8 {
        const n = self.commits.items.len;
        const Ch = struct { id: u32, data: util.Buf };
        var chunks: std.ArrayList(Ch) = .empty;

        var fan: util.Buf = .empty;
        {
            var count: u32 = 0;
            var i: usize = 0;
            var b: usize = 0;
            while (b < 256) : (b += 1) {
                while (i < n and self.commits.items[i].oid[0] == b) {
                    count += 1;
                    i += 1;
                }
                put32(&fan, count);
            }
        }
        chunks.append(gpa, .{ .id = CH_OIDFANOUT, .data = fan }) catch util.oom();
        var look: util.Buf = .empty;
        for (self.commits.items) |c| look.appendSlice(gpa, &c.oid) catch util.oom();
        chunks.append(gpa, .{ .id = CH_OIDLOOKUP, .data = look }) catch util.oom();

        var cdat: util.Buf = .empty;
        var extra: util.Buf = .empty;
        var num_extra: u32 = 0;
        for (self.commits.items) |c| {
            if (!c.parsed and !self.parseAny(c)) util.die("unable to parse commit {s}", .{hash.hex(c.oid)});
            cdat.appendSlice(gpa, &c.tree) catch util.oom();
            if (c.parents.len == 0) put32(&cdat, GRAPH_PARENT_NONE) else put32(&cdat, self.parentPos(c.parents[0], c.oid));
            if (c.parents.len < 2) {
                put32(&cdat, GRAPH_PARENT_NONE);
            } else if (c.parents.len > 2) {
                put32(&cdat, GRAPH_EXTRA_EDGES_NEEDED | num_extra);
                num_extra += @intCast(c.parents.len - 1);
                for (c.parents[1..], 0..) |po, k| {
                    var ev = self.parentPos(po, c.oid);
                    if (k + 2 == c.parents.len) ev |= GRAPH_LAST_EDGE;
                    put32(&extra, ev);
                }
            } else put32(&cdat, self.parentPos(c.parents[1], c.oid));
            put32(&cdat, @as(u32, @intCast((c.date >> 32) & 3)) | (c.topo << 2));
            put32(&cdat, @truncate(c.date));
        }
        chunks.append(gpa, .{ .id = CH_DATA, .data = cdat }) catch util.oom();

        if (self.write_generation_data) {
            var gd: util.Buf = .empty;
            var go: util.Buf = .empty;
            var nov: u32 = 0;
            for (self.commits.items) |c| {
                var off = genOffset(c);
                if (off > V2_OFFSET_MAX) {
                    put32(&go, @truncate(off >> 32));
                    put32(&go, @truncate(off));
                    off = OFFSET_OVERFLOW | nov;
                    nov += 1;
                }
                put32(&gd, @truncate(off));
            }
            chunks.append(gpa, .{ .id = CH_GENDATA, .data = gd }) catch util.oom();
            if (self.num_overflows > 0) chunks.append(gpa, .{ .id = CH_GENOVERFLOW, .data = go }) catch util.oom();
        }
        if (self.num_extra_edges > 0) chunks.append(gpa, .{ .id = CH_EXTRAEDGES, .data = extra }) catch util.oom();
        if (self.changed_paths) {
            var bi: util.Buf = .empty;
            var bd: util.Buf = .empty;
            put32(&bd, self.bloom.hash_version);
            put32(&bd, self.bloom.num_hashes);
            put32(&bd, self.bloom.bits_per_entry);
            var cur: u32 = 0;
            for (self.commits.items) |c| {
                const f = self.writtenFilter(c);
                cur += @intCast(f.len);
                put32(&bi, cur);
                bd.appendSlice(gpa, f) catch util.oom();
            }
            chunks.append(gpa, .{ .id = CH_BLOOMINDEXES, .data = bi }) catch util.oom();
            trace2Data("bloom", "settings", util.fmt("{{\"hash_version\":{d},\"num_hashes\":{d},\"bits_per_entry\":{d},\"max_changed_paths\":{d}}}", .{ self.bloom.hash_version, self.bloom.num_hashes, self.bloom.bits_per_entry, self.bloom.max_changed_paths }), true);
            chunks.append(gpa, .{ .id = CH_BLOOMDATA, .data = bd }) catch util.oom();
        }
        if (self.num_after > 1) {
            var base: util.Buf = .empty;
            var layers: std.ArrayList(*Graph) = .empty;
            var b = self.new_base;
            while (b) |x| : (b = x.base) layers.append(gpa, x) catch util.oom();
            if (layers.items.len != self.num_after - 1) util.die("failed to write correct number of base graph ids", .{});
            var k = layers.items.len;
            while (k > 0) {
                k -= 1;
                base.appendSlice(gpa, &layers.items[k].oid) catch util.oom();
            }
            chunks.append(gpa, .{ .id = CH_BASE, .data = base }) catch util.oom();
        }

        var out: util.Buf = .empty;
        put32(&out, GRAPH_SIGNATURE);
        out.append(gpa, 1) catch util.oom();
        out.append(gpa, 1) catch util.oom();
        out.append(gpa, @intCast(chunks.items.len)) catch util.oom();
        out.append(gpa, @intCast(if (self.num_after > 0) self.num_after - 1 else 0)) catch util.oom();
        var off: u64 = HEADER_SIZE + (chunks.items.len + 1) * TOC_ENTRY;
        for (chunks.items) |c| {
            put32(&out, c.id);
            put64(&out, off);
            off += c.data.items.len;
        }
        put32(&out, 0);
        put64(&out, off);
        var p: ?*progress.Progress = null;
        if (self.opts.progress) {
            const nc = chunks.items.len;
            p = progress.startDelayed(util.fmt("Writing out commit graph in {d} pass{s}", .{ nc, if (nc == 1) "" else "es" }), nc * n);
        }
        for (chunks.items, 0..) |c, k| {
            out.appendSlice(gpa, c.data.items) catch util.oom();
            progress.update(p, (k + 1) * n);
        }
        progress.stop(&p);
        var h = hash.Hasher.init(.{});
        h.update(out.items);
        var digest: Oid = undefined;
        h.final(&digest);
        out.appendSlice(gpa, &digest) catch util.oom();
        return out.items;
    }

    fn writeFile(self: *Writer) bool {
        const data = self.buildFile();
        const digest: Oid = data[data.len - RAWSZ ..][0..RAWSZ].*;
        if (!self.opts.split) {
            const name = graphFilename(self.dir);
            if (!os.mkdirLeading(name)) {
                util.err("unable to create leading directories of {s}", .{name});
                return false;
            }
            const lk = lockfile.lockOrDie(name);
            lk.write(data);
            _ = os.chmod(lk.lock_path, 0o444);
            if (!lk.commit()) {
                util.err("unable to write {s}: {s}", .{ name, os.lastErr() });
                return false;
            }
            return true;
        }
        const cdir = util.concat(&.{ self.dir, "/info/commit-graphs" });
        const chain_name = chainFilename(self.dir);
        if (!os.mkdirLeading(chain_name)) {
            util.err("unable to create leading directories of {s}", .{util.concat(&.{ cdir, "/tmp_graph_XXXXXX" })});
            return false;
        }
        const lk = lockfile.lockOrDie(chain_name);
        const tmp = os.tmpFile(cdir, "tmp_graph_");
        if (tmp.fd < 0) {
            lk.rollback();
            util.err("unable to create temporary graph layer", .{});
            return false;
        }
        os.writeAll(tmp.fd, data) catch util.dieErrno("unable to write {s}", .{tmp.path});
        os.close(tmp.fd);
        _ = os.chmod(tmp.path, 0o444);

        if (self.base_graph_name != null and self.num_after > 1) {
            const b = self.new_base.?;
            const hx = hash.hexAlloc(b.oid);
            self.filenames_after[self.num_after - 2] = splitFilename(b.source, hx);
            self.hash_after[self.num_after - 2] = hx;
        }
        if (self.base_graph_name) |bname| {
            var idx = self.num_after - 1;
            if (self.num_after > 1) idx -= 1;
            const dest = self.filenames_after[idx];
            if (!util.eql(bname, dest)) {
                if (!os.rename(bname, dest)) {
                    _ = os.unlink(tmp.path);
                    lk.rollback();
                    util.err("failed to rename base commit-graph file", .{});
                    return false;
                }
            }
        } else {
            _ = os.unlink(graphFilename(self.dir));
        }
        const hx = hash.hexAlloc(digest);
        self.hash_after[self.num_after - 1] = hx;
        const final_name = splitFilename(self.dir, hx);
        self.filenames_after[self.num_after - 1] = final_name;
        const ok = os.rename(tmp.path, final_name);
        var chain: util.Buf = .empty;
        for (self.hash_after) |h| {
            chain.appendSlice(gpa, h) catch util.oom();
            chain.append(gpa, '\n') catch util.oom();
        }
        lk.write(chain.items);
        _ = os.chmod(lk.lock_path, 0o444);
        if (!ok) {
            util.err("failed to rename temporary commit-graph file", .{});
            lk.rollback();
            return false;
        }
        _ = lk.commit();
        return true;
    }

    fn markGraphs(self: *Writer) void {
        const now = os.now();
        var i = self.num_after -| 1;
        while (i < self.before.items.len) : (i += 1) {
            const f = self.before.items[i].filename;
            const st = os.statPath(f) orelse continue;
            const ut = Utimbuf{ .actime = st.atime, .modtime = now };
            _ = utime(os.z(f), &ut);
        }
    }

    fn expireGraphs(self: *Writer) void {
        var expire = os.now();
        if (self.opts.expire_time != 0) expire = self.opts.expire_time;
        if (!self.opts.split) {
            _ = os.unlink(chainFilename(self.dir));
            self.num_after = 0;
        }
        const d = util.concat(&.{ self.dir, "/info/commit-graphs" });
        const ents = os.listDir(d) orelse return;
        for (ents) |e| {
            const path = util.concat(&.{ d, "/", e.name });
            const st = os.statPath(path) orelse continue;
            if (st.mtime > expire) continue;
            if (!util.endsWith(path, ".graph")) continue;
            var found = false;
            var i: usize = 0;
            while (i < self.num_after) : (i += 1) {
                if (util.eql(self.filenames_after[i], path)) found = true;
            }
            if (!found) _ = os.unlink(path);
        }
    }
};

const Utimbuf = extern struct { actime: i64, modtime: i64 };
extern "c" fn utime(path: [*:0]const u8, times: *const Utimbuf) c_int;

fn genOffset(c: *const Node) u64 {
    const masked = c.date & ((@as(u64, 1) << 34) - 1);
    return c.gen -% masked;
}

fn put32(b: *util.Buf, v: u32) void {
    var x: [4]u8 = undefined;
    std.mem.writeInt(u32, &x, v, .big);
    b.appendSlice(gpa, &x) catch util.oom();
}
fn put64(b: *util.Buf, v: u64) void {
    var x: [8]u8 = undefined;
    std.mem.writeInt(u64, &x, v, .big);
    b.appendSlice(gpa, &x) catch util.oom();
}

/// Type of a packed object, resolving delta chains.
fn packedType(pk: *odb_mod.Pack, data: []const u8, off: u64, depth: u32) ?odb_mod.ObjType {
    if (depth > 10000) return null;
    const h = odb_mod.parseEntryHeader(data, @intCast(off)) orelse return null;
    switch (h.typ) {
        .commit, .tree, .blob, .tag => return h.typ,
        .ofs_delta => {
            var pos: usize = @as(usize, @intCast(off)) + h.hdr_len;
            const rel = odb_mod.parseOfsDelta(data, &pos);
            if (rel > off) return null;
            return packedType(pk, data, off - rel, depth + 1);
        },
        .ref_delta => {
            const pos: usize = @as(usize, @intCast(off)) + h.hdr_len;
            if (pos + 20 > data.len) return null;
            const base: Oid = data[pos..][0..20].*;
            if (pk.find(base)) |i| return packedType(pk, data, pk.offsetAt(i), depth + 1);
            const o = repo_mod.repo().odb().read(base) orelse return null;
            return o.typ;
        },
        else => return null,
    }
}

/// write_commit_graph(). `packs` are pack-index names relative to
/// <dir>/pack; `commits` are starting commits. Returns 0 on success.
pub fn write(dir: []const u8, packs: ?[]const []const u8, commits: ?[]const Oid, opts: WriteOpts) u8 {
    if (!(repo_mod.cfg.getBool("core.commitgraph") orelse true)) {
        util.warn("attempting to write a commit-graph, but 'core.commitGraph' is disabled", .{});
        return 0;
    }
    if (!compatible()) return 0;
    const cpv = changedPathsVersion();
    if (cpv < -1 or cpv > 2) {
        util.warn("attempting to write a commit-graph, but 'commitGraph.changedPathsVersion' ({d}) is not supported", .{cpv});
        return 0;
    }
    var w = Writer{ .opts = opts, .dir = dir, .dirs = repo_mod.repo().odb().allDirs() };
    w.write_generation_data = generationVersion() == 2;
    w.die_on_parse = envBool("GIT_TEST_COMMIT_GRAPH_DIE_ON_PARSE", false);
    var hv: i64 = cpv;
    w.bloom.bits_per_entry = envU32("GIT_TEST_BLOOM_SETTINGS_BITS_PER_ENTRY", w.bloom.bits_per_entry);
    w.bloom.num_hashes = envU32("GIT_TEST_BLOOM_SETTINGS_NUM_HASHES", w.bloom.num_hashes);
    w.bloom.max_changed_paths = envU32("GIT_TEST_BLOOM_SETTINGS_MAX_CHANGED_PATHS", w.bloom.max_changed_paths);

    resetPrepared();
    w.g = prepare();
    if (opts.write_bloom) w.changed_paths = true;
    if (!opts.no_write_bloom) {
        if (w.g) |g| {
            if (g.bloom_settings) |s| {
                w.changed_paths = true;
                if (hv == -1) hv = s.hash_version;
                w.bloom.bits_per_entry = s.bits_per_entry;
                w.bloom.num_hashes = s.num_hashes;
                w.bloom.max_changed_paths = s.max_changed_paths;
            }
        }
    }
    w.bloom.hash_version = if (hv == 2) 2 else 1;

    if (opts.split) {
        var gg = w.g;
        while (gg) |x| : (gg = x.base) w.before.append(gpa, x) catch util.oom();
        std.mem.reverse(*Graph, w.before.items);
    }
    if (opts.append) {
        if (w.g) |g| {
            var i: u32 = 0;
            while (i < g.num_commits) : (i += 1) w.oids.append(gpa, g.lexOid(i)) catch util.oom();
        }
    }
    if (packs) |pl| {
        w.order_by_pack = true;
        if (!w.fillFromPacks(pl)) return 1;
    }
    if (commits) |cl| w.oids.appendSlice(gpa, cl) catch util.oom();
    if (packs == null and commits == null) {
        w.order_by_pack = true;
        w.fillFromAllPacks();
    }
    w.closeReachable();
    w.copyOidsToCommits();
    if (w.commits.items.len >= GRAPH_EDGE_LAST_MASK) {
        util.err("too many commits to write graph", .{});
        return 1;
    }
    const replace = opts.split and opts.split_flags == .replace;
    if (w.commits.items.len == 0 and !replace) return 0;
    if (opts.split) {
        w.splitStrategy();
        if (!replace) w.mergeGraphs();
    } else w.num_after = 1;
    w.computeReachable(true);
    if (w.write_generation_data) w.computeReachable(false);
    if (w.changed_paths) w.computeBloom();
    var res: u8 = 0;
    if (!w.writeFile()) res = 1;
    if (opts.split) w.markGraphs();
    w.expireGraphs();
    resetPrepared();
    return res;
}

fn envU32(name: []const u8, def: u32) u32 {
    const v = os.getenv(name) orelse return def;
    return std.fmt.parseInt(u32, v, 10) catch def;
}

/// write_commit_graph_reachable(): all commits reachable from refs.
pub fn writeReachable(dir: []const u8, opts: WriteOpts) u8 {
    var set: hash.OidSet = .empty;
    var list: std.ArrayList(Oid) = .empty;
    var p: ?*progress.Progress = null;
    if (opts.progress) p = progress.startDelayed("Collecting referenced commits", 0);
    const odb = repo_mod.repo().odb();
    for (refs.iterate("refs/", .{ .check_objects = false })) |r| {
        if (!odb.has(r.oid)) continue;
        const pe = objects.peel(r.oid) orelse continue;
        if (pe.typ == .commit) {
            const gop = set.getOrPut(gpa, pe.oid) catch util.oom();
            if (!gop.found_existing) list.append(gpa, pe.oid) catch util.oom();
        }
        progress.update(p, set.count());
    }
    progress.stop(&p);
    return write(dir, null, list.items, opts);
}

// ---------------------------------------------------------------- verify

const VC = struct {
    parsed: bool = false,
    graph_pos: ?u32 = null,
    has_data: bool = false,
    generation: u64 = 0,
    date: u64 = 0,
    tree: Oid = hash.zero,
    parents: []Oid = &.{},
};

var vmap: hash.OidMap(*VC) = .empty;
var verify_error: u8 = 0;
const VERIFY_ERROR_HASH: u8 = 2;

fn vc(oid: Oid) *VC {
    const gop = vmap.getOrPut(gpa, oid) catch util.oom();
    if (!gop.found_existing) {
        const x = gpa.create(VC) catch util.oom();
        x.* = .{};
        gop.value_ptr.* = x;
    }
    return gop.value_ptr.*;
}

fn graphReport(comptime f: []const u8, args: anytype) void {
    verify_error |= 1;
    util.ewrite(util.fmt(f ++ "\n", args));
}

fn parseInGraphOne(g: *Graph, oid: Oid, item: *VC) bool {
    if (item.parsed) return true;
    const pos = item.graph_pos orelse findPos(g, oid) orelse return false;
    var partial: Info = undefined;
    const info_opt = fill(g, pos, &partial);
    item.graph_pos = pos;
    item.has_data = true;
    item.date = partial.date;
    item.generation = partial.generation;
    item.tree = partial.tree;
    const info = info_opt orelse return false;
    const ps = gpa.alloc(Oid, info.parents.len) catch util.oom();
    for (info.parents, 0..) |pp, k| {
        ps[k] = oidAtPos(g, pp);
        const pv = vc(ps[k]);
        pv.graph_pos = pp;
        pv.has_data = true;
    }
    item.parents = ps;
    item.parsed = true;
    return true;
}

fn genFromGraph(x: *const VC) u64 {
    if (x.graph_pos == null) return GEN_INFINITY;
    return x.generation;
}

fn checksumValid(g: *const Graph) bool {
    if (g.data.len < RAWSZ) return false;
    var h = hash.Hasher.init(.{});
    h.update(g.data[0 .. g.data.len - RAWSZ]);
    var d: Oid = undefined;
    h.final(&d);
    return std.mem.eql(u8, &d, g.data[g.data.len - RAWSZ ..]);
}

fn verifyOne(g: *Graph, p: ?*progress.Progress, seen: *u64) u8 {
    const odb = repo_mod.repo().odb();
    if (!checksumValid(g)) {
        graphReport("the commit-graph file has incorrect checksum and is likely corrupt", .{});
        verify_error = VERIFY_ERROR_HASH;
    }
    var prev: Oid = hash.zero;
    var fpos: u32 = 0;
    var i: u32 = 0;
    while (i < g.num_commits) : (i += 1) {
        const cur = g.lexOid(i);
        if (i > 0 and hash.order(prev, cur) != .lt)
            graphReport("commit-graph has incorrect OID order: {s} then {s}", .{ hash.hex(prev), hash.hex(cur) });
        prev = cur;
        while (cur[0] > fpos) {
            const fv = be32(g.fanout, @as(usize, fpos) * 4);
            if (i != fv) graphReport("commit-graph has incorrect fanout value: fanout[{d}] = {d} != {d}", .{ fpos, fv, i });
            fpos += 1;
        }
        if (!parseInGraphOne(g, cur, vc(cur)))
            graphReport("failed to parse commit {s} from commit-graph", .{hash.hex(cur)});
    }
    while (fpos < 256) : (fpos += 1) {
        const fv = be32(g.fanout, @as(usize, fpos) * 4);
        if (g.num_commits != fv) graphReport("commit-graph has incorrect fanout value: fanout[{d}] = {d} != {d}", .{ fpos, fv, i });
    }
    if (verify_error & ~VERIFY_ERROR_HASH != 0) return verify_error;

    var seen_zero: ?Oid = null;
    var seen_nonzero: ?Oid = null;
    i = 0;
    while (i < g.num_commits) : (i += 1) {
        seen.* += 1;
        progress.update(p, seen.*);
        const cur = g.lexOid(i);
        const gc = vc(cur);
        const obj = odb.read(cur);
        var oc: ?objects.Commit = null;
        if (obj) |o| {
            if (o.typ == .commit) oc = objects.parseCommit(cur, o.data) else util.err("Object {s} not a commit", .{hash.hex(cur)});
        } else util.err("Could not read {s}", .{hash.hex(cur)});
        const odbc = oc orelse {
            graphReport("failed to parse commit {s} from object database for commit-graph", .{hash.hex(cur)});
            continue;
        };
        const odb_date = parseCommitDate(obj.?.data);
        if (!hash.eql(gc.tree, odbc.tree))
            graphReport("root tree OID for commit {s} in commit-graph is {s} != {s}", .{ hash.hex(cur), hash.hex(gc.tree), hash.hex(odbc.tree) });
        var max_gen: u64 = 0;
        var k: usize = 0;
        while (k < gc.parents.len) : (k += 1) {
            if (k >= odbc.parents.len) {
                graphReport("commit-graph parent list for commit {s} is too long", .{hash.hex(cur)});
                break;
            }
            const gp = gc.parents[k];
            const pv = vc(gp);
            _ = parseInGraphOne(g, gp, pv);
            if (!hash.eql(gp, odbc.parents[k]))
                graphReport("commit-graph parent for {s} is {s} != {s}", .{ hash.hex(cur), hash.hex(gp), hash.hex(odbc.parents[k]) });
            const gen = genFromGraph(pv);
            if (gen > max_gen) max_gen = gen;
        }
        if (k < odbc.parents.len and !(k < gc.parents.len))
            graphReport("commit-graph parent list for commit {s} terminates early", .{hash.hex(cur)});
        if (genFromGraph(gc) != 0) seen_nonzero = cur else seen_zero = cur;
        if (seen_zero != null) continue;
        if (!g.read_generation_data and max_gen == V1_MAX) max_gen -= 1;
        const generation: u64 = if (gc.has_data and gc.generation != 0) gc.generation else GEN_INFINITY;
        if (generation < max_gen + 1)
            graphReport("commit-graph generation for commit {s} is {d} < {d}", .{ hash.hex(cur), generation, max_gen + 1 });
        if (gc.date != odb_date)
            graphReport("commit date for commit {s} in commit-graph is {d} != {d}", .{ hash.hex(cur), gc.date, odb_date });
    }
    if (seen_zero != null and seen_nonzero != null)
        graphReport("commit-graph has both zero and non-zero generations (e.g., commits '{s}' and '{s}')", .{ hash.hex(seen_zero.?), hash.hex(seen_nonzero.?) });
    return verify_error;
}

/// verify_commit_graph()
pub fn verify(g0: *Graph, shallow: bool, show_progress: bool) u8 {
    var p: ?*progress.Progress = null;
    if (show_progress) {
        var total: u64 = g0.num_commits;
        if (!shallow) total += g0.num_in_base;
        p = progress.start("Verifying commits in commit graph", total);
    }
    var local: u8 = 0;
    var seen: u64 = 0;
    var gg: ?*Graph = g0;
    while (gg) |g| : (gg = g.base) {
        local |= verifyOne(g, p, &seen);
        if (shallow) break;
    }
    progress.stop(&p);
    return local;
}
