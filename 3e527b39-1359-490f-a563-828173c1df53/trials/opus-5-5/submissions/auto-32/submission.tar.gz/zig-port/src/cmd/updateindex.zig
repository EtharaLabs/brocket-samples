//! git update-index

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const objects = @import("../objects.zig");
const refs = @import("../refs.zig");
const index_mod = @import("../index.zig");
const pathspec = @import("../pathspec.zig");
const Oid = hash.Oid;
const Entry = index_mod.Entry;
const Index = index_mod.Index;
const gpa = util.gpa;

const Mark = enum { none, mark, unmark };

var allow_add = false;
var allow_remove = false;
var allow_replace = false;
var info_only = false;
var force_remove = false;
var verbose = false;
var mark_valid_only: Mark = .none;
var mark_skip_worktree_only: Mark = .none;
var mark_fsmonitor_only: Mark = .none;
var ignore_skip_worktree_entries = false;
/// core.ignorestat
var assume_unchanged = false;
var idx: *Index = undefined;

const usage = [_][]const u8{"git update-index [<options>] [--] [<file>...]"};

var d_bool = false;
var d_int: i32 = 0;
var d_str: ?[]const u8 = null;
fn dcb(_: ?[]const u8, _: bool) void {}

const usage_opts = [_]po.Opt{
    po.bit('q', "", &d_int, 1, "continue refresh even when index needs update"),
    po.bit(0, "ignore-submodules", &d_int, 1, "refresh: ignore submodules"),
    po.setInt(0, "add", &d_int, 1, "do not ignore new files"),
    po.setInt(0, "replace", &d_int, 1, "let files replace directories and vice-versa"),
    po.setInt(0, "remove", &d_int, 1, "notice files missing from worktree"),
    po.bit(0, "unmerged", &d_int, 1, "refresh even if index contains unmerged entries"),
    .{ .kind = .callback, .long = "refresh", .cb = dcb, .noarg = true, .noneg = true, .help = "refresh stat information" },
    .{ .kind = .callback, .long = "really-refresh", .cb = dcb, .noarg = true, .noneg = true, .help = "like --refresh, but ignore assume-unchanged setting" },
    .{ .kind = .callback, .long = "cacheinfo", .cb = dcb, .noarg = true, .noneg = true, .literal_argh = true, .argh = "<mode>,<object>,<path>", .help = "add the specified entry to the index" },
    .{ .kind = .callback, .long = "chmod", .cb = dcb, .noneg = true, .literal_argh = true, .argh = "(+|-)x", .help = "override the executable bit of the listed files" },
    .{ .kind = .set_int, .long = "assume-unchanged", .i = &d_int, .noarg = true, .noneg = true, .help = "mark files as \"not changing\"" },
    .{ .kind = .set_int, .long = "no-assume-unchanged", .i = &d_int, .noarg = true, .noneg = true, .help = "clear assumed-unchanged bit" },
    .{ .kind = .set_int, .long = "skip-worktree", .i = &d_int, .noarg = true, .noneg = true, .help = "mark files as \"index-only\"" },
    .{ .kind = .set_int, .long = "no-skip-worktree", .i = &d_int, .noarg = true, .noneg = true, .help = "clear skip-worktree bit" },
    po.boolean(0, "ignore-skip-worktree-entries", &d_bool, "do not touch index-only entries"),
    po.setInt(0, "info-only", &d_int, 1, "add to index only; do not add content to object database"),
    po.setInt(0, "force-remove", &d_int, 1, "remove named paths even if present in worktree"),
    po.boolean('z', "", &d_bool, "with --stdin: input lines are terminated by null bytes"),
    .{ .kind = .callback, .long = "stdin", .cb = dcb, .noarg = true, .noneg = true, .help = "read list of paths to be updated from standard input" },
    .{ .kind = .callback, .long = "index-info", .cb = dcb, .noarg = true, .noneg = true, .help = "add entries from standard input to the index" },
    .{ .kind = .callback, .long = "unresolve", .cb = dcb, .noarg = true, .noneg = true, .help = "repopulate stages #2 and #3 for the listed paths" },
    .{ .kind = .callback, .short = 'g', .long = "again", .cb = dcb, .noarg = true, .noneg = true, .help = "only update entries that differ from HEAD" },
    po.bit(0, "ignore-missing", &d_int, 1, "ignore files missing from worktree"),
    po.setInt(0, "verbose", &d_int, 1, "report actions to standard output"),
    .{ .kind = .callback, .long = "clear-resolve-undo", .cb = dcb, .noarg = true, .noneg = true, .help = "(for porcelains) forget saved unresolved conflicts" },
    po.integer(0, "index-version", &d_int, "<n>", "write index in this format"),
    po.setInt(0, "show-index-version", &d_int, -1, "report on-disk index format version"),
    po.boolean(0, "split-index", &d_bool, "enable or disable split index"),
    po.boolean(0, "untracked-cache", &d_bool, "enable/disable untracked cache"),
    po.setInt(0, "test-untracked-cache", &d_int, 1, "test if the filesystem supports untracked cache"),
    po.setInt(0, "force-untracked-cache", &d_int, 1, "enable untracked cache without testing the filesystem"),
    po.setInt(0, "force-write-index", &d_int, 1, "write out the index even if is not flagged as changed"),
    po.boolean(0, "fsmonitor", &d_bool, "enable or disable file system monitor"),
    .{ .kind = .set_int, .long = "fsmonitor-valid", .i = &d_int, .noarg = true, .noneg = true, .help = "mark files as fsmonitor valid" },
    .{ .kind = .set_int, .long = "no-fsmonitor-valid", .i = &d_int, .noarg = true, .noneg = true, .help = "clear fsmonitor valid bit" },
};

fn report(comptime f: []const u8, args: anytype) void {
    if (!verbose) return;
    util.outf(f ++ "\n", args);
}

fn usageError() noreturn {
    po.usageExit(&usage, &usage_opts, true);
}

fn removeOnePath(path: []const u8) bool {
    if (!allow_remove) {
        util.err("{s}: does not exist and --remove not passed", .{path});
        return false;
    }
    _ = idx.removePath(path);
    return true;
}

fn addOnePath(old: ?*const Entry, path: []const u8, st: os.Stat) bool {
    if (old) |o| {
        if (o.stage() == 0 and idx.matchStat(o, st, false) == 0) return true;
    }
    var e = Entry{ .path = util.dupe(path) };
    e.fillStat(st);
    e.mode = index_mod.ceModeFromStat(old, st);
    if (st.isDir()) {
        e.oid = index_mod.gitlinkHead(path) orelse return false;
    } else {
        const ne = index_mod.entryFromFile(e.path, st, old, !info_only) orelse {
            util.err("{s}: failed to insert into database", .{path});
            return false;
        };
        e.oid = ne.oid;
    }
    if (!idx.add(e, .{ .ok_to_add = allow_add, .ok_to_replace = allow_replace })) {
        util.err("{s}: cannot add to the index - missing --add option?", .{path});
        return false;
    }
    return true;
}

fn processDirectory(path: []const u8, st: os.Stat) bool {
    switch (idx.pos(path, 0)) {
        .found => |i| {
            const ce = &idx.entries.items[i];
            if (ce.mode & os.S_IFMT == os.S_IFGITLINK) {
                if (index_mod.gitlinkHead(path) == null) return true;
                const copy = ce.*;
                return addOnePath(&copy, path, st);
            }
            return removeOnePath(path);
        },
        .missing => |start| {
            var p = start;
            while (p < idx.entries.items.len) : (p += 1) {
                const n = idx.entries.items[p].path;
                if (n.len < path.len or !std.mem.eql(u8, n[0..path.len], path)) break;
                if (n.len == path.len) continue;
                if (n[path.len] > '/') break;
                if (n[path.len] < '/') continue;
                util.err("{s}: is a directory - add individual files instead", .{path});
                return false;
            }
        },
    }
    if (index_mod.gitlinkHead(path) != null) return addOnePath(null, path, st);
    util.err("{s}: is a directory - add files inside instead", .{path});
    return false;
}

fn processPath(path: []const u8, st: ?os.Stat) bool {
    if (pathspec.hasSymlinkLeadingPath(path)) {
        util.err("'{s}' is beyond a symbolic link", .{path});
        return false;
    }
    const ce: ?Entry = if (idx.findPos(path)) |i| idx.entries.items[i] else null;
    if (ce) |c| {
        if (c.skipWorktree()) {
            if (!ignore_skip_worktree_entries and allow_remove) _ = idx.removePath(path);
            return true;
        }
    }
    const s = st orelse return removeOnePath(path);
    if (s.isDir()) return processDirectory(path, s);
    if (ce) |c| {
        const copy = c;
        return addOnePath(&copy, path, s);
    }
    return addOnePath(null, path, s);
}

fn markFlags(path: []const u8, is_skip: bool, mark: bool) bool {
    const i = idx.findPos(path) orelse return false;
    const e = &idx.entries.items[i];
    if (is_skip) {
        if (mark) e.ext_flags |= index_mod.CE_SKIP_WORKTREE else e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
    } else {
        if (mark) e.flags |= index_mod.CE_VALID else e.flags &= ~index_mod.CE_VALID;
    }
    e.update_in_base = true;
    idx.invalidatePath(path);
    return true;
}

fn updateOne(path: []const u8) void {
    var st: ?os.Stat = null;
    if (mark_valid_only == .none and mark_skip_worktree_only == .none and !force_remove and mark_fsmonitor_only == .none)
        st = os.lstatPath(path);
    const mode: u32 = if (st) |s| s.mode else 0;
    if (!index_mod.verifyPath(path, mode)) {
        util.eprint("Ignoring path {s}\n", .{path});
        return;
    }
    if (mark_valid_only != .none) {
        if (!markFlags(path, false, mark_valid_only == .mark)) util.die("Unable to mark file {s}", .{path});
        return;
    }
    if (mark_skip_worktree_only != .none) {
        if (!markFlags(path, true, mark_skip_worktree_only == .mark)) util.die("Unable to mark file {s}", .{path});
        return;
    }
    if (mark_fsmonitor_only != .none) {
        if (idx.findPos(path) == null) util.die("Unable to mark file {s}", .{path});
        return;
    }
    if (force_remove) {
        _ = idx.removePath(path);
        report("remove '{s}'", .{path});
        return;
    }
    if (!processPath(path, st)) util.die("Unable to process path {s}", .{path});
    report("add '{s}'", .{path});
}

fn chmodPath(flip: u8, path: []const u8) void {
    const i = idx.findPos(path) orelse util.die("git update-index: cannot chmod {c}x '{s}'", .{ flip, path });
    const e = &idx.entries.items[i];
    if (e.mode & os.S_IFMT != os.S_IFREG) util.die("git update-index: cannot chmod {c}x '{s}'", .{ flip, path });
    e.mode = if (flip == '+') 0o100755 else 0o100644;
    e.update_in_base = true;
    idx.invalidatePath(path);
    report("chmod {c}x '{s}'", .{ flip, path });
}

fn addCacheinfo(mode: u32, oid: Oid, path: []const u8, stage: u32) bool {
    if (!index_mod.verifyPath(path, mode)) {
        util.err("Invalid path '{s}'", .{path});
        return false;
    }
    var e = Entry{ .path = util.dupe(path), .oid = oid, .mode = index_mod.canonMode(mode) };
    e.setStage(stage);
    if (assume_unchanged) e.flags |= index_mod.CE_VALID;
    if (!idx.add(e, .{ .ok_to_add = allow_add, .ok_to_replace = allow_replace })) {
        util.err("{s}: cannot add to the index - missing --add option?", .{path});
        return false;
    }
    report("add '{s}'", .{path});
    return true;
}

fn parseOctal(s: []const u8) ?u32 {
    if (s.len == 0) return null;
    return std.fmt.parseInt(u32, s, 8) catch null;
}

fn readLines(nul: bool) [][]const u8 {
    const data = os.readAllFd(0) catch util.die("could not read from stdin", .{});
    var l: std.ArrayList([]const u8) = .empty;
    const sep: u8 = if (nul) 0 else '\n';
    var it = std.mem.splitScalar(u8, data, sep);
    while (it.next()) |line0| {
        var line = line0;
        if (!nul and line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
        l.append(gpa, line) catch util.oom();
    }
    // drop the trailing empty element after the last terminator
    if (l.items.len > 0 and l.items[l.items.len - 1].len == 0) _ = l.pop();
    return l.items;
}

fn readIndexInfo(nul: bool) void {
    for (readLines(nul)) |line| {
        const sp = std.mem.indexOfScalar(u8, line, ' ') orelse badLine(line);
        const mode = parseOctal(line[0..sp]) orelse badLine(line);
        const tab = std.mem.indexOfScalar(u8, line, '\t') orelse badLine(line);
        if (tab < sp + 41) badLine(line);
        var stage: u32 = 0;
        var oid_end = tab;
        if (line[tab - 2] == ' ' and line[tab - 1] >= '0' and line[tab - 1] <= '3') {
            stage = line[tab - 1] - '0';
            oid_end = tab - 2;
        }
        if (oid_end < 41) badLine(line);
        const oid = hash.fromHex(line[oid_end - 40 .. oid_end]) orelse badLine(line);
        if (line[oid_end - 41] != ' ') badLine(line);
        var path: []const u8 = line[tab + 1 ..];
        if (!nul and path.len > 0 and path[0] == '"') {
            const uq = util.cunquote(path) orelse util.die("git update-index: bad quoting of path name", .{});
            path = uq.value;
        }
        if (!index_mod.verifyPath(path, mode)) {
            util.eprint("Ignoring path {s}\n", .{path});
            continue;
        }
        if (mode == 0) {
            _ = idx.removePath(path);
        } else {
            if (!addCacheinfo(mode, oid, path, stage)) util.die("git update-index: unable to update {s}", .{path});
        }
    }
}

fn badLine(line: []const u8) noreturn {
    util.die("malformed index info {s}", .{line});
}

fn prefixed(arg: []const u8) []const u8 {
    return repo_mod.prefixPath(arg) orelse util.die("'{s}' is outside repository at '{s}'", .{ arg, repo_mod.repo().work_tree orelse "" });
}

fn doReupdate(paths: []const []const u8) bool {
    const r = repo_mod.repo();
    const ps = pathspec.parse(r.prefix, paths, .{ .prefer_cwd = true });
    const head = refs.readOid("HEAD");
    const head_tree: ?Oid = if (head) |h| (if (objects.readCommit(h)) |c| c.tree else null) else null;
    redo: while (true) {
        var i: usize = 0;
        while (i < idx.entries.items.len) : (i += 1) {
            const e = idx.entries.items[i];
            if (e.stage() != 0 or !ps.matches(e.path, false)) continue;
            if (head_tree) |t| {
                if (objects.treeLookup(t, e.path)) |te| {
                    if (te.mode == e.mode and hash.eql(te.oid, e.oid)) continue;
                }
            }
            const save = idx.entries.items.len;
            updateOne(e.path);
            if (save != idx.entries.items.len) continue :redo;
        }
        break;
    }
    return false;
}

// -------------------------------------------------------------------
// option parsing: a port of the parse_options_step() loop used by
// cmd_update_index (options interleaved with paths, low-level callbacks)

const OptId = enum {
    q,
    ignore_submodules,
    add,
    replace,
    remove,
    unmerged,
    refresh,
    really_refresh,
    cacheinfo,
    chmod,
    assume_unchanged,
    no_assume_unchanged,
    skip_worktree,
    no_skip_worktree,
    ignore_skip_worktree_entries,
    info_only,
    force_remove,
    z,
    stdin,
    index_info,
    unresolve,
    again,
    ignore_missing,
    verbose,
    clear_resolve_undo,
    index_version,
    show_index_version,
    split_index,
    untracked_cache,
    test_untracked_cache,
    force_untracked_cache,
    force_write_index,
    fsmonitor,
    fsmonitor_valid,
    no_fsmonitor_valid,
};

const ArgKind = enum { none, str, int };

const UOpt = struct {
    id: OptId,
    short: u8 = 0,
    long: []const u8 = "",
    arg: ArgKind = .none,
    noneg: bool = false,
};

const uopts = [_]UOpt{
    .{ .id = .q, .short = 'q' },
    .{ .id = .ignore_submodules, .long = "ignore-submodules" },
    .{ .id = .add, .long = "add" },
    .{ .id = .replace, .long = "replace" },
    .{ .id = .remove, .long = "remove" },
    .{ .id = .unmerged, .long = "unmerged" },
    .{ .id = .refresh, .long = "refresh", .noneg = true },
    .{ .id = .really_refresh, .long = "really-refresh", .noneg = true },
    .{ .id = .cacheinfo, .long = "cacheinfo", .noneg = true },
    .{ .id = .chmod, .long = "chmod", .arg = .str, .noneg = true },
    .{ .id = .assume_unchanged, .long = "assume-unchanged", .noneg = true },
    .{ .id = .no_assume_unchanged, .long = "no-assume-unchanged", .noneg = true },
    .{ .id = .skip_worktree, .long = "skip-worktree", .noneg = true },
    .{ .id = .no_skip_worktree, .long = "no-skip-worktree", .noneg = true },
    .{ .id = .ignore_skip_worktree_entries, .long = "ignore-skip-worktree-entries" },
    .{ .id = .info_only, .long = "info-only" },
    .{ .id = .force_remove, .long = "force-remove" },
    .{ .id = .z, .short = 'z' },
    .{ .id = .stdin, .long = "stdin", .noneg = true },
    .{ .id = .index_info, .long = "index-info", .noneg = true },
    .{ .id = .unresolve, .long = "unresolve", .noneg = true },
    .{ .id = .again, .short = 'g', .long = "again", .noneg = true },
    .{ .id = .ignore_missing, .long = "ignore-missing" },
    .{ .id = .verbose, .long = "verbose" },
    .{ .id = .clear_resolve_undo, .long = "clear-resolve-undo", .noneg = true },
    .{ .id = .index_version, .long = "index-version", .arg = .int },
    .{ .id = .show_index_version, .long = "show-index-version" },
    .{ .id = .split_index, .long = "split-index" },
    .{ .id = .untracked_cache, .long = "untracked-cache" },
    .{ .id = .test_untracked_cache, .long = "test-untracked-cache" },
    .{ .id = .force_untracked_cache, .long = "force-untracked-cache" },
    .{ .id = .force_write_index, .long = "force-write-index" },
    .{ .id = .fsmonitor, .long = "fsmonitor" },
    .{ .id = .fsmonitor_valid, .long = "fsmonitor-valid", .noneg = true },
    .{ .id = .no_fsmonitor_valid, .long = "no-fsmonitor-valid", .noneg = true },
};

const UC_UNSPECIFIED: i32 = -1;
const UC_DISABLE: i32 = 0;
const UC_ENABLE: i32 = 1;
const UC_TEST: i32 = 2;
const UC_FORCE: i32 = 3;

const State = struct {
    args: []const []const u8,
    /// index of the argument currently being parsed
    i: usize = 0,
    /// rest of a short-option cluster, or the value after '=' of a long option
    opt: ?[]const u8 = null,
    has_errors: bool = false,
    refresh_flags: u32 = 0,
    nul: bool = false,
    read_stdin: bool = false,
    flip: u8 = 0,
    preferred_version: i32 = 0,
    force_write: bool = false,
    split_index: i32 = -1,
    untracked_cache: i32 = UC_UNSPECIFIED,
    fsmonitor: i32 = -1,
    /// set by callbacks that consume all remaining arguments
    consumed_all: bool = false,
};

const ParseError = error{ParseFailed};

fn optName(o: *const UOpt, short: bool, unset: bool) []const u8 {
    if (short) return util.fmt("switch `{c}'", .{o.short});
    if (unset) return util.fmt("option `no-{s}'", .{o.long});
    return util.fmt("option `{s}'", .{o.long});
}

fn fail(comptime f: []const u8, args: anytype) ParseError {
    util.err(f, args);
    return error.ParseFailed;
}

/// strtoul(s, &end, 8) followed by a check of what follows; returns value and end index
fn parseOctalPrefix(s: []const u8) ?struct { v: u32, end: usize } {
    var i: usize = 0;
    while (i < s.len and (s[i] == ' ' or (s[i] >= '\t' and s[i] <= '\r'))) i += 1;
    if (i < s.len and s[i] == '+') i += 1;
    const start = i;
    var v: u64 = 0;
    while (i < s.len and s[i] >= '0' and s[i] <= '7') : (i += 1) {
        v = v * 8 + (s[i] - '0');
        if (v > std.math.maxInt(u32)) return null;
    }
    if (i == start) return null;
    return .{ .v = @intCast(v), .end = i };
}

/// strtoul_ui(s, 8, &mode)
fn strtoulUi(s: []const u8) ?u32 {
    if (std.mem.indexOfScalar(u8, s, '-') != null) return null;
    const r = parseOctalPrefix(s) orelse return null;
    if (r.end != s.len) return null;
    return r.v;
}

fn getArg(st: *State, o: *const UOpt, short: bool, unset: bool) ParseError![]const u8 {
    if (st.opt) |v| {
        st.opt = null;
        return v;
    }
    if (st.i + 1 < st.args.len) {
        st.i += 1;
        return st.args[st.i];
    }
    return fail("{s} requires a value", .{optName(o, short, unset)});
}

fn doRefresh(st: *State, flag: u32) void {
    _ = repo_mod.requireWorkTree("update-index");
    if (index_mod.refresh(idx, st.refresh_flags | flag, null, null)) st.has_errors = true;
    // has_racy_timestamp(): rewrite the index to make racy entries non-racy
    for (idx.entries.items) |*e| {
        if (e.removed) continue;
        if (e.mode & os.S_IFMT == os.S_IFGITLINK) continue;
        if (idx.isRacy(e)) {
            idx.changed = true;
            idx.something_changed = true;
            break;
        }
    }
}

fn cacheinfoCallback(st: *State) ParseError!void {
    const next: ?[]const u8 = if (st.i + 1 < st.args.len) st.args[st.i + 1] else null;
    if (next) |arg| {
        if (parseNewStyle(arg)) |ci| {
            if (!addCacheinfo(ci.mode, ci.oid, ci.path, 0))
                util.die("git update-index: --cacheinfo cannot add {s}", .{ci.path});
            st.i += 1;
            return;
        }
    }
    if (st.args.len - st.i <= 3)
        return fail("option 'cacheinfo' expects <mode>,<sha1>,<path>", .{});
    const mode = strtoulUi(st.args[st.i + 1]) orelse
        util.die("git update-index: --cacheinfo cannot add {s}", .{st.args[st.i + 1]});
    const oid = hash.fromHex(st.args[st.i + 2]) orelse
        util.die("git update-index: --cacheinfo cannot add {s}", .{st.args[st.i + 2]});
    if (!addCacheinfo(mode, oid, st.args[st.i + 3], 0))
        util.die("git update-index: --cacheinfo cannot add {s}", .{st.args[st.i + 3]});
    st.i += 3;
}

fn getValue(st: *State, o: *const UOpt, short: bool, unset: bool) ParseError!void {
    if (unset and st.opt != null) return fail("{s} takes no value", .{optName(o, short, unset)});
    if (unset and o.noneg) return fail("{s} isn't available", .{optName(o, short, unset)});
    if (!short and st.opt != null and o.arg == .none) return fail("{s} takes no value", .{optName(o, short, unset)});

    switch (o.id) {
        .q => setBit(&st.refresh_flags, index_mod.REFRESH_QUIET, unset),
        .ignore_submodules => setBit(&st.refresh_flags, index_mod.REFRESH_IGNORE_SUBMODULES, unset),
        .unmerged => setBit(&st.refresh_flags, index_mod.REFRESH_UNMERGED, unset),
        .ignore_missing => setBit(&st.refresh_flags, index_mod.REFRESH_IGNORE_MISSING, unset),
        .add => allow_add = !unset,
        .replace => allow_replace = !unset,
        .remove => allow_remove = !unset,
        .info_only => info_only = !unset,
        .force_remove => force_remove = !unset,
        .verbose => verbose = !unset,
        .force_write_index => st.force_write = !unset,
        .ignore_skip_worktree_entries => ignore_skip_worktree_entries = !unset,
        .z => st.nul = !unset,
        .refresh => doRefresh(st, 0),
        .really_refresh => doRefresh(st, index_mod.REFRESH_REALLY),
        .cacheinfo => try cacheinfoCallback(st),
        .chmod => {
            const a = try getArg(st, o, short, unset);
            if (a.len != 2 or (a[0] != '-' and a[0] != '+') or a[1] != 'x')
                return fail("option 'chmod' expects \"+x\" or \"-x\"", .{});
            st.flip = a[0];
        },
        .assume_unchanged => mark_valid_only = .mark,
        .no_assume_unchanged => mark_valid_only = .unmark,
        .skip_worktree => mark_skip_worktree_only = .mark,
        .no_skip_worktree => mark_skip_worktree_only = .unmark,
        .fsmonitor_valid => mark_fsmonitor_only = .mark,
        .no_fsmonitor_valid => mark_fsmonitor_only = .unmark,
        .stdin => {
            if (st.i + 1 != st.args.len) return fail("option '{s}' must be the last argument", .{o.long});
            st.read_stdin = true;
        },
        .index_info => {
            if (st.i + 1 != st.args.len) return fail("option '{s}' must be the last argument", .{o.long});
            allow_add = true;
            allow_replace = true;
            allow_remove = true;
            readIndexInfo(st.nul);
        },
        .unresolve => {
            var err = false;
            for (st.args[st.i + 1 ..]) |p| {
                if (!idx.unmergeEntry(prefixed(p))) err = true;
            }
            st.has_errors = err;
            if (err) idx.changed = false;
            st.consumed_all = true;
        },
        .again => {
            _ = repo_mod.requireWorkTree("update-index");
            st.has_errors = doReupdate(st.args[st.i + 1 ..]);
            if (st.has_errors) idx.changed = false;
            st.consumed_all = true;
        },
        .clear_resolve_undo => {
            if (idx.reuc.items.len > 0) idx.changed = true;
            idx.reuc.clearRetainingCapacity();
        },
        .index_version => {
            if (unset) {
                st.preferred_version = 0;
                return;
            }
            const a = try getArg(st, o, short, unset);
            if (a.len == 0) return fail("{s} expects a numerical value", .{optName(o, short, unset)});
            const n = po.parseIntArg(a) orelse
                return fail("{s} expects an integer value with an optional k/m/g suffix", .{optName(o, short, unset)});
            if (n > std.math.maxInt(i32) or n < std.math.minInt(i32))
                return fail("value {s} for {s} not in range [{d},{d}]", .{ a, optName(o, short, unset), std.math.minInt(i32), std.math.maxInt(i32) });
            st.preferred_version = @intCast(n);
        },
        .show_index_version => st.preferred_version = if (unset) 0 else -1,
        .split_index => st.split_index = if (unset) 0 else 1,
        .untracked_cache => st.untracked_cache = if (unset) UC_DISABLE else UC_ENABLE,
        .test_untracked_cache => st.untracked_cache = if (unset) 0 else UC_TEST,
        .force_untracked_cache => st.untracked_cache = if (unset) 0 else UC_FORCE,
        .fsmonitor => st.fsmonitor = if (unset) 0 else 1,
    }
}

fn setBit(v: *u32, b: u32, unset: bool) void {
    if (unset) v.* &= ~b else v.* |= b;
}

const Abbrev = struct { o: ?*const UOpt = null, unset: bool = false };

fn registerAbbrev(o: *const UOpt, unset: bool, abbrev: *Abbrev, ambiguous: *Abbrev) void {
    if (abbrev.o != null) ambiguous.* = abbrev.*;
    abbrev.* = .{ .o = o, .unset = unset };
}

const LongResult = enum { done, unknown };

fn parseLong(st: *State, arg: []const u8) ParseError!LongResult {
    const arg_end = std.mem.indexOfScalar(u8, arg, '=') orelse arg.len;
    var start = arg;
    var unset_flag = false;
    var no_no = false;
    if (util.skipPrefix(start, "no-")) |r| {
        start = r;
        if (util.skipPrefix(start, "no-")) |r2| {
            start = r2;
            no_no = true;
        } else unset_flag = true;
    }
    var abbrev = Abbrev{};
    var ambiguous = Abbrev{};
    const start_off = arg.len - start.len;
    for (&uopts) |*o| {
        if (o.long.len == 0) continue;
        var long_name = o.long;
        var opt_unset = false;
        const allow_unset = !o.noneg;
        if (util.skipPrefix(long_name, "no-")) |r| {
            long_name = r;
            opt_unset = true;
        } else if (no_no) continue;
        if (unset_flag != opt_unset and !allow_unset) continue;
        if (std.mem.startsWith(u8, start, long_name)) {
            const rest = start[long_name.len..];
            if (rest.len > 0 and rest[0] == '=') {
                st.opt = rest[1..];
            } else if (rest.len > 0) continue;
            try getValue(st, o, false, unset_flag != opt_unset);
            return .done;
        }
        const alen = if (arg_end >= start_off) arg_end - start_off else 0;
        if (alen <= long_name.len and std.mem.eql(u8, long_name[0..alen], start[0..alen]))
            registerAbbrev(o, unset_flag != opt_unset, &abbrev, &ambiguous);
        if (allow_unset and std.mem.startsWith(u8, "no-", arg))
            registerAbbrev(o, !opt_unset, &abbrev, &ambiguous);
    }
    if (ambiguous.o) |amb| {
        util.err("ambiguous option: {s} (could be --{s}{s} or --{s}{s})", .{
            arg,
            if (ambiguous.unset) "no-" else "",
            amb.long,
            if (abbrev.unset) "no-" else "",
            abbrev.o.?.long,
        });
        po.usageExit(&usage, &usage_opts, true);
    }
    if (abbrev.o) |ab| {
        if (arg_end < arg.len) st.opt = arg[arg_end + 1 ..];
        try getValue(st, ab, false, abbrev.unset);
        return .done;
    }
    return .unknown;
}

fn findShort(ch: u8) ?*const UOpt {
    for (&uopts) |*o| {
        if (o.short != 0 and o.short == ch) return o;
    }
    return null;
}

/// check_typos(): "-add" probably meant "--add"
fn checkTypos(arg: []const u8) void {
    if (arg.len < 3) return;
    if (std.mem.startsWith(u8, arg, "no-")) {
        util.err("did you mean `--{s}` (with two dashes)?", .{arg});
        os.exit(129);
    }
    for (&uopts) |*o| {
        if (o.long.len == 0) continue;
        if (std.mem.startsWith(u8, o.long, arg)) {
            util.err("did you mean `--{s}` (with two dashes)?", .{arg});
            os.exit(129);
        }
    }
}

fn unknownSwitch(ch: u8) noreturn {
    if (ch == 'h') po.usageExit(&usage, &usage_opts, false);
    util.err("unknown switch '{c}'", .{ch});
    po.usageExit(&usage, &usage_opts, true);
}

fn parseShortCluster(st: *State, arg: []const u8) ParseError!void {
    st.opt = arg[1..];
    var first = true;
    while (st.opt) |rest| {
        const o = findShort(rest[0]) orelse {
            if (first) checkTypos(arg[1..]);
            unknownSwitch(rest[0]);
        };
        st.opt = if (rest.len > 1) rest[1..] else null;
        try getValue(st, o, true, false);
        if (st.consumed_all) {
            st.opt = null;
            return;
        }
        if (first and st.opt != null) checkTypos(arg[1..]);
        first = false;
    }
}

fn processPathArg(st: *State, path: []const u8) void {
    _ = repo_mod.requireWorkTree("update-index");
    const p = prefixed(path);
    updateOne(p);
    if (st.flip != 0) chmodPath(st.flip, p);
}

fn checkNullOids() void {
    const allow = os.getenv("GIT_ALLOW_NULL_SHA1") != null and
        @import("../config.zig").configBool("GIT_ALLOW_NULL_SHA1", os.getenv("GIT_ALLOW_NULL_SHA1"));
    var bad = false;
    for (idx.entries.items) |*e| {
        if (e.removed) continue;
        if (!hash.isZero(e.oid)) continue;
        if (allow) {
            util.warn("cache entry has null sha1: {s}", .{e.path});
        } else {
            util.err("cache entry has null sha1: {s}", .{e.path});
            bad = true;
        }
    }
    if (bad) util.die("Unable to write new index file", .{});
}

pub fn cmdUpdateIndex(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all")))
        po.usageExit(&usage, &usage_opts, false);
    po.checkGitcomp(args[1..], &usage_opts);
    idx = index_mod.lockAndRead();
    assume_unchanged = repo_mod.cfg.getBoolDefault("core.ignorestat", false);

    var st = State{ .args = args[1..] };
    var done_opts = false;
    while (st.i < st.args.len) : (st.i += 1) {
        const a = st.args[st.i];
        st.opt = null;
        if (done_opts or a.len < 2 or a[0] != '-') {
            processPathArg(&st, a);
            continue;
        }
        if (a[1] != '-') {
            parseShortCluster(&st, a) catch os.exit(129);
        } else if (a.len == 2 or util.eql(a, "--end-of-options")) {
            done_opts = true;
            continue;
        } else if (util.eql(a, "--help-all") or util.eql(a, "--help")) {
            po.usageExit(&usage, &usage_opts, false);
        } else {
            const res = parseLong(&st, a[2..]) catch os.exit(129);
            if (res == .unknown) {
                util.err("unknown option '{s}'", .{a[2..]});
                po.usageExit(&usage, &usage_opts, true);
            }
        }
        if (st.consumed_all) break;
    }

    if (st.preferred_version != 0) {
        if (st.preferred_version < 0) {
            util.outf("{d}\n", .{idx.version});
        } else if (st.preferred_version < 2 or st.preferred_version > 4) {
            util.die("index-version {d} not in range: 2..4", .{st.preferred_version});
        } else {
            if (idx.version != st.preferred_version) {
                idx.changed = true;
                idx.something_changed = true;
            }
            report("index-version: was {d}, set to {d}", .{ idx.version, st.preferred_version });
            idx.version = @intCast(st.preferred_version);
            idx.loaded_from_disk = true;
        }
    }

    if (st.read_stdin) {
        _ = repo_mod.requireWorkTree("update-index");
        for (readLines(st.nul)) |line0| {
            var line = line0;
            if (!st.nul and line.len > 0 and line[0] == '"') {
                const uq = util.cunquote(line) orelse util.die("line is badly quoted", .{});
                line = uq.value;
            }
            const p = prefixed(line);
            updateOne(p);
            if (st.flip != 0) chmodPath(st.flip, p);
        }
    }

    if (st.split_index > 0) {
        if (repo_mod.cfg.getBool("core.splitindex")) |b| {
            if (!b) util.warn("core.splitIndex is set to false; remove or change it, if you really want to enable split index", .{});
        }
        if (idx.split != null) idx.split_ordered = true else idx.addSplitIndex();
        idx.changed = true;
    } else if (st.split_index == 0) {
        if (repo_mod.cfg.getBool("core.splitindex")) |b| {
            if (b) util.warn("core.splitIndex is set to true; remove or change it, if you really want to disable split index", .{});
        }
        idx.removeSplitIndex();
    }

    switch (st.untracked_cache) {
        UC_DISABLE => {
            if (repo_mod.cfg.getBool("core.untrackedcache") orelse false)
                util.warn("core.untrackedCache is set to true; remove or change it, if you really want to disable the untracked cache", .{});
            report("Untracked cache disabled", .{});
        },
        UC_TEST => {
            _ = repo_mod.requireWorkTree("update-index");
            idx.rollback();
            return 0;
        },
        UC_ENABLE, UC_FORCE => {
            if (repo_mod.cfg.getBool("core.untrackedcache")) |b| {
                if (!b) util.warn("core.untrackedCache is set to false; remove or change it, if you really want to enable the untracked cache", .{});
            }
            report("Untracked cache enabled for '{s}'", .{repo_mod.repo().work_tree orelse ""});
        },
        else => {},
    }

    if (st.fsmonitor > 0) {
        if (repo_mod.cfg.get("core.fsmonitor") == null)
            util.warn("core.fsmonitor is unset; set it if you really want to enable fsmonitor", .{});
        report("fsmonitor enabled", .{});
    } else if (st.fsmonitor == 0) {
        if (repo_mod.cfg.getBool("core.fsmonitor") orelse false)
            util.warn("core.fsmonitor is set; remove it if you really want to disable fsmonitor", .{});
        report("fsmonitor disabled", .{});
    }

    if (idx.changed or st.force_write) {
        checkNullOids();
        idx.write();
    } else {
        idx.rollback();
    }
    return if (st.has_errors) 1 else 0;
}

const CacheInfo = struct { mode: u32, oid: Oid, path: []const u8 };

fn parseNewStyle(arg: []const u8) ?CacheInfo {
    const m = parseOctalPrefix(arg) orelse return null;
    if (m.end >= arg.len or arg[m.end] != ',') return null;
    const rest = arg[m.end + 1 ..];
    if (rest.len < 41 or rest[40] != ',') return null;
    const oid = hash.fromHex(rest[0..40]) orelse return null;
    return .{ .mode = m.v, .oid = oid, .path = rest[41..] };
}
