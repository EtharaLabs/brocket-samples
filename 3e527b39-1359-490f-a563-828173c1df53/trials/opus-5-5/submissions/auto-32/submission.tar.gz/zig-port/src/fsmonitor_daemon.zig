//! git fsmonitor--daemon (Linux/inotify backend) plus the simple-IPC
//! client used by `core.fsmonitor=true`.
//!
//! Port of builtin/fsmonitor--daemon.c, fsmonitor-ipc.c,
//! fsmonitor-settings.c, compat/fsmonitor/fsm-{listen,health,path-utils}-linux.c,
//! compat/fsmonitor/fsm-{ipc,settings}-unix.c and
//! compat/simple-ipc/ipc-unix-socket.c (+ unix-socket.c, unix-stream-server.c).
//!
//! The daemon is single threaded: one poll() loop multiplexes the listening
//! socket and the inotify fd.  Client requests are served one at a time; the
//! "cookie" handshake is done by draining inotify inline until the cookie
//! file event is seen (or 1s elapses), which gives the same observable
//! behaviour as the threaded C implementation.
//!
//! Public client API (used by src/fsmonitor.zig):
//!   ipcQuery(allocator, git_dir, last_token) ?QueryResult
//!   ipcGetState() IpcState
//!   checkIncompatible(ipc) Reason / incompatibleMsg(reason)

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const po = @import("parseopt.zig");
const repo_mod = @import("repo.zig");
const trace = @import("trace.zig");
const hash = @import("hash.zig");
const gpa = util.gpa;

// ---------------------------------------------------------------- libc

const SockaddrUn = extern struct {
    family: u16 = 1,
    path: [108]u8 = @splat(0),
};
const PollFd = extern struct {
    fd: c_int,
    events: i16,
    revents: i16 = 0,
};
const InotifyEvent = extern struct {
    wd: c_int,
    mask: u32,
    cookie: u32,
    len: u32,
};
const Timeval = extern struct { sec: i64, usec: i64 };

extern "c" fn socket(domain: c_int, ty: c_int, proto: c_int) c_int;
extern "c" fn bind(fd: c_int, addr: *const SockaddrUn, len: u32) c_int;
extern "c" fn connect(fd: c_int, addr: *const SockaddrUn, len: u32) c_int;
extern "c" fn listen(fd: c_int, backlog: c_int) c_int;
extern "c" fn accept(fd: c_int, addr: ?*anyopaque, len: ?*u32) c_int;
extern "c" fn setsockopt(fd: c_int, level: c_int, name: c_int, val: *const anyopaque, len: u32) c_int;
extern "c" fn poll(fds: [*]PollFd, n: c_ulong, timeout: c_int) c_int;
extern "c" fn read(fd: c_int, buf: [*]u8, n: usize) isize;
extern "c" fn write(fd: c_int, buf: [*]const u8, n: usize) isize;
extern "c" fn close(fd: c_int) c_int;
extern "c" fn open(path: [*:0]const u8, flags: c_int, ...) c_int;
extern "c" fn unlink(path: [*:0]const u8) c_int;
extern "c" fn fchdir(fd: c_int) c_int;
extern "c" fn chdir(path: [*:0]const u8) c_int;
extern "c" fn inotify_init1(flags: c_int) c_int;
extern "c" fn inotify_add_watch(fd: c_int, path: [*:0]const u8, mask: u32) c_int;
extern "c" fn inotify_rm_watch(fd: c_int, wd: c_int) c_int;
extern "c" fn statfs(path: [*:0]const u8, buf: *[16]i64) c_int;
extern "c" fn setsid() c_int;
extern "c" fn fork() c_int;
extern "c" fn execv(file: [*:0]const u8, argv: [*:null]const ?[*:0]const u8) c_int;
extern "c" fn waitpid(pid: c_int, status: *c_int, options: c_int) c_int;
extern "c" fn getpid() c_int;
extern "c" fn usleep(us: c_uint) c_int;
extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn _exit(code: c_int) noreturn;
extern "c" fn gettimeofday(tv: *Timeval, tz: ?*anyopaque) c_int;
extern "c" fn time(t: ?*i64) i64;

const ENOENT = 2;
const EINTR = 4;
const EAGAIN = 11;
const EEXIST = 17;
const ENOTDIR = 20;
const EINVAL = 22;
const ENOSPC = 28;
const EADDRINUSE = 98;
const ETIMEDOUT = 110;
const ECONNREFUSED = 111;

const POLLIN: i16 = 1;

const IN_ACCESS: u32 = 0x1;
const IN_MODIFY: u32 = 0x2;
const IN_ATTRIB: u32 = 0x4;
const IN_CLOSE_WRITE: u32 = 0x8;
const IN_CLOSE_NOWRITE: u32 = 0x10;
const IN_CLOSE: u32 = 0x18;
const IN_OPEN: u32 = 0x20;
const IN_MOVED_FROM: u32 = 0x40;
const IN_MOVED_TO: u32 = 0x80;
const IN_MOVE: u32 = 0xc0;
const IN_CREATE: u32 = 0x100;
const IN_DELETE: u32 = 0x200;
const IN_DELETE_SELF: u32 = 0x400;
const IN_MOVE_SELF: u32 = 0x800;
const IN_UNMOUNT: u32 = 0x2000;
const IN_Q_OVERFLOW: u32 = 0x4000;
const IN_IGNORED: u32 = 0x8000;
const IN_ONLYDIR: u32 = 0x01000000;
const IN_MASK_CREATE: u32 = 0x10000000;
const IN_ISDIR: u32 = 0x40000000;
const IN_ALL_EVENTS: u32 = 0xfff;

fn errno() c_int {
    return os.errno();
}

fn sleepMs(ms: u32) void {
    _ = usleep(ms * 1000);
}

pub var trace_fsmonitor = trace.Key{ .name = "GIT_TRACE_FSMONITOR" };

fn tr(comptime f: []const u8, args: anytype) void {
    trace.printf(&trace_fsmonitor, "fsmonitor--daemon.c", 0, f, args);
}

// ---------------------------------------------------------------- path utils (fsm-path-utils-linux.c)

const FsInfo = struct { is_remote: bool, typename: []const u8 };

fn isRemoteFsType(t: u64) bool {
    return switch (t) {
        0xff534d42, 0x517b, 0xfe534d42, 0x6969, 0x5346414f, 0x73757245, 0x65735546 => true,
        else => false,
    };
}

fn fsTypename(t: u64) []const u8 {
    return switch (t) {
        0xff534d42 => "cifs",
        0x517b => "smb",
        0xfe534d42 => "smb2",
        0x6969 => "nfs",
        0x5346414f => "afs",
        0x73757245 => "coda",
        0x65735546 => "fuse",
        else => "unknown",
    };
}

fn findMount(path: []const u8, fsid: [2]i64) ?[]const u8 {
    _ = fsid;
    const data = os.readFile("/proc/mounts") orelse return null;
    var best_len: usize = 0;
    var best: ?[]const u8 = null;
    var it = std.mem.splitScalar(u8, data, '\n');
    var self_buf: [16]i64 = undefined;
    if (statfs(os.z(path), &self_buf) != 0) return null;
    while (it.next()) |line| {
        var f = std.mem.splitScalar(u8, line, ' ');
        _ = f.next() orelse continue;
        const mp = f.next() orelse continue;
        const ty = f.next() orelse continue;
        if (!util.startsWith(path, mp)) continue;
        if (!(path.len == mp.len or path[mp.len] == '/' or util.eql(mp, "/"))) continue;
        var mbuf: [16]i64 = undefined;
        if (statfs(os.z(mp), &mbuf) != 0) continue;
        // f_fsid is at byte offset 56 (index 7) on x86_64
        if (mbuf[7] != self_buf[7]) continue;
        if (mp.len > best_len or best == null) {
            best_len = mp.len;
            best = ty;
        }
    }
    return best;
}

fn getFsInfo(path: []const u8) ?FsInfo {
    var buf: [16]i64 = undefined;
    if (statfs(os.z(path), &buf) == -1) {
        tr("statfs('{s}') failed: {s}", .{ path, os.lastErr() });
        return null;
    }
    const t: u64 = @bitCast(buf[0]);
    tr("statfs('{s}') [type 0x{x:0>8}]", .{ path, t });
    const abs = if (path.len > 0 and path[0] == '/') path else (os.realPath(path) orelse path);
    const name = findMount(abs, .{ 0, 0 }) orelse fsTypename(t);
    const info = FsInfo{ .is_remote = isRemoteFsType(t), .typename = name };
    tr("'{s}' is_remote: {d}, typename: {s}", .{ path, @intFromBool(info.is_remote), info.typename });
    return info;
}

/// fsmonitor__is_fs_remote(): 1 remote, 0 local, -1 error
fn isFsRemote(path: []const u8) i32 {
    const i = getFsInfo(path) orelse return -1;
    return @intFromBool(i.is_remote);
}

// ---------------------------------------------------------------- settings (fsmonitor-settings.c)

pub const Reason = enum { untested, ok, bare, err, remote, vfs4git, nosockets };

fn worktree() ?[]const u8 {
    const r = repo_mod.repo_ orelse return null;
    return r.work_tree;
}

fn checkRemote() Reason {
    const wt = worktree() orelse return .ok;
    switch (isFsRemote(wt)) {
        0 => return .ok,
        1 => {
            const allow = repo_mod.cfg.getBool("fsmonitor.allowremote") orelse false;
            return if (allow) .ok else .remote;
        },
        else => return .err,
    }
}

fn checkUdsVolume() Reason {
    const p = ipcPath();
    const info = getFsInfo(cDirname(p)) orelse return .err;
    if (info.is_remote or util.eql(info.typename, "msdos") or util.eql(info.typename, "ntfs"))
        return .nosockets;
    return .ok;
}

/// check_for_incompatible()
pub fn checkIncompatible(ipc: bool) Reason {
    if (worktree() == null) return .bare;
    const r = checkRemote();
    if (r != .ok) return r;
    if (ipc) {
        const u = checkUdsVolume();
        if (u != .ok) return u;
    }
    return .ok;
}

/// fsm_settings__get_incompatible_msg()
pub fn incompatibleMsg(reason: Reason) []const u8 {
    const wt = worktree() orelse "(null)";
    return switch (reason) {
        .untested, .ok => "",
        .bare => util.fmt("bare repository '{s}' is incompatible with fsmonitor", .{os.getcwd()}),
        .err => util.fmt("repository '{s}' is incompatible with fsmonitor due to errors", .{wt}),
        .remote => util.fmt("remote repository '{s}' is incompatible with fsmonitor", .{wt}),
        .vfs4git => util.fmt("virtual repository '{s}' is incompatible with fsmonitor", .{wt}),
        .nosockets => util.fmt("socket directory '{s}' is incompatible with fsmonitor due to lack of Unix sockets support", .{cDirname(ipcPath())}),
    };
}

fn cDirname(p: []const u8) []const u8 {
    var s = p;
    while (s.len > 1 and s[s.len - 1] == '/') s = s[0 .. s.len - 1];
    const i = std.mem.lastIndexOfScalar(u8, s, '/') orelse return ".";
    if (i == 0) return "/";
    return s[0..i];
}

// ---------------------------------------------------------------- ipc path (fsm-ipc-unix.c)

var ipc_path_cache: ?[]const u8 = null;

/// fsmonitor_ipc__get_path()
pub fn ipcPath() []const u8 {
    if (ipc_path_cache) |p| return p;
    const r = repo_mod.repo();
    if (isFsRemote(r.git_dir) < 1) {
        ipc_path_cache = r.gitPath("fsmonitor--daemon.ipc");
        return ipc_path_cache.?;
    }
    var h = hash.Hasher.init(.{});
    h.update(r.work_tree orelse "");
    var digest: [20]u8 = undefined;
    h.final(&digest);
    const hx = hash.hex(digest);
    const sock_dir = repo_mod.cfg.get("fsmonitor.socketdir");
    const file = if (sock_dir != null and sock_dir.?.len > 0)
        util.fmt("{s}/.git-fsmonitor-{s}", .{ sock_dir.?, &hx })
    else
        util.fmt("~/.git-fsmonitor-{s}", .{&hx});
    ipc_path_cache = interpolateHome(file) orelse util.die("Invalid path: {s}", .{file});
    return ipc_path_cache.?;
}

fn interpolateHome(p: []const u8) ?[]const u8 {
    if (!util.startsWith(p, "~")) return p;
    if (p.len == 1 or p[1] == '/') {
        const home = os.getenv("HOME") orelse return null;
        return util.concat(&.{ home, p[1..] });
    }
    return p; // ~user not supported
}

// ---------------------------------------------------------------- unix sockets (unix-socket.c)

/// Fill sockaddr; for long paths chdir into the directory (returns the fd
/// to fchdir back to, or -1).
fn prepSockaddr(path: []const u8, sa: *SockaddrUn, saved_cwd: *c_int) bool {
    saved_cwd.* = -1;
    var p = path;
    if (p.len >= sa.path.len) {
        const dir = cDirname(p);
        saved_cwd.* = open(".", os.O_RDONLY);
        if (saved_cwd.* < 0) return false;
        if (chdir(os.z(dir)) != 0) {
            _ = close(saved_cwd.*);
            saved_cwd.* = -1;
            return false;
        }
        p = util.basename(p);
        if (p.len >= sa.path.len) {
            os.setErrno(36); // ENAMETOOLONG
            return false;
        }
    }
    @memcpy(sa.path[0..p.len], p);
    sa.path[p.len] = 0;
    return true;
}

fn restoreCwd(fd: c_int) void {
    if (fd < 0) return;
    const e = errno();
    if (fchdir(fd) != 0) util.die("unable to restore original working directory", .{});
    _ = close(fd);
    os.setErrno(e);
}

fn unixStreamConnect(path: []const u8) c_int {
    var sa = SockaddrUn{};
    var saved: c_int = -1;
    if (!prepSockaddr(path, &sa, &saved)) {
        restoreCwd(saved);
        return -1;
    }
    const fd = socket(1, 1 | os.O_CLOEXEC, 0);
    if (fd < 0) {
        restoreCwd(saved);
        return -1;
    }
    if (connect(fd, &sa, @sizeOf(SockaddrUn)) < 0) {
        const e = errno();
        _ = close(fd);
        restoreCwd(saved);
        os.setErrno(e);
        return -1;
    }
    restoreCwd(saved);
    return fd;
}

fn unixStreamListen(path: []const u8, backlog: c_int) c_int {
    _ = unlink(os.z(path));
    var sa = SockaddrUn{};
    var saved: c_int = -1;
    if (!prepSockaddr(path, &sa, &saved)) {
        restoreCwd(saved);
        return -1;
    }
    const fd = socket(1, 1 | os.O_CLOEXEC, 0);
    if (fd < 0) {
        restoreCwd(saved);
        return -1;
    }
    if (bind(fd, &sa, @sizeOf(SockaddrUn)) < 0 or listen(fd, backlog) < 0) {
        const e = errno();
        _ = close(fd);
        restoreCwd(saved);
        os.setErrno(e);
        return -1;
    }
    restoreCwd(saved);
    return fd;
}

// ---------------------------------------------------------------- simple-ipc client

pub const IpcState = enum { listening, not_listening, invalid_path, path_not_found, other_error };

const ConnectOpts = struct { wait_if_busy: bool = false, wait_if_not_found: bool = false };

fn connectToServer(path: []const u8, timeout_ms: u32, o: ConnectOpts, pfd: *c_int) IpcState {
    pfd.* = -1;
    var k: u32 = 0;
    while (k < timeout_ms) : (k += 50) {
        const fd = unixStreamConnect(path);
        if (fd != -1) {
            pfd.* = fd;
            return .listening;
        }
        const e = errno();
        if (e == ENOENT) {
            if (!o.wait_if_not_found) return .path_not_found;
        } else if (e == ETIMEDOUT or e == ECONNREFUSED) {
            if (!o.wait_if_busy) return .not_listening;
        } else return .other_error;
        sleepMs(50);
    }
    return .not_listening;
}

fn tryConnect(path: []const u8, o: ConnectOpts, pfd: *c_int) IpcState {
    return connectToServer(path, 1000, o, pfd);
}

/// ipc_get_active_state()
fn ipcGetActiveState(path: []const u8) IpcState {
    const st = os.lstatPath(path) orelse {
        const e = errno();
        if (e == ENOENT or e == ENOTDIR) return .not_listening;
        return .invalid_path;
    };
    if ((st.mode & 0o170000) != 0o140000) return .invalid_path;
    var fd: c_int = -1;
    const s = tryConnect(path, .{}, &fd);
    if (fd >= 0) _ = close(fd);
    return s;
}

/// fsmonitor_ipc__get_state()
pub fn ipcGetState() IpcState {
    return ipcGetActiveState(ipcPath());
}

const LARGE_PACKET_MAX = 65520;
const LARGE_PACKET_DATA_MAX = LARGE_PACKET_MAX - 4;

fn writeAllFd(fd: c_int, data: []const u8) bool {
    var off: usize = 0;
    while (off < data.len) {
        const n = write(fd, data.ptr + off, data.len - off);
        if (n < 0) {
            if (errno() == EINTR or errno() == EAGAIN) continue;
            return false;
        }
        off += @intCast(n);
    }
    return true;
}

fn readExact(fd: c_int, dst: []u8) bool {
    var off: usize = 0;
    while (off < dst.len) {
        const n = read(fd, dst.ptr + off, dst.len - off);
        if (n < 0) {
            if (errno() == EINTR) continue;
            return false;
        }
        if (n == 0) return false;
        off += @intCast(n);
    }
    return true;
}

/// write_packetized_from_buf_no_flush()
fn writePacketized(fd: c_int, data: []const u8) bool {
    var off: usize = 0;
    while (off < data.len) {
        const n = @min(data.len - off, LARGE_PACKET_DATA_MAX);
        var hdr: [4]u8 = undefined;
        _ = std.fmt.bufPrint(&hdr, "{x:0>4}", .{n + 4}) catch unreachable;
        if (!writeAllFd(fd, &hdr)) return false;
        if (!writeAllFd(fd, data[off .. off + n])) return false;
        off += n;
    }
    return true;
}

fn packetFlush(fd: c_int) bool {
    return writeAllFd(fd, "0000");
}

/// read_packetized_to_strbuf(): returns null on error/EOF before flush.
fn readPacketized(fd: c_int) ?[]u8 {
    var b: util.Buf = .empty;
    while (true) {
        var hdr: [4]u8 = undefined;
        if (!readExact(fd, &hdr)) return null;
        const len = std.fmt.parseInt(usize, &hdr, 16) catch return null;
        if (len == 0) break;
        if (len < 4) return null;
        const start = b.items.len;
        b.resize(gpa, start + len - 4) catch util.oom();
        if (!readExact(fd, b.items[start..])) return null;
    }
    return b.items;
}

fn sendCommandToConnection(fd: c_int, msg: []const u8) ?[]u8 {
    _ = signal(13, 1);
    if (!writePacketized(fd, msg) or !packetFlush(fd)) {
        util.err("could not send IPC command", .{});
        return null;
    }
    return readPacketized(fd) orelse {
        util.err("could not read IPC response", .{});
        return null;
    };
}

fn spawnDaemonStart() bool {
    const r = os.run(&.{ gitBinary(), "fsmonitor--daemon", "start" }, .{ .no_stdin = true, .no_stderr = true, .capture_stdout = true, .trace2_class = "fsmonitor" });
    return r.status == 0 and !r.signaled;
}

fn gitBinary() []const u8 {
    return @import("proc.zig").gitBinary();
}

/// fsmonitor_ipc__send_query(): returns the raw answer or null on error.
pub fn ipcSendQuery(since_token: []const u8) ?[]u8 {
    var o = ConnectOpts{ .wait_if_busy = true, .wait_if_not_found = false };
    var tried = false;
    const path = ipcPath();
    while (true) {
        var fd: c_int = -1;
        switch (tryConnect(path, o, &fd)) {
            .listening => {
                const ans = sendCommandToConnection(fd, since_token);
                _ = close(fd);
                return ans;
            },
            .not_listening, .path_not_found => {
                if (tried) return null;
                tried = true;
                if (!spawnDaemonStart()) return null;
                o.wait_if_not_found = true;
            },
            .invalid_path => {
                util.err("fsmonitor_ipc__send_query: invalid path '{s}'", .{path});
                return null;
            },
            .other_error => {
                util.err("fsmonitor_ipc__send_query: unspecified error on '{s}'", .{path});
                return null;
            },
        }
    }
}

/// fsmonitor_ipc__send_command()
fn ipcSendCommand(command: []const u8) []u8 {
    var fd: c_int = -1;
    const st = tryConnect(ipcPath(), .{ .wait_if_busy = true }, &fd);
    if (st != .listening) util.die("fsmonitor--daemon is not running", .{});
    const ans = sendCommandToConnection(fd, command);
    _ = close(fd);
    return ans orelse util.die("could not send '{s}' command to fsmonitor--daemon", .{command});
}

pub const QueryResult = struct {
    token: []u8,
    trivial: bool,
    paths: [][]u8,
};

/// Query the builtin daemon (spawning it if needed) for changes since
/// `last_token` (pass "" when the index has no token; "builtin:fake" is
/// then used, like refresh_fsmonitor()).  Returns null when the daemon
/// could not be reached: the caller should then use the token
/// "builtin:fake" and invalidate everything.
pub fn ipcQuery(allocator: std.mem.Allocator, git_dir: []const u8, last_token: []const u8) !?QueryResult {
    _ = git_dir;
    const tok = if (last_token.len > 0) last_token else "builtin:fake";
    const ans = ipcSendQuery(tok) orelse return null;
    const nul = std.mem.indexOfScalar(u8, ans, 0) orelse ans.len;
    const token = try allocator.dupe(u8, ans[0..nul]);
    var paths: std.ArrayList([]u8) = .empty;
    var trivial = false;
    if (nul < ans.len) {
        const rest = ans[nul + 1 ..];
        if (rest.len > 0 and rest[0] == '/') {
            trivial = true;
        } else {
            var it = std.mem.splitScalar(u8, rest, 0);
            while (it.next()) |p| {
                if (p.len == 0) continue;
                try paths.append(allocator, try allocator.dupe(u8, p));
            }
        }
    } else trivial = true;
    return .{ .token = token, .trivial = trivial, .paths = paths.items };
}

// ---------------------------------------------------------------- daemon state

const Batch = struct {
    seq: u64 = 0,
    paths: std.ArrayList([]const u8) = .empty,
    pinned_time: i64 = 0,
};

const TokenData = struct {
    token_id: []const u8,
    /// oldest first; last element is the head
    batches: std.ArrayList(*Batch) = .empty,

    fn head(self: *TokenData) *Batch {
        return self.batches.items[self.batches.items.len - 1];
    }
    fn tail(self: *TokenData) *Batch {
        return self.batches.items[0];
    }
};

const Shutdown = enum { cont, stop, err, force };

const Cookie = struct { name: []const u8, result: CookieResult };
const CookieResult = enum(i32) { err = -1, init = 0, seen = 1, abort = 2 };

const Watch = struct { wd: c_int, cookie: u32 = 0, dir: []const u8 };
const RenameEntry = struct { whence: i64, cookie: u32, dir: []const u8 };

const State = struct {
    path_worktree_watch: []const u8 = "",
    path_gitdir_watch: []const u8 = "",
    nr_paths_watching: u32 = 1,
    path_cookie_prefix: []const u8 = "",
    path_ipc: []const u8 = "",
    token: *TokenData = undefined,
    cookie_seq: u32 = 0,
    cookies: std.ArrayList(*Cookie) = .empty,
    // listener
    fd_inotify: c_int = -1,
    shutdown: Shutdown = .err,
    listen_error_code: i32 = 0,
    watches: std.AutoHashMapUnmanaged(c_int, *Watch) = .empty,
    revwatches: std.StringHashMapUnmanaged(*Watch) = .empty,
    renames: std.AutoHashMapUnmanaged(u32, RenameEntry) = .empty,
    // server
    fd_listen: c_int = -1,
    sock_ino: u64 = 0,
    sock_dev: u64 = 0,
    quit: bool = false,
};

var st: State = .{};

var ipc_threads: i32 = 8;
var start_timeout_sec: i32 = 60;
var announce_startup: i64 = 0;

var test_env_value: i64 = -1;
var flush_count: u64 = 0;

fn newTokenData() *TokenData {
    const t = gpa.create(TokenData) catch util.oom();
    t.* = .{ .token_id = "" };
    const b = gpa.create(Batch) catch util.oom();
    b.* = .{};
    t.batches.append(gpa, b) catch util.oom();
    if (test_env_value < 0) {
        const v = os.getenv("GIT_TEST_FSMONITOR_TOKEN");
        test_env_value = if (v) |s| (if (@import("config.zig").parseBool(s)) |bv| @intFromBool(bv) else 0) else 0;
    }
    if (test_env_value == 0) {
        var tv: Timeval = undefined;
        _ = gettimeofday(&tv, null);
        const tm = os.gmtime(tv.sec);
        t.token_id = util.fmt("{d}.{d}.{d:>4}{d:0>2}{d:0>2}T{d:0>2}{d:0>2}{d:0>2}.{d:0>6}Z", .{
            flush_count, getpid(),
            @as(u32, @intCast(tm.year + 1900)), @as(u32, @intCast(tm.mon + 1)), @as(u32, @intCast(tm.mday)),
            @as(u32, @intCast(tm.hour)), @as(u32, @intCast(tm.min)), @as(u32, @intCast(tm.sec)),
            @as(u64, @intCast(tv.usec)),
        });
        flush_count += 1;
    } else {
        t.token_id = util.fmt("test_{x:0>8}", .{@as(u32, @intCast(test_env_value))});
        test_env_value += 1;
    }
    if (test_env_value != 0) b.pinned_time = time(null);
    return t;
}

fn batchAddPath(b: *Batch, path: []const u8) void {
    const p = util.dupe(path);
    tr("event: {s}", .{p});
    b.paths.append(gpa, p) catch util.oom();
}

fn abortAllCookies() void {
    for (st.cookies.items) |ck| {
        tr("cookie-abort: '{s}'", .{ck.name});
        ck.result = .abort;
    }
}

fn forceResync() void {
    st.token = newTokenData();
    abortAllCookies();
}

fn markCookiesSeen(names: []const []const u8) void {
    for (names) |n| {
        for (st.cookies.items) |ck| {
            if (util.eql(ck.name, n)) {
                tr("cookie-seen: '{s}'", .{ck.name});
                ck.result = .seen;
            }
        }
    }
}

const MY_COMBINE_LIMIT = 1024;

/// fsmonitor_publish()
fn publish(batch: ?*Batch, cookie_names: []const []const u8) void {
    if (batch) |b| {
        const t = st.token;
        const hd = t.head();
        if (hd.pinned_time != 0) {
            b.seq = hd.seq + 1;
            t.batches.append(gpa, b) catch util.oom();
        } else if (hd.seq == 0) {
            // batch 0 is unpinned: drop
        } else if (hd.paths.items.len + b.paths.items.len > MY_COMBINE_LIMIT) {
            b.seq = hd.seq + 1;
            t.batches.append(gpa, b) catch util.oom();
        } else {
            hd.paths.appendSlice(gpa, b.paths.items) catch util.oom();
        }
    }
    if (cookie_names.len > 0) markCookiesSeen(cookie_names);
}

const FSMONITOR_COOKIE_PREFIX = "fsmonitor--daemon/cookies/";

const PathType = enum { outside_cone, workdir_path, dot_git, inside_dot_git, inside_dot_git_with_cookie_prefix, gitdir, inside_gitdir, inside_gitdir_with_cookie_prefix };

fn classifyWorkdirRelative(rel0: []const u8) PathType {
    if (!util.startsWith(rel0, ".git")) return .workdir_path;
    var rel = rel0[4..];
    if (rel.len == 0) return .dot_git;
    if (rel[0] != '/') return .workdir_path;
    rel = rel[1..];
    if (util.startsWith(rel, FSMONITOR_COOKIE_PREFIX)) return .inside_dot_git_with_cookie_prefix;
    return .inside_dot_git;
}

fn classifyGitdirRelative(rel: []const u8) PathType {
    if (util.startsWith(rel, FSMONITOR_COOKIE_PREFIX)) return .inside_gitdir_with_cookie_prefix;
    return .inside_gitdir;
}

fn classifyAbsolute(path: []const u8) PathType {
    var t: PathType = .outside_cone;
    const w = st.path_worktree_watch;
    if (util.startsWith(path, w)) {
        const rel = path[w.len..];
        if (rel.len == 0) {
            t = .workdir_path;
        } else if (rel[0] == '/') {
            t = classifyWorkdirRelative(rel[1..]);
        }
    }
    if (st.nr_paths_watching == 1) return t;
    if (t != .outside_cone) return t;
    const g = st.path_gitdir_watch;
    if (!util.startsWith(path, g)) return .outside_cone;
    const rel = path[g.len..];
    if (rel.len == 0) return .gitdir;
    if (rel[0] != '/') return .outside_cone;
    return classifyGitdirRelative(rel[1..]);
}

// ---------------------------------------------------------------- inotify listener (fsm-listen-linux.c)

fn addWatch(path: []const u8) bool {
    const mask = (IN_ALL_EVENTS | IN_ONLYDIR | IN_MASK_CREATE) ^ IN_ACCESS ^ IN_CLOSE ^ IN_OPEN;
    const wd = inotify_add_watch(st.fd_inotify, os.z(path), mask);
    if (wd < 0) {
        const e = errno();
        if (e == ENOENT or e == ENOTDIR) return true;
        if (e == EEXIST) return true;
        if (e == ENOSPC) {
            util.err("inotify watch limit reached; increase fs.inotify.max_user_watches", .{});
            return false;
        }
        util.err("inotify_add_watch('{s}') failed: {s}", .{ path, os.lastErr() });
        return false;
    }
    const w = gpa.create(Watch) catch util.oom();
    w.* = .{ .wd = wd, .dir = util.dupe(path) };
    if (st.watches.fetchRemove(wd)) |old| _ = st.revwatches.remove(old.value.dir);
    st.watches.put(gpa, wd, w) catch util.oom();
    st.revwatches.put(gpa, w.dir, w) catch util.oom();
    return true;
}

fn removeWatch(w: *Watch) void {
    if (inotify_rm_watch(st.fd_inotify, w.wd) != 0 and errno() != EINVAL)
        util.err("inotify_rm_watch() failed: {s}", .{os.lastErr()});
    _ = st.watches.remove(w.wd);
    _ = st.revwatches.remove(w.dir);
}

fn checkStaleDirRenames(max_age: i64) bool {
    var it = st.renames.valueIterator();
    while (it.next()) |re| {
        if (re.whence <= max_age) return true;
    }
    return false;
}

fn addDirRename(cookie: u32, path: []const u8) void {
    const w = st.revwatches.get(path) orelse {
        tr("no watch found for rename from '{s}'", .{path});
        return;
    };
    w.cookie = cookie;
    st.renames.put(gpa, cookie, .{ .dir = w.dir, .cookie = cookie, .whence = time(null) }) catch util.oom();
}

fn renameDir(cookie: u32, path: []const u8) void {
    if (st.renames.get(cookie)) |re| {
        if (st.revwatches.get(re.dir)) |w| {
            w.cookie = 0;
            removeWatch(w);
            if (!addWatch(path)) tr("failed to add watch for renamed dir '{s}'", .{path});
        } else {
            tr("no matching watch for rename to '{s}'", .{path});
        }
        _ = st.renames.remove(cookie);
    } else {
        tr("no matching cookie for rename to '{s}'", .{path});
    }
}

/// Recursively add watches to every directory under path.
fn registerInotify(path: []const u8, batch: ?*Batch) bool {
    const entries = os.listDir(path) orelse {
        const e = errno();
        if (e == ENOENT or e == ENOTDIR) return true;
        util.err("opendir('{s}') failed: {s}", .{ path, os.lastErr() });
        return false;
    };
    for (entries) |de| {
        if (util.eql(de.name, ".") or util.eql(de.name, "..")) continue;
        const cur = util.concat(&.{ path, "/", de.name });
        const s = os.lstatPath(cur) orelse {
            if (errno() == ENOENT) continue;
            util.err("lstat('{s}') failed: {s}", .{ cur, os.lastErr() });
            return false;
        };
        if (s.isDir()) {
            if (!addWatch(cur)) return false;
            if (!registerInotify(cur, batch)) return false;
        } else if (batch) |b| {
            const rel = cur[st.path_worktree_watch.len + 1 ..];
            tr("explicitly adding '{s}'", .{rel});
            batchAddPath(b, rel);
        }
    }
    return true;
}

fn listenCtor() bool {
    st.listen_error_code = -1;
    st.shutdown = .err;
    const fd = inotify_init1(0o4000 | os.O_CLOEXEC);
    if (fd < 0) {
        util.err("inotify_init1() failed: {s}", .{os.lastErr()});
        return false;
    }
    st.fd_inotify = fd;
    var ok = addWatch(st.path_worktree_watch) and registerInotify(st.path_worktree_watch, null);
    if (ok and st.nr_paths_watching > 1)
        ok = addWatch(st.path_gitdir_watch) and registerInotify(st.path_gitdir_watch, null);
    if (ok) {
        st.listen_error_code = 0;
        st.shutdown = .cont;
    }
    return ok;
}

fn logMaskSet(path: []const u8, mask: u32) void {
    if (!trace.want(&trace_fsmonitor)) return;
    var b: util.Buf = .empty;
    const names = [_]struct { m: u32, n: []const u8 }{
        .{ .m = IN_ACCESS, .n = "IN_ACCESS|" },         .{ .m = IN_MODIFY, .n = "IN_MODIFY|" },
        .{ .m = IN_ATTRIB, .n = "IN_ATTRIB|" },         .{ .m = IN_CLOSE_WRITE, .n = "IN_CLOSE_WRITE|" },
        .{ .m = IN_CLOSE_NOWRITE, .n = "IN_CLOSE_NOWRITE|" }, .{ .m = IN_OPEN, .n = "IN_OPEN|" },
        .{ .m = IN_MOVED_FROM, .n = "IN_MOVED_FROM|" }, .{ .m = IN_MOVED_TO, .n = "IN_MOVED_TO|" },
        .{ .m = IN_CREATE, .n = "IN_CREATE|" },         .{ .m = IN_DELETE, .n = "IN_DELETE|" },
        .{ .m = IN_DELETE_SELF, .n = "IN_DELETE_SELF|" }, .{ .m = IN_MOVE_SELF, .n = "IN_MOVE_SELF|" },
        .{ .m = IN_UNMOUNT, .n = "IN_UNMOUNT|" },       .{ .m = IN_Q_OVERFLOW, .n = "IN_Q_OVERFLOW|" },
        .{ .m = IN_IGNORED, .n = "IN_IGNORED|" },       .{ .m = IN_ISDIR, .n = "IN_ISDIR|" },
    };
    for (names) |x| if (mask & x.m != 0) util.bufAppend(&b, x.n);
    if (b.items.len > 0) b.items.len -= 1;
    tr("inotify_event: '{s}', mask={s} {s}", .{ path, hexMask(mask), b.items });
}

fn hexMask(mask: u32) []const u8 {
    // printf("%#8.8x")
    if (mask == 0) return "00000000";
    return util.fmt("0x{x:0>8}", .{mask});
}

fn processEvent(path: []const u8, mask: u32, cookie: u32, batch: *?*Batch, cookie_list: *std.ArrayList([]const u8)) bool {
    switch (classifyAbsolute(path)) {
        .inside_dot_git_with_cookie_prefix, .inside_gitdir_with_cookie_prefix => {
            cookie_list.append(gpa, util.dupe(util.basename(path))) catch util.oom();
        },
        .inside_dot_git, .inside_gitdir => {},
        .dot_git, .gitdir => {
            if (mask & IN_ISDIR != 0 and mask & IN_DELETE != 0) {
                tr("event: gitdir removed", .{});
                st.shutdown = .force;
                return false;
            }
            if (mask & IN_ISDIR != 0 and mask & IN_MOVE != 0) {
                tr("event: gitdir renamed", .{});
                st.shutdown = .force;
                return false;
            }
        },
        .workdir_path => {
            logMaskSet(path, mask);
            if (batch.* == null) {
                const b = gpa.create(Batch) catch util.oom();
                b.* = .{};
                batch.* = b;
            }
            const rel = if (path.len > st.path_worktree_watch.len) path[st.path_worktree_watch.len + 1 ..] else "";
            batchAddPath(batch.*.?, rel);
            if (mask & IN_ISDIR != 0 and mask & IN_DELETE != 0) return true;
            if (mask & IN_ISDIR != 0 and mask & IN_MOVED_FROM != 0) addDirRename(cookie, path);
            if (mask & IN_ISDIR != 0 and mask & IN_MOVED_TO != 0) {
                renameDir(cookie, path);
                if (!registerInotify(path, batch.*)) {
                    st.shutdown = .err;
                    return false;
                }
            }
            if (mask & IN_ISDIR != 0 and mask & IN_CREATE != 0) {
                if (!addWatch(path) or !registerInotify(path, batch.*)) {
                    st.shutdown = .err;
                    return false;
                }
            }
        },
        .outside_cone => tr("ignoring '{s}'", .{path}),
    }
    return true;
}

fn handleEvents() void {
    var buf: [4096]u8 align(@alignOf(InotifyEvent)) = undefined;
    while (true) {
        const n = read(st.fd_inotify, &buf, buf.len);
        if (n == -1) {
            const e = errno();
            if (e == EAGAIN or e == EINTR) return;
            util.err("reading inotify message stream failed: {s}", .{os.lastErr()});
            st.shutdown = .err;
            return;
        }
        if (n == 0) return;
        const len: usize = @intCast(n);
        var batch: ?*Batch = null;
        var cookie_list: std.ArrayList([]const u8) = .empty;
        var off: usize = 0;
        while (off + @sizeOf(InotifyEvent) <= len) {
            const ev: *const InotifyEvent = @ptrCast(@alignCast(&buf[off]));
            const name_raw = buf[off + @sizeOf(InotifyEvent) .. off + @sizeOf(InotifyEvent) + ev.len];
            off += @sizeOf(InotifyEvent) + ev.len;
            const name = name_raw[0 .. std.mem.indexOfScalar(u8, name_raw, 0) orelse name_raw.len];
            const mask = ev.mask;
            if (mask & IN_IGNORED != 0 or mask & IN_MOVE_SELF != 0) continue;
            if (mask & IN_UNMOUNT != 0 or mask & IN_Q_OVERFLOW != 0) {
                logMaskSet("forcing shutdown", mask);
                st.shutdown = .force;
                return;
            }
            const w = st.watches.get(ev.wd) orelse continue;
            if (mask & IN_DELETE_SELF != 0) {
                removeWatch(w);
                continue;
            }
            const path = util.concat(&.{ w.dir, "/", name });
            if (!processEvent(path, mask, ev.cookie, &batch, &cookie_list)) return;
        }
        publish(batch, cookie_list.items);
    }
}

// ---------------------------------------------------------------- server

/// with_lock__wait_for_cookie()
fn waitForCookie() CookieResult {
    const seq = st.cookie_seq;
    st.cookie_seq += 1;
    const name = util.fmt("{d}-{d}", .{ getpid(), seq });
    const pathname = util.concat(&.{ st.path_cookie_prefix, name });
    const ck = gpa.create(Cookie) catch util.oom();
    ck.* = .{ .name = name, .result = .init };
    st.cookies.append(gpa, ck) catch util.oom();
    defer {
        for (st.cookies.items, 0..) |x, i| {
            if (x == ck) {
                _ = st.cookies.orderedRemove(i);
                break;
            }
        }
    }
    tr("cookie-wait: '{s}' '{s}'", .{ name, pathname });
    const fd = open(os.z(pathname), os.O_WRONLY | os.O_CREAT | os.O_EXCL, @as(c_uint, 0o600));
    if (fd < 0) {
        util.err("could not create fsmonitor cookie '{s}': {s}", .{ name, os.lastErr() });
        return .err;
    }
    _ = close(fd);
    _ = unlink(os.z(pathname));

    const deadline = os.nowMicros() + 1_000_000;
    while (ck.result == .init and st.shutdown == .cont) {
        const now = os.nowMicros();
        if (now >= deadline) break;
        var pfd = [1]PollFd{.{ .fd = st.fd_inotify, .events = POLLIN }};
        const ms: c_int = @intCast(@max(1, @divFloor(deadline - now, 1000)));
        const r = poll(&pfd, 1, ms);
        if (r > 0 and (pfd[0].revents & POLLIN) != 0) handleEvents();
    }
    if (ck.result == .init) {
        if (st.shutdown != .cont) {
            ck.result = .abort;
        } else {
            tr("cookie_wait timed out", .{});
            ck.result = .err;
        }
    }
    return ck.result;
}

fn parseClientToken(tok: []const u8, id: *[]const u8, seq: *u64) bool {
    id.* = "";
    seq.* = 0;
    if (!util.startsWith(tok, "builtin:")) return false;
    const p = tok["builtin:".len..];
    const colon = std.mem.indexOfScalar(u8, p, ':') orelse return false;
    id.* = p[0..colon];
    const num = p[colon + 1 ..];
    // strtoumax: leading digits; trailing garbage => error; empty => 0
    var i: usize = 0;
    var v: u64 = 0;
    while (i < num.len and std.ascii.isDigit(num[i])) : (i += 1) v = v *% 10 +% (num[i] - '0');
    if (i != num.len) return false;
    seq.* = v;
    return true;
}

const MY_TIME_DELAY_SECONDS = 5 * 60;

/// Returns true if this is a quit request.
fn doHandleClient(fd: c_int, command: []const u8) bool {
    var do_trivial = false;
    var do_flush = false;
    var do_cookie = false;
    var req_id: []const u8 = "";
    var req_seq: u64 = 0;

    if (util.eql(command, "quit")) {
        return true;
    } else if (util.eql(command, "flush")) {
        do_flush = true;
        do_trivial = true;
    } else if (!util.startsWith(command, "builtin:")) {
        var i: usize = 0;
        while (i < command.len and std.ascii.isDigit(command[i])) i += 1;
        if (i < command.len) {
            tr("fsmonitor: invalid command line '{s}'", .{command});
        } else {
            tr("fsmonitor: unsupported V1 protocol '{s}'", .{command});
        }
        do_trivial = true;
        do_cookie = true;
    } else {
        if (!parseClientToken(command, &req_id, &req_seq)) {
            tr("fsmonitor: invalid V2 protocol token '{s}'", .{command});
            do_trivial = true;
        }
        do_cookie = true;
    }

    if (do_cookie) {
        const cr = waitForCookie();
        if (cr != .seen) {
            util.err("fsmonitor: cookie_result '{d}' != SEEN", .{@intFromEnum(cr)});
            do_trivial = true;
        }
    }
    if (do_flush) forceResync();

    const td = st.token;
    const bh = td.head();
    bh.pinned_time = time(null);
    const resp_token = util.fmt("builtin:{s}:{d}", .{ td.token_id, bh.seq });
    var tb: util.Buf = .empty;
    util.bufAppend(&tb, resp_token);
    util.bufByte(&tb, 0);
    _ = writePacketized(fd, tb.items);
    tr("response token: {s}", .{resp_token});

    if (!do_trivial) {
        if (!util.eql(req_id, td.token_id)) {
            do_trivial = true;
        } else if (req_seq < td.tail().seq) {
            tr("client requested truncated data", .{});
            do_trivial = true;
        }
    }
    if (do_trivial) {
        _ = writePacketized(fd, "/\x00");
        return false;
    }

    var shown: std.StringHashMapUnmanaged(void) = .empty;
    var payload: util.Buf = .empty;
    var count: usize = 0;
    var idx: usize = td.batches.items.len;
    var stop_at: ?usize = null;
    while (idx > 0) {
        idx -= 1;
        const b = td.batches.items[idx];
        if (b.seq <= req_seq) {
            stop_at = idx;
            break;
        }
        for (b.paths.items) |s| {
            const gop = shown.getOrPut(gpa, s) catch util.oom();
            if (gop.found_existing) continue;
            tr("send[{d}]: {s}", .{ count, s });
            if (payload.items.len + s.len + 1 >= LARGE_PACKET_DATA_MAX) {
                _ = writePacketized(fd, payload.items);
                payload.clearRetainingCapacity();
            }
            util.bufAppend(&payload, s);
            util.bufByte(&payload, 0);
            count += 1;
        }
    }
    if (payload.items.len > 0) _ = writePacketized(fd, payload.items);

    // truncate old batches
    if (stop_at) |mi| {
        const marker = td.batches.items[mi];
        tr("Truncate: mark ({d},{d})", .{ marker.seq, marker.pinned_time });
        var j: usize = mi + 1;
        while (j > 0) {
            j -= 1;
            const b = td.batches.items[j];
            if (b.pinned_time == 0) continue;
            if (b.pinned_time + MY_TIME_DELAY_SECONDS > marker.pinned_time) continue;
            // keep j as new tail; drop everything older
            if (j > 0) {
                const rest = td.batches.items[j..];
                std.mem.copyForwards(*Batch, td.batches.items[0..rest.len], rest);
                td.batches.items.len = rest.len;
            }
            break;
        }
    }
    return false;
}

fn handleConnection(fd: c_int) void {
    // avoid hanging forever on a client that never sends anything
    const tv = Timeval{ .sec = 5, .usec = 0 };
    _ = setsockopt(fd, 1, 20, &tv, @sizeOf(Timeval)); // SO_RCVTIMEO
    _ = setsockopt(fd, 1, 21, &tv, @sizeOf(Timeval)); // SO_SNDTIMEO
    const cmd = readPacketized(fd) orelse {
        _ = close(fd);
        return;
    };
    // the request is a NUL-free text message
    const command = cmd[0 .. std.mem.indexOfScalar(u8, cmd, 0) orelse cmd.len];
    tr("requested token: {s}", .{command});
    const quit = doHandleClient(fd, command);
    _ = packetFlush(fd);
    _ = close(fd);
    if (quit) st.quit = true;
}

fn socketWasStolen() bool {
    const s = os.lstatPath(st.path_ipc) orelse return true;
    if (s.ino != st.sock_ino or s.dev != st.sock_dev) return true;
    if ((s.mode & 0o170000) != 0o140000) return true;
    return false;
}

/// unix_ss_create(): returns 0, -1 (errno set) or -2 (EADDRINUSE)
fn serverCreate(path: []const u8) i32 {
    const lock_path = util.concat(&.{ path, ".lock" });
    var waited: u32 = 0;
    var lfd: c_int = -1;
    while (true) {
        lfd = open(os.z(lock_path), os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, @as(c_uint, 0o666));
        if (lfd >= 0) break;
        if (errno() != EEXIST or waited >= 100) return -1;
        sleepMs(10);
        waited += 10;
    }
    _ = close(lfd);
    defer _ = unlink(os.z(lock_path));
    const probe = unixStreamConnect(path);
    if (probe >= 0) {
        _ = close(probe);
        os.setErrno(EADDRINUSE);
        return -2;
    }
    const fd = unixStreamListen(path, 50);
    if (fd < 0) return -1;
    st.fd_listen = fd;
    if (os.lstatPath(path)) |s| {
        st.sock_ino = s.ino;
        st.sock_dev = s.dev;
    }
    return 0;
}

fn serverFree() void {
    if (st.fd_listen >= 0) {
        if (!socketWasStolen()) _ = unlink(os.z(st.path_ipc));
        _ = close(st.fd_listen);
        st.fd_listen = -1;
    }
}

fn runDaemonLoop() i32 {
    if (serverCreate(st.path_ipc) != 0) {
        util.err("could not start IPC thread pool on '{s}': {s}", .{ st.path_ipc, os.lastErr() });
        return -1;
    }
    _ = signal(13, 1); // SIGPIPE
    var checked = time(null);
    const interval = 1;
    while (true) {
        switch (st.shutdown) {
            .cont => {
                if (st.quit) {
                    st.shutdown = .stop;
                    continue;
                }
                var pfds = [2]PollFd{
                    .{ .fd = st.fd_inotify, .events = POLLIN },
                    .{ .fd = st.fd_listen, .events = POLLIN },
                };
                const n = poll(&pfds, 2, 50);
                if (n == -1) {
                    if (errno() == EINTR) continue;
                    util.err("polling inotify message stream failed: {s}", .{os.lastErr()});
                    st.shutdown = .err;
                    continue;
                }
                if (time(null) - checked >= interval) {
                    checked = time(null);
                    if (checkStaleDirRenames(checked - interval)) {
                        tr("missed IN_MOVED_TO events, forcing shutdown", .{});
                        st.shutdown = .force;
                        continue;
                    }
                }
                if (n > 0 and (pfds[0].revents & POLLIN) != 0) handleEvents();
                if (st.shutdown != .cont) continue;
                if (n > 0 and (pfds[1].revents & POLLIN) != 0) {
                    const cfd = accept(st.fd_listen, null, null);
                    if (cfd >= 0) handleConnection(cfd);
                }
                if (socketWasStolen()) {
                    // somebody replaced our socket; stop serving
                    st.shutdown = .stop;
                }
            },
            .err => {
                st.listen_error_code = -1;
                break;
            },
            .force, .stop => {
                st.listen_error_code = 0;
                break;
            },
        }
    }
    serverFree();
    return st.listen_error_code;
}

/// fsmonitor_run_daemon()
fn runDaemon() i32 {
    const r = repo_mod.repo();
    st.token = newTokenData();
    const wt = r.work_tree orelse "";
    st.path_worktree_watch = absPath(wt);
    st.nr_paths_watching = 1;

    st.path_gitdir_watch = util.concat(&.{ st.path_worktree_watch, "/.git" });
    if (!os.isDir(st.path_gitdir_watch)) {
        var g = absPath(r.git_dir);
        if (util.endsWith(g, "/.")) g = g[0 .. g.len - 2];
        st.path_gitdir_watch = g;
        st.nr_paths_watching = 2;
    }

    var cp = util.concat(&.{ st.path_gitdir_watch, "/fsmonitor--daemon" });
    _ = os.mkdir(cp, 0o777);
    cp = util.concat(&.{ cp, "/cookies" });
    _ = os.mkdir(cp, 0o777);
    st.path_cookie_prefix = util.concat(&.{ cp, "/" });

    st.path_ipc = absPath(ipcPath());

    if (!listenCtor()) {
        util.err("could not initialize listener thread", .{});
        return -1;
    }

    if (os.getenv("HOME")) |home| {
        if (home.len > 0 and !os.chdir(home)) util.dieErrno("could not cd home '{s}'", .{home});
    }

    tr("Watching: worktree '{s}'", .{st.path_worktree_watch});
    if (st.nr_paths_watching > 1) tr("Watching: gitdir '{s}'", .{st.path_gitdir_watch});

    const rc = runDaemonLoop();
    if (st.fd_inotify >= 0) _ = close(st.fd_inotify);
    return rc;
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return util.normalizePath(p) orelse p;
    const j = util.concat(&.{ os.getcwd(), "/", p });
    return util.normalizePath(j) orelse j;
}

// ---------------------------------------------------------------- client subcommands

fn sendStop() u8 {
    _ = ipcSendCommand("quit");
    var elapsed: u32 = 0;
    const max_wait: u32 = 30000;
    while (ipcGetState() == .listening) {
        if (elapsed >= max_wait) {
            util.err("daemon did not stop within {d} seconds", .{max_wait / 1000});
            return 1;
        }
        sleepMs(50);
        elapsed += 50;
    }
    return 0;
}

fn doStatus() u8 {
    const wt = worktree() orelse "(null)";
    if (ipcGetState() == .listening) {
        util.outf("fsmonitor-daemon is watching '{s}'\n", .{wt});
        return 0;
    }
    util.outf("fsmonitor-daemon is not watching '{s}'\n", .{wt});
    return 1;
}

fn runForeground(detach: bool) u8 {
    const wt = worktree() orelse "(null)";
    if (ipcGetState() == .listening)
        util.die("fsmonitor--daemon is already running '{s}'", .{wt});
    if (announce_startup != 0) util.eprint("running fsmonitor-daemon in '{s}'\n", .{wt});
    if (detach) {
        if (setsid() == -1) util.warn("setsid failed: {s}", .{os.lastErr()});
    }
    return if (runDaemon() != 0) 1 else 0;
}

fn startBackground() u8 {
    const wt = worktree() orelse "(null)";
    if (ipcGetState() == .listening)
        util.die("fsmonitor--daemon is already running '{s}'", .{wt});
    if (announce_startup != 0) util.eprint("starting fsmonitor-daemon in '{s}'\n", .{wt});

    util.flushStdout();
    const exe = gitBinary();
    const threads_arg = util.fmt("--ipc-threads={d}", .{ipc_threads});
    const argv = [_]?[*:0]const u8{ os.z("git"), os.z("fsmonitor--daemon"), os.z("run"), os.z("--detach"), os.z(threads_arg), null };
    const exe_z = os.z(exe);
    const pid = fork();
    if (pid < 0) {
        util.err("daemon failed to start", .{});
        return 1;
    }
    if (pid == 0) {
        const nul = open("/dev/null", os.O_RDWR);
        if (nul >= 0) {
            _ = @import("std").c.dup2(nul, 0);
            _ = @import("std").c.dup2(nul, 1);
            _ = @import("std").c.dup2(nul, 2);
        }
        var i: c_int = 3;
        while (i < 1024) : (i += 1) _ = close(i);
        if (std.mem.indexOfScalar(u8, exe, '/') != null) {
            _ = execv(exe_z, @ptrCast(&argv));
        } else {
            _ = @import("std").c.execvp(exe_z, @ptrCast(&argv));
        }
        _exit(127);
    }
    const limit = time(null) + start_timeout_sec;
    while (true) {
        var status: c_int = 0;
        const seen = waitpid(pid, &status, 1); // WNOHANG
        if (seen == 0) {
            switch (ipcGetState()) {
                .listening => return 0,
                .not_listening, .path_not_found => {
                    if (time(null) < limit) {
                        sleepMs(10);
                        continue;
                    }
                    util.err("daemon not online yet", .{});
                    return 1;
                },
                else => {
                    util.err("daemon failed to start", .{});
                    return 1;
                },
            }
        } else if (seen == pid) {
            util.err("daemon terminated", .{});
            return 1;
        } else if (seen < 0 and errno() == EINTR) {
            continue;
        }
        util.err("daemon failed to start", .{});
        return 1;
    }
}

const usage_lines = [_][]const u8{
    "git fsmonitor--daemon start [<options>]",
    "git fsmonitor--daemon run [<options>]",
    "git fsmonitor--daemon stop",
    "git fsmonitor--daemon status",
};

fn loadConfig() void {
    const cfg = &repo_mod.cfg;
    if (cfg.getInt("fsmonitor.ipcthreads")) |v| {
        if (v < 1) {
            util.err("value of '{s}' out of range: {d}", .{ "fsmonitor.ipcthreads", v });
        } else ipc_threads = @intCast(@min(v, std.math.maxInt(i32)));
    }
    if (cfg.getInt("fsmonitor.starttimeout")) |v| {
        if (v < 0) {
            util.err("value of '{s}' out of range: {d}", .{ "fsmonitor.starttimeout", v });
        } else start_timeout_sec = @intCast(@min(v, std.math.maxInt(i32)));
    }
    if (cfg.getEntry("fsmonitor.announcestartup")) |e| {
        const val = e.value;
        if (val) |s| {
            if (@import("config.zig").parseBool(s)) |b| {
                announce_startup = @intFromBool(b);
            } else if (cfg.getInt("fsmonitor.announcestartup")) |iv| {
                announce_startup = iv;
            }
        } else announce_startup = 1;
    }
}

pub fn cmdFsmonitorDaemon(args: []const []const u8) u8 {
    var detach = false;
    loadConfig();
    const opts = [_]po.Opt{
        po.boolean(0, "detach", &detach, "detach from console"),
        po.integer(0, "ipc-threads", &ipc_threads, "n", "use <n> ipc worker threads"),
        po.integer(0, "start-timeout", &start_timeout_sec, "n", "max seconds to wait for background daemon startup"),
    };
    const rest = po.parse(args[1..], &opts, &usage_lines, .{});
    if (rest.len != 1) po.usageWithOptions(&usage_lines, &opts);
    const subcmd = rest[0];

    if (ipc_threads < 1) util.die("invalid 'ipc-threads' value ({d})", .{ipc_threads});

    const reason = checkIncompatible(true);
    if (reason != .ok) util.die("{s}", .{incompatibleMsg(reason)});

    if (util.eql(subcmd, "start")) return startBackground();
    if (util.eql(subcmd, "run")) return runForeground(detach);
    if (util.eql(subcmd, "stop")) return sendStop();
    if (util.eql(subcmd, "status")) return doStatus();
    util.die("Unhandled subcommand '{s}'", .{subcmd});
}
