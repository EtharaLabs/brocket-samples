//! A few of git's t/helper test-tool subcommands that inspect on-disk
//! index state (reached when the binary is invoked as "test-tool").

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");

pub fn main(all: []const []const u8) u8 {
    if (all.len < 2) util.die("usage: test-tool <cmd> [args]", .{});
    const cmd = all[1];
    const args = all[2..];
    if (util.eql(cmd, "dump-split-index")) return dumpSplitIndex(args);
    if (util.eql(cmd, "chmtime")) return chmtime(args);
    util.die("There is no test named '{s}'", .{cmd});
}

fn dumpSplitIndex(args: []const []const u8) u8 {
    repo_mod.setup(false);
    if (args.len < 1) util.die("usage: test-tool dump-split-index <file>", .{});
    const idx = index_mod.readRawFile(args[0]);
    util.outf("own {s}\n", .{&hash.hex(idx.oid)});
    const si = idx.split orelse {
        util.out("not a split index\n");
        return 0;
    };
    util.outf("base {s}\n", .{&hash.hex(si.base_oid)});
    for (idx.entries.items) |e| {
        util.outf("{o:0>6} {s} {d}\t{s}\n", .{ e.mode, &hash.hex(e.oid), e.stage(), e.path });
    }
    util.out("replacements:");
    if (si.replace_bm) |*bm| for (bm.bits()) |b| util.outf(" {d}", .{b});
    util.out("\ndeletions:");
    if (si.delete_bm) |*bm| for (bm.bits()) |b| util.outf(" {d}", .{b});
    util.out("\n");
    return 0;
}

const Utimbuf = extern struct { actime: i64, modtime: i64 };
extern "c" fn utime(path: [*:0]const u8, times: *const Utimbuf) c_int;

/// test-tool chmtime [-g|--get] [-v|--verbose] [=|=+|=-|+|-]<seconds> <file>...
fn chmtime(args0: []const []const u8) u8 {
    var args = args0;
    var get = false;
    var verbose = false;
    while (args.len > 0) {
        if (util.eql(args[0], "-g") or util.eql(args[0], "--get")) {
            get = true;
        } else if (util.eql(args[0], "-v") or util.eql(args[0], "--verbose")) {
            verbose = true;
        } else break;
        args = args[1..];
    }
    var set_eq: u8 = 0; // 0 relative to file, 1 absolute, 2 relative to now
    var delta: i64 = 0;
    if (!get) {
        if (args.len == 0) util.die("usage: test-tool chmtime <time> <file>...", .{});
        var s = args[0];
        if (s.len > 0 and s[0] == '=') {
            set_eq = 1;
            s = s[1..];
            if (s.len > 0 and (s[0] == '+' or s[0] == '-')) set_eq = 2;
        }
        delta = std.fmt.parseInt(i64, s, 10) catch util.die("Not a base-10 integer: {s}", .{args[0]});
        args = args[1..];
    } else if (args.len > 0 and (args[0][0] == '=' or args[0][0] == '+' or args[0][0] == '-')) {
        args = args[1..];
    }
    const now = os.now();
    for (args) |f| {
        const st = os.statPath(f) orelse {
            util.eprint("Failed to stat {s}\n", .{f});
            return 1;
        };
        var mtime: i64 = st.mtime;
        if (!get) {
            mtime = switch (set_eq) {
                1 => delta,
                2 => now + delta,
                else => mtime + delta,
            };
        }
        if (get or verbose) util.outf("{d}\t{s}\n", .{ mtime, f });
        if (!get) {
            const ut = Utimbuf{ .actime = st.atime, .modtime = mtime };
            const z = util.concat(&.{ f, "\x00" });
            if (utime(z[0..f.len :0], &ut) != 0) {
                util.eprint("Failed to modify time on {s}\n", .{f});
                return 1;
            }
        }
    }
    return 0;
}
