//! Untracked cache (dir.c: UNTR index extension, struct untracked_cache).
//! STUB: full port pending.

const std = @import("std");
const util = @import("util.zig");
const index_mod = @import("index.zig");

pub const Cache = struct {
    raw: []const u8 = "",
    use_fsmonitor: bool = false,
};

/// read_untracked_extension(): null on corruption (silently, like C).
pub fn readExtension(data: []const u8) ?*Cache {
    _ = data;
    return null;
}

/// write_untracked_extension()
pub fn writeExtension(c: *Cache, b: *util.Buf) void {
    util.bufAppend(b, c.raw);
}

/// tweak_untracked_cache(): apply core.untrackedCache.
pub fn tweak(idx: *index_mod.Index) void {
    _ = idx;
}

/// add_untracked_cache()
pub fn add(idx: *index_mod.Index) void {
    _ = idx;
}

/// untracked_cache_invalidate_path()
pub fn invalidatePath(idx: *index_mod.Index, path: []const u8, safe_path: bool) void {
    _ = idx;
    _ = path;
    _ = safe_path;
}

/// untracked_cache_invalidate_trimmed_path()
pub fn invalidateTrimmedPath(idx: *index_mod.Index, path: []const u8, safe_path: bool) void {
    _ = idx;
    _ = path;
    _ = safe_path;
}
