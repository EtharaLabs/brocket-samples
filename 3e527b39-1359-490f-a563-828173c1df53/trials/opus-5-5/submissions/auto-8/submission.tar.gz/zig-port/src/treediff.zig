//! Port of tree-diff.c and tree_entry_interesting() (tree-walk.c).
//!
//!   treediff.treeEntryInteresting(name, mode, base, &ps) Interesting
//!   treediff.diffTreePaths(new, parents, base, opt, cb, ctx)  (combined walker)
//!   treediff.diffTreeOid(old, new, base, opt)  (queues pairs into diff.queue)

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const objects = @import("objects.zig");
const pathspec_mod = @import("pathspec.zig");
const diff = @import("diff.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Buf = util.Buf;
const Pathspec = pathspec_mod.Pathspec;
const Item = pathspec_mod.Item;

pub const Interesting = enum(i8) {
    all_entries_not_interesting = -1,
    entry_not_interesting = 0,
    entry_interesting = 1,
    all_entries_interesting = 2,
};

const S_IFMT: u32 = 0o170000;
fn isDir(mode: u32) bool {
    return mode & S_IFMT == 0o040000;
}
fn isGitlink(mode: u32) bool {
    return mode & S_IFMT == 0o160000;
}

fn at(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

/// strncmp with NUL-terminated semantics on slices
fn cstrncmp(a: []const u8, b: []const u8, n: usize, icase: bool) i32 {
    var i: usize = 0;
    while (i < n) : (i += 1) {
        var ca = at(a, i);
        var cb = at(b, i);
        if (icase) {
            ca = std.ascii.toLower(ca);
            cb = std.ascii.toLower(cb);
        }
        if (ca != cb) return @as(i32, ca) - @as(i32, cb);
        if (ca == 0) return 0;
    }
    return 0;
}

fn psStrncmp(it: *const Item, a: []const u8, b: []const u8, n: usize) i32 {
    return cstrncmp(a, b, n, it.magic & pathspec_mod.MAGIC_ICASE != 0);
}

fn matchEntry(it: *const Item, name: []const u8, mode: u32, match: []const u8, never: *Interesting) bool {
    const pathlen = name.len;
    const matchlen = match.len;
    var m: i32 = -1;
    var m_set = false;
    if (it.magic & pathspec_mod.MAGIC_ICASE != 0) {
        never.* = .entry_not_interesting;
    } else if (never.* != .entry_not_interesting) {
        m = cstrncmp(match, name, @min(matchlen, pathlen), false);
        m_set = true;
        if (m < 0) return false;
        never.* = .entry_not_interesting;
    }
    if (pathlen > matchlen) return false;
    if (matchlen > pathlen) {
        if (match[pathlen] != '/') return false;
        if (!isDir(mode) and (!isGitlink(mode) or matchlen > pathlen + 1)) return false;
    }
    if (!m_set) m = psStrncmp(it, match, name, pathlen);
    return m == 0;
}

fn basecmp(it: *const Item, base0: []const u8, match0: []const u8, len0: usize) i32 {
    var base = base0;
    var match = match0;
    var len = len0;
    if (it.magic & pathspec_mod.MAGIC_ICASE != 0) {
        const n = @min(len, it.prefix);
        const r = cstrncmp(base, match, n, false);
        if (r != 0) return r;
        base = base[@min(n, base.len)..];
        match = match[@min(n, match.len)..];
        len -= n;
    }
    return psStrncmp(it, base, match, len);
}

fn matchDirPrefix(it: *const Item, base: []const u8, match: []const u8, matchlen: usize) bool {
    if (basecmp(it, base, match, matchlen) != 0) return false;
    if (matchlen == 0 or at(base, matchlen) == '/' or match[matchlen - 1] == '/') return true;
    return false;
}

fn matchWildcardBase(it: *const Item, base: []const u8) bool {
    const match = it.match;
    const matchlen = it.nowildcard_len;
    if (base.len > 0) {
        if (base.len >= matchlen) return basecmp(it, base, match, matchlen) == 0;
        if (basecmp(it, base, match, base.len) != 0) return false;
    }
    return true;
}

fn withinDepth(name: []const u8, depth: i32, max_depth: i32) bool {
    return pathspec_mod.withinDepth(name, depth, max_depth);
}

fn doMatch(name: []const u8, mode: u32, base: []const u8, ps: *const Pathspec, exclude: bool) Interesting {
    var never: Interesting = if (ps.has_wildcard) .entry_not_interesting else .all_entries_not_interesting;
    const baselen = base.len;
    if (ps.items.len == 0) {
        if (!ps.recursive or ps.magic & pathspec_mod.MAGIC_MAXDEPTH == 0 or ps.max_depth == -1)
            return .all_entries_interesting;
        return if (withinDepth(base, if (isDir(mode)) 1 else 0, ps.max_depth)) .entry_interesting else .entry_not_interesting;
    }
    var i: usize = ps.items.len;
    while (i > 0) {
        i -= 1;
        const it = &ps.items[i];
        const match = it.match;
        const matchlen = match.len;
        const is_ex = it.magic & pathspec_mod.MAGIC_EXCLUDE != 0;
        if (is_ex != exclude) continue;
        var interesting = false;
        blk: {
            if (baselen >= matchlen) {
                if (!matchDirPrefix(it, base, match, matchlen)) break :blk;
                if (!ps.recursive or ps.magic & pathspec_mod.MAGIC_MAXDEPTH == 0 or ps.max_depth == -1) {
                    if (it.attr_match.len == 0) return .all_entries_interesting;
                    interesting = true;
                    break :blk;
                }
                const rest = if (matchlen + 1 <= baselen) base[matchlen + 1 ..] else "";
                if (withinDepth(rest, if (isDir(mode)) 1 else 0, ps.max_depth)) {
                    interesting = true;
                    break :blk;
                }
                return .entry_not_interesting;
            }
            if (baselen == 0 or basecmp(it, base, match, baselen) == 0) {
                if (matchEntry(it, name, mode, match[baselen..], &never)) {
                    interesting = true;
                    break :blk;
                }
                if (it.nowildcard_len < match.len) {
                    const pfx = if (it.nowildcard_len > baselen) it.nowildcard_len - baselen else 0;
                    if (pathspec_mod.gitFnmatchItem(it, match[baselen..], name, pfx)) {
                        interesting = true;
                        break :blk;
                    }
                    if (ps.recursive and isDir(mode)) return .entry_interesting;
                }
                continue;
            }
            // match_wildcards:
            if (it.nowildcard_len == match.len) continue;
            if (it.nowildcard_len > 0 and !matchWildcardBase(it, base)) continue;
            const full = util.concat(&.{ base, name });
            if (pathspec_mod.gitFnmatchItem(it, match, full, it.nowildcard_len)) {
                interesting = true;
                break :blk;
            }
            if (ps.recursive and isDir(mode)) return .entry_interesting;
            continue;
        }
        if (!interesting) {
            // came from "doesn't match dir prefix": go to wildcard matching
            if (it.nowildcard_len == match.len) continue;
            if (it.nowildcard_len > 0 and !matchWildcardBase(it, base)) continue;
            const full = util.concat(&.{ base, name });
            if (!pathspec_mod.gitFnmatchItem(it, match, full, it.nowildcard_len)) {
                if (ps.recursive and isDir(mode)) return .entry_interesting;
                continue;
            }
        }
        // interesting:
        if (it.attr_match.len > 0) {
            never = .entry_not_interesting;
            if (isDir(mode)) return .entry_interesting;
            if (!pathspec_mod.matchItemAttrs(it, util.concat(&.{ base, name }))) continue;
        }
        return .entry_interesting;
    }
    return never;
}

/// tree_entry_interesting(); base is "" or ends with '/'
pub fn treeEntryInteresting(name: []const u8, mode: u32, base: []const u8, ps: *const Pathspec) Interesting {
    const positive = doMatch(name, mode, base, ps, false);
    if (ps.magic & pathspec_mod.MAGIC_EXCLUDE == 0 or @intFromEnum(positive) <= 0) return positive;
    const negative = doMatch(name, mode, base, ps, true);
    if (positive == .all_entries_interesting and negative == .entry_not_interesting) return .entry_interesting;
    if (@intFromEnum(negative) <= 0) return positive;
    if (isDir(mode) and @intFromEnum(positive) >= 1 and negative == .entry_interesting) return .entry_interesting;
    if ((positive == .entry_interesting and @intFromEnum(negative) >= 1) or
        (positive == .all_entries_interesting and negative == .entry_interesting)) return .entry_not_interesting;
    return .all_entries_not_interesting;
}

// ---------------------------------------------------------------------------
// tree walker

pub const CombineParent = struct {
    status: u8,
    mode: u32,
    oid: Oid,
};

pub const CombinePath = struct {
    path: []const u8,
    mode: u32,
    oid: Oid,
    parent: []CombineParent,
};

/// return true to keep the path in the result list
pub const PathChangeFn = *const fn (ctx: ?*anyopaque, opt: *diff.DiffOptions, p: *CombinePath) bool;

const Desc = struct {
    entries: []objects.TreeEntry,
    pos: usize = 0,
    neq: bool = false,

    fn size(d: *const Desc) bool {
        return d.pos < d.entries.len;
    }
    fn cur(d: *const Desc) objects.TreeEntry {
        return d.entries[d.pos];
    }
};

fn canonMode(mode: u32) u32 {
    if (mode & S_IFMT == 0o100000) return 0o100000 | (if (mode & 0o100 != 0) @as(u32, 0o755) else 0o644);
    if (mode & S_IFMT == 0o120000) return 0o120000;
    if (isDir(mode)) return 0o040000;
    if (isGitlink(mode)) return 0o160000;
    return mode;
}

fn fillDesc(oid: ?Oid) Desc {
    const o = oid orelse return .{ .entries = &.{} };
    const t = objects.peelTo(o, .tree) orelse util.die("unable to read tree ({s})", .{hash.hexAlloc(o)});
    const entries = objects.readTree(t) orelse util.die("unable to read tree ({s})", .{hash.hexAlloc(o)});
    for (entries) |*e| e.mode = canonMode(e.mode);
    return .{ .entries = entries };
}

fn pathcmp(a: *const Desc, b: *const Desc) i32 {
    if (!a.size()) return if (b.size()) 1 else 0;
    if (!b.size()) return -1;
    const ea = a.cur();
    const eb = b.cur();
    return switch (objects.baseNameCompare(ea.name, ea.mode, eb.name, eb.mode)) {
        .lt => -1,
        .eq => 0,
        .gt => 1,
    };
}

fn skipUninteresting(d: *Desc, base: []const u8, opt: *diff.DiffOptions) void {
    while (d.size()) {
        const e = d.cur();
        const m = treeEntryInteresting(e.name, e.mode, base, &opt.pathspec);
        if (m != .entry_not_interesting) {
            if (m == .all_entries_not_interesting) d.pos = d.entries.len;
            break;
        }
        d.pos += 1;
    }
}

fn checkRecursionDepth(name: []const u8, ps: *const Pathspec, max_depth: i32) bool {
    if (ps.items.len == 0) return withinDepth(name, 1, max_depth);
    var i: usize = ps.items.len;
    while (i > 0) {
        i -= 1;
        const it = &ps.items[i];
        if (name.len >= it.match.len) {
            if (!isDirPrefix(name, it.match)) continue;
            return withinDepth(name[it.match.len..], 1, max_depth);
        }
        if (isDirPrefix(it.match, name)) return true;
    }
    return false;
}

fn isDirPrefix(path: []const u8, dir: []const u8) bool {
    return util.startsWith(path, dir) and (path.len == dir.len or path[dir.len] == '/');
}

fn shouldRecurse(name: []const u8, opt: *diff.DiffOptions) bool {
    if (!opt.flags.recursive) return false;
    if (!opt.max_depth_valid) return true;
    return checkRecursionDepth(name, &opt.pathspec, opt.max_depth);
}

const Walker = struct {
    opt: *diff.DiffOptions,
    cb: PathChangeFn,
    ctx: ?*anyopaque,
    out: *std.ArrayList(*CombinePath),
};

fn emitPath(w: *Walker, base: *Buf, nparent: usize, t: ?*Desc, tp: ?[]Desc, imin: usize, depth: usize) void {
    const opt = w.opt;
    var mode: u32 = undefined;
    var name: []const u8 = undefined;
    var oid: ?Oid = null;
    var is_dir: bool = undefined;
    if (t) |tt| {
        const e = tt.cur();
        oid = e.oid;
        name = e.name;
        mode = e.mode;
        is_dir = isDir(mode);
    } else {
        const e = tp.?[imin].cur();
        name = e.name;
        is_dir = isDir(e.mode);
        mode = 0;
    }
    const old_len = base.items.len;
    var recurse = false;
    var emitthis = true;
    if (is_dir) {
        util.bufAppend(base, name);
        if (shouldRecurse(base.items, opt)) {
            recurse = true;
            emitthis = opt.flags.tree_in_recursive;
        }
        base.shrinkRetainingCapacity(old_len);
    }
    if (emitthis) {
        const p = gpa.create(CombinePath) catch util.oom();
        p.* = .{
            .path = util.concat(&.{ base.items, name }),
            .mode = mode,
            .oid = oid orelse hash.zero,
            .parent = gpa.alloc(CombineParent, nparent) catch util.oom(),
        };
        for (0..nparent) |i| {
            const valid = tp != null and !tp.?[i].neq;
            p.parent[i].status = if (t == null) diff.STATUS_DELETED else if (valid) diff.STATUS_MODIFIED else diff.STATUS_ADDED;
            if (valid) {
                const e = tp.?[i].cur();
                p.parent[i].oid = e.oid;
                p.parent[i].mode = e.mode;
            } else {
                p.parent[i].oid = hash.zero;
                p.parent[i].mode = 0;
            }
        }
        if (w.cb(w.ctx, opt, p)) w.out.append(gpa, p) catch util.oom();
    }
    if (recurse) {
        const parents = gpa.alloc(?Oid, nparent) catch util.oom();
        for (0..nparent) |i| {
            const valid = tp != null and !tp.?[i].neq;
            parents[i] = if (valid) tp.?[i].cur().oid else null;
        }
        util.bufAppend(base, name);
        util.bufByte(base, '/');
        llDiffTreePaths(w, oid, parents, base, depth + 1);
    }
    base.shrinkRetainingCapacity(old_len);
}

fn llDiffTreePaths(w: *Walker, oid: ?Oid, parents: []const ?Oid, base: *Buf, depth: usize) void {
    const opt = w.opt;
    if (depth > 4096) util.die("exceeded maximum allowed tree depth", .{});
    const nparent = parents.len;
    const tp = gpa.alloc(Desc, nparent) catch util.oom();
    for (parents, 0..) |po, i| tp[i] = fillDesc(po);
    var t = fillDesc(oid);
    opt.pathspec.recursive = opt.flags.recursive;
    while (true) {
        if (diff.canQuitEarly(opt)) break;
        if (opt.pathspec.items.len > 0) {
            skipUninteresting(&t, base.items, opt);
            for (tp) |*d| skipUninteresting(d, base.items, opt);
        }
        if (!t.size()) {
            var done = true;
            for (tp) |*d| {
                if (d.size()) {
                    done = false;
                    break;
                }
            }
            if (done) break;
        }
        var imin: usize = 0;
        tp[0].neq = false;
        for (1..nparent) |i| {
            const cmp = pathcmp(&tp[i], &tp[imin]);
            if (cmp < 0) {
                imin = i;
                tp[i].neq = false;
            } else if (cmp == 0) {
                tp[i].neq = false;
            } else tp[i].neq = true;
        }
        for (0..imin) |i| tp[i].neq = true;

        const cmp = pathcmp(&t, &tp[imin]);
        if (cmp == 0) {
            var skip = false;
            if (!opt.flags.find_copies_harder) {
                for (tp) |*d| {
                    if (d.neq) continue;
                    const a = t.cur();
                    const b = d.cur();
                    if (!hash.eql(a.oid, b.oid) or a.mode != b.mode) continue;
                    skip = true;
                    break;
                }
            }
            if (!skip) emitPath(w, base, nparent, &t, tp, imin, depth);
            t.pos += 1;
            for (tp) |*d| {
                if (!d.neq) d.pos += 1;
            }
        } else if (cmp < 0) {
            emitPath(w, base, nparent, &t, null, 0, depth);
            t.pos += 1;
        } else {
            var skip = false;
            if (!opt.flags.find_copies_harder) {
                for (tp) |*d| {
                    if (d.neq) {
                        skip = true;
                        break;
                    }
                }
            }
            if (!skip) emitPath(w, base, nparent, null, tp, imin, depth);
            for (tp) |*d| {
                if (!d.neq) d.pos += 1;
            }
        }
    }
}

/// diff_tree_paths(): combined tree walker
pub fn diffTreePaths(oid: ?Oid, parents: []const ?Oid, base: []const u8, opt: *diff.DiffOptions, cb: PathChangeFn, ctx: ?*anyopaque) []*CombinePath {
    var out: std.ArrayList(*CombinePath) = .empty;
    var w = Walker{ .opt = opt, .cb = cb, .ctx = ctx, .out = &out };
    var b: Buf = .empty;
    util.bufAppend(&b, base);
    llDiffTreePaths(&w, oid, parents, &b, 0);
    return out.items;
}

fn emitFirstParentOnly(ctx: ?*anyopaque, opt: *diff.DiffOptions, p: *CombinePath) bool {
    _ = ctx;
    const p0 = &p.parent[0];
    if (p.mode != 0 and p0.mode != 0) {
        diff.change(opt, p0.mode, p.mode, p0.oid, p.oid, true, true, p.path, 0, 0);
    } else if (p.mode != 0) {
        diff.addRemove(opt, '+', p.mode, p.oid, true, p.path, 0);
    } else {
        diff.addRemove(opt, '-', p0.mode, p0.oid, true, p.path, 0);
    }
    return false;
}

fn llDiffTreeOid(old: ?Oid, new: ?Oid, base: []const u8, opt: *diff.DiffOptions) void {
    const parents = [_]?Oid{old};
    _ = diffTreePaths(new, &parents, base, opt, emitFirstParentOnly, null);
}

fn diffMightBeRename() bool {
    return diff.queue.items.len == 1 and !diff.fileValid(diff.queue.items[0].one);
}

fn tryToFollowRenames(old: ?Oid, new: ?Oid, base: []const u8, opt: *diff.DiffOptions) void {
    const choice0 = diff.queue.items[0];
    var choice = choice0;
    diff.clearQueue();
    var dopts = diff.DiffOptions.initBasic();
    dopts.flags.recursive = true;
    dopts.flags.find_copies_harder = true;
    dopts.output_format = diff.FMT_NO_OUTPUT;
    dopts.single_follow = opt.pathspec.items[0].match;
    dopts.break_opt = opt.break_opt;
    dopts.rename_score = opt.rename_score;
    dopts.file = null;
    dopts.setupDone();
    llDiffTreeOid(old, new, base, &dopts);
    diff.diffcoreStd(&dopts);
    opt.found_follow = false;
    for (diff.queue.items) |p| {
        if ((p.status == 'R' or p.status == 'C') and util.eql(p.two.path, opt.pathspec.items[0].match)) {
            choice = p;
            const paths = [_][]const u8{p.one.path};
            opt.pathspec = pathspec_mod.parse("", &paths, .{ .literal = true });
            opt.found_follow = true;
            break;
        }
    }
    diff.clearQueue();
    _ = diff.queuePair(choice.one, choice.two).*;
    diff.queue.items[0] = choice;
}

/// diff_tree_oid(): queue the differences between two trees (old may be null = root)
pub fn diffTreeOid(old: ?Oid, new: ?Oid, base: []const u8, opt: *diff.DiffOptions) void {
    llDiffTreeOid(old, new, base, opt);
    if (base.len == 0 and opt.flags.follow_renames and diffMightBeRename())
        tryToFollowRenames(old, new, base, opt);
}
