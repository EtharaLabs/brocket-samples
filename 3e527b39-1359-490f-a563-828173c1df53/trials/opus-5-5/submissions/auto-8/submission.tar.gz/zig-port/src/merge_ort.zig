//! Port of merge-ort.c, merge-ort-wrappers.c, merge-ll.c and the parts of
//! diffcore-rename.c / diffcore-delta.c that merge-ort needs.
//!
//! Memory is never freed (process-lifetime allocations via util.gpa).

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const os = @import("os.zig");
const objects = @import("objects.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const xdiff = @import("xdiff.zig");
const attr = @import("attr.zig");
const config = @import("config.zig");
const index_mod = @import("index.zig");
const ut = @import("unpacktrees.zig");
const refs = @import("refs.zig");
const cn = @import("commitnode.zig");
const creach = @import("commitreach.zig");
const revparse = @import("revparse.zig");

const Oid = hash.Oid;
const gpa = util.gpa;
const oom = util.oom;

fn StrMap(comptime V: type) type {
    return std.StringArrayHashMapUnmanaged(V);
}
const IntMap = StrMap(i32);

fn iget(m: *const IntMap, k: []const u8, def: i32) i32 {
    return m.get(k) orelse def;
}
fn iset(m: *IntMap, k: []const u8, v: i32) void {
    m.put(gpa, k, v) catch oom();
}
fn mput(comptime V: type, m: *StrMap(V), k: []const u8, v: V) void {
    m.put(gpa, k, v) catch oom();
}
fn appendT(comptime T: type, l: *std.ArrayList(T), v: T) void {
    l.append(gpa, v) catch oom();
}

const S_IFMT = os.S_IFMT;
fn isReg(m: u32) bool {
    return m & S_IFMT == os.S_IFREG;
}
fn isLnk(m: u32) bool {
    return m & S_IFMT == os.S_IFLNK;
}
fn isGitlink(m: u32) bool {
    return m & S_IFMT == os.S_IFGITLINK;
}
fn isDirMode(m: u32) bool {
    return m & S_IFMT == os.S_IFDIR;
}

const empty_tree: Oid = hash.fromHex(hash.empty_tree_hex).?;
const empty_blob: Oid = hash.fromHex(hash.empty_blob_hex).?;

// ---------------------------------------------------------------------------
// Public options

pub const DirRenames = enum(u8) { none = 0, conflict = 1, true_ = 2 };
pub const Variant = enum(u8) { normal = 0, ours = 1, theirs = 2 };

pub const Options = struct {
    branch1: []const u8 = "",
    branch2: []const u8 = "",
    ancestor: ?[]const u8 = null,
    detect_renames: i32 = -1,
    detect_directory_renames: DirRenames = .conflict,
    rename_limit: i32 = -1,
    rename_score: i32 = 0,
    show_rename_progress: bool = false,
    verbosity: i32 = 2,
    renormalize: bool = false,
    recursive_variant: Variant = .normal,
    xdl_flags: xdiff.Flags = .{ .algorithm = .histogram, .indent_heuristic = false },
    conflict_style: i32 = -1,
    subtree_shift: ?[]const u8 = null,
    record_conflict_msgs_as_headers: bool = false,
    msg_header_prefix: ?[]const u8 = null,
    mergeability_only: bool = false,
    priv: ?*Priv = null,
};

pub const Result = struct {
    clean: i32 = 0,
    tree: Oid = hash.zero,
    priv: ?*Priv = null,
};

// ---------------------------------------------------------------------------
// merge-ll

/// git_xmerge_style (merge.conflictstyle), -1 if unset.
pub var xmerge_style: i32 = -1;
var xmerge_loaded = false;

pub fn parseConflictStyleName(v: []const u8) i32 {
    if (util.eql(v, "merge")) return 0;
    if (util.eql(v, "diff3")) return 1;
    if (util.eql(v, "zdiff3")) return 2;
    return -1;
}

/// git_xmerge_config
pub fn loadXmergeConfig() void {
    if (xmerge_loaded) return;
    xmerge_loaded = true;
    if (repo_mod.cfg.getEntry("merge.conflictstyle")) |e| {
        const v = e.value orelse {
            util.err("missing value for '{s}'", .{"merge.conflictstyle"});
            return;
        };
        xmerge_style = parseConflictStyleName(v);
        if (xmerge_style == -1) util.err("unknown style '{s}' given for '{s}'", .{ v, "merge.conflictstyle" });
    }
}

pub fn styleFromInt(s: i32) xdiff.MergeStyle {
    return switch (s) {
        1 => .diff3,
        2 => .zdiff3,
        else => .merge,
    };
}

pub const LlStatus = enum(i8) { err = -1, ok = 0, conflict = 1, binary_conflict = 2 };

pub const LlOpts = struct {
    virtual_ancestor: bool = false,
    variant: xdiff.MergeFavor = .none,
    renormalize: bool = false,
    extra_marker_size: i32 = 0,
    xdl_flags: xdiff.Flags = .{ .indent_heuristic = false },
    conflict_style: i32 = -1,
};

pub const LlResult = struct { status: LlStatus, result: ?[]const u8 };

const DriverKind = enum { binary, text, union_, ext };
const Driver = struct {
    name: []const u8,
    description: ?[]const u8 = null,
    kind: DriverKind,
    recursive: ?[]const u8 = null,
    cmdline: ?[]const u8 = null,
};

var builtin_drivers = [_]Driver{
    .{ .name = "binary", .description = "built-in binary merge", .kind = .binary },
    .{ .name = "text", .description = "built-in 3-way text merge", .kind = .text },
    .{ .name = "union", .description = "built-in union merge", .kind = .union_ },
};
var user_drivers: std.ArrayList(*Driver) = .empty;
var default_ll_merge: ?[]const u8 = null;
var ll_initialized = false;

fn initializeLlMerge() void {
    if (ll_initialized) return;
    ll_initialized = true;
    for (repo_mod.cfg.entries.items) |e| {
        if (util.eql(e.key, "merge.default")) {
            default_ll_merge = e.value;
            continue;
        }
        const rest = util.skipPrefix(e.key, "merge.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse continue;
        const name = rest[0..dot];
        const key = rest[dot + 1 ..];
        var fnp: ?*Driver = null;
        for (user_drivers.items) |d| {
            if (util.eql(d.name, name)) {
                fnp = d;
                break;
            }
        }
        const d = fnp orelse blk: {
            const nd = gpa.create(Driver) catch oom();
            nd.* = .{ .name = name, .kind = .ext };
            appendT(*Driver, &user_drivers, nd);
            break :blk nd;
        };
        if (util.eql(key, "name")) {
            d.description = e.value;
        } else if (util.eql(key, "driver")) {
            if (e.value) |v| d.cmdline = v else util.err("missing value for '{s}'", .{e.key});
        } else if (util.eql(key, "recursive")) {
            d.recursive = e.value;
        }
    }
}

fn findDriverByName(name: []const u8) *Driver {
    for (user_drivers.items) |d| if (util.eql(d.name, name)) return d;
    for (&builtin_drivers) |*d| if (util.eql(d.name, name)) return d;
    return &builtin_drivers[1];
}

fn findLlMergeDriver(v: attr.Value) *Driver {
    initializeLlMerge();
    switch (v) {
        .set => return &builtin_drivers[1],
        .unset => return &builtin_drivers[0],
        .unspecified => {
            const n = default_ll_merge orelse return &builtin_drivers[1];
            return findDriverByName(n);
        },
        .value => |n| return findDriverByName(n),
    }
}

pub fn bufferIsBinary(b: []const u8) bool {
    const n = @min(b.len, 8000);
    return std.mem.indexOfScalar(u8, b[0..n], 0) != null;
}

fn llBinaryMerge(orig: []const u8, src1: []const u8, src2: []const u8, opts: *const LlOpts) LlResult {
    if (opts.virtual_ancestor) return .{ .status = .ok, .result = orig };
    return switch (opts.variant) {
        .ours => .{ .status = .ok, .result = src1 },
        .theirs => .{ .status = .ok, .result = src2 },
        else => .{ .status = .binary_conflict, .result = src1 },
    };
}

fn llXdlMerge(orig: []const u8, orig_name: ?[]const u8, src1: []const u8, name1: ?[]const u8, src2: []const u8, name2: ?[]const u8, opts: *const LlOpts, marker_size: i32) LlResult {
    if (bufferIsBinary(orig) or bufferIsBinary(src1) or bufferIsBinary(src2))
        return llBinaryMerge(orig, src1, src2, opts);
    loadXmergeConfig();
    var mo = xdiff.MergeOpts{
        .flags = opts.xdl_flags,
        .level = .zealous,
        .favor = opts.variant,
        .ancestor_name = orig_name,
        .ours_name = name1,
        .theirs_name = name2,
    };
    if (opts.conflict_style >= 0) {
        mo.style = styleFromInt(opts.conflict_style);
    } else if (xmerge_style >= 0) mo.style = styleFromInt(xmerge_style);
    if (marker_size > 0) mo.marker_size = marker_size;
    const r = xdiff.merge(orig, src1, src2, mo) catch return .{ .status = .err, .result = null };
    return .{ .status = if (r.conflicts > 0) .conflict else .ok, .result = r.result };
}

fn createTemp(data: []const u8) []const u8 {
    const t = os.tmpFile(".", ".merge_file_");
    if (t.fd < 0) util.dieErrno("unable to create temp-file", .{});
    os.writeAll(t.fd, data) catch util.dieErrno("unable to write temp-file", .{});
    os.close(t.fd);
    return util.skipPrefix(t.path, "./") orelse t.path;
}

fn llExtMerge(d: *const Driver, path: []const u8, orig: []const u8, orig_name: ?[]const u8, src1: []const u8, name1: ?[]const u8, src2: []const u8, name2: ?[]const u8, marker_size: i32) LlResult {
    const format = d.cmdline orelse util.die("custom merge driver {s} lacks command line.", .{d.name});
    var temp: [3][]const u8 = undefined;
    temp[0] = createTemp(orig);
    temp[1] = createTemp(src1);
    temp[2] = createTemp(src2);
    var cmd: util.Buf = .empty;
    var i: usize = 0;
    while (i < format.len) {
        const ch = format[i];
        if (ch != '%') {
            util.bufByte(&cmd, ch);
            i += 1;
            continue;
        }
        i += 1;
        if (i >= format.len) {
            util.bufByte(&cmd, '%');
            break;
        }
        const f = format[i];
        switch (f) {
            '%' => util.bufByte(&cmd, '%'),
            'O' => util.bufAppend(&cmd, temp[0]),
            'A' => util.bufAppend(&cmd, temp[1]),
            'B' => util.bufAppend(&cmd, temp[2]),
            'L' => util.bufPrint(&cmd, "{d}", .{marker_size}),
            'P' => util.sqQuote(&cmd, path),
            'S' => util.sqQuote(&cmd, orig_name orelse ""),
            'X' => util.sqQuote(&cmd, name1 orelse ""),
            'Y' => util.sqQuote(&cmd, name2 orelse ""),
            else => {
                util.bufByte(&cmd, '%');
                continue;
            },
        }
        i += 1;
    }
    const res = os.run(&.{cmd.items}, .{ .use_shell = true });
    const out = os.readFile(temp[1]);
    for (temp) |t| {
        if (!os.unlink(t)) util.warn("unable to unlink '{s}': {s}", .{ t, os.lastErr() });
    }
    const st: LlStatus = if (res.status == 0) .ok else if (res.status <= 128) .conflict else .err;
    return .{ .status = st, .result = out };
}

/// ll_merge()
pub fn llMerge(path: []const u8, ancestor: []const u8, ancestor_label: ?[]const u8, ours: []const u8, our_label: ?[]const u8, theirs: []const u8, their_label: ?[]const u8, opts: *const LlOpts) LlResult {
    const vals = attr.check(path, &.{ "merge", "conflict-marker-size" });
    var marker_size: i32 = xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
    switch (vals[1]) {
        .value => |v| {
            if (std.fmt.parseInt(i32, v, 10)) |n| {
                marker_size = n;
            } else |_| {
                marker_size = xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
                util.warn("invalid marker-size '{s}', expecting an integer", .{v});
            }
            if (marker_size <= 0) marker_size = xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
        },
        .set => {
            // value "true": strtol_i fails
            util.warn("invalid marker-size '{s}', expecting an integer", .{"true"});
        },
        .unset => {
            util.warn("invalid marker-size '{s}', expecting an integer", .{"false"});
        },
        .unspecified => {},
    }
    var driver = findLlMergeDriver(vals[0]);
    if (opts.virtual_ancestor) {
        if (driver.recursive) |r| driver = findLlMergeDriver(.{ .value = r });
    }
    if (opts.extra_marker_size != 0) marker_size += opts.extra_marker_size;
    return switch (driver.kind) {
        .binary => llBinaryMerge(ancestor, ours, theirs, opts),
        .text => llXdlMerge(ancestor, ancestor_label, ours, our_label, theirs, their_label, opts, marker_size),
        .union_ => blk: {
            var o = opts.*;
            o.variant = .union_;
            break :blk llXdlMerge(ancestor, ancestor_label, ours, our_label, theirs, their_label, &o, marker_size);
        },
        .ext => llExtMerge(driver, path, ancestor, ancestor_label, ours, our_label, theirs, their_label, marker_size),
    };
}

// ---------------------------------------------------------------------------
// Internal data

const MERGE_BASE = 0;
const MERGE_SIDE1 = 1;
const MERGE_SIDE2 = 2;

const NOT_RELEVANT: i32 = 0;
const RELEVANT_FOR_ANCESTOR: i32 = 1;
const RELEVANT_FOR_SELF: i32 = 2;

const RELEVANT_NO_MORE: i32 = 0;
const RELEVANT_CONTENT: i32 = 1;
const RELEVANT_LOCATION: i32 = 2;

const MAX_SCORE: i32 = 60000;
const DEFAULT_RENAME_SCORE: i32 = 30000;

pub const Ct = enum(u8) {
    INFO_AUTO_MERGING = 0,
    CONFLICT_CONTENTS,
    CONFLICT_BINARY,
    CONFLICT_FILE_DIRECTORY,
    CONFLICT_DISTINCT_MODES,
    CONFLICT_MODIFY_DELETE,
    CONFLICT_RENAME_RENAME,
    CONFLICT_RENAME_COLLIDES,
    CONFLICT_RENAME_DELETE,
    CONFLICT_DIR_RENAME_SUGGESTED,
    INFO_DIR_RENAME_APPLIED,
    INFO_DIR_RENAME_SKIPPED_DUE_TO_RERENAME,
    CONFLICT_DIR_RENAME_FILE_IN_WAY,
    CONFLICT_DIR_RENAME_COLLISION,
    CONFLICT_DIR_RENAME_SPLIT,
    INFO_SUBMODULE_FAST_FORWARDING,
    CONFLICT_SUBMODULE_FAILED_TO_MERGE,
    CONFLICT_SUBMODULE_FAILED_TO_MERGE_BUT_POSSIBLE_RESOLUTION,
    CONFLICT_SUBMODULE_NOT_INITIALIZED,
    CONFLICT_SUBMODULE_HISTORY_NOT_AVAILABLE,
    CONFLICT_SUBMODULE_MAY_HAVE_REWINDS,
    CONFLICT_SUBMODULE_NULL_MERGE_BASE,
    NB_REGULAR_CONFLICT_TYPES,
    ERROR_SUBMODULE_CORRUPT,
    ERROR_THREEWAY_CONTENT_MERGE_FAILED,
    ERROR_OBJECT_WRITE_FAILED,
    ERROR_OBJECT_READ_FAILED,
    ERROR_OBJECT_NOT_A_BLOB,
};

fn shortDesc(t: Ct) []const u8 {
    return switch (t) {
        .INFO_AUTO_MERGING => "Auto-merging",
        .CONFLICT_CONTENTS => "CONFLICT (contents)",
        .CONFLICT_BINARY => "CONFLICT (binary)",
        .CONFLICT_FILE_DIRECTORY => "CONFLICT (file/directory)",
        .CONFLICT_DISTINCT_MODES => "CONFLICT (distinct modes)",
        .CONFLICT_MODIFY_DELETE => "CONFLICT (modify/delete)",
        .CONFLICT_RENAME_RENAME => "CONFLICT (rename/rename)",
        .CONFLICT_RENAME_COLLIDES => "CONFLICT (rename involved in collision)",
        .CONFLICT_RENAME_DELETE => "CONFLICT (rename/delete)",
        .CONFLICT_DIR_RENAME_SUGGESTED => "CONFLICT (directory rename suggested)",
        .INFO_DIR_RENAME_APPLIED => "Path updated due to directory rename",
        .INFO_DIR_RENAME_SKIPPED_DUE_TO_RERENAME => "Directory rename skipped since directory was renamed on both sides",
        .CONFLICT_DIR_RENAME_FILE_IN_WAY => "CONFLICT (file in way of directory rename)",
        .CONFLICT_DIR_RENAME_COLLISION => "CONFLICT(directory rename collision)",
        .CONFLICT_DIR_RENAME_SPLIT => "CONFLICT(directory rename unclear split)",
        .INFO_SUBMODULE_FAST_FORWARDING => "Fast forwarding submodule",
        .CONFLICT_SUBMODULE_FAILED_TO_MERGE => "CONFLICT (submodule)",
        .CONFLICT_SUBMODULE_FAILED_TO_MERGE_BUT_POSSIBLE_RESOLUTION => "CONFLICT (submodule with possible resolution)",
        .CONFLICT_SUBMODULE_NOT_INITIALIZED => "CONFLICT (submodule not initialized)",
        .CONFLICT_SUBMODULE_HISTORY_NOT_AVAILABLE => "CONFLICT (submodule history not available)",
        .CONFLICT_SUBMODULE_MAY_HAVE_REWINDS => "CONFLICT (submodule may have rewinds)",
        .CONFLICT_SUBMODULE_NULL_MERGE_BASE => "CONFLICT (submodule lacks merge base)",
        .NB_REGULAR_CONFLICT_TYPES => "",
        .ERROR_SUBMODULE_CORRUPT => "ERROR (submodule corrupt)",
        .ERROR_THREEWAY_CONTENT_MERGE_FAILED => "ERROR (three-way content merge failed)",
        .ERROR_OBJECT_WRITE_FAILED => "ERROR (object write failed)",
        .ERROR_OBJECT_READ_FAILED => "ERROR (object read failed)",
        .ERROR_OBJECT_NOT_A_BLOB => "ERROR (object is not a blob)",
    };
}

const VersionInfo = struct {
    oid: Oid = hash.zero,
    mode: u32 = 0,
};

/// merged_info + conflict_info combined.
const Info = struct {
    result: VersionInfo = .{},
    is_null: bool = false,
    clean: bool = false,
    basename_offset: usize = 0,
    directory_name: []const u8 = "",
    stages: [3]VersionInfo = .{ .{}, .{}, .{} },
    pathnames: [3][]const u8 = .{ "", "", "" },
    df_conflict: bool = false,
    path_conflict: bool = false,
    filemask: u8 = 0,
    dirmask: u8 = 0,
    match_mask: u8 = 0,
};

fn newInfo() *Info {
    const p = gpa.create(Info) catch oom();
    p.* = .{};
    return p;
}

const Spec = struct {
    path: []const u8,
    oid: Oid = hash.zero,
    mode: u32 = 0,
    rename_used: u32 = 0,
    data: ?[]const u8 = null,
    cnt: ?[]const Span = null,
    fn valid(s: *const Spec) bool {
        return s.mode != 0;
    }
};

const Pair = struct {
    one: *Spec,
    two: *Spec,
    status: u8 = 0,
    score: i32 = 0,
    renamed_pair: bool = false,
};

const Msg = struct {
    typ: Ct,
    paths: []const []const u8,
    text: []const u8,
};

const SideInfo = struct {
    pairs: std.ArrayList(*Pair) = .empty,
    dirs_removed: IntMap = .empty, // default NOT_RELEVANT
    dir_rename_count: StrMap(*IntMap) = .empty,
    dir_renames: StrMap([]const u8) = .empty,
    relevant_sources: IntMap = .empty, // default -1
    possible_trivial_merges: IntMap = .empty, // default 0
    trivial_merges_okay: bool = true,
};

pub const Priv = struct {
    paths: StrMap(*Info) = .empty,
    conflicted: StrMap(*Info) = .empty,
    conflicts: StrMap(*std.ArrayList(Msg)) = .empty,
    sides: [3]SideInfo = .{ .{}, .{}, .{} },
    dir_rename_mask: u8 = 0,
    current_dir_name: []const u8 = "",
    call_depth: i32 = 0,
    needed_limit: i32 = 0,
};

fn clearOrReinit(p: *Priv, reinitialize: bool) void {
    p.paths = .empty;
    p.conflicted = .empty;
    var i: usize = 1;
    while (i <= 2) : (i += 1) {
        const s = &p.sides[i];
        s.dirs_removed = .empty;
        s.dir_renames = .empty;
        s.relevant_sources = .empty;
        s.dir_rename_count = .empty;
        s.possible_trivial_merges = .empty;
        s.trivial_merges_okay = true;
        s.pairs = .empty;
    }
    p.dir_rename_mask = 0;
    if (!reinitialize) p.conflicts = .empty;
}

// ---------------------------------------------------------------------------
// path_msg

fn pathMsg(opt: *Options, typ: Ct, omittable_hint: bool, primary_path: []const u8, other1: ?[]const u8, other2: ?[]const u8, others: ?[]const []const u8, text: []const u8) void {
    const priv = opt.priv.?;
    if (opt.record_conflict_msgs_as_headers and omittable_hint) return;
    if (priv.call_depth != 0 and opt.verbosity < 5) return;
    const gop = priv.conflicts.getOrPut(gpa, primary_path) catch oom();
    if (!gop.found_existing) {
        const l = gpa.create(std.ArrayList(Msg)) catch oom();
        l.* = .empty;
        gop.value_ptr.* = l;
    }
    var paths: std.ArrayList([]const u8) = .empty;
    appendT([]const u8, &paths, primary_path);
    if (other1) |o| appendT([]const u8, &paths, o);
    if (other2) |o| appendT([]const u8, &paths, o);
    if (others) |os_| for (os_) |o| appendT([]const u8, &paths, o);

    var dest: util.Buf = .empty;
    if (priv.call_depth != 0) {
        util.bufAppend(&dest, "  From inner merge:");
        var k: i32 = 0;
        while (k < priv.call_depth * 2) : (k += 1) util.bufByte(&dest, ' ');
    }
    util.bufAppend(&dest, text);
    var buf: util.Buf = .empty;
    if (opt.record_conflict_msgs_as_headers) {
        if (opt.msg_header_prefix) |pfx| util.bufPrint(&buf, "{s} ", .{pfx});
        for (dest.items) |ch| {
            util.bufByte(&buf, ch);
            if (ch == '\n') util.bufByte(&buf, ' ');
        }
    } else buf = dest;
    appendT(Msg, gop.value_ptr.*, .{ .typ = typ, .paths = paths.items, .text = buf.items });
}

fn uniquePath(opt: *Options, path: []const u8, branch: []const u8) []const u8 {
    var b: util.Buf = .empty;
    util.bufPrint(&b, "{s}~", .{path});
    for (branch) |ch| util.bufByte(&b, if (ch == '/') '_' else ch);
    const base_len = b.items.len;
    var suffix: i32 = 0;
    while (opt.priv.?.paths.contains(b.items)) {
        b.items.len = base_len;
        util.bufPrint(&b, "_{d}", .{suffix});
        suffix += 1;
    }
    return b.items;
}

// ---------------------------------------------------------------------------
// Tree traversal (traverse_trees equivalent for 3 trees)

const NameEntry = struct {
    name: []const u8 = "",
    mode: u32 = 0,
    oid: Oid = hash.zero,
};

const CbData = struct {
    mask: u8,
    dirmask: u8,
    names: [3]NameEntry,
};

fn readTreeEntries(oid: ?Oid) []const objects.TreeEntry {
    const o = oid orelse return &.{};
    if (hash.eql(o, empty_tree)) return &.{};
    return objects.readTree(o) orelse &.{};
}

const UnionItem = struct {
    key: []const u8,
    data: CbData,
};

fn unionLess(_: void, a: UnionItem, b: UnionItem) bool {
    return std.mem.order(u8, a.key, b.key) == .lt;
}

/// Collect the entries of one directory level across 3 trees, in the order
/// traverse_trees() would visit them.
fn levelEntries(trees: [3]?Oid) []CbData {
    var map: StrMap(usize) = .empty;
    var items: std.ArrayList(UnionItem) = .empty;
    for (0..3) |i| {
        const ents = readTreeEntries(trees[i]);
        for (ents) |e| {
            const gop = map.getOrPut(gpa, e.name) catch oom();
            if (!gop.found_existing) {
                gop.value_ptr.* = items.items.len;
                appendT(UnionItem, &items, .{ .key = e.name, .data = .{ .mask = 0, .dirmask = 0, .names = .{ .{}, .{}, .{} } } });
            }
            const it = &items.items[gop.value_ptr.*];
            const bit: u8 = @as(u8, 1) << @intCast(i);
            if (it.data.mask & bit != 0) continue; // duplicate entry
            it.data.mask |= bit;
            if (isDirMode(e.mode)) it.data.dirmask |= bit;
            it.data.names[i] = .{ .name = e.name, .mode = e.mode, .oid = e.oid };
        }
    }
    for (items.items) |*it| {
        // all present entries are directories -> sorts as "name/"
        if (it.data.dirmask == it.data.mask) it.key = util.concat(&.{ it.key, "/" });
    }
    std.mem.sort(UnionItem, items.items, {}, unionLess);
    const out = gpa.alloc(CbData, items.items.len) catch oom();
    for (items.items, 0..) |it, i| out[i] = it.data;
    return out;
}

const TraverseInfo = struct {
    /// full path of the directory being traversed ("" for toplevel)
    base: []const u8,
    /// length of prefix for children (0 at toplevel, else base.len+1)
    pathlen: usize,
};

fn traverseTrees(opt: *Options, trees: [3]?Oid, info: TraverseInfo) i32 {
    const ents = levelEntries(trees);
    for (ents) |*e| {
        const r = collectMergeInfoCallback(opt, e.mask, e.dirmask, &e.names, info);
        if (r < 0) return -1;
    }
    return 0;
}

fn traverseTreesWrapper(opt: *Options, trees: [3]?Oid, info: TraverseInfo) i32 {
    const priv = opt.priv.?;
    const ents = levelEntries(trees);
    for (ents) |e| {
        const filemask = e.mask & ~e.dirmask;
        if (filemask != 0 and filemask == priv.dir_rename_mask) priv.dir_rename_mask = 0x07;
    }
    for (ents) |*e| {
        const r = collectMergeInfoCallback(opt, e.mask, e.dirmask, &e.names, info);
        if (r < 0) return -1;
    }
    return 0;
}

fn setupPathInfo(opt: *Options, current_dir_name: []const u8, current_dir_name_len: usize, fullpath: []const u8, names: *const [3]NameEntry, merged_version: ?*const NameEntry, is_null: bool, df_conflict: bool, filemask: u8, dirmask: u8, resolved: bool) ?*Info {
    const mi = newInfo();
    mi.directory_name = current_dir_name;
    mi.basename_offset = current_dir_name_len;
    mi.clean = resolved;
    if (resolved) {
        mi.result.mode = merged_version.?.mode;
        mi.result.oid = merged_version.?.oid;
        mi.is_null = is_null;
    } else {
        for (0..3) |i| {
            mi.pathnames[i] = fullpath;
            mi.stages[i].mode = names[i].mode;
            mi.stages[i].oid = names[i].oid;
        }
        mi.filemask = filemask;
        mi.dirmask = dirmask;
        mi.df_conflict = df_conflict;
        if (dirmask != 0) mi.is_null = true;
    }
    const gop = opt.priv.?.paths.getOrPut(gpa, fullpath) catch oom();
    if (gop.found_existing) {
        gop.value_ptr.* = mi;
        util.err("tree has duplicate entries for '{s}'", .{fullpath});
        return null;
    }
    gop.value_ptr.* = mi;
    return mi;
}

fn newSpec(path: []const u8) *Spec {
    const s = gpa.create(Spec) catch oom();
    s.* = .{ .path = path };
    return s;
}

fn addPair(opt: *Options, names: *const [3]NameEntry, pathname: []const u8, side: usize, is_add: bool, match_mask: u8, dir_rename_mask: u8) void {
    const priv = opt.priv.?;
    const names_idx: usize = if (is_add) side else 0;
    if (!is_add) {
        const content_relevant = (match_mask == 0);
        const location_relevant = (dir_rename_mask == 0x07);
        if (content_relevant or location_relevant) {
            iset(&priv.sides[side].relevant_sources, pathname, if (content_relevant) RELEVANT_CONTENT else RELEVANT_LOCATION);
        }
    }
    const one = newSpec(pathname);
    const two = newSpec(pathname);
    const s = if (is_add) two else one;
    s.oid = names[names_idx].oid;
    s.mode = names[names_idx].mode;
    const p = gpa.create(Pair) catch oom();
    p.* = .{ .one = one, .two = two };
    appendT(*Pair, &priv.sides[side].pairs, p);
}

fn collectRenameInfo(opt: *Options, names: *const [3]NameEntry, dirname: []const u8, fullname: []const u8, filemask: u8, dirmask: u8, match_mask: u8) void {
    const priv = opt.priv.?;
    if (priv.dir_rename_mask != 0x07 and (dirmask == 3 or dirmask == 5)) {
        priv.dir_rename_mask = dirmask & ~@as(u8, 1);
    }
    if (dirmask == 1 or dirmask == 3 or dirmask == 5) {
        const sides = (0x07 - dirmask) / 2;
        const relevance: i32 = if (priv.dir_rename_mask == 0x07) RELEVANT_FOR_ANCESTOR else NOT_RELEVANT;
        if (sides & 1 != 0) iset(&priv.sides[1].dirs_removed, fullname, relevance);
        if (sides & 2 != 0) iset(&priv.sides[2].dirs_removed, fullname, relevance);
    }
    if (priv.dir_rename_mask == 0x07 and (filemask == 2 or filemask == 4)) {
        const side: usize = 3 - (filemask >> 1);
        iset(&priv.sides[side].dirs_removed, dirname, RELEVANT_FOR_SELF);
    }
    if (filemask == 0 or filemask == 7) return;
    var side: usize = 1;
    while (side <= 2) : (side += 1) {
        const side_mask: u8 = @as(u8, 1) << @intCast(side);
        if ((filemask & 1) != 0 and (filemask & side_mask) == 0)
            addPair(opt, names, fullname, side, false, match_mask & filemask, priv.dir_rename_mask);
        if ((filemask & 1) == 0 and (filemask & side_mask) != 0)
            addPair(opt, names, fullname, side, true, match_mask & filemask, priv.dir_rename_mask);
    }
}

fn collectMergeInfoCallback(opt: *Options, mask: u8, dirmask0: u8, names: *const [3]NameEntry, info: TraverseInfo) i32 {
    const priv = opt.priv.?;
    const dirname = priv.current_dir_name;
    const prev_dir_rename_mask = priv.dir_rename_mask;
    const filemask = mask & ~dirmask0;
    var dirmask = dirmask0;
    var match_mask: u8 = 0;
    const mbase_null = (mask & 1) == 0;
    const side1_null = (mask & 2) == 0;
    const side2_null = (mask & 4) == 0;
    const side1_matches_mbase = (!side1_null and !mbase_null and names[0].mode == names[1].mode and hash.eql(names[0].oid, names[1].oid));
    const side2_matches_mbase = (!side2_null and !mbase_null and names[0].mode == names[2].mode and hash.eql(names[0].oid, names[2].oid));
    const sides_match = (!side1_null and !side2_null and names[1].mode == names[2].mode and hash.eql(names[1].oid, names[2].oid));
    const df_conflict = (filemask != 0) and (dirmask != 0);

    if (side1_matches_mbase) {
        match_mask = if (side2_matches_mbase) 7 else 3;
    } else if (side2_matches_mbase) {
        match_mask = 5;
    } else if (sides_match) match_mask = 6;

    var pidx: usize = 0;
    while (names[pidx].mode == 0) pidx += 1;
    const pname = names[pidx].name;
    const fullpath = if (info.base.len == 0) util.dupe(pname) else util.concat(&.{ info.base, "/", pname });

    if (side1_matches_mbase and side2_matches_mbase) {
        if (setupPathInfo(opt, dirname, info.pathlen, fullpath, names, &names[0], mbase_null, false, filemask, dirmask, true) == null) return -1;
        return mask;
    }
    if (sides_match and filemask == 0x07) {
        if (setupPathInfo(opt, dirname, info.pathlen, fullpath, names, &names[1], side1_null, false, filemask, dirmask, true) == null) return -1;
        return mask;
    }
    if (side1_matches_mbase and filemask == 0x07) {
        if (setupPathInfo(opt, dirname, info.pathlen, fullpath, names, &names[2], side2_null, false, filemask, dirmask, true) == null) return -1;
        return mask;
    }
    if (side2_matches_mbase and filemask == 0x07) {
        if (setupPathInfo(opt, dirname, info.pathlen, fullpath, names, &names[1], side1_null, false, filemask, dirmask, true) == null) return -1;
        return mask;
    }
    collectRenameInfo(opt, names, dirname, fullpath, filemask, dirmask, match_mask);
    const ci = setupPathInfo(opt, dirname, info.pathlen, fullpath, names, null, false, df_conflict, filemask, dirmask, false) orelse return -1;
    ci.match_mask = match_mask;
    if (dirmask != 0) {
        var side: usize = if (side1_matches_mbase) MERGE_SIDE2 else if (side2_matches_mbase) MERGE_SIDE1 else MERGE_BASE;
        if (filemask == 0 and (dirmask == 2 or dirmask == 4)) {
            ci.match_mask = 7 - dirmask;
            side = dirmask / 2;
        }
        if (priv.dir_rename_mask != 0x07 and side != MERGE_BASE and priv.sides[side].trivial_merges_okay) {
            iset(&priv.sides[side].possible_trivial_merges, fullpath, priv.dir_rename_mask);
            priv.dir_rename_mask = prev_dir_rename_mask;
            return mask;
        }
        ci.match_mask &= filemask;
        var t: [3]?Oid = .{ null, null, null };
        for (0..3) |i| {
            if (i == 1 and side1_matches_mbase) {
                t[1] = t[0];
            } else if (i == 2 and side2_matches_mbase) {
                t[2] = t[0];
            } else if (i == 2 and sides_match) {
                t[2] = t[1];
            } else {
                if (dirmask & 1 != 0) t[i] = names[i].oid;
            }
            dirmask >>= 1;
        }
        const original_dir_name = priv.current_dir_name;
        priv.current_dir_name = fullpath;
        const newinfo = TraverseInfo{ .base = fullpath, .pathlen = fullpath.len + 1 };
        const ret = if (priv.dir_rename_mask == 0 or priv.dir_rename_mask == 0x07)
            traverseTrees(opt, t, newinfo)
        else
            traverseTreesWrapper(opt, t, newinfo);
        priv.current_dir_name = original_dir_name;
        priv.dir_rename_mask = prev_dir_rename_mask;
        if (ret < 0) return -1;
    }
    return mask;
}

fn resolveTrivialDirectoryMerge(ci: *Info, side: usize) void {
    ci.result.oid = ci.stages[side].oid;
    ci.result.mode = ci.stages[side].mode;
    ci.is_null = hash.isZero(ci.stages[side].oid);
    ci.dirmask &= ~ci.match_mask;
    ci.filemask &= ~ci.match_mask;
    ci.match_mask = 0;
    ci.clean = !ci.df_conflict or ci.dirmask != 0;
    ci.df_conflict = false;
}

fn handleDeferredEntries(opt: *Options) i32 {
    const priv = opt.priv.?;
    var side: usize = 1;
    while (side <= 2) : (side += 1) {
        const s = &priv.sides[side];
        // No rename cache: optimization is only okay when there are no
        // relevant sources at all.
        const optimization_okay = s.relevant_sources.count() == 0;
        s.trivial_merges_okay = optimization_okay;
        const copy = s.possible_trivial_merges;
        s.possible_trivial_merges = .empty;
        var it = copy.iterator();
        while (it.next()) |entry| {
            const path = entry.key_ptr.*;
            const dir_rename_mask: u8 = @intCast(entry.value_ptr.*);
            const ci = priv.paths.get(path).?;
            var dirmask = ci.dirmask;
            if (optimization_okay) {
                resolveTrivialDirectoryMerge(ci, side);
                continue;
            }
            var t: [3]?Oid = .{ null, null, null };
            for (0..3) |i| {
                if (i == 1 and ci.match_mask == 3) {
                    t[1] = t[0];
                } else if (i == 2 and ci.match_mask == 5) {
                    t[2] = t[0];
                } else if (i == 2 and ci.match_mask == 6) {
                    t[2] = t[1];
                } else {
                    if (dirmask & 1 != 0) t[i] = ci.stages[i].oid;
                }
                dirmask >>= 1;
            }
            ci.match_mask &= ci.filemask;
            priv.current_dir_name = path;
            priv.dir_rename_mask = dir_rename_mask;
            const info = TraverseInfo{ .base = path, .pathlen = path.len + 1 };
            const ret = if (priv.dir_rename_mask == 0 or priv.dir_rename_mask == 0x07)
                traverseTrees(opt, t, info)
            else
                traverseTreesWrapper(opt, t, info);
            if (ret < 0) return ret;
        }
        var it2 = s.possible_trivial_merges.iterator();
        while (it2.next()) |entry| {
            const ci = priv.paths.get(entry.key_ptr.*).?;
            resolveTrivialDirectoryMerge(ci, side);
        }
    }
    return 0;
}

fn collectMergeInfo(opt: *Options, merge_base: Oid, side1: Oid, side2: Oid) i32 {
    const priv = opt.priv.?;
    priv.current_dir_name = "";
    const info = TraverseInfo{ .base = "", .pathlen = 0 };
    var ret = traverseTrees(opt, .{ merge_base, side1, side2 }, info);
    if (ret == 0) ret = handleDeferredEntries(opt);
    return ret;
}
