//! Port of git's fsck.c: object validation (fsck message ids, severities,
//! skip lists), plus a small parsed-object table that mimics git's object
//! hash so that iteration order (e.g. "dangling" output) matches git.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const config = @import("config.zig");
const zlib = @import("zlib.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

// ---------------------------------------------------------------------------
// message ids

pub const MsgType = enum { ignore, info, fatal, err, warn };

pub const MsgId = enum {
    nul_in_header,
    unterminated_header,
    bad_header_continuation,
    bad_date,
    bad_date_overflow,
    bad_email,
    bad_gpgsig,
    bad_head_target,
    bad_name,
    bad_object_sha1,
    bad_packed_ref_entry,
    bad_packed_ref_header,
    bad_parent_sha1,
    bad_referent_name,
    bad_ref_content,
    bad_ref_filetype,
    bad_ref_name,
    bad_ref_oid,
    bad_timezone,
    bad_tree,
    bad_tree_sha1,
    bad_type,
    duplicate_entries,
    gitattributes_blob,
    gitattributes_large,
    gitattributes_line_length,
    gitattributes_missing,
    gitmodules_blob,
    gitmodules_large,
    gitmodules_missing,
    gitmodules_name,
    gitmodules_path,
    gitmodules_symlink,
    gitmodules_update,
    gitmodules_url,
    missing_author,
    missing_committer,
    missing_email,
    missing_name_before_email,
    missing_object,
    missing_space_before_date,
    missing_space_before_email,
    missing_tag,
    missing_tag_entry,
    missing_tree,
    missing_type,
    missing_type_entry,
    multiple_authors,
    packed_ref_entry_not_terminated,
    packed_ref_unsorted,
    tree_not_sorted,
    unknown_type,
    zero_padded_date,
    bad_reftable_table_name,
    empty_name,
    full_pathname,
    has_dot,
    has_dotdot,
    has_dotgit,
    large_pathname,
    null_sha1,
    nul_in_commit,
    zero_padded_filemode,
    bad_filemode,
    bad_tag_name,
    empty_packed_refs_file,
    gitattributes_symlink,
    gitignore_symlink,
    gitmodules_parse,
    mailmap_symlink,
    missing_tagger_entry,
    ref_missing_newline,
    symlink_ref,
    symref_target_is_not_a_ref,
    trailing_ref_content,
    extra_header_entry,
};

pub const msg_count = @typeInfo(MsgId).@"enum".fields.len;

pub fn defaultType(id: MsgId) MsgType {
    const i = @intFromEnum(id);
    if (i <= @intFromEnum(MsgId.unterminated_header)) return .fatal;
    if (i <= @intFromEnum(MsgId.zero_padded_date)) return .err;
    if (i <= @intFromEnum(MsgId.zero_padded_filemode)) return .warn;
    if (i <= @intFromEnum(MsgId.trailing_ref_content)) return .info;
    return .ignore;
}

/// "nulInHeader"
pub fn camelName(id: MsgId) []const u8 {
    const n = @tagName(id);
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (i < n.len) : (i += 1) {
        if (n[i] == '_') {
            i += 1;
            if (i < n.len) util.bufByte(&b, std.ascii.toUpper(n[i]));
        } else util.bufByte(&b, n[i]);
    }
    return b.items;
}

/// "nulinheader"
pub fn downcasedName(id: MsgId) []const u8 {
    const n = @tagName(id);
    var b: util.Buf = .empty;
    for (n) |ch| {
        if (ch != '_') util.bufByte(&b, ch);
    }
    return b.items;
}

pub fn parseMsgId(text: []const u8) ?MsgId {
    inline for (@typeInfo(MsgId).@"enum".fields) |f| {
        const id: MsgId = @enumFromInt(f.value);
        if (util.eql(text, downcasedName(id))) return id;
    }
    return null;
}

fn parseMsgType(s: []const u8) MsgType {
    if (util.eql(s, "error")) return .err;
    if (util.eql(s, "warn")) return .warn;
    if (util.eql(s, "ignore")) return .ignore;
    util.die("Unknown fsck message type: '{s}'", .{s});
}

pub var max_tree_entry_len: usize = 4096;

// ---------------------------------------------------------------------------
// options

/// An oidset that remembers insertion order (for deterministic iteration).
pub const OidList = struct {
    set: hash.OidSet = .empty,
    list: std.ArrayList(Oid) = .empty,
    pub fn insert(self: *OidList, oid: Oid) void {
        if ((self.set.fetchPut(gpa, oid, {}) catch util.oom()) == null) self.list.append(gpa, oid) catch util.oom();
    }
    pub fn contains(self: *const OidList, oid: Oid) bool {
        return self.set.contains(oid);
    }
    pub fn clear(self: *OidList) void {
        self.set = .empty;
        self.list = .empty;
    }
};

pub const WalkFn = *const fn (obj: ?*Obj, typ: ?ObjType, data: ?*Obj, o: *Options) i32;
pub const ErrorFn = *const fn (o: *Options, oid: ?Oid, typ: ObjType, mt: MsgType, id: MsgId, msg: []const u8) i32;

pub const Options = struct {
    strict: bool = false,
    msg_type: ?[]MsgType = null,
    skip_oids: hash.OidSet = .empty,
    gitmodules_found: OidList = .{},
    gitmodules_done: hash.OidSet = .empty,
    gitattributes_found: OidList = .{},
    gitattributes_done: hash.OidSet = .empty,
    object_names: ?*hash.OidMap([]const u8) = null,
    error_func: ErrorFn = objectsErrorFunction,
    walk: ?WalkFn = null,
};

pub fn msgTypeOf(o: *const Options, id: MsgId) MsgType {
    if (o.msg_type) |mt| return mt[@intFromEnum(id)];
    const t = defaultType(id);
    if (o.strict and t == .warn) return .err;
    return t;
}

pub fn setMsgTypeFromId(o: *Options, id: MsgId, t: MsgType) void {
    if (o.msg_type == null) {
        const arr = gpa.alloc(MsgType, msg_count) catch util.oom();
        for (arr, 0..) |*a, i| a.* = msgTypeOf(o, @enumFromInt(i));
        o.msg_type = arr;
    }
    o.msg_type.?[@intFromEnum(id)] = t;
}

pub fn setMsgType(o: *Options, id_str: []const u8, type_str0: []const u8) void {
    const id = parseMsgId(id_str) orelse util.die("Unhandled message id: {s}", .{id_str});
    var type_str = type_str0;
    if (id == .large_pathname) {
        if (std.mem.indexOfScalar(u8, type_str, ':')) |colon| {
            const rest = type_str[colon + 1 ..];
            type_str = type_str[0..colon];
            const v = parseSsize(rest) orelse util.die("unable to parse max tree entry len: {s}", .{rest});
            max_tree_entry_len = v;
        }
    }
    const t = parseMsgType(type_str);
    if (t != .err and defaultType(id) == .fatal) util.die("Cannot demote {s} to {s}", .{ id_str, type_str });
    setMsgTypeFromId(o, id, t);
}

fn parseSsize(s: []const u8) ?usize {
    const r = config.parseSigned(s, std.math.maxInt(i64));
    return switch (r) {
        .ok => |v| if (v < 0) std.math.maxInt(usize) else @intCast(v),
        .err => null,
    };
}

pub fn setMsgTypes(o: *Options, values: []const u8) void {
    var rest = values;
    while (true) {
        const len = std.mem.indexOfAny(u8, rest, " ,|") orelse rest.len;
        const done = len == rest.len;
        if (len == 0) {
            if (done) break;
            rest = rest[1..];
            continue;
        }
        const tok = rest[0..len];
        var equal: usize = 0;
        var key: util.Buf = .empty;
        while (equal < len and tok[equal] != '=' and tok[equal] != ':') : (equal += 1) util.bufByte(&key, std.ascii.toLower(tok[equal]));
        if (util.eql(key.items, "skiplist")) {
            if (equal == len) util.die("skiplist requires a path", .{});
            parseOidFile(&o.skip_oids, tok[equal + 1 ..]);
        } else {
            if (equal == len) util.die("Missing '=': '{s}'", .{key.items});
            setMsgType(o, key.items, tok[equal + 1 ..]);
        }
        if (done) break;
        rest = rest[len + 1 ..];
    }
}

pub fn parseOidFile(set: *hash.OidSet, path: []const u8) void {
    const data = os.readFile(path) orelse util.die("could not open object name list: {s}", .{path});
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        var line = line0;
        if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
        if (std.mem.indexOfScalar(u8, line, '#')) |h| line = line[0..h];
        line = std.mem.trim(u8, line, " \t\r\n\x0b\x0c");
        if (line.len == 0) continue;
        if (line.len != 40) util.die("invalid object name: {s}", .{line});
        const oid = hash.fromHex(line) orelse util.die("invalid object name: {s}", .{line});
        set.put(gpa, oid, {}) catch util.oom();
    }
}

/// git_fsck_config(): apply fsck.* settings from the repository config.
pub fn applyConfig(o: *Options) void {
    for (repo_mod.cfg.entries.items) |e| {
        if (util.eql(e.key, "fsck.skiplist")) {
            switch (config.configPathname(e.key, e.value)) {
                .ok => |p| if (p) |path| setMsgTypes(o, util.concat(&.{ "skiplist=", path })),
                .err => dieConfig(e),
            }
            continue;
        }
        if (util.skipPrefix(e.key, "fsck.")) |id| {
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                dieConfig(e);
            };
            setMsgType(o, id, v);
        }
    }
}

pub fn dieConfig(e: config.Entry) noreturn {
    if (e.origin_type == .cmdline) util.die("unable to parse '{s}' from command-line config", .{e.key});
    util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
}

// ---------------------------------------------------------------------------
// object names

pub fn enableObjectNames(o: *Options) void {
    if (o.object_names == null) {
        const m = gpa.create(hash.OidMap([]const u8)) catch util.oom();
        m.* = .empty;
        o.object_names = m;
    }
}

pub fn getObjectName(o: *const Options, oid: Oid) ?[]const u8 {
    const m = o.object_names orelse return null;
    return m.get(oid);
}

pub fn putObjectName(o: *Options, oid: Oid, comptime f: []const u8, args: anytype) void {
    const m = o.object_names orelse return;
    if (m.contains(oid)) return;
    m.put(gpa, oid, util.fmt(f, args)) catch util.oom();
}

pub fn describeObject(o: *const Options, oid: Oid) []const u8 {
    const h = hash.hex(oid);
    if (getObjectName(o, oid)) |n| return util.fmt("{s} ({s})", .{ &h, n });
    return util.dupe(&h);
}

// ---------------------------------------------------------------------------
// reporting

pub fn objectsErrorFunction(o: *Options, oid: ?Oid, typ: ObjType, mt: MsgType, id: MsgId, msg: []const u8) i32 {
    _ = typ;
    _ = id;
    const d = if (oid) |x| describeObject(o, x) else "(null)";
    if (mt == .warn) {
        util.warn("object {s}: {s}", .{ d, msg });
        return 0;
    }
    util.err("object {s}: {s}", .{ d, msg });
    return 1;
}

pub fn report(o: *Options, oid: ?Oid, typ: ObjType, id: MsgId, comptime f: []const u8, args: anytype) i32 {
    if (oid) |x| {
        if (o.skip_oids.contains(x)) return 0;
    }
    var mt = msgTypeOf(o, id);
    if (mt == .ignore) return 0;
    if (mt == .fatal) mt = .err else if (mt == .info) mt = .warn;
    const msg = util.concat(&.{ camelName(id), ": ", util.fmt(f, args) });
    return o.error_func(o, oid, typ, mt, id, msg);
}

// ---------------------------------------------------------------------------
// parsed object table (mimics git's obj_hash)

pub const Obj = struct {
    oid: Oid,
    typ: ObjType = .none,
    flags: u32 = 0,
    parsed: bool = false,
    // commit
    tree: ?*Obj = null,
    parents: []*Obj = &.{},
    // tag
    tagged: ?*Obj = null,
    tag_name: []const u8 = "",
    // tree
    buffer: ?[]const u8 = null,
};

pub var obj_hash: []?*Obj = &.{};
pub var nr_objs: usize = 0;

fn hashObj(oid: Oid, n: usize) usize {
    return @as(usize, std.mem.readInt(u32, oid[0..4], .little)) & (n - 1);
}

fn insertObjHash(obj: *Obj, table: []?*Obj) void {
    var j = hashObj(obj.oid, table.len);
    while (table[j] != null) {
        j += 1;
        if (j >= table.len) j = 0;
    }
    table[j] = obj;
}

pub fn lookupObject(oid: Oid) ?*Obj {
    if (obj_hash.len == 0) return null;
    const first = hashObj(oid, obj_hash.len);
    var i = first;
    while (obj_hash[i]) |obj| {
        if (hash.eql(obj.oid, oid)) {
            if (i != first) {
                const t = obj_hash[first];
                obj_hash[first] = obj_hash[i];
                obj_hash[i] = t;
            }
            return obj;
        }
        i += 1;
        if (i == obj_hash.len) i = 0;
    }
    return null;
}

fn growObjectHash() void {
    const new_size: usize = if (obj_hash.len < 32) 32 else 2 * obj_hash.len;
    const nt = gpa.alloc(?*Obj, new_size) catch util.oom();
    @memset(nt, null);
    for (obj_hash) |o| {
        if (o) |x| insertObjHash(x, nt);
    }
    obj_hash = nt;
}

pub fn createObject(oid: Oid) *Obj {
    const obj = gpa.create(Obj) catch util.oom();
    obj.* = .{ .oid = oid };
    if (obj_hash.len == 0 or obj_hash.len - 1 <= nr_objs * 2) growObjectHash();
    insertObjHash(obj, obj_hash);
    nr_objs += 1;
    return obj;
}

pub fn lookupUnknown(oid: Oid) *Obj {
    return lookupObject(oid) orelse createObject(oid);
}

pub fn objectAsType(obj: *Obj, typ: ObjType, quiet: bool) ?*Obj {
    if (obj.typ == typ) return obj;
    if (obj.typ == .none) {
        obj.typ = typ;
        return obj;
    }
    if (!quiet) util.err("object {s} is a {s}, not a {s}", .{ &hash.hex(obj.oid), obj.typ.name(), typ.name() });
    return null;
}

pub fn lookupTyped(oid: Oid, typ: ObjType) ?*Obj {
    if (lookupObject(oid)) |o| return objectAsType(o, typ, false);
    const o = createObject(oid);
    o.typ = typ;
    return o;
}

pub fn typeName(t: ObjType) ?[]const u8 {
    return switch (t) {
        .commit, .tree, .blob, .tag => t.name(),
        else => null,
    };
}

// ---------------------------------------------------------------------------
// shallow grafts

var shallow_loaded = false;
var shallow_set: hash.OidSet = .empty;

pub fn isShallow(oid: Oid) bool {
    if (!shallow_loaded) {
        shallow_loaded = true;
        const r = repo_mod.repo();
        const path = os.getenv("GIT_SHALLOW_FILE") orelse r.commonPath("shallow");
        if (os.readFile(path)) |data| {
            var it = std.mem.splitScalar(u8, data, '\n');
            while (it.next()) |l| {
                if (l.len >= 40) {
                    if (hash.fromHex(l[0..40])) |o| shallow_set.put(gpa, o, {}) catch util.oom();
                }
            }
        }
    }
    return shallow_set.contains(oid);
}

// ---------------------------------------------------------------------------
// reading objects

pub const LooseRead = struct {
    ok: bool = false,
    contents: ?[]u8 = null,
    real: Oid = hash.zero,
    typ: ?ObjType = null,
};

fn zerrString(st: c_int) []const u8 {
    return switch (st) {
        -4 => "out of memory",
        -6 => "wrong version",
        2 => "needs dictionary",
        -3 => "data stream error",
        -2 => "stream consistency error",
        else => "unknown error",
    };
}

fn gitInflate(s: *zlib.ZStream, flush: c_int) c_int {
    const st = zlib.inflate(s, flush);
    switch (st) {
        zlib.Z_BUF_ERROR, zlib.Z_OK, zlib.Z_STREAM_END => return st,
        else => {},
    }
    const m: []const u8 = if (s.msg) |p| std.mem.span(p) else "no message";
    util.err("inflate: {s} ({s})", .{ zerrString(st), m });
    return st;
}

fn typeFromString(s: []const u8) ?ObjType {
    return ObjType.fromName(s);
}

/// read_loose_object(): read and verify a loose object file, reporting
/// problems the way git does (unless quiet).
pub fn readLooseObject(path: []const u8, expected: Oid, quiet: bool) LooseRead {
    var res = LooseRead{};
    const map = os.readFile(path) orelse {
        if (!quiet) util.err("unable to mmap {s}: {s}", .{ path, os.lastErr() });
        return res;
    };
    var s = zlib.ZStream{};
    if (zlib.inflateInit_(&s, zlib.zlibVersion(), @sizeOf(zlib.ZStream)) != zlib.Z_OK) return res;
    defer _ = zlib.inflateEnd(&s);
    var hdr: [32]u8 = undefined;
    s.next_in = map.ptr;
    s.avail_in = @intCast(@min(map.len, std.math.maxInt(c_uint)));
    s.next_out = &hdr;
    s.avail_out = hdr.len;
    const st = gitInflate(&s, 0);
    const produced = hdr.len - s.avail_out;
    if ((st != zlib.Z_OK and st != zlib.Z_STREAM_END) or std.mem.indexOfScalar(u8, hdr[0..produced], 0) == null) {
        if (!quiet) util.err("unable to unpack header of {s}", .{path});
        return res;
    }
    const nul = std.mem.indexOfScalar(u8, hdr[0..produced], 0).?;
    const h = hdr[0..nul];
    // parse_loose_header
    const sp = std.mem.indexOfScalar(u8, h, ' ') orelse {
        if (!quiet) util.err("unable to parse header of {s}", .{path});
        return res;
    };
    const typ = typeFromString(h[0..sp]);
    var size: usize = 0;
    const digits = h[sp + 1 ..];
    var bad_size = digits.len == 0 or !std.ascii.isDigit(digits[0]);
    if (!bad_size) {
        if (digits[0] == '0') {
            if (digits.len != 1) bad_size = true;
        } else {
            for (digits) |ch| {
                if (!std.ascii.isDigit(ch)) {
                    bad_size = true;
                    break;
                }
                size = std.math.mul(usize, size, 10) catch util.die("size overflow", .{});
                size = std.math.add(usize, size, ch - '0') catch util.die("size overflow", .{});
            }
        }
    }
    if (bad_size) {
        if (!quiet) util.err("unable to parse header of {s}", .{path});
        return res;
    }
    if (typ == null) {
        if (!quiet) util.err("unable to parse type from header '{s}' of {s}", .{ h, path });
        return res;
    }
    res.typ = typ;
    // unpack_loose_rest
    const buf = gpa.alloc(u8, size + 1) catch util.oom();
    var n = produced - (nul + 1);
    if (n > size) n = size;
    @memcpy(buf[0..n], hdr[nul + 1 .. nul + 1 + n]);
    var status: c_int = zlib.Z_OK;
    s.next_out = buf.ptr + n;
    s.avail_out = @intCast(size - n);
    while (status == zlib.Z_OK) status = gitInflate(&s, zlib.Z_FINISH);
    var contents: ?[]u8 = buf[0..size];
    if (status != zlib.Z_STREAM_END) {
        if (!quiet) util.err("corrupt loose object '{s}'", .{&hash.hex(expected)});
        contents = null;
    } else if (s.avail_in != 0) {
        if (!quiet) util.err("garbage at end of loose object '{s}'", .{&hash.hex(expected)});
        contents = null;
    }
    const c = contents orelse {
        if (!quiet) util.err("unable to unpack contents of {s}", .{path});
        return res;
    };
    res.contents = c;
    res.real = odb_mod.hashObject(typ.?, c);
    if (!hash.eql(res.real, expected)) return res;
    res.ok = true;
    return res;
}

pub const ReadResult = struct { typ: ObjType, data: []const u8 };

/// Read an object without caching it. Corrupt loose objects die like git's
/// odb_read_object() when `die_if_corrupt` is set.
pub fn readObject(oid: Oid, die_if_corrupt: bool) ?ReadResult {
    const odb = repo_mod.repo().odb();
    if (util.eql(&hash.hex(oid), hash.empty_tree_hex)) return .{ .typ = .tree, .data = "" };
    var i: u32 = 0;
    while (i < 2) : (i += 1) {
        if (odb.findPacked(oid)) |loc| {
            if (odb.readPacked(loc.pack, loc.pack.offsetAt(loc.idx))) |o| return .{ .typ = o.typ, .data = o.data };
        }
        var corrupt_path: ?[]const u8 = null;
        for (odb.allDirs()) |dir| {
            const path = odb.looseObjectPath(dir, oid);
            if (os.lstatPath(path) == null) continue;
            const r = readLooseObject(path, oid, true);
            if (r.contents) |c| {
                if (r.typ) |t| return .{ .typ = t, .data = c };
            }
            if (corrupt_path == null) corrupt_path = path;
        }
        if (corrupt_path) |p| {
            if (die_if_corrupt) util.die("loose object {s} (stored in {s}) is corrupt", .{ &hash.hex(oid), p });
            return null;
        }
        if (i == 0) odb.reloadPacks();
    }
    return null;
}

pub fn readObjectType(oid: Oid) ?ObjType {
    const r = readObject(oid, false) orelse return null;
    return r.typ;
}

pub fn hasObject(oid: Oid) bool {
    return repo_mod.repo().odb().has(oid);
}

// ---------------------------------------------------------------------------
// parsing objects into the table

fn parseHex(buf: []const u8, pos: usize) ?Oid {
    if (pos + 40 > buf.len) return null;
    return hash.fromHex(buf[pos .. pos + 40]);
}

pub fn parseCommitBuffer(item: *Obj, buf: []const u8) i32 {
    if (item.parsed) return 0;
    item.parents = &.{};
    const hx = hash.hex(item.oid);
    const tail = buf.len;
    if (tail <= 45 + 1 or !util.startsWith(buf, "tree ") or buf[45] != '\n') {
        util.err("bogus commit object {s}", .{&hx});
        return -1;
    }
    const toid = parseHex(buf, 5) orelse {
        util.err("bad tree pointer in commit {s}", .{&hx});
        return -1;
    };
    const tree = lookupTyped(toid, .tree) orelse {
        util.err("bad tree pointer {s} in commit {s}", .{ &hash.hex(toid), &hx });
        return -1;
    };
    item.tree = tree;
    var p: usize = 46;
    const graft = isShallow(item.oid);
    var parents: std.ArrayList(*Obj) = .empty;
    while (p + 47 < tail and util.startsWith(buf[p..], "parent ")) {
        const poid = parseHex(buf, p + 7);
        if (tail <= p + 48 or poid == null or buf[p + 47] != '\n') {
            util.err("bad parents in commit {s}", .{&hx});
            return -1;
        }
        p += 48;
        if (graft) continue;
        const np = lookupTyped(poid.?, .commit) orelse {
            util.err("bad parent {s} in commit {s}", .{ &hash.hex(poid.?), &hx });
            return -1;
        };
        parents.append(gpa, np) catch util.oom();
    }
    item.parents = parents.items;
    item.parsed = true;
    return 0;
}

pub fn parseTagBuffer(item: *Obj, buf: []const u8) i32 {
    if (item.parsed) return 0;
    const hx = hash.hex(item.oid);
    if (buf.len < 40 + 24) return -1;
    if (!util.startsWith(buf, "object ")) return -1;
    const oid = parseHex(buf, 7) orelse return -1;
    var p: usize = 47;
    if (buf[p] != '\n') return -1;
    p += 1;
    if (!util.startsWith(buf[p..], "type ")) return -1;
    p += 5;
    const nl = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse return -1;
    if (nl - p >= 20) return -1;
    const tstr = buf[p..nl];
    p = nl + 1;
    const t = ObjType.fromName(tstr) orelse {
        util.err("unknown tag type '{s}' in {s}", .{ tstr, &hx });
        return -1;
    };
    item.tagged = lookupTyped(oid, t);
    if (item.tagged == null) {
        util.err("bad tag pointer to {s} in {s}", .{ &hash.hex(oid), &hx });
        return -1;
    }
    if (!(p + 4 < buf.len and util.startsWith(buf[p..], "tag "))) return -1;
    p += 4;
    const nl2 = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse return -1;
    item.tag_name = buf[p..nl2];
    item.parsed = true;
    return 0;
}

/// parse_object_buffer()
pub fn parseObjectBuffer(oid: Oid, typ: ObjType, data: []const u8) ?*Obj {
    switch (typ) {
        .blob => {
            const b = lookupTyped(oid, .blob) orelse return null;
            b.parsed = true;
            return b;
        },
        .tree => {
            const t = lookupTyped(oid, .tree) orelse return null;
            if (t.buffer == null) t.parsed = false;
            if (!t.parsed) {
                t.buffer = data;
                t.parsed = true;
            }
            return t;
        },
        .commit => {
            const c = lookupTyped(oid, .commit) orelse return null;
            if (parseCommitBuffer(c, data) != 0) return null;
            return c;
        },
        .tag => {
            const t = lookupTyped(oid, .tag) orelse return null;
            if (parseTagBuffer(t, data) != 0) return null;
            return t;
        },
        else => {
            util.warn("object {s} has unknown type id {d}", .{ &hash.hex(oid), @intFromEnum(typ) });
            return null;
        },
    }
}

/// parse_object()
pub fn parseObject(oid: Oid) ?*Obj {
    if (lookupObject(oid)) |o| {
        if (o.parsed) return o;
    }
    const r = readObject(oid, true) orelse return null;
    if (!hash.eql(odb_mod.hashObject(r.typ, r.data), oid)) {
        util.err("hash mismatch {s}", .{&hash.hex(oid)});
        return null;
    }
    return parseObjectBuffer(oid, r.typ, r.data);
}

fn parseCommit(item: *Obj) i32 {
    if (item.parsed) return 0;
    const r = readObject(item.oid, true) orelse {
        util.err("Could not read {s}", .{&hash.hex(item.oid)});
        return -1;
    };
    if (r.typ != .commit) {
        util.err("Object {s} not a commit", .{&hash.hex(item.oid)});
        return -1;
    }
    return parseCommitBuffer(item, r.data);
}

fn parseTree(item: *Obj) i32 {
    if (item.parsed and item.buffer != null) return 0;
    const r = readObject(item.oid, true) orelse {
        util.err("Could not read {s}", .{&hash.hex(item.oid)});
        return -1;
    };
    if (r.typ != .tree) {
        util.err("Object {s} not a tree", .{&hash.hex(item.oid)});
        return -1;
    }
    item.buffer = r.data;
    item.parsed = true;
    return 0;
}

fn parseTag(item: *Obj) i32 {
    if (item.parsed) return 0;
    const r = readObject(item.oid, true) orelse {
        util.err("Could not read {s}", .{&hash.hex(item.oid)});
        return -1;
    };
    if (r.typ != .tag) {
        util.err("Object {s} not a tag", .{&hash.hex(item.oid)});
        return -1;
    }
    return parseTagBuffer(item, r.data);
}

// ---------------------------------------------------------------------------
// tree entry decoding (tree-walk.c)

pub const TreeEntry = struct {
    mode: u16,
    name: []const u8,
    oid: Oid,
    start: usize,
    end: usize,
};

const Decoded = union(enum) { ok: TreeEntry, err: []const u8 };

fn decodeTreeEntry(buf: []const u8, pos: usize) Decoded {
    const size = buf.len - pos;
    if (size < 20 + 3 or buf[buf.len - 21] != 0) return .{ .err = "too-short tree object" };
    var p = pos;
    if (buf[p] == ' ') return .{ .err = "malformed mode in tree entry" };
    var mode: u16 = 0;
    while (true) {
        if (p >= buf.len) return .{ .err = "malformed mode in tree entry" };
        const c = buf[p];
        p += 1;
        if (c == ' ') break;
        if (c < '0' or c > '7') return .{ .err = "malformed mode in tree entry" };
        mode = (mode << 3) +% @as(u16, c - '0');
    }
    const nul = std.mem.indexOfScalarPos(u8, buf, p, 0) orelse return .{ .err = "too-short tree object" };
    if (nul == p) return .{ .err = "empty filename in tree entry" };
    if (nul + 21 > buf.len) return .{ .err = "too-short tree object" };
    return .{ .ok = .{ .mode = mode, .name = buf[p..nul], .oid = buf[nul + 1 ..][0..20].*, .start = pos, .end = nul + 21 } };
}

fn canonMode(mode: u16) u16 {
    const m: u32 = mode;
    if (m & os.S_IFMT == os.S_IFREG) return @intCast(os.S_IFREG | (if (m & 0o100 != 0) @as(u32, 0o755) else 0o644));
    if (m & os.S_IFMT == os.S_IFLNK) return @intCast(os.S_IFLNK);
    if (m & os.S_IFMT == os.S_IFDIR) return @intCast(os.S_IFDIR);
    return @intCast(os.S_IFGITLINK);
}

fn isDir(m: u16) bool {
    return @as(u32, m) & os.S_IFMT == os.S_IFDIR;
}
fn isReg(m: u16) bool {
    return @as(u32, m) & os.S_IFMT == os.S_IFREG;
}
fn isLnk(m: u16) bool {
    return @as(u32, m) & os.S_IFMT == os.S_IFLNK;
}
fn isGitlink(m: u16) bool {
    return @as(u32, m) & os.S_IFMT == os.S_IFGITLINK;
}

// ---------------------------------------------------------------------------
// walking

fn walkTree(tree: *Obj, data: ?*Obj, o: *Options) i32 {
    if (parseTree(tree) != 0) return -1;
    const name = getObjectName(o, tree.oid);
    const buf = tree.buffer.?;
    var res: i32 = 0;
    if (buf.len == 0) return 0;
    var cur = switch (decodeTreeEntry(buf, 0)) {
        .ok => |e| e,
        .err => |m| {
            util.err("{s}", .{m});
            return -1;
        },
    };
    while (true) {
        const entry = cur;
        var have_next = false;
        if (entry.end < buf.len) {
            switch (decodeTreeEntry(buf, entry.end)) {
                .ok => |e| {
                    cur = e;
                    have_next = true;
                },
                .err => |m| {
                    util.err("{s}", .{m});
                    break;
                },
            }
        }
        const mode = canonMode(entry.mode);
        if (!isGitlink(mode)) {
            var result: i32 = 0;
            if (isDir(mode)) {
                const obj = lookupTyped(entry.oid, .tree);
                if (name != null and obj != null) putObjectName(o, entry.oid, "{s}{s}/", .{ name.?, entry.name });
                result = o.walk.?(obj, .tree, data, o);
            } else if (isReg(mode) or isLnk(mode)) {
                const obj = lookupTyped(entry.oid, .blob);
                if (name != null and obj != null) putObjectName(o, entry.oid, "{s}{s}", .{ name.?, entry.name });
                result = o.walk.?(obj, .blob, data, o);
            } else {
                util.err("in tree {s}: entry {s} has bad mode {o:0>6}", .{ describeObject(o, tree.oid), entry.name, mode });
                result = -1;
            }
            if (result < 0) return result;
            if (res == 0) res = result;
        }
        if (!have_next) break;
    }
    return res;
}

fn walkCommit(commit: *Obj, data: ?*Obj, o: *Options) i32 {
    if (parseCommit(commit) != 0) return -1;
    const name = getObjectName(o, commit.oid);
    if (name) |n| putObjectName(o, commit.tree.?.oid, "{s}:", .{n});
    var result = o.walk.?(commit.tree, .tree, data, o);
    if (result < 0) return result;
    var res = result;

    var generation: i64 = 0;
    var name_prefix_len: usize = 0;
    if (name != null and commit.parents.len > 0) {
        const n = name.?;
        var len = n.len;
        if (len > 0 and n[len - 1] == '^') {
            generation = 1;
            name_prefix_len = len - 1;
        } else {
            var power: i64 = 1;
            generation = 0;
            while (len > 0 and std.ascii.isDigit(n[len - 1])) : (power *%= 10) {
                len -= 1;
                generation +%= power *% (n[len] - '0');
            }
            if (power > 1 and len > 0 and n[len - 1] == '~') {
                name_prefix_len = len - 1;
            } else {
                generation = 0;
                name_prefix_len = len;
            }
        }
    }
    var counter: usize = 0;
    for (commit.parents) |p| {
        if (name) |n| {
            if (counter > 0) {
                counter += 1;
                putObjectName(o, p.oid, "{s}^{d}", .{ n, counter });
            } else {
                counter += 1;
                if (generation > 0) {
                    putObjectName(o, p.oid, "{s}~{d}", .{ n[0..name_prefix_len], generation + 1 });
                } else putObjectName(o, p.oid, "{s}^", .{n});
            }
        }
        result = o.walk.?(p, .commit, data, o);
        if (result < 0) return result;
        if (res == 0) res = result;
    }
    return res;
}

fn walkTag(tag: *Obj, data: ?*Obj, o: *Options) i32 {
    const name = getObjectName(o, tag.oid);
    if (parseTag(tag) != 0) return -1;
    if (name) |n| putObjectName(o, tag.tagged.?.oid, "{s}", .{n});
    return o.walk.?(tag.tagged, null, data, o);
}

pub fn fsckWalk(obj0: ?*Obj, data: ?*Obj, o: *Options) i32 {
    const obj = obj0 orelse return -1;
    if (obj.typ == .none) _ = parseObject(obj.oid);
    switch (obj.typ) {
        .blob => return 0,
        .tree => return walkTree(obj, data, o),
        .commit => return walkCommit(obj, data, o),
        .tag => return walkTag(obj, data, o),
        else => {
            util.err("Unknown object type for {s}", .{describeObject(o, obj.oid)});
            return -1;
        },
    }
}

// ---------------------------------------------------------------------------
// path checks (utf8.c / path.c)

fn nextHfsChar(s: []const u8, pos: *usize) u21 {
    while (true) {
        if (pos.* >= s.len) return 0;
        const n = std.unicode.utf8ByteSequenceLength(s[pos.*]) catch return 0;
        if (pos.* + n > s.len) return 0;
        const c = std.unicode.utf8Decode(s[pos.* .. pos.* + n]) catch return 0;
        pos.* += n;
        switch (c) {
            0x200c...0x200f, 0x202a...0x202e, 0x206a...0x206f, 0xfeff => continue,
            else => return c,
        }
    }
}

fn isHfsDot(path: []const u8, needle: []const u8) bool {
    var pos: usize = 0;
    var c = nextHfsChar(path, &pos);
    if (c != '.') return false;
    for (needle) |nc| {
        c = nextHfsChar(path, &pos);
        if (c > 127) return false;
        if (std.ascii.toLower(@intCast(c)) != nc) return false;
    }
    c = nextHfsChar(path, &pos);
    if (c != 0 and c != '/') return false;
    return true;
}

fn at(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

fn isXplatformDirSep(c: u8) bool {
    return c == '/' or c == '\\';
}

pub fn isNtfsDotgit(name: []const u8) bool {
    var i: usize = 0;
    const c0 = at(name, i);
    i += 1;
    if (c0 == '.') {
        if (std.ascii.toLower(at(name, 1)) != 'g' or std.ascii.toLower(at(name, 2)) != 'i' or std.ascii.toLower(at(name, 3)) != 't') return false;
        i = 4;
    } else if (c0 == 'g' or c0 == 'G') {
        if (std.ascii.toLower(at(name, 1)) != 'i' or std.ascii.toLower(at(name, 2)) != 't' or at(name, 3) != '~' or at(name, 4) != '1') return false;
        i = 5;
    } else return false;
    while (true) {
        const c = at(name, i);
        i += 1;
        if (c == 0 or isXplatformDirSep(c) or c == ':') return true;
        if (c != '.' and c != ' ') return false;
    }
}

fn onlySpacesAndPeriods(name: []const u8, start: usize) bool {
    var i = start;
    while (true) {
        const c = at(name, i);
        i += 1;
        if (c == 0 or c == ':') return true;
        if (c != ' ' and c != '.') return false;
    }
}

fn strncasecmpEq(a: []const u8, off: usize, b: []const u8) bool {
    for (b, 0..) |bc, k| {
        const ac = at(a, off + k);
        if (std.ascii.toLower(ac) != std.ascii.toLower(bc)) return false;
    }
    return true;
}

fn isNtfsDotGeneric(name: []const u8, dotgit_name: []const u8, prefix: []const u8) bool {
    if (at(name, 0) == '.' and strncasecmpEq(name, 1, dotgit_name)) {
        return onlySpacesAndPeriods(name, dotgit_name.len + 1);
    }
    if (strncasecmpEq(name, 0, dotgit_name[0..6]) and at(name, 6) == '~' and at(name, 7) >= '1' and at(name, 7) <= '4') {
        return onlySpacesAndPeriods(name, 8);
    }
    var i: usize = 0;
    var saw_tilde = false;
    while (i < 8) : (i += 1) {
        const c = at(name, i);
        if (c == 0) return false;
        if (saw_tilde) {
            if (c < '0' or c > '9') return false;
        } else if (c == '~') {
            i += 1;
            if (at(name, i) < '1' or at(name, i) > '9') return false;
            saw_tilde = true;
        } else if (i >= 6) {
            return false;
        } else if (c & 0x80 != 0) {
            return false;
        } else if (std.ascii.toLower(c) != prefix[i]) return false;
    }
    return onlySpacesAndPeriods(name, i);
}

pub fn isHfsDotgit(n: []const u8) bool {
    return isHfsDot(n, "git");
}
pub fn isDotgitmodules(n: []const u8) bool {
    return isHfsDot(n, "gitmodules") or isNtfsDotGeneric(n, "gitmodules", "gi7eba");
}
fn isNtfsDotgitmodules(n: []const u8) bool {
    return isNtfsDotGeneric(n, "gitmodules", "gi7eba");
}
fn isDotgitattributes(n: []const u8) bool {
    return isHfsDot(n, "gitattributes") or isNtfsDotGeneric(n, "gitattributes", "gi7d29");
}
fn isDotgitignore(n: []const u8) bool {
    return isHfsDot(n, "gitignore") or isNtfsDotGeneric(n, "gitignore", "gi250a");
}
fn isDotmailmap(n: []const u8) bool {
    return isHfsDot(n, "mailmap") or isNtfsDotGeneric(n, "mailmap", "maba30");
}

// ---------------------------------------------------------------------------
// tree checks

const TREE_UNORDERED: i32 = -1;
const TREE_HAS_DUPS: i32 = -2;

fn isLessThanSlash(c: u8) bool {
    return c != 0 and c < '/';
}

fn verifyOrdered(mode1: u16, name1: []const u8, mode2: u16, name2: []const u8, candidates: *std.ArrayList([]const u8)) i32 {
    const len = @min(name1.len, name2.len);
    switch (std.mem.order(u8, name1[0..len], name2[0..len])) {
        .lt => return 0,
        .gt => return TREE_UNORDERED,
        .eq => {},
    }
    var c1 = at(name1, len);
    var c2 = at(name2, len);
    if (c1 == 0 and c2 == 0) return TREE_HAS_DUPS;
    if (c1 == 0 and isDir(mode1)) c1 = '/';
    if (c2 == 0 and isDir(mode2)) c2 = '/';

    if (c1 == 0 and isLessThanSlash(c2)) {
        candidates.append(gpa, name1) catch util.oom();
    } else if (c2 == '/' and isLessThanSlash(c1)) {
        while (true) {
            const f_name = candidates.pop() orelse break;
            const p = util.skipPrefix(name2, f_name) orelse continue;
            if (p.len == 0) return TREE_HAS_DUPS;
            if (isLessThanSlash(p[0])) {
                candidates.append(gpa, f_name) catch util.oom();
                break;
            }
        }
    }
    return if (c1 < c2) 0 else TREE_UNORDERED;
}

fn fsckTree(oid: Oid, buf: []const u8, o: *Options) i32 {
    var retval: i32 = 0;
    var has_null_sha1 = false;
    var has_full_path = false;
    var has_empty_name = false;
    var has_dot = false;
    var has_dotdot = false;
    var has_dotgit = false;
    var has_zero_pad = false;
    var has_bad_modes = false;
    var has_dup_entries = false;
    var not_properly_sorted = false;
    var has_large_name = false;
    var candidates: std.ArrayList([]const u8) = .empty;

    var cur: TreeEntry = undefined;
    var have = buf.len > 0;
    if (have) {
        switch (decodeTreeEntry(buf, 0)) {
            .ok => |e| cur = e,
            .err => |m| {
                util.err("{s}", .{m});
                retval += report(o, oid, .tree, .bad_tree, "cannot be parsed as a tree", .{});
                return retval;
            },
        }
    }
    var o_name: ?[]const u8 = null;
    var o_mode: u16 = 0;
    while (have) {
        const e = cur;
        const mode = e.mode;
        const name = e.name;
        has_null_sha1 = has_null_sha1 or hash.isZero(e.oid);
        has_full_path = has_full_path or std.mem.indexOfScalar(u8, name, '/') != null;
        has_empty_name = has_empty_name or name.len == 0;
        has_dot = has_dot or util.eql(name, ".");
        has_dotdot = has_dotdot or util.eql(name, "..");
        has_dotgit = has_dotgit or isHfsDotgit(name) or isNtfsDotgit(name);
        has_zero_pad = has_zero_pad or buf[e.start] == '0';
        has_large_name = has_large_name or name.len > max_tree_entry_len;

        if (isDotgitmodules(name)) {
            if (!isLnk(mode)) o.gitmodules_found.insert(e.oid) else retval += report(o, oid, .tree, .gitmodules_symlink, ".gitmodules is a symbolic link", .{});
        }
        if (isDotgitattributes(name)) {
            if (!isLnk(mode)) o.gitattributes_found.insert(e.oid) else retval += report(o, oid, .tree, .gitattributes_symlink, ".gitattributes is a symlink", .{});
        }
        if (isLnk(mode)) {
            if (isDotgitignore(name)) retval += report(o, oid, .tree, .gitignore_symlink, ".gitignore is a symlink", .{});
            if (isDotmailmap(name)) retval += report(o, oid, .tree, .mailmap_symlink, ".mailmap is a symlink", .{});
        }
        if (std.mem.indexOfScalar(u8, name, '\\')) |first_bs| {
            var bs: ?usize = first_bs;
            while (bs) |b| {
                const rest = name[b + 1 ..];
                has_dotgit = has_dotgit or isNtfsDotgit(rest);
                if (isNtfsDotgitmodules(rest)) {
                    if (!isLnk(mode)) o.gitmodules_found.insert(e.oid) else retval += report(o, oid, .tree, .gitmodules_symlink, ".gitmodules is a symbolic link", .{});
                }
                bs = if (std.mem.indexOfScalar(u8, rest, '\\')) |nb| b + 1 + nb else null;
            }
        }

        // update_tree_entry_gently
        if (e.end < buf.len) {
            switch (decodeTreeEntry(buf, e.end)) {
                .ok => |n| cur = n,
                .err => |m| {
                    util.err("{s}", .{m});
                    retval += report(o, oid, .tree, .bad_tree, "cannot be parsed as a tree", .{});
                    break;
                },
            }
        } else have = false;

        switch (mode) {
            0o100755, 0o100644, 0o120000, 0o040000, 0o160000 => {},
            0o100664 => {
                if (o.strict) has_bad_modes = true;
            },
            else => has_bad_modes = true,
        }

        if (o_name) |on| {
            switch (verifyOrdered(o_mode, on, mode, name, &candidates)) {
                TREE_UNORDERED => not_properly_sorted = true,
                TREE_HAS_DUPS => has_dup_entries = true,
                else => {},
            }
        }
        o_mode = mode;
        o_name = name;
    }

    if (has_null_sha1) retval += report(o, oid, .tree, .null_sha1, "contains entries pointing to null sha1", .{});
    if (has_full_path) retval += report(o, oid, .tree, .full_pathname, "contains full pathnames", .{});
    if (has_empty_name) retval += report(o, oid, .tree, .empty_name, "contains empty pathname", .{});
    if (has_dot) retval += report(o, oid, .tree, .has_dot, "contains '.'", .{});
    if (has_dotdot) retval += report(o, oid, .tree, .has_dotdot, "contains '..'", .{});
    if (has_dotgit) retval += report(o, oid, .tree, .has_dotgit, "contains '.git'", .{});
    if (has_zero_pad) retval += report(o, oid, .tree, .zero_padded_filemode, "contains zero-padded file modes", .{});
    if (has_bad_modes) retval += report(o, oid, .tree, .bad_filemode, "contains bad file modes", .{});
    if (has_dup_entries) retval += report(o, oid, .tree, .duplicate_entries, "contains duplicate file entries", .{});
    if (not_properly_sorted) retval += report(o, oid, .tree, .tree_not_sorted, "not properly sorted", .{});
    if (has_large_name) retval += report(o, oid, .tree, .large_pathname, "contains excessively large pathname", .{});
    return retval;
}

// ---------------------------------------------------------------------------
// commit / tag checks

fn verifyHeaders(buf: []const u8, oid: ?Oid, typ: ObjType, o: *Options) i32 {
    for (buf, 0..) |ch, i| {
        switch (ch) {
            0 => return report(o, oid, typ, .nul_in_header, "unterminated header: NUL at offset {d}", .{i}),
            '\n' => if (i + 1 < buf.len and buf[i + 1] == '\n') return 0,
            else => {},
        }
    }
    if (buf.len > 0 and buf[buf.len - 1] == '\n') return 0;
    return report(o, oid, typ, .unterminated_header, "unterminated header", .{});
}

fn fsckIdent(buf: []const u8, pos: *usize, oid: ?Oid, typ: ObjType, o: *Options) i32 {
    var p = pos.*;
    const nl = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse buf.len;
    pos.* = nl + 1;
    const end = buf.len;
    if (at(buf, p) == '<') return report(o, oid, typ, .missing_name_before_email, "invalid author/committer line - missing space before email", .{});
    while (true) {
        if (p >= end or buf[p] == '\n') return report(o, oid, typ, .missing_email, "invalid author/committer line - missing email", .{});
        if (buf[p] == '>') return report(o, oid, typ, .bad_name, "invalid author/committer line - bad name", .{});
        if (buf[p] == '<') break;
        p += 1;
    }
    if (buf[p - 1] != ' ') return report(o, oid, typ, .missing_space_before_email, "invalid author/committer line - missing space before email", .{});
    p += 1;
    while (true) {
        if (p >= end or buf[p] == '<' or buf[p] == '\n') return report(o, oid, typ, .bad_email, "invalid author/committer line - bad email", .{});
        if (buf[p] == '>') break;
        p += 1;
    }
    p += 1;
    if (at(buf, p) != ' ') return report(o, oid, typ, .missing_space_before_date, "invalid author/committer line - missing space before date", .{});
    p += 1;
    while (at(buf, p) == ' ' or at(buf, p) == '\t') p += 1;
    if (!std.ascii.isDigit(at(buf, p))) return report(o, oid, typ, .bad_date, "invalid author/committer line - bad date", .{});
    if (at(buf, p) == '0' and at(buf, p + 1) != ' ') return report(o, oid, typ, .zero_padded_date, "invalid author/committer line - zero-padded date", .{});
    // parse_timestamp_from_buf
    var overflow = false;
    {
        var q = p;
        var cnt: usize = 0;
        var v: u64 = 0;
        var sat = false;
        while (q < end and std.ascii.isDigit(buf[q])) {
            if (cnt >= 23) {
                overflow = true;
                break;
            }
            const d: u64 = buf[q] - '0';
            if (!sat) {
                const m = @mulWithOverflow(v, 10);
                const a = @addWithOverflow(m[0], d);
                if (m[1] != 0 or a[1] != 0) sat = true else v = a[0];
            }
            cnt += 1;
            q += 1;
        }
        if (!overflow) {
            if (sat or v == std.math.maxInt(u64)) overflow = true;
            p = q;
        }
    }
    if (overflow) return report(o, oid, typ, .bad_date_overflow, "invalid author/committer line - date causes integer overflow", .{});
    if (at(buf, p) != ' ') return report(o, oid, typ, .bad_date, "invalid author/committer line - bad date", .{});
    p += 1;
    if ((at(buf, p) != '+' and at(buf, p) != '-') or
        !std.ascii.isDigit(at(buf, p + 1)) or
        !std.ascii.isDigit(at(buf, p + 2)) or
        !std.ascii.isDigit(at(buf, p + 3)) or
        !std.ascii.isDigit(at(buf, p + 4)) or
        at(buf, p + 5) != '\n')
        return report(o, oid, typ, .bad_timezone, "invalid author/committer line - bad time zone", .{});
    return 0;
}

fn lineEnd(buf: []const u8, p: usize) usize {
    return std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse buf.len;
}

fn fsckCommit(oid: Oid, buf: []const u8, o: *Options) i32 {
    if (verifyHeaders(buf, oid, .commit, o) != 0) return -1;
    var p: usize = 0;
    var err: i32 = 0;
    if (!util.startsWith(buf, "tree ")) return report(o, oid, .commit, .missing_tree, "invalid format - expected 'tree' line", .{});
    p = 5;
    if (parseHex(buf, p) == null or at(buf, p + 40) != '\n') {
        err = report(o, oid, .commit, .bad_tree_sha1, "invalid 'tree' line format - bad sha1", .{});
        if (err != 0) return err;
        p = if (parseHex(buf, p) != null) p + 41 else lineEnd(buf, p) + 1;
    } else p += 41;
    while (p < buf.len and util.startsWith(buf[p..], "parent ")) {
        p += 7;
        if (parseHex(buf, p) == null or at(buf, p + 40) != '\n') {
            err = report(o, oid, .commit, .bad_parent_sha1, "invalid 'parent' line format - bad sha1", .{});
            if (err != 0) return err;
            p = if (parseHex(buf, p) != null) p + 41 else lineEnd(buf, p) + 1;
        } else p += 41;
    }
    var author_count: u32 = 0;
    while (p < buf.len and util.startsWith(buf[p..], "author ")) {
        p += 7;
        author_count += 1;
        err = fsckIdent(buf, &p, oid, .commit, o);
        if (err != 0) return err;
    }
    if (author_count < 1) {
        err = report(o, oid, .commit, .missing_author, "invalid format - expected 'author' line", .{});
    } else if (author_count > 1) {
        err = report(o, oid, .commit, .multiple_authors, "invalid format - multiple 'author' lines", .{});
    }
    if (err != 0) return err;
    if (p >= buf.len or !util.startsWith(buf[p..], "committer ")) return report(o, oid, .commit, .missing_committer, "invalid format - expected 'committer' line", .{});
    p += 10;
    err = fsckIdent(buf, &p, oid, .commit, o);
    if (err != 0) return err;
    if (std.mem.indexOfScalar(u8, buf, 0) != null) {
        err = report(o, oid, .commit, .nul_in_commit, "NUL byte in the commit object body", .{});
        if (err != 0) return err;
    }
    return 0;
}

/// fsck_tag_standalone(). `tagged_type` is set to the parsed type (null if
/// invalid).
pub fn fsckTagStandalone(oid: ?Oid, buf: []const u8, o: *Options, tagged_oid: *Oid, tagged_type: *?ObjType) i32 {
    var ret = verifyHeaders(buf, oid, .tag, o);
    if (ret != 0) return ret;
    var p: usize = 0;
    if (!util.startsWith(buf, "object ")) return report(o, oid, .tag, .missing_object, "invalid format - expected 'object' line", .{});
    p = 7;
    if (parseHex(buf, p)) |t| tagged_oid.* = t;
    if (parseHex(buf, p) == null or at(buf, p + 40) != '\n') {
        ret = report(o, oid, .tag, .bad_object_sha1, "invalid 'object' line format - bad sha1", .{});
        if (ret != 0) return ret;
        p = if (parseHex(buf, p) != null) p + 41 else lineEnd(buf, p) + 1;
    } else p += 41;

    if (p >= buf.len or !util.startsWith(buf[p..], "type ")) return report(o, oid, .tag, .missing_type_entry, "invalid format - expected 'type' line", .{});
    p += 5;
    const eol = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse return report(o, oid, .tag, .missing_type, "invalid format - unexpected end after 'type' line", .{});
    tagged_type.* = ObjType.fromName(buf[p..eol]);
    if (tagged_type.* == null) ret = report(o, oid, .tag, .bad_type, "invalid 'type' value", .{});
    if (ret != 0) return ret;
    p = eol + 1;

    if (p >= buf.len or !util.startsWith(buf[p..], "tag ")) return report(o, oid, .tag, .missing_tag_entry, "invalid format - expected 'tag' line", .{});
    p += 4;
    const eol2 = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse return report(o, oid, .tag, .missing_tag, "invalid format - unexpected end after 'type' line", .{});
    const tagname = buf[p..eol2];
    const refname = util.concat(&.{ "refs/tags/", tagname });
    if (std.mem.indexOfScalar(u8, tagname, 0) != null or !refs.checkRefnameFormat(refname, 0)) {
        ret = report(o, oid, .tag, .bad_tag_name, "invalid 'tag' name: {s}", .{tagname});
        if (ret != 0) return ret;
    }
    p = eol2 + 1;

    if (p >= buf.len or !util.startsWith(buf[p..], "tagger ")) {
        ret = report(o, oid, .tag, .missing_tagger_entry, "invalid format - expected 'tagger' line", .{});
        if (ret != 0) return ret;
    } else {
        p += 7;
        ret = fsckIdent(buf, &p, oid, .tag, o);
    }

    if (p < buf.len and (util.startsWith(buf[p..], "gpgsig ") or util.startsWith(buf[p..], "gpgsig-sha256 "))) {
        p += if (util.startsWith(buf[p..], "gpgsig ")) @as(usize, 7) else 14;
        const e = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse return report(o, oid, .tag, .bad_gpgsig, "invalid format - unexpected end after 'gpgsig' or 'gpgsig-sha256' line", .{});
        p = e + 1;
        while (p < buf.len and buf[p] == ' ') {
            const e2 = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse return report(o, oid, .tag, .bad_header_continuation, "invalid format - unexpected end in 'gpgsig' or 'gpgsig-sha256' continuation line", .{});
            p = e2 + 1;
        }
    }

    if (p < buf.len and buf[p] != '\n') {
        ret = report(o, oid, .tag, .extra_header_entry, "invalid format - extra header(s) after 'tagger'", .{});
        if (ret != 0) return ret;
    }
    return ret;
}

// ---------------------------------------------------------------------------
// blob checks (.gitmodules / .gitattributes)

fn checkSubmoduleName(name: []const u8) bool {
    if (name.len == 0) return false;
    var i: usize = 0;
    // always start inside a component
    while (true) {
        if (at(name, i) == '.' and at(name, i + 1) == '.' and (i + 2 >= name.len or isXplatformDirSep(name[i + 2]))) return false;
        while (i < name.len and !isXplatformDirSep(name[i])) i += 1;
        if (i >= name.len) break;
        i += 1;
    }
    return true;
}

fn urlDecode(s: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        if (s[i] == '%' and i + 2 < s.len + 0 and i + 2 <= s.len - 1) {
            const v = std.fmt.parseInt(u8, s[i + 1 .. i + 3], 16) catch {
                util.bufByte(&b, s[i]);
                continue;
            };
            util.bufByte(&b, v);
            i += 2;
        } else util.bufByte(&b, s[i]);
    }
    return b.items;
}

fn startsWithDotSlash(s: []const u8) bool {
    return at(s, 0) == '.' and isXplatformDirSep(at(s, 1));
}
fn startsWithDotDotSlash(s: []const u8) bool {
    return at(s, 0) == '.' and at(s, 1) == '.' and isXplatformDirSep(at(s, 2));
}

fn checkSubmoduleUrl(url: []const u8) bool {
    if (url.len > 0 and url[0] == '-') return false;
    if (startsWithDotSlash(url) or startsWithDotDotSlash(url) or util.startsWith(url, "git://")) {
        if (std.mem.indexOfScalar(u8, urlDecode(url), '\n') != null) return false;
        var next = url;
        var dotdots: usize = 0;
        while (true) {
            if (startsWithDotDotSlash(next)) {
                dotdots += 1;
                next = next[3..];
                continue;
            }
            if (startsWithDotSlash(next)) {
                next = next[2..];
                continue;
            }
            break;
        }
        if (dotdots > 0 and (at(next, 0) == ':' or at(next, 0) == '/')) return false;
        return true;
    }
    var curl: ?[]const u8 = null;
    for ([_][]const u8{ "http::", "https::", "ftp::", "ftps::" }) |pfx| {
        if (util.skipPrefix(url, pfx)) |r| {
            curl = r;
            break;
        }
    }
    if (curl == null) {
        for ([_][]const u8{ "http://", "https://", "ftp://", "ftps://" }) |pfx| {
            if (util.startsWith(url, pfx)) {
                curl = url;
                break;
            }
        }
    }
    if (curl) |c| {
        // approximate url_normalize(): need "<scheme>://<host>"
        const sep = std.mem.indexOf(u8, c, "://") orelse return false;
        const rest = c[sep + 3 ..];
        const host_end = std.mem.indexOfAny(u8, rest, "/?#") orelse rest.len;
        if (host_end == 0) return false;
        if (std.mem.indexOfScalar(u8, urlDecode(c), '\n') != null) return false;
        return true;
    }
    return true;
}

const GitmodulesData = struct { oid: Oid, o: *Options, ret: i32 = 0 };

fn gitmodulesFn(ctx: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo) i32 {
    _ = kvi;
    const d: *GitmodulesData = @ptrCast(@alignCast(ctx));
    const parts = config.parseConfigKey(key, "submodule") orelse return 0;
    const name = parts.sub orelse return 0;
    const k = parts.key;
    if (!checkSubmoduleName(name)) d.ret |= report(d.o, d.oid, .blob, .gitmodules_name, "disallowed submodule name: {s}", .{name});
    if (value) |v| {
        if (util.eql(k, "url") and !checkSubmoduleUrl(v)) d.ret |= report(d.o, d.oid, .blob, .gitmodules_url, "disallowed submodule url: {s}", .{v});
        if (util.eql(k, "path") and v.len > 0 and v[0] == '-') d.ret |= report(d.o, d.oid, .blob, .gitmodules_path, "disallowed submodule path: {s}", .{v});
        if (util.eql(k, "update") and v.len > 0 and v[0] == '!' and !util.eql(v, "none") and !util.eql(v, "checkout") and !util.eql(v, "rebase") and !util.eql(v, "merge"))
            d.ret |= report(d.o, d.oid, .blob, .gitmodules_update, "disallowed submodule update setting: {s}", .{v});
    }
    return 0;
}

const ATTR_MAX_LINE_LENGTH = 2048;
const ATTR_MAX_FILE_SIZE = 100 * 1024 * 1024;

fn fsckBlob(oid: Oid, buf: ?[]const u8, o: *Options) i32 {
    var ret: i32 = 0;
    if (o.skip_oids.contains(oid)) return 0;
    if (o.gitmodules_found.contains(oid)) {
        o.gitmodules_done.put(gpa, oid, {}) catch util.oom();
        const b = buf orelse return report(o, oid, .blob, .gitmodules_large, ".gitmodules too large to parse", .{});
        var data = GitmodulesData{ .oid = oid, .o = o };
        const src = config.Source{ .data = b, .origin_type = .blob, .name = ".gitmodules", .scope = .unknown, .error_action = .silent };
        if (config.parseSource(src, .{ .f = gitmodulesFn, .ctx = &data }, null, null) != 0)
            data.ret |= report(o, oid, .blob, .gitmodules_parse, "could not parse gitmodules blob", .{});
        ret |= data.ret;
    }
    if (o.gitattributes_found.contains(oid)) {
        o.gitattributes_done.put(gpa, oid, {}) catch util.oom();
        const b = buf orelse return report(o, oid, .blob, .gitattributes_large, ".gitattributes too large to parse", .{});
        if (b.len > ATTR_MAX_FILE_SIZE) return report(o, oid, .blob, .gitattributes_large, ".gitattributes too large to parse", .{});
        const end = std.mem.indexOfScalar(u8, b, 0) orelse b.len;
        var p: usize = 0;
        while (p < end) {
            const eol = std.mem.indexOfScalarPos(u8, b[0..end], p, '\n') orelse end;
            if (eol - p >= ATTR_MAX_LINE_LENGTH) {
                ret |= report(o, oid, .blob, .gitattributes_line_length, ".gitattributes has too long lines to parse", .{});
                break;
            }
            p = if (eol < end) eol + 1 else eol;
        }
    }
    return ret;
}

pub fn fsckBuffer(oid: Oid, typ: ObjType, data: ?[]const u8, o: *Options) i32 {
    return switch (typ) {
        .blob => fsckBlob(oid, data, o),
        .tree => fsckTree(oid, data orelse "", o),
        .commit => fsckCommit(oid, data orelse "", o),
        .tag => blk: {
            var t: Oid = hash.zero;
            var tt: ?ObjType = null;
            break :blk fsckTagStandalone(oid, data orelse "", o, &t, &tt);
        },
        else => report(o, oid, typ, .unknown_type, "unknown type '{d}' (internal fsck error)", .{@intFromEnum(typ)}),
    };
}

pub fn fsckObject(obj: ?*Obj, data: ?[]const u8, o: *Options) i32 {
    const ob = obj orelse return report(o, null, .none, .bad_object_sha1, "no valid object to fsck", .{});
    return fsckBuffer(ob.oid, ob.typ, data, o);
}

fn fsckBlobs(found: *OidList, done: *hash.OidSet, msg_missing: MsgId, msg_type: MsgId, o: *Options, blob_type: []const u8) i32 {
    var ret: i32 = 0;
    for (found.list.items) |oid| {
        if (done.contains(oid)) continue;
        const r = readObject(oid, true) orelse {
            ret |= report(o, oid, .blob, msg_missing, "unable to read {s} blob", .{blob_type});
            continue;
        };
        if (r.typ == .blob) {
            ret |= fsckBlob(oid, r.data, o);
        } else ret |= report(o, oid, r.typ, msg_type, "non-blob found at {s}", .{blob_type});
    }
    found.clear();
    done.* = .empty;
    return ret;
}

pub fn fsckFinish(o: *Options) i32 {
    var ret: i32 = 0;
    ret |= fsckBlobs(&o.gitmodules_found, &o.gitmodules_done, .gitmodules_missing, .gitmodules_blob, o, ".gitmodules");
    ret |= fsckBlobs(&o.gitattributes_found, &o.gitattributes_done, .gitattributes_missing, .gitattributes_blob, o, ".gitattributes");
    return ret;
}
