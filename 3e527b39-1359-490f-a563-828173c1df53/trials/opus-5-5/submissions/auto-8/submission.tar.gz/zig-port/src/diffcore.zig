//! diffcore: rename/copy detection, break, pickaxe, order, rotate (port of diffcore-*.c)
const std = @import("std");
const util = @import("util.zig");
const diff = @import("diff.zig");

pub const Changes = struct { src_copied: u64, literal_added: u64 };

pub fn countChanges(one: *diff.Filespec, two: *diff.Filespec) Changes {
    _ = one;
    _ = two;
    return .{ .src_copied = 0, .literal_added = 0 };
}
pub fn breakPairs(o: *diff.DiffOptions, score: i32) void {
    _ = o;
    _ = score;
}
pub fn rename(o: *diff.DiffOptions) void {
    _ = o;
}
pub fn mergeBroken() void {}
pub fn pickaxe(o: *diff.DiffOptions) void {
    _ = o;
}
pub fn order(of: []const u8) void {
    _ = of;
}
pub fn rotate(o: *diff.DiffOptions) void {
    _ = o;
}
