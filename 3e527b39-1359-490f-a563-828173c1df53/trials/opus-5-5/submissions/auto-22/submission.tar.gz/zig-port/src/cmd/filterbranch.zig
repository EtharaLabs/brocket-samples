//! git filter-branch (port of git-filter-branch.sh)
//!
//! The driver logic lives here; the user supplied filters are shell
//! snippets, so they are evaluated by one long-lived /bin/sh coprocess
//! (mirroring the single shell of the original script, so variables and
//! functions defined by --setup or one filter stay visible to later
//! filters).  Each command we send is followed by `echo $? >&9`; fd 9 is a
//! pipe back to us carrying the exit status.

const std = @import("std");
const c = std.c;
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const gpa = util.gpa;

extern "c" fn fork() c_int;
extern "c" fn pipe(fds: *[2]c_int) c_int;
extern "c" fn execv(file: [*:0]const u8, argv: [*:null]const ?[*:0]const u8) c_int;
extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn sleep(secs: c_uint) c_uint;

const usage_text =
    "[--setup <command>] [--subdirectory-filter <directory>] [--env-filter <command>]\n" ++
    "\t[--tree-filter <command>] [--index-filter <command>]\n" ++
    "\t[--parent-filter <command>] [--msg-filter <command>]\n" ++
    "\t[--commit-filter <command>] [--tag-name-filter <command>]\n" ++
    "\t[--original <namespace>]\n" ++
    "\t[-d <directory>] [-f | --force] [--state-branch <branch>]\n" ++
    "\t[--] [<rev-list options>...]";

const warning_text =
    "WARNING: git-filter-branch has a glut of gotchas generating mangled history\n" ++
    "\t rewrites.  Hit Ctrl-C before proceeding to abort, then use an\n" ++
    "\t alternative filtering tool such as 'git filter-repo'\n" ++
    "\t (https://github.com/newren/git-filter-repo/) instead.  See the\n" ++
    "\t filter-branch manual page for more details; to squelch this warning,\n" ++
    "\t set FILTER_BRANCH_SQUELCH_WARNING=1.\n";

/// Shell functions available to the filters (the `$functions` of the script).
const functions_text =
    \\EMPTY_TREE=$(git hash-object -t tree /dev/null)
    \\
    \\warn () {
    \\    echo "$*" >&2
    \\}
    \\
    \\map()
    \\{
    \\    # if it was not rewritten, take the original
    \\    if test -r "$workdir/../map/$1"
    \\    then
    \\        cat "$workdir/../map/$1"
    \\    else
    \\        echo "$1"
    \\    fi
    \\}
    \\
    \\# if you run 'skip_commit "$@"' in a commit filter, it will print
    \\# the (mapped) parents, effectively skipping the commit.
    \\
    \\skip_commit()
    \\{
    \\    shift;
    \\    while [ -n "$1" ];
    \\    do
    \\        shift;
    \\        map "$1";
    \\        shift;
    \\    done;
    \\}
    \\
    \\# if you run 'git_commit_non_empty_tree "$@"' in a commit filter,
    \\# it will skip commits that leave the tree untouched, commit the other.
    \\git_commit_non_empty_tree()
    \\{
    \\    if test $# = 3 && test "$1" = $(git rev-parse "$3^{tree}"); then
    \\        map "$3"
    \\    elif test $# = 1 && test "$1" = $EMPTY_TREE; then
    \\        :
    \\    else
    \\        git commit-tree "$@"
    \\    fi
    \\}
    \\# override die(): this version puts in an extra line break, so that
    \\# the progress is still visible
    \\
    \\die()
    \\{
    \\    echo >&2
    \\    echo "$*" >&2
    \\    exit 1
    \\}
;

/// What git-sh-setup adds on top (it is sourced after $functions in the
/// script, so its die() wins in the main shell).
const sh_setup_text =
    \\unset CDPATH
    \\die () {
    \\    die_with_status 1 "$@"
    \\}
    \\die_with_status () {
    \\    status=$1
    \\    shift
    \\    printf >&2 '%s\n' "$*"
    \\    exit "$status"
    \\}
    \\is_bare_repository () {
    \\    git rev-parse --is-bare-repository
    \\}
    \\set_reflog_action() {
    \\    if [ -z "${GIT_REFLOG_ACTION:+set}" ]
    \\    then
    \\        GIT_REFLOG_ACTION="$*"
    \\        export GIT_REFLOG_ACTION
    \\    fi
    \\}
    \\
;

// ---------------------------------------------------------------- state

var tempdir: []const u8 = ".git-rewrite";
var tempdir_abs: ?[]const u8 = null;
var orig_dir: []const u8 = "";
var sh_pid: c_int = -1;
var sh_in: c_int = -1;
var sh_st: c_int = -1;

fn cleanup() void {
    if (sh_in >= 0) {
        _ = c.close(sh_in);
        sh_in = -1;
    }
    if (sh_pid > 0) {
        _ = proc.wait(sh_pid);
        sh_pid = -1;
    }
    if (tempdir_abs) |t| {
        _ = os.chdir(orig_dir);
        os.removeTree(t);
        tempdir_abs = null;
    }
}

fn exitWith(code: u8) noreturn {
    util.flushStdout();
    cleanup();
    os.exit(code);
}

/// git-sh-setup's die(): message to stderr, exit 1 (running the trap).
fn die(comptime f: []const u8, a: anytype) noreturn {
    util.flushStdout();
    util.eprint(f ++ "\n", a);
    exitWith(1);
}

fn warn(comptime f: []const u8, a: anytype) void {
    util.flushStdout();
    util.eprint(f ++ "\n", a);
}

fn gitArgv(args: []const []const u8) []const []const u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return argv.items;
}

fn stripNl(s: []const u8) []const u8 {
    var r = s;
    while (r.len > 0 and r[r.len - 1] == '\n') r = r[0 .. r.len - 1];
    return r;
}

const Cap = struct { out: []const u8, ok: bool, status: u8 };

/// $(git ...)
fn capture(args: []const []const u8, silent: bool) Cap {
    const r = os.run(gitArgv(args), .{ .capture_stdout = true, .no_stderr = silent });
    return .{ .out = stripNl(r.stdout), .ok = r.status == 0, .status = r.status };
}

fn captureEnv(args: []const []const u8, env: []const [2][]const u8) Cap {
    const r = os.run(gitArgv(args), .{ .capture_stdout = true, .env = env });
    return .{ .out = stripNl(r.stdout), .ok = r.status == 0, .status = r.status };
}

fn captureIn(args: []const []const u8, input: []const u8) Cap {
    const r = os.run(gitArgv(args), .{ .capture_stdout = true, .stdin_data = input });
    return .{ .out = stripNl(r.stdout), .ok = r.status == 0, .status = r.status };
}

fn runGit(args: []const []const u8, o: os.SpawnOpts) u8 {
    return os.run(gitArgv(args), o).status;
}

fn quietOk(args: []const []const u8) bool {
    const r = os.run(gitArgv(args), .{ .capture_stdout = true, .no_stderr = true });
    return r.status == 0;
}

fn sq(s: []const u8) []const u8 {
    var b: util.Buf = .empty;
    util.sqQuote(&b, s);
    return b.items;
}

fn isWs(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n';
}

/// Split on IFS whitespace.
fn words(s: []const u8) [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    var i: usize = 0;
    while (i < s.len) {
        while (i < s.len and isWs(s[i])) i += 1;
        if (i >= s.len) break;
        const st = i;
        while (i < s.len and !isWs(s[i])) i += 1;
        l.append(gpa, s[st..i]) catch util.oom();
    }
    return l.items;
}

/// Parse the output of `git rev-parse --sq` (as `eval set -- "..."` would).
fn parseSq(s: []const u8) [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    var cur: util.Buf = .empty;
    var in_word = false;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        const ch = s[i];
        if (ch == '\'') {
            in_word = true;
            i += 1;
            while (i < s.len and s[i] != '\'') : (i += 1) util.bufByte(&cur, s[i]);
        } else if (ch == '\\' and i + 1 < s.len) {
            in_word = true;
            i += 1;
            util.bufByte(&cur, s[i]);
        } else if (isWs(ch)) {
            if (in_word) {
                l.append(gpa, cur.items) catch util.oom();
                cur = .empty;
                in_word = false;
            }
        } else {
            in_word = true;
            util.bufByte(&cur, ch);
        }
    }
    if (in_word) l.append(gpa, cur.items) catch util.oom();
    return l.items;
}

/// `read a b c` style split of a line into the first fields and the rest.
fn readFields(line: []const u8, n: usize) [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    var t = std.mem.trim(u8, line, " \t");
    while (l.items.len + 1 < n) {
        if (t.len == 0) break;
        const e = std.mem.indexOfAny(u8, t, " \t") orelse t.len;
        l.append(gpa, t[0..e]) catch util.oom();
        t = std.mem.trimLeft(u8, t[e..], " \t");
    }
    l.append(gpa, t) catch util.oom();
    while (l.items.len < n) l.append(gpa, "") catch util.oom();
    return l.items;
}

fn lines(s: []const u8) [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    if (s.len == 0) return l.items;
    var it = std.mem.splitScalar(u8, s, '\n');
    while (it.next()) |x| l.append(gpa, x) catch util.oom();
    if (l.items.len > 0 and l.items[l.items.len - 1].len == 0) _ = l.pop();
    return l.items;
}

// ---------------------------------------------------------------- shell

fn shStart(preamble: []const u8) void {
    var cmd_pipe: [2]c_int = .{ -1, -1 };
    var st_pipe: [2]c_int = .{ -1, -1 };
    if (pipe(&cmd_pipe) != 0 or pipe(&st_pipe) != 0) die("cannot create pipe", .{});
    util.flushStdout();
    const pid = fork();
    if (pid < 0) die("fork failed", .{});
    if (pid == 0) {
        _ = signal(13, 0);
        _ = c.dup2(cmd_pipe[0], 0);
        _ = c.dup2(st_pipe[1], 9);
        _ = c.close(cmd_pipe[0]);
        _ = c.close(cmd_pipe[1]);
        _ = c.close(st_pipe[0]);
        if (st_pipe[1] != 9) _ = c.close(st_pipe[1]);
        const argv = [_:null]?[*:0]const u8{ "/bin/sh", null };
        _ = execv("/bin/sh", &argv);
        c._exit(127);
    }
    _ = c.close(cmd_pipe[0]);
    _ = c.close(st_pipe[1]);
    sh_pid = pid;
    sh_in = cmd_pipe[1];
    sh_st = st_pipe[0];
    _ = shExec(preamble);
}

/// Run a script in the coprocess shell, return the status of its last command.
/// If the shell exits (e.g. `exit` or die in a filter), we exit with its status.
fn shExec(script: []const u8) u8 {
    util.flushStdout();
    const full = util.concat(&.{ script, "\necho $? >&9\n" });
    const old = signal(13, 1);
    os.writeAll(sh_in, full) catch {};
    _ = signal(13, old);
    var buf: util.Buf = .empty;
    while (true) {
        var b: [1]u8 = undefined;
        const n = c.read(sh_st, &b, 1);
        if (n <= 0) {
            // the shell went away
            _ = c.close(sh_in);
            sh_in = -1;
            const st = proc.wait(sh_pid);
            sh_pid = -1;
            exitWith(st);
        }
        if (b[0] == '\n') break;
        util.bufByte(&buf, b[0]);
    }
    return std.fmt.parseInt(u8, std.mem.trim(u8, buf.items, " "), 10) catch 1;
}

/// eval "$filter" < /dev/null in the main shell
fn evalFilter(f: []const u8) u8 {
    return shExec(util.concat(&.{ "{ eval ", sq(f), "\n} </dev/null 9>&-" }));
}

// ---------------------------------------------------------------- helpers

fn mapCommit(workdir: []const u8, sha: []const u8) []const u8 {
    const p = util.concat(&.{ workdir, "/../map/", sha });
    if (os.access(p, 4)) {
        if (os.readFile(p)) |d| return d;
    }
    return util.concat(&.{ sha, "\n" });
}

/// The shell assignments produced by set_ident (parse_ident_from_commit
/// author AUTHOR committer COMMITTER + finish_ident).
fn identScript(commit: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var it = std.mem.splitScalar(u8, commit, '\n');
    while (it.next()) |line| {
        if (line.len == 0) break;
        const kinds = [_][2][]const u8{ .{ "author ", "AUTHOR" }, .{ "committer ", "COMMITTER" } };
        for (kinds) |k| {
            if (!util.startsWith(line, k[0])) continue;
            const rest = line[k[0].len..];
            var name: []const u8 = line;
            var email: []const u8 = line;
            var date: []const u8 = line;
            const lt = std.mem.indexOfScalar(u8, rest, '<');
            if (lt) |l| {
                // \([^<]*\) <[^>]*> .*$
                const gt = std.mem.indexOfScalarPos(u8, rest, l, '>');
                if (l >= 1 and rest[l - 1] == ' ' and gt != null and gt.? + 1 < rest.len and rest[gt.? + 1] == ' ') {
                    name = rest[0 .. l - 1];
                    email = rest[l + 1 .. gt.?];
                    date = util.concat(&.{ "@", rest[gt.? + 2 ..] });
                }
            }
            util.bufPrint(&b, "GIT_{s}_NAME={s}\n", .{ k[1], sq(name) });
            util.bufPrint(&b, "GIT_{s}_EMAIL={s}\n", .{ k[1], sq(email) });
            util.bufPrint(&b, "GIT_{s}_DATE={s}\n", .{ k[1], sq(date) });
        }
    }
    for ([_][]const u8{ "AUTHOR", "COMMITTER" }) |w| {
        util.bufPrint(&b, "case \"$GIT_{s}_NAME\" in \"\") GIT_{s}_NAME=\"${{GIT_{s}_EMAIL%%@*}}\" && export GIT_{s}_NAME;; esac\n", .{ w, w, w, w });
        util.bufPrint(&b, "export GIT_{s}_NAME\nexport GIT_{s}_EMAIL\nexport GIT_{s}_DATE\n", .{ w, w, w });
    }
    return b.items;
}

fn envOrEmpty(n: []const u8) []const u8 {
    return os.getenv(n) orelse "";
}

fn isBare() bool {
    const r = capture(&.{ "rev-parse", "--is-bare-repository" }, false);
    return !util.eql(r.out, "false");
}

fn requireCleanWorkTree() void {
    if (!quietOut(&.{ "rev-parse", "--verify", "HEAD" })) os.exit(1);
    _ = runGit(&.{ "update-index", "-q", "--ignore-submodules", "--refresh" }, .{});
    var e = false;
    if (runGit(&.{ "diff-files", "--quiet", "--ignore-submodules" }, .{}) != 0) {
        util.eprint("Cannot rewrite branches: You have unstaged changes.\n", .{});
        e = true;
    }
    if (runGit(&.{ "diff-index", "--cached", "--quiet", "--ignore-submodules", "HEAD", "--" }, .{}) != 0) {
        if (!e) {
            util.eprint("Cannot rewrite branches: Your index contains uncommitted changes.\n", .{});
        } else {
            util.eprint("Additionally, your index contains uncommitted changes.\n", .{});
        }
        e = true;
    }
    if (e) os.exit(1);
}

/// >/dev/null but stderr shown
fn quietOut(args: []const []const u8) bool {
    const r = os.run(gitArgv(args), .{ .capture_stdout = true });
    return r.status == 0;
}

fn usageDie() noreturn {
    util.flushStdout();
    util.eprint("usage: git filter-branch {s}\n", .{usage_text});
    os.exit(1);
}

// ---------------------------------------------------------------- main

pub fn cmdFilterBranch(args: []const []const u8) u8 {
    var argv = args[1..];

    if (envOrEmpty("FILTER_BRANCH_SQUELCH_WARNING").len == 0 and envOrEmpty("GIT_TEST_DISALLOW_ABBREVIATED_OPTIONS").len == 0) {
        util.out(warning_text);
        util.flushStdout();
        _ = sleep(10);
        util.out("Proceeding with filter-branch...\n\n");
    }
    if (argv.len > 0 and util.eql(argv[0], "-h")) {
        util.outf("usage: git filter-branch {s}\n", .{usage_text});
        return 0;
    }

    // git_dir_init
    const gd = capture(&.{ "rev-parse", "--git-dir" }, false);
    if (!gd.ok) os.exit(gd.status);
    const cdup = capture(&.{ "rev-parse", "--show-cdup" }, false);
    if (cdup.out.len > 0) {
        util.eprint("You need to run this command from the toplevel of the working tree.\n", .{});
        os.exit(1);
    }
    orig_dir = os.getcwd();
    const git_dir = if (gd.out.len > 0 and gd.out[0] == '/') gd.out else (util.normalizePath(util.joinPath(orig_dir, gd.out)) orelse gd.out);

    if (!isBare()) requireCleanWorkTree();

    var filter_setup: []const u8 = "";
    var filter_env: []const u8 = "";
    var filter_tree: []const u8 = "";
    var filter_index: []const u8 = "";
    var filter_parent: []const u8 = "";
    var filter_msg: []const u8 = "cat";
    var filter_commit: []const u8 = "";
    var filter_tag_name: []const u8 = "";
    var filter_subdir: []const u8 = "";
    var state_branch: []const u8 = "";
    var orig_namespace: []const u8 = "refs/original/";
    var force = false;
    var prune_empty = false;
    var remap_to_ancestor = false;

    while (argv.len > 0) {
        const a = argv[0];
        if (util.eql(a, "--")) {
            argv = argv[1..];
            break;
        }
        if (util.eql(a, "--force") or util.eql(a, "-f")) {
            force = true;
            argv = argv[1..];
            continue;
        }
        if (util.eql(a, "--remap-to-ancestor")) {
            remap_to_ancestor = true;
            argv = argv[1..];
            continue;
        }
        if (util.eql(a, "--prune-empty")) {
            prune_empty = true;
            argv = argv[1..];
            continue;
        }
        if (a.len == 0 or a[0] != '-') break;
        if (argv.len == 1) usageDie();
        const optarg = argv[1];
        argv = argv[2..];
        if (util.eql(a, "-d")) {
            tempdir = optarg;
        } else if (util.eql(a, "--setup")) {
            filter_setup = optarg;
        } else if (util.eql(a, "--subdirectory-filter")) {
            filter_subdir = optarg;
            remap_to_ancestor = true;
        } else if (util.eql(a, "--env-filter")) {
            filter_env = optarg;
        } else if (util.eql(a, "--tree-filter")) {
            filter_tree = optarg;
        } else if (util.eql(a, "--index-filter")) {
            filter_index = optarg;
        } else if (util.eql(a, "--parent-filter")) {
            filter_parent = optarg;
        } else if (util.eql(a, "--msg-filter")) {
            filter_msg = optarg;
        } else if (util.eql(a, "--commit-filter")) {
            filter_commit = util.concat(&.{ functions_text, "; ", optarg });
        } else if (util.eql(a, "--tag-name-filter")) {
            filter_tag_name = optarg;
        } else if (util.eql(a, "--original")) {
            // expr "$OPTARG/" : '\(.*[^/]\)/*$'
            var o = optarg;
            while (o.len > 0 and o[o.len - 1] == '/') o = o[0 .. o.len - 1];
            orig_namespace = util.concat(&.{ o, "/" });
        } else if (util.eql(a, "--state-branch")) {
            state_branch = optarg;
        } else usageDie();
    }

    if (filter_commit.len == 0) {
        filter_commit = if (prune_empty)
            util.concat(&.{ functions_text, "; git_commit_non_empty_tree \"$@\"" })
        else
            "git commit-tree \"$@\"";
    } else if (prune_empty) {
        die("Cannot set --prune-empty and --commit-filter at the same time", .{});
    }

    if (force) {
        os.removeTree(tempdir);
    } else if (os.isDir(tempdir)) {
        die("{s} already exists, please remove it", .{tempdir});
    }
    const t_dir = util.joinPath(tempdir, "t");
    _ = os.mkdirAll(t_dir);
    if (!os.isDir(t_dir)) die("", .{});
    const tdir_abs = if (tempdir.len > 0 and tempdir[0] == '/') tempdir else (util.normalizePath(util.joinPath(orig_dir, tempdir)) orelse tempdir);
    tempdir_abs = tdir_abs;
    const workdir = util.joinPath(tdir_abs, "t");
    if (!os.chdir(workdir)) die("", .{});

    const orig_env_names = [_][]const u8{ "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE" };
    var orig_env: [orig_env_names.len][]const u8 = undefined;
    for (orig_env_names, 0..) |n, i| orig_env[i] = envOrEmpty(n);

    os.setEnv("GIT_DIR", git_dir);
    os.setEnv("GIT_WORK_TREE", ".");

    // Make sure refs/original is empty
    const fer = capture(&.{"for-each-ref"}, false);
    if (!fer.ok) exitWith(fer.status);
    for (lines(fer.out)) |l| {
        const f = readFields(l, 3);
        if (util.startsWith(f[2], orig_namespace)) {
            if (!force) die("Cannot create a new backup.\nA previous backup already exists in {s}\nForce overwriting the backup with -f", .{orig_namespace});
            _ = runGit(&.{ "update-ref", "-d", f[2], f[0] }, .{});
        }
    }

    // The refs should be updated if their heads were rewritten
    var rp_args: std.ArrayList([]const u8) = .empty;
    rp_args.appendSlice(gpa, &.{ "rev-parse", "--no-flags", "--revs-only", "--symbolic-full-name", "--default", "HEAD" }) catch util.oom();
    rp_args.appendSlice(gpa, argv) catch util.oom();
    const raw = capture(rp_args.items, false);
    if (!raw.ok) exitWith(raw.status);
    var heads: std.ArrayList([]const u8) = .empty;
    for (lines(raw.out)) |ref0| {
        const ref = std.mem.trim(u8, ref0, " \t");
        if (ref.len >= 2 and ref[0] == '^') continue;
        if (quietOk(&.{ "rev-parse", "--verify", util.concat(&.{ ref, "^0" }) })) {
            heads.append(gpa, ref) catch util.oom();
        } else {
            warn("WARNING: not rewriting '{s}' (not a committish)", .{ref});
        }
    }
    if (heads.items.len == 0) die("You must specify a ref to rewrite.", .{});

    const index_file = util.concat(&.{ workdir, "/../index" });
    os.setEnv("GIT_INDEX_FILE", index_file);

    const map_dir = util.concat(&.{ workdir, "/../map" });
    if (!os.mkdir(map_dir, 0o777)) die("Could not create map/ directory", .{});

    var state_commit: []const u8 = "";
    if (state_branch.len > 0) {
        state_commit = capture(&.{ "rev-parse", "--no-flags", "--revs-only", state_branch }, false).out;
        if (state_commit.len > 0) {
            util.eprint("Populating map from {s} ({s})\n", .{ state_branch, state_commit });
            const r = os.run(gitArgv(&.{ "show", util.concat(&.{ state_commit, ":filter.map" }) }), .{ .capture_stdout = true });
            os.writeFile(util.concat(&.{ tdir_abs, "/filter-map" }), r.stdout, 0o666) catch {};
            if (r.status != 0) die("Unable to load state from {s}:filter.map", .{state_branch});
            for (lines(r.stdout)) |l0| {
                const l = std.mem.trim(u8, l0, " \t");
                const colon = std.mem.lastIndexOfScalar(u8, l, ':') orelse
                    die("Unable to load state from {s}:filter.map", .{state_branch});
                const first = std.mem.indexOfScalar(u8, l, ':').?;
                os.writeFile(util.concat(&.{ map_dir, "/", l[first + 1 ..] }), util.concat(&.{ l[0..colon], "\n" }), 0o666) catch {};
            }
        } else {
            util.eprint("Branch {s} does not exist. Will create\n", .{state_branch});
        }
    }

    // we need "--" only if there are no path arguments in $@
    var nr_args: std.ArrayList([]const u8) = .empty;
    nr_args.appendSlice(gpa, &.{ "rev-parse", "--no-revs" }) catch util.oom();
    nr_args.appendSlice(gpa, argv) catch util.oom();
    const nonrevs = capture(nr_args.items, false);
    if (!nonrevs.ok) exitWith(nonrevs.status);
    var dashdash: ?[]const u8 = "--";
    if (nonrevs.out.len > 0) {
        dashdash = null;
        remap_to_ancestor = true;
    }

    var ro_args: std.ArrayList([]const u8) = .empty;
    ro_args.appendSlice(gpa, &.{ "rev-parse", "--revs-only" }) catch util.oom();
    ro_args.appendSlice(gpa, argv) catch util.oom();
    const parse_out = os.run(gitArgv(ro_args.items), .{ .capture_stdout = true }).stdout;

    var sq_args: std.ArrayList([]const u8) = .empty;
    sq_args.appendSlice(gpa, &.{ "rev-parse", "--sq", "--no-revs" }) catch util.oom();
    sq_args.appendSlice(gpa, argv) catch util.oom();
    if (filter_subdir.len > 0) {
        if (dashdash) |d| sq_args.append(gpa, d) catch util.oom();
        sq_args.append(gpa, filter_subdir) catch util.oom();
    }
    const rest_args = parseSq(capture(sq_args.items, false).out);

    var rl_args: std.ArrayList([]const u8) = .empty;
    rl_args.appendSlice(gpa, &.{ "rev-list", "--reverse", "--topo-order", "--default", "HEAD", "--parents", "--simplify-merges", "--stdin" }) catch util.oom();
    rl_args.appendSlice(gpa, rest_args) catch util.oom();
    const rl = captureIn(rl_args.items, parse_out);
    if (!rl.ok) die("Could not get the commits", .{});
    const revs = lines(rl.out);
    const commits = revs.len;
    if (commits == 0) {
        util.flushStdout();
        util.eprint("Found nothing to rewrite\n", .{});
        exitWith(2);
    }

    const need_index = filter_index.len > 0 or filter_tree.len > 0 or filter_subdir.len > 0;

    // the main shell
    {
        var pre: util.Buf = .empty;
        util.bufAppend(&pre, functions_text);
        util.bufAppend(&pre, "\n");
        util.bufAppend(&pre, sh_setup_text);
        util.bufPrint(&pre, "tempdir={s}\nworkdir={s}\norig_dir={s}\norig_namespace={s}\n", .{ sq(tdir_abs), sq(workdir), sq(orig_dir), sq(orig_namespace) });
        util.bufPrint(&pre, "filter_env={s}\nfilter_tree={s}\nfilter_index={s}\nfilter_parent={s}\nfilter_msg={s}\nfilter_commit={s}\nfilter_tag_name={s}\nfilter_subdir={s}\n", .{ sq(filter_env), sq(filter_tree), sq(filter_index), sq(filter_parent), sq(filter_msg), sq(filter_commit), sq(filter_tag_name), sq(filter_subdir) });
        util.bufPrint(&pre, "commits={d}\n", .{commits});
        util.bufAppend(&pre, ":");
        shStart(pre.items);
    }

    if (evalFilter(filter_setup) != 0) die("filter setup failed: {s}", .{filter_setup});

    // progress
    const start_ts = os.now();
    var next_sample_at: i64 = 0;
    var progress: []const u8 = "dummy to ensure this is not empty";
    var count_str: []const u8 = "";
    var commit_count: i64 = 0;

    for (revs) |line| {
        const ws = words(line);
        if (ws.len == 0) continue;
        const commit = ws[0];
        const parents = ws[1..];
        commit_count += 1;

        // report_progress
        if (progress.len > 0 and commit_count > next_sample_at) {
            const cnt = commit_count;
            count_str = util.fmt("{d}", .{cnt});
            const elapsed = os.now() - start_ts;
            const remaining = @divTrunc((@as(i64, @intCast(commits)) - cnt) * elapsed, cnt);
            if (elapsed > 0) {
                next_sample_at = @divTrunc((elapsed + 1) * cnt, elapsed);
            } else {
                next_sample_at += 1;
            }
            progress = util.fmt(" ({d} seconds passed, remaining {d} predicted)", .{ elapsed, remaining });
        }
        util.outf("\rRewrite {s} ({s}/{d}){s}    ", .{ commit, count_str, commits, progress });

        if (os.isFile(util.concat(&.{ map_dir, "/", commit }))) continue;

        if (filter_subdir.len == 0) {
            if (need_index) {
                if (runGit(&.{ "read-tree", "-i", "-m", commit }, .{ .env = &.{.{ "GIT_ALLOW_NULL_SHA1", "1" }} }) != 0)
                    die("Could not initialize the index", .{});
            }
        } else {
            const spec = util.concat(&.{ commit, ":", filter_subdir });
            const r = os.run(gitArgv(&.{ "read-tree", "-i", "-m", spec }), .{ .capture_stdout = true, .no_stderr = true, .env = &.{.{ "GIT_ALLOW_NULL_SHA1", "1" }} });
            if (r.status != 0) {
                if (!quietOk(&.{ "rev-parse", "-q", "--verify", spec })) {
                    _ = os.unlink(index_file);
                } else {
                    // show the error
                    _ = runGit(&.{ "read-tree", "-i", "-m", spec }, .{ .env = &.{.{ "GIT_ALLOW_NULL_SHA1", "1" }} });
                    die("Could not initialize the index", .{});
                }
            }
        }

        const cat = os.run(gitArgv(&.{ "cat-file", "commit", commit }), .{ .capture_stdout = true });
        os.writeFile(util.concat(&.{ workdir, "/../commit" }), cat.stdout, 0o666) catch {};
        if (cat.status != 0) die("Cannot read commit {s}", .{commit});

        // set GIT_COMMIT, identity and run the env filter
        {
            var s: util.Buf = .empty;
            var pj: util.Buf = .empty;
            for (parents, 0..) |p, i| {
                if (i > 0) util.bufByte(&pj, ' ');
                util.bufAppend(&pj, p);
            }
            util.bufPrint(&s, "commit={s}\nparents={s}\nGIT_COMMIT=$commit\nexport GIT_COMMIT\n", .{ commit, sq(pj.items) });
            util.bufAppend(&s, identScript(cat.stdout));
            util.bufAppend(&s, ":");
            _ = shExec(s.items);
        }
        if (evalFilter(filter_env) != 0) die("env filter failed: {s}", .{filter_env});

        if (filter_tree.len > 0) {
            if (runGit(&.{ "checkout-index", "-f", "-u", "-a" }, .{}) != 0)
                die("Could not checkout the index", .{});
            // files that $commit removed are now still in the working tree;
            // remove them, else they would be added again
            _ = runGit(&.{ "clean", "-d", "-q", "-f", "-x" }, .{});
            if (evalFilter(filter_tree) != 0) die("tree filter failed: {s}", .{filter_tree});

            const di = os.run(gitArgv(&.{ "diff-index", "-r", "--name-only", "--ignore-submodules", commit, "--" }), .{ .capture_stdout = true });
            if (di.status != 0) exitWith(di.status);
            const lo = os.run(gitArgv(&.{ "ls-files", "--others" }), .{ .capture_stdout = true });
            if (lo.status != 0) exitWith(lo.status);
            const state = util.concat(&.{ di.stdout, lo.stdout });
            os.writeFile(util.concat(&.{ tdir_abs, "/tree-state" }), state, 0o666) catch {};
            const st = runGit(&.{ "update-index", "--add", "--replace", "--remove", "--stdin" }, .{ .stdin_data = state });
            if (st != 0) exitWith(st);
        }

        if (evalFilter(filter_index) != 0) die("index filter failed: {s}", .{filter_index});

        var parentstr: util.Buf = .empty;
        for (parents) |p| {
            for (words(mapCommit(workdir, p))) |rp| {
                const needle = util.concat(&.{ " -p ", rp, " " });
                const hay = util.concat(&.{ parentstr.items, " " });
                if (std.mem.indexOf(u8, hay, needle) == null) {
                    util.bufAppend(&parentstr, " -p ");
                    util.bufAppend(&parentstr, rp);
                }
            }
        }
        if (filter_parent.len > 0) {
            const s = util.concat(&.{ "parentstr=", sq(parentstr.items), "\nparentstr=\"$(echo \"$parentstr\" | { eval ", sq(filter_parent), "\n} 9>&-)\"" });
            if (shExec(s) != 0) die("parent filter failed: {s}", .{filter_parent});
        } else {
            _ = shExec(util.concat(&.{ "parentstr=", sq(parentstr.items) }));
        }

        {
            const s = util.concat(&.{
                "{\n\twhile IFS='' read -r header_line && test -n \"$header_line\"\n\tdo\n\t\t:;\n\tdone\n\tcat\n} <../commit |\n{ eval ",
                sq(filter_msg),
                "\n} >../message 9>&-",
            });
            if (shExec(s) != 0) die("msg filter failed: {s}", .{filter_msg});
        }

        const tree = if (need_index)
            capture(&.{"write-tree"}, false).out
        else
            capture(&.{ "rev-parse", util.concat(&.{ commit, "^{tree}" }) }, false).out;

        {
            const s = util.concat(&.{ "workdir=$workdir /bin/sh -c \"$filter_commit\" \"git commit-tree\" ", sq(tree), " $parentstr <../message >../map/$commit 9>&-" });
            if (shExec(s) != 0) die("could not write rewritten commit", .{});
        }
    }

    // If we are filtering for paths, as in the case of a subdirectory
    // filter, it is possible that a specified head is not in the set of
    // rewritten commits, because it was pruned by the revision walker.
    // Ancestor remapping fixes this by mapping these heads to the unique
    // nearest ancestor that survived the pruning.
    if (remap_to_ancestor) {
        for (heads.items) |ref| {
            const sha1 = capture(&.{ "rev-parse", util.concat(&.{ ref, "^0" }) }, false).out;
            if (os.isFile(util.concat(&.{ map_dir, "/", sha1 }))) continue;
            var a: std.ArrayList([]const u8) = .empty;
            a.appendSlice(gpa, &.{ "rev-list", "--simplify-merges", "-1", ref }) catch util.oom();
            a.appendSlice(gpa, rest_args) catch util.oom();
            const anc = capture(a.items, false).out;
            if (anc.len > 0) {
                // echo $(map $ancestor)
                const m = words(mapCommit(workdir, anc));
                var b: util.Buf = .empty;
                for (m, 0..) |w, i| {
                    if (i > 0) util.bufByte(&b, ' ');
                    util.bufAppend(&b, w);
                }
                util.bufByte(&b, '\n');
                os.writeFile(util.concat(&.{ map_dir, "/", sha1 }), b.items, 0o666) catch {};
            }
        }
    }

    // Finally update the refs
    util.out("\n");
    for (heads.items) |ref| {
        // avoid rewriting a ref twice
        if (os.isFile(util.concat(&.{ orig_namespace, ref }))) continue;
        const sha1 = capture(&.{ "rev-parse", util.concat(&.{ ref, "^0" }) }, false).out;
        const rewritten = stripNl(mapCommit(workdir, sha1));
        if (util.eql(sha1, rewritten)) {
            warn("WARNING: Ref '{s}' is unchanged", .{ref});
            continue;
        }
        if (rewritten.len == 0) {
            util.outf("Ref '{s}' was deleted\n", .{ref});
            if (runGit(&.{ "update-ref", "-m", "filter-branch: delete", "-d", ref, sha1 }, .{}) != 0)
                die("Could not delete {s}", .{ref});
        } else {
            util.outf("Ref '{s}' was rewritten\n", .{ref});
            var a: std.ArrayList([]const u8) = .empty;
            a.appendSlice(gpa, &.{ "update-ref", "-m", "filter-branch: rewrite", ref }) catch util.oom();
            a.appendSlice(gpa, words(rewritten)) catch util.oom();
            if (sha1.len > 0) a.append(gpa, sha1) catch util.oom();
            if (runGit(a.items, .{ .no_stderr = true }) != 0) {
                if (util.eql(capture(&.{ "cat-file", "-t", ref }, false).out, "tag")) {
                    if (filter_tag_name.len == 0) {
                        warn("WARNING: You said to rewrite tagged commits, but not the corresponding tag.", .{});
                        warn("WARNING: Perhaps use '--tag-name-filter cat' to rewrite the tag.", .{});
                    }
                } else die("Could not rewrite {s}", .{ref});
            }
        }
        const st = runGit(&.{ "update-ref", "-m", "filter-branch: backup", util.concat(&.{ orig_namespace, ref }), sha1 }, .{});
        if (st != 0) exitWith(st);
    }

    // Filter tags
    if (filter_tag_name.len > 0) tags: {
        const tl = capture(&.{ "for-each-ref", "--format=%(objectname) %(objecttype) %(refname)", "refs/tags" }, false).out;
        for (lines(tl)) |l| {
            const f = readFields(l, 3);
            var sha1 = f[0];
            const typ = f[1];
            var ref = f[2];
            if (util.startsWith(ref, "refs/tags/")) ref = ref["refs/tags/".len..];
            if (!util.eql(typ, "commit") and !util.eql(typ, "tag")) continue;
            const sha1t = sha1;
            if (util.eql(typ, "tag")) {
                const r = capture(&.{ "rev-parse", "-q", util.concat(&.{ sha1, "^{commit}" }) }, false);
                if (!r.ok) continue;
                sha1 = r.out;
            }
            const mp = util.concat(&.{ map_dir, "/", sha1 });
            if (!os.isFile(mp)) continue;
            var new_sha1 = stripNl(os.readFile(mp) orelse "");
            const s = util.concat(&.{
                "GIT_COMMIT=",                         sha1,
                "\nexport GIT_COMMIT\nnew_ref=\"$(echo ", sq(ref),
                " | { eval ",                          sq(filter_tag_name),
                "\n} 9>&-)\"\n__fb_st=$?\nprintf '%s' \"$new_ref\" >\"$tempdir\"/new-ref\ntest $__fb_st = 0",
            });
            if (shExec(s) != 0) {
                warn("tag name filter failed: {s}", .{filter_tag_name});
                break :tags;
            }
            const new_ref = os.readFile(util.concat(&.{ tdir_abs, "/new-ref" })) orelse "";
            util.outf("{s} -> {s} ({s} -> {s})\n", .{ ref, new_ref, sha1, new_sha1 });

            if (util.eql(typ, "tag")) {
                const body = os.run(gitArgv(&.{ "cat-file", "tag", ref }), .{ .capture_stdout = true }).stdout;
                var b: util.Buf = .empty;
                util.bufPrint(&b, "object {s}\ntype commit\ntag {s}\n", .{ new_sha1, new_ref });
                var in_header = true;
                var signed = false;
                var it = std.mem.splitScalar(u8, body, '\n');
                var lineno: usize = 0;
                while (it.next()) |ln| {
                    if (it.index == null and ln.len == 0) break;
                    lineno += 1;
                    if (in_header) {
                        if (lineno > 1 and ln.len == 0) in_header = false;
                        if (util.startsWith(ln, "object ") or util.startsWith(ln, "type ") or util.startsWith(ln, "tag ")) continue;
                    }
                    if (util.startsWith(ln, "-----BEGIN PGP SIGNATURE-----")) {
                        signed = true;
                        break;
                    }
                    util.bufAppend(&b, ln);
                    util.bufByte(&b, '\n');
                }
                const h = captureIn(&.{ "hash-object", "-t", "tag", "-w", "--stdin" }, b.items);
                if (!h.ok) {
                    warn("Could not create new tag object for {s}", .{ref});
                    break :tags;
                }
                new_sha1 = h.out;
                if (signed) warn("gpg signature stripped from tag object {s}", .{sha1t});
            }
            if (runGit(&.{ "update-ref", util.concat(&.{ "refs/tags/", new_ref }), new_sha1 }, .{}) != 0) {
                warn("Could not write tag {s}", .{new_ref});
                break :tags;
            }
        }
    }

    for (orig_env_names, 0..) |n, i| {
        if (orig_env[i].len > 0) os.setEnv(n, orig_env[i]) else os.unsetEnv(n);
    }

    if (state_branch.len > 0) {
        util.eprint("Saving rewrite state to {s}\n", .{state_branch});
        var b: util.Buf = .empty;
        var names: std.ArrayList([]const u8) = .empty;
        if (os.listDir(map_dir)) |ents| {
            for (ents) |e| names.append(gpa, e.name) catch util.oom();
        }
        util.sortStrings(names.items);
        for (names.items) |n| {
            util.bufPrint(&b, "{s}:{s}\n", .{ n, stripNl(os.readFile(util.concat(&.{ map_dir, "/", n })) orelse "") });
        }
        const blob = captureIn(&.{ "hash-object", "-w", "--stdin" }, b.items);
        if (!blob.ok) die("Unable to save state", .{});
        const tree = captureIn(&.{"mktree"}, util.fmt("100644 blob {s}\tfilter.map\n", .{blob.out})).out;
        const sc = if (state_commit.len > 0)
            captureIn(&.{ "commit-tree", tree, "-p", state_commit }, "Sync\n").out
        else
            captureIn(&.{ "commit-tree", tree }, "Sync\n").out;
        _ = runGit(&.{ "update-ref", state_branch, sc }, .{});
    }

    util.flushStdout();
    cleanup();

    if (!isBare()) {
        const st = runGit(&.{ "read-tree", "-u", "-m", "HEAD" }, .{});
        if (st != 0) return st;
    }
    return 0;
}
