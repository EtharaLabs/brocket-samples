//! Port of git's diff machinery (diff.c, ws.c, diff-lib.c, parts of diffcore).
//!
//! Stable API (used by other commands):
//!
//!   var o = diff.DiffOptions.init();       // porcelain defaults (diff.* UI config, renames)
//!   var o = diff.DiffOptions.initBasic();  // plumbing defaults (basic config only)
//!   o.output_format = diff.FMT_PATCH | diff.FMT_DIFFSTAT ...;  (FMT_RAW, FMT_DIFFSTAT,
//!       FMT_NUMSTAT, FMT_SUMMARY, FMT_PATCH, FMT_SHORTSTAT, FMT_DIRSTAT, FMT_NAME,
//!       FMT_NAME_STATUS, FMT_CHECKDIFF, FMT_NO_OUTPUT)
//!   o.detect_rename = diff.DETECT_RENAME / DETECT_COPY; o.pathspec = ...;
//!   o.flags.recursive / .reverse / .quick / .exit_with_status ...
//!   o.file: ?*util.Out (default &util.stdout; null = no output)
//!   const n = o.parseOpt(args, i);   // consume diff options at args[i] (0 = not a diff option)
//!   o.setupDone();                    // diff_setup_done
//!
//!   diff.diffTree(&o, old_tree_or_null, new_tree_or_null, base)  // queue tree changes
//!   diff.runDiffIndex(&o, tree_oid, cached)                      // queue tree vs index/worktree
//!   diff.runDiffFiles(&o)                                        // queue index vs worktree
//!   diff.flush(&o)            // diff_flush (runs diffcore_std first if not done yet)
//!   diff.diffcoreStd(&o) then inspect diff.queue.items (*FilePair{status, score,
//!       one/two: *Filespec{path, oid, mode, oid_valid}}) then diff.clearQueue()
//!   diff.hasChanges(&o) / diff.resultCodeOpts(&o)
//!   diff.treesSame(old, new, &pathspec) bool
//!   diff.diffCombined(&o, commit_oid, parents, dense)
//!   diff.printStatSummary(out, files, ins, del)
//!   diff.setupRevDiff(revs) / diff.revResultCode(revs): install diff hooks for log & co.
//!   ws.c: parseWhitespaceRule, whitespaceRule, wsErrorString, wsCheck, wsCheckEmit,
//!       wsBlankLine, wsFixCopy (WS_* constants).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const color = @import("color.zig");
const attr = @import("attr.zig");
const pathspec_mod = @import("pathspec.zig");
const xdiff = @import("xdiff.zig");
const regex = @import("regex.zig");
const userdiff = @import("userdiff.zig");
const index_mod = @import("index.zig");
const objects = @import("objects.zig");
const convert = @import("convert.zig");
const revparse = @import("revparse.zig");
const pretty = @import("pretty.zig");
const odb_mod = @import("odb.zig");
const revision = @import("revision.zig");
const graph_mod = @import("graph.zig");
const cn = @import("commitnode.zig");
const zlib_mod = @import("zlib.zig");
pub const diffcore = @import("diffcore.zig");
pub const treediff = @import("treediff.zig");
pub const combined = @import("combined.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Buf = util.Buf;

// ---------------------------------------------------------------------------
// constants (diff.h, ws.h, diffcore.h)

pub const FMT_RAW: u32 = 0x0001;
pub const FMT_DIFFSTAT: u32 = 0x0002;
pub const FMT_NUMSTAT: u32 = 0x0004;
pub const FMT_SUMMARY: u32 = 0x0008;
pub const FMT_PATCH: u32 = 0x0010;
pub const FMT_SHORTSTAT: u32 = 0x0020;
pub const FMT_DIRSTAT: u32 = 0x0040;
pub const FMT_NAME: u32 = 0x0100;
pub const FMT_NAME_STATUS: u32 = 0x0200;
pub const FMT_CHECKDIFF: u32 = 0x0400;
pub const FMT_NO_OUTPUT: u32 = 0x0800;
pub const FMT_CALLBACK: u32 = 0x1000;

pub const DETECT_RENAME: u8 = 1;
pub const DETECT_COPY: u8 = 2;

pub const MAX_SCORE: u32 = 60000;
pub const DEFAULT_RENAME_SCORE: u32 = 30000;
pub const DEFAULT_BREAK_SCORE: u32 = 30000;
pub const DEFAULT_MERGE_SCORE: u32 = 36000;
pub const MINIMUM_BREAK_SIZE: usize = 400;

pub const PICKAXE_ALL: u32 = 1;
pub const PICKAXE_REGEX: u32 = 2;
pub const PICKAXE_KIND_S: u32 = 4;
pub const PICKAXE_KIND_G: u32 = 8;
pub const PICKAXE_KIND_OBJFIND: u32 = 16;
pub const PICKAXE_KINDS_MASK: u32 = PICKAXE_KIND_S | PICKAXE_KIND_G | PICKAXE_KIND_OBJFIND;
pub const PICKAXE_IGNORE_CASE: u32 = 32;

pub const WS_BLANK_AT_EOL: u32 = 1 << 6;
pub const WS_SPACE_BEFORE_TAB: u32 = 1 << 7;
pub const WS_INDENT_WITH_NON_TAB: u32 = 1 << 8;
pub const WS_CR_AT_EOL: u32 = 1 << 9;
pub const WS_BLANK_AT_EOF: u32 = 1 << 10;
pub const WS_TAB_IN_INDENT: u32 = 1 << 11;
pub const WS_INCOMPLETE_LINE: u32 = 1 << 12;
pub const WS_TRAILING_SPACE: u32 = WS_BLANK_AT_EOL | WS_BLANK_AT_EOF;
pub const WS_DEFAULT_RULE: u32 = WS_TRAILING_SPACE | WS_SPACE_BEFORE_TAB | 8;
pub const WS_TAB_WIDTH_MASK: u32 = (1 << 6) - 1;
pub const WS_RULE_MASK: u32 = (1 << 16) - 1;

pub const WSEH_NEW: u32 = 1 << 16;
pub const WSEH_CONTEXT: u32 = 1 << 17;
pub const WSEH_OLD: u32 = 1 << 18;
const SYM_BLANK_LINE_EOF: u32 = 1 << 19;
const SYM_MOVED_LINE: u32 = 1 << 20;
const SYM_MOVED_LINE_ALT: u32 = 1 << 21;
const SYM_MOVED_LINE_UNINTERESTING: u32 = 1 << 22;
const SYM_CONTENT_WS_MASK: u32 = WSEH_NEW | WSEH_OLD | WSEH_CONTEXT | WS_RULE_MASK;

pub const STATUS_ADDED: u8 = 'A';
pub const STATUS_COPIED: u8 = 'C';
pub const STATUS_DELETED: u8 = 'D';
pub const STATUS_MODIFIED: u8 = 'M';
pub const STATUS_RENAMED: u8 = 'R';
pub const STATUS_TYPE_CHANGED: u8 = 'T';
pub const STATUS_UNKNOWN: u8 = 'X';
pub const STATUS_UNMERGED: u8 = 'U';
pub const STATUS_FILTER_AON: u8 = '*';
pub const STATUS_FILTER_BROKEN: u8 = 'B';

const status_letters = "ACDMRTXU*B";

pub fn filterBit(status: u8) u32 {
    for (status_letters, 0..) |c, i| {
        if (c == status) return @as(u32, 1) << @intCast(i);
    }
    return 0;
}

pub const WordDiff = enum { none, porcelain, plain, color };

pub const ColorMoved = enum(u8) { no = 0, plain = 1, blocks = 2, zebra = 3, zebra_dim = 4 };
pub const COLOR_MOVED_DEFAULT = ColorMoved.zebra;
pub const COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE: u32 = 1 << 5;
pub const COLOR_MOVED_WS_ERROR: u32 = 1 << 0;

pub const SubmoduleFormat = enum { short, log, inline_diff };

const OUTPUT_INDICATOR_NEW = 0;
const OUTPUT_INDICATOR_OLD = 1;
const OUTPUT_INDICATOR_CONTEXT = 2;

pub fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r';
}
fn isDigit(c: u8) bool {
    return c >= '0' and c <= '9';
}

fn sIsDir(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFDIR;
}
fn sIsReg(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFREG;
}
fn sIsLnk(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFLNK;
}
fn sIsGitlink(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFGITLINK;
}

// ---------------------------------------------------------------------------
// ws.c

pub var whitespace_rule_cfg: u32 = WS_DEFAULT_RULE;
var whitespace_cfg_loaded = false;

const WsRuleName = struct { name: []const u8, bits: u32, loosens_error: bool = false, exclude_default: bool = false };
const whitespace_rule_names = [_]WsRuleName{
    .{ .name = "trailing-space", .bits = WS_TRAILING_SPACE },
    .{ .name = "space-before-tab", .bits = WS_SPACE_BEFORE_TAB },
    .{ .name = "indent-with-non-tab", .bits = WS_INDENT_WITH_NON_TAB },
    .{ .name = "cr-at-eol", .bits = WS_CR_AT_EOL, .loosens_error = true },
    .{ .name = "blank-at-eol", .bits = WS_BLANK_AT_EOL },
    .{ .name = "blank-at-eof", .bits = WS_BLANK_AT_EOF },
    .{ .name = "tab-in-indent", .bits = WS_TAB_IN_INDENT, .exclude_default = true },
    .{ .name = "incomplete-line", .bits = WS_INCOMPLETE_LINE },
};

pub fn wsTabWidth(rule: u32) u32 {
    return rule & WS_TAB_WIDTH_MASK;
}

/// parse_whitespace_rule()
pub fn parseWhitespaceRule(string0: []const u8) u32 {
    var rule: u32 = WS_DEFAULT_RULE;
    var s = string0;
    while (true) {
        var k: usize = 0;
        while (k < s.len and (s[k] == ',' or s[k] == ' ' or s[k] == '\t' or s[k] == '\n' or s[k] == '\r')) k += 1;
        s = s[k..];
        const ep = std.mem.indexOfScalar(u8, s, ',') orelse s.len;
        var item = s[0..ep];
        var negated = false;
        if (item.len > 0 and item[0] == '-') {
            negated = true;
            item = item[1..];
        }
        if (item.len == 0) break;
        for (whitespace_rule_names) |r| {
            if (!std.mem.startsWith(u8, r.name, item)) continue;
            if (negated) rule &= ~r.bits else rule |= r.bits;
            break;
        }
        if (util.skipPrefix(s, "tabwidth=")) |arg| {
            var n: u32 = 0;
            var j: usize = 0;
            while (j < arg.len and isDigit(arg[j])) : (j += 1) n = n *| 10 +| (arg[j] - '0');
            if (0 < n and n < 0o100) {
                rule &= ~WS_TAB_WIDTH_MASK;
                rule |= n;
            } else {
                const arg_end = std.mem.indexOfScalar(u8, arg, ',') orelse arg.len;
                util.warn("tabwidth {s} out of range", .{arg[0..arg_end]});
            }
        }
        if (ep >= s.len) break;
        s = s[ep..];
    }
    if (rule & WS_TAB_IN_INDENT != 0 and rule & WS_INDENT_WITH_NON_TAB != 0)
        util.die("cannot enforce both tab-in-indent and indent-with-non-tab", .{});
    return rule;
}

fn loadWhitespaceCfg() void {
    if (whitespace_cfg_loaded) return;
    whitespace_cfg_loaded = true;
    if (repo_mod.cfg.getEntry("core.whitespace")) |e| {
        const v = e.value orelse util.die("missing value for '{s}'", .{e.key});
        whitespace_rule_cfg = parseWhitespaceRule(v);
    }
}

/// whitespace_rule(): rule for a path (attribute "whitespace" + core.whitespace)
pub fn whitespaceRule(path: []const u8) u32 {
    loadWhitespaceCfg();
    const v: attr.Value = if (repo_mod.repo_ != null) attr.get(path, "whitespace") else .unspecified;
    switch (v) {
        .set => {
            var all_rule = wsTabWidth(whitespace_rule_cfg);
            for (whitespace_rule_names) |r| {
                if (!r.loosens_error and !r.exclude_default) all_rule |= r.bits;
            }
            return all_rule;
        },
        .unset => return wsTabWidth(whitespace_rule_cfg),
        .unspecified => return whitespace_rule_cfg,
        .value => |s| return parseWhitespaceRule(s),
    }
}

/// whitespace_error_string()
pub fn wsErrorString(ws: u32) []const u8 {
    var err: Buf = .empty;
    if (ws & WS_TRAILING_SPACE == WS_TRAILING_SPACE) {
        util.bufAppend(&err, "trailing whitespace");
    } else {
        if (ws & WS_BLANK_AT_EOL != 0) util.bufAppend(&err, "trailing whitespace");
        if (ws & WS_BLANK_AT_EOF != 0) {
            if (err.items.len > 0) util.bufAppend(&err, ", ");
            util.bufAppend(&err, "new blank line at EOF");
        }
    }
    if (ws & WS_SPACE_BEFORE_TAB != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "space before tab in indent");
    }
    if (ws & WS_INDENT_WITH_NON_TAB != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "indent with spaces");
    }
    if (ws & WS_TAB_IN_INDENT != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "tab in indent");
    }
    if (ws & WS_INCOMPLETE_LINE != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "no newline at the end of file");
    }
    return err.items;
}

fn wsCheckEmit1(line: []const u8, ws_rule: u32, stream: ?*Buf, set: []const u8, reset: []const u8, ws: []const u8) u32 {
    var result: u32 = 0;
    var written: usize = 0;
    var trailing_whitespace: ?usize = null;
    var trailing_newline = false;
    var trailing_cr = false;
    var len = line.len;
    if (len > 0 and line[len - 1] == '\n') {
        trailing_newline = true;
        len -= 1;
    }
    if (ws_rule & WS_CR_AT_EOL != 0 and len > 0 and line[len - 1] == '\r') {
        trailing_cr = true;
        len -= 1;
    }
    if (ws_rule & WS_BLANK_AT_EOL != 0) {
        var i: usize = len;
        while (i > 0) {
            i -= 1;
            if (isSpace(line[i])) {
                trailing_whitespace = i;
                result |= WS_BLANK_AT_EOL;
            } else break;
        }
    }
    const tw = trailing_whitespace orelse len;
    if (!trailing_newline and ws_rule & WS_INCOMPLETE_LINE != 0) result |= WS_INCOMPLETE_LINE;

    var i: usize = 0;
    while (i < tw) : (i += 1) {
        if (line[i] == ' ') continue;
        if (line[i] != '\t') break;
        if (ws_rule & WS_SPACE_BEFORE_TAB != 0 and written < i) {
            result |= WS_SPACE_BEFORE_TAB;
            if (stream) |st| {
                util.bufAppend(st, ws);
                util.bufAppend(st, line[written..i]);
                util.bufAppend(st, reset);
                util.bufAppend(st, line[i .. i + 1]);
            }
        } else if (ws_rule & WS_TAB_IN_INDENT != 0) {
            result |= WS_TAB_IN_INDENT;
            if (stream) |st| {
                util.bufAppend(st, line[written..i]);
                util.bufAppend(st, ws);
                util.bufAppend(st, line[i .. i + 1]);
                util.bufAppend(st, reset);
            }
        } else if (stream) |st| {
            util.bufAppend(st, line[written .. i + 1]);
        }
        written = i + 1;
    }
    if (ws_rule & WS_INDENT_WITH_NON_TAB != 0 and i >= written and i - written >= wsTabWidth(ws_rule)) {
        result |= WS_INDENT_WITH_NON_TAB;
        if (stream) |st| {
            util.bufAppend(st, ws);
            util.bufAppend(st, line[written..i]);
            util.bufAppend(st, reset);
        }
        written = i;
    }
    if (stream) |st| {
        if (tw > written) {
            util.bufAppend(st, set);
            util.bufAppend(st, line[written..tw]);
            util.bufAppend(st, reset);
        }
        if (tw != len) {
            util.bufAppend(st, ws);
            util.bufAppend(st, line[tw..len]);
            util.bufAppend(st, reset);
        }
        if (trailing_cr) util.bufByte(st, '\r');
        if (trailing_newline) util.bufByte(st, '\n');
    }
    return result;
}

/// ws_check_emit(): append the line with whitespace errors highlighted to `stream`.
pub fn wsCheckEmit(line: []const u8, ws_rule: u32, stream: *Buf, set: []const u8, reset: []const u8, ws: []const u8) void {
    _ = wsCheckEmit1(line, ws_rule, stream, set, reset, ws);
}

/// ws_check()
pub fn wsCheck(line: []const u8, ws_rule: u32) u32 {
    return wsCheckEmit1(line, ws_rule, null, "", "", "");
}

/// ws_blank_line()
pub fn wsBlankLine(line: []const u8) bool {
    for (line) |c| {
        if (!isSpace(c)) return false;
    }
    return true;
}

/// ws_fix_copy(): append src to dst fixing whitespace errors per ws_rule.
pub fn wsFixCopy(dst: *Buf, src0: []const u8, ws_rule: u32, error_count: ?*usize) void {
    var src = src0;
    var len = src.len;
    var add_nl_to_tail = false;
    var add_cr_to_tail = false;
    var fixed = false;
    var last_tab_in_indent: isize = -1;
    var last_space_in_indent: isize = -1;
    var need_fix_leading_space = false;
    const tabw: isize = @intCast(wsTabWidth(ws_rule));

    if (ws_rule & WS_INCOMPLETE_LINE != 0) {
        if (0 < len and src[len - 1] != '\n') {
            fixed = true;
            add_nl_to_tail = true;
        }
    }
    if (ws_rule & WS_BLANK_AT_EOL != 0) {
        if (0 < len and src[len - 1] == '\n') {
            add_nl_to_tail = true;
            len -= 1;
            if (0 < len and src[len - 1] == '\r') {
                add_cr_to_tail = ws_rule & WS_CR_AT_EOL != 0;
                len -= 1;
            }
        }
        if (0 < len and isSpace(src[len - 1])) {
            while (0 < len and isSpace(src[len - 1])) len -= 1;
            fixed = true;
        }
    }
    var i: usize = 0;
    while (i < len) : (i += 1) {
        const ch = src[i];
        const ii: isize = @intCast(i);
        if (ch == '\t') {
            last_tab_in_indent = ii;
            if (ws_rule & WS_SPACE_BEFORE_TAB != 0 and 0 <= last_space_in_indent)
                need_fix_leading_space = true;
        } else if (ch == ' ') {
            last_space_in_indent = ii;
            if (ws_rule & WS_INDENT_WITH_NON_TAB != 0 and tabw <= ii - last_tab_in_indent)
                need_fix_leading_space = true;
        } else break;
    }
    if (need_fix_leading_space) {
        var consecutive_spaces: isize = 0;
        var last: usize = @intCast(last_tab_in_indent + 1);
        if (ws_rule & WS_INDENT_WITH_NON_TAB != 0) {
            if (last_tab_in_indent < last_space_in_indent)
                last = @intCast(last_space_in_indent + 1)
            else
                last = @intCast(last_tab_in_indent + 1);
        }
        i = 0;
        while (i < last) : (i += 1) {
            const ch = src[i];
            if (ch != ' ') {
                consecutive_spaces = 0;
                util.bufByte(dst, ch);
            } else {
                consecutive_spaces += 1;
                if (consecutive_spaces == tabw) {
                    util.bufByte(dst, '\t');
                    consecutive_spaces = 0;
                }
            }
        }
        while (consecutive_spaces > 0) : (consecutive_spaces -= 1) util.bufByte(dst, ' ');
        len -= last;
        src = src[last..];
        fixed = true;
    } else if (ws_rule & WS_TAB_IN_INDENT != 0 and last_tab_in_indent >= 0) {
        const start = dst.items.len;
        const last: usize = @intCast(last_tab_in_indent + 1);
        i = 0;
        while (i < last) : (i += 1) {
            if (src[i] == '\t') {
                while (true) {
                    util.bufByte(dst, ' ');
                    if ((dst.items.len - start) % @as(usize, @intCast(tabw)) == 0) break;
                }
            } else util.bufByte(dst, src[i]);
        }
        len -= last;
        src = src[last..];
        fixed = true;
    }
    util.bufAppend(dst, src[0..len]);
    if (add_cr_to_tail) util.bufByte(dst, '\r');
    if (add_nl_to_tail) util.bufByte(dst, '\n');
    if (fixed) {
        if (error_count) |ec| ec.* += 1;
    }
}

// ---------------------------------------------------------------------------
// colors

pub const Slot = enum(u8) {
    reset = 0,
    context,
    metainfo,
    fraginfo,
    old,
    new,
    commit,
    whitespace,
    funcinfo,
    old_moved,
    old_moved_alt,
    old_moved_dim,
    old_moved_alt_dim,
    new_moved,
    new_moved_alt,
    new_moved_dim,
    new_moved_alt_dim,
    context_dim,
    old_dim,
    new_dim,
    context_bold,
    old_bold,
    new_bold,
};

var diff_colors = [_][]const u8{
    color.RESET,
    "", // CONTEXT
    color.BOLD, // METAINFO
    color.CYAN, // FRAGINFO
    color.RED, // OLD
    color.GREEN, // NEW
    color.YELLOW, // COMMIT
    "\x1b[41m", // WHITESPACE
    "", // FUNCINFO
    color.BOLD_MAGENTA,
    color.BOLD_BLUE,
    color.FAINT,
    "\x1b[2;3m",
    color.BOLD_CYAN,
    color.BOLD_YELLOW,
    color.FAINT,
    "\x1b[2;3m",
    color.FAINT,
    "\x1b[2;31m",
    "\x1b[2;32m",
    color.BOLD,
    color.BOLD_RED,
    color.BOLD_GREEN,
};

const color_slot_names = [_][]const u8{
    "",                    "context",                   "meta",           "frag",
    "old",                 "new",                       "commit",         "whitespace",
    "func",                "oldMoved",                  "oldMovedAlternative", "oldMovedDimmed",
    "oldMovedAlternativeDimmed", "newMoved",            "newMovedAlternative", "newMovedDimmed",
    "newMovedAlternativeDimmed", "contextDimmed",       "oldDimmed",      "newDimmed",
    "contextBold",         "oldBold",                   "newBold",
};

fn parseDiffColorSlot(name: []const u8) ?usize {
    if (std.ascii.eqlIgnoreCase(name, "plain")) return @intFromEnum(Slot.context);
    for (color_slot_names, 0..) |n, i| {
        if (i == 0) continue;
        if (std.ascii.eqlIgnoreCase(n, name)) return i;
    }
    return null;
}

/// Slot lookup by name as used by log-tree's get_color hook ("commit", "reset", ...).
pub fn slotByName(name: []const u8) ?Slot {
    if (util.eql(name, "reset")) return .reset;
    const i = parseDiffColorSlot(name) orelse return null;
    return @enumFromInt(i);
}

var stdout_tty: ?bool = null;
pub fn wantColor(cb: color.ColorBool) bool {
    var v = cb;
    if (v == .unknown) v = git_use_color_default;
    if (v == .auto) {
        if (stdout_tty == null) stdout_tty = color.wantColorBool(.auto, null);
        return stdout_tty.?;
    }
    return v == .always;
}

pub fn getColor(o: *const DiffOptions, slot: Slot) []const u8 {
    if (wantColor(o.use_color)) return diff_colors[@intFromEnum(slot)];
    return "";
}

fn getColorCb(cb: color.ColorBool, slot: Slot) []const u8 {
    if (wantColor(cb)) return diff_colors[@intFromEnum(slot)];
    return "";
}

// ---------------------------------------------------------------------------
// configuration (git_diff_basic_config / git_diff_ui_config)

var basic_loaded = false;
var ui_loaded = false;

var diff_use_color_default: color.ColorBool = .unknown;
var git_use_color_default: color.ColorBool = .auto;
var diff_color_moved_default: ColorMoved = .no;
var diff_color_moved_ws_default: u32 = 0;
var diff_context_default: i32 = 3;
var diff_interhunk_context_default: i32 = 0;
var diff_word_regex_cfg: ?[]const u8 = null;
var external_diff_cfg: ?[]const u8 = null;
var external_diff_trust_cfg = false;
var diff_order_file_cfg: ?[]const u8 = null;
pub var diff_auto_refresh_index = true;
var diff_mnemonic_prefix = false;
var diff_no_prefix = false;
var diff_src_prefix: ?[]const u8 = null;
var diff_dst_prefix: ?[]const u8 = null;
var diff_relative = false;
var diff_stat_name_width: i32 = 0;
var diff_stat_graph_width: i32 = 0;
var diff_dirstat_permille_default: i32 = 30;
var diff_dirstat_flags_default: DirstatFlags = .{};
var diff_algorithm: u64 = 0;
var ws_error_highlight_default: u32 = WSEH_NEW;
var diff_detect_rename_default: u8 = 0;
var diff_rename_limit_default: i32 = 1000;
var diff_suppress_blank_empty = false;
var diff_indent_heuristic = true;
var diff_submodule_format_default: SubmoduleFormat = .short;
var diff_ignore_submodules_default: ?[]const u8 = null;

const DirstatFlags = struct { by_line: bool = false, by_file: bool = false, cumulative: bool = false };

fn cfgInt(e: config.Entry) i32 {
    const kv = e.kvi();
    return config.configInt(e.key, e.value, &kv);
}

/// config_error_nonbool + die (git dies on config callback errors)
fn cfgNonbool(e: config.Entry) []const u8 {
    return e.value orelse {
        util.err("missing value for '{s}'", .{e.key});
        badConfigDie(e);
    };
}

fn badConfigDie(e: config.Entry) noreturn {
    if (e.origin_type == .cmdline or e.origin.len == 0)
        util.die("unable to parse '{s}' from command-line config", .{e.key});
    util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
}

fn parseAlgorithmValue(value: ?[]const u8) ?u64 {
    const v = value orelse return null;
    if (std.ascii.eqlIgnoreCase(v, "myers") or std.ascii.eqlIgnoreCase(v, "default")) return 0;
    if (std.ascii.eqlIgnoreCase(v, "minimal")) return xdiff.XDF_NEED_MINIMAL;
    if (std.ascii.eqlIgnoreCase(v, "patience")) return xdiff.XDF_PATIENCE_DIFF;
    if (std.ascii.eqlIgnoreCase(v, "histogram")) return xdiff.XDF_HISTOGRAM_DIFF;
    return null;
}

/// git_config_rename()
fn configRename(key: []const u8, value: ?[]const u8) u8 {
    const v = value orelse return DETECT_RENAME;
    if (std.ascii.eqlIgnoreCase(v, "copies") or std.ascii.eqlIgnoreCase(v, "copy")) return DETECT_COPY;
    return if (config.configBool(key, v)) DETECT_RENAME else 0;
}

fn parseOneToken(arg: *[]const u8, token: []const u8) bool {
    if (util.skipPrefix(arg.*, token)) |rest| {
        if (rest.len == 0 or rest[0] == ',') {
            arg.* = rest;
            return true;
        }
    }
    return false;
}

/// parse_ws_error_highlight(): value, or error offset (-1 - offset)
fn parseWsErrorHighlight(arg0: []const u8) i64 {
    var arg = arg0;
    var val: u32 = 0;
    while (arg.len > 0) {
        if (parseOneToken(&arg, "none")) {
            val = 0;
        } else if (parseOneToken(&arg, "default")) {
            val = WSEH_NEW;
        } else if (parseOneToken(&arg, "all")) {
            val = WSEH_NEW | WSEH_OLD | WSEH_CONTEXT;
        } else if (parseOneToken(&arg, "new")) {
            val |= WSEH_NEW;
        } else if (parseOneToken(&arg, "old")) {
            val |= WSEH_OLD;
        } else if (parseOneToken(&arg, "context")) {
            val |= WSEH_CONTEXT;
        } else {
            return -1 - @as(i64, @intCast(arg0.len - arg.len));
        }
        if (arg.len > 0) arg = arg[1..];
    }
    return val;
}

fn parseColorMoved(arg: ?[]const u8) ?ColorMoved {
    switch (config.parseMaybeBool(arg)) {
        0 => return .no,
        1 => return COLOR_MOVED_DEFAULT,
        else => {},
    }
    const a = arg orelse return null;
    if (util.eql(a, "no")) return .no;
    if (util.eql(a, "plain")) return .plain;
    if (util.eql(a, "blocks")) return .blocks;
    if (util.eql(a, "zebra")) return .zebra;
    if (util.eql(a, "default")) return COLOR_MOVED_DEFAULT;
    if (util.eql(a, "dimmed-zebra") or util.eql(a, "dimmed_zebra")) return .zebra_dim;
    util.err("color moved setting must be one of 'no', 'default', 'blocks', 'zebra', 'dimmed-zebra', 'plain'", .{});
    return null;
}

fn parseColorMovedWs(arg: []const u8) u32 {
    var ret: u32 = 0;
    var it = std.mem.splitScalar(u8, arg, ',');
    while (it.next()) |raw| {
        const s = util.trim(raw);
        if (util.eql(s, "no")) {
            ret = 0;
        } else if (util.eql(s, "ignore-space-change")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE_CHANGE);
        } else if (util.eql(s, "ignore-space-at-eol")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE_AT_EOL);
        } else if (util.eql(s, "ignore-all-space")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE);
        } else if (util.eql(s, "allow-indentation-change")) {
            ret |= COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE;
        } else {
            ret |= COLOR_MOVED_WS_ERROR;
            util.err("unknown color-moved-ws mode '{s}', possible values are 'ignore-space-change', 'ignore-space-at-eol', 'ignore-all-space', 'allow-indentation-change'", .{s});
        }
    }
    if (ret & COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE != 0 and ret & @as(u32, @intCast(xdiff.XDF_WHITESPACE_FLAGS)) != 0) {
        util.err("color-moved-ws: allow-indentation-change cannot be combined with other whitespace modes", .{});
        ret |= COLOR_MOVED_WS_ERROR;
    }
    return ret;
}

/// parse_dirstat_params(): returns error text (empty if ok)
fn parseDirstatParams(o: *DiffOptions, params: []const u8) []const u8 {
    var errmsg: Buf = .empty;
    if (params.len == 0) return "";
    var it = std.mem.splitScalar(u8, params, ',');
    while (it.next()) |p| {
        if (util.eql(p, "changes")) {
            o.flags.dirstat_by_line = false;
            o.flags.dirstat_by_file = false;
        } else if (util.eql(p, "lines")) {
            o.flags.dirstat_by_line = true;
            o.flags.dirstat_by_file = false;
        } else if (util.eql(p, "files")) {
            o.flags.dirstat_by_line = false;
            o.flags.dirstat_by_file = true;
        } else if (util.eql(p, "noncumulative")) {
            o.flags.dirstat_cumulative = false;
        } else if (util.eql(p, "cumulative")) {
            o.flags.dirstat_cumulative = true;
        } else if (p.len > 0 and isDigit(p[0])) {
            var j: usize = 0;
            var n: i32 = 0;
            while (j < p.len and isDigit(p[j])) : (j += 1) n = n *% 10 +% @as(i32, p[j] - '0');
            var permille = n *% 10;
            if (j < p.len and p[j] == '.' and j + 1 < p.len and isDigit(p[j + 1])) {
                j += 1;
                permille += p[j] - '0';
                j += 1;
                while (j < p.len and isDigit(p[j])) j += 1;
            } else if (j < p.len and p[j] == '.') {
                j += 1;
            }
            if (j == p.len) {
                o.dirstat_permille = permille;
            } else {
                util.bufPrint(&errmsg, "  Failed to parse dirstat cut-off percentage '{s}'\n", .{p});
            }
        } else {
            util.bufPrint(&errmsg, "  Unknown dirstat parameter '{s}'\n", .{p});
        }
    }
    return errmsg.items;
}

fn loadBasicConfig() void {
    if (basic_loaded) return;
    basic_loaded = true;
    loadWhitespaceCfg();
    userdiff.loadConfig();
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        if (util.eql(k, "diff.renamelimit")) {
            diff_rename_limit_default = cfgInt(e);
        } else if (util.skipPrefix(k, "diff.color.") orelse util.skipPrefix(k, "color.diff.")) |name| {
            const slot = parseDiffColorSlot(name) orelse continue;
            const v = cfgNonbool(e);
            diff_colors[slot] = color.parseColor(v) orelse {
                util.err("invalid color value: {s}", .{v});
                badConfigDie(e);
            };
        } else if (util.eql(k, "diff.wserrorhighlight")) {
            const v = cfgNonbool(e);
            const val = parseWsErrorHighlight(v);
            if (val < 0) {
                util.err("unknown value for config '{s}': {s}", .{ k, v });
                badConfigDie(e);
            }
            ws_error_highlight_default = @intCast(val);
        } else if (util.eql(k, "diff.suppressblankempty") or util.eql(k, "diff.suppress-blank-empty")) {
            diff_suppress_blank_empty = config.configBool(k, e.value);
        } else if (util.eql(k, "diff.dirstat")) {
            const v = cfgNonbool(e);
            var tmp = DiffOptions.zero();
            tmp.dirstat_permille = diff_dirstat_permille_default;
            tmp.flags.dirstat_by_line = diff_dirstat_flags_default.by_line;
            tmp.flags.dirstat_by_file = diff_dirstat_flags_default.by_file;
            tmp.flags.dirstat_cumulative = diff_dirstat_flags_default.cumulative;
            const em = parseDirstatParams(&tmp, v);
            if (em.len > 0) util.warn("Found errors in 'diff.dirstat' config variable:\n{s}", .{em});
            diff_dirstat_permille_default = tmp.dirstat_permille;
            diff_dirstat_flags_default = .{ .by_line = tmp.flags.dirstat_by_line, .by_file = tmp.flags.dirstat_by_file, .cumulative = tmp.flags.dirstat_cumulative };
        } else if (util.eql(k, "diff.indentheuristic")) {
            diff_indent_heuristic = config.configBool(k, e.value);
        }
    }
}

fn loadUiConfig() void {
    loadBasicConfig();
    if (ui_loaded) return;
    ui_loaded = true;
    diff_detect_rename_default = DETECT_RENAME;
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        const v = e.value;
        if (util.eql(k, "diff.color") or util.eql(k, "color.diff")) {
            diff_use_color_default = color.configColorBool(k, v);
        } else if (util.eql(k, "color.ui")) {
            git_use_color_default = color.configColorBool(k, v);
        } else if (util.eql(k, "diff.colormoved")) {
            diff_color_moved_default = parseColorMoved(v) orelse badConfigDie(e);
        } else if (util.eql(k, "diff.colormovedws")) {
            const s = cfgNonbool(e);
            const cm = parseColorMovedWs(s);
            if (cm & COLOR_MOVED_WS_ERROR != 0) badConfigDie(e);
            diff_color_moved_ws_default = cm;
        } else if (util.eql(k, "diff.context")) {
            const val = cfgInt(e);
            if (val < 0) badConfigDie(e);
            diff_context_default = val;
        } else if (util.eql(k, "diff.interhunkcontext")) {
            const val = cfgInt(e);
            if (val < 0) badConfigDie(e);
            diff_interhunk_context_default = val;
        } else if (util.eql(k, "diff.renames")) {
            diff_detect_rename_default = configRename(k, v);
        } else if (util.eql(k, "diff.autorefreshindex")) {
            diff_auto_refresh_index = config.configBool(k, v);
        } else if (util.eql(k, "diff.mnemonicprefix")) {
            diff_mnemonic_prefix = config.configBool(k, v);
        } else if (util.eql(k, "diff.noprefix")) {
            diff_no_prefix = config.configBool(k, v);
        } else if (util.eql(k, "diff.srcprefix")) {
            diff_src_prefix = cfgNonbool(e);
        } else if (util.eql(k, "diff.dstprefix")) {
            diff_dst_prefix = cfgNonbool(e);
        } else if (util.eql(k, "diff.relative")) {
            diff_relative = config.configBool(k, v);
        } else if (util.eql(k, "diff.statnamewidth")) {
            diff_stat_name_width = cfgInt(e);
        } else if (util.eql(k, "diff.statgraphwidth")) {
            diff_stat_graph_width = cfgInt(e);
        } else if (util.eql(k, "diff.external")) {
            external_diff_cfg = cfgNonbool(e);
        } else if (util.eql(k, "diff.trustexitcode")) {
            external_diff_trust_cfg = config.configBool(k, v);
        } else if (util.eql(k, "diff.wordregex")) {
            diff_word_regex_cfg = cfgNonbool(e);
        } else if (util.eql(k, "diff.orderfile")) {
            _ = cfgNonbool(e);
            diff_order_file_cfg = repo_mod.cfg.getPath(k);
        } else if (util.eql(k, "diff.ignoresubmodules")) {
            diff_ignore_submodules_default = cfgNonbool(e);
        } else if (util.eql(k, "diff.submodule")) {
            const s = cfgNonbool(e);
            if (util.eql(s, "log")) {
                diff_submodule_format_default = .log;
            } else if (util.eql(s, "short")) {
                diff_submodule_format_default = .short;
            } else if (util.eql(s, "diff")) {
                diff_submodule_format_default = .inline_diff;
            } else util.warn("Unknown value for 'diff.submodule' config variable: '{s}'", .{s});
        } else if (util.eql(k, "diff.algorithm")) {
            const s = cfgNonbool(e);
            diff_algorithm = parseAlgorithmValue(s) orelse {
                util.err("unknown value for config '{s}': {s}", .{ k, s });
                badConfigDie(e);
            };
        }
    }
}

/// Make the porcelain ("UI") diff configuration effective (git_diff_ui_config).
pub fn useUiConfig() void {
    loadUiConfig();
}

/// external_diff(): GIT_EXTERNAL_DIFF or diff.external
fn externalDiff() ?[]const u8 {
    if (os.getenv("GIT_EXTERNAL_DIFF")) |e| return e;
    return external_diff_cfg;
}

// ---------------------------------------------------------------------------
// diff_options

pub const DiffFlags = struct {
    recursive: bool = false,
    tree_in_recursive: bool = false,
    binary: bool = false,
    text: bool = false,
    full_index: bool = false,
    silent_on_remove: bool = false,
    find_copies_harder: bool = false,
    follow_renames: bool = false,
    rename_empty: bool = true,
    has_changes: bool = false,
    quick: bool = false,
    no_index: bool = false,
    allow_external: bool = false,
    exit_with_status: bool = false,
    reverse: bool = false,
    check_failed: bool = false,
    relative_name: bool = false,
    ignore_submodules: bool = false,
    dirstat_cumulative: bool = false,
    dirstat_by_file: bool = false,
    allow_textconv: bool = false,
    textconv_set_via_cmdline: bool = false,
    diff_from_contents: bool = false,
    dirty_submodules: bool = false,
    ignore_untracked_in_submodules: bool = false,
    ignore_dirty_submodules: bool = false,
    override_submodule_config: bool = false,
    dirstat_by_line: bool = false,
    funccontext: bool = false,
    default_follow_renames: bool = false,
    stat_with_summary: bool = false,
    suppress_diff_headers: bool = false,
    dual_color_diffed_diffs: bool = false,
    suppress_hunk_header_line_count: bool = false,
    ignore_submodule_set: bool = false,
};

pub const DiffOptions = struct {
    output_format: u32 = 0,
    flags: DiffFlags = .{},
    /// output stream; null = discard
    file: ?*util.Out = &util.stdout,
    close_file: bool = false,
    pathspec: pathspec_mod.Pathspec = .{},
    a_prefix: ?[]const u8 = null,
    b_prefix: ?[]const u8 = null,
    line_prefix: ?[]const u8 = null,
    /// --relative prefix (path relative to top, ending with '/')
    prefix: ?[]const u8 = null,
    prefix_length: usize = 0,
    stat_sep: ?[]const u8 = null,
    xdl_opts: u64 = 0,
    ignore_driver_algorithm: bool = false,
    ignore_regex: std.ArrayList(regex.Regex) = .empty,
    anchors: std.ArrayList([]const u8) = .empty,
    ws_error_highlight: u32 = WSEH_NEW,
    context: i32 = 3,
    interhunkcontext: i32 = 0,
    break_opt: i32 = -1,
    detect_rename: u8 = 0,
    irreversible_delete: bool = false,
    skip_stat_unmatch: i32 = 0,
    /// diff-pairs: keep the statuses of queued pairs as given
    skip_resolving_statuses: bool = false,
    /// remerge-diff: extra per-path header lines (diff_options.additional_path_headers)
    additional_path_headers: ?*const PathHeaders = null,
    line_termination: u8 = '\n',
    output_indicators: [3]u8 = .{ '+', '-', ' ' },
    pickaxe: ?[]const u8 = null,
    pickaxe_opts: u32 = 0,
    pickaxe_re: ?regex.Regex = null,
    filter: u32 = 0,
    filter_not: u32 = 0,
    orderfile: ?[]const u8 = null,
    rotate_to: ?[]const u8 = null,
    skip_instead_of_rotate: bool = false,
    /// die when --rotate-to path is missing (diff, not log)
    rotate_to_strict: bool = false,
    objfind: ?*hash.OidSet = null,
    /// -1 = default abbreviation, 0 = full
    abbrev: i32 = -1,
    rename_score: u32 = 0,
    rename_limit: i32 = -1,
    needed_rename_limit: i32 = 0,
    degraded_cc_to_c: bool = false,
    show_rename_progress: bool = false,
    use_color: color.ColorBool = .unknown,
    color_moved: ColorMoved = .no,
    color_moved_ws_handling: u32 = 0,
    /// buffered symbols while --color-moved detection runs (o->emitted_symbols)
    emitted: ?*std.ArrayList(Emitted) = null,
    stat_width: i32 = 0,
    stat_name_width: i32 = 0,
    stat_graph_width: i32 = 0,
    stat_count: i32 = 0,
    word_regex: ?[]const u8 = null,
    word_diff: WordDiff = .none,
    submodule_format: SubmoduleFormat = .short,
    dirstat_permille: i32 = 30,
    found_changes: bool = false,
    found_follow: bool = false,
    graph: ?*graph_mod.Graph = null,
    ita_invisible_in_index: bool = false,
    max_depth: i32 = -1,
    max_depth_valid: bool = false,
    /// --follow: restrict rename detection to this path (diffcore-rename)
    single_follow: ?[]const u8 = null,
    diff_path_counter: usize = 0,
    /// set when the options come from a porcelain (init())
    porcelain: bool = false,
    /// --no-index: paths are not repository paths
    no_index_paths: bool = false,
    /// prefixes came from diff.noprefix config (format-patch ignores it)
    prefix_from_cfg: bool = false,
    /// rev_info for log-tree callbacks (setupRevDiff)
    revs: ?*revision.RevInfo = null,

    /// all zero, no config consulted
    pub fn zero() DiffOptions {
        return .{};
    }

    /// repo_diff_setup() after git_diff_basic_config (plumbing)
    pub fn initBasic() DiffOptions {
        loadBasicConfig();
        var o = DiffOptions{};
        o.setupDefaults();
        return o;
    }

    /// repo_diff_setup() after git_diff_ui_config (porcelain)
    pub fn init() DiffOptions {
        loadUiConfig();
        var o = DiffOptions{};
        o.porcelain = true;
        o.setupDefaults();
        return o;
    }

    fn setupDefaults(o: *DiffOptions) void {
        o.file = &util.stdout;
        o.output_indicators = .{ '+', '-', ' ' };
        o.abbrev = -1;
        o.line_termination = '\n';
        o.break_opt = -1;
        o.rename_limit = -1;
        o.dirstat_permille = diff_dirstat_permille_default;
        o.flags.dirstat_by_line = diff_dirstat_flags_default.by_line;
        o.flags.dirstat_by_file = diff_dirstat_flags_default.by_file;
        o.flags.dirstat_cumulative = diff_dirstat_flags_default.cumulative;
        o.context = diff_context_default;
        o.interhunkcontext = diff_interhunk_context_default;
        o.ws_error_highlight = ws_error_highlight_default;
        o.flags.rename_empty = true;
        o.flags.relative_name = diff_relative;
        o.use_color = diff_use_color_default;
        o.detect_rename = diff_detect_rename_default;
        o.xdl_opts |= diff_algorithm;
        if (diff_indent_heuristic) o.xdl_opts |= xdiff.XDF_INDENT_HEURISTIC;
        o.orderfile = diff_order_file_cfg;
        if (!o.flags.ignore_submodule_set) o.flags.ignore_untracked_in_submodules = true;
        if (diff_no_prefix) {
            o.setNoprefix();
            o.prefix_from_cfg = true;
        } else if (!diff_mnemonic_prefix) {
            o.setDefaultPrefix();
        }
        o.color_moved = diff_color_moved_default;
        o.color_moved_ws_handling = diff_color_moved_ws_default;
        o.submodule_format = diff_submodule_format_default;
        if (repo_mod.repo_) |r| {
            if (r.prefix.len > 0) {
                o.prefix = r.prefix;
                o.prefix_length = r.prefix.len;
            }
        }
        if (diff_ignore_submodules_default) |v| {
            if (util.eql(v, "all")) o.flags.ignore_submodules = true;
        }
    }

    pub fn setNoprefix(o: *DiffOptions) void {
        o.a_prefix = "";
        o.b_prefix = "";
    }

    pub fn setDefaultPrefix(o: *DiffOptions) void {
        o.a_prefix = diff_src_prefix orelse "a/";
        o.b_prefix = diff_dst_prefix orelse "b/";
    }

    /// diff_set_mnemonic_prefix(): only fills unset prefixes
    pub fn setMnemonicPrefix(o: *DiffOptions, a: []const u8, b: []const u8) void {
        if (o.a_prefix == null) o.a_prefix = a;
        if (o.b_prefix == null) o.b_prefix = b;
    }

    /// handle_ignore_submodules_arg()
    pub fn handleIgnoreSubmodulesArg(o: *DiffOptions, arg: []const u8) void {
        o.flags.ignore_submodule_set = true;
        o.flags.ignore_submodules = false;
        o.flags.ignore_untracked_in_submodules = false;
        o.flags.ignore_dirty_submodules = false;
        if (util.eql(arg, "all")) {
            o.flags.ignore_submodules = true;
        } else if (util.eql(arg, "untracked")) {
            o.flags.ignore_untracked_in_submodules = true;
        } else if (util.eql(arg, "dirty")) {
            o.flags.ignore_dirty_submodules = true;
        } else if (!util.eql(arg, "none")) {
            util.die("bad --ignore-submodules argument: {s}", .{arg});
        }
    }

    pub fn setAlgorithm(o: *DiffOptions, alg: []const u8) bool {
        const v = parseAlgorithmValue(alg) orelse return false;
        o.xdl_opts &= ~xdiff.XDF_DIFF_ALGORITHM_MASK;
        o.xdl_opts |= v;
        return true;
    }

    /// Parse one diff option at args[i]. Returns the number of args consumed,
    /// 0 when args[i] is not a diff option. Usage errors exit 129.
    pub fn parseOpt(o: *DiffOptions, args: []const []const u8, i: usize) usize {
        return parseDiffOpt(o, args, i);
    }

    /// diff_setup_done()
    pub fn setupDone(o: *DiffOptions) void {
        setupDoneImpl(o);
    }

    pub fn out(o: *DiffOptions) *util.Out {
        return o.file orelse &null_out;
    }
};

var null_out = util.Out{ .fd = -1, .broken = true };

fn hasMultiBits(x: u32) bool {
    return x & (x -% 1) != 0;
}

fn setupDoneImpl(o: *DiffOptions) void {
    const check_mask = FMT_NAME | FMT_NAME_STATUS | FMT_CHECKDIFF | FMT_NO_OUTPUT;
    if (hasMultiBits(o.output_format & check_mask))
        util.die("options '{s}', '{s}', '{s}', and '{s}' cannot be used together", .{ "--name-only", "--name-status", "--check", "-s" });
    if (hasMultiBits(o.pickaxe_opts & PICKAXE_KINDS_MASK))
        util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ "-G", "-S", "--find-object" });
    if (hasMultiBits(o.pickaxe_opts & (PICKAXE_KIND_G | PICKAXE_REGEX)))
        util.die("options '{s}' and '{s}' cannot be used together, use '{s}' with '{s}'", .{ "-G", "--pickaxe-regex", "--pickaxe-regex", "-S" });
    if (hasMultiBits(o.pickaxe_opts & (PICKAXE_ALL | PICKAXE_KIND_OBJFIND)))
        util.die("options '{s}' and '{s}' cannot be used together, use '{s}' with '{s}' and '{s}'", .{ "--pickaxe-all", "--find-object", "--pickaxe-all", "-G", "-S" });

    o.flags.diff_from_contents = (o.xdl_opts & xdiff.XDF_WHITESPACE_FLAGS) != 0 or o.ignore_regex.items.len > 0;
    if (o.flags.find_copies_harder) o.detect_rename = DETECT_COPY;
    if (!o.flags.relative_name) o.prefix = null;
    o.prefix_length = if (o.prefix) |p| p.len else 0;

    if (o.output_format & (FMT_NAME | FMT_NAME_STATUS | FMT_CHECKDIFF | FMT_NO_OUTPUT) != 0)
        o.output_format &= ~(FMT_RAW | FMT_NUMSTAT | FMT_DIFFSTAT | FMT_SHORTSTAT | FMT_DIRSTAT | FMT_SUMMARY | FMT_PATCH);
    if (o.output_format & (FMT_PATCH | FMT_NUMSTAT | FMT_DIFFSTAT | FMT_SHORTSTAT | FMT_DIRSTAT | FMT_SUMMARY | FMT_CHECKDIFF) != 0)
        o.flags.recursive = true;
    if (o.pickaxe_opts & PICKAXE_KINDS_MASK != 0) o.flags.recursive = true;
    if (o.output_format & FMT_PATCH != 0) o.flags.dirty_submodules = true;
    if (o.detect_rename != 0 and o.rename_limit < 0) o.rename_limit = diff_rename_limit_default;
    if (40 < o.abbrev) o.abbrev = 40;
    if (o.flags.quick) {
        o.output_format = FMT_NO_OUTPUT;
        o.flags.exit_with_status = true;
        o.detect_rename = 0;
        o.flags.find_copies_harder = false;
    }
    if (o.flags.allow_external and o.flags.exit_with_status) o.flags.diff_from_contents = true;
    o.diff_path_counter = 0;
    if (o.flags.follow_renames) _ = checkFollowPathspec(&o.pathspec, true);
    if (o.flags.allow_external and externalDiff() != null) o.color_moved = .no;
    if (o.filter_not != 0) {
        if (o.filter == 0) o.filter = ~filterBit(STATUS_FILTER_AON);
        o.filter &= ~o.filter_not;
    }
    if (o.pathspec.has_wildcard and o.max_depth_valid)
        util.die("max-depth cannot be used with wildcard pathspecs", .{});
}

/// diff_check_follow_pathspec()
pub fn checkFollowPathspec(ps: *const pathspec_mod.Pathspec, die_on_error: bool) bool {
    if (ps.items.len != 1) {
        if (die_on_error) util.die("--follow requires exactly one pathspec", .{});
        return false;
    }
    const forbidden = ps.items[0].magic & ~(pathspec_mod.MAGIC_FROMTOP | pathspec_mod.MAGIC_LITERAL);
    if (forbidden != 0) {
        if (die_on_error) util.die("pathspec magic not supported by --follow: {s}", .{pathspec_mod.magicNames(forbidden)});
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------
// option parsing (add_diff_options + parse-options ONE_SHOT|KEEP_UNKNOWN_OPT)

const ArgKind = enum { none, req, opt };
const OptId = enum {
    patch,
    no_patch,
    u,
    unified,
    function_context,
    raw,
    patch_with_raw,
    patch_with_stat,
    numstat,
    shortstat,
    dirstat,
    cumulative,
    dirstat_by_file,
    check,
    summary,
    name_only,
    name_status,
    stat,
    stat_width,
    stat_name_width,
    stat_graph_width,
    stat_count,
    compact_summary,
    binary,
    full_index,
    color,
    ws_error_highlight,
    z,
    abbrev,
    src_prefix,
    dst_prefix,
    line_prefix,
    no_prefix,
    default_prefix,
    inter_hunk_context,
    output_indicator_new,
    output_indicator_old,
    output_indicator_context,
    break_rewrites,
    find_renames,
    irreversible_delete,
    find_copies,
    find_copies_harder,
    no_renames,
    rename_empty,
    follow,
    rename_limit,
    minimal,
    ignore_all_space,
    ignore_space_change,
    ignore_space_at_eol,
    ignore_cr_at_eol,
    ignore_blank_lines,
    ignore_matching_lines,
    indent_heuristic,
    patience,
    histogram,
    diff_algorithm,
    anchored,
    word_diff,
    word_diff_regex,
    color_words,
    color_moved,
    color_moved_ws,
    relative,
    text,
    reverse,
    exit_code,
    quiet,
    ext_diff,
    textconv,
    ignore_submodules,
    submodule,
    ita_invisible,
    ita_visible,
    pickaxe_s,
    pickaxe_g,
    pickaxe_all,
    pickaxe_regex,
    orderfile,
    rotate_to,
    skip_to,
    find_object,
    diff_filter,
    max_depth,
    output,
};

const OptDef = struct {
    short: u8 = 0,
    long: []const u8 = "",
    arg: ArgKind = .none,
    noneg: bool = false,
    id: OptId,
};

const opt_defs = [_]OptDef{
    .{ .short = 'p', .long = "patch", .noneg = true, .id = .patch },
    .{ .short = 's', .long = "no-patch", .id = .no_patch },
    .{ .short = 'u', .noneg = true, .id = .u },
    .{ .short = 'U', .long = "unified", .arg = .opt, .noneg = true, .id = .unified },
    .{ .short = 'W', .long = "function-context", .id = .function_context },
    .{ .long = "raw", .noneg = true, .id = .raw },
    .{ .long = "patch-with-raw", .noneg = true, .id = .patch_with_raw },
    .{ .long = "patch-with-stat", .noneg = true, .id = .patch_with_stat },
    .{ .long = "numstat", .noneg = true, .id = .numstat },
    .{ .long = "shortstat", .noneg = true, .id = .shortstat },
    .{ .short = 'X', .long = "dirstat", .arg = .opt, .noneg = true, .id = .dirstat },
    .{ .long = "cumulative", .noneg = true, .id = .cumulative },
    .{ .long = "dirstat-by-file", .arg = .opt, .noneg = true, .id = .dirstat_by_file },
    .{ .long = "check", .noneg = true, .id = .check },
    .{ .long = "summary", .noneg = true, .id = .summary },
    .{ .long = "name-only", .noneg = true, .id = .name_only },
    .{ .long = "name-status", .noneg = true, .id = .name_status },
    .{ .long = "stat", .arg = .opt, .noneg = true, .id = .stat },
    .{ .long = "stat-width", .arg = .req, .noneg = true, .id = .stat_width },
    .{ .long = "stat-name-width", .arg = .req, .noneg = true, .id = .stat_name_width },
    .{ .long = "stat-graph-width", .arg = .req, .noneg = true, .id = .stat_graph_width },
    .{ .long = "stat-count", .arg = .req, .noneg = true, .id = .stat_count },
    .{ .long = "compact-summary", .id = .compact_summary },
    .{ .long = "binary", .noneg = true, .id = .binary },
    .{ .long = "full-index", .id = .full_index },
    .{ .long = "color", .arg = .opt, .id = .color },
    .{ .long = "ws-error-highlight", .arg = .req, .noneg = true, .id = .ws_error_highlight },
    .{ .short = 'z', .id = .z },
    .{ .long = "abbrev", .arg = .opt, .id = .abbrev },
    .{ .long = "src-prefix", .arg = .req, .noneg = true, .id = .src_prefix },
    .{ .long = "dst-prefix", .arg = .req, .noneg = true, .id = .dst_prefix },
    .{ .long = "line-prefix", .arg = .req, .noneg = true, .id = .line_prefix },
    .{ .long = "no-prefix", .noneg = true, .id = .no_prefix },
    .{ .long = "default-prefix", .noneg = true, .id = .default_prefix },
    .{ .long = "inter-hunk-context", .arg = .req, .id = .inter_hunk_context },
    .{ .long = "output-indicator-new", .arg = .req, .noneg = true, .id = .output_indicator_new },
    .{ .long = "output-indicator-old", .arg = .req, .noneg = true, .id = .output_indicator_old },
    .{ .long = "output-indicator-context", .arg = .req, .noneg = true, .id = .output_indicator_context },
    .{ .short = 'B', .long = "break-rewrites", .arg = .opt, .noneg = true, .id = .break_rewrites },
    .{ .short = 'M', .long = "find-renames", .arg = .opt, .noneg = true, .id = .find_renames },
    .{ .short = 'D', .long = "irreversible-delete", .noneg = true, .id = .irreversible_delete },
    .{ .short = 'C', .long = "find-copies", .arg = .opt, .noneg = true, .id = .find_copies },
    .{ .long = "find-copies-harder", .id = .find_copies_harder },
    .{ .long = "no-renames", .noneg = true, .id = .no_renames },
    .{ .long = "rename-empty", .id = .rename_empty },
    .{ .long = "follow", .id = .follow },
    .{ .short = 'l', .arg = .req, .id = .rename_limit },
    .{ .long = "minimal", .noneg = true, .id = .minimal },
    .{ .short = 'w', .long = "ignore-all-space", .noneg = true, .id = .ignore_all_space },
    .{ .short = 'b', .long = "ignore-space-change", .noneg = true, .id = .ignore_space_change },
    .{ .long = "ignore-space-at-eol", .noneg = true, .id = .ignore_space_at_eol },
    .{ .long = "ignore-cr-at-eol", .noneg = true, .id = .ignore_cr_at_eol },
    .{ .long = "ignore-blank-lines", .noneg = true, .id = .ignore_blank_lines },
    .{ .short = 'I', .long = "ignore-matching-lines", .arg = .req, .id = .ignore_matching_lines },
    .{ .long = "indent-heuristic", .id = .indent_heuristic },
    .{ .long = "patience", .noneg = true, .id = .patience },
    .{ .long = "histogram", .noneg = true, .id = .histogram },
    .{ .long = "diff-algorithm", .arg = .req, .noneg = true, .id = .diff_algorithm },
    .{ .long = "anchored", .arg = .req, .noneg = true, .id = .anchored },
    .{ .long = "word-diff", .arg = .opt, .noneg = true, .id = .word_diff },
    .{ .long = "word-diff-regex", .arg = .req, .noneg = true, .id = .word_diff_regex },
    .{ .long = "color-words", .arg = .opt, .noneg = true, .id = .color_words },
    .{ .long = "color-moved", .arg = .opt, .id = .color_moved },
    .{ .long = "color-moved-ws", .arg = .req, .id = .color_moved_ws },
    .{ .long = "relative", .arg = .opt, .id = .relative },
    .{ .short = 'a', .long = "text", .id = .text },
    .{ .short = 'R', .id = .reverse },
    .{ .long = "exit-code", .id = .exit_code },
    .{ .long = "quiet", .id = .quiet },
    .{ .long = "ext-diff", .id = .ext_diff },
    .{ .long = "textconv", .id = .textconv },
    .{ .long = "ignore-submodules", .arg = .opt, .noneg = true, .id = .ignore_submodules },
    .{ .long = "submodule", .arg = .opt, .noneg = true, .id = .submodule },
    .{ .long = "ita-invisible-in-index", .noneg = true, .id = .ita_invisible },
    .{ .long = "ita-visible-in-index", .noneg = true, .id = .ita_visible },
    .{ .short = 'S', .arg = .req, .id = .pickaxe_s },
    .{ .short = 'G', .arg = .req, .id = .pickaxe_g },
    .{ .long = "pickaxe-all", .noneg = true, .id = .pickaxe_all },
    .{ .long = "pickaxe-regex", .noneg = true, .id = .pickaxe_regex },
    .{ .short = 'O', .arg = .req, .id = .orderfile },
    .{ .long = "rotate-to", .arg = .req, .noneg = true, .id = .rotate_to },
    .{ .long = "skip-to", .arg = .req, .noneg = true, .id = .skip_to },
    .{ .long = "find-object", .arg = .req, .noneg = true, .id = .find_object },
    .{ .long = "diff-filter", .arg = .req, .noneg = true, .id = .diff_filter },
    .{ .long = "max-depth", .arg = .req, .noneg = true, .id = .max_depth },
    .{ .long = "output", .arg = .req, .noneg = true, .id = .output },
};

fn optError(comptime f: []const u8, args: anytype) noreturn {
    util.err(f, args);
    os.exit(129);
}

fn optName(d: *const OptDef, short: bool, unset: bool) []const u8 {
    if (short) return util.fmt("switch `{c}'", .{d.short});
    if (unset) return util.fmt("option `no-{s}'", .{d.long});
    return util.fmt("option `{s}'", .{d.long});
}

const ParseState = struct {
    args: []const []const u8,
    i: usize,
    consumed: usize = 1,
};

fn checkTypos(arg: []const u8) void {
    if (arg.len < 3) return;
    if (util.startsWith(arg, "no-")) optError("did you mean `--{s}` (with two dashes)?", .{arg});
    for (opt_defs) |d| {
        if (d.long.len == 0) continue;
        if (util.startsWith(d.long, arg)) optError("did you mean `--{s}` (with two dashes)?", .{arg});
    }
}

fn parseDiffOpt(o: *DiffOptions, args: []const []const u8, i: usize) usize {
    if (i >= args.len) return 0;
    const arg = args[i];
    if (arg.len < 2 or arg[0] != '-') return 0;
    var st = ParseState{ .args = args, .i = i };
    if (arg[1] != '-') {
        // short option(s)
        var rest: []const u8 = arg[1..];
        var first = true;
        while (rest.len > 0) {
            const c = rest[0];
            var found: ?*const OptDef = null;
            for (&opt_defs) |*d| {
                if (d.short == c) {
                    found = d;
                    break;
                }
            }
            const d = found orelse {
                if (first and rest.len > 0) checkTypos(arg[1..]);
                return 0;
            };
            rest = rest[1..];
            var value: ?[]const u8 = null;
            switch (d.arg) {
                .none => {},
                .opt => {
                    if (rest.len > 0) value = rest;
                    rest = "";
                },
                .req => {
                    if (rest.len > 0) {
                        value = rest;
                    } else if (i + 1 < args.len) {
                        value = args[i + 1];
                        st.consumed = 2;
                    } else optError("{s} requires a value", .{optName(d, true, false)});
                    rest = "";
                },
            }
            applyOpt(o, d, value, false, true, &st);
            if (first and rest.len > 0) checkTypos(arg[1..]);
            first = false;
        }
        return st.consumed;
    }
    if (arg.len == 2) return 0; // "--"
    const body = arg[2..];
    if (util.eql(body, "end-of-options")) return 0;
    var arg_start = body;
    var flags_unset = false;
    var no_no = false;
    if (util.skipPrefix(arg_start, "no-")) |r| {
        arg_start = r;
        if (util.skipPrefix(arg_start, "no-")) |r2| {
            arg_start = r2;
            no_no = true;
        } else flags_unset = true;
    }
    for (&opt_defs) |*d| {
        if (d.long.len == 0) continue;
        var long_name = d.long;
        var opt_unset = false;
        if (util.skipPrefix(long_name, "no-")) |r| {
            long_name = r;
            opt_unset = true;
        } else if (no_no) continue;
        const unset = flags_unset != opt_unset;
        if (unset and d.noneg) continue;
        const rest = util.skipPrefix(arg_start, long_name) orelse continue;
        var value: ?[]const u8 = null;
        var has_eq = false;
        if (rest.len > 0) {
            if (rest[0] != '=') continue;
            value = rest[1..];
            has_eq = true;
        }
        if (unset and has_eq) optError("{s} takes no value", .{optName(d, false, true)});
        if (d.arg == .none and has_eq) optError("{s} takes no value", .{optName(d, false, false)});
        if (d.arg == .req and !has_eq and !unset) {
            if (i + 1 < args.len) {
                value = args[i + 1];
                st.consumed = 2;
            } else optError("{s} requires a value", .{optName(d, false, false)});
        }
        applyOpt(o, d, value, unset, false, &st);
        return st.consumed;
    }
    return 0;
}

fn strtoulPrefix(s: []const u8) struct { v: i64, rest: []const u8 } {
    var j: usize = 0;
    while (j < s.len and isSpace(s[j])) j += 1;
    if (j < s.len and s[j] == '+') j += 1;
    const start = j;
    var v: i64 = 0;
    while (j < s.len and isDigit(s[j])) : (j += 1) v = v *% 10 +% (s[j] - '0');
    if (j == start) return .{ .v = 0, .rest = s };
    return .{ .v = v, .rest = s[j..] };
}

fn strtolPrefix(s: []const u8) struct { v: i64, rest: []const u8 } {
    var j: usize = 0;
    while (j < s.len and isSpace(s[j])) j += 1;
    var neg = false;
    if (j < s.len and (s[j] == '+' or s[j] == '-')) {
        neg = s[j] == '-';
        j += 1;
    }
    const start = j;
    var v: i64 = 0;
    while (j < s.len and isDigit(s[j])) : (j += 1) v = v *% 10 +% (s[j] - '0');
    if (j == start) return .{ .v = 0, .rest = s };
    return .{ .v = if (neg) -v else v, .rest = s[j..] };
}

/// parse_rename_score(): returns score and the unparsed rest
pub fn parseRenameScore(s: []const u8, rest_out: *[]const u8) u32 {
    var num: u64 = 0;
    var scale: u64 = 1;
    var dot = false;
    var j: usize = 0;
    while (j < s.len) {
        const ch = s[j];
        if (!dot and ch == '.') {
            scale = 1;
            dot = true;
        } else if (ch == '%') {
            scale = if (dot) scale * 100 else 100;
            j += 1;
            break;
        } else if (isDigit(ch)) {
            if (scale < 100000) {
                scale *= 10;
                num = num * 10 + (ch - '0');
            }
        } else break;
        j += 1;
    }
    rest_out.* = s[j..];
    if (num >= scale) return MAX_SCORE;
    return @intCast(MAX_SCORE * num / scale);
}

fn userPrefix() []const u8 {
    if (repo_mod.repo_) |r| return r.prefix;
    return "";
}

fn prefixFilename(arg: []const u8) []const u8 {
    if (arg.len > 0 and arg[0] == '/') return arg;
    const p = userPrefix();
    if (p.len == 0) return arg;
    return util.concat(&.{ p, arg });
}

fn parseDirstatOpt(o: *DiffOptions, params: []const u8) void {
    const em = parseDirstatParams(o, params);
    if (em.len > 0) util.die("Failed to parse --dirstat/-X option parameter:\n{s}", .{em});
    o.output_format &= ~FMT_NO_OUTPUT;
    o.output_format |= FMT_DIRSTAT;
}

fn enablePatchOutput(o: *DiffOptions) void {
    o.output_format &= ~FMT_NO_OUTPUT;
    o.output_format |= FMT_PATCH;
}

fn bitop(o: *DiffOptions, set: u32) void {
    o.output_format &= ~FMT_NO_OUTPUT;
    o.output_format |= set;
}

fn applyOpt(o: *DiffOptions, d: *const OptDef, value: ?[]const u8, unset: bool, short: bool, st: *ParseState) void {
    _ = st;
    switch (d.id) {
        .patch, .u => bitop(o, FMT_PATCH),
        .no_patch => o.output_format = if (unset) 0 else FMT_NO_OUTPUT,
        .unified => {
            if (value) |v| {
                const r = strtolPrefix(v);
                if (r.rest.len != 0 or (v.len == 0)) {
                    if (r.rest.len != 0) optError("{s} expects a numerical value", .{"--unified"});
                }
                if (r.v < 0) optError("{s} expects a non-negative integer", .{"--unified"});
                o.context = @intCast(@min(r.v, std.math.maxInt(i32)));
            }
            enablePatchOutput(o);
        },
        .function_context => o.flags.funccontext = !unset,
        .raw => bitop(o, FMT_RAW),
        .patch_with_raw => bitop(o, FMT_PATCH | FMT_RAW),
        .patch_with_stat => bitop(o, FMT_PATCH | FMT_DIFFSTAT),
        .numstat => bitop(o, FMT_NUMSTAT),
        .shortstat => bitop(o, FMT_SHORTSTAT),
        .dirstat => parseDirstatOpt(o, value orelse ""),
        .cumulative => parseDirstatOpt(o, "cumulative"),
        .dirstat_by_file => {
            parseDirstatOpt(o, "files");
            parseDirstatOpt(o, value orelse "");
        },
        .check => o.output_format |= FMT_CHECKDIFF,
        .summary => bitop(o, FMT_SUMMARY),
        .name_only => o.output_format |= FMT_NAME,
        .name_status => o.output_format |= FMT_NAME_STATUS,
        .stat, .stat_width, .stat_name_width, .stat_graph_width, .stat_count => {
            var width = o.stat_width;
            var name_width = o.stat_name_width;
            var graph_width = o.stat_graph_width;
            var count = o.stat_count;
            if (d.id == .stat) {
                if (value) |v| {
                    var r = strtoulPrefix(v);
                    width = @truncate(r.v);
                    if (r.rest.len > 0 and r.rest[0] == ',') {
                        r = strtoulPrefix(r.rest[1..]);
                        name_width = @truncate(r.v);
                    }
                    if (r.rest.len > 0 and r.rest[0] == ',') {
                        r = strtoulPrefix(r.rest[1..]);
                        count = @truncate(r.v);
                    }
                    if (r.rest.len > 0) optError("invalid --stat value: {s}", .{v});
                }
            } else {
                const v = value.?;
                const r = strtoulPrefix(v);
                if (r.rest.len > 0) optError("{s} expects a numerical value", .{d.long});
                const n: i32 = @truncate(r.v);
                switch (d.id) {
                    .stat_width => width = n,
                    .stat_name_width => name_width = n,
                    .stat_graph_width => graph_width = n,
                    else => count = n,
                }
            }
            bitop(o, FMT_DIFFSTAT);
            o.stat_name_width = name_width;
            o.stat_graph_width = graph_width;
            o.stat_width = width;
            o.stat_count = count;
        },
        .compact_summary => {
            if (unset) {
                o.flags.stat_with_summary = false;
            } else {
                o.flags.stat_with_summary = true;
                bitop(o, FMT_DIFFSTAT);
            }
        },
        .binary => {
            enablePatchOutput(o);
            o.flags.binary = true;
        },
        .full_index => o.flags.full_index = !unset,
        .color => {
            const a = value orelse (if (unset) "never" else "always");
            const v = color.configColorBool(null, a);
            if (v == .unknown) optError("option `{s}' expects \"always\", \"auto\", or \"never\"", .{"color"});
            o.use_color = v;
        },
        .ws_error_highlight => {
            const v = value.?;
            const val = parseWsErrorHighlight(v);
            if (val < 0) {
                const n: usize = @intCast(-1 - val);
                optError("unknown value after ws-error-highlight={s}", .{v[0..@min(n, v.len)]});
            }
            o.ws_error_highlight = @intCast(val);
        },
        .z => o.line_termination = if (unset) '\n' else 0,
        .abbrev => {
            if (value) |v| {
                if (v.len == 0) optError("option `{s}' expects a numerical value", .{"abbrev"});
                const r = strtolPrefix(v);
                if (r.rest.len > 0) optError("option `{s}' expects a numerical value", .{"abbrev"});
                var n: i32 = @truncate(r.v);
                if (n != 0 and n < 4) n = 4;
                o.abbrev = n;
            } else {
                o.abbrev = if (unset) 0 else -1;
            }
        },
        .src_prefix => {
            o.a_prefix = value.?;
            o.prefix_from_cfg = false;
        },
        .dst_prefix => {
            o.b_prefix = value.?;
            o.prefix_from_cfg = false;
        },
        .line_prefix => {
            o.line_prefix = value.?;
            graph_mod.line_prefix = value.?;
        },
        .no_prefix => {
            o.setNoprefix();
            o.prefix_from_cfg = false;
        },
        .default_prefix => {
            diff_src_prefix = null;
            diff_dst_prefix = null;
            o.setDefaultPrefix();
            o.prefix_from_cfg = false;
        },
        .inter_hunk_context => {
            if (unset) {
                o.interhunkcontext = 0;
            } else {
                const v = value.?;
                if (v.len == 0) optError("{s} expects a numerical value", .{optName(d, short, false)});
                if (v[0] == '-') optError("{s} expects a non-negative integer value with an optional k/m/g suffix", .{optName(d, short, false)});
                switch (config.parseSigned(v, std.math.maxInt(i32))) {
                    .ok => |n| {
                        if (n < 0) optError("{s} expects a non-negative integer value with an optional k/m/g suffix", .{optName(d, short, false)});
                        o.interhunkcontext = @intCast(n);
                    },
                    .err => |e| {
                        if (e == .out_of_range) optError("value {s} for {s} not in range [0,{d}]", .{ v, optName(d, short, false), std.math.maxInt(u32) });
                        optError("{s} expects a non-negative integer value with an optional k/m/g suffix", .{optName(d, short, false)});
                    },
                }
            }
        },
        .output_indicator_new, .output_indicator_old, .output_indicator_context => {
            const v = value.?;
            if (v.len != 1) optError("{s} expects a character, got '{s}'", .{ d.long, v });
            const idx: usize = switch (d.id) {
                .output_indicator_new => OUTPUT_INDICATOR_NEW,
                .output_indicator_old => OUTPUT_INDICATOR_OLD,
                else => OUTPUT_INDICATOR_CONTEXT,
            };
            o.output_indicators[idx] = v[0];
        },
        .break_rewrites => {
            const a = value orelse "";
            var rest: []const u8 = undefined;
            const opt1 = parseRenameScore(a, &rest);
            var opt2: u32 = 0;
            if (rest.len != 0) {
                if (rest[0] != '/') optError("{s} expects <n>/<m> form", .{d.long});
                opt2 = parseRenameScore(rest[1..], &rest);
            }
            if (rest.len != 0) optError("{s} expects <n>/<m> form", .{d.long});
            o.break_opt = @bitCast(opt1 | (opt2 << 16));
        },
        .find_renames => {
            var rest: []const u8 = undefined;
            o.rename_score = parseRenameScore(value orelse "", &rest);
            if (rest.len != 0) optError("invalid argument to {s}", .{d.long});
            o.detect_rename = DETECT_RENAME;
        },
        .irreversible_delete => o.irreversible_delete = true,
        .find_copies => {
            var rest: []const u8 = undefined;
            o.rename_score = parseRenameScore(value orelse "", &rest);
            if (rest.len != 0) optError("invalid argument to {s}", .{d.long});
            if (o.detect_rename == DETECT_COPY) {
                o.flags.find_copies_harder = true;
            } else o.detect_rename = DETECT_COPY;
        },
        .find_copies_harder => o.flags.find_copies_harder = !unset,
        .no_renames => o.detect_rename = 0,
        .rename_empty => o.flags.rename_empty = !unset,
        .follow => {
            if (unset) {
                o.flags.follow_renames = false;
                o.flags.default_follow_renames = false;
            } else o.flags.follow_renames = true;
        },
        .rename_limit => {
            if (unset) {
                o.rename_limit = 0;
            } else {
                const v = value.?;
                if (v.len == 0) optError("{s} expects a numerical value", .{optName(d, short, false)});
                switch (config.parseSigned(v, std.math.maxInt(i32))) {
                    .ok => |n| o.rename_limit = @intCast(n),
                    .err => |e| {
                        if (e == .out_of_range) optError("value {s} for {s} not in range [{d},{d}]", .{ v, optName(d, short, false), std.math.minInt(i32), std.math.maxInt(i32) });
                        optError("{s} expects an integer value with an optional k/m/g suffix", .{optName(d, short, false)});
                    },
                }
            }
        },
        .minimal, .histogram => {
            _ = o.setAlgorithm(d.long);
            o.ignore_driver_algorithm = true;
        },
        .ignore_all_space => o.xdl_opts |= xdiff.XDF_IGNORE_WHITESPACE,
        .ignore_space_change => o.xdl_opts |= xdiff.XDF_IGNORE_WHITESPACE_CHANGE,
        .ignore_space_at_eol => o.xdl_opts |= xdiff.XDF_IGNORE_WHITESPACE_AT_EOL,
        .ignore_cr_at_eol => o.xdl_opts |= xdiff.XDF_IGNORE_CR_AT_EOL,
        .ignore_blank_lines => o.xdl_opts |= xdiff.XDF_IGNORE_BLANK_LINES,
        .ignore_matching_lines => {
            if (unset) optError("{s} isn't available", .{optName(d, short, true)});
            const v = value.?;
            switch (regex.Regex.compile(v, .{ .extended = true, .newline = true })) {
                .ok => |re| o.ignore_regex.append(gpa, re) catch util.oom(),
                .err => optError("invalid regex given to -I: '{s}'", .{v}),
            }
        },
        .indent_heuristic => {
            if (unset) o.xdl_opts &= ~xdiff.XDF_INDENT_HEURISTIC else o.xdl_opts |= xdiff.XDF_INDENT_HEURISTIC;
        },
        .patience => {
            o.anchors.clearRetainingCapacity();
            o.ignore_driver_algorithm = true;
            _ = o.setAlgorithm("patience");
        },
        .diff_algorithm => {
            if (!o.setAlgorithm(value.?))
                optError("option diff-algorithm accepts \"myers\", \"minimal\", \"patience\" and \"histogram\"", .{});
            o.ignore_driver_algorithm = true;
        },
        .anchored => {
            o.xdl_opts = (o.xdl_opts & ~xdiff.XDF_DIFF_ALGORITHM_MASK) | xdiff.XDF_PATIENCE_DIFF;
            o.anchors.append(gpa, value.?) catch util.oom();
        },
        .word_diff => {
            if (value) |v| {
                if (util.eql(v, "plain")) {
                    o.word_diff = .plain;
                } else if (util.eql(v, "color")) {
                    o.use_color = .always;
                    o.word_diff = .color;
                } else if (util.eql(v, "porcelain")) {
                    o.word_diff = .porcelain;
                } else if (util.eql(v, "none")) {
                    o.word_diff = .none;
                } else optError("bad --word-diff argument: {s}", .{v});
            } else if (o.word_diff == .none) o.word_diff = .plain;
        },
        .word_diff_regex => {
            if (o.word_diff == .none) o.word_diff = .plain;
            o.word_regex = value.?;
        },
        .color_words => {
            o.use_color = .always;
            o.word_diff = .color;
            o.word_regex = value;
        },
        .color_moved => {
            if (unset) {
                o.color_moved = .no;
            } else if (value) |v| {
                o.color_moved = parseColorMoved(v) orelse optError("bad --color-moved argument: {s}", .{v});
            } else {
                if (diff_color_moved_default != .no) o.color_moved = diff_color_moved_default;
                if (o.color_moved == .no) o.color_moved = COLOR_MOVED_DEFAULT;
            }
        },
        .color_moved_ws => {
            if (unset) {
                o.color_moved_ws_handling = 0;
            } else {
                const cm = parseColorMovedWs(value.?);
                if (cm & COLOR_MOVED_WS_ERROR != 0) optError("invalid mode '{s}' in --color-moved-ws", .{value.?});
                o.color_moved_ws_handling = cm;
            }
        },
        .relative => {
            o.flags.relative_name = !unset;
            if (value) |v| o.prefix = v;
        },
        .text => o.flags.text = !unset,
        .reverse => o.flags.reverse = !unset,
        .exit_code => o.flags.exit_with_status = !unset,
        .quiet => o.flags.quick = !unset,
        .ext_diff => o.flags.allow_external = !unset,
        .textconv => {
            if (unset) {
                o.flags.allow_textconv = false;
            } else {
                o.flags.allow_textconv = true;
                o.flags.textconv_set_via_cmdline = true;
            }
        },
        .ignore_submodules => {
            o.flags.override_submodule_config = true;
            o.handleIgnoreSubmodulesArg(value orelse "all");
        },
        .submodule => {
            const v = value orelse "log";
            if (util.eql(v, "log")) {
                o.submodule_format = .log;
            } else if (util.eql(v, "short")) {
                o.submodule_format = .short;
            } else if (util.eql(v, "diff")) {
                o.submodule_format = .inline_diff;
            } else optError("failed to parse --submodule option parameter: '{s}'", .{v});
        },
        .ita_invisible => o.ita_invisible_in_index = true,
        .ita_visible => o.ita_invisible_in_index = false,
        .pickaxe_s, .pickaxe_g => {
            if (unset) optError("{s} isn't available", .{optName(d, short, true)});
            o.pickaxe = value;
            o.pickaxe_opts |= if (d.id == .pickaxe_s) PICKAXE_KIND_S else PICKAXE_KIND_G;
            if (value.?.len == 0) {
                if (d.id == .pickaxe_s) optError("-S requires a non-empty argument", .{});
                optError("-G requires a non-empty argument", .{});
            }
        },
        .pickaxe_all => o.pickaxe_opts |= PICKAXE_ALL,
        .pickaxe_regex => o.pickaxe_opts |= PICKAXE_REGEX,
        .orderfile => {
            if (unset) {
                o.orderfile = null;
            } else {
                const v = value.?;
                o.orderfile = if (v.len == 0) null else if (util.eql(v, "-")) v else prefixFilename(v);
            }
        },
        .rotate_to, .skip_to => {
            o.skip_instead_of_rotate = d.id == .skip_to;
            o.rotate_to = value.?;
        },
        .find_object => {
            const v = value.?;
            if (repo_mod.repo_ == null) optError("--find-object requires a git repository", .{});
            const oid = revparse.getOid(v) orelse optError("unable to resolve '{s}'", .{v});
            if (o.objfind == null) {
                const set = gpa.create(hash.OidSet) catch util.oom();
                set.* = .{};
                o.objfind = set;
            }
            o.pickaxe_opts |= PICKAXE_KIND_OBJFIND;
            o.flags.recursive = true;
            o.flags.tree_in_recursive = true;
            o.objfind.?.put(gpa, oid, {}) catch util.oom();
        },
        .diff_filter => {
            const v = value.?;
            for (v) |ch0| {
                var ch = ch0;
                var negate = false;
                if (ch >= 'a' and ch <= 'z') {
                    negate = true;
                    ch = ch - 'a' + 'A';
                }
                const b = filterBit(ch);
                if (b == 0) optError("unknown change class '{c}' in --diff-filter={s}", .{ ch0, v });
                if (negate) o.filter_not |= b else o.filter |= b;
            }
        },
        .max_depth => {
            const v = value.?;
            const n = switch (config.parseSigned(v, std.math.maxInt(i32))) {
                .ok => |n| n,
                .err => optError("invalid value for '{s}': '{s}'", .{ "--max-depth", v }),
            };
            o.max_depth = @intCast(n);
            o.flags.recursive = true;
            o.max_depth_valid = o.max_depth >= 0;
        },
        .output => {
            const path = prefixFilename(value.?);
            const fd = os.openFile(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o666);
            if (fd < 0) util.die("could not open '{s}' for writing: {s}", .{ path, os.lastErr() });
            const f = gpa.create(util.Out) catch util.oom();
            f.* = .{ .fd = fd };
            o.file = f;
            o.close_file = true;
            if (o.use_color != .always) o.use_color = .never;
        },
    }
}

// ---------------------------------------------------------------------------
// filespec / filepair / queue (diffcore.h)

pub const Filespec = struct {
    path: []const u8,
    oid: Oid = hash.zero,
    mode: u32 = 0,
    oid_valid: bool = false,
    data: ?[]const u8 = null,
    size: usize = 0,
    is_binary: i8 = -1,
    driver: ?*userdiff.Driver = null,
    dirty_submodule: u8 = 0,
    rename_used: i32 = 0,
    count: i32 = 1,
    is_stdin: bool = false,
    /// diffcore-delta span hash cache
    cnt_data: ?*anyopaque = null,
};

pub const DIRTY_SUBMODULE_UNTRACKED: u8 = 1;
pub const DIRTY_SUBMODULE_MODIFIED: u8 = 2;

pub const FilePair = struct {
    one: *Filespec,
    two: *Filespec,
    score: u32 = 0,
    status: u8 = 0,
    broken_pair: bool = false,
    renamed_pair: bool = false,
    is_unmerged: bool = false,
    done_skip_stat_unmatch: bool = false,
    skip_stat_unmatch_result: bool = false,
    /// git log -L: post-image line ranges to restrict patch output to
    line_ranges: ?[]const LineRange = null,
    /// synthetic pair carrying only additional_path_headers (remerge-diff)
    header_only: bool = false,
};

/// 0-based [start, end) line range (line-log.h struct range)
pub const LineRange = struct { start: i64, end: i64 };
/// Set by linelog.zig: xdiDiffOutf restricted to post-image line ranges.
pub var line_range_outf: ?*const fn (a: []const u8, b: []const u8, flags: xdiff.Flags, eo: xdiff.EmitOpts, ranges: []const LineRange, ctx: *anyopaque, f: LineFn) bool = null;
var cur_line_ranges: ?[]const LineRange = null;

pub const Queue = std.ArrayList(*FilePair);

/// diff_queued_diff
pub var queue: Queue = .empty;

pub fn fileValid(s: *const Filespec) bool {
    return s.mode != 0;
}
pub fn pairTypeChanged(p: *const FilePair) bool {
    return fileValid(p.one) and fileValid(p.two) and (p.one.mode & os.S_IFMT) != (p.two.mode & os.S_IFMT);
}
pub fn pairBroken(p: *const FilePair) bool {
    return fileValid(p.one) != fileValid(p.two) and p.broken_pair;
}

pub fn allocFilespec(path: []const u8, oid: Oid, oid_valid: bool, mode: u32) *Filespec {
    const s = gpa.create(Filespec) catch util.oom();
    s.* = .{ .path = path };
    fillFilespec(s, oid, oid_valid, mode);
    return s;
}

pub fn allocEmptyFilespec(path: []const u8) *Filespec {
    const s = gpa.create(Filespec) catch util.oom();
    s.* = .{ .path = path };
    return s;
}

pub fn fillFilespec(s: *Filespec, oid: Oid, oid_valid: bool, mode: u32) void {
    if (mode != 0) {
        s.mode = canonMode(mode);
        s.oid = oid;
        s.oid_valid = oid_valid;
    }
}

fn canonMode(mode: u32) u32 {
    if (sIsReg(mode)) return os.S_IFREG | (if (mode & 0o100 != 0) @as(u32, 0o755) else 0o644);
    if (sIsLnk(mode)) return os.S_IFLNK;
    if (sIsDir(mode)) return os.S_IFDIR;
    if (sIsGitlink(mode)) return os.S_IFGITLINK;
    return mode;
}

/// diff_queue(): append a pair to the given queue (or the global one)
pub fn queuePairTo(q: ?*Queue, one: *Filespec, two: *Filespec) *FilePair {
    const p = gpa.create(FilePair) catch util.oom();
    p.* = .{ .one = one, .two = two };
    if (q) |qq| qq.append(gpa, p) catch util.oom();
    return p;
}

pub fn queuePair(one: *Filespec, two: *Filespec) *FilePair {
    return queuePairTo(&queue, one, two);
}

pub fn clearQueue() void {
    queue = .empty;
}

fn prefixMismatch(o: *const DiffOptions, path: []const u8) bool {
    const p = o.prefix orelse return false;
    if (o.prefix_length == 0) return false;
    return !util.startsWith(path, p[0..o.prefix_length]);
}

fn isSubmoduleIgnored(o: *const DiffOptions, path: []const u8) bool {
    _ = path;
    return o.flags.ignore_submodules;
}

/// diff_addremove(): addremove is '+' or '-'
pub fn addRemove(o: *DiffOptions, addremove0: u8, mode: u32, oid: Oid, oid_valid: bool, path: []const u8, dirty_submodule: u8) void {
    if (sIsGitlink(mode) and isSubmoduleIgnored(o, path)) return;
    if (prefixMismatch(o, path)) return;
    var addremove = addremove0;
    if (o.flags.reverse) addremove = if (addremove == '+') '-' else if (addremove == '-') '+' else addremove;
    const one = allocEmptyFilespec(path);
    const two = allocEmptyFilespec(path);
    if (addremove != '+') fillFilespec(one, oid, oid_valid, mode);
    if (addremove != '-') {
        fillFilespec(two, oid, oid_valid, mode);
        two.dirty_submodule = dirty_submodule;
    }
    _ = queuePair(one, two);
    if (!o.flags.diff_from_contents) o.flags.has_changes = true;
}

/// diff_change()
pub fn change(o: *DiffOptions, old_mode0: u32, new_mode0: u32, old_oid0: Oid, new_oid0: Oid, old_oid_valid0: bool, new_oid_valid0: bool, path: []const u8, old_dirty0: u8, new_dirty0: u8) void {
    if (sIsGitlink(old_mode0) and sIsGitlink(new_mode0) and isSubmoduleIgnored(o, path)) return;
    var old_mode = old_mode0;
    var new_mode = new_mode0;
    var old_oid = old_oid0;
    var new_oid = new_oid0;
    var old_valid = old_oid_valid0;
    var new_valid = new_oid_valid0;
    var old_dirty = old_dirty0;
    var new_dirty = new_dirty0;
    if (o.flags.reverse) {
        std.mem.swap(u32, &old_mode, &new_mode);
        std.mem.swap(Oid, &old_oid, &new_oid);
        std.mem.swap(bool, &old_valid, &new_valid);
        std.mem.swap(u8, &old_dirty, &new_dirty);
    }
    if (prefixMismatch(o, path)) return;
    const one = allocEmptyFilespec(path);
    const two = allocEmptyFilespec(path);
    fillFilespec(one, old_oid, old_valid, old_mode);
    fillFilespec(two, new_oid, new_valid, new_mode);
    one.dirty_submodule = old_dirty;
    two.dirty_submodule = new_dirty;
    const p = queuePair(one, two);
    if (o.flags.diff_from_contents) return;
    if (o.flags.quick and o.skip_stat_unmatch != 0 and !checkStatUnmatch(p)) {
        _ = queue.pop();
        return;
    }
    o.flags.has_changes = true;
}

/// diff_unmerge()
pub fn unmerge(o: *DiffOptions, path: []const u8) ?*FilePair {
    if (prefixMismatch(o, path)) return null;
    const one = allocEmptyFilespec(path);
    const two = allocEmptyFilespec(path);
    const p = queuePair(one, two);
    p.is_unmerged = true;
    return p;
}

// ---------------------------------------------------------------------------
// filespec contents

var default_driver = userdiff.Driver{ .name = "default" };

pub fn loadDriver(s: *Filespec) *userdiff.Driver {
    if (s.driver == null) {
        s.driver = userdiff.findByPath(s.path) orelse (userdiff.findByName("default") orelse &default_driver);
    }
    return s.driver.?;
}

/// diff_populate_filespec(); returns 0 on success, -1 on error
pub fn populateFilespec(s: *Filespec, size_only: bool) i32 {
    if (!fileValid(s)) util.die("internal error: asking to populate invalid file.", .{});
    if (sIsDir(s.mode)) return -1;
    if (s.data != null) return 0;
    if (size_only and s.size > 0) return 0;
    if (sIsGitlink(s.mode)) {
        const dirty: []const u8 = if (s.dirty_submodule != 0) "-dirty" else "";
        const d = util.fmt("Subproject commit {s}{s}\n", .{ hash.hexAlloc(s.oid), dirty });
        s.size = d.len;
        if (!size_only) s.data = d;
        return 0;
    }
    if (!s.oid_valid) {
        const st = os.lstatPath(s.path) orelse {
            s.data = "";
            s.size = 0;
            return -1;
        };
        if (st.size == 0) {
            s.data = "";
            s.size = 0;
            return 0;
        }
        if (st.isLnk()) {
            const t = os.readLink(s.path) orelse {
                s.data = "";
                s.size = 0;
                return -1;
            };
            s.data = t;
            s.size = t.len;
            return 0;
        }
        const raw = os.readFile(s.path) orelse {
            s.data = "";
            s.size = 0;
            return -1;
        };
        var d: []const u8 = raw;
        if (repo_mod.repo_ != null and !s.is_stdin) {
            var flags = convert.globalConvFlags();
            if (flags & convert.CONV_EOL_RNDTRP_DIE != 0) flags = (flags & ~convert.CONV_EOL_RNDTRP_DIE) | convert.CONV_EOL_RNDTRP_WARN;
            d = convert.toGitFlags(s.path, raw, flags);
        }
        s.data = d;
        s.size = d.len;
        return 0;
    }
    const obj = repo_mod.repo().odb().read(s.oid) orelse util.die("unable to read {s}", .{hash.hexAlloc(s.oid)});
    s.data = obj.data;
    s.size = obj.data.len;
    return 0;
}

pub fn filespecSize(s: *Filespec) usize {
    if (!fileValid(s)) return 0;
    if (s.data == null) _ = populateFilespec(s, false);
    return s.size;
}

pub fn bufferIsBinary(data: []const u8) bool {
    const n = @min(data.len, 8000);
    return std.mem.indexOfScalar(u8, data[0..n], 0) != null;
}

/// diff_filespec_is_binary()
pub fn isBinary(s: *Filespec) bool {
    if (s.is_binary == -1) {
        const d = loadDriver(s);
        if (d.binary != -1) {
            s.is_binary = d.binary;
        } else {
            if (s.data == null and fileValid(s)) _ = populateFilespec(s, false);
            if (s.is_binary == -1 and s.data != null) s.is_binary = if (bufferIsBinary(s.data.?)) 1 else 0;
            if (s.is_binary == -1) s.is_binary = 0;
        }
    }
    return s.is_binary == 1;
}

/// fill_mmfile()
fn fillMmfile(s: *Filespec) []const u8 {
    if (!fileValid(s)) return "";
    if (populateFilespec(s, false) != 0 and s.data == null) return "";
    return s.data orelse "";
}

/// get_textconv()
pub fn getTextconv(s: *Filespec) ?*userdiff.Driver {
    if (!fileValid(s)) return null;
    const d = loadDriver(s);
    return userdiff.getTextconv(d);
}

const TempFile = struct { name: []const u8, hex: []const u8, mode: []const u8 };
var temp_files: std.ArrayList([]const u8) = .empty;

fn tmpDir() []const u8 {
    if (os.getenv("TMPDIR")) |t| {
        if (t.len > 0) return t;
    }
    return "/tmp";
}

extern "c" fn mkdtemp(template: [*:0]u8) ?[*:0]u8;

/// reuse_worktree_file(): can the checked-out file stand in for this blob?
fn reuseWorktreeFile(name: []const u8, oid: Oid) bool {
    const idx = index_mod.peek() orelse return false;
    const pos = idx.findPos(name) orelse return false;
    const ce = &idx.entries.items[pos];
    if (!std.mem.eql(u8, &ce.oid, &oid) or ce.mode & os.S_IFMT != os.S_IFREG) return false;
    if (ce.assumeValid() or ce.skipWorktree()) return false;
    if (ce.uptodate) return true;
    const st = os.lstatPath(name) orelse return false;
    return idx.matchStat(ce, st, false) == 0;
}

/// prepare_temp_file()
fn prepareTempFile(name: []const u8, s: *Filespec) TempFile {
    if (!fileValid(s)) return .{ .name = "/dev/null", .hex = ".", .mode = "." };
    const mode_s = util.fmt("{o:0>6}", .{s.mode});
    if (!sIsGitlink(s.mode) and !s.is_stdin and (!s.oid_valid or reuseWorktreeFile(name, s.oid))) {
        if (os.lstatPath(name)) |st| {
            if (st.isLnk()) {
                const t = os.readLink(name) orelse util.die("readlink({s})", .{name});
                const hex: []const u8 = if (s.oid_valid) hash.hexAlloc(s.oid) else hash.hexAlloc(odb_mod.hashObject(.blob, t));
                return prepTempBlob(name, t, hex, mode_s);
            }
            const hex: []const u8 = if (s.oid_valid) hash.hexAlloc(s.oid) else hash.zero_hex;
            return .{ .name = name, .hex = hex, .mode = mode_s };
        } else if (!s.oid_valid) {
            return .{ .name = "/dev/null", .hex = ".", .mode = "." };
        }
    }
    _ = populateFilespec(s, false);
    const hex: []const u8 = if (s.oid_valid) hash.hexAlloc(s.oid) else hash.zero_hex;
    var data: []const u8 = s.data orelse "";
    if (repo_mod.repo_ != null and !sIsLnk(s.mode)) data = convert.toWorktree(name, data);
    return prepTempBlob(name, data, hex, mode_s);
}

/// prep_temp_blob(): <tmpdir>/git-blob-XXXXXX/<basename>
fn prepTempBlob(name: []const u8, data: []const u8, hex: []const u8, mode_s: []const u8) TempFile {
    const tmpl_s = util.concat(&.{ tmpDir(), "/git-blob-XXXXXX" });
    const tmpl = gpa.allocSentinel(u8, tmpl_s.len, 0) catch util.oom();
    @memcpy(tmpl[0..tmpl_s.len], tmpl_s);
    if (mkdtemp(tmpl.ptr) == null) util.die("unable to create temp-file", .{});
    const dir: []const u8 = tmpl[0..tmpl.len];
    const path = util.concat(&.{ dir, "/", util.basename(name) });
    os.writeFile(path, data, 0o600) catch util.die("unable to write temp-file", .{});
    temp_files.append(gpa, path) catch util.oom();
    temp_dirs.append(gpa, dir) catch util.oom();
    return .{ .name = path, .hex = hex, .mode = mode_s };
}

var temp_dirs: std.ArrayList([]const u8) = .empty;

fn removeTempFiles() void {
    for (temp_files.items) |p| _ = os.unlink(p);
    for (temp_dirs.items) |p| _ = os.rmdir(p);
    temp_files = .empty;
    temp_dirs = .empty;
}

/// fill_textconv()
pub fn fillTextconv(driver: ?*userdiff.Driver, s: *Filespec) []const u8 {
    const d = driver orelse {
        if (!fileValid(s)) return "";
        _ = populateFilespec(s, false);
        return s.data orelse "";
    };
    const tc = d.textconv orelse {
        _ = populateFilespec(s, false);
        return s.data orelse "";
    };
    const temp = prepareTempFile(s.path, s);
    const r = os.run(&.{ tc, temp.name }, .{ .capture_stdout = true, .use_shell = true });
    removeTempFiles();
    if (r.status != 0) util.die("unable to read files to diff", .{});
    return r.stdout;
}

/// diff_fill_oid_info()
fn fillOidInfo(s: *Filespec) void {
    if (fileValid(s)) {
        if (!s.oid_valid) {
            if (s.is_stdin) {
                s.oid = hash.zero;
                return;
            }
            const st = os.lstatPath(s.path) orelse util.die("stat '{s}': {s}", .{ s.path, os.lastErr() });
            if (sIsGitlink(s.mode)) {
                s.oid = index_mod.gitlinkHead(s.path) orelse hash.zero;
            } else {
                s.oid = index_mod.hashWorktreeFile(s.path, st, s.mode) orelse util.die("cannot hash {s}", .{s.path});
            }
        }
    } else s.oid = hash.zero;
}

// ---------------------------------------------------------------------------
// xdiff glue

pub fn xflagsFrom(o: *const DiffOptions) xdiff.Flags {
    const x = o.xdl_opts;
    const algo: xdiff.Algorithm = if (x & xdiff.XDF_PATIENCE_DIFF != 0) .patience else if (x & xdiff.XDF_HISTOGRAM_DIFF != 0) .histogram else if (x & xdiff.XDF_NEED_MINIMAL != 0) .minimal else .myers;
    return .{
        .algorithm = algo,
        .ignore_ws = x & xdiff.XDF_IGNORE_WHITESPACE != 0,
        .ignore_ws_change = x & xdiff.XDF_IGNORE_WHITESPACE_CHANGE != 0,
        .ignore_ws_eol = x & xdiff.XDF_IGNORE_WHITESPACE_AT_EOL != 0,
        .ignore_cr_eol = x & xdiff.XDF_IGNORE_CR_AT_EOL != 0,
        .ignore_blank_lines = x & xdiff.XDF_IGNORE_BLANK_LINES != 0,
        .indent_heuristic = x & xdiff.XDF_INDENT_HEURISTIC != 0,
        .ignore_regex = o.ignore_regex.items,
        .anchors = o.anchors.items,
    };
}

/// Line consumer receiving git-style lines ("@@ ...", "+...", "-...", " ...",
/// "\\ No newline at end of file\n"), as xdiff_outf's line_fn.
pub const LineFn = *const fn (ctx: *anyopaque, line: []const u8) void;

const OutfCtx = struct {
    ctx: *anyopaque,
    f: LineFn,
    buf: Buf = .empty,
};

fn outfLine(c: ?*anyopaque, kind: xdiff.LineKind, text: []const u8) void {
    const self: *OutfCtx = @ptrCast(@alignCast(c.?));
    if (kind == .hunk_header) {
        self.f(self.ctx, text);
        return;
    }
    self.buf.clearRetainingCapacity();
    const sign: u8 = switch (kind) {
        .context => ' ',
        .del => '-',
        .add => '+',
        .hunk_header => unreachable,
    };
    self.buf.append(gpa, sign) catch util.oom();
    self.buf.appendSlice(gpa, text) catch util.oom();
    const incomplete = text.len == 0 or text[text.len - 1] != '\n';
    if (incomplete) self.buf.append(gpa, '\n') catch util.oom();
    self.f(self.ctx, self.buf.items);
    if (incomplete) self.f(self.ctx, "\\ No newline at end of file\n");
}

/// xdi_diff_outf(): returns false when xdiff failed
pub fn xdiDiffOutf(a0: []const u8, b0: []const u8, flags: xdiff.Flags, eo: xdiff.EmitOpts, ctx: *anyopaque, f: LineFn) bool {
    var a = a0;
    var b = b0;
    if (eo.context == 0 and !eo.func_context) {
        const t = xdiff.trimCommonTail(a, b);
        a = t.a;
        b = t.b;
    }
    var d = xdiff.diff(a, b, flags) catch return false;
    defer d.deinit();
    var oc = OutfCtx{ .ctx = ctx, .f = f };
    xdiff.emitDiff(&d, eo, .{ .ctx = &oc, .line = outfLine });
    return true;
}

const FuncCache = struct { drv: *userdiff.Driver, ff: *xdiff.RegexFindFunc };
var func_cache: std.ArrayList(FuncCache) = .empty;

fn funcnameFor(drv: *userdiff.Driver) ?xdiff.FindFunc {
    const pat = drv.funcname orelse return null;
    for (func_cache.items) |fc| {
        if (fc.drv == drv) return fc.ff.findFunc();
    }
    const ff = xdiff.RegexFindFunc.init(pat, .{ .extended = drv.funcname_extended, .icase = drv.funcname_icase });
    func_cache.append(gpa, .{ .drv = drv, .ff = ff }) catch util.oom();
    return ff.findFunc();
}

// ---------------------------------------------------------------------------
// emission (emit_diff_symbol and friends)

pub fn linePrefix(o: *const DiffOptions) []const u8 {
    if (o.graph != null) return graph_mod.linePrefix(o.graph);
    return o.line_prefix orelse graph_mod.line_prefix;
}

const Sym = enum {
    binary_diff_header,
    binary_diff_header_delta,
    binary_diff_header_literal,
    binary_diff_body,
    binary_diff_footer,
    stats_summary_no_files,
    stats_summary_abbrev,
    stats_summary_inserts_deletes,
    stats_line,
    word_diff,
    stat_sep,
    summary,
    submodule_add,
    submodule_del,
    submodule_untracked,
    submodule_modified,
    submodule_header,
    submodule_error,
    submodule_pipethrough,
    rewrite_diff,
    binary_files,
    header,
    filepair_plus,
    filepair_minus,
    words_porcelain,
    words,
    context,
    context_incomplete,
    plus,
    minus,
    no_lf_eof,
    context_frag_info,
    context_marker,
    separator,
};

fn emitLine0(o: *DiffOptions, set_sign: ?[]const u8, set: ?[]const u8, reverse: bool, reset: []const u8, first: u8, line0: []const u8) void {
    const f = o.out();
    f.write(linePrefix(o));
    var line = line0;
    const has_nl = line.len > 0 and line[line.len - 1] == '\n';
    if (has_nl) line = line[0 .. line.len - 1];
    const has_cr = line.len > 0 and line[line.len - 1] == '\r';
    if (has_cr) line = line[0 .. line.len - 1];
    var needs_reset = false;
    blk: {
        if (line.len == 0 and first == 0) break :blk;
        if (reverse and wantColor(o.use_color)) {
            f.write(color.REVERSE);
            needs_reset = true;
        }
        if (set_sign) |ss| {
            f.write(ss);
            needs_reset = true;
        }
        if (first != 0) f.byte(first);
        if (line.len == 0) break :blk;
        if (set) |s| {
            if (set_sign != null and set_sign.?.ptr != s.ptr) f.write(reset);
            f.write(s);
            needs_reset = true;
        }
        f.write(line);
        needs_reset = true;
    }
    if (needs_reset) f.write(reset);
    if (has_cr) f.byte('\r');
    if (has_nl) f.byte('\n');
}

fn emitLine(o: *DiffOptions, set: []const u8, reset: []const u8, line: []const u8) void {
    emitLine0(o, set, null, false, reset, 0, line);
}

fn emitLineWsMarkup(o: *DiffOptions, set: []const u8, reset: []const u8, sign_index: usize, line: []const u8, ws_rule: u32, blank_at_eof: bool) void {
    emitLineWsMarkupSign(o, null, set, reset, sign_index, line, ws_rule, blank_at_eof);
}

fn emitLineWsMarkupSign(o: *DiffOptions, set_sign: ?[]const u8, set: []const u8, reset: []const u8, sign_index: usize, line: []const u8, ws_rule: u32, blank_at_eof: bool) void {
    var sign = o.output_indicators[sign_index];
    if (diff_suppress_blank_empty and sign_index == OUTPUT_INDICATOR_CONTEXT and line.len == 1 and line[0] == '\n') sign = 0;
    var ws: ?[]const u8 = null;
    if (o.ws_error_highlight & ws_rule != 0) {
        const w = getColor(o, .whitespace);
        if (w.len > 0) ws = w;
    }
    if (ws == null and set_sign == null) {
        emitLine0(o, set, null, false, reset, sign, line);
    } else if (ws == null) {
        emitLine0(o, set_sign, set, true, reset, sign, line);
    } else if (blank_at_eof) {
        emitLine0(o, ws.?, null, false, reset, sign, line);
    } else {
        emitLine0(o, set_sign orelse set, null, set_sign != null, reset, sign, "");
        var b: Buf = .empty;
        wsCheckEmit(line, ws_rule, &b, set, reset, ws.?);
        o.out().write(b.items);
    }
}

fn emitSym(o: *DiffOptions, s: Sym, line: []const u8, flags: u32) void {
    if (o.file == null) return;
    if (o.emitted) |list| {
        list.append(gpa, .{ .s = s, .line = gpa.dupe(u8, line) catch util.oom(), .flags = flags }) catch util.oom();
        return;
    }
    emitSymFromStruct(o, s, line, flags);
}

fn emitSymFromStruct(o: *DiffOptions, s: Sym, line: []const u8, flags: u32) void {
    const f = o.out();
    switch (s) {
        .submodule_header, .submodule_error, .submodule_pipethrough, .stats_summary_inserts_deletes, .summary, .stats_line, .binary_diff_body, .context_frag_info => emitLine(o, "", "", line),
        .context_incomplete => {
            const set = if (flags & WS_INCOMPLETE_LINE != 0 and flags & o.ws_error_highlight != 0) getColor(o, .whitespace) else getColor(o, .context);
            emitLine(o, set, getColor(o, .reset), line);
        },
        .context_marker => emitLine(o, getColor(o, .context), getColor(o, .reset), line),
        .separator => {
            f.write(linePrefix(o));
            f.byte(o.line_termination);
        },
        .context => {
            var set = getColor(o, .context);
            if (o.flags.dual_color_diffed_diffs) {
                const ch: u8 = if (line.len == 0) 0 else line[0];
                if (ch == '+') set = getColor(o, .new) else if (ch == '@') set = getColor(o, .fraginfo) else if (ch == '-') set = getColor(o, .old);
            }
            emitLineWsMarkup(o, set, getColor(o, .reset), OUTPUT_INDICATOR_CONTEXT, line, flags & SYM_CONTENT_WS_MASK, false);
        },
        .plus => {
            const set = switch (flags & (SYM_MOVED_LINE | SYM_MOVED_LINE_ALT | SYM_MOVED_LINE_UNINTERESTING)) {
                SYM_MOVED_LINE | SYM_MOVED_LINE_ALT | SYM_MOVED_LINE_UNINTERESTING => getColor(o, .new_moved_alt_dim),
                SYM_MOVED_LINE | SYM_MOVED_LINE_ALT => getColor(o, .new_moved_alt),
                SYM_MOVED_LINE | SYM_MOVED_LINE_UNINTERESTING => getColor(o, .new_moved_dim),
                SYM_MOVED_LINE => getColor(o, .new_moved),
                else => getColor(o, .new),
            };
            if (o.flags.dual_color_diffed_diffs) {
                const ch: u8 = if (line.len == 0) 0 else line[0];
                const inner = if (ch == '-') getColor(o, .old_bold) else if (ch == '@') getColor(o, .fraginfo) else if (ch == '+') getColor(o, .new_bold) else getColor(o, .context_bold);
                emitLineWsMarkupSign(o, set, inner, getColor(o, .reset), OUTPUT_INDICATOR_NEW, line, 0, flags & SYM_BLANK_LINE_EOF != 0);
            } else emitLineWsMarkup(o, set, getColor(o, .reset), OUTPUT_INDICATOR_NEW, line, flags & SYM_CONTENT_WS_MASK, flags & SYM_BLANK_LINE_EOF != 0);
        },
        .minus => {
            const set = switch (flags & (SYM_MOVED_LINE | SYM_MOVED_LINE_ALT | SYM_MOVED_LINE_UNINTERESTING)) {
                SYM_MOVED_LINE | SYM_MOVED_LINE_ALT | SYM_MOVED_LINE_UNINTERESTING => getColor(o, .old_moved_alt_dim),
                SYM_MOVED_LINE | SYM_MOVED_LINE_ALT => getColor(o, .old_moved_alt),
                SYM_MOVED_LINE | SYM_MOVED_LINE_UNINTERESTING => getColor(o, .old_moved_dim),
                SYM_MOVED_LINE => getColor(o, .old_moved),
                else => getColor(o, .old),
            };
            if (o.flags.dual_color_diffed_diffs) {
                const ch: u8 = if (line.len == 0) 0 else line[0];
                const inner = if (ch == '+') getColor(o, .new_dim) else if (ch == '@') getColor(o, .fraginfo) else if (ch == '-') getColor(o, .old_dim) else getColor(o, .context_dim);
                emitLineWsMarkupSign(o, set, inner, getColor(o, .reset), OUTPUT_INDICATOR_OLD, line, flags & SYM_CONTENT_WS_MASK, false);
            } else emitLineWsMarkup(o, set, getColor(o, .reset), OUTPUT_INDICATOR_OLD, line, flags & SYM_CONTENT_WS_MASK, false);
        },
        .words_porcelain => {
            emitLine(o, getColor(o, .context), getColor(o, .reset), line);
            f.write("~\n");
        },
        .words => emitLine(o, getColor(o, .context), getColor(o, .reset), if (line.len > 0 and line[0] != '\n') line[1..] else line),
        .filepair_plus, .filepair_minus => {
            const tab: []const u8 = if (std.mem.indexOfScalar(u8, line, ' ') != null) "\t" else "";
            f.print("{s}{s}{s} {s}{s}{s}\n", .{ linePrefix(o), getColor(o, .metainfo), if (s == .filepair_plus) "+++" else "---", line, getColor(o, .reset), tab });
        },
        .binary_files, .header => f.write(line),
        .binary_diff_header => f.print("{s}GIT binary patch\n", .{linePrefix(o)}),
        .binary_diff_header_delta => f.print("{s}delta {s}\n", .{ linePrefix(o), line }),
        .binary_diff_header_literal => f.print("{s}literal {s}\n", .{ linePrefix(o), line }),
        .binary_diff_footer => {
            f.write(linePrefix(o));
            f.byte('\n');
        },
        .rewrite_diff => emitLine(o, getColor(o, .fraginfo), getColor(o, .reset), line),
        .submodule_add => emitLine(o, getColor(o, .new), getColor(o, .reset), line),
        .submodule_del => emitLine(o, getColor(o, .old), getColor(o, .reset), line),
        .submodule_untracked => f.print("{s}Submodule {s} contains untracked content\n", .{ linePrefix(o), line }),
        .submodule_modified => f.print("{s}Submodule {s} contains modified content\n", .{ linePrefix(o), line }),
        .stats_summary_no_files => emitLine(o, "", "", " 0 files changed\n"),
        .stats_summary_abbrev => emitLine(o, "", "", " ...\n"),
        .word_diff => f.write(line),
        .stat_sep => f.write(o.stat_sep orelse ""),
        .no_lf_eof => emitLine(o, getColor(o, .context), getColor(o, .reset), line),
    }
}

/// Per-file emission state (struct emit_callback)
const Ecb = struct {
    o: *DiffOptions,
    ws_rule: u32 = 0,
    blank_at_eof_in_preimage: i64 = 0,
    blank_at_eof_in_postimage: i64 = 0,
    lno_in_preimage: i64 = 0,
    lno_in_postimage: i64 = 0,
    label_path: [2]?[]const u8 = .{ null, null },
    header: ?*Buf = null,
    last_line_kind: u8 = 0,
    words: ?*WordsData = null,
};

fn countLines(data: []const u8) i64 {
    var count: i64 = 0;
    var nl_just_seen = false;
    for (data) |ch| {
        if (ch == '\n') {
            count += 1;
            nl_just_seen = true;
        } else nl_just_seen = false;
    }
    if (data.len == 0) return 0;
    if (!nl_just_seen) count += 1;
    return count;
}

fn countTrailingBlank(data: []const u8) i64 {
    var cnt: i64 = 0;
    if (data.len == 0) return 0;
    var ptr: isize = @as(isize, @intCast(data.len)) - 1;
    if (data[@intCast(ptr)] == '\n') ptr -= 1;
    while (0 < ptr) {
        var prev_eol: isize = ptr;
        while (0 <= prev_eol) : (prev_eol -= 1) {
            if (data[@intCast(prev_eol)] == '\n') break;
        }
        const start: usize = @intCast(prev_eol + 1);
        const len: usize = @intCast(ptr - prev_eol);
        if (!wsBlankLine(data[start .. start + len])) break;
        cnt += 1;
        ptr = prev_eol - 1;
    }
    return cnt;
}

fn checkBlankAtEof(a: []const u8, b: []const u8, e: *Ecb) void {
    const l1 = countTrailingBlank(a);
    const l2 = countTrailingBlank(b);
    if (l2 <= l1) {
        e.blank_at_eof_in_preimage = 0;
        e.blank_at_eof_in_postimage = 0;
        return;
    }
    e.blank_at_eof_in_preimage = (countLines(a) - l1) + 1;
    e.blank_at_eof_in_postimage = (countLines(b) - l2) + 1;
}

fn newBlankLineAtEof(e: *Ecb, line: []const u8) bool {
    if (!(e.ws_rule & WS_BLANK_AT_EOF != 0 and e.blank_at_eof_in_preimage != 0 and e.blank_at_eof_in_postimage != 0 and
        e.blank_at_eof_in_preimage <= e.lno_in_preimage and e.blank_at_eof_in_postimage <= e.lno_in_postimage))
        return false;
    return wsBlankLine(line);
}

fn emitAddLine(e: *Ecb, line: []const u8) void {
    var flags = WSEH_NEW | e.ws_rule;
    if (newBlankLineAtEof(e, line)) flags |= SYM_BLANK_LINE_EOF;
    emitSym(e.o, .plus, line, flags);
}

fn emitDelLine(e: *Ecb, line: []const u8) void {
    emitSym(e.o, .minus, line, WSEH_OLD | e.ws_rule);
}

fn emitContextLine(e: *Ecb, line: []const u8) void {
    emitSym(e.o, .context, line, WSEH_CONTEXT | e.ws_rule);
}

fn emitIncompleteLineMarker(e: *Ecb, line: []const u8) void {
    const k: u32 = if (e.last_line_kind == '+') WSEH_NEW else if (e.last_line_kind == '-') WSEH_OLD else WSEH_CONTEXT;
    emitSym(e.o, .context_incomplete, line, k | e.ws_rule);
}

fn emitHunkHeader(e: *Ecb, line: []const u8) void {
    const o = e.o;
    const context = getColor(o, .context);
    const frag = getColor(o, .fraginfo);
    const func = getColor(o, .funcinfo);
    const reset = getColor(o, .reset);
    if (line.len < 10 or !util.startsWith(line, "@@")) {
        emitSym(o, .context_marker, line, 0);
        return;
    }
    const ep0 = std.mem.indexOf(u8, line[2..], "@@") orelse {
        emitSym(o, .context_marker, line, 0);
        return;
    };
    var ep = ep0 + 2 + 2;
    var msg: Buf = .empty;
    if (o.flags.dual_color_diffed_diffs and wantColor(o.use_color)) util.bufAppend(&msg, color.REVERSE);
    util.bufAppend(&msg, frag);
    if (o.flags.suppress_hunk_header_line_count) util.bufAppend(&msg, "@@") else util.bufAppend(&msg, line[0..ep]);
    util.bufAppend(&msg, reset);
    var len = line.len;
    const org_len = len;
    var i: usize = 1;
    while (i < 3) : (i += 1) {
        if (len >= i and (line[len - i] == '\r' or line[len - i] == '\n')) len -= 1;
    }
    const cp = ep;
    while (ep < len) : (ep += 1) {
        if (line[ep] != ' ' and line[ep] != '\t') break;
    }
    if (ep != cp) {
        util.bufAppend(&msg, context);
        util.bufAppend(&msg, line[cp..ep]);
        util.bufAppend(&msg, reset);
    }
    if (ep < len) {
        util.bufAppend(&msg, func);
        util.bufAppend(&msg, line[ep..len]);
        util.bufAppend(&msg, reset);
    }
    util.bufAppend(&msg, line[len..org_len]);
    if (msg.items.len > 0 and msg.items[msg.items.len - 1] != '\n') util.bufByte(&msg, '\n');
    emitSym(o, .context_frag_info, msg.items, 0);
}

fn saneTruncateLine(line: []const u8) usize {
    var pos: usize = 0;
    while (pos < line.len) {
        const save = pos;
        if (pretty.utf8Width(line, &pos) == null) return save;
        if (pos == save) return save;
    }
    return line.len;
}

fn findLno(line: []const u8, e: *Ecb) void {
    e.lno_in_preimage = 0;
    e.lno_in_postimage = 0;
    const p = std.mem.indexOfScalar(u8, line, '-') orelse return;
    e.lno_in_preimage = strtolPrefix(line[p + 1 ..]).v;
    const q = std.mem.indexOfScalarPos(u8, line, p, '+') orelse return;
    e.lno_in_postimage = strtolPrefix(line[q + 1 ..]).v;
}

fn fnOutConsume(ctx: *anyopaque, line0: []const u8) void {
    const e: *Ecb = @ptrCast(@alignCast(ctx));
    const o = e.o;
    o.found_changes = true;
    if (e.header) |h| {
        emitSym(o, .header, h.items, 0);
        h.clearRetainingCapacity();
        e.header = null;
    }
    if (e.label_path[0]) |l0| {
        emitSym(o, .filepair_minus, l0, 0);
        emitSym(o, .filepair_plus, e.label_path[1].?, 0);
        e.label_path = .{ null, null };
    }
    var line = line0;
    if (line[0] == '@') {
        if (e.words) |w| wordsFlush(e, w);
        line = line[0..saneTruncateLine(line)];
        findLno(line, e);
        emitHunkHeader(e, line);
        return;
    }
    if (e.words) |w| {
        if (line[0] == '-') {
            wordsAppend(line, &w.minus);
            return;
        } else if (line[0] == '+') {
            wordsAppend(line, &w.plus);
            return;
        } else if (util.startsWith(line, "\\ ")) {
            return;
        }
        wordsFlush(e, w);
        emitSym(o, if (w.typ == .porcelain) .words_porcelain else .words, line, 0);
        return;
    }
    switch (line[0]) {
        '+' => {
            e.lno_in_postimage += 1;
            emitAddLine(e, line[1..]);
        },
        '-' => {
            e.lno_in_preimage += 1;
            emitDelLine(e, line[1..]);
        },
        ' ' => {
            e.lno_in_postimage += 1;
            e.lno_in_preimage += 1;
            emitContextLine(e, line[1..]);
        },
        '\\' => {
            e.lno_in_preimage += 1;
            emitIncompleteLineMarker(e, line);
        },
        else => {},
    }
    e.last_line_kind = line[0];
}

fn quickConsume(ctx: *anyopaque, line: []const u8) void {
    _ = line;
    const e: *Ecb = @ptrCast(@alignCast(ctx));
    e.o.found_changes = true;
}

/// quote_two(): quote prefix+name as one C-style string if needed
pub fn quoteTwo(a: []const u8, b: []const u8) []const u8 {
    if (util.needsQuote(a) or util.needsQuote(b)) {
        var r: Buf = .empty;
        util.bufByte(&r, '"');
        util.cquoteInto(&r, a);
        util.cquoteInto(&r, b);
        util.bufByte(&r, '"');
        return r.items;
    }
    return util.concat(&.{ a, b });
}

fn addLineCount(b: *Buf, count: i64) void {
    switch (count) {
        0 => util.bufAppend(b, "0,0"),
        1 => util.bufAppend(b, "1"),
        else => util.bufPrint(b, "1,{d}", .{count}),
    }
}

fn emitRewriteLines(e: *Ecb, prefix: u8, data0: []const u8) void {
    var data = data0;
    var had_nl = true;
    while (data.len > 0) {
        const nl = std.mem.indexOfScalar(u8, data, '\n');
        var line: []const u8 = undefined;
        var len: usize = undefined;
        if (nl) |n| {
            len = n + 1;
            line = data[0..len];
            had_nl = true;
        } else {
            len = data.len;
            line = util.concat(&.{ data, "\n" });
            had_nl = false;
        }
        if (prefix != '+') {
            e.lno_in_preimage += 1;
            emitDelLine(e, line);
        } else {
            e.lno_in_postimage += 1;
            emitAddLine(e, line);
        }
        data = data[len..];
    }
    if (!had_nl) {
        e.last_line_kind = prefix;
        emitIncompleteLineMarker(e, "\\ No newline at end of file\n");
    }
}

fn emitRewriteDiff(name_a0: []const u8, name_b0: []const u8, one: *Filespec, two: *Filespec, tc_one: ?*userdiff.Driver, tc_two: ?*userdiff.Driver, o: *DiffOptions) void {
    var a_prefix = o.a_prefix orelse "";
    var b_prefix = o.b_prefix orelse "";
    if (diff_mnemonic_prefix and o.flags.reverse) std.mem.swap([]const u8, &a_prefix, &b_prefix);
    const name_a = if (name_a0.len > 0 and name_a0[0] == '/') name_a0[1..] else name_a0;
    const name_b = if (name_b0.len > 0 and name_b0[0] == '/') name_b0[1..] else name_b0;
    const a_name = quoteTwo(a_prefix, name_a);
    const b_name = quoteTwo(b_prefix, name_b);
    const data_one = fillTextconv(tc_one, one);
    const data_two = fillTextconv(tc_two, two);
    var ws_rule = whitespaceRule(name_b);
    if (fileValid(two) and sIsLnk(two.mode)) ws_rule &= ~WS_INCOMPLETE_LINE;
    var e = Ecb{ .o = o, .ws_rule = ws_rule };
    if (ws_rule & WS_BLANK_AT_EOF != 0) checkBlankAtEof(data_one, data_two, &e);
    e.lno_in_preimage = 1;
    e.lno_in_postimage = 1;
    const lc_a = countLines(data_one);
    const lc_b = countLines(data_two);
    emitSym(o, .filepair_minus, a_name, 0);
    emitSym(o, .filepair_plus, b_name, 0);
    var b: Buf = .empty;
    util.bufAppend(&b, "@@ -");
    if (!o.irreversible_delete) addLineCount(&b, lc_a) else util.bufAppend(&b, "?,?");
    util.bufAppend(&b, " +");
    addLineCount(&b, lc_b);
    util.bufAppend(&b, " @@\n");
    emitSym(o, .rewrite_diff, b.items, 0);
    if (lc_a != 0 and !o.irreversible_delete) emitRewriteLines(&e, '-', data_one);
    if (lc_b != 0) emitRewriteLines(&e, '+', data_two);
}

fn emitOptsFrom(o: *const DiffOptions) xdiff.EmitOpts {
    return .{
        .context = @intCast(@max(o.context, 0)),
        .interhunk = @intCast(@max(o.interhunkcontext, 0)),
        .func_context = o.flags.funccontext,
        .funcnames = true,
    };
}

fn builtinDiff(name_a0: []const u8, name_b0: []const u8, one: *Filespec, two: *Filespec, xfrm_msg: ?[]const u8, must_show_header0: bool, o: *DiffOptions, complete_rewrite: bool) void {
    var must_show_header = must_show_header0;
    const meta = getColor(o, .metainfo);
    const reset = getColor(o, .reset);
    const line_prefix = linePrefix(o);
    o.setMnemonicPrefix("a/", "b/");
    var a_prefix = o.a_prefix.?;
    var b_prefix = o.b_prefix.?;
    if (o.flags.reverse) std.mem.swap([]const u8, &a_prefix, &b_prefix);

    if (o.submodule_format == .log and (one.mode == 0 or sIsGitlink(one.mode)) and (two.mode == 0 or sIsGitlink(two.mode))) {
        showSubmoduleSummary(o, one, two);
        o.found_changes = true;
        return;
    }
    if (o.submodule_format == .inline_diff and (one.mode == 0 or sIsGitlink(one.mode)) and (two.mode == 0 or sIsGitlink(two.mode))) {
        showSubmoduleInlineDiff(o, one, two);
        o.found_changes = true;
        return;
    }

    var tc_one: ?*userdiff.Driver = null;
    var tc_two: ?*userdiff.Driver = null;
    if (o.flags.allow_textconv) {
        tc_one = getTextconv(one);
        tc_two = getTextconv(two);
    }
    const name_a = if (fileValid(one)) name_a0 else name_b0;
    const name_b = if (fileValid(two)) name_b0 else name_a;
    const a_one = quoteTwo(a_prefix, if (name_a.len > 0 and name_a[0] == '/') name_a[1..] else name_a);
    const b_two = quoteTwo(b_prefix, if (name_b.len > 0 and name_b[0] == '/') name_b[1..] else name_b);
    var lbl: [2]?[]const u8 = .{ if (fileValid(one)) a_one else "/dev/null", if (fileValid(two)) b_two else "/dev/null" };
    if (!fileValid(one) and !fileValid(two)) {
        // header-only pairs (remerge-diff): no "new file"/"deleted file"
        lbl = .{ a_one, b_two };
    }
    var header: Buf = .empty;
    util.bufPrint(&header, "{s}{s}diff --git {s} {s}{s}\n", .{ line_prefix, meta, a_one, b_two, reset });
    if (lbl[0].?[0] == '/') {
        util.bufPrint(&header, "{s}{s}new file mode {o:0>6}{s}\n", .{ line_prefix, meta, two.mode, reset });
        if (xfrm_msg) |m| util.bufAppend(&header, m);
        o.found_changes = true;
        must_show_header = true;
    } else if (lbl[1].?[0] == '/') {
        util.bufPrint(&header, "{s}{s}deleted file mode {o:0>6}{s}\n", .{ line_prefix, meta, one.mode, reset });
        if (xfrm_msg) |m| util.bufAppend(&header, m);
        o.found_changes = true;
        must_show_header = true;
    } else {
        if (one.mode != two.mode) {
            util.bufPrint(&header, "{s}{s}old mode {o:0>6}{s}\n", .{ line_prefix, meta, one.mode, reset });
            util.bufPrint(&header, "{s}{s}new mode {o:0>6}{s}\n", .{ line_prefix, meta, two.mode, reset });
            o.found_changes = true;
            must_show_header = true;
        }
        if (xfrm_msg) |m| util.bufAppend(&header, m);
        if ((one.mode ^ two.mode) & os.S_IFMT != 0) return;
        if (complete_rewrite and (tc_one != null or !isBinary(one)) and (tc_two != null or !isBinary(two))) {
            emitSym(o, .header, header.items, 0);
            header.clearRetainingCapacity();
            emitRewriteDiff(name_a, name_b, one, two, tc_one, tc_two, o);
            o.found_changes = true;
            return;
        }
    }

    if (o.irreversible_delete and lbl[1].?[0] == '/') {
        emitSym(o, .header, header.items, 0);
        return;
    } else if (!o.flags.text and ((tc_one == null and isBinary(one)) or (tc_two == null and isBinary(two)))) {
        if (one.data == null and two.data == null and sIsReg(one.mode) and sIsReg(two.mode) and !o.flags.binary) {
            if (hash.eql(one.oid, two.oid)) {
                if (must_show_header) emitSym(o, .header, header.items, 0);
                return;
            }
            emitSym(o, .header, header.items, 0);
            emitSym(o, .binary_files, util.fmt("{s}Binary files {s} and {s} differ\n", .{ linePrefix(o), lbl[0].?, lbl[1].? }), 0);
            o.found_changes = true;
            return;
        }
        const mf1 = fillMmfile(one);
        const mf2 = fillMmfile(two);
        if (std.mem.eql(u8, mf1, mf2)) {
            if (must_show_header) emitSym(o, .header, header.items, 0);
            return;
        }
        emitSym(o, .header, header.items, 0);
        header.clearRetainingCapacity();
        if (o.flags.binary) {
            emitBinaryDiff(o, mf1, mf2);
        } else {
            emitSym(o, .binary_files, util.fmt("{s}Binary files {s} and {s} differ\n", .{ linePrefix(o), lbl[0].?, lbl[1].? }), 0);
        }
        o.found_changes = true;
    } else {
        if (must_show_header) {
            emitSym(o, .header, header.items, 0);
            header.clearRetainingCapacity();
        }
        const mf1 = fillTextconv(tc_one, one);
        const mf2 = fillTextconv(tc_two, two);
        var ws_rule = whitespaceRule(name_b);
        if (fileValid(two) and sIsLnk(two.mode)) ws_rule &= ~WS_INCOMPLETE_LINE;
        var ff = funcnameFor(loadDriver(one));
        if (ff == null) ff = funcnameFor(loadDriver(two));
        if (o.flags.suppress_diff_headers) lbl[0] = null;
        var e = Ecb{ .o = o, .ws_rule = ws_rule, .label_path = lbl };
        if (ws_rule & WS_BLANK_AT_EOF != 0) checkBlankAtEof(mf1, mf2, &e);
        if (header.items.len > 0 and !o.flags.suppress_diff_headers) e.header = &header;
        var eo = emitOptsFrom(o);
        eo.find_func = ff;
        if (os.getenv("GIT_DIFF_OPTS")) |dopts| {
            if (util.skipPrefix(dopts, "--unified=")) |v| {
                eo.context = @intCast(@max(strtoulPrefix(v).v, 0));
            } else if (util.skipPrefix(dopts, "-u")) |v| {
                eo.context = @intCast(@max(strtoulPrefix(v).v, 0));
            }
        }
        if (o.word_diff != .none) initWordsData(&e, o, one, two);
        const flags = xflagsFrom(o);
        if (o.file == null) {
            _ = xdiDiffOutf(mf1, mf2, flags, eo, &e, quickConsume);
        } else if (cur_line_ranges) |lr| {
            if (!line_range_outf.?(mf1, mf2, flags, eo, lr, &e, fnOutConsume)) util.die("unable to generate diff for {s}", .{one.path});
        } else if (!xdiDiffOutf(mf1, mf2, flags, eo, &e, fnOutConsume)) {
            util.die("unable to generate diff for {s}", .{one.path});
        }
        if (e.words) |w| wordsFlush(&e, w);
    }
}

fn selfGit() []const u8 {
    return os.readLink("/proc/self/exe") orelse "git";
}

const submodule_unset_env = [_][]const u8{
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CONFIG",           "GIT_CONFIG_PARAMETERS", "GIT_CONFIG_COUNT",
    "GIT_OBJECT_DIRECTORY",             "GIT_DIR",              "GIT_WORK_TREE",         "GIT_IMPLICIT_WORK_TREE",
    "GIT_GRAFT_FILE",                   "GIT_INDEX_FILE",       "GIT_NO_REPLACE_OBJECTS", "GIT_REPLACE_REF_BASE",
    "GIT_PREFIX",                       "GIT_INTERNAL_SUPER_PREFIX", "GIT_SHALLOW_FILE",  "GIT_COMMON_DIR",
};

/// submodule git dir for a gitlink path (worktree .git, gitfile, or .git/modules/<name>)
fn submoduleGitDir(path: []const u8) ?[]const u8 {
    const dotgit = util.concat(&.{ path, "/.git" });
    if (repo_mod.resolveGitdir(dotgit)) |gd| return gd;
    const r = repo_mod.repo_ orelse return null;
    var name: []const u8 = path;
    if (repo_mod.cfg.get(util.concat(&.{ "submodule.", path, ".url" })) == null) {
        // look up the name in .gitmodules (submodule.<name>.path = <path>)
        if (os.readFile(".gitmodules")) |gm| {
            var cur: ?[]const u8 = null;
            var it = std.mem.splitScalar(u8, gm, '\n');
            while (it.next()) |raw| {
                const ln = std.mem.trim(u8, raw, " \t\r");
                if (ln.len > 2 and ln[0] == '[') {
                    cur = null;
                    if (std.mem.indexOfScalar(u8, ln, '"')) |q1| {
                        if (std.mem.lastIndexOfScalar(u8, ln, '"')) |q2| {
                            if (q2 > q1) cur = ln[q1 + 1 .. q2];
                        }
                    }
                } else if (cur != null and std.ascii.startsWithIgnoreCase(ln, "path")) {
                    const eq = std.mem.indexOfScalar(u8, ln, '=') orelse continue;
                    if (util.eql(std.mem.trim(u8, ln[eq + 1 ..], " \t"), path)) {
                        name = cur.?;
                        break;
                    }
                }
            }
        }
    }
    const gd = r.commonPath(util.concat(&.{ "modules/", name }));
    if (repo_mod.isGitDirectory(gd)) return gd;
    return null;
}

fn subGit(gd: []const u8, args: []const []const u8, capture: bool) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, selfGit()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return os.run(argv.items, .{ .capture_stdout = capture, .no_stderr = true, .no_stdin = true, .unset_env = &submodule_unset_env, .env = &.{.{ "GIT_DIR", gd }} });
}

fn subCommitExists(gd: []const u8, oid: Oid) bool {
    const r = subGit(gd, &.{ "cat-file", "-e", util.concat(&.{ hash.hexAlloc(oid), "^{commit}" }) }, false);
    return r.status == 0 and !r.signaled;
}

const SubHeader = struct { left: bool = false, right: bool = false, gd: ?[]const u8 = null, show: bool = true };

/// show_submodule_header()
fn showSubmoduleHeader(o: *DiffOptions, path: []const u8, one: Oid, two: Oid, dirty: u32) SubHeader {
    var res = SubHeader{};
    if (dirty & DIRTY_SUBMODULE_UNTRACKED != 0) emitSym(o, .submodule_untracked, path, 0);
    if (dirty & DIRTY_SUBMODULE_MODIFIED != 0) emitSym(o, .submodule_modified, path, 0);
    var message: ?[]const u8 = null;
    if (hash.isZero(one)) message = "(new submodule)" else if (hash.isZero(two)) message = "(submodule deleted)";
    var ff = false;
    var fb = false;
    res.gd = submoduleGitDir(path);
    if (res.gd) |gd| {
        res.left = !hash.isZero(one) and subCommitExists(gd, one);
        res.right = !hash.isZero(two) and subCommitExists(gd, two);
        if ((!hash.isZero(one) and !res.left) or (!hash.isZero(two) and !res.right)) message = "(commits not present)";
        if (res.left and res.right) {
            const r = subGit(gd, &.{ "merge-base", hash.hexAlloc(one), hash.hexAlloc(two) }, true);
            if (r.status == 0) {
                const mb = std.mem.trim(u8, r.stdout, " \n");
                if (util.eql(mb, &hash.hex(one))) ff = true else if (util.eql(mb, &hash.hex(two))) fb = true;
            }
        }
        if (hash.eql(one, two)) {
            res.show = false;
            return res;
        }
    } else if (message == null) message = "(commits not present)";
    var b: Buf = .empty;
    util.bufPrint(&b, "Submodule {s} {s}{s}{s}", .{ path, revparse.abbrev(one, 7), if (ff or fb) ".." else "...", revparse.abbrev(two, 7) });
    if (message) |m| util.bufPrint(&b, " {s}\n", .{m}) else util.bufPrint(&b, "{s}:\n", .{if (fb) " (rewind)" else ""});
    emitSym(o, .submodule_header, b.items, 0);
    return res;
}

/// show_submodule_diff_summary()
fn showSubmoduleSummary(o: *DiffOptions, one: *Filespec, two: *Filespec) void {
    const path = if (one.path.len > 0) one.path else two.path;
    const h = showSubmoduleHeader(o, path, one.oid, two.oid, two.dirty_submodule);
    if (!h.show or !h.left or !h.right) return;
    const gd = h.gd orelse return;
    const range = util.concat(&.{ hash.hexAlloc(one.oid), "...", hash.hexAlloc(two.oid) });
    const r = subGit(gd, &.{ "log", "--no-color", "--left-right", "--first-parent", "--format=  %m %s", range }, true);
    if (r.status != 0) {
        emitSym(o, .submodule_error, "(revision walker failed)\n", 0);
        return;
    }
    var it = std.mem.splitScalar(u8, r.stdout, '\n');
    while (it.next()) |ln| {
        if (ln.len < 3) continue;
        const l = util.concat(&.{ ln, "\n" });
        if (ln[2] == '<') emitSym(o, .submodule_del, l, 0) else emitSym(o, .submodule_add, l, 0);
    }
}

/// show_submodule_inline_diff()
fn showSubmoduleInlineDiff(o: *DiffOptions, one: *Filespec, two: *Filespec) void {
    const path = if (one.path.len > 0) one.path else two.path;
    const dirty = two.dirty_submodule;
    const h = showSubmoduleHeader(o, path, one.oid, two.oid, dirty);
    if (!h.show) return;
    if (!(h.left or hash.isZero(one.oid)) or !(h.right or hash.isZero(two.oid))) return;
    const old_hex: []const u8 = if (h.left) hash.hexAlloc(one.oid) else hash.empty_tree_hex;
    const new_hex: []const u8 = if (h.right) hash.hexAlloc(two.oid) else hash.empty_tree_hex;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ selfGit(), "diff", "--submodule=diff" }) catch util.oom();
    argv.append(gpa, if (wantColor(o.use_color)) "--color=always" else "--color=never") catch util.oom();
    if (o.flags.reverse) argv.append(gpa, "-R") catch util.oom();
    argv.append(gpa, util.concat(&.{ "--src-prefix=", o.a_prefix orelse "a/", path, "/" })) catch util.oom();
    argv.append(gpa, util.concat(&.{ "--dst-prefix=", o.b_prefix orelse "b/", path, "/" })) catch util.oom();
    argv.append(gpa, old_hex) catch util.oom();
    if (dirty & DIRTY_SUBMODULE_MODIFIED == 0) argv.append(gpa, new_hex) catch util.oom();
    var cwd: []const u8 = path;
    var env: []const [2][]const u8 = &.{.{ "GIT_DIR", ".git" }};
    if (!os.isDir(path)) {
        cwd = h.gd orelse return;
        env = &.{ .{ "GIT_DIR", "." }, .{ "GIT_WORK_TREE", "." } };
    }
    if (o.file) |f| f.flush();
    const r = os.run(argv.items, .{ .capture_stdout = true, .no_stdin = true, .cwd = cwd, .unset_env = &submodule_unset_env, .env = env });
    var rest: []const u8 = r.stdout;
    while (rest.len > 0) {
        const nl = std.mem.indexOfScalar(u8, rest, '\n');
        const end = if (nl) |k| k + 1 else rest.len;
        emitSym(o, .submodule_pipethrough, rest[0..end], 0);
        rest = rest[end..];
    }
    if (r.status != 0 or r.signaled) emitSym(o, .submodule_error, "(diff failed)\n", 0);
}

// binary patches ("--binary"): literal deflated data, base85 encoded
fn deflateIt(data: []const u8) []u8 {
    return zlib_mod.compress(data, zlibLevel());
}

fn zlibLevel() c_int {
    if (repo_mod.repo_ != null) {
        if (repo_mod.cfg.getInt("core.compression")) |v| return @intCast(v);
        if (repo_mod.cfg.getInt("core.loosecompression")) |v| return @intCast(v);
    }
    return 1;
}

const en85 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~";

pub fn encode85(b: *Buf, data0: []const u8) void {
    var data = data0;
    while (data.len > 0) {
        var acc: u32 = 0;
        var cnt: u5 = 24;
        while (true) {
            const ch: u32 = data[0];
            data = data[1..];
            acc |= ch << cnt;
            if (data.len == 0 or cnt == 0) break;
            cnt -= 8;
        }
        var tmp: [5]u8 = undefined;
        var i: usize = 5;
        while (i > 0) {
            i -= 1;
            tmp[i] = en85[acc % 85];
            acc /= 85;
        }
        b.appendSlice(gpa, &tmp) catch util.oom();
    }
}

fn emitBinaryDiffBody(o: *DiffOptions, one: []const u8, two: []const u8) void {
    _ = one;
    const deflated = deflateIt(two);
    emitSym(o, .binary_diff_header_literal, util.fmt("{d}", .{two.len}), 0);
    var data = deflated;
    while (data.len > 0) {
        const bytes = @min(52, data.len);
        var line: Buf = .empty;
        if (bytes <= 26) util.bufByte(&line, @intCast(bytes + @as(usize, 'A') - 1)) else util.bufByte(&line, @intCast(bytes - 26 + @as(usize, 'a') - 1));
        encode85(&line, data[0..bytes]);
        data = data[bytes..];
        util.bufByte(&line, '\n');
        emitSym(o, .binary_diff_body, line.items, 0);
    }
    emitSym(o, .binary_diff_footer, "", 0);
}

fn emitBinaryDiff(o: *DiffOptions, one: []const u8, two: []const u8) void {
    emitSym(o, .binary_diff_header, "", 0);
    emitBinaryDiffBody(o, one, two);
    emitBinaryDiffBody(o, two, one);
}

fn similarityIndex(p: *const FilePair) u32 {
    return p.score * 100 / MAX_SCORE;
}

pub fn diffAbbrevOid(oid: Oid, abbrev0: i32) []const u8 {
    if (repo_mod.repo_ != null) {
        if (abbrev0 >= 40 or abbrev0 == 0) return hash.hexAlloc(oid);
        return revparse.abbrev(oid, if (abbrev0 < 0) 0 else @intCast(abbrev0));
    }
    const hex = hash.hexAlloc(oid);
    var abbrev = abbrev0;
    if (abbrev < 0) abbrev = 7;
    if (abbrev == 0 or abbrev >= 40) return hex;
    return hex[0..@intCast(abbrev)];
}

fn fillMetainfo(msg: *Buf, name: []const u8, other: ?[]const u8, one: *Filespec, two: *Filespec, o: *DiffOptions, p: *FilePair, must_show_header: *bool, use_color: color.ColorBool) void {
    const set = getColorCb(use_color, .metainfo);
    const reset = getColorCb(use_color, .reset);
    const lp = linePrefix(o);
    must_show_header.* = true;
    switch (p.status) {
        STATUS_COPIED, STATUS_RENAMED => {
            const what: []const u8 = if (p.status == STATUS_COPIED) "copy" else "rename";
            util.bufPrint(msg, "{s}{s}similarity index {d}%", .{ lp, set, similarityIndex(p) });
            util.bufPrint(msg, "{s}\n{s}{s}{s} from ", .{ reset, lp, set, what });
            util.bufAppend(msg, util.cquote(name));
            util.bufPrint(msg, "{s}\n{s}{s}{s} to ", .{ reset, lp, set, what });
            util.bufAppend(msg, util.cquote(other orelse name));
            util.bufPrint(msg, "{s}\n", .{reset});
        },
        STATUS_MODIFIED => {
            if (p.score != 0) {
                util.bufPrint(msg, "{s}{s}dissimilarity index {d}%{s}\n", .{ lp, set, similarityIndex(p), reset });
            } else must_show_header.* = false;
        },
        else => must_show_header.* = false,
    }
    if (addFormattedHeaders(msg, o, lp, set, reset, p.one.path) or
        (!util.eql(p.one.path, p.two.path) and addFormattedHeaders(msg, o, lp, set, reset, p.two.path)))
        must_show_header.* = true;
    if (!hash.eql(one.oid, two.oid)) {
        var abbrev: i32 = if (o.abbrev != 0) o.abbrev else -1;
        if (o.flags.full_index) abbrev = 40;
        if (o.flags.binary) {
            if ((fileValid(one) and isBinary(one)) or (fileValid(two) and isBinary(two))) abbrev = 40;
        }
        util.bufPrint(msg, "{s}{s}index {s}..{s}", .{ lp, set, diffAbbrevOid(one.oid, abbrev), diffAbbrevOid(two.oid, abbrev) });
        if (one.mode == two.mode) util.bufPrint(msg, " {o:0>6}", .{one.mode});
        util.bufPrint(msg, "{s}\n", .{reset});
    }
}

fn runDiffCmd(pgm0: ?[]const u8, name: []const u8, other: ?[]const u8, attr_path: []const u8, one: ?*Filespec, two: ?*Filespec, want_msg: bool, o: *DiffOptions, p: *FilePair) void {
    var pgm = pgm0;
    var trust = external_diff_trust_cfg;
    const complete_rewrite = p.status == STATUS_MODIFIED and p.score != 0;
    var must_show_header = false;
    var drv: ?*userdiff.Driver = null;
    if (o.flags.allow_external or !o.ignore_driver_algorithm) drv = userdiff.findByPath(attr_path);
    if (o.flags.allow_external) {
        if (drv) |d| {
            if (d.external_cmd) |cmd| {
                pgm = cmd;
                trust = d.trust_exit_code;
            }
        }
    }
    var xfrm_msg: ?[]const u8 = null;
    var msg: Buf = .empty;
    if (want_msg) {
        fillMetainfo(&msg, name, other, one.?, two.?, o, p, &must_show_header, if (pgm != null) .never else o.use_color);
        if (msg.items.len > 0) xfrm_msg = msg.items;
    }
    if (pgm) |cmd| {
        runExternalDiff(cmd, trust, name, other, one, two, xfrm_msg, o);
        return;
    }
    if (one != null and two != null) {
        const saved = o.xdl_opts;
        if (!o.ignore_driver_algorithm) {
            if (drv) |d| {
                if (d.algorithm) |a| _ = o.setAlgorithm(a);
            }
        }
        cur_line_ranges = p.line_ranges;
        builtinDiff(name, other orelse name, one.?, two.?, xfrm_msg, must_show_header, o, complete_rewrite);
        cur_line_ranges = null;
        o.xdl_opts = saved;
        if (p.status == STATUS_COPIED or p.status == STATUS_RENAMED) o.found_changes = true;
    } else {
        if (o.file) |f| f.print("* Unmerged path {s}\n", .{name});
        o.found_changes = true;
    }
}

fn runExternalDiff(pgm: []const u8, trust: bool, name: []const u8, other: ?[]const u8, one: ?*Filespec, two: ?*Filespec, xfrm_msg: ?[]const u8, o: *DiffOptions) void {
    if (!trust and o.file == null) {
        o.found_changes = true;
        return;
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, pgm) catch util.oom();
    argv.append(gpa, name) catch util.oom();
    if (one != null and two != null) {
        const t1 = prepareTempFile(name, one.?);
        const t2 = prepareTempFile(other orelse name, two.?);
        for ([_]TempFile{ t1, t2 }) |t| {
            argv.append(gpa, t.name) catch util.oom();
            argv.append(gpa, t.hex) catch util.oom();
            argv.append(gpa, t.mode) catch util.oom();
        }
        if (other) |ot| {
            argv.append(gpa, ot) catch util.oom();
            argv.append(gpa, xfrm_msg orelse "") catch util.oom();
        }
    }
    o.diff_path_counter += 1;
    const counter = util.fmt("{d}", .{o.diff_path_counter});
    const total = util.fmt("{d}", .{queue.items.len});
    util.flushStdout();
    if (o.file) |f| f.flush();
    const r = os.run(argv.items, .{ .use_shell = true, .env = &.{ .{ "GIT_DIFF_PATH_COUNTER", counter }, .{ "GIT_DIFF_PATH_TOTAL", total } } });
    removeTempFiles();
    if (!trust and r.status == 0) {
        o.found_changes = true;
    } else if (trust and r.status == 1) {
        o.found_changes = true;
    } else if (r.status != 0 or r.signaled) {
        util.die("external diff died, stopping at {s}", .{name});
    }
}

fn stripPrefix(prefix_length: usize, name: *[]const u8, other: *?[]const u8) void {
    if (name.len > 0 and name.*[0] != '/') {
        name.* = name.*[@min(prefix_length, name.len)..];
        if (name.len > 0 and name.*[0] == '/') name.* = name.*[1..];
    }
    if (other.*) |ot| {
        if (ot.len > 0 and ot[0] != '/') {
            var x = ot[@min(prefix_length, ot.len)..];
            if (x.len > 0 and x[0] == '/') x = x[1..];
            other.* = x;
        }
    }
}

fn runDiff(p: *FilePair, o: *DiffOptions) void {
    var pgm = externalDiff();
    const one = p.one;
    const two = p.two;
    var name = one.path;
    var other: ?[]const u8 = if (!util.eql(name, two.path)) two.path else null;
    const attr_path = name;
    if (o.prefix_length != 0) stripPrefix(o.prefix_length, &name, &other);
    if (!o.flags.allow_external) pgm = null;
    if (p.is_unmerged) {
        runDiffCmd(pgm, name, null, attr_path, null, null, false, o, p);
        return;
    }
    fillOidInfo(one);
    fillOidInfo(two);
    if (pgm == null and fileValid(one) and fileValid(two) and (one.mode & os.S_IFMT) != (two.mode & os.S_IFMT)) {
        const null1 = allocEmptyFilespec(two.path);
        runDiffCmd(null, name, other, attr_path, one, null1, true, o, p);
        const null2 = allocEmptyFilespec(one.path);
        runDiffCmd(null, name, other, attr_path, null2, two, true, o, p);
    } else runDiffCmd(pgm, name, other, attr_path, one, two, true, o, p);
}

// ---------------------------------------------------------------------------
// diffstat

pub const DiffstatFile = struct {
    print_name: ?[]const u8 = null,
    comments: ?[]const u8 = null,
    from_name: ?[]const u8 = null,
    name: []const u8,
    is_unmerged: bool = false,
    is_binary: bool = false,
    is_renamed: bool = false,
    is_interesting: bool = false,
    added: u64 = 0,
    deleted: u64 = 0,
};

pub const Diffstat = struct {
    files: std.ArrayList(*DiffstatFile) = .empty,
};

/// pprint_rename()
pub fn pprintRename(name: *Buf, a: []const u8, b: []const u8) void {
    if (util.needsQuote(a) or util.needsQuote(b)) {
        util.bufAppend(name, util.cquote(a));
        util.bufAppend(name, " => ");
        util.bufAppend(name, util.cquote(b));
        return;
    }
    var pfx_length: usize = 0;
    var i: usize = 0;
    while (i < a.len and i < b.len and a[i] == b[i]) : (i += 1) {
        if (a[i] == '/') pfx_length = i + 1;
    }
    var sfx_length: usize = 0;
    const pfx_adjust: isize = if (pfx_length != 0) 1 else 0;
    var oi: isize = @intCast(a.len);
    var ni: isize = @intCast(b.len);
    const lo: isize = @as(isize, @intCast(pfx_length)) - pfx_adjust;
    while (lo <= oi and lo <= ni) {
        // a[len] == b[len] == NUL at the start
        const ca: u8 = if (oi == a.len) 0 else a[@intCast(oi)];
        const cb: u8 = if (ni == b.len) 0 else b[@intCast(ni)];
        if (ca != cb) break;
        if (ca == '/') sfx_length = a.len - @as(usize, @intCast(oi));
        oi -= 1;
        ni -= 1;
    }
    const a_mid: usize = if (a.len >= pfx_length + sfx_length) a.len - pfx_length - sfx_length else 0;
    const b_mid: usize = if (b.len >= pfx_length + sfx_length) b.len - pfx_length - sfx_length else 0;
    if (pfx_length + sfx_length != 0) {
        util.bufAppend(name, a[0..pfx_length]);
        util.bufByte(name, '{');
    }
    util.bufAppend(name, a[pfx_length .. pfx_length + a_mid]);
    util.bufAppend(name, " => ");
    util.bufAppend(name, b[pfx_length .. pfx_length + b_mid]);
    if (pfx_length + sfx_length != 0) {
        util.bufByte(name, '}');
        util.bufAppend(name, a[a.len - sfx_length ..]);
    }
}

fn diffstatAdd(ds: *Diffstat, name_a: []const u8, name_b: ?[]const u8) *DiffstatFile {
    const x = gpa.create(DiffstatFile) catch util.oom();
    if (name_b) |nb| {
        x.* = .{ .from_name = name_a, .name = nb, .is_renamed = true };
    } else x.* = .{ .name = name_a };
    ds.files.append(gpa, x) catch util.oom();
    return x;
}

fn diffstatConsume(ctx: *anyopaque, line: []const u8) void {
    const x: *DiffstatFile = @ptrCast(@alignCast(ctx));
    if (line.len == 0) return;
    if (line[0] == '+') x.added += 1 else if (line[0] == '-') x.deleted += 1;
}

fn getCompactSummary(p: *const FilePair, is_renamed: bool) ?[]const u8 {
    if (!is_renamed) {
        if (p.status == STATUS_ADDED) {
            if (sIsLnk(p.two.mode)) return "new +l";
            if (p.two.mode & 0o777 == 0o755) return "new +x";
            return "new";
        } else if (p.status == STATUS_DELETED) return "gone";
    }
    if (sIsLnk(p.one.mode) and !sIsLnk(p.two.mode)) return "mode -l";
    if (!sIsLnk(p.one.mode) and sIsLnk(p.two.mode)) return "mode +l";
    if (p.one.mode & 0o777 == 0o644 and p.two.mode & 0o777 == 0o755) return "mode +x";
    if (p.one.mode & 0o777 == 0o755 and p.two.mode & 0o777 == 0o644) return "mode -x";
    return null;
}

fn builtinDiffstat(name_a: []const u8, name_b: ?[]const u8, one: ?*Filespec, two: ?*Filespec, ds: *Diffstat, o: *DiffOptions, p: *FilePair) void {
    var complete_rewrite = false;
    if (!p.is_unmerged) {
        if (p.status == STATUS_MODIFIED and p.score != 0) complete_rewrite = true;
    }
    const data = diffstatAdd(ds, name_a, name_b);
    data.is_interesting = p.status != STATUS_UNKNOWN;
    if (o.flags.stat_with_summary) data.comments = getCompactSummary(p, data.is_renamed);
    if (one == null or two == null) {
        data.is_unmerged = true;
        return;
    }
    const s1 = one.?;
    const s2 = two.?;
    const may_differ = !(s1.oid_valid and s2.oid_valid and hash.eql(s1.oid, s2.oid));
    if (isBinary(s1) or isBinary(s2)) {
        data.is_binary = true;
        if (may_differ) {
            data.added = filespecSize(s2);
            data.deleted = filespecSize(s1);
        }
    } else if (complete_rewrite) {
        data.deleted = @intCast(countLines(fillMmfile(s1)));
        data.added = @intCast(countLines(fillMmfile(s2)));
    } else if (may_differ) {
        const mf1 = fillMmfile(s1);
        const mf2 = fillMmfile(s2);
        var eo = emitOptsFrom(o);
        eo.no_hunk_header = true;
        eo.func_context = false;
        if (!xdiDiffOutf(mf1, mf2, xflagsFrom(o), eo, data, diffstatConsume))
            util.die("unable to generate diffstat for {s}", .{s1.path});
        if (fileValid(s1) and fileValid(s2)) {
            if (p.status == STATUS_MODIFIED and data.added == 0 and data.deleted == 0 and s1.mode == s2.mode) {
                _ = ds.files.pop();
            }
        }
    }
}

fn runDiffstat(p: *FilePair, o: *DiffOptions, ds: *Diffstat) void {
    if (!o.ignore_driver_algorithm) {
        if (userdiff.findByPath(p.one.path)) |d| {
            if (d.algorithm) |a| _ = o.setAlgorithm(a);
        }
    }
    if (p.is_unmerged) {
        builtinDiffstat(p.one.path, null, null, null, ds, o, p);
        return;
    }
    var name = p.one.path;
    var other: ?[]const u8 = if (!util.eql(name, p.two.path)) p.two.path else null;
    if (o.prefix_length != 0) stripPrefix(o.prefix_length, &name, &other);
    fillOidInfo(p.one);
    fillOidInfo(p.two);
    builtinDiffstat(name, other, p.one, p.two, ds, o, p);
}

fn scaleLinear(it: i64, width: i64, max_change: i64) i64 {
    if (it == 0) return 0;
    return 1 + @divTrunc(it * (width - 1), max_change);
}

fn showGraph(out_b: *Buf, ch: u8, cnt: i64, set: []const u8, reset: []const u8) void {
    if (cnt <= 0) return;
    util.bufAppend(out_b, set);
    var i: i64 = 0;
    while (i < cnt) : (i += 1) util.bufByte(out_b, ch);
    util.bufAppend(out_b, reset);
}

fn fillPrintName(f: *DiffstatFile) void {
    if (f.print_name != null) return;
    var b: Buf = .empty;
    if (f.is_renamed) pprintRename(&b, f.from_name.?, f.name) else util.bufAppend(&b, util.cquote(f.name));
    if (f.comments) |c| util.bufPrint(&b, " ({s})", .{c});
    f.print_name = b.items;
}

fn printStatSummaryInsertsDeletes(o: *DiffOptions, files: i64, insertions: i64, deletions: i64) void {
    if (files == 0) {
        emitSym(o, .stats_summary_no_files, "", 0);
        return;
    }
    var sb: Buf = .empty;
    if (files == 1) util.bufPrint(&sb, " {d} file changed", .{files}) else util.bufPrint(&sb, " {d} files changed", .{files});
    if (insertions != 0 or deletions == 0)
        if (insertions == 1) util.bufPrint(&sb, ", {d} insertion(+)", .{insertions}) else util.bufPrint(&sb, ", {d} insertions(+)", .{insertions});
    if (deletions != 0 or insertions == 0)
        if (deletions == 1) util.bufPrint(&sb, ", {d} deletion(-)", .{deletions}) else util.bufPrint(&sb, ", {d} deletions(-)", .{deletions});
    util.bufByte(&sb, '\n');
    emitSym(o, .stats_summary_inserts_deletes, sb.items, 0);
}

/// print_stat_summary()
pub fn printStatSummary(f: *util.Out, files: i64, insertions: i64, deletions: i64) void {
    var o = DiffOptions.zero();
    o.file = f;
    o.a_prefix = "";
    printStatSummaryInsertsDeletes(&o, files, insertions, deletions);
}

fn decimalWidth(n0: u64) i64 {
    var n = n0;
    var w: i64 = 1;
    while (n >= 10) : (n /= 10) w += 1;
    return w;
}

fn utf8IshWidth(s: []const u8, pos: *usize) i64 {
    const old = pos.*;
    const w = pretty.utf8Width(s, pos);
    if (w == null) {
        pos.* = old + 1;
        return 1;
    }
    if (pos.* == old) pos.* = old + 1;
    return if (w.? < 0) 0 else w.?;
}

fn padSpaces(b: *Buf, n: i64) void {
    var i: i64 = 0;
    while (i < n) : (i += 1) util.bufByte(b, ' ');
}

fn padLeft(b: *Buf, width: i64, s: []const u8) void {
    padSpaces(b, width - @as(i64, @intCast(s.len)));
    util.bufAppend(b, s);
}

fn showStats(data: *Diffstat, o: *DiffOptions) void {
    const files = data.files.items;
    if (files.len == 0) return;
    var count: usize = if (o.stat_count != 0) @intCast(o.stat_count) else files.len;
    const reset = getColor(o, .reset);
    const add_c = getColor(o, .new);
    const del_c = getColor(o, .old);
    var max_change: u64 = 0;
    var max_len: i64 = 0;
    var bin_width: i64 = 0;
    var number_width: i64 = 0;
    var i: usize = 0;
    while (i < count and i < files.len) : (i += 1) {
        const file = files[i];
        const chg = file.added + file.deleted;
        if (!file.is_interesting and chg == 0) {
            count += 1;
            continue;
        }
        fillPrintName(file);
        const len = pretty.utf8Strwidth(file.print_name.?);
        if (max_len < len) max_len = len;
        if (file.is_unmerged) {
            if (bin_width < 8) bin_width = 8;
            continue;
        }
        if (file.is_binary) {
            const w = 14 + decimalWidth(file.added) + decimalWidth(file.deleted);
            if (bin_width < w) bin_width = w;
            number_width = 3;
            continue;
        }
        if (max_change < chg) max_change = chg;
    }
    count = i;
    if (o.revs) |rv| {
        if (rv.fp_stat_width != 0) {
            if (o.stat_width <= 0) o.stat_width = rv.fp_stat_width;
            if (o.stat_graph_width == -1) o.stat_graph_width = 0;
            if (o.stat_name_width == -1) o.stat_name_width = 0;
        }
    }
    const lp = linePrefix(o);
    var width: i64 = undefined;
    if (o.stat_width == -1) {
        width = pretty.termColumns() - pretty.utf8Strnwidth(lp, true);
    } else width = if (o.stat_width != 0) o.stat_width else 80;
    if (decimalWidth(max_change) > number_width) number_width = decimalWidth(max_change);
    if (o.stat_name_width == -1) o.stat_name_width = diff_stat_name_width;
    if (o.stat_graph_width == -1) o.stat_graph_width = diff_stat_graph_width;
    if (width < 16 + 6 + number_width) width = 16 + 6 + number_width;
    const mc: i64 = @intCast(max_change);
    var graph_width: i64 = if (mc + 4 > bin_width) mc else bin_width - 4;
    if (o.stat_graph_width != 0 and o.stat_graph_width < graph_width) graph_width = o.stat_graph_width;
    var name_width: i64 = if (o.stat_name_width > 0 and o.stat_name_width < max_len) o.stat_name_width else max_len;
    if (name_width + number_width + 6 + graph_width > width) {
        if (graph_width > @divTrunc(width * 3, 8) - number_width - 6) {
            graph_width = @divTrunc(width * 3, 8) - number_width - 6;
            if (graph_width < 6) graph_width = 6;
        }
        if (o.stat_graph_width != 0 and graph_width > o.stat_graph_width) graph_width = o.stat_graph_width;
        if (name_width > width - number_width - 6 - graph_width) {
            name_width = width - number_width - 6 - graph_width;
        } else graph_width = width - number_width - 6 - name_width;
    }
    var out_b: Buf = .empty;
    i = 0;
    while (i < count) : (i += 1) {
        const file = files[i];
        var prefix: []const u8 = "";
        const added = file.added;
        const deleted = file.deleted;
        if (!file.is_interesting and added + deleted == 0) continue;
        var name = file.print_name.?;
        var len = name_width;
        var name_len = pretty.utf8Strwidth(name);
        if (name_width < name_len) {
            prefix = "...";
            len -= 3;
            if (len < 0) len = 0;
            var pos: usize = 0;
            while (name_len > len and pos < name.len) name_len -= utf8IshWidth(name, &pos);
            name = name[@min(pos, name.len)..];
            if (std.mem.indexOfScalar(u8, name, '/')) |sl| name = name[sl..];
        }
        var padding = len - pretty.utf8Strwidth(name);
        if (padding < 0) padding = 0;
        if (file.is_binary) {
            util.bufPrint(&out_b, " {s}{s}", .{ prefix, name });
            padSpaces(&out_b, padding);
            util.bufAppend(&out_b, " | ");
            padLeft(&out_b, number_width, "Bin");
            if (added == 0 and deleted == 0) {
                util.bufByte(&out_b, '\n');
                emitSym(o, .stats_line, out_b.items, 0);
                out_b.clearRetainingCapacity();
                continue;
            }
            util.bufPrint(&out_b, " {s}{d}{s} -> {s}{d}{s} bytes\n", .{ del_c, deleted, reset, add_c, added, reset });
            emitSym(o, .stats_line, out_b.items, 0);
            out_b.clearRetainingCapacity();
            continue;
        } else if (file.is_unmerged) {
            util.bufPrint(&out_b, " {s}{s}", .{ prefix, name });
            padSpaces(&out_b, padding);
            util.bufAppend(&out_b, " | ");
            padLeft(&out_b, number_width, "Unmerged\n");
            emitSym(o, .stats_line, out_b.items, 0);
            out_b.clearRetainingCapacity();
            continue;
        }
        var add: i64 = @intCast(added);
        var del: i64 = @intCast(deleted);
        if (graph_width <= mc) {
            var total = scaleLinear(add + del, graph_width, mc);
            if (total < 2 and add != 0 and del != 0) total = 2;
            if (add < del) {
                add = scaleLinear(add, graph_width, mc);
                del = total - add;
            } else {
                del = scaleLinear(del, graph_width, mc);
                add = total - del;
            }
        }
        util.bufPrint(&out_b, " {s}{s}", .{ prefix, name });
        padSpaces(&out_b, padding);
        util.bufAppend(&out_b, " | ");
        padLeft(&out_b, number_width, util.fmt("{d}", .{added + deleted}));
        if (added + deleted != 0) util.bufByte(&out_b, ' ');
        showGraph(&out_b, '+', add, add_c, reset);
        showGraph(&out_b, '-', del, del_c, reset);
        util.bufByte(&out_b, '\n');
        emitSym(o, .stats_line, out_b.items, 0);
        out_b.clearRetainingCapacity();
    }
    var total_files: i64 = @intCast(files.len);
    var adds: i64 = 0;
    var dels: i64 = 0;
    var extra_shown = false;
    for (files, 0..) |file, j| {
        if (file.is_unmerged or (!file.is_interesting and file.added + file.deleted == 0)) {
            total_files -= 1;
            continue;
        }
        if (!file.is_binary) {
            adds += @intCast(file.added);
            dels += @intCast(file.deleted);
        }
        if (j < count) continue;
        if (!extra_shown) emitSym(o, .stats_summary_abbrev, "", 0);
        extra_shown = true;
    }
    printStatSummaryInsertsDeletes(o, total_files, adds, dels);
}

fn showShortstats(data: *Diffstat, o: *DiffOptions) void {
    const files = data.files.items;
    if (files.len == 0) return;
    var total_files: i64 = @intCast(files.len);
    var adds: i64 = 0;
    var dels: i64 = 0;
    for (files) |f| {
        if (f.is_unmerged or (!f.is_interesting and f.added + f.deleted == 0)) {
            total_files -= 1;
        } else if (!f.is_binary) {
            adds += @intCast(f.added);
            dels += @intCast(f.deleted);
        }
    }
    printStatSummaryInsertsDeletes(o, total_files, adds, dels);
}

pub fn writeNameQuoted(f: *util.Out, name: []const u8, term: u8) void {
    if (term != 0) f.write(util.cquote(name)) else f.write(name);
    f.byte(term);
}

fn showNumstat(data: *Diffstat, o: *DiffOptions) void {
    const files = data.files.items;
    if (files.len == 0) return;
    const f = o.out();
    for (files) |file| {
        f.write(linePrefix(o));
        if (file.is_binary) f.write("-\t-\t") else f.print("{d}\t{d}\t", .{ file.added, file.deleted });
        if (o.line_termination != 0) {
            fillPrintName(file);
            if (!file.is_renamed) {
                writeNameQuoted(f, file.name, o.line_termination);
            } else {
                f.write(file.print_name.?);
                f.byte(o.line_termination);
            }
        } else {
            if (file.is_renamed) {
                f.byte(0);
                writeNameQuoted(f, file.from_name.?, 0);
            }
            writeNameQuoted(f, file.name, 0);
        }
    }
}

const DirstatFile = struct { name: []const u8, changed: u64 };
const DirstatDir = struct { files: []DirstatFile, permille: i64, cumulative: bool };

fn gatherDirstat(o: *DiffOptions, dir: *DirstatDir, changed: u64, base: []const u8) u64 {
    var sum_changes: u64 = 0;
    var sources: u32 = 0;
    while (dir.files.len > 0) {
        const f = dir.files[0];
        if (f.name.len < base.len) break;
        if (!util.startsWith(f.name, base)) break;
        var changes: u64 = undefined;
        if (std.mem.indexOfScalarPos(u8, f.name, base.len, '/')) |sl| {
            changes = gatherDirstat(o, dir, changed, f.name[0 .. sl + 1]);
            sources += 1;
        } else {
            changes = f.changed;
            dir.files = dir.files[1..];
            sources += 2;
        }
        sum_changes += changes;
    }
    if (base.len > 0 and sources != 1) {
        if (sum_changes != 0) {
            const permille: i64 = @intCast(sum_changes * 1000 / changed);
            if (permille >= dir.permille) {
                o.out().print("{s}{d: >4}.{d}% {s}\n", .{ linePrefix(o), @as(u64, @intCast(@divTrunc(permille, 10))), @as(u64, @intCast(@mod(permille, 10))), base });
                if (!dir.cumulative) return 0;
            }
        }
    }
    return sum_changes;
}

fn dirstatLess(_: void, a: DirstatFile, b: DirstatFile) bool {
    return std.mem.order(u8, a.name, b.name) == .lt;
}

fn concludeDirstat(o: *DiffOptions, files: []DirstatFile, changed: u64) void {
    if (changed == 0) return;
    std.mem.sort(DirstatFile, files, {}, dirstatLess);
    var dir = DirstatDir{ .files = files, .permille = o.dirstat_permille, .cumulative = o.flags.dirstat_cumulative };
    _ = gatherDirstat(o, &dir, changed, "");
}

fn showDirstat(o: *DiffOptions) void {
    var files: std.ArrayList(DirstatFile) = .empty;
    var changed: u64 = 0;
    for (queue.items) |p| {
        const name = if (p.two.path.len > 0) p.two.path else p.one.path;
        var damage: u64 = 0;
        if (p.one.oid_valid and p.two.oid_valid and hash.eql(p.one.oid, p.two.oid)) {
            damage = 0;
        } else if (o.flags.dirstat_by_file) {
            damage = 1;
        } else {
            var copied: u64 = 0;
            var added: u64 = 0;
            if (fileValid(p.one) and fileValid(p.two)) {
                _ = populateFilespec(p.one, false);
                _ = populateFilespec(p.two, false);
                const r = diffcore.countChanges(p.one, p.two);
                copied = r.src_copied;
                added = r.literal_added;
            } else if (fileValid(p.one)) {
                _ = populateFilespec(p.one, false);
            } else if (fileValid(p.two)) {
                _ = populateFilespec(p.two, false);
                added = p.two.size;
            } else continue;
            damage = (p.one.size -| copied) + added;
            if (damage == 0) damage = 1;
        }
        files.append(gpa, .{ .name = name, .changed = damage }) catch util.oom();
        changed += damage;
    }
    concludeDirstat(o, files.items, changed);
}

fn showDirstatByLine(data: *Diffstat, o: *DiffOptions) void {
    if (data.files.items.len == 0) return;
    var files: std.ArrayList(DirstatFile) = .empty;
    var changed: u64 = 0;
    for (data.files.items) |f| {
        var damage = f.added + f.deleted;
        if (f.is_binary) damage = (damage + 63) / 64;
        files.append(gpa, .{ .name = f.name, .changed = damage }) catch util.oom();
        changed += damage;
    }
    concludeDirstat(o, files.items, changed);
}

// ---------------------------------------------------------------------------
// --check

const CheckdiffData = struct {
    o: *DiffOptions,
    filename: []const u8,
    lineno: i64 = 0,
    ws_rule: u32 = 0,
    status: u32 = 0,
    conflict_marker_size: usize = 7,
    last_line_kind: u8 = 0,
};

fn isConflictMarkerLine(line: []const u8, marker_size: usize) bool {
    if (line.len < marker_size + 1) return false;
    const first = line[0];
    switch (first) {
        '=', '>', '<', '|' => {},
        else => return false,
    }
    var cnt: usize = 1;
    while (cnt < marker_size) : (cnt += 1) {
        if (line[cnt] != first) return false;
    }
    return isSpace(line[marker_size]);
}

fn checkdiffHunk(ctx: ?*anyopaque, h: xdiff.HunkInfo) void {
    const d: *CheckdiffData = @ptrCast(@alignCast(ctx.?));
    d.lineno = @as(i64, @intCast(h.new_begin)) - 1;
}

fn checkdiffLine(ctx: ?*anyopaque, kind: xdiff.LineKind, text: []const u8) void {
    const d: *CheckdiffData = @ptrCast(@alignCast(ctx.?));
    var b: Buf = .empty;
    const sign: u8 = switch (kind) {
        .add => '+',
        .del => '-',
        .context => ' ',
        .hunk_header => return,
    };
    util.bufByte(&b, sign);
    util.bufAppend(&b, text);
    const incomplete = text.len == 0 or text[text.len - 1] != '\n';
    if (incomplete) util.bufByte(&b, '\n');
    checkdiffConsume(d, b.items);
    if (incomplete) checkdiffConsume(d, "\\ No newline at end of file\n");
}

fn checkdiffConsume(d: *CheckdiffData, line: []const u8) void {
    const o = d.o;
    const ws = getColor(o, .whitespace);
    const reset = getColor(o, .reset);
    const set = getColor(o, .new);
    const lp = linePrefix(o);
    const f = o.out();
    const last = d.last_line_kind;
    d.last_line_kind = line[0];
    if (line[0] == '+') {
        d.lineno += 1;
        if (isConflictMarkerLine(line[1..], d.conflict_marker_size)) {
            d.status |= 1;
            f.print("{s}{s}:{d}: leftover conflict marker\n", .{ lp, d.filename, d.lineno });
        }
        const bad = wsCheck(line[1..], d.ws_rule);
        if (bad == 0) return;
        d.status |= bad;
        f.print("{s}{s}:{d}: {s}.\n", .{ lp, d.filename, d.lineno, wsErrorString(bad) });
        emitLine0(o, set, null, false, reset, 0, line[0..1]);
        var eb: Buf = .empty;
        wsCheckEmit(line[1..], d.ws_rule, &eb, set, reset, ws);
        f.write(eb.items);
    } else if (line[0] == ' ') {
        d.lineno += 1;
    } else if (line[0] == '\\') {
        if (d.ws_rule & WS_INCOMPLETE_LINE != 0 and last == '+') {
            d.status |= WS_INCOMPLETE_LINE;
            f.print("{s}{s}:{d}: {s}.\n", .{ lp, d.filename, d.lineno, wsErrorString(WS_INCOMPLETE_LINE) });
        }
    }
}

fn markerSizeFor(path: []const u8) usize {
    if (repo_mod.repo_ == null) return 7;
    switch (attr.get(path, "conflict-marker-size")) {
        .value => |v| {
            const n = std.fmt.parseInt(i64, v, 10) catch return 7;
            if (n > 0) return @intCast(n);
            return 7;
        },
        else => return 7,
    }
}

fn builtinCheckdiff(name_a: []const u8, name_b: ?[]const u8, attr_path: []const u8, one: *Filespec, two: *Filespec, o: *DiffOptions) void {
    var d = CheckdiffData{ .o = o, .filename = name_b orelse name_a };
    d.ws_rule = whitespaceRule(attr_path);
    d.conflict_marker_size = markerSizeFor(attr_path);
    if (fileValid(two) and sIsLnk(two.mode)) d.ws_rule &= ~WS_INCOMPLETE_LINE;
    const mf1 = fillMmfile(one);
    const mf2 = fillMmfile(two);
    if (isBinary(two)) return;
    var dd = xdiff.diff(mf1, mf2, .{}) catch util.die("unable to generate checkdiff for {s}", .{one.path});
    defer dd.deinit();
    xdiff.emitDiff(&dd, .{ .context = 1, .interhunk = 0 }, .{ .ctx = &d, .hunk = checkdiffHunk, .line = checkdiffLine });
    if (d.ws_rule & WS_BLANK_AT_EOF != 0) {
        var e = Ecb{ .o = o, .ws_rule = d.ws_rule };
        checkBlankAtEof(mf1, mf2, &e);
        if (e.blank_at_eof_in_postimage != 0) {
            o.out().print("{s}:{d}: {s}.\n", .{ d.filename, e.blank_at_eof_in_postimage, wsErrorString(WS_BLANK_AT_EOF) });
            d.status = 1;
        }
    }
    if (d.status != 0) o.flags.check_failed = true;
}

fn runCheckdiff(p: *FilePair, o: *DiffOptions) void {
    if (p.is_unmerged) return;
    var name = p.one.path;
    var other: ?[]const u8 = if (!util.eql(name, p.two.path)) p.two.path else null;
    const attr_path = other orelse name;
    if (o.prefix_length != 0) stripPrefix(o.prefix_length, &name, &other);
    fillOidInfo(p.one);
    fillOidInfo(p.two);
    builtinCheckdiff(name, other, attr_path, p.one, p.two, o);
}

// ---------------------------------------------------------------------------
// flush

fn printSha1Ellipsis() bool {
    const v = os.getenv("GIT_PRINT_SHA1_ELLIPSIS") orelse return false;
    return util.eql(v, "yes");
}

/// diff_aligned_abbrev()
pub fn alignedAbbrev(oid: Oid, len: i32) []const u8 {
    if (len == 40) return hash.hexAlloc(oid);
    const ab = diffAbbrevOid(oid, len);
    if (!printSha1Ellipsis()) return ab;
    const abblen: i32 = @intCast(ab.len);
    if (abblen < 37) {
        if (len < abblen and abblen <= len + 2) {
            return util.concat(&.{ ab, ".."[0..@intCast(len + 3 - abblen)] });
        }
        return util.concat(&.{ ab, "..." });
    }
    return hash.hexAlloc(oid);
}

fn flushRaw(p: *FilePair, o: *DiffOptions) void {
    const f = o.out();
    const lt = o.line_termination;
    const inter: u8 = if (lt != 0) '\t' else 0;
    f.write(linePrefix(o));
    if (o.output_format & FMT_NAME_STATUS == 0) {
        f.print(":{o:0>6} {o:0>6} {s} ", .{ p.one.mode, p.two.mode, alignedAbbrev(p.one.oid, o.abbrev) });
        f.print("{s} ", .{alignedAbbrev(p.two.oid, o.abbrev)});
    }
    if (p.score != 0) {
        f.print("{c}{d:0>3}", .{ p.status, similarityIndex(p) });
        f.byte(inter);
    } else {
        f.byte(p.status);
        f.byte(inter);
    }
    if (p.status == STATUS_COPIED or p.status == STATUS_RENAMED) {
        var a = p.one.path;
        var b: ?[]const u8 = p.two.path;
        stripPrefix(o.prefix_length, &a, &b);
        writeNameQuoted(f, a, inter);
        writeNameQuoted(f, b.?, lt);
    } else {
        var a = if (p.one.mode != 0) p.one.path else p.two.path;
        var b: ?[]const u8 = null;
        stripPrefix(o.prefix_length, &a, &b);
        writeNameQuoted(f, a, lt);
    }
}

/// diff_unmodified_pair()
pub fn unmodifiedPair(p: *const FilePair) bool {
    const one = p.one;
    const two = p.two;
    if (p.is_unmerged) return false;
    if (fileValid(one) != fileValid(two) or one.mode != two.mode or !util.eql(one.path, two.path)) return false;
    if (one.oid_valid and two.oid_valid and hash.eql(one.oid, two.oid) and one.dirty_submodule == 0 and two.dirty_submodule == 0) return true;
    if (!one.oid_valid and !two.oid_valid) return true;
    return false;
}

fn isTreePair(p: *const FilePair) bool {
    return (fileValid(p.one) and sIsDir(p.one.mode)) or (fileValid(p.two) and sIsDir(p.two.mode));
}

fn flushPatch(p: *FilePair, o: *DiffOptions) void {
    if (unmodifiedPair(p)) return;
    if (isTreePair(p)) return;
    runDiff(p, o);
}

fn flushPatchQuietly(p: *FilePair, o: *DiffOptions) bool {
    const saved_file = o.file;
    const saved = o.found_changes;
    o.file = null;
    o.found_changes = false;
    flushPatch(p, o);
    const ret = o.found_changes;
    o.file = saved_file;
    o.found_changes = o.found_changes or saved;
    return ret;
}

fn flushStat(p: *FilePair, o: *DiffOptions, ds: *Diffstat) void {
    if (unmodifiedPair(p)) return;
    if (isTreePair(p)) return;
    runDiffstat(p, o, ds);
}

fn flushCheckdiff(p: *FilePair, o: *DiffOptions) void {
    if (unmodifiedPair(p)) return;
    if (isTreePair(p)) return;
    runCheckdiff(p, o);
}

fn checkPairStatus(p: *const FilePair) bool {
    return switch (p.status) {
        STATUS_UNKNOWN => false,
        0 => util.die("internal error in diff-resolve-rename-copy", .{}),
        else => true,
    };
}

fn flushOnePair(p: *FilePair, o: *DiffOptions) void {
    const fmt_ = o.output_format;
    if (fmt_ & FMT_CHECKDIFF != 0) {
        flushCheckdiff(p, o);
    } else if (fmt_ & (FMT_RAW | FMT_NAME_STATUS) != 0) {
        flushRaw(p, o);
    } else if (fmt_ & FMT_NAME != 0) {
        var a = p.two.path;
        var b: ?[]const u8 = null;
        stripPrefix(o.prefix_length, &a, &b);
        const f = o.out();
        f.write(linePrefix(o));
        writeNameQuoted(f, a, o.line_termination);
    }
    o.found_changes = true;
}

fn showFileModeName(o: *DiffOptions, newdelete: []const u8, fs: *Filespec) void {
    var sb: Buf = .empty;
    if (fs.mode != 0) util.bufPrint(&sb, " {s} mode {o:0>6} ", .{ newdelete, fs.mode }) else util.bufPrint(&sb, " {s} ", .{newdelete});
    util.bufAppend(&sb, util.cquote(fs.path));
    util.bufByte(&sb, '\n');
    emitSym(o, .summary, sb.items, 0);
}

fn showModeChange(o: *DiffOptions, p: *FilePair, show_name: bool) void {
    if (p.one.mode != 0 and p.two.mode != 0 and p.one.mode != p.two.mode) {
        var sb: Buf = .empty;
        util.bufPrint(&sb, " mode change {o:0>6} => {o:0>6}", .{ p.one.mode, p.two.mode });
        if (show_name) {
            util.bufByte(&sb, ' ');
            util.bufAppend(&sb, util.cquote(p.two.path));
        }
        util.bufByte(&sb, '\n');
        emitSym(o, .summary, sb.items, 0);
    }
}

fn showRenameCopy(o: *DiffOptions, what: []const u8, p: *FilePair) void {
    var names: Buf = .empty;
    pprintRename(&names, p.one.path, p.two.path);
    emitSym(o, .summary, util.fmt(" {s} {s} ({d}%)\n", .{ what, names.items, similarityIndex(p) }), 0);
    showModeChange(o, p, false);
}

fn diffSummary(o: *DiffOptions, p: *FilePair) void {
    switch (p.status) {
        STATUS_DELETED => showFileModeName(o, "delete", p.one),
        STATUS_ADDED => showFileModeName(o, "create", p.two),
        STATUS_COPIED => showRenameCopy(o, "copy", p),
        STATUS_RENAMED => showRenameCopy(o, "rename", p),
        else => {
            if (p.score != 0) {
                emitSym(o, .summary, util.fmt(" rewrite {s} ({d}%)\n", .{ util.cquote(p.two.path), similarityIndex(p) }), 0);
            }
            showModeChange(o, p, p.score == 0);
        },
    }
}

fn isSummaryEmpty() bool {
    for (queue.items) |p| {
        switch (p.status) {
            STATUS_DELETED, STATUS_ADDED, STATUS_COPIED, STATUS_RENAMED => return false,
            else => {
                if (p.score != 0) return false;
                if (p.one.mode != 0 and p.two.mode != 0 and p.one.mode != p.two.mode) return false;
            },
        }
    }
    return true;
}

pub fn computeDiffstat(o: *DiffOptions, ds: *Diffstat) void {
    for (queue.items) |p| {
        if (checkPairStatus(p)) flushStat(p, o, ds);
    }
    o.found_changes = ds.files.items.len > 0;
}

/// diff_flush()
pub fn flush(o: *DiffOptions) void {
    if (o.prefix_from_cfg) {
        if (o.revs) |rv| {
            // format-patch ignores diff.noprefix
            if (rv.fp_stat_width != 0) {
                o.setDefaultPrefix();
                o.prefix_from_cfg = false;
            }
        }
    }
    // callers that skipped diffcore_std(): statuses are not resolved yet
    if (queue.items.len > 0 and queue.items[0].status == 0) diffcoreStd(o);
    const fmt_ = o.output_format;
    var separator = false;
    if (queue.items.len > 0) {
        if (fmt_ & (FMT_RAW | FMT_NAME | FMT_NAME_STATUS | FMT_CHECKDIFF) != 0) {
            for (queue.items) |p| {
                if (!checkPairStatus(p)) continue;
                if (o.flags.diff_from_contents and !flushPatchQuietly(p, o)) continue;
                flushOnePair(p, o);
            }
            separator = true;
        }
        const dirstat_by_line = fmt_ & FMT_DIRSTAT != 0 and o.flags.dirstat_by_line;
        if (fmt_ & (FMT_DIFFSTAT | FMT_SHORTSTAT | FMT_NUMSTAT) != 0 or dirstat_by_line) {
            var ds = Diffstat{};
            computeDiffstat(o, &ds);
            if (fmt_ & FMT_NUMSTAT != 0) showNumstat(&ds, o);
            if (fmt_ & FMT_DIFFSTAT != 0) showStats(&ds, o);
            if (fmt_ & FMT_SHORTSTAT != 0) showShortstats(&ds, o);
            if (dirstat_by_line) showDirstatByLine(&ds, o);
            separator = true;
        }
        if (fmt_ & FMT_DIRSTAT != 0 and !dirstat_by_line) showDirstat(o);
        if (fmt_ & FMT_SUMMARY != 0 and !isSummaryEmpty()) {
            for (queue.items) |p| diffSummary(o, p);
            separator = true;
        }
        if (fmt_ & FMT_PATCH != 0) {
            if (separator) {
                emitSym(o, .separator, "", 0);
                if (o.stat_sep != null) emitSym(o, .stat_sep, "", 0);
            }
            var esm: std.ArrayList(Emitted) = .empty;
            if (o.color_moved != .no and wantColor(o.use_color)) o.emitted = &esm;
            for (queue.items) |p| {
                if (checkPairStatus(p)) flushPatch(p, o);
            }
            flushEmittedSymbols(o);
        }
        if (fmt_ & FMT_NO_OUTPUT != 0 and o.flags.exit_with_status and o.flags.diff_from_contents) {
            for (queue.items) |p| {
                if (checkPairStatus(p)) _ = flushPatchQuietly(p, o);
                if (o.found_changes) break;
            }
        }
    }
    clearQueue();
    if (o.flags.diff_from_contents) o.flags.has_changes = o.found_changes;
    if (o.close_file) {
        if (o.file) |f| f.flush();
    }
}

// ---------------------------------------------------------------------------
// diffcore_std

fn filterBitTst(status: u8, o: *const DiffOptions) bool {
    return o.filter & filterBit(status) != 0;
}

fn matchFilter(o: *const DiffOptions, p: *const FilePair) bool {
    return (p.status == STATUS_MODIFIED and ((p.score != 0 and filterBitTst(STATUS_FILTER_BROKEN, o)) or
        (p.score == 0 and filterBitTst(STATUS_MODIFIED, o)))) or
        (p.status != STATUS_MODIFIED and filterBitTst(p.status, o));
}

fn applyFilter(o: *DiffOptions) void {
    if (o.filter == 0) return;
    if (filterBitTst(STATUS_FILTER_AON, o)) {
        for (queue.items) |p| {
            if (matchFilter(o, p)) return;
        }
        queue = .empty;
        return;
    }
    var outq: Queue = .empty;
    for (queue.items) |p| {
        if (matchFilter(o, p)) outq.append(gpa, p) catch util.oom();
    }
    queue = outq;
}

fn filespecIsIdentical(one: *Filespec, two: *Filespec) bool {
    if (sIsGitlink(one.mode)) return false;
    if (populateFilespec(one, false) != 0) return false;
    if (populateFilespec(two, false) != 0) return false;
    return std.mem.eql(u8, one.data.?, two.data.?);
}

/// diff_filespec_check_stat_unmatch(): true = real change
fn checkStatUnmatch(p: *FilePair) bool {
    if (p.done_skip_stat_unmatch) return p.skip_stat_unmatch_result;
    p.done_skip_stat_unmatch = true;
    p.skip_stat_unmatch_result = false;
    if (!fileValid(p.one) or !fileValid(p.two) or (p.one.oid_valid and p.two.oid_valid) or p.one.mode != p.two.mode or
        populateFilespec(p.one, true) != 0 or populateFilespec(p.two, true) != 0 or
        p.one.size != p.two.size or !filespecIsIdentical(p.one, p.two))
        p.skip_stat_unmatch_result = true;
    return p.skip_stat_unmatch_result;
}

fn skipStatUnmatch(o: *DiffOptions) void {
    var outq: Queue = .empty;
    for (queue.items) |p| {
        if (checkStatUnmatch(p)) {
            outq.append(gpa, p) catch util.oom();
        } else if (!o.flags.no_index) o.skip_stat_unmatch += 1;
    }
    queue = outq;
}

fn resolveRenameCopy() void {
    for (queue.items) |p| {
        if (p.header_only) {
            p.status = STATUS_MODIFIED;
            continue;
        }
        p.status = 0;
        if (p.is_unmerged) {
            p.status = STATUS_UNMERGED;
        } else if (!fileValid(p.one)) {
            p.status = STATUS_ADDED;
        } else if (!fileValid(p.two)) {
            p.status = STATUS_DELETED;
        } else if (pairTypeChanged(p)) {
            p.status = STATUS_TYPE_CHANGED;
        } else if (p.renamed_pair) {
            if (util.eql(p.one.path, p.two.path)) {
                p.status = STATUS_MODIFIED;
            } else {
                p.one.rename_used -= 1;
                p.status = if (p.one.rename_used > 0) STATUS_COPIED else STATUS_RENAMED;
            }
        } else if (!hash.eql(p.one.oid, p.two.oid) or p.one.mode != p.two.mode or p.one.dirty_submodule != 0 or
            p.two.dirty_submodule != 0 or hash.eql(p.one.oid, hash.zero))
        {
            p.status = STATUS_MODIFIED;
        } else {
            util.err("feeding unmodified {s} to diffcore", .{p.one.path});
            p.status = STATUS_UNKNOWN;
        }
    }
}

/// diffcore_std()
pub fn diffcoreStd(o: *DiffOptions) void {
    if (o.skip_stat_unmatch != 0) skipStatUnmatch(o);
    if (!o.found_follow) {
        if (o.break_opt != -1) diffcore.breakPairs(o, o.break_opt);
        if (o.detect_rename != 0) diffcore.rename(o);
        if (o.break_opt != -1) diffcore.mergeBroken();
    }
    if (o.pickaxe_opts & PICKAXE_KINDS_MASK != 0) diffcore.pickaxe(o);
    if (o.orderfile) |of| diffcore.order(of);
    if (o.rotate_to != null) diffcore.rotate(o);
    if (!o.found_follow and !o.skip_resolving_statuses) resolveRenameCopy();
    applyFilter(o);
    o.flags.has_changes = queue.items.len > 0 and !o.flags.diff_from_contents;
    o.found_follow = false;
}

/// diffcore_fix_diff_index(): sort queue by name
pub fn fixDiffIndex() void {
    std.mem.sort(*FilePair, queue.items, {}, struct {
        fn lt(_: void, a: *FilePair, b: *FilePair) bool {
            return std.mem.order(u8, a.one.path, b.one.path) == .lt;
        }
    }.lt);
}

pub fn hasChanges(o: *const DiffOptions) bool {
    return o.flags.has_changes;
}

pub fn canQuitEarly(o: *const DiffOptions) bool {
    return o.flags.quick and o.filter == 0 and o.flags.has_changes;
}

pub fn queueIsEmpty() bool {
    for (queue.items) |p| {
        if (!unmodifiedPair(p)) return false;
    }
    return true;
}

/// diff_warn_rename_limit()
pub fn warnRenameLimit(varname: []const u8, needed: i32, degraded_cc: bool) void {
    util.flushStdout();
    if (degraded_cc) {
        util.warn("only found copies from modified paths due to too many files.", .{});
    } else if (needed != 0) {
        util.warn("exhaustive rename detection was skipped due to too many files.", .{});
    } else return;
    if (0 < needed) util.warn("you may want to set your {s} variable to at least {d} and retry the command.", .{ varname, needed });
}

/// diff_result_code() for a bare diff_options
pub fn resultCodeOpts(o: *DiffOptions) u8 {
    warnRenameLimit("diff.renameLimit", o.needed_rename_limit, o.degraded_cc_to_c);
    var r: u8 = 0;
    if (o.flags.exit_with_status and o.flags.has_changes) r |= 1;
    if (o.output_format & FMT_CHECKDIFF != 0 and o.flags.check_failed) r |= 2;
    return r;
}

// ---------------------------------------------------------------------------
// word diff (diff_words_*)

const WordsStyleElem = struct { prefix: []const u8, suffix: []const u8, color: []const u8 = "" };
const WordsStyle = struct {
    new_word: WordsStyleElem,
    old_word: WordsStyleElem,
    ctx: WordsStyleElem,
    newline: []const u8,
};
const WordBound = struct { begin: usize, end: usize };

const WordsData = struct {
    typ: WordDiff = .none,
    o: *DiffOptions,
    minus: Buf = .empty,
    plus: Buf = .empty,
    minus_orig: std.ArrayList(WordBound) = .empty,
    plus_orig: std.ArrayList(WordBound) = .empty,
    current_plus: usize = 0,
    last_minus: isize = 0,
    word_regex: ?regex.Regex = null,
    style: WordsStyle,
};

fn initWordsData(e: *Ecb, o: *DiffOptions, one: *Filespec, two: *Filespec) void {
    const w = gpa.create(WordsData) catch util.oom();
    var style: WordsStyle = switch (o.word_diff) {
        .porcelain => .{ .new_word = .{ .prefix = "+", .suffix = "\n" }, .old_word = .{ .prefix = "-", .suffix = "\n" }, .ctx = .{ .prefix = " ", .suffix = "\n" }, .newline = "~\n" },
        .plain => .{ .new_word = .{ .prefix = "{+", .suffix = "+}" }, .old_word = .{ .prefix = "[-", .suffix = "-]" }, .ctx = .{ .prefix = "", .suffix = "" }, .newline = "\n" },
        else => .{ .new_word = .{ .prefix = "", .suffix = "" }, .old_word = .{ .prefix = "", .suffix = "" }, .ctx = .{ .prefix = "", .suffix = "" }, .newline = "\n" },
    };
    if (wantColor(o.use_color)) {
        style.old_word.color = getColor(o, .old);
        style.new_word.color = getColor(o, .new);
        style.ctx.color = getColor(o, .context);
    }
    var wr = o.word_regex;
    if (wr == null and fileValid(one)) wr = loadDriver(one).word_regex;
    if (wr == null and fileValid(two)) wr = loadDriver(two).word_regex;
    if (wr == null) wr = diff_word_regex_cfg;
    w.* = .{ .typ = o.word_diff, .o = o, .style = style };
    if (wr) |pat| {
        w.word_regex = switch (regex.Regex.compile(pat, .{ .extended = true, .newline = true })) {
            .ok => |r| r,
            .err => util.die("invalid regular expression: {s}", .{pat}),
        };
    }
    e.words = w;
}

fn wordsAppend(line: []const u8, b: *Buf) void {
    util.bufAppend(b, line[1..]);
}

fn isGitSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r';
}

/// find_word_boundaries(): returns false when no more words
fn findWordBoundaries(text: []const u8, word_regex: ?regex.Regex, begin: *usize, end: *usize) bool {
    if (word_regex) |re| {
        while (begin.* < text.len) {
            const m = re.exec(text[begin.*..], 0) orelse return false;
            const so: usize = @intCast(m.so);
            const eo: usize = @intCast(m.eo);
            const nl = std.mem.indexOfScalar(u8, text[begin.* + so .. begin.* + eo], '\n');
            end.* = if (nl) |k| begin.* + so + k else eo + begin.*;
            begin.* += so;
            if (begin.* == end.*) {
                begin.* += 1;
            } else return begin.* <= end.*;
        }
    }
    while (begin.* < text.len and isGitSpace(text[begin.*])) begin.* += 1;
    if (begin.* >= text.len) return false;
    end.* = begin.* + 1;
    while (end.* < text.len and !isGitSpace(text[end.*])) end.* += 1;
    return true;
}

fn wordsFill(text: []const u8, orig: *std.ArrayList(WordBound), word_regex: ?regex.Regex) []const u8 {
    var out: Buf = .empty;
    orig.clearRetainingCapacity();
    orig.append(gpa, .{ .begin = 0, .end = 0 }) catch util.oom();
    var i: usize = 0;
    while (i < text.len) : (i += 1) {
        var j: usize = 0;
        if (!findWordBoundaries(text, word_regex, &i, &j)) break;
        orig.append(gpa, .{ .begin = i, .end = j }) catch util.oom();
        util.bufAppend(&out, text[i..j]);
        util.bufByte(&out, '\n');
        i = j - 1;
    }
    return out.items;
}

fn wordsWriteHelper(o: *DiffOptions, st: WordsStyleElem, newline: []const u8, buf0: []const u8) void {
    var buf = buf0;
    var print = false;
    var sb: Buf = .empty;
    while (buf.len > 0) {
        const p = std.mem.indexOfScalar(u8, buf, '\n');
        if (print) util.bufAppend(&sb, linePrefix(o));
        if (p == null or p.? != 0) {
            const has_color = st.color.len > 0;
            if (has_color) util.bufAppend(&sb, st.color);
            util.bufAppend(&sb, st.prefix);
            util.bufAppend(&sb, buf[0 .. p orelse buf.len]);
            util.bufAppend(&sb, st.suffix);
            if (has_color) util.bufAppend(&sb, color.RESET);
        }
        const k = p orelse break;
        util.bufAppend(&sb, newline);
        buf = buf[k + 1 ..];
        print = true;
        if (buf.len > 0) {
            emitSym(o, .word_diff, sb.items, 0);
            sb.clearRetainingCapacity();
        }
    }
    if (sb.items.len > 0) emitSym(o, .word_diff, sb.items, 0);
}

fn wordsOutputGraphPrefix(w: *const WordsData) bool {
    return (w.last_minus == 0 and w.current_plus == 0) or
        (w.current_plus > 0 and w.plus.items[w.current_plus - 1] == '\n');
}

fn wordsHunk(ctx: ?*anyopaque, a_start: isize, a_len: isize, b_start: isize, b_len: isize) void {
    const w: *WordsData = @ptrCast(@alignCast(ctx.?));
    const o = w.o;
    const minus_first: usize = @intCast(if (a_len > 0) a_start + 1 else a_start);
    const plus_first: usize = @intCast(if (b_len > 0) b_start + 1 else b_start);
    const ml: usize = @intCast(a_len);
    const pl: usize = @intCast(b_len);
    var minus_begin: usize = undefined;
    var minus_end: usize = undefined;
    var plus_begin: usize = undefined;
    var plus_end: usize = undefined;
    if (ml > 0) {
        minus_begin = w.minus_orig.items[minus_first].begin;
        minus_end = w.minus_orig.items[minus_first + ml - 1].end;
    } else {
        minus_begin = w.minus_orig.items[minus_first].end;
        minus_end = minus_begin;
    }
    if (pl > 0) {
        plus_begin = w.plus_orig.items[plus_first].begin;
        plus_end = w.plus_orig.items[plus_first + pl - 1].end;
    } else {
        plus_begin = w.plus_orig.items[plus_first].end;
        plus_end = plus_begin;
    }
    if (wordsOutputGraphPrefix(w)) emitSym(o, .word_diff, linePrefix(o), 0);
    if (w.current_plus != plus_begin) wordsWriteHelper(o, w.style.ctx, w.style.newline, w.plus.items[w.current_plus..plus_begin]);
    if (minus_begin != minus_end) wordsWriteHelper(o, w.style.old_word, w.style.newline, w.minus.items[minus_begin..minus_end]);
    if (plus_begin != plus_end) wordsWriteHelper(o, w.style.new_word, w.style.newline, w.plus.items[plus_begin..plus_end]);
    w.current_plus = plus_end;
    w.last_minus = @intCast(minus_first);
}

fn wordsShow(w: *WordsData) void {
    const o = w.o;
    const lp = linePrefix(o);
    if (w.plus.items.len == 0) {
        emitSym(o, .word_diff, lp, 0);
        wordsWriteHelper(o, w.style.old_word, w.style.newline, w.minus.items);
        w.minus.clearRetainingCapacity();
        return;
    }
    w.current_plus = 0;
    w.last_minus = 0;
    const minus = wordsFill(w.minus.items, &w.minus_orig, w.word_regex);
    const plus = wordsFill(w.plus.items, &w.plus_orig, w.word_regex);
    const t = xdiff.trimCommonTail(minus, plus);
    var d = xdiff.diff(t.a, t.b, .{}) catch util.die("unable to generate word diff", .{});
    defer d.deinit();
    xdiff.forEachHunkRange(&d, .{ .context = 0 }, w, wordsHunk);
    if (w.current_plus != w.plus.items.len) {
        if (wordsOutputGraphPrefix(w)) emitSym(o, .word_diff, lp, 0);
        wordsWriteHelper(o, w.style.ctx, w.style.newline, w.plus.items[w.current_plus..]);
    }
    w.minus.clearRetainingCapacity();
    w.plus.clearRetainingCapacity();
}

fn wordsFlush(e: *Ecb, w: *WordsData) void {
    _ = e;
    if (w.minus.items.len > 0 or w.plus.items.len > 0) wordsShow(w);
}

// ---------------------------------------------------------------------------
// tree diff entry points (tree-diff.c)

/// diff_tree_oid(): queue the changes between two trees (null = empty tree).
pub fn diffTree(o: *DiffOptions, old: ?Oid, new: ?Oid, base: []const u8) void {
    treediff.diffTreeOid(old, new, base, o);
}

/// diff_root_tree_oid()
pub fn diffRootTree(o: *DiffOptions, new: Oid, base: []const u8) void {
    treediff.diffTreeOid(null, new, base, o);
}

/// diff_same(): queue an unmodified pair (find-copies-harder source)
pub fn same(o: *DiffOptions, mode: u32, oid: Oid, path: []const u8) void {
    if (sIsGitlink(mode) and isSubmoduleIgnored(o, path)) return;
    if (prefixMismatch(o, path)) return;
    const one = allocFilespec(path, oid, true, mode);
    _ = queuePair(one, one);
    one.count += 1;
}

/// Quick check whether two trees are the same under a pathspec.
pub fn treesSame(old: ?Oid, new: ?Oid, ps: *const pathspec_mod.Pathspec) bool {
    var o = DiffOptions.zero();
    o.file = null;
    o.flags.recursive = true;
    o.flags.quick = true;
    o.output_format = FMT_NO_OUTPUT;
    o.pathspec = ps.*;
    const saved = queue;
    queue = .empty;
    treediff.diffTreeOid(old, new, "", &o);
    const r = queue.items.len == 0;
    queue = saved;
    return r;
}

// ---------------------------------------------------------------------------
// diff-lib.c: diff-files / diff-index

pub const DiffLibOpts = struct {
    /// diff-files: unmerged stage to compare against (revs->max_count; -1 = 2)
    unmerged_stage: i32 = -1,
    /// -c / --cc for unmerged entries
    combine_merges: bool = false,
    dense_combined_merges: bool = false,
    /// DIFF_RACY_IS_MODIFIED
    racy_is_modified: bool = false,
    /// diff-index -m
    match_missing: bool = false,
    /// --merge-base
    merge_base: bool = false,
    /// DIFF_SILENT_ON_REMOVED (diff-files -q)
    silent_on_removed: bool = false,
};

/// check_removed(): 1 = removed, 0 = exists, -1 = error
fn checkRemoved(e: *const index_mod.Entry, st_out: *os.Stat) i32 {
    const st = os.lstatPath(e.path) orelse {
        const er = os.errno();
        if (er != os.ENOENT and er != os.ENOTDIR) return -1;
        return 1;
    };
    st_out.* = st;
    if (pathspec_mod.hasSymlinkLeadingPath(e.path)) return 1;
    if (st.isDir()) {
        if (!sIsGitlink(e.mode) and index_mod.gitlinkHead(e.path) == null) return 1;
    }
    return 0;
}

fn matchStatWithSubmodule(o: *DiffOptions, idx: *index_mod.Index, e: *const index_mod.Entry, st: os.Stat, racy: bool, dirty: *u8) bool {
    var changed = idx.matchStat(e, st, racy) != 0;
    if (changed and !racy and !sIsGitlink(e.mode)) {
        // ie_match_stat compares contents for metadata-only changes when racy
        changed = idx.matchStat(e, st, racy) != 0;
    }
    if (sIsGitlink(e.mode)) {
        if (o.flags.ignore_submodules) {
            changed = false;
        } else if (st.isDir()) {
            const head = index_mod.gitlinkHead(e.path);
            changed = if (head) |h| !hash.eql(h, e.oid) else false;
            if (!o.flags.ignore_dirty_submodules and (!changed or o.flags.dirty_submodules))
                dirty.* = submoduleDirty(e.path, o.flags.ignore_untracked_in_submodules);
        }
    }
    return changed;
}

/// is_submodule_modified(): run "git status --porcelain=2" in the submodule
fn submoduleDirty(path: []const u8, ignore_untracked: bool) u8 {
    const dotgit = util.concat(&.{ path, "/.git" });
    const gd = repo_mod.readGitfile(dotgit) orelse dotgit;
    if (!repo_mod.isGitDirectory(gd)) {
        if (os.isDir(gd)) util.die("'{s}' not recognized as a git repository", .{gd});
        return 0;
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ selfGit(), "status", "--porcelain=2" }) catch util.oom();
    if (ignore_untracked) argv.append(gpa, "-uno") catch util.oom();
    const r = os.run(argv.items, .{ .capture_stdout = true, .no_stdin = true, .cwd = path, .unset_env = &submodule_unset_env, .env = &.{.{ "GIT_DIR", ".git" }} });
    var dirty: u8 = 0;
    var done = false;
    var it = std.mem.splitScalar(u8, r.stdout, '\n');
    while (it.next()) |ln| {
        if (ln.len == 0) continue;
        if (ln[0] == '?') dirty |= DIRTY_SUBMODULE_UNTRACKED;
        if (ln[0] == 'u' or ln[0] == '1' or ln[0] == '2') {
            if (ln.len < 9) continue;
            if (ln[5] == 'S' and ln[8] == 'U') dirty |= DIRTY_SUBMODULE_UNTRACKED;
            if (ln[0] == 'u' or ln[0] == '2' or !std.mem.eql(u8, ln[5..9], "S..U")) dirty |= DIRTY_SUBMODULE_MODIFIED;
        }
        if (dirty & DIRTY_SUBMODULE_MODIFIED != 0 and (dirty & DIRTY_SUBMODULE_UNTRACKED != 0 or ignore_untracked)) {
            done = true;
            break;
        }
    }
    if ((r.status != 0 or r.signaled) and !done) util.die("'git status --porcelain=2' failed in submodule {s}", .{path});
    return dirty;
}

fn ceUptodate(e: *const index_mod.Entry) bool {
    return e.uptodate;
}

/// run_diff_files() without diffcore/flush: queue index vs worktree changes
pub fn queueDiffFiles(o: *DiffOptions, lo: DiffLibOpts) void {
    if (o.max_depth_valid) util.die("max-depth is not supported for worktree diffs", .{});
    o.setMnemonicPrefix("i/", "w/");
    const idx = index_mod.get();
    const entries = idx.entries.items;
    const diff_unmerged_stage: u32 = if (lo.unmerged_stage < 0) 2 else @intCast(lo.unmerged_stage);
    var i: usize = 0;
    while (i < entries.len) : (i += 1) {
        var ce = &entries[i];
        if (ce.removed) continue;
        if (canQuitEarly(o)) break;
        if (!o.pathspec.matches(ce.path, sIsDir(ce.mode) or sIsGitlink(ce.mode))) continue;
        if (o.prefix) |p| {
            if (!util.startsWith(ce.path, p[0..o.prefix_length])) continue;
        }
        if (ce.stage() != 0) {
            var wt_mode: u32 = 0;
            var st: os.Stat = undefined;
            const ch = checkRemoved(ce, &st);
            if (ch == 0) {
                wt_mode = index_mod.ceModeFromStat(ce, st);
            } else if (ch < 0) {
                util.eprint("{s}: {s}\n", .{ ce.path, os.lastErr() });
                continue;
            }
            const cp = gpa.create(treediff.CombinePath) catch util.oom();
            cp.* = .{ .path = ce.path, .mode = wt_mode, .oid = hash.zero, .parent = gpa.alloc(treediff.CombineParent, 2) catch util.oom() };
            for (cp.parent) |*pp| pp.* = .{ .status = 0, .mode = 0, .oid = hash.zero };
            var num_compare_stages: usize = 0;
            while (i < entries.len) {
                const nce = &entries[i];
                if (!util.eql(ce.path, nce.path)) break;
                const stg = nce.stage();
                if (2 <= stg) {
                    num_compare_stages += 1;
                    cp.parent[stg - 2].oid = nce.oid;
                    cp.parent[stg - 2].mode = index_mod.canonMode(nce.mode);
                    cp.parent[stg - 2].status = STATUS_MODIFIED;
                }
                if (stg == diff_unmerged_stage) ce = nce;
                i += 1;
            }
            i -= 1;
            if (lo.combine_merges and num_compare_stages == 2) {
                combined.showCombinedDiff(cp, 2, o, lo.dense_combined_merges);
                continue;
            }
            if (unmerge(o, ce.path)) |pair| {
                if (wt_mode != 0) pair.two.mode = wt_mode;
            }
            if (ce.stage() != diff_unmerged_stage) continue;
        }
        if (ceUptodate(ce) or ce.skipWorktree()) {
            if (o.flags.find_copies_harder) same(o, ce.mode, ce.oid, ce.path);
            continue;
        }
        var changed = false;
        var newmode: u32 = ce.mode;
        var dirty: u8 = 0;
        if (ce.assumeValid()) {
            changed = false;
        } else {
            var st: os.Stat = undefined;
            const ch = checkRemoved(ce, &st);
            if (ch != 0) {
                if (ch < 0) {
                    util.eprint("{s}: {s}\n", .{ ce.path, os.lastErr() });
                    continue;
                }
                if (lo.silent_on_removed) continue;
                addRemove(o, '-', ce.mode, ce.oid, !hash.isZero(ce.oid), ce.path, 0);
                continue;
            } else if (o.ita_invisible_in_index and ce.intentToAdd()) {
                newmode = index_mod.ceModeFromStat(ce, st);
                addRemove(o, '+', newmode, hash.zero, false, ce.path, 0);
                continue;
            }
            changed = matchStatWithSubmodule(o, idx, ce, st, lo.racy_is_modified, &dirty);
            newmode = index_mod.ceModeFromStat(ce, st);
        }
        if (!changed and dirty == 0) {
            ce.uptodate = true;
            if (o.flags.find_copies_harder) same(o, newmode, ce.oid, ce.path);
            continue;
        }
        const new_oid = if (changed) hash.zero else ce.oid;
        change(o, ce.mode, newmode, ce.oid, new_oid, !hash.isZero(ce.oid), !hash.isZero(new_oid), ce.path, 0, dirty);
    }
}

/// run_diff_files(): index vs worktree; runs diffcore_std and flushes
pub fn runDiffFiles(o: *DiffOptions) void {
    runDiffFilesWith(o, .{});
}

pub fn runDiffFilesWith(o: *DiffOptions, lo: DiffLibOpts) void {
    queueDiffFiles(o, lo);
    diffcoreStd(o);
    flush(o);
}

/// get_stat_data(); returns false when the entry should be skipped
fn getStatData(o: *DiffOptions, idx: *index_mod.Index, e: *const index_mod.Entry, oid: *Oid, mode: *u32, cached: bool, match_missing: bool, dirty: *u8) bool {
    oid.* = e.oid;
    mode.* = e.mode;
    if (!cached and !ceUptodate(e)) {
        var st: os.Stat = undefined;
        const ch = checkRemoved(e, &st);
        if (ch < 0) return false;
        if (ch > 0) return match_missing;
        if (matchStatWithSubmodule(o, idx, e, st, false, dirty)) {
            mode.* = index_mod.ceModeFromStat(e, st);
            oid.* = hash.zero;
        }
    }
    return true;
}

const TreeEnt = struct { path: []const u8, mode: u32, oid: Oid };

fn onewayDiff(o: *DiffOptions, idx: *index_mod.Index, ie0: ?*const index_mod.Entry, te: ?TreeEnt, cached0: bool, lo: DiffLibOpts) void {
    var ie = ie0;
    if (cached0 and o.ita_invisible_in_index and ie != null and ie.?.intentToAdd()) {
        ie = null;
        if (te == null) return;
    }
    const cached = cached0 or (ie != null and (ie.?.assumeValid() or ie.?.skipWorktree()));
    if (cached and ie != null and ie.?.stage() != 0) {
        if (unmerge(o, ie.?.path)) |pair| {
            if (te) |t| fillFilespec(pair.one, t.oid, true, t.mode);
        }
        return;
    }
    if (te == null) {
        const e = ie.?;
        var oid: Oid = undefined;
        var mode: u32 = undefined;
        var dirty: u8 = 0;
        if (!getStatData(o, idx, e, &oid, &mode, cached, lo.match_missing, &dirty)) return;
        addRemove(o, '+', mode, oid, !hash.isZero(oid), e.path, dirty);
        return;
    }
    const t = te.?;
    if (ie == null) {
        addRemove(o, '-', t.mode, t.oid, true, t.path, 0);
        return;
    }
    // show_modified
    const e = ie.?;
    var oid: Oid = undefined;
    var mode: u32 = undefined;
    var dirty: u8 = 0;
    if (!getStatData(o, idx, e, &oid, &mode, cached, lo.match_missing, &dirty)) {
        addRemove(o, '-', t.mode, t.oid, true, t.path, 0);
        return;
    }
    if (lo.combine_merges and !cached and (!hash.eql(oid, t.oid) or !hash.eql(t.oid, e.oid))) {
        const cp = gpa.create(treediff.CombinePath) catch util.oom();
        cp.* = .{ .path = e.path, .mode = mode, .oid = hash.zero, .parent = gpa.alloc(treediff.CombineParent, 2) catch util.oom() };
        cp.parent[0] = .{ .status = STATUS_MODIFIED, .mode = e.mode, .oid = e.oid };
        cp.parent[1] = .{ .status = STATUS_MODIFIED, .mode = t.mode, .oid = t.oid };
        combined.showCombinedDiff(cp, 2, o, lo.dense_combined_merges);
        return;
    }
    if (mode != t.mode or !hash.eql(oid, t.oid) or dirty != 0) {
        change(o, t.mode, mode, t.oid, oid, true, !hash.isZero(oid), t.path, 0, dirty);
    } else if (o.flags.find_copies_harder) {
        same(o, mode, oid, t.path);
    }
}

fn flattenTreeInto(tree: Oid, base: []const u8, out: *std.ArrayList(TreeEnt)) void {
    const entries = objects.readTree(tree) orelse util.die("unable to read tree ({s})", .{hash.hexAlloc(tree)});
    for (entries) |e| {
        const p = util.concat(&.{ base, e.name });
        if (e.isDir()) {
            flattenTreeInto(e.oid, util.concat(&.{ p, "/" }), out);
        } else out.append(gpa, .{ .path = p, .mode = canonMode(e.mode), .oid = e.oid }) catch util.oom();
    }
}

/// diff_cache(): queue the differences between a tree and the index (cached)
/// or the worktree. Returns false if the tree is bad.
pub fn queueDiffIndex(o: *DiffOptions, tree_oid: Oid, cached: bool, lo: DiffLibOpts) bool {
    const t = objects.peelTo(tree_oid, .tree) orelse return false;
    if (o.max_depth_valid) util.die("max-depth is not supported for index diffs", .{});
    var tl: std.ArrayList(TreeEnt) = .empty;
    flattenTreeInto(t, "", &tl);
    const idx = index_mod.get();
    const entries = idx.entries.items;
    o.pathspec.recursive = true;
    var ti: usize = 0;
    var ii: usize = 0;
    while (ti < tl.items.len or ii < entries.len) {
        if (ii < entries.len and entries[ii].removed) {
            ii += 1;
            continue;
        }
        var ie: ?*index_mod.Entry = null;
        var te: ?TreeEnt = null;
        if (ii >= entries.len) {
            te = tl.items[ti];
            ti += 1;
        } else if (ti >= tl.items.len) {
            ie = &entries[ii];
        } else {
            switch (std.mem.order(u8, entries[ii].path, tl.items[ti].path)) {
                .lt => ie = &entries[ii],
                .gt => {
                    te = tl.items[ti];
                    ti += 1;
                },
                .eq => {
                    ie = &entries[ii];
                    te = tl.items[ti];
                    ti += 1;
                },
            }
        }
        if (ie) |e| {
            // skip the other stages of the same path
            ii += 1;
            while (ii < entries.len and util.eql(entries[ii].path, e.path)) ii += 1;
        }
        const path = if (ie) |e| e.path else te.?.path;
        const mode = if (ie) |e| e.mode else te.?.mode;
        if (o.prefix) |p| {
            if (!util.startsWith(path, p[0..o.prefix_length])) continue;
        }
        if (!o.pathspec.matches(path, sIsDir(mode) or sIsGitlink(mode))) continue;
        onewayDiff(o, idx, ie, te, cached, lo);
        if (canQuitEarly(o)) break;
    }
    return true;
}

/// run_diff_index(): tree vs index (cached) or worktree; diffcore_std + flush
pub fn runDiffIndex(o: *DiffOptions, tree_oid: Oid, cached: bool) void {
    runDiffIndexWith(o, tree_oid, null, cached, .{});
}

pub fn runDiffIndexWith(o: *DiffOptions, tree_oid: Oid, name: ?[]const u8, cached: bool, lo: DiffLibOpts) void {
    if (!queueDiffIndex(o, tree_oid, cached, lo)) {
        util.err("bad tree object {s}", .{name orelse hash.hexAlloc(tree_oid)});
        os.exit(128);
    }
    o.setMnemonicPrefix("c/", if (cached) "i/" else "w/");
    fixDiffIndex();
    diffcoreStd(o);
    flush(o);
}

// ---------------------------------------------------------------------------
// patch id (diff_get_patch_id)

fn removeSpaceInto(h: *hash.Hasher, s: []const u8) usize {
    var n: usize = 0;
    for (s) |c| {
        if (!std.ascii.isWhitespace(c)) {
            h.update(&[_]u8{c});
            n += 1;
        }
    }
    return n;
}

fn flushOneHunk(result: *Oid, h: *hash.Hasher) void {
    var d: Oid = undefined;
    h.final(&d);
    h.* = hash.Hasher.init(.{});
    var carry: u16 = 0;
    for (0..20) |i| {
        carry += @as(u16, result[i]) + d[i];
        result[i] = @truncate(carry);
        carry >>= 8;
    }
}

const PatchIdCtx = struct { h: *hash.Hasher };

fn patchIdConsume(ctx: *anyopaque, line: []const u8) void {
    const c: *PatchIdCtx = @ptrCast(@alignCast(ctx));
    if (line.len > 12 and util.startsWith(line, "\\ ")) return;
    _ = removeSpaceInto(c.h, line);
}

fn pidMode(h: *hash.Hasher, mode: u32) void {
    var b: [16]u8 = undefined;
    h.update(std.fmt.bufPrint(&b, "{o:0>6}", .{mode}) catch unreachable);
}

/// diff_get_patch_id() over the current (diffcore'd) queue; clears the queue
pub fn flushPatchId(o: *DiffOptions, header_only: bool) ?Oid {
    _ = o;
    defer clearQueue();
    var h = hash.Hasher.init(.{});
    var result: Oid = hash.zero;
    for (queue.items) |p| {
        if (p.status == 0) return null;
        if (p.status == STATUS_UNKNOWN) continue;
        if (unmodifiedPair(p)) continue;
        if ((fileValid(p.one) and sIsDir(p.one.mode)) or (fileValid(p.two) and sIsDir(p.two.mode))) continue;
        if (p.is_unmerged) continue;
        fillOidInfo(p.one);
        fillOidInfo(p.two);
        h.update("diff--git");
        h.update("a/");
        _ = removeSpaceInto(&h, p.one.path);
        h.update("b/");
        _ = removeSpaceInto(&h, p.two.path);
        if (p.one.mode == 0) {
            h.update("newfilemode");
            pidMode(&h, p.two.mode);
        } else if (p.two.mode == 0) {
            h.update("deletedfilemode");
            pidMode(&h, p.one.mode);
        } else if (p.one.mode != p.two.mode) {
            h.update("oldmode");
            pidMode(&h, p.one.mode);
            h.update("newmode");
            pidMode(&h, p.two.mode);
        }
        if (header_only) {} else if (isBinary(p.one) or isBinary(p.two)) {
            h.update(&hash.hex(p.one.oid));
            h.update(&hash.hex(p.two.oid));
        } else {
            if (p.one.mode == 0) {
                h.update("---/dev/null");
                h.update("+++b/");
                _ = removeSpaceInto(&h, p.two.path);
            } else if (p.two.mode == 0) {
                h.update("---a/");
                _ = removeSpaceInto(&h, p.one.path);
                h.update("+++/dev/null");
            } else {
                h.update("---a/");
                _ = removeSpaceInto(&h, p.one.path);
                h.update("+++b/");
                _ = removeSpaceInto(&h, p.two.path);
            }
            const a = fillMmfile(p.one);
            const b = fillMmfile(p.two);
            var ctx = PatchIdCtx{ .h = &h };
            var eo = xdiff.EmitOpts{};
            eo.context = 3;
            eo.no_hunk_header = true;
            if (!xdiDiffOutf(a, b, .{}, eo, &ctx, patchIdConsume)) return null;
        }
        flushOneHunk(&result, &h);
    }
    return result;
}

var patch_id_opts: ?*DiffOptions = null;

/// commit_patch_id() with init_patch_ids() options; null for merges / errors
pub fn commitPatchId(commit: *cn.Commit) ?Oid {
    const o = patch_id_opts orelse blk: {
        const p = gpa.create(DiffOptions) catch util.oom();
        p.* = DiffOptions.init();
        p.detect_rename = 0;
        p.flags.recursive = true;
        p.file = null;
        p.setupDone();
        patch_id_opts = p;
        break :blk p;
    };
    return commitPatchIdWith(commit, o);
}

pub fn commitPatchIdWith(commit: *cn.Commit, o: *DiffOptions) ?Oid {
    cn.parseOrDie(commit);
    if (commit.parents) |pl| {
        if (pl.next != null) return null;
        cn.parseOrDie(pl.item);
    }
    const saved = queue;
    queue = .empty;
    defer queue = saved;
    if (commit.parents) |pl| {
        treediff.diffTreeOid(pl.item.tree, commit.tree, "", o);
    } else treediff.diffTreeOid(null, commit.tree, "", o);
    diffcoreStd(o);
    return flushPatchId(o, false);
}

// ---------------------------------------------------------------------------
// rev_info integration (log, show, whatchanged, format-patch, diff-tree)

fn revOpts(revs: *revision.RevInfo) *DiffOptions {
    return @ptrCast(@alignCast(revs.diffopt.?));
}

fn syncToRevs(revs: *revision.RevInfo, o: *DiffOptions) void {
    revs.output_format = o.output_format;
    revs.line_termination = o.line_termination;
    revs.diff_wants_diff = o.pickaxe_opts & PICKAXE_KINDS_MASK != 0 or o.filter != 0 or o.filter_not != 0 or o.flags.follow_renames;
    revs.follow_renames = o.flags.follow_renames;
    revs.diff_objfind = o.objfind != null;
    revs.use_color = wantColor(o.use_color);
}

fn syncFromRevs(revs: *revision.RevInfo, o: *DiffOptions) void {
    o.output_format = revs.output_format;
    o.line_termination = revs.line_termination;
    o.graph = revs.graph;
    o.revs = revs;
    if (revs.stat_sep) |s| o.stat_sep = s;
}

fn revDiffParse(revs: *revision.RevInfo, argv: []const []const u8) usize {
    const o = revOpts(revs);
    syncFromRevs(revs, o);
    const n = o.parseOpt(argv, 0);
    if (n > 0) syncToRevs(revs, o);
    return n;
}

fn revDiffFinish(revs: *revision.RevInfo) void {
    const o = revOpts(revs);
    syncFromRevs(revs, o);
    if (revs.diff_recursive) o.flags.recursive = true;
    if (revs.diff_tree_in_recursive) o.flags.tree_in_recursive = true;
    if (revs.pickaxe_ignore_case) o.pickaxe_opts |= PICKAXE_IGNORE_CASE;
    if (!revs.prune_data.isEmpty() and !revs.full_diff) o.pathspec = revs.prune_data;
    o.abbrev = @intCast(revs.abbrev);
    if (revs.fp_stat_width != 0) {
        if (o.stat_width <= 0) o.stat_width = revs.fp_stat_width;
        if (o.stat_graph_width == -1) o.stat_graph_width = 0;
        if (o.stat_name_width == -1) o.stat_name_width = 0;
    }
    if (revs.fp_binary and !o.flags.text) o.flags.binary = true;
    if (revs.fp_no_prefix) o.setNoprefix();
    o.setupDone();
    syncToRevs(revs, o);
}

fn opsDiffTree(revs: *revision.RevInfo, old: ?Oid, new: Oid) void {
    const o = revOpts(revs);
    syncFromRevs(revs, o);
    treediff.diffTreeOid(old, new, "", o);
}

fn opsDiffcore(revs: *revision.RevInfo) bool {
    const o = revOpts(revs);
    syncFromRevs(revs, o);
    diffcoreStd(o);
    return !queueIsEmpty();
}

fn opsFlush(revs: *revision.RevInfo) void {
    const o = revOpts(revs);
    syncFromRevs(revs, o);
    flush(o);
}

fn opsDiscard(revs: *revision.RevInfo) void {
    const o = revOpts(revs);
    const saved = o.output_format;
    o.output_format = FMT_NO_OUTPUT;
    flush(o);
    o.output_format = saved;
}

fn opsLinePrefix(revs: *revision.RevInfo) []const u8 {
    const o = revOpts(revs);
    o.graph = revs.graph;
    return linePrefix(o);
}

fn opsCombinedMerge(revs: *revision.RevInfo, commit: *cn.Commit) void {
    const o = revOpts(revs);
    syncFromRevs(revs, o);
    combined.diffTreeCombinedMerge(commit, revs, o);
}

fn opsExitWithStatus(revs: *revision.RevInfo) bool {
    return revOpts(revs).flags.exit_with_status;
}

fn opsGetColor(revs: *revision.RevInfo, slot: []const u8) []const u8 {
    const o = revOpts(revs);
    const s = slotByName(slot) orelse return "";
    return getColor(o, s);
}

fn revPatchId(revs: *revision.RevInfo, commit: *cn.Commit) ?Oid {
    _ = revs;
    return commitPatchId(commit);
}

pub const rev_diff_ops = revision.DiffOps{
    .diff_tree = opsDiffTree,
    .diffcore = opsDiffcore,
    .flush = opsFlush,
    .discard = opsDiscard,
    .line_prefix = opsLinePrefix,
    .combined_merge = opsCombinedMerge,
    .exit_with_status = opsExitWithStatus,
    .get_color = opsGetColor,
    .remerge = opsRemerge,
};

/// Install the diff machinery into a rev_info using porcelain (log) defaults.
pub fn setupRevDiff(revs: *revision.RevInfo) void {
    const o = gpa.create(DiffOptions) catch util.oom();
    o.* = DiffOptions.init();
    o.flags.recursive = true;
    o.stat_width = -1; // init_diffstat_widths()
    o.stat_name_width = -1;
    o.stat_graph_width = -1;
    o.flags.allow_textconv = true;
    setupRevDiffWith(revs, o);
}

/// Install the given (already initialised) diff options into a rev_info.
pub fn setupRevDiffWith(revs: *revision.RevInfo, o: *DiffOptions) void {
    revs.diffopt = o;
    revs.diff_parse = revDiffParse;
    revs.diff_finish = revDiffFinish;
    revs.diff_ops = &rev_diff_ops;
    revs.patch_id_hook = revPatchId;
    revs.output_format = o.output_format;
    revs.line_termination = o.line_termination;
    revs.use_color = wantColor(o.use_color);
    o.revs = revs;
}

/// The DiffOptions installed by setupRevDiff.
pub fn revDiffOptions(revs: *revision.RevInfo) *DiffOptions {
    return revOpts(revs);
}

/// diff_result_code() for a rev_info set up with setupRevDiff
pub fn resultCode(revs: *revision.RevInfo) u8 {
    const o = revOpts(revs);
    return resultCodeOpts(o);
}

pub fn revResultCode(revs: *revision.RevInfo) u8 {
    return resultCode(revs);
}

// ---------------------------------------------------------------------------
// --color-moved (moved-line detection over buffered symbols)

const Emitted = struct {
    s: Sym,
    line: []const u8,
    flags: u32,
    id: u32 = 0,
    indent_off: usize = 0,
    indent_width: i32 = 0,
};

const INDENT_BLANKLINE: i32 = std.math.minInt(i32);
const COLOR_MOVED_MIN_ALNUM_COUNT = 20;
const SYM_MOVED_LINE_ZEBRA_MASK = SYM_MOVED_LINE | SYM_MOVED_LINE_ALT;

const MovedEntry = struct {
    es: usize, // index into emitted symbols
    next_line: ?*MovedEntry = null,
    next_match: ?*MovedEntry = null,
};

const MovedBlock = struct {
    match: ?*MovedEntry,
    wsd: i32,
};

const MovedEntryList = struct { add: ?*MovedEntry = null, del: ?*MovedEntry = null };

fn fillEsIndentData(es: *Emitted) void {
    const s = es.line;
    const len = s.len;
    var off: usize = 0;
    var width: i32 = 0;
    var tab_width: i32 = @intCast(es.flags & WS_TAB_WIDTH_MASK);
    if (tab_width == 0) tab_width = 8;
    const at = struct {
        fn f(b: []const u8, i: usize) u8 {
            return if (i < b.len) b[i] else 0;
        }
    }.f;
    while (at(s, off) == '\x0c' or at(s, off) == '\x0b' or (len > 0 and off < len - 1 and at(s, off) == '\r')) off += 1;
    while (true) {
        if (at(s, off) == ' ') {
            width += 1;
            off += 1;
        } else if (at(s, off) == '\t') {
            width += tab_width - @mod(width, tab_width);
            off += 1;
            while (at(s, off) == '\t') : (off += 1) width += tab_width;
        } else break;
    }
    var i = off;
    while (i < len) : (i += 1) {
        if (!std.ascii.isWhitespace(s[i])) break;
    }
    if (i >= len) {
        es.indent_width = INDENT_BLANKLINE;
        es.indent_off = len;
    } else {
        es.indent_off = off;
        es.indent_width = width;
    }
}

fn computeWsDelta(a: *const Emitted, b: *const Emitted) i32 {
    if (a.indent_width == INDENT_BLANKLINE and b.indent_width == INDENT_BLANKLINE) return INDENT_BLANKLINE;
    return a.indent_width - b.indent_width;
}

fn cmpInBlockWithWsd(syms: []Emitted, cur: *const MovedEntry, l: *const Emitted, pmb: *MovedBlock) bool {
    const ces = &syms[cur.es];
    if (ces.id != l.id) return true;
    if (ces.indent_width == INDENT_BLANKLINE) return false;
    const delta = l.indent_width - ces.indent_width;
    if (pmb.wsd == INDENT_BLANKLINE) pmb.wsd = delta;
    return delta != pmb.wsd;
}

const InternCtx = struct {
    syms: []Emitted,
    flags: u64,
    pub fn hash(self: InternCtx, k: usize) u64 {
        const es = &self.syms[k];
        return xdiff.hashRecord(es.line[es.indent_off..], self.flags);
    }
    pub fn eql(self: InternCtx, a: usize, b: usize) bool {
        const x = &self.syms[a];
        const y = &self.syms[b];
        return xdiff.recmatch(x.line[x.indent_off..], y.line[y.indent_off..], self.flags);
    }
};

fn addLinesToMoveDetection(o: *DiffOptions, syms: []Emitted) []MovedEntryList {
    const ws_flags: u64 = o.color_moved_ws_handling & @as(u32, @intCast(xdiff.XDF_WHITESPACE_FLAGS));
    const ctx = InternCtx{ .syms = syms, .flags = ws_flags };
    var map = std.HashMapUnmanaged(usize, void, InternCtx, 80).empty;
    var list: std.ArrayList(MovedEntryList) = .empty;
    var prev_line: ?*MovedEntry = null;
    var id: u32 = 0;
    for (syms, 0..) |*l, n| {
        if (l.s != .plus and l.s != .minus) {
            prev_line = null;
            continue;
        }
        if (o.color_moved_ws_handling & COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE != 0) fillEsIndentData(l);
        const gop = map.getOrPutContext(gpa, n, ctx) catch util.oom();
        if (gop.found_existing) {
            l.id = syms[gop.key_ptr.*].id;
        } else {
            l.id = id;
            id += 1;
            list.append(gpa, .{}) catch util.oom();
        }
        const entry = gpa.create(MovedEntry) catch util.oom();
        entry.* = .{ .es = n };
        if (prev_line) |pl| {
            if (syms[pl.es].s == l.s) pl.next_line = entry;
        }
        prev_line = entry;
        if (l.s == .plus) {
            entry.next_match = list.items[l.id].add;
            list.items[l.id].add = entry;
        } else {
            entry.next_match = list.items[l.id].del;
            list.items[l.id].del = entry;
        }
    }
    return list.items;
}

fn pmbAdvanceOrNull(o: *DiffOptions, syms: []Emitted, l: *const Emitted, pmb: *std.ArrayList(MovedBlock)) void {
    var j: usize = 0;
    for (pmb.items) |*b| {
        const prev = b.match;
        const cur: ?*MovedEntry = if (prev) |p| p.next_line else null;
        const match = if (o.color_moved_ws_handling & COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE != 0)
            cur != null and !cmpInBlockWithWsd(syms, cur.?, l, b)
        else
            cur != null and syms[cur.?.es].id == l.id;
        if (match) {
            var nb = b.*;
            nb.match = cur;
            pmb.items[j] = nb;
            j += 1;
        }
    }
    pmb.shrinkRetainingCapacity(j);
}

fn fillPotentialMovedBlocks(o: *DiffOptions, syms: []Emitted, match0: ?*MovedEntry, l: *const Emitted, pmb: *std.ArrayList(MovedBlock)) void {
    var match = match0;
    while (match) |m| : (match = m.next_match) {
        const wsd: i32 = if (o.color_moved_ws_handling & COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE != 0) computeWsDelta(l, &syms[m.es]) else 0;
        pmb.append(gpa, .{ .match = m, .wsd = wsd }) catch util.oom();
    }
}

fn adjustLastBlock(o: *DiffOptions, syms: []Emitted, n: usize, block_length: usize) bool {
    if (o.color_moved == .plain) return block_length != 0;
    var alnum_count: usize = 0;
    var i: usize = 1;
    while (i < block_length + 1) : (i += 1) {
        for (syms[n - i].line) |ch| {
            if (ch == 0) break;
            if (!std.ascii.isAlphanumeric(ch)) continue;
            alnum_count += 1;
            if (alnum_count >= COLOR_MOVED_MIN_ALNUM_COUNT) return true;
        }
    }
    i = 1;
    while (i < block_length + 1) : (i += 1) syms[n - i].flags &= ~SYM_MOVED_LINE_ZEBRA_MASK;
    return false;
}

fn markColorAsMoved(o: *DiffOptions, syms: []Emitted, entry_list: []MovedEntryList) void {
    var pmb: std.ArrayList(MovedBlock) = .empty;
    var flipped_block: u1 = 0;
    var block_length: usize = 0;
    var moved_symbol: ?Sym = null;
    var n: usize = 0;
    while (n < syms.len) : (n += 1) {
        var match: ?*MovedEntry = null;
        const l = &syms[n];
        switch (l.s) {
            .plus => match = entry_list[l.id].del,
            .minus => match = entry_list[l.id].add,
            else => flipped_block = 0,
        }
        if (pmb.items.len > 0 and (match == null or moved_symbol == null or l.s != moved_symbol.?)) {
            if (!adjustLastBlock(o, syms, n, block_length) and block_length > 1) {
                match = null;
                n -= block_length;
            }
            pmb.clearRetainingCapacity();
            block_length = 0;
            flipped_block = 0;
        }
        if (match == null) {
            moved_symbol = null;
            continue;
        }
        const ll = &syms[n];
        if (o.color_moved == .plain) {
            ll.flags |= SYM_MOVED_LINE;
            continue;
        }
        pmbAdvanceOrNull(o, syms, ll, &pmb);
        if (pmb.items.len == 0) {
            const contiguous = adjustLastBlock(o, syms, n, block_length);
            if (!contiguous and block_length > 1) {
                n -= block_length;
            } else {
                fillPotentialMovedBlocks(o, syms, match, ll, &pmb);
            }
            const ls = syms[n].s;
            if (contiguous and pmb.items.len > 0 and moved_symbol != null and moved_symbol.? == ls) {
                flipped_block +%= 1;
            } else flipped_block = 0;
            moved_symbol = if (pmb.items.len > 0) ls else null;
            block_length = 0;
        }
        if (pmb.items.len > 0) {
            block_length += 1;
            syms[n].flags |= SYM_MOVED_LINE;
            if (flipped_block != 0 and o.color_moved != .blocks) syms[n].flags |= SYM_MOVED_LINE_ALT;
        }
    }
    _ = adjustLastBlock(o, syms, n, block_length);
}

fn dimMovedLines(syms: []Emitted) void {
    for (syms, 0..) |*l, n| {
        if (l.s != .plus and l.s != .minus) continue;
        if (l.flags & SYM_MOVED_LINE == 0) continue;
        var prev: ?*Emitted = if (n != 0) &syms[n - 1] else null;
        var next: ?*Emitted = if (n + 1 < syms.len) &syms[n + 1] else null;
        if (prev) |p| {
            if (p.s != .plus and p.s != .minus) prev = null;
        }
        if (next) |x| {
            if (x.s != .plus and x.s != .minus) next = null;
        }
        const z = l.flags & SYM_MOVED_LINE_ZEBRA_MASK;
        if (prev != null and prev.?.flags & SYM_MOVED_LINE_ZEBRA_MASK == z and next != null and next.?.flags & SYM_MOVED_LINE_ZEBRA_MASK == z) {
            l.flags |= SYM_MOVED_LINE_UNINTERESTING;
            continue;
        }
        if (prev) |p| {
            if (p.flags & SYM_MOVED_LINE != 0 and p.flags & SYM_MOVED_LINE_ALT != l.flags & SYM_MOVED_LINE_ALT) continue;
        }
        if (next) |x| {
            if (x.flags & SYM_MOVED_LINE != 0 and x.flags & SYM_MOVED_LINE_ALT != l.flags & SYM_MOVED_LINE_ALT) continue;
        }
        l.flags |= SYM_MOVED_LINE_UNINTERESTING;
    }
}

/// the --color-moved tail of diff_flush_patch_all_file_pairs()
fn flushEmittedSymbols(o: *DiffOptions) void {
    const list = o.emitted orelse return;
    o.emitted = null;
    const syms = list.items;
    const entry_list = addLinesToMoveDetection(o, syms);
    markColorAsMoved(o, syms, entry_list);
    if (o.color_moved == .zebra_dim) dimMovedLines(syms);
    for (syms) |e| emitSymFromStruct(o, e.s, e.line, e.flags);
    list.clearRetainingCapacity();
}

// ---------------------------------------------------------------------------
// remerge-diff (log-tree.c do_remerge_diff + additional_path_headers)

/// path -> list of header messages (merge-ort path_messages)
pub const PathHeaders = std.StringArrayHashMapUnmanaged(std.ArrayList([]const u8));

const merge_ort = @import("merge_ort.zig");
const commitreach = @import("commitreach.zig");
const logtree = @import("logtree.zig");

fn opsRemerge(revs: *revision.RevInfo, commit: *cn.Commit) bool {
    const o = revOpts(revs);
    const parents = revision.getSavedParents(revs, commit).?;
    const p1 = parents.item;
    const p2 = parents.next.?.item;
    var mo = merge_ort.initMergeOptions(true);
    mo.show_rename_progress = false;
    mo.record_conflict_msgs_as_headers = true;
    mo.msg_header_prefix = "remerge";
    const ctx = pretty.Context{ .abbrev = revparse.defaultAbbrev() };
    var d1: Buf = .empty;
    var d2: Buf = .empty;
    pretty.formatCommitMessage(p1, "%h (%s)", &d1, &ctx);
    pretty.formatCommitMessage(p2, "%h (%s)", &d2, &ctx);
    mo.branch1 = d1.items;
    mo.branch2 = d2.items;
    cn.parseOrDie(p1);
    cn.parseOrDie(p2);
    const bases = commitreach.getMergeBases(p1, p2);

    const saved_mem = odb_mod.write_in_memory_only;
    odb_mod.write_in_memory_only = true;
    defer odb_mod.write_in_memory_only = saved_mem;
    var res = merge_ort.Result{};
    merge_ort.mergeIncoreRecursive(&mo, bases, p1, p2, &res);

    var headers: PathHeaders = .empty;
    if (res.priv) |priv| {
        for (priv.conflicts.keys(), priv.conflicts.values()) |k, list| {
            var l: std.ArrayList([]const u8) = .empty;
            for (list.items) |m| l.append(gpa, m.text) catch util.oom();
            headers.put(gpa, k, l) catch util.oom();
        }
    }
    o.additional_path_headers = &headers;
    defer o.additional_path_headers = null;
    syncFromRevs(revs, o);
    treediff.diffTreeOid(res.tree, commit.tree, "", o);
    syncToRevs(revs, o);
    _ = logtree.logTreeDiffFlush(revs);
    return revs.loginfo == null;
}

/// create_filepairs_for_header_only_notifications()
fn createHeaderOnlyPairs(o: *DiffOptions) void {
    const hdrs = o.additional_path_headers orelse return;
    var present = std.StringHashMapUnmanaged(void).empty;
    for (queue.items) |p| {
        const path = p.one.path;
        if (hdrs.contains(path)) present.put(gpa, path, {}) catch util.oom();
    }
    for (hdrs.keys()) |k| {
        if (present.contains(k)) continue;
        const one = allocEmptyFilespec(k);
        const two = allocEmptyFilespec(k);
        const p = queuePair(one, two);
        p.status = STATUS_MODIFIED;
        p.header_only = true;
    }
    fixDiffIndex();
}

fn addFormattedHeaders(msg: *Buf, o: *DiffOptions, lp: []const u8, set: []const u8, reset: []const u8, path: []const u8) bool {
    const hdrs = o.additional_path_headers orelse return false;
    const list = hdrs.get(path) orelse return false;
    for (list.items) |h| {
        var it = std.mem.splitScalar(u8, h, '\n');
        while (it.next()) |line| {
            if (line.len == 0 and it.index == null) break;
            util.bufPrint(msg, "{s}{s}{s}{s}\n", .{ lp, set, line, reset });
        }
    }
    return list.items.len > 0;
}

