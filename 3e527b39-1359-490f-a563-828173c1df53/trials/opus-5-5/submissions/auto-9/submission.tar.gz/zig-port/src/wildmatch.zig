//! Port of git's wildmatch.c

const std = @import("std");

pub const CASEFOLD: u32 = 1;
pub const PATHNAME: u32 = 2;

const NOMATCH = 1;
const MATCH = 0;
const ABORT_ALL = -1;
const ABORT_TO_STARSTAR = -2;

fn at(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

fn isGlobSpecial(ch: u8) bool {
    return ch == '*' or ch == '?' or ch == '[' or ch == '\\';
}

fn dowild(pat: []const u8, p0: usize, text: []const u8, t0: usize, flags: u32) i32 {
    var p = p0;
    var t = t0;
    while (at(pat, p) != 0) : ({
        t += 1;
        p += 1;
    }) {
        var p_ch = at(pat, p);
        var t_ch = at(text, t);
        if (t_ch == 0 and p_ch != '*') return ABORT_ALL;
        if (flags & CASEFOLD != 0 and std.ascii.isUpper(t_ch)) t_ch = std.ascii.toLower(t_ch);
        if (flags & CASEFOLD != 0 and std.ascii.isUpper(p_ch)) p_ch = std.ascii.toLower(p_ch);
        switch (p_ch) {
            '?' => {
                if (flags & PATHNAME != 0 and t_ch == '/') return NOMATCH;
                continue;
            },
            '*' => {
                var match_slash: bool = undefined;
                p += 1;
                if (at(pat, p) == '*') {
                    const prev_p = p;
                    p += 1;
                    while (at(pat, p) == '*') p += 1;
                    if (flags & PATHNAME == 0) {
                        match_slash = true;
                    } else if ((prev_p < 2 or pat[prev_p - 2] == '/') and
                        (at(pat, p) == 0 or at(pat, p) == '/' or (at(pat, p) == '\\' and at(pat, p + 1) == '/')))
                    {
                        if (at(pat, p) == '/' and dowild(pat, p + 1, text, t, flags) == MATCH) return MATCH;
                        match_slash = true;
                    } else {
                        match_slash = false;
                    }
                } else {
                    match_slash = flags & PATHNAME == 0;
                }
                if (at(pat, p) == 0) {
                    if (!match_slash) {
                        if (std.mem.indexOfScalar(u8, text[t..], '/') != null) return ABORT_TO_STARSTAR;
                    }
                    return MATCH;
                } else if (!match_slash and at(pat, p) == '/') {
                    const slash = std.mem.indexOfScalar(u8, text[t..], '/') orelse return ABORT_ALL;
                    t = t + slash;
                    continue;
                }
                while (true) {
                    if (t_ch == 0) break;
                    if (!isGlobSpecial(at(pat, p))) {
                        var pc = at(pat, p);
                        if (flags & CASEFOLD != 0 and std.ascii.isUpper(pc)) pc = std.ascii.toLower(pc);
                        while (true) {
                            t_ch = at(text, t);
                            if (t_ch == 0 or !(match_slash or t_ch != '/')) break;
                            if (flags & CASEFOLD != 0 and std.ascii.isUpper(t_ch)) t_ch = std.ascii.toLower(t_ch);
                            if (t_ch == pc) break;
                            t += 1;
                        }
                        if (t_ch != pc) {
                            return if (match_slash) ABORT_ALL else ABORT_TO_STARSTAR;
                        }
                    }
                    const matched = dowild(pat, p, text, t, flags);
                    if (matched != NOMATCH) {
                        if (!match_slash or matched != ABORT_TO_STARSTAR) return matched;
                    } else if (!match_slash and t_ch == '/') return ABORT_TO_STARSTAR;
                    t += 1;
                    t_ch = at(text, t);
                }
                return ABORT_ALL;
            },
            '[' => {
                p += 1;
                p_ch = at(pat, p);
                if (p_ch == '^') p_ch = '!';
                const negated = p_ch == '!';
                if (negated) {
                    p += 1;
                    p_ch = at(pat, p);
                }
                var prev_ch: u8 = 0;
                var matched = false;
                while (true) {
                    if (p_ch == 0) return ABORT_ALL;
                    if (p_ch == '\\') {
                        p += 1;
                        p_ch = at(pat, p);
                        if (p_ch == 0) return ABORT_ALL;
                        if (t_ch == p_ch) matched = true;
                    } else if (p_ch == '-' and prev_ch != 0 and at(pat, p + 1) != 0 and at(pat, p + 1) != ']') {
                        p += 1;
                        p_ch = at(pat, p);
                        if (p_ch == '\\') {
                            p += 1;
                            p_ch = at(pat, p);
                            if (p_ch == 0) return ABORT_ALL;
                        }
                        if (t_ch <= p_ch and t_ch >= prev_ch) {
                            matched = true;
                        } else if (flags & CASEFOLD != 0 and std.ascii.isLower(t_ch)) {
                            const up = std.ascii.toUpper(t_ch);
                            if (up <= p_ch and up >= prev_ch) matched = true;
                        }
                        p_ch = 0;
                    } else if (p_ch == '[' and at(pat, p + 1) == ':') {
                        p += 2;
                        const s = p;
                        while (at(pat, p) != 0 and at(pat, p) != ']') p += 1;
                        p_ch = at(pat, p);
                        if (p_ch == 0) return ABORT_ALL;
                        if (p - s < 1 or pat[p - 1] != ':') {
                            p = s - 2;
                            p_ch = '[';
                            if (t_ch == p_ch) matched = true;
                            prev_ch = p_ch;
                            p += 1;
                            p_ch = at(pat, p);
                            if (p_ch == ']') break;
                            continue;
                        }
                        const cls = pat[s .. p - 1];
                        const eq = std.mem.eql;
                        if (eq(u8, cls, "alnum")) {
                            if (std.ascii.isAlphanumeric(t_ch)) matched = true;
                        } else if (eq(u8, cls, "alpha")) {
                            if (std.ascii.isAlphabetic(t_ch)) matched = true;
                        } else if (eq(u8, cls, "blank")) {
                            if (t_ch == ' ' or t_ch == '\t') matched = true;
                        } else if (eq(u8, cls, "cntrl")) {
                            if (std.ascii.isControl(t_ch)) matched = true;
                        } else if (eq(u8, cls, "digit")) {
                            if (std.ascii.isDigit(t_ch)) matched = true;
                        } else if (eq(u8, cls, "graph")) {
                            if (t_ch > 32 and t_ch < 127) matched = true;
                        } else if (eq(u8, cls, "lower")) {
                            if (std.ascii.isLower(t_ch)) matched = true;
                        } else if (eq(u8, cls, "print")) {
                            if (std.ascii.isPrint(t_ch)) matched = true;
                        } else if (eq(u8, cls, "punct")) {
                            if (t_ch > 32 and t_ch < 127 and !std.ascii.isAlphanumeric(t_ch)) matched = true;
                        } else if (eq(u8, cls, "space")) {
                            if (std.ascii.isWhitespace(t_ch)) matched = true;
                        } else if (eq(u8, cls, "upper")) {
                            if (std.ascii.isUpper(t_ch)) matched = true else if (flags & CASEFOLD != 0 and std.ascii.isLower(t_ch)) matched = true;
                        } else if (eq(u8, cls, "xdigit")) {
                            if (std.ascii.isHex(t_ch)) matched = true;
                        } else return ABORT_ALL;
                        p_ch = 0;
                    } else if (t_ch == p_ch) matched = true;
                    prev_ch = p_ch;
                    p += 1;
                    p_ch = at(pat, p);
                    if (p_ch == ']') break;
                }
                if (matched == negated or (flags & PATHNAME != 0 and t_ch == '/')) return NOMATCH;
                continue;
            },
            '\\' => {
                p += 1;
                p_ch = at(pat, p);
                if (t_ch != p_ch) return NOMATCH;
                continue;
            },
            else => {
                if (t_ch != p_ch) return NOMATCH;
                continue;
            },
        }
    }
    return if (t < text.len) NOMATCH else MATCH;
}

pub fn match(pattern: []const u8, text: []const u8, flags: u32) bool {
    return dowild(pattern, 0, text, 0, flags) == MATCH;
}

/// fnmatch-like without pathname semantics
pub fn fnmatch(pattern: []const u8, text: []const u8) bool {
    return match(pattern, text, 0);
}

pub fn hasGlobChars(s: []const u8) bool {
    for (s) |ch| {
        if (isGlobSpecial(ch)) return true;
    }
    return false;
}
