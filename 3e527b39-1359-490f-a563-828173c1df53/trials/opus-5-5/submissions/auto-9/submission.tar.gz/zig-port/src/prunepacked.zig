//! Port of prune-packed.c: remove loose objects that also exist in a pack.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const progress = @import("progress.zig");

/// prune_packed_objects(). `quiet` suppresses the progress meter
/// (PRUNE_PACKED_VERBOSE is the inverse).
pub fn prunePacked(dry_run: bool, quiet: bool) void {
    const odb = repo_mod.repo().odb();
    odb.loadPacks();
    var prog: ?*progress.Progress = null;
    if (!quiet and os.isatty(2)) prog = progress.startDelayed("Removing duplicate objects", 256);
    const dir = odb.objects_dir;
    var b: usize = 0;
    while (b < 256) : (b += 1) {
        const hx = util.fmt("{x:0>2}", .{b});
        const sub = util.concat(&.{ dir, "/", hx });
        if (os.listDir(sub)) |ents| {
            for (ents) |e| {
                if (e.name.len != 38) continue;
                const oid = hash.fromHex(util.concat(&.{ hx, e.name })) orelse continue;
                if (odb.findPacked(oid) == null) continue;
                const path = util.concat(&.{ sub, "/", e.name });
                if (dry_run) {
                    util.outf("rm -f {s}\n", .{path});
                } else if (!os.unlink(path)) {
                    util.warn("unable to unlink '{s}': {s}", .{ path, os.lastErr() });
                }
            }
            if (!dry_run) _ = os.rmdir(sub);
        }
        progress.update(prog, b + 1);
    }
    progress.update(prog, 256);
    progress.stop(&prog);
}
