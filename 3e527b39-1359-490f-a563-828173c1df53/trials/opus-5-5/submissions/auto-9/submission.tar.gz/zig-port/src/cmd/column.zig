//! git column (builtin/column.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const column = @import("../column.zig");
const gpa = util.gpa;

const usage = [_][]const u8{"git column [<options>]"};

var colopts: i32 = 0;
var real_command: ?[]const u8 = null;
var width: i32 = 0;
var indent: ?[]const u8 = null;
var nl: ?[]const u8 = null;
var padding: i32 = 1;

fn modeCb(arg: ?[]const u8, unset: bool) void {
    var u: u32 = @bitCast(colopts);
    const ok = column.parseoptColumn(&u, arg, unset);
    colopts = @bitCast(u);
    if (!ok) os.exit(129);
}

const options = [_]po.Opt{
    po.string(0, "command", &real_command, "name", "lookup config vars"),
    .{ .long = "mode", .kind = .callback, .cb = modeCb, .optarg = true, .argh = "style", .help = "layout to use" },
    .{ .long = "raw-mode", .kind = .uint, .i = &colopts, .argh = "n", .help = "layout to use" },
    po.integer(0, "width", &width, "n", "maximum width"),
    po.string(0, "indent", &indent, "string", "padding space on left border"),
    po.string(0, "nl", &nl, "string", "padding space on right border"),
    po.integer(0, "padding", &padding, "n", "padding space between columns"),
};

pub fn cmdColumn(args: []const []const u8) u8 {
    var command: ?[]const u8 = null;
    if (args.len > 1 and util.startsWith(args[1], "--command=")) command = args[1]["--command=".len..];
    var u: u32 = 0;
    column.applyRepoConfig(command, &u);
    colopts = @bitCast(u);
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (padding < 0) util.die("{s} must be non-negative", .{"--padding"});
    if (rest.len > 0) po.usageWithOptions(&usage, &options);
    if (real_command != null or command != null) {
        if (real_command == null or command == null or !util.eql(real_command.?, command.?))
            util.die("--command must be the first argument", .{});
    }
    u = @bitCast(colopts);
    column.finalizeColopts(&u, -1);
    const data = os.readAllFd(0) catch &[_]u8{};
    var lines: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |l0| {
        if (l0.len == 0 and it.index == null) break;
        // strbuf_getline() strips a trailing CR too
        const l = if (l0.len > 0 and l0[l0.len - 1] == '\r') l0[0 .. l0.len - 1] else l0;
        lines.append(gpa, l) catch util.oom();
    }
    column.printColumns(lines.items, u, .{ .width = width, .padding = padding, .indent = indent, .nl = nl });
    return 0;
}
