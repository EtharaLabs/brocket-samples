//! Commit message grep filter used by the revision walker
//! (subset of grep.c: header/body patterns, --all-match, --invert-grep).

const std = @import("std");
const util = @import("util.zig");
const regex = @import("regex.zig");
const gpa = util.gpa;

pub const PatternType = enum { unspecified, bre, ere, fixed, pcre };
pub const Field = enum(u8) { author = 0, committer = 1, reflog = 2 };
const header_names = [_][]const u8{ "author ", "committer ", "reflog " };

pub const Token = enum { pattern_head, pattern_body, pattern };

pub const Pat = struct {
    token: Token,
    field: Field = .author,
    pattern: []const u8,
    re: ?regex.Regex = null,
};

const Node = union(enum) {
    true_,
    atom: *Pat,
    not: *Expr,
    and_: [2]*Expr,
    or_: [2]*Expr,
};

const Expr = struct {
    node: Node,
    hit: bool = false,
};

pub const Filter = struct {
    pattern_list: std.ArrayList(*Pat) = .empty,
    header_list: std.ArrayList(*Pat) = .empty,
    pattern_type_option: PatternType = .unspecified,
    extended_regexp_option: bool = false,
    ignore_case: bool = false,
    all_match: bool = false,
    no_body_match: bool = false,
    word_regexp: bool = false,
    expr: ?*Expr = null,
    body_hit: bool = false,
    compiled: bool = false,

    pub fn isEmpty(f: *const Filter) bool {
        return f.pattern_list.items.len == 0 and f.header_list.items.len == 0;
    }

    pub fn hasReflogFilter(f: *const Filter) bool {
        for (f.header_list.items) |p| if (p.field == .reflog) return true;
        return false;
    }

    pub fn addBody(f: *Filter, pattern: []const u8) void {
        const p = gpa.create(Pat) catch util.oom();
        p.* = .{ .token = .pattern_body, .pattern = pattern };
        f.pattern_list.append(gpa, p) catch util.oom();
    }

    pub fn addHeader(f: *Filter, field: Field, pattern: []const u8) void {
        const p = gpa.create(Pat) catch util.oom();
        p.* = .{ .token = .pattern_head, .field = field, .pattern = pattern };
        f.header_list.append(gpa, p) catch util.oom();
    }

    /// Apply grep.patternType / grep.extendedRegexp config.
    pub fn config(f: *Filter, cfg_get: anytype) void {
        if (cfg_get.get("grep.extendedregexp")) |v| {
            f.extended_regexp_option = util.eql(v, "true") or util.eql(v, "yes") or util.eql(v, "on") or util.eql(v, "1");
        }
        if (cfg_get.get("grep.patterntype")) |v| {
            if (parsePatternType(v)) |t| {
                if (t != .unspecified) f.pattern_type_option = t;
            }
        }
    }

    pub fn compile(f: *Filter) void {
        if (f.compiled) return;
        f.compiled = true;
        if (f.pattern_type_option == .unspecified)
            f.pattern_type_option = if (f.extended_regexp_option) .ere else .bre;
        var header_expr: ?*Expr = null;
        if (f.header_list.items.len > 0) {
            for (f.header_list.items) |p| compileRegexp(p, f);
            var groups = [_]?*Expr{ null, null, null };
            for (f.header_list.items) |p| {
                const h = newExpr(.{ .atom = p });
                const fi = @intFromEnum(p.field);
                if (groups[fi]) |g| {
                    groups[fi] = newExpr(.{ .or_ = .{ h, g } });
                } else groups[fi] = h;
            }
            for (groups) |g| {
                const gg = g orelse continue;
                if (header_expr == null) header_expr = newExpr(.true_);
                header_expr = newExpr(.{ .or_ = .{ gg, header_expr.? } });
            }
        }
        for (f.pattern_list.items) |p| compileRegexp(p, f);
        if (!(f.all_match or f.no_body_match or header_expr != null)) return;
        // build OR chain of body patterns (compile_pattern_or)
        var pe: ?*Expr = null;
        if (f.pattern_list.items.len > 0) {
            var i: usize = f.pattern_list.items.len;
            while (i > 0) {
                i -= 1;
                const a = newExpr(.{ .atom = f.pattern_list.items[i] });
                pe = if (pe) |r| newExpr(.{ .or_ = .{ a, r } }) else a;
            }
        }
        if (f.no_body_match and pe != null) pe = newExpr(.{ .not = pe.? });
        f.expr = pe;
        const he = header_expr orelse return;
        if (f.expr == null) {
            f.expr = he;
        } else if (f.all_match) {
            // grep_splice_or
            var x: ?*Expr = he;
            while (x) |xx| {
                const r = xx.node.or_[1];
                if (r.node == .true_) {
                    xx.node.or_[1] = f.expr.?;
                    break;
                }
                x = r;
            }
            f.expr = he;
        } else {
            f.expr = newExpr(.{ .or_ = .{ f.expr.?, he } });
        }
        f.all_match = true;
    }

    /// grep_buffer in status-only mode.
    pub fn matchBuffer(f: *Filter, buf: []const u8) bool {
        if (!f.compiled) f.compile();
        if (!f.all_match and !f.no_body_match) return source1(f, buf, false);
        if (f.expr) |e| clrHitMarker(e);
        f.body_hit = false;
        _ = source1(f, buf, true);
        if (f.all_match and f.expr != null and !chkHitMarker(f.expr.?)) return false;
        if (f.no_body_match and f.body_hit) return false;
        return source1(f, buf, false);
    }
};

pub fn parsePatternType(v: []const u8) ?PatternType {
    if (util.eql(v, "default")) return .unspecified;
    if (util.eql(v, "basic")) return .bre;
    if (util.eql(v, "extended")) return .ere;
    if (util.eql(v, "fixed")) return .fixed;
    if (util.eql(v, "perl")) return .pcre;
    return null;
}

fn newExpr(n: Node) *Expr {
    const e = gpa.create(Expr) catch util.oom();
    e.* = .{ .node = n };
    return e;
}

fn escapeBre(s: []const u8) []const u8 {
    var b: util.Buf = .empty;
    for (s) |ch| {
        switch (ch) {
            '.', '[', ']', '\\', '*', '^', '$' => {
                util.bufByte(&b, '\\');
                util.bufByte(&b, ch);
            },
            else => util.bufByte(&b, ch),
        }
    }
    return b.items;
}

fn compileRegexp(p: *Pat, f: *Filter) void {
    var pat = p.pattern;
    var extended = false;
    switch (f.pattern_type_option) {
        .fixed => pat = escapeBre(p.pattern),
        .ere, .pcre => extended = true,
        else => {},
    }
    switch (regex.Regex.compile(pat, .{ .extended = extended, .icase = f.ignore_case, .newline = true })) {
        .ok => |r| p.re = r,
        .err => |m| util.die("{s}: '{s}'", .{ m, p.pattern }),
    }
}

fn isWordChar(ch: u8) bool {
    return std.ascii.isAlphanumeric(ch) or ch == '_';
}

fn matchOne(p: *Pat, f: *Filter, line0: []const u8, in_head: bool) bool {
    var line = line0;
    if (p.token != .pattern and (p.token == .pattern_head) != in_head) return false;
    if (p.token == .pattern_head) {
        const fld = header_names[@intFromEnum(p.field)];
        if (!util.startsWith(line, fld)) return false;
        line = line[fld.len..];
        if (p.field != .reflog) {
            // strip_timestamp
            if (std.mem.lastIndexOfScalar(u8, line, '>')) |gt| {
                if (gt > 0) line = line[0 .. gt + 1];
            }
        }
    }
    const re = p.re orelse return false;
    if (!f.word_regexp) return re.isMatch(line);
    var start: usize = 0;
    var notbol = false;
    while (start <= line.len) {
        const m = re.find(line[start..], notbol) orelse return false;
        const so = start + @as(usize, @intCast(m.so));
        const eo = start + @as(usize, @intCast(m.eo));
        if ((so == 0 or !isWordChar(line[so - 1])) and (eo == line.len or !isWordChar(line[eo])) and so != eo) return true;
        if (so + 1 >= line.len) return false;
        start = so + 1;
        while (start < line.len and isWordChar(line[start - 1])) start += 1;
        notbol = true;
        if (start >= line.len) return false;
    }
    return false;
}

fn evalExpr(f: *Filter, x: *Expr, line: []const u8, in_head: bool, collect: bool) bool {
    var h = false;
    switch (x.node) {
        .true_ => h = true,
        .atom => |p| {
            h = matchOne(p, f, line, in_head);
            if (p.token == .pattern_body and h) f.body_hit = true;
        },
        .not => |u| h = !evalExpr(f, u, line, in_head, false),
        .and_ => |b| {
            h = evalExpr(f, b[0], line, in_head, false);
            if (h) h = evalExpr(f, b[1], line, in_head, false);
        },
        .or_ => |b| {
            if (!collect) return evalExpr(f, b[0], line, in_head, false) or evalExpr(f, b[1], line, in_head, false);
            h = evalExpr(f, b[0], line, in_head, false);
            if (h) b[0].hit = true;
            if (evalExpr(f, b[1], line, in_head, true)) h = true;
        },
    }
    if (collect and h) x.hit = true;
    return h;
}

fn matchLine(f: *Filter, line: []const u8, in_head: bool, collect: bool) bool {
    if (f.expr) |e| return evalExpr(f, e, line, in_head, collect);
    for (f.pattern_list.items) |p| {
        if (matchOne(p, f, line, in_head)) return true;
    }
    return false;
}

fn source1(f: *Filter, buf: []const u8, collect: bool) bool {
    var in_head = true;
    var pos: usize = 0;
    while (pos < buf.len) {
        const nl = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse buf.len;
        const line = buf[pos..nl];
        if (in_head and line.len == 0) in_head = false;
        const hit = matchLine(f, line, in_head, collect);
        if (!collect and hit) return true;
        pos = nl + 1;
    }
    return false;
}

fn clrHitMarker(x0: *Expr) void {
    var x = x0;
    while (true) {
        x.hit = false;
        switch (x.node) {
            .or_ => |b| {
                b[0].hit = false;
                x = b[1];
            },
            else => return,
        }
    }
}

fn chkHitMarker(x0: *Expr) bool {
    var x = x0;
    while (true) {
        switch (x.node) {
            .or_ => |b| {
                if (!b[0].hit) return false;
                x = b[1];
            },
            else => return x.hit,
        }
    }
}
