//! Pathspec parsing and matching (port of pathspec.c and the matching half of dir.c).
//!
//! API:
//!   parse(prefix, args, Flags) -> Pathspec   (prefix like "sub/" or "")
//!   Pathspec.matches(path, is_dir) bool       simple yes/no (handles exclude magic)
//!   Pathspec.matchSeen(path, is_dir, seen) u8 match_pathspec() with seen[] bookkeeping
//!   Pathspec.matchLeading(path, is_dir, seen) match_leading_pathspec()
//!   Pathspec.matchingItem(path, is_dir) ?usize
//!   Pathspec.couldMatchUnder(dir) bool        could anything below dir/ match?
//!   Pathspec.newSeen() []u8, reportPathError(seen) usize (prints "error: pathspec '%s' did not match...")
//!   Pathspec.matchAgainstIndex(idx, seen, skip_skip_worktree)
//!   Pathspec.commonPrefixLen() / commonPrefix()
//!   matchItem(item, path, is_dir) MatchKind (legacy single item matcher)
//!   MATCHED_* constants; MAGIC_* bits.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const wildmatch = @import("wildmatch.zig");
const gpa = util.gpa;

pub const MAGIC_FROMTOP: u32 = 1 << 0;
pub const MAGIC_MAXDEPTH: u32 = 1 << 1;
pub const MAGIC_LITERAL: u32 = 1 << 2;
pub const MAGIC_GLOB: u32 = 1 << 3;
pub const MAGIC_ICASE: u32 = 1 << 4;
pub const MAGIC_EXCLUDE: u32 = 1 << 5;
pub const MAGIC_ATTR: u32 = 1 << 6;

pub const MATCHED_RECURSIVELY: u8 = 1;
pub const MATCHED_RECURSIVELY_LEADING_PATHSPEC: u8 = 2;
pub const MATCHED_FNMATCH: u8 = 3;
pub const MATCHED_EXACTLY: u8 = 4;

pub const DO_MATCH_EXCLUDE: u32 = 1 << 0;
pub const DO_MATCH_DIRECTORY: u32 = 1 << 1;
pub const DO_MATCH_LEADING_PATHSPEC: u32 = 1 << 2;

pub const AttrMode = enum { set, unset, value, unspecified };
pub const AttrMatch = struct { name: []const u8, mode: AttrMode, value: []const u8 = "" };

pub const Item = struct {
    /// pattern relative to the top of the worktree (prefix applied)
    match: []const u8,
    /// original argument
    original: []const u8,
    /// length of leading part without glob chars
    nowildcard_len: usize,
    /// length of the prefix part of match (case sensitive part for icase)
    prefix: usize = 0,
    magic: u32 = 0,
    onestar: bool = false,
    attr_match: []AttrMatch = &.{},
    // convenience copies of magic bits
    literal: bool = false,
    glob: bool = false,
    icase: bool = false,
    exclude: bool = false,
    top: bool = false,
};

pub const Flags = struct {
    /// die if a path is outside the repository (kept for compat; always dies)
    keep_outside: bool = false,
    /// treat all pathspecs literally (PATHSPEC_LITERAL_PATH)
    literal: bool = false,
    /// no magic allowed
    no_magic: bool = false,
    /// no args -> empty pathspec (match all)
    prefer_full: bool = false,
    /// no args -> prefix is the pathspec
    prefer_cwd: bool = false,
    /// enable max_depth handling
    maxdepth_valid: bool = false,
    /// magic bits that are not supported by the command (die if used)
    magic_mask: u32 = 0,
    /// die if pathspec is beyond a symbolic link
    symlink_leading_path: bool = false,
    /// produce :(prefix:N) originals for passing to subprocesses
    prefix_origin: bool = false,
    /// no repository (outside dir tree message)
    no_repository: bool = false,
};

pub const Pathspec = struct {
    items: []Item = &.{},
    magic: u32 = 0,
    has_wildcard: bool = false,
    recursive: bool = false,
    max_depth: i32 = -1,

    pub fn isEmpty(self: *const Pathspec) bool {
        return self.items.len == 0;
    }

    /// Does `path` match? `is_dir` allows matching "dir/" items against directories.
    pub fn matches(self: *const Pathspec, path: []const u8, is_dir: bool) bool {
        return self.matchFlags(path, 0, null, if (is_dir) DO_MATCH_DIRECTORY else 0) != 0;
    }

    /// match_pathspec(): returns MATCHED_* (0 = no match); updates seen.
    pub fn matchSeen(self: *const Pathspec, path: []const u8, is_dir: bool, seen: ?[]u8) u8 {
        return self.matchFlags(path, 0, seen, if (is_dir) DO_MATCH_DIRECTORY else 0);
    }

    /// match_leading_pathspec()
    pub fn matchLeading(self: *const Pathspec, path: []const u8, is_dir: bool, seen: ?[]u8) u8 {
        return self.matchFlags(path, 0, seen, if (is_dir) DO_MATCH_DIRECTORY | DO_MATCH_LEADING_PATHSPEC else 0);
    }

    /// match_pathspec_with_flags()
    pub fn matchFlags(self: *const Pathspec, path: []const u8, prefix: usize, seen: ?[]u8, flags: u32) u8 {
        const positive = doMatch(self, path, prefix, seen, flags);
        if (self.magic & MAGIC_EXCLUDE == 0 or positive == 0) return positive;
        const negative = doMatch(self, path, 0, seen, flags | DO_MATCH_EXCLUDE);
        return if (negative != 0) 0 else positive;
    }

    /// Index of the first item matching path, or null. Used for "did not match" reporting.
    pub fn matchingItem(self: *const Pathspec, path: []const u8, is_dir: bool) ?usize {
        for (self.items, 0..) |*it, i| {
            if (it.magic & MAGIC_EXCLUDE != 0) continue;
            if (matchItemFlags(it, 0, path, if (is_dir) DO_MATCH_DIRECTORY else 0) != 0) return i;
        }
        return null;
    }

    /// Could anything under directory `dir` (no trailing slash) match?
    pub fn couldMatchUnder(self: *const Pathspec, dir: []const u8) bool {
        if (self.items.len == 0) return true;
        const d = util.concat(&.{ dir, "/" });
        return self.matchFlags(d, 0, null, DO_MATCH_LEADING_PATHSPEC | DO_MATCH_DIRECTORY) != 0;
    }

    pub fn newSeen(self: *const Pathspec) []u8 {
        const s = gpa.alloc(u8, self.items.len) catch util.oom();
        @memset(s, 0);
        return s;
    }

    /// report_path_error(): returns number of errors printed.
    pub fn reportPathError(self: *const Pathspec, seen: []const u8) usize {
        var errors: usize = 0;
        for (self.items, 0..) |it, num| {
            if (seen[num] != 0) continue;
            var dup = false;
            for (self.items, 0..) |o, other| {
                if (other == num or seen[other] == 0) continue;
                if (util.eql(o.original, it.original)) {
                    dup = true;
                    break;
                }
            }
            if (dup) continue;
            util.err("pathspec '{s}' did not match any file(s) known to git", .{it.original});
            errors += 1;
        }
        return errors;
    }

    /// add_pathspec_matches_against_index()
    pub fn matchAgainstIndex(self: *const Pathspec, idx: anytype, seen: []u8, ignore_skip_worktree: bool) void {
        var unmatched: usize = 0;
        for (seen) |s| {
            if (s == 0) unmatched += 1;
        }
        if (unmatched == 0) return;
        for (idx.entries.items) |*e| {
            if (ignore_skip_worktree and e.skipWorktree()) continue;
            _ = self.matchSeen(e.path, isGitlinkMode(e.mode), seen);
        }
    }

    /// Length of the common leading directory part of all non-exclude items.
    pub fn commonPrefixLen(self: *const Pathspec) usize {
        var first: ?usize = null;
        var max: usize = 0;
        for (self.items, 0..) |*it, n| {
            if (it.magic & MAGIC_EXCLUDE != 0) continue;
            if (first == null) first = n;
            const f = &self.items[first.?];
            const item_len = if (it.magic & MAGIC_ICASE != 0) it.prefix else it.nowildcard_len;
            var i: usize = 0;
            var len: usize = 0;
            while (i < item_len and (n == first.? or i < max)) : (i += 1) {
                const ch = it.match[i];
                if (i >= f.match.len or ch != f.match[i]) break;
                if (ch == '/') len = i + 1;
            }
            if (n == first.? or len < max) {
                max = len;
                if (max == 0) break;
            }
        }
        return max;
    }

    pub fn commonPrefix(self: *const Pathspec) []const u8 {
        const l = self.commonPrefixLen();
        if (l == 0) return "";
        for (self.items) |*it| {
            if (it.magic & MAGIC_EXCLUDE == 0) return it.match[0..l];
        }
        return "";
    }
};

fn isGitlinkMode(mode: u32) bool {
    return mode & 0o170000 == 0o160000;
}

pub const MatchKind = enum { none, exact, leading_dir, wildcard };

/// Legacy single-item matcher.
pub fn matchItem(it: *const Item, path: []const u8, is_dir: bool) MatchKind {
    const r = matchItemFlags(it, 0, path, if (is_dir) DO_MATCH_DIRECTORY else 0);
    return switch (r) {
        0 => .none,
        MATCHED_EXACTLY => .exact,
        MATCHED_FNMATCH => .wildcard,
        else => .leading_dir,
    };
}

fn psNcmpEq(it: *const Item, a: []const u8, b: []const u8, n: usize) bool {
    if (a.len < n or b.len < n) {
        // compare like strncmp with NUL termination
        const m = @min(n, @min(a.len, b.len));
        if (!psEq(it, a[0..m], b[0..m])) return false;
        // both must end at the same position
        return a.len == b.len or (a.len >= n and b.len >= n);
    }
    return psEq(it, a[0..n], b[0..n]);
}

fn psEq(it: *const Item, a: []const u8, b: []const u8) bool {
    if (it.magic & MAGIC_ICASE != 0) return std.ascii.eqlIgnoreCase(a, b);
    return std.mem.eql(u8, a, b);
}

fn gitFnmatch(it: *const Item, pattern_in: []const u8, string_in: []const u8, prefix: usize) bool {
    var pattern = pattern_in;
    var string = string_in;
    if (prefix > 0) {
        if (!psNcmpEq(it, pattern, string, prefix)) return false;
        pattern = pattern[prefix..];
        string = string[prefix..];
    }
    if (it.onestar) {
        const p = pattern[1..];
        if (string.len < p.len) return false;
        return psEq(it, p, string[string.len - p.len ..]);
    }
    var fl: u32 = 0;
    if (it.magic & MAGIC_ICASE != 0) fl |= wildmatch.CASEFOLD;
    if (it.magic & MAGIC_GLOB != 0) fl |= wildmatch.PATHNAME;
    return wildmatch.match(pattern, string, fl);
}

/// match_pathspec_item(); `name` is the full path, prefix is cut by us.
pub fn matchItemFlags(it: *const Item, prefix: usize, full_name: []const u8, flags: u32) u8 {
    if (prefix > full_name.len) return 0;
    const name = full_name[prefix..];
    const match = it.match[@min(prefix, it.match.len)..];
    const matchlen = match.len;
    const namelen = name.len;

    if (it.prefix > 0 and it.magic & MAGIC_ICASE != 0) {
        if (full_name.len < it.prefix or !std.mem.eql(u8, it.match[0..it.prefix], full_name[0..it.prefix])) return 0;
    }
    if (it.attr_match.len > 0) {
        if (!matchAttrs(it, full_name)) return 0;
    }
    if (matchlen == 0) return MATCHED_RECURSIVELY;

    if (matchlen <= namelen and psEq(it, match, name[0..matchlen])) {
        if (matchlen == namelen) return MATCHED_EXACTLY;
        if (match[matchlen - 1] == '/' or name[matchlen] == '/') return MATCHED_RECURSIVELY;
    } else if (flags & DO_MATCH_DIRECTORY != 0 and match[matchlen - 1] == '/' and
        namelen == matchlen - 1 and psEq(it, match[0..namelen], name))
        return MATCHED_EXACTLY;

    if (it.nowildcard_len < it.match.len) {
        const pl = if (it.nowildcard_len > prefix) it.nowildcard_len - prefix else 0;
        if (gitFnmatch(it, match, name, pl)) return MATCHED_FNMATCH;
    }

    if (flags & DO_MATCH_LEADING_PATHSPEC != 0 and flags & DO_MATCH_EXCLUDE == 0) {
        const offset: usize = if (namelen > 0 and name[namelen - 1] == '/') 1 else 0;
        if (namelen < matchlen and match[namelen - offset] == '/' and psEq(it, match[0..namelen], name))
            return MATCHED_RECURSIVELY_LEADING_PATHSPEC;
        if (it.nowildcard_len < it.match.len) {
            const nl = if (it.nowildcard_len > prefix) it.nowildcard_len - prefix else 0;
            if (!psNcmpEq(it, match, name, nl)) return 0;
        }
        if (it.nowildcard_len == it.match.len) return 0;
        return MATCHED_RECURSIVELY_LEADING_PATHSPEC;
    }
    return 0;
}

pub fn withinDepth(name: []const u8, depth0: i32, max_depth: i32) bool {
    var depth = depth0;
    for (name) |ch| {
        if (ch != '/') continue;
        depth += 1;
        if (depth > max_depth) return false;
    }
    return depth <= max_depth;
}

fn doMatch(ps: *const Pathspec, name: []const u8, prefix: usize, seen: ?[]u8, flags: u32) u8 {
    const exclude = flags & DO_MATCH_EXCLUDE != 0;
    if (ps.items.len == 0) {
        if (!ps.recursive or ps.magic & MAGIC_MAXDEPTH == 0 or ps.max_depth == -1) return MATCHED_RECURSIVELY;
        return if (withinDepth(name, 0, ps.max_depth)) MATCHED_EXACTLY else 0;
    }
    var retval: u8 = 0;
    var i: usize = ps.items.len;
    while (i > 0) {
        i -= 1;
        const it = &ps.items[i];
        const is_ex = it.magic & MAGIC_EXCLUDE != 0;
        if (is_ex != exclude) continue;
        if (seen) |s| {
            if (s[i] == MATCHED_EXACTLY and it.nowildcard_len == it.match.len) continue;
            if (is_ex) s[i] = MATCHED_FNMATCH;
        }
        var how = matchItemFlags(it, prefix, name, flags);
        if (ps.recursive and ps.magic & MAGIC_MAXDEPTH != 0 and ps.max_depth != -1 and how != 0 and how != MATCHED_FNMATCH) {
            var len = it.match.len;
            if (len < name.len and name[len] == '/') len += 1;
            if (len > name.len) len = name.len;
            how = if (withinDepth(name[len..], 0, ps.max_depth)) MATCHED_EXACTLY else 0;
        }
        if (how != 0) {
            if (retval < how) retval = how;
            if (seen) |s| {
                if (s[i] < how) s[i] = how;
            }
        }
    }
    return retval;
}

fn matchAttrs(it: *const Item, path: []const u8) bool {
    const attr = @import("attr.zig");
    var names: std.ArrayList([]const u8) = .empty;
    for (it.attr_match) |am| names.append(gpa, am.name) catch util.oom();
    const vals = attr.check(path, names.items);
    for (it.attr_match, 0..) |am, i| {
        const ok = switch (vals[i]) {
            .set => am.mode == .set,
            .unset => am.mode == .unset,
            .unspecified => am.mode == .unspecified,
            .value => |v| am.mode == .value and util.eql(am.value, v),
        };
        if (!ok) return false;
    }
    return true;
}

var g_literal: ?bool = null;
var g_glob: ?bool = null;
var g_noglob: ?bool = null;
var g_icase: ?bool = null;

fn envBool(name: []const u8) bool {
    const v = os.getenv(name) orelse return false;
    return @import("config.zig").parseBool(v) orelse false;
}
fn globalLiteral() bool {
    if (g_literal == null) g_literal = envBool("GIT_LITERAL_PATHSPECS");
    return g_literal.?;
}
fn globalGlob() bool {
    if (g_glob == null) g_glob = envBool("GIT_GLOB_PATHSPECS");
    return g_glob.?;
}
fn globalNoglob() bool {
    if (g_noglob == null) g_noglob = envBool("GIT_NOGLOB_PATHSPECS");
    return g_noglob.?;
}
fn globalIcase() bool {
    if (g_icase == null) g_icase = envBool("GIT_ICASE_PATHSPECS");
    return g_icase.?;
}

/// Reset cached env lookups (after commands set GIT_*_PATHSPECS, e.g. --literal-pathspecs).
pub fn resetGlobals() void {
    g_literal = null;
    g_glob = null;
    g_noglob = null;
    g_icase = null;
}

fn globalMagic(element_magic: u32) u32 {
    var m: u32 = 0;
    if (globalLiteral()) m |= MAGIC_LITERAL;
    if (globalGlob() and element_magic & MAGIC_LITERAL == 0) m |= MAGIC_GLOB;
    if (globalGlob() and globalNoglob()) util.die("global 'glob' and 'noglob' pathspec settings are incompatible", .{});
    if (globalIcase()) m |= MAGIC_ICASE;
    if (m & MAGIC_LITERAL != 0 and m & ~MAGIC_LITERAL != 0)
        util.die("global 'literal' pathspec setting is incompatible with all other global pathspec settings", .{});
    if (globalNoglob() and element_magic & MAGIC_GLOB == 0) m |= MAGIC_LITERAL;
    return m;
}

/// length of the leading part without glob special chars (simple_length)
pub fn simpleLength(s: []const u8) usize {
    for (s, 0..) |ch, i| {
        if (ch == '*' or ch == '?' or ch == '[' or ch == '\\') return i;
    }
    return s.len;
}

pub fn noWildcard(s: []const u8) bool {
    return simpleLength(s) == s.len;
}

fn strcspnEscaped(s: []const u8, stop: []const u8) usize {
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        if (s[i] == '\\' and i + 1 < s.len) {
            i += 1;
            continue;
        }
        if (std.mem.indexOfScalar(u8, stop, s[i]) != null) break;
    }
    return @min(i, s.len);
}

fn attrValueUnescape(v: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (i < v.len) : (i += 1) {
        var ch = v[i];
        if (ch == '\\') {
            if (i + 1 >= v.len) util.die("Escape character '\\' not allowed as last character in attr value", .{});
            i += 1;
            ch = v[i];
        }
        if (!(std.ascii.isAlphanumeric(ch) or ch == ',' or ch == '-' or ch == '_'))
            util.die("cannot use '{c}' for value matching", .{ch});
        util.bufByte(&b, ch);
    }
    return b.items;
}

fn parseAttrMatch(it: *Item, value: []const u8) void {
    if (it.attr_match.len > 0) util.die("Only one 'attr:' specification is allowed.", .{});
    if (value.len == 0) util.die("attr spec must not be empty", .{});
    var l: std.ArrayList(AttrMatch) = .empty;
    var words = std.mem.tokenizeScalar(u8, value, ' ');
    const attr = @import("attr.zig");
    while (words.next()) |w0| {
        var w = w0;
        var am = AttrMatch{ .name = "", .mode = .set };
        if (w[0] == '!') {
            am.mode = .unspecified;
            w = w[1..];
        } else if (w[0] == '-') {
            am.mode = .unset;
            w = w[1..];
        } else if (std.mem.indexOfScalar(u8, w, '=')) |eq| {
            am.mode = .value;
            am.value = attrValueUnescape(w[eq + 1 ..]);
            w = w[0..eq];
        }
        if (!attr.validAttrName(w)) util.die("invalid attribute name {s}", .{w});
        am.name = w;
        l.append(gpa, am) catch util.oom();
    }
    it.attr_match = l.items;
}

const magic_names = [_]struct { bit: u32, mnemonic: u8, name: []const u8 }{
    .{ .bit = MAGIC_FROMTOP, .mnemonic = '/', .name = "top" },
    .{ .bit = MAGIC_LITERAL, .mnemonic = 0, .name = "literal" },
    .{ .bit = MAGIC_GLOB, .mnemonic = 0, .name = "glob" },
    .{ .bit = MAGIC_ICASE, .mnemonic = 0, .name = "icase" },
    .{ .bit = MAGIC_EXCLUDE, .mnemonic = '!', .name = "exclude" },
    .{ .bit = MAGIC_ATTR, .mnemonic = 0, .name = "attr" },
};

fn isPathspecMagic(ch: u8) bool {
    // GIT_PATHSPEC_MAGIC in ctype: !"#%&',-/:;<=>@_`~
    return std.mem.indexOfScalar(u8, "!\"#%&',-/:;<=>@_`~", ch) != null;
}

fn parseLongMagic(magic: *u32, prefix_len: *i64, it: *Item, elem: []const u8) usize {
    var pos: usize = 2;
    while (pos < elem.len and elem[pos] != ')') {
        const rest = elem[pos..];
        const len = strcspnEscaped(rest, ",)");
        const nextat = if (len < rest.len and rest[len] == ',') pos + len + 1 else pos + len;
        defer pos = nextat;
        if (len == 0) continue;
        const word = rest[0..len];
        if (util.startsWith(word, "prefix:")) {
            prefix_len.* = std.fmt.parseInt(i64, word[7..], 10) catch util.die("invalid parameter for pathspec magic 'prefix'", .{});
            continue;
        }
        if (util.startsWith(word, "attr:")) {
            parseAttrMatch(it, word[5..]);
            magic.* |= MAGIC_ATTR;
            continue;
        }
        var found = false;
        for (magic_names) |m| {
            if (util.eql(m.name, word)) {
                magic.* |= m.bit;
                found = true;
                break;
            }
        }
        if (!found) util.die("Invalid pathspec magic '{s}' in '{s}'", .{ word, elem });
    }
    if (pos >= elem.len or elem[pos] != ')') util.die("Missing ')' at the end of pathspec magic in '{s}'", .{elem});
    return pos + 1;
}

fn parseShortMagic(magic: *u32, elem: []const u8) usize {
    var pos: usize = 1;
    while (pos < elem.len and elem[pos] != ':') : (pos += 1) {
        const ch = elem[pos];
        if (ch == '^') {
            magic.* |= MAGIC_EXCLUDE;
            continue;
        }
        if (!isPathspecMagic(ch)) break;
        var found = false;
        for (magic_names) |m| {
            if (m.mnemonic == ch) {
                magic.* |= m.bit;
                found = true;
                break;
            }
        }
        if (!found) util.die("Unimplemented pathspec magic '{c}' in '{s}'", .{ ch, elem });
    }
    if (pos < elem.len and elem[pos] == ':') pos += 1;
    return pos;
}

/// normalize_path_copy_len for relative paths; adjusts prefix_len. null on escaping above root.
fn normalizeLen(src: []const u8, prefix_len: ?*usize) ?[]u8 {
    var dst: util.Buf = .empty;
    var i: usize = 0;
    var absolute = false;
    if (src.len > 0 and src[0] == '/') {
        util.bufByte(&dst, '/');
        absolute = true;
        i = 1;
    }
    const dst0 = dst.items.len;
    while (i < src.len and src[i] == '/') i += 1;
    while (true) {
        const ch: u8 = if (i < src.len) src[i] else 0;
        var up = false;
        if (ch == '.') {
            const c1: u8 = if (i + 1 < src.len) src[i + 1] else 0;
            if (c1 == 0) {
                i += 1;
            } else if (c1 == '/') {
                i += 2;
                while (i < src.len and src[i] == '/') i += 1;
                continue;
            } else if (c1 == '.') {
                const c2: u8 = if (i + 2 < src.len) src[i + 2] else 0;
                if (c2 == 0) {
                    i += 2;
                    up = true;
                } else if (c2 == '/') {
                    i += 3;
                    while (i < src.len and src[i] == '/') i += 1;
                    up = true;
                }
            }
        }
        if (up) {
            // strip last component
            var d = dst.items.len;
            if (d == 0) return null;
            d -= 1; // trailing '/'
            if (d <= dst0) return null;
            while (dst0 < d and dst.items[d - 1] != '/') d -= 1;
            dst.items.len = d;
            if (prefix_len) |pl| {
                if (pl.* > d - dst0) pl.* = d - dst0;
            }
            continue;
        }
        // copy up to next '/'
        while (i < src.len and src[i] != '/') : (i += 1) util.bufByte(&dst, src[i]);
        if (i < src.len and src[i] == '/') {
            util.bufByte(&dst, '/');
            while (i < src.len and src[i] == '/') i += 1;
        } else break;
    }
    return dst.items;
}

/// prefix_path_gently
pub fn prefixPathGently(prefix: []const u8, prefixlen: *usize, path: []const u8) ?[]const u8 {
    if (path.len > 0 and path[0] == '/') {
        prefixlen.* = 0;
        const n = normalizeLen(path, null) orelse return null;
        return absInsideRepo(n);
    }
    const joined = util.concat(&.{ prefix[0..prefixlen.*], path });
    return normalizeLen(joined, prefixlen);
}

fn absInsideRepo(path: []const u8) ?[]const u8 {
    const r = repo_mod.repo_ orelse return null;
    const wt = r.work_tree orelse return null;
    if (util.startsWith(path, wt)) {
        if (path.len > wt.len and path[wt.len] == '/') return path[wt.len + 1 ..];
        if (path.len == wt.len) return "";
        if (wt.len > 0 and wt[wt.len - 1] == '/') return path[wt.len..];
    }
    // check each level with realpath
    var i: usize = 1;
    while (i < path.len) : (i += 1) {
        if (path[i] == '/') {
            if (os.realPath(path[0..i])) |rp| {
                if (util.eql(rp, wt)) return path[i + 1 ..];
            }
        }
    }
    if (os.realPath(path)) |rp| {
        if (util.eql(rp, wt)) return "";
    }
    return null;
}

fn initItem(it: *Item, flags: Flags, prefix: []const u8, prefixlen_in: usize, elt: []const u8) void {
    var magic: u32 = 0;
    var element_magic: u32 = 0;
    var copyfrom = elt;
    var pathspec_prefix: i64 = -1;
    var prefixlen = prefixlen_in;
    it.* = .{ .match = "", .original = elt, .nowildcard_len = 0 };
    if (flags.literal) {
        magic = MAGIC_LITERAL;
    } else {
        if (elt.len > 0 and elt[0] == ':' and !globalLiteral()) {
            const p = if (elt.len > 1 and elt[1] == '(') parseLongMagic(&element_magic, &pathspec_prefix, it, elt) else parseShortMagic(&element_magic, elt);
            copyfrom = elt[p..];
        }
        magic |= element_magic;
        magic |= globalMagic(element_magic);
    }
    it.magic = magic;
    if (magic & MAGIC_LITERAL != 0 and magic & MAGIC_GLOB != 0)
        util.die("{s}: 'literal' and 'glob' are incompatible", .{elt});

    var match: []const u8 = undefined;
    if (pathspec_prefix >= 0) {
        match = util.dupe(copyfrom);
        prefixlen = @intCast(pathspec_prefix);
    } else if (magic & MAGIC_FROMTOP != 0) {
        match = util.dupe(copyfrom);
        prefixlen = 0;
    } else {
        match = prefixPathGently(prefix, &prefixlen, copyfrom) orelse {
            if (flags.no_repository or repo_mod.repo_ == null)
                util.die("'{s}' is outside the directory tree", .{copyfrom});
            const r = repo_mod.repo_.?;
            const hint = r.work_tree orelse r.git_dir;
            util.die("{s}: '{s}' is outside repository at '{s}'", .{ elt, copyfrom, absPath(hint) });
        };
    }
    it.match = match;
    it.prefix = @min(prefixlen, match.len);
    if (flags.prefix_origin and !globalLiteral()) {
        var b: util.Buf = .empty;
        if (element_magic == 0) {
            util.bufPrint(&b, ":(prefix:{d})", .{prefixlen});
        } else {
            if (elt.len > 1 and elt[1] != '(') {
                util.bufAppend(&b, ":(");
                for (magic_names) |m| {
                    if (element_magic & m.bit != 0 and m.mnemonic != 0) {
                        if (b.items[b.items.len - 1] != '(') util.bufByte(&b, ',');
                        util.bufAppend(&b, m.name);
                    }
                }
            } else {
                const close = std.mem.indexOfScalar(u8, elt, ')').?;
                util.bufAppend(&b, elt[0..close]);
            }
            util.bufPrint(&b, ",prefix:{d})", .{prefixlen});
        }
        util.bufAppend(&b, match);
        it.original = b.items;
    } else it.original = elt;

    if (magic & MAGIC_LITERAL != 0) {
        it.nowildcard_len = match.len;
    } else {
        it.nowildcard_len = simpleLength(match);
        if (it.nowildcard_len < it.prefix) it.nowildcard_len = it.prefix;
    }
    if (magic & MAGIC_GLOB == 0) {
        if (it.nowildcard_len < match.len and match[it.nowildcard_len] == '*' and noWildcard(match[it.nowildcard_len + 1 ..]))
            it.onestar = true;
    }
    it.literal = magic & MAGIC_LITERAL != 0;
    it.glob = magic & MAGIC_GLOB != 0;
    it.icase = magic & MAGIC_ICASE != 0;
    it.exclude = magic & MAGIC_EXCLUDE != 0;
    it.top = magic & MAGIC_FROMTOP != 0;
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return p;
    return os.realPath(p) orelse util.joinPath(os.getcwd(), p);
}

pub fn magicNames(magic: u32) []const u8 {
    var b: util.Buf = .empty;
    for (magic_names) |m| {
        if (magic & m.bit == 0) continue;
        if (b.items.len > 0) util.bufAppend(&b, ", ");
        if (m.mnemonic != 0) {
            util.bufPrint(&b, "'{s}' (mnemonic: '{c}')", .{ m.name, m.mnemonic });
        } else util.bufPrint(&b, "'{s}'", .{m.name});
    }
    return b.items;
}

/// Parse pathspec arguments relative to `prefix` (e.g. "sub/" or "").
pub fn parse(prefix: []const u8, args: []const []const u8, flags: Flags) Pathspec {
    var ps = Pathspec{};
    if (flags.maxdepth_valid) ps.magic |= MAGIC_MAXDEPTH;
    if (args.len == 0) {
        if (flags.prefer_cwd and prefix.len > 0) {
            const items = gpa.alloc(Item, 1) catch util.oom();
            items[0] = .{ .match = prefix, .original = prefix, .nowildcard_len = prefix.len, .prefix = prefix.len };
            ps.items = items;
        }
        return ps;
    }
    for (args) |a| {
        if (a.len == 0) util.die("empty string is not a valid pathspec. please use . instead if you meant to match all paths", .{});
    }
    var items: std.ArrayList(Item) = .empty;
    var nr_exclude: usize = 0;
    for (args) |arg| {
        var it: Item = undefined;
        initItem(&it, flags, prefix, prefix.len, arg);
        if (it.magic & MAGIC_EXCLUDE != 0) nr_exclude += 1;
        var mask = flags.magic_mask;
        if (flags.no_magic) mask |= ~MAGIC_LITERAL & 0x7f & ~MAGIC_MAXDEPTH;
        if (it.magic & mask != 0)
            util.die("{s}: pathspec magic not supported by this command: {s}", .{ arg, magicNames(it.magic & mask) });
        if (flags.symlink_leading_path and hasSymlinkLeadingPath(it.match))
            util.die("pathspec '{s}' is beyond a symbolic link", .{arg});
        if (it.nowildcard_len < it.match.len) ps.has_wildcard = true;
        ps.magic |= it.magic;
        items.append(gpa, it) catch util.oom();
    }
    if (nr_exclude == args.len) {
        var it: Item = undefined;
        const plen = if (flags.prefer_cwd) prefix.len else 0;
        initItem(&it, .{}, prefix, plen, ".");
        items.append(gpa, it) catch util.oom();
    }
    ps.items = items.items;
    if (ps.magic & MAGIC_MAXDEPTH != 0) {
        std.mem.sort(Item, ps.items, {}, struct {
            fn lt(_: void, a: Item, b: Item) bool {
                return std.mem.order(u8, a.match, b.match) == .lt;
            }
        }.lt);
    }
    return ps;
}

/// has_symlink_leading_path: does any leading directory of `path` resolve to a symlink?
pub fn hasSymlinkLeadingPath(path: []const u8) bool {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, path, i, '/')) |slash| {
        const st = os.lstatPath(path[0..slash]) orelse return false;
        if (st.isLnk()) return true;
        if (!st.isDir()) return false;
        i = slash + 1;
    }
    return false;
}

/// Read pathspecs from a file (--pathspec-from-file), honoring quoting / NUL termination.
pub fn readPathspecFile(file: []const u8, nul_term: bool) [][]const u8 {
    const data = if (util.eql(file, "-")) (os.readAllFd(0) catch util.die("could not read from stdin", .{})) else (os.readFile(file) orelse util.dieErrno("could not open '{s}' for reading", .{file}));
    var l: std.ArrayList([]const u8) = .empty;
    const sep: u8 = if (nul_term) 0 else '\n';
    var it = std.mem.splitScalar(u8, data, sep);
    while (it.next()) |line0| {
        var line = line0;
        if (it.index == null and line.len == 0) break;
        if (!nul_term and line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
        if (!nul_term and line.len > 0 and line[0] == '"') {
            const u = util.cunquote(line) orelse util.die("line is badly quoted: {s}", .{line});
            line = u.value;
        }
        l.append(gpa, line) catch util.oom();
    }
    return l.items;
}

/// git_fnmatch() for tree-diff's tree_entry_interesting (added for diff/treediff.zig)
pub fn gitFnmatchItem(it: *const Item, pattern: []const u8, string: []const u8, prefix: usize) bool {
    return gitFnmatch(it, pattern, string, prefix);
}

/// match_pathspec_attrs() (added for diff/treediff.zig)
pub fn matchItemAttrs(it: *const Item, path: []const u8) bool {
    return matchAttrs(it, path);
}
