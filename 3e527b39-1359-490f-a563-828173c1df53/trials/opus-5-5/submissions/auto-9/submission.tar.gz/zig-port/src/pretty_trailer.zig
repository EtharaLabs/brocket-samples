//! Trailer parsing and formatting (port of the parsing half of trailer.c):
//! trailer configuration (trailer.separators, trailer.<name>.key), trailer block
//! detection, parse_trailers, format_trailers and format_trailers_from_commit.

const std = @import("std");
const util = @import("util.zig");
const repo_mod = @import("repo.zig");
const gpa = util.gpa;

pub const Options = struct {
    in_place: bool = false,
    trim_empty: bool = false,
    only_trailers: bool = false,
    only_input: bool = false,
    unfold: bool = false,
    no_divider: bool = false,
    key_only: bool = false,
    value_only: bool = false,
    canonicalize: bool = false,
    separator: ?[]const u8 = null,
    key_value_separator: ?[]const u8 = null,
    /// filter on keys: returns true to keep
    filter: ?*const fn (key: []const u8, data: ?*anyopaque) bool = null,
    filter_data: ?*anyopaque = null,
};

pub const ConfInfo = struct {
    name: []const u8,
    key: ?[]const u8 = null,
    command: ?[]const u8 = null,
    cmd: ?[]const u8 = null,
    where: ?[]const u8 = null,
    if_exists: ?[]const u8 = null,
    if_missing: ?[]const u8 = null,
};

pub const Item = struct {
    /// null for non-trailer lines
    token: ?[]const u8,
    value: []const u8,
};

pub const Block = struct {
    blank_line_before_trailer: bool,
    start: usize,
    end: usize,
    trailers: [][]const u8,
};

var configured = false;
pub var separators: []const u8 = ":";
pub var conf_items: std.ArrayList(ConfInfo) = .empty;

const git_generated_prefixes = [_][]const u8{ "Signed-off-by: ", "(cherry picked from commit " };
const cut_line = "------------------------ >8 ------------------------";

pub fn commentLineStr() []const u8 {
    const v = repo_mod.cfg.get("core.commentstring") orelse repo_mod.cfg.get("core.commentchar") orelse return "#";
    if (v.len == 0 or std.ascii.eqlIgnoreCase(v, "auto")) return "#";
    return v;
}

fn getConfItem(name: []const u8) *ConfInfo {
    for (conf_items.items) |*it| {
        if (std.ascii.eqlIgnoreCase(it.name, name)) return it;
    }
    conf_items.append(gpa, .{ .name = name }) catch util.oom();
    return &conf_items.items[conf_items.items.len - 1];
}

/// trailer_config_init
pub fn configInit() void {
    if (configured) return;
    configured = true;
    for (repo_mod.cfg.entries.items) |e| {
        const item = util.skipPrefix(e.key, "trailer.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, item, '.') orelse {
            if (util.eql(item, "separators")) {
                if (e.value) |v| separators = v;
            }
            continue;
        };
        const variable = item[dot + 1 ..];
        const name = item[0..dot];
        const known = [_][]const u8{ "key", "command", "cmd", "where", "ifexists", "ifmissing" };
        var found = false;
        for (known) |k| {
            if (util.eql(k, variable)) found = true;
        }
        if (!found) continue;
        const ci = getConfItem(name);
        const v = e.value orelse continue;
        if (util.eql(variable, "key")) {
            ci.key = v;
        } else if (util.eql(variable, "command")) {
            ci.command = v;
        } else if (util.eql(variable, "cmd")) {
            ci.cmd = v;
        } else if (util.eql(variable, "where")) {
            ci.where = v;
        } else if (util.eql(variable, "ifexists")) {
            ci.if_exists = v;
        } else if (util.eql(variable, "ifmissing")) {
            ci.if_missing = v;
        }
    }
}

fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r';
}

fn at(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

fn tokenLenWithoutSeparator(token: []const u8) usize {
    var len = token.len;
    while (len > 0 and !std.ascii.isAlphanumeric(token[len - 1])) len -= 1;
    return len;
}

fn strncasecmpEq(a: []const u8, b: []const u8, n: usize) bool {
    // strncasecmp(a, b, n) == 0 with C string semantics (stop at NUL / end)
    var i: usize = 0;
    while (i < n) : (i += 1) {
        const ca = std.ascii.toLower(at(a, i));
        const cb = std.ascii.toLower(at(b, i));
        if (ca != cb) return false;
        if (ca == 0) return true;
    }
    return true;
}

fn tokenMatchesItem(tok: []const u8, item: *const ConfInfo, tok_len: usize) bool {
    if (strncasecmpEq(tok, item.name, tok_len)) return true;
    if (item.key) |k| return strncasecmpEq(tok, k, tok_len);
    return false;
}

/// find_separator: position of the separator, or null (not well-formed).
/// Returns 0 if the line starts with a separator.
pub fn findSeparator(line: []const u8, seps: []const u8) ?usize {
    var whitespace_found = false;
    var i: usize = 0;
    while (i < line.len and line[i] != 0) : (i += 1) {
        const c = line[i];
        if (std.mem.indexOfScalar(u8, seps, c) != null) {
            if (!whitespace_found and util.startsWith(line[i..], "://")) return null;
            return i;
        }
        if (!whitespace_found and (std.ascii.isAlphanumeric(c) or c == '-')) continue;
        if (i != 0 and (c == ' ' or c == '\t')) {
            whitespace_found = true;
            continue;
        }
        break;
    }
    return null;
}

/// parse_trailer: split a trailer line into (token, value), canonicalizing the
/// token according to trailer.<name>.key.
pub fn parseTrailer(trailer: []const u8, separator_pos: ?usize) struct { tok: []const u8, val: []const u8, conf: ?*const ConfInfo } {
    var tok: []const u8 = undefined;
    var val: []const u8 = "";
    if (separator_pos) |sp| {
        tok = ctrim(trailer[0..sp]);
        val = ctrim(trailer[sp + 1 ..]);
    } else {
        tok = ctrim(trailer);
    }
    const tok_len = tokenLenWithoutSeparator(tok);
    var conf: ?*const ConfInfo = null;
    for (conf_items.items) |*item| {
        if (tokenMatchesItem(tok, item, tok_len)) {
            conf = item;
            tok = item.key orelse tok;
            break;
        }
    }
    return .{ .tok = tok, .val = val, .conf = conf };
}

fn nextLine(s: []const u8, pos: usize) usize {
    const nl = std.mem.indexOfScalarPos(u8, s, pos, '\n') orelse return s.len;
    return nl + 1;
}

/// start of the last line in buf[0..len]; null if len == 0
fn lastLine(buf: []const u8, len: usize) ?usize {
    if (len == 0) return null;
    if (len == 1) return 0;
    var i: isize = @as(isize, @intCast(len)) - 2;
    while (i >= 0) : (i -= 1) {
        if (buf[@intCast(i)] == '\n') return @as(usize, @intCast(i)) + 1;
    }
    return 0;
}

/// is_blank_line on the line starting at buf[pos]
fn isBlankLine(buf: []const u8, pos: usize) bool {
    var i = pos;
    while (i < buf.len and buf[i] != '\n' and isSpace(buf[i])) i += 1;
    return i >= buf.len or buf[i] == '\n';
}

fn wtStatusLocateEnd(s: []const u8, len0: usize) usize {
    var len = len0;
    const cl = commentLineStr();
    const pattern = util.concat(&.{ "\n", cl, " ", cut_line });
    if (util.startsWith(s, pattern[1..])) {
        len = 0;
    } else if (std.mem.indexOf(u8, s, pattern)) |p| {
        const newlen = p + 1;
        if (newlen < len) len = newlen;
    }
    return len;
}

/// ignored_log_message_bytes (commit.c)
pub fn ignoredLogMessageBytes(buf: []const u8, len: usize) usize {
    var boc: usize = 0;
    var bol: usize = 0;
    var in_old_conflicts_block = false;
    const cutoff = wtStatusLocateEnd(buf[0..len], len);
    const cl = commentLineStr();
    while (bol < cutoff) {
        const next = if (std.mem.indexOfScalarPos(u8, buf[0..len], bol, '\n')) |n| n + 1 else len;
        if (util.startsWith(buf[bol..cutoff], cl) or buf[bol] == '\n') {
            if (boc == 0) boc = bol;
        } else if (util.startsWith(buf[bol..len], "Conflicts:\n")) {
            in_old_conflicts_block = true;
            if (boc == 0) boc = bol;
        } else if (in_old_conflicts_block and buf[bol] == '\t') {
            // a pathname in the conflicts block
        } else if (boc != 0) {
            boc = 0;
            in_old_conflicts_block = false;
        }
        bol = next;
    }
    return if (boc != 0) len - boc else len - cutoff;
}

fn findEndOfLogMessage(input: []const u8, no_divider: bool) usize {
    var end = input.len;
    if (!no_divider) {
        var s: usize = 0;
        while (s < input.len) : (s = nextLine(input, s)) {
            if (util.startsWith(input[s..], "---") and isSpace(at(input, s + 3))) {
                end = s;
                break;
            }
        }
    }
    return end - ignoredLogMessageBytes(input, end);
}

fn findTrailerBlockStart(buf: []const u8, len: usize) usize {
    const cl = commentLineStr();
    var only_spaces = true;
    var recognized_prefix = false;
    var trailer_lines: i32 = 0;
    var non_trailer_lines: i32 = 0;
    var possible_continuation_lines: i32 = 0;

    var s: usize = 0;
    while (s < len) : (s = nextLine(buf[0..len], s)) {
        if (util.startsWith(buf[s..len], cl)) continue;
        if (isBlankLine(buf, s)) break;
    }
    const end_of_title = s;

    var lopt = lastLine(buf, len);
    outer: while (lopt) |l| : (lopt = lastLine(buf, l)) {
        if (l < end_of_title) break;
        const bol = buf[l..];
        if (util.startsWith(buf[l..len], cl)) {
            non_trailer_lines += possible_continuation_lines;
            possible_continuation_lines = 0;
            continue;
        }
        if (isBlankLine(buf, l)) {
            if (only_spaces) continue;
            non_trailer_lines += possible_continuation_lines;
            if (recognized_prefix and trailer_lines * 3 >= non_trailer_lines)
                return nextLine(buf, l);
            if (trailer_lines != 0 and non_trailer_lines == 0)
                return nextLine(buf, l);
            return len;
        }
        only_spaces = false;

        for (git_generated_prefixes) |p| {
            if (util.startsWith(bol, p)) {
                trailer_lines += 1;
                possible_continuation_lines = 0;
                recognized_prefix = true;
                continue :outer;
            }
        }

        const sp = findSeparator(bol, separators);
        if (sp != null and sp.? >= 1 and !isSpace(bol[0])) {
            trailer_lines += 1;
            possible_continuation_lines = 0;
            if (recognized_prefix) continue;
            for (conf_items.items) |*item| {
                if (tokenMatchesItem(bol, item, sp.?)) {
                    recognized_prefix = true;
                    break;
                }
            }
        } else if (isSpace(at(bol, 0))) {
            possible_continuation_lines += 1;
        } else {
            non_trailer_lines += 1;
            non_trailer_lines += possible_continuation_lines;
            possible_continuation_lines = 0;
        }
        if (l == 0) break;
    }
    return len;
}

fn endsWithBlankLine(buf: []const u8, len: usize) bool {
    const ll = lastLine(buf, len) orelse return false;
    return isBlankLine(buf, ll);
}

/// unfold_value
pub fn unfoldValue(val: []const u8) []const u8 {
    var out: util.Buf = .empty;
    var i: usize = 0;
    while (i < val.len) {
        var c = val[i];
        i += 1;
        if (c == '\n') {
            while (i < val.len and isSpace(val[i])) i += 1;
            c = ' ';
        }
        out.append(gpa, c) catch util.oom();
    }
    return ctrim(out.items);
}

/// trailer_block_get
pub fn blockGet(opts: *const Options, str: []const u8) Block {
    configInit();
    const end_of_log = findEndOfLogMessage(str, opts.no_divider);
    const start = findTrailerBlockStart(str, end_of_log);

    var list: std.ArrayList([]const u8) = .empty;
    var last: ?usize = null;
    const region = str[start..end_of_log];
    var pos: usize = 0;
    while (pos < region.len) {
        const e = nextLine(region, pos);
        const line = region[pos..e];
        pos = e;
        if (last != null and isSpace(line[0])) {
            list.items[last.?] = util.concat(&.{ list.items[last.?], line });
            continue;
        }
        list.append(gpa, line) catch util.oom();
        const sp = findSeparator(line, separators);
        last = if (sp != null and sp.? >= 1) list.items.len - 1 else null;
    }
    return .{
        .blank_line_before_trailer = endsWithBlankLine(str, start),
        .start = start,
        .end = end_of_log,
        .trailers = list.items,
    };
}

/// parse_trailers: returns the block and the parsed items.
pub fn parseTrailers(opts: *const Options, str: []const u8, items: *std.ArrayList(Item)) Block {
    const block = blockGet(opts, str);
    const cl = commentLineStr();
    for (block.trailers) |trailer| {
        if (util.startsWith(trailer, cl)) continue;
        const sp = findSeparator(trailer, separators);
        if (sp != null and sp.? >= 1) {
            const p = parseTrailer(trailer, sp);
            var val = p.val;
            if (opts.unfold) val = unfoldValue(val);
            items.append(gpa, .{ .token = p.tok, .value = val }) catch util.oom();
        } else if (!opts.only_trailers) {
            var v = trailer;
            if (util.endsWith(v, "\n")) v = v[0 .. v.len - 1];
            items.append(gpa, .{ .token = null, .value = v }) catch util.oom();
        }
    }
    return block;
}

fn lastNonSpaceChar(s: []const u8) u8 {
    var i = s.len;
    while (i > 0) {
        i -= 1;
        if (!isSpace(s[i])) return s[i];
    }
    return 0;
}

fn rtrimBuf(b: *util.Buf) void {
    while (b.items.len > 0 and isSpace(b.items[b.items.len - 1])) b.items.len -= 1;
}

/// format_trailers
pub fn formatTrailers(opts: *const Options, items: []const Item, out: *util.Buf) void {
    const origlen = out.items.len;
    for (items) |item| {
        if (item.token) |tok| {
            if (opts.trim_empty and item.value.len == 0) continue;
            const keep = if (opts.filter) |f| f(tok, opts.filter_data) else true;
            if (!keep) continue;
            if (opts.separator) |s| {
                if (out.items.len != origlen) util.bufAppend(out, s);
            }
            if (!opts.value_only) util.bufAppend(out, tok);
            if (!opts.key_only and !opts.value_only) {
                if (opts.key_value_separator) |kvs| {
                    util.bufAppend(out, kvs);
                } else {
                    const c = lastNonSpaceChar(tok);
                    if (c != 0 and std.mem.indexOfScalar(u8, separators, c) == null) {
                        util.bufByte(out, separators[0]);
                        util.bufByte(out, ' ');
                    }
                }
            }
            if (!opts.key_only) util.bufAppend(out, item.value);
            if (opts.separator == null) util.bufByte(out, '\n');
        } else if (!opts.only_trailers) {
            if (opts.separator) |s| {
                if (out.items.len != origlen) util.bufAppend(out, s);
            }
            util.bufAppend(out, item.value);
            if (opts.separator != null) rtrimBuf(out) else util.bufByte(out, '\n');
        }
    }
}

/// format_trailers_from_commit: msg is the commit message (starting at the subject).
pub fn formatTrailersFromCommit(opts: *const Options, msg: []const u8, out: *util.Buf) void {
    var items: std.ArrayList(Item) = .empty;
    const block = parseTrailers(opts, msg, &items);
    if (!opts.only_trailers and !opts.unfold and opts.filter == null and
        opts.separator == null and !opts.key_only and !opts.value_only and
        opts.key_value_separator == null)
    {
        util.bufAppend(out, msg[block.start..block.end]);
    } else formatTrailers(opts, items.items, out);
}

/// trailer iterator: all trailers of msg (values always unfolded).
pub const Iterator = struct {
    block: Block,
    cur: usize = 0,
    raw: []const u8 = "",
    key: []const u8 = "",
    val: []const u8 = "",

    pub fn init(msg: []const u8) Iterator {
        const opts = Options{ .no_divider = true };
        return .{ .block = blockGet(&opts, msg) };
    }
    pub fn next(self: *Iterator) bool {
        if (self.cur >= self.block.trailers.len) return false;
        const line = self.block.trailers[self.cur];
        self.cur += 1;
        self.raw = line;
        const sp = findSeparator(line, separators);
        const p = parseTrailer(line, sp);
        self.key = p.tok;
        self.val = unfoldValue(p.val);
        return true;
    }
};

fn ctrim(s: []const u8) []const u8 {
    return std.mem.trim(u8, s, " \t\r\n");
}
