//! Port of line-range.c (-L argument parsing for blame and log) plus the
//! range_set helpers from line-log.c.

const std = @import("std");
const util = @import("util.zig");
const regex = @import("regex.zig");
const xdiff = @import("xdiff.zig");
const userdiff = @import("userdiff.zig");

/// Access to the lines of a buffer: `starts` has lines+1 entries, the last
/// being buf.len.
pub const Lines = struct {
    buf: []const u8,
    starts: []const usize,

    pub fn count(self: Lines) i64 {
        return @as(i64, @intCast(self.starts.len)) - 1;
    }
    /// offset of line n (0-based); clamps to the buffer end
    pub fn nth(self: Lines, n: i64) usize {
        if (n < 0) return 0;
        const u: usize = @intCast(n);
        if (u >= self.starts.len) return self.buf.len;
        return self.starts[u];
    }
};

/// find_line_starts: offsets of each line plus a final entry at buf.len
pub fn findLineStarts(buf: []const u8) []usize {
    var l: std.ArrayList(usize) = .empty;
    var i: usize = 0;
    while (i < buf.len) {
        l.append(util.gpa, i) catch util.oom();
        if (std.mem.indexOfScalarPos(u8, buf, i, '\n')) |nl| i = nl + 1 else i = buf.len;
    }
    l.append(util.gpa, buf.len) catch util.oom();
    return l.items;
}

/// strtol(…, 10): returns value and number of bytes consumed (0 if none)
fn strtol(s: []const u8) struct { v: i64, n: usize } {
    var i: usize = 0;
    while (i < s.len and (s[i] == ' ' or (s[i] >= 9 and s[i] <= 13))) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    const ds = i;
    var v: i64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) {
        v = v *% 10 +% (s[i] - '0');
    }
    if (i == ds) return .{ .v = 0, .n = 0 };
    return .{ .v = if (neg) -v else v, .n = i };
}

/// parse_loc; returns the unparsed remainder
fn parseLoc(spec0: []const u8, ln: ?Lines, lines: i64, begin0: i64, ret: ?*i64) []const u8 {
    var spec = spec0;
    var begin = begin0;
    if (1 <= begin and spec.len > 0 and (spec[0] == '+' or spec[0] == '-')) {
        const r = strtol(spec[1..]);
        if (r.n != 0) {
            const term = spec[1 + r.n ..];
            const out = ret orelse return term;
            var num = r.v;
            if (num == 0) util.die("-L invalid empty range", .{});
            if (spec[0] == '-') num = 0 - num;
            if (0 < num)
                out.* = begin + num - 2
            else if (num == 0)
                out.* = begin
            else
                out.* = if (begin + num > 0) begin + num else 1;
            return term;
        }
        return spec;
    }
    const r = strtol(spec);
    if (r.n != 0) {
        if (ret) |out| {
            if (r.v <= 0) util.die("-L invalid line number: {d}", .{r.v});
            out.* = r.v;
        }
        return spec[r.n..];
    }
    if (begin < 0) {
        if (spec.len == 0 or spec[0] != '^') {
            begin = -begin;
        } else {
            begin = 1;
            spec = spec[1..];
        }
    }
    if (spec.len == 0 or spec[0] != '/') return spec;
    var t: usize = 1;
    while (t < spec.len and spec[t] != '/') : (t += 1) {
        if (spec[t] == '\\') t += 1;
    }
    if (t >= spec.len or spec[t] != '/') return spec;
    const out = ret orelse return spec[t + 1 ..];
    const l = ln.?;
    const pattern = spec[1..t];
    begin -= 1;
    var line = l.nth(begin);
    switch (regex.Regex.compile(pattern, .{ .newline = true })) {
        .ok => |re| {
            if (re.find(l.buf[line..], false)) |m| {
                const cp = line + @as(usize, @intCast(m.so));
                while (true) {
                    const cont = begin < lines;
                    begin += 1;
                    if (!cont) break;
                    const nline = l.nth(begin);
                    if (line <= cp and cp < nline) break;
                    line = nline;
                }
                out.* = begin;
                return spec[t + 1 ..];
            }
            util.die("-L parameter '{s}' starting at line {d}: No match", .{ pattern, begin + 1 });
        },
        .err => |e| util.die("-L parameter '{s}' starting at line {d}: {s}", .{ pattern, begin + 1, e }),
    }
}

fn matchFuncname(ff: ?xdiff.FindFunc, line: []const u8) bool {
    if (ff) |f| {
        var b: [1]u8 = undefined;
        return f.func(f.ctx, line, &b) >= 0;
    }
    if (line.len == 0) return false;
    const c = line[0];
    return std.ascii.isAlphabetic(c) or c == '_' or c == '$';
}

fn findFuncnameMatchingRegexp(ff: ?xdiff.FindFunc, buf: []const u8, start0: usize, re: regex.Regex) ?usize {
    var start = start0;
    while (start < buf.len and buf[start] != 0) {
        const m = re.find(buf[start..], false) orelse return null;
        var bol = start + @as(usize, @intCast(m.so));
        var eol = start + @as(usize, @intCast(m.eo));
        while (bol > start) {
            bol -= 1;
            if (buf[bol] == '\n') break;
        }
        if (buf[bol] == '\n') bol += 1;
        while (eol < buf.len and buf[eol] != '\n') eol += 1;
        if (eol < buf.len and buf[eol] == '\n') eol += 1;
        if (matchFuncname(ff, buf[bol..eol])) return bol;
        start = eol;
    }
    return null;
}

fn funcnameFindFunc(path: ?[]const u8) ?xdiff.FindFunc {
    const drv = userdiff.findByPath(path) orelse return null;
    const pat = drv.funcname orelse return null;
    const rf = xdiff.RegexFindFunc.init(pat, .{ .extended = drv.funcname_extended, .icase = drv.funcname_icase, .newline = true });
    return rf.findFunc();
}

/// parse_range_funcname; returns the remainder or null on syntax error
fn parseRangeFuncname(arg0: []const u8, ln: ?Lines, lines: i64, anchor0: i64, begin: ?*i64, end: ?*i64, path: ?[]const u8) ?[]const u8 {
    var arg = arg0;
    var anchor = anchor0;
    if (arg.len > 0 and arg[0] == '^') {
        anchor = 1;
        arg = arg[1..];
    }
    var t: usize = 1;
    while (t < arg.len and arg[t] != ':') {
        if (arg[t] == '\\' and t + 1 < arg.len) t += 1;
        t += 1;
    }
    if (t == 1) return null;
    const b = begin orelse return arg[t..];
    const e = end.?;
    const l = ln.?;
    const pattern = arg[1..t];
    anchor -= 1;
    const start = l.nth(anchor);
    const ff = funcnameFindFunc(path);
    const re = switch (regex.Regex.compile(pattern, .{ .newline = true })) {
        .ok => |r| r,
        .err => |msg| util.die("-L parameter '{s}': {s}", .{ pattern, msg }),
    };
    const p = findFuncnameMatchingRegexp(ff, l.buf, start, re) orelse
        util.die("-L parameter '{s}' starting at line {d}: no match", .{ pattern, anchor + 1 });
    b.* = 0;
    while (p > l.nth(b.*)) b.* += 1;
    if (b.* >= lines) util.die("-L parameter '{s}' matches at EOF", .{pattern});
    e.* = b.* + 1;
    while (e.* < lines) {
        const bol = l.nth(e.*);
        const eol = l.nth(e.* + 1);
        if (matchFuncname(ff, l.buf[bol..eol])) break;
        e.* += 1;
    }
    b.* += 1;
    return arg[t..];
}

pub const Range = struct { begin: i64, end: i64 };

/// parse_range_arg; returns null on syntax error (caller prints usage)
pub fn parseRangeArg(arg0: []const u8, ln: Lines, anchor0: i64, path: ?[]const u8) ?Range {
    const lines = ln.count();
    var begin: i64 = 0;
    var end: i64 = 0;
    var anchor = anchor0;
    if (anchor < 1) anchor = 1;
    if (anchor > lines) anchor = lines + 1;
    if ((arg0.len > 0 and arg0[0] == ':') or (arg0.len > 1 and arg0[0] == '^' and arg0[1] == ':')) {
        const rest = parseRangeFuncname(arg0, ln, lines, anchor, &begin, &end, path) orelse return null;
        if (rest.len != 0) return null;
        return .{ .begin = begin, .end = end };
    }
    var arg = parseLoc(arg0, ln, lines, -anchor, &begin);
    if (arg.len > 0 and arg[0] == ',')
        arg = parseLoc(arg[1..], ln, lines, begin + 1, &end);
    if (arg.len != 0) return null;
    if (begin != 0 and end != 0 and end < begin) std.mem.swap(i64, &begin, &end);
    return .{ .begin = begin, .end = end };
}

/// skip_range_arg: returns the remainder after a range spec (or null)
pub fn skipRangeArg(arg0: []const u8, path: ?[]const u8) ?[]const u8 {
    if ((arg0.len > 0 and arg0[0] == ':') or (arg0.len > 1 and arg0[0] == '^' and arg0[1] == ':'))
        return parseRangeFuncname(arg0, null, 0, 0, null, null, path);
    var arg = parseLoc(arg0, null, 0, -1, null);
    if (arg.len > 0 and arg[0] == ',') arg = parseLoc(arg[1..], null, 0, 0, null);
    return arg;
}

pub const RangeSpan = struct { start: i64, end: i64 };

/// sort_and_merge_range_set
pub fn sortAndMerge(rs: *std.ArrayList(RangeSpan)) void {
    std.mem.sort(RangeSpan, rs.items, {}, struct {
        fn lt(_: void, a: RangeSpan, b: RangeSpan) bool {
            return a.start < b.start;
        }
    }.lt);
    var o: usize = 0;
    for (0..rs.items.len) |i| {
        const r = rs.items[i];
        if (r.start == r.end) continue;
        if (o > 0 and r.start <= rs.items[o - 1].end) {
            if (rs.items[o - 1].end < r.end) rs.items[o - 1].end = r.end;
        } else {
            rs.items[o] = r;
            o += 1;
        }
    }
    rs.items.len = o;
}
