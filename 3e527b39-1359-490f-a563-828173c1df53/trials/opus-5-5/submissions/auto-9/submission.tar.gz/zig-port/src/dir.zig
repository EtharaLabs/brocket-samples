//! Working tree enumeration and ignore rules (port of dir.c, without untracked cache).
//!
//! API (all paths relative to the worktree top; process cwd is the worktree top):
//!
//!   var d = dir.Dir.init();            // empty: no exclude rules, flags = .{}
//!   d.setupStandardExcludes();         // .gitignore per directory, info/exclude, core.excludesFile
//!   d.addPattern("*.o", "--exclude option")   // command line pattern (EXC_CMDL group)
//!   d.addExcludesFile(path)            // patterns from a file (EXC_FILE group), dies if unreadable
//!   d.flags.show_other_directories = true; ...   (see Flags; mirrors DIR_* flags)
//!   _ = d.fill(index.get(), &pathspec);    // fill_directory(): fills d.entries / d.ignored (sorted)
//!   for (d.entries.items) |e| e.name     // directories end with '/'
//!   d.isExcluded(path, &dtype) bool    // is_excluded(); dtype: DT_UNKNOWN/DT_DIR/DT_REG (in-out)
//!   d.lastMatchingPattern(path, &dtype) ?*Pattern  (for check-ignore -v: pattern.list.src, srcpos, original)
//!
//! Convenience:
//!   dir.isIgnored(path, is_dir) bool   // standard excludes, global cached Dir
//!   dir.untracked(.{ .pathspec = &ps, .show_dirs = true, .hide_empty = true, ... }) Result {entries, ignored}
//!   dir.matchBasename/matchPathname/parsePathPattern: used by attr.zig as well.
//!   dir.indexNameIsOther(idx, name) bool
//!   dir.isNonbareRepositoryDir(path) bool
//!   dir.ignoreCase() bool (core.ignorecase)

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const wildmatch = @import("wildmatch.zig");
const pathspec_mod = @import("pathspec.zig");
const index_mod = @import("index.zig");
const gpa = util.gpa;

pub const Pathspec = pathspec_mod.Pathspec;
pub const Index = index_mod.Index;

pub const DT_UNKNOWN: u8 = 0;
pub const DT_DIR: u8 = 4;
pub const DT_REG: u8 = 8;
pub const DT_LNK: u8 = 10;

pub const PATTERN_FLAG_NODIR: u32 = 1;
pub const PATTERN_FLAG_ENDSWITH: u32 = 4;
pub const PATTERN_FLAG_MUSTBEDIR: u32 = 8;
pub const PATTERN_FLAG_NEGATIVE: u32 = 16;

pub const EXC_CMDL = 0;
pub const EXC_DIRS = 1;
pub const EXC_FILE = 2;

pub const Pattern = struct {
    /// pattern without leading '!' and trailing '/'
    pattern: []const u8,
    /// the full original line (after trimming), as shown by check-ignore -v
    original: []const u8,
    nowildcardlen: usize,
    flags: u32,
    /// directory the pattern is relative to ("" or "dir/")
    base: []const u8,
    srcpos: usize,
    list: *PatternList,
};

pub const PatternList = struct {
    patterns: std.ArrayList(*Pattern) = .empty,
    /// source file name (null for command line / unnamed)
    src: ?[]const u8 = null,
};

pub const Entry = struct {
    name: []const u8,
};

pub const Flags = struct {
    show_ignored: bool = false,
    show_other_directories: bool = false,
    hide_empty_directories: bool = false,
    no_gitlinks: bool = false,
    collect_ignored: bool = false,
    show_ignored_too: bool = false,
    collect_killed_only: bool = false,
    keep_untracked_contents: bool = false,
    show_ignored_too_mode_matching: bool = false,
    skip_nested_git: bool = false,
};

const Treatment = enum(u8) { none = 0, recurse = 1, excluded = 2, untracked = 3 };

const StackEnt = struct {
    baselen: usize,
    exclude_ix: usize,
};

var ignore_case_cache: ?bool = null;
pub fn ignoreCase() bool {
    if (ignore_case_cache == null) ignore_case_cache = repo_mod.cfg.getBool("core.ignorecase") orelse false;
    return ignore_case_cache.?;
}

fn fsEq(a: []const u8, b: []const u8) bool {
    if (ignoreCase()) return std.ascii.eqlIgnoreCase(a, b);
    return std.mem.eql(u8, a, b);
}

// ---------------------------------------------------------------------------
// Pattern parsing / matching

pub fn simpleLength(s: []const u8) usize {
    return pathspec_mod.simpleLength(s);
}

pub const ParsedPattern = struct { pattern: []const u8, flags: u32, nowildcardlen: usize };

/// parse_path_pattern()
pub fn parsePathPattern(p0: []const u8) ParsedPattern {
    var p = p0;
    var flags: u32 = 0;
    if (p.len > 0 and p[0] == '!') {
        flags |= PATTERN_FLAG_NEGATIVE;
        p = p[1..];
    }
    var len = p.len;
    if (len > 0 and p[len - 1] == '/') {
        len -= 1;
        flags |= PATTERN_FLAG_MUSTBEDIR;
    }
    if (std.mem.indexOfScalar(u8, p[0..len], '/') == null) flags |= PATTERN_FLAG_NODIR;
    var nw = simpleLength(p);
    if (nw > len) nw = len;
    if (p.len > 0 and p[0] == '*' and pathspec_mod.noWildcard(p[1..])) flags |= PATTERN_FLAG_ENDSWITH;
    return .{ .pattern = p[0..len], .flags = flags, .nowildcardlen = nw };
}

fn fnmatchIcase(pattern: []const u8, string: []const u8, flags0: u32) bool {
    var flags = flags0;
    if (ignoreCase()) flags |= wildmatch.CASEFOLD;
    return wildmatch.match(pattern, string, flags);
}

/// match_basename()
pub fn matchBasename(basename: []const u8, pattern: []const u8, prefix: usize, flags: u32) bool {
    if (prefix == pattern.len) {
        return pattern.len == basename.len and fsEq(pattern, basename);
    } else if (flags & PATTERN_FLAG_ENDSWITH != 0) {
        return pattern.len - 1 <= basename.len and fsEq(pattern[1..], basename[basename.len - (pattern.len - 1) ..]);
    } else {
        return fnmatchIcase(pattern, basename, 0);
    }
}

/// match_pathname(); baselen excludes trailing slash of base.
pub fn matchPathname(pathname: []const u8, base: []const u8, baselen: usize, pattern0: []const u8, prefix0: usize) bool {
    var pattern = pattern0;
    var prefix = prefix0;
    if (pattern.len > 0 and pattern[0] == '/') {
        pattern = pattern[1..];
        if (prefix > 0) prefix -= 1;
    }
    if (pathname.len < baselen + 1 or (baselen > 0 and pathname[baselen] != '/') or !fsEq(pathname[0..baselen], base[0..baselen]))
        return false;
    var name = if (baselen > 0) pathname[baselen + 1 ..] else pathname;
    if (prefix > 0) {
        if (prefix > name.len) return false;
        if (!fsEq(pattern[0..prefix], name[0..prefix])) return false;
        if (pattern.len == prefix and name.len == prefix) return true;
        prefix -= 1;
        pattern = pattern[prefix..];
        name = name[prefix..];
    }
    return fnmatchIcase(pattern, name, wildmatch.PATHNAME);
}

fn trimTrailingSpaces(s: []const u8) []const u8 {
    var last_space: ?usize = null;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        switch (s[i]) {
            ' ' => {
                if (last_space == null) last_space = i;
            },
            '\\' => {
                i += 1;
                if (i >= s.len) return s;
                last_space = null;
            },
            else => last_space = null,
        }
    }
    if (last_space) |l| return s[0..l];
    return s;
}

/// add_pattern()
pub fn addPatternToList(pl: *PatternList, string: []const u8, base: []const u8, srcpos: usize) void {
    const pp = parsePathPattern(string);
    const p = gpa.create(Pattern) catch util.oom();
    p.* = .{
        .pattern = util.dupe(pp.pattern),
        .original = util.dupe(string),
        .nowildcardlen = pp.nowildcardlen,
        .flags = pp.flags,
        .base = base,
        .srcpos = srcpos,
        .list = pl,
    };
    pl.patterns.append(gpa, p) catch util.oom();
}

/// add_patterns_from_buffer()
pub fn addPatternsFromBuffer(pl: *PatternList, buf0: []const u8, base: []const u8) void {
    var buf = buf0;
    if (util.startsWith(buf, "\xef\xbb\xbf")) buf = buf[3..];
    var lineno: usize = 1;
    var start: usize = 0;
    var i: usize = 0;
    while (i <= buf.len) : (i += 1) {
        const at_end = i == buf.len;
        if (at_end and start == buf.len) break;
        if (at_end or buf[i] == '\n') {
            var line = buf[start..i];
            if (line.len > 0 and line[0] != '#') {
                if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
                line = trimTrailingSpaces(line);
                addPatternToList(pl, line, base, lineno);
            }
            lineno += 1;
            start = i + 1;
        }
    }
}

fn readSkipWorktreeFromIndex(idx: ?*Index, path: []const u8) ?[]const u8 {
    const ix = idx orelse return null;
    const e = ix.get(path) orelse return null;
    if (!e.skipWorktree()) return null;
    const obj = repo_mod.repo().odb().read(e.oid) orelse return null;
    if (obj.typ != .blob) return null;
    return obj.data;
}

/// add_patterns(): returns false if the file couldn't be read.
pub fn addPatternsFromFile(pl: *PatternList, fname: []const u8, base: []const u8, idx: ?*Index, nofollow: bool) bool {
    var data: ?[]const u8 = null;
    if (nofollow) {
        if (os.lstatPath(fname)) |st| {
            if (st.isLnk()) {
                data = null;
            } else data = os.readFile(fname);
        }
    } else data = os.readFile(fname);
    if (data == null) {
        data = readSkipWorktreeFromIndex(idx, fname) orelse return false;
    }
    addPatternsFromBuffer(pl, data.?, base);
    return true;
}

// ---------------------------------------------------------------------------
// Dir

pub const Dir = struct {
    flags: Flags = .{},
    exclude_per_dir: ?[]const u8 = null,
    entries: std.ArrayList(Entry) = .empty,
    ignored: std.ArrayList(Entry) = .empty,
    groups: [3]std.ArrayList(*PatternList) = .{ .empty, .empty, .empty },
    /// pattern that excludes the current directory (prep_exclude)
    pattern: ?*Pattern = null,
    stack: std.ArrayList(StackEnt) = .empty,
    basebuf: util.Buf = .empty,
    stack_inited: bool = false,
    idx: ?*Index = null,
    // icase lookup caches
    icase_files: ?std.StringHashMapUnmanaged(usize) = null,
    icase_dirs: ?std.StringHashMapUnmanaged(void) = null,

    pub fn init() Dir {
        return .{};
    }

    pub fn addPatternList(self: *Dir, group: usize, src: ?[]const u8) *PatternList {
        const pl = gpa.create(PatternList) catch util.oom();
        pl.* = .{ .src = src };
        self.groups[group].append(gpa, pl) catch util.oom();
        return pl;
    }

    /// Command line exclude pattern (ls-files --exclude, clean -e, ...). All
    /// patterns given this way share one list (like git's per-command list).
    pub fn addPattern(self: *Dir, pattern: []const u8, src: []const u8) void {
        var pl: *PatternList = undefined;
        if (self.groups[EXC_CMDL].items.len == 0) {
            pl = self.addPatternList(EXC_CMDL, src);
        } else pl = self.groups[EXC_CMDL].items[0];
        addPatternToList(pl, pattern, "", @intCast(pl.patterns.items.len + 1));
    }

    /// Like addPattern, but uses a fresh list with a given srcpos (for check-ignore style -v output).
    pub fn addPatternSrcpos(self: *Dir, pl: *PatternList, pattern: []const u8, srcpos: usize) void {
        _ = self;
        addPatternToList(pl, pattern, "", srcpos);
    }

    /// add_patterns_from_file(): EXC_FILE group, dies if unreadable.
    pub fn addExcludesFile(self: *Dir, fname: []const u8) void {
        const pl = self.addPatternList(EXC_FILE, fname);
        if (!addPatternsFromFile(pl, fname, "", null, false))
            util.die("cannot use {s} as an exclude file", .{fname});
    }

    /// setup_standard_excludes()
    pub fn setupStandardExcludes(self: *Dir) void {
        self.exclude_per_dir = ".gitignore";
        const ef = excludesFile();
        if (ef) |f| {
            if (os.access(f, 4)) {
                self.addExcludesFile(f);
            } else warnAccess(f);
        }
        if (repo_mod.repo_) |r| {
            const p = r.gitPath("info/exclude");
            if (os.access(p, 4)) {
                self.addExcludesFile(p);
            } else warnAccess(p);
        }
    }

    // ---- matching ----

    fn lastMatchingFromList(self: *Dir, pathname: []const u8, basename: []const u8, dtype: *u8, pl: *PatternList) ?*Pattern {
        var i = pl.patterns.items.len;
        while (i > 0) {
            i -= 1;
            const p = pl.patterns.items[i];
            if (p.flags & PATTERN_FLAG_MUSTBEDIR != 0) {
                dtype.* = self.resolveDtype(dtype.*, pathname);
                if (dtype.* != DT_DIR) continue;
            }
            if (p.flags & PATTERN_FLAG_NODIR != 0) {
                if (matchBasename(basename, p.pattern, p.nowildcardlen, p.flags)) return p;
                continue;
            }
            const bl = if (p.base.len > 0) p.base.len - 1 else 0;
            if (matchPathname(pathname, p.base, bl, p.pattern, p.nowildcardlen)) return p;
        }
        return null;
    }

    fn lastMatchingFromLists(self: *Dir, pathname: []const u8, basename: []const u8, dtype: *u8) ?*Pattern {
        for (0..3) |g| {
            var j = self.groups[g].items.len;
            while (j > 0) {
                j -= 1;
                if (self.lastMatchingFromList(pathname, basename, dtype, self.groups[g].items[j])) |p| return p;
            }
        }
        return null;
    }

    /// prep_exclude(): load per-directory exclude files for `base` (with trailing '/').
    fn prepExclude(self: *Dir, base: []const u8) void {
        const baselen = base.len;
        // pop
        while (self.stack.items.len > 0) {
            const stk = self.stack.items[self.stack.items.len - 1];
            if (stk.baselen <= baselen and std.mem.eql(u8, self.basebuf.items[0..stk.baselen], base[0..stk.baselen])) break;
            _ = self.stack.pop();
            self.pattern = null;
            self.groups[EXC_DIRS].items.len = stk.exclude_ix;
        }
        if (self.pattern != null) return;

        var current: isize = if (self.stack.items.len > 0) @intCast(self.stack.items[self.stack.items.len - 1].baselen) else -1;
        self.basebuf.items.len = if (current < 0) 0 else @intCast(current);
        while (current < @as(isize, @intCast(baselen))) {
            var cp: usize = undefined;
            var cur: usize = undefined;
            if (current < 0) {
                cp = 0;
                cur = 0;
            } else {
                cur = @intCast(current);
                const slash = std.mem.indexOfScalarPos(u8, base, cur + 1, '/') orelse util.die("oops in prep_exclude", .{});
                cp = slash + 1;
            }
            const stk = StackEnt{ .baselen = cp, .exclude_ix = self.groups[EXC_DIRS].items.len };
            const pl = self.addPatternList(EXC_DIRS, null);
            util.bufAppend(&self.basebuf, base[cur..cp]);
            if (stk.baselen > 0) {
                var dt: u8 = DT_DIR;
                const dname = self.basebuf.items[0 .. stk.baselen - 1];
                const bname = self.basebuf.items[cur .. stk.baselen - 1];
                self.pattern = self.lastMatchingFromLists(util.dupe(dname), util.dupe(bname), &dt);
                if (self.pattern) |p| {
                    if (p.flags & PATTERN_FLAG_NEGATIVE != 0) self.pattern = null;
                }
                if (self.pattern != null) {
                    self.stack.append(gpa, stk) catch util.oom();
                    return;
                }
            }
            if (self.exclude_per_dir) |epd| {
                const dirb = util.dupe(self.basebuf.items);
                const src = util.concat(&.{ dirb, epd });
                pl.src = src;
                _ = addPatternsFromFile(pl, src, dirb, self.idx, true);
            }
            self.stack.append(gpa, stk) catch util.oom();
            current = @intCast(stk.baselen);
        }
        self.basebuf.items.len = baselen;
    }

    /// last_matching_pattern()
    pub fn lastMatchingPattern(self: *Dir, pathname: []const u8, dtype: *u8) ?*Pattern {
        const bpos = if (std.mem.lastIndexOfScalar(u8, pathname, '/')) |i| i + 1 else 0;
        self.prepExclude(pathname[0..bpos]);
        if (self.pattern) |p| return p;
        return self.lastMatchingFromLists(pathname, pathname[bpos..], dtype);
    }

    /// is_excluded()
    pub fn isExcluded(self: *Dir, pathname: []const u8, dtype: *u8) bool {
        const p = self.lastMatchingPattern(pathname, dtype) orelse return false;
        return p.flags & PATTERN_FLAG_NEGATIVE == 0;
    }

    // ---- index helpers ----

    fn buildIcase(self: *Dir) void {
        if (self.icase_files != null) return;
        var files: std.StringHashMapUnmanaged(usize) = .empty;
        var dirs: std.StringHashMapUnmanaged(void) = .empty;
        if (self.idx) |ix| {
            for (ix.entries.items, 0..) |e, i| {
                const low = util.lower(e.path);
                files.put(gpa, low, i) catch util.oom();
                var p: []const u8 = low;
                while (std.mem.lastIndexOfScalar(u8, p, '/')) |sl| {
                    p = p[0..sl];
                    const gop = dirs.getOrPut(gpa, p) catch util.oom();
                    if (gop.found_existing) break;
                }
            }
        }
        self.icase_files = files;
        self.icase_dirs = dirs;
    }

    /// index_file_exists(); returns entry
    pub fn indexFileExists(self: *Dir, name: []const u8, icase: bool) ?*index_mod.Entry {
        const ix = self.idx orelse return null;
        if (icase) {
            self.buildIcase();
            const i = self.icase_files.?.get(util.lower(name)) orelse return null;
            return &ix.entries.items[i];
        }
        const i = ix.firstPos(name);
        if (i < ix.entries.items.len and util.eql(ix.entries.items[i].path, name)) return &ix.entries.items[i];
        return null;
    }

    const Exist = enum { nonexistent, directory, gitdir };

    fn directoryExistsInIndex(self: *Dir, dirname: []const u8) Exist {
        const ix = self.idx orelse return .nonexistent;
        if (ignoreCase()) {
            self.buildIcase();
            if (self.icase_dirs.?.contains(util.lower(dirname))) return .directory;
            if (self.indexFileExists(dirname, true)) |e| {
                if (isGitlink(e.mode)) return .gitdir;
            }
            return .nonexistent;
        }
        var pos = ix.firstPos(dirname);
        while (pos < ix.entries.items.len) : (pos += 1) {
            const e = &ix.entries.items[pos];
            if (!util.startsWith(e.path, dirname)) break;
            const endchar: u8 = if (e.path.len > dirname.len) e.path[dirname.len] else 0;
            if (endchar > '/') break;
            if (endchar == '/') return .directory;
            if (endchar == 0 and isGitlink(e.mode)) return .gitdir;
        }
        return .nonexistent;
    }

    fn getIndexDtype(self: *Dir, path: []const u8) u8 {
        const ix = self.idx orelse return DT_UNKNOWN;
        if (self.indexFileExists(path, false)) |e| {
            if (!e.uptodate) return DT_UNKNOWN;
            if (isGitlink(e.mode)) return DT_DIR;
            return DT_REG;
        }
        var pos = switch (ix.pos(path, 0)) {
            .found => return DT_UNKNOWN,
            .missing => |m| m,
        };
        while (pos < ix.entries.items.len) : (pos += 1) {
            const e = &ix.entries.items[pos];
            if (!util.startsWith(e.path, path)) break;
            const ch: u8 = if (e.path.len > path.len) e.path[path.len] else 0;
            if (ch > '/') break;
            if (ch < '/') continue;
            if (!e.uptodate) break;
            return DT_DIR;
        }
        return DT_UNKNOWN;
    }

    fn resolveDtype(self: *Dir, dtype: u8, path: []const u8) u8 {
        if (dtype != DT_UNKNOWN) return dtype;
        const d = self.getIndexDtype(path);
        if (d != DT_UNKNOWN) return d;
        return lstatDtype(path);
    }

    fn addName(self: *Dir, path: []const u8) void {
        if (self.indexFileExists(path, ignoreCase()) != null) return;
        self.entries.append(gpa, .{ .name = util.dupe(path) }) catch util.oom();
    }

    fn addIgnored(self: *Dir, path: []const u8) void {
        if (self.idx) |ix| {
            if (!indexNameIsOther(ix, path)) return;
        }
        self.ignored.append(gpa, .{ .name = util.dupe(path) }) catch util.oom();
    }

    // ---- traversal ----

    fn treatDirectory(self: *Dir, dirname: []const u8, excluded: bool, ps: ?*const Pathspec) Treatment {
        const status = self.directoryExistsInIndex(dirname[0 .. dirname.len - 1]);
        if (status == .directory) return .recurse;
        if (status == .gitdir) return .none;

        var matches_how: u8 = 0;
        if (ps != null and !excluded) {
            matches_how = ps.?.matchFlags(dirname, 0, null, pathspec_mod.DO_MATCH_LEADING_PATHSPEC);
            if (matches_how == 0) return .none;
        }

        if (self.flags.skip_nested_git or !self.flags.no_gitlinks) {
            var nested = isNonbareRepositoryDir(dirname);
            if (nested) {
                const rd = os.realPath(util.concat(&.{ dirname, ".git" }));
                const rg = os.realPath(repo_mod.repo().git_dir);
                if (rd != null and rg != null and util.eql(rd.?, rg.?)) nested = false;
            }
            if (nested) {
                if (self.flags.skip_nested_git or matches_how == pathspec_mod.MATCHED_RECURSIVELY_LEADING_PATHSPEC) return .none;
                return if (excluded) .excluded else .untracked;
            }
        }

        if (!self.flags.show_other_directories) {
            if (excluded and self.flags.show_ignored_too and self.flags.show_ignored_too_mode_matching) {
                if (!self.flags.hide_empty_directories) return .excluded;
                if (self.readDirectoryRecursive(dirname, true, true, ps) == .excluded) return .excluded;
                return .none;
            }
            return .recurse;
        }

        if (matches_how == pathspec_mod.MATCHED_RECURSIVELY_LEADING_PATHSPEC) return .recurse;

        if (excluded) {
            if (!self.flags.hide_empty_directories) return .excluded;
            if (self.flags.show_ignored_too and self.flags.show_ignored_too_mode_matching) return .excluded;
        }

        if (!excluded and !(self.flags.show_ignored or self.flags.show_ignored_too or self.flags.hide_empty_directories))
            return .untracked;

        const check_only = self.flags.hide_empty_directories and !self.flags.show_ignored_too;
        const stop_early = check_only and excluded;

        const old_ignored_nr = self.ignored.items.len;
        const old_untracked_nr = self.entries.items.len;

        var state = self.readDirectoryRecursive(dirname, check_only, stop_early, ps);

        if (state == .excluded) {
            const want_ignored_subpaths = self.flags.show_ignored_too and self.flags.show_ignored_too_mode_matching;
            if (want_ignored_subpaths) {
                state = .none;
            } else {
                self.ignored.items.len = old_ignored_nr;
            }
        }
        if (self.flags.show_ignored_too and !self.flags.keep_untracked_contents) {
            self.entries.items.len = old_untracked_nr;
        }
        if (state == .none and !self.flags.hide_empty_directories)
            state = if (excluded) .excluded else .untracked;
        return state;
    }

    fn simplifyAway(ps: ?*const Pathspec, path: []const u8) bool {
        const p = ps orelse return false;
        if (p.items.len == 0) return false;
        for (p.items) |*it| {
            var len = it.nowildcard_len;
            if (len > path.len) len = path.len;
            if (psNcmp(it, it.match, path, len)) return false;
        }
        return true;
    }

    fn excludeMatchesPathspec(ps: ?*const Pathspec, path: []const u8) bool {
        const p = ps orelse return false;
        if (p.items.len == 0) return false;
        for (p.items) |*it| {
            const len = it.nowildcard_len;
            if (len == path.len and psNcmp(it, it.match, path, path.len)) return true;
            if (len > path.len and it.match[path.len] == '/' and psNcmp(it, it.match, path, path.len)) return true;
        }
        return false;
    }

    /// treat_path(); `path` is the full path (base + name), d_type may be DT_UNKNOWN.
    fn treatPath(self: *Dir, name: []const u8, d_type: u8, path_buf: *util.Buf, ps: ?*const Pathspec) Treatment {
        if (util.eql(name, ".") or util.eql(name, "..") or fsEq(name, ".git")) return .none;
        util.bufAppend(path_buf, name);
        const path = path_buf.items;
        if (simplifyAway(ps, path)) return .none;
        var dtype = self.resolveDtype(d_type, path);
        const has_path_in_index = self.indexFileExists(path, ignoreCase()) != null;
        if (dtype != DT_DIR and has_path_in_index) return .none;
        if (self.flags.collect_killed_only and dtype == DT_DIR and !has_path_in_index and
            self.directoryExistsInIndex(path) == .nonexistent) return .none;

        const excluded = self.isExcluded(util.dupe(path), &dtype);
        if (excluded and !(self.flags.show_ignored or self.flags.show_ignored_too)) return .excluded;

        switch (dtype) {
            DT_DIR => {
                util.bufByte(path_buf, '/');
                return self.treatDirectory(util.dupe(path_buf.items), excluded, ps);
            },
            DT_REG, DT_LNK => {
                if (ps) |p| {
                    if (p.matchSeen(path, false, null) == 0) return .none;
                }
                return if (excluded) .excluded else .untracked;
            },
            else => return .none,
        }
    }

    fn addPathToResult(self: *Dir, path: []const u8, ps: ?*const Pathspec, state: Treatment) void {
        switch (state) {
            .excluded => {
                if (self.flags.show_ignored) {
                    self.addName(path);
                } else if (self.flags.show_ignored_too or (self.flags.collect_ignored and excludeMatchesPathspec(ps, path))) {
                    self.addIgnored(path);
                }
            },
            .untracked => {
                if (self.flags.show_ignored) return;
                self.addName(path);
            },
            else => {},
        }
    }

    fn readDirectoryRecursive(self: *Dir, base: []const u8, check_only: bool, stop_at_first_file: bool, ps: ?*const Pathspec) Treatment {
        var dir_state: Treatment = .none;
        const ents = os.listDir(if (base.len == 0) "." else base) orelse {
            if (os.lstatPath(if (base.len == 0) "." else base) != null and os.isDir(if (base.len == 0) "." else base))
                util.warn("could not open directory '{s}': {s}", .{ if (base.len == 0) "." else base, os.lastErr() });
            return .none;
        };
        // Sort for deterministic behavior
        std.mem.sort(os.DirEntry, ents, {}, struct {
            fn lt(_: void, a: os.DirEntry, b: os.DirEntry) bool {
                return std.mem.order(u8, a.name, b.name) == .lt;
            }
        }.lt);
        var path: util.Buf = .empty;
        for (ents) |de| {
            path.items.len = 0;
            util.bufAppend(&path, base);
            var state = self.treatPath(de.name, de.typ, &path, ps);
            if (@intFromEnum(state) > @intFromEnum(dir_state)) dir_state = state;
            if (state == .recurse) {
                const sub = util.dupe(path.items);
                const subdir_state = self.readDirectoryRecursive(sub, check_only, stop_at_first_file, ps);
                if (@intFromEnum(subdir_state) > @intFromEnum(dir_state)) dir_state = subdir_state;
                if (ps) |p| {
                    if (p.matchSeen(sub, false, null) == 0) state = .none;
                }
            }
            if (check_only) {
                if (stop_at_first_file) {
                    if (@intFromEnum(dir_state) >= @intFromEnum(Treatment.excluded)) {
                        dir_state = .excluded;
                        break;
                    }
                }
                if (dir_state == .untracked) break;
                continue;
            }
            self.addPathToResult(path.items, ps, state);
        }
        return dir_state;
    }

    fn treatLeadingPath(self: *Dir, path0: []const u8, ps: ?*const Pathspec) bool {
        var len = path0.len;
        while (len > 0 and path0[len - 1] == '/') len -= 1;
        if (len == 0) return true;
        const path = path0[0..len];
        var baselen: usize = 0;
        var state: Treatment = .none;
        var sb: util.Buf = .empty;
        while (true) {
            const prevlen = baselen + @intFromBool(baselen != 0);
            baselen = if (std.mem.indexOfScalarPos(u8, path, prevlen, '/')) |c| c else len;
            if (!os.isDir(path[0..baselen])) break;
            sb.items.len = 0;
            util.bufAppend(&sb, path[0..prevlen]);
            state = self.treatPath(path[prevlen..baselen], DT_DIR, &sb, ps);
            if (state != .recurse) break;
            if (len <= baselen) break;
        }
        self.addPathToResult(sb.items, ps, state);
        return state == .recurse;
    }

    /// read_directory()
    pub fn readDirectory(self: *Dir, idx: ?*Index, path: []const u8, ps: ?*const Pathspec) usize {
        self.idx = idx;
        if (path.len > 0 and pathspec_mod.hasSymlinkLeadingPath(path)) return self.entries.items.len;
        if (path.len == 0 or self.treatLeadingPath(path, ps))
            _ = self.readDirectoryRecursive(path, false, false, ps);
        sortEntries(self.entries.items);
        sortEntries(self.ignored.items);
        return self.entries.items.len;
    }

    /// fill_directory(): returns the common prefix length used.
    pub fn fill(self: *Dir, idx: ?*Index, ps: ?*const Pathspec) usize {
        var plen: usize = 0;
        var prefix: []const u8 = "";
        if (ps) |p| {
            plen = p.commonPrefixLen();
            prefix = p.commonPrefix();
        }
        _ = self.readDirectory(idx, prefix, ps);
        return plen;
    }
};

fn psNcmp(it: *const pathspec_mod.Item, a: []const u8, b: []const u8, n: usize) bool {
    // strncmp semantics (a, b NUL-terminated)
    var i: usize = 0;
    while (i < n) : (i += 1) {
        const ca: u8 = if (i < a.len) a[i] else 0;
        const cb: u8 = if (i < b.len) b[i] else 0;
        const eq = if (it.magic & pathspec_mod.MAGIC_ICASE != 0) std.ascii.toLower(ca) == std.ascii.toLower(cb) else ca == cb;
        if (!eq) return false;
        if (ca == 0) return true;
    }
    return true;
}

pub fn sortEntries(items: []Entry) void {
    std.mem.sort(Entry, items, {}, struct {
        fn lt(_: void, a: Entry, b: Entry) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
}

fn isGitlink(mode: u32) bool {
    return mode & 0o170000 == 0o160000;
}

fn lstatDtype(path: []const u8) u8 {
    const st = os.lstatPath(path) orelse return DT_UNKNOWN;
    if (st.isReg()) return DT_REG;
    if (st.isDir()) return DT_DIR;
    if (st.isLnk()) return DT_LNK;
    return DT_UNKNOWN;
}

fn warnAccess(path: []const u8) void {
    const e = os.errno();
    if (e == os.ENOENT or e == os.ENOTDIR) return;
    util.warn("unable to access '{s}': {s}", .{ path, os.strErr(e) });
}

/// core.excludesFile, defaulting to $XDG_CONFIG_HOME/git/ignore
pub fn excludesFile() ?[]const u8 {
    if (repo_mod.cfg.getPath("core.excludesfile")) |p| return p;
    return xdgConfigHome("ignore");
}

pub fn xdgConfigHome(name: []const u8) ?[]const u8 {
    if (os.getenv("XDG_CONFIG_HOME")) |x| {
        if (x.len > 0) return util.concat(&.{ x, "/git/", name });
    }
    const home = os.getenv("HOME") orelse return null;
    return util.concat(&.{ home, "/.config/git/", name });
}

/// index_name_is_other()
pub fn indexNameIsOther(idx: *Index, name0: []const u8) bool {
    var name = name0;
    if (name.len > 0 and name[name.len - 1] == '/') name = name[0 .. name.len - 1];
    switch (idx.pos(name, 0)) {
        .found => return false,
        .missing => |p| {
            if (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, name)) return false;
            return true;
        },
    }
}

/// is_nonbare_repository_dir(): does `path` contain a .git dir/gitfile? path may end with '/'.
pub fn isNonbareRepositoryDir(path: []const u8) bool {
    const dg = if (path.len > 0 and path[path.len - 1] != '/') util.concat(&.{ path, "/.git" }) else util.concat(&.{ path, ".git" });
    const st = os.statPath(dg) orelse return false;
    if (st.isReg()) {
        const data = os.readFile(dg) orelse return true;
        const rest = util.skipPrefix(data, "gitdir: ") orelse return false;
        const p = util.trimRight(rest);
        const full = if (p.len > 0 and p[0] == '/') p else util.joinPath(util.dirname(dg), p);
        return repo_mod.isGitDirectory(full);
    }
    if (st.isDir()) return repo_mod.isGitDirectory(dg);
    return false;
}

// ---------------------------------------------------------------------------
// Convenience wrappers

var std_dir: ?*Dir = null;

/// Standard ignore check (gitignore files, info/exclude, core.excludesFile).
pub fn isIgnored(path: []const u8, is_dir: bool) bool {
    if (std_dir == null) {
        const d = gpa.create(Dir) catch util.oom();
        d.* = Dir.init();
        d.setupStandardExcludes();
        d.idx = if (repo_mod.repo_ != null) index_mod.get() else null;
        std_dir = d;
    }
    var p = path;
    if (p.len > 0 and p[p.len - 1] == '/') p = p[0 .. p.len - 1];
    var dt: u8 = if (is_dir) DT_DIR else DT_REG;
    return std_dir.?.isExcluded(p, &dt);
}

/// Return the standard Dir used by isIgnored (for callers needing the matched pattern).
pub fn standardDir() *Dir {
    _ = isIgnored("", false);
    return std_dir.?;
}

pub const UntrackedOpts = struct {
    pathspec: ?*const Pathspec = null,
    /// collapse untracked directories into "dir/" (DIR_SHOW_OTHER_DIRECTORIES)
    show_dirs: bool = false,
    /// with show_dirs: hide empty directories
    hide_empty: bool = false,
    /// also collect ignored paths (DIR_SHOW_IGNORED_TOO); result.ignored
    show_ignored_too: bool = false,
    /// --ignored=matching mode
    ignored_matching: bool = false,
    /// keep untracked contents of dirs (DIR_KEEP_UNTRACKED_CONTENTS)
    keep_untracked_contents: bool = false,
    /// only show ignored files in entries (DIR_SHOW_IGNORED)
    only_ignored: bool = false,
    /// do not treat nested repositories as gitlinks (DIR_NO_GITLINKS)
    no_gitlinks: bool = false,
    /// skip nested git repositories
    skip_nested_git: bool = false,
    /// collect ignored paths named by pathspec (DIR_COLLECT_IGNORED)
    collect_ignored: bool = false,
    /// use standard exclude rules
    standard_excludes: bool = true,
    /// extra command line exclude patterns
    excludes: []const []const u8 = &.{},
    index: ?*Index = null,
};

pub const Result = struct {
    entries: []Entry,
    ignored: []Entry,
};

/// One-shot untracked enumeration.
pub fn untracked(opts: UntrackedOpts) Result {
    var d = gpa.create(Dir) catch util.oom();
    d.* = Dir.init();
    d.flags = .{
        .show_other_directories = opts.show_dirs,
        .hide_empty_directories = opts.hide_empty,
        .show_ignored_too = opts.show_ignored_too,
        .show_ignored_too_mode_matching = opts.ignored_matching,
        .keep_untracked_contents = opts.keep_untracked_contents,
        .show_ignored = opts.only_ignored,
        .no_gitlinks = opts.no_gitlinks,
        .skip_nested_git = opts.skip_nested_git,
        .collect_ignored = opts.collect_ignored,
    };
    for (opts.excludes) |e| d.addPattern(e, "--exclude option");
    if (opts.standard_excludes) d.setupStandardExcludes();
    const idx = opts.index orelse index_mod.get();
    _ = d.fill(idx, opts.pathspec);
    return .{ .entries = d.entries.items, .ignored = d.ignored.items };
}

/// file_exists()
pub fn fileExists(path: []const u8) bool {
    return os.lstatPath(path) != null;
}

/// is_empty_dir()
pub fn isEmptyDir(path: []const u8) bool {
    const ents = os.listDir(path) orelse return false;
    return ents.len == 0;
}
