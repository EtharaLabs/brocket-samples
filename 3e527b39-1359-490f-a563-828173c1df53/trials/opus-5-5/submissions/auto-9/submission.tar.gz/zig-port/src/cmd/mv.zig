//! git mv

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git mv [-v] [-f] [-n] [-k] <source> <destination>",
    "git mv [-v] [-f] [-n] [-k] <source>... <destination-directory>",
};

const WORKING_DIRECTORY: u32 = 1 << 1;
const INDEX: u32 = 1 << 2;
const SPARSE: u32 = 1 << 3;
const SKIP_WORKTREE_DIR: u32 = 1 << 4;
const MOVE_VIA_PARENT_DIR: u32 = 1 << 5;

const DUP_BASENAME: u32 = 1;
const KEEP_TRAILING_SLASH: u32 = 2;

var verbose: i32 = 0;
var show_only = false;
var force: i32 = 0;
var ignore_errors = false;
var ignore_sparse = false;

const options = [_]po.Opt{
    .{ .short = 'v', .long = "verbose", .kind = .counter, .i = &verbose, .help = "be verbose" },
    po.boolean('n', "dry-run", &show_only, "dry run"),
    po.counter('f', "force", &force, "force move/rename even if target exists"),
    po.boolean('k', "", &ignore_errors, "skip move/rename errors"),
    po.boolean(0, "sparse", &ignore_sparse, "allow updating entries outside of the sparse-checkout cone"),
};

fn prefixPath(prefix: []const u8, path: []const u8) []const u8 {
    var plen = prefix.len;
    return pathspec_mod.prefixPathGently(prefix, &plen, path) orelse
        util.die("'{s}' is outside repository at '{s}'", .{ path, repo_mod.repo().work_tree orelse "" });
}

fn internalPrefix(out: *std.ArrayList([]const u8), prefix: []const u8, paths: []const []const u8, flags: u32) void {
    for (paths) |p| {
        var n = p.len;
        while (flags & KEEP_TRAILING_SLASH == 0 and n > 0 and p[n - 1] == '/') n -= 1;
        const trimmed = p[0..n];
        const name = if (flags & DUP_BASENAME != 0) basename(trimmed) else trimmed;
        out.append(gpa, prefixPath(prefix, name)) catch util.oom();
    }
}

fn basename(p: []const u8) []const u8 {
    if (p.len == 0) return ".";
    const s = std.mem.lastIndexOfScalar(u8, p, '/') orelse return p;
    return p[s + 1 ..];
}

fn addSlash(p: []const u8) []const u8 {
    if (p.len > 0 and p[p.len - 1] != '/') return util.concat(&.{ p, "/" });
    return p;
}

/// Returns [first, last) of entries under src/.
fn indexRangeOfSameDir(idx: *index_mod.Index, src: []const u8) [2]usize {
    const ws = addSlash(src);
    if (idx.findPos(ws) != null) util.die("{s} is in index", .{ws});
    const first = idx.firstPos(ws);
    var last = first;
    while (last < idx.entries.items.len and util.startsWith(idx.entries.items[last].path, ws)) last += 1;
    return .{ first, last };
}

fn hasSymlinkLeadingPath(p: []const u8) bool {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, p, i, '/')) |s| : (i = s + 1) {
        const st = os.lstatPath(p[0..s]) orelse return false;
        if (st.isLnk()) return true;
        if (!st.isDir()) return false;
    }
    return false;
}

pub fn cmdMv(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    const argv = po.parse(args[1..], &options, &usage, .{});
    if (argv.len < 2) po.usageWithOptions(&usage, &options);
    var argc = argv.len - 1;

    const idx = index_mod.lockAndRead();
    const prefix = r.prefix;

    var sources: std.ArrayList([]const u8) = .empty;
    internalPrefix(&sources, prefix, argv[0..argc], 0);
    var modes: std.ArrayList(u32) = .empty;
    modes.appendNTimes(gpa, 0, argc) catch util.oom();

    var flags: u32 = KEEP_TRAILING_SLASH;
    if (argc == 1 and os.isDir(argv[0]) and !os.isDir(argv[1])) flags = 0;
    var dest_paths: std.ArrayList([]const u8) = .empty;
    internalPrefix(&dest_paths, prefix, argv[argc .. argc + 1], flags);
    const dst_w_slash = addSlash(dest_paths.items[0]);

    var destinations: std.ArrayList([]const u8) = .empty;
    if (dest_paths.items[0].len == 0) {
        internalPrefix(&destinations, dest_paths.items[0], argv[0..argc], DUP_BASENAME);
    } else if (os.lstatPath(dest_paths.items[0])) |st| {
        if (st.isDir()) {
            internalPrefix(&destinations, dst_w_slash, argv[0..argc], DUP_BASENAME);
        } else if (argc != 1) {
            util.die("destination '{s}' is not a directory", .{dest_paths.items[0]});
        } else destinations.append(gpa, dest_paths.items[0]) catch util.oom();
    } else if (argc != 1) {
        util.die("destination '{s}' is not a directory", .{dest_paths.items[0]});
    } else destinations.append(gpa, dest_paths.items[0]) catch util.oom();

    var src_dir: std.ArrayList([]const u8) = .empty;
    var src_for_dst: std.StringHashMapUnmanaged(void) = .empty;

    var i: usize = 0;
    while (i < argc) : (i +%= 1) {
        const src = sources.items[i];
        const dst = destinations.items[i];
        var bad: ?[]const u8 = null;
        if (show_only) util.outf("Checking rename of '{s}' to '{s}'\n", .{ src, dst });

        check: {
            const st = os.lstatPath(src) orelse {
                if (idx.findPos(src)) |pos| {
                    const ce = &idx.entries.items[pos];
                    if (!ce.skipWorktree()) {
                        bad = "bad source";
                        break :check;
                    }
                    if (idx.findPos(dst) == null) {
                        modes.items[i] |= SPARSE;
                        break :check;
                    }
                    if (force == 0) {
                        bad = "destination exists";
                        break :check;
                    }
                    modes.items[i] |= SPARSE;
                    break :check;
                }
                if (modes.items[i] & SPARSE == 0) bad = "bad source";
                break :check;
            };
            if (util.startsWith(dst, src) and (dst.len == src.len or dst[src.len] == '/')) {
                bad = "can not move directory into itself";
                break :check;
            }
            if (st.isDir() and os.lstatPath(dst) != null) {
                bad = "destination already exists";
                break :check;
            }
            if (st.isDir()) {
                if (idx.findPos(src)) |first| {
                    if (idx.entries.items[first].mode != 0o160000)
                        util.die("Directory {s} is in index and no submodule?", .{src});
                    break :check;
                }
                const range = indexRangeOfSameDir(idx, src);
                if (range[1] <= range[0]) {
                    bad = "source directory is empty";
                    break :check;
                }
                modes.items[i] |= WORKING_DIRECTORY;
                src_dir.append(gpa, src) catch util.oom();
                const dws = addSlash(dst);
                var j = range[0];
                while (j < range[1]) : (j += 1) {
                    const ce = &idx.entries.items[j];
                    sources.append(gpa, ce.path) catch util.oom();
                    destinations.append(gpa, prefixPath(dws, ce.path[src.len + 1 ..])) catch util.oom();
                    modes.append(gpa, MOVE_VIA_PARENT_DIR | (if (ce.skipWorktree()) SPARSE else INDEX)) catch util.oom();
                }
                argc += range[1] - range[0];
                break :check;
            }
            const pos = idx.findPos(src) orelse blk: {
                const p = idx.firstPos(src);
                if (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, src)) break :blk p;
                bad = "not under version control";
                break :check;
            };
            if (idx.entries.items[pos].stage() != 0) {
                bad = "conflicted";
                break :check;
            }
            if (os.lstatPath(dst)) |dst_st| {
                bad = "destination exists";
                if (force != 0) {
                    if (dst_st.isReg() or dst_st.isLnk()) {
                        if (verbose != 0) util.warn("overwriting '{s}'", .{dst});
                        bad = null;
                    } else bad = "Cannot overwrite";
                }
                break :check;
            }
            if (src_for_dst.contains(dst)) {
                bad = "multiple sources for the same target";
                break :check;
            }
            if (dst.len > 0 and dst[dst.len - 1] == '/') {
                bad = "destination directory does not exist";
                break :check;
            }
            if (hasSymlinkLeadingPath(dst)) {
                bad = "destination is beyond a symbolic link";
                break :check;
            }
            if (modes.items[i] & (INDEX | SPARSE | SKIP_WORKTREE_DIR) == 0) {
                if (std.mem.lastIndexOfScalar(u8, dst, '/')) |s| {
                    if (os.lstatPath(dst[0..s])) |ds| {
                        if (!ds.isDir()) bad = "destination is not a directory";
                    } else bad = "destination directory does not exist";
                }
                if (bad != null) break :check;
            }
            src_for_dst.put(gpa, dst, {}) catch util.oom();
        }

        if (bad) |b| {
            if (!ignore_errors) util.die("{s}, source={s}, destination={s}", .{ b, src, dst });
            argc -= 1;
            if (argc > 0 or i < sources.items.len) {
                _ = sources.orderedRemove(i);
                _ = destinations.orderedRemove(i);
                _ = modes.orderedRemove(i);
                i -%= 1;
            }
        }
    }

    for (0..argc) |k| {
        if (modes.items[k] & MOVE_VIA_PARENT_DIR != 0) continue;
        var p = sources.items[k];
        while (std.mem.lastIndexOfScalar(u8, p, '/')) |s| {
            if (s == 0) break;
            p = p[0..s];
            for (src_dir.items) |d| {
                if (util.eql(d, p)) util.die("cannot move both '{s}' and its parent directory '{s}'", .{ sources.items[k], p });
            }
        }
    }

    for (0..argc) |k| {
        const src = sources.items[k];
        const dst = destinations.items[k];
        const mode = modes.items[k];
        if (show_only or verbose != 0) util.outf("Renaming {s} to {s}\n", .{ src, dst });
        if (show_only) continue;
        if (mode & (INDEX | SPARSE | SKIP_WORKTREE_DIR) == 0 and !os.rename(src, dst)) {
            if (ignore_errors) continue;
            util.dieErrno("renaming '{s}' to '{s}' failed", .{ src, dst });
        }
        if (mode & (WORKING_DIRECTORY | SKIP_WORKTREE_DIR) != 0) continue;
        const pos = idx.findPos(src) orelse continue;
        var ne = idx.entries.items[pos];
        ne.path = dst;
        idx.removeAt(pos);
        idx.invalidatePath(src);
        _ = idx.add(ne, .{});
        idx.changed = true;
    }

    for (src_dir.items) |d| {
        const range = indexRangeOfSameDir(idx, d);
        if (range[1] <= range[0]) os.removeTree(d);
    }

    if (idx.changed) idx.write() else idx.rollback();
    return 0;
}
