//! builtin/apply.c
const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const repo_mod = @import("../repo.zig");
const apply = @import("../apply.zig");

const usage = [_][]const u8{"git apply [<options>] [<patch>...]"};

pub fn cmdApply(args: []const []const u8) u8 {
    var state: apply.State = .{};
    var prefix: ?[]const u8 = null;
    if (repo_mod.repo_ != null) {
        const p = repo_mod.repo().prefix;
        if (p.len > 0) prefix = p;
    }
    if (apply.initState(&state, prefix) != 0) os.exit(128);
    var force_apply = false;
    var options: u32 = 0;
    const rest = apply.parseOptions(args[1..], &state, &force_apply, &options, &usage);
    if (apply.checkState(&state, force_apply) != 0) os.exit(128);
    const ret = apply.applyAllPatches(&state, rest, options);
    util.flushStdout();
    return ret;
}
