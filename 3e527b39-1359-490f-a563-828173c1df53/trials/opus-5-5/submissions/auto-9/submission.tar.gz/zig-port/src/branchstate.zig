//! remove_branch_state() / remove_merge_branch_state() (branch.c) and
//! sequencer_post_commit_cleanup() (sequencer.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const refs = @import("refs.zig");
const repo_mod = @import("repo.zig");

fn removeTree(path: []const u8) void {
    const st = os.lstatPath(path) orelse return;
    if (st.isDir()) {
        if (os.listDir(path)) |ents| {
            for (ents) |de| removeTree(util.concat(&.{ path, "/", de.name }));
        }
        _ = os.rmdir(path);
    } else _ = os.unlink(path);
}

fn haveFinishedTheLastPick() bool {
    const r = repo_mod.repo();
    const data = os.readFile(r.gitPath("sequencer/todo")) orelse return false;
    const eol = std.mem.indexOfScalar(u8, data, '\n') orelse return true;
    return eol + 1 >= data.len;
}

pub fn sequencerPostCommitCleanup(verbose: bool) void {
    var need_cleanup = false;
    if (refs.exists("CHERRY_PICK_HEAD")) {
        if (refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "")) |_| {
            if (verbose) util.warn("cancelling a cherry picking in progress", .{});
        } else |_| {}
        need_cleanup = true;
    }
    if (refs.exists("REVERT_HEAD")) {
        if (refs.deleteRef("REVERT_HEAD", null, refs.F_NO_DEREF, "")) |_| {
            if (verbose) util.warn("cancelling a revert in progress", .{});
        } else |_| {}
        need_cleanup = true;
    }
    if (refs.exists("AUTO_MERGE")) refs.deleteRef("AUTO_MERGE", null, refs.F_NO_DEREF, "") catch {};
    if (!need_cleanup) return;
    if (!haveFinishedTheLastPick()) return;
    removeTree(repo_mod.repo().gitPath("sequencer"));
}

pub fn removeMergeBranchState() void {
    const r = repo_mod.repo();
    _ = os.unlink(r.gitPath("MERGE_HEAD"));
    _ = os.unlink(r.gitPath("MERGE_RR"));
    _ = os.unlink(r.gitPath("MERGE_MSG"));
    _ = os.unlink(r.gitPath("MERGE_MODE"));
    if (refs.exists("AUTO_MERGE")) refs.deleteRef("AUTO_MERGE", null, refs.F_NO_DEREF, "") catch {};
}

pub fn removeBranchState(verbose: bool) void {
    sequencerPostCommitCleanup(verbose);
    _ = os.unlink(repo_mod.repo().gitPath("SQUASH_MSG"));
    removeMergeBranchState();
}
