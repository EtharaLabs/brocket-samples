//! update_server_info() (server-info.c): $GIT_DIR/info/refs and
//! objects/info/packs for dumb transports.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const objects = @import("objects.zig");
const hash = @import("hash.zig");
const gpa = util.gpa;

/// Write `content` to `path` unless the existing file is identical (or
/// `force`). Returns false on error.
fn updateInfoFile(path: []const u8, content: []const u8, force: bool) bool {
    _ = os.mkdirLeading(path);
    if (!force) {
        if (os.readFile(path)) |old| {
            if (std.mem.eql(u8, old, content)) return true;
        }
    }
    const dir = util.dirname(path);
    const t = os.tmpFile(if (dir.len == 0) "." else dir, util.concat(&.{ util.basename(path), "_" }));
    if (t.fd < 0) {
        util.err("unable to update {s}", .{path});
        return false;
    }
    os.writeAll(t.fd, content) catch {
        os.close(t.fd);
        _ = os.unlink(t.path);
        util.err("unable to update {s}", .{path});
        return false;
    };
    os.close(t.fd);
    _ = os.chmod(t.path, @intCast(0o666 & ~umaskValue()));
    if (!os.rename(t.path, path)) {
        _ = os.unlink(t.path);
        util.err("unable to update {s}", .{path});
        return false;
    }
    return true;
}

extern "c" fn umask(mask: c_uint) c_uint;
fn umaskValue() c_uint {
    const m = umask(0o022);
    _ = umask(m);
    return m;
}

fn generateInfoRefs() []const u8 {
    var b: util.Buf = .empty;
    for (refs.iterate("refs/", .{ .check_objects = false })) |r| {
        const odb = repo_mod.repo().odb();
        const o = odb.read(r.oid) orelse continue;
        util.bufPrint(&b, "{s}\t{s}\n", .{ hash.hex(r.oid), r.name });
        if (o.typ == .tag) {
            if (objects.peel(r.oid)) |p| util.bufPrint(&b, "{s}\t{s}^{{}}\n", .{ hash.hex(p.oid), r.name });
        }
    }
    return b.items;
}

fn generatePacks(infofile: []const u8, force: bool) []const u8 {
    const odb = repo_mod.repo().odb();
    odb.loadPacks();
    var names: std.ArrayList([]const u8) = .empty;
    for (odb.packs.items) |p| {
        if (!util.startsWith(p.idx_path, odb.objects_dir)) continue;
        if (!os.exists(p.pack_path)) continue;
        names.append(gpa, util.basename(p.pack_path)) catch util.oom();
    }
    // Keep the order of the existing file when it is not stale.
    var ordered: std.ArrayList([]const u8) = .empty;
    var stale = true;
    if (!force) {
        if (os.readFile(infofile)) |old| {
            stale = false;
            var it = std.mem.splitScalar(u8, old, '\n');
            while (it.next()) |line| {
                if (line.len == 0) continue;
                if (util.startsWith(line, "P ")) {
                    const n = line[2..];
                    var found = false;
                    for (names.items) |x| {
                        if (util.eql(x, n)) found = true;
                    }
                    if (!found) {
                        stale = true;
                        break;
                    }
                    ordered.append(gpa, n) catch util.oom();
                } else if (line[0] == 'D' or line[0] == 'T') {
                    stale = true;
                    break;
                } else util.err("unrecognized: {s}", .{line});
            }
        }
    }
    if (stale) ordered.items.len = 0;
    for (names.items) |n| {
        var have = false;
        for (ordered.items) |x| {
            if (util.eql(x, n)) have = true;
        }
        if (!have) ordered.append(gpa, n) catch util.oom();
    }
    var b: util.Buf = .empty;
    for (ordered.items) |n| util.bufPrint(&b, "P {s}\n", .{n});
    util.bufAppend(&b, "\n");
    return b.items;
}

pub fn updateServerInfo(force: bool) bool {
    const r = repo_mod.repo();
    var ok = true;
    const refs_path = util.concat(&.{ r.git_dir, "/info/refs" });
    ok = updateInfoFile(refs_path, generateInfoRefs(), force) and ok;
    const packs_path = util.concat(&.{ r.odb().objects_dir, "/info/packs" });
    ok = updateInfoFile(packs_path, generatePacks(packs_path, force), force) and ok;
    _ = os.unlink(util.concat(&.{ r.git_dir, "/info/rev-cache" }));
    return ok;
}
