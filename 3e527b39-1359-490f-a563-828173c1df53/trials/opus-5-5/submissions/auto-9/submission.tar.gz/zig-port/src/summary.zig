//! print_commit_summary (sequencer.c) with a small built-in shortstat/summary
//! diff between a commit and its first parent (exact rename detection only).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const objects = @import("objects.zig");
const refs = @import("refs.zig");
const repo_mod = @import("repo.zig");
const ident = @import("ident.zig");
const advice = @import("advice.zig");
const xdiff = @import("xdiff.zig");
const cn = @import("commitnode.zig");
const revparse = @import("revparse.zig");
const pretty = @import("pretty.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const SUMMARY_INITIAL_COMMIT: u32 = 1;
pub const SUMMARY_SHOW_AUTHOR_DATE: u32 = 2;

const implicit_ident_advice_noconfig =
    "Your name and email address were configured automatically based\n" ++
    "on your username and hostname. Please check that they are accurate.\n" ++
    "You can suppress this message by setting them explicitly. Run the\n" ++
    "following command and follow the instructions in your editor to edit\n" ++
    "your configuration file:\n" ++
    "\n" ++
    "    git config --global --edit\n" ++
    "\n" ++
    "After doing this, you may fix the identity used for this commit with:\n" ++
    "\n" ++
    "    git commit --amend --reset-author\n";

const implicit_ident_advice_config =
    "Your name and email address were configured automatically based\n" ++
    "on your username and hostname. Please check that they are accurate.\n" ++
    "You can suppress this message by setting them explicitly:\n" ++
    "\n" ++
    "    git config --global user.name \"Your Name\"\n" ++
    "    git config --global user.email you@example.com\n" ++
    "\n" ++
    "After doing this, you may fix the identity used for this commit with:\n" ++
    "\n" ++
    "    git commit --amend --reset-author\n";

fn implicitIdentAdvice() []const u8 {
    const g = repo_mod.globalConfigPaths();
    var exists = false;
    if (g.home) |h| exists = exists or os.access(h, 0);
    if (g.xdg) |x| exists = exists or os.access(x, 0);
    return if (exists) implicit_ident_advice_config else implicit_ident_advice_noconfig;
}

pub fn committerIdentSufficientlyGiven() bool {
    return ident.getEmail(.committer) != null;
}

fn fmtCommit(c: *cn.Commit, f: []const u8) []const u8 {
    var b: util.Buf = .empty;
    const ctx = pretty.Context{ .abbrev = revparse.defaultAbbrev() };
    pretty.formatCommitMessage(c, f, &b, &ctx);
    return b.items;
}

pub fn printCommitSummary(oid: Oid, flags: u32) void {
    const c = cn.lookupCommit(oid) orelse util.die("couldn't look up newly created commit", .{});
    if (!cn.parse(c)) util.die("could not parse newly created commit", .{});
    var hdr: util.Buf = .empty;
    util.bufAppend(&hdr, fmtCommit(c, "%h] %s"));
    const author = fmtCommit(c, "%an <%ae>");
    const committer = fmtCommit(c, "%cn <%ce>");
    if (!util.eql(author, committer)) util.bufPrint(&hdr, "\n Author: {s}", .{author});
    if (flags & SUMMARY_SHOW_AUTHOR_DATE != 0) util.bufPrint(&hdr, "\n Date: {s}", .{fmtCommit(c, "%ad")});
    if (!committerIdentSufficientlyGiven()) {
        util.bufPrint(&hdr, "\n Committer: {s}", .{committer});
        if (advice.enabled("implicitIdentity")) {
            util.bufByte(&hdr, '\n');
            util.bufAppend(&hdr, implicitIdentAdvice());
        }
    }
    var head: []const u8 = refs.resolveTarget("HEAD");
    if (util.eql(head, "HEAD")) head = "detached HEAD" else if (util.skipPrefix(head, "refs/heads/")) |h| head = h;
    util.outf("[{s}{s} ", .{ head, if (flags & SUMMARY_INITIAL_COMMIT != 0) " (root-commit)" else "" });
    util.out(hdr.items);
    util.out("\n");

    const co = objects.readCommit(oid) orelse return;
    if (co.parents.len > 1) return;
    var parent_tree: ?Oid = null;
    if (co.parents.len == 1) {
        const p = objects.readCommit(co.parents[0]) orelse return;
        parent_tree = p.tree;
    }
    util.out(diffSummary(parent_tree, co.tree));
}

// ---------------------------------------------------------------------------
// mini diff: shortstat + summary

const Pair = struct {
    status: u8, // 'A', 'D', 'M', 'R', 'T'
    old_path: []const u8 = "",
    new_path: []const u8 = "",
    old_mode: u32 = 0,
    new_mode: u32 = 0,
    old_oid: Oid = hash.zero,
    new_oid: Oid = hash.zero,
};

fn pairLess(_: void, a: Pair, b: Pair) bool {
    const pa = if (a.status == 'D') a.old_path else a.new_path;
    const pb = if (b.status == 'D') b.old_path else b.new_path;
    return std.mem.order(u8, pa, pb) == .lt;
}

fn readBlob(oid: Oid) []const u8 {
    const o = repo_mod.repo().odb().read(oid) orelse return "";
    return o.data;
}

fn isBinary(data: []const u8) bool {
    const n = @min(data.len, 8000);
    return std.mem.indexOfScalar(u8, data[0..n], 0) != null;
}

fn countLines(data: []const u8) usize {
    if (data.len == 0) return 0;
    var n = std.mem.count(u8, data, "\n");
    if (data[data.len - 1] != '\n') n += 1;
    return n;
}

fn lineCounts(a_oid: ?Oid, b_oid: ?Oid) struct { ins: usize, del: usize } {
    const a = if (a_oid) |o| readBlob(o) else "";
    const b = if (b_oid) |o| readBlob(o) else "";
    if (isBinary(a) or isBinary(b)) return .{ .ins = 0, .del = 0 };
    if (a.len == 0) return .{ .ins = countLines(b), .del = 0 };
    if (b.len == 0) return .{ .ins = 0, .del = countLines(a) };
    var d = xdiff.diff(a, b, .{}) catch return .{ .ins = countLines(b), .del = countLines(a) };
    defer d.deinit();
    var ins: usize = 0;
    var del: usize = 0;
    for (d.changes) |ch| {
        ins += @intCast(ch.chg2);
        del += @intCast(ch.chg1);
    }
    return .{ .ins = ins, .del = del };
}

fn isGitlink(mode: u32) bool {
    return mode == 0o160000;
}

/// pprint_rename
pub fn pprintRename(b: *util.Buf, a: []const u8, bn: []const u8) void {
    if (util.needsQuote(a) or util.needsQuote(bn)) {
        util.bufAppend(b, util.cquote(a));
        util.bufAppend(b, " => ");
        util.bufAppend(b, util.cquote(bn));
        return;
    }
    const len_a: isize = @intCast(a.len);
    const len_b: isize = @intCast(bn.len);
    var pfx: isize = 0;
    {
        var i: usize = 0;
        while (i < a.len and i < bn.len and a[i] == bn[i]) : (i += 1) {
            if (a[i] == '/') pfx = @as(isize, @intCast(i)) + 1;
        }
    }
    var sfx: isize = 0;
    {
        const adj: isize = if (pfx != 0) 1 else 0;
        var oi: isize = len_a;
        var ni: isize = len_b;
        while (pfx - adj <= oi and pfx - adj <= ni) {
            const oc: u8 = if (oi < len_a) a[@intCast(oi)] else 0;
            const nc: u8 = if (ni < len_b) bn[@intCast(ni)] else 0;
            if (oc != nc) break;
            if (oc == '/') sfx = len_a - oi;
            oi -= 1;
            ni -= 1;
        }
    }
    var a_mid = len_a - pfx - sfx;
    var b_mid = len_b - pfx - sfx;
    if (a_mid < 0) a_mid = 0;
    if (b_mid < 0) b_mid = 0;
    const p: usize = @intCast(pfx);
    const s: usize = @intCast(sfx);
    if (pfx + sfx != 0) {
        util.bufAppend(b, a[0..p]);
        util.bufByte(b, '{');
    }
    util.bufAppend(b, a[p .. p + @as(usize, @intCast(a_mid))]);
    util.bufAppend(b, " => ");
    util.bufAppend(b, bn[p .. p + @as(usize, @intCast(b_mid))]);
    if (pfx + sfx != 0) {
        util.bufByte(b, '}');
        util.bufAppend(b, a[a.len - s ..]);
    }
}

pub fn diffSummary(old_tree: ?Oid, new_tree: Oid) []const u8 {
    var olds: std.ArrayList(objects.FlatEntry) = .empty;
    var news: std.ArrayList(objects.FlatEntry) = .empty;
    if (old_tree) |t| objects.flattenTree(t, "", &olds);
    objects.flattenTree(new_tree, "", &news);
    var pairs: std.ArrayList(Pair) = .empty;
    var oi: usize = 0;
    var ni: usize = 0;
    while (oi < olds.items.len or ni < news.items.len) {
        const ord: std.math.Order = if (oi >= olds.items.len) .gt else if (ni >= news.items.len) .lt else std.mem.order(u8, olds.items[oi].path, news.items[ni].path);
        switch (ord) {
            .lt => {
                const o = olds.items[oi];
                pairs.append(gpa, .{ .status = 'D', .old_path = o.path, .old_mode = o.mode, .old_oid = o.oid }) catch util.oom();
                oi += 1;
            },
            .gt => {
                const n = news.items[ni];
                pairs.append(gpa, .{ .status = 'A', .new_path = n.path, .new_mode = n.mode, .new_oid = n.oid }) catch util.oom();
                ni += 1;
            },
            .eq => {
                const o = olds.items[oi];
                const n = news.items[ni];
                if (o.mode != n.mode or !hash.eql(o.oid, n.oid)) {
                    const typechange = (o.mode & 0o170000) != (n.mode & 0o170000);
                    if (typechange) {
                        pairs.append(gpa, .{ .status = 'D', .old_path = o.path, .old_mode = o.mode, .old_oid = o.oid }) catch util.oom();
                        pairs.append(gpa, .{ .status = 'A', .new_path = n.path, .new_mode = n.mode, .new_oid = n.oid }) catch util.oom();
                    } else {
                        pairs.append(gpa, .{ .status = 'M', .old_path = o.path, .new_path = n.path, .old_mode = o.mode, .new_mode = n.mode, .old_oid = o.oid, .new_oid = n.oid }) catch util.oom();
                    }
                }
                oi += 1;
                ni += 1;
            },
        }
    }
    // exact rename detection
    var used = gpa.alloc(bool, pairs.items.len) catch util.oom();
    @memset(used, false);
    for (pairs.items) |*p| {
        if (p.status != 'A' or isGitlink(p.new_mode)) continue;
        for (pairs.items, 0..) |*q, j| {
            if (q.status != 'D' or used[j] or isGitlink(q.old_mode)) continue;
            if (!hash.eql(q.old_oid, p.new_oid)) continue;
            if ((q.old_mode & 0o170000) != (p.new_mode & 0o170000)) continue;
            used[j] = true;
            p.status = 'R';
            p.old_path = q.old_path;
            p.old_mode = q.old_mode;
            p.old_oid = q.old_oid;
            break;
        }
    }
    var final: std.ArrayList(Pair) = .empty;
    for (pairs.items, 0..) |p, j| {
        if (used[j]) continue;
        final.append(gpa, p) catch util.oom();
    }
    std.mem.sort(Pair, final.items, {}, pairLess);
    if (final.items.len == 0) return "";

    var files: usize = 0;
    var ins: usize = 0;
    var del: usize = 0;
    for (final.items) |p| {
        files += 1;
        switch (p.status) {
            'A' => if (!isGitlink(p.new_mode)) {
                const r = lineCounts(null, p.new_oid);
                ins += r.ins;
            } else {
                ins += 1;
            },
            'D' => if (!isGitlink(p.old_mode)) {
                const r = lineCounts(p.old_oid, null);
                del += r.del;
            } else {
                del += 1;
            },
            'M' => if (isGitlink(p.old_mode) or isGitlink(p.new_mode)) {
                ins += 1;
                del += 1;
            } else if (!hash.eql(p.old_oid, p.new_oid)) {
                const r = lineCounts(p.old_oid, p.new_oid);
                ins += r.ins;
                del += r.del;
            },
            else => {},
        }
    }
    var b: util.Buf = .empty;
    util.bufPrint(&b, " {d} file{s} changed", .{ files, if (files == 1) "" else "s" });
    if (ins != 0 or del == 0) util.bufPrint(&b, ", {d} insertion{s}(+)", .{ ins, if (ins == 1) "" else "s" });
    if (del != 0 or ins == 0) util.bufPrint(&b, ", {d} deletion{s}(-)", .{ del, if (del == 1) "" else "s" });
    util.bufByte(&b, '\n');
    for (final.items) |p| {
        switch (p.status) {
            'A' => {
                util.bufPrint(&b, " create mode {o:0>6} ", .{p.new_mode});
                util.bufAppend(&b, util.cquote(p.new_path));
                util.bufByte(&b, '\n');
            },
            'D' => {
                util.bufPrint(&b, " delete mode {o:0>6} ", .{p.old_mode});
                util.bufAppend(&b, util.cquote(p.old_path));
                util.bufByte(&b, '\n');
            },
            'R' => {
                util.bufAppend(&b, " rename ");
                pprintRename(&b, p.old_path, p.new_path);
                util.bufAppend(&b, " (100%)\n");
                if (p.old_mode != p.new_mode) util.bufPrint(&b, " mode change {o:0>6} => {o:0>6}\n", .{ p.old_mode, p.new_mode });
            },
            else => {
                if (p.old_mode != p.new_mode) {
                    util.bufPrint(&b, " mode change {o:0>6} => {o:0>6} ", .{ p.old_mode, p.new_mode });
                    util.bufAppend(&b, util.cquote(p.new_path));
                    util.bufByte(&b, '\n');
                }
            },
        }
    }
    return b.items;
}
