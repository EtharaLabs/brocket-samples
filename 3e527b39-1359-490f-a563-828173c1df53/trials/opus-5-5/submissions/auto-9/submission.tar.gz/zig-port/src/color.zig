//! Color parsing and color.* boolean handling (port of color.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");

pub const RESET = "\x1b[m";
pub const BOLD = "\x1b[1m";
pub const RED = "\x1b[31m";
pub const GREEN = "\x1b[32m";
pub const YELLOW = "\x1b[33m";
pub const BLUE = "\x1b[34m";
pub const MAGENTA = "\x1b[35m";
pub const CYAN = "\x1b[36m";
pub const BOLD_RED = "\x1b[1;31m";
pub const BOLD_GREEN = "\x1b[1;32m";
pub const BOLD_YELLOW = "\x1b[1;33m";
pub const BOLD_BLUE = "\x1b[1;34m";
pub const BOLD_MAGENTA = "\x1b[1;35m";
pub const BOLD_CYAN = "\x1b[1;36m";
pub const FAINT = "\x1b[2m";
pub const REVERSE = "\x1b[7m";

pub const ColorBool = enum { unknown, never, always, auto };

const CType = enum(u8) { unspecified, normal, ansi, c256, rgb };
const Color = struct {
    t: CType = .unspecified,
    value: u32 = 0,
    r: u8 = 0,
    g: u8 = 0,
    b: u8 = 0,

    fn empty(self: Color) bool {
        return @intFromEnum(self.t) <= @intFromEnum(CType.normal);
    }
};

fn matchWord(word: []const u8, m: []const u8) bool {
    return std.ascii.eqlIgnoreCase(word, m);
}

fn hexval(ch: u8) i32 {
    return switch (ch) {
        '0'...'9' => ch - '0',
        'a'...'f' => ch - 'a' + 10,
        'A'...'F' => ch - 'A' + 10,
        else => -1,
    };
}

fn getHex(s: []const u8, width: usize) ?u8 {
    const hi = hexval(s[0]);
    const lo = hexval(s[width - 1]);
    if (hi < 0 or lo < 0) return null;
    return @intCast((hi << 4) | lo);
}

fn parseAnsiColor(out: *Color, name0: []const u8) bool {
    const names = [_][]const u8{ "black", "red", "green", "yellow", "blue", "magenta", "cyan", "white" };
    var off: u32 = 30;
    var name = name0;
    if (matchWord(name, "default")) {
        out.* = .{ .t = .ansi, .value = 9 + off };
        return true;
    }
    if (name.len >= 6 and std.ascii.eqlIgnoreCase(name[0..6], "bright")) {
        off = 90;
        name = name[6..];
    }
    for (names, 0..) |n, i| {
        if (matchWord(name, n)) {
            out.* = .{ .t = .ansi, .value = @as(u32, @intCast(i)) + off };
            return true;
        }
    }
    return false;
}

fn parseOneColor(out: *Color, name: []const u8) bool {
    if (matchWord(name, "normal")) {
        out.t = .normal;
        return true;
    }
    if ((name.len == 7 or name.len == 4) and name[0] == '#') {
        const w: usize = if (name.len == 7) 2 else 1;
        const s = name[1..];
        if (getHex(s, w)) |r| if (getHex(s[w..], w)) |g| if (getHex(s[2 * w ..], w)) |b| {
            out.* = .{ .t = .rgb, .r = r, .g = g, .b = b };
            return true;
        };
    }
    if (parseAnsiColor(out, name)) return true;
    // strtol(name, 10) consuming the whole word
    var s = name;
    var neg = false;
    if (s.len > 0 and (s[0] == '+' or s[0] == '-')) {
        neg = s[0] == '-';
        s = s[1..];
    }
    if (s.len == 0) return false;
    var val: i64 = 0;
    for (s) |ch| {
        if (ch < '0' or ch > '9') return false;
        val = val *| 10 +| (ch - '0');
    }
    if (neg) val = -val;
    if (val < -1) return false;
    if (val < 0) {
        out.t = .normal;
        return true;
    }
    if (val < 8) {
        out.* = .{ .t = .ansi, .value = @intCast(val + 30) };
        return true;
    }
    if (val < 16) {
        out.* = .{ .t = .ansi, .value = @intCast(val - 8 + 90) };
        return true;
    }
    if (val < 256) {
        out.* = .{ .t = .c256, .value = @intCast(val) };
        return true;
    }
    return false;
}

fn parseAttr(name0: []const u8) i32 {
    const Attr = struct { n: []const u8, v: i32, neg: i32 };
    const attrs = [_]Attr{
        .{ .n = "bold", .v = 1, .neg = 22 },
        .{ .n = "dim", .v = 2, .neg = 22 },
        .{ .n = "italic", .v = 3, .neg = 23 },
        .{ .n = "ul", .v = 4, .neg = 24 },
        .{ .n = "blink", .v = 5, .neg = 25 },
        .{ .n = "reverse", .v = 7, .neg = 27 },
        .{ .n = "strike", .v = 9, .neg = 29 },
    };
    var name = name0;
    var negate = false;
    if (util.startsWith(name, "no")) {
        name = name[2..];
        if (util.startsWith(name, "-")) name = name[1..];
        negate = true;
    }
    for (attrs) |a| {
        if (util.eql(a.n, name)) return if (negate) a.neg else a.v;
    }
    return -1;
}

fn colorOutput(b: *util.Buf, c: Color, background: bool) void {
    const off: u32 = if (background) 10 else 0;
    switch (c.t) {
        .unspecified, .normal => {},
        .ansi => util.bufPrint(b, "{d}", .{c.value + off}),
        .c256 => util.bufPrint(b, "{d};5;{d}", .{ 38 + off, c.value }),
        .rgb => util.bufPrint(b, "{d};2;{d};{d};{d}", .{ 38 + off, c.r, c.g, c.b }),
    }
}

fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r' or ch == 11 or ch == 12;
}

/// Parse a color description ("bold red", "#ff0000 ul", ...) into an ANSI
/// escape sequence. Returns null (silently) if the value is invalid.
/// An empty value yields "".
pub fn parseColor(value: []const u8) ?[]const u8 {
    var ptr: usize = 0;
    while (ptr < value.len and isSpace(value[ptr])) ptr += 1;
    if (ptr == value.len) return "";
    var has_reset = false;
    var attr: u32 = 0;
    var fg = Color{};
    var bg = Color{};
    while (ptr < value.len) {
        const start = ptr;
        while (ptr < value.len and !isSpace(value[ptr])) ptr += 1;
        const word = value[start..ptr];
        while (ptr < value.len and isSpace(value[ptr])) ptr += 1;
        if (matchWord(word, "reset")) {
            has_reset = true;
            continue;
        }
        var c = Color{};
        if (parseOneColor(&c, word)) {
            if (fg.t == .unspecified) {
                fg = c;
                continue;
            }
            if (bg.t == .unspecified) {
                bg = c;
                continue;
            }
            return null;
        }
        const v = parseAttr(word);
        if (v < 0) return null;
        attr |= @as(u32, 1) << @intCast(v);
    }
    var b: util.Buf = .empty;
    if (has_reset or attr != 0 or !fg.empty() or !bg.empty()) {
        var sep: u32 = if (has_reset) 1 else 0;
        util.bufAppend(&b, "\x1b[");
        var i: u5 = 0;
        while (attr != 0) : (i += 1) {
            const bitv = @as(u32, 1) << i;
            if (attr & bitv == 0) continue;
            attr &= ~bitv;
            if (sep > 0) util.bufByte(&b, ';');
            sep += 1;
            util.bufPrint(&b, "{d}", .{i});
        }
        if (!fg.empty()) {
            if (sep > 0) util.bufByte(&b, ';');
            sep += 1;
            colorOutput(&b, fg, false);
        }
        if (!bg.empty()) {
            if (sep > 0) util.bufByte(&b, ';');
            sep += 1;
            colorOutput(&b, bg, true);
        }
        util.bufByte(&b, 'm');
    }
    return b.items;
}

/// Like parseColor, but prints "error: invalid color value: ..." on failure
/// (as git's color_parse does).
pub fn parseColorOrError(value: []const u8) ?[]const u8 {
    return parseColor(value) orelse {
        util.err("invalid color value: {s}", .{value});
        return null;
    };
}

/// git_config_colorbool: value may be null (a bare "key" in config = true).
/// Dies on a non-boolean value (like git_config_bool) when `var_name` is given.
pub fn configColorBool(var_name: ?[]const u8, value: ?[]const u8) ColorBool {
    if (value) |v| {
        if (std.ascii.eqlIgnoreCase(v, "never")) return .never;
        if (std.ascii.eqlIgnoreCase(v, "always")) return .always;
        if (std.ascii.eqlIgnoreCase(v, "auto")) return .auto;
    }
    const vn = var_name orelse return .unknown;
    const v = value orelse return .auto;
    const config = @import("config.zig");
    const b = config.parseBool(v) orelse util.die("bad boolean config value '{s}' for '{s}'", .{ v, vn });
    return if (b) .auto else .never;
}

pub fn isTerminalDumb() bool {
    const t = os.getenv("TERM") orelse return true;
    return util.eql(t, "dumb");
}

/// Whether a pager is being used for our stdout.
pub fn pagerInUse() bool {
    if (os.pager_pid != 0) return true;
    const v = os.getenv("GIT_PAGER_IN_USE") orelse return false;
    const config = @import("config.zig");
    return config.parseBool(v) orelse false;
}

/// want_color for a parsed ColorBool. `stdout_is_tty`: null = check isatty(1).
/// "auto" means: stdout is a tty (or a pager is in use and color.pager is
/// not false) and TERM is not dumb.
pub fn wantColorBool(cb: ColorBool, stdout_is_tty: ?bool) bool {
    var v = cb;
    if (v == .unknown) v = .auto;
    if (v == .auto) {
        const tty = stdout_is_tty orelse os.isatty(1);
        var pager_color = true;
        if (tty == false and pagerInUse()) {
            const repo_mod = @import("repo.zig");
            if (repo_mod.cfg.getEntry("color.pager")) |e| {
                pager_color = if (e.value) |s| (@import("config.zig").parseBool(s) orelse true) else true;
            }
        }
        if (tty or (pagerInUse() and pager_color)) return !isTerminalDumb();
        return false;
    }
    return v == .always;
}

/// Decide whether to use color given a config value (e.g. of color.ui or
/// color.diff): "auto"/"always"/"never"/"true"/"false"/null(=unset => auto).
pub fn wantColor(config_value: ?[]const u8, stdout_is_tty: bool) bool {
    var cb: ColorBool = .auto;
    if (config_value) |v| {
        cb = configColorBool("color", v);
    }
    return wantColorBool(cb, stdout_is_tty);
}

/// Look up a color.* boolean in the loaded config following git's rules:
/// the slot (e.g. "color.diff") falls back to color.ui, default auto.
/// Returns whether to use color on stdout.
pub fn wantColorFor(slot: ?[]const u8) bool {
    const repo_mod = @import("repo.zig");
    var cb: ColorBool = .unknown;
    if (slot) |s| {
        if (repo_mod.cfg.getEntry(s)) |e| cb = configColorBool(s, e.value);
    }
    if (cb == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| cb = configColorBool("color.ui", e.value);
    }
    return wantColorBool(cb, null);
}
