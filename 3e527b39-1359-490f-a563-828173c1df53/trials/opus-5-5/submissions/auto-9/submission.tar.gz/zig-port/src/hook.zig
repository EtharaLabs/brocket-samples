//! Running hooks (hook.c, traditional hooks in $GIT_DIR/hooks or core.hooksPath).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const advice = @import("advice.zig");
const gpa = util.gpa;

var advised: std.ArrayList([]const u8) = .empty;

/// find_hook: path of an executable hook, or null.
pub fn find(name: []const u8) ?[]const u8 {
    const r = repo_mod.repo();
    const dir = repo_mod.cfg.getPath("core.hookspath") orelse r.commonPath("hooks");
    const path = util.concat(&.{ dir, "/", name });
    if (os.access(path, 1)) return path;
    if (os.errno() == 13 and advice.enabled("ignoredHook")) {
        for (advised.items) |a| if (util.eql(a, name)) return null;
        advised.append(gpa, name) catch util.oom();
        advice.advise(util.fmt("The '{s}' hook was ignored because it's not set as executable.\n" ++
            "You can disable this warning with `git config set advice.ignoredHook false`.", .{path}));
    }
    return null;
}

pub const Opts = struct {
    env: []const [2][]const u8 = &.{},
    stdin_data: ?[]const u8 = null,
    invoked: ?*bool = null,
};

/// run_hooks_opt: returns the hook's exit status (0 when there is no hook).
pub fn run(name: []const u8, args: []const []const u8, o: Opts) u8 {
    const path = find(name) orelse {
        if (o.invoked) |p| p.* = false;
        return 0;
    };
    if (o.invoked) |p| p.* = true;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, path) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    const res = os.run(argv.items, .{
        .env = o.env,
        .stdin_data = o.stdin_data,
        .no_stdin = o.stdin_data == null,
        .stdout_to_stderr = true,
    });
    return res.status;
}

/// run_commit_hook (commit.c)
pub fn runCommitHook(editor_is_used: bool, index_file: []const u8, invoked: ?*bool, name: []const u8, args: []const []const u8) u8 {
    var env: std.ArrayList([2][]const u8) = .empty;
    env.append(gpa, .{ "GIT_INDEX_FILE", index_file }) catch util.oom();
    if (!editor_is_used) env.append(gpa, .{ "GIT_EDITOR", ":" }) catch util.oom();
    return run(name, args, .{ .env = env.items, .invoked = invoked });
}
