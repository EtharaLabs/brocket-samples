//! Port of apply.c: parse and apply patches (git apply / git am backend).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const odb_mod = @import("odb.zig");
const diff = @import("diff.zig");
const zlib = @import("zlib.zig");
const wildmatch = @import("wildmatch.zig");
const xdiff = @import("xdiff.zig");
const entry_mod = @import("entry.zig");
const convert = @import("convert.zig");
const pathspec = @import("pathspec.zig");
const revparse = @import("revparse.zig");

const gpa = util.gpa;
const Buf = util.Buf;
const Oid = hash.Oid;

pub const WsErrorAction = enum { nowarn, warn, die, correct };
pub const WsIgnore = enum { none, change };

pub const VERBOSITY_SILENT: i32 = -1;
pub const VERBOSITY_NORMAL: i32 = 0;
pub const VERBOSITY_VERBOSE: i32 = 1;

pub const APPLY_OPT_INACCURATE_EOF: u32 = 1 << 0;
pub const APPLY_OPT_RECOUNT: u32 = 1 << 1;

const MAX_APPLY_SIZE: usize = 1024 * 1024 * 1023;

const BINARY_DELTA_DEFLATED: i64 = 1;
const BINARY_LITERAL_DEFLATED: i64 = 2;

pub const Fragment = struct {
    leading: i64 = 0, // also binary_patch_method
    trailing: i64 = 0,
    oldpos: i64 = 0,
    oldlines: i64 = 0,
    newpos: i64 = 0,
    newlines: i64 = 0,
    patch: []const u8 = "",
    rejected: bool = false,
    linenr: i32 = 0,
    next: ?*Fragment = null,
};

pub const Patch = struct {
    new_name: ?[]const u8 = null,
    old_name: ?[]const u8 = null,
    def_name: ?[]const u8 = null,
    old_mode: u32 = 0,
    new_mode: u32 = 0,
    is_new: i32 = 0,
    is_delete: i32 = 0,
    rejected: bool = false,
    ws_rule: u32 = 0,
    lines_added: i32 = 0,
    lines_deleted: i32 = 0,
    score: i32 = 0,
    extension_linenr: i32 = 0,
    is_toplevel_relative: bool = false,
    inaccurate_eof: bool = false,
    is_binary: bool = false,
    is_copy: bool = false,
    is_rename: bool = false,
    recount: bool = false,
    conflicted_threeway: bool = false,
    direct_to_threeway: bool = false,
    crlf_in_old: bool = false,
    fragments: ?*Fragment = null,
    result: []const u8 = "",
    old_oid_prefix: []const u8 = "",
    new_oid_prefix: []const u8 = "",
    next: ?*Patch = null,
    threeway_stage: [3]Oid = .{ hash.zero, hash.zero, hash.zero },
};

const NameLimit = struct { pattern: []const u8, include: bool };

const FnItem = union(enum) {
    patch: *Patch,
    to_be_deleted,
    was_deleted,
};

pub const State = struct {
    prefix: ?[]const u8 = null,

    apply: bool = true,
    cached: bool = false,
    check: bool = false,
    check_index: bool = false,
    update_index: bool = false,
    ita_only: bool = false,

    diffstat: bool = false,
    numstat: bool = false,
    summary: bool = false,

    allow_overlap: bool = false,
    apply_in_reverse: bool = false,
    apply_with_reject: bool = false,
    no_add: bool = false,
    threeway: bool = false,
    unidiff_zero: bool = false,
    unsafe_paths: bool = false,
    allow_empty: bool = false,

    index_file: ?[]const u8 = null,
    apply_verbosity: i32 = VERBOSITY_NORMAL,
    merge_variant: xdiff.MergeFavor = .none,
    fake_ancestor: ?[]const u8 = null,
    patch_input_file: []const u8 = "",
    line_termination: u8 = '\n',
    root: Buf = .empty,
    p_value: i32 = 1,
    p_value_known: bool = false,
    p_context: u32 = std.math.maxInt(u32),

    limit_by_name: std.ArrayList(NameLimit) = .empty,
    has_include: bool = false,

    linenr: i32 = 1,
    removed_symlinks: std.StringHashMapUnmanaged(void) = .empty,
    kept_symlinks: std.StringHashMapUnmanaged(void) = .empty,

    max_change: i32 = 0,
    max_len: i32 = 0,

    fn_table: std.StringHashMapUnmanaged(FnItem) = .empty,

    ws_error_action: WsErrorAction = .warn,
    ws_ignore_action: WsIgnore = .none,
    whitespace_option: ?[]const u8 = null,
    whitespace_error: i32 = 0,
    squelch_whitespace_errors: i32 = 5,
    applied_after_fixing_ws: i32 = 0,

    // config-derived
    cfg_default_whitespace: ?[]const u8 = null,
    cfg_default_ignorewhitespace: ?[]const u8 = null,

    // index in use
    istate: ?*index_mod.Index = null,
    index_locked: bool = false,
};

// ---------------------------------------------------------------------------
// error reporting (muted in silent mode, like set_error_routine(mute_routine))

pub var muted: bool = false;

fn errorf(comptime f: []const u8, args: anytype) i32 {
    if (!muted) util.err(f, args);
    return -1;
}
fn warnf(comptime f: []const u8, args: anytype) void {
    if (!muted) util.warn(f, args);
}

// ---------------------------------------------------------------------------
// small helpers

fn at(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r' or c == 11 or c == 12;
}

fn isDigit(c: u8) bool {
    return c >= '0' and c <= '9';
}

const Strtoul = struct { val: u64, len: usize };

fn strtoul(s: []const u8, base: u8) Strtoul {
    var i: usize = 0;
    while (i < s.len and isSpace(s[i])) i += 1;
    if (i < s.len and s[i] == '+') i += 1;
    const start = i;
    var v: u64 = 0;
    while (i < s.len) {
        const c = s[i];
        const d: u64 = if (c >= '0' and c <= '9') c - '0' else if (c >= 'a' and c <= 'z') c - 'a' + 10 else if (c >= 'A' and c <= 'Z') c - 'A' + 10 else 99;
        if (d >= base) break;
        v = v *% base +% d;
        i += 1;
    }
    if (i == start) return .{ .val = 0, .len = 0 };
    return .{ .val = v, .len = i };
}

fn linelen(buffer: []const u8, size: usize) usize {
    var len: usize = 0;
    const n = @min(size, buffer.len);
    while (len < n) {
        len += 1;
        if (buffer[len - 1] == '\n') break;
    }
    return len;
}

fn isDevNull(s: []const u8) bool {
    return util.startsWith(s, "/dev/null") and isSpace(at(s, 9));
}

const TERM_SPACE: u32 = 1;
const TERM_TAB: u32 = 2;

fn nameTerminate(c: u8, terminate: u32) bool {
    if (c == ' ' and terminate & TERM_SPACE == 0) return false;
    if (c == '\t' and terminate & TERM_TAB == 0) return false;
    return true;
}

fn squashSlash(name: ?[]const u8) ?[]const u8 {
    const n = name orelse return null;
    var b: Buf = .empty;
    var i: usize = 0;
    while (i < n.len) {
        const c = n[i];
        util.bufByte(&b, c);
        i += 1;
        if (c == '/') {
            while (i < n.len and n[i] == '/') i += 1;
        }
    }
    return b.items;
}

fn findNameGnu(root: *const Buf, line: []const u8, p_value0: i32) ?[]const u8 {
    const uq = util.cunquote(line) orelse return null;
    const name = uq.value;
    var cp: usize = 0;
    var p_value = p_value0;
    while (p_value > 0) : (p_value -= 1) {
        const k = std.mem.indexOfScalarPos(u8, name, cp, '/') orelse return null;
        cp = k + 1;
    }
    return squashSlash(util.concat(&.{ root.items, name[cp..] }));
}

fn saneTzLen(line: []const u8, len: usize) usize {
    if (len < 6 or line[len - 6] != ' ') return 0;
    const tz = len - 6;
    if (line[tz + 1] != '+' and line[tz + 1] != '-') return 0;
    var p = tz + 2;
    while (p != len) : (p += 1) {
        if (!isDigit(line[p])) return 0;
    }
    return len - tz;
}

fn tzWithColonLen(line: []const u8, len: usize) usize {
    if (len < 7 or line[len - 3] != ':') return 0;
    const tz = len - 7;
    if (line[tz] != ' ' or (line[tz + 1] != '+' and line[tz + 1] != '-')) return 0;
    const p = tz + 2;
    if (!isDigit(line[p]) or !isDigit(line[p + 1]) or line[p + 2] != ':' or
        !isDigit(line[p + 3]) or !isDigit(line[p + 4])) return 0;
    return len - tz;
}

fn dateLen(line: []const u8, len: usize) usize {
    if (len < 8 or line[len - 3] != '-') return 0;
    var date = len - 8;
    const p = date;
    if (!isDigit(line[p]) or !isDigit(line[p + 1]) or line[p + 2] != '-' or
        !isDigit(line[p + 3]) or !isDigit(line[p + 4]) or line[p + 5] != '-' or
        !isDigit(line[p + 6]) or !isDigit(line[p + 7])) return 0;
    if (date >= 2 and isDigit(line[date - 1]) and isDigit(line[date - 2])) date -= 2;
    return len - date;
}

fn shortTimeLen(line: []const u8, len: usize) usize {
    if (len < 9 or line[len - 3] != ':') return 0;
    const t = len - 9;
    const p = t;
    if (line[p] != ' ' or
        !isDigit(line[p + 1]) or !isDigit(line[p + 2]) or line[p + 3] != ':' or
        !isDigit(line[p + 4]) or !isDigit(line[p + 5]) or line[p + 6] != ':' or
        !isDigit(line[p + 7]) or !isDigit(line[p + 8])) return 0;
    return len - t;
}

fn fractionalTimeLen(line: []const u8, len: usize) usize {
    if (len == 0 or !isDigit(line[len - 1])) return 0;
    var p = len - 1;
    while (p > 0 and isDigit(line[p])) p -= 1;
    if (line[p] != '.') return 0;
    const n = shortTimeLen(line, p);
    if (n == 0) return 0;
    return len - p + n;
}

fn trailingSpacesLen(line: []const u8, len: usize) usize {
    if (len == 0 or line[len - 1] != ' ') return 0;
    var p = len;
    while (p != 0) {
        p -= 1;
        if (line[p] != ' ') return len - (p + 1);
    }
    return len;
}

fn diffTimestampLen(line: []const u8, len: usize) usize {
    var end = len;
    if (len == 0 or !isDigit(line[end - 1])) return 0;
    var n = saneTzLen(line, end);
    if (n == 0) n = tzWithColonLen(line, end);
    end -= n;
    n = shortTimeLen(line, end);
    if (n == 0) n = fractionalTimeLen(line, end);
    end -= n;
    n = dateLen(line, end);
    if (n == 0) return 0;
    end -= n;
    if (end == 0) return 0;
    if (line[end - 1] == '\t') {
        end -= 1;
        return len - end;
    }
    if (line[end - 1] != ' ') return 0;
    end -= trailingSpacesLen(line, end);
    return len - end;
}

/// find_name_common; `end` is an optional limit (index into line)
fn findNameCommon(root: *const Buf, line: []const u8, def: ?[]const u8, p_value0: i32, end: ?usize, terminate: u32) ?[]const u8 {
    var p_value = p_value0;
    var start: ?usize = null;
    if (p_value == 0) start = 0;
    var i: usize = 0;
    while (true) {
        if (end) |e| {
            if (i == e) break;
        } else if (i >= line.len) break;
        const c = line[i];
        if (end == null and isSpace(c)) {
            if (c == '\n') break;
            if (nameTerminate(c, terminate)) break;
        }
        i += 1;
        if (c == '/') {
            p_value -= 1;
            if (p_value == 0) start = i;
        }
    }
    const s = start orelse return squashSlash(if (def) |d| util.dupe(d) else null);
    const len = i - s;
    if (len == 0) return squashSlash(if (def) |d| util.dupe(d) else null);
    if (def) |d| {
        if (d.len < len and std.mem.eql(u8, line[s .. s + d.len], d)) return squashSlash(util.dupe(d));
    }
    return squashSlash(util.concat(&.{ root.items, line[s .. s + len] }));
}

fn findName(root: *const Buf, line: []const u8, def: ?[]const u8, p_value: i32, terminate: u32) ?[]const u8 {
    if (at(line, 0) == '"') {
        if (findNameGnu(root, line, p_value)) |n| return n;
    }
    return findNameCommon(root, line, def, p_value, null, terminate);
}

fn findNameTraditional(root: *const Buf, line: []const u8, def: ?[]const u8, p_value: i32) ?[]const u8 {
    if (at(line, 0) == '"') {
        if (findNameGnu(root, line, p_value)) |n| return n;
    }
    var len = std.mem.indexOfScalar(u8, line, '\n') orelse line.len;
    const dl = diffTimestampLen(line, len);
    if (dl == 0) return findNameCommon(root, line, def, p_value, null, TERM_TAB);
    len -= dl;
    return findNameCommon(root, line, def, p_value, len, 0);
}

fn countSlashes(s: []const u8) i32 {
    var n: i32 = 0;
    for (s) |c| {
        if (c == '/') n += 1;
    }
    return n;
}

fn guessPValue(state: *State, nameline: []const u8) i32 {
    if (isDevNull(nameline)) return -1;
    const name = findNameTraditional(&state.root, nameline, null, 0) orelse return -1;
    var val: i32 = -1;
    const cp = std.mem.indexOfScalar(u8, name, '/');
    if (cp == null) {
        val = 0;
    } else if (state.prefix) |prefix| {
        if (util.startsWith(name, prefix)) {
            val = countSlashes(prefix);
        } else {
            if (util.startsWith(name[cp.? + 1 ..], prefix)) val = countSlashes(prefix) + 1;
        }
    }
    return val;
}

/// has_epoch_timestamp: "^[0-2][0-9]:([0-5][0-9]):00(\.0+)? ([-+][0-2][0-9]:?[0-5][0-9])\n"
fn hasEpochTimestamp(nameline: []const u8) bool {
    var ts: ?usize = null;
    var i: usize = 0;
    while (i < nameline.len and nameline[i] != '\n') : (i += 1) {
        if (nameline[i] == '\t') ts = i + 1;
    }
    var t = nameline[ts orelse return false ..];
    var epoch_hour: i32 = 0;
    if (util.skipPrefix(t, "1969-12-31 ")) |r| {
        epoch_hour = 24;
        t = r;
    } else if (util.skipPrefix(t, "1970-01-01 ")) |r| {
        epoch_hour = 0;
        t = r;
    } else return false;
    // match regexp manually
    if (t.len < 8) return false;
    if (!(t[0] >= '0' and t[0] <= '2') or !isDigit(t[1]) or t[2] != ':') return false;
    if (!(t[3] >= '0' and t[3] <= '5') or !isDigit(t[4]) or t[5] != ':') return false;
    if (t[6] != '0' or t[7] != '0') return false;
    var p: usize = 8;
    if (at(t, p) == '.' and at(t, p + 1) == '0') {
        p += 1;
        while (at(t, p) == '0') p += 1;
    }
    if (at(t, p) != ' ') return false;
    p += 1;
    const zs = p;
    if (at(t, p) != '-' and at(t, p) != '+') return false;
    p += 1;
    if (!(at(t, p) >= '0' and at(t, p) <= '2') or !isDigit(at(t, p + 1))) return false;
    p += 2;
    var has_colon = false;
    if (at(t, p) == ':') {
        has_colon = true;
        p += 1;
    }
    if (!(at(t, p) >= '0' and at(t, p) <= '5') or !isDigit(at(t, p + 1))) return false;
    p += 2;
    if (at(t, p) != '\n') return false;

    const hour: i32 = (t[0] - '0') * 10 + (t[1] - '0');
    const minute: i32 = (t[3] - '0') * 10 + (t[4] - '0');
    const zh: i32 = (t[zs + 1] - '0') * 10 + (t[zs + 2] - '0');
    var zoneoffset: i32 = undefined;
    if (has_colon) {
        zoneoffset = zh * 60 + (t[zs + 4] - '0') * 10 + (t[zs + 5] - '0');
    } else {
        const v = zh * 100 + (t[zs + 3] - '0') * 10 + (t[zs + 4] - '0');
        zoneoffset = @divTrunc(v, 100) * 60 + @rem(v, 100);
    }
    if (t[zs] == '-') zoneoffset = -zoneoffset;
    return hour * 60 + minute - zoneoffset == epoch_hour * 60;
}

fn parseTraditionalPatch(state: *State, first0: []const u8, second0: []const u8, patch: *Patch) i32 {
    const first = first0[4..];
    const second = second0[4..];
    if (!state.p_value_known) {
        var p = guessPValue(state, first);
        const q = guessPValue(state, second);
        if (p < 0) p = q;
        if (0 <= p and p == q) {
            state.p_value = p;
            state.p_value_known = true;
        }
    }
    var name: ?[]const u8 = null;
    if (isDevNull(first)) {
        patch.is_new = 1;
        patch.is_delete = 0;
        name = findNameTraditional(&state.root, second, null, state.p_value);
        patch.new_name = name;
    } else if (isDevNull(second)) {
        patch.is_new = 0;
        patch.is_delete = 1;
        name = findNameTraditional(&state.root, first, null, state.p_value);
        patch.old_name = name;
    } else {
        const first_name = findNameTraditional(&state.root, first, null, state.p_value);
        name = findNameTraditional(&state.root, second, first_name, state.p_value);
        if (hasEpochTimestamp(first)) {
            patch.is_new = 1;
            patch.is_delete = 0;
            patch.new_name = name;
        } else if (hasEpochTimestamp(second)) {
            patch.is_new = 0;
            patch.is_delete = 1;
            patch.old_name = name;
        } else {
            patch.old_name = name;
            patch.new_name = name;
        }
    }
    if (name == null)
        return errorf("unable to find filename in patch at {s}:{d}", .{ state.patch_input_file, state.linenr });
    return 0;
}

// ---------------------------------------------------------------------------
// git diff header parsing

const GitdiffData = struct {
    root: *const Buf,
    patch_input_file: ?[]const u8,
    linenr: i32,
    p_value: i32,
};

const DIFF_OLD_NAME = 0;
const DIFF_NEW_NAME = 1;

fn gitdiffVerifyName(st: *GitdiffData, line: []const u8, isnull: bool, name: *?[]const u8, side: u32) i32 {
    if (name.* == null and !isnull) {
        name.* = findName(st.root, line, null, st.p_value, TERM_TAB);
        return 0;
    }
    if (name.*) |n| {
        if (isnull) {
            if (st.patch_input_file) |f|
                return errorf("git apply: bad git-diff - expected /dev/null, got {s} at {s}:{d}", .{ n, f, st.linenr });
            return errorf("git apply: bad git-diff - expected /dev/null, got {s} on line {d}", .{ n, st.linenr });
        }
        const another = findName(st.root, line, null, st.p_value, TERM_TAB);
        if (another == null or !util.eql(another.?, n)) {
            if (st.patch_input_file) |f| {
                if (side == DIFF_NEW_NAME)
                    return errorf("git apply: bad git-diff - inconsistent new filename at {s}:{d}", .{ f, st.linenr });
                return errorf("git apply: bad git-diff - inconsistent old filename at {s}:{d}", .{ f, st.linenr });
            }
            if (side == DIFF_NEW_NAME)
                return errorf("git apply: bad git-diff - inconsistent new filename on line {d}", .{st.linenr});
            return errorf("git apply: bad git-diff - inconsistent old filename on line {d}", .{st.linenr});
        }
    } else {
        if (!isDevNull(line)) {
            if (st.patch_input_file) |f|
                return errorf("git apply: bad git-diff - expected /dev/null at {s}:{d}", .{ f, st.linenr });
            return errorf("git apply: bad git-diff - expected /dev/null on line {d}", .{st.linenr});
        }
    }
    return 0;
}

fn parseModeLine(line: []const u8, patch_input_file: ?[]const u8, linenr: i32, mode: *u32) i32 {
    const r = strtoul(line, 8);
    if (r.len == 0 or !isSpace(at(line, r.len))) {
        const l = std.mem.trimEnd(u8, line, "\n");
        if (patch_input_file) |f|
            return errorf("invalid mode at {s}:{d}: {s}\n", .{ f, linenr, l });
        return errorf("invalid mode on line {d}: {s}\n", .{ linenr, l });
    }
    mode.* = index_mod.canonMode(@truncate(r.val));
    return 0;
}

const HdrOp = enum { hdrend, oldname, newname, oldmode, newmode, delete, newfile, copysrc, copydst, renamesrc, renamedst, similarity, dissimilarity, index, unrecognized };

const optable = [_]struct { str: []const u8, op: HdrOp }{
    .{ .str = "@@ -", .op = .hdrend },
    .{ .str = "--- ", .op = .oldname },
    .{ .str = "+++ ", .op = .newname },
    .{ .str = "old mode ", .op = .oldmode },
    .{ .str = "new mode ", .op = .newmode },
    .{ .str = "deleted file mode ", .op = .delete },
    .{ .str = "new file mode ", .op = .newfile },
    .{ .str = "copy from ", .op = .copysrc },
    .{ .str = "copy to ", .op = .copydst },
    .{ .str = "rename old ", .op = .renamesrc },
    .{ .str = "rename new ", .op = .renamedst },
    .{ .str = "rename from ", .op = .renamesrc },
    .{ .str = "rename to ", .op = .renamedst },
    .{ .str = "similarity index ", .op = .similarity },
    .{ .str = "dissimilarity index ", .op = .dissimilarity },
    .{ .str = "index ", .op = .index },
    .{ .str = "", .op = .unrecognized },
};

fn runHdrOp(st: *GitdiffData, op: HdrOp, line: []const u8, patch: *Patch) i32 {
    const pv1 = if (st.p_value != 0) st.p_value - 1 else 0;
    switch (op) {
        .hdrend, .unrecognized => return 1,
        .oldname => return gitdiffVerifyName(st, line, patch.is_new != 0, &patch.old_name, DIFF_OLD_NAME),
        .newname => return gitdiffVerifyName(st, line, patch.is_delete != 0, &patch.new_name, DIFF_NEW_NAME),
        .oldmode => return parseModeLine(line, st.patch_input_file, st.linenr, &patch.old_mode),
        .newmode => return parseModeLine(line, st.patch_input_file, st.linenr, &patch.new_mode),
        .delete => {
            patch.is_delete = 1;
            patch.old_name = patch.def_name;
            return parseModeLine(line, st.patch_input_file, st.linenr, &patch.old_mode);
        },
        .newfile => {
            patch.is_new = 1;
            patch.new_name = patch.def_name;
            return parseModeLine(line, st.patch_input_file, st.linenr, &patch.new_mode);
        },
        .copysrc => {
            patch.is_copy = true;
            patch.old_name = findName(st.root, line, null, pv1, 0);
            return 0;
        },
        .copydst => {
            patch.is_copy = true;
            patch.new_name = findName(st.root, line, null, pv1, 0);
            return 0;
        },
        .renamesrc => {
            patch.is_rename = true;
            patch.old_name = findName(st.root, line, null, pv1, 0);
            return 0;
        },
        .renamedst => {
            patch.is_rename = true;
            patch.new_name = findName(st.root, line, null, pv1, 0);
            return 0;
        },
        .similarity, .dissimilarity => {
            const v = strtoul(line, 10).val;
            if (v <= 100) patch.score = @intCast(v);
            return 0;
        },
        .index => {
            const hexsz: usize = hash.HEXSZ;
            const dot = std.mem.indexOfScalar(u8, line, '.') orelse return 0;
            if (at(line, dot + 1) != '.' or hexsz < dot) return 0;
            patch.old_oid_prefix = util.dupe(line[0..dot]);
            const rest = line[dot + 2 ..];
            const eol = std.mem.indexOfScalar(u8, rest, '\n') orelse rest.len;
            var p = std.mem.indexOfScalar(u8, rest, ' ') orelse eol;
            if (eol < p) p = eol;
            if (hexsz < p) return 0;
            patch.new_oid_prefix = util.dupe(rest[0..p]);
            if (at(rest, p) == ' ') return parseModeLine(rest[p + 1 ..], st.patch_input_file, st.linenr, &patch.old_mode);
            return 0;
        },
    }
}

fn skipTreePrefix(p_value: i32, line: []const u8) ?usize {
    if (p_value == 0) return if (line.len > 0 and line[0] == '/') null else 0;
    var nslash = p_value;
    for (line, 0..) |c, i| {
        if (c == '/') {
            nslash -= 1;
            if (nslash <= 0) return if (i == 0) null else i + 1;
        }
    }
    return null;
}

fn gitHeaderName(p_value: i32, line0: []const u8) ?[]const u8 {
    const line = line0["diff --git ".len..];
    const llen = line.len;
    if (at(line, 0) == '"') {
        const uq = util.cunquote(line) orelse return null;
        const first0 = uq.value;
        const cp0 = skipTreePrefix(p_value, first0) orelse return null;
        const first = first0[cp0..];
        var second: usize = llen - uq.rest.len;
        while (second < llen and isSpace(line[second])) second += 1;
        if (llen <= second) return null;
        if (line[second] == '"') {
            const uq2 = util.cunquote(line[second..]) orelse return null;
            const cp = skipTreePrefix(p_value, uq2.value) orelse return null;
            if (!util.eql(uq2.value[cp..], first)) return null;
            return first;
        }
        const sec = line[second..];
        const cp = skipTreePrefix(p_value, sec) orelse return null;
        if (!util.eql(sec[cp..], first)) return null;
        return first;
    }

    const name_off = skipTreePrefix(p_value, line) orelse return null;
    const name = line[name_off..];
    // a dq, if exists, must be the beginning of the second name
    for (name, 0..) |c, si| {
        if (c == '"') {
            const uq = util.cunquote(name[si..]) orelse return null;
            const np = skipTreePrefix(p_value, uq.value) orelse return null;
            const npv = uq.value[np..];
            const len = npv.len;
            if (len < si and std.mem.eql(u8, npv, name[0..len]) and isSpace(name[len])) return util.dupe(npv);
            return null;
        }
    }
    const nl = std.mem.indexOfScalar(u8, name, '\n') orelse return null;
    const line_len = nl;
    var len: usize = 0;
    while (true) : (len += 1) {
        const c = at(name, len);
        switch (c) {
            '\n' => return null,
            '\t', ' ' => {
                if (at(name, len + 1) == 0) return null;
                if (len + 1 > line_len) continue;
                const sec_slice = name[len + 1 .. line_len];
                const so = skipTreePrefix(p_value, sec_slice) orelse continue;
                const secv = name[len + 1 + so ..];
                if (at(secv, len) == '\n' and std.mem.eql(u8, name[0..len], secv[0..@min(len, secv.len)]) and secv.len >= len) return util.dupe(name[0..len]);
            },
            0 => {
                if (len >= name.len) return null;
            },
            else => {},
        }
    }
}

fn checkHeaderLine(linenr: i32, patch: *Patch) i32 {
    const extensions = @as(i32, @intFromBool(patch.is_delete == 1)) + @intFromBool(patch.is_new == 1) +
        @intFromBool(patch.is_rename) + @intFromBool(patch.is_copy);
    if (extensions > 1)
        return errorf("inconsistent header lines {d} and {d}", .{ patch.extension_linenr, linenr });
    if (extensions != 0 and patch.extension_linenr == 0) patch.extension_linenr = linenr;
    return 0;
}

/// parse_git_diff_header(); `buf` starts at the "diff --git" line, len is its length
pub fn parseGitDiffHeader(root: *const Buf, patch_input_file: ?[]const u8, linenr: *i32, p_value: i32, buf: []const u8, len0: usize, size0: usize, patch: *Patch) i32 {
    patch.is_new = 0;
    patch.is_delete = 0;
    patch.def_name = gitHeaderName(p_value, buf[0..len0]);
    if (patch.def_name != null and root.items.len > 0) {
        patch.def_name = util.concat(&.{ root.items, patch.def_name.? });
    }
    var line = buf[len0..];
    var size = size0 - len0;
    linenr.* += 1;
    var st = GitdiffData{ .root = root, .patch_input_file = patch_input_file, .linenr = linenr.*, .p_value = p_value };
    var offset: usize = len0;
    var len: usize = len0;
    outer: while (size > 0) : ({
        offset += len;
        size -= len;
        line = line[len..];
        linenr.* += 1;
    }) {
        len = linelen(line, size);
        if (len == 0 or line[len - 1] != '\n') break;
        for (optable) |p| {
            const oplen = p.str.len;
            if (len < oplen or !std.mem.eql(u8, p.str, line[0..oplen])) continue;
            st.linenr = linenr.*;
            const res = runHdrOp(&st, p.op, line[oplen..len], patch);
            if (res < 0) return -1;
            if (checkHeaderLine(linenr.*, patch) != 0) return -1;
            if (res > 0) break :outer;
            break;
        }
    }

    if (patch.old_name == null and patch.new_name == null) {
        if (patch.def_name == null) {
            const comp = if (st.p_value == 1) "component" else "components";
            if (patch_input_file) |f| {
                _ = errorf("git diff header lacks filename information when removing {d} leading pathname {s} at {s}:{d}", .{ st.p_value, comp, f, linenr.* });
            } else {
                _ = errorf("git diff header lacks filename information when removing {d} leading pathname {s} (line {d})", .{ st.p_value, comp, linenr.* });
            }
            return -128;
        }
        patch.old_name = patch.def_name;
        patch.new_name = patch.def_name;
    }
    if ((patch.new_name == null and patch.is_delete == 0) or (patch.old_name == null and patch.is_new == 0)) {
        if (patch_input_file) |f| {
            _ = errorf("git diff header lacks filename information at {s}:{d}", .{ f, linenr.* });
        } else {
            _ = errorf("git diff header lacks filename information (line {d})", .{linenr.*});
        }
        return -128;
    }
    patch.is_toplevel_relative = true;
    return @intCast(offset);
}

fn parseNum(line: []const u8, p: *i64) usize {
    if (!isDigit(at(line, 0))) return 0;
    const r = strtoul(line, 10);
    if (r.val > std.math.maxInt(i64)) return 0;
    p.* = @intCast(r.val);
    return r.len;
}

fn parseRange(line0: []const u8, len0: usize, offset0: i64, expect: []const u8, p1: *i64, p2: *i64) i64 {
    if (offset0 < 0 or offset0 >= @as(i64, @intCast(len0))) return -1;
    var offset: usize = @intCast(offset0);
    var line = line0[offset..len0];
    var digits = parseNum(line, p1);
    if (digits == 0) return -1;
    offset += digits;
    line = line[digits..];
    p2.* = 1;
    if (at(line, 0) == ',') {
        digits = parseNum(line[1..], p2);
        if (digits == 0) return -1;
        offset += digits + 1;
        line = line[digits + 1 ..];
    }
    if (expect.len > line.len) return -1;
    if (!std.mem.eql(u8, line[0..expect.len], expect)) return -1;
    return @intCast(offset + expect.len);
}

fn recountDiff(line0: []const u8, size0: usize, fragment: *Fragment) void {
    var oldlines: i64 = 0;
    var newlines: i64 = 0;
    var size: i64 = @intCast(size0);
    var line = line0;
    if (size < 1) {
        warnf("recount: ignore empty hunk", .{});
        return;
    }
    while (true) {
        const len = linelen(line, @intCast(size));
        size -= @intCast(len);
        line = line[len..];
        if (size < 1) break;
        var ret = false;
        switch (line[0]) {
            ' ', '\n' => {
                newlines += 1;
                oldlines += 1;
                continue;
            },
            '-' => {
                oldlines += 1;
                continue;
            },
            '+' => {
                newlines += 1;
                continue;
            },
            '\\' => continue,
            '@' => ret = size < 3 or !util.startsWith(line, "@@ "),
            'd' => ret = size < 5 or !util.startsWith(line, "diff "),
            else => ret = true,
        }
        if (ret) {
            const l = linelen(line, @intCast(size));
            warnf("recount: unexpected line: {s}", .{line[0..l]});
            return;
        }
        break;
    }
    fragment.oldlines = oldlines;
    fragment.newlines = newlines;
}

fn parseFragmentHeader(line: []const u8, len: usize, fragment: *Fragment) i64 {
    if (len == 0 or line[len - 1] != '\n') return -1;
    var offset = parseRange(line, len, 4, " +", &fragment.oldpos, &fragment.oldlines);
    offset = parseRange(line, len, offset, " @@", &fragment.newpos, &fragment.newlines);
    return offset;
}

/// find_header: returns offset of header, -1 if not found, -128 on error
fn findHeader(state: *State, buf: []const u8, size0: usize, hdrsize: *usize, patch: *Patch) i64 {
    patch.is_toplevel_relative = false;
    patch.is_rename = false;
    patch.is_copy = false;
    patch.is_new = -1;
    patch.is_delete = -1;
    patch.old_mode = 0;
    patch.new_mode = 0;
    patch.old_name = null;
    patch.new_name = null;
    var offset: usize = 0;
    var size = size0;
    var line = buf;
    var len: usize = 0;
    while (size > 0) : ({
        offset += len;
        size -= len;
        line = line[len..];
        state.linenr += 1;
    }) {
        len = linelen(line, size);
        if (len == 0) break;
        if (len < 6) continue;
        if (std.mem.eql(u8, line[0..4], "@@ -")) {
            var dummy = Fragment{};
            if (parseFragmentHeader(line, len, &dummy) < 0) continue;
            _ = errorf("patch fragment without header at {s}:{d}: {s}", .{ state.patch_input_file, state.linenr, line[0 .. len - 1] });
            return -128;
        }
        if (size < len + 6) break;
        if (util.startsWith(line[0..len], "diff --git ")) {
            const git_hdr_len = parseGitDiffHeader(&state.root, state.patch_input_file, &state.linenr, state.p_value, line, len, size, patch);
            if (git_hdr_len < 0) return -128;
            if (git_hdr_len <= len) continue;
            hdrsize.* = @intCast(git_hdr_len);
            return @intCast(offset);
        }
        if (!std.mem.eql(u8, line[0..4], "--- ") or !std.mem.eql(u8, line[len .. len + 4], "+++ ")) continue;
        const nextlen = linelen(line[len..], size - len);
        if (size < nextlen + 14 or !std.mem.eql(u8, line[len + nextlen .. len + nextlen + 4], "@@ -")) continue;
        if (parseTraditionalPatch(state, line, line[len..], patch) != 0) return -128;
        hdrsize.* = len + nextlen;
        state.linenr += 2;
        return @intCast(offset);
    }
    return -1;
}

fn recordWsError(state: *State, result: u32, line: []const u8, len0: usize, linenr: i32) void {
    if (result == 0) return;
    state.whitespace_error += 1;
    if (state.squelch_whitespace_errors != 0 and state.squelch_whitespace_errors < state.whitespace_error) return;
    var len = len0;
    if (result & diff.WS_INCOMPLETE_LINE != 0) len += 1;
    const e = diff.wsErrorString(result);
    if (state.apply_verbosity > VERBOSITY_SILENT)
        util.eprint("{s}:{d}: {s}.\n{s}\n", .{ state.patch_input_file, linenr, e, line[0..@min(len, line.len)] });
}

fn checkWhitespace(state: *State, line: []const u8, len: usize, ws_rule: u32) void {
    const result = diff.wsCheck(line[1..len], ws_rule);
    recordWsError(state, result, line[1..], if (len >= 2) len - 2 else 0, state.linenr);
}

fn checkOldForCrlf(patch: *Patch, line: []const u8, len: usize) void {
    if (len >= 2 and line[len - 1] == '\n' and line[len - 2] == '\r') {
        patch.ws_rule |= diff.WS_CR_AT_EOL;
        patch.crlf_in_old = true;
    }
}

fn adjustIncomplete(line: []const u8, len: usize, size: usize) usize {
    const c = line[0];
    if (c != '\n' and c != ' ' and c != '+' and c != '-') return 0;
    if (size - len < 12 or !std.mem.eql(u8, line[len .. len + 2], "\\ ")) return 0;
    const nextlen = linelen(line[len..], size - len);
    if (nextlen < 12) return 0;
    return nextlen;
}

fn parseFragment(state: *State, line0: []const u8, size0: usize, patch: *Patch, fragment: *Fragment) i64 {
    var line = line0;
    var size = size0;
    var len = linelen(line, size);
    if (patch.ws_rule & diff.WS_INCOMPLETE_LINE != 0) {
        const mode = if (state.apply_in_reverse) patch.old_mode else if (patch.new_mode != 0) patch.new_mode else patch.old_mode;
        if (mode != 0 and mode & 0o170000 == 0o120000) patch.ws_rule &= ~diff.WS_INCOMPLETE_LINE;
    }
    var offset = parseFragmentHeader(line, len, fragment);
    if (offset < 0) return -1;
    if (offset > 0 and patch.recount) {
        const o: usize = @intCast(offset);
        recountDiff(line[o..], size - o, fragment);
    }
    var oldlines = fragment.oldlines;
    var newlines = fragment.newlines;
    var leading: i64 = 0;
    var trailing: i64 = 0;

    line = line[len..];
    size -= len;
    state.linenr += 1;
    var added: i32 = 0;
    var deleted: i32 = 0;
    offset = @intCast(len);
    while (0 < size) : ({
        offset += @intCast(len);
        size -= len;
        line = line[len..];
        state.linenr += 1;
    }) {
        if (oldlines == 0 and newlines == 0) break;
        len = linelen(line, size);
        if (len == 0 or line[len - 1] != '\n') return -1;
        var skip_len = adjustIncomplete(line, len, size);
        if (skip_len != 0) {
            len -= 1;
            skip_len += 1;
        }
        switch (line[0]) {
            '\n', ' ' => {
                oldlines -= 1;
                newlines -= 1;
                if (deleted == 0 and added == 0) leading += 1;
                trailing += 1;
                checkOldForCrlf(patch, line, len);
                if (!state.apply_in_reverse and state.ws_error_action == .correct) {
                    if (line[0] == '\n') {
                        checkWhitespace(state, " \n", 2, patch.ws_rule);
                    } else checkWhitespace(state, line, len, patch.ws_rule);
                }
            },
            '-' => {
                if (!state.apply_in_reverse) checkOldForCrlf(patch, line, len);
                if (state.apply_in_reverse and state.ws_error_action != .nowarn)
                    checkWhitespace(state, line, len, patch.ws_rule);
                deleted += 1;
                oldlines -= 1;
                trailing = 0;
            },
            '+' => {
                if (state.apply_in_reverse) checkOldForCrlf(patch, line, len);
                if (!state.apply_in_reverse and state.ws_error_action != .nowarn)
                    checkWhitespace(state, line, len, patch.ws_rule);
                added += 1;
                newlines -= 1;
                trailing = 0;
            },
            else => return -1,
        }
        if (skip_len != 0) {
            len += skip_len;
            state.linenr += 1;
        }
    }
    if (oldlines != 0 or newlines != 0) return -1;
    if (!patch.recount and deleted == 0 and added == 0) return -1;

    fragment.leading = leading;
    fragment.trailing = trailing;
    patch.lines_added += added;
    patch.lines_deleted += deleted;

    if (0 < patch.is_new and oldlines != 0) return errorf("new file depends on old contents", .{});
    if (0 < patch.is_delete and newlines != 0) return errorf("deleted file still has contents", .{});
    return offset;
}

fn parseSinglePatch(state: *State, line0: []const u8, size0: usize, patch: *Patch) i64 {
    var line = line0;
    var size = size0;
    var offset: usize = 0;
    var oldlines: i64 = 0;
    var newlines: i64 = 0;
    var context: i64 = 0;
    var tail: *?*Fragment = &patch.fragments;
    while (size > 4 and std.mem.eql(u8, line[0..4], "@@ -")) {
        const fragment = gpa.create(Fragment) catch util.oom();
        fragment.* = .{};
        fragment.linenr = state.linenr;
        const len = parseFragment(state, line, size, patch, fragment);
        if (len <= 0) {
            return errorf("corrupt patch at {s}:{d}", .{ state.patch_input_file, state.linenr });
        }
        const ulen: usize = @intCast(len);
        fragment.patch = line[0..ulen];
        oldlines += fragment.oldlines;
        newlines += fragment.newlines;
        context += fragment.leading + fragment.trailing;
        tail.* = fragment;
        tail = &fragment.next;
        offset += ulen;
        line = line[ulen..];
        size -= ulen;
    }
    const multi = patch.fragments != null and patch.fragments.?.next != null;
    if (patch.is_new < 0 and (oldlines != 0 or multi)) patch.is_new = 0;
    if (patch.is_delete < 0 and (newlines != 0 or multi)) patch.is_delete = 0;

    if (0 < patch.is_new and oldlines != 0)
        return errorf("new file {s} depends on old contents", .{patch.new_name orelse "(null)"});
    if (0 < patch.is_delete and newlines != 0)
        return errorf("deleted file {s} still has contents", .{patch.old_name orelse "(null)"});
    if (patch.is_delete == 0 and newlines == 0 and context != 0 and state.apply_verbosity > VERBOSITY_SILENT)
        util.eprint("** warning: file {s} becomes empty but is not deleted\n", .{patch.new_name orelse "(null)"});
    return @intCast(offset);
}

fn metadataChanges(patch: *const Patch) bool {
    return patch.is_rename or patch.is_copy or patch.is_new > 0 or patch.is_delete != 0 or
        (patch.old_mode != 0 and patch.new_mode != 0 and patch.old_mode != patch.new_mode);
}

fn inflateIt(data: []const u8, inflated_size: usize) ?[]const u8 {
    const r = zlib.decompress(data, inflated_size) orelse return null;
    if (r.data.len != inflated_size) return null;
    return r.data;
}

// base85 decoding
const en85 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~";

fn de85(ch: u8) i32 {
    const i = std.mem.indexOfScalar(u8, en85, ch) orelse return -1;
    return @intCast(i);
}

fn decode85(dst: []u8, buffer: []const u8, len0: usize) bool {
    var len = len0;
    var bi: usize = 0;
    var di: usize = 0;
    while (len > 0) {
        var acc: u32 = 0;
        var cnt: u32 = 4;
        while (cnt > 0) : (cnt -= 1) {
            const ch = at(buffer, bi);
            bi += 1;
            const de = de85(ch);
            if (de < 0) {
                _ = errorf("invalid base85 alphabet {c}", .{ch});
                return false;
            }
            acc = acc *% 85 +% @as(u32, @intCast(de));
        }
        const ch = at(buffer, bi);
        bi += 1;
        const de = de85(ch);
        if (de < 0) {
            _ = errorf("invalid base85 alphabet {c}", .{ch});
            return false;
        }
        if (0xffffffff / 85 < acc or 0xffffffff - @as(u32, @intCast(de)) < acc * 85) {
            _ = errorf("invalid base85 sequence {s}", .{buffer[bi - 5 .. bi]});
            return false;
        }
        acc = acc * 85 + @as(u32, @intCast(de));
        cnt = if (len < 4) @intCast(len) else 4;
        len -= cnt;
        while (cnt > 0) : (cnt -= 1) {
            acc = (acc << 8) | (acc >> 24);
            dst[di] = @truncate(acc);
            di += 1;
        }
    }
    return true;
}

const BinHunk = struct { frag: ?*Fragment, status: i32, used: usize, rest: []const u8, size: usize };

fn parseBinaryHunk(state: *State, buf0: []const u8, size0: usize) BinHunk {
    var buffer = buf0;
    var size = size0;
    var llen = linelen(buffer, size);
    var used = llen;
    var patch_method: i64 = 0;
    var origlen: u64 = 0;
    var data: Buf = .empty;
    var error_msg: ?[]const u8 = null;

    if (util.startsWith(buffer[0..llen], "delta ")) {
        patch_method = BINARY_DELTA_DEFLATED;
        origlen = strtoul(buffer[6..llen], 10).val;
    } else if (util.startsWith(buffer[0..llen], "literal ")) {
        patch_method = BINARY_LITERAL_DEFLATED;
        origlen = strtoul(buffer[8..llen], 10).val;
    } else return .{ .frag = null, .status = 0, .used = 0, .rest = buffer, .size = size };

    corrupt: {
        if (origlen >= MAX_APPLY_SIZE) {
            error_msg = "patch too large";
            break :corrupt;
        }
        state.linenr += 1;
        buffer = buffer[llen..];
        size -= llen;
        while (true) {
            llen = linelen(buffer, size);
            used += llen;
            state.linenr += 1;
            if (llen == 1) {
                buffer = buffer[1..];
                size -= 1;
                break;
            }
            if (llen < 7 or (llen - 2) % 5 != 0) break :corrupt;
            const max_byte_length = (llen - 2) / 5 * 4;
            var byte_length: usize = buffer[0];
            if ('A' <= byte_length and byte_length <= 'Z') {
                byte_length = byte_length - 'A' + 1;
            } else if ('a' <= byte_length and byte_length <= 'z') {
                byte_length = byte_length - 'a' + 27;
            } else break :corrupt;
            if (max_byte_length < byte_length or byte_length + 4 <= max_byte_length) break :corrupt;
            const old = data.items.len;
            data.resize(gpa, old + byte_length) catch util.oom();
            if (!decode85(data.items[old..], buffer[1..], byte_length)) break :corrupt;
            buffer = buffer[llen..];
            size -= llen;
        }
        const frag = gpa.create(Fragment) catch util.oom();
        frag.* = .{};
        frag.patch = inflateIt(data.items, @intCast(origlen)) orelse break :corrupt;
        frag.leading = patch_method;
        return .{ .frag = frag, .status = 0, .used = used, .rest = buffer, .size = size };
    }
    if (error_msg) |m| {
        _ = errorf("{s}", .{m});
    } else {
        const l = if (llen > 0) llen - 1 else 0;
        _ = errorf("corrupt binary patch at {s}:{d}: {s}", .{ state.patch_input_file, state.linenr - 1, buffer[0..@min(l, buffer.len)] });
    }
    return .{ .frag = null, .status = -1, .used = used, .rest = buffer, .size = size };
}

fn parseBinary(state: *State, buffer: []const u8, size: usize, patch: *Patch) i64 {
    const fwd = parseBinaryHunk(state, buffer, size);
    if (fwd.frag == null and fwd.status == 0)
        return errorf("unrecognized binary patch at {s}:{d}", .{ state.patch_input_file, state.linenr - 1 });
    if (fwd.status != 0) return fwd.status;
    var used = fwd.used;
    const rev = parseBinaryHunk(state, fwd.rest, fwd.size);
    if (rev.frag != null) {
        used += rev.used;
    } else if (rev.status != 0) return rev.status;
    fwd.frag.?.next = rev.frag;
    patch.fragments = fwd.frag;
    patch.is_binary = true;
    return @intCast(used);
}

fn prefixFilename(prefix: []const u8, name: []const u8) []const u8 {
    if (name.len > 0 and name[0] == '/') return name;
    return util.concat(&.{ prefix, name });
}

fn prefixPatch(state: *State, p: *Patch) void {
    const prefix = state.prefix orelse return;
    if (p.is_toplevel_relative) return;
    if (p.new_name) |n| p.new_name = prefixFilename(prefix, n);
    if (p.old_name) |n| p.old_name = prefixFilename(prefix, n);
}

fn usePatch(state: *State, p: *const Patch) bool {
    const pathname = p.new_name orelse p.old_name orelse "";
    if (state.prefix) |prefix| {
        if (prefix.len > 0) {
            const rest = util.skipPrefix(pathname, prefix) orelse return false;
            if (rest.len == 0) return false;
        }
    }
    for (state.limit_by_name.items) |it| {
        if (wildmatch.match(it.pattern, pathname, 0)) return it.include;
    }
    return !state.has_include;
}

/// parse_chunk: returns bytes consumed, -1 if no header / binary failure, -128 on other errors
fn parseChunk(state: *State, buffer: []const u8, size: usize, patch: *Patch) i64 {
    var hdrsize: usize = 0;
    const offset = findHeader(state, buffer, size, &hdrsize, patch);
    if (offset < 0) return offset;
    prefixPatch(state, patch);
    if (!usePatch(state, patch)) {
        patch.ws_rule = 0;
    } else if (patch.new_name) |n| {
        patch.ws_rule = diff.whitespaceRule(n);
    } else {
        patch.ws_rule = diff.whitespaceRule(patch.old_name.?);
    }
    const uoff: usize = @intCast(offset);
    const hd = uoff + hdrsize;
    var patchsize = parseSinglePatch(state, buffer[hd..], size - hd, patch);
    if (patchsize < 0) return -128;
    if (patchsize == 0) {
        const git_binary = "GIT binary patch\n";
        const llen = linelen(buffer[hd..], size - hd);
        if (llen == git_binary.len and std.mem.eql(u8, buffer[hd .. hd + llen], git_binary)) {
            state.linenr += 1;
            const used = parseBinary(state, buffer[hd + llen ..], size - hd - llen, patch);
            if (used < 0) return -1;
            patchsize = if (used != 0) used + @as(i64, @intCast(llen)) else 0;
        } else if (llen >= 8 and std.mem.eql(u8, buffer[hd + llen - 8 .. hd + llen], " differ\n")) {
            const binhdr = [_][]const u8{ "Binary files ", "Files " };
            for (binhdr) |h| {
                if (h.len < size - hd and std.mem.eql(u8, buffer[hd .. hd + h.len], h)) {
                    state.linenr += 1;
                    patch.is_binary = true;
                    patchsize = @intCast(llen);
                    break;
                }
            }
        }
        if ((state.apply or state.check) and (!patch.is_binary and !metadataChanges(patch))) {
            _ = errorf("patch with only garbage at {s}:{d}", .{ state.patch_input_file, state.linenr });
            return -128;
        }
    }
    return offset + @as(i64, @intCast(hdrsize)) + patchsize;
}

fn reversePatches(p0: ?*Patch) void {
    var p = p0;
    while (p) |pp| : (p = pp.next) {
        std.mem.swap(?[]const u8, &pp.new_name, &pp.old_name);
        if (pp.new_mode != 0 or pp.is_delete != 0) std.mem.swap(u32, &pp.new_mode, &pp.old_mode);
        std.mem.swap(i32, &pp.is_new, &pp.is_delete);
        std.mem.swap(i32, &pp.lines_added, &pp.lines_deleted);
        std.mem.swap([]const u8, &pp.old_oid_prefix, &pp.new_oid_prefix);
        var frag = pp.fragments;
        while (frag) |f| : (frag = f.next) {
            std.mem.swap(i64, &f.newpos, &f.oldpos);
            std.mem.swap(i64, &f.newlines, &f.oldlines);
        }
    }
}

// ---------------------------------------------------------------------------
// diffstat-like output

const pluses = "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
const minuses = "----------------------------------------------------------------------";

fn padRight(b: *Buf, s: []const u8, width: usize) void {
    util.bufAppend(b, s);
    var n = s.len;
    while (n < width) : (n += 1) util.bufByte(b, ' ');
}

fn showStats(state: *State, patch: *Patch) void {
    const cp = patch.new_name orelse patch.old_name.?;
    var qname: Buf = .empty;
    util.bufAppend(&qname, util.cquote(cp));
    var max: usize = @intCast(@max(state.max_len, 0));
    if (max > 50) max = 50;
    if (qname.items.len > max) {
        const startpos = qname.items.len + 3 - max;
        const slash = std.mem.indexOfScalarPos(u8, qname.items, startpos, '/');
        const cut = slash orelse startpos;
        var nb: Buf = .empty;
        util.bufAppend(&nb, "...");
        util.bufAppend(&nb, qname.items[cut..]);
        qname = nb;
    }
    var line: Buf = .empty;
    util.bufByte(&line, ' ');
    padRight(&line, qname.items, max);
    if (patch.is_binary) {
        util.bufAppend(&line, " |  Bin\n");
        util.out(line.items);
        return;
    }
    util.bufAppend(&line, " |");
    const mc: i64 = state.max_change;
    const imax: i64 = @intCast(max);
    const smax: i64 = if (imax + mc > 70) 70 - imax else mc;
    var add: i64 = patch.lines_added;
    var del: i64 = patch.lines_deleted;
    if (mc > 0) {
        const total = @divTrunc((add + del) * smax + @divTrunc(mc, 2), mc);
        add = @divTrunc(add * smax + @divTrunc(mc, 2), mc);
        del = total - add;
    }
    util.bufPrint(&line, "{s: >5} {s}{s}\n", .{ util.fmt("{d}", .{patch.lines_added + patch.lines_deleted}), pluses[0..@intCast(@max(add, 0))], minuses[0..@intCast(@max(del, 0))] });
    util.out(line.items);
}

// ---------------------------------------------------------------------------
// images

const LINE_COMMON: u8 = 1;
const LINE_PATCHED: u8 = 2;

const Line = struct { len: usize, hash: u32, flag: u8 };

const Image = struct {
    buf: Buf = .empty,
    lines: std.ArrayList(Line) = .empty,

    fn nr(self: *const Image) usize {
        return self.lines.items.len;
    }
    fn clear(self: *Image) void {
        self.buf = .empty;
        self.lines = .empty;
    }
};

fn hashLine(cp: []const u8) u32 {
    var h: u32 = 0;
    for (cp) |c| {
        if (!isSpace(c)) h = h *% 3 +% c;
    }
    return h & 0xffffff;
}

fn imageAddLine(img: *Image, bol: []const u8, flag: u8) void {
    img.lines.append(gpa, .{ .len = bol.len, .hash = hashLine(bol), .flag = flag }) catch util.oom();
}

fn imagePrepare(img: *Image, data: []const u8, prepare_linetable: bool) void {
    img.clear();
    util.bufAppend(&img.buf, data);
    if (!prepare_linetable) return;
    const b = img.buf.items;
    var cp: usize = 0;
    while (cp < b.len) {
        var next = cp;
        while (next < b.len and b[next] != '\n') next += 1;
        if (next < b.len) next += 1;
        imageAddLine(img, b[cp..next], 0);
        cp = next;
    }
}

fn imageRemoveFirstLine(img: *Image) void {
    const l = img.lines.items[0].len;
    std.mem.copyForwards(u8, img.buf.items[0 .. img.buf.items.len - l], img.buf.items[l..]);
    img.buf.items.len -= l;
    _ = img.lines.orderedRemove(0);
}

fn imageRemoveLastLine(img: *Image) void {
    const l = img.lines.items[img.lines.items.len - 1].len;
    img.buf.items.len -= l;
    img.lines.items.len -= 1;
}

fn updatePrePostImages(preimage: *Image, postimage: *Image, data: []const u8) void {
    var fixed_preimage = Image{};
    imagePrepare(&fixed_preimage, data, true);
    for (fixed_preimage.lines.items, 0..) |*l, i| {
        l.flag = if (i < preimage.lines.items.len) preimage.lines.items[i].flag else 0;
    }
    preimage.* = fixed_preimage;
    var fixed: usize = 0;
    var insert_pos: usize = 0;
    var ctx: usize = 0;
    var reduced: usize = 0;
    var i: usize = 0;
    while (i < postimage.lines.items.len) : (i += 1) {
        var l_len = postimage.lines.items[i].len;
        if (postimage.lines.items[i].flag & LINE_COMMON == 0) {
            insert_pos += l_len;
            continue;
        }
        while (ctx < preimage.lines.items.len and preimage.lines.items[ctx].flag & LINE_COMMON == 0) {
            fixed += preimage.lines.items[ctx].len;
            ctx += 1;
        }
        if (preimage.lines.items.len <= ctx) {
            reduced += 1;
            continue;
        }
        l_len = preimage.lines.items[ctx].len;
        postimage.buf.replaceRange(gpa, insert_pos, postimage.lines.items[i].len, preimage.buf.items[fixed .. fixed + l_len]) catch util.oom();
        insert_pos += l_len;
        fixed += l_len;
        postimage.lines.items[i].len = l_len;
        ctx += 1;
    }
    postimage.lines.items.len -= reduced;
}

fn fuzzyMatchlines(a: []const u8, b: []const u8) bool {
    var end1 = a.len;
    var end2 = b.len;
    while (end1 > 0 and (a[end1 - 1] == '\r' or a[end1 - 1] == '\n')) end1 -= 1;
    while (end2 > 0 and (b[end2 - 1] == '\r' or b[end2 - 1] == '\n')) end2 -= 1;
    var s1: usize = 0;
    var s2: usize = 0;
    while (s1 < end1 and s2 < end2) {
        if (isSpace(a[s1])) {
            if (!isSpace(b[s2])) return false;
            while (s1 < end1 and isSpace(a[s1])) s1 += 1;
            while (s2 < end2 and isSpace(b[s2])) s2 += 1;
        } else {
            if (a[s1] != b[s2]) return false;
            s1 += 1;
            s2 += 1;
        }
    }
    return s1 == end1 and s2 == end2;
}

fn lineByLineFuzzyMatch(img: *Image, preimage: *Image, postimage: *Image, current: usize, current_lno: usize, preimage_limit: usize) bool {
    var imgoff: usize = 0;
    var preoff: usize = 0;
    var i: usize = 0;
    while (i < preimage_limit) : (i += 1) {
        const prelen = preimage.lines.items[i].len;
        const imglen = img.lines.items[current_lno + i].len;
        if (!fuzzyMatchlines(img.buf.items[current + imgoff .. current + imgoff + imglen], preimage.buf.items[preoff .. preoff + prelen])) return false;
        imgoff += imglen;
        preoff += prelen;
    }
    const preimage_eof = preoff;
    while (i < preimage.lines.items.len) : (i += 1) preoff += preimage.lines.items[i].len;
    const preimage_end = preoff;
    for (preimage.buf.items[preimage_eof..preimage_end]) |c| {
        if (!isSpace(c)) return false;
    }
    var fixed: Buf = .empty;
    util.bufAppend(&fixed, img.buf.items[current .. current + imgoff]);
    util.bufAppend(&fixed, preimage.buf.items[preimage_eof..preimage_end]);
    updatePrePostImages(preimage, postimage, fixed.items);
    return true;
}

fn matchFragment(state: *State, img: *Image, preimage: *Image, postimage: *Image, current: usize, current_lno: usize, ws_rule: u32, match_beginning: bool, match_end: bool) bool {
    var preimage_limit: usize = undefined;
    const pre_nr = preimage.lines.items.len;
    const img_nr = img.lines.items.len;
    if (pre_nr + current_lno <= img_nr) {
        preimage_limit = pre_nr;
        if (match_end and pre_nr + current_lno != img_nr) return false;
    } else if (state.ws_error_action == .correct and ws_rule & diff.WS_BLANK_AT_EOF != 0) {
        preimage_limit = img_nr - current_lno;
    } else return false;

    if (match_beginning and current_lno != 0) return false;

    var i: usize = 0;
    while (i < preimage_limit) : (i += 1) {
        const il = img.lines.items[current_lno + i];
        if (il.flag & LINE_PATCHED != 0 or preimage.lines.items[i].hash != il.hash) return false;
    }

    if (preimage_limit == pre_nr) {
        const plen = preimage.buf.items.len;
        const ok = if (match_end) current + plen == img.buf.items.len else current + plen <= img.buf.items.len;
        if (ok and std.mem.eql(u8, img.buf.items[current .. current + plen], preimage.buf.items)) return true;
    } else {
        var buf_end: usize = 0;
        i = 0;
        while (i < preimage_limit) : (i += 1) buf_end += preimage.lines.items[i].len;
        var b: usize = 0;
        while (b < buf_end) : (b += 1) {
            if (!isSpace(preimage.buf.items[b])) break;
        }
        if (b == buf_end) return false;
    }

    if (state.ws_ignore_action == .change)
        return lineByLineFuzzyMatch(img, preimage, postimage, current, current_lno, preimage_limit);

    if (state.ws_error_action != .correct) return false;

    var fixed: Buf = .empty;
    var orig: usize = 0;
    var target: usize = current;
    i = 0;
    while (i < preimage_limit) : (i += 1) {
        const oldlen = preimage.lines.items[i].len;
        const tgtlen = img.lines.items[current_lno + i].len;
        const fixstart = fixed.items.len;
        diff.wsFixCopy(&fixed, preimage.buf.items[orig .. orig + oldlen], ws_rule, null);
        var tgtfix: Buf = .empty;
        diff.wsFixCopy(&tgtfix, img.buf.items[target .. target + tgtlen], ws_rule, null);
        if (!std.mem.eql(u8, tgtfix.items, fixed.items[fixstart..])) return false;
        orig += oldlen;
        target += tgtlen;
    }
    while (i < pre_nr) : (i += 1) {
        const fixstart = fixed.items.len;
        const oldlen = preimage.lines.items[i].len;
        diff.wsFixCopy(&fixed, preimage.buf.items[orig .. orig + oldlen], ws_rule, null);
        for (fixed.items[fixstart..]) |c| {
            if (!isSpace(c)) return false;
        }
        orig += oldlen;
    }
    updatePrePostImages(preimage, postimage, fixed.items);
    return true;
}

fn findPos(state: *State, img: *Image, preimage: *Image, postimage: *Image, line0: i64, ws_rule: u32, match_beginning0: bool, match_end: bool) i64 {
    var match_beginning = match_beginning0;
    const img_nr = img.lines.items.len;
    if (state.allow_overlap and match_beginning and match_end and img_nr != preimage.lines.items.len)
        match_beginning = false;
    var line = line0;
    if (match_beginning) {
        line = 0;
    } else if (match_end) {
        line = @as(i64, @intCast(img_nr)) - @as(i64, @intCast(preimage.lines.items.len));
    }
    if (line < 0 or line > @as(i64, @intCast(img_nr))) line = @intCast(img_nr);
    const uline: usize = @intCast(line);
    var current: usize = 0;
    for (img.lines.items[0..uline]) |l| current += l.len;

    var backwards = current;
    var backwards_lno = uline;
    var forwards = current;
    var forwards_lno = uline;
    var current_lno = uline;

    var i: usize = 0;
    while (true) : (i += 1) {
        if (matchFragment(state, img, preimage, postimage, current, current_lno, ws_rule, match_beginning, match_end))
            return @intCast(current_lno);
        while (true) {
            if (backwards_lno == 0 and forwards_lno == img_nr) return -1;
            if (i & 1 != 0) {
                if (backwards_lno == 0) {
                    i += 1;
                    continue;
                }
                backwards_lno -= 1;
                backwards -= img.lines.items[backwards_lno].len;
                current = backwards;
                current_lno = backwards_lno;
            } else {
                if (forwards_lno == img_nr) {
                    i += 1;
                    continue;
                }
                forwards += img.lines.items[forwards_lno].len;
                forwards_lno += 1;
                current = forwards;
                current_lno = forwards_lno;
            }
            break;
        }
    }
}

fn updateImage(state: *State, img: *Image, applied_pos: usize, preimage: *Image, postimage: *Image) void {
    var preimage_limit = preimage.lines.items.len;
    const img_nr = img.lines.items.len;
    if (preimage_limit > img_nr - applied_pos) preimage_limit = img_nr - applied_pos;
    var applied_at: usize = 0;
    for (img.lines.items[0..applied_pos]) |l| applied_at += l.len;
    var remove_count: usize = 0;
    for (img.lines.items[applied_pos .. applied_pos + preimage_limit]) |l| remove_count += l.len;
    img.buf.replaceRange(gpa, applied_at, remove_count, postimage.buf.items) catch util.oom();
    img.lines.replaceRange(gpa, applied_pos, preimage_limit, postimage.lines.items) catch util.oom();
    if (!state.allow_overlap) {
        for (img.lines.items[applied_pos .. applied_pos + postimage.lines.items.len]) |*l| l.flag |= LINE_PATCHED;
    }
}

fn applyOneFragment(state: *State, img: *Image, frag: *Fragment, inaccurate_eof: bool, ws_rule: u32, nth_fragment: i32) bool {
    var patch = frag.patch;
    var size: usize = patch.len;
    var oldlines: Buf = .empty;
    var newlines: Buf = .empty;
    var new_blank_lines_at_end: i32 = 0;
    var found_new_blank_lines_at_end: i32 = 0;
    var hunk_linenr = frag.linenr;
    var preimage = Image{};
    var postimage = Image{};
    var applied_pos: i64 = -1;

    while (size > 0) {
        const len = linelen(patch, size);
        if (len == 0) break;
        var plen: i64 = @as(i64, @intCast(len)) - 1;
        if (len < size and patch[len] == '\\') plen -= 1;
        var first = patch[0];
        if (state.apply_in_reverse) {
            if (first == '-') {
                first = '+';
            } else if (first == '+') first = '-';
        }
        var added_blank_line = false;
        var is_blank_context = false;
        const pl: usize = if (plen < 0) 0 else @intCast(plen);
        const body = if (len >= 1) patch[1 .. 1 + pl] else patch[0..0];
        switch (first) {
            '\n' => {
                if (plen >= 0) {
                    util.bufByte(&oldlines, '\n');
                    util.bufByte(&newlines, '\n');
                    imageAddLine(&preimage, "\n", LINE_COMMON);
                    imageAddLine(&postimage, "\n", LINE_COMMON);
                    is_blank_context = true;
                }
            },
            ' ', '-', '+' => {
                if (first == ' ' and pl != 0 and ws_rule & diff.WS_BLANK_AT_EOF != 0 and diff.wsBlankLine(body))
                    is_blank_context = true;
                if (first != '+') {
                    util.bufAppend(&oldlines, body);
                    imageAddLine(&preimage, body, if (first == ' ') LINE_COMMON else 0);
                }
                if (first != '-' and !(first == '+' and state.no_add)) {
                    const start = newlines.items.len;
                    if (first != '+' or state.whitespace_error == 0 or state.ws_error_action != .correct) {
                        util.bufAppend(&newlines, body);
                    } else {
                        var cnt: usize = @intCast(state.applied_after_fixing_ws);
                        diff.wsFixCopy(&newlines, body, ws_rule, &cnt);
                        state.applied_after_fixing_ws = @intCast(cnt);
                    }
                    imageAddLine(&postimage, newlines.items[start..], if (first == '+') 0 else LINE_COMMON);
                    if (first == '+' and ws_rule & diff.WS_BLANK_AT_EOF != 0 and diff.wsBlankLine(body))
                        added_blank_line = true;
                }
            },
            '@', '\\' => {},
            else => {
                if (state.apply_verbosity > VERBOSITY_NORMAL)
                    _ = errorf("invalid start of line: '{c}'", .{first});
                return true;
            },
        }
        if (added_blank_line) {
            if (new_blank_lines_at_end == 0) found_new_blank_lines_at_end = hunk_linenr;
            new_blank_lines_at_end += 1;
        } else if (is_blank_context) {} else new_blank_lines_at_end = 0;
        patch = patch[len..];
        size -= len;
        hunk_linenr += 1;
    }
    if (inaccurate_eof and oldlines.items.len > 0 and oldlines.items[oldlines.items.len - 1] == '\n' and
        newlines.items.len > 0 and newlines.items[newlines.items.len - 1] == '\n')
    {
        oldlines.items.len -= 1;
        newlines.items.len -= 1;
        preimage.lines.items[preimage.lines.items.len - 1].len -= 1;
        postimage.lines.items[postimage.lines.items.len - 1].len -= 1;
    }

    var leading = frag.leading;
    var trailing = frag.trailing;
    var match_beginning = frag.oldpos == 0 or (frag.oldpos == 1 and !state.unidiff_zero);
    var match_end = !state.unidiff_zero and trailing == 0;
    var pos: i64 = if (frag.newpos != 0) frag.newpos - 1 else 0;
    util.bufAppend(&preimage.buf, oldlines.items);
    postimage.buf = newlines;

    while (true) {
        applied_pos = findPos(state, img, &preimage, &postimage, pos, ws_rule, match_beginning, match_end);
        if (applied_pos >= 0) break;
        if (leading <= state.p_context and trailing <= state.p_context) break;
        if (match_beginning or match_end) {
            match_beginning = false;
            match_end = false;
            continue;
        }
        if (leading >= trailing) {
            imageRemoveFirstLine(&preimage);
            imageRemoveFirstLine(&postimage);
            pos -= 1;
            leading -= 1;
        }
        if (trailing > leading) {
            imageRemoveLastLine(&preimage);
            imageRemoveLastLine(&postimage);
            trailing -= 1;
        }
    }

    if (applied_pos >= 0) {
        const ap: usize = @intCast(applied_pos);
        if (new_blank_lines_at_end != 0 and preimage.lines.items.len + ap >= img.lines.items.len and
            ws_rule & diff.WS_BLANK_AT_EOF != 0 and state.ws_error_action != .nowarn)
        {
            recordWsError(state, diff.WS_BLANK_AT_EOF, "+", 1, found_new_blank_lines_at_end);
            if (state.ws_error_action == .correct) {
                while (new_blank_lines_at_end > 0) : (new_blank_lines_at_end -= 1) imageRemoveLastLine(&postimage);
            }
            if (state.ws_error_action == .die) state.apply = false;
        }
        if (state.apply_verbosity > VERBOSITY_NORMAL and applied_pos != pos) {
            var offset = applied_pos - pos;
            if (state.apply_in_reverse) offset = 0 - offset;
            if (offset == 1 or offset == -1) {
                util.eprint("Hunk #{d} succeeded at {d} (offset {d} line).\n", .{ nth_fragment, applied_pos + 1, offset });
            } else util.eprint("Hunk #{d} succeeded at {d} (offset {d} lines).\n", .{ nth_fragment, applied_pos + 1, offset });
        }
        if ((leading != frag.leading or trailing != frag.trailing) and state.apply_verbosity > VERBOSITY_SILENT)
            util.eprint("Context reduced to ({d}/{d}) to apply fragment at {d}\n", .{ leading, trailing, applied_pos + 1 });
        updateImage(state, img, ap, &preimage, &postimage);
    } else {
        if (state.apply_verbosity > VERBOSITY_NORMAL)
            _ = errorf("while searching for:\n{s}", .{oldlines.items});
    }
    return applied_pos < 0;
}

fn applyBinaryFragment(state: *State, img: *Image, patch: *Patch) i32 {
    var fragment = patch.fragments orelse
        return errorf("missing binary patch data for '{s}'", .{patch.new_name orelse patch.old_name.?});
    if (state.apply_in_reverse) {
        fragment = fragment.next orelse
            return errorf("cannot reverse-apply a binary patch without the reverse hunk to '{s}'", .{patch.new_name orelse patch.old_name.?});
    }
    switch (fragment.leading) {
        BINARY_DELTA_DEFLATED => {
            const dst = odb_mod.applyDelta(img.buf.items, fragment.patch) orelse return -1;
            img.clear();
            util.bufAppend(&img.buf, dst);
            return 0;
        },
        BINARY_LITERAL_DEFLATED => {
            img.clear();
            util.bufAppend(&img.buf, fragment.patch);
            return 0;
        },
        else => return -1,
    }
}

fn applyBinary(state: *State, img: *Image, patch: *Patch) i32 {
    const name = patch.old_name orelse patch.new_name.?;
    if (patch.old_oid_prefix.len != hash.HEXSZ or patch.new_oid_prefix.len != hash.HEXSZ or
        hash.fromHex(patch.old_oid_prefix) == null or hash.fromHex(patch.new_oid_prefix) == null)
        return errorf("cannot apply binary patch to '{s}' without full index line", .{name});
    if (patch.old_name != null) {
        const oid = odb_mod.hashObject(.blob, img.buf.items);
        const hx = hash.hex(oid);
        if (!util.eql(&hx, patch.old_oid_prefix))
            return errorf("the patch applies to '{s}' ({s}), which does not match the current contents.", .{ name, &hx });
    } else {
        if (img.buf.items.len != 0)
            return errorf("the patch applies to an empty '{s}' but it is not empty", .{name});
    }
    const oid = hash.fromHex(patch.new_oid_prefix).?;
    if (hash.isZero(oid)) {
        img.clear();
        return 0;
    }
    const odb = repo_mod.repo().odb();
    if (odb.has(oid)) {
        const obj = odb.read(oid) orelse
            return errorf("the necessary postimage {s} for '{s}' cannot be read", .{ patch.new_oid_prefix, name });
        img.clear();
        util.bufAppend(&img.buf, obj.data);
    } else {
        if (applyBinaryFragment(state, img, patch) != 0)
            return errorf("binary patch does not apply to '{s}'", .{name});
        const got = odb_mod.hashObject(.blob, img.buf.items);
        const hx = hash.hex(got);
        if (!util.eql(&hx, patch.new_oid_prefix))
            return errorf("binary patch to '{s}' creates incorrect result (expecting {s}, got {s})", .{ name, patch.new_oid_prefix, &hx });
    }
    return 0;
}

fn applyFragments(state: *State, img: *Image, patch: *Patch) i32 {
    const name = patch.old_name orelse patch.new_name.?;
    if (patch.is_binary) return applyBinary(state, img, patch);
    var frag = patch.fragments;
    var nth: i32 = 0;
    while (frag) |f| : (frag = f.next) {
        nth += 1;
        if (applyOneFragment(state, img, f, patch.inaccurate_eof, patch.ws_rule, nth)) {
            _ = errorf("patch failed: {s}:{d}", .{ name, f.oldpos });
            if (!state.apply_with_reject) return -1;
            f.rejected = true;
        }
    }
    return 0;
}

fn readBlobObject(buf: *Buf, oid: Oid, mode: u32) i32 {
    if (mode & 0o170000 == 0o160000) {
        util.bufPrint(buf, "Subproject commit {s}\n", .{&hash.hex(oid)});
    } else {
        const obj = repo_mod.repo().odb().read(oid) orelse return -1;
        util.bufAppend(buf, obj.data);
    }
    return 0;
}

// ---------------------------------------------------------------------------
// filename table

fn inFnTable(state: *State, name: ?[]const u8) ?FnItem {
    const n = name orelse return null;
    return state.fn_table.get(n);
}

fn fnPut(state: *State, name: []const u8, v: FnItem) void {
    state.fn_table.put(gpa, name, v) catch util.oom();
}

fn addToFnTable(state: *State, patch: *Patch) void {
    if (patch.new_name) |n| fnPut(state, n, .{ .patch = patch });
    if (patch.new_name == null or patch.is_rename) fnPut(state, patch.old_name.?, .was_deleted);
}

fn prepareFnTable(state: *State, patch0: ?*Patch) void {
    var p = patch0;
    while (p) |patch| : (p = patch.next) {
        if (patch.new_name == null or patch.is_rename) fnPut(state, patch.old_name.?, .to_be_deleted);
    }
}

fn istate(state: *State) *index_mod.Index {
    if (state.istate) |i| return i;
    state.istate = index_mod.get();
    return state.istate.?;
}

fn checkoutTarget(state: *State, ce: *index_mod.Entry, st: *os.Stat) i32 {
    var costate = entry_mod.State{ .refresh_cache = true, .istate = istate(state) };
    if (entry_mod.checkoutEntry(ce, &costate, null)) return errorf("cannot checkout {s}", .{ce.path});
    st.* = os.lstatPath(ce.path) orelse return errorf("cannot checkout {s}", .{ce.path});
    return 0;
}

const Previous = struct { patch: ?*Patch, gone: bool };

fn previousPatch(state: *State, patch: *Patch) Previous {
    if (patch.is_copy or patch.is_rename) return .{ .patch = null, .gone = false };
    const prev = inFnTable(state, patch.old_name) orelse return .{ .patch = null, .gone = false };
    switch (prev) {
        .to_be_deleted => return .{ .patch = null, .gone = false },
        .was_deleted => return .{ .patch = null, .gone = true },
        .patch => |p| return .{ .patch = p, .gone = false },
    }
}

fn verifyIndexMatch(state: *State, ce: *const index_mod.Entry, st: os.Stat) bool {
    if (ce.mode & 0o170000 == 0o160000) return !st.isDir();
    return entry_mod.matchStatIgnoreValid(istate(state), ce, st) != 0;
}

const SUBMODULE_PATCH_WITHOUT_INDEX: i32 = 1;

fn readOldData(st: os.Stat, patch: *Patch, path: []const u8, buf: *Buf) i32 {
    const conv_flags = if (patch.crlf_in_old) convert.CONV_EOL_KEEP_CRLF else convert.CONV_EOL_RENORMALIZE;
    if (st.isLnk()) {
        const l = os.readLink(path) orelse return errorf("unable to read symlink {s}", .{path});
        util.bufAppend(buf, l);
        return 0;
    } else if (st.isReg()) {
        const d = os.readFile(path) orelse return errorf("unable to open or read {s}", .{path});
        if (d.len != @as(usize, @intCast(st.size))) return errorf("unable to open or read {s}", .{path});
        if (repo_mod.repo_ != null) {
            util.bufAppend(buf, convert.toGitFlags(path, d, conv_flags));
        } else util.bufAppend(buf, d);
        return 0;
    }
    return -1;
}

fn readFileOrGitlink(ce: ?*const index_mod.Entry, buf: *Buf) i32 {
    const e = ce orelse return 0;
    return readBlobObject(buf, e.oid, e.mode);
}

fn loadPatchTarget(state: *State, buf: *Buf, ce: ?*const index_mod.Entry, st: os.Stat, patch: *Patch, name: ?[]const u8, expected_mode: u32) i32 {
    if (state.cached or state.check_index) {
        if (readFileOrGitlink(ce, buf) != 0) return errorf("failed to read {s}", .{name orelse "(null)"});
    } else if (name) |n| {
        if (expected_mode & 0o170000 == 0o160000) {
            if (ce != null) return readFileOrGitlink(ce, buf);
            return SUBMODULE_PATCH_WITHOUT_INDEX;
        } else if (pathspec.hasSymlinkLeadingPath(n)) {
            return errorf("reading from '{s}' beyond a symbolic link", .{n});
        } else {
            if (readOldData(st, patch, n, buf) != 0) return errorf("failed to read {s}", .{n});
        }
    }
    return 0;
}

fn loadPreimage(state: *State, image: *Image, patch: *Patch, st: os.Stat, ce: ?*const index_mod.Entry) i32 {
    var buf: Buf = .empty;
    const prev = previousPatch(state, patch);
    if (prev.gone) return errorf("path {s} has been renamed/deleted", .{patch.old_name.?});
    if (prev.patch) |p| {
        util.bufAppend(&buf, p.result);
    } else {
        const status = loadPatchTarget(state, &buf, ce, st, patch, patch.old_name, patch.old_mode);
        if (status < 0) return status;
        if (status == SUBMODULE_PATCH_WITHOUT_INDEX) {
            patch.fragments = null;
        } else if (status != 0) {
            return errorf("failed to read {s}", .{patch.old_name.?});
        }
    }
    imagePrepare(image, buf.items, !patch.is_binary);
    return 0;
}

fn resolveTo(image: *Image, oid: Oid) i32 {
    image.clear();
    const obj = repo_mod.repo().odb().read(oid) orelse util.die("unable to read blob object {s}", .{&hash.hex(oid)});
    if (obj.typ != .blob) util.die("unable to read blob object {s}", .{&hash.hex(oid)});
    util.bufAppend(&image.buf, obj.data);
    return 0;
}

fn bufferIsBinary(d: []const u8) bool {
    const n = @min(d.len, 8000);
    return std.mem.indexOfScalar(u8, d[0..n], 0) != null;
}

pub fn conflictStyle() xdiff.MergeStyle {
    const v = repo_mod.cfg.get("merge.conflictstyle") orelse return .merge;
    if (util.eql(v, "diff3")) return .diff3;
    if (util.eql(v, "zdiff3")) return .zdiff3;
    return .merge;
}

const LLResult = struct { status: i32, result: ?[]const u8 };

/// Minimal ll_merge(): text merge via xdiff, binary => take ours + conflict.
fn llMerge(path: []const u8, base: []const u8, ours: []const u8, theirs: []const u8, variant: xdiff.MergeFavor) LLResult {
    if (bufferIsBinary(base) or bufferIsBinary(ours) or bufferIsBinary(theirs)) {
        switch (variant) {
            .ours => return .{ .status = 0, .result = ours },
            .theirs => return .{ .status = 0, .result = theirs },
            else => return .{ .status = 2, .result = ours },
        }
    }
    var marker_size: isize = xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
    if (repo_mod.repo_ != null) {
        switch (@import("attr.zig").get(path, "conflict-marker-size")) {
            .value => |v| {
                if (std.fmt.parseInt(isize, v, 10)) |n| {
                    if (n > 0) marker_size = n;
                } else |_| {}
            },
            else => {},
        }
    }
    const r = xdiff.merge(base, ours, theirs, .{
        .level = .zealous,
        .favor = variant,
        .style = conflictStyle(),
        .marker_size = marker_size,
        .ancestor_name = "base",
        .ours_name = "ours",
        .theirs_name = "theirs",
    }) catch return .{ .status = -1, .result = null };
    return .{ .status = if (r.conflicts > 0) 1 else 0, .result = r.result };
}

fn threeWayMerge(state: *State, image: *Image, path: []const u8, base: Oid, ours: Oid, theirs: Oid) i32 {
    if (hash.eql(base, ours)) return resolveTo(image, theirs);
    if (hash.eql(base, theirs) or hash.eql(ours, theirs)) return resolveTo(image, ours);
    const odb = repo_mod.repo().odb();
    const b = if (odb.read(base)) |o| o.data else "";
    const o_ = if (odb.read(ours)) |o| o.data else "";
    const t = if (odb.read(theirs)) |o| o.data else "";
    const r = llMerge(path, b, o_, t, state.merge_variant);
    if (r.status == 2) warnf("Cannot merge binary files: {s} ({s} vs. {s})", .{ path, "ours", "theirs" });
    if (r.status < 0 or r.result == null) return -1;
    image.clear();
    util.bufAppend(&image.buf, r.result.?);
    return r.status;
}

fn loadCurrent(state: *State, image: *Image, patch: *Patch) i32 {
    const name = patch.new_name.?;
    const mode = patch.new_mode;
    if (patch.is_new == 0) util.die("BUG: patch to {s} is not a creation", .{patch.old_name orelse "(null)"});
    const idx = istate(state);
    const pos = idx.findPos(name) orelse return errorf("{s}: does not exist in index", .{name});
    const ce = &idx.entries.items[pos];
    var st: os.Stat = undefined;
    if (os.lstatPath(name)) |s| {
        st = s;
    } else {
        const e = os.errno();
        if (e != os.ENOENT) return errorf("{s}: {s}", .{ name, os.strErr(e) });
        if (checkoutTarget(state, ce, &st) != 0) return -1;
    }
    if (verifyIndexMatch(state, ce, st)) return errorf("{s}: does not match index", .{name});
    var buf: Buf = .empty;
    const status = loadPatchTarget(state, &buf, ce, st, patch, name, mode);
    if (status < 0) return status;
    if (status != 0) return -1;
    imagePrepare(image, buf.items, !patch.is_binary);
    return 0;
}

fn tryThreeway(state: *State, image: *Image, patch: *Patch, st: os.Stat, ce: ?*const index_mod.Entry) i32 {
    const odb = repo_mod.repo().odb();
    if (patch.is_delete != 0 or patch.old_mode & 0o170000 == 0o160000 or patch.new_mode & 0o170000 == 0o160000 or
        (patch.is_new != 0 and !patch.direct_to_threeway) or
        (patch.is_rename and patch.lines_added == 0 and patch.lines_deleted == 0))
        return -1;
    var buf: Buf = .empty;
    var pre_oid: Oid = undefined;
    if (patch.is_new != 0) {
        pre_oid = odb.write(.blob, "");
    } else {
        const o = revparse.getOid(patch.old_oid_prefix);
        if (o == null or readBlobObject(&buf, o.?, patch.old_mode) != 0)
            return errorf("repository lacks the necessary blob to perform 3-way merge.", .{});
        pre_oid = o.?;
    }
    if (state.apply_verbosity > VERBOSITY_SILENT and patch.direct_to_threeway)
        util.eprint("Performing three-way merge...\n", .{});
    var tmp_image = Image{};
    imagePrepare(&tmp_image, buf.items, true);
    if (applyFragments(state, &tmp_image, patch) < 0) return -1;
    const post_oid = odb.write(.blob, tmp_image.buf.items);
    tmp_image.clear();
    if (patch.is_new != 0) {
        if (loadCurrent(state, &tmp_image, patch) != 0)
            return errorf("cannot read the current contents of '{s}'", .{patch.new_name.?});
    } else {
        if (loadPreimage(state, &tmp_image, patch, st, ce) != 0)
            return errorf("cannot read the current contents of '{s}'", .{patch.old_name.?});
    }
    const our_oid = odb.write(.blob, tmp_image.buf.items);
    const status = threeWayMerge(state, image, patch.new_name.?, pre_oid, our_oid, post_oid);
    if (status < 0) {
        if (state.apply_verbosity > VERBOSITY_SILENT) util.eprint("Failed to perform three-way merge...\n", .{});
        return status;
    }
    if (status != 0) {
        patch.conflicted_threeway = true;
        patch.threeway_stage[0] = if (patch.is_new != 0) hash.zero else pre_oid;
        patch.threeway_stage[1] = our_oid;
        patch.threeway_stage[2] = post_oid;
        if (state.apply_verbosity > VERBOSITY_SILENT)
            util.eprint("Applied patch to '{s}' with conflicts.\n", .{patch.new_name.?});
    } else {
        if (state.apply_verbosity > VERBOSITY_SILENT)
            util.eprint("Applied patch to '{s}' cleanly.\n", .{patch.new_name.?});
    }
    return 0;
}

fn applyData(state: *State, patch: *Patch, st: os.Stat, ce: ?*const index_mod.Entry) i32 {
    var image = Image{};
    if (loadPreimage(state, &image, patch, st, ce) < 0) return -1;
    if (!state.threeway or tryThreeway(state, &image, patch, st, ce) < 0) {
        if (state.apply_verbosity > VERBOSITY_SILENT and state.threeway and !patch.direct_to_threeway)
            util.eprint("Falling back to direct application...\n", .{});
        if (patch.direct_to_threeway or applyFragments(state, &image, patch) < 0) return -1;
    }
    patch.result = image.buf.items;
    addToFnTable(state, patch);
    if (0 < patch.is_delete and patch.result.len != 0) return errorf("removal patch leaves file contents", .{});
    return 0;
}

fn checkPreimage(state: *State, patch: *Patch, ce: *?*index_mod.Entry, st: *os.Stat) i32 {
    const old_name = patch.old_name orelse return 0;
    var st_mode: u32 = 0;
    var stat_failed = false;
    const prev = previousPatch(state, patch);
    if (prev.gone) return errorf("path {s} has been renamed/deleted", .{old_name});
    is_new: {
        if (prev.patch) |p| {
            st_mode = p.new_mode;
        } else if (!state.cached) {
            if (os.lstatPath(old_name)) |s| {
                st.* = s;
            } else {
                stat_failed = true;
                const e = os.errno();
                if (e != os.ENOENT) return errorf("{s}: {s}", .{ old_name, os.strErr(e) });
            }
        }
        if (state.check_index and prev.patch == null) {
            const idx = istate(state);
            const pos = idx.findPos(old_name) orelse {
                if (patch.is_new < 0) break :is_new;
                return errorf("{s}: does not exist in index", .{old_name});
            };
            ce.* = &idx.entries.items[pos];
            if (stat_failed) {
                if (checkoutTarget(state, ce.*.?, st) != 0) return -1;
            }
            if (!state.cached and verifyIndexMatch(state, ce.*.?, st.*))
                return errorf("{s}: does not match index", .{old_name});
            if (state.cached) st_mode = ce.*.?.mode;
        } else if (stat_failed) {
            if (patch.is_new < 0) break :is_new;
            return errorf("{s}: {s}", .{ old_name, os.strErr(os.ENOENT) });
        }
        if (!state.cached and prev.patch == null) {
            const trust_exec = repo_mod.cfg.getBool("core.filemode") orelse true;
            if (trust_exec or !st.isReg()) {
                st_mode = index_mod.ceModeFromStat(ce.*, st.*);
            } else if (ce.*) |c| {
                st_mode = c.mode;
            } else st_mode = patch.old_mode;
        }
        if (patch.is_new < 0) patch.is_new = 0;
        if (patch.old_mode == 0) patch.old_mode = st_mode;
        if ((st_mode ^ patch.old_mode) & 0o170000 != 0) return errorf("{s}: wrong type", .{old_name});
        if (st_mode != patch.old_mode)
            warnf("{s} has type {o}, expected {o}", .{ old_name, st_mode, patch.old_mode });
        if (patch.new_mode == 0 and patch.is_delete == 0) patch.new_mode = st_mode;
        return 0;
    }
    patch.is_new = 1;
    patch.is_delete = 0;
    patch.old_name = null;
    return 0;
}

const EXISTS_IN_INDEX: i32 = 1;
const EXISTS_IN_WORKTREE: i32 = 2;
const EXISTS_IN_INDEX_AS_ITA: i32 = 3;

fn checkToCreate(state: *State, new_name: []const u8, ok_if_exists: bool) i32 {
    if (state.check_index and (!ok_if_exists or !state.cached)) {
        const idx = istate(state);
        if (idx.findPos(new_name)) |pos| {
            const ce = &idx.entries.items[pos];
            if (!ok_if_exists and !ce.intentToAdd()) return EXISTS_IN_INDEX;
            if (!state.cached and ce.intentToAdd()) return EXISTS_IN_INDEX_AS_ITA;
        }
    }
    if (state.cached) return 0;
    if (os.lstatPath(new_name)) |nst| {
        if (nst.isDir() or ok_if_exists) return 0;
        if (pathspec.hasSymlinkLeadingPath(new_name)) return 0;
        return EXISTS_IN_WORKTREE;
    } else {
        const e = os.errno();
        if (e != os.ENOENT and e != os.ENOTDIR) return errorf("{s}: {s}", .{ new_name, os.strErr(e) });
    }
    return 0;
}

fn prepareSymlinkChanges(state: *State, patch0: ?*Patch) void {
    var p = patch0;
    while (p) |patch| : (p = patch.next) {
        if (patch.old_name != null and patch.old_mode & 0o170000 == 0o120000 and (patch.is_rename or patch.is_delete != 0))
            state.removed_symlinks.put(gpa, patch.old_name.?, {}) catch util.oom();
        if (patch.new_name != null and patch.new_mode & 0o170000 == 0o120000)
            state.kept_symlinks.put(gpa, patch.new_name.?, {}) catch util.oom();
    }
}

fn pathIsBeyondSymlink(state: *State, name: []const u8) bool {
    var len = name.len;
    while (true) {
        while (len > 0) {
            len -= 1;
            if (len == 0 or name[len] == '/') break;
        }
        if (len == 0) break;
        const sub = name[0..len];
        if (state.kept_symlinks.contains(sub)) return true;
        if (state.removed_symlinks.contains(sub)) continue;
        if (state.check_index) {
            const idx = istate(state);
            if (idx.get(sub)) |ce| {
                if (ce.mode & 0o170000 == 0o120000) return true;
            }
        } else {
            if (os.lstatPath(sub)) |st| {
                if (st.isLnk()) return true;
            }
        }
    }
    return false;
}

fn checkUnsafePath(patch: *Patch) i32 {
    var old_name: ?[]const u8 = null;
    var new_name: ?[]const u8 = null;
    if (patch.is_delete != 0) {
        old_name = patch.old_name;
    } else if (patch.is_new == 0 and !patch.is_copy) old_name = patch.old_name;
    if (patch.is_delete == 0) new_name = patch.new_name;
    if (old_name) |n| {
        if (!index_mod.verifyPath(n, patch.old_mode)) return errorf("invalid path '{s}'", .{n});
    }
    if (new_name) |n| {
        if (!index_mod.verifyPath(n, patch.new_mode)) return errorf("invalid path '{s}'", .{n});
    }
    return 0;
}

fn checkPatch(state: *State, patch: *Patch) i32 {
    var st: os.Stat = std.mem.zeroes(os.Stat);
    const new_name = patch.new_name;
    const name = patch.old_name orelse new_name.?;
    var ce: ?*index_mod.Entry = null;
    patch.rejected = true;
    const status = checkPreimage(state, patch, &ce, &st);
    if (status != 0) return status;
    const old_name = patch.old_name;

    var ok_if_exists = false;
    if (inFnTable(state, new_name)) |t| {
        switch (t) {
            .was_deleted, .to_be_deleted => ok_if_exists = true,
            else => {},
        }
    }
    if (new_name != null and (0 < patch.is_new or patch.is_rename or patch.is_copy)) {
        const nn = new_name.?;
        const e = checkToCreate(state, nn, ok_if_exists);
        if (e != 0 and state.threeway) {
            patch.direct_to_threeway = true;
        } else switch (e) {
            0 => {},
            EXISTS_IN_INDEX => return errorf("{s}: already exists in index", .{nn}),
            EXISTS_IN_INDEX_AS_ITA => return errorf("{s}: does not match index", .{nn}),
            EXISTS_IN_WORKTREE => return errorf("{s}: already exists in working directory", .{nn}),
            else => return e,
        }
        if (patch.new_mode == 0) {
            patch.new_mode = if (0 < patch.is_new) 0o100644 else patch.old_mode;
        }
    }
    if (new_name != null and old_name != null) {
        const same = util.eql(old_name.?, new_name.?);
        if (patch.new_mode == 0) patch.new_mode = patch.old_mode;
        if ((patch.old_mode ^ patch.new_mode) & 0o170000 != 0) {
            if (same)
                return errorf("new mode ({o}) of {s} does not match old mode ({o})", .{ patch.new_mode, new_name.?, patch.old_mode });
            return errorf("new mode ({o}) of {s} does not match old mode ({o}) of {s}", .{ patch.new_mode, new_name.?, patch.old_mode, old_name.? });
        }
    }
    if (!state.unsafe_paths and checkUnsafePath(patch) != 0) return -128;
    if (patch.is_delete == 0 and pathIsBeyondSymlink(state, patch.new_name.?))
        return errorf("affected file '{s}' is beyond a symbolic link", .{patch.new_name.?});
    if (applyData(state, patch, st, ce) < 0) return errorf("{s}: patch does not apply", .{name});
    patch.rejected = false;
    return 0;
}

fn sayPatchName(comptime f: []const u8, patch: *const Patch) void {
    var sb: Buf = .empty;
    if (patch.old_name != null and patch.new_name != null and !util.eql(patch.old_name.?, patch.new_name.?)) {
        util.bufAppend(&sb, util.cquote(patch.old_name.?));
        util.bufAppend(&sb, " => ");
        util.bufAppend(&sb, util.cquote(patch.new_name.?));
    } else {
        util.bufAppend(&sb, util.cquote(patch.new_name orelse patch.old_name.?));
    }
    util.eprint(f ++ "\n", .{sb.items});
}

fn checkPatchList(state: *State, patch0: ?*Patch) i32 {
    var e: i32 = 0;
    prepareSymlinkChanges(state, patch0);
    prepareFnTable(state, patch0);
    var p = patch0;
    while (p) |patch| : (p = patch.next) {
        if (state.apply_verbosity > VERBOSITY_NORMAL) sayPatchName("Checking patch {s}...", patch);
        const res = checkPatch(state, patch);
        if (res == -128) return -128;
        e |= res;
    }
    return e;
}

fn readApplyCache(state: *State) i32 {
    if (state.istate != null) return 0;
    if (state.index_file) |f| {
        state.istate = index_mod.readFrom(f);
    } else {
        state.istate = index_mod.get();
    }
    return 0;
}

fn preimageOidInGitlinkPatch(p: *Patch) ?Oid {
    if (p.fragments) |hunk| {
        if (hunk.next == null and hunk.oldpos == 1 and hunk.oldlines == 1) {
            if (std.mem.indexOfScalar(u8, hunk.patch, '\n')) |nl| {
                const pre = hunk.patch[nl + 1 ..];
                const heading = "-Subproject commit ";
                if (util.startsWith(pre, heading) and pre.len >= heading.len + hash.HEXSZ + 1) {
                    const hx = pre[heading.len .. heading.len + hash.HEXSZ];
                    if (hash.fromHex(hx)) |oid| {
                        if (pre[heading.len + hash.HEXSZ] == '\n' and util.startsWith(hx, p.old_oid_prefix)) return oid;
                    }
                }
            }
        }
    }
    if (p.old_oid_prefix.len != hash.HEXSZ) return null;
    return hash.fromHex(p.old_oid_prefix);
}

fn buildFakeAncestor(state: *State, list: ?*Patch) i32 {
    var result = index_mod.Index{};
    result.path = state.fake_ancestor.?;
    var p = list;
    while (p) |patch| : (p = patch.next) {
        const name = patch.old_name orelse patch.new_name.?;
        if (0 < patch.is_new) continue;
        var oid: Oid = undefined;
        if (patch.old_mode & 0o170000 == 0o160000) {
            oid = preimageOidInGitlinkPatch(patch) orelse
                return errorf("sha1 information is lacking or useless for submodule {s}", .{name});
        } else if (blk: {
            const r = revparse.resolve(patch.old_oid_prefix, .{}) orelse break :blk null;
            const obj = repo_mod.repo().odb().read(r.oid) orelse break :blk null;
            if (obj.typ != .blob) break :blk null;
            break :blk r.oid;
        }) |o| {
            oid = o;
        } else if (patch.lines_added == 0 and patch.lines_deleted == 0) {
            _ = readApplyCache(state);
            const idx = istate(state);
            const pos = idx.findPos(patch.old_name.?) orelse
                return errorf("mode change for {s}, which is not in current HEAD", .{name});
            oid = idx.entries.items[pos].oid;
        } else return errorf("sha1 information is lacking or useless ({s}).", .{name});
        if (!index_mod.verifyPath(name, patch.old_mode))
            return errorf("make_cache_entry failed for path '{s}'", .{name});
        const e = index_mod.Entry{ .path = name, .mode = index_mod.canonMode(patch.old_mode), .oid = oid };
        if (!result.add(e, .{ .ok_to_add = true }))
            return errorf("could not add {s} to temporary index", .{name});
    }
    result.write();
    return 0;
}

fn printStatSummary(files: i32, insertions: i32, deletions: i32) void {
    var sb: Buf = .empty;
    if (files == 0) {
        util.out(" 0 files changed\n");
        return;
    }
    if (files == 1) util.bufPrint(&sb, " {d} file changed", .{files}) else util.bufPrint(&sb, " {d} files changed", .{files});
    if (insertions != 0 or deletions == 0) {
        if (insertions == 1) util.bufPrint(&sb, ", {d} insertion(+)", .{insertions}) else util.bufPrint(&sb, ", {d} insertions(+)", .{insertions});
    }
    if (deletions != 0 or insertions == 0) {
        if (deletions == 1) util.bufPrint(&sb, ", {d} deletion(-)", .{deletions}) else util.bufPrint(&sb, ", {d} deletions(-)", .{deletions});
    }
    util.bufByte(&sb, '\n');
    util.out(sb.items);
}

fn statPatchList(state: *State, list: ?*Patch) void {
    var files: i32 = 0;
    var adds: i32 = 0;
    var dels: i32 = 0;
    var p = list;
    while (p) |patch| : (p = patch.next) {
        files += 1;
        adds += patch.lines_added;
        dels += patch.lines_deleted;
        showStats(state, patch);
    }
    printStatSummary(files, adds, dels);
}

fn numstatPatchList(state: *State, list: ?*Patch) void {
    var p = list;
    while (p) |patch| : (p = patch.next) {
        const name = patch.new_name orelse patch.old_name.?;
        if (patch.is_binary) {
            util.out("-\t-\t");
        } else util.outf("{d}\t{d}\t", .{ patch.lines_added, patch.lines_deleted });
        if (state.line_termination != 0) util.out(util.cquote(name)) else util.out(name);
        util.out(&.{state.line_termination});
    }
}

fn showFileModeName(newdelete: []const u8, mode: u32, name: []const u8) void {
    if (mode != 0) {
        util.outf(" {s} mode {o:0>6} {s}\n", .{ newdelete, mode, name });
    } else util.outf(" {s} {s}\n", .{ newdelete, name });
}

fn showModeChange(p: *const Patch, show_name: bool) void {
    if (p.old_mode != 0 and p.new_mode != 0 and p.old_mode != p.new_mode) {
        if (show_name) {
            util.outf(" mode change {o:0>6} => {o:0>6} {s}\n", .{ p.old_mode, p.new_mode, p.new_name.? });
        } else util.outf(" mode change {o:0>6} => {o:0>6}\n", .{ p.old_mode, p.new_mode });
    }
}

fn showRenameCopy(p: *const Patch) void {
    const renamecopy = if (p.is_rename) "rename" else "copy";
    const on = p.old_name.?;
    const nn = p.new_name.?;
    var o: usize = 0;
    var n: usize = 0;
    while (true) {
        const so = std.mem.indexOfScalarPos(u8, on, o, '/') orelse break;
        const sn = std.mem.indexOfScalarPos(u8, nn, n, '/') orelse break;
        if (so - o != sn - n or !std.mem.eql(u8, on[o..so], nn[n..sn])) break;
        o = so + 1;
        n = sn + 1;
    }
    if (o != 0) {
        util.outf(" {s} {s}{{{s} => {s}}} ({d}%)\n", .{ renamecopy, on[0..o], on[o..], nn[n..], p.score });
    } else util.outf(" {s} {s} => {s} ({d}%)\n", .{ renamecopy, on, nn, p.score });
    showModeChange(p, false);
}

fn summaryPatchList(list: ?*Patch) void {
    var pp = list;
    while (pp) |p| : (pp = p.next) {
        if (p.is_new != 0) {
            showFileModeName("create", p.new_mode, p.new_name.?);
        } else if (p.is_delete != 0) {
            showFileModeName("delete", p.old_mode, p.old_name.?);
        } else {
            if (p.is_rename or p.is_copy) {
                showRenameCopy(p);
            } else {
                if (p.score != 0) {
                    util.outf(" rewrite {s} ({d}%)\n", .{ p.new_name.?, p.score });
                    showModeChange(p, false);
                } else showModeChange(p, true);
            }
        }
    }
}

fn patchStats(state: *State, patch: *const Patch) void {
    const lines = patch.lines_added + patch.lines_deleted;
    if (lines > state.max_change) state.max_change = lines;
    if (patch.old_name) |n| {
        const len: i32 = @intCast(util.cquote(n).len);
        if (len > state.max_len) state.max_len = len;
    }
    if (patch.new_name) |n| {
        const len: i32 = @intCast(util.cquote(n).len);
        if (len > state.max_len) state.max_len = len;
    }
}

// ---------------------------------------------------------------------------
// writing out results

fn removeOrWarn(mode: u32, file: []const u8) bool {
    if (mode & 0o170000 == 0o160000) {
        if (!os.rmdir(file)) {
            const e = os.errno();
            if (e == os.ENOENT) return true;
            warnf("unable to rmdir '{s}': {s}", .{ file, os.strErr(e) });
            return false;
        }
        return true;
    }
    if (!os.unlink(file)) {
        const e = os.errno();
        if (e == os.ENOENT) return true;
        warnf("unable to unlink '{s}': {s}", .{ file, os.strErr(e) });
        return false;
    }
    return true;
}

fn removeFile(state: *State, patch: *Patch, rmdir_empty: bool) i32 {
    if (state.update_index and !state.ita_only) {
        index_mod.removeFileWithFlags(istate(state), patch.old_name.?, 0);
    }
    if (!state.cached) {
        if (removeOrWarn(patch.old_mode, patch.old_name.?) and rmdir_empty)
            _ = index_mod.removeWorktreePath(patch.old_name.?);
    }
    return 0;
}

fn addIndexFile(state: *State, path: []const u8, mode: u32, buf: []const u8) i32 {
    var ce = index_mod.Entry{ .path = util.dupe(path), .mode = index_mod.canonMode(mode), .oid = hash.zero };
    const odb = repo_mod.repo().odb();
    if (state.ita_only) {
        ce.ext_flags |= index_mod.CE_INTENT_TO_ADD;
        ce.oid = odb.write(.blob, "");
    } else if (mode & 0o170000 == 0o160000) {
        const s = util.skipPrefix(buf, "Subproject commit ") orelse return errorf("corrupt patch for submodule {s}", .{path});
        if (s.len < hash.HEXSZ) return errorf("corrupt patch for submodule {s}", .{path});
        ce.oid = hash.fromHex(s[0..hash.HEXSZ]) orelse return errorf("corrupt patch for submodule {s}", .{path});
    } else {
        if (!state.cached) {
            const st = os.lstatPath(path) orelse
                return errorf("unable to stat newly created file '{s}': {s}", .{ path, os.lastErr() });
            ce.fillStat(st);
        }
        ce.oid = odb.write(.blob, buf);
    }
    const idx = istate(state);
    if (!idx.add(ce, .{ .ok_to_add = true, .ok_to_replace = false }))
        return errorf("unable to add cache entry for {s}", .{path});
    idx.changed = true;
    return 0;
}

/// -1 unrecoverable, 0 ok, 1 recoverable (errno set)
fn tryCreateFile(state: *State, path: []const u8, mode: u32, buf: []const u8) i32 {
    _ = state;
    if (mode & 0o170000 == 0o160000) {
        if (os.lstatPath(path)) |st| {
            if (st.isDir()) return 0;
        }
        return if (os.mkdir(path, 0o777)) 0 else 1;
    }
    const has_symlinks = repo_mod.cfg.getBool("core.symlinks") orelse true;
    if (has_symlinks and mode & 0o170000 == 0o120000) {
        const target = if (std.mem.indexOfScalar(u8, buf, 0)) |n| buf[0..n] else buf;
        return if (os.symlink(target, path)) 0 else 1;
    }
    const fd = os.openFile(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, if (mode & 0o100 != 0) 0o777 else 0o666);
    if (fd < 0) return 1;
    const data = if (repo_mod.repo_ != null) convert.toWorktree(path, buf) else buf;
    var res = false;
    os.writeAll(fd, data) catch {
        res = true;
        _ = errorf("failed to write to '{s}': {s}", .{ path, os.lastErr() });
    };
    os.close(fd);
    return if (res) -1 else 0;
}

fn createOneFile(state: *State, path: []const u8, mode: u32, buf: []const u8) i32 {
    if (state.cached) return 0;
    if (pathIsBeyondSymlink(state, path))
        return errorf("affected file '{s}' is beyond a symbolic link", .{path});
    var res = tryCreateFile(state, path, mode, buf);
    if (res < 0) return -1;
    if (res == 0) return 0;
    var e = os.errno();
    if (e == os.ENOENT) {
        if (!os.mkdirLeading(path)) return 0;
        res = tryCreateFile(state, path, mode, buf);
        if (res < 0) return -1;
        if (res == 0) return 0;
        e = os.errno();
    }
    if (e == os.EEXIST or e == os.EACCES) {
        if (os.lstatPath(path)) |st| {
            if (!st.isDir() or !os.rmdir(path)) e = os.EEXIST;
        }
        // note: C leaves errno as set by rmdir/lstat otherwise
        else e = os.errno();
    }
    if (e == os.EEXIST) {
        var nr: u32 = @intCast(std.c.getpid());
        while (true) {
            const newpath = util.fmt("{s}~{d}", .{ path, nr });
            res = tryCreateFile(state, newpath, mode, buf);
            if (res < 0) return -1;
            if (res == 0) {
                if (os.rename(newpath, path)) return 0;
                e = os.errno();
                if (!os.unlink(newpath)) {
                    const ue = os.errno();
                    if (ue != os.ENOENT) warnf("unable to unlink '{s}': {s}", .{ newpath, os.strErr(ue) });
                }
                break;
            }
            e = os.errno();
            if (e != os.EEXIST) break;
            nr +%= 1;
        }
    }
    return errorf("unable to write file '{s}' mode {o}: {s}", .{ path, mode, os.strErr(e) });
}

fn addConflictedStagesFile(state: *State, patch: *Patch) i32 {
    if (!state.update_index) return 0;
    const mode = if (patch.new_mode != 0) patch.new_mode else 0o100644;
    const idx = istate(state);
    index_mod.removeFileWithFlags(idx, patch.new_name.?, 0);
    var stage: u32 = 1;
    while (stage < 4) : (stage += 1) {
        const oid = patch.threeway_stage[stage - 1];
        if (hash.isZero(oid)) continue;
        var ce = index_mod.Entry{ .path = util.dupe(patch.new_name.?), .mode = index_mod.canonMode(mode), .oid = oid };
        ce.setStage(stage);
        if (!idx.add(ce, .{ .ok_to_add = true, .ok_to_replace = false }))
            return errorf("unable to add cache entry for {s}", .{patch.new_name.?});
    }
    idx.changed = true;
    return 0;
}

fn createFile(state: *State, patch: *Patch) i32 {
    const path = patch.new_name.?;
    var mode = patch.new_mode;
    if (mode == 0) mode = 0o100644;
    if (createOneFile(state, path, mode, patch.result) != 0) return -1;
    if (patch.conflicted_threeway) return addConflictedStagesFile(state, patch);
    if (state.check_index or (state.ita_only and patch.is_new > 0))
        return addIndexFile(state, path, mode, patch.result);
    return 0;
}

fn writeOutOneResult(state: *State, patch: *Patch, phase: u32) i32 {
    if (patch.is_delete > 0) {
        if (phase == 0) return removeFile(state, patch, true);
        return 0;
    }
    if (patch.is_new > 0 or patch.is_copy) {
        if (phase == 1) return createFile(state, patch);
        return 0;
    }
    if (phase == 0) return removeFile(state, patch, patch.is_rename);
    if (phase == 1) return createFile(state, patch);
    return 0;
}

fn writeOutOneReject(state: *State, patch: *Patch) i32 {
    var cnt: i32 = 0;
    var fr = patch.fragments;
    while (fr) |f| : (fr = f.next) {
        if (f.rejected) cnt += 1;
    }
    if (cnt == 0) {
        if (state.apply_verbosity > VERBOSITY_NORMAL and !muted) sayPatchName("Applied patch {s} cleanly.", patch);
        return 0;
    }
    if (patch.new_name == null) util.die("internal error", .{});
    if (state.apply_verbosity > VERBOSITY_SILENT) {
        var sb: Buf = .empty;
        if (patch.old_name != null and patch.new_name != null and !util.eql(patch.old_name.?, patch.new_name.?)) {
            util.bufPrint(&sb, "{s} => {s}", .{ util.cquote(patch.old_name.?), util.cquote(patch.new_name.?) });
        } else util.bufAppend(&sb, util.cquote(patch.new_name orelse patch.old_name.?));
        if (cnt == 1) {
            util.eprint("Applying patch {s} with {d} reject...\n", .{ sb.items, cnt });
        } else util.eprint("Applying patch {s} with {d} rejects...\n", .{ sb.items, cnt });
    }
    const namebuf = util.fmt("{s}.rej", .{patch.new_name.?});
    var fd = os.openFile(namebuf, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o666);
    if (fd < 0) {
        if (os.errno() != os.EEXIST) {
            _ = errorf("cannot open {s}: {s}", .{ namebuf, os.lastErr() });
            return -1;
        }
        if (!os.unlink(namebuf)) {
            _ = errorf("cannot unlink '{s}': {s}", .{ namebuf, os.lastErr() });
            return -1;
        }
        fd = os.openFile(namebuf, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o666);
        if (fd < 0) {
            _ = errorf("cannot open {s}: {s}", .{ namebuf, os.lastErr() });
            return -1;
        }
    }
    var rej: Buf = .empty;
    util.bufPrint(&rej, "diff a/{s} b/{s}\t(rejected hunks)\n", .{ patch.new_name.?, patch.new_name.? });
    cnt = 1;
    fr = patch.fragments;
    while (fr) |f| : ({
        fr = f.next;
        cnt += 1;
    }) {
        if (!f.rejected) {
            if (state.apply_verbosity > VERBOSITY_SILENT) util.eprint("Hunk #{d} applied cleanly.\n", .{cnt});
            continue;
        }
        if (state.apply_verbosity > VERBOSITY_SILENT) util.eprint("Rejected hunk #{d}.\n", .{cnt});
        util.bufAppend(&rej, f.patch);
        if (f.patch.len == 0 or f.patch[f.patch.len - 1] != '\n') util.bufByte(&rej, '\n');
    }
    os.writeAll(fd, rej.items) catch {};
    os.close(fd);
    return -1;
}

fn strLess(_: void, a: []const u8, b: []const u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

fn writeOutResults(state: *State, list: ?*Patch) i32 {
    var errs: i32 = 0;
    var cpath: std.ArrayList([]const u8) = .empty;
    var phase: u32 = 0;
    while (phase < 2) : (phase += 1) {
        var l = list;
        while (l) |p| : (l = p.next) {
            if (p.rejected) {
                errs = 1;
            } else {
                if (writeOutOneResult(state, p, phase) != 0) return -1;
                if (phase == 1) {
                    if (writeOutOneReject(state, p) != 0) errs = 1;
                    if (p.conflicted_threeway) {
                        cpath.append(gpa, p.new_name.?) catch util.oom();
                        errs = 1;
                    }
                }
            }
        }
    }
    if (cpath.items.len > 0) {
        std.mem.sort([]const u8, cpath.items, {}, strLess);
        if (state.apply_verbosity > VERBOSITY_SILENT) {
            for (cpath.items) |s| util.eprint("U {s}\n", .{s});
        }
    }
    return errs;
}

fn endsWithPathComponents(path: []const u8, comp: []const u8) bool {
    if (!std.mem.endsWith(u8, path, comp)) return false;
    if (path.len == comp.len) return true;
    return path[path.len - comp.len - 1] == '/';
}

fn applyPatch(state: *State, fd: c_int, filename: []const u8, options: u32) i32 {
    state.patch_input_file = filename;
    state.linenr = 1;
    defer state.fn_table.clearRetainingCapacity();
    const buf = os.readAllFd(fd) catch {
        return errorf("failed to read patch: {s}", .{os.lastErr()}) * 128;
    };
    if (buf.len >= MAX_APPLY_SIZE) return errorf("patch too large", .{}) * 128;
    var list: ?*Patch = null;
    var tail: ?*Patch = null;
    var skipped_patch: i32 = 0;
    var flush_attributes = false;
    var offset: usize = 0;
    while (offset < buf.len) {
        const patch = gpa.create(Patch) catch util.oom();
        patch.* = .{};
        patch.inaccurate_eof = options & APPLY_OPT_INACCURATE_EOF != 0;
        patch.recount = options & APPLY_OPT_RECOUNT != 0;
        const nr = parseChunk(state, buf[offset..], buf.len - offset, patch);
        if (nr < 0) {
            if (nr == -128) return -128;
            break;
        }
        if (state.apply_in_reverse) reversePatches(patch);
        if (usePatch(state, patch)) {
            patchStats(state, patch);
            if (list == null or !state.apply_in_reverse) {
                if (tail) |t| t.next = patch else list = patch;
                tail = patch;
            } else {
                patch.next = list;
                list = patch;
            }
            if ((patch.new_name != null and endsWithPathComponents(patch.new_name.?, ".gitattributes")) or
                (patch.old_name != null and endsWithPathComponents(patch.old_name.?, ".gitattributes")))
                flush_attributes = true;
        } else {
            if (state.apply_verbosity > VERBOSITY_NORMAL and !muted) sayPatchName("Skipped patch '{s}'.", patch);
            skipped_patch += 1;
        }
        offset += @intCast(nr);
    }

    if (list == null and skipped_patch == 0) {
        if (!state.allow_empty) {
            _ = errorf("No valid patches in input (allow with \"--allow-empty\")", .{});
            return -128;
        }
        return 0;
    }

    if (state.whitespace_error != 0 and state.ws_error_action == .die) state.apply = false;

    state.update_index = (state.check_index or state.ita_only) and state.apply;
    if (state.update_index and !state.index_locked) {
        if (state.index_file) |f| {
            const idx = index_mod.readFrom(f);
            idx.lockIndex();
            state.istate = idx;
        } else {
            state.istate = index_mod.lockAndRead();
        }
        state.index_locked = true;
    }
    if (state.check_index or state.update_index) _ = readApplyCache(state);

    if (state.check or state.apply) {
        const r = checkPatchList(state, list);
        if (r == -128) return -128;
        if (r < 0 and !state.apply_with_reject) return -1;
    }

    if (state.apply) {
        const write_res = writeOutResults(state, list);
        if (write_res < 0) return -128;
        if (write_res > 0) return if (state.apply_with_reject) -1 else 1;
    }

    if (state.fake_ancestor != null and buildFakeAncestor(state, list) != 0) return -128;

    if (state.diffstat and state.apply_verbosity > VERBOSITY_SILENT) statPatchList(state, list);
    if (state.numstat and state.apply_verbosity > VERBOSITY_SILENT) numstatPatchList(state, list);
    if (state.summary and state.apply_verbosity > VERBOSITY_SILENT) summaryPatchList(list);

    if (flush_attributes and repo_mod.repo_ != null) @import("attr.zig").reset();
    return 0;
}

pub fn parseWhitespaceOption(state: *State, option: ?[]const u8) i32 {
    const o = option orelse {
        state.ws_error_action = .warn;
        return 0;
    };
    if (util.eql(o, "warn")) {
        state.ws_error_action = .warn;
    } else if (util.eql(o, "nowarn")) {
        state.ws_error_action = .nowarn;
    } else if (util.eql(o, "error")) {
        state.ws_error_action = .die;
    } else if (util.eql(o, "error-all")) {
        state.ws_error_action = .die;
        state.squelch_whitespace_errors = 0;
    } else if (util.eql(o, "strip") or util.eql(o, "fix")) {
        state.ws_error_action = .correct;
    } else return errorf("unrecognized whitespace option '{s}'", .{o});
    return 0;
}

pub fn parseIgnorewhitespaceOption(state: *State, option: ?[]const u8) i32 {
    if (option == null or util.eql(option.?, "no") or util.eql(option.?, "false") or
        util.eql(option.?, "never") or util.eql(option.?, "none"))
    {
        state.ws_ignore_action = .none;
        return 0;
    }
    if (util.eql(option.?, "change")) {
        state.ws_ignore_action = .change;
        return 0;
    }
    return errorf("unrecognized whitespace ignore option '{s}'", .{option.?});
}

/// init_apply_state()
pub fn initState(state: *State, prefix: ?[]const u8) i32 {
    state.* = .{};
    state.prefix = prefix;
    if (repo_mod.repo_ != null) {
        state.cfg_default_whitespace = repo_mod.cfg.get("apply.whitespace");
        state.cfg_default_ignorewhitespace = repo_mod.cfg.get("apply.ignorewhitespace");
    } else {
        state.cfg_default_whitespace = repo_mod.cfg.get("apply.whitespace");
        state.cfg_default_ignorewhitespace = repo_mod.cfg.get("apply.ignorewhitespace");
    }
    if (state.cfg_default_whitespace) |w| {
        if (parseWhitespaceOption(state, w) != 0) return -1;
    }
    if (state.cfg_default_ignorewhitespace) |w| {
        if (parseIgnorewhitespaceOption(state, w) != 0) return -1;
    }
    return 0;
}

pub fn checkState(state: *State, force_apply: bool) i32 {
    const is_not_gitdir = repo_mod.repo_ == null;
    if (state.apply_with_reject and state.threeway)
        return errorf("options '{s}' and '{s}' cannot be used together", .{ "--reject", "--3way" });
    if (state.threeway) {
        if (is_not_gitdir) return errorf("'{s}' outside a repository", .{"--3way"});
        state.check_index = true;
    }
    if (state.apply_with_reject) {
        state.apply = true;
        if (state.apply_verbosity == VERBOSITY_NORMAL) state.apply_verbosity = VERBOSITY_VERBOSE;
    }
    if (!force_apply and (state.diffstat or state.numstat or state.summary or state.check or state.fake_ancestor != null))
        state.apply = false;
    if (state.check_index and is_not_gitdir) return errorf("'{s}' outside a repository", .{"--index"});
    if (state.cached) {
        if (is_not_gitdir) return errorf("'{s}' outside a repository", .{"--cached"});
        state.check_index = true;
    }
    if (state.ita_only and (state.check_index or is_not_gitdir)) state.ita_only = false;
    if (state.check_index) state.unsafe_paths = false;
    if (state.apply_verbosity <= VERBOSITY_SILENT) muted = true;
    return 0;
}

fn setDefaultWhitespaceMode(state: *State) void {
    if (state.whitespace_option == null and state.cfg_default_whitespace == null)
        state.ws_error_action = if (state.apply) .warn else .nowarn;
}

pub fn applyAllPatches(state: *State, argv: []const []const u8, options: u32) u8 {
    const saved_muted = muted;
    defer muted = saved_muted;
    const res = applyAllInner(state, argv, options);
    if (state.index_locked) {
        if (state.istate) |i| i.rollback();
        state.index_locked = false;
    }
    if (res > -1) return @intCast(res);
    return if (res == -1) 1 else 128;
}

fn applyAllInner(state: *State, argv: []const []const u8, options: u32) i32 {
    var errs: i32 = 0;
    var read_stdin = true;
    var res: i32 = 0;
    for (argv) |arg0| {
        if (util.eql(arg0, "-")) {
            res = applyPatch(state, 0, "<stdin>", options);
            if (res < 0) return res;
            errs |= res;
            read_stdin = false;
            continue;
        }
        const arg = if (state.prefix) |p| prefixFilename(p, arg0) else arg0;
        const fd = os.openFile(arg, os.O_RDONLY, 0);
        if (fd < 0) {
            _ = errorf("can't open patch '{s}': {s}", .{ arg, os.lastErr() });
            return -128;
        }
        read_stdin = false;
        setDefaultWhitespaceMode(state);
        res = applyPatch(state, fd, arg, options);
        os.close(fd);
        if (res < 0) return res;
        errs |= res;
    }
    setDefaultWhitespaceMode(state);
    if (read_stdin) {
        res = applyPatch(state, 0, "<stdin>", options);
        if (res < 0) return res;
        errs |= res;
    }

    if (state.whitespace_error != 0) {
        if (state.squelch_whitespace_errors != 0 and state.squelch_whitespace_errors < state.whitespace_error) {
            const squelched = state.whitespace_error - state.squelch_whitespace_errors;
            if (squelched == 1) warnf("squelched {d} whitespace error", .{squelched}) else warnf("squelched {d} whitespace errors", .{squelched});
        }
        if (state.ws_error_action == .die) {
            if (state.whitespace_error == 1)
                _ = errorf("{d} line adds whitespace errors.", .{state.whitespace_error})
            else
                _ = errorf("{d} lines add whitespace errors.", .{state.whitespace_error});
            return -128;
        }
        if (state.applied_after_fixing_ws != 0 and state.apply) {
            if (state.applied_after_fixing_ws == 1)
                warnf("{d} line applied after fixing whitespace errors.", .{state.applied_after_fixing_ws})
            else
                warnf("{d} lines applied after fixing whitespace errors.", .{state.applied_after_fixing_ws});
        } else if (state.whitespace_error != 0) {
            if (state.whitespace_error == 1)
                warnf("{d} line adds whitespace errors.", .{state.whitespace_error})
            else
                warnf("{d} lines add whitespace errors.", .{state.whitespace_error});
        }
    }

    if (state.update_index) {
        const idx = istate(state);
        idx.write();
        state.index_locked = false;
    }
    return if (errs != 0) 1 else 0;
}

// ---------------------------------------------------------------------------
// option parsing (apply_parse_options)

const po = @import("parseopt.zig");

var cur_state: *State = undefined;

fn cbExclude(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    cur_state.limit_by_name.append(gpa, .{ .pattern = arg.?, .include = false }) catch util.oom();
}
fn cbInclude(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    cur_state.limit_by_name.append(gpa, .{ .pattern = arg.?, .include = true }) catch util.oom();
    cur_state.has_include = true;
}
fn cbP(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const v = std.fmt.parseInt(i32, arg.?, 10) catch -1;
    if (v < 0) util.die("option -p expects a non-negative integer, got '{s}'", .{arg.?});
    cur_state.p_value = v;
    cur_state.p_value_known = true;
}
fn cbSpaceChange(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    cur_state.ws_ignore_action = if (unset) .none else .change;
}
fn cbWhitespace(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    cur_state.whitespace_option = arg;
    if (parseWhitespaceOption(cur_state, arg) != 0) os.exit(129);
}
fn cbDirectory(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    cur_state.root.clearRetainingCapacity();
    const n = util.normalizePath(arg.?) orelse {
        util.err("unable to normalize directory: '{s}'", .{arg.?});
        os.exit(129);
    };
    util.bufAppend(&cur_state.root, n);
    if (cur_state.root.items.len > 0 and cur_state.root.items[cur_state.root.items.len - 1] != '/')
        util.bufByte(&cur_state.root, '/');
}
fn cbOurs(_: ?[]const u8, _: bool) void {
    cur_state.merge_variant = .ours;
}
fn cbTheirs(_: ?[]const u8, _: bool) void {
    cur_state.merge_variant = .theirs;
}
fn cbUnion(_: ?[]const u8, _: bool) void {
    cur_state.merge_variant = .union_;
}
fn cbZ(_: ?[]const u8, _: bool) void {
    cur_state.line_termination = 0;
}
fn cbNoop(_: ?[]const u8, _: bool) void {}

/// apply_parse_options(): returns remaining args.
pub fn parseOptions(args: []const []const u8, state: *State, force_apply: *bool, options: *u32, usage: []const []const u8) [][]const u8 {
    cur_state = state;
    var opts_i: i32 = @intCast(options.*);
    var ctx: i32 = -1;
    const S = struct {
        var fa: bool = false;
    };
    S.fa = force_apply.*;
    const table = [_]po.Opt{
        .{ .long = "exclude", .kind = .callback, .cb = cbExclude, .argh = "path", .help = "don't apply changes matching the given path", .noneg = true },
        .{ .long = "include", .kind = .callback, .cb = cbInclude, .argh = "path", .help = "apply changes matching the given path", .noneg = true },
        po.callback('p', "", cbP, "num", "remove <num> leading slashes from traditional diff paths"),
        po.boolean(0, "no-add", &state.no_add, "ignore additions made by the patch"),
        po.boolean(0, "stat", &state.diffstat, "instead of applying the patch, output diffstat for the input"),
        .{ .long = "allow-binary-replacement", .kind = .callback, .cb = cbNoop, .noarg = true, .noneg = true, .help = "no-op (backward compatibility)" },
        .{ .long = "binary", .kind = .callback, .cb = cbNoop, .noarg = true, .noneg = true, .help = "no-op (backward compatibility)" },
        po.boolean(0, "numstat", &state.numstat, "show number of added and deleted lines in decimal notation"),
        po.boolean(0, "summary", &state.summary, "instead of applying the patch, output a summary for the input"),
        po.boolean(0, "check", &state.check, "instead of applying the patch, see if the patch is applicable"),
        po.boolean(0, "index", &state.check_index, "make sure the patch is applicable to the current index"),
        po.boolean('N', "intent-to-add", &state.ita_only, "mark new files with `git add --intent-to-add`"),
        po.boolean(0, "cached", &state.cached, "apply a patch without touching the working tree"),
        po.boolean(0, "unsafe-paths", &state.unsafe_paths, "accept a patch that touches outside the working area"),
        po.boolean(0, "apply", &S.fa, "also apply the patch (use with --stat/--summary/--check)"),
        po.boolean('3', "3way", &state.threeway, "attempt three-way merge, fall back on normal patch if that fails"),
        .{ .long = "ours", .kind = .callback, .cb = cbOurs, .noarg = true, .noneg = true, .help = "for conflicts, use our version" },
        .{ .long = "theirs", .kind = .callback, .cb = cbTheirs, .noarg = true, .noneg = true, .help = "for conflicts, use their version" },
        .{ .long = "union", .kind = .callback, .cb = cbUnion, .noarg = true, .noneg = true, .help = "for conflicts, use a union version" },
        po.filename(0, "build-fake-ancestor", &state.fake_ancestor, "file", "build a temporary index based on embedded index information"),
        po.callbackNoArg('z', "", cbZ, "paths are separated with NUL character"),
        .{ .short = 'C', .kind = .uint, .i = &ctx, .argh = "n", .help = "ensure at least <n> lines of context match" },
        po.callback(0, "whitespace", cbWhitespace, "action", "detect new or modified lines that have whitespace errors"),
        po.callbackNoArg(0, "ignore-space-change", cbSpaceChange, "ignore changes in whitespace when finding context"),
        po.callbackNoArg(0, "ignore-whitespace", cbSpaceChange, "ignore changes in whitespace when finding context"),
        po.boolean('R', "reverse", &state.apply_in_reverse, "apply the patch in reverse"),
        po.boolean(0, "unidiff-zero", &state.unidiff_zero, "don't expect at least one line of context"),
        po.boolean(0, "reject", &state.apply_with_reject, "leave the rejected hunks in corresponding *.rej files"),
        po.boolean(0, "allow-overlap", &state.allow_overlap, "allow overlapping hunks"),
        po.callbackNoArg('v', "verbose", cbVerbose, "be more verbose"),
        po.callbackNoArg('q', "quiet", cbQuiet, "be more quiet"),
        po.bit(0, "inaccurate-eof", &opts_i, @intCast(APPLY_OPT_INACCURATE_EOF), "tolerate incorrectly detected missing new-line at the end of file"),
        po.bit(0, "recount", &opts_i, @intCast(APPLY_OPT_RECOUNT), "do not trust the line counts in the hunk headers"),
        po.callback(0, "directory", cbDirectory, "root", "prepend <root> to all filenames"),
        po.boolean(0, "allow-empty", &state.allow_empty, "don't return error for empty patches"),
    };
    const rest = po.parse(args, &table, usage, .{});
    options.* = @intCast(opts_i);
    force_apply.* = S.fa;
    if (ctx >= 0) state.p_context = @intCast(ctx);
    if (state.merge_variant != .none and !state.threeway)
        util.die("--ours, --theirs, and --union require --3way", .{});
    return rest;
}

fn cbVerbose(_: ?[]const u8, unset: bool) void {
    const v = &cur_state.apply_verbosity;
    if (unset) v.* = 0 else v.* = (if (v.* < 0) 0 else v.*) + 1;
}
fn cbQuiet(_: ?[]const u8, unset: bool) void {
    const v = &cur_state.apply_verbosity;
    if (unset) v.* = 0 else v.* = (if (v.* > 0) 0 else v.*) - 1;
}
