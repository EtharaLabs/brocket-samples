//! gitattributes (port of attr.c).
//!
//! API:
//!   attr.check(path, names) []Value      // values for the given attribute names
//!   attr.all(path) []NameValue           // all attributes set/unset/valued for path (git_all_attrs order)
//!   attr.setDirection(.checkin/.checkout/.index)   // default .checkin; drops cached stacks
//!   attr.setSource(treeish)              // --attr-source (else GIT_ATTR_SOURCE / attr.tree)
//!   attr.validAttrName(name) bool
//!   attr.reset()                         // drop caches (e.g. after .gitattributes changed)
//!   Value = union { unspecified, set, unset, value: []const u8 }
//!   attr.isTrue(v) etc helpers.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const dir = @import("dir.zig");
const index_mod = @import("index.zig");
const objects = @import("objects.zig");
const revparse = @import("revparse.zig");
const hash = @import("hash.zig");
const gpa = util.gpa;

pub const Value = union(enum) {
    unspecified,
    set,
    unset,
    value: []const u8,
};

pub const NameValue = struct { name: []const u8, value: Value };

pub const Direction = enum { checkin, checkout, index };

const State = struct { attr: usize, setto: Value };

const MatchAttr = struct {
    is_macro: bool,
    macro_attr: usize = 0,
    pattern: []const u8 = "",
    nowildcardlen: usize = 0,
    flags: u32 = 0,
    states: []State,
};

const Frame = struct {
    origin: ?[]const u8 = null,
    attrs: std.ArrayList(*MatchAttr) = .empty,
};

// ---- interning ----
var attr_names: std.ArrayList([]const u8) = .empty;
var attr_map: std.StringHashMapUnmanaged(usize) = .empty;

fn intern(name: []const u8) usize {
    if (attr_map.get(name)) |n| return n;
    const d = util.dupe(name);
    const n = attr_names.items.len;
    attr_names.append(gpa, d) catch util.oom();
    attr_map.put(gpa, d, n) catch util.oom();
    return n;
}

pub fn validAttrName(name: []const u8) bool {
    if (name.len == 0 or name[0] == '-') return false;
    for (name) |ch| {
        if (!(ch == '-' or ch == '.' or ch == '_' or std.ascii.isAlphanumeric(ch))) return false;
    }
    return true;
}

fn reserved(name: []const u8) bool {
    return util.startsWith(name, "builtin_");
}

const blank = " \t\r\n";

fn isBlank(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\r' or c == '\n';
}

fn spanBlank(s: []const u8, start: usize) usize {
    var i = start;
    while (i < s.len and isBlank(s[i])) i += 1;
    return i;
}

fn cspanBlank(s: []const u8, start: usize) usize {
    var i = start;
    while (i < s.len and !isBlank(s[i])) i += 1;
    return i;
}

fn reportInvalid(name: []const u8, src: []const u8, lineno: usize) void {
    util.eprint("{s} is not a valid attribute name: {s}:{d}\n", .{ name, src, lineno });
}

const MACRO_OK: u32 = 1;
const NOFOLLOW: u32 = 2;

/// Parse one attribute state starting at s[i]; returns new index or null on error.
fn parseAttr(src: []const u8, lineno: usize, s: []const u8, i: usize, e: ?*State) ?usize {
    const ep = cspanBlank(s, i);
    var equals: ?usize = std.mem.indexOfScalarPos(u8, s, i, '=');
    if (equals != null and ep < equals.?) equals = null;
    var cp = i;
    var len = if (equals) |q| q - cp else ep - cp;
    if (e == null) {
        if (s[cp] == '-' or s[cp] == '!') {
            cp += 1;
            len -|= 1;
        }
        const nm = s[cp .. cp + len];
        if (!validAttrName(nm) or reserved(s[cp..])) {
            reportInvalid(nm, src, lineno);
            return null;
        }
    } else {
        const st = e.?;
        if (s[cp] == '-' or s[cp] == '!') {
            st.setto = if (s[cp] == '-') .unset else .unspecified;
            cp += 1;
            len -= 1;
        } else if (equals == null) {
            st.setto = .set;
        } else {
            st.setto = .{ .value = util.dupe(s[equals.? + 1 .. ep]) };
        }
        st.attr = intern(s[cp .. cp + len]);
    }
    return spanBlank(s, ep);
}

fn parseAttrLine(line: []const u8, src: []const u8, lineno: usize, flags: u32) ?*MatchAttr {
    const cp = spanBlank(line, 0);
    if (cp >= line.len or line[cp] == '#') return null;
    if (line.len >= 2048) {
        util.warn("ignoring overly long attributes line {d}", .{lineno});
        return null;
    }
    var name: []const u8 = undefined;
    var states: []const u8 = undefined;
    var quoted = false;
    if (line[cp] == '"') {
        if (util.cunquote(line[cp..])) |r| {
            name = r.value;
            states = r.rest;
            quoted = true;
        }
    }
    if (!quoted) {
        const e = cspanBlank(line, cp);
        name = line[cp..e];
        states = line[e..];
    }
    var is_macro = false;
    if (name.len > "[attr]".len and util.startsWith(name, "[attr]")) {
        if (flags & MACRO_OK == 0) {
            // C prints the whole (rest of the) line from name; mimic with name+states for unquoted
            const shown = if (quoted) name else line[cp..];
            util.eprint("{s} not allowed: {s}:{d}\n", .{ shown, src, lineno });
            return null;
        }
        is_macro = true;
        // re-parse from the line itself (names after "[attr]" may be separated by blanks)
        const full = if (quoted) name else line[cp..];
        var k = "[attr]".len;
        k = spanBlank(full, k);
        const e = cspanBlank(full, k);
        name = full[k..e];
        if (!quoted) states = full[e..];
        if (!validAttrName(name) or reserved(name)) {
            reportInvalid(name, src, lineno);
            return null;
        }
    }
    const st0 = spanBlank(states, 0);
    // first pass
    var n: usize = 0;
    var i = st0;
    while (i < states.len) : (n += 1) {
        i = parseAttr(src, lineno, states, i, null) orelse return null;
    }
    const res = gpa.create(MatchAttr) catch util.oom();
    res.* = .{ .is_macro = is_macro, .states = gpa.alloc(State, n) catch util.oom() };
    if (is_macro) {
        res.macro_attr = intern(name);
    } else {
        const pp = dir.parsePathPattern(name);
        if (pp.flags & dir.PATTERN_FLAG_NEGATIVE != 0) {
            util.warn("Negative patterns are ignored in git attributes\nUse '\\!' for literal leading exclamation.", .{});
            return null;
        }
        res.pattern = util.dupe(pp.pattern);
        res.flags = pp.flags;
        res.nowildcardlen = pp.nowildcardlen;
    }
    i = st0;
    var k: usize = 0;
    while (i < states.len) : (k += 1) {
        res.states[k] = .{ .attr = 0, .setto = .set };
        i = parseAttr(src, lineno, states, i, &res.states[k]).?;
    }
    return res;
}

fn handleLine(fr: *Frame, line: []const u8, src: []const u8, lineno: usize, flags: u32) void {
    const a = parseAttrLine(line, src, lineno, flags) orelse return;
    fr.attrs.append(gpa, a) catch util.oom();
}

fn readFromBuf(data0: []const u8, src: []const u8, flags: u32) *Frame {
    const fr = gpa.create(Frame) catch util.oom();
    fr.* = .{};
    var data = data0;
    if (std.mem.indexOfScalar(u8, data, 0)) |z| data = data[0..z];
    var lineno: usize = 0;
    var it = std.mem.splitScalar(u8, data, '\n');
    var first = true;
    while (it.next()) |ln0| {
        var ln = ln0;
        if (it.index == null and ln.len == 0) break;
        if (first and util.startsWith(ln, "\xef\xbb\xbf")) ln = ln[3..];
        first = false;
        lineno += 1;
        handleLine(fr, ln, src, lineno, flags);
    }
    return fr;
}

fn readFromFile(path: []const u8, flags: u32) ?*Frame {
    if (flags & NOFOLLOW != 0) {
        const st = os.lstatPath(path) orelse return null;
        if (st.isLnk()) return null;
    }
    const data = os.readFile(path) orelse {
        const e = os.errno();
        if (e != os.ENOENT and e != os.ENOTDIR and os.lstatPath(path) != null and !os.isDir(path))
            util.warn("unable to access '{s}': {s}", .{ path, os.strErr(e) });
        return null;
    };
    if (data.len >= 100 * 1024 * 1024) {
        util.warn("ignoring overly large gitattributes file '{s}'", .{path});
        return null;
    }
    // strbuf_getline strips "\r\n" too
    const fr = gpa.create(Frame) catch util.oom();
    fr.* = .{};
    var lineno: usize = 0;
    var start: usize = 0;
    while (start < data.len) {
        const nl = std.mem.indexOfScalarPos(u8, data, start, '\n') orelse data.len;
        var ln = data[start..nl];
        if (ln.len > 0 and ln[ln.len - 1] == '\r') ln = ln[0 .. ln.len - 1];
        if (lineno == 0 and util.startsWith(ln, "\xef\xbb\xbf")) ln = ln[3..];
        lineno += 1;
        handleLine(fr, ln, path, lineno, flags);
        start = nl + 1;
    }
    return fr;
}

fn readFromIndex(path: []const u8, flags: u32) ?*Frame {
    if (repo_mod.repo_ == null) return null;
    const idx = index_mod.get();
    const e = idx.get(path) orelse return null;
    if (e.stage() != 0) return null;
    const obj = repo_mod.repo().odb().read(e.oid) orelse return null;
    if (obj.typ != .blob) return null;
    return readFromBuf(obj.data, path, flags);
}

fn readFromBlob(tree: hash.Oid, path: []const u8, flags: u32) ?*Frame {
    const te = objects.treeLookup(tree, path) orelse return null;
    const obj = repo_mod.repo().odb().read(te.oid) orelse return null;
    if (obj.typ != .blob) return null;
    return readFromBuf(obj.data, path, flags);
}

var direction: Direction = .checkin;

fn isBare() bool {
    const r = repo_mod.repo_ orelse return true;
    return r.work_tree == null;
}

fn readAttr(tree: ?hash.Oid, path: []const u8, flags: u32) *Frame {
    var res: ?*Frame = null;
    if (direction == .index) {
        res = readFromIndex(path, flags);
    } else if (tree) |t| {
        res = readFromBlob(t, path, flags);
    } else if (!isBare()) {
        if (direction == .checkout) {
            res = readFromIndex(path, flags);
            if (res == null) res = readFromFile(path, flags);
        } else {
            res = readFromFile(path, flags);
            if (res == null) res = readFromIndex(path, flags);
        }
    }
    if (res) |r| return r;
    const fr = gpa.create(Frame) catch util.oom();
    fr.* = .{};
    return fr;
}

pub fn systemFile() []const u8 {
    return "/etc/gitattributes";
}

pub fn globalFile() ?[]const u8 {
    if (repo_mod.cfg.getPath("core.attributesfile")) |p| return p;
    return dir.xdgConfigHome("attributes");
}

fn systemEnabled() bool {
    const v = os.getenv("GIT_ATTR_NOSYSTEM") orelse return true;
    return !(@import("config.zig").parseBool(v) orelse false);
}

// Stack: frames[0] is builtin ... frames[n-1]; info frame kept separately.
var stack: std.ArrayList(*Frame) = .empty;
var info_frame: ?*Frame = null;
var bootstrapped = false;

fn bootstrap(tree: ?hash.Oid) void {
    if (bootstrapped) return;
    bootstrapped = true;
    stack.items.len = 0;
    const b = gpa.create(Frame) catch util.oom();
    b.* = .{};
    handleLine(b, "[attr]binary -diff -merge -text", "[builtin]", 1, MACRO_OK);
    stack.append(gpa, b) catch util.oom();
    if (systemEnabled()) {
        if (readFromFile(systemFile(), MACRO_OK)) |f| stack.append(gpa, f) catch util.oom();
    }
    if (globalFile()) |g| {
        if (readFromFile(g, MACRO_OK)) |f| stack.append(gpa, f) catch util.oom();
    }
    const root = readAttr(tree, ".gitattributes", MACRO_OK | NOFOLLOW);
    root.origin = "";
    stack.append(gpa, root) catch util.oom();
    var info: ?*Frame = null;
    if (repo_mod.repo_) |r| info = readFromFile(r.gitPath("info/attributes"), MACRO_OK);
    if (info == null) {
        info = gpa.create(Frame) catch util.oom();
        info.?.* = .{};
    }
    info_frame = info;
}

fn prepareStack(tree: ?hash.Oid, path: []const u8, dirlen: usize) void {
    bootstrap(tree);
    // pop frames whose origin is not a prefix of path
    while (stack.items.len > 0) {
        const top = stack.items[stack.items.len - 1];
        const o = top.origin orelse break;
        if (o.len == 0) break;
        if (o.len <= dirlen and util.startsWith(path, o) and path[o.len] == '/') break;
        _ = stack.pop();
    }
    const top = stack.items[stack.items.len - 1];
    var pathbuf: util.Buf = .empty;
    util.bufAppend(&pathbuf, top.origin orelse "");
    while (pathbuf.items.len < dirlen) {
        var len = pathbuf.items.len;
        if (len < dirlen and path[len] == '/') len += 1;
        while (len < dirlen and path[len] != '/') len += 1;
        if (pathbuf.items.len > 0) util.bufByte(&pathbuf, '/');
        util.bufAppend(&pathbuf, path[pathbuf.items.len..len]);
        util.bufAppend(&pathbuf, "/.gitattributes");
        const next = readAttr(tree, util.dupe(pathbuf.items), NOFOLLOW);
        pathbuf.items.len = len;
        next.origin = util.dupe(pathbuf.items);
        stack.append(gpa, next) catch util.oom();
    }
}

fn pathMatches(pathname: []const u8, basename_offset: usize, a: *const MatchAttr, base: []const u8) bool {
    const isdir = pathname.len > 0 and pathname[pathname.len - 1] == '/';
    if (a.flags & dir.PATTERN_FLAG_MUSTBEDIR != 0 and !isdir) return false;
    const plen = pathname.len - @intFromBool(isdir);
    if (a.flags & dir.PATTERN_FLAG_NODIR != 0) {
        const bstart = @min(basename_offset, plen);
        return dir.matchBasename(pathname[bstart..plen], a.pattern, a.nowildcardlen, a.flags);
    }
    return dir.matchPathname(pathname[0..plen], base, base.len, a.pattern, a.nowildcardlen);
}

const Slot = struct { value: ?Value = null, macro: ?*MatchAttr = null };

fn fillOne(slots: []Slot, a: *MatchAttr, rem0: usize) usize {
    var rem = rem0;
    var todo: std.ArrayList(*const State) = .empty;
    for (a.states) |*s| todo.append(gpa, s) catch util.oom();
    while (rem > 0) {
        const st = todo.pop() orelse break;
        const slot = &slots[st.attr];
        if (slot.value == null) {
            slot.value = st.setto;
            rem -= 1;
            if (slot.macro != null and st.setto == .set) {
                for (slot.macro.?.states) |*s| todo.append(gpa, s) catch util.oom();
            }
        }
    }
    return rem;
}

fn frames() []*Frame {
    var l: std.ArrayList(*Frame) = .empty;
    l.append(gpa, info_frame.?) catch util.oom();
    var i = stack.items.len;
    while (i > 0) {
        i -= 1;
        l.append(gpa, stack.items[i]) catch util.oom();
    }
    return l.items;
}

fn collect(path: []const u8) []Slot {
    var last_slash: ?usize = null;
    for (path, 0..) |ch, i| {
        if (ch == '/' and i + 1 < path.len) last_slash = i;
    }
    const basename_offset = if (last_slash) |l| l + 1 else 0;
    const dirlen = last_slash orelse 0;
    const tree = defaultSource();
    prepareStack(tree, path, dirlen);
    const fs = frames();
    const slots = gpa.alloc(Slot, attr_names.items.len) catch util.oom();
    for (slots) |*s| s.* = .{};
    // determine macros (top first wins)
    for (fs) |fr| {
        var i = fr.attrs.items.len;
        while (i > 0) {
            i -= 1;
            const ma = fr.attrs.items[i];
            if (ma.is_macro and slots[ma.macro_attr].macro == null) slots[ma.macro_attr].macro = ma;
        }
    }
    var rem = slots.len;
    for (fs) |fr| {
        if (rem == 0) break;
        const base = fr.origin orelse "";
        var i = fr.attrs.items.len;
        while (rem > 0 and i > 0) {
            i -= 1;
            const a = fr.attrs.items[i];
            if (a.is_macro) continue;
            if (pathMatches(path, basename_offset, a, base)) rem = fillOne(slots, a, rem);
        }
    }
    return slots;
}

fn builtinObjectMode(path: []const u8) Value {
    var mode: u32 = 0;
    const idx: ?*index_mod.Index = if (repo_mod.repo_ != null) index_mod.get() else null;
    if (direction == .checkin) {
        const st = os.lstatPath(path) orelse util.die("unable to stat '{s}': {s}", .{ path, os.lastErr() });
        if (st.isReg()) {
            mode = if (st.mode & 0o100 != 0) 0o100755 else 0o100644;
        } else if (st.isLnk()) {
            mode = 0o120000;
        } else if (st.isDir()) {
            mode = 0o40000;
            if (idx) |ix| {
                if (ix.get(path)) |e| {
                    if (e.mode == 0o160000) mode = 0o160000;
                } else if (dir.isNonbareRepositoryDir(path)) {
                    mode = 0o160000;
                }
            }
        }
    } else {
        const ix = idx orelse return .unspecified;
        const e = ix.get(path) orelse return .unspecified;
        mode = e.mode;
    }
    return .{ .value = util.fmt("{o:0>6}", .{mode}) };
}

/// Values of the named attributes for `path`.
pub fn check(path: []const u8, names: []const []const u8) []Value {
    var nrs = gpa.alloc(usize, names.len) catch util.oom();
    for (names, 0..) |n, i| nrs[i] = intern(n);
    const slots = collect(path);
    const res = gpa.alloc(Value, names.len) catch util.oom();
    for (nrs, 0..) |n, i| {
        if (slots[n].value) |v| {
            res[i] = v;
        } else if (util.eql(attr_names.items[n], "builtin_objectmode")) {
            res[i] = builtinObjectMode(path);
        } else res[i] = .unspecified;
    }
    return res;
}

/// Single attribute convenience.
pub fn get(path: []const u8, name: []const u8) Value {
    return check(path, &.{name})[0];
}

/// All attributes that are set/unset/have a value (git_all_attrs).
pub fn all(path: []const u8) []NameValue {
    const slots = collect(path);
    var l: std.ArrayList(NameValue) = .empty;
    for (slots, 0..) |s, i| {
        const v = s.value orelse continue;
        if (v == .unspecified) continue;
        l.append(gpa, .{ .name = attr_names.items[i], .value = v }) catch util.oom();
    }
    return l.items;
}

pub fn reset() void {
    bootstrapped = false;
    stack.items.len = 0;
    info_frame = null;
}

pub fn setDirection(d: Direction) void {
    if (d != direction) reset();
    direction = d;
}

var source_name: ?[]const u8 = null;
var source_state: ?(?hash.Oid) = null;

pub fn setSource(name: []const u8) void {
    source_name = util.dupe(name);
    source_state = null;
    reset();
}

fn defaultSource() ?hash.Oid {
    if (source_state) |s| return s;
    source_state = computeSource();
    return source_state.?;
}

fn computeSource() ?hash.Oid {
    var ignore_bad = false;
    var name = source_name;
    if (name == null) name = os.getenv("GIT_ATTR_SOURCE");
    if (name == null) {
        if (repo_mod.repo_ != null) {
            if (repo_mod.cfg.get("attr.tree")) |t| {
                name = t;
                ignore_bad = true;
            }
        }
    }
    const n = name orelse return null;
    if (repo_mod.repo_ == null) {
        if (!ignore_bad) util.die("cannot use --attr-source or GIT_ATTR_SOURCE without repo", .{});
        return null;
    }
    const oid = revparse.getTreeish(n) orelse {
        if (!ignore_bad) util.die("bad --attr-source or GIT_ATTR_SOURCE", .{});
        return null;
    };
    return oid;
}

pub fn isSet(v: Value) bool {
    return v == .set;
}
pub fn isUnset(v: Value) bool {
    return v == .unset;
}
pub fn isUnspecified(v: Value) bool {
    return v == .unspecified;
}
