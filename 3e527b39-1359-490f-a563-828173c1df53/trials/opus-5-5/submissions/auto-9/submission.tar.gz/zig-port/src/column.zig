//! Port of column.c: laying out a list of strings in columns
//! (print_columns, column option/config parsing, finalize_colopts).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const color_mod = @import("color.zig");
const gpa = util.gpa;

pub const COL_LAYOUT_MASK: u32 = 0x000F;
pub const COL_ENABLE_MASK: u32 = 0x0030;
pub const COL_PARSEOPT: u32 = 0x0040;
pub const COL_DENSE: u32 = 0x0080;
pub const COL_DISABLED: u32 = 0x0000;
pub const COL_ENABLED: u32 = 0x0010;
pub const COL_AUTO: u32 = 0x0020;
pub const COL_COLUMN: u32 = 0;
pub const COL_ROW: u32 = 1;
pub const COL_PLAIN: u32 = 15;

pub fn layoutOf(c: u32) u32 {
    return c & COL_LAYOUT_MASK;
}

pub fn columnActive(c: u32) bool {
    return c & COL_ENABLE_MASK == COL_ENABLED;
}

/// explicitly_enable_column()
pub fn explicitlyEnabled(c: u32) bool {
    return c & COL_PARSEOPT != 0 and columnActive(c);
}

pub const Options = struct {
    width: i32 = 0,
    padding: i32 = 1,
    indent: ?[]const u8 = null,
    nl: ?[]const u8 = null,
};

extern "c" fn ioctl(fd: c_int, req: c_ulong, ...) c_int;

var term_cols_cached: ?i32 = null;

/// term_columns() (pager.c)
pub fn termColumns() i32 {
    if (term_cols_cached) |v| return v;
    var n: i32 = 80;
    var from_env = false;
    if (os.getenv("COLUMNS")) |s| {
        // atoi()
        var i: usize = 0;
        while (i < s.len and (s[i] == ' ' or s[i] == '\t')) i += 1;
        var neg = false;
        if (i < s.len and (s[i] == '-' or s[i] == '+')) {
            neg = s[i] == '-';
            i += 1;
        }
        var v: i64 = 0;
        while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) {
            v = v * 10 + (s[i] - '0');
            if (v > std.math.maxInt(i32)) break;
        }
        if (neg) v = -v;
        if (v > 0 and v <= std.math.maxInt(i32)) {
            n = @intCast(v);
            from_env = true;
        }
    }
    if (!from_env) {
        var ws: [4]u16 = .{ 0, 0, 0, 0 };
        if (ioctl(1, 0x5413, &ws) == 0 and ws[1] > 0) n = ws[1];
    }
    term_cols_cached = n;
    return n;
}

fn isWide(cp: u21) bool {
    return (cp >= 0x1100 and cp <= 0x115f) or (cp >= 0x231a and cp <= 0x231b) or
        (cp >= 0x2e80 and cp <= 0xa4cf and cp != 0x303f) or
        (cp >= 0xac00 and cp <= 0xd7a3) or (cp >= 0xf900 and cp <= 0xfaff) or (cp >= 0xfe30 and cp <= 0xfe6f) or
        (cp >= 0xff00 and cp <= 0xff60) or (cp >= 0xffe0 and cp <= 0xffe6) or
        (cp >= 0x1f300 and cp <= 0x1f64f) or (cp >= 0x1f900 and cp <= 0x1f9ff) or
        (cp >= 0x20000 and cp <= 0x3fffd);
}

fn isZeroWidth(cp: u21) bool {
    return (cp >= 0x0300 and cp <= 0x036f) or (cp >= 0x0483 and cp <= 0x0489) or
        (cp >= 0x0591 and cp <= 0x05bd) or (cp >= 0x0610 and cp <= 0x061a) or
        (cp >= 0x064b and cp <= 0x065f) or (cp >= 0x200b and cp <= 0x200f) or
        (cp >= 0x20d0 and cp <= 0x20ff) or (cp >= 0xfe00 and cp <= 0xfe0f) or
        (cp >= 0xfe20 and cp <= 0xfe2f) or cp == 0xad;
}

/// utf8_strnwidth(s, len, skip_ansi=1); invalid UTF-8 yields the byte length.
pub fn strWidth(str: []const u8) usize {
    var w: usize = 0;
    var i: usize = 0;
    while (i < str.len) {
        const ch = str[i];
        if (ch == 0x1b and i + 1 < str.len and str[i + 1] == '[') {
            var j = i + 2;
            while (j < str.len and (std.ascii.isDigit(str[j]) or str[j] == ';')) j += 1;
            if (j < str.len and str[j] == 'm') {
                i = j + 1;
                continue;
            }
        }
        if (ch < 0x80) {
            if (ch >= 0x20 and ch != 0x7f) w += 1;
            i += 1;
            continue;
        }
        const len = std.unicode.utf8ByteSequenceLength(ch) catch return str.len;
        if (i + len > str.len) return str.len;
        const cp = std.unicode.utf8Decode(str[i .. i + len]) catch return str.len;
        if (cp >= 0x80 and cp < 0xa0) {} else if (isZeroWidth(cp)) {} else if (isWide(cp)) {
            w += 2;
        } else w += 1;
        i += len;
    }
    return w;
}

/// parse_option() / parse_config(): returns false (after printing an error)
/// on an unknown word.
pub fn parseConfig(colopts: *u32, value: []const u8) bool {
    const Entry = struct { n: []const u8, v: u32, mask: u32 };
    const table = [_]Entry{
        .{ .n = "always", .v = COL_ENABLED, .mask = COL_ENABLE_MASK },
        .{ .n = "never", .v = COL_DISABLED, .mask = COL_ENABLE_MASK },
        .{ .n = "auto", .v = COL_AUTO, .mask = COL_ENABLE_MASK },
        .{ .n = "plain", .v = COL_PLAIN, .mask = COL_LAYOUT_MASK },
        .{ .n = "column", .v = COL_COLUMN, .mask = COL_LAYOUT_MASK },
        .{ .n = "row", .v = COL_ROW, .mask = COL_LAYOUT_MASK },
        .{ .n = "dense", .v = COL_DENSE, .mask = 0 },
    };
    var group_set: u32 = 0;
    var p: usize = 0;
    const isSep = struct {
        fn f(ch: u8) bool {
            return ch == ' ' or ch == ',';
        }
    }.f;
    while (p < value.len) {
        var e = p;
        while (e < value.len and !isSep(value[e])) e += 1;
        if (e > p) {
            const word = value[p..e];
            var found = false;
            for (table) |t| {
                var w = word;
                var set = true;
                if (t.mask == 0 and w.len > 2 and std.mem.startsWith(u8, w, "no")) {
                    w = w[2..];
                    set = false;
                }
                if (!util.eql(w, t.n)) continue;
                if (t.mask == COL_ENABLE_MASK) group_set |= 2;
                if (t.mask == COL_LAYOUT_MASK) group_set |= 1;
                if (t.mask != 0) {
                    colopts.* = (colopts.* & ~t.mask) | t.v;
                } else if (set) {
                    colopts.* |= t.v;
                } else {
                    colopts.* &= ~t.v;
                }
                found = true;
                break;
            }
            if (!found) {
                // C prints the rest of the string starting at the bad word
                util.err("unsupported option '{s}'", .{value[p..]});
                return false;
            }
            p = e;
        }
        while (p < value.len and isSep(value[p])) p += 1;
    }
    if (group_set & 1 != 0 and group_set & 2 == 0)
        colopts.* = (colopts.* & ~COL_ENABLE_MASK) | COL_ENABLED;
    return true;
}

/// git_column_config(): handles column.ui and column.<command>.
/// Returns 0 when fine, -1 on error (already reported).
pub fn gitColumnConfig(key: []const u8, value: ?[]const u8, command: ?[]const u8, colopts: *u32) i32 {
    const it = util.skipPrefix(key, "column.") orelse return 0;
    const matches = util.eql(it, "ui") or (command != null and util.eql(it, command.?));
    if (!matches) return 0;
    const v = value orelse {
        util.err("missing value for '{s}'", .{key});
        return -1;
    };
    if (!parseConfig(colopts, v)) {
        util.err("invalid column.{s} mode {s}", .{ it, v });
        return -1;
    }
    return 0;
}

/// Apply column.ui / column.<command> from the loaded repository config, in
/// file order. Dies like git does when a value is bad.
pub fn applyRepoConfig(command: ?[]const u8, colopts: *u32) void {
    const repo_mod = @import("repo.zig");
    for (repo_mod.cfg.entries.items) |e| {
        if (!util.startsWith(e.key, "column.")) continue;
        if (gitColumnConfig(e.key, e.value, command, colopts) < 0) {
            if (e.origin_type == .cmdline) util.die("unable to parse '{s}' from command-line config", .{e.key});
            util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
        }
    }
}

/// parseopt_column_callback(); returns false on a parse error.
pub fn parseoptColumn(colopts: *u32, arg: ?[]const u8, unset: bool) bool {
    colopts.* |= COL_PARSEOPT;
    colopts.* &= ~COL_ENABLE_MASK;
    if (unset) return true;
    colopts.* |= COL_ENABLED;
    if (arg) |a| return parseConfig(colopts, a);
    return true;
}

/// finalize_colopts(): resolve "auto" (stdout_is_tty < 0 means: check fd 1).
pub fn finalizeColopts(colopts: *u32, stdout_is_tty: i32) void {
    if (colopts.* & COL_ENABLE_MASK == COL_AUTO) {
        var tty = stdout_is_tty;
        if (tty < 0) tty = if (os.isatty(1)) 1 else 0;
        colopts.* &= ~COL_ENABLE_MASK;
        if (tty != 0 or color_mod.pagerInUse()) colopts.* |= COL_ENABLED;
    }
}

const Data = struct {
    n: usize,
    colopts: u32,
    rows: isize = 0,
    cols: isize = 0,
    len: []isize,
    width: ?[]usize = null,
    indent: []const u8,
    nl: []const u8,
    padding: isize,
    total: isize,

    fn linear(d: *const Data, x: isize, y: isize) isize {
        if (layoutOf(d.colopts) == COL_COLUMN) return x * d.rows + y;
        return y * d.cols + x;
    }

    fn computeColumnWidth(d: *Data) void {
        const w = d.width.?;
        var x: isize = 0;
        while (x < d.cols) : (x += 1) {
            const xi: usize = @intCast(x);
            w[xi] = @intCast(d.linear(x, 0));
            var y: isize = 0;
            while (y < d.rows) : (y += 1) {
                const i = d.linear(x, y);
                if (i < d.n and d.len[w[xi]] < d.len[@intCast(i)]) w[xi] = @intCast(i);
            }
        }
    }

    fn ensureWidth(d: *Data) void {
        const need: usize = @intCast(@max(d.cols, 1));
        if (d.width) |w| {
            if (w.len < need) d.width = gpa.realloc(w, need) catch util.oom();
        } else {
            d.width = gpa.alloc(usize, need) catch util.oom();
        }
    }
};

fn divRoundUp(a: isize, b: isize) isize {
    return @divTrunc(a + b - 1, b);
}

/// Write `list` laid out per `colopts` into `o`.
pub fn printColumnsTo(o: *util.Out, list: []const []const u8, colopts: u32, opts: ?Options) void {
    if (opts) |op| {
        if (op.padding < 0) util.die("BUG: padding must be non-negative", .{});
    }
    if (list.len == 0) return;
    const indent: []const u8 = if (opts) |op| (op.indent orelse "") else "";
    const nl: []const u8 = if (opts) |op| (op.nl orelse "\n") else "\n";
    const padding: isize = if (opts) |op| op.padding else 1;
    const width: isize = if (opts != null and opts.?.width != 0) opts.?.width else termColumns() - 1;
    if (!columnActive(colopts)) {
        for (list) |item| {
            o.write(item);
            o.write("\n");
        }
        return;
    }
    switch (layoutOf(colopts)) {
        COL_PLAIN => {
            for (list) |item| {
                o.write(indent);
                o.write(item);
                o.write(nl);
            }
        },
        COL_ROW, COL_COLUMN => displayTable(o, list, colopts, indent, nl, padding, width),
        else => util.die("BUG: invalid layout mode {d}", .{layoutOf(colopts)}),
    }
}

/// print_columns() to stdout.
pub fn printColumns(list: []const []const u8, colopts: u32, opts: ?Options) void {
    printColumnsTo(&util.stdout, list, colopts, opts);
}

fn displayTable(o: *util.Out, list: []const []const u8, colopts: u32, indent: []const u8, nl: []const u8, padding: isize, width: isize) void {
    var d = Data{
        .n = list.len,
        .colopts = colopts,
        .len = gpa.alloc(isize, list.len) catch util.oom(),
        .indent = indent,
        .nl = nl,
        .padding = padding,
        .total = width,
    };
    for (list, 0..) |item, i| d.len[i] = @intCast(strWidth(item));

    // layout()
    var initial_width: isize = 0;
    for (d.len) |l| {
        if (initial_width < l) initial_width = l;
    }
    initial_width += padding;
    const n: isize = @intCast(list.len);
    if (initial_width <= 0) {
        d.cols = n;
    } else {
        d.cols = @divTrunc(width - @as(isize, @intCast(indent.len)), initial_width);
    }
    if (d.cols <= 0) d.cols = 1;
    d.rows = divRoundUp(n, d.cols);

    if (colopts & COL_DENSE != 0) {
        // shrink_columns()
        d.ensureWidth();
        while (d.rows > 1) {
            const rows = d.rows;
            const cols = d.cols;
            d.rows -= 1;
            d.cols = divRoundUp(n, d.rows);
            d.ensureWidth();
            d.computeColumnWidth();
            var total: isize = @intCast(indent.len);
            var x: usize = 0;
            while (x < d.cols) : (x += 1) {
                total += d.len[d.width.?[x]];
                total += padding;
            }
            if (total > width) {
                d.rows = rows;
                d.cols = cols;
                break;
            }
        }
        d.ensureWidth();
        d.computeColumnWidth();
    }

    var y: isize = 0;
    while (y < d.rows) : (y += 1) {
        var x: isize = 0;
        while (x < d.cols) : (x += 1) {
            // display_cell()
            const i = d.linear(x, y);
            if (i >= n) break;
            const iu: usize = @intCast(i);
            var len = d.len[iu];
            if (d.width) |w| {
                const cw = d.len[w[@intCast(x)]];
                if (cw < initial_width) {
                    len += initial_width - cw;
                    len -= padding;
                }
            }
            const newline = if (layoutOf(colopts) == COL_COLUMN)
                i + d.rows >= n
            else
                (x == d.cols - 1 or i == n - 1);
            if (x == 0) o.write(indent);
            o.write(list[iu]);
            if (newline) {
                o.write(nl);
            } else {
                var pad: isize = initial_width - len;
                while (pad > 0) : (pad -= 1) o.byte(' ');
            }
        }
    }
}

/// Alias of columnActive().
pub fn active(c: u32) bool {
    return columnActive(c);
}

// In-process replacement for run_column_filter()/stop_column_filter(): output
// written to util.stdout between begin() and end() is collected and laid out.
var filter_active = false;
var filter_colopts: u32 = 0;
var filter_opts: Options = .{};
var filter_start: usize = 0;

/// run_column_filter(colopts, &{ .padding = padding }); returns false if a
/// filter is already running.
pub fn begin(colopts: u32, padding: i32) bool {
    return beginOpts(colopts, .{ .padding = padding });
}

pub fn beginOpts(colopts: u32, opts: Options) bool {
    if (opts.padding < 0) util.die("BUG: padding must be non-negative", .{});
    if (filter_active) return false;
    util.stdout.flush();
    filter_active = true;
    filter_colopts = colopts;
    filter_opts = opts;
    filter_start = util.stdout.buf.items.len;
    util.stdout.capture = true;
    return true;
}

/// stop_column_filter()
pub fn end() bool {
    if (!filter_active) return false;
    filter_active = false;
    util.stdout.capture = false;
    const data = util.dupe(util.stdout.buf.items[filter_start..]);
    util.stdout.buf.shrinkRetainingCapacity(filter_start);
    var lines: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |l| {
        if (l.len == 0 and it.index == null) break;
        lines.append(gpa, l) catch util.oom();
    }
    // `git column --raw-mode=N` semantics (opts.nl stays default)
    var o = filter_opts;
    if (o.padding == 0) o.padding = 1;
    printColumns(lines.items, filter_colopts, o);
    util.stdout.flush();
    return true;
}
