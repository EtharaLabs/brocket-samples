//! Long-running filter process protocol (filter.<driver>.process), port of the
//! multi-file filter part of convert.c + sub-process.c + pkt-line.c.
//!
//! API: apply(path, src, cmd, cap) ?[]const u8
//!   cap: 1 = clean, 2 = smudge. Returns filtered content or null on failure
//!   (errors already reported as git does).
const std = @import("std");
const util = @import("util.zig");
const gpa = util.gpa;

extern "c" fn fork() c_int;
extern "c" fn pipe(fds: *[2]c_int) c_int;
extern "c" fn dup2(a: c_int, b: c_int) c_int;
extern "c" fn execvp(file: [*:0]const u8, argv: [*:null]const ?[*:0]const u8) c_int;
extern "c" fn close(fd: c_int) c_int;
extern "c" fn read(fd: c_int, buf: [*]u8, n: usize) isize;
extern "c" fn write(fd: c_int, buf: [*]const u8, n: usize) isize;
extern "c" fn waitpid(pid: c_int, status: *c_int, opts: c_int) c_int;
extern "c" fn _exit(code: c_int) noreturn;
extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn atexit(f: *const fn () callconv(.c) void) c_int;
extern "c" fn __errno_location() *c_int;

pub const CAP_CLEAN: u32 = 1;
pub const CAP_SMUDGE: u32 = 2;
pub const CAP_DELAY: u32 = 4;

const LARGE_PACKET_DATA_MAX: usize = 65520 - 4;

const Proc = struct {
    cmd: []const u8,
    pid: c_int,
    in_fd: c_int, // we write here
    out_fd: c_int, // we read here
    caps: u32,
    rbuf: [8192]u8 = undefined,
    rpos: usize = 0,
    rlen: usize = 0,
    alive: bool = true,
};

var procs: std.ArrayList(*Proc) = .empty;
var atexit_registered = false;

fn exitHandler() callconv(.c) void {
    for (procs.items) |p| stop(p);
}

fn stop(p: *Proc) void {
    if (!p.alive) return;
    p.alive = false;
    _ = close(p.in_fd);
    _ = close(p.out_fd);
    var st: c_int = 0;
    while (waitpid(p.pid, &st, 0) < 0 and __errno_location().* == 4) {}
}

fn removeProc(p: *Proc) void {
    stop(p);
    for (procs.items, 0..) |q, i| {
        if (q == p) {
            _ = procs.orderedRemove(i);
            break;
        }
    }
}

// ---------------- pkt-line ----------------

fn writeAllFd(fd: c_int, data: []const u8) bool {
    var off: usize = 0;
    while (off < data.len) {
        const n = write(fd, data[off..].ptr, data.len - off);
        if (n < 0) {
            if (__errno_location().* == 4) continue;
            return false;
        }
        if (n == 0) return false;
        off += @intCast(n);
    }
    return true;
}

fn pktWrite(p: *Proc, data: []const u8) bool {
    var hdr: [4]u8 = undefined;
    _ = std.fmt.bufPrint(&hdr, "{x:0>4}", .{data.len + 4}) catch unreachable;
    var buf: util.Buf = .empty;
    buf.appendSlice(gpa, &hdr) catch util.oom();
    buf.appendSlice(gpa, data) catch util.oom();
    return writeAllFd(p.in_fd, buf.items);
}

fn pktLine(p: *Proc, line: []const u8) bool {
    return pktWrite(p, util.concat(&.{ line, "\n" }));
}

fn pktFlush(p: *Proc) bool {
    return writeAllFd(p.in_fd, "0000");
}

fn pktContent(p: *Proc, data: []const u8) bool {
    var off: usize = 0;
    while (off < data.len) {
        const n = @min(LARGE_PACKET_DATA_MAX, data.len - off);
        if (!pktWrite(p, data[off .. off + n])) return false;
        off += n;
    }
    return true;
}

fn readExact(p: *Proc, out: []u8) bool {
    var got: usize = 0;
    while (got < out.len) {
        if (p.rpos == p.rlen) {
            const n = read(p.out_fd, &p.rbuf, p.rbuf.len);
            if (n < 0) {
                if (__errno_location().* == 4) continue;
                return false;
            }
            if (n == 0) return false;
            p.rpos = 0;
            p.rlen = @intCast(n);
        }
        const k = @min(out.len - got, p.rlen - p.rpos);
        @memcpy(out[got .. got + k], p.rbuf[p.rpos .. p.rpos + k]);
        p.rpos += k;
        got += k;
    }
    return true;
}

const Pkt = union(enum) { flush, data: []u8, eof };

fn pktRead(p: *Proc) Pkt {
    var hdr: [4]u8 = undefined;
    if (!readExact(p, &hdr)) return .eof;
    const len = std.fmt.parseInt(usize, &hdr, 16) catch return .eof;
    if (len == 0) return .flush;
    if (len < 4) return .eof;
    const d = gpa.alloc(u8, len - 4) catch util.oom();
    if (!readExact(p, d)) return .eof;
    return .{ .data = d };
}

/// Read a text line (trailing newline stripped); null on flush; error on eof.
fn pktReadLine(p: *Proc) error{Eof}!?[]const u8 {
    switch (pktRead(p)) {
        .flush => return null,
        .eof => return error.Eof,
        .data => |d| {
            var s: []const u8 = d;
            if (s.len > 0 and s[s.len - 1] == '\n') s = s[0 .. s.len - 1];
            return s;
        },
    }
}

// ---------------- process start / handshake ----------------

fn spawn(cmd: []const u8) ?*Proc {
    util.flushStdout();
    var in_pipe: [2]c_int = .{ -1, -1 };
    var out_pipe: [2]c_int = .{ -1, -1 };
    if (pipe(&in_pipe) != 0) return null;
    if (pipe(&out_pipe) != 0) return null;
    var argv_list: std.ArrayList([]const u8) = .empty;
    if (std.mem.indexOfAny(u8, cmd, "|&;<>()$`\\\"' \t\n*?[#~=%") == null) {
        argv_list.append(gpa, cmd) catch util.oom();
    } else {
        argv_list.appendSlice(gpa, &.{ "/bin/sh", "-c", cmd, cmd }) catch util.oom();
    }
    const cargv = gpa.allocSentinel(?[*:0]const u8, argv_list.items.len, null) catch util.oom();
    for (argv_list.items, 0..) |a, i| cargv[i] = @import("os.zig").z(a);
    const pid = fork();
    if (pid < 0) return null;
    if (pid == 0) {
        _ = dup2(in_pipe[0], 0);
        _ = dup2(out_pipe[1], 1);
        _ = close(in_pipe[0]);
        _ = close(in_pipe[1]);
        _ = close(out_pipe[0]);
        _ = close(out_pipe[1]);
        _ = execvp(cargv[0].?, cargv.ptr);
        util.eprint("error: cannot run {s}: No such file or directory\n", .{argv_list.items[0]});
        _exit(127);
    }
    _ = close(in_pipe[0]);
    _ = close(out_pipe[1]);
    const p = gpa.create(Proc) catch util.oom();
    p.* = .{ .cmd = cmd, .pid = pid, .in_fd = in_pipe[1], .out_fd = out_pipe[0], .caps = 0 };
    return p;
}

fn handshake(p: *Proc) bool {
    if (!pktLine(p, "git-filter-client")) return false;
    if (!pktLine(p, "version=2")) return false;
    if (!pktFlush(p)) return false;

    const welcome = (pktReadLine(p) catch {
        util.err("Could not read from subprocess '{s}'", .{p.cmd});
        return false;
    }) orelse {
        util.err("Unexpected line '', expected git-filter-server", .{});
        return false;
    };
    if (!util.eql(welcome, "git-filter-server")) {
        util.err("Unexpected line '{s}', expected git-filter-server", .{welcome});
        return false;
    }
    var version_seen = false;
    while (true) {
        const l = (pktReadLine(p) catch return false) orelse break;
        if (util.startsWith(l, "version=")) {
            if (version_seen) {
                util.err("Multiple version", .{});
                return false;
            }
            version_seen = true;
            const v = l["version=".len..];
            if (!util.eql(v, "2")) {
                util.err("Version {s} not supported", .{v});
                return false;
            }
        } else {
            util.err("Unexpected line '{s}', expected version", .{l});
            return false;
        }
    }
    if (!version_seen) {
        util.err("Unexpected line '', expected version", .{});
        return false;
    }

    if (!pktLine(p, "capability=clean")) return false;
    if (!pktLine(p, "capability=smudge")) return false;
    if (!pktFlush(p)) return false;

    while (true) {
        const l = (pktReadLine(p) catch return false) orelse break;
        if (util.startsWith(l, "capability=")) {
            const c = l["capability=".len..];
            if (util.eql(c, "clean")) {
                p.caps |= CAP_CLEAN;
            } else if (util.eql(c, "smudge")) {
                p.caps |= CAP_SMUDGE;
            } else if (util.eql(c, "delay")) {
                p.caps |= CAP_DELAY;
            } else {
                util.die("subprocess '{s}' requested unsupported capability '{s}'", .{ p.cmd, c });
            }
        } else {
            util.die("subprocess '{s}' requested unsupported capability '{s}'", .{ p.cmd, l });
        }
    }
    return true;
}

fn findOrStart(cmd: []const u8) ?*Proc {
    for (procs.items) |p| if (util.eql(p.cmd, cmd)) return p;
    // ignore SIGPIPE for the whole lifetime: the filter may die at any time
    _ = signal(13, 1);
    if (!atexit_registered) {
        atexit_registered = true;
        _ = atexit(&exitHandler);
    }
    const p = spawn(cmd) orelse {
        util.err("cannot fork to run subprocess '{s}'", .{cmd});
        return null;
    };
    if (!handshake(p)) {
        util.err("initialization for subprocess '{s}' failed", .{cmd});
        stop(p);
        return null;
    }
    procs.append(gpa, p) catch util.oom();
    return p;
}

/// Reads "status=..." lines until flush. Returns false on read error.
fn readStatus(p: *Proc, status: *[]const u8) bool {
    while (true) {
        const l = (pktReadLine(p) catch return false) orelse return true;
        if (util.startsWith(l, "status=")) status.* = l["status=".len..];
    }
}

pub fn apply(path: []const u8, src: []const u8, cmd: []const u8, cap: u32) ?[]const u8 {
    const p = findOrStart(cmd) orelse return null;
    if (p.caps & cap == 0) return null;

    var status: []const u8 = "";
    var result: ?[]const u8 = null;
    var ok = true;
    send: {
        if (!pktLine(p, if (cap == CAP_CLEAN) "command=clean" else "command=smudge")) {
            ok = false;
            break :send;
        }
        if (!pktLine(p, util.concat(&.{ "pathname=", path }))) {
            ok = false;
            break :send;
        }
        if (!pktFlush(p)) {
            ok = false;
            break :send;
        }
        if (!pktContent(p, src) or !pktFlush(p)) {
            ok = false;
            break :send;
        }
        if (!readStatus(p, &status)) {
            ok = false;
            break :send;
        }
        if (!util.eql(status, "success")) break :send;
        var out: util.Buf = .empty;
        while (true) {
            switch (pktRead(p)) {
                .flush => break,
                .eof => {
                    ok = false;
                    break :send;
                },
                .data => |d| out.appendSlice(gpa, d) catch util.oom(),
            }
        }
        if (!readStatus(p, &status)) {
            ok = false;
            break :send;
        }
        if (util.eql(status, "success")) result = out.items;
    }
    if (!ok) status = "";
    if (result == null) {
        if (util.eql(status, "error")) {
            // filter reported error for this file only
        } else if (util.eql(status, "abort")) {
            p.caps &= ~cap;
        } else {
            util.err("external filter '{s}' failed", .{cmd});
            removeProc(p);
        }
    }
    return result;
}
