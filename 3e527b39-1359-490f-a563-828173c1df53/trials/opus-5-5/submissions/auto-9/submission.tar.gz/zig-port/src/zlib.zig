//! zlib bindings (declared, not translated).

const std = @import("std");
const util = @import("util.zig");
const gpa = util.gpa;

pub const ZStream = extern struct {
    next_in: ?[*]const u8 = null,
    avail_in: c_uint = 0,
    total_in: c_ulong = 0,
    next_out: ?[*]u8 = null,
    avail_out: c_uint = 0,
    total_out: c_ulong = 0,
    msg: ?[*:0]const u8 = null,
    state: ?*anyopaque = null,
    zalloc: ?*anyopaque = null,
    zfree: ?*anyopaque = null,
    opaque_: ?*anyopaque = null,
    data_type: c_int = 0,
    adler: c_ulong = 0,
    reserved: c_ulong = 0,
};

pub extern fn zlibVersion() [*:0]const u8;
pub extern fn inflateInit_(strm: *ZStream, version: [*:0]const u8, size: c_int) c_int;
pub extern fn inflate(strm: *ZStream, flush: c_int) c_int;
pub extern fn inflateEnd(strm: *ZStream) c_int;
pub extern fn deflateInit_(strm: *ZStream, level: c_int, version: [*:0]const u8, size: c_int) c_int;
pub extern fn deflate(strm: *ZStream, flush: c_int) c_int;
pub extern fn deflateEnd(strm: *ZStream) c_int;
pub extern fn deflateBound(strm: *ZStream, len: c_ulong) c_ulong;
extern fn crc32(crc: c_ulong, buf: [*]const u8, len: c_uint) c_ulong;
extern fn adler32(a: c_ulong, buf: [*]const u8, len: c_uint) c_ulong;

pub const Z_OK = 0;
pub const Z_STREAM_END = 1;
pub const Z_BUF_ERROR = -5;
pub const Z_FINISH = 4;
pub const Z_NO_FLUSH = 0;
pub const Z_SYNC_FLUSH = 2;

pub fn crc(prev: u32, data: []const u8) u32 {
    return @intCast(crc32(prev, data.ptr, @intCast(data.len)));
}

pub fn compress(data: []const u8, level: c_int) []u8 {
    var s = ZStream{};
    if (deflateInit_(&s, level, zlibVersion(), @sizeOf(ZStream)) != Z_OK) util.die("deflateInit failed", .{});
    const bound = deflateBound(&s, data.len);
    const outbuf = gpa.alloc(u8, bound + 64) catch util.oom();
    s.next_in = data.ptr;
    s.avail_in = @intCast(data.len);
    s.next_out = outbuf.ptr;
    s.avail_out = @intCast(outbuf.len);
    const r = deflate(&s, Z_FINISH);
    if (r != Z_STREAM_END) util.die("unable to deflate ({d})", .{r});
    const n = s.total_out;
    _ = deflateEnd(&s);
    return outbuf[0..n];
}

pub const InflateResult = struct {
    data: []u8,
    consumed: usize,
};

/// Inflate a zlib stream starting at `input`. If `expected` is given, it's the output size.
pub fn decompress(input: []const u8, expected: ?usize) ?InflateResult {
    var s = ZStream{};
    if (inflateInit_(&s, zlibVersion(), @sizeOf(ZStream)) != Z_OK) return null;
    defer _ = inflateEnd(&s);
    var cap: usize = if (expected) |e| e + 1 else @max(input.len * 3, 256);
    var outbuf = gpa.alloc(u8, cap) catch util.oom();
    s.next_in = input.ptr;
    s.avail_in = @intCast(@min(input.len, std.math.maxInt(c_uint)));
    while (true) {
        s.next_out = outbuf.ptr + s.total_out;
        s.avail_out = @intCast(cap - s.total_out);
        const r = inflate(&s, Z_NO_FLUSH);
        if (r == Z_STREAM_END) break;
        if (r != Z_OK and r != Z_BUF_ERROR) return null;
        if (s.avail_out == 0) {
            cap *= 2;
            outbuf = gpa.realloc(outbuf, cap) catch util.oom();
            continue;
        }
        if (s.avail_in == 0) return null; // truncated
        if (r == Z_BUF_ERROR) return null;
    }
    return .{ .data = outbuf[0..s.total_out], .consumed = s.total_in };
}

/// Streaming deflater used for pack writing.
pub const Deflater = struct {
    s: ZStream = .{},
    pub fn init(level: c_int) Deflater {
        var d = Deflater{};
        _ = deflateInit_(&d.s, level, zlibVersion(), @sizeOf(ZStream));
        return d;
    }
};
