//! Creating commit objects (commit_tree_extended).

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const ident = @import("ident.zig");
const Oid = hash.Oid;

pub const CreateOpts = struct {
    tree: Oid,
    parents: []const Oid = &.{},
    message: []const u8,
    /// full ident lines; default from environment/config
    author: ?[]const u8 = null,
    committer: ?[]const u8 = null,
    /// extra headers (e.g. "mergetag ...") already formatted, each ending in '\n'
    extra_headers: []const u8 = "",
};

fn isUtf8(s: []const u8) bool {
    return std.unicode.utf8ValidateSlice(s);
}

pub fn commitEncoding() ?[]const u8 {
    const enc = repo_mod.cfg.get("i18n.commitencoding") orelse return null;
    if (std.ascii.eqlIgnoreCase(enc, "utf-8") or std.ascii.eqlIgnoreCase(enc, "utf8")) return null;
    return enc;
}

pub fn create(o: CreateOpts) Oid {
    var b: util.Buf = .empty;
    util.bufPrint(&b, "tree {s}\n", .{hash.hex(o.tree)});
    for (o.parents) |p| util.bufPrint(&b, "parent {s}\n", .{hash.hex(p)});
    const author = o.author orelse ident.authorStrict();
    const committer = o.committer orelse ident.committerStrict();
    util.bufPrint(&b, "author {s}\ncommitter {s}\n", .{ author, committer });
    const enc = commitEncoding();
    if (enc) |e| util.bufPrint(&b, "encoding {s}\n", .{e});
    util.bufAppend(&b, o.extra_headers);
    util.bufByte(&b, '\n');
    util.bufAppend(&b, o.message);
    if (enc == null and !isUtf8(o.message)) {
        util.eprint("Warning: commit message did not conform to UTF-8.\nYou may want to amend it after fixing the message, or set the config\nvariable i18n.commitEncoding to the encoding your project uses.\n", .{});
    }
    return repo_mod.repo().odb().write(.commit, b.items);
}
