//! git status (port of cmd_status from builtin/commit.c, git v2.56.1)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const wt = @import("../wtstatus.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const lockfile = @import("../lockfile.zig");
const revparse = @import("../revparse.zig");

const usage = [_][]const u8{"git status [<options>] [--] [<pathspec>...]"};

var verbose: i32 = 0;
var status_format: wt.Format = .unspecified;
var show_branch: i32 = -1;
var show_stash: i32 = -1;
var ahead_behind: i32 = -1;
var null_termination: bool = false;
var untracked_files_arg: ?[]const u8 = null;
var ignored_arg: ?[]const u8 = null;
var ignore_submodule_arg: ?[]const u8 = null;
var no_renames: i32 = -1;
var rename_score_set = false;
var rename_score_arg: ?[]const u8 = null;
var colopts: *u32 = undefined;
var short_fmt: i32 = 0;
var long_fmt: i32 = 0;

fn setShort(_: ?[]const u8, unset: bool) void {
    status_format = if (unset) .unspecified else .short;
}

fn setLong(_: ?[]const u8, unset: bool) void {
    status_format = if (unset) .unspecified else .long;
}

fn parsePorcelain(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        status_format = .none;
    } else if (arg == null) {
        status_format = .porcelain;
    } else if (util.eql(arg.?, "v1") or util.eql(arg.?, "1")) {
        status_format = .porcelain;
    } else if (util.eql(arg.?, "v2") or util.eql(arg.?, "2")) {
        status_format = .porcelain_v2;
    } else util.die("unsupported porcelain version '{s}'", .{arg.?});
}

fn parseColumn(arg: ?[]const u8, unset: bool) void {
    const COL_ENABLE_MASK: u32 = 0x0030;
    const COL_ENABLED: u32 = 0x0010;
    const COL_PARSEOPT: u32 = 0x0040;
    colopts.* |= COL_PARSEOPT;
    colopts.* &= ~COL_ENABLE_MASK;
    if (unset) return;
    colopts.* |= COL_ENABLED;
    if (arg) |a| {
        if (!wt.parseColumnOption(a, colopts)) os.exit(129);
    }
}

fn parseRenameScoreOpt(arg: ?[]const u8, _: bool) void {
    rename_score_set = true;
    var a = arg;
    if (a) |v| {
        if (v.len > 0 and v[0] == '=') a = v[1..];
    }
    rename_score_arg = a;
}

fn noRenames(_: ?[]const u8, unset: bool) void {
    no_renames = if (unset) 0 else 1;
}

const options = [_]po.Opt{
    .{ .short = 'v', .long = "verbose", .kind = .counter, .i = &verbose, .help = "be verbose" },
    .{ .short = 's', .long = "short", .kind = .callback, .cb = setShort, .noarg = true, .help = "show status concisely" },
    po.setInt('b', "branch", &show_branch, 1, "show branch information"),
    po.setInt(0, "show-stash", &show_stash, 1, "show stash information"),
    po.setInt(0, "ahead-behind", &ahead_behind, 1, "compute full ahead/behind values"),
    .{ .long = "porcelain", .kind = .callback, .cb = parsePorcelain, .optarg = true, .argh = "version", .help = "machine-readable output" },
    .{ .long = "long", .kind = .callback, .cb = setLong, .noarg = true, .help = "show status in long format (default)" },
    po.boolean('z', "null", &null_termination, "terminate entries with NUL"),
    po.optString('u', "untracked-files", &untracked_files_arg, "all", "mode", "show untracked files, optional modes: all, normal, no. (Default: all)"),
    po.optString(0, "ignored", &ignored_arg, "traditional", "mode", "show ignored files, optional modes: traditional, matching, no. (Default: traditional)"),
    po.optString(0, "ignore-submodules", &ignore_submodule_arg, "all", "when", "ignore changes to submodules, optional when: all, dirty, untracked. (Default: all)"),
    .{ .long = "column", .kind = .callback, .cb = parseColumn, .optarg = true, .argh = "style", .help = "list untracked files in columns" },
    .{ .long = "no-renames", .kind = .callback, .cb = noRenames, .noarg = true, .help = "do not detect renames" },
    .{ .short = 'M', .long = "find-renames", .kind = .callback, .cb = parseRenameScoreOpt, .optarg = true, .noneg = true, .argh = "n", .help = "detect renames, optionally set similarity index" },
};

pub fn cmdStatus(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    var s = wt.prepare();
    colopts = &s.colopts;
    wt.initConfig(&s);
    const rest = po.parse(args[1..], &options, &usage, .{});

    if (show_branch >= 0) s.show_branch = show_branch;
    if (show_stash >= 0) s.show_stash = show_stash != 0;
    if (ahead_behind >= 0) s.ahead_behind_flags = if (ahead_behind != 0) .full else .quick;
    s.null_termination = null_termination;

    wt.finalizeColopts(&s.colopts, -1);
    wt.finalizeDeferredConfig(&s, status_format);

    // handle_untracked_files_arg()
    if (untracked_files_arg) |u| {
        const m = wt.parseUntrackedSetting(u);
        if (m == .err) util.die("Invalid untracked files mode '{s}'", .{u});
        s.show_untracked_files = m;
    }
    // handle_ignored_arg()
    if (ignored_arg) |ia| {
        if (util.eql(ia, "traditional")) {
            s.show_ignored_mode = .traditional;
        } else if (util.eql(ia, "no")) {
            s.show_ignored_mode = .no;
        } else if (util.eql(ia, "matching")) {
            s.show_ignored_mode = .matching;
        } else util.die("Invalid ignored mode '{s}'", .{ia});
    }
    if (s.show_ignored_mode == .matching and s.show_untracked_files == .no)
        util.die("Unsupported combination of ignored and untracked-files arguments", .{});

    s.pathspec = pathspec_mod.parse(r.prefix, rest, .{});

    const idx = index_mod.get();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET | index_mod.REFRESH_UNMERGED, @as(?*const pathspec_mod.Pathspec, &s.pathspec), null);

    var lock: ?*lockfile.Lock = null;
    const optional_locks = if (os.getenv("GIT_OPTIONAL_LOCKS")) |v| !util.eql(v, "0") else true;
    if (optional_locks) {
        switch (lockfile.tryLock(r.indexPath())) {
            .ok => |l| lock = l,
            .err => {},
        }
    }

    if (revparse.getOid(s.reference)) |o| {
        s.is_initial = false;
        s.oid_commit = o;
    } else s.is_initial = true;

    s.ignore_submodule_arg = ignore_submodule_arg;
    s.verbose = verbose;
    if (no_renames != -1) s.detect_rename = if (no_renames != 0) 0 else 1;
    if (rename_score_set) {
        if (s.detect_rename < wt.DETECT_RENAME) s.detect_rename = wt.DETECT_RENAME;
        if (rename_score_arg) |a| {
            var restp: []const u8 = "";
            s.rename_score = parseRenameScore(a, &restp);
        }
    }
    s.idx = idx;

    wt.collect(&s);

    if (lock) |l| {
        idx.lock = l;
        if (idx.changed) idx.write() else idx.rollback();
    }

    if (s.relative_paths) s.prefix = r.prefix;

    wt.print(&s);
    util.stdout.flush();
    return 0;
}

/// parse_rename_score() (diff.c)
fn parseRenameScore(s: []const u8, rest_out: *[]const u8) i32 {
    var num: u64 = 0;
    var scale: u64 = 1;
    var dot = false;
    var j: usize = 0;
    while (j < s.len) {
        const ch = s[j];
        if (!dot and ch == '.') {
            scale = 1;
            dot = true;
        } else if (ch == '%') {
            scale = if (dot) scale * 100 else 100;
            j += 1;
            break;
        } else if (std.ascii.isDigit(ch)) {
            if (scale < 100000) {
                scale *= 10;
                num = num * 10 + (ch - '0');
            }
        } else break;
        j += 1;
    }
    rest_out.* = s[j..];
    const max: u64 = @intCast(wt.MAX_SCORE);
    if (num >= scale) return wt.MAX_SCORE;
    return @intCast(max * num / scale);
}
