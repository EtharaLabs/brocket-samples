//! Port of branch.c: create_branch(), setup_tracking(), install_branch_config(),
//! validate_branchname(), validate_new_branchname(), dwim_and_setup_tracking(),
//! branch_checked_out(), plus remote_find_tracking() and repo_get_oid_mb().

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const refs = @import("refs.zig");
const revparse = @import("revparse.zig");
const advice = @import("advice.zig");
const hash = @import("hash.zig");
const cn = @import("commitnode.zig");
const commitreach = @import("commitreach.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

pub const Track = enum(i32) {
    unspecified = -1,
    never = 0,
    remote,
    always,
    explicit,
    override,
    inherit,
    simple,
};

/// branch.autoSetupMerge (git_branch_track); default .remote.
pub fn configBranchTrack() Track {
    const v = repo_mod.cfg.getEntry("branch.autosetupmerge") orelse return .remote;
    const val = v.value orelse return .remote;
    if (util.eql(val, "always")) return .always;
    if (util.eql(val, "inherit")) return .inherit;
    if (util.eql(val, "simple")) return .simple;
    if (config.parseBool(val)) |b| return if (b) .remote else .never;
    return .remote;
}

const AutoRebase = enum { never, local, remote, always };
fn autoRebase() AutoRebase {
    const v = repo_mod.cfg.get("branch.autosetuprebase") orelse return .never;
    if (util.eql(v, "never")) return .never;
    if (util.eql(v, "local")) return .local;
    if (util.eql(v, "remote")) return .remote;
    if (util.eql(v, "always")) return .always;
    util.err("malformed value for branch.autosetuprebase", .{});
    return .never;
}

// ---------------- remotes ----------------

/// Names of configured remotes, in config order.
pub fn remoteNames() [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    for (repo_mod.cfg.entries.items) |e| {
        const rest = util.skipPrefix(e.key, "remote.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse continue;
        const name = rest[0..dot];
        if (name.len == 0) continue;
        var dup = false;
        for (l.items) |n| {
            if (util.eql(n, name)) dup = true;
        }
        if (!dup) l.append(gpa, name) catch util.oom();
    }
    return l.items;
}

fn matchPattern(key: []const u8, name: []const u8, value: []const u8) ?[]const u8 {
    const kstar = std.mem.indexOfScalar(u8, key, '*') orelse return null;
    const kpre = key[0..kstar];
    const ksuf = key[kstar + 1 ..];
    if (!util.startsWith(name, kpre) or name.len < kpre.len + ksuf.len or !util.endsWith(name, ksuf)) return null;
    const vstar = std.mem.indexOfScalar(u8, value, '*') orelse return null;
    return util.concat(&.{ value[0..vstar], name[kpre.len .. name.len - ksuf.len], value[vstar + 1 ..] });
}

const Spec = struct { negative: bool, pattern: bool, src: []const u8, dst: ?[]const u8 };

fn fetchSpecs(remote: []const u8) []Spec {
    var l: std.ArrayList(Spec) = .empty;
    for (repo_mod.cfg.getAll(util.concat(&.{ "remote.", remote, ".fetch" }))) |v0| {
        var v = v0;
        var neg = false;
        if (v.len > 0 and v[0] == '+') v = v[1..] else if (v.len > 0 and v[0] == '^') {
            neg = true;
            v = v[1..];
        }
        var s = Spec{ .negative = neg, .pattern = false, .src = v, .dst = null };
        if (std.mem.lastIndexOfScalar(u8, v, ':')) |c| {
            s.src = v[0..c];
            s.dst = v[c + 1 ..];
        }
        s.pattern = std.mem.indexOfScalar(u8, s.src, '*') != null;
        l.append(gpa, s) catch util.oom();
    }
    return l.items;
}

/// remote_find_tracking() with only dst set: returns the matching src.
pub fn remoteFindTrackingSrc(remote: []const u8, dst: []const u8) ?[]const u8 {
    const specs = fetchSpecs(remote);
    for (specs) |s| {
        if (s.negative) continue;
        const d = s.dst orelse continue;
        var src: ?[]const u8 = null;
        if (s.pattern) {
            src = matchPattern(d, dst, s.src);
        } else if (util.eql(d, dst)) src = s.src;
        if (src) |found| {
            // omitted by a negative refspec?
            for (specs) |n| {
                if (!n.negative) continue;
                if (n.pattern) {
                    if (matchPattern(n.src, found, n.src) != null) return null;
                } else if (util.eql(n.src, found)) return null;
            }
            return found;
        }
    }
    return null;
}

// ---------------- config ----------------

fn configPath() []const u8 {
    return repo_mod.repo().commonPath("config");
}

fn shouldSetupRebase(origin: ?[]const u8) bool {
    return switch (autoRebase()) {
        .never => false,
        .local => origin == null,
        .remote => origin != null,
        .always => true,
    };
}

/// install_branch_config_multiple_remotes(); returns false on error.
pub fn installBranchConfigMultiple(verbose: bool, local: []const u8, origin: ?[]const u8, remotes: []const []const u8) bool {
    const rebasing = shouldSetupRebase(origin);
    if (rebasing and remotes.len > 1)
        util.die("cannot inherit upstream tracking configuration of multiple refs when rebasing is requested", .{});
    if (origin == null) {
        for (remotes) |r| {
            if (util.skipPrefix(r, "refs/heads/")) |short| {
                if (util.eql(local, short)) {
                    util.warn("not setting branch '{s}' as its own upstream", .{local});
                    return true;
                }
            }
        }
    }
    const path = configPath();
    var ok = true;
    blk: {
        if (config.setInFileGently(path, util.fmt("branch.{s}.remote", .{local}), null, origin orelse ".") < 0) {
            ok = false;
            break :blk;
        }
        const mkey = util.fmt("branch.{s}.merge", .{local});
        if (config.setInFileGently(path, mkey, null, null) < 0) {
            ok = false;
            break :blk;
        }
        for (remotes) |r| {
            if (config.setMultivarInFile(path, mkey, r, .none, null, .{}) < 0) {
                ok = false;
                break :blk;
            }
        }
        if (rebasing) {
            if (config.setInFileGently(path, util.fmt("branch.{s}.rebase", .{local}), null, "true") < 0) {
                ok = false;
                break :blk;
            }
        }
    }
    repo_mod.loadConfig();
    if (!ok) {
        util.err("unable to write upstream branch configuration", .{});
        advice.advise("\nAfter fixing the error cause you may try to fix up\nthe remote tracking information by invoking:");
        if (remotes.len == 1) {
            advice.advise(util.fmt("  git branch --set-upstream-to={s}{s}{s}", .{ origin orelse "", if (origin != null) "/" else "", remotes[0] }));
        } else {
            advice.advise(util.fmt("  git config --add branch.\"{s}\".remote {s}", .{ local, origin orelse "." }));
            for (remotes) |r| advice.advise(util.fmt("  git config --add branch.\"{s}\".merge {s}", .{ local, r }));
        }
        return false;
    }
    if (verbose) {
        var names: std.ArrayList([]const u8) = .empty;
        for (remotes) |r| {
            const short = util.skipPrefix(r, "refs/heads/") orelse r;
            names.append(gpa, if (origin) |o| util.fmt("{s}/{s}", .{ o, short }) else short) catch util.oom();
        }
        if (remotes.len == 1) {
            if (rebasing) {
                util.outf("branch '{s}' set up to track '{s}' by rebasing.\n", .{ local, names.items[0] });
            } else util.outf("branch '{s}' set up to track '{s}'.\n", .{ local, names.items[0] });
        } else {
            util.outf("branch '{s}' set up to track:\n", .{local});
            for (names.items) |n| util.outf("  {s}\n", .{n});
        }
    }
    return true;
}

/// install_branch_config()
pub fn installBranchConfig(verbose: bool, local: []const u8, origin: ?[]const u8, remote: []const u8) bool {
    return installBranchConfigMultiple(verbose, local, origin, &.{remote});
}

/// setup_tracking(): new_ref is the short branch name, orig_ref a full ref.
pub fn setupTracking(new_ref: []const u8, orig_ref: []const u8, track: Track, quiet: bool) void {
    var srcs: std.ArrayList([]const u8) = .empty;
    var remote: ?[]const u8 = null;
    var matches: usize = 0;
    var ambiguous: std.ArrayList([]const u8) = .empty;
    if (track != .inherit) {
        for (remoteNames()) |rn| {
            if (remoteFindTrackingSrc(rn, orig_ref)) |src| {
                matches += 1;
                switch (matches) {
                    1 => {
                        srcs.append(gpa, src) catch util.oom();
                        remote = rn;
                    },
                    else => {
                        if (matches == 2) ambiguous.append(gpa, remote.?) catch util.oom();
                        ambiguous.append(gpa, rn) catch util.oom();
                        srcs.clearRetainingCapacity();
                    },
                }
            }
        }
    } else {
        const bare = util.skipPrefix(orig_ref, "refs/heads/") orelse orig_ref;
        const rem = repo_mod.cfg.get(util.fmt("branch.{s}.remote", .{bare}));
        if (rem == null) {
            util.warn("asked to inherit tracking from '{s}', but no remote is set", .{bare});
            return;
        }
        const merges = repo_mod.cfg.getAll(util.fmt("branch.{s}.merge", .{bare}));
        if (merges.len < 1) {
            util.warn("asked to inherit tracking from '{s}', but no merge configuration is set", .{bare});
            return;
        }
        remote = rem;
        for (merges) |m| srcs.append(gpa, m) catch util.oom();
    }
    if (matches == 0) {
        switch (track) {
            .always, .explicit, .override, .inherit => {},
            else => return,
        }
    }
    if (matches > 1) {
        util.flushStdout();
        util.eprint("fatal: not tracking: ambiguous information for ref '{s}'\n", .{orig_ref});
        if (advice.enabled("ambiguousFetchRefspec")) {
            var b: util.Buf = .empty;
            for (ambiguous.items) |a| util.bufPrint(&b, "  {s}\n", .{a});
            advice.advise(util.fmt("There are multiple remotes whose fetch refspecs map to the remote\ntracking ref '{s}':\n{s}\nThis is typically a configuration error.\n\nTo support setting up tracking branches, ensure that\ndifferent remotes' fetch refspecs map into different\ntracking namespaces.", .{ orig_ref, b.items }));
        }
        os.exit(128);
    }
    if (track == .simple) {
        const tb = util.skipPrefix(srcs.items[0], "refs/heads/") orelse return;
        if (!util.eql(tb, new_ref)) return;
    }
    if (srcs.items.len < 1) srcs.append(gpa, orig_ref) catch util.oom();
    if (!installBranchConfigMultiple(!quiet, new_ref, remote, srcs.items)) os.exit(1);
}

// ---------------- validation ----------------

/// check_branch_ref(): full refname for a branch name, null if invalid.
pub fn checkBranchRef(name: []const u8) ?[]const u8 {
    var expanded = name;
    if (repo_mod.repo_ != null) expanded = revparse.interpretBranchName(name);
    const full = util.concat(&.{ "refs/heads/", expanded });
    if ((name.len > 0 and name[0] == '-') or util.eql(full, "refs/heads/HEAD")) return null;
    if (!refs.checkRefnameFormat(full, 0)) return null;
    return full;
}

/// validate_branchname(): die if invalid; returns whether it exists. ref receives the full name.
pub fn validateBranchname(name: []const u8, ref: *[]const u8) bool {
    ref.* = checkBranchRef(name) orelse {
        util.flushStdout();
        util.eprint("fatal: '{s}' is not a valid branch name\n", .{name});
        advice.adviseIfEnabled("refSyntax", "See 'git help check-ref-format'");
        os.exit(128);
    };
    return refs.exists(ref.*);
}

/// validate_new_branchname()
pub fn validateNewBranchname(name: []const u8, ref: *[]const u8, force: bool) bool {
    if (!validateBranchname(name, ref)) return false;
    if (!force) util.die("a branch named '{s}' already exists", .{ref.*["refs/heads/".len..]});
    if (branchCheckedOut(ref.*)) |path|
        util.die("cannot force update the branch '{s}' used by worktree at '{s}'", .{ ref.*["refs/heads/".len..], path });
    return true;
}

// ---------------- worktrees ----------------

const CheckedOut = struct { refname: []const u8, path: []const u8, gitdir: []const u8 = "" };
var checked_out: ?[]CheckedOut = null;

fn headRefOf(gitdir: []const u8) ?[]const u8 {
    const data = os.readFile(util.concat(&.{ gitdir, "/HEAD" })) orelse return null;
    const t = util.trim(data);
    return util.skipPrefix(t, "ref: ");
}

fn addWorktreeState(l: *std.ArrayList(CheckedOut), gitdir: []const u8, path: []const u8) void {
    if (headRefOf(gitdir)) |h| l.append(gpa, .{ .refname = util.dupe(h), .path = path, .gitdir = gitdir }) catch util.oom();
    for ([_][]const u8{ "/rebase-merge/head-name", "/rebase-apply/head-name" }) |f| {
        if (os.readFile(util.concat(&.{ gitdir, f }))) |d| {
            const t = util.trim(d);
            const name = util.skipPrefix(t, "refs/heads/") orelse t;
            if (!util.eql(name, "detached HEAD"))
                l.append(gpa, .{ .refname = util.concat(&.{ "refs/heads/", name }), .path = path, .gitdir = gitdir }) catch util.oom();
        }
    }
    if (os.readFile(util.concat(&.{ gitdir, "/BISECT_START" }))) |d| {
        const t = util.trim(d);
        if (t.len > 0 and refs.checkRefnameFormat(util.concat(&.{ "refs/heads/", t }), 0))
            l.append(gpa, .{ .refname = util.concat(&.{ "refs/heads/", t }), .path = path, .gitdir = gitdir }) catch util.oom();
    }
}

fn prepareCheckedOut() []CheckedOut {
    if (checked_out) |c| return c;
    var l: std.ArrayList(CheckedOut) = .empty;
    const r = repo_mod.repo();
    const common = r.common_dir;
    // main worktree
    const main_bare = repo_mod.cfg.getBool("core.bare") orelse false;
    if (!main_bare) {
        const main_path = if (util.endsWith(common, "/.git")) common[0 .. common.len - 5] else (r.work_tree orelse common);
        addWorktreeState(&l, common, main_path);
    }
    const wtdir = util.concat(&.{ common, "/worktrees" });
    if (os.listDir(wtdir)) |ents| {
        for (ents) |de| {
            const gd = util.concat(&.{ wtdir, "/", de.name });
            const gf = os.readFile(util.concat(&.{ gd, "/gitdir" })) orelse continue;
            const p = util.dirname(util.trim(gf));
            addWorktreeState(&l, gd, p);
        }
    }
    checked_out = l.items;
    return l.items;
}

/// branch_checked_out(): path of a worktree that has refname checked out.
pub fn branchCheckedOut(refname: []const u8) ?[]const u8 {
    for (prepareCheckedOut()) |c| {
        if (util.eql(c.refname, refname)) return c.path;
    }
    return null;
}

// ---------------- start point ----------------

/// repo_get_oid_mb(): like get_oid but supports "A...B" (unique merge base).
pub fn getOidMb(name: []const u8) ?Oid {
    const dots = std.mem.indexOf(u8, name, "...") orelse return revparse.getOid(name);
    const left = if (dots == 0) "HEAD" else name[0..dots];
    const right_s = name[dots + 3 ..];
    const right = if (right_s.len == 0) "HEAD" else right_s;
    const o1 = revparse.getOid(left) orelse return null;
    const o2 = revparse.getOid(right) orelse return null;
    const c1 = cn.lookupCommitReference(o1) orelse return null;
    const c2 = cn.lookupCommitReference(o2) orelse return null;
    const mbs = commitreach.getMergeBases(c1, c2) orelse return null;
    if (mbs.next != null) return null;
    return mbs.item.oid();
}

const upstream_advice =
    "\nIf you are planning on basing your work on an upstream\n" ++
    "branch that already exists at the remote, you may need to\n" ++
    "run \"git fetch\" to retrieve it.\n" ++
    "\n" ++
    "If you are planning to push out a new local branch that\n" ++
    "will track its remote counterpart, you may want to use\n" ++
    "\"git push -u\" to set the upstream config as you push.";

fn validateRemoteTrackingBranch(ref: []const u8) bool {
    // returns true when NO remote tracks `ref` (C returns !for_each_remote(...))
    for (remoteNames()) |rn| {
        if (remoteFindTrackingSrc(rn, ref) != null) return false;
    }
    return true;
}

pub const Start = struct { real_ref: ?[]const u8, oid: Oid };

/// dwim_branch_start()
pub fn dwimBranchStart(start_name: []const u8, track: Track) Start {
    const explicit = track == .explicit or track == .override;
    const oid0 = getOidMb(start_name) orelse {
        if (explicit) {
            util.flushStdout();
            util.eprint("fatal: the requested upstream branch '{s}' does not exist\n", .{start_name});
            advice.adviseIfEnabled("setUpstreamFailure", upstream_advice);
            os.exit(128);
        }
        util.die("not a valid object name: '{s}'", .{start_name});
    };
    var oid = oid0;
    var real_ref: ?[]const u8 = null;
    if (refs.dwimRef(start_name)) |d| {
        if (d.count > 1) util.die("ambiguous object name: '{s}'", .{start_name});
        real_ref = d.name;
        oid = d.oid;
        if (!util.startsWith(d.name, "refs/heads/") and validateRemoteTrackingBranch(d.name)) {
            if (explicit) util.die("cannot set up tracking information; starting point '{s}' is not a branch", .{start_name});
            real_ref = null;
        }
    } else {
        if (explicit) util.die("cannot set up tracking information; starting point '{s}' is not a branch", .{start_name});
    }
    const c = cn.lookupCommitReference(oid) orelse util.die("not a valid branch point: '{s}'", .{start_name});
    return .{ .real_ref = real_ref, .oid = c.oid() };
}

/// create_branch()
pub fn createBranch(name: []const u8, start_name: []const u8, force: bool, clobber_head_ok: bool, reflog: bool, quiet: bool, track: Track, dry_run: bool) void {
    var ref: []const u8 = "";
    const forcing = if (clobber_head_ok) validateBranchname(name, &ref) else validateNewBranchname(name, &ref, force);
    const st = dwimBranchStart(start_name, track);
    if (dry_run) return;
    var flags: u32 = 0;
    if (reflog) flags |= refs.F_FORCE_CREATE_REFLOG;
    const msg = if (forcing) util.fmt("branch: Reset to {s}", .{start_name}) else util.fmt("branch: Created from {s}", .{start_name});
    refs.updateFlags(ref, st.oid, if (forcing) null else hash.zero, msg, flags) catch {
        util.die("{s}", .{refs.last_error});
    };
    if (st.real_ref != null and track != .never)
        setupTracking(ref["refs/heads/".len..], st.real_ref.?, track, quiet);
}

/// dwim_and_setup_tracking()
pub fn dwimAndSetupTracking(new_ref: []const u8, orig_ref: []const u8, track: Track, quiet: bool) void {
    const st = dwimBranchStart(orig_ref, track);
    setupTracking(new_ref, st.real_ref orelse orig_ref, track, quiet);
}

/// remote_find_tracking() with only src set: returns the matching dst.
pub fn remoteFindTrackingDst(remote: []const u8, src: []const u8) ?[]const u8 {
    const specs = fetchSpecs(remote);
    for (specs) |n| {
        if (!n.negative) continue;
        if (n.pattern) {
            if (matchPattern(n.src, src, n.src) != null) return null;
        } else if (util.eql(n.src, src)) return null;
    }
    for (specs) |s| {
        if (s.negative) continue;
        const d = s.dst orelse continue;
        if (s.pattern) {
            if (matchPattern(s.src, src, d)) |r| return r;
        } else if (util.eql(s.src, src)) return d;
    }
    return null;
}

pub const TrackingName = struct {
    dst: ?[]const u8,
    oid: Oid,
    num_matches: usize,
    remotes: [][]const u8,
};

/// unique_tracking_name() (checkout.c)
pub fn uniqueTrackingName(name: []const u8) TrackingName {
    const default_remote = repo_mod.cfg.get("checkout.defaultremote");
    const src = util.concat(&.{ "refs/heads/", name });
    var res = TrackingName{ .dst = null, .oid = hash.zero, .num_matches = 0, .remotes = &.{} };
    var names: std.ArrayList([]const u8) = .empty;
    var default_dst: ?[]const u8 = null;
    var default_oid: Oid = hash.zero;
    var first: ?[]const u8 = null;
    for (remoteNames()) |rn| {
        const dst = remoteFindTrackingDst(rn, src) orelse continue;
        const oid = revparse.getOid(dst) orelse continue;
        res.oid = oid;
        res.num_matches += 1;
        if (default_remote) |d| {
            if (util.eql(d, rn)) {
                default_dst = dst;
                default_oid = oid;
            }
        }
        names.append(gpa, rn) catch util.oom();
        if (first == null) first = dst;
    }
    res.remotes = names.items;
    if (res.num_matches == 1) {
        res.dst = first;
        return res;
    }
    if (default_dst) |d| {
        res.dst = d;
        res.oid = default_oid;
    }
    return res;
}

/// die_if_checked_out(refname, ignore_current_worktree=1): path of another
/// worktree that has `refname` checked out (or is rebasing/bisecting it).
pub fn branchCheckedOutElsewhere(refname: []const u8) ?[]const u8 {
    const r = repo_mod.repo();
    const cur = os.realPath(r.git_dir) orelse r.git_dir;
    for (prepareCheckedOut()) |c| {
        if (util.eql(os.realPath(c.gitdir) orelse c.gitdir, cur)) continue;
        if (util.eql(c.refname, refname)) return c.path;
    }
    return null;
}
