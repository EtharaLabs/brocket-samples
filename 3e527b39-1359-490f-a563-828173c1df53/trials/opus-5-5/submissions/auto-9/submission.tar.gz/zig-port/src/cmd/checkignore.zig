//! git check-ignore, git check-attr

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const dir_mod = @import("../dir.zig");
const attr = @import("../attr.zig");
const revparse = @import("../revparse.zig");
const gpa = util.gpa;

extern "c" fn read(fd: c_int, buf: [*]u8, n: usize) isize;

/// Line reader on stdin that does not block for more data than needed
/// (so that --stdin works interactively through pipes).
const LineReader = struct {
    buf: [4096]u8 = undefined,
    pos: usize = 0,
    len: usize = 0,
    eof: bool = false,

    fn next(self: *LineReader, term: u8) ?[]const u8 {
        var line: util.Buf = .empty;
        var got_any = false;
        while (true) {
            if (self.pos == self.len) {
                if (self.eof) break;
                const n = read(0, &self.buf, self.buf.len);
                if (n <= 0) {
                    if (n < 0 and os.errno() == 4) continue;
                    self.eof = true;
                    break;
                }
                self.pos = 0;
                self.len = @intCast(n);
            }
            got_any = true;
            const chunk = self.buf[self.pos..self.len];
            if (std.mem.indexOfScalar(u8, chunk, term)) |i| {
                util.bufAppend(&line, chunk[0..i]);
                self.pos += i + 1;
                return finish(line.items, term);
            }
            util.bufAppend(&line, chunk);
            self.pos = self.len;
        }
        if (!got_any or line.items.len == 0) return null;
        return finish(line.items, term);
    }

    fn finish(l: []u8, term: u8) []const u8 {
        // strbuf_getline_lf: strip only the LF; strbuf_getline would strip CR too,
        // but git uses the _lf/_nul variants here.
        _ = term;
        return l;
    }
};

fn unquoteLine(l: []const u8, nul: bool) []const u8 {
    if (!nul and l.len > 0 and l[0] == '"') {
        const u = util.cunquote(l) orelse util.die("line is badly quoted", .{});
        if (u.rest.len != 0) util.die("line is badly quoted", .{});
        return u.value;
    }
    return l;
}

// ===================================================================
// check-ignore

const check_ignore_usage = [_][]const u8{
    "git check-ignore [<options>] <pathname>...",
    "git check-ignore [<options>] --stdin",
};

var quiet = false;
var verbose = false;
var stdin_paths = false;
var show_non_matching = false;
var no_index = false;
var nul_term_line = false;

fn outputPattern(path: []const u8, pattern: ?*dir_mod.Pattern) void {
    var bang: []const u8 = "";
    var slash: []const u8 = "";
    if (pattern) |p| {
        if (p.flags & dir_mod.PATTERN_FLAG_NEGATIVE != 0) bang = "!";
        if (p.flags & dir_mod.PATTERN_FLAG_MUSTBEDIR != 0) slash = "/";
    }
    if (!nul_term_line) {
        if (!verbose) {
            util.out(util.cquote(path));
            util.out("\n");
        } else {
            if (pattern) |p| {
                util.out(util.cquote(p.list.src orelse ""));
                util.outf(":{d}:{s}{s}{s}\t", .{ srcposOut(p), bang, p.pattern, slash });
            } else util.out("::\t");
            util.out(util.cquote(path));
            util.out("\n");
        }
    } else {
        if (!verbose) {
            util.out(path);
            util.out("\x00");
        } else {
            if (pattern) |p| {
                util.out(p.list.src orelse "");
                util.out("\x00");
                util.outf("{d}", .{srcposOut(p)});
                util.out("\x00");
                util.outf("{s}{s}{s}", .{ bang, p.pattern, slash });
                util.out("\x00");
                util.out(path);
                util.out("\x00");
            } else {
                util.out("\x00\x00\x00");
                util.out(path);
                util.out("\x00");
            }
        }
    }
}

fn srcposOut(p: *dir_mod.Pattern) i64 {
    return @intCast(p.srcpos);
}

fn dieInsideSubmodule(idx: *index_mod.Index, ps: *const pathspec_mod.Pathspec) void {
    for (idx.entries.items) |e| {
        if (e.mode & 0o170000 != 0o160000) continue;
        const n = e.path.len;
        for (ps.items) |it| {
            if (it.match.len <= n) continue;
            if (it.match[n] != '/') continue;
            if (!std.mem.startsWith(u8, it.match, e.path)) continue;
            if (it.match.len == n + 1) continue;
            util.die("Pathspec '{s}' is in submodule '{s}'", .{ it.original, e.path });
        }
    }
}

fn checkIgnore(d: *dir_mod.Dir, idx: *index_mod.Index, prefix: []const u8, args: []const []const u8) usize {
    if (args.len == 0) {
        if (!quiet) util.eprint("no pathspec given.\n", .{});
        return 0;
    }
    const ps = pathspec_mod.parse(prefix, args, .{
        .symlink_leading_path = true,
        .magic_mask = pathspec_mod.MAGIC_LITERAL | pathspec_mod.MAGIC_GLOB | pathspec_mod.MAGIC_ICASE |
            pathspec_mod.MAGIC_EXCLUDE | pathspec_mod.MAGIC_ATTR | pathspec_mod.MAGIC_MAXDEPTH,
    });
    dieInsideSubmodule(idx, &ps);
    const seen = ps.newSeen();
    ps.matchAgainstIndex(idx, seen, true);
    var num_ignored: usize = 0;
    for (ps.items, 0..) |it, i| {
        var pattern: ?*dir_mod.Pattern = null;
        if (seen[i] == 0) {
            var dtype: u8 = dir_mod.DT_UNKNOWN;
            pattern = d.lastMatchingPattern(it.match, &dtype);
            if (!verbose) {
                if (pattern) |p| {
                    if (p.flags & dir_mod.PATTERN_FLAG_NEGATIVE != 0) pattern = null;
                }
            }
        }
        if (!quiet and (pattern != null or show_non_matching)) outputPattern(it.original, pattern);
        if (pattern != null) num_ignored += 1;
    }
    return num_ignored;
}

pub fn cmdCheckIgnore(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    const opts = [_]po.Opt{
        po.boolean('q', "quiet", &quiet, "suppress progress reporting"),
        po.boolean('v', "verbose", &verbose, "be verbose"),
        po.group(""),
        po.boolean(0, "stdin", &stdin_paths, "read file names from stdin"),
        po.boolean('z', "", &nul_term_line, "terminate input and output records by a NUL character"),
        po.boolean('n', "non-matching", &show_non_matching, "show non-matching input paths"),
        po.boolean(0, "no-index", &no_index, "ignore index when checking"),
    };
    po.prefix = r.prefix;
    const argv = po.parse(args[1..], &opts, &check_ignore_usage, .{});

    if (stdin_paths) {
        if (argv.len > 0) util.die("cannot specify pathnames with --stdin", .{});
    } else {
        if (nul_term_line) util.die("-z only makes sense with --stdin", .{});
        if (argv.len == 0) util.die("no path specified", .{});
    }
    if (quiet) {
        if (argv.len > 1) util.die("--quiet is only valid with a single pathname", .{});
        if (verbose) util.die("cannot have both --quiet and --verbose", .{});
    }
    if (show_non_matching and !verbose) util.die("--non-matching is only valid with --verbose", .{});

    var empty_idx: index_mod.Index = .{};
    const idx: *index_mod.Index = if (no_index) &empty_idx else index_mod.get();

    var d = dir_mod.Dir.init();
    d.setupStandardExcludes();
    d.idx = idx;

    var num_ignored: usize = 0;
    if (stdin_paths) {
        var lr = LineReader{};
        const term: u8 = if (nul_term_line) 0 else '\n';
        while (lr.next(term)) |line0| {
            const line = unquoteLine(line0, nul_term_line);
            num_ignored += checkIgnore(&d, idx, r.prefix, &.{line});
            util.flushStdout();
        }
    } else {
        num_ignored = checkIgnore(&d, idx, r.prefix, argv);
    }
    return if (num_ignored == 0) 1 else 0;
}

// ===================================================================
// check-attr

const check_attr_usage = [_][]const u8{
    "git check-attr [--source <tree-ish>] [-a | --all | <attr>...] [--] <pathname>...",
    "git check-attr --stdin [-z] [--source <tree-ish>] [-a | --all | <attr>...]",
};

var all_attrs = false;
var cached_attrs = false;
var a_stdin = false;
var a_nul = false;
var source: ?[]const u8 = null;
var attr_opts: []const po.Opt = &.{};

fn errorWithUsage(msg: []const u8) noreturn {
    util.err("{s}", .{msg});
    po.usageWithOptions(&check_attr_usage, attr_opts);
}

fn valueStr(v: attr.Value) []const u8 {
    return switch (v) {
        .set => "set",
        .unset => "unset",
        .unspecified => "unspecified",
        .value => |s| s,
    };
}

fn outputAttr(file: []const u8, names: []const []const u8, vals: []const attr.Value) void {
    for (names, 0..) |n, j| {
        const value = valueStr(vals[j]);
        if (a_nul) {
            util.out(file);
            util.out("\x00");
            util.out(n);
            util.out("\x00");
            util.out(value);
            util.out("\x00");
        } else {
            util.out(util.cquote(file));
            util.outf(": {s}: {s}\n", .{ n, value });
        }
    }
}

fn checkAttrPath(names: []const []const u8, collect_all: bool, file: []const u8) void {
    const full = repo_mod.prefixPath(file) orelse {
        const wt = repo_mod.repo().work_tree orelse "";
        util.die("'{s}' is outside repository at '{s}'", .{ file, wt });
    };
    if (collect_all) {
        const nv = attr.all(full);
        var ns: std.ArrayList([]const u8) = .empty;
        var vs: std.ArrayList(attr.Value) = .empty;
        for (nv) |x| {
            ns.append(gpa, x.name) catch util.oom();
            vs.append(gpa, x.value) catch util.oom();
        }
        outputAttr(file, ns.items, vs.items);
    } else {
        outputAttr(file, names, attr.check(full, names));
    }
}

pub fn cmdCheckAttr(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    const opts = [_]po.Opt{
        po.boolean('a', "all", &all_attrs, "report all attributes set on file"),
        po.boolean(0, "cached", &cached_attrs, "use .gitattributes only from the index"),
        po.boolean(0, "stdin", &a_stdin, "read file names from stdin"),
        po.boolean('z', "", &a_nul, "terminate input and output records by a NUL character"),
        po.string(0, "source", &source, "<tree-ish>", "which tree-ish to check attributes at"),
    };
    attr_opts = &opts;
    po.prefix = r.prefix;
    const argv = po.parse(args[1..], &opts, &check_attr_usage, .{ .keep_dashdash = true });

    if (cached_attrs) attr.setDirection(.index);

    var doubledash: i64 = -1;
    for (argv, 0..) |a, i| {
        if (util.eql(a, "--")) {
            doubledash = @intCast(i);
            break;
        }
    }
    const argc: i64 = @intCast(argv.len);
    var cnt: i64 = 0;
    var filei: i64 = 0;
    if (all_attrs) {
        if (doubledash >= 1) errorWithUsage("Attributes and --all both specified");
        cnt = 0;
        filei = doubledash + 1;
    } else if (doubledash == 0) {
        errorWithUsage("No attribute specified");
    } else if (doubledash < 0) {
        if (argc == 0) errorWithUsage("No attribute specified");
        if (a_stdin) {
            cnt = argc;
            filei = argc;
        } else {
            cnt = 1;
            filei = 1;
        }
    } else {
        cnt = doubledash;
        filei = doubledash + 1;
    }

    if (a_stdin) {
        if (filei < argc) errorWithUsage("Can't specify files with --stdin");
    } else {
        if (filei >= argc) errorWithUsage("No file specified");
    }

    const names = argv[0..@intCast(cnt)];
    if (!all_attrs) {
        for (names) |n| {
            if (!attr.validAttrName(n)) {
                util.err("{s}: not a valid attribute name", .{n});
                return 255;
            }
        }
    }

    if (source) |s| {
        if (revparse.getTreeish(s) == null) util.die("{s}: not a valid tree-ish source", .{s});
        attr.setSource(s);
    }

    if (a_stdin) {
        var lr = LineReader{};
        const term: u8 = if (a_nul) 0 else '\n';
        while (lr.next(term)) |line0| {
            const line = unquoteLine(line0, a_nul);
            checkAttrPath(names, all_attrs, line);
            util.flushStdout();
        }
    } else {
        for (argv[@intCast(filei)..]) |f| checkAttrPath(names, all_attrs, f);
    }
    return 0;
}
