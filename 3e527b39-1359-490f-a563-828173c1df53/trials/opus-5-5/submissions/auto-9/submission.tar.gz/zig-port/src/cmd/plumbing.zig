//! Plumbing: hash-object, cat-file, write-tree, commit-tree, mktree.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const odb_mod = @import("../odb.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const index_mod = @import("../index.zig");
const commit_mod = @import("../commit.zig");
const convert = @import("../convert.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

// ---------------- hash-object ----------------

fn readStdin() []u8 {
    return os.readAllFd(0) catch util.die("could not read from stdin", .{});
}

/// Light fsck check of object contents (like index_mem with HASH_FORMAT_CHECK).
pub fn checkObjectFormat(typ: ObjType, data: []const u8) ?[]const u8 {
    switch (typ) {
        .commit => {
            if (!util.startsWith(data, "tree ")) return "corrupt commit";
            if (data.len < 46 or hash.fromHex(data[5..45]) == null or data[45] != '\n') return "corrupt commit";
            var p: usize = 46;
            while (util.startsWith(data[p..], "parent ")) {
                if (data.len < p + 48 or hash.fromHex(data[p + 7 .. p + 47]) == null or data[p + 47] != '\n') return "corrupt commit";
                p += 48;
            }
            if (!util.startsWith(data[p..], "author ")) return "corrupt commit";
            const nl = std.mem.indexOfScalarPos(u8, data, p, '\n') orelse return "corrupt commit";
            p = nl + 1;
            if (!util.startsWith(data[p..], "committer ")) return "corrupt commit";
            return null;
        },
        .tree => {
            var it = objects.TreeIter{ .data = data };
            var prev: ?objects.TreeEntry = null;
            var consumed: usize = 0;
            while (it.next()) |e| {
                if (e.name.len == 0 or std.mem.indexOfScalar(u8, e.name, '/') != null) return "corrupt tree file";
                if (prev) |pv| {
                    if (objects.baseNameCompare(pv.name, pv.mode, e.name, e.mode) != .lt) return "corrupt tree file";
                }
                prev = e;
                consumed = it.pos;
            }
            if (consumed != data.len) return "corrupt tree file";
            return null;
        },
        .tag => {
            if (!util.startsWith(data, "object ")) return "corrupt tag";
            if (data.len < 48 or hash.fromHex(data[7..47]) == null) return "corrupt tag";
            if (!util.startsWith(data[48..], "type ")) return "corrupt tag";
            return null;
        },
        else => return null,
    }
}

fn hashOne(data_in: []const u8, typ: ObjType, write: bool, path: ?[]const u8, literally: bool) Oid {
    var data = data_in;
    if (path) |p| {
        if (typ == .blob) data = convert.toGitChecked(p, data, write);
    }
    if (!literally) {
        if (checkObjectFormat(typ, data)) |msg| util.die("{s}", .{msg});
    }
    if (write) return repo_mod.repo().odb().write(typ, data);
    return odb_mod.hashObject(typ, data);
}

pub fn cmdHashObject(args: []const []const u8) u8 {
    var typ_s: ?[]const u8 = null;
    var write = false;
    var stdin = false;
    var stdin_paths = false;
    var no_filters = false;
    var literally = false;
    var path: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.string('t', "", &typ_s, "type", "object type"),
        po.boolean('w', "", &write, "write the object into the object database"),
        po.boolean(0, "stdin", &stdin, "read the object from stdin"),
        po.boolean(0, "stdin-paths", &stdin_paths, "read file names from stdin"),
        po.boolean(0, "no-filters", &no_filters, "store file as is without filters"),
        po.boolean(0, "literally", &literally, "just hash any random garbage to create corrupt objects for debugging Git"),
        po.string(0, "path", &path, "file", "process file as it were from this path"),
    };
    const usage = [_][]const u8{
        "git hash-object [-t <type>] [-w] [--path=<file> | --no-filters]\n                [--stdin [--literally]] [--] <file>...",
        "git hash-object [-t <type>] [-w] --stdin-paths [--no-filters]",
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (write) {
        repo_mod.setup(false);
    } else {
        repo_mod.setup(true);
    }
    const prefix = if (repo_mod.repo_) |r| r.prefix else "";
    var typ: ObjType = .blob;
    if (typ_s) |t| {
        typ = ObjType.fromName(t) orelse blk: {
            if (literally) break :blk .blob;
            util.die("invalid object type \"{s}\"", .{t});
        };
    }
    if (stdin_paths) {
        if (stdin) util.usageDie("Can't use --stdin-paths with --stdin", .{});
        if (rest.len > 0) util.usageDie("Can't specify files with --stdin-paths", .{});
        if (path != null) util.usageDie("Can't use --stdin-paths with --path", .{});
    }
    if (no_filters and path != null) util.usageDie("Can't use --path with --no-filters", .{});
    const use_filters = !no_filters and repo_mod.repo_ != null;
    if (stdin) {
        const data = readStdin();
        const p: ?[]const u8 = if (use_filters) path else null;
        const oid = hashOne(data, typ, write, p, literally);
        util.outf("{s}\n", .{hash.hex(oid)});
    }
    for (rest) |f| {
        const full = if (f.len > 0 and f[0] == '/') f else util.concat(&.{ prefix, f });
        const data = os.readFile(full) orelse util.dieErrno("could not open '{s}' for reading", .{f});
        const st = os.lstatPath(full);
        var d = data;
        if (st != null and st.?.isLnk()) d = os.readLink(full) orelse data;
        const p: ?[]const u8 = if (use_filters) (path orelse full) else null;
        const oid = hashOne(d, typ, write, p, literally);
        util.outf("{s}\n", .{hash.hex(oid)});
    }
    if (stdin_paths) {
        const input = readStdin();
        var it = std.mem.splitScalar(u8, input, '\n');
        while (it.next()) |line0| {
            if (line0.len == 0 and it.index == null) break;
            var line = line0;
            if (line.len > 0 and line[0] == '"') {
                if (util.cunquote(line)) |u| line = u.value else util.die("line is badly quoted", .{});
            }
            const data = os.readFile(line) orelse util.dieErrno("could not open '{s}' for reading", .{line});
            const p: ?[]const u8 = if (use_filters) line else null;
            const oid = hashOne(data, typ, write, p, literally);
            util.outf("{s}\n", .{hash.hex(oid)});
        }
    }
    return 0;
}

// ---------------- cat-file ----------------

fn printTreePretty(data: []const u8) void {
    var it = objects.TreeIter{ .data = data };
    while (it.next()) |e| {
        const t = if (e.mode == 0o40000) "tree" else if (e.mode == 0o160000) "commit" else "blob";
        util.outf("{o:0>6} {s} {s}\t", .{ e.mode, t, hash.hex(e.oid) });
        util.out(util.cquote(e.name));
        util.out("\n");
    }
}

const BatchMode = enum { none, batch, check, command };

const BatchOpts = struct {
    mode: BatchMode = .none,
    format: ?[]const u8 = null,
    all_objects: bool = false,
    unordered: bool = false,
    buffer: bool = false,
    follow_symlinks: bool = false,
    nul_in: bool = false,
    nul_out: bool = false,
    textconv: bool = false,
    filters: bool = false,
};

fn expandBatchFormat(b: *util.Buf, f: []const u8, name: []const u8, oid: Oid, obj: ?odb_mod.Object, rest: []const u8) void {
    var i: usize = 0;
    while (i < f.len) {
        if (f[i] == '%' and i + 1 < f.len and f[i + 1] == '(') {
            const close = std.mem.indexOfScalarPos(u8, f, i, ')') orelse {
                util.bufByte(b, f[i]);
                i += 1;
                continue;
            };
            const atom = f[i + 2 .. close];
            if (util.eql(atom, "objectname")) {
                util.bufAppend(b, &hash.hex(oid));
            } else if (util.eql(atom, "objecttype")) {
                if (obj) |o| util.bufAppend(b, o.typ.name());
            } else if (util.eql(atom, "objectsize")) {
                if (obj) |o| util.bufPrint(b, "{d}", .{o.data.len});
            } else if (util.eql(atom, "objectsize:disk")) {
                util.bufPrint(b, "{d}", .{diskSize(oid)});
            } else if (util.eql(atom, "deltabase")) {
                util.bufAppend(b, hash.zero_hex);
            } else if (util.eql(atom, "rest")) {
                util.bufAppend(b, rest);
            } else if (util.eql(atom, "objectmode")) {
                // only meaningful for tree:path lookups
            } else {
                util.die("unknown format element: {s}", .{f[i .. close + 1]});
            }
            _ = name;
            i = close + 1;
        } else if (f[i] == '%' and i + 1 < f.len and f[i + 1] == '%') {
            util.bufByte(b, '%');
            i += 2;
        } else {
            util.bufByte(b, f[i]);
            i += 1;
        }
    }
}

fn diskSize(oid: Oid) usize {
    const odb = repo_mod.repo().odb();
    for (odb.allDirs()) |dir| {
        if (os.statPath(odb.looseObjectPath(dir, oid))) |st| return @intCast(st.size);
    }
    return 0;
}

fn batchOne(bo: *const BatchOpts, spec: []const u8, out_buf: *util.Buf) void {
    const fmt_s = bo.format orelse "%(objectname) %(objecttype) %(objectsize)";
    var name = spec;
    var rest: []const u8 = "";
    if (std.mem.indexOf(u8, fmt_s, "%(rest)") != null) {
        if (std.mem.indexOfAny(u8, spec, " \t")) |sp| {
            name = spec[0..sp];
            rest = std.mem.trimStart(u8, spec[sp + 1 ..], " \t");
        }
    }
    const eol: u8 = if (bo.nul_out) 0 else '\n';
    const res = revparse.resolve(name, .{ .quiet = true }) orelse {
        // ambiguous?
        util.bufPrint(out_buf, "{s} missing", .{name});
        util.bufByte(out_buf, eol);
        return;
    };
    const obj = repo_mod.repo().odb().read(res.oid) orelse {
        util.bufPrint(out_buf, "{s} missing", .{name});
        util.bufByte(out_buf, eol);
        return;
    };
    expandBatchFormat(out_buf, fmt_s, name, res.oid, obj, rest);
    util.bufByte(out_buf, eol);
    if (bo.mode == .batch) {
        util.bufAppend(out_buf, obj.data);
        util.bufByte(out_buf, eol);
    }
}

fn runBatch(bo: *BatchOpts) u8 {
    var b: util.Buf = .empty;
    if (bo.all_objects) {
        const all = repo_mod.repo().odb().allObjects(true);
        std.mem.sort(Oid, all, {}, hash.lessThan);
        var prev: ?Oid = null;
        for (all) |o| {
            if (prev != null and hash.eql(prev.?, o)) continue;
            prev = o;
            batchOne(bo, &hash.hex(o), &b);
            util.out(b.items);
            b.clearRetainingCapacity();
        }
        return 0;
    }
    const input = readStdin();
    const sep: u8 = if (bo.nul_in) 0 else '\n';
    var it = std.mem.splitScalar(u8, input, sep);
    var queued: std.ArrayList([]const u8) = .empty;
    while (it.next()) |line| {
        if (line.len == 0 and it.index == null) break;
        if (bo.mode == .command) {
            if (util.skipPrefix(line, "contents ")) |n| {
                const save = bo.mode;
                bo.mode = .batch;
                if (bo.buffer) queued.append(gpa, util.concat(&.{ "B", n })) catch util.oom() else batchOne(bo, n, &b);
                bo.mode = save;
            } else if (util.skipPrefix(line, "info ")) |n| {
                const save = bo.mode;
                bo.mode = .check;
                if (bo.buffer) queued.append(gpa, util.concat(&.{ "C", n })) catch util.oom() else batchOne(bo, n, &b);
                bo.mode = save;
            } else if (util.eql(line, "flush")) {
                if (!bo.buffer) util.die("flush is only for --buffer mode", .{});
                for (queued.items) |q| {
                    const save = bo.mode;
                    bo.mode = if (q[0] == 'B') .batch else .check;
                    batchOne(bo, q[1..], &b);
                    bo.mode = save;
                }
                queued.clearRetainingCapacity();
                util.out(b.items);
                b.clearRetainingCapacity();
                util.flushStdout();
            } else if (line.len == 0) {
                util.die("empty command in input", .{});
            } else if (line[0] == ' ' or line[0] == '\t') {
                util.die("whitespace before command: '{s}'", .{line});
            } else {
                util.die("unknown command: '{s}'", .{line});
            }
        } else {
            batchOne(bo, line, &b);
        }
        if (!bo.buffer) {
            util.out(b.items);
            b.clearRetainingCapacity();
            util.flushStdout();
        }
    }
    util.out(b.items);
    return 0;
}

pub fn cmdCatFile(args: []const []const u8) u8 {
    var opt_t = false;
    var opt_s = false;
    var opt_e = false;
    var opt_p = false;
    var allow_unknown = false;
    var textconv = false;
    var filters = false;
    var path: ?[]const u8 = null;
    var batch: ?[]const u8 = null;
    var batch_check: ?[]const u8 = null;
    var batch_command: ?[]const u8 = null;
    var all_objects = false;
    var unordered = false;
    var buffer = false;
    var follow = false;
    var opt_z = false;
    var opt_Z = false;
    const opts = [_]po.Opt{
        po.group("Check object existence or emit object contents"),
        po.boolean('e', "", &opt_e, "check if <object> exists"),
        po.boolean('p', "", &opt_p, "pretty-print <object> content"),
        po.group("Emit [broken] object attributes"),
        po.boolean('t', "", &opt_t, "show object type (one of 'blob', 'tree', 'commit', 'tag', ...)"),
        po.boolean('s', "", &opt_s, "show object size"),
        po.boolean(0, "allow-unknown-type", &allow_unknown, "allow -s and -t to work with broken/corrupt objects"),
        po.boolean(0, "use-mailmap", &allow_unknown, "use mail map file"),
        po.group("Batch objects requested on stdin (or --batch-all-objects)"),
        po.optString(0, "batch", &batch, "", "format", "show full <object> or <rev> contents"),
        po.optString(0, "batch-check", &batch_check, "", "format", "like --batch, but don't emit <contents>"),
        po.optString(0, "batch-command", &batch_command, "", "format", "read commands from stdin"),
        po.boolean(0, "batch-all-objects", &all_objects, "with --batch[-check]: ignores stdin, batches all known objects"),
        po.group("Change or optimize batch output"),
        po.boolean(0, "buffer", &buffer, "buffer --batch output"),
        po.boolean(0, "follow-symlinks", &follow, "follow in-tree symlinks"),
        po.boolean(0, "unordered", &unordered, "do not order objects before emitting them"),
        po.boolean('z', "", &opt_z, "stdin is NUL-terminated"),
        po.boolean('Z', "", &opt_Z, "stdin and stdout is NUL-terminated"),
        po.group("Emit object (blob or tree) with conversion or filter (stand-alone, or with batch)"),
        po.boolean(0, "textconv", &textconv, "run textconv on object's content"),
        po.boolean(0, "filters", &filters, "run filters on object's content"),
        po.string(0, "path", &path, "blob|tree", "use a <path> for (--textconv | --filters); Not with 'batch'"),
    };
    const usage = [_][]const u8{
        "git cat-file <type> <object>",
        "git cat-file (-e | -p | -t | -s) <object>",
        "git cat-file (--textconv | --filters)\n             [<rev>:<path|tree-ish> | --path=<path|tree-ish> <rev>]",
        "git cat-file (--batch | --batch-check | --batch-command) [--batch-all-objects]\n             [--buffer] [--follow-symlinks] [--unordered]\n             [--textconv | --filters] [-Z]",
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    repo_mod.setup(false);
    const batch_set = batch != null;
    const check_set = batch_check != null;
    const command_set = batch_command != null;
    if (batch_set or check_set or command_set) {
        var bo = BatchOpts{ .all_objects = all_objects, .unordered = unordered, .buffer = buffer, .follow_symlinks = follow, .nul_in = opt_z or opt_Z, .nul_out = opt_Z, .textconv = textconv, .filters = filters };
        if (batch_set) {
            bo.mode = .batch;
            bo.format = if (batch.?.len == 0) null else batch;
        } else if (check_set) {
            bo.mode = .check;
            bo.format = if (batch_check.?.len == 0) null else batch_check;
        } else {
            bo.mode = .command;
            bo.format = if (batch_command.?.len == 0) null else batch_command;
        }
        if (rest.len > 0) po.usageWithOptions(&usage, &opts);
        return runBatch(&bo);
    }
    if (all_objects) util.usageDie("--batch-all-objects requires a batch mode", .{});
    var mode: u8 = 0;
    var cnt: u32 = 0;
    if (opt_t) {
        mode = 't';
        cnt += 1;
    }
    if (opt_s) {
        mode = 's';
        cnt += 1;
    }
    if (opt_e) {
        mode = 'e';
        cnt += 1;
    }
    if (opt_p) {
        mode = 'p';
        cnt += 1;
    }
    if (textconv) {
        mode = 'c';
        cnt += 1;
    }
    if (filters) {
        mode = 'w';
        cnt += 1;
    }
    if (cnt > 1) {
        util.err("options '-{c}' and '-{c}' cannot be used together", .{ firstMode(opt_e, opt_p, opt_t, opt_s), mode });
        po.usageWithOptions(&usage, &opts);
    }
    var type_name: ?[]const u8 = null;
    var obj_name: []const u8 = undefined;
    if (mode == 0) {
        if (rest.len != 2) po.usageWithOptions(&usage, &opts);
        type_name = rest[0];
        obj_name = rest[1];
    } else {
        if (rest.len != 1) {
            if (rest.len == 0) {
                util.err("only one batch option may be specified", .{});
            }
            po.usageWithOptions(&usage, &opts);
        }
        obj_name = rest[0];
    }
    const res = revparse.resolve(obj_name, .{}) orelse util.die("Not a valid object name {s}", .{obj_name});
    const oid = res.oid;
    const odb = repo_mod.repo().odb();
    switch (mode) {
        'e' => {
            if (odb.has(oid)) return 0;
            return 1;
        },
        't' => {
            const obj = odb.read(oid) orelse util.die("git cat-file: could not get object info", .{});
            util.outf("{s}\n", .{obj.typ.name()});
            return 0;
        },
        's' => {
            const obj = odb.read(oid) orelse util.die("git cat-file: could not get object info", .{});
            util.outf("{d}\n", .{obj.data.len});
            return 0;
        },
        'p' => {
            const obj = odb.read(oid) orelse util.die("Not a valid object name {s}", .{obj_name});
            if (obj.typ == .tree) {
                printTreePretty(obj.data);
            } else util.out(obj.data);
            return 0;
        },
        'c', 'w' => {
            const obj = odb.read(oid) orelse util.die("Not a valid object name {s}", .{obj_name});
            const p = path orelse res.path orelse util.die("git cat-file --{s}: <object> must be <sha1:path>", .{if (mode == 'c') "textconv" else "filters"});
            if (mode == 'w' and obj.typ == .blob) {
                util.out(convert.toWorktree(p, obj.data));
            } else util.out(obj.data);
            return 0;
        },
        else => {
            const want = ObjType.fromName(type_name.?) orelse util.die("invalid object type \"{s}\"", .{type_name.?});
            const obj = odb.read(oid) orelse util.die("git cat-file {s}: bad file", .{obj_name});
            if (obj.typ == want) {
                util.out(obj.data);
                return 0;
            }
            // peel
            const p = objects.peelTo(oid, want) orelse util.die("git cat-file {s}: bad file", .{obj_name});
            const o2 = odb.read(p) orelse util.die("git cat-file {s}: bad file", .{obj_name});
            util.out(o2.data);
            return 0;
        },
    }
}

fn firstMode(e: bool, p: bool, t: bool, s: bool) u8 {
    if (t) return 't';
    if (s) return 's';
    if (e) return 'e';
    if (p) return 'p';
    return '?';
}



// ---------------- write-tree ----------------

pub fn cmdWriteTree(args: []const []const u8) u8 {
    var missing_ok = false;
    var prefix: ?[]const u8 = null;
    var ignore_cache_tree = false;
    const opts = [_]po.Opt{
        po.boolean(0, "missing-ok", &missing_ok, "allow missing objects"),
        po.string(0, "prefix", &prefix, "<prefix>/", "write tree object for a subdirectory <prefix>"),
        po.boolean(0, "ignore-cache-tree", &ignore_cache_tree, "only useful for debugging"),
    };
    const usage = [_][]const u8{"git write-tree [--missing-ok] [--prefix=<prefix>/]"};
    _ = po.parse(args[1..], &opts, &usage, .{});
    const idx = index_mod.get();
    if (idx.unmerged()) {
        var prev: []const u8 = "";
        for (idx.entries.items) |e| {
            if (e.stage() == 0) continue;
            if (util.eql(prev, e.path)) continue;
            prev = e.path;
            util.err("{s}: unmerged ({s})", .{ e.path, hash.hex(e.oid) });
        }
        util.die("git-write-tree: error building trees", .{});
    }
    const had_tree = idx.cache_tree != null and idx.cache_tree.?.entry_count >= 0;
    if (ignore_cache_tree) idx.cache_tree = null;
    const root = idx.writeTree(missing_ok) orelse util.die("git-write-tree: error building trees", .{});
    // update the index's cache tree on disk (git does this when it can lock)
    if (!had_tree) {
        switch (@import("../lockfile.zig").tryLock(idx.path)) {
            .ok => |l| {
                idx.lock = l;
                idx.write();
            },
            .err => {},
        }
    }
    var out_oid = root;
    if (prefix) |p0| {
        var p = p0;
        while (p.len > 0 and p[p.len - 1] == '/') p = p[0 .. p.len - 1];
        const ent = objects.treeLookup(root, p) orelse util.die("git-write-tree: prefix {s} not found", .{p0});
        if (!ent.isDir()) util.die("git-write-tree: prefix {s} not found", .{p0});
        out_oid = ent.oid;
    }
    util.outf("{s}\n", .{hash.hex(out_oid)});
    return 0;
}

// ---------------- commit-tree ----------------

var ct_parents: std.ArrayList(Oid) = .empty;
var ct_msg: util.Buf = .empty;
var ct_have_msg = false;

fn ctParent(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg.?;
    const o = revparse.getCommit(a) orelse util.die("not a valid object name {s}", .{a});
    for (ct_parents.items) |p| {
        if (hash.eql(p, o)) {
            util.err("duplicate parent {s} ignored", .{hash.hex(o)});
            return;
        }
    }
    ct_parents.append(gpa, o) catch util.oom();
}

fn ctMessage(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    if (ct_msg.items.len > 0) util.bufByte(&ct_msg, '\n');
    util.bufAppend(&ct_msg, arg.?);
    // strbuf_complete_line
    if (ct_msg.items.len > 0 and ct_msg.items[ct_msg.items.len - 1] != '\n') util.bufByte(&ct_msg, '\n');
    ct_have_msg = true;
}

fn ctFile(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg.?;
    if (ct_msg.items.len > 0) util.bufByte(&ct_msg, '\n');
    const data = if (util.eql(a, "-")) readStdin() else (os.readFile(util.concat(&.{ po.prefix, a })) orelse util.dieErrno("could not read log file '{s}'", .{a}));
    util.bufAppend(&ct_msg, data);
    if (ct_msg.items.len > 0 and ct_msg.items[ct_msg.items.len - 1] != '\n') util.bufByte(&ct_msg, '\n');
    ct_have_msg = true;
}

pub fn cmdCommitTree(args: []const []const u8) u8 {
    var sign: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.callback('p', "", ctParent, "parent", "id of a parent commit object"),
        po.callback('m', "", ctMessage, "message", "commit message"),
        po.callback('F', "", ctFile, "file", "read commit log message from file"),
        po.optString('S', "gpg-sign", &sign, "", "key-id", "GPG sign commit"),
    };
    const usage = [_][]const u8{"git commit-tree <tree> [(-p <parent>)...]\n                [(-m <message>)...] [(-F <file>)...] <tree>"};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len != 1) {
        if (rest.len == 0) util.die("must give exactly one tree", .{});
        util.die("must give exactly one tree", .{});
    }
    const tree = revparse.getTreeish(rest[0]) orelse util.die("not a valid object name {s}", .{rest[0]});
    if (!ct_have_msg) {
        const data = readStdin();
        util.bufAppend(&ct_msg, data);
    }
    const oid = commit_mod.create(.{ .tree = tree, .parents = ct_parents.items, .message = ct_msg.items });
    util.outf("{s}\n", .{hash.hex(oid)});
    return 0;
}

// ---------------- mktree ----------------

pub fn cmdMktree(args: []const []const u8) u8 {
    var nul = false;
    var missing = false;
    var batch = false;
    const opts = [_]po.Opt{
        po.boolean('z', "", &nul, "input is NUL terminated"),
        po.boolean(0, "missing", &missing, "allow missing objects"),
        po.boolean(0, "batch", &batch, "allow creation of more than one tree"),
    };
    const usage = [_][]const u8{"git mktree [-z] [--missing] [--batch]"};
    _ = po.parse(args[1..], &opts, &usage, .{});
    const input = readStdin();
    const sep: u8 = if (nul) 0 else '\n';
    var entries: std.ArrayList(objects.TreeEntry) = .empty;
    var it = std.mem.splitScalar(u8, input, sep);
    var any = false;
    while (true) {
        const line_opt = it.next();
        const at_end = line_opt == null or (line_opt.?.len == 0 and it.index == null);
        if (at_end or line_opt.?.len == 0) {
            if (any or (at_end and !batch) or (!at_end and batch)) {
                if (!(at_end and batch and !any)) {
                    objects.sortTreeEntries(entries.items);
                    const oid = repo_mod.repo().odb().write(.tree, objects.formatTree(entries.items));
                    util.outf("{s}\n", .{hash.hex(oid)});
                }
            }
            entries.clearRetainingCapacity();
            any = false;
            if (at_end) break;
            if (!batch) break;
            continue;
        }
        const line = line_opt.?;
        any = true;
        // "mode SP type SP sha TAB path"
        const sp1 = std.mem.indexOfScalar(u8, line, ' ') orelse util.die("input format error: {s}", .{line});
        const sp2 = std.mem.indexOfScalarPos(u8, line, sp1 + 1, ' ') orelse util.die("input format error: {s}", .{line});
        const tab = std.mem.indexOfScalarPos(u8, line, sp2 + 1, '\t') orelse util.die("input format error: {s}", .{line});
        const mode = std.fmt.parseInt(u32, line[0..sp1], 8) catch util.die("input format error: {s}", .{line});
        const typ_s = line[sp1 + 1 .. sp2];
        const oid = hash.fromHex(line[sp2 + 1 .. tab]) orelse util.die("input format error: {s}", .{line});
        var path: []const u8 = line[tab + 1 ..];
        if (!nul and path.len > 0 and path[0] == '"') {
            path = (util.cunquote(path) orelse util.die("invalid quoting", .{})).value;
        }
        if (std.mem.indexOfScalar(u8, path, '/') != null) util.die("path {s} contains slash", .{path});
        const mode_type: []const u8 = if (mode == 0o40000) "tree" else if (mode == 0o160000) "commit" else "blob";
        if (!util.eql(mode_type, typ_s)) util.die("entry '{s}' object type ({s}) doesn't match mode type ({s})", .{ path, typ_s, mode_type });
        if (mode != 0o160000) {
            const t = repo_mod.repo().odb().readType(oid);
            if (t == null) {
                if (!missing) util.die("entry '{s}' object {s} is unavailable", .{ path, hash.hex(oid) });
            } else if (!util.eql(t.?.name(), typ_s)) {
                util.die("entry '{s}' object {s} is a {s} but specified type was ({s})", .{ path, hash.hex(oid), t.?.name(), typ_s });
            }
        }
        entries.append(gpa, .{ .mode = mode, .name = path, .oid = oid }) catch util.oom();
    }
    return 0;
}
