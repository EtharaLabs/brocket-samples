//! find_bisection() from bisect.c (used by rev-list --bisect*).

const std = @import("std");
const util = @import("util.zig");
const cn = @import("commitnode.zig");
const logtree = @import("logtree.zig");
const gpa = util.gpa;

const Commit = cn.Commit;
const CommitList = cn.CommitList;

const COUNTED: u32 = 1 << 16;
pub const FIND_BISECTION_ALL: u32 = 1 << 0;
pub const FIND_BISECTION_FIRST_PARENT_ONLY: u32 = 1 << 1;

var weights: cn.Slab(i32) = cn.Slab(i32).init(0);

fn weight(c: *Commit) i32 {
    return weights.at(c).*;
}
fn weightSet(c: *Commit, w: i32) void {
    weights.at(c).* = w;
}

fn countDistance(entry0: ?*CommitList) i32 {
    var nr: i32 = 0;
    var entry = entry0;
    while (entry) |e| {
        const commit = e.item;
        if (commit.obj.flags & (cn.UNINTERESTING | COUNTED) != 0) break;
        if (commit.obj.flags & cn.TREESAME == 0) nr += 1;
        commit.obj.flags |= COUNTED;
        const p = commit.parents;
        entry = p;
        if (p) |pp| {
            var q = pp.next;
            while (q) |qq| : (q = qq.next) nr += countDistance(qq);
        }
    }
    return nr;
}

fn clearDistance(list: ?*CommitList) void {
    var l = list;
    while (l) |e| : (l = e.next) e.item.obj.flags &= ~COUNTED;
}

fn countInterestingParents(commit: *Commit, flags: u32) usize {
    var count: usize = 0;
    var p = commit.parents;
    while (p) |pp| : (p = pp.next) {
        if (pp.item.obj.flags & cn.UNINTERESTING == 0) count += 1;
        if (flags & FIND_BISECTION_FIRST_PARENT_ONLY != 0) break;
    }
    return count;
}

fn approxHalfway(p: *CommitList, nr: i32) bool {
    if (p.item.obj.flags & cn.TREESAME != 0) return false;
    const diff = 2 * weight(p.item) - nr;
    return switch (diff) {
        -1, 0, 1 => true,
        else => @abs(diff) < @divTrunc(nr, 1024),
    };
}

fn bestBisection(list: *CommitList, nr: i32) *CommitList {
    var best = list;
    var best_distance: i32 = -1;
    var p: ?*CommitList = list;
    while (p) |pp| : (p = pp.next) {
        if (pp.item.obj.flags & cn.TREESAME != 0) continue;
        var distance = weight(pp.item);
        if (nr - distance < distance) distance = nr - distance;
        if (distance > best_distance) {
            best = pp;
            best_distance = distance;
        }
    }
    return best;
}

const CommitDist = struct { commit: *Commit, distance: i32 };

fn lessDist(_: void, a: CommitDist, b: CommitDist) bool {
    if (a.distance != b.distance) return a.distance > b.distance;
    return std.mem.order(u8, &a.commit.obj.oid, &b.commit.obj.oid) == .lt;
}

fn bestBisectionSorted(list: *CommitList, nr: i32) *CommitList {
    var arr: std.ArrayList(CommitDist) = .empty;
    var p: ?*CommitList = list;
    while (p) |pp| : (p = pp.next) {
        if (pp.item.obj.flags & cn.TREESAME != 0) continue;
        var distance = weight(pp.item);
        if (nr - distance < distance) distance = nr - distance;
        arr.append(gpa, .{ .commit = pp.item, .distance = distance }) catch util.oom();
    }
    std.sort.pdq(CommitDist, arr.items, {}, lessDist);
    var q: *CommitList = list;
    for (arr.items, 0..) |cd, i| {
        logtree.addNameDecoration(.none, util.fmt("dist={d}", .{cd.distance}), &cd.commit.obj);
        q.item = cd.commit;
        if (i + 1 < arr.items.len) q = q.next.?;
    }
    q.next = null;
    return list;
}

fn doFindBisection(list: *CommitList, nr: i32, flags: u32) ?*CommitList {
    var counted: i32 = 0;
    var p: ?*CommitList = list;
    while (p) |pp| : (p = pp.next) {
        const commit = pp.item;
        switch (countInterestingParents(commit, flags)) {
            0 => {
                if (commit.obj.flags & cn.TREESAME == 0) {
                    weightSet(commit, 1);
                    counted += 1;
                } else weightSet(commit, 0);
            },
            1 => weightSet(commit, -1),
            else => weightSet(commit, -2),
        }
    }

    p = list;
    while (p) |pp| : (p = pp.next) {
        if (pp.item.obj.flags & cn.UNINTERESTING != 0) continue;
        if (weight(pp.item) != -2) continue;
        if (flags & FIND_BISECTION_FIRST_PARENT_ONLY != 0) util.die("BUG: shouldn't be calling count-distance in fp mode", .{});
        weightSet(pp.item, countDistance(pp));
        clearDistance(list);
        if (flags & FIND_BISECTION_ALL == 0 and approxHalfway(pp, nr)) return pp;
        counted += 1;
    }

    while (counted < nr) {
        var progress = false;
        p = list;
        while (p) |pp| : (p = pp.next) {
            if (0 <= weight(pp.item)) continue;
            var q = pp.item.parents;
            while (q) |qq| {
                if (qq.item.obj.flags & cn.UNINTERESTING == 0 and 0 <= weight(qq.item)) break;
                q = if (flags & FIND_BISECTION_FIRST_PARENT_ONLY != 0) null else qq.next;
            }
            const qq = q orelse continue;
            progress = true;
            if (pp.item.obj.flags & cn.TREESAME == 0) {
                weightSet(pp.item, weight(qq.item) + 1);
                counted += 1;
            } else weightSet(pp.item, weight(qq.item));
            if (flags & FIND_BISECTION_ALL == 0 and approxHalfway(pp, nr)) return pp;
        }
        if (!progress) break; // C would loop forever
    }

    if (flags & FIND_BISECTION_ALL == 0) return bestBisection(list, nr);
    return bestBisectionSorted(list, nr);
}

/// find_bisection(): returns the new list; sets reaches/all.
pub fn findBisection(commit_list: *?*CommitList, reaches: *i32, all: *i32, flags: u32) void {
    var nr: i32 = 0;
    var last: ?*CommitList = null;
    var p = commit_list.*;
    while (p) |pp| {
        const next = pp.next;
        p = next;
        const f = pp.item.obj.flags;
        if (f & cn.UNINTERESTING != 0) continue;
        pp.next = last;
        last = pp;
        if (f & cn.TREESAME == 0) nr += 1;
    }
    all.* = nr;
    const list = last orelse {
        commit_list.* = null;
        return;
    };
    var best = doFindBisection(list, nr, flags);
    if (best) |b| {
        if (flags & FIND_BISECTION_ALL == 0) {
            list.item = b.item;
            list.next = null;
            best = list;
        }
        reaches.* = weight(best.?.item);
    }
    commit_list.* = best;
}

/// estimate_bisect_steps()
pub fn estimateBisectSteps(all: i32) i32 {
    if (all < 3) return 0;
    const n: i32 = @intCast(std.math.log2_int(u32, @intCast(all)));
    const e: i32 = @as(i32, 1) << @intCast(n);
    const x = all - e;
    return if (e < 3 * x) n else n - 1;
}
