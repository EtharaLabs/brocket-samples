//! git prune (port of builtin/prune.c).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const date = @import("../date.zig");
const revparse = @import("../revparse.zig");
const fsck = @import("../fsck.zig");
const reachable = @import("../reachable.zig");
const prunepacked = @import("../prunepacked.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

const prune_usage = [_][]const u8{"git prune [-n] [-v] [--progress] [--expire <time>] [--] [<head>...]"};

var show_only = false;
var verbose: i32 = 0;
var expire: i64 = std.math.maxInt(i64);
var show_progress: i32 = -1;
var exclude_promisor = false;

var extra_heads: std.ArrayList(Oid) = .empty;
var reach_done = false;
var reach_set: hash.OidSet = .empty;

fn traversal() void {
    if (reach_done) return;
    reach_done = true;
    reach_set = reachable.markReachable(.{ .mark_reflog = true, .mark_recent = expire, .extra = extra_heads.items });
}

fn isReachable(oid: Oid) bool {
    traversal();
    return reach_set.contains(oid);
}

fn expireCb(arg: ?[]const u8, unset: bool) void {
    const a = if (unset) "never" else (arg orelse "never");
    expire = date.parseExpiryDate(a) orelse util.die("malformed expiration date '{s}'", .{a});
}

fn pruneTmpFile(path: []const u8) void {
    const st = os.lstatPath(path) orelse {
        util.err("Could not stat '{s}'", .{path});
        return;
    };
    if (st.mtime > expire) return;
    if (st.isDir()) {
        if (show_only or verbose > 0) util.outf("Removing stale temporary directory {s}\n", .{path});
        if (!show_only) os.removeTree(path);
    } else {
        if (show_only or verbose > 0) util.outf("Removing stale temporary file {s}\n", .{path});
        if (!show_only and !os.unlink(path)) util.warn("unable to unlink '{s}': {s}", .{ path, os.lastErr() });
    }
}

fn removeTemporaryFiles(path: []const u8) void {
    const ents = os.listDir(path) orelse {
        if (os.exists(path)) util.eprint("Unable to open directory {s}: {s}\n", .{ path, os.lastErr() });
        return;
    };
    for (ents) |e| {
        if (util.startsWith(e.name, "tmp_")) pruneTmpFile(util.concat(&.{ path, "/", e.name }));
    }
}

fn pruneObject(oid: Oid, path: []const u8) void {
    if (isReachable(oid)) return;
    const st = os.lstatPath(path) orelse {
        util.err("Could not stat '{s}'", .{path});
        return;
    };
    if (st.mtime > expire) return;
    if (show_only or verbose > 0) {
        const t = fsck.readObjectType(oid);
        util.outf("{s} {s}\n", .{ &hash.hex(oid), if (t) |x| (fsck.typeName(x) orelse "unknown") else "unknown" });
    }
    if (!show_only and !os.unlink(path)) util.warn("unable to unlink '{s}': {s}", .{ path, os.lastErr() });
}

fn pruneShallow() void {
    const r = repo_mod.repo();
    const path = r.commonPath("shallow");
    const data = os.readFile(path) orelse return;
    var list: std.ArrayList(Oid) = .empty;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |l| {
        if (l.len < 40) continue;
        const o = hash.fromHex(l[0..40]) orelse continue;
        var dup = false;
        for (list.items) |x| {
            if (hash.eql(x, o)) dup = true;
        }
        if (!dup) list.append(gpa, o) catch util.oom();
    }
    std.mem.sort(Oid, list.items, {}, struct {
        fn lt(_: void, a: Oid, b: Oid) bool {
            return hash.order(a, b) == .lt;
        }
    }.lt);
    var out: util.Buf = .empty;
    var count: usize = 0;
    for (list.items) |o| {
        if (!reach_set.contains(o)) {
            if (show_only) util.outf("Removing {s} from .git/shallow\n", .{&hash.hex(o)});
            continue;
        }
        count += 1;
        util.bufAppend(&out, &hash.hex(o));
        util.bufByte(&out, '\n');
    }
    if (show_only) return;
    if (count > 0) {
        const lock = util.concat(&.{ path, ".lock" });
        os.writeFile(lock, out.items, 0o666) catch util.die("failed to write to {s}", .{lock});
        if (std.c.rename(@ptrCast(util.concat(&.{ lock, "\x00" }).ptr), @ptrCast(util.concat(&.{ path, "\x00" }).ptr)) != 0)
            util.die("unable to write shallow file", .{});
    } else {
        _ = os.unlink(path);
    }
}

pub fn cmdPrune(args: []const []const u8) u8 {
    const options = [_]po.Opt{
        po.boolean('n', "dry-run", &show_only, "do not remove, show only"),
        po.verbose(&verbose),
        po.setInt(0, "progress", &show_progress, 1, "show progress"),
        .{ .long = "expire", .kind = .callback, .cb = expireCb, .argh = "expiry-date", .help = "expire objects older than <time>" },
        po.boolean(0, "exclude-promisor-objects", &exclude_promisor, "limit traversal to objects outside promisor packfiles"),
    };
    const rest = po.parse(args[1..], &options, &prune_usage, .{});

    if (repo_mod.cfg.getBool("extensions.preciousobjects") orelse false)
        util.die("cannot prune in a precious-objects repo", .{});

    for (rest) |name| {
        const oid = revparse.getOid(name) orelse util.die("unrecognized argument: {s}", .{name});
        if (!fsck.hasObject(oid)) util.die("unable to parse object: {s}", .{name});
        extra_heads.append(gpa, oid) catch util.oom();
    }

    const odb = repo_mod.repo().odb();
    const dir = odb.objects_dir;
    var b: usize = 0;
    while (b < 256) : (b += 1) {
        const hx = util.fmt("{x:0>2}", .{b});
        const sub = util.concat(&.{ dir, "/", hx });
        const ents = os.listDir(sub) orelse continue;
        for (ents) |e| {
            const path = util.concat(&.{ sub, "/", e.name });
            if (e.name.len == 38) {
                if (hash.fromHex(util.concat(&.{ hx, e.name }))) |oid| {
                    pruneObject(oid, path);
                    continue;
                }
            }
            if (util.startsWith(e.name, "tmp_obj_")) {
                pruneTmpFile(path);
            } else util.eprint("bad sha1 file: {s}\n", .{path});
        }
        if (!show_only) _ = os.rmdir(sub);
    }

    prunepacked.prunePacked(show_only, true);
    removeTemporaryFiles(dir);
    removeTemporaryFiles(util.concat(&.{ dir, "/pack" }));

    const shallow_path = repo_mod.repo().commonPath("shallow");
    if (os.readFile(shallow_path)) |sd| {
        if (sd.len > 0) {
            traversal();
            pruneShallow();
        }
    }
    util.flushStdout();
    return 0;
}
