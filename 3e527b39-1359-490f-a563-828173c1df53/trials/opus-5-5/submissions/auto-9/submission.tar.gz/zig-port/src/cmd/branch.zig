//! Port of builtin/branch.c
const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const cn = @import("../commitnode.zig");
const reach = @import("../commitreach.zig");
const rf = @import("../reffilter.zig");
const color_mod = @import("../color.zig");
const advice = @import("../advice.zig");
const editor = @import("../editor.zig");
const trailer_cfg = @import("../pretty_trailer.zig");
const column = @import("../column.zig");
const bc = @import("../branchcreate.zig");
const worktree = @import("../worktree.zig");
const Oid = hash.Oid;
const gpa = util.gpa;
const Buf = util.Buf;

const branch_usage = [_][]const u8{
    "git branch [<options>] [-r | -a] [--merged] [--no-merged] [(--forked <branch>)...]",
    "git branch [<options>] [-f] [--recurse-submodules] <branch-name> [<start-point>]",
    "git branch [<options>] [-l] [<pattern>...]",
    "git branch [<options>] [-r] (-d | -D) <branch-name>...",
    "git branch [<options>] (-m | -M) [<old-branch>] <new-branch>",
    "git branch [<options>] (-c | -C) [<old-branch>] <new-branch>",
    "git branch [<options>] [-r | -a] [--points-at]",
    "git branch [<options>] [-r | -a] [--format]",
    "git branch [<options>] (--delete-merged <pattern>)... [<branch-pattern>...]",
};

var head: []const u8 = "";
var head_oid: Oid = hash.zero;

var branch_use_color: color_mod.ColorBool = .unknown;
const C_RESET = 0;
const C_PLAIN = 1;
const C_REMOTE = 2;
const C_LOCAL = 3;
const C_CURRENT = 4;
const C_UPSTREAM = 5;
const C_WORKTREE = 6;
var branch_colors = [_][]const u8{ color_mod.RESET, "", color_mod.RED, "", color_mod.GREEN, color_mod.BLUE, color_mod.CYAN };
const color_slots = [_][]const u8{ "reset", "plain", "remote", "local", "current", "upstream", "worktree" };
var want_color = false;

var colopts: u32 = 0;

fn getColor(ix: usize) []const u8 {
    if (want_color) return branch_colors[ix];
    return "";
}

fn configPath() []const u8 {
    return repo_mod.repo().commonPath("config");
}

fn readConfig(sorting: *std.ArrayList([]const u8), submodule_propagate: *bool, recurse_submodules: *bool) void {
    const cfg = &repo_mod.cfg;
    for (cfg.entries.items) |e| {
        const k = e.key;
        if (util.eql(k, "branch.sort")) {
            const v = e.value orelse {
                _ = config.errorNonbool(k);
                util.die("bad config variable '{s}'", .{k});
            };
            sorting.append(gpa, v) catch util.oom();
        } else if (util.eql(k, "color.branch")) {
            branch_use_color = color_mod.configColorBool(k, e.value);
        } else if (util.skipPrefix(k, "color.branch.")) |slot| {
            for (color_slots, 0..) |s, i| {
                if (std.ascii.eqlIgnoreCase(s, slot)) {
                    const v = e.value orelse util.die("missing value for '{s}'", .{k});
                    branch_colors[i] = color_mod.parseColorOrError(v) orelse util.die("bad config variable '{s}'", .{k});
                }
            }
        } else if (util.eql(k, "submodule.recurse")) {
            recurse_submodules.* = config.configBool(k, e.value);
        } else if (util.eql(k, "submodule.propagatebranches")) {
            submodule_propagate.* = config.configBool(k, e.value);
        }
    }
    column.applyRepoConfig("branch", &colopts);
}

// ---------------------------------------------------------------------------
// deletion

const DEL_FORCE: u32 = 1;
const DEL_QUIET: u32 = 2;
const DEL_SKIP_UNMERGED: u32 = 4;
const DEL_NO_HEAD_FALLBACK: u32 = 8;
const DEL_DRY_RUN: u32 = 16;

fn inMergeBases(rev: *cn.Commit, ref: *cn.Commit) bool {
    return reach.inMergeBasesChecked(rev, ref) catch os.exit(128);
}

fn branchMerged(kind: u32, name: []const u8, rev: *cn.Commit, head_rev: ?*cn.Commit) bool {
    var reference_rev: ?*cn.Commit = null;
    var reference_name: ?[]const u8 = null;
    if (kind == rf.FILTER_REFS_BRANCHES) {
        const b = rf.branchGet(name);
        if (rf.branchGetUpstream(b, null)) |up| {
            const r = refs.resolveFull(up, true);
            if (!r.missing and !r.broken) {
                reference_name = r.name;
                reference_rev = cn.lookupCommitReference(r.oid);
            }
        }
    }
    if (reference_rev == null) reference_rev = head_rev;
    const merged = if (reference_rev) |r| inMergeBases(rev, r) else false;
    if (head_rev) |hr| {
        if (hr != reference_rev) {
            const expect = inMergeBases(rev, hr);
            if (expect != merged) {
                if (merged) {
                    util.warn("deleting branch '{s}' that has been merged to\n         '{s}', but not yet merged to HEAD", .{ name, reference_name orelse "(null)" });
                } else {
                    util.warn("not deleting branch '{s}' that is not yet merged to\n         '{s}', even though it is merged to HEAD", .{ name, reference_name orelse "(null)" });
                }
            }
        }
    }
    return merged;
}

/// returns true on failure
fn checkBranchCommit(branchname: []const u8, refname: []const u8, oid: Oid, head_rev: ?*cn.Commit, kinds: u32, flags: u32) bool {
    const rev = cn.lookupCommitReference(oid);
    if (flags & DEL_FORCE == 0 and rev == null) {
        util.err("couldn't look up commit object for '{s}'", .{refname});
        return true;
    }
    if (flags & DEL_FORCE == 0 and !branchMerged(kinds, branchname, rev.?, head_rev)) {
        if (flags & DEL_SKIP_UNMERGED == 0) {
            util.err("the branch '{s}' is not fully merged", .{branchname});
            advice.adviseIfEnabled("forceDeleteBranch", util.fmt("If you are sure you want to delete it, run 'git branch -D {s}'", .{branchname}));
        }
        return true;
    }
    return false;
}

fn deleteBranchConfig(name: []const u8) void {
    if (config.renameSection(configPath(), util.concat(&.{ "branch.", name }), null) < 0)
        util.warn("update of config-file failed", .{});
    repo_mod.loadConfig();
}

fn branchBisecting(refname: []const u8) ?[]const u8 {
    for (worktree.getAllWithoutHead()) |wt| {
        const d = os.readFile(wt.gitPath("BISECT_START")) orelse continue;
        const t = util.trim(d);
        if (t.len > 0 and util.eql(util.concat(&.{ "refs/heads/", t }), refname)) return wt.path;
    }
    return null;
}

const Resolved = struct { target: []const u8, oid: Oid, symref: bool, broken: bool };

/// refs_resolve_refdup(name, READING|NO_RECURSE|ALLOW_BAD_NAME)
fn resolveNoRecurse(name: []const u8) ?Resolved {
    var bad = false;
    if (!refs.checkRefnameFormat(name, refs.ALLOW_ONELEVEL)) {
        if (!refs.refnameIsSafe(name)) return null;
        bad = true;
    }
    return switch (refs.readRawFull(name)) {
        .oid => |o| .{ .target = name, .oid = if (bad) hash.zero else o, .symref = false, .broken = bad },
        .symref => |t| .{ .target = t, .oid = hash.zero, .symref = true, .broken = false },
        else => null,
    };
}

fn deleteBranches(argv: []const []const u8, kinds: u32, flags0: u32) u8 {
    var flags = flags0;
    var fmt_prefix: []const u8 = undefined;
    var remote_branch = false;
    switch (kinds) {
        rf.FILTER_REFS_REMOTES => {
            fmt_prefix = "refs/remotes/";
            remote_branch = true;
            flags |= DEL_FORCE;
        },
        rf.FILTER_REFS_BRANCHES => fmt_prefix = "refs/heads/",
        else => util.die("cannot use -a with -d", .{}),
    }
    var head_rev: ?*cn.Commit = null;
    if (flags & DEL_FORCE == 0 and flags & DEL_NO_HEAD_FALLBACK == 0)
        head_rev = cn.lookupCommitReference(head_oid);
    var ret: u8 = 0;
    var names: std.ArrayList([]const u8) = .empty;
    var descs: std.ArrayList([]const u8) = .empty;
    for (argv) |arg| {
        const bname = revparse.interpretBranchName(arg);
        const name = util.concat(&.{ fmt_prefix, bname });
        if (kinds == rf.FILTER_REFS_BRANCHES) {
            if (branchBisecting(name)) |p| {
                util.err("cannot delete branch '{s}' used by worktree at '{s}' for bisect", .{ bname, p });
                ret = 1;
                continue;
            }
            if (bc.branchCheckedOut(name)) |p| {
                util.err("cannot delete branch '{s}' used by worktree at '{s}'", .{ bname, p });
                ret = 1;
                continue;
            }
        }
        const r = resolveNoRecurse(name) orelse {
            if (remote_branch) {
                util.err("remote-tracking branch '{s}' not found", .{bname});
            } else if (resolveNoRecurse(util.concat(&.{ "refs/remotes/", bname })) != null) {
                util.err("branch '{s}' not found.\nDid you forget --remote?", .{bname});
            } else util.err("branch '{s}' not found", .{bname});
            ret = 1;
            continue;
        };
        if (!r.symref and !r.broken and checkBranchCommit(bname, name, r.oid, head_rev, kinds, flags)) {
            if (flags & DEL_SKIP_UNMERGED == 0) ret = 1;
            continue;
        }
        names.append(gpa, name) catch util.oom();
        descs.append(gpa, if (r.broken) "broken" else if (r.symref) r.target else revparse.abbrev(r.oid, revparse.defaultAbbrev())) catch util.oom();
    }
    if (flags & DEL_DRY_RUN == 0 and !refs.deleteRefs(names.items, refs.F_NO_DEREF, null)) ret = 1;
    for (names.items, descs.items) |name, desc| {
        const short = name[fmt_prefix.len..];
        if (flags & DEL_DRY_RUN != 0) {
            if (flags & DEL_QUIET == 0) {
                if (remote_branch) {
                    util.outf("Would delete remote-tracking branch {s} (was {s}).\n", .{ short, desc });
                } else util.outf("Would delete branch {s} (was {s}).\n", .{ short, desc });
            }
        } else if (!refs.exists(name)) {
            if (flags & DEL_QUIET == 0) {
                if (remote_branch) {
                    util.outf("Deleted remote-tracking branch {s} (was {s}).\n", .{ short, desc });
                } else util.outf("Deleted branch {s} (was {s}).\n", .{ short, desc });
            }
            deleteBranchConfig(short);
        }
    }
    return ret;
}

// ---------------------------------------------------------------------------
// --delete-merged

/// Emulates the iteration order of git's strset (hashmap with FNV-1 strhash).
const StrSet = struct {
    size: usize = 64,
    table: std.ArrayList(std.ArrayList([]const u8)) = .empty, // each chain: head first
    count: usize = 0,

    fn strhash(s: []const u8) u32 {
        var h: u32 = 0x811c9dc5;
        for (s) |ch| h = (h *% 0x01000193) ^ ch;
        return h;
    }
    fn ensure(self: *StrSet) void {
        if (self.table.items.len == 0) {
            for (0..self.size) |_| self.table.append(gpa, .empty) catch util.oom();
        }
    }
    fn contains(self: *StrSet, s: []const u8) bool {
        self.ensure();
        const b = strhash(s) & @as(u32, @intCast(self.size - 1));
        for (self.table.items[b].items) |x| if (util.eql(x, s)) return true;
        return false;
    }
    fn pushHead(self: *StrSet, s: []const u8) void {
        const b = strhash(s) & @as(u32, @intCast(self.size - 1));
        self.table.items[b].insert(gpa, 0, s) catch util.oom();
    }
    fn add(self: *StrSet, s: []const u8) void {
        if (self.contains(s)) return;
        self.pushHead(s);
        self.count += 1;
        if (self.count > self.size * 80 / 100) {
            const old = self.table;
            self.size <<= 2;
            self.table = .empty;
            self.ensure();
            for (old.items) |chain| {
                for (chain.items) |e| self.pushHead(e);
            }
        }
    }
    fn remove(self: *StrSet, s: []const u8) void {
        self.ensure();
        const b = strhash(s) & @as(u32, @intCast(self.size - 1));
        const chain = &self.table.items[b];
        for (chain.items, 0..) |x, i| {
            if (util.eql(x, s)) {
                _ = chain.orderedRemove(i);
                self.count -= 1;
                return;
            }
        }
    }
    fn items(self: *StrSet) [][]const u8 {
        self.ensure();
        var l: std.ArrayList([]const u8) = .empty;
        for (self.table.items) |chain| l.appendSlice(gpa, chain.items) catch util.oom();
        return l.items;
    }
};

fn upstreamBranchName(name: []const u8) ?[]const u8 {
    const b = rf.branchGet(name);
    const up = rf.branchGetUpstream(b, null) orelse return null;
    return util.skipPrefix(up, "refs/heads/");
}

fn branchPushesToUpstream(b: *rf.Branch, upstream: []const u8) bool {
    var explicit = false;
    const remote = rf.remoteForBranch(b, &explicit);
    const push_refname: ?[]const u8 = if (repo_mod.cfg.getAll(util.concat(&.{ "remote.", remote, ".push" })).len > 0)
        rf.applyRefspecs(remote, "push", b.refname)
    else
        b.refname;
    const pr = push_refname orelse return false;
    const tracking = rf.applyRefspecs(remote, "fetch", pr) orelse return false;
    return util.eql(tracking, upstream);
}

fn deleteMergedBranches(upstreams: []const []const u8, argv: []const []const u8, flags: u32) u8 {
    var filter = rf.Filter{};
    for (upstreams) |u| {
        if (!rf.forkedAdd(&filter, u)) util.die("'{s}' is not a valid branch or pattern", .{u});
    }
    filter.kind = rf.FILTER_REFS_BRANCHES;
    filter.name_patterns = argv;
    const candidates = rf.filterRefs(&filter, filter.kind);
    var deletable = StrSet{};
    var protected = StrSet{};
    for (candidates) |it| {
        const bname = util.skipPrefix(it.refname, "refs/heads/") orelse util.die("BUG: filter returned non-branch ref '{s}'", .{it.refname});
        if (bc.branchCheckedOut(it.refname) != null) continue;
        const b = rf.branchGet(bname);
        const up = rf.branchGetUpstream(b, null) orelse continue;
        if (!refs.exists(up)) continue;
        if (branchPushesToUpstream(b, up)) continue;
        if (checkBranchCommit(bname, bname, it.objectname, null, rf.FILTER_REFS_BRANCHES, DEL_SKIP_UNMERGED)) continue;
        if (repo_mod.cfg.getBool(util.fmt("branch.{s}.deletemerged", .{bname}))) |v| {
            if (!v) {
                if (flags & DEL_QUIET == 0)
                    util.eprint("Skipping '{s}' (branch.{s}.deleteMerged is false)\n", .{ bname, bname });
                continue;
            }
        }
        deletable.add(bname);
    }
    // protect_stacked_branch_bases
    const iter = refs.iterate("refs/heads/", .{});
    for (iter) |r| {
        const bname = r.name["refs/heads/".len..];
        if (deletable.contains(bname)) continue;
        const ub = upstreamBranchName(bname) orelse continue;
        if (!deletable.contains(ub)) continue;
        protected.add(ub);
    }
    for (protected.items()) |p| deletable.remove(p);

    const to_delete = deletable.items();
    var ret: u8 = 0;
    if (to_delete.len > 0)
        ret = deleteBranches(to_delete, rf.FILTER_REFS_BRANCHES, DEL_SKIP_UNMERGED | DEL_NO_HEAD_FALLBACK | flags);
    if (ret == 0 and flags & DEL_DRY_RUN == 0) {
        // clear_deleted_upstreams
        for (protected.items()) |p| {
            const ub = upstreamBranchName(p) orelse continue;
            if (!deletable.contains(ub)) continue;
            _ = config.setInFileGently(configPath(), util.fmt("branch.{s}.merge", .{p}), null, null);
            _ = config.setInFileGently(configPath(), util.fmt("branch.{s}.remote", .{p}), null, null);
        }
        repo_mod.loadConfig();
    }
    return ret;
}

// ---------------------------------------------------------------------------
// listing

fn calcMaxwidth(items: []*rf.Item, remote_bonus: usize) usize {
    var max: usize = 0;
    for (items) |it| {
        var desc = it.refname;
        if (util.skipPrefix(desc, "refs/heads/")) |d| desc = d;
        if (util.skipPrefix(desc, "refs/remotes/")) |d| desc = d;
        var w: usize = undefined;
        if (it.kind == rf.FILTER_REFS_DETACHED_HEAD) {
            w = column.strWidth(rf.getHeadDescription());
        } else w = column.strWidth(desc);
        if (it.kind == rf.FILTER_REFS_REMOTES) w += remote_bonus;
        if (w > max) max = w;
    }
    return max;
}

fn quoteLiteral(s: []const u8) []const u8 {
    var b: Buf = .empty;
    for (s) |ch| {
        if (ch == '%') util.bufAppend(&b, "%%") else util.bufByte(&b, ch);
    }
    return b.items;
}

fn buildFormat(filter: *rf.Filter, maxwidth: usize, remote_prefix: []const u8) []const u8 {
    var local: Buf = .empty;
    var remote: Buf = .empty;
    util.bufAppend(&local, util.fmt("%(if)%(HEAD)%(then)* {s}%(else)%(if)%(worktreepath)%(then)+ {s}%(else)  {s}%(end)%(end)", .{ getColor(C_CURRENT), getColor(C_WORKTREE), getColor(C_LOCAL) }));
    util.bufAppend(&remote, util.fmt("  {s}", .{getColor(C_REMOTE)}));
    if (filter.verbose != 0) {
        const obname = if (filter.abbrev < 0)
            "%(objectname:short)"
        else if (filter.abbrev == 0)
            "%(objectname)"
        else
            util.fmt("%(objectname:short={d})", .{filter.abbrev});
        util.bufAppend(&local, util.fmt("%(align:{d},left)%(refname:lstrip=2)%(end)", .{maxwidth}));
        util.bufAppend(&local, getColor(C_RESET));
        util.bufAppend(&local, util.fmt(" {s} ", .{obname}));
        if (filter.verbose > 1) {
            util.bufAppend(&local, util.fmt("%(if:notequals=*)%(HEAD)%(then)%(if)%(worktreepath)%(then)({s}%(worktreepath){s}) %(end)%(end)", .{ getColor(C_WORKTREE), getColor(C_RESET) }));
            util.bufAppend(&local, util.fmt("%(if)%(upstream)%(then)[{s}%(upstream:short){s}%(if)%(upstream:track)%(then): %(upstream:track,nobracket)%(end)] %(end)%(contents:subject)", .{ getColor(C_UPSTREAM), getColor(C_RESET) }));
        } else {
            util.bufAppend(&local, "%(if)%(upstream:track)%(then)%(upstream:track) %(end)%(contents:subject)");
        }
        util.bufAppend(&remote, util.fmt("%(align:{d},left){s}%(refname:lstrip=2)%(end){s}%(if)%(symref)%(then) -> %(symref:short)%(else) {s} %(contents:subject)%(end)", .{ maxwidth, quoteLiteral(remote_prefix), getColor(C_RESET), obname }));
    } else {
        util.bufAppend(&local, util.fmt("%(refname:lstrip=2){s}%(if)%(symref)%(then) -> %(symref:short)%(end)", .{getColor(C_RESET)}));
        util.bufAppend(&remote, util.fmt("{s}%(refname:lstrip=2){s}%(if)%(symref)%(then) -> %(symref:short)%(end)", .{ quoteLiteral(remote_prefix), getColor(C_RESET) }));
    }
    return util.fmt("%(if:notequals=refs/remotes)%(refname:rstrip=-2)%(then){s}%(else){s}%(end)", .{ local.items, remote.items });
}

fn printRefList(filter: *rf.Filter, sorting: ?*rf.Sorting, format: *rf.Format) void {
    const remote_prefix: []const u8 = if (filter.kind != rf.FILTER_REFS_REMOTES) "remotes/" else "";
    const items = rf.filterRefs(filter, filter.kind);
    var maxwidth: usize = 0;
    if (filter.verbose != 0) maxwidth = calcMaxwidth(items, remote_prefix.len);
    if (format.format.len == 0) format.format = buildFormat(filter, maxwidth, remote_prefix);
    format.use_color = branch_use_color;
    if (!rf.verifyFormat(format)) util.die("unable to parse format string", .{});
    rf.filterAheadBehind(items);
    rf.sortItems(sorting, items);
    if (column.columnActive(colopts)) {
        var lines: std.ArrayList([]const u8) = .empty;
        for (items) |it| {
            var out: Buf = .empty;
            rf.formatItem(it, format, &out);
            lines.append(gpa, out.items) catch util.oom();
        }
        column.printColumns(lines.items, colopts, null);
    } else {
        rf.printFormattedArray(items, format);
    }
}

fn printCurrentBranchName() void {
    const r = refs.resolveFull("HEAD", false);
    if (r.broken) util.die("could not resolve HEAD", .{});
    if (r.flags & refs.REF_ISSYMREF == 0) return;
    if (util.skipPrefix(r.name, "refs/heads/")) |s| {
        util.outf("{s}\n", .{s});
    } else util.die("HEAD ({s}) points outside of refs/heads/", .{r.name});
}

// ---------------------------------------------------------------------------
// rename / copy

fn headNameFile(wt: *worktree.Worktree, f: []const u8) ?[]const u8 {
    const d = os.readFile(wt.gitPath(f)) orelse return null;
    return util.trim(d);
}

fn rejectRebaseOrBisectBranch(wts: []*worktree.Worktree, target: []const u8) void {
    for (wts) |wt| {
        if (!wt.is_detached) continue;
        for ([_][]const u8{ "rebase-apply/head-name", "rebase-merge/head-name" }) |f| {
            if (headNameFile(wt, f)) |hn| {
                if (util.eql(hn, target)) util.die("branch {s} is being rebased at {s}", .{ target, wt.path });
            }
        }
        if (headNameFile(wt, "BISECT_START")) |bs| {
            if (bs.len > 0 and util.eql(util.concat(&.{ "refs/heads/", bs }), target))
                util.die("branch {s} is being bisected at {s}", .{ target, wt.path });
        }
    }
}

fn replaceEachWorktreeHeadSymref(wts: []*worktree.Worktree, oldref: []const u8, newref: []const u8, logmsg: []const u8) bool {
    var failed = false;
    for (wts) |wt| {
        if (wt.is_detached) continue;
        const hr = wt.head_ref orelse continue;
        if (!util.eql(oldref, hr)) continue;
        if (wt.is_current) {
            refs.writeSymref("HEAD", newref, logmsg) catch {
                util.err("HEAD of working tree {s} is not updated", .{wt.path});
                failed = true;
            };
        } else {
            os.writeFile(wt.gitPath("HEAD"), util.concat(&.{ "ref: ", newref, "\n" }), 0o644) catch {
                util.err("HEAD of working tree {s} is not updated", .{wt.path});
                failed = true;
            };
        }
    }
    return failed;
}

fn copyOrRenameBranch(oldname: []const u8, newname: []const u8, copy: bool, force: bool) void {
    const wts = worktree.getAll();
    var recovery = false;
    const interp = revparse.interpretBranchName(oldname);
    const oldref = util.concat(&.{ "refs/heads/", interp });
    if (bc.checkBranchRef(oldname) == null) {
        if (refs.exists(oldref)) {
            recovery = true;
        } else {
            util.flushStdout();
            util.eprint("fatal: invalid branch name: '{s}'\n", .{oldname});
            advice.adviseIfEnabled("refSyntax", "See 'git help check-ref-format'");
            os.exit(128);
        }
    }
    var is_head = false;
    var is_orphan = false;
    for (wts) |wt| {
        if (wt.head_ref) |hr| {
            if (util.eql(oldref, hr)) {
                is_head = true;
                if (hash.isZero(wt.head_oid)) is_orphan = true;
                break;
            }
        }
    }
    if ((copy or !is_head) and !refs.exists(oldref)) {
        if (is_head) util.die("no commit on branch '{s}' yet", .{oldname});
        util.die("no branch named '{s}'", .{oldname});
    }
    var newref: []const u8 = "";
    if (util.eql(oldname, newname)) {
        _ = bc.validateBranchname(newname, &newref);
    } else _ = bc.validateNewBranchname(newname, &newref, force);
    rejectRebaseOrBisectBranch(wts, oldref);
    const i_old = oldref["refs/heads/".len..];
    const i_new = newref["refs/heads/".len..];
    const logmsg = if (copy)
        util.fmt("Branch: copied {s} to {s}", .{ oldref, newref })
    else
        util.fmt("Branch: renamed {s} to {s}", .{ oldref, newref });
    if (!copy and !is_orphan and !refs.renameRef(oldref, newref, logmsg, false)) util.die("branch rename failed", .{});
    if (copy and !refs.renameRef(oldref, newref, logmsg, true)) util.die("branch copy failed", .{});
    if (recovery) {
        if (copy) {
            util.warn("created a copy of a misnamed branch '{s}'", .{i_old});
        } else util.warn("renamed a misnamed branch '{s}' away", .{i_old});
    }
    if (!copy and is_head and replaceEachWorktreeHeadSymref(wts, oldref, newref, logmsg))
        util.die("branch renamed to {s}, but HEAD is not updated", .{newname});
    const oldsection = util.concat(&.{ "branch.", i_old });
    const newsection = util.concat(&.{ "branch.", i_new });
    if (!copy and config.renameSection(configPath(), oldsection, newsection) < 0)
        util.die("branch is renamed, but update of config-file failed", .{});
    if (copy and !util.eql(i_old, i_new) and config.copySection(configPath(), oldsection, newsection) < 0)
        util.die("branch is copied, but update of config-file failed", .{});
    repo_mod.loadConfig();
}

// ---------------------------------------------------------------------------
// --edit-description

fn commentedAdd(b: *Buf, text: []const u8, prefix: []const u8) void {
    var rest = text;
    while (rest.len > 0) {
        const nl = std.mem.indexOfScalar(u8, rest, '\n');
        const end = if (nl) |x| x + 1 else rest.len;
        util.bufAppend(b, prefix);
        if (rest[0] != '\n' and rest[0] != '\t') util.bufByte(b, ' ');
        util.bufAppend(b, rest[0..end]);
        rest = rest[end..];
    }
    if (b.items.len > 0 and b.items[b.items.len - 1] != '\n') util.bufByte(b, '\n');
}

/// returns true on failure
fn editBranchDescription(name: []const u8) bool {
    const key = util.fmt("branch.{s}.description", .{name});
    const existing = repo_mod.cfg.get(key);
    const exists = existing != null;
    var buf: Buf = .empty;
    if (existing) |d| util.bufAppend(&buf, d);
    if (buf.items.len == 0 or buf.items[buf.items.len - 1] != '\n') util.bufByte(&buf, '\n');
    const cstr = trailer_cfg.commentLineStr();
    commentedAdd(&buf, util.fmt("Please edit the description for the branch\n  {s}\nLines starting with '{s}' will be stripped.\n", .{ name, cstr }), cstr);
    const path = repo_mod.repo().gitPath("EDIT_DESCRIPTION");
    os.writeFile(path, buf.items, 0o666) catch util.die("could not write to '{s}'", .{path});
    if (editor.launch(path, &.{})) return true;
    const content = os.readFile(path) orelse {
        util.err("could not read file '{s}': {s}", .{ path, os.lastErr() });
        return true;
    };
    const s = util.stripspace(content, cstr);
    if (s.len > 0 or exists) {
        const rc = config.setInFileGently(configPath(), key, null, if (s.len > 0) s else null);
        if (rc != 0 and !(rc == 5 and s.len == 0)) {
            if (s.len > 0) util.die("could not set '{s}' to '{s}'", .{ key, s });
            util.die("could not unset '{s}'", .{key});
        }
        repo_mod.loadConfig();
    }
    return false;
}

fn remoteIsConfigured(name: []const u8) bool {
    for (bc.remoteNames()) |r| {
        if (util.eql(r, name)) return true;
    }
    return false;
}

fn dieIfUpstreamLooksLikeRemote(new_upstream: []const u8, branch_name: []const u8) void {
    if (std.mem.indexOfScalar(u8, new_upstream, '/') != null or !remoteIsConfigured(new_upstream)) return;
    if (!refs.exists(util.fmt("refs/remotes/{s}/{s}", .{ new_upstream, branch_name }))) return;
    util.flushStdout();
    util.eprint("fatal: --set-upstream-to takes a single <remote>/<branch> argument\n", .{});
    advice.adviseIfEnabled("setUpstreamFailure", util.fmt("Did you mean to use: git branch --set-upstream-to={s}/{s}?", .{ new_upstream, branch_name }));
    os.exit(128);
}

/// branch_get(): null when name refers to a detached HEAD.
fn branchGetOrCurrent(name: ?[]const u8) ?*rf.Branch {
    if (name == null or name.?.len == 0 or util.eql(name.?, "HEAD")) {
        const h = refs.resolveFull("HEAD", false);
        if (h.flags & refs.REF_ISSYMREF == 0) return null;
        const short = util.skipPrefix(h.name, "refs/heads/") orelse return null;
        return rf.branchGet(short);
    }
    return rf.branchGet(name.?);
}

// ---------------------------------------------------------------------------
// option callbacks

var track_ptr: *i32 = undefined;
var abbrev_ptr: *i32 = undefined;
var forked_filter: *rf.Filter = undefined;

fn trackCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        track_ptr.* = @intFromEnum(bc.Track.never);
    } else if (arg == null or util.eql(arg.?, "direct")) {
        track_ptr.* = @intFromEnum(bc.Track.explicit);
    } else if (util.eql(arg.?, "inherit")) {
        track_ptr.* = @intFromEnum(bc.Track.inherit);
    } else {
        util.err("option `{s}' expects \"{s}\" or \"{s}\"", .{ "--track", "direct", "inherit" });
        os.exit(129);
    }
}

fn abbrevCb(arg: ?[]const u8, unset: bool) void {
    const a = arg orelse {
        abbrev_ptr.* = if (unset) 0 else -1;
        return;
    };
    const v = std.fmt.parseInt(i64, a, 10) catch {
        util.err("option `abbrev' expects a numerical value", .{});
        os.exit(129);
    };
    var x: i32 = @intCast(std.math.clamp(v, -1, 1000));
    if (x != 0 and x < 4) {
        x = 4;
    } else if (x > 40) x = 40;
    abbrev_ptr.* = x;
}

fn forkedCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse return;
    if (!rf.forkedAdd(forked_filter, a)) util.die("'{s}' is not a valid branch or pattern", .{a});
}

fn columnCb(arg: ?[]const u8, unset: bool) void {
    if (!column.parseoptColumn(&colopts, arg, unset)) os.exit(129);
}

// ---------------------------------------------------------------------------

pub fn cmdBranch(args: []const []const u8) u8 {
    var filter = rf.Filter{};
    var format = rf.Format{};
    rf.cur_filter = &filter;
    rf.cur_color = &branch_use_color;
    forked_filter = &filter;
    filter.abbrev = -1;

    var delete: i32 = 0;
    var rename: i32 = 0;
    var copy: i32 = 0;
    var list = false;
    var unset_upstream = false;
    var show_current = false;
    var edit_description = false;
    var delete_merged: std.ArrayList([]const u8) = .empty;
    var dry_run = false;
    var new_upstream: ?[]const u8 = null;
    var reflog = false;
    var quiet: i32 = 0;
    var icase = false;
    var force: i32 = 0;
    var recurse_explicit = false;
    var kind: i32 = @intCast(rf.FILTER_REFS_BRANCHES);
    var track: i32 = 0;
    var fmt_s: ?[]const u8 = null;
    var sort_opts: std.ArrayList([]const u8) = .empty;
    track_ptr = &track;
    abbrev_ptr = &filter.abbrev;

    const opts = [_]po.Opt{
        po.group("Generic options"),
        .{ .short = 'v', .long = "verbose", .kind = .counter, .i = &filter.verbose, .help = "show hash and subject, give twice for upstream branch" },
        .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet, .help = "suppress informational messages" },
        .{ .short = 't', .long = "track", .kind = .callback, .cb = trackCb, .argh = "(direct|inherit)", .literal_argh = true, .help = "set branch tracking configuration", .optarg = true },
        .{ .long = "set-upstream", .kind = .set_int, .i = &track, .val = @intFromEnum(bc.Track.override), .help = "do not use", .hidden = true },
        po.string('u', "set-upstream-to", &new_upstream, "upstream", "change the upstream info"),
        po.boolean(0, "unset-upstream", &unset_upstream, "unset the upstream info"),
        rf.colorOpt("use colored output"),
        .{ .short = 'r', .long = "remotes", .kind = .set_int, .i = &kind, .val = @intCast(rf.FILTER_REFS_REMOTES), .help = "act on remote-tracking branches", .noneg = true },
        rf.containsOpt("contains", "print only branches that contain the commit", false),
        rf.containsOpt("no-contains", "print only branches that don't contain the commit", false),
        rf.containsOpt("with", "print only branches that contain the commit", true),
        rf.containsOpt("without", "print only branches that don't contain the commit", true),
        .{ .long = "abbrev", .kind = .callback, .cb = abbrevCb, .optarg = true, .argh = "n", .help = "use <n> digits to display object names" },
        po.group("Specific git-branch actions:"),
        .{ .short = 'a', .long = "all", .kind = .set_int, .i = &kind, .val = @intCast(rf.FILTER_REFS_REMOTES | rf.FILTER_REFS_BRANCHES), .help = "list both remote-tracking and local branches", .noneg = true },
        po.bit('d', "delete", &delete, 1, "delete fully merged branch"),
        po.bit('D', "", &delete, 2, "delete branch (even if not merged)"),
        po.bit('m', "move", &rename, 1, "move/rename a branch and its reflog"),
        po.bit('M', "", &rename, 2, "move/rename a branch, even if target exists"),
        po.boolean(0, "omit-empty", &format.omit_empty, "do not output a newline after empty formatted refs"),
        po.bit('c', "copy", &copy, 1, "copy a branch and its reflog"),
        po.bit('C', "", &copy, 2, "copy a branch, even if target exists"),
        po.boolean('l', "list", &list, "list branch names"),
        po.boolean(0, "show-current", &show_current, "show current branch name"),
        po.boolean(0, "create-reflog", &reflog, "create the branch's reflog"),
        po.boolean(0, "edit-description", &edit_description, "edit the description for the branch"),
        .{ .long = "delete-merged", .kind = .list, .l = &delete_merged, .argh = "pattern", .help = "delete merged branches whose upstream matches <pattern> (repeatable)", .noneg = true },
        po.boolean(0, "dry-run", &dry_run, "with --delete-merged, only print which branches would be deleted"),
        .{ .short = 'f', .long = "force", .kind = .counter, .i = &force, .help = "force creation, move/rename, deletion" },
        rf.mergedOpt("merged", "print only branches that are merged"),
        rf.mergedOpt("no-merged", "print only branches that are not merged"),
        .{ .long = "forked", .kind = .callback, .cb = forkedCb, .argh = "branch", .help = "print only branches whose upstream matches <branch> (repeatable)", .noneg = true },
        .{ .long = "column", .kind = .callback, .cb = columnCb, .argh = "style", .help = "list branches in columns", .optarg = true },
        po.list(0, "sort", &sort_opts, "key", "field name to sort on"),
        .{ .long = "points-at", .kind = .callback, .cbx = rf.parseOptPointsAt, .argh = "object", .help = "print only branches of the object" },
        po.boolean('i', "ignore-case", &icase, "sorting and filtering are case insensitive"),
        po.boolean(0, "recurse-submodules", &recurse_explicit, "recurse through submodules"),
        po.string(0, "format", &fmt_s, "format", "format to use for the output"),
    };

    if (args.len == 2 and util.eql(args[1], "-h")) _ = po.parse(args[1..], &opts, &branch_usage, .{});

    var submodule_propagate = false;
    var recurse_submodules = false;
    readConfig(&sort_opts, &submodule_propagate, &recurse_submodules);
    if (sort_opts.items.len == 0) sort_opts.append(gpa, "refname") catch util.oom();
    track = @intFromEnum(bc.configBranchTrack());

    const h = refs.resolveFull("HEAD", false);
    if (h.broken) util.die("failed to resolve HEAD as a valid ref", .{});
    head_oid = h.oid;
    if (util.eql(h.name, "HEAD")) {
        filter.detached = true;
        head = "HEAD";
    } else {
        head = util.skipPrefix(h.name, "refs/heads/") orelse util.die("HEAD not found below refs/heads!", .{});
    }

    const argv = po.parse(args[1..], &opts, &branch_usage, .{});
    filter.kind = @intCast(kind);
    if (fmt_s) |f| format.format = f;

    if (delete == 0 and rename == 0 and copy == 0 and !edit_description and new_upstream == null and
        !show_current and !unset_upstream and delete_merged.items.len == 0 and argv.len == 0)
        list = true;
    if (filter.with_commit != null or filter.no_commit != null or filter.reachable_from != null or
        filter.unreachable_from != null or filter.points_at.items.len > 0 or filter.forked.items.len > 0)
        list = true;

    const noncreate: i32 = @as(i32, @intFromBool(delete != 0)) + @intFromBool(rename != 0) + @intFromBool(copy != 0) +
        @intFromBool(new_upstream != null) + @intFromBool(show_current) + @intFromBool(list) +
        @intFromBool(edit_description) + @intFromBool(unset_upstream) + @intFromBool(delete_merged.items.len > 0);
    if (noncreate > 1) po.usageWithOptions(&branch_usage, &opts);
    if (dry_run and delete_merged.items.len == 0) util.die("--dry-run requires --delete-merged", .{});

    if (recurse_explicit) {
        if (!submodule_propagate) util.die("branch with --recurse-submodules can only be used if submodule.propagateBranches is enabled", .{});
        if (noncreate != 0) util.die("--recurse-submodules can only be used to create branches", .{});
    }
    recurse_submodules = (recurse_submodules or recurse_explicit) and submodule_propagate;
    filter.ignore_case = icase;

    column.finalizeColopts(&colopts, -1);
    if (filter.verbose != 0) {
        if (column.explicitlyEnabled(colopts)) util.die("options '{s}' and '{s}' cannot be used together", .{ "--column", "--verbose" });
        colopts = 0;
    }

    if (force != 0) {
        delete *= 2;
        rename *= 2;
        copy *= 2;
    }

    if (branch_use_color == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| branch_use_color = color_mod.configColorBool("color.ui", e.value);
    }

    if (list) {
        const pc = repo_mod.cfg.getBool("pager.branch");
        if (@import("../main.zig").use_pager orelse (pc orelse true)) @import("../commands.zig").setupPager();
    }
    want_color = color_mod.wantColorBool(branch_use_color, null);

    if (delete != 0) {
        if (argv.len == 0) util.die("branch name required", .{});
        return deleteBranches(argv, filter.kind, (if (delete > 1) DEL_FORCE else 0) | (if (quiet != 0) DEL_QUIET else 0));
    } else if (delete_merged.items.len > 0) {
        return deleteMergedBranches(delete_merged.items, argv, (if (quiet != 0) DEL_QUIET else 0) | (if (dry_run) DEL_DRY_RUN else 0));
    } else if (show_current) {
        printCurrentBranchName();
        return 0;
    } else if (list) {
        if (filter.kind & rf.FILTER_REFS_BRANCHES != 0 and filter.detached)
            filter.kind |= rf.FILTER_REFS_DETACHED_HEAD;
        filter.name_patterns = argv;
        const sorting = rf.sortingOptions(sort_opts.items);
        rf.setSortFlagsAll(sorting, rf.SORT_ICASE, icase);
        rf.setSortFlagsAll(sorting, rf.SORT_DETACHED_HEAD_FIRST, true);
        printRefList(&filter, sorting, &format);
        return 0;
    } else if (edit_description) {
        var branch_name: []const u8 = undefined;
        if (argv.len == 0) {
            if (filter.detached) util.die("cannot give description to detached HEAD", .{});
            branch_name = head;
        } else if (argv.len == 1) {
            branch_name = revparse.interpretBranchName(argv[0]);
        } else util.die("cannot edit description of more than one branch", .{});
        const bref = util.concat(&.{ "refs/heads/", branch_name });
        if (!refs.exists(bref)) {
            if (argv.len == 0 or bc.branchCheckedOut(bref) != null) {
                util.err("no commit on branch '{s}' yet", .{branch_name});
            } else util.err("no branch named '{s}'", .{branch_name});
            return 1;
        }
        return if (editBranchDescription(branch_name)) 1 else 0;
    } else if (copy != 0 or rename != 0) {
        if (argv.len == 0) {
            util.die("branch name required", .{});
        } else if (argv.len == 1 and filter.detached) {
            if (copy != 0) util.die("cannot copy the current branch while not on any", .{});
            util.die("cannot rename the current branch while not on any", .{});
        } else if (argv.len == 1) {
            copyOrRenameBranch(head, argv[0], copy != 0, copy + rename > 1);
        } else if (argv.len == 2) {
            copyOrRenameBranch(argv[0], argv[1], copy != 0, copy + rename > 1);
        } else {
            if (copy != 0) util.die("too many branches for a copy operation", .{});
            util.die("too many arguments for a rename operation", .{});
        }
    } else if (new_upstream) |nu| {
        var b: ?*rf.Branch = null;
        if (argv.len == 0) {
            b = branchGetOrCurrent(null);
        } else if (argv.len == 1) {
            b = branchGetOrCurrent(revparse.interpretBranchName(argv[0]));
        } else util.die("too many arguments to set new upstream", .{});
        const br = b orelse {
            if (argv.len == 0 or util.eql(argv[0], "HEAD"))
                util.die("could not set upstream of HEAD to {s} when it does not point to any branch", .{nu});
            util.die("no such branch '{s}'", .{argv[0]});
        };
        if (!refs.exists(br.refname)) {
            if (argv.len == 0 or bc.branchCheckedOut(br.refname) != null)
                util.die("no commit on branch '{s}' yet", .{br.name});
            if (argv.len == 1 and advice.enabled("setUpstreamFailure")) dieIfUpstreamLooksLikeRemote(nu, argv[0]);
            util.die("branch '{s}' does not exist", .{br.name});
        }
        bc.dwimAndSetupTracking(br.name, nu, .override, quiet != 0);
    } else if (unset_upstream) {
        var b: ?*rf.Branch = null;
        if (argv.len == 0) {
            b = branchGetOrCurrent(null);
        } else if (argv.len == 1) {
            b = branchGetOrCurrent(revparse.interpretBranchName(argv[0]));
        } else util.die("too many arguments to unset upstream", .{});
        const br = b orelse {
            if (argv.len == 0 or util.eql(argv[0], "HEAD"))
                util.die("could not unset upstream of HEAD when it does not point to any branch", .{});
            util.die("no such branch '{s}'", .{argv[0]});
        };
        if (repo_mod.cfg.getAll(util.fmt("branch.{s}.merge", .{br.name})).len == 0)
            util.die("branch '{s}' has no upstream information", .{br.name});
        for ([_][]const u8{ "remote", "merge" }) |what| {
            const key = util.fmt("branch.{s}.{s}", .{ br.name, what });
            if (config.setMultivarInFile(configPath(), key, null, .any, null, .{ .multi_replace = true }) != 0)
                util.die("could not unset '{s}'", .{key});
        }
        repo_mod.loadConfig();
    } else if (noncreate == 0 and argv.len > 0 and argv.len <= 2) {
        const branch_name = argv[0];
        const start_name = if (argv.len == 2) argv[1] else head;
        if (filter.kind != rf.FILTER_REFS_BRANCHES)
            util.die("the -a, and -r, options to 'git branch' do not take a branch name.\nDid you mean to use: -a|-r --list <pattern>?", .{});
        if (track == @intFromEnum(bc.Track.override))
            util.die("the '--set-upstream' option is no longer supported. Please use '--track' or '--set-upstream-to' instead", .{});
        bc.createBranch(branch_name, start_name, force != 0, false, reflog, quiet != 0, @enumFromInt(track), false);
    } else po.usageWithOptions(&branch_usage, &opts);
    return 0;
}
