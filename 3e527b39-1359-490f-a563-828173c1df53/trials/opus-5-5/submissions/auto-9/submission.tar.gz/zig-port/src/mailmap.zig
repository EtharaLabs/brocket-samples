//! Port of mailmap.c: reading .mailmap / mailmap.file / mailmap.blob and mapping
//! identities. Keys (emails, names) are matched case-insensitively.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const revparse = @import("revparse.zig");
const gpa = util.gpa;

const Info = struct {
    name: ?[]const u8 = null,
    email: ?[]const u8 = null,
};

const Entry = struct {
    /// simple (email-only) mapping
    name: ?[]const u8 = null,
    email: ?[]const u8 = null,
    /// complex mapping keyed by lowercased old name
    namemap: std.StringHashMapUnmanaged(Info) = .empty,
};

pub const Map = struct {
    /// keyed by lowercased old email
    entries: std.StringHashMapUnmanaged(*Entry) = .empty,

    pub fn count(self: *const Map) usize {
        return self.entries.count();
    }

    pub fn addMapping(self: *Map, new_name: ?[]const u8, new_email0: ?[]const u8, old_name: ?[]const u8, old_email0: ?[]const u8) void {
        var new_email = new_email0;
        var old_email = old_email0;
        if (old_email == null) {
            old_email = new_email;
            new_email = null;
        }
        const key = util.lower(old_email.?);
        const gop = self.entries.getOrPut(gpa, key) catch util.oom();
        if (!gop.found_existing) {
            const e = gpa.create(Entry) catch util.oom();
            e.* = .{};
            gop.value_ptr.* = e;
        }
        const me = gop.value_ptr.*;
        if (old_name == null) {
            if (new_name) |n| me.name = util.dupe(n);
            if (new_email) |e| me.email = util.dupe(e);
        } else {
            const nk = util.lower(old_name.?);
            me.namemap.put(gpa, nk, .{
                .name = if (new_name) |n| util.dupe(n) else null,
                .email = if (new_email) |e| util.dupe(e) else null,
            }) catch util.oom();
        }
    }

    /// Read mailmap lines from a buffer.
    pub fn readString(self: *Map, buf: []const u8) void {
        var it = std.mem.splitScalar(u8, buf, '\n');
        while (it.next()) |line| {
            if (line.len == 0 and it.index == null) break;
            self.readLine(line);
        }
    }

    fn readLine(self: *Map, buffer: []const u8) void {
        if (buffer.len > 0 and buffer[0] == '#') return;
        const r1 = parseNameAndEmail(buffer, false) orelse return;
        var name2: ?[]const u8 = null;
        var email2: ?[]const u8 = null;
        if (r1.rest) |rest| {
            if (parseNameAndEmail(rest, true)) |r2| {
                name2 = r2.name;
                email2 = r2.email;
            }
        }
        self.addMapping(r1.name, r1.email, name2, email2);
    }

    /// Read a mailmap file; missing files are ignored.
    pub fn readFile(self: *Map, path: []const u8, nofollow: bool) void {
        if (nofollow) {
            if (os.lstatPath(path)) |st| {
                if (st.isLnk()) {
                    util.err("unable to open mailmap at {s}: Too many levels of symbolic links", .{path});
                    return;
                }
            }
        }
        const data = os.readFile(path) orelse {
            if (os.errno() == os.ENOENT or !os.exists(path)) return;
            util.err("unable to open mailmap at {s}: {s}", .{ path, os.lastErr() });
            return;
        };
        // emulate fgets() with a 1024-byte buffer: overlong lines are split
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line0| {
            if (line0.len == 0 and it.index == null) break;
            var line = line0;
            while (line.len > 1022) {
                self.readLine(line[0..1023]);
                line = line[1023..];
            }
            self.readLine(line);
        }
    }

    pub fn readBlob(self: *Map, name: []const u8) void {
        const oid = revparse.getOid(name) orelse return;
        const obj = repo_mod.repo().odb().read(oid) orelse {
            util.err("unable to read mailmap object at {s}", .{name});
            return;
        };
        if (obj.typ != .blob) {
            util.err("mailmap is not a blob: {s}", .{name});
            return;
        }
        self.readString(obj.data);
    }

    /// map_user: returns the replacement (name, email) if the identity is mapped.
    pub fn mapUser(self: *Map, name: []const u8, email: []const u8) ?Mapped {
        return mapUserImpl(self, name, email);
    }
};

pub const Mapped = struct { name: []const u8, email: []const u8 };

const Parsed = struct { name: ?[]const u8, email: []const u8, rest: ?[]const u8 };

fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r';
}

fn parseNameAndEmail(buffer: []const u8, allow_empty_email: bool) ?Parsed {
    const left = std.mem.indexOfScalar(u8, buffer, '<') orelse return null;
    const right = std.mem.indexOfScalarPos(u8, buffer, left + 1, '>') orelse return null;
    if (!allow_empty_email and left + 1 == right) return null;
    var nstart: usize = 0;
    while (nstart < left and isSpace(buffer[nstart])) nstart += 1;
    var nend: isize = @as(isize, @intCast(left)) - 1;
    while (nend > @as(isize, @intCast(nstart)) and isSpace(buffer[@intCast(nend)])) nend -= 1;
    const name: ?[]const u8 = if (@as(isize, @intCast(nstart)) <= nend) buffer[nstart..@intCast(nend + 1)] else null;
    const email = buffer[left + 1 .. right];
    const rest: ?[]const u8 = if (right + 1 < buffer.len) buffer[right + 1 ..] else null;
    return .{ .name = name, .email = email, .rest = rest };
}

fn lowerTmp(s: []const u8, buf: []u8) ?[]const u8 {
    if (s.len > buf.len) return null;
    for (s, 0..) |ch, i| buf[i] = std.ascii.toLower(ch);
    return buf[0..s.len];
}

fn mapUserImpl(m: *Map, name: []const u8, email: []const u8) ?Mapped {
    if (m.entries.count() == 0) return null;
    const ekey = util.lower(email);
    const me = m.entries.get(ekey) orelse return null;
    var info = Info{ .name = me.name, .email = me.email };
    if (me.namemap.count() > 0) {
        const nkey = util.lower(name);
        if (me.namemap.get(nkey)) |sub| info = sub;
    }
    if (info.name == null and info.email == null) return null;
    return .{ .name = info.name orelse name, .email = info.email orelse email };
}

/// map_user on a Map.
pub fn mapUser(m: *Map, name: []const u8, email: []const u8) ?Mapped {
    return mapUserImpl(m, name, email);
}

/// read_mailmap(): .mailmap in the worktree (unless bare), mailmap.blob (default
/// HEAD:.mailmap in bare repositories), and mailmap.file.
pub fn readMailmapInto(m: *Map) void {
    const cfg = &repo_mod.cfg;
    const mailmap_file = cfg.getPath("mailmap.file");
    var mailmap_blob = cfg.get("mailmap.blob");
    const have_repo = repo_mod.repo_ != null;
    const bare = if (repo_mod.repo_) |r| r.work_tree == null else false;
    if (mailmap_blob == null and bare) mailmap_blob = "HEAD:.mailmap";
    if (!have_repo or !bare) m.readFile(".mailmap", have_repo);
    if (have_repo) {
        if (mailmap_blob) |b| m.readBlob(b);
    }
    if (mailmap_file) |f| m.readFile(f, false);
}

var global_map: ?*Map = null;

/// Read (once) and return the repository's mailmap.
pub fn readMailmap() *Map {
    if (global_map) |g| return g;
    const m = gpa.create(Map) catch util.oom();
    m.* = .{};
    readMailmapInto(m);
    global_map = m;
    return m;
}

/// Fresh (uncached) map.
pub fn newMap() *Map {
    const m = gpa.create(Map) catch util.oom();
    m.* = .{};
    return m;
}
