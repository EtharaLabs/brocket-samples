//! git rm

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const dir_mod = @import("../dir.zig");
const advice = @import("../advice.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git rm [-f | --force] [-n] [-r] [--cached] [--ignore-unmatch]\n" ++
        "       [--quiet] [--pathspec-from-file=<file> [--pathspec-file-nul]]\n" ++
        "       [--] [<pathspec>...]",
};

var show_only = false;
var force: i32 = 0;
var index_only = false;
var recursive = false;
var quiet: i32 = 0;
var ignore_unmatch = false;
var include_sparse = false;
var pathspec_from_file: ?[]const u8 = null;
var pathspec_file_nul = false;

const options = [_]po.Opt{
    po.boolean('n', "dry-run", &show_only, "dry run"),
    .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet, .help = "do not list removed files" },
    po.boolean(0, "cached", &index_only, "only remove from the index"),
    po.counter('f', "force", &force, "override the up-to-date check"),
    po.boolean('r', "", &recursive, "allow recursive removal"),
    po.boolean(0, "ignore-unmatch", &ignore_unmatch, "exit with a zero status even if nothing matched"),
    po.boolean(0, "sparse", &include_sparse, "allow updating entries outside of the sparse-checkout cone"),
    po.filename(0, "pathspec-from-file", &pathspec_from_file, "file", "read pathspec from file"),
    po.boolean(0, "pathspec-file-nul", &pathspec_file_nul, "with --pathspec-from-file, pathspec elements are separated with NUL character"),
};

const Item = struct { name: []const u8, is_submodule: bool };

fn oursPos(idx: *index_mod.Index, path: []const u8) ?usize {
    var p = idx.firstPos(path);
    while (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, path)) : (p += 1) {
        if (idx.entries.items[p].stage() == 2) return p;
    }
    return null;
}

fn printErrorFiles(files: []const []const u8, main_msg: []const u8, hints: []const u8, errs: *bool) void {
    if (files.len == 0) return;
    var b: util.Buf = .empty;
    util.bufAppend(&b, main_msg);
    for (files) |f| util.bufPrint(&b, "\n    {s}", .{f});
    if (advice.enabled("rmHints")) util.bufAppend(&b, hints);
    util.err("{s}", .{b.items});
    errs.* = true;
}

fn checkLocalMod(idx: *index_mod.Index, head_tree: ?hash.Oid, list: []const Item) bool {
    var staged: std.ArrayList([]const u8) = .empty;
    var cached: std.ArrayList([]const u8) = .empty;
    var local: std.ArrayList([]const u8) = .empty;
    for (list) |item| {
        const name = item.name;
        const pos = idx.findPos(name) orelse blk: {
            const p = oursPos(idx, name) orelse continue;
            if (idx.entries.items[p].mode != 0o160000 or dir_mod.isEmptyDir(name)) continue;
            break :blk p;
        };
        const ce = &idx.entries.items[pos];
        const st = os.lstatPath(ce.path) orelse continue;
        if (st.isDir() and ce.mode != 0o160000) continue;
        const local_changes = idx.matchStat(ce, st, false) != 0;
        var staged_changes = true;
        if (head_tree) |t| {
            if (objects.treeLookup(t, name)) |te| {
                if (te.mode == ce.mode and hash.eql(te.oid, ce.oid)) staged_changes = false;
            }
        }
        if (local_changes and staged_changes) {
            if (!index_only or !ce.intentToAdd()) staged.append(gpa, name) catch util.oom();
        } else if (!index_only) {
            if (staged_changes) cached.append(gpa, name) catch util.oom();
            if (local_changes) local.append(gpa, name) catch util.oom();
        }
    }
    var errs = false;
    printErrorFiles(staged.items, if (staged.items.len == 1)
        "the following file has staged content different from both the\nfile and the HEAD:"
    else
        "the following files have staged content different from both the\nfile and the HEAD:", "\n(use -f to force removal)", &errs);
    printErrorFiles(cached.items, if (cached.items.len == 1)
        "the following file has changes staged in the index:"
    else
        "the following files have changes staged in the index:", "\n(use --cached to keep the file, or -f to force removal)", &errs);
    printErrorFiles(local.items, if (local.items.len == 1)
        "the following file has local modifications:"
    else
        "the following files have local modifications:", "\n(use --cached to keep the file, or -f to force removal)", &errs);
    return errs;
}

pub fn cmdRm(args: []const []const u8) u8 {
    const rest = po.parse(args[1..], &options, &usage, .{});
    const r = repo_mod.repo();
    const ps_flags = pathspec_mod.Flags{ .prefer_cwd = true };
    var ps = pathspec_mod.parse(r.prefix, rest, ps_flags);
    if (pathspec_from_file) |pf| {
        if (ps.items.len > 0) util.die("'{s}' and pathspec arguments cannot be used together", .{"--pathspec-from-file"});
        ps = pathspec_mod.parse(r.prefix, pathspec_mod.readPathspecFile(pf, pathspec_file_nul), ps_flags);
    } else if (pathspec_file_nul) {
        util.die("the option '{s}' requires '{s}'", .{ "--pathspec-file-nul", "--pathspec-from-file" });
    }
    if (ps.items.len == 0) util.die("No pathspec was given. Which files should I remove?", .{});
    if (!index_only) _ = repo_mod.requireWorkTree("rm");

    const idx = index_mod.lockAndRead();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET | index_mod.REFRESH_UNMERGED, @as(?*const pathspec_mod.Pathspec, &ps), null);
    const seen = ps.newSeen();
    var list: std.ArrayList(Item) = .empty;
    for (idx.entries.items) |*e| {
        if (!include_sparse and e.skipWorktree()) continue;
        if (ps.matchSeen(e.path, e.mode == 0o160000, seen) == 0) continue;
        if (list.items.len > 0 and util.eql(list.items[list.items.len - 1].name, e.path)) continue;
        list.append(gpa, .{ .name = e.path, .is_submodule = e.mode == 0o160000 }) catch util.oom();
    }
    const ret: u8 = 0;
    {
        var seen_any = false;
        for (ps.items, 0..) |it, i| {
            const original = it.original;
            if (seen[i] != 0) {
                seen_any = true;
            } else if (ignore_unmatch) {
                continue;
            } else {
                util.die("pathspec '{s}' did not match any files", .{original});
            }
            if (!recursive and seen[i] == pathspec_mod.MATCHED_RECURSIVELY)
                util.die("not removing '{s}' recursively without -r", .{if (original.len > 0) original else "."});
        }
        if (!seen_any) {
            idx.rollback();
            os.exit(ret);
        }
    }
    if (force == 0) {
        var head_tree: ?hash.Oid = null;
        if (revparse.getCommit("HEAD")) |h| {
            if (objects.readCommit(h)) |c| head_tree = c.tree;
        }
        if (checkLocalMod(idx, head_tree, list.items)) {
            idx.rollback();
            os.exit(1);
        }
    }
    for (list.items) |item| {
        if (quiet == 0) util.outf("rm '{s}'\n", .{item.name});
        _ = idx.removePath(item.name);
        idx.invalidatePath(item.name);
        idx.changed = true;
    }
    if (show_only) {
        idx.rollback();
        return 0;
    }
    if (!index_only) {
        var removed = false;
        for (list.items) |item| {
            if (item.is_submodule) {
                if (os.isDir(item.name)) os.removeTree(item.name);
                removed = true;
                continue;
            }
            if (index_mod.removeWorktreePath(item.name)) {
                removed = true;
                continue;
            }
            if (!removed) util.dieErrno("git rm: '{s}'", .{item.name});
        }
    }
    if (idx.changed) idx.write() else idx.rollback();
    return ret;
}
