//! Port of pretty.c (commit pretty-printing and --format placeholders),
//! plus the parts of utf8.c it needs (display widths, wrapping, encodings).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const revision = @import("revision.zig");
const revparse = @import("revparse.zig");
const cn = @import("commitnode.zig");
const hash = @import("hash.zig");
const date_mod = @import("date.zig");
const color_mod = @import("color.zig");
const config_mod = @import("config.zig");
const reflogwalk = @import("reflogwalk.zig");
const logtree = @import("logtree.zig");
const mailmap_mod = @import("mailmap.zig");
const trailer_mod = @import("pretty_trailer.zig");
const gpa = util.gpa;
const Buf = util.Buf;

pub const Fmt = revision.CmitFmt;

/// Limit for formatting directives that let the user append arbitrarily
/// many bytes (padding, wrapping).
const FORMATTING_LIMIT: i64 = 16 * 1024;

pub const Context = struct {
    fmt: Fmt = .medium,
    /// 0 = full hex
    abbrev: usize = 0,
    after_subject: ?[]const u8 = null,
    preserve_subject: bool = false,
    date_mode: date_mod.DateMode = .{},
    date_mode_explicit: bool = false,
    expand_tabs_in_log: i32 = 0,
    need_8bit_cte: i32 = 0,
    notes_message: ?[]const u8 = null,
    reflog_info: ?*reflogwalk.Info = null,
    rev: ?*revision.RevInfo = null,
    output_encoding: ?[]const u8 = null,
    mailmap: ?*mailmap_mod.Map = null,
    /// already resolved (want_color)
    color: bool = false,
    graph_width: usize = 0,
    /// user format to use for .userformat (defaults to the global one)
    fmt_string: ?[]const u8 = null,
    /// format-patch: rfc2047-encode non-ASCII headers
    encode_email_headers: bool = false,
    /// format-patch --from: "Name <email>" used in From:, original goes in-body
    from_ident: ?[]const u8 = null,
    in_body_headers: std.ArrayList([]const u8) = .empty,
    /// limit for %(describe) invocations (null = unlimited)
    describe_max_invocations: ?*usize = null,
};

// ---------------------------------------------------------------------------
// small C-like helpers

fn at(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r';
}

fn isDigit(ch: u8) bool {
    return ch >= '0' and ch <= '9';
}

fn isAlnum(ch: u8) bool {
    return std.ascii.isAlphanumeric(ch);
}

fn cstr(s: []const u8) []const u8 {
    if (std.mem.indexOfScalar(u8, s, 0)) |i| return s[0..i];
    return s;
}

fn addChars(b: *Buf, ch: u8, n: i64) void {
    if (n <= 0) return;
    b.appendNTimes(gpa, ch, @intCast(n)) catch util.oom();
}

fn insertAt(b: *Buf, pos: usize, s: []const u8) void {
    b.insertSlice(gpa, pos, s) catch util.oom();
}

fn rtrimBuf(b: *Buf) void {
    while (b.items.len > 0 and isSpace(b.items[b.items.len - 1])) b.items.len -= 1;
}

/// strtol-like parse: returns value (saturated) and the index after the number
/// (0 if no conversion).
fn strtol(s: []const u8) struct { val: i64, end: usize } {
    var i: usize = 0;
    while (i < s.len and (isSpace(s[i]) or s[i] == 0x0b or s[i] == 0x0c)) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    const ds = i;
    var v: i64 = 0;
    while (i < s.len and isDigit(s[i])) : (i += 1) v = v *| 10 +| @as(i64, s[i] - '0');
    if (i == ds) return .{ .val = 0, .end = 0 };
    return .{ .val = if (neg) -v else v, .end = i };
}

/// strtoul-like: negative numbers become huge.
fn strtoul(s: []const u8) struct { val: u64, end: usize } {
    const r = strtol(s);
    if (r.val < 0) return .{ .val = std.math.maxInt(u64), .end = r.end };
    return .{ .val = @intCast(r.val), .end = r.end };
}

fn decimalWidth(n0: i64) usize {
    var n: u64 = @bitCast(n0);
    var w: usize = 1;
    while (n >= 10) : (w += 1) n /= 10;
    return w;
}

fn hex2chr(s: []const u8) ?u8 {
    if (s.len < 2) return null;
    const hi = std.fmt.charToDigit(s[0], 16) catch return null;
    const lo = std.fmt.charToDigit(s[1], 16) catch return null;
    return hi * 16 + lo;
}

extern "c" fn ioctl(fd: c_int, req: c_ulong, ...) c_int;

var term_columns_cache: i64 = 0;

/// term_columns(): $COLUMNS, else the terminal width of stdout, else 80.
pub fn termColumns() i64 {
    if (term_columns_cache != 0) return term_columns_cache;
    term_columns_cache = 80;
    if (os.getenv("COLUMNS")) |s| {
        const r = strtol(s);
        if (r.end > 0 and r.val > 0) {
            term_columns_cache = r.val;
            return term_columns_cache;
        }
    }
    const WinSize = extern struct { row: u16, col: u16, xpixel: u16, ypixel: u16 };
    var ws: WinSize = .{ .row = 0, .col = 0, .xpixel = 0, .ypixel = 0 };
    if (ioctl(1, 0x5413, &ws) == 0 and ws.col != 0) term_columns_cache = ws.col;
    return term_columns_cache;
}

// ---------------------------------------------------------------------------
// user formats / --pretty=<name>

const FmtMap = struct {
    name: []const u8,
    format: Fmt,
    is_tformat: bool = false,
    expand_tabs_in_log: i32 = 0,
    is_alias: bool = false,
    default_date_mode: ?date_mod.Mode = null,
    user_format: []const u8 = "",
};

var user_format: ?[]const u8 = null;
var commit_formats: std.ArrayList(FmtMap) = .empty;
var builtin_formats_len: usize = 0;
var formats_setup = false;

pub fn commitFormatIsEmpty(fmt: Fmt) bool {
    return fmt == .userformat and userFormatString().len == 0;
}

/// The current global user format ("" if none).
pub fn userFormatString() []const u8 {
    return user_format orelse "";
}

fn saveUserFormat(rev: *revision.RevInfo, cp: []const u8, is_tformat: bool) void {
    user_format = util.dupe(cp);
    rev.user_format = user_format.?;
    if (is_tformat) rev.use_terminator = true;
    rev.commit_format = .userformat;
}

fn prettyFormatsConfig(key: []const u8, value: ?[]const u8) void {
    const name = util.skipPrefix(key, "pretty.") orelse return;
    for (commit_formats.items[0..builtin_formats_len]) |f| {
        if (util.eql(f.name, name)) return;
    }
    var slot: ?*FmtMap = null;
    for (commit_formats.items[builtin_formats_len..]) |*f| {
        if (util.eql(f.name, name)) {
            slot = f;
            break;
        }
    }
    if (slot == null) {
        commit_formats.append(gpa, .{ .name = name, .format = .userformat }) catch util.oom();
        slot = &commit_formats.items[commit_formats.items.len - 1];
    }
    const cf = slot.?;
    cf.* = .{ .name = util.dupe(name), .format = .userformat };
    const fmt = value orelse {
        util.err("missing value for '{s}'", .{key});
        util.die("bad config variable '{s}'", .{key});
    };
    if (util.skipPrefix(fmt, "format:")) |s| {
        cf.is_tformat = false;
        cf.user_format = s;
    } else if (util.skipPrefix(fmt, "tformat:")) |s| {
        cf.is_tformat = true;
        cf.user_format = s;
    } else if (std.mem.indexOfScalar(u8, fmt, '%') != null) {
        cf.is_tformat = true;
        cf.user_format = fmt;
    } else {
        cf.is_alias = true;
        cf.user_format = fmt;
    }
}

fn setupCommitFormats() void {
    formats_setup = true;
    const builtins = [_]FmtMap{
        .{ .name = "raw", .format = .raw },
        .{ .name = "medium", .format = .medium, .expand_tabs_in_log = 8 },
        .{ .name = "short", .format = .short },
        .{ .name = "email", .format = .email },
        .{ .name = "mboxrd", .format = .mboxrd },
        .{ .name = "fuller", .format = .fuller, .expand_tabs_in_log = 8 },
        .{ .name = "full", .format = .full, .expand_tabs_in_log = 8 },
        .{ .name = "oneline", .format = .oneline, .is_tformat = true },
        .{ .name = "reference", .format = .userformat, .is_tformat = true, .default_date_mode = .short, .user_format = "%C(auto)%h (%s, %ad)" },
    };
    commit_formats.appendSlice(gpa, &builtins) catch util.oom();
    builtin_formats_len = builtins.len;
    for (repo_mod.cfg.entries.items) |e| prettyFormatsConfig(e.key, e.value);
}

fn istartsWith(s: []const u8, prefix: []const u8) bool {
    return s.len >= prefix.len and std.ascii.eqlIgnoreCase(s[0..prefix.len], prefix);
}

fn findCommitFormatRecursive(sought: []const u8, original: []const u8, num_redirections: usize) ?*FmtMap {
    if (num_redirections >= commit_formats.items.len)
        util.die("invalid --pretty format: '{s}' references an alias which points to itself", .{original});
    var found: ?*FmtMap = null;
    var found_len: usize = 0;
    for (commit_formats.items) |*f| {
        if (!istartsWith(f.name, sought)) continue;
        if (found == null or found_len > f.name.len) {
            found = f;
            found_len = f.name.len;
        }
    }
    if (found) |f| {
        if (f.is_alias) return findCommitFormatRecursive(f.user_format, original, num_redirections + 1);
    }
    return found;
}

fn findCommitFormat(sought: []const u8) ?*FmtMap {
    if (!formats_setup) setupCommitFormats();
    return findCommitFormatRecursive(sought, sought, 0);
}

/// get_commit_format() with C's NULL argument: a bare --pretty selects the
/// default (medium) format. Suitable as RevInfo.format_hook.
pub fn getCommitFormatOpt(revs: *revision.RevInfo, arg: ?[]const u8) void {
    if (arg) |a| return getCommitFormat(a, revs);
    revs.use_terminator = false;
    revs.commit_format = .medium;
}

/// get_commit_format(): parse a --pretty/--format argument into revs.
pub fn getCommitFormat(arg: []const u8, revs: *revision.RevInfo) void {
    revs.use_terminator = false;
    if (util.skipPrefix(arg, "format:")) |s| {
        saveUserFormat(revs, s, false);
        return;
    }
    if (arg.len == 0) {
        saveUserFormat(revs, arg, true);
        return;
    }
    if (util.skipPrefix(arg, "tformat:")) |s| {
        saveUserFormat(revs, s, true);
        return;
    }
    if (std.mem.indexOfScalar(u8, arg, '%') != null) {
        saveUserFormat(revs, arg, true);
        return;
    }
    const cf = findCommitFormat(arg) orelse util.die("invalid --pretty format: {s}", .{arg});
    revs.commit_format = cf.format;
    revs.use_terminator = cf.is_tformat;
    revs.expand_tabs_in_log_default = cf.expand_tabs_in_log;
    if (!revs.date_mode_explicit) {
        if (cf.default_date_mode) |m| revs.date_mode.mode = m;
    }
    if (cf.format == .userformat) saveUserFormat(revs, cf.user_format, cf.is_tformat);
}

// ---------------------------------------------------------------------------
// header helpers

fn getOneLine(msg: []const u8, pos: usize) usize {
    if (pos >= msg.len) return 0;
    if (std.mem.indexOfScalarPos(u8, msg, pos, '\n')) |nl| return nl + 1 - pos;
    return msg.len - pos;
}

fn nonAscii(ch: u8) bool {
    return ch >= 0x80 or ch == 0x1b;
}

pub fn hasNonAscii(s: ?[]const u8) bool {
    const v = s orelse return false;
    for (v) |ch| {
        if (ch == 0) break;
        if (nonAscii(ch)) return true;
    }
    return false;
}

fn isRfc822Special(ch: u8) bool {
    return switch (ch) {
        '(', ')', '<', '>', '[', ']', ':', ';', '@', ',', '.', '"', '\\' => true,
        else => false,
    };
}

fn needsRfc822Quoting(s: []const u8) bool {
    for (s) |ch| if (isRfc822Special(ch)) return true;
    return false;
}

fn lastLineLength(sb: *const Buf) usize {
    if (std.mem.lastIndexOfScalar(u8, sb.items, '\n')) |i| return sb.items.len - (i + 1);
    return sb.items.len;
}

fn addRfc822Quoted(out: *Buf, s: []const u8) void {
    util.bufByte(out, '"');
    for (s) |ch| {
        if (ch == '"' or ch == '\\') util.bufByte(out, '\\');
        util.bufByte(out, ch);
    }
    util.bufByte(out, '"');
}

const Rfc2047Type = enum { subject, address };

fn isRfc2047Special(ch: u8, typ: Rfc2047Type) bool {
    if (nonAscii(ch) or !(ch >= 0x20 and ch <= 0x7e)) return true;
    if (isSpace(ch) or ch == '=' or ch == '?' or ch == '_') return true;
    if (typ != .address) return false;
    return !(isAlnum(ch) or ch == '!' or ch == '*' or ch == '+' or ch == '-' or ch == '/');
}

fn needsRfc2047Encoding(line: []const u8) bool {
    for (line, 0..) |ch, i| {
        if (nonAscii(ch) or ch == '\n') return true;
        if (i + 1 < line.len and ch == '=' and line[i + 1] == '?') return true;
    }
    return false;
}

fn addRfc2047(sb: *Buf, line: []const u8, encoding: []const u8, typ: Rfc2047Type) void {
    const max_encoded_length = 76;
    var line_len = lastLineLength(sb);
    util.bufPrint(sb, "=?{s}?q?", .{encoding});
    line_len += encoding.len + 5;
    var pos: usize = 0;
    var remain = line.len;
    while (remain > 0) {
        const p = pos;
        const chrlen = mbsChrlen(line, &pos, &remain, encoding);
        const is_special = chrlen > 1 or isRfc2047Special(line[p], typ);
        const encoded_len: usize = if (is_special) 3 * chrlen else 1;
        if (line_len + encoded_len + 2 > max_encoded_length) {
            util.bufPrint(sb, "?=\n =?{s}?q?", .{encoding});
            line_len = encoding.len + 5 + 1;
        }
        for (line[p .. p + chrlen]) |ch| {
            if (is_special) util.bufPrint(sb, "={X:0>2}", .{ch}) else util.bufByte(sb, ch);
        }
        line_len += encoded_len;
    }
    util.bufAppend(sb, "?=");
}

/// struct ident_split equivalent.
pub const Ident = struct {
    name: []const u8,
    mail: []const u8,
    date: ?[]const u8 = null,
    tz: ?[]const u8 = null,
};

/// split_ident_line(): parse "Name <email> 1234567890 +0000".
pub fn splitIdentLine(line0: []const u8) ?Ident {
    const line = line0;
    const len = line.len;
    var mail_begin: ?usize = null;
    var i: usize = 0;
    while (i < len and line[i] != 0) : (i += 1) {
        if (line[i] == '<') {
            mail_begin = i + 1;
            break;
        }
    }
    const mb = mail_begin orelse return null;
    var name_end: usize = 0;
    var j: isize = @as(isize, @intCast(mb)) - 2;
    while (j >= 0) : (j -= 1) {
        if (!isSpace(line[@intCast(j)])) {
            name_end = @intCast(j + 1);
            break;
        }
    }
    var mail_end: ?usize = null;
    i = mb;
    while (i < len) : (i += 1) {
        if (line[i] == '>') {
            mail_end = i;
            break;
        }
    }
    const me = mail_end orelse return null;
    var s = Ident{ .name = line[0..name_end], .mail = line[mb..me] };
    var cp: usize = len - 1;
    while (line[cp] != '>') cp -= 1;
    cp += 1;
    while (cp < len and isSpace(line[cp])) cp += 1;
    if (cp >= len) return s;
    const db = cp;
    while (cp < len and isDigit(line[cp])) cp += 1;
    if (cp == db) return s;
    const de = cp;
    while (cp < len and isSpace(line[cp])) cp += 1;
    if (cp >= len or (line[cp] != '+' and line[cp] != '-')) return s;
    const tb = cp;
    cp += 1;
    while (cp < len and isDigit(line[cp])) cp += 1;
    if (cp == tb + 1) return s;
    s.date = line[db..de];
    s.tz = line[tb..cp];
    return s;
}

/// show_ident_date()
pub fn showIdentDate(id: *const Ident, mode: date_mod.DateMode) []const u8 {
    var t: i64 = 0;
    var tz: i64 = 0;
    var overflow = false;
    if (id.date) |d| {
        var v: u64 = 0;
        for (d) |ch| {
            if (!isDigit(ch)) break;
            v = v *| 10 +| (ch - '0');
        }
        if (v > std.math.maxInt(i64)) overflow = true else t = @intCast(v);
    }
    if (overflow or date_mod.dateOverflows(t)) {
        t = 0;
    } else if (id.tz) |z| {
        tz = strtol(z).val;
        if (tz >= std.math.maxInt(i32) or tz <= std.math.minInt(i32)) tz = 0;
    }
    return date_mod.showDate(t, @intCast(tz), mode);
}

fn identDiffers(a: *const Ident, b: *const Ident) bool {
    return !util.eql(a.mail, b.mail) or !util.eql(a.name, b.name);
}

fn useInBodyFrom(pp: *const Context, from: *const Ident, id: *const Ident) bool {
    if (pp.rev) |r| if (r.force_in_body_from) return true;
    return identDiffers(from, id);
}

fn isMail(fmt: Fmt) bool {
    return fmt == .email or fmt == .mboxrd;
}

/// pp_user_info()
pub fn ppUserInfo(pp: *Context, what: []const u8, sb: *Buf, line0: []const u8, encoding: []const u8) void {
    if (pp.fmt == .oneline) return;
    const line_end = std.mem.indexOfScalar(u8, line0, '\n') orelse line0.len;
    const ident = splitIdentLine(line0[0..line_end]) orelse return;
    var mailbuf = ident.mail;
    var namebuf = ident.name;
    var max_length: usize = 78;

    const mm: ?*mailmap_mod.Map = pp.mailmap orelse blk: {
        if (pp.rev) |r| {
            if (r.mailmap) |m| break :blk m;
            if (r.use_mailmap) break :blk mailmap_mod.readMailmap();
        }
        break :blk null;
    };
    if (mm) |m| {
        if (m.mapUser(namebuf, mailbuf)) |r| {
            namebuf = r.name;
            mailbuf = r.email;
        }
    }

    if (isMail(pp.fmt)) {
        if (pp.from_ident) |fi_line| {
            if (splitIdentLine(fi_line)) |fi| {
                if (useInBodyFrom(pp, &fi, &ident)) {
                    const hdr = util.concat(&.{ "From: ", namebuf, " <", mailbuf, ">\n" });
                    pp.in_body_headers.append(gpa, hdr) catch util.oom();
                    mailbuf = fi.mail;
                    namebuf = fi.name;
                }
            }
        }
        util.bufAppend(sb, "From: ");
        if (encodeEmailHeaders(pp) and needsRfc2047Encoding(namebuf)) {
            addRfc2047(sb, namebuf, encoding, .address);
            max_length = 76;
        } else if (needsRfc822Quoting(namebuf)) {
            var quoted: Buf = .empty;
            addRfc822Quoted(&quoted, namebuf);
            addWrappedText(sb, quoted.items, -6, 1, @intCast(max_length));
        } else {
            addWrappedText(sb, namebuf, -6, 1, @intCast(max_length));
        }
        if (max_length < lastLineLength(sb) + 2 + mailbuf.len + 1) util.bufByte(sb, '\n');
        util.bufPrint(sb, " <{s}>\n", .{mailbuf});
    } else {
        util.bufPrint(sb, "{s}: ", .{what});
        if (pp.fmt == .fuller) addChars(sb, ' ', 4);
        util.bufPrint(sb, "{s} <{s}>\n", .{ namebuf, mailbuf });
    }

    switch (pp.fmt) {
        .medium => util.bufPrint(sb, "Date:   {s}\n", .{showIdentDate(&ident, pp.date_mode)}),
        .email, .mboxrd => util.bufPrint(sb, "Date: {s}\n", .{showIdentDate(&ident, date_mod.DateMode.of(.rfc2822))}),
        .fuller => util.bufPrint(sb, "{s}Date: {s}\n", .{ what, showIdentDate(&ident, pp.date_mode) }),
        else => {},
    }
}

fn encodeEmailHeaders(pp: *const Context) bool {
    if (pp.encode_email_headers) return true;
    if (pp.rev) |r| return r.encode_email_headers;
    return false;
}

/// is_blank_line(): trims trailing whitespace from line[0..len.*]
fn isBlankLine(line: []const u8, len: *usize) bool {
    var l = len.*;
    while (l > 0 and isSpace(line[l - 1])) l -= 1;
    len.* = l;
    return l == 0;
}

/// skip_blank_lines(): returns the new position.
pub fn skipBlankLines(msg: []const u8, pos0: usize) usize {
    var pos = pos0;
    while (true) {
        const linelen = getOneLine(msg, pos);
        var ll = linelen;
        if (linelen == 0) break;
        if (!isBlankLine(msg[pos..], &ll)) break;
        pos += linelen;
    }
    return pos;
}

fn addAbbrev(sb: *Buf, oid: hash.Oid, n: usize) void {
    if (n == 0 or n >= hash.HEXSZ) {
        const h = hash.hex(oid);
        util.bufAppend(sb, &h);
    } else {
        util.bufAppend(sb, revparse.abbrev(oid, n));
    }
}

fn addOidHex(sb: *Buf, oid: hash.Oid) void {
    const h = hash.hex(oid);
    util.bufAppend(sb, &h);
}

fn addMergeInfo(pp: *const Context, sb: *Buf, commit: *const cn.Commit) void {
    const parent = commit.parents orelse return;
    if (pp.fmt == .oneline or isMail(pp.fmt) or parent.next == null) return;
    util.bufAppend(sb, "Merge:");
    var p: ?*cn.CommitList = parent;
    while (p) |x| : (p = x.next) {
        util.bufByte(sb, ' ');
        if (pp.abbrev != 0) addAbbrev(sb, x.item.obj.oid, pp.abbrev) else addOidHex(sb, x.item.obj.oid);
    }
    util.bufByte(sb, '\n');
}

fn getHeader(msg: []const u8, key: []const u8) ?[]const u8 {
    return cn.findHeader(msg, key);
}

// ---------------------------------------------------------------------------
// encodings

fn sameUtfEncoding(src0: []const u8, dst0: []const u8) bool {
    if (istartsWith(src0, "utf") and istartsWith(dst0, "utf")) {
        var src = src0[3..];
        var dst = dst0[3..];
        if (util.startsWith(src, "-")) src = src[1..];
        if (util.startsWith(dst, "-")) dst = dst[1..];
        return std.ascii.eqlIgnoreCase(src, dst);
    }
    return false;
}

pub fn isEncodingUtf8(name: ?[]const u8) bool {
    const n = name orelse return true;
    return sameUtfEncoding("utf-8", n);
}

pub fn sameEncoding(src0: ?[]const u8, dst0: ?[]const u8) bool {
    const src = src0 orelse "UTF-8";
    const dst = dst0 orelse "UTF-8";
    if (sameUtfEncoding(src, dst)) return true;
    return std.ascii.eqlIgnoreCase(src, dst);
}

/// get_log_output_encoding()
pub fn logOutputEncoding() []const u8 {
    if (revision.log_output_encoding) |e| return e;
    if (repo_mod.cfg.get("i18n.logoutputencoding")) |e| return e;
    if (repo_mod.cfg.get("i18n.commitencoding")) |e| return e;
    return "UTF-8";
}

extern "c" fn iconv_open(tocode: [*:0]const u8, fromcode: [*:0]const u8) ?*anyopaque;
extern "c" fn iconv(cd: ?*anyopaque, inbuf: ?*[*]u8, inleft: ?*usize, outbuf: ?*[*]u8, outleft: ?*usize) usize;
extern "c" fn iconv_close(cd: ?*anyopaque) c_int;

fn openIconv(out_enc: []const u8, in_enc: []const u8) ?*anyopaque {
    const to = gpa.dupeSentinel(u8, out_enc, 0) catch util.oom();
    const from = gpa.dupeSentinel(u8, in_enc, 0) catch util.oom();
    const cd = iconv_open(to.ptr, from.ptr);
    if (cd == null or @intFromPtr(cd) == std.math.maxInt(usize)) return null;
    return cd;
}

/// reencode_string_len(): convert `in` from in_enc to out_enc (null on failure).
pub fn reencodeString(in: []const u8, out_enc: []const u8, in_enc: []const u8) ?[]u8 {
    var cd = openIconv(out_enc, in_enc);
    if (cd == null) {
        // git retries with "UTF-8" <-> "UTF8" spelled differently
        const o = if (isEncodingUtf8(out_enc)) "UTF-8" else out_enc;
        const i = if (isEncodingUtf8(in_enc)) "UTF-8" else in_enc;
        cd = openIconv(o, i);
        if (cd == null) return null;
    }
    defer _ = iconv_close(cd);
    var outsz: usize = in.len * 4 + 16;
    while (true) {
        const out = gpa.alloc(u8, outsz) catch util.oom();
        const inbuf = gpa.dupe(u8, in) catch util.oom();
        var inp: [*]u8 = inbuf.ptr;
        var inleft: usize = inbuf.len;
        var outp: [*]u8 = out.ptr;
        var outleft: usize = out.len;
        _ = iconv(cd, null, null, null, null);
        const r = iconv(cd, &inp, &inleft, &outp, &outleft);
        if (r == std.math.maxInt(usize)) {
            if (os.errno() == 7) { // E2BIG
                outsz *= 2;
                continue;
            }
            return null;
        }
        const r2 = iconv(cd, null, null, &outp, &outleft);
        if (r2 == std.math.maxInt(usize)) {
            outsz *= 2;
            continue;
        }
        return out[0 .. out.len - outleft];
    }
}

fn replaceEncodingHeader(buf: []u8, encoding: []const u8) []u8 {
    var cp: usize = 0;
    while (!util.startsWith(buf[cp..], "encoding ")) {
        const nl = std.mem.indexOfScalarPos(u8, buf, cp, '\n') orelse return buf;
        cp = nl + 1;
        if (at(buf, cp) == '\n') return buf;
    }
    const start = cp;
    const nl = std.mem.indexOfScalarPos(u8, buf, cp, '\n') orelse return buf;
    const len = nl + 1 - start;
    if (isEncodingUtf8(encoding)) {
        return util.concat(&.{ buf[0..start], buf[start + len ..] });
    }
    return util.concat(&.{ buf[0 .. start + "encoding ".len], encoding, buf[nl..] });
}

/// Raw commit buffer as git sees it (a C string: stops at the first NUL).
fn commitBuffer(commit: *cn.Commit) []const u8 {
    _ = cn.parse(commit);
    return cstr(commit.buffer);
}

pub const Reencoded = struct { msg: []const u8, encoding: ?[]const u8 };

/// repo_logmsg_reencode(): the commit buffer, converted to output_encoding.
pub fn logmsgReencode(commit: *cn.Commit, output_encoding: ?[]const u8) Reencoded {
    const msg = commitBuffer(commit);
    const encoding = getHeader(msg, "encoding");
    const oe = output_encoding orelse return .{ .msg = msg, .encoding = encoding };
    if (oe.len == 0) return .{ .msg = msg, .encoding = encoding };
    const use_encoding = encoding orelse "UTF-8";
    var out: ?[]u8 = null;
    if (sameEncoding(use_encoding, oe)) {
        if (encoding == null) return .{ .msg = msg, .encoding = encoding };
        out = util.dupe(msg);
    } else {
        out = reencodeString(msg, oe, use_encoding);
    }
    if (out) |o| return .{ .msg = cstr(replaceEncodingHeader(o, oe)), .encoding = encoding };
    return .{ .msg = msg, .encoding = encoding };
}

// ---------------------------------------------------------------------------
// format_commit_message

fn mailmapName(email: *[]const u8, name: *[]const u8) void {
    const m = mailmap_mod.readMailmap();
    if (m.count() == 0) return;
    if (m.mapUser(name.*, email.*)) |r| {
        name.* = r.name;
        email.* = r.email;
    }
}

fn formatPersonPart(sb: *Buf, part: u8, msg: []const u8, dmode: date_mod.DateMode) usize {
    const placeholder_len = 2;
    skip: {
        const s = splitIdentLine(msg) orelse break :skip;
        var name = s.name;
        var mail = s.mail;
        if (part == 'N' or part == 'E' or part == 'L') mailmapName(&mail, &name);
        if (part == 'n' or part == 'N') {
            util.bufAppend(sb, name);
            return placeholder_len;
        }
        if (part == 'e' or part == 'E') {
            util.bufAppend(sb, mail);
            return placeholder_len;
        }
        if (part == 'l' or part == 'L') {
            const m = if (std.mem.indexOfScalar(u8, mail, '@')) |i| mail[0..i] else mail;
            util.bufAppend(sb, m);
            return placeholder_len;
        }
        const d = s.date orelse break :skip;
        if (part == 't') {
            util.bufAppend(sb, d);
            return placeholder_len;
        }
        const mode: date_mod.DateMode = switch (part) {
            'd' => dmode,
            'D' => date_mod.DateMode.of(.rfc2822),
            'r' => date_mod.DateMode.of(.relative),
            'i' => date_mod.DateMode.of(.iso8601),
            'I' => date_mod.DateMode.of(.iso8601_strict),
            'h' => date_mod.DateMode.of(.human),
            's' => date_mod.DateMode.of(.short),
            else => break :skip,
        };
        util.bufAppend(sb, showIdentDate(&s, mode));
        return placeholder_len;
    }
    switch (part) {
        'n', 'e', 't', 'd', 'D', 'r', 'i' => return placeholder_len,
        else => return 0,
    }
}

const Chunk = struct { off: usize = 0, len: usize = 0 };
const FlushType = enum { no_flush, flush_right, flush_left, flush_left_and_steal, flush_both };
const TruncType = enum { trunc_none, trunc_left, trunc_middle, trunc_right };

const FormatContext = struct {
    commit: *cn.Commit,
    pp: *const Context,
    header_parsed: bool = false,
    message_parsed: bool = false,
    flush_type: FlushType = .no_flush,
    truncate: TruncType = .trunc_none,
    message: []const u8 = "",
    commit_encoding: ?[]const u8 = null,
    width: usize = 0,
    indent1: usize = 0,
    indent2: usize = 0,
    auto_color: bool = false,
    padding: i64 = 0,
    author: Chunk = .{},
    committer: Chunk = .{},
    message_off: usize = 0,
    subject_off: usize = 0,
    body_off: usize = 0,
    wrap_start: usize = 0,
};

fn parseCommitHeader(c: *FormatContext) void {
    const msg = c.message;
    var i: usize = 0;
    while (i < msg.len) : (i += 1) {
        const eol = std.mem.indexOfScalarPos(u8, msg, i, '\n') orelse msg.len;
        if (i == eol) break;
        const line = msg[i..eol];
        if (util.startsWith(line, "author ")) {
            c.author = .{ .off = i + 7, .len = eol - (i + 7) };
        } else if (util.startsWith(line, "committer ")) {
            c.committer = .{ .off = i + 10, .len = eol - (i + 10) };
        }
        i = eol;
    }
    c.message_off = @min(i, msg.len);
    c.header_parsed = true;
}

fn isTitleChar(ch: u8) bool {
    return (ch >= 'a' and ch <= 'z') or (ch >= 'A' and ch <= 'Z') or
        (ch >= '0' and ch <= '9') or ch == '.' or ch == '_';
}

/// format_sanitized_subject() (%f)
pub fn formatSanitizedSubject(sb: *Buf, msg: []const u8) void {
    const start_len = sb.items.len;
    var space: u8 = 2;
    var i: usize = 0;
    while (i < msg.len) : (i += 1) {
        if (isTitleChar(msg[i])) {
            if (space == 1) util.bufByte(sb, '-');
            space = 0;
            util.bufByte(sb, msg[i]);
            if (msg[i] == '.') {
                while (i + 1 < msg.len and msg[i + 1] == '.') i += 1;
            }
        } else space |= 1;
    }
    while (sb.items.len > start_len and (sb.items[sb.items.len - 1] == '.' or sb.items[sb.items.len - 1] == '-'))
        sb.items.len -= 1;
}

/// format_subject(): append the subject lines of msg[pos..] (joined by
/// line_separator) to sb (if non-null). Returns the position after the subject.
pub fn formatSubject(sb: ?*Buf, msg: []const u8, pos0: usize, line_separator: []const u8) usize {
    var pos = pos0;
    var first = true;
    while (true) {
        const line = pos;
        var linelen = getOneLine(msg, line);
        pos += linelen;
        if (linelen == 0 or isBlankLine(msg[line..], &linelen)) break;
        const b = sb orelse continue;
        if (!first) util.bufAppend(b, line_separator);
        util.bufAppend(b, msg[line .. line + linelen]);
        first = false;
    }
    return pos;
}

/// Find the subject of a commit message (the raw buffer): returns the
/// subject text (joined with spaces), like find_commit_subject + format_subject.
pub fn findCommitSubject(msg: []const u8) []const u8 {
    var start: usize = 0;
    if (std.mem.indexOf(u8, msg, "\n\n")) |i| {
        start = i + 2;
    } else return "";
    var b: Buf = .empty;
    _ = formatSubject(&b, msg, skipBlankLines(msg, start), " ");
    return b.items;
}

fn parseCommitMessage(c: *FormatContext) void {
    const msg = c.message;
    var pos = skipBlankLines(msg, c.message_off);
    c.subject_off = pos;
    pos = formatSubject(null, msg, pos, "");
    pos = skipBlankLines(msg, pos);
    c.body_off = pos;
    c.message_parsed = true;
}

fn strbufWrap(sb: *Buf, pos: usize, width: usize, indent1: usize, indent2: usize) void {
    var tmp: Buf = .empty;
    util.bufAppend(&tmp, sb.items[0..pos]);
    addWrappedText(&tmp, sb.items[pos..], @intCast(indent1), @intCast(indent2), @intCast(width));
    sb.* = tmp;
}

fn rewrapMessageTail(sb: *Buf, c: *FormatContext, new_width: usize, new_indent1: usize, new_indent2: usize) void {
    if (c.width == new_width and c.indent1 == new_indent1 and c.indent2 == new_indent2) return;
    if (c.wrap_start < sb.items.len) strbufWrap(sb, c.wrap_start, c.width, c.indent1, c.indent2);
    c.wrap_start = sb.items.len;
    c.width = new_width;
    c.indent1 = new_indent1;
    c.indent2 = new_indent2;
}

fn formatReflogPerson(sb: *Buf, part: u8, log: ?*reflogwalk.Info, dmode: date_mod.DateMode) usize {
    const l = log orelse return 2;
    const ident = reflogwalk.getReflogIdent(l) orelse return 2;
    return formatPersonPart(sb, part, ident, dmode);
}

fn parseColorPlaceholder(sb: *Buf, ph: []const u8, c: *FormatContext) usize {
    if (at(ph, 1) == '(') {
        const end = std.mem.indexOfScalarPos(u8, ph, 2, ')') orelse return 0;
        var begin: usize = 2;
        const spec = ph[2..end];
        if (util.startsWith(spec, "auto,")) {
            if (!c.pp.color) return end + 1;
            begin += 5;
        } else if (util.startsWith(spec, "always,")) {
            begin += 7;
        } else {
            if (!c.pp.color) return end + 1;
        }
        const col = color_mod.parseColor(ph[begin..end]) orelse util.die("unable to parse --pretty format", .{});
        util.bufAppend(sb, col);
        return end + 1;
    }
    const rest = ph[1..];
    var basic: ?[]const u8 = null;
    var consumed: usize = 0;
    if (util.startsWith(rest, "red")) {
        basic = color_mod.RED;
        consumed = 1 + 3;
    } else if (util.startsWith(rest, "green")) {
        basic = color_mod.GREEN;
        consumed = 1 + 5;
    } else if (util.startsWith(rest, "blue")) {
        basic = color_mod.BLUE;
        consumed = 1 + 4;
    } else if (util.startsWith(rest, "reset")) {
        basic = color_mod.RESET;
        consumed = 1 + 5;
    }
    if (basic) |b| {
        if (c.pp.color) util.bufAppend(sb, b);
    }
    return consumed;
}

fn parsePaddingPlaceholder(ph: []const u8, c: *FormatContext) usize {
    var ch: usize = 0;
    var flush_type: FlushType = undefined;
    var to_column = false;
    switch (at(ph, ch)) {
        '<' => {
            flush_type = .flush_right;
            ch += 1;
        },
        '>' => {
            ch += 1;
            if (at(ph, ch) == '<') {
                flush_type = .flush_both;
                ch += 1;
            } else if (at(ph, ch) == '>') {
                flush_type = .flush_left_and_steal;
                ch += 1;
            } else flush_type = .flush_left;
        },
        else => return 0,
    }
    if (at(ph, ch) == '|') {
        to_column = true;
        ch += 1;
    }
    if (at(ph, ch) != '(') return 0;
    const start = ch + 1;
    var end = start;
    while (end < ph.len and ph[end] != ',' and ph[end] != ')') end += 1;
    if (end >= ph.len or end == start) return 0;
    const r = strtol(ph[start..]);
    var width = r.val;
    if (width < -FORMATTING_LIMIT or width > FORMATTING_LIMIT) return 0;
    if (r.end == 0 or width == 0) return 0;
    if (width < 0) {
        if (to_column) width += termColumns();
        if (width < 0) return 0;
    }
    c.padding = if (to_column) -width else width;
    c.flush_type = flush_type;
    if (ph[end] == ',') {
        const s2 = end + 1;
        const e2 = std.mem.indexOfScalarPos(u8, ph, s2, ')') orelse return 0;
        if (e2 == s2) return 0;
        const t = ph[s2..];
        if (util.startsWith(t, "trunc)")) {
            c.truncate = .trunc_right;
        } else if (util.startsWith(t, "ltrunc)")) {
            c.truncate = .trunc_left;
        } else if (util.startsWith(t, "mtrunc)")) {
            c.truncate = .trunc_middle;
        } else return 0;
        end = e2;
    } else c.truncate = .trunc_none;
    return end + 1;
}

const ArgMatch = struct { end: usize, val: ?[]const u8 };

/// match_placeholder_arg_value(); `end` is relative to `s`.
fn matchArgValue(s: []const u8, candidate: []const u8) ?ArgMatch {
    if (!util.startsWith(s, candidate)) return null;
    var p = candidate.len;
    var val: ?[]const u8 = null;
    if (at(s, p) == '=') {
        const vs = p + 1;
        var ve = vs;
        while (ve < s.len and s[ve] != ',' and s[ve] != ')') ve += 1;
        val = s[vs..ve];
        p = ve;
    } else if (at(s, p) != ',' and at(s, p) != ')') return null;
    if (at(s, p) == ',') return .{ .end = p + 1, .val = val };
    if (at(s, p) == ')') return .{ .end = p, .val = val };
    return null;
}

/// git_parse_maybe_bool()
fn parseMaybeBool(v: []const u8) ?bool {
    return config_mod.parseBool(v);
}

fn matchBoolArg(s: []const u8, candidate: []const u8, val: *bool) ?usize {
    const m = matchArgValue(s, candidate) orelse return null;
    const v = m.val orelse {
        val.* = true;
        return m.end;
    };
    val.* = parseMaybeBool(v) orelse return null;
    return m.end;
}

/// expand_string_arg(): expands %n, %xNN and %%.
fn expandStringArg(arg: []const u8) []const u8 {
    var sb: Buf = .empty;
    var pos: usize = 0;
    while (expandStep(&sb, arg, &pos)) {
        const rest = arg[pos..];
        if (at(rest, 0) == '%') {
            util.bufByte(&sb, '%');
            pos += 1;
        } else {
            const l = expandLiteral(&sb, rest);
            if (l > 0) pos += l else util.bufByte(&sb, '%');
        }
    }
    return sb.items;
}

/// strbuf_expand_step(): copy literal text up to the next '%'; returns true
/// (with pos just after the '%') if one was found.
fn expandStep(sb: *Buf, format: []const u8, pos: *usize) bool {
    const rest = format[pos.*..];
    if (std.mem.indexOfScalar(u8, rest, '%')) |i| {
        util.bufAppend(sb, rest[0..i]);
        pos.* += i + 1;
        return true;
    }
    util.bufAppend(sb, rest);
    pos.* = format.len;
    return false;
}

/// strbuf_expand_literal(): %n and %xNN
fn expandLiteral(sb: *Buf, ph: []const u8) usize {
    switch (at(ph, 0)) {
        'n' => {
            util.bufByte(sb, '\n');
            return 1;
        },
        'x' => {
            const ch = hex2chr(ph[1..]) orelse return 0;
            util.bufByte(sb, ch);
            return 3;
        },
        else => return 0,
    }
}

const TrailerKey = struct { s: []const u8, len: usize };
const TrailerFilter = struct { keys: std.ArrayList(TrailerKey) = .empty };

fn trailerMatchCb(key: []const u8, data: ?*anyopaque) bool {
    const f: *TrailerFilter = @ptrCast(@alignCast(data.?));
    for (f.keys.items) |k| {
        if (key.len == k.len and k.s.len >= key.len and std.ascii.eqlIgnoreCase(k.s[0..key.len], key)) return true;
    }
    return false;
}

/// format_set_trailers_options(): parse "key=..,only,..." up to ')'.
/// Returns the number of bytes consumed, or null on error (invalid_arg set).
pub fn setTrailersOptions(opts: *trailer_mod.Options, arg: []const u8, invalid_arg: ?*[]const u8) ?usize {
    var pos: usize = 0;
    var filter: ?*TrailerFilter = null;
    while (true) {
        const s = arg[pos..];
        if (at(s, 0) == ')') break;
        if (matchArgValue(s, "key")) |m| {
            const v = m.val orelse return null;
            var len = v.len;
            if (len > 0 and v[len - 1] == ':') len -= 1;
            if (filter == null) {
                filter = gpa.create(TrailerFilter) catch util.oom();
                filter.?.* = .{};
            }
            // C keeps the pointer to the rest of the format string
            filter.?.keys.append(gpa, .{ .s = s[v.ptr - s.ptr ..], .len = len }) catch util.oom();
            opts.filter = trailerMatchCb;
            opts.filter_data = filter.?;
            opts.only_trailers = true;
            pos += m.end;
        } else if (matchArgValue(s, "separator")) |m| {
            opts.separator = expandStringArg(m.val orelse "");
            pos += m.end;
        } else if (matchArgValue(s, "key_value_separator")) |m| {
            opts.key_value_separator = expandStringArg(m.val orelse "");
            pos += m.end;
        } else if (matchBoolArg(s, "only", &opts.only_trailers)) |e| {
            pos += e;
        } else if (matchBoolArg(s, "unfold", &opts.unfold)) |e| {
            pos += e;
        } else if (matchBoolArg(s, "keyonly", &opts.key_only)) |e| {
            pos += e;
        } else if (matchBoolArg(s, "valueonly", &opts.value_only)) |e| {
            pos += e;
        } else {
            if (invalid_arg) |ia| {
                var l: usize = 0;
                while (l < s.len and s[l] != ',' and s[l] != ')') l += 1;
                ia.* = s[0..l];
            }
            return null;
        }
    }
    return pos;
}

fn strtolSpan(s: []const u8) usize {
    return strtol(s).end;
}

/// parse_describe_args(): returns bytes consumed.
fn parseDescribeArgs(start: []const u8, args: *std.ArrayList([]const u8)) usize {
    var pos: usize = 0;
    while (true) {
        const s = start[pos..];
        var optval = false;
        if (matchBoolArg(s, "tags", &optval)) |e| {
            args.append(gpa, if (optval) "--tags" else "--no-tags") catch util.oom();
            pos += e;
            continue;
        }
        if (matchArgValue(s, "abbrev")) |m| {
            const v = m.val orelse "";
            if (v.len == 0) return 0;
            if (strtolSpan(v) != v.len) return 0;
            args.append(gpa, util.concat(&.{ "--abbrev=", v })) catch util.oom();
            pos += m.end;
            continue;
        }
        var found = false;
        for ([_][]const u8{ "exclude", "match" }) |name| {
            if (matchArgValue(s, name)) |m| {
                const v = m.val orelse "";
                if (v.len == 0) return 0;
                args.append(gpa, util.concat(&.{ "--", name, "=", v })) catch util.oom();
                pos += m.end;
                found = true;
                break;
            }
        }
        if (!found) break;
    }
    return pos;
}

fn parseDecorationOptions(arg: []const u8, opts: *logtree.DecorationOptions) usize {
    var pos: usize = 0;
    while (true) {
        const s = arg[pos..];
        if (matchArgValue(s, "prefix")) |m| {
            opts.prefix = expandStringArg(m.val orelse "");
            pos += m.end;
        } else if (matchArgValue(s, "suffix")) |m| {
            opts.suffix = expandStringArg(m.val orelse "");
            pos += m.end;
        } else if (matchArgValue(s, "separator")) |m| {
            opts.separator = expandStringArg(m.val orelse "");
            pos += m.end;
        } else if (matchArgValue(s, "pointer")) |m| {
            opts.pointer = expandStringArg(m.val orelse "");
            pos += m.end;
        } else if (matchArgValue(s, "tag")) |m| {
            opts.tag = expandStringArg(m.val orelse "");
            pos += m.end;
        } else break;
    }
    return pos;
}

var diff_commit_color: ?[]const u8 = null;

fn commitColor(use: bool) []const u8 {
    if (!use) return "";
    if (diff_commit_color == null) {
        diff_commit_color = color_mod.YELLOW;
        for ([_][]const u8{ "diff.color.commit", "color.diff.commit" }) |k| {
            if (repo_mod.cfg.get(k)) |v| {
                if (color_mod.parseColor(v)) |col| diff_commit_color = col;
            }
        }
    }
    return diff_commit_color.?;
}

fn resetColor(use: bool) []const u8 {
    return if (use) color_mod.RESET else "";
}

fn runDescribe(sb: *Buf, args: []const []const u8, commit: *cn.Commit) void {
    var argv: std.ArrayList([]const u8) = .empty;
    const self_exe = os.readLink("/proc/self/exe") orelse "git";
    argv.appendSlice(gpa, &.{ "/bin/sh", "-c", "exec \"$@\" 2>/dev/null", "sh", self_exe, "describe" }) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    argv.append(gpa, hash.hexAlloc(commit.obj.oid)) catch util.oom();
    const r = os.run(argv.items, .{ .capture_stdout = true, .no_stdin = true });
    var out: Buf = .empty;
    util.bufAppend(&out, r.stdout);
    rtrimBuf(&out);
    util.bufAppend(sb, out.items);
}

fn formatCommitOne(sb: *Buf, ph: []const u8, c: *FormatContext) usize {
    const commit = c.commit;
    const pp = c.pp;

    const lit = expandLiteral(sb, ph);
    if (lit > 0) return lit;

    switch (at(ph, 0)) {
        'C' => {
            if (util.startsWith(ph[1..], "(auto)")) {
                c.auto_color = pp.color;
                if (c.auto_color and sb.items.len > 0) util.bufAppend(sb, color_mod.RESET);
                return 7;
            }
            const ret = parseColorPlaceholder(sb, ph, c);
            if (ret != 0) c.auto_color = false;
            return ret;
        },
        'w' => {
            if (at(ph, 1) != '(') return 0;
            const start: usize = 2;
            const end = std.mem.indexOfScalarPos(u8, ph, start, ')') orelse return 0;
            var width: u64 = 0;
            var indent1: u64 = 0;
            var indent2: u64 = 0;
            if (end > start) {
                var next: usize = start;
                const r1 = strtoul(ph[next..]);
                width = r1.val;
                next += r1.end;
                if (at(ph, next) == ',') {
                    next += 1;
                    const r2 = strtoul(ph[next..]);
                    indent1 = r2.val;
                    next += r2.end;
                    if (at(ph, next) == ',') {
                        next += 1;
                        const r3 = strtoul(ph[next..]);
                        indent2 = r3.val;
                        next += r3.end;
                    }
                }
                if (at(ph, next) != ')') return 0;
            }
            if (width > FORMATTING_LIMIT or indent1 > FORMATTING_LIMIT or indent2 > FORMATTING_LIMIT) return 0;
            rewrapMessageTail(sb, c, @intCast(width), @intCast(indent1), @intCast(indent2));
            return end + 1;
        },
        '<', '>' => return parsePaddingPlaceholder(ph, c),
        else => {},
    }

    if (util.skipPrefix(ph, "(describe")) |arg0| {
        if (pp.describe_max_invocations) |m| {
            if (m.* == 0) return 0;
            m.* -= 1;
        }
        var args: std.ArrayList([]const u8) = .empty;
        var arg = arg0;
        if (at(arg, 0) == ':') {
            arg = arg[1..];
            arg = arg[parseDescribeArgs(arg, &args)..];
        }
        if (at(arg, 0) != ')') return 0;
        runDescribe(sb, args.items, commit);
        return ph.len - arg.len + 1;
    }

    if (!commit.obj.parsed) _ = cn.parseObject(commit.obj.oid);

    if (util.startsWith(ph, "(count)")) {
        const rev = pp.rev orelse util.die("{s} is not supported by this command", .{"%(count)"});
        const w = decimalWidth(rev.total);
        var tmp: Buf = .empty;
        util.bufPrint(&tmp, "{d}", .{rev.nr});
        if (rev.nr >= 0) addChars(sb, '0', @as(i64, @intCast(w)) - @as(i64, @intCast(tmp.items.len)));
        util.bufAppend(sb, tmp.items);
        return 7;
    }
    if (util.startsWith(ph, "(total)")) {
        const rev = pp.rev orelse util.die("{s} is not supported by this command", .{"%(total)"});
        util.bufPrint(sb, "{d}", .{rev.total});
        return 7;
    }

    switch (at(ph, 0)) {
        'H' => {
            util.bufAppend(sb, commitColor(c.auto_color));
            addOidHex(sb, commit.obj.oid);
            util.bufAppend(sb, resetColor(c.auto_color));
            return 1;
        },
        'h' => {
            util.bufAppend(sb, commitColor(c.auto_color));
            addAbbrev(sb, commit.obj.oid, pp.abbrev);
            util.bufAppend(sb, resetColor(c.auto_color));
            return 1;
        },
        'T' => {
            addOidHex(sb, commit.tree);
            return 1;
        },
        't' => {
            addAbbrev(sb, commit.tree, pp.abbrev);
            return 1;
        },
        'P' => {
            var p = commit.parents;
            while (p) |x| : (p = x.next) {
                if (x != commit.parents.?) util.bufByte(sb, ' ');
                addOidHex(sb, x.item.obj.oid);
            }
            return 1;
        },
        'p' => {
            var p = commit.parents;
            while (p) |x| : (p = x.next) {
                if (x != commit.parents.?) util.bufByte(sb, ' ');
                addAbbrev(sb, x.item.obj.oid, pp.abbrev);
            }
            return 1;
        },
        'm' => {
            util.bufAppend(sb, revision.getRevisionMark(null, commit));
            return 1;
        },
        'd' => {
            logtree.loadRefDecorationsDefault();
            logtree.formatDecorations(sb, commit, c.auto_color, null);
            return 1;
        },
        'D' => {
            logtree.loadRefDecorationsDefault();
            const opts = logtree.DecorationOptions{ .prefix = "", .suffix = "" };
            logtree.formatDecorations(sb, commit, c.auto_color, &opts);
            return 1;
        },
        'S' => {
            const rev = pp.rev orelse return 0;
            const sources = rev.sources orelse return 0;
            const slot = sources.peek(commit) orelse return 0;
            const s = slot.* orelse return 0;
            util.bufAppend(sb, s);
            return 1;
        },
        'g' => {
            switch (at(ph, 1)) {
                'd', 'D' => {
                    if (pp.reflog_info) |ri|
                        reflogwalk.getReflogSelector(sb, ri, pp.date_mode, pp.date_mode_explicit, at(ph, 1) == 'd');
                    return 2;
                },
                's' => {
                    if (pp.reflog_info) |ri| reflogwalk.getReflogMessage(sb, ri);
                    return 2;
                },
                'n', 'N', 'e', 'E' => return formatReflogPerson(sb, ph[1], pp.reflog_info, pp.date_mode),
                else => return 0,
            }
        },
        'N' => {
            if (pp.notes_message) |n| {
                util.bufAppend(sb, n);
                return 1;
            }
            return 0;
        },
        'G' => {
            // No GPG support: every commit is reported as unsigned.
            switch (at(ph, 1)) {
                'G', 'S', 'K', 'F', 'P' => {},
                '?' => util.bufByte(sb, 'N'),
                'T' => util.bufAppend(sb, "undefined"),
                else => return 0,
            }
            return 2;
        },
        else => {},
    }

    if (util.skipPrefix(ph, "(decorate")) |arg0| {
        var opts = logtree.DecorationOptions{};
        var arg = arg0;
        if (at(arg, 0) == ':') {
            arg = arg[1..];
            arg = arg[parseDecorationOptions(arg, &opts)..];
        }
        if (at(arg, 0) == ')') {
            logtree.loadRefDecorationsDefault();
            logtree.formatDecorations(sb, commit, c.auto_color, &opts);
            return ph.len - arg.len + 1;
        }
        return 0;
    }

    if (!c.header_parsed) {
        const r = logmsgReencode(commit, "UTF-8");
        c.message = r.msg;
        c.commit_encoding = r.encoding;
        parseCommitHeader(c);
    }
    const msg = c.message;

    switch (at(ph, 0)) {
        'a' => return formatPersonPart(sb, at(ph, 1), msg[c.author.off .. c.author.off + c.author.len], pp.date_mode),
        'c' => return formatPersonPart(sb, at(ph, 1), msg[c.committer.off .. c.committer.off + c.committer.len], pp.date_mode),
        'e' => {
            if (c.commit_encoding) |e| util.bufAppend(sb, e);
            return 1;
        },
        'B' => {
            if (c.message_off + 1 <= msg.len) util.bufAppend(sb, msg[c.message_off + 1 ..]);
            return 1;
        },
        else => {},
    }

    if (!c.message_parsed) parseCommitMessage(c);

    switch (at(ph, 0)) {
        's' => {
            _ = formatSubject(sb, msg, c.subject_off, " ");
            return 1;
        },
        'f' => {
            const s = msg[c.subject_off..];
            const eol = std.mem.indexOfScalar(u8, s, '\n') orelse s.len;
            formatSanitizedSubject(sb, s[0..eol]);
            return 1;
        },
        'b' => {
            util.bufAppend(sb, msg[c.body_off..]);
            return 1;
        },
        else => {},
    }

    if (util.skipPrefix(ph, "(trailers")) |arg0| {
        var opts = trailer_mod.Options{ .no_divider = true };
        var arg = arg0;
        if (at(arg, 0) == ':') {
            arg = arg[1..];
            const n = setTrailersOptions(&opts, arg, null) orelse return 0;
            arg = arg[n..];
        }
        if (at(arg, 0) == ')') {
            trailer_mod.formatTrailersFromCommit(&opts, msg[c.subject_off..], sb);
            return ph.len - arg.len + 1;
        }
        return 0;
    }

    return 0;
}

fn formatAndPadCommit(sb: *Buf, ph0: []const u8, c: *FormatContext) usize {
    var local: Buf = .empty;
    var total_consumed: usize = 0;
    var padding: i64 = c.padding;
    var ph = ph0;

    if (padding < 0) {
        const start = std.mem.lastIndexOfScalar(u8, sb.items, '\n') orelse 0;
        var occupied = utf8Strnwidth(sb.items[start..], true);
        occupied += @intCast(c.pp.graph_width);
        padding = -padding - occupied;
    }
    while (true) {
        const modifier = at(ph, 0) == 'C';
        const consumed = formatCommitOne(&local, ph, c);
        total_consumed += consumed;
        if (!modifier) break;
        ph = ph[consumed..];
        if (at(ph, 0) != '%') break;
        ph = ph[1..];
        total_consumed += 1;
    }
    const len = utf8Strnwidth(local.items, true);

    if (c.flush_type == .flush_left_and_steal) {
        const buf = sb.items;
        var ch: isize = @as(isize, @intCast(buf.len)) - 1;
        while (len > padding and ch > 0) {
            const uch: usize = @intCast(ch);
            if (buf[uch] == ' ') {
                ch -= 1;
                padding += 1;
                continue;
            }
            if (buf[uch] != 'm') break;
            var p: isize = ch - 1;
            while (p > 0 and ch - p < 10 and buf[@intCast(p)] != 0x1b) p -= 1;
            const up: usize = @intCast(p);
            if (buf[up] != 0x1b or uch + 1 - up != displayModeEscSequenceLen(buf, up)) break;
            insertAt(&local, 0, buf[up .. uch + 1]);
            ch = p - 1;
        }
        sb.items.len = @intCast(ch + 1);
        c.flush_type = .flush_left;
    }

    if (len > padding) {
        switch (c.truncate) {
            .trunc_left => utf8Replace(&local, 0, len - (padding - 2), ".."),
            .trunc_middle => utf8Replace(&local, @divTrunc(padding, 2) - 1, len - (padding - 2), ".."),
            .trunc_right => utf8Replace(&local, padding - 2, len - (padding - 2), ".."),
            .trunc_none => {},
        }
        util.bufAppend(sb, local.items);
    } else {
        const sb_len = sb.items.len;
        var offset: usize = 0;
        if (c.flush_type == .flush_left) {
            offset = @intCast(padding - len);
        } else if (c.flush_type == .flush_both) {
            offset = @intCast(@divTrunc(padding - len, 2));
        }
        padding = padding - len + @as(i64, @intCast(local.items.len));
        addChars(sb, ' ', padding);
        @memcpy(sb.items[sb_len + offset .. sb_len + offset + local.items.len], local.items);
    }
    c.flush_type = .no_flush;
    return total_consumed;
}

fn formatCommitItem(sb: *Buf, ph0: []const u8, c: *FormatContext) usize {
    const Magic = enum { none, add_lf, del_lf, add_sp };
    var magic: Magic = .none;
    var ph = ph0;
    switch (at(ph, 0)) {
        '-' => magic = .del_lf,
        '+' => magic = .add_lf,
        ' ' => magic = .add_sp,
        else => {},
    }
    if (magic != .none) {
        ph = ph[1..];
        if (at(ph, 0) == 'w') return 0;
    }
    const orig_len = sb.items.len;
    const consumed = if (c.flush_type == .no_flush) formatCommitOne(sb, ph, c) else formatAndPadCommit(sb, ph, c);
    if (magic == .none) return consumed;

    if (orig_len == sb.items.len and magic == .del_lf) {
        while (sb.items.len > 0 and sb.items[sb.items.len - 1] == '\n') sb.items.len -= 1;
    } else if (orig_len != sb.items.len) {
        if (magic == .add_lf) insertAt(sb, orig_len, "\n") else if (magic == .add_sp) insertAt(sb, orig_len, " ");
    }
    return consumed + 1;
}

pub const Requirements = struct { notes: bool = false, source: bool = false, decorate: bool = false };

/// userformat_find_requirements()
pub fn userformatFindRequirements(fmt0: ?[]const u8) Requirements {
    var w = Requirements{};
    const fmt = fmt0 orelse (user_format orelse return w);
    var pos: usize = 0;
    while (std.mem.indexOfScalarPos(u8, fmt, pos, '%')) |i| {
        pos = i + 1;
        if (at(fmt, pos) == '%') {
            pos += 1;
            continue;
        }
        if (at(fmt, pos) == '+' or at(fmt, pos) == '-' or at(fmt, pos) == ' ') pos += 1;
        switch (at(fmt, pos)) {
            'N' => w.notes = true,
            'S' => w.source = true,
            'd', 'D' => w.decorate = true,
            '(' => {
                if (util.startsWith(fmt[pos + 1 ..], "decorate")) w.decorate = true;
            },
            else => {},
        }
    }
    return w;
}

/// repo_format_commit_message()
pub fn formatCommitMessage(commit: *cn.Commit, format: []const u8, sb: *Buf, ctx: *const Context) void {
    var c = FormatContext{ .commit = commit, .pp = ctx, .wrap_start = sb.items.len };
    var pos: usize = 0;
    while (expandStep(sb, format, &pos)) {
        const rest = format[pos..];
        if (at(rest, 0) == '%') {
            util.bufByte(sb, '%');
            pos += 1;
        } else {
            const len = formatCommitItem(sb, rest, &c);
            if (len > 0) pos += len else util.bufByte(sb, '%');
        }
    }
    rewrapMessageTail(sb, &c, 0, 0, 0);

    var output_enc = ctx.output_encoding;
    if (output_enc) |oe| {
        if (sameEncoding("UTF-8", oe)) output_enc = null;
    } else {
        if (c.commit_encoding) |ce| {
            if (!sameEncoding(ce, "UTF-8")) output_enc = ce;
        }
    }
    if (output_enc) |oe| {
        if (reencodeString(sb.items, oe, "UTF-8")) |out| {
            sb.clearRetainingCapacity();
            util.bufAppend(sb, out);
        }
    }
}

// ---------------------------------------------------------------------------
// pretty_print_commit

fn ppHeader(pp: *Context, encoding: []const u8, commit: *const cn.Commit, msg: []const u8, pos: *usize, sb: *Buf) void {
    var parents_shown = false;
    while (true) {
        const line = msg[pos.*..];
        const linelen = getOneLine(msg, pos.*);
        if (linelen == 0) return;
        pos.* += linelen;
        if (linelen == 1) return;
        if (pp.fmt == .raw) {
            util.bufAppend(sb, line[0..linelen]);
            continue;
        }
        if (util.startsWith(line, "parent ")) {
            if (linelen != hash.HEXSZ + 8) util.die("bad parent line in commit", .{});
            continue;
        }
        if (!parents_shown) {
            addMergeInfo(pp, sb, commit);
            parents_shown = true;
        }
        if (util.skipPrefix(line, "author ")) |name| {
            ppUserInfo(pp, "Author", sb, name, encoding);
        }
        if (util.skipPrefix(line, "committer ")) |name| {
            if (pp.fmt == .full or pp.fmt == .fuller) ppUserInfo(pp, "Commit", sb, name, encoding);
        }
    }
}

/// fmt_output_email_subject()
pub fn fmtOutputEmailSubject(sb: *Buf, rev: ?*revision.RevInfo) void {
    const opt = rev orelse {
        util.bufAppend(sb, "Subject: ");
        return;
    };
    const prefix = opt.subject_prefix orelse "";
    if (opt.total > 0) {
        util.bufPrint(sb, "Subject: [{s}{s}", .{ prefix, if (prefix.len > 0) " " else "" });
        const w = decimalWidth(opt.total);
        var tmp: Buf = .empty;
        util.bufPrint(&tmp, "{d}", .{opt.nr});
        if (opt.nr >= 0) addChars(sb, '0', @as(i64, @intCast(w)) - @as(i64, @intCast(tmp.items.len)));
        util.bufAppend(sb, tmp.items);
        util.bufPrint(sb, "/{d}] ", .{opt.total});
    } else if (opt.total == 0 and prefix.len > 0) {
        util.bufPrint(sb, "Subject: [{s}] ", .{prefix});
    } else {
        util.bufAppend(sb, "Subject: ");
    }
}

/// pp_email_subject()
pub fn ppEmailSubject(pp: *Context, msg: []const u8, pos: *usize, sb: *Buf, encoding: []const u8, need_8bit_cte0: i32) void {
    const max_length = 78;
    var need_8bit_cte = need_8bit_cte0;
    var title: Buf = .empty;
    pos.* = formatSubject(&title, msg, pos.*, if (pp.preserve_subject) "\n" else " ");

    fmtOutputEmailSubject(sb, pp.rev);
    if (encodeEmailHeaders(pp) and needsRfc2047Encoding(title.items)) {
        addRfc2047(sb, title.items, encoding, .subject);
    } else {
        addWrappedText(sb, title.items, -@as(i64, @intCast(lastLineLength(sb))), 1, max_length);
    }
    util.bufByte(sb, '\n');

    if (need_8bit_cte == 0) {
        for (pp.in_body_headers.items) |h| {
            if (hasNonAscii(h)) {
                need_8bit_cte = 1;
                break;
            }
        }
    }
    if (need_8bit_cte > 0) {
        util.bufPrint(sb, "MIME-Version: 1.0\nContent-Type: text/plain; charset={s}\nContent-Transfer-Encoding: 8bit\n", .{encoding});
    }
    if (pp.after_subject) |a| util.bufAppend(sb, a);
    util.bufByte(sb, '\n');
    if (pp.in_body_headers.items.len > 0) {
        for (pp.in_body_headers.items) |h| util.bufAppend(sb, h);
        pp.in_body_headers.clearRetainingCapacity();
        util.bufByte(sb, '\n');
    }
}

fn ppUtf8Width(s: []const u8) ?i64 {
    var width: i64 = 0;
    var pos: usize = 0;
    var remain: usize = s.len;
    while (remain > 0) {
        const n = utf8WidthRem(s, &pos, &remain) orelse return null;
        if (n < 0) return null;
        width += n;
    }
    return width;
}

fn addTabexpand(sb: *Buf, tabwidth: i32, line0: []const u8) void {
    var line = line0;
    while (std.mem.indexOfScalar(u8, line, '\t')) |tab| {
        const width = ppUtf8Width(line[0..tab]) orelse break;
        util.bufAppend(sb, line[0..tab]);
        addChars(sb, ' ', tabwidth - @mod(width, tabwidth));
        line = line[tab + 1 ..];
    }
    util.bufAppend(sb, line);
}

fn ppHandleIndent(pp: *const Context, sb: *Buf, indent: i64, line: []const u8) void {
    addChars(sb, ' ', indent);
    if (pp.expand_tabs_in_log != 0) addTabexpand(sb, pp.expand_tabs_in_log, line) else util.bufAppend(sb, line);
}

fn isMboxrdFrom(line: []const u8) bool {
    if (line.len <= 4) return false;
    var i: usize = 0;
    while (i < line.len and line[i] == '>') i += 1;
    return util.startsWith(line[i..], "From ");
}

/// pp_remainder()
pub fn ppRemainder(pp: *const Context, msg: []const u8, pos: *usize, sb: *Buf, indent: i64) void {
    var first = true;
    while (true) {
        const start = pos.*;
        var linelen = getOneLine(msg, start);
        pos.* += linelen;
        if (linelen == 0) break;
        const line = msg[start..];
        if (isBlankLine(line, &linelen)) {
            if (first) continue;
            if (pp.fmt == .short) break;
        }
        first = false;
        if (indent != 0) {
            ppHandleIndent(pp, sb, indent, line[0..linelen]);
        } else if (pp.expand_tabs_in_log != 0) {
            addTabexpand(sb, pp.expand_tabs_in_log, line[0..linelen]);
        } else {
            if (pp.fmt == .mboxrd and isMboxrdFrom(line[0..linelen])) util.bufByte(sb, '>');
            util.bufAppend(sb, line[0..linelen]);
        }
        util.bufByte(sb, '\n');
    }
}

/// pretty_print_commit()
pub fn prettyPrintCommit(ctx: *Context, commit: *cn.Commit, sb: *Buf) void {
    if (ctx.fmt == .userformat) {
        const f = ctx.fmt_string orelse user_format orelse (if (ctx.rev) |r| r.user_format else "");
        formatCommitMessage(commit, f, sb, ctx);
        return;
    }
    var need_8bit_cte = ctx.need_8bit_cte;
    const encoding = logOutputEncoding();
    const msg = logmsgReencode(commit, encoding).msg;
    var indent: i64 = 4;
    if (ctx.fmt == .oneline or isMail(ctx.fmt)) indent = 0;

    if (isMail(ctx.fmt) and need_8bit_cte == 0) {
        var in_body = false;
        for (msg, 0..) |ch, i| {
            if (!in_body) {
                if (ch == '\n' and at(msg, i + 1) == '\n') in_body = true;
            } else if (nonAscii(ch)) {
                need_8bit_cte = 1;
                break;
            }
        }
    }

    var pos: usize = 0;
    ppHeader(ctx, encoding, commit, msg, &pos, sb);
    if (ctx.fmt != .oneline and !isMail(ctx.fmt)) util.bufByte(sb, '\n');

    pos = skipBlankLines(msg, pos);

    if (ctx.fmt == .oneline) {
        pos = formatSubject(sb, msg, pos, " ");
        util.bufByte(sb, '\n');
    } else if (isMail(ctx.fmt)) {
        ppEmailSubject(ctx, msg, &pos, sb, encoding, need_8bit_cte);
    }

    const beginning_of_body = sb.items.len;
    if (ctx.fmt != .oneline) ppRemainder(ctx, msg, &pos, sb, indent);
    rtrimBuf(sb);
    if (ctx.fmt != .oneline) util.bufByte(sb, '\n');
    if (isMail(ctx.fmt) and sb.items.len <= beginning_of_body) util.bufByte(sb, '\n');
}

/// pp_commit_easy()
pub fn ppCommitEasy(fmt: Fmt, commit: *cn.Commit, sb: *Buf) void {
    var ctx = Context{ .fmt = fmt };
    prettyPrintCommit(&ctx, commit, sb);
}

// ---------------------------------------------------------------------------
// utf8.c helpers

/// display_mode_esc_sequence_len(): length of an "ESC [ ... m" sequence at s[i].
pub fn displayModeEscSequenceLen(s: []const u8, i: usize) usize {
    var p = i;
    if (at(s, p) != 0x1b) return 0;
    p += 1;
    if (at(s, p) != '[') return 0;
    p += 1;
    while (isDigit(at(s, p)) or at(s, p) == ';') p += 1;
    if (at(s, p) != 'm') return 0;
    p += 1;
    return p - i;
}

fn bisearch(ucs: u32, table: []const [2]u32) bool {
    if (ucs < table[0][0] or ucs > table[table.len - 1][1]) return false;
    var min: isize = 0;
    var max: isize = @as(isize, @intCast(table.len)) - 1;
    while (max >= min) {
        const mid = min + @divTrunc(max - min, 2);
        const e = table[@intCast(mid)];
        if (ucs > e[1]) {
            min = mid + 1;
        } else if (ucs < e[0]) {
            max = mid - 1;
        } else return true;
    }
    return false;
}

/// git_wcwidth()
pub fn gitWcwidth(ch: u32) i32 {
    if (ch == 0) return 0;
    if (ch < 32 or (ch >= 0x7f and ch < 0xa0)) return -1;
    if (bisearch(ch, &zero_width_tbl)) return 0;
    if (bisearch(ch, &double_width_tbl)) return 2;
    return 1;
}

/// pick_one_utf8_char(): decode one char at s[pos.*] (bytes past the end read
/// as NUL). Returns null if invalid (git sets *start = NULL then).
pub fn pickOneUtf8Char(s: []const u8, pos: *usize, remainder_p: ?*usize) ?u32 {
    const i = pos.*;
    const remainder: usize = if (remainder_p) |r| r.* else 999;
    const s0 = at(s, i);
    const s1 = at(s, i + 1);
    const s2 = at(s, i + 2);
    const s3 = at(s, i + 3);
    var ch: u32 = 0;
    var incr: usize = 0;
    if (remainder < 1) {
        return null;
    } else if (s0 < 0x80) {
        ch = s0;
        incr = 1;
    } else if ((s0 & 0xe0) == 0xc0) {
        if (remainder < 2 or (s1 & 0xc0) != 0x80 or (s0 & 0xfe) == 0xc0) return null;
        ch = (@as(u32, s0 & 0x1f) << 6) | (s1 & 0x3f);
        incr = 2;
    } else if ((s0 & 0xf0) == 0xe0) {
        if (remainder < 3 or (s1 & 0xc0) != 0x80 or (s2 & 0xc0) != 0x80 or
            (s0 == 0xe0 and (s1 & 0xe0) == 0x80) or
            (s0 == 0xed and (s1 & 0xe0) == 0xa0) or
            (s0 == 0xef and s1 == 0xbf and (s2 & 0xfe) == 0xbe)) return null;
        ch = (@as(u32, s0 & 0x0f) << 12) | (@as(u32, s1 & 0x3f) << 6) | (s2 & 0x3f);
        incr = 3;
    } else if ((s0 & 0xf8) == 0xf0) {
        if (remainder < 4 or (s1 & 0xc0) != 0x80 or (s2 & 0xc0) != 0x80 or (s3 & 0xc0) != 0x80 or
            (s0 == 0xf0 and (s1 & 0xf0) == 0x80) or
            (s0 == 0xf4 and s1 > 0x8f) or s0 > 0xf4) return null;
        ch = (@as(u32, s0 & 0x07) << 18) | (@as(u32, s1 & 0x3f) << 12) | (@as(u32, s2 & 0x3f) << 6) | (s3 & 0x3f);
        incr = 4;
    } else return null;
    pos.* += incr;
    if (remainder_p) |r| r.* -= incr;
    return ch;
}

/// utf8_width() without a remainder; null = invalid UTF-8.
pub fn utf8Width(s: []const u8, pos: *usize) ?i32 {
    const ch = pickOneUtf8Char(s, pos, null) orelse return null;
    return gitWcwidth(ch);
}

fn utf8WidthRem(s: []const u8, pos: *usize, rem: *usize) ?i32 {
    const ch = pickOneUtf8Char(s, pos, rem) orelse return null;
    return gitWcwidth(ch);
}

/// utf8_strnwidth(): display width; returns s.len if not valid UTF-8.
pub fn utf8Strnwidth(s: []const u8, skip_ansi: bool) i64 {
    var i: usize = 0;
    var width: i64 = 0;
    while (i < s.len) {
        if (skip_ansi) {
            while (true) {
                const k = displayModeEscSequenceLen(s, i);
                if (k == 0) break;
                i += k;
            }
        }
        const w = utf8Width(s, &i) orelse return @intCast(s.len);
        if (w > 0) width += w;
    }
    return width;
}

/// utf8_strwidth()
pub fn utf8Strwidth(s: []const u8) i64 {
    return utf8Strnwidth(s, false);
}

/// is_utf8()
pub fn isUtf8(text: []const u8) bool {
    var i: usize = 0;
    while (i < text.len and text[i] != 0) {
        if (text[i] == '\n' or text[i] == '\t' or text[i] == '\r') {
            i += 1;
            continue;
        }
        _ = utf8Width(text, &i) orelse return false;
    }
    return true;
}

fn addIndentedText(buf: *Buf, text: []const u8, indent0: i64, indent2: i64) void {
    var indent = if (indent0 < 0) 0 else indent0;
    var t: usize = 0;
    while (t < text.len) {
        var eol = std.mem.indexOfScalarPos(u8, text, t, '\n') orelse text.len;
        if (eol < text.len) eol += 1;
        addChars(buf, ' ', indent);
        util.bufAppend(buf, text[t..eol]);
        t = eol;
        indent = indent2;
    }
}

/// strbuf_add_wrapped_text()
pub fn addWrappedText(buf: *Buf, text0: []const u8, indent1: i64, indent2: i64, width: i64) void {
    const text = cstr(text0);
    if (width <= 0) {
        addIndentedText(buf, text, indent1, indent2);
        return;
    }
    var assume_utf8 = true;
    const orig_len = buf.items.len;
    retry: while (true) {
        var t: usize = 0;
        var bol: usize = 0;
        var indent: i64 = indent1;
        var w: i64 = indent1;
        var space: ?usize = null;
        if (indent < 0) {
            w = -indent;
            space = 0;
        }
        while (true) {
            while (true) {
                const k = displayModeEscSequenceLen(text, t);
                if (k == 0) break;
                t += k;
            }
            const c = at(text, t);
            if (c == 0 or isSpace(c)) {
                var new_line = false;
                if (w <= width or space == null) {
                    var start = bol;
                    if (c == 0 and t == start) return;
                    if (space) |sp| start = sp else addChars(buf, ' ', indent);
                    util.bufAppend(buf, text[start..t]);
                    if (c == 0) return;
                    space = t;
                    if (c == '\t') {
                        w |= 0x07;
                    } else if (c == '\n') {
                        space.? += 1;
                        const nc = at(text, space.?);
                        if (nc == '\n') {
                            util.bufByte(buf, '\n');
                            new_line = true;
                        } else if (!isAlnum(nc)) {
                            new_line = true;
                        } else util.bufByte(buf, ' ');
                    }
                    if (!new_line) {
                        w += 1;
                        t += 1;
                    }
                } else new_line = true;
                if (new_line) {
                    util.bufByte(buf, '\n');
                    const sp = space.?;
                    t = sp + @intFromBool(isSpace(at(text, sp)));
                    bol = t;
                    space = null;
                    indent = indent2;
                    w = indent2;
                }
                continue;
            }
            if (assume_utf8) {
                if (utf8Width(text, &t)) |cw| {
                    w += cw;
                } else {
                    assume_utf8 = false;
                    buf.items.len = orig_len;
                    continue :retry;
                }
            } else {
                w += 1;
                t += 1;
            }
        }
    }
}

/// strbuf_utf8_replace(): replace the columns [pos, pos+width) with subst.
pub fn utf8Replace(sb: *Buf, pos: i64, width: i64, subst0: ?[]const u8) void {
    var subst = subst0;
    const src = sb.items;
    var dst: Buf = .empty;
    var i: usize = 0;
    var w: i64 = 0;
    while (i < src.len) {
        while (true) {
            const n = displayModeEscSequenceLen(src, i);
            if (n == 0) break;
            util.bufAppend(&dst, src[i .. i + n]);
            i += n;
        }
        if (i >= src.len) break;
        const old = i;
        var gw: i64 = utf8Width(src, &i) orelse return;
        if (gw < 0) gw = 0;
        if (gw != 0 and w >= pos and w < pos + width) {
            if (subst) |s| {
                util.bufAppend(&dst, s);
                subst = null;
            }
        } else {
            util.bufAppend(&dst, src[old..@min(i, src.len)]);
        }
        w += gw;
    }
    sb.* = dst;
}

/// mbs_chrlen()
pub fn mbsChrlen(text: []const u8, pos: *usize, remainder_p: *usize, encoding: []const u8) usize {
    if (remainder_p.* < 1) return 0;
    var chrlen: usize = 1;
    if (isEncodingUtf8(encoding)) {
        var p = pos.*;
        var r = remainder_p.*;
        if (pickOneUtf8Char(text, &p, &r) != null) chrlen = p - pos.*;
    }
    pos.* += chrlen;
    remainder_p.* -= chrlen;
    return chrlen;
}

// Unicode width tables (generated from git's unicode-width.h)
const zero_width_tbl = [_][2]u32{
    .{ 0x0300, 0x036F },
    .{ 0x0483, 0x0489 },
    .{ 0x0591, 0x05BD },
    .{ 0x05BF, 0x05BF },
    .{ 0x05C1, 0x05C2 },
    .{ 0x05C4, 0x05C5 },
    .{ 0x05C7, 0x05C7 },
    .{ 0x0600, 0x0605 },
    .{ 0x0610, 0x061A },
    .{ 0x061C, 0x061C },
    .{ 0x064B, 0x065F },
    .{ 0x0670, 0x0670 },
    .{ 0x06D6, 0x06DD },
    .{ 0x06DF, 0x06E4 },
    .{ 0x06E7, 0x06E8 },
    .{ 0x06EA, 0x06ED },
    .{ 0x070F, 0x070F },
    .{ 0x0711, 0x0711 },
    .{ 0x0730, 0x074A },
    .{ 0x07A6, 0x07B0 },
    .{ 0x07EB, 0x07F3 },
    .{ 0x07FD, 0x07FD },
    .{ 0x0816, 0x0819 },
    .{ 0x081B, 0x0823 },
    .{ 0x0825, 0x0827 },
    .{ 0x0829, 0x082D },
    .{ 0x0859, 0x085B },
    .{ 0x0890, 0x0891 },
    .{ 0x0897, 0x089F },
    .{ 0x08CA, 0x0902 },
    .{ 0x093A, 0x093A },
    .{ 0x093C, 0x093C },
    .{ 0x0941, 0x0948 },
    .{ 0x094D, 0x094D },
    .{ 0x0951, 0x0957 },
    .{ 0x0962, 0x0963 },
    .{ 0x0981, 0x0981 },
    .{ 0x09BC, 0x09BC },
    .{ 0x09C1, 0x09C4 },
    .{ 0x09CD, 0x09CD },
    .{ 0x09E2, 0x09E3 },
    .{ 0x09FE, 0x09FE },
    .{ 0x0A01, 0x0A02 },
    .{ 0x0A3C, 0x0A3C },
    .{ 0x0A41, 0x0A42 },
    .{ 0x0A47, 0x0A48 },
    .{ 0x0A4B, 0x0A4D },
    .{ 0x0A51, 0x0A51 },
    .{ 0x0A70, 0x0A71 },
    .{ 0x0A75, 0x0A75 },
    .{ 0x0A81, 0x0A82 },
    .{ 0x0ABC, 0x0ABC },
    .{ 0x0AC1, 0x0AC5 },
    .{ 0x0AC7, 0x0AC8 },
    .{ 0x0ACD, 0x0ACD },
    .{ 0x0AE2, 0x0AE3 },
    .{ 0x0AFA, 0x0AFF },
    .{ 0x0B01, 0x0B01 },
    .{ 0x0B3C, 0x0B3C },
    .{ 0x0B3F, 0x0B3F },
    .{ 0x0B41, 0x0B44 },
    .{ 0x0B4D, 0x0B4D },
    .{ 0x0B55, 0x0B56 },
    .{ 0x0B62, 0x0B63 },
    .{ 0x0B82, 0x0B82 },
    .{ 0x0BC0, 0x0BC0 },
    .{ 0x0BCD, 0x0BCD },
    .{ 0x0C00, 0x0C00 },
    .{ 0x0C04, 0x0C04 },
    .{ 0x0C3C, 0x0C3C },
    .{ 0x0C3E, 0x0C40 },
    .{ 0x0C46, 0x0C48 },
    .{ 0x0C4A, 0x0C4D },
    .{ 0x0C55, 0x0C56 },
    .{ 0x0C62, 0x0C63 },
    .{ 0x0C81, 0x0C81 },
    .{ 0x0CBC, 0x0CBC },
    .{ 0x0CBF, 0x0CBF },
    .{ 0x0CC6, 0x0CC6 },
    .{ 0x0CCC, 0x0CCD },
    .{ 0x0CE2, 0x0CE3 },
    .{ 0x0D00, 0x0D01 },
    .{ 0x0D3B, 0x0D3C },
    .{ 0x0D41, 0x0D44 },
    .{ 0x0D4D, 0x0D4D },
    .{ 0x0D62, 0x0D63 },
    .{ 0x0D81, 0x0D81 },
    .{ 0x0DCA, 0x0DCA },
    .{ 0x0DD2, 0x0DD4 },
    .{ 0x0DD6, 0x0DD6 },
    .{ 0x0E31, 0x0E31 },
    .{ 0x0E34, 0x0E3A },
    .{ 0x0E47, 0x0E4E },
    .{ 0x0EB1, 0x0EB1 },
    .{ 0x0EB4, 0x0EBC },
    .{ 0x0EC8, 0x0ECE },
    .{ 0x0F18, 0x0F19 },
    .{ 0x0F35, 0x0F35 },
    .{ 0x0F37, 0x0F37 },
    .{ 0x0F39, 0x0F39 },
    .{ 0x0F71, 0x0F7E },
    .{ 0x0F80, 0x0F84 },
    .{ 0x0F86, 0x0F87 },
    .{ 0x0F8D, 0x0F97 },
    .{ 0x0F99, 0x0FBC },
    .{ 0x0FC6, 0x0FC6 },
    .{ 0x102D, 0x1030 },
    .{ 0x1032, 0x1037 },
    .{ 0x1039, 0x103A },
    .{ 0x103D, 0x103E },
    .{ 0x1058, 0x1059 },
    .{ 0x105E, 0x1060 },
    .{ 0x1071, 0x1074 },
    .{ 0x1082, 0x1082 },
    .{ 0x1085, 0x1086 },
    .{ 0x108D, 0x108D },
    .{ 0x109D, 0x109D },
    .{ 0x1160, 0x11FF },
    .{ 0x135D, 0x135F },
    .{ 0x1712, 0x1714 },
    .{ 0x1732, 0x1733 },
    .{ 0x1752, 0x1753 },
    .{ 0x1772, 0x1773 },
    .{ 0x17B4, 0x17B5 },
    .{ 0x17B7, 0x17BD },
    .{ 0x17C6, 0x17C6 },
    .{ 0x17C9, 0x17D3 },
    .{ 0x17DD, 0x17DD },
    .{ 0x180B, 0x180F },
    .{ 0x1885, 0x1886 },
    .{ 0x18A9, 0x18A9 },
    .{ 0x1920, 0x1922 },
    .{ 0x1927, 0x1928 },
    .{ 0x1932, 0x1932 },
    .{ 0x1939, 0x193B },
    .{ 0x1A17, 0x1A18 },
    .{ 0x1A1B, 0x1A1B },
    .{ 0x1A56, 0x1A56 },
    .{ 0x1A58, 0x1A5E },
    .{ 0x1A60, 0x1A60 },
    .{ 0x1A62, 0x1A62 },
    .{ 0x1A65, 0x1A6C },
    .{ 0x1A73, 0x1A7C },
    .{ 0x1A7F, 0x1A7F },
    .{ 0x1AB0, 0x1ADD },
    .{ 0x1AE0, 0x1AEB },
    .{ 0x1B00, 0x1B03 },
    .{ 0x1B34, 0x1B34 },
    .{ 0x1B36, 0x1B3A },
    .{ 0x1B3C, 0x1B3C },
    .{ 0x1B42, 0x1B42 },
    .{ 0x1B6B, 0x1B73 },
    .{ 0x1B80, 0x1B81 },
    .{ 0x1BA2, 0x1BA5 },
    .{ 0x1BA8, 0x1BA9 },
    .{ 0x1BAB, 0x1BAD },
    .{ 0x1BE6, 0x1BE6 },
    .{ 0x1BE8, 0x1BE9 },
    .{ 0x1BED, 0x1BED },
    .{ 0x1BEF, 0x1BF1 },
    .{ 0x1C2C, 0x1C33 },
    .{ 0x1C36, 0x1C37 },
    .{ 0x1CD0, 0x1CD2 },
    .{ 0x1CD4, 0x1CE0 },
    .{ 0x1CE2, 0x1CE8 },
    .{ 0x1CED, 0x1CED },
    .{ 0x1CF4, 0x1CF4 },
    .{ 0x1CF8, 0x1CF9 },
    .{ 0x1DC0, 0x1DFF },
    .{ 0x200B, 0x200F },
    .{ 0x202A, 0x202E },
    .{ 0x2060, 0x2064 },
    .{ 0x2066, 0x206F },
    .{ 0x20D0, 0x20F0 },
    .{ 0x2CEF, 0x2CF1 },
    .{ 0x2D7F, 0x2D7F },
    .{ 0x2DE0, 0x2DFF },
    .{ 0x302A, 0x302D },
    .{ 0x3099, 0x309A },
    .{ 0xA66F, 0xA672 },
    .{ 0xA674, 0xA67D },
    .{ 0xA69E, 0xA69F },
    .{ 0xA6F0, 0xA6F1 },
    .{ 0xA802, 0xA802 },
    .{ 0xA806, 0xA806 },
    .{ 0xA80B, 0xA80B },
    .{ 0xA825, 0xA826 },
    .{ 0xA82C, 0xA82C },
    .{ 0xA8C4, 0xA8C5 },
    .{ 0xA8E0, 0xA8F1 },
    .{ 0xA8FF, 0xA8FF },
    .{ 0xA926, 0xA92D },
    .{ 0xA947, 0xA951 },
    .{ 0xA980, 0xA982 },
    .{ 0xA9B3, 0xA9B3 },
    .{ 0xA9B6, 0xA9B9 },
    .{ 0xA9BC, 0xA9BD },
    .{ 0xA9E5, 0xA9E5 },
    .{ 0xAA29, 0xAA2E },
    .{ 0xAA31, 0xAA32 },
    .{ 0xAA35, 0xAA36 },
    .{ 0xAA43, 0xAA43 },
    .{ 0xAA4C, 0xAA4C },
    .{ 0xAA7C, 0xAA7C },
    .{ 0xAAB0, 0xAAB0 },
    .{ 0xAAB2, 0xAAB4 },
    .{ 0xAAB7, 0xAAB8 },
    .{ 0xAABE, 0xAABF },
    .{ 0xAAC1, 0xAAC1 },
    .{ 0xAAEC, 0xAAED },
    .{ 0xAAF6, 0xAAF6 },
    .{ 0xABE5, 0xABE5 },
    .{ 0xABE8, 0xABE8 },
    .{ 0xABED, 0xABED },
    .{ 0xFB1E, 0xFB1E },
    .{ 0xFE00, 0xFE0F },
    .{ 0xFE20, 0xFE2F },
    .{ 0xFEFF, 0xFEFF },
    .{ 0xFFF9, 0xFFFB },
    .{ 0x101FD, 0x101FD },
    .{ 0x102E0, 0x102E0 },
    .{ 0x10376, 0x1037A },
    .{ 0x10A01, 0x10A03 },
    .{ 0x10A05, 0x10A06 },
    .{ 0x10A0C, 0x10A0F },
    .{ 0x10A38, 0x10A3A },
    .{ 0x10A3F, 0x10A3F },
    .{ 0x10AE5, 0x10AE6 },
    .{ 0x10D24, 0x10D27 },
    .{ 0x10D69, 0x10D6D },
    .{ 0x10EAB, 0x10EAC },
    .{ 0x10EFA, 0x10EFF },
    .{ 0x10F46, 0x10F50 },
    .{ 0x10F82, 0x10F85 },
    .{ 0x11001, 0x11001 },
    .{ 0x11038, 0x11046 },
    .{ 0x11070, 0x11070 },
    .{ 0x11073, 0x11074 },
    .{ 0x1107F, 0x11081 },
    .{ 0x110B3, 0x110B6 },
    .{ 0x110B9, 0x110BA },
    .{ 0x110BD, 0x110BD },
    .{ 0x110C2, 0x110C2 },
    .{ 0x110CD, 0x110CD },
    .{ 0x11100, 0x11102 },
    .{ 0x11127, 0x1112B },
    .{ 0x1112D, 0x11134 },
    .{ 0x11173, 0x11173 },
    .{ 0x11180, 0x11181 },
    .{ 0x111B6, 0x111BE },
    .{ 0x111C9, 0x111CC },
    .{ 0x111CF, 0x111CF },
    .{ 0x1122F, 0x11231 },
    .{ 0x11234, 0x11234 },
    .{ 0x11236, 0x11237 },
    .{ 0x1123E, 0x1123E },
    .{ 0x11241, 0x11241 },
    .{ 0x112DF, 0x112DF },
    .{ 0x112E3, 0x112EA },
    .{ 0x11300, 0x11301 },
    .{ 0x1133B, 0x1133C },
    .{ 0x11340, 0x11340 },
    .{ 0x11366, 0x1136C },
    .{ 0x11370, 0x11374 },
    .{ 0x113BB, 0x113C0 },
    .{ 0x113CE, 0x113CE },
    .{ 0x113D0, 0x113D0 },
    .{ 0x113D2, 0x113D2 },
    .{ 0x113E1, 0x113E2 },
    .{ 0x11438, 0x1143F },
    .{ 0x11442, 0x11444 },
    .{ 0x11446, 0x11446 },
    .{ 0x1145E, 0x1145E },
    .{ 0x114B3, 0x114B8 },
    .{ 0x114BA, 0x114BA },
    .{ 0x114BF, 0x114C0 },
    .{ 0x114C2, 0x114C3 },
    .{ 0x115B2, 0x115B5 },
    .{ 0x115BC, 0x115BD },
    .{ 0x115BF, 0x115C0 },
    .{ 0x115DC, 0x115DD },
    .{ 0x11633, 0x1163A },
    .{ 0x1163D, 0x1163D },
    .{ 0x1163F, 0x11640 },
    .{ 0x116AB, 0x116AB },
    .{ 0x116AD, 0x116AD },
    .{ 0x116B0, 0x116B5 },
    .{ 0x116B7, 0x116B7 },
    .{ 0x1171D, 0x1171D },
    .{ 0x1171F, 0x1171F },
    .{ 0x11722, 0x11725 },
    .{ 0x11727, 0x1172B },
    .{ 0x1182F, 0x11837 },
    .{ 0x11839, 0x1183A },
    .{ 0x1193B, 0x1193C },
    .{ 0x1193E, 0x1193E },
    .{ 0x11943, 0x11943 },
    .{ 0x119D4, 0x119D7 },
    .{ 0x119DA, 0x119DB },
    .{ 0x119E0, 0x119E0 },
    .{ 0x11A01, 0x11A0A },
    .{ 0x11A33, 0x11A38 },
    .{ 0x11A3B, 0x11A3E },
    .{ 0x11A47, 0x11A47 },
    .{ 0x11A51, 0x11A56 },
    .{ 0x11A59, 0x11A5B },
    .{ 0x11A8A, 0x11A96 },
    .{ 0x11A98, 0x11A99 },
    .{ 0x11B60, 0x11B60 },
    .{ 0x11B62, 0x11B64 },
    .{ 0x11B66, 0x11B66 },
    .{ 0x11C30, 0x11C36 },
    .{ 0x11C38, 0x11C3D },
    .{ 0x11C3F, 0x11C3F },
    .{ 0x11C92, 0x11CA7 },
    .{ 0x11CAA, 0x11CB0 },
    .{ 0x11CB2, 0x11CB3 },
    .{ 0x11CB5, 0x11CB6 },
    .{ 0x11D31, 0x11D36 },
    .{ 0x11D3A, 0x11D3A },
    .{ 0x11D3C, 0x11D3D },
    .{ 0x11D3F, 0x11D45 },
    .{ 0x11D47, 0x11D47 },
    .{ 0x11D90, 0x11D91 },
    .{ 0x11D95, 0x11D95 },
    .{ 0x11D97, 0x11D97 },
    .{ 0x11EF3, 0x11EF4 },
    .{ 0x11F00, 0x11F01 },
    .{ 0x11F36, 0x11F3A },
    .{ 0x11F40, 0x11F40 },
    .{ 0x11F42, 0x11F42 },
    .{ 0x11F5A, 0x11F5A },
    .{ 0x13430, 0x13440 },
    .{ 0x13447, 0x13455 },
    .{ 0x1611E, 0x16129 },
    .{ 0x1612D, 0x1612F },
    .{ 0x16AF0, 0x16AF4 },
    .{ 0x16B30, 0x16B36 },
    .{ 0x16F4F, 0x16F4F },
    .{ 0x16F8F, 0x16F92 },
    .{ 0x16FE4, 0x16FE4 },
    .{ 0x1BC9D, 0x1BC9E },
    .{ 0x1BCA0, 0x1BCA3 },
    .{ 0x1CF00, 0x1CF2D },
    .{ 0x1CF30, 0x1CF46 },
    .{ 0x1D167, 0x1D169 },
    .{ 0x1D173, 0x1D182 },
    .{ 0x1D185, 0x1D18B },
    .{ 0x1D1AA, 0x1D1AD },
    .{ 0x1D242, 0x1D244 },
    .{ 0x1DA00, 0x1DA36 },
    .{ 0x1DA3B, 0x1DA6C },
    .{ 0x1DA75, 0x1DA75 },
    .{ 0x1DA84, 0x1DA84 },
    .{ 0x1DA9B, 0x1DA9F },
    .{ 0x1DAA1, 0x1DAAF },
    .{ 0x1E000, 0x1E006 },
    .{ 0x1E008, 0x1E018 },
    .{ 0x1E01B, 0x1E021 },
    .{ 0x1E023, 0x1E024 },
    .{ 0x1E026, 0x1E02A },
    .{ 0x1E08F, 0x1E08F },
    .{ 0x1E130, 0x1E136 },
    .{ 0x1E2AE, 0x1E2AE },
    .{ 0x1E2EC, 0x1E2EF },
    .{ 0x1E4EC, 0x1E4EF },
    .{ 0x1E5EE, 0x1E5EF },
    .{ 0x1E6E3, 0x1E6E3 },
    .{ 0x1E6E6, 0x1E6E6 },
    .{ 0x1E6EE, 0x1E6EF },
    .{ 0x1E6F5, 0x1E6F5 },
    .{ 0x1E8D0, 0x1E8D6 },
    .{ 0x1E944, 0x1E94A },
    .{ 0xE0001, 0xE0001 },
    .{ 0xE0020, 0xE007F },
    .{ 0xE0100, 0xE01EF },
};
const double_width_tbl = [_][2]u32{
    .{ 0x1100, 0x115F },
    .{ 0x231A, 0x231B },
    .{ 0x2329, 0x232A },
    .{ 0x23E9, 0x23EC },
    .{ 0x23F0, 0x23F0 },
    .{ 0x23F3, 0x23F3 },
    .{ 0x25FD, 0x25FE },
    .{ 0x2614, 0x2615 },
    .{ 0x2630, 0x2637 },
    .{ 0x2648, 0x2653 },
    .{ 0x267F, 0x267F },
    .{ 0x268A, 0x268F },
    .{ 0x2693, 0x2693 },
    .{ 0x26A1, 0x26A1 },
    .{ 0x26AA, 0x26AB },
    .{ 0x26BD, 0x26BE },
    .{ 0x26C4, 0x26C5 },
    .{ 0x26CE, 0x26CE },
    .{ 0x26D4, 0x26D4 },
    .{ 0x26EA, 0x26EA },
    .{ 0x26F2, 0x26F3 },
    .{ 0x26F5, 0x26F5 },
    .{ 0x26FA, 0x26FA },
    .{ 0x26FD, 0x26FD },
    .{ 0x2705, 0x2705 },
    .{ 0x270A, 0x270B },
    .{ 0x2728, 0x2728 },
    .{ 0x274C, 0x274C },
    .{ 0x274E, 0x274E },
    .{ 0x2753, 0x2755 },
    .{ 0x2757, 0x2757 },
    .{ 0x2795, 0x2797 },
    .{ 0x27B0, 0x27B0 },
    .{ 0x27BF, 0x27BF },
    .{ 0x2B1B, 0x2B1C },
    .{ 0x2B50, 0x2B50 },
    .{ 0x2B55, 0x2B55 },
    .{ 0x2E80, 0x2E99 },
    .{ 0x2E9B, 0x2EF3 },
    .{ 0x2F00, 0x2FD5 },
    .{ 0x2FF0, 0x303E },
    .{ 0x3041, 0x3096 },
    .{ 0x3099, 0x30FF },
    .{ 0x3105, 0x312F },
    .{ 0x3131, 0x318E },
    .{ 0x3190, 0x31E5 },
    .{ 0x31EF, 0x321E },
    .{ 0x3220, 0x3247 },
    .{ 0x3250, 0xA48C },
    .{ 0xA490, 0xA4C6 },
    .{ 0xA960, 0xA97C },
    .{ 0xAC00, 0xD7A3 },
    .{ 0xF900, 0xFAFF },
    .{ 0xFE10, 0xFE19 },
    .{ 0xFE30, 0xFE52 },
    .{ 0xFE54, 0xFE66 },
    .{ 0xFE68, 0xFE6B },
    .{ 0xFF01, 0xFF60 },
    .{ 0xFFE0, 0xFFE6 },
    .{ 0x16FE0, 0x16FE4 },
    .{ 0x16FF0, 0x16FF6 },
    .{ 0x17000, 0x18CD5 },
    .{ 0x18CFF, 0x18D1E },
    .{ 0x18D80, 0x18DF2 },
    .{ 0x1AFF0, 0x1AFF3 },
    .{ 0x1AFF5, 0x1AFFB },
    .{ 0x1AFFD, 0x1AFFE },
    .{ 0x1B000, 0x1B122 },
    .{ 0x1B132, 0x1B132 },
    .{ 0x1B150, 0x1B152 },
    .{ 0x1B155, 0x1B155 },
    .{ 0x1B164, 0x1B167 },
    .{ 0x1B170, 0x1B2FB },
    .{ 0x1D300, 0x1D356 },
    .{ 0x1D360, 0x1D376 },
    .{ 0x1F004, 0x1F004 },
    .{ 0x1F0CF, 0x1F0CF },
    .{ 0x1F18E, 0x1F18E },
    .{ 0x1F191, 0x1F19A },
    .{ 0x1F200, 0x1F202 },
    .{ 0x1F210, 0x1F23B },
    .{ 0x1F240, 0x1F248 },
    .{ 0x1F250, 0x1F251 },
    .{ 0x1F260, 0x1F265 },
    .{ 0x1F300, 0x1F320 },
    .{ 0x1F32D, 0x1F335 },
    .{ 0x1F337, 0x1F37C },
    .{ 0x1F37E, 0x1F393 },
    .{ 0x1F3A0, 0x1F3CA },
    .{ 0x1F3CF, 0x1F3D3 },
    .{ 0x1F3E0, 0x1F3F0 },
    .{ 0x1F3F4, 0x1F3F4 },
    .{ 0x1F3F8, 0x1F43E },
    .{ 0x1F440, 0x1F440 },
    .{ 0x1F442, 0x1F4FC },
    .{ 0x1F4FF, 0x1F53D },
    .{ 0x1F54B, 0x1F54E },
    .{ 0x1F550, 0x1F567 },
    .{ 0x1F57A, 0x1F57A },
    .{ 0x1F595, 0x1F596 },
    .{ 0x1F5A4, 0x1F5A4 },
    .{ 0x1F5FB, 0x1F64F },
    .{ 0x1F680, 0x1F6C5 },
    .{ 0x1F6CC, 0x1F6CC },
    .{ 0x1F6D0, 0x1F6D2 },
    .{ 0x1F6D5, 0x1F6D8 },
    .{ 0x1F6DC, 0x1F6DF },
    .{ 0x1F6EB, 0x1F6EC },
    .{ 0x1F6F4, 0x1F6FC },
    .{ 0x1F7E0, 0x1F7EB },
    .{ 0x1F7F0, 0x1F7F0 },
    .{ 0x1F90C, 0x1F93A },
    .{ 0x1F93C, 0x1F945 },
    .{ 0x1F947, 0x1F9FF },
    .{ 0x1FA70, 0x1FA7C },
    .{ 0x1FA80, 0x1FA8A },
    .{ 0x1FA8E, 0x1FAC6 },
    .{ 0x1FAC8, 0x1FAC8 },
    .{ 0x1FACD, 0x1FADC },
    .{ 0x1FADF, 0x1FAEA },
    .{ 0x1FAEF, 0x1FAF8 },
    .{ 0x20000, 0x2FFFD },
    .{ 0x30000, 0x3FFFD },
};
