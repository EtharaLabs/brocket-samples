//! Faithful port of git's xdiff library (xdiff/*.c from git v2.56.1).
//!
//! Public API
//! ----------
//! Diffing:
//!   Flags                       diff parameters (algorithm, whitespace flags, indent
//!                               heuristic, -I<regex> list, --anchored list).
//!   Change                      one edit-script atom (xdchange_t): lines [j1, j1+chg1) of a
//!                               replaced by [j2, j2+chg2) of b (0-based), plus `ignore`
//!                               (set by --ignore-blank-lines / -I).
//!   diff(a, b, flags) !Diff     xdl_do_diff + xdl_change_compact (both sides) +
//!                               xdl_build_script + ignorable marking. `Diff` owns an arena;
//!                               call `d.deinit()` when done. `d.changes` is the edit script,
//!                               `d.lineA(i)` / `d.lineB(i)` give records (with trailing '\n'
//!                               when present), `d.nrecA()` / `d.nrecB()` line counts.
//!   trimCommonTail(a, b)        xdiff-interface.c trim_common_tail (git applies it when
//!                               context == 0 and no function context).
//! Emitting (xemit.c):
//!   EmitOpts                    ctxlen / interhunk / func_context / funcnames / no_hunk_header
//!                               / find_func (null = git's def_ff).
//!   FindFunc                    custom function-name matcher (xecfg->find_func).
//!   RegexFindFunc.init(pattern, opts)   port of xdiff_set_find_func/ff_regexp (userdiff
//!                               "funcname"/"xfuncname" patterns, '\n'-separated, '!' negation).
//!   Callbacks                   `hunk` (optional, like ecb->out_hunk) and `line`. When `hunk`
//!                               is null the formatted "@@ -a,b +c,d @@ func\n" is passed to
//!                               `line` with kind .hunk_header. For .context/.del/.add the text
//!                               is the raw record (ends with '\n' unless it is an incomplete
//!                               last line; then the caller must print "\n\\ No newline at end
//!                               of file\n" after it, as xdl_emit_diffrec does).
//!   emitDiff(&d, opts, cb)      xdl_emit_diff.
//!   forEachHunkRange(&d, opts, ctx, fn)  xdl_call_hunk_func (xecfg->hunk_func).
//!   getHunk(changes, &start, opts) ?usize  xdl_get_hunk on a change slice.
//!   unifiedDiff(a, b, flags, opts) ![]u8   complete hunk text exactly as the body of
//!                               `git diff` (no ---/+++ header), incl. "\ No newline" lines.
//! Merging (xmerge.c):
//!   MergeOpts{flags, level, favor, style, marker_size, ancestor_name, ours_name, theirs_name}
//!   merge(base, ours, theirs, opts) !MergeResult{ result, conflicts }
//!
//! Errors: error.DiffFailed is returned exactly where xdiff returns -1 (histogram index
//! overflow cases); git reports these as "unable to generate diff".

const std = @import("std");
const util = @import("util.zig");
const regex = @import("regex.zig");

const Allocator = std.mem.Allocator;

// ---------------------------------------------------------------------------
// flags (xdiff.h)

pub const XDF_NEED_MINIMAL: u64 = 1 << 0;
pub const XDF_IGNORE_WHITESPACE: u64 = 1 << 1;
pub const XDF_IGNORE_WHITESPACE_CHANGE: u64 = 1 << 2;
pub const XDF_IGNORE_WHITESPACE_AT_EOL: u64 = 1 << 3;
pub const XDF_IGNORE_CR_AT_EOL: u64 = 1 << 4;
pub const XDF_WHITESPACE_FLAGS: u64 = XDF_IGNORE_WHITESPACE | XDF_IGNORE_WHITESPACE_CHANGE |
    XDF_IGNORE_WHITESPACE_AT_EOL | XDF_IGNORE_CR_AT_EOL;
pub const XDF_IGNORE_BLANK_LINES: u64 = 1 << 7;
pub const XDF_PATIENCE_DIFF: u64 = 1 << 14;
pub const XDF_HISTOGRAM_DIFF: u64 = 1 << 15;
pub const XDF_DIFF_ALGORITHM_MASK: u64 = XDF_PATIENCE_DIFF | XDF_HISTOGRAM_DIFF | XDF_NEED_MINIMAL;
pub const XDF_INDENT_HEURISTIC: u64 = 1 << 23;

fn alg(flags: u64) u64 {
    return flags & XDF_DIFF_ALGORITHM_MASK;
}

pub const Algorithm = enum { myers, minimal, patience, histogram };

pub const Flags = struct {
    algorithm: Algorithm = .myers,
    ignore_ws: bool = false,
    ignore_ws_change: bool = false,
    ignore_ws_eol: bool = false,
    ignore_cr_eol: bool = false,
    ignore_blank_lines: bool = false,
    indent_heuristic: bool = true,
    /// -I<regex>: changes whose lines all match one of these are marked ignorable.
    ignore_regex: []const regex.Regex = &.{},
    /// --anchored=<text> (patience only)
    anchors: []const []const u8 = &.{},

    pub fn bits(f: Flags) u64 {
        var r: u64 = 0;
        switch (f.algorithm) {
            .myers => {},
            .minimal => r |= XDF_NEED_MINIMAL,
            .patience => r |= XDF_PATIENCE_DIFF,
            .histogram => r |= XDF_HISTOGRAM_DIFF,
        }
        if (f.ignore_ws) r |= XDF_IGNORE_WHITESPACE;
        if (f.ignore_ws_change) r |= XDF_IGNORE_WHITESPACE_CHANGE;
        if (f.ignore_ws_eol) r |= XDF_IGNORE_WHITESPACE_AT_EOL;
        if (f.ignore_cr_eol) r |= XDF_IGNORE_CR_AT_EOL;
        if (f.ignore_blank_lines) r |= XDF_IGNORE_BLANK_LINES;
        if (f.indent_heuristic) r |= XDF_INDENT_HEURISTIC;
        return r;
    }
};

pub const DiffError = error{DiffFailed};

// ---------------------------------------------------------------------------
// ctype (git's sane_ctype)

pub inline fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r';
}
inline fn isAlpha(c: u8) bool {
    return (c >= 'a' and c <= 'z') or (c >= 'A' and c <= 'Z');
}
inline fn isAlnum(c: u8) bool {
    return isAlpha(c) or (c >= '0' and c <= '9');
}

inline fn U(i: isize) usize {
    return @intCast(i);
}

// ---------------------------------------------------------------------------
// types (xtypes.h)

const Rec = struct {
    line: []const u8,
    mph: usize,
};

const XdFile = struct {
    buf: []const u8,
    recs: []Rec,
    nrec: isize,
    dstart: isize,
    dend: isize,
    /// changed[-1 .. nrec] stored at offset +1
    changed_mem: []bool,
    reference_index: []isize,
    nreff: isize,

    inline fn changed(self: *const XdFile, i: isize) bool {
        if (i < -1 or i > self.nrec) return false;
        return self.changed_mem[U(i + 1)];
    }
    inline fn setChanged(self: *XdFile, i: isize, v: bool) void {
        self.changed_mem[U(i + 1)] = v;
    }
    inline fn rec(self: *const XdFile, i: isize) []const u8 {
        return self.recs[U(i)].line;
    }
    inline fn mph(self: *const XdFile, i: isize) usize {
        return self.recs[U(i)].mph;
    }
};

const Env = struct {
    xdf1: XdFile,
    xdf2: XdFile,
};

pub const Change = struct {
    i1: isize,
    i2: isize,
    chg1: isize,
    chg2: isize,
    ignore: bool = false,
};

// ---------------------------------------------------------------------------
// xutils.c

fn bogosqrt(n0: u64) u64 {
    var n = n0;
    var i: u64 = 1;
    while (n > 0) : (n >>= 2) i <<= 1;
    return i;
}

fn hashbits(size: u32) u5 {
    var val: u64 = 1;
    var b: u32 = 0;
    while (val < size and b < 32) : ({
        val <<= 1;
        b += 1;
    }) {}
    return if (b != 0) @intCast(@min(b, 31)) else 1;
}

fn hashLong(v: u64, b: u5) u64 {
    return (v +% (v >> b)) & ((@as(u64, 1) << b) - 1);
}

fn blankLine(line: []const u8, flags: u64) bool {
    if (flags & XDF_WHITESPACE_FLAGS == 0) return line.len <= 1;
    var i: usize = 0;
    while (i < line.len and isSpace(line[i])) i += 1;
    return i == line.len;
}

fn endsWithOptionalCr(l: []const u8, i: usize) bool {
    var s = l.len;
    const complete = s != 0 and l[s - 1] == '\n';
    if (complete) s -= 1;
    if (s == i) return true;
    if (complete and s == i + 1 and l[i] == '\r') return true;
    return false;
}

/// xdl_recmatch
pub fn recmatch(l1: []const u8, l2: []const u8, flags: u64) bool {
    if (std.mem.eql(u8, l1, l2)) return true;
    if (flags & XDF_WHITESPACE_FLAGS == 0) return false;
    const s1 = l1.len;
    const s2 = l2.len;
    var j1: usize = 0;
    var j2: usize = 0;
    if (flags & XDF_IGNORE_WHITESPACE != 0) {
        while (true) {
            while (j1 < s1 and isSpace(l1[j1])) j1 += 1;
            while (j2 < s2 and isSpace(l2[j2])) j2 += 1;
            if (!(j1 < s1 and j2 < s2)) break;
            if (l1[j1] != l2[j2]) return false;
            j1 += 1;
            j2 += 1;
        }
    } else if (flags & XDF_IGNORE_WHITESPACE_CHANGE != 0) {
        while (j1 < s1 and j2 < s2) {
            if (isSpace(l1[j1]) and isSpace(l2[j2])) {
                while (j1 < s1 and isSpace(l1[j1])) j1 += 1;
                while (j2 < s2 and isSpace(l2[j2])) j2 += 1;
                continue;
            }
            if (l1[j1] != l2[j2]) return false;
            j1 += 1;
            j2 += 1;
        }
    } else if (flags & XDF_IGNORE_WHITESPACE_AT_EOL != 0) {
        while (j1 < s1 and j2 < s2 and l1[j1] == l2[j2]) {
            j1 += 1;
            j2 += 1;
        }
    } else if (flags & XDF_IGNORE_CR_AT_EOL != 0) {
        while (j1 < s1 and j2 < s2 and l1[j1] == l2[j2]) {
            j1 += 1;
            j2 += 1;
        }
        return endsWithOptionalCr(l1, j1) and endsWithOptionalCr(l2, j2);
    }
    if (j1 < s1) {
        while (j1 < s1 and isSpace(l1[j1])) j1 += 1;
        if (s1 != j1) return false;
    }
    if (j2 < s2) {
        while (j2 < s2 and isSpace(l2[j2])) j2 += 1;
        return s2 == j2;
    }
    return true;
}

/// xdl_hash_record: `line` is the record (stops at the first '\n').
pub fn hashRecord(line: []const u8, flags: u64) u64 {
    var ha: u64 = 5381;
    const top = line.len;
    if (flags & XDF_WHITESPACE_FLAGS == 0) {
        for (line) |c| {
            if (c == '\n') break;
            ha = ha *% 33 +% c;
        }
        return ha;
    }
    const cr_at_eol_only = (flags & XDF_WHITESPACE_FLAGS) == XDF_IGNORE_CR_AT_EOL;
    var p: usize = 0;
    while (p < top and line[p] != '\n') : (p += 1) {
        if (cr_at_eol_only) {
            if (line[p] == '\r' and p + 1 < top and line[p + 1] == '\n') continue;
        } else if (isSpace(line[p])) {
            var p2 = p;
            while (p + 1 < top and isSpace(line[p + 1]) and line[p + 1] != '\n') p += 1;
            const at_eol = top <= p + 1 or line[p + 1] == '\n';
            if (flags & XDF_IGNORE_WHITESPACE != 0) {
                // already handled
            } else if (flags & XDF_IGNORE_WHITESPACE_CHANGE != 0 and !at_eol) {
                ha +%= (ha << 5);
                ha ^= ' ';
            } else if (flags & XDF_IGNORE_WHITESPACE_AT_EOL != 0 and !at_eol) {
                while (p2 != p + 1) : (p2 += 1) {
                    ha +%= (ha << 5);
                    ha ^= line[p2];
                }
            }
            continue;
        }
        ha +%= (ha << 5);
        ha ^= line[p];
    }
    return ha;
}

fn spanOf(recs: []const Rec) []const u8 {
    const first = recs[0].line;
    const last = recs[recs.len - 1].line;
    const len = @intFromPtr(last.ptr) + last.len - @intFromPtr(first.ptr);
    return first.ptr[0..len];
}

// ---------------------------------------------------------------------------
// xprepare.c

const Class = struct {
    line_hash: u64,
    next: ?u32,
    line: []const u8,
    len1: isize = 0,
    len2: isize = 0,
};

const Classifier = struct {
    al: Allocator,
    flags: u64,
    heads: std.AutoHashMapUnmanaged(u64, u32) = .empty,
    classes: std.ArrayList(Class) = .empty,

    fn classify(cf: *Classifier, pass: u32, line: []const u8, h: u64) usize {
        const gop = cf.heads.getOrPut(cf.al, h) catch util.oom();
        var found: ?u32 = null;
        if (gop.found_existing) {
            var it: ?u32 = gop.value_ptr.*;
            while (it) |ci| {
                const c = &cf.classes.items[ci];
                if (c.line_hash == h and recmatch(c.line, line, cf.flags)) {
                    found = ci;
                    break;
                }
                it = c.next;
            }
        }
        const idx: u32 = found orelse blk: {
            const ni: u32 = @intCast(cf.classes.items.len);
            cf.classes.append(cf.al, .{
                .line_hash = h,
                .next = if (gop.found_existing) gop.value_ptr.* else null,
                .line = line,
            }) catch util.oom();
            gop.value_ptr.* = ni;
            break :blk ni;
        };
        if (pass == 1) cf.classes.items[idx].len1 += 1 else cf.classes.items[idx].len2 += 1;
        return idx;
    }
};

fn prepareCtx(al: Allocator, pass: u32, buf: []const u8, flags: u64, cf: *Classifier) XdFile {
    var recs: std.ArrayList(Rec) = .empty;
    var cur: usize = 0;
    while (cur < buf.len) {
        const end = if (std.mem.findScalarPos(u8, buf, cur, '\n')) |n| n + 1 else buf.len;
        const line = buf[cur..end];
        cur = end;
        const h = hashRecord(line, flags);
        const m = cf.classify(pass, line, h);
        recs.append(al, .{ .line = line, .mph = m }) catch util.oom();
    }
    const nrec: isize = @intCast(recs.items.len);
    const ch = al.alloc(bool, recs.items.len + 2) catch util.oom();
    @memset(ch, false);
    return .{
        .buf = buf,
        .recs = recs.items,
        .nrec = nrec,
        .dstart = 0,
        .dend = nrec - 1,
        .changed_mem = ch,
        .reference_index = &.{},
        .nreff = 0,
    };
}

const DISCARD: u8 = 0;
const KEEP: u8 = 1;
const INVESTIGATE: u8 = 2;
const XDL_KPDIS_RUN = 4;
const XDL_MAX_EQLIMIT = 1024;
const XDL_SIMSCAN_WINDOW = 100;

fn cleanMmatch(action: []const u8, i: isize, len: isize) bool {
    var s: isize = 0;
    var e: isize = len - 1;
    if (i - s > XDL_SIMSCAN_WINDOW) s = i - XDL_SIMSCAN_WINDOW;
    if (e - i > XDL_SIMSCAN_WINDOW) e = i + XDL_SIMSCAN_WINDOW;

    var r: isize = 1;
    var rdis0: isize = 0;
    var rpdis0: isize = 1;
    while (i - r >= s) : (r += 1) {
        const a = action[U(i - r)];
        if (a == DISCARD) rdis0 += 1 else if (a == INVESTIGATE) rpdis0 += 1 else break;
    }
    if (rdis0 == 0) return false;
    var rdis1: isize = 0;
    var rpdis1: isize = 1;
    r = 1;
    while (i + r <= e) : (r += 1) {
        const a = action[U(i + r)];
        if (a == DISCARD) rdis1 += 1 else if (a == INVESTIGATE) rpdis1 += 1 else break;
    }
    if (rdis1 == 0) return false;
    rdis1 += rdis0;
    rpdis1 += rpdis0;
    return rpdis1 * XDL_KPDIS_RUN < (rpdis1 + rdis1);
}

fn cleanupRecords(al: Allocator, cf: *Classifier, x1: *XdFile, x2: *XdFile) void {
    const need_min = cf.flags & XDF_NEED_MINIMAL != 0;
    const off = x1.dstart;
    const len1 = x1.dend - off + 1;
    const len2 = x2.dend - off + 1;
    const action1 = al.alloc(u8, U(@max(len1, 0))) catch util.oom();
    const action2 = al.alloc(u8, U(@max(len2, 0))) catch util.oom();
    x1.reference_index = al.alloc(isize, U(@max(len1, 0))) catch util.oom();
    x2.reference_index = al.alloc(isize, U(@max(len2, 0))) catch util.oom();

    var mlim1: isize = std.math.maxInt(isize);
    if (!need_min) mlim1 = @intCast(@min(bogosqrt(@intCast(x1.nrec)), XDL_MAX_EQLIMIT));
    var i: isize = 0;
    while (i < len1) : (i += 1) {
        const nm = cf.classes.items[x1.mph(i + off)].len2;
        action1[U(i)] = if (nm == 0) DISCARD else if (nm < mlim1) KEEP else INVESTIGATE;
    }
    var mlim2: isize = std.math.maxInt(isize);
    if (!need_min) mlim2 = @intCast(@min(bogosqrt(@intCast(x2.nrec)), XDL_MAX_EQLIMIT));
    i = 0;
    while (i < len2) : (i += 1) {
        const nm = cf.classes.items[x2.mph(i + off)].len1;
        action2[U(i)] = if (nm == 0) DISCARD else if (nm < mlim2) KEEP else INVESTIGATE;
    }

    x1.nreff = 0;
    i = 0;
    while (i < len1) : (i += 1) {
        var a = action1[U(i)];
        if (a == INVESTIGATE) a = if (!cleanMmatch(action1, i, len1)) KEEP else DISCARD;
        if (a == KEEP) {
            x1.reference_index[U(x1.nreff)] = i + off;
            x1.nreff += 1;
        } else x1.setChanged(i + off, true);
    }
    x2.nreff = 0;
    i = 0;
    while (i < len2) : (i += 1) {
        var a = action2[U(i)];
        if (a == INVESTIGATE) a = if (!cleanMmatch(action2, i, len2)) KEEP else DISCARD;
        if (a == KEEP) {
            x2.reference_index[U(x2.nreff)] = i + off;
            x2.nreff += 1;
        } else x2.setChanged(i + off, true);
    }
}

fn trimEnds(x1: *XdFile, x2: *XdFile) void {
    var lim: isize = @min(x1.nrec, x2.nrec);
    var i: isize = 0;
    while (i < lim) : (i += 1) {
        if (x1.mph(i) != x2.mph(i)) break;
    }
    x1.dstart = i;
    x2.dstart = i;
    lim -= i;
    i = 0;
    while (i < lim) : (i += 1) {
        if (x1.mph(x1.nrec - 1 - i) != x2.mph(x2.nrec - 1 - i)) break;
    }
    x1.dend = x1.nrec - i - 1;
    x2.dend = x2.nrec - i - 1;
}

fn prepareEnv(al: Allocator, a: []const u8, b: []const u8, flags: u64) Env {
    var cf = Classifier{ .al = al, .flags = flags };
    var xe: Env = .{
        .xdf1 = prepareCtx(al, 1, a, flags, &cf),
        .xdf2 = undefined,
    };
    xe.xdf2 = prepareCtx(al, 2, b, flags, &cf);
    if (alg(flags) != XDF_PATIENCE_DIFF and alg(flags) != XDF_HISTOGRAM_DIFF) {
        trimEnds(&xe.xdf1, &xe.xdf2);
        cleanupRecords(al, &cf, &xe.xdf1, &xe.xdf2);
    }
    return xe;
}

// ---------------------------------------------------------------------------
// xdiffi.c: Myers

const XDL_MAX_COST_MIN = 256;
const XDL_HEUR_MIN_COST = 256;
const XDL_LINE_MAX: isize = std.math.maxInt(isize);
const XDL_SNAKE_CNT = 20;
const XDL_K_HEUR = 4;

const AlgoEnv = struct {
    mxcost: isize,
    snake_cnt: isize,
    heur_min: isize,
};

const Split = struct {
    i1: isize = 0,
    i2: isize = 0,
    min_lo: bool = false,
    min_hi: bool = false,
};

const KV = struct {
    mem: []isize,
    base: isize,
    inline fn at(self: KV, d: isize) *isize {
        return &self.mem[U(self.base + d)];
    }
};

inline fn getHash(x: *const XdFile, index: isize) usize {
    return x.recs[U(x.reference_index[U(index)])].mph;
}

fn xdlSplit(x1: *const XdFile, off1: isize, lim1: isize, x2: *const XdFile, off2: isize, lim2: isize, kvdf: KV, kvdb: KV, need_min: bool, spl: *Split, xenv: *const AlgoEnv) void {
    const dmin = off1 - lim2;
    const dmax = lim1 - off2;
    const fmid = off1 - off2;
    const bmid = lim1 - lim2;
    const odd = ((fmid - bmid) & 1) != 0;
    var fmin = fmid;
    var fmax = fmid;
    var bmin = bmid;
    var bmax = bmid;

    kvdf.at(fmid).* = off1;
    kvdb.at(bmid).* = lim1;

    var ec: isize = 1;
    while (true) : (ec += 1) {
        var got_snake = false;

        if (fmin > dmin) {
            fmin -= 1;
            kvdf.at(fmin - 1).* = -1;
        } else fmin += 1;
        if (fmax < dmax) {
            fmax += 1;
            kvdf.at(fmax + 1).* = -1;
        } else fmax -= 1;

        var d = fmax;
        while (d >= fmin) : (d -= 2) {
            var j1: isize = undefined;
            if (kvdf.at(d - 1).* >= kvdf.at(d + 1).*)
                j1 = kvdf.at(d - 1).* + 1
            else
                j1 = kvdf.at(d + 1).*;
            const prev1 = j1;
            var j2 = j1 - d;
            while (j1 < lim1 and j2 < lim2 and getHash(x1, j1) == getHash(x2, j2)) {
                j1 += 1;
                j2 += 1;
            }
            if (j1 - prev1 > xenv.snake_cnt) got_snake = true;
            kvdf.at(d).* = j1;
            if (odd and bmin <= d and d <= bmax and kvdb.at(d).* <= j1) {
                spl.i1 = j1;
                spl.i2 = j2;
                spl.min_lo = true;
                spl.min_hi = true;
                return;
            }
        }

        if (bmin > dmin) {
            bmin -= 1;
            kvdb.at(bmin - 1).* = XDL_LINE_MAX;
        } else bmin += 1;
        if (bmax < dmax) {
            bmax += 1;
            kvdb.at(bmax + 1).* = XDL_LINE_MAX;
        } else bmax -= 1;

        d = bmax;
        while (d >= bmin) : (d -= 2) {
            var j1: isize = undefined;
            if (kvdb.at(d - 1).* < kvdb.at(d + 1).*)
                j1 = kvdb.at(d - 1).*
            else
                j1 = kvdb.at(d + 1).* - 1;
            const prev1 = j1;
            var j2 = j1 - d;
            while (j1 > off1 and j2 > off2 and getHash(x1, j1 - 1) == getHash(x2, j2 - 1)) {
                j1 -= 1;
                j2 -= 1;
            }
            if (prev1 - j1 > xenv.snake_cnt) got_snake = true;
            kvdb.at(d).* = j1;
            if (!odd and fmin <= d and d <= fmax and j1 <= kvdf.at(d).*) {
                spl.i1 = j1;
                spl.i2 = j2;
                spl.min_lo = true;
                spl.min_hi = true;
                return;
            }
        }

        if (need_min) continue;

        if (got_snake and ec > xenv.heur_min) {
            var best: isize = 0;
            d = fmax;
            while (d >= fmin) : (d -= 2) {
                const dd = if (d > fmid) d - fmid else fmid - d;
                const j1 = kvdf.at(d).*;
                const j2 = j1 - d;
                const v = (j1 - off1) + (j2 - off2) - dd;
                if (v > XDL_K_HEUR * ec and v > best and
                    off1 + xenv.snake_cnt <= j1 and j1 < lim1 and
                    off2 + xenv.snake_cnt <= j2 and j2 < lim2)
                {
                    var k: isize = 1;
                    while (getHash(x1, j1 - k) == getHash(x2, j2 - k)) : (k += 1) {
                        if (k == xenv.snake_cnt) {
                            best = v;
                            spl.i1 = j1;
                            spl.i2 = j2;
                            break;
                        }
                    }
                }
            }
            if (best > 0) {
                spl.min_lo = true;
                spl.min_hi = false;
                return;
            }

            best = 0;
            d = bmax;
            while (d >= bmin) : (d -= 2) {
                const dd = if (d > bmid) d - bmid else bmid - d;
                const j1 = kvdb.at(d).*;
                const j2 = j1 - d;
                const v = (lim1 - j1) + (lim2 - j2) - dd;
                if (v > XDL_K_HEUR * ec and v > best and
                    off1 < j1 and j1 <= lim1 - xenv.snake_cnt and
                    off2 < j2 and j2 <= lim2 - xenv.snake_cnt)
                {
                    var k: isize = 0;
                    while (getHash(x1, j1 + k) == getHash(x2, j2 + k)) : (k += 1) {
                        if (k == xenv.snake_cnt - 1) {
                            best = v;
                            spl.i1 = j1;
                            spl.i2 = j2;
                            break;
                        }
                    }
                }
            }
            if (best > 0) {
                spl.min_lo = false;
                spl.min_hi = true;
                return;
            }
        }

        if (ec >= xenv.mxcost) {
            var fbest: isize = -1;
            var fbest1: isize = -1;
            d = fmax;
            while (d >= fmin) : (d -= 2) {
                var j1 = @min(kvdf.at(d).*, lim1);
                var j2 = j1 - d;
                if (lim2 < j2) {
                    j1 = lim2 + d;
                    j2 = lim2;
                }
                if (fbest < j1 + j2) {
                    fbest = j1 + j2;
                    fbest1 = j1;
                }
            }
            var bbest: isize = XDL_LINE_MAX;
            var bbest1: isize = XDL_LINE_MAX;
            d = bmax;
            while (d >= bmin) : (d -= 2) {
                var j1 = @max(off1, kvdb.at(d).*);
                var j2 = j1 - d;
                if (j2 < off2) {
                    j1 = off2 + d;
                    j2 = off2;
                }
                if (j1 + j2 < bbest) {
                    bbest = j1 + j2;
                    bbest1 = j1;
                }
            }
            if ((lim1 + lim2) - bbest < fbest - (off1 + off2)) {
                spl.i1 = fbest1;
                spl.i2 = fbest - fbest1;
                spl.min_lo = true;
                spl.min_hi = false;
            } else {
                spl.i1 = bbest1;
                spl.i2 = bbest - bbest1;
                spl.min_lo = false;
                spl.min_hi = true;
            }
            return;
        }
    }
}

fn recsCmp(x1: *XdFile, off1_: isize, lim1_: isize, x2: *XdFile, off2_: isize, lim2_: isize, kvdf: KV, kvdb: KV, need_min: bool, xenv: *const AlgoEnv) void {
    var off1 = off1_;
    var lim1 = lim1_;
    var off2 = off2_;
    var lim2 = lim2_;
    while (off1 < lim1 and off2 < lim2 and getHash(x1, off1) == getHash(x2, off2)) {
        off1 += 1;
        off2 += 1;
    }
    while (off1 < lim1 and off2 < lim2 and getHash(x1, lim1 - 1) == getHash(x2, lim2 - 1)) {
        lim1 -= 1;
        lim2 -= 1;
    }
    if (off1 == lim1) {
        while (off2 < lim2) : (off2 += 1) x2.setChanged(x2.reference_index[U(off2)], true);
    } else if (off2 == lim2) {
        while (off1 < lim1) : (off1 += 1) x1.setChanged(x1.reference_index[U(off1)], true);
    } else {
        var spl = Split{};
        xdlSplit(x1, off1, lim1, x2, off2, lim2, kvdf, kvdb, need_min, &spl, xenv);
        recsCmp(x1, off1, spl.i1, x2, off2, spl.i2, kvdf, kvdb, spl.min_lo, xenv);
        recsCmp(x1, spl.i1, lim1, x2, spl.i2, lim2, kvdf, kvdb, spl.min_hi, xenv);
    }
}

fn doDiff(al: Allocator, a: []const u8, b: []const u8, flags: u64, anchors: []const []const u8) DiffError!Env {
    var xe = prepareEnv(al, a, b, flags);
    if (alg(flags) == XDF_PATIENCE_DIFF) {
        try patienceDiff(al, flags, anchors, &xe, 1, xe.xdf1.nrec, 1, xe.xdf2.nrec);
        return xe;
    }
    if (alg(flags) == XDF_HISTOGRAM_DIFF) {
        try histogramDiff(al, flags, &xe, xe.xdf1.dstart + 1, xe.xdf1.dend - xe.xdf1.dstart + 1, xe.xdf2.dstart + 1, xe.xdf2.dend - xe.xdf2.dstart + 1);
        return xe;
    }
    const ndiags = xe.xdf1.nreff + xe.xdf2.nreff + 3;
    const kvd = al.alloc(isize, U(2 * ndiags + 2)) catch util.oom();
    defer al.free(kvd);
    const kvdf = KV{ .mem = kvd, .base = xe.xdf2.nreff + 1 };
    const kvdb = KV{ .mem = kvd, .base = ndiags + xe.xdf2.nreff + 1 };
    var mx: isize = @intCast(bogosqrt(@intCast(ndiags)));
    if (mx < XDL_MAX_COST_MIN) mx = XDL_MAX_COST_MIN;
    const xenv = AlgoEnv{ .mxcost = mx, .snake_cnt = XDL_SNAKE_CNT, .heur_min = XDL_HEUR_MIN_COST };
    recsCmp(&xe.xdf1, 0, xe.xdf1.nreff, &xe.xdf2, 0, xe.xdf2.nreff, kvdf, kvdb, flags & XDF_NEED_MINIMAL != 0, &xenv);
    return xe;
}

/// xdl_fall_back_diff (lines are 1-based)
fn fallBackDiff(al: Allocator, env: *Env, flags: u64, line1: isize, count1: isize, line2: isize, count2: isize) DiffError!void {
    const sub1 = spanOf(env.xdf1.recs[U(line1 - 1)..U(line1 + count1 - 1)]);
    const sub2 = spanOf(env.xdf2.recs[U(line2 - 1)..U(line2 + count2 - 1)]);
    const e = try doDiff(al, sub1, sub2, flags, &.{});
    @memcpy(env.xdf1.changed_mem[U(line1)..U(line1 + count1)], e.xdf1.changed_mem[1..U(1 + count1)]);
    @memcpy(env.xdf2.changed_mem[U(line2)..U(line2 + count2)], e.xdf2.changed_mem[1..U(1 + count2)]);
}

// ---------------------------------------------------------------------------
// xpatience.c

const NON_UNIQUE: usize = std.math.maxInt(usize);
const NONE: u32 = std.math.maxInt(u32);

const PEntry = struct {
    mph: usize = 0,
    line1: usize = 0,
    line2: usize = 0,
    next: u32 = NONE,
    previous: u32 = NONE,
};

const PMap = struct {
    nr: usize = 0,
    alloc: usize,
    entries: []PEntry,
    first: u32 = NONE,
    last: u32 = NONE,
    has_matches: bool = false,
    env: *Env,
    flags: u64,
    anchors: []const []const u8,
};

fn isAnchor(anchors: []const []const u8, x: *const XdFile, line: []const u8) bool {
    const off = @intFromPtr(line.ptr) - @intFromPtr(x.buf.ptr);
    const rest = x.buf[off..];
    for (anchors) |an| {
        if (std.mem.startsWith(u8, rest, an)) return true;
    }
    return false;
}

fn insertRecord(line: usize, map: *PMap, pass: u32) void {
    const recs = if (pass == 1) map.env.xdf1.recs else map.env.xdf2.recs;
    const r = recs[line - 1];
    var index: usize = (r.mph << 1) % map.alloc;
    while (map.entries[index].line1 != 0) {
        if (map.entries[index].mph != r.mph) {
            index += 1;
            if (index >= map.alloc) index = 0;
            continue;
        }
        if (pass == 2) map.has_matches = true;
        if (pass == 1 or map.entries[index].line2 != 0)
            map.entries[index].line2 = NON_UNIQUE
        else
            map.entries[index].line2 = line;
        return;
    }
    if (pass == 2) return;
    map.entries[index].line1 = line;
    map.entries[index].mph = r.mph;
    const idx: u32 = @intCast(index);
    if (map.first == NONE) map.first = idx;
    if (map.last != NONE) {
        map.entries[map.last].next = idx;
        map.entries[index].previous = map.last;
    }
    map.last = idx;
    map.nr += 1;
}

fn binarySearch(map: *PMap, sequence: []u32, longest: isize, entry: u32) isize {
    var left: isize = -1;
    var right: isize = longest;
    while (left + 1 < right) {
        const middle = left + @divTrunc(right - left, 2);
        if (map.entries[sequence[U(middle)]].line2 > map.entries[entry].line2)
            right = middle
        else
            left = middle;
    }
    return left;
}

fn findLongestCommonSequence(al: Allocator, map: *PMap) u32 {
    const recs = map.env.xdf2.recs;
    const sequence = al.alloc(u32, map.nr) catch util.oom();
    defer al.free(sequence);
    var longest: isize = 0;
    var anchor_i: isize = -1;
    var entry = map.first;
    while (entry != NONE) : (entry = map.entries[entry].next) {
        const e = &map.entries[entry];
        if (e.line2 == 0 or e.line2 == NON_UNIQUE) continue;
        var i: isize = undefined;
        if (longest == 0 or e.line2 > map.entries[sequence[U(longest - 1)]].line2)
            i = longest - 1
        else
            i = binarySearch(map, sequence, longest, entry);
        e.previous = if (i < 0) NONE else sequence[U(i)];
        i += 1;
        if (i <= anchor_i) continue;
        sequence[U(i)] = entry;
        if (isAnchor(map.anchors, &map.env.xdf2, recs[e.line2 - 1].line)) {
            anchor_i = i;
            longest = anchor_i + 1;
        } else if (i == longest) {
            longest += 1;
        }
    }
    if (longest == 0) return NONE;
    entry = sequence[U(longest - 1)];
    map.entries[entry].next = NONE;
    while (map.entries[entry].previous != NONE) {
        const p = map.entries[entry].previous;
        map.entries[p].next = entry;
        entry = p;
    }
    return entry;
}

fn pmatch(map: *PMap, line1: isize, line2: isize) bool {
    return map.env.xdf1.recs[U(line1 - 1)].mph == map.env.xdf2.recs[U(line2 - 1)].mph;
}

fn walkCommonSequence(al: Allocator, map: *PMap, first_: u32, line1_: isize, count1: isize, line2_: isize, count2: isize) DiffError!void {
    var first = first_;
    var line1 = line1_;
    var line2 = line2_;
    const end1 = line1 + count1;
    const end2 = line2 + count2;
    while (true) {
        var next1: isize = undefined;
        var next2: isize = undefined;
        if (first != NONE) {
            next1 = @intCast(map.entries[first].line1);
            next2 = @intCast(map.entries[first].line2);
            while (next1 > line1 and next2 > line2 and pmatch(map, next1 - 1, next2 - 1)) {
                next1 -= 1;
                next2 -= 1;
            }
        } else {
            next1 = end1;
            next2 = end2;
        }
        while (line1 < next1 and line2 < next2 and pmatch(map, line1, line2)) {
            line1 += 1;
            line2 += 1;
        }
        if (next1 > line1 or next2 > line2) {
            try patienceDiff(al, map.flags, map.anchors, map.env, line1, next1 - line1, line2, next2 - line2);
        }
        if (first == NONE) return;
        while (true) {
            const f = map.entries[first];
            if (f.next == NONE) break;
            const n = map.entries[f.next];
            if (!(n.line1 == f.line1 + 1 and n.line2 == f.line2 + 1)) break;
            first = f.next;
        }
        line1 = @intCast(map.entries[first].line1 + 1);
        line2 = @intCast(map.entries[first].line2 + 1);
        first = map.entries[first].next;
    }
}

fn patienceDiff(al: Allocator, flags: u64, anchors: []const []const u8, env: *Env, line1_: isize, count1_: isize, line2_: isize, count2_: isize) DiffError!void {
    var line1 = line1_;
    var line2 = line2_;
    var count1 = count1_;
    var count2 = count2_;
    if (count1 == 0) {
        while (count2 > 0) : (count2 -= 1) {
            env.xdf2.setChanged(line2 - 1, true);
            line2 += 1;
        }
        return;
    } else if (count2 == 0) {
        while (count1 > 0) : (count1 -= 1) {
            env.xdf1.setChanged(line1 - 1, true);
            line1 += 1;
        }
        return;
    }
    const n = U(count1 * 2);
    const entries = al.alloc(PEntry, n) catch util.oom();
    defer al.free(entries);
    @memset(entries, .{});
    var map = PMap{ .alloc = n, .entries = entries, .env = env, .flags = flags, .anchors = anchors };
    {
        var l = line1;
        var c = count1;
        while (c > 0) : (c -= 1) {
            insertRecord(U(l), &map, 1);
            l += 1;
        }
        l = line2;
        c = count2;
        while (c > 0) : (c -= 1) {
            insertRecord(U(l), &map, 2);
            l += 1;
        }
    }
    if (!map.has_matches) {
        while (count1 > 0) : (count1 -= 1) {
            env.xdf1.setChanged(line1 - 1, true);
            line1 += 1;
        }
        while (count2 > 0) : (count2 -= 1) {
            env.xdf2.setChanged(line2 - 1, true);
            line2 += 1;
        }
        return;
    }
    const first = findLongestCommonSequence(al, &map);
    if (first != NONE)
        try walkCommonSequence(al, &map, first, line1, count1, line2, count2)
    else
        try fallBackDiff(al, env, flags & ~XDF_DIFF_ALGORITHM_MASK, line1, count1, line2, count2);
}

// ---------------------------------------------------------------------------
// xhistogram.c

const HRecord = struct {
    ptr: isize,
    cnt: isize,
    next: u32,
};

const HistIndex = struct {
    records: []u32, // heads into rcha
    line_map: []u32,
    rcha: std.ArrayList(HRecord) = .empty,
    next_ptrs: []isize,
    table_bits: u5,
    max_chain_length: isize,
    ptr_shift: isize,
    cnt: isize = 0,
    has_common: bool = false,
    env: *Env,

    inline fn lineMap(self: *HistIndex, a: isize) *u32 {
        return &self.line_map[U(a - self.ptr_shift)];
    }
    inline fn nextPtr(self: *HistIndex, a: isize) *isize {
        return &self.next_ptrs[U(a - self.ptr_shift)];
    }
    inline fn cntOf(self: *HistIndex, a: isize) isize {
        return self.rcha.items[self.lineMap(a).*].cnt;
    }
    inline fn cmp(self: *HistIndex, s1: u32, l1: isize, s2: u32, l2: isize) bool {
        const r1 = if (s1 == 1) self.env.xdf1.recs else self.env.xdf2.recs;
        const r2 = if (s2 == 1) self.env.xdf1.recs else self.env.xdf2.recs;
        return r1[U(l1 - 1)].mph == r2[U(l2 - 1)].mph;
    }
    inline fn tableHash(self: *HistIndex, side: u32, line: isize) usize {
        const r = if (side == 1) self.env.xdf1.recs else self.env.xdf2.recs;
        return @intCast(hashLong(r[U(line - 1)].mph, self.table_bits));
    }
};

const Region = struct {
    begin1: isize = 0,
    end1: isize = 0,
    begin2: isize = 0,
    end2: isize = 0,
};

fn scanA(al: Allocator, index: *HistIndex, line1: isize, count1: isize) bool {
    var ptr: isize = line1 + count1 - 1;
    outer: while (line1 <= ptr) : (ptr -= 1) {
        const tbl_idx = index.tableHash(1, ptr);
        var rec = index.records[tbl_idx];
        var chain_len: isize = 0;
        while (rec != NONE) {
            const r = &index.rcha.items[rec];
            if (index.cmp(1, r.ptr, 1, ptr)) {
                index.nextPtr(ptr).* = r.ptr;
                r.ptr = ptr;
                r.cnt = @min(@as(isize, std.math.maxInt(u32)), r.cnt + 1);
                index.lineMap(ptr).* = rec;
                continue :outer;
            }
            rec = r.next;
            chain_len += 1;
        }
        if (chain_len == index.max_chain_length) return false;
        const ni: u32 = @intCast(index.rcha.items.len);
        index.rcha.append(al, .{ .ptr = ptr, .cnt = 1, .next = index.records[tbl_idx] }) catch util.oom();
        index.records[tbl_idx] = ni;
        index.lineMap(ptr).* = ni;
    }
    return true;
}

fn tryLcs(index: *HistIndex, lcs: *Region, b_ptr: isize, line1: isize, count1: isize, line2: isize, count2: isize) isize {
    var b_next = b_ptr + 1;
    var rec = index.records[index.tableHash(2, b_ptr)];
    const le1 = line1 + count1 - 1;
    const le2 = line2 + count2 - 1;
    while (rec != NONE) : (rec = index.rcha.items[rec].next) {
        const r = index.rcha.items[rec];
        if (r.cnt > index.cnt) {
            if (!index.has_common) index.has_common = index.cmp(1, r.ptr, 2, b_ptr);
            continue;
        }
        var as = r.ptr;
        if (!index.cmp(1, as, 2, b_ptr)) continue;
        index.has_common = true;
        while (true) {
            var np = index.nextPtr(as).*;
            var bs = b_ptr;
            var ae = as;
            var be = bs;
            var rc = r.cnt;
            while (line1 < as and line2 < bs and index.cmp(1, as - 1, 2, bs - 1)) {
                as -= 1;
                bs -= 1;
                if (1 < rc) rc = @min(rc, index.cntOf(as));
            }
            while (ae < le1 and be < le2 and index.cmp(1, ae + 1, 2, be + 1)) {
                ae += 1;
                be += 1;
                if (1 < rc) rc = @min(rc, index.cntOf(ae));
            }
            if (b_next <= be) b_next = be + 1;
            if (lcs.end1 - lcs.begin1 < ae - as or rc < index.cnt) {
                lcs.begin1 = as;
                lcs.begin2 = bs;
                lcs.end1 = ae;
                lcs.end2 = be;
                index.cnt = rc;
            }
            if (np == 0) break;
            var should_break = false;
            while (np <= ae) {
                np = index.nextPtr(np).*;
                if (np == 0) {
                    should_break = true;
                    break;
                }
            }
            if (should_break) break;
            as = np;
        }
    }
    return b_next;
}

/// returns -1 on error, 1 if fall back needed, 0 otherwise
fn findLcs(al: Allocator, env: *Env, lcs: *Region, line1: isize, count1: isize, line2: isize, count2: isize) isize {
    const table_bits = hashbits(@intCast(count1));
    const records_size = @as(usize, 1) << table_bits;
    const records = al.alloc(u32, records_size) catch util.oom();
    defer al.free(records);
    @memset(records, NONE);
    const line_map = al.alloc(u32, U(count1)) catch util.oom();
    defer al.free(line_map);
    @memset(line_map, NONE);
    const next_ptrs = al.alloc(isize, U(count1)) catch util.oom();
    defer al.free(next_ptrs);
    @memset(next_ptrs, 0);
    var index = HistIndex{
        .records = records,
        .line_map = line_map,
        .next_ptrs = next_ptrs,
        .table_bits = table_bits,
        .max_chain_length = 64,
        .ptr_shift = line1,
        .env = env,
    };
    defer index.rcha.deinit(al);
    if (!scanA(al, &index, line1, count1)) return -1;
    index.cnt = index.max_chain_length + 1;
    var b_ptr = line2;
    while (b_ptr <= line2 + count2 - 1)
        b_ptr = tryLcs(&index, lcs, b_ptr, line1, count1, line2, count2);
    if (index.has_common and index.max_chain_length < index.cnt) return 1;
    return 0;
}

fn histogramDiff(al: Allocator, flags: u64, env: *Env, line1_: isize, count1_: isize, line2_: isize, count2_: isize) DiffError!void {
    var line1 = line1_;
    var line2 = line2_;
    var count1 = count1_;
    var count2 = count2_;
    while (true) {
        if (count1 <= 0 and count2 <= 0) return;
        if (line1 + count1 - 1 >= std.math.maxInt(u32)) return error.DiffFailed;
        if (count1 == 0) {
            while (count2 > 0) : (count2 -= 1) {
                env.xdf2.setChanged(line2 - 1, true);
                line2 += 1;
            }
            return;
        } else if (count2 == 0) {
            while (count1 > 0) : (count1 -= 1) {
                env.xdf1.setChanged(line1 - 1, true);
                line1 += 1;
            }
            return;
        }
        var lcs = Region{};
        const found = findLcs(al, env, &lcs, line1, count1, line2, count2);
        if (found < 0) return error.DiffFailed;
        if (found > 0) {
            return fallBackDiff(al, env, flags & ~XDF_DIFF_ALGORITHM_MASK, line1, count1, line2, count2);
        }
        if (lcs.begin1 == 0 and lcs.begin2 == 0) {
            while (count1 > 0) : (count1 -= 1) {
                env.xdf1.setChanged(line1 - 1, true);
                line1 += 1;
            }
            while (count2 > 0) : (count2 -= 1) {
                env.xdf2.setChanged(line2 - 1, true);
                line2 += 1;
            }
            return;
        }
        try histogramDiff(al, flags, env, line1, lcs.begin1 - line1, line2, lcs.begin2 - line2);
        const le1 = line1 + count1 - 1;
        const le2 = line2 + count2 - 1;
        count1 = le1 - lcs.end1;
        line1 = lcs.end1 + 1;
        count2 = le2 - lcs.end2;
        line2 = lcs.end2 + 1;
    }
}

// ---------------------------------------------------------------------------
// xdiffi.c: change compaction (incl. indent heuristic)

const MAX_INDENT = 200;
const MAX_BLANKS = 20;

fn getIndent(r: []const u8) isize {
    var ret: isize = 0;
    for (r) |c| {
        if (!isSpace(c)) return ret;
        if (c == ' ') ret += 1 else if (c == '\t') ret += 8 - @mod(ret, 8);
        if (ret >= MAX_INDENT) return MAX_INDENT;
    }
    return -1;
}

const SplitMeasurement = struct {
    end_of_file: bool,
    indent: isize,
    pre_blank: isize,
    pre_indent: isize,
    post_blank: isize,
    post_indent: isize,
};

const SplitScore = struct {
    effective_indent: isize = 0,
    penalty: isize = 0,
};

fn measureSplit(x: *const XdFile, split: isize) SplitMeasurement {
    var m: SplitMeasurement = undefined;
    if (split >= x.nrec) {
        m.end_of_file = true;
        m.indent = -1;
    } else {
        m.end_of_file = false;
        m.indent = getIndent(x.rec(split));
    }
    m.pre_blank = 0;
    m.pre_indent = -1;
    var i = split - 1;
    while (i >= 0) : (i -= 1) {
        m.pre_indent = getIndent(x.rec(i));
        if (m.pre_indent != -1) break;
        m.pre_blank += 1;
        if (m.pre_blank == MAX_BLANKS) {
            m.pre_indent = 0;
            break;
        }
    }
    m.post_blank = 0;
    m.post_indent = -1;
    i = split + 1;
    while (i < x.nrec) : (i += 1) {
        m.post_indent = getIndent(x.rec(i));
        if (m.post_indent != -1) break;
        m.post_blank += 1;
        if (m.post_blank == MAX_BLANKS) {
            m.post_indent = 0;
            break;
        }
    }
    return m;
}

const START_OF_FILE_PENALTY = 1;
const END_OF_FILE_PENALTY = 21;
const TOTAL_BLANK_WEIGHT = -30;
const POST_BLANK_WEIGHT = 6;
const RELATIVE_INDENT_PENALTY = -4;
const RELATIVE_INDENT_WITH_BLANK_PENALTY = 10;
const RELATIVE_OUTDENT_PENALTY = 24;
const RELATIVE_OUTDENT_WITH_BLANK_PENALTY = 17;
const RELATIVE_DEDENT_PENALTY = 23;
const RELATIVE_DEDENT_WITH_BLANK_PENALTY = 17;
const INDENT_WEIGHT = 60;
const INDENT_HEURISTIC_MAX_SLIDING = 100;

fn scoreAddSplit(m: *const SplitMeasurement, s: *SplitScore) void {
    if (m.pre_indent == -1 and m.pre_blank == 0) s.penalty += START_OF_FILE_PENALTY;
    if (m.end_of_file) s.penalty += END_OF_FILE_PENALTY;
    const post_blank: isize = if (m.indent == -1) 1 + m.post_blank else 0;
    const total_blank = m.pre_blank + post_blank;
    s.penalty += TOTAL_BLANK_WEIGHT * total_blank;
    s.penalty += POST_BLANK_WEIGHT * post_blank;
    const indent = if (m.indent != -1) m.indent else m.post_indent;
    const any_blanks = total_blank != 0;
    s.effective_indent += indent;
    if (indent == -1) {} else if (m.pre_indent == -1) {} else if (indent > m.pre_indent) {
        s.penalty += if (any_blanks) RELATIVE_INDENT_WITH_BLANK_PENALTY else RELATIVE_INDENT_PENALTY;
    } else if (indent == m.pre_indent) {} else {
        if (m.post_indent != -1 and m.post_indent > indent) {
            s.penalty += if (any_blanks) RELATIVE_OUTDENT_WITH_BLANK_PENALTY else RELATIVE_OUTDENT_PENALTY;
        } else {
            s.penalty += if (any_blanks) RELATIVE_DEDENT_WITH_BLANK_PENALTY else RELATIVE_DEDENT_PENALTY;
        }
    }
}

fn scoreCmp(s1: *const SplitScore, s2: *const SplitScore) isize {
    const cmp_indents: isize = @as(isize, @intFromBool(s1.effective_indent > s2.effective_indent)) -
        @as(isize, @intFromBool(s1.effective_indent < s2.effective_indent));
    return INDENT_WEIGHT * cmp_indents + (s1.penalty - s2.penalty);
}

const Group = struct {
    start: isize,
    end: isize,
};

fn groupInit(x: *const XdFile) Group {
    var g = Group{ .start = 0, .end = 0 };
    while (x.changed(g.end)) g.end += 1;
    return g;
}

fn groupNext(x: *const XdFile, g: *Group) bool {
    if (g.end == x.nrec) return false;
    g.start = g.end + 1;
    g.end = g.start;
    while (x.changed(g.end)) g.end += 1;
    return true;
}

fn groupPrevious(x: *const XdFile, g: *Group) bool {
    if (g.start == 0) return false;
    g.end = g.start - 1;
    g.start = g.end;
    while (x.changed(g.start - 1)) g.start -= 1;
    return true;
}

fn groupSlideDown(x: *XdFile, g: *Group) bool {
    if (g.end < x.nrec and x.mph(g.start) == x.mph(g.end)) {
        x.setChanged(g.start, false);
        g.start += 1;
        x.setChanged(g.end, true);
        g.end += 1;
        while (x.changed(g.end)) g.end += 1;
        return true;
    }
    return false;
}

fn groupSlideUp(x: *XdFile, g: *Group) bool {
    if (g.start > 0 and x.mph(g.start - 1) == x.mph(g.end - 1)) {
        g.start -= 1;
        x.setChanged(g.start, true);
        g.end -= 1;
        x.setChanged(g.end, false);
        while (x.changed(g.start - 1)) g.start -= 1;
        return true;
    }
    return false;
}

fn bug(comptime msg: []const u8) noreturn {
    util.die("BUG: xdiff: " ++ msg, .{});
}

/// xdl_change_compact
fn changeCompact(al: Allocator, xdf: *XdFile, xdfo: *XdFile, flags: u64) DiffError!void {
    var g = groupInit(xdf);
    var go = groupInit(xdfo);
    while (true) {
        if (g.end != g.start) {
            const g_orig = g;
            var earliest_end: isize = undefined;
            var end_matching_other: isize = undefined;
            var groupsize: isize = undefined;
            while (true) {
                groupsize = g.end - g.start;
                end_matching_other = -1;
                while (groupSlideUp(xdf, &g)) {
                    if (!groupPrevious(xdfo, &go)) bug("group sync broken sliding up");
                }
                earliest_end = g.end;
                if (go.end > go.start) end_matching_other = g.end;
                while (true) {
                    if (!groupSlideDown(xdf, &g)) break;
                    if (!groupNext(xdfo, &go)) bug("group sync broken sliding down");
                    if (go.end > go.start) end_matching_other = g.end;
                }
                if (groupsize == g.end - g.start) break;
            }

            if (g.end == earliest_end) {
                // no shifting was possible
            } else if (end_matching_other != -1) {
                while (go.end == go.start) {
                    if (!groupSlideUp(xdf, &g)) bug("match disappeared");
                    if (!groupPrevious(xdfo, &go)) bug("group sync broken sliding to match");
                }
            } else if (flags & XDF_INDENT_HEURISTIC != 0) {
                var best_shift: isize = -1;
                var best_score = SplitScore{};
                var shift = earliest_end;
                if (g.end - groupsize - 1 > shift) shift = g.end - groupsize - 1;
                if (g.end - INDENT_HEURISTIC_MAX_SLIDING > shift) shift = g.end - INDENT_HEURISTIC_MAX_SLIDING;
                while (shift <= g.end) : (shift += 1) {
                    var score = SplitScore{};
                    var m = measureSplit(xdf, shift);
                    scoreAddSplit(&m, &score);
                    m = measureSplit(xdf, shift - groupsize);
                    scoreAddSplit(&m, &score);
                    if (best_shift == -1 or scoreCmp(&score, &best_score) <= 0) {
                        best_score = score;
                        best_shift = shift;
                    }
                }
                while (g.end > best_shift) {
                    if (!groupSlideUp(xdf, &g)) bug("best shift unreached");
                    if (!groupPrevious(xdfo, &go)) bug("group sync broken sliding to blank line");
                }
            }

            if (go.end != go.start and alg(flags) == XDF_HISTOGRAM_DIFF and
                (g.start != g_orig.start or g.end != g_orig.end))
            {
                // git passes xdf as xdf1 and xdfo as xdf2 regardless of direction;
                // the copies share the `changed` arrays.
                var xe = Env{ .xdf1 = xdf.*, .xdf2 = xdfo.* };
                try fallBackDiff(al, &xe, flags & ~XDF_DIFF_ALGORITHM_MASK, g.start + 1, g.end - g.start, go.start + 1, go.end - go.start);
            }
        }
        if (!groupNext(xdf, &g)) break;
        if (!groupNext(xdfo, &go)) bug("group sync broken moving to next group");
    }
    if (groupNext(xdfo, &go)) bug("group sync broken at end of file");
}

fn buildScript(al: Allocator, xe: *const Env) []Change {
    var list: std.ArrayList(Change) = .empty;
    var j1 = xe.xdf1.nrec;
    var j2 = xe.xdf2.nrec;
    while (j1 >= 0 or j2 >= 0) : ({
        j1 -= 1;
        j2 -= 1;
    }) {
        if (xe.xdf1.changed(j1 - 1) or xe.xdf2.changed(j2 - 1)) {
            const l1 = j1;
            while (xe.xdf1.changed(j1 - 1)) j1 -= 1;
            const l2 = j2;
            while (xe.xdf2.changed(j2 - 1)) j2 -= 1;
            list.append(al, .{ .i1 = j1, .i2 = j2, .chg1 = l1 - j1, .chg2 = l2 - j2 }) catch util.oom();
        }
    }
    std.mem.reverse(Change, list.items);
    return list.items;
}

fn compactAndScript(al: Allocator, xe: *Env, flags: u64) DiffError![]Change {
    try changeCompact(al, &xe.xdf1, &xe.xdf2, flags);
    try changeCompact(al, &xe.xdf2, &xe.xdf1, flags);
    return buildScript(al, xe);
}

// ---------------------------------------------------------------------------
// public diff

pub const Diff = struct {
    arena: *std.heap.ArenaAllocator,
    env: Env,
    changes: []Change,

    pub fn deinit(self: *Diff) void {
        const a = self.arena;
        a.deinit();
        util.gpa.destroy(a);
    }
    pub fn nrecA(self: *const Diff) usize {
        return U(self.env.xdf1.nrec);
    }
    pub fn nrecB(self: *const Diff) usize {
        return U(self.env.xdf2.nrec);
    }
    pub fn lineA(self: *const Diff, i: usize) []const u8 {
        return self.env.xdf1.recs[i].line;
    }
    pub fn lineB(self: *const Diff, i: usize) []const u8 {
        return self.env.xdf2.recs[i].line;
    }
};

fn markIgnorableLines(changes: []Change, xe: *const Env, flags: u64) void {
    for (changes) |*ch| {
        var ignore = true;
        var i: isize = 0;
        while (i < ch.chg1 and ignore) : (i += 1) ignore = blankLine(xe.xdf1.rec(ch.i1 + i), flags);
        i = 0;
        while (i < ch.chg2 and ignore) : (i += 1) ignore = blankLine(xe.xdf2.rec(ch.i2 + i), flags);
        ch.ignore = ignore;
    }
}

fn recordMatchesRegex(r: []const u8, res: []const regex.Regex) bool {
    for (res) |re| {
        if (re.find(r, false) != null) return true;
    }
    return false;
}

fn markIgnorableRegex(changes: []Change, xe: *const Env, res: []const regex.Regex) void {
    for (changes) |*ch| {
        if (ch.ignore) continue;
        var ignore = true;
        var i: isize = 0;
        while (i < ch.chg1 and ignore) : (i += 1) ignore = recordMatchesRegex(xe.xdf1.rec(ch.i1 + i), res);
        i = 0;
        while (i < ch.chg2 and ignore) : (i += 1) ignore = recordMatchesRegex(xe.xdf2.rec(ch.i2 + i), res);
        ch.ignore = ignore;
    }
}

/// Compute the edit script between a and b (xdl_do_diff + compaction + script).
pub fn diff(a: []const u8, b: []const u8, flags: Flags) DiffError!Diff {
    const arena = util.gpa.create(std.heap.ArenaAllocator) catch util.oom();
    arena.* = std.heap.ArenaAllocator.init(util.gpa);
    errdefer {
        arena.deinit();
        util.gpa.destroy(arena);
    }
    const al = arena.allocator();
    const fl = flags.bits();
    var xe = try doDiff(al, a, b, fl, flags.anchors);
    const changes = try compactAndScript(al, &xe, fl);
    if (changes.len > 0) {
        if (fl & XDF_IGNORE_BLANK_LINES != 0) markIgnorableLines(changes, &xe, fl);
        if (flags.ignore_regex.len > 0) markIgnorableRegex(changes, &xe, flags.ignore_regex);
    }
    return .{ .arena = arena, .env = xe, .changes = changes };
}

/// trim_common_tail from xdiff-interface.c
pub fn trimCommonTail(a: []const u8, b: []const u8) struct { a: []const u8, b: []const u8 } {
    const blk = 1024;
    var trimmed: usize = 0;
    var recovered: usize = 0;
    const smaller = @min(a.len, b.len);
    while (blk + trimmed <= smaller and
        std.mem.eql(u8, a[a.len - trimmed - blk .. a.len - trimmed], b[b.len - trimmed - blk .. b.len - trimmed]))
    {
        trimmed += blk;
    }
    const ap = a.len - trimmed;
    while (recovered < trimmed) {
        const c = a[ap + recovered];
        recovered += 1;
        if (c == '\n') break;
    }
    return .{ .a = a[0 .. a.len - (trimmed - recovered)], .b = b[0 .. b.len - (trimmed - recovered)] };
}

// ---------------------------------------------------------------------------
// xemit.c

pub const FindFunc = struct {
    ctx: ?*anyopaque = null,
    /// Return -1 if `line` is not a function line, else the number of bytes written to buf.
    func: *const fn (ctx: ?*anyopaque, line: []const u8, buf: []u8) isize,
};

pub const EmitOpts = struct {
    context: usize = 3,
    interhunk: usize = 0,
    /// XDL_EMIT_FUNCCONTEXT (-W)
    func_context: bool = false,
    /// XDL_EMIT_FUNCNAMES (git diff always sets this)
    funcnames: bool = true,
    /// XDL_EMIT_NO_HUNK_HDR
    no_hunk_header: bool = false,
    find_func: ?FindFunc = null,
};

pub const LineKind = enum { hunk_header, context, del, add };

pub const HunkInfo = struct {
    old_begin: isize,
    old_nr: isize,
    new_begin: isize,
    new_nr: isize,
    func: []const u8,
};

pub const Callbacks = struct {
    ctx: ?*anyopaque = null,
    hunk: ?*const fn (ctx: ?*anyopaque, h: HunkInfo) void = null,
    line: *const fn (ctx: ?*anyopaque, kind: LineKind, text: []const u8) void,
};

fn defFf(r: []const u8, buf: []u8) isize {
    if (r.len > 0 and (isAlpha(r[0]) or r[0] == '_' or r[0] == '$')) {
        var len = @min(r.len, buf.len);
        while (len > 0 and isSpace(r[len - 1])) len -= 1;
        @memcpy(buf[0..len], r[0..len]);
        return @intCast(len);
    }
    return -1;
}

fn matchFuncRec(x: *const XdFile, o: *const EmitOpts, ri: isize, buf: []u8) isize {
    const r = x.rec(ri);
    if (o.find_func) |ff| return ff.func(ff.ctx, r, buf);
    return defFf(r, buf);
}

fn isFuncRec(x: *const XdFile, o: *const EmitOpts, ri: isize) bool {
    var dummy: [1]u8 = undefined;
    return matchFuncRec(x, o, ri, &dummy) >= 0;
}

const FuncLine = struct {
    len: usize = 0,
    buf: [80]u8 = undefined,
};

fn getFuncLine(xe: *const Env, o: *const EmitOpts, func_line: ?*FuncLine, start: isize, limit: isize) isize {
    const step: isize = if (start > limit) -1 else 1;
    var dummy: [1]u8 = undefined;
    const buf: []u8 = if (func_line) |f| &f.buf else &dummy;
    var l = start;
    while (l != limit and 0 <= l and l < xe.xdf1.nrec) : (l += step) {
        const len = matchFuncRec(&xe.xdf1, o, l, buf);
        if (len >= 0) {
            if (func_line) |f| f.len = U(len);
            return l;
        }
    }
    return -1;
}

fn isEmptyRec(x: *const XdFile, ri: isize) bool {
    for (x.rec(ri)) |c| {
        if (!isSpace(c)) return false;
    }
    return true;
}

fn satAdd(a: isize, b: isize) isize {
    const r = @addWithOverflow(a, b);
    return if (r[1] != 0) std.math.maxInt(isize) else r[0];
}

/// xdl_get_hunk: `start` is the index of the first change to consider (it may be
/// advanced past ignorable changes). Returns the index of the last change of the
/// hunk, or null if there is no hunk left (start then == changes.len).
pub fn getHunk(changes: []const Change, start: *usize, o: EmitOpts) ?usize {
    const ctxlen: isize = @intCast(o.context);
    const max_common = satAdd(satAdd(ctxlen, ctxlen), @intCast(o.interhunk));
    const max_ignorable = ctxlen;
    var ignored: isize = 0;
    const n = changes.len;

    var xchp = start.*;
    while (xchp < n and changes[xchp].ignore) : (xchp += 1) {
        const xch = xchp + 1;
        if (xch >= n or changes[xch].i1 - (changes[xchp].i1 + changes[xchp].chg1) >= max_ignorable)
            start.* = xch;
    }
    if (start.* >= n) return null;

    var lxch = start.*;
    xchp = start.*;
    var xch = xchp + 1;
    while (xch < n) : ({
        xchp = xch;
        xch += 1;
    }) {
        const c = changes[xch];
        const p = changes[xchp];
        const distance = c.i1 - (p.i1 + p.chg1);
        if (distance > max_common) break;
        if (distance < max_ignorable and (!c.ignore or lxch == xchp)) {
            lxch = xch;
            ignored = 0;
        } else if (distance < max_ignorable and c.ignore) {
            ignored += c.chg2;
        } else if (lxch != xchp and c.i1 + ignored - (changes[lxch].i1 + changes[lxch].chg1) > max_common) {
            break;
        } else if (!c.ignore) {
            lxch = xch;
            ignored = 0;
        } else {
            ignored += c.chg2;
        }
    }
    return lxch;
}

fn numOut(out: *std.ArrayList(u8), v: isize) void {
    out.print(util.gpa, "{d}", .{v}) catch util.oom();
}

/// xdl_format_hunk_hdr: s1/s2 are 1-based starts as passed by xdl_emit_diff.
pub fn formatHunkHeader(out: *std.ArrayList(u8), s1: isize, c1: isize, s2: isize, c2: isize, func: []const u8) void {
    const start_len = out.items.len;
    out.appendSlice(util.gpa, "@@ -") catch util.oom();
    numOut(out, if (c1 != 0) s1 else s1 - 1);
    if (c1 != 1) {
        out.append(util.gpa, ',') catch util.oom();
        numOut(out, c1);
    }
    out.appendSlice(util.gpa, " +") catch util.oom();
    numOut(out, if (c2 != 0) s2 else s2 - 1);
    if (c2 != 1) {
        out.append(util.gpa, ',') catch util.oom();
        numOut(out, c2);
    }
    out.appendSlice(util.gpa, " @@") catch util.oom();
    if (func.len > 0) {
        out.append(util.gpa, ' ') catch util.oom();
        const nb = out.items.len - start_len;
        var fl = func.len;
        if (fl > 128 - nb - 1) fl = 128 - nb - 1;
        out.appendSlice(util.gpa, func[0..fl]) catch util.oom();
    }
    out.append(util.gpa, '\n') catch util.oom();
}

fn emitHunkHdr(s1: isize, c1: isize, s2: isize, c2: isize, func: []const u8, cb: Callbacks) void {
    if (cb.hunk) |h| {
        h(cb.ctx, .{
            .old_begin = if (c1 != 0) s1 else s1 - 1,
            .old_nr = c1,
            .new_begin = if (c2 != 0) s2 else s2 - 1,
            .new_nr = c2,
            .func = func,
        });
        return;
    }
    var buf: std.ArrayList(u8) = .empty;
    defer buf.deinit(util.gpa);
    formatHunkHeader(&buf, s1, c1, s2, c2, func);
    cb.line(cb.ctx, .hunk_header, buf.items);
}

/// xdl_emit_diff
pub fn emitDiff(d: *const Diff, o: EmitOpts, cb: Callbacks) void {
    const xe = &d.env;
    const changes = d.changes;
    const n = changes.len;
    const ctxlen: isize = @intCast(o.context);
    const nrec1 = xe.xdf1.nrec;
    const nrec2 = xe.xdf2.nrec;
    var funclineprev: isize = -1;
    var func_line = FuncLine{};

    var xch: usize = 0;
    while (xch < n) {
        var xchp = xch;
        var xche = getHunk(changes, &xch, o) orelse break;
        var s1: isize = undefined;
        var s2: isize = undefined;

        pre: while (true) {
            s1 = @max(changes[xch].i1 - ctxlen, 0);
            s2 = @max(changes[xch].i2 - ctxlen, 0);
            if (o.func_context) {
                var j1 = changes[xch].i1;
                if (j1 >= nrec1) {
                    var j2 = changes[xch].i2;
                    var whole = false;
                    while (j2 < nrec2) : (j2 += 1) {
                        if (isFuncRec(&xe.xdf2, &o, j2)) {
                            whole = true;
                            break;
                        }
                    }
                    if (whole) break :pre;
                    j1 = nrec1 - 1;
                }
                var fs1 = getFuncLine(xe, &o, null, j1, -1);
                while (fs1 > 0 and !isEmptyRec(&xe.xdf1, fs1 - 1) and !isFuncRec(&xe.xdf1, &o, fs1 - 1))
                    fs1 -= 1;
                if (fs1 < 0) fs1 = 0;
                if (fs1 < s1) {
                    s2 = @max(s2 - (s1 - fs1), 0);
                    s1 = fs1;
                    while (xchp != xch and
                        changes[xchp].i1 + changes[xchp].chg1 <= s1 and
                        changes[xchp].i2 + changes[xchp].chg2 <= s2)
                        xchp += 1;
                    if (xchp != xch) {
                        xch = xchp;
                        continue :pre;
                    }
                }
            }
            break;
        }

        var e1: isize = undefined;
        var e2: isize = undefined;
        while (true) {
            var lctx = ctxlen;
            lctx = @min(lctx, nrec1 - (changes[xche].i1 + changes[xche].chg1));
            lctx = @min(lctx, nrec2 - (changes[xche].i2 + changes[xche].chg2));
            e1 = changes[xche].i1 + changes[xche].chg1 + lctx;
            e2 = changes[xche].i2 + changes[xche].chg2 + lctx;
            if (o.func_context) {
                var fe1 = getFuncLine(xe, &o, null, changes[xche].i1 + changes[xche].chg1, nrec1);
                while (fe1 > 0 and isEmptyRec(&xe.xdf1, fe1 - 1)) fe1 -= 1;
                if (fe1 < 0) fe1 = nrec1;
                if (fe1 > e1) {
                    e2 = @min(e2 + (fe1 - e1), nrec2);
                    e1 = fe1;
                }
                if (xche + 1 < n) {
                    const l = @min(changes[xche + 1].i1, nrec1 - 1);
                    if (l - ctxlen <= e1 or getFuncLine(xe, &o, null, l, e1) < 0) {
                        xche += 1;
                        continue;
                    }
                }
            }
            break;
        }

        if (o.funcnames) {
            _ = getFuncLine(xe, &o, &func_line, s1 - 1, funclineprev);
            funclineprev = s1 - 1;
        }
        if (!o.no_hunk_header)
            emitHunkHdr(s1 + 1, e1 - s1, s2 + 1, e2 - s2, func_line.buf[0..func_line.len], cb);

        while (s2 < changes[xch].i2) : (s2 += 1) cb.line(cb.ctx, .context, xe.xdf2.rec(s2));

        s1 = changes[xch].i1;
        s2 = changes[xch].i2;
        while (true) : (xch += 1) {
            const c = changes[xch];
            while (s1 < c.i1 and s2 < c.i2) : ({
                s1 += 1;
                s2 += 1;
            }) cb.line(cb.ctx, .context, xe.xdf2.rec(s2));
            s1 = c.i1;
            while (s1 < c.i1 + c.chg1) : (s1 += 1) cb.line(cb.ctx, .del, xe.xdf1.rec(s1));
            s2 = c.i2;
            while (s2 < c.i2 + c.chg2) : (s2 += 1) cb.line(cb.ctx, .add, xe.xdf2.rec(s2));
            if (xch == xche) break;
            s1 = c.i1 + c.chg1;
            s2 = c.i2 + c.chg2;
        }

        s2 = changes[xche].i2 + changes[xche].chg2;
        while (s2 < e2) : (s2 += 1) cb.line(cb.ctx, .context, xe.xdf2.rec(s2));

        xch = xche + 1;
    }
}

/// xdl_call_hunk_func: report (start_a, count_a, start_b, count_b) of each hunk
/// (0-based starts, no context added).
pub fn forEachHunkRange(d: *const Diff, o: EmitOpts, ctx: ?*anyopaque, func: *const fn (ctx: ?*anyopaque, start_a: isize, count_a: isize, start_b: isize, count_b: isize) void) void {
    const changes = d.changes;
    var xch: usize = 0;
    while (xch < changes.len) {
        const xche = getHunk(changes, &xch, o) orelse break;
        const a = changes[xch];
        const e = changes[xche];
        func(ctx, a.i1, e.i1 + e.chg1 - a.i1, a.i2, e.i2 + e.chg2 - a.i2);
        xch = xche + 1;
    }
}

const TextSink = struct {
    out: std.ArrayList(u8) = .empty,

    fn line(ctx: ?*anyopaque, kind: LineKind, text: []const u8) void {
        const self: *TextSink = @ptrCast(@alignCast(ctx.?));
        switch (kind) {
            .hunk_header => {},
            .context => self.out.append(util.gpa, ' ') catch util.oom(),
            .del => self.out.append(util.gpa, '-') catch util.oom(),
            .add => self.out.append(util.gpa, '+') catch util.oom(),
        }
        self.out.appendSlice(util.gpa, text) catch util.oom();
        if (kind != .hunk_header and text.len > 0 and text[text.len - 1] != '\n')
            self.out.appendSlice(util.gpa, "\n\\ No newline at end of file\n") catch util.oom();
    }
};

/// Complete unified diff body (hunks only), byte-identical to git's output body.
/// Applies trim_common_tail like xdi_diff when context == 0 and no func context.
pub fn unifiedDiff(a: []const u8, b: []const u8, flags: Flags, o: EmitOpts) DiffError![]u8 {
    var aa = a;
    var bb = b;
    if (o.context == 0 and !o.func_context) {
        const t = trimCommonTail(a, b);
        aa = t.a;
        bb = t.b;
    }
    var d = try diff(aa, bb, flags);
    defer d.deinit();
    var sink = TextSink{};
    emitDiff(&d, o, .{ .ctx = &sink, .line = TextSink.line });
    return sink.out.items;
}

/// Port of xdiff_set_find_func + ff_regexp (userdiff funcname patterns).
pub const RegexFindFunc = struct {
    regs: []Reg,

    const Reg = struct { re: regex.Regex, negate: bool };

    pub fn init(value: []const u8, opts: regex.Opts) *RegexFindFunc {
        var list: std.ArrayList(Reg) = .empty;
        var nr: usize = 1;
        for (value) |c| {
            if (c == '\n') nr += 1;
        }
        var it = std.mem.splitScalar(u8, value, '\n');
        var i: usize = 0;
        while (it.next()) |part0| : (i += 1) {
            var part = part0;
            const negate = part.len > 0 and part[0] == '!';
            if (negate and i == nr - 1) util.die("Last expression must not be negated: {s}", .{part});
            if (negate) part = part[1..];
            const re = switch (regex.Regex.compile(part, opts)) {
                .ok => |r| r,
                .err => util.die("Invalid regexp to look for hunk header: {s}", .{part}),
            };
            list.append(util.gpa, .{ .re = re, .negate = negate }) catch util.oom();
        }
        const self = util.gpa.create(RegexFindFunc) catch util.oom();
        self.* = .{ .regs = list.items };
        return self;
    }

    pub fn findFunc(self: *RegexFindFunc) FindFunc {
        return .{ .ctx = self, .func = ffRegexp };
    }

    fn ffRegexp(ctx: ?*anyopaque, line0: []const u8, buf: []u8) isize {
        const self: *RegexFindFunc = @ptrCast(@alignCast(ctx.?));
        var line = line0;
        if (line.len > 0 and line[line.len - 1] == '\n') {
            if (line.len > 1 and line[line.len - 2] == '\r')
                line = line[0 .. line.len - 2]
            else
                line = line[0 .. line.len - 1];
        }
        var pm: [2]regex.Match = undefined;
        var matched = false;
        for (self.regs) |r| {
            if (r.re.findGroups(line, &pm)) {
                if (r.negate) return -1;
                matched = true;
                break;
            }
        }
        if (!matched) return -1;
        const gi: usize = if (pm[1].so >= 0) 1 else 0;
        const so: usize = @intCast(pm[gi].so);
        var result: usize = @intCast(pm[gi].eo - pm[gi].so);
        const l = line[so..];
        if (result > buf.len) result = buf.len;
        while (result > 0 and isSpace(l[result - 1])) result -= 1;
        @memcpy(buf[0..result], l[0..result]);
        return @intCast(result);
    }
};

// ---------------------------------------------------------------------------
// xmerge.c

pub const MergeLevel = enum(u2) { minimal = 0, eager = 1, zealous = 2, zealous_alnum = 3 };
pub const MergeFavor = enum(u2) { none = 0, ours = 1, theirs = 2, union_ = 3 };
pub const MergeStyle = enum(u2) { merge = 0, diff3 = 1, zdiff3 = 2 };

pub const DEFAULT_CONFLICT_MARKER_SIZE = 7;

pub const MergeOpts = struct {
    flags: Flags = .{ .indent_heuristic = false },
    level: MergeLevel = .zealous_alnum,
    favor: MergeFavor = .none,
    style: MergeStyle = .merge,
    marker_size: isize = DEFAULT_CONFLICT_MARKER_SIZE,
    ancestor_name: ?[]const u8 = null,
    ours_name: ?[]const u8 = null,
    theirs_name: ?[]const u8 = null,
};

pub const MergeResult = struct {
    result: []u8,
    conflicts: usize,
};

const XdMerge = struct {
    mode: u32,
    i1: isize,
    i2: isize,
    chg1: isize,
    chg2: isize,
    i0: isize,
    chg0: isize,
};

fn appendMerge(al: Allocator, list: *std.ArrayList(XdMerge), mode: u32, j0: isize, chg0: isize, j1: isize, chg1: isize, j2: isize, chg2: isize) void {
    if (list.items.len > 0) {
        const m = &list.items[list.items.len - 1];
        if (j1 <= m.i1 + m.chg1 or j2 <= m.i2 + m.chg2) {
            if (mode != m.mode) m.mode = 0;
            m.chg0 = j0 + chg0 - m.i0;
            m.chg1 = j1 + chg1 - m.i1;
            m.chg2 = j2 + chg2 - m.i2;
            return;
        }
    }
    list.append(al, .{ .mode = mode, .i0 = j0, .chg0 = chg0, .i1 = j1, .chg1 = chg1, .i2 = j2, .chg2 = chg2 }) catch util.oom();
}

fn mergeCmpLines(xe1: *const Env, j1: isize, xe2: *const Env, j2: isize, line_count: isize, flags: u64) bool {
    var i: isize = 0;
    while (i < line_count) : (i += 1) {
        if (!recmatch(xe1.xdf2.rec(j1 + i), xe2.xdf2.rec(j2 + i), flags)) return false;
    }
    return true;
}

fn recsCopy0(out: *std.ArrayList(u8), x: *const XdFile, i: isize, count: isize, needs_cr: bool, add_nl: bool) void {
    if (count < 1) return;
    var k: isize = 0;
    while (k < count) : (k += 1) out.appendSlice(util.gpa, x.rec(i + k)) catch util.oom();
    if (add_nl) {
        const last = x.rec(i + count - 1);
        if (last.len == 0 or last[last.len - 1] != '\n') {
            if (needs_cr) out.append(util.gpa, '\r') catch util.oom();
            out.append(util.gpa, '\n') catch util.oom();
        }
    }
}

fn isEolCrlf(file: *const XdFile, i: isize) i32 {
    if (i < file.nrec - 1) {
        const r = file.rec(i);
        return @intFromBool(r.len > 1 and r[r.len - 2] == '\r');
    }
    if (file.nrec == 0) return -1;
    const r = file.rec(i);
    if (r.len > 0 and r[r.len - 1] == '\n')
        return @intFromBool(r.len > 1 and r[r.len - 2] == '\r');
    if (i == 0) return -1;
    const p = file.rec(i - 1);
    return @intFromBool(p.len > 1 and p[p.len - 2] == '\r');
}

fn isCrNeeded(xe1: *const Env, xe2: *const Env, m: *const XdMerge) bool {
    var needs_cr = isEolCrlf(&xe1.xdf2, if (m.i1 != 0) m.i1 - 1 else 0);
    if (needs_cr != 0) needs_cr = isEolCrlf(&xe2.xdf2, if (m.i2 != 0) m.i2 - 1 else 0);
    if (needs_cr != 0) needs_cr = isEolCrlf(&xe1.xdf1, 0);
    return if (needs_cr < 0) false else needs_cr != 0;
}

fn marker(out: *std.ArrayList(u8), c: u8, size: usize, name: ?[]const u8, needs_cr: bool) void {
    out.appendNTimes(util.gpa, c, size) catch util.oom();
    if (name) |nm| {
        if (nm.len > 0) {
            out.append(util.gpa, ' ') catch util.oom();
            out.appendSlice(util.gpa, nm) catch util.oom();
        }
    }
    if (needs_cr) out.append(util.gpa, '\r') catch util.oom();
    out.append(util.gpa, '\n') catch util.oom();
}

fn fillConflictHunk(out: *std.ArrayList(u8), xe1: *const Env, name1: ?[]const u8, xe2: *const Env, name2: ?[]const u8, name3: ?[]const u8, i: isize, style: MergeStyle, m: *const XdMerge, marker_size_: isize) void {
    const needs_cr = isCrNeeded(xe1, xe2, m);
    const marker_size: usize = if (marker_size_ <= 0) DEFAULT_CONFLICT_MARKER_SIZE else U(marker_size_);
    recsCopy0(out, &xe1.xdf2, i, m.i1 - i, false, false);
    marker(out, '<', marker_size, name1, needs_cr);
    recsCopy0(out, &xe1.xdf2, m.i1, m.chg1, needs_cr, true);
    if (style == .diff3 or style == .zdiff3) {
        marker(out, '|', marker_size, name3, needs_cr);
        recsCopy0(out, &xe1.xdf1, m.i0, m.chg0, needs_cr, true);
    }
    marker(out, '=', marker_size, null, needs_cr);
    recsCopy0(out, &xe2.xdf2, m.i2, m.chg2, needs_cr, true);
    marker(out, '>', marker_size, name2, needs_cr);
}

fn fillMergeBuffer(out: *std.ArrayList(u8), xe1: *const Env, name1: ?[]const u8, xe2: *const Env, name2: ?[]const u8, ancestor_name: ?[]const u8, favor: u32, ms: []XdMerge, style: MergeStyle, marker_size: isize) void {
    var i: isize = 0;
    for (ms) |*m| {
        if (favor != 0 and m.mode == 0) m.mode = favor;
        if (m.mode == 0) {
            fillConflictHunk(out, xe1, name1, xe2, name2, ancestor_name, i, style, m, marker_size);
        } else if (m.mode & 3 != 0) {
            recsCopy0(out, &xe1.xdf2, i, m.i1 - i, false, false);
            if (m.mode & 1 != 0) {
                const needs_cr = isCrNeeded(xe1, xe2, m);
                recsCopy0(out, &xe1.xdf2, m.i1, m.chg1, needs_cr, (m.mode & 2) != 0);
            }
            if (m.mode & 2 != 0) recsCopy0(out, &xe2.xdf2, m.i2, m.chg2, false, false);
        } else continue;
        i = m.i1 + m.chg1;
    }
    recsCopy0(out, &xe1.xdf2, i, xe1.xdf2.nrec - i, false, false);
}

fn refineZdiff3Conflicts(xe1: *const Env, xe2: *const Env, ms: []XdMerge, flags: u64) void {
    for (ms) |*m| {
        if (m.mode != 0) continue;
        while (m.chg1 != 0 and m.chg2 != 0 and recmatch(xe1.xdf2.rec(m.i1), xe2.xdf2.rec(m.i2), flags)) {
            m.chg1 -= 1;
            m.chg2 -= 1;
            m.i1 += 1;
            m.i2 += 1;
        }
        while (m.chg1 != 0 and m.chg2 != 0 and
            recmatch(xe1.xdf2.rec(m.i1 + m.chg1 - 1), xe2.xdf2.rec(m.i2 + m.chg2 - 1), flags))
        {
            m.chg1 -= 1;
            m.chg2 -= 1;
        }
    }
}

fn refineConflicts(al: Allocator, xe1: *const Env, xe2: *const Env, ms: []XdMerge, flags: u64) DiffError![]XdMerge {
    var out: std.ArrayList(XdMerge) = .empty;
    for (ms) |m0| {
        var m = m0;
        if (m.mode != 0 or m.chg1 == 0 or m.chg2 == 0) {
            out.append(al, m) catch util.oom();
            continue;
        }
        const j1 = m.i1;
        const j2 = m.i2;
        const t1 = spanOf(xe1.xdf2.recs[U(m.i1)..U(m.i1 + m.chg1)]);
        const t2 = spanOf(xe2.xdf2.recs[U(m.i2)..U(m.i2 + m.chg2)]);
        var xe = try doDiff(al, t1, t2, flags, &.{});
        const xscr = try compactAndScript(al, &xe, flags);
        if (xscr.len == 0) {
            m.mode = 4;
            out.append(al, m) catch util.oom();
            continue;
        }
        m.i1 = xscr[0].i1 + j1;
        m.chg1 = xscr[0].chg1;
        m.i2 = xscr[0].i2 + j2;
        m.chg2 = xscr[0].chg2;
        out.append(al, m) catch util.oom();
        for (xscr[1..]) |x| {
            out.append(al, .{ .mode = 0, .i0 = 0, .chg0 = 0, .i1 = x.i1 + j1, .chg1 = x.chg1, .i2 = x.i2 + j2, .chg2 = x.chg2 }) catch util.oom();
        }
    }
    return out.items;
}

fn linesContainAlnum(xe: *const Env, j0: isize, chg0: isize) bool {
    var i = j0;
    var chg = chg0;
    while (chg != 0) : ({
        chg -= 1;
        i += 1;
    }) {
        for (xe.xdf2.rec(i)) |c| {
            if (isAlnum(c)) return true;
        }
    }
    return false;
}

fn simplifyNonConflicts(xe1: *const Env, list: *std.ArrayList(XdMerge), simplify_if_no_alnum: bool) void {
    if (list.items.len == 0) return;
    var mi: usize = 0;
    while (mi + 1 < list.items.len) {
        const m = &list.items[mi];
        const next_m = list.items[mi + 1];
        const begin = m.i1 + m.chg1;
        const end = next_m.i1;
        if (m.mode != 0 or next_m.mode != 0 or
            (end - begin > 3 and (!simplify_if_no_alnum or linesContainAlnum(xe1, begin, end - begin))))
        {
            mi += 1;
        } else {
            m.chg1 = next_m.i1 + next_m.chg1 - m.i1;
            m.chg2 = next_m.i2 + next_m.chg2 - m.i2;
            _ = list.orderedRemove(mi + 1);
        }
    }
}

fn doMerge(al: Allocator, xe1: *const Env, xscr1_: []const Change, xe2: *const Env, xscr2_: []const Change, o: MergeOpts) DiffError!MergeResult {
    const flags = o.flags.bits();
    var level = o.level;
    const style = o.style;
    if (style == .diff3 or style == .zdiff3) {
        if (@intFromEnum(level) > @intFromEnum(MergeLevel.eager)) level = .eager;
    }
    var changes: std.ArrayList(XdMerge) = .empty;
    var xscr1 = xscr1_;
    var xscr2 = xscr2_;
    while (xscr1.len > 0 and xscr2.len > 0) {
        const s1 = xscr1[0];
        const s2 = xscr2[0];
        if (s1.i1 + s1.chg1 < s2.i1) {
            appendMerge(al, &changes, 1, s1.i1, s1.chg1, s1.i2, s1.chg2, s2.i2 - s2.i1 + s1.i1, s1.chg1);
            xscr1 = xscr1[1..];
            continue;
        }
        if (s2.i1 + s2.chg1 < s1.i1) {
            appendMerge(al, &changes, 2, s2.i1, s2.chg1, s1.i2 - s1.i1 + s2.i1, s2.chg1, s2.i2, s2.chg2);
            xscr2 = xscr2[1..];
            continue;
        }
        if (level == .minimal or s1.i1 != s2.i1 or s1.chg1 != s2.chg1 or s1.chg2 != s2.chg2 or
            !mergeCmpLines(xe1, s1.i2, xe2, s2.i2, s1.chg2, flags))
        {
            const off = s1.i1 - s2.i1;
            const ffo = off + s1.chg1 - s2.chg1;
            var j0 = s1.i1;
            var j1 = s1.i2;
            var j2 = s2.i2;
            if (off > 0) {
                j0 -= off;
                j1 -= off;
            } else j2 += off;
            var chg0 = s1.i1 + s1.chg1 - j0;
            var chg1 = s1.i2 + s1.chg2 - j1;
            var chg2 = s2.i2 + s2.chg2 - j2;
            if (ffo < 0) {
                chg0 -= ffo;
                chg1 -= ffo;
            } else chg2 += ffo;
            appendMerge(al, &changes, 0, j0, chg0, j1, chg1, j2, chg2);
        }
        const e1 = s1.i1 + s1.chg1;
        const e2 = s2.i1 + s2.chg1;
        if (e1 >= e2) xscr2 = xscr2[1..];
        if (e2 >= e1) xscr1 = xscr1[1..];
    }
    for (xscr1) |s1| {
        appendMerge(al, &changes, 1, s1.i1, s1.chg1, s1.i2, s1.chg2, s1.i1 + xe2.xdf2.nrec - xe2.xdf1.nrec, s1.chg1);
    }
    for (xscr2) |s2| {
        appendMerge(al, &changes, 2, s2.i1, s2.chg1, s2.i1 + xe1.xdf2.nrec - xe1.xdf1.nrec, s2.chg1, s2.i2, s2.chg2);
    }
    if (style == .zdiff3) {
        refineZdiff3Conflicts(xe1, xe2, changes.items, flags);
    } else if (@intFromEnum(level) >= @intFromEnum(MergeLevel.zealous)) {
        const refined = try refineConflicts(al, xe1, xe2, changes.items, flags);
        changes = .fromOwnedSlice(refined);
        simplifyNonConflicts(xe1, &changes, @intFromEnum(level) > @intFromEnum(MergeLevel.zealous));
    }
    var out: std.ArrayList(u8) = .empty;
    fillMergeBuffer(&out, xe1, o.ours_name, xe2, o.theirs_name, o.ancestor_name, @intFromEnum(o.favor), changes.items, style, o.marker_size);
    var conflicts: usize = 0;
    for (changes.items) |m| {
        if (m.mode == 0) conflicts += 1;
    }
    return .{ .result = out.items, .conflicts = conflicts };
}

/// xdl_merge: three-way merge of `ours` (mf1) and `theirs` (mf2) against `base`.
pub fn merge(base: []const u8, ours: []const u8, theirs: []const u8, o: MergeOpts) DiffError!MergeResult {
    var arena = std.heap.ArenaAllocator.init(util.gpa);
    defer arena.deinit();
    const al = arena.allocator();
    const flags = o.flags.bits();
    var xe1 = try doDiff(al, base, ours, flags, o.flags.anchors);
    var xe2 = try doDiff(al, base, theirs, flags, o.flags.anchors);
    const xscr1 = try compactAndScript(al, &xe1, flags);
    const xscr2 = try compactAndScript(al, &xe2, flags);
    if (xscr1.len == 0) return .{ .result = util.gpa.dupe(u8, theirs) catch util.oom(), .conflicts = 0 };
    if (xscr2.len == 0) return .{ .result = util.gpa.dupe(u8, ours) catch util.oom(), .conflicts = 0 };
    return doMerge(al, &xe1, xscr1, &xe2, xscr2, o);
}

// ---------------------------------------------------------------------------
// tests

fn expectDiff(a: []const u8, b: []const u8, flags: Flags, o: EmitOpts, expected: []const u8) !void {
    const got = try unifiedDiff(a, b, flags, o);
    std.testing.expectEqualStrings(expected, got) catch |e| {
        std.debug.print("---- got ----\n{s}---- expected ----\n{s}----\n", .{ got, expected });
        return e;
    };
}

test "simple change" {
    try expectDiff("a\nb\nc\n", "a\nB\nc\n", .{}, .{}, "@@ -1,3 +1,3 @@\n a\n-b\n+B\n c\n");
}

test "no newline at eof" {
    try expectDiff("a\nb", "a\nc", .{}, .{}, "@@ -1,2 +1,2 @@\n a\n-b\n\\ No newline at end of file\n+c\n\\ No newline at end of file\n");
    try expectDiff("a\n", "a", .{}, .{}, "@@ -1 +1 @@\n-a\n+a\n\\ No newline at end of file\n");
}

test "empty files" {
    try expectDiff("", "a\nb\n", .{}, .{}, "@@ -0,0 +1,2 @@\n+a\n+b\n");
    try expectDiff("a\n", "", .{}, .{}, "@@ -1 +0,0 @@\n-a\n");
    try expectDiff("same\n", "same\n", .{}, .{}, "");
}

test "funcname header" {
    const a = "int main(void)\n{\n\tone;\n\ttwo;\n\tthree;\n\tfour;\n\tfive;\n}\n";
    const b = "int main(void)\n{\n\tone;\n\ttwo;\n\tthree;\n\tfour;\n\tFIVE;\n}\n";
    try expectDiff(a, b, .{}, .{}, "@@ -4,5 +4,5 @@ int main(void)\n \ttwo;\n \tthree;\n \tfour;\n-\tfive;\n+\tFIVE;\n }\n");
}

test "hunk merging and separation" {
    const a = "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20\n";
    const b = "1\nX\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\nY\n20\n";
    try expectDiff(a, b, .{}, .{},
        "@@ -1,5 +1,5 @@\n 1\n-2\n+X\n 3\n 4\n 5\n" ++
        "@@ -16,5 +16,5 @@\n 16\n 17\n 18\n-19\n+Y\n 20\n");
    // changes 6 lines apart (<= 2*ctx) merge into one hunk
    const c = "1\nX\n3\n4\n5\n6\n7\nY\n9\n10\n";
    try expectDiff(a[0..21], c, .{}, .{ .context = 3 },
        "@@ -1,10 +1,10 @@\n 1\n-2\n+X\n 3\n 4\n 5\n 6\n 7\n-8\n+Y\n 9\n 10\n");
}

test "indent heuristic (t4061)" {
    // t4061-diff-indent.sh "spaces" example: 1 2 a <blank> b 3 4 -> insert "b a <blank>"
    const old = "1\n2\na\n\nb\n3\n4\n";
    const new = "1\n2\na\n\nb\na\n\nb\n3\n4\n";
    // with the (default) indent heuristic the blank line ends the inserted block
    try expectDiff(old, new, .{}, .{}, "@@ -2,6 +2,9 @@\n 2\n a\n \n+b\n+a\n+\n b\n 3\n 4\n");
    // --no-indent-heuristic: the group is slid down as far as possible
    try expectDiff(old, new, .{ .indent_heuristic = false }, .{}, "@@ -3,5 +3,8 @@\n a\n \n b\n+a\n+\n+b\n 3\n 4\n");
}

test "indent heuristic functions" {
    // from t4061: adding a function after another
    const old =
        \\    1
        \\    2
        \\    if (x) {
        \\        y();
        \\    }
        \\    3
        \\
    ;
    const new =
        \\    1
        \\    2
        \\    if (x) {
        \\        y();
        \\    }
        \\    if (x) {
        \\        y();
        \\    }
        \\    3
        \\
    ;
    try expectDiff(old, new, .{}, .{},
        \\@@ -3,4 +3,7 @@
        \\     if (x) {
        \\         y();
        \\     }
        \\+    if (x) {
        \\+        y();
        \\+    }
        \\     3
        \\
    );
}

test "patience vs myers (t4033)" {
    const a =
        \\#include <stdio.h>
        \\
        \\// Frobs foo heartily
        \\int frobnitz(int foo)
        \\{
        \\    int i;
        \\    for(i = 0; i < 10; i++)
        \\    {
        \\        printf("Your answer is: ");
        \\        printf("%d\n", foo);
        \\    }
        \\}
        \\
        \\int fact(int n)
        \\{
        \\    if(n > 1)
        \\    {
        \\        return fact(n-1) * n;
        \\    }
        \\    return 1;
        \\}
        \\
        \\int main(int argc, char **argv)
        \\{
        \\    frobnitz(fact(10));
        \\}
        \\
    ;
    const b =
        \\#include <stdio.h>
        \\
        \\int fib(int n)
        \\{
        \\    if(n > 2)
        \\    {
        \\        return fib(n-1) + fib(n-2);
        \\    }
        \\    return 1;
        \\}
        \\
        \\// Frobs foo heartily
        \\int frobnitz(int foo)
        \\{
        \\    int i;
        \\    for(i = 0; i < 10; i++)
        \\    {
        \\        printf("%d\n", foo);
        \\    }
        \\}
        \\
        \\int main(int argc, char **argv)
        \\{
        \\    frobnitz(fib(10));
        \\}
        \\
    ;
    const patience_expect =
        \\@@ -1,26 +1,25 @@
        \\ #include <stdio.h>
        \\ 
        \\+int fib(int n)
        \\+{
        \\+    if(n > 2)
        \\+    {
        \\+        return fib(n-1) + fib(n-2);
        \\+    }
        \\+    return 1;
        \\+}
        \\+
        \\ // Frobs foo heartily
        \\ int frobnitz(int foo)
        \\ {
        \\     int i;
        \\     for(i = 0; i < 10; i++)
        \\     {
        \\-        printf("Your answer is: ");
        \\         printf("%d\n", foo);
        \\     }
        \\ }
        \\ 
        \\-int fact(int n)
        \\-{
        \\-    if(n > 1)
        \\-    {
        \\-        return fact(n-1) * n;
        \\-    }
        \\-    return 1;
        \\-}
        \\-
        \\ int main(int argc, char **argv)
        \\ {
        \\-    frobnitz(fact(10));
        \\+    frobnitz(fib(10));
        \\ }
        \\
    ;
    try expectDiff(a, b, .{ .algorithm = .patience }, .{ .context = 3 }, patience_expect);
    try expectDiff(a, b, .{ .algorithm = .histogram }, .{ .context = 3 }, patience_expect);
}

test "ignore whitespace" {
    try expectDiff("a b\nc\n", "a  b\nd\n", .{ .ignore_ws_change = true }, .{}, "@@ -1,2 +1,2 @@\n a  b\n-c\n+d\n");
    try expectDiff("a b\n", "ab\n", .{ .ignore_ws = true }, .{}, "");
    try expectDiff("a b \n", "a b\n", .{ .ignore_ws_eol = true }, .{}, "");
    try expectDiff("a\r\n", "a\n", .{ .ignore_cr_eol = true }, .{}, "");
    try expectDiff("a\n", "a \n", .{}, .{}, "@@ -1 +1 @@\n-a\n+a \n");
}

test "ignore blank lines" {
    try expectDiff("a\nb\n", "a\n\nb\n", .{ .ignore_blank_lines = true }, .{}, "");
    const a = "1\n2\n3\n4\n5\n6\n7\n8\n9\n";
    const b = "1\n2\n3\n4\n5\n6\n7\n8\nX\n\n";
    // blank-line addition adjacent to a real change is shown
    try expectDiff(a, b, .{ .ignore_blank_lines = true }, .{}, "@@ -6,4 +6,5 @@\n 6\n 7\n 8\n-9\n+X\n+\n");
}

test "merge clean and conflict" {
    const base = "1\n2\n3\n4\n5\n6\n7\n8\n9\n";
    const ours = "1\nA\n3\n4\n5\n6\n7\n8\n9\n";
    const theirs = "1\n2\n3\n4\n5\n6\n7\nB\n9\n";
    const r = try merge(base, ours, theirs, .{});
    try std.testing.expectEqual(@as(usize, 0), r.conflicts);
    try std.testing.expectEqualStrings("1\nA\n3\n4\n5\n6\n7\nB\n9\n", r.result);

    const t2 = "1\nB\n3\n4\n5\n6\n7\n8\n9\n";
    const r2 = try merge(base, ours, t2, .{ .ours_name = "ours", .theirs_name = "theirs" });
    try std.testing.expectEqual(@as(usize, 1), r2.conflicts);
    try std.testing.expectEqualStrings("1\n<<<<<<< ours\nA\n=======\nB\n>>>>>>> theirs\n3\n4\n5\n6\n7\n8\n9\n", r2.result);

    const r3 = try merge(base, ours, t2, .{ .style = .diff3, .ours_name = "ours", .theirs_name = "theirs", .ancestor_name = "base" });
    try std.testing.expectEqualStrings("1\n<<<<<<< ours\nA\n||||||| base\n2\n=======\nB\n>>>>>>> theirs\n3\n4\n5\n6\n7\n8\n9\n", r3.result);

    const r4 = try merge(base, ours, t2, .{ .favor = .union_ });
    try std.testing.expectEqual(@as(usize, 0), r4.conflicts);
    try std.testing.expectEqualStrings("1\nA\nB\n3\n4\n5\n6\n7\n8\n9\n", r4.result);

    const r5 = try merge(base, ours, t2, .{ .favor = .theirs });
    try std.testing.expectEqualStrings(t2, r5.result);
}

test "zealous merge refines identical parts" {
    const base = "1\n2\n3\n";
    const ours = "1\nx\ny\nz\n3\n";
    const theirs = "1\nx\nQ\nz\n3\n";
    const r = try merge(base, ours, theirs, .{ .marker_size = 3 });
    try std.testing.expectEqual(@as(usize, 1), r.conflicts);
    try std.testing.expectEqualStrings("1\nx\n<<<\ny\n===\nQ\n>>>\nz\n3\n", r.result);
    const z = try merge(base, ours, theirs, .{ .style = .zdiff3, .marker_size = 3 });
    try std.testing.expectEqualStrings("1\nx\n<<<\ny\n|||\n2\n===\nQ\n>>>\nz\n3\n", z.result);
    const d3 = try merge(base, ours, theirs, .{ .style = .diff3, .marker_size = 3 });
    try std.testing.expectEqualStrings("1\n<<<\nx\ny\nz\n|||\n2\n===\nx\nQ\nz\n>>>\n3\n", d3.result);
}

test "func context" {
    const a = "f1\n a\n\nf2\n c\n d\n e\n f\n g\n h\n\nf3\n x\n";
    const b = "f1\n a\n\nf2\n c\n d\n e\n f\n g\n H\n\nf3\n x\n";
    try expectDiff(a, b, .{}, .{ .context = 1, .func_context = true },
        "@@ -4,8 +4,8 @@ f1\n f2\n  c\n  d\n  e\n  f\n  g\n- h\n+ H\n \n");
    try expectDiff(a, b, .{}, .{ .context = 1 }, "@@ -9,3 +9,3 @@ f2\n  g\n- h\n+ H\n \n");
}

test "ignore regex (-I)" {
    const re = switch (regex.Regex.compile("^#", .{ .extended = true })) {
        .ok => |r| r,
        .err => return error.TestUnexpectedResult,
    };
    const res = [_]regex.Regex{re};
    try expectDiff("a\n#x\nb\n", "a\n#y\nb\n", .{ .ignore_regex = &res }, .{}, "");
    try expectDiff("a\n#x\nb\n", "a\n#y\nc\n", .{ .ignore_regex = &res }, .{}, "@@ -1,3 +1,3 @@\n a\n-#x\n-b\n+#y\n+c\n");
}

test "xfuncname regex" {
    const ff = RegexFindFunc.init("!^static\n^[a-z]+ ([a-z]+)\\(", .{ .extended = true });
    const a = "void foo(int x)\nstatic bar(int y)\n1\n2\n3\n4\n";
    const b = "void foo(int x)\nstatic bar(int y)\n1\n2\n3\nX\n";
    try expectDiff(a, b, .{}, .{ .context = 1, .find_func = ff.findFunc() }, "@@ -5,2 +5,2 @@ foo\n 3\n-4\n+X\n");
    try expectDiff(a, b, .{}, .{ .context = 1 }, "@@ -5,2 +5,2 @@ static bar(int y)\n 3\n-4\n+X\n");
}

test "anchored patience" {
    // without anchor patience keeps "a" common; anchoring "c" forces c to be kept instead
    const a = "a\nb\nc\n";
    const b = "c\na\nb\n";
    try expectDiff(a, b, .{ .algorithm = .patience }, .{}, "@@ -1,3 +1,3 @@\n+c\n a\n b\n-c\n");
    const anchors = [_][]const u8{"c"};
    try expectDiff(a, b, .{ .algorithm = .patience, .anchors = &anchors }, .{}, "@@ -1,3 +1,3 @@\n-a\n-b\n c\n+a\n+b\n");
}

test "merge crlf markers and missing newline" {
    const base = "1\r\n2\r\n3\r\n";
    const ours = "1\r\nA\r\n3\r\n";
    const theirs = "1\r\nB\r\n3\r\n";
    const r = try merge(base, ours, theirs, .{ .ours_name = "o", .theirs_name = "t" });
    try std.testing.expectEqualStrings("1\r\n<<<<<<< o\r\nA\r\n=======\r\nB\r\n>>>>>>> t\r\n3\r\n", r.result);
    const r2 = try merge("1\n2", "1\nA", "1\nB", .{});
    try std.testing.expectEqual(@as(usize, 1), r2.conflicts);
    try std.testing.expectEqualStrings("1\n<<<<<<<\nA\n=======\nB\n>>>>>>>\n", r2.result);
}

fn applyCheck(a: []const u8, b: []const u8, flags: Flags) !void {
    var d = try diff(a, b, flags);
    defer d.deinit();
    // rebuild b from a and the edit script
    var out: std.ArrayList(u8) = .empty;
    defer out.deinit(std.testing.allocator);
    var ia: isize = 0;
    for (d.changes) |c| {
        try std.testing.expect(c.i1 >= ia);
        while (ia < c.i1) : (ia += 1) try out.appendSlice(std.testing.allocator, d.lineA(U(ia)));
        var k: isize = 0;
        while (k < c.chg2) : (k += 1) try out.appendSlice(std.testing.allocator, d.lineB(U(c.i2 + k)));
        ia = c.i1 + c.chg1;
    }
    while (ia < d.nrecA()) : (ia += 1) try out.appendSlice(std.testing.allocator, d.lineA(U(ia)));
    try std.testing.expectEqualStrings(b, out.items);
}

test "random diffs reconstruct b for all algorithms" {
    var prng = std.Random.DefaultPrng.init(12345);
    const rnd = prng.random();
    const words = [_][]const u8{ "a\n", "b\n", "c\n", "\n", "  x\n", "\ty\n", "}\n", "{\n", "foo\n", "bar\n" };
    var iter: usize = 0;
    while (iter < 300) : (iter += 1) {
        var a: std.ArrayList(u8) = .empty;
        defer a.deinit(std.testing.allocator);
        var b: std.ArrayList(u8) = .empty;
        defer b.deinit(std.testing.allocator);
        const na = rnd.uintLessThan(usize, if (iter % 10 == 0) 600 else 40);
        for (0..na) |_| try a.appendSlice(std.testing.allocator, words[rnd.uintLessThan(usize, words.len)]);
        // mutate
        var i: usize = 0;
        var lines = std.mem.splitScalar(u8, a.items, '\n');
        while (lines.next()) |l| : (i += 1) {
            if (lines.index == null and l.len == 0) break;
            const r = rnd.uintLessThan(u8, 10);
            if (r == 0) continue;
            if (r == 1) try b.appendSlice(std.testing.allocator, words[rnd.uintLessThan(usize, words.len)]);
            try b.appendSlice(std.testing.allocator, l);
            try b.append(std.testing.allocator, '\n');
        }
        if (rnd.boolean() and b.items.len > 0) _ = b.pop();
        for ([_]Algorithm{ .myers, .minimal, .patience, .histogram }) |al| {
            try applyCheck(a.items, b.items, .{ .algorithm = al });
            _ = try unifiedDiff(a.items, b.items, .{ .algorithm = al, .ignore_ws_change = true, .indent_heuristic = false }, .{});
            _ = try unifiedDiff(a.items, b.items, .{ .algorithm = al }, .{ .func_context = true });
            _ = try merge(a.items, b.items, a.items[0 .. a.items.len / 2], .{ .flags = .{ .algorithm = al }, .style = .zdiff3 });
            _ = try merge(a.items, b.items, a.items[a.items.len / 2 ..], .{ .flags = .{ .algorithm = al } });
        }
    }
}
