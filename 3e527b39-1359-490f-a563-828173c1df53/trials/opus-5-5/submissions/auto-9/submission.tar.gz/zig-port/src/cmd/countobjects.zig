//! git count-objects (builtin/count-objects.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const gpa = util.gpa;

pub fn humaniseBytes(b: *util.Buf, bytes: u64) void {
    if (bytes > 1 << 30) {
        const x = bytes + 5368709;
        util.bufPrint(b, "{d}.{d:0>2} GiB", .{ x >> 30, (x & ((1 << 30) - 1)) / 10737419 });
    } else if (bytes > 1 << 20) {
        const x = bytes + 5243;
        util.bufPrint(b, "{d}.{d:0>2} MiB", .{ x >> 20, ((x & ((1 << 20) - 1)) * 100) >> 20 });
    } else if (bytes > 1 << 10) {
        const x = bytes + 5;
        util.bufPrint(b, "{d}.{d:0>2} KiB", .{ x >> 10, ((x & ((1 << 10) - 1)) * 100) >> 10 });
    } else {
        util.bufPrint(b, "{d} {s}", .{ bytes, if (bytes == 1) "byte" else "bytes" });
    }
}

var garbage: u64 = 0;
var size_garbage: u64 = 0;

fn reportGarbage(desc: []const u8, path: []const u8) void {
    if (os.statPath(path)) |st| size_garbage += @intCast(st.size);
    util.warn("{s}: {s}", .{ desc, path });
    garbage += 1;
}

fn isHex(s: []const u8) bool {
    for (s) |ch| {
        if (!std.ascii.isHex(ch) or std.ascii.isUpper(ch)) return false;
    }
    return true;
}

fn lessStr(_: void, a: []const u8, b: []const u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

/// report_pack_garbage over objects/pack (only called when verbose).
fn packGarbage(pack_dir: []const u8) void {
    const ents = os.listDir(pack_dir) orelse return;
    var list: std.ArrayList([]const u8) = .empty;
    for (ents) |e| {
        const name = e.name;
        const full = util.concat(&.{ pack_dir, "/", name });
        if (util.eql(name, "multi-pack-index") or util.eql(name, "multi-pack-index.d")) continue;
        if (util.startsWith(name, "multi-pack-index") and (util.endsWith(name, ".bitmap") or util.endsWith(name, ".rev"))) continue;
        const exts = [_][]const u8{ ".idx", ".rev", ".pack", ".bitmap", ".keep", ".promisor", ".mtimes" };
        var known = false;
        for (exts) |x| {
            if (util.endsWith(name, x)) known = true;
        }
        if (known) list.append(gpa, full) catch util.oom() else reportGarbage("garbage found", full);
    }
    std.mem.sort([]const u8, list.items, {}, lessStr);
    var baselen: ?usize = null;
    var first: usize = 0;
    var seen: u32 = 0;
    var i: usize = 0;
    while (i < list.items.len) : (i += 1) {
        const path = list.items[i];
        if (baselen) |bl| {
            if (!(path.len >= bl and std.mem.eql(u8, path[0..bl], list.items[first][0..bl]))) {
                helper(list.items, seen, first, i);
                baselen = null;
                seen = 0;
            }
        }
        if (baselen == null) {
            const dot = std.mem.lastIndexOfScalar(u8, path, '.') orelse {
                reportGarbage("garbage found", path);
                continue;
            };
            baselen = dot + 1;
            first = i;
        }
        const ext = path[baselen.?..];
        if (util.eql(ext, "pack")) seen |= 1 else if (util.eql(ext, "idx")) seen |= 2;
    }
    helper(list.items, seen, first, list.items.len);
}

fn helper(list: []const []const u8, seen: u32, first: usize, last: usize) void {
    if (seen == 3) return;
    const desc: []const u8 = switch (seen) {
        0 => "no corresponding .idx or .pack",
        1 => "no corresponding .idx",
        2 => "no corresponding .pack",
        else => return,
    };
    var k = first;
    while (k < last) : (k += 1) reportGarbage(desc, list[k]);
}

const usage = [_][]const u8{"git count-objects [-v] [-H | --human-readable]"};

pub fn cmdCountObjects(args: []const []const u8) u8 {
    var verbose: i32 = 0;
    var human = false;
    const options = [_]po.Opt{
        po.verbose(&verbose),
        po.boolean('H', "human-readable", &human, "print sizes in human readable format"),
    };
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len > 0) po.usageWithOptions(&usage, &options);
    const r = repo_mod.repo();
    const odb = r.odb();
    odb.loadPacks();
    const vb = verbose > 0;

    if (vb and !util.eql(r.git_dir, r.common_dir)) linkedCheckoutGarbage(r.git_dir);

    var loose: u64 = 0;
    var loose_size: u64 = 0;
    var packed_loose: u64 = 0;
    var pack_reported = false;
    var d: usize = 0;
    while (d < 256) : (d += 1) {
        const sub = util.fmt("{x:0>2}", .{d});
        const dir = util.concat(&.{ odb.objects_dir, "/", sub });
        const ents = os.listDir(dir) orelse continue;
        for (ents) |e| {
            const path = util.concat(&.{ dir, "/", e.name });
            if (e.name.len == 38 and isHex(e.name)) {
                const st = os.lstatPath(path);
                if (st == null or !st.?.isReg()) {
                    if (vb) reportGarbage("garbage found", path);
                    continue;
                }
                loose_size += @as(u64, @intCast(st.?.blocks)) * 512;
                loose += 1;
                if (vb) {
                    if (!pack_reported) {
                        pack_reported = true;
                        packGarbage(util.concat(&.{ odb.objects_dir, "/pack" }));
                    }
                    const oid = hash.fromHex(util.concat(&.{ sub, e.name })) orelse continue;
                    if (odb.findPacked(oid) != null) packed_loose += 1;
                }
            } else {
                if (vb) reportGarbage("garbage found", path);
            }
        }
    }

    if (vb) {
        if (!pack_reported) packGarbage(util.concat(&.{ odb.objects_dir, "/pack" }));
        var packed_n: u64 = 0;
        var num_pack: u64 = 0;
        var size_pack: u64 = 0;
        for (odb.packs.items) |p| {
            if (!util.startsWith(p.idx_path, odb.objects_dir)) continue;
            packed_n += p.num;
            const ps = os.statPath(p.pack_path);
            size_pack += if (ps) |s| @as(u64, @intCast(s.size)) else 0;
            size_pack += p.idx.len;
            num_pack += 1;
        }
        var lb: util.Buf = .empty;
        var pb: util.Buf = .empty;
        var gb: util.Buf = .empty;
        if (human) {
            humaniseBytes(&lb, loose_size);
            humaniseBytes(&pb, size_pack);
            humaniseBytes(&gb, size_garbage);
        } else {
            util.bufPrint(&lb, "{d}", .{loose_size / 1024});
            util.bufPrint(&pb, "{d}", .{size_pack / 1024});
            util.bufPrint(&gb, "{d}", .{size_garbage / 1024});
        }
        util.outf("count: {d}\n", .{loose});
        util.outf("size: {s}\n", .{lb.items});
        util.outf("in-pack: {d}\n", .{packed_n});
        util.outf("packs: {d}\n", .{num_pack});
        util.outf("size-pack: {s}\n", .{pb.items});
        util.outf("prune-packable: {d}\n", .{packed_loose});
        util.outf("garbage: {d}\n", .{garbage});
        util.outf("size-garbage: {s}\n", .{gb.items});
        for (odb.alternates.items) |a| {
            util.outf("alternate: {s}\n", .{util.cquote(a)});
        }
    } else {
        var b: util.Buf = .empty;
        if (human) humaniseBytes(&b, loose_size) else util.bufPrint(&b, "{d} kilobytes", .{loose_size / 1024});
        util.outf("{d} objects, {s}\n", .{ loose, b.items });
    }
    return 0;
}

fn linkedCheckoutGarbage(git_dir: []const u8) void {
    // Mirrors common_list entries with ignore_garbage == 0.
    const entries = [_][]const u8{ "branches", "common", "hooks", "info", "info/sparse-checkout", "logs/refs/bisect", "logs/refs/rewritten", "logs/refs/worktree", "lost-found", "objects", "refs", "refs/bisect", "refs/rewritten", "refs/worktree", "remotes", "worktrees", "rr-cache", "svn", "config", "packed-refs", "shallow" };
    for (entries) |e| {
        const p = util.concat(&.{ git_dir, "/", e });
        if (os.exists(p)) reportGarbage("garbage found", p);
    }
}
