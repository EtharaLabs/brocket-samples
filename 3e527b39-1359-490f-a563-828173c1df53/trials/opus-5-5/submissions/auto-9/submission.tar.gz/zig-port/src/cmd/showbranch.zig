//! git show-branch (port of builtin/show-branch.c)

const std = @import("std");
const util = @import("../util.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const revparse = @import("../revparse.zig");
const refs = @import("../refs.zig");
const cn = @import("../commitnode.zig");
const po = @import("../parseopt.zig");
const pretty = @import("../pretty.zig");
const date = @import("../date.zig");
const color = @import("../color.zig");
const wildmatch = @import("../wildmatch.zig");
const os = @import("../os.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Commit = cn.Commit;

const show_branch_usage = [_][]const u8{
    "git show-branch [-a | --all] [-r | --remotes] [--topo-order | --date-order]\n" ++
        "                [--current] [--color[=<when>] | --no-color] [--sparse]\n" ++
        "                [--more=<n> | --list | --independent | --merge-base]\n" ++
        "                [--no-name | --sha1-name] [--topics]\n" ++
        "                [(<rev> | <glob>)...]",
    "git show-branch (-g | --reflog)[=<n>[,<base>]] [--list] [<ref>]",
};

const UNINTERESTING: u32 = 1;
const REV_SHIFT: u5 = 2;
const FLAG_BITS = 28;
const MAX_REVS: usize = FLAG_BITS - REV_SHIFT;
const DEFAULT_REFLOG: i32 = 4;

const column_colors_ansi = [_][]const u8{
    "\x1b[31m",   "\x1b[32m",   "\x1b[33m",   "\x1b[34m",   "\x1b[35m",   "\x1b[36m",
    "\x1b[1;31m", "\x1b[1;32m", "\x1b[1;33m", "\x1b[1;34m", "\x1b[1;35m", "\x1b[1;36m",
};

var use_color: color.ColorBool = .unknown;
var color_on = false;

fn getColorCode(idx: usize) []const u8 {
    if (color_on) return column_colors_ansi[idx % column_colors_ansi.len];
    return "";
}
fn getColorResetCode() []const u8 {
    if (color_on) return "\x1b[m";
    return "";
}

fn interesting(queue: *cn.PrioQueue) ?*Commit {
    for (queue.items()) |it| {
        if (it.data.obj.flags & UNINTERESTING == 0) return it.data;
    }
    return null;
}

const CommitName = struct { head_name: []const u8, generation: i32 };
var name_slab = cn.Slab(?*CommitName).init(null);

fn commitToName(c: *Commit) ?*CommitName {
    const p = name_slab.peek(c) orelse return null;
    return p.*;
}

fn nameCommit(c: *Commit, head_name: []const u8, nth: i32) void {
    const slot = name_slab.at(c);
    if (slot.* == null) slot.* = gpa.create(CommitName) catch util.oom();
    slot.*.?.* = .{ .head_name = head_name, .generation = nth };
}

fn nameParent(c: *Commit, parent: *Commit) void {
    const cname = commitToName(c) orelse return;
    const pname = commitToName(parent);
    if (pname == null or cname.generation + 1 < pname.?.generation)
        nameCommit(parent, cname.head_name, cname.generation + 1);
}

fn nameFirstParentChain(c0: *Commit) i32 {
    var i: i32 = 0;
    var c = c0;
    while (true) {
        if (commitToName(c) == null) break;
        const pl = c.parents orelse break;
        const p = pl.item;
        if (commitToName(p) == null) {
            nameParent(c, p);
            i += 1;
        } else break;
        c = p;
    }
    return i;
}

fn nameCommits(list: ?*cn.CommitList, rev: []*Commit, ref_names: []const []const u8) void {
    var cl = list;
    while (cl) |l| : (cl = l.next) {
        const c = l.item;
        if (commitToName(c) != null) continue;
        for (rev, 0..) |r, i| {
            if (r == c) {
                nameCommit(c, ref_names[i], 0);
                break;
            }
        }
    }
    while (true) {
        var i: i32 = 0;
        cl = list;
        while (cl) |l| : (cl = l.next) i += nameFirstParentChain(l.item);
        if (i == 0) break;
    }
    while (true) {
        var i: i32 = 0;
        cl = list;
        while (cl) |l| : (cl = l.next) {
            const c = l.item;
            const n = commitToName(c) orelse continue;
            var parents = c.parents;
            var nth: i32 = 0;
            while (parents) |pl| {
                const p = pl.item;
                parents = pl.next;
                nth += 1;
                if (commitToName(p) != null) continue;
                var nn: util.Buf = .empty;
                switch (n.generation) {
                    0 => util.bufAppend(&nn, n.head_name),
                    1 => util.bufPrint(&nn, "{s}^", .{n.head_name}),
                    else => util.bufPrint(&nn, "{s}~{d}", .{ n.head_name, n.generation }),
                }
                if (nth == 1) util.bufByte(&nn, '^') else util.bufPrint(&nn, "^{d}", .{nth});
                nameCommit(p, nn.items, 0);
                i += 1;
                _ = nameFirstParentChain(p);
            }
        }
        if (i == 0) break;
    }
}

fn markSeen(c: *Commit, seen: *?*cn.CommitList) bool {
    if (c.obj.flags == 0) {
        _ = cn.listInsert(c, seen);
        return true;
    }
    return false;
}

fn masks(num_rev: usize) struct { all_mask: u32, all_revs: u32 } {
    const all_mask: u32 = @intCast((@as(u64, 1) << @intCast(REV_SHIFT + num_rev)) - 1);
    const all_revs: u32 = all_mask & ~((@as(u32, 1) << REV_SHIFT) - 1);
    return .{ .all_mask = all_mask, .all_revs = all_revs };
}

fn joinRevs(queue: *cn.PrioQueue, seen: *?*cn.CommitList, num_rev: usize, extra0: i32) void {
    var extra = extra0;
    const m = masks(num_rev);
    while (queue.peek()) |commit| {
        const still_interesting = interesting(queue) != null;
        var flags = commit.obj.flags & m.all_mask;
        if (!still_interesting and extra <= 0) break;
        _ = queue.get();
        _ = markSeen(commit, seen);
        if (flags & m.all_revs == m.all_revs) flags |= UNINTERESTING;
        var parents = commit.parents;
        while (parents) |pl| {
            const p = pl.item;
            parents = pl.next;
            if (p.obj.flags & flags == flags) continue;
            _ = cn.parse(p);
            if (markSeen(p, seen) and !still_interesting) extra -= 1;
            p.obj.flags |= flags;
            queue.put(p);
        }
    }
    while (true) {
        var changed = false;
        var s = seen.*;
        while (s) |sl| : (s = sl.next) {
            const c = sl.item;
            if (c.obj.flags & m.all_revs != m.all_revs and c.obj.flags & UNINTERESTING == 0) continue;
            var parents = c.parents;
            while (parents) |pl| {
                const p = pl.item;
                parents = pl.next;
                if (p.obj.flags & UNINTERESTING == 0) {
                    p.obj.flags |= UNINTERESTING;
                    changed = true;
                }
            }
        }
        if (!changed) break;
    }
}

fn showOneCommit(commit: *Commit, no_name: bool) void {
    var pretty_str: []const u8 = "(unavailable)";
    if (commit.obj.parsed) {
        var sb: util.Buf = .empty;
        pretty.ppCommitEasy(.oneline, commit, &sb);
        pretty_str = sb.items;
        if (pretty_str.len > 0 and pretty_str[pretty_str.len - 1] == '\n') pretty_str = pretty_str[0 .. pretty_str.len - 1];
    }
    if (util.startsWith(pretty_str, "[PATCH] ")) pretty_str = pretty_str[8..];
    var b: util.Buf = .empty;
    if (!no_name) {
        if (commitToName(commit)) |name| {
            util.bufPrint(&b, "[{s}", .{name.head_name});
            if (name.generation != 0) {
                if (name.generation == 1) util.bufByte(&b, '^') else util.bufPrint(&b, "~{d}", .{name.generation});
            }
            util.bufAppend(&b, "] ");
        } else {
            util.bufPrint(&b, "[{s}] ", .{revparse.abbrev(commit.obj.oid, revparse.defaultAbbrev())});
        }
    }
    util.bufAppend(&b, pretty_str);
    util.bufByte(&b, '\n');
    util.out(b.items);
}

var ref_name: std.ArrayList([]const u8) = .empty;

fn findDigitPrefix(s: []const u8, pos: *usize) i32 {
    var v: i32 = 0;
    while (pos.* < s.len and std.ascii.isDigit(s[pos.*])) : (pos.* += 1) v = v *% 10 +% @as(i32, s[pos.*] - '0');
    return v;
}

fn versionCmp(a: []const u8, b: []const u8) i32 {
    var pa: usize = 0;
    var pb: usize = 0;
    while (true) {
        const va = findDigitPrefix(a, &pa);
        const vb = findDigitPrefix(b, &pb);
        if (va != vb) return va - vb;
        while (true) {
            var ca: i32 = if (pa < a.len) a[pa] else 0;
            var cb: i32 = if (pb < b.len) b[pb] else 0;
            if ('0' <= ca and ca <= '9') ca = 0;
            if ('0' <= cb and cb <= '9') cb = 0;
            if (ca != cb) return ca - cb;
            if (ca == 0) break;
            pa += 1;
            pb += 1;
        }
        if (pa >= a.len and pb >= b.len) return 0;
    }
}

fn sortRefRange(bottom: usize, top: usize) void {
    std.mem.sort([]const u8, ref_name.items[bottom..top], {}, struct {
        fn lt(_: void, x: []const u8, y: []const u8) bool {
            return versionCmp(x, y) < 0;
        }
    }.lt);
}

fn appendRef(refname: []const u8, oid: Oid, allow_dups: bool) void {
    _ = cn.lookupCommitReference(oid) orelse return;
    if (!allow_dups) {
        for (ref_name.items) |n| if (util.eql(n, refname)) return;
    }
    if (MAX_REVS <= ref_name.items.len) {
        util.warn("ignoring {s}; cannot handle more than {d} refs", .{ refname, MAX_REVS });
        return;
    }
    ref_name.append(gpa, util.dupe(refname)) catch util.oom();
}

fn appendHeadRef(name: []const u8, oid: Oid) void {
    if (!util.startsWith(name, "refs/heads/")) return;
    var ofs: usize = 11;
    const tmp = revparse.getOid(name[ofs..]);
    if (tmp == null or !hash.eql(tmp.?, oid)) ofs = 5;
    appendRef(name[ofs..], oid, false);
}

fn appendRemoteRef(name: []const u8, oid: Oid) void {
    if (!util.startsWith(name, "refs/remotes/")) return;
    var ofs: usize = 13;
    const tmp = revparse.getOid(name[ofs..]);
    if (tmp == null or !hash.eql(tmp.?, oid)) ofs = 5;
    appendRef(name[ofs..], oid, false);
}

fn appendTagRef(name: []const u8, oid: Oid) void {
    if (!util.startsWith(name, "refs/tags/")) return;
    appendRef(name[5..], oid, false);
}

fn countSlashes(s: []const u8) usize {
    return std.mem.count(u8, s, "/");
}

fn appendMatchingRef(name: []const u8, oid: Oid, pattern: []const u8, match_slash: usize) void {
    var slash = countSlashes(name);
    var t: usize = 0;
    while (t < name.len and match_slash < slash) {
        if (name[t] == '/') slash -= 1;
        t += 1;
    }
    if (t >= name.len) return;
    if (!wildmatch.match(pattern, name[t..], 0)) return;
    if (util.startsWith(name, "refs/heads/")) return appendHeadRef(name, oid);
    if (util.startsWith(name, "refs/tags/")) return appendTagRef(name, oid);
    appendRef(name, oid, false);
}

fn allRefs() []refs.Ref {
    return refs.iterate("refs/", .{ .check_objects = false });
}

fn snarfRefs(head: bool, remotes: bool) void {
    if (head) {
        const orig = ref_name.items.len;
        for (allRefs()) |r| appendHeadRef(r.name, r.oid);
        sortRefRange(orig, ref_name.items.len);
    }
    if (remotes) {
        const orig = ref_name.items.len;
        for (allRefs()) |r| appendRemoteRef(r.name, r.oid);
        sortRefRange(orig, ref_name.items.len);
    }
}

fn revIsHead(head0: ?[]const u8, name0: []const u8) bool {
    var head = head0 orelse return false;
    if (util.skipPrefix(head, "refs/heads/")) |h| head = h;
    var name = name0;
    if (util.skipPrefix(name, "refs/heads/")) |n| {
        name = n;
    } else if (util.skipPrefix(name, "heads/")) |n| name = n;
    return util.eql(head, name);
}

fn showMergeBase(seen: ?*cn.CommitList, num_rev: usize) u8 {
    const m = masks(num_rev);
    var status: u8 = 1;
    var s = seen;
    while (s) |sl| : (s = sl.next) {
        const c = sl.item;
        const flags = c.obj.flags & m.all_mask;
        if (flags & UNINTERESTING == 0 and flags & m.all_revs == m.all_revs) {
            util.outf("{s}\n", .{hash.hex(c.obj.oid)});
            status = 0;
            c.obj.flags |= UNINTERESTING;
        }
    }
    return status;
}

fn showIndependent(rev: []*Commit, rev_mask: []u32) u8 {
    for (rev, 0..) |c, i| {
        if (c.obj.flags == rev_mask[i]) util.outf("{s}\n", .{hash.hex(c.obj.oid)});
        c.obj.flags |= UNINTERESTING;
    }
    return 0;
}

fn appendOneRev(av: []const u8) void {
    if (revparse.getOid(av)) |oid| {
        appendRef(av, oid, false);
        return;
    }
    if (std.mem.indexOfAny(u8, av, "*?[") != null) {
        const saved = ref_name.items.len;
        const slashes = countSlashes(av);
        for (allRefs()) |r| appendMatchingRef(r.name, r.oid, av, slashes);
        if (saved == ref_name.items.len and ref_name.items.len < MAX_REVS)
            util.err("no matching refs with {s}", .{av});
        sortRefRange(saved, ref_name.items.len);
        return;
    }
    util.die("bad sha1 reference {s}", .{av});
}

fn omitInDense(commit: *Commit, rev: []*Commit) bool {
    for (rev) |r| if (r == commit) return false;
    const flag = commit.obj.flags;
    var count: usize = 0;
    for (0..rev.len) |i| {
        if (flag & (@as(u32, 1) << @intCast(i + REV_SHIFT)) != 0) count += 1;
    }
    return count == 1;
}

var reflog: i32 = 0;
var reflog_base: ?[]const u8 = null;
var reflog_err = false;

fn parseReflogParam(arg0: ?[]const u8, unset: bool) void {
    _ = unset;
    const arg = arg0 orelse "";
    var i: usize = 0;
    var v: u64 = 0;
    while (i < arg.len and std.ascii.isDigit(arg[i])) : (i += 1) v = v *% 10 +% (arg[i] - '0');
    reflog = @truncate(@as(i64, @bitCast(v)));
    if (i < arg.len and arg[i] == ',') {
        reflog_base = arg[i + 1 ..];
    } else if (i < arg.len) {
        util.err("unrecognized reflog param '{s}'", .{arg});
        reflog_err = true;
        return;
    } else reflog_base = null;
    if (reflog <= 0) reflog = DEFAULT_REFLOG;
}

var color_arg_bad = false;
fn colorCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        use_color = .never;
        return;
    }
    const v = color.configColorBool(null, arg orelse "always");
    if (v == .unknown) {
        util.err("option `color' expects \"always\", \"auto\", or \"never\"", .{});
        os.exit(129);
    }
    use_color = v;
}

fn identTime(ident: []const u8) struct { t: i64, tz: i32 } {
    const gt = std.mem.lastIndexOfScalar(u8, ident, '>') orelse return .{ .t = 0, .tz = 0 };
    var rest = std.mem.trim(u8, ident[gt + 1 ..], " ");
    var t: i64 = 0;
    var tz: i32 = 0;
    const sp = std.mem.indexOfScalar(u8, rest, ' ') orelse rest.len;
    t = std.fmt.parseInt(i64, rest[0..sp], 10) catch 0;
    if (sp < rest.len) {
        rest = std.mem.trim(u8, rest[sp..], " ");
        tz = std.fmt.parseInt(i32, rest, 10) catch 0;
    }
    return .{ .t = t, .tz = tz };
}

pub fn cmdShowBranch(args_in: []const []const u8) u8 {
    const cfg = &repo_mod.cfg;
    var args = args_in;
    var default_args: std.ArrayList([]const u8) = .empty;
    for (cfg.getAll("showbranch.default")) |v| {
        if (default_args.items.len == 0) default_args.append(gpa, "show-branch") catch util.oom();
        default_args.append(gpa, v) catch util.oom();
    }
    if (cfg.getEntry("color.showbranch")) |e| use_color = color.configColorBool("color.showbranch", e.value);
    if (args.len == 1 and default_args.items.len > 0) args = default_args.items;

    var all_heads = false;
    var all_remotes = false;
    var extra: i32 = 0;
    var no_name = false;
    var with_current_branch = false;
    var sha1_name = false;
    var merge_base = false;
    var independent = false;
    var sort_order: i32 = 0; // 0 = graph, 1 = commit date
    var topics = false;
    var sparse: i32 = 0;

    const options = [_]po.Opt{
        po.boolean('a', "all", &all_heads, "show remote-tracking and local branches"),
        po.boolean('r', "remotes", &all_remotes, "show remote-tracking branches"),
        .{ .long = "color", .kind = .callback, .cb = colorCb, .optarg = true, .def = "always", .argh = "when", .help = "color '*!+-' corresponding to the branch" },
        .{ .long = "more", .kind = .int, .i = &extra, .argh = "n", .help = "show <n> more commits after the common ancestor", .optarg = true, .val = 1 },
        po.setInt(0, "list", &extra, -1, "synonym to more=-1"),
        po.boolean(0, "no-name", &no_name, "suppress naming strings"),
        po.boolean(0, "current", &with_current_branch, "include the current branch"),
        po.boolean(0, "sha1-name", &sha1_name, "name commits with their object names"),
        po.boolean(0, "merge-base", &merge_base, "show possible merge bases"),
        po.boolean(0, "independent", &independent, "show refs unreachable from any other ref"),
        .{ .long = "topo-order", .kind = .set_int, .i = &sort_order, .val = 0, .noneg = true, .help = "show commits in topological order" },
        po.boolean(0, "topics", &topics, "show only commits not on the first branch"),
        po.setInt(0, "sparse", &sparse, 1, "show merges reachable from only one tip"),
        .{ .long = "date-order", .kind = .set_int, .i = &sort_order, .val = 1, .noneg = true, .help = "topologically sort, maintaining date order where possible" },
        .{ .short = 'g', .long = "reflog", .kind = .callback, .cb = parseReflogParam, .optarg = true, .noneg = true, .argh = "<n>[,<base>]", .literal_argh = true, .help = "show <n> most recent ref-log entries starting at base" },
    };

    var av = po.parse(args[1..], &options, &show_branch_usage, .{ .stop_at_non_option = true });
    if (reflog_err) po.usageWithOptions(&show_branch_usage, &options);
    if (all_heads) all_remotes = true;

    if (extra != 0 or reflog != 0) {
        if (independent or merge_base) po.usageWithOptions(&show_branch_usage, &options);
        if (reflog != 0 and (0 < extra or all_heads or all_remotes))
            util.die("options '{s}' and '{s}' cannot be used together", .{ "--reflog", "--all/--remotes/--independent/--merge-base" });
    }
    if (with_current_branch and reflog != 0)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--reflog", "--current" });

    if (av.len <= @intFromBool(topics) and !all_heads and !all_remotes) all_heads = true;

    var reflog_msg: std.ArrayList([]const u8) = .empty;
    if (reflog != 0) {
        var one: [1][]const u8 = undefined;
        if (av.len == 0) {
            const h = refs.resolve("HEAD") orelse util.die("no branches given, and HEAD is not valid", .{});
            one[0] = h.name;
            av = &one;
        }
        if (av.len != 1) util.die("--reflog option needs one branch name", .{});
        if (MAX_REVS < reflog) util.die("only {d} entries can be shown at one time.", .{MAX_REVS});
        const d = refs.dwimRef(av[0]) orelse util.die("no such ref {s}", .{av[0]});
        const ref = d.name;
        const entries = refs.readReflog(ref);
        const n = entries.len;
        var base: usize = 0;
        if (reflog_base) |rb| {
            var i: usize = 0;
            var v: usize = 0;
            while (i < rb.len and std.ascii.isDigit(rb[i])) : (i += 1) v = v *% 10 +% (rb[i] - '0');
            base = v;
            if (i < rb.len) {
                const at = date.approxidate(rb);
                base = n;
                var k: usize = 0;
                while (k < n) : (k += 1) {
                    const e = entries[n - 1 - k];
                    if (identTime(e.ident).t <= at) {
                        base = k;
                        break;
                    }
                }
            }
        }
        var i: usize = 0;
        while (i < @as(usize, @intCast(reflog))) : (i += 1) {
            const idx = base + i;
            if (n == 0 and idx > 0) util.die("log for {s} is empty", .{ref});
            if (idx >= n) {
                reflog = @intCast(i);
                break;
            }
            const e = entries[n - 1 - idx];
            var logmsg = e.msg;
            if (std.mem.indexOfScalar(u8, logmsg, '\n')) |nl| logmsg = logmsg[0..nl];
            const msg = if (logmsg.len == 0) "(none)" else logmsg;
            const it = identTime(e.ident);
            reflog_msg.append(gpa, util.fmt("({s}) {s}", .{ date.showDate(it.t, it.tz, date.DateMode.of(.relative)), msg })) catch util.oom();
            appendRef(util.fmt("{s}@{{{d}}}", .{ av[0], idx }), e.new, true);
        }
    } else {
        for (av) |a| appendOneRev(a);
        if (all_heads or all_remotes) snarfRefs(all_heads, all_remotes);
    }

    const head_res = refs.resolve("HEAD");
    const head: ?[]const u8 = if (head_res) |h| h.name else null;
    const head_oid: Oid = if (head_res) |h| h.oid else hash.zero;

    if (with_current_branch and head != null) {
        var has_head = false;
        for (ref_name.items) |n| {
            if (revIsHead(head, n)) {
                has_head = true;
                break;
            }
        }
        if (!has_head) {
            var name = head.?;
            if (util.skipPrefix(name, "refs/heads/")) |x| name = x;
            appendOneRev(name);
        }
    }

    if (ref_name.items.len == 0) {
        util.eprint("No revs to be shown.\n", .{});
        return 0;
    }

    color_on = blk: {
        var cb = use_color;
        if (cb == .unknown) {
            if (cfg.getEntry("color.ui")) |e| cb = color.configColorBool("color.ui", e.value);
        }
        break :blk color.wantColorBool(cb, null);
    };

    var queue = cn.PrioQueue{ .compare = cn.compareByCommitDate };
    var seen: ?*cn.CommitList = null;
    var rev: std.ArrayList(*Commit) = .empty;
    for (ref_name.items, 0..) |rn, num_rev| {
        const flag: u32 = @as(u32, 1) << @intCast(num_rev + REV_SHIFT);
        if (MAX_REVS <= num_rev) util.die("cannot handle more than {d} revs.", .{MAX_REVS});
        const revkey = revparse.getOid(rn) orelse util.die("'{s}' is not a valid ref.", .{rn});
        const commit = cn.lookupCommitReference(revkey) orelse
            util.die("cannot find commit {s} ({s})", .{ rn, hash.hex(revkey) });
        _ = cn.parse(commit);
        _ = markSeen(commit, &seen);
        commit.obj.flags |= flag;
        if (commit.obj.flags == flag) queue.put(commit);
        rev.append(gpa, commit) catch util.oom();
    }
    const num_rev = rev.items.len;
    const rev_mask = gpa.alloc(u32, num_rev) catch util.oom();
    for (rev.items, 0..) |c, i| rev_mask[i] = c.obj.flags;

    if (0 <= extra) joinRevs(&queue, &seen, num_rev, extra);
    cn.listSortByDate(&seen);

    if (merge_base) return showMergeBase(seen, num_rev);
    if (independent) return showIndependent(rev.items, rev_mask);

    var head_at: ?usize = null;
    if (1 < num_rev or extra < 0) {
        for (0..num_rev) |i| {
            const is_head = revIsHead(head, ref_name.items[i]) and hash.eql(head_oid, rev.items[i].obj.oid);
            if (extra < 0) {
                util.outf("{c} [{s}] ", .{ @as(u8, if (is_head) '*' else ' '), ref_name.items[i] });
            } else {
                var b: util.Buf = .empty;
                for (0..i) |_| util.bufByte(&b, ' ');
                util.bufPrint(&b, "{s}{c}{s} [{s}] ", .{ getColorCode(i), @as(u8, if (is_head) '*' else '!'), getColorResetCode(), ref_name.items[i] });
                util.out(b.items);
            }
            if (reflog == 0) {
                showOneCommit(rev.items[i], true);
            } else {
                util.outf("{s}\n", .{reflog_msg.items[i]});
            }
            if (is_head) head_at = i;
        }
        if (0 <= extra) {
            var b: util.Buf = .empty;
            for (0..num_rev) |_| util.bufByte(&b, '-');
            util.bufByte(&b, '\n');
            util.out(b.items);
        }
    }
    if (extra < 0) return 0;

    cn.sortInTopologicalOrder(&seen, if (sort_order == 1) .commit_date else .graph);
    if (!sha1_name and !no_name) nameCommits(seen, rev.items, ref_name.items);

    const m = masks(num_rev);
    var shown_merge_point = false;
    var l = seen;
    while (l) |node| : (l = node.next) {
        const commit = node.item;
        const this_flag = commit.obj.flags;
        const is_merge_point = this_flag & m.all_revs == m.all_revs;
        shown_merge_point = shown_merge_point or is_merge_point;
        if (1 < num_rev) {
            const is_merge = commit.parents != null and commit.parents.?.next != null;
            if (topics and !is_merge_point and this_flag & (@as(u32, 1) << REV_SHIFT) != 0) continue;
            if (sparse == 0 and is_merge and omitInDense(commit, rev.items)) continue;
            var b: util.Buf = .empty;
            for (0..num_rev) |i| {
                var mark: u8 = undefined;
                if (this_flag & (@as(u32, 1) << @intCast(i + REV_SHIFT)) == 0)
                    mark = ' '
                else if (is_merge)
                    mark = '-'
                else if (head_at != null and i == head_at.?)
                    mark = '*'
                else
                    mark = '+';
                if (mark == ' ') util.bufByte(&b, mark) else util.bufPrint(&b, "{s}{c}{s}", .{ getColorCode(i), mark, getColorResetCode() });
            }
            util.bufByte(&b, ' ');
            util.out(b.items);
        }
        showOneCommit(commit, no_name);
        if (shown_merge_point) {
            extra -= 1;
            if (extra < 0) break;
        }
    }
    return 0;
}
