//! git add

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const dir_mod = @import("../dir.zig");
const advice = @import("../advice.zig");
const gpa = util.gpa;

const usage = [_][]const u8{"git add [<options>] [--] <pathspec>..."};

var show_only = false;
var verbose: i32 = 0;
var add_interactive = false;
var patch_interactive = false;
var auto_advance = true;
var context: i32 = -1;
var interhunk: i32 = -1;
var edit_interactive = false;
var ignored_too: i32 = 0;
var take_worktree_changes = false;
var add_renormalize = false;
var add_resolved = false;
var intent_to_add = false;
var addremove_explicit: i32 = -1;
var refresh_only = false;
var ignore_add_errors = false;
var ignore_missing = false;
var include_sparse = false;
var chmod_arg: ?[]const u8 = null;
var warn_on_embedded_repo = true;
var pathspec_from_file: ?[]const u8 = null;
var pathspec_file_nul = false;

fn allCb(_: ?[]const u8, unset: bool) void {
    addremove_explicit = if (unset) 0 else 1;
}
fn ignoreRemovalCb(_: ?[]const u8, unset: bool) void {
    addremove_explicit = if (unset) 1 else 0;
}

const options = [_]po.Opt{
    po.boolean('n', "dry-run", &show_only, "dry run"),
    .{ .short = 'v', .long = "verbose", .kind = .counter, .i = &verbose, .help = "be verbose" },
    po.group(""),
    po.boolean('i', "interactive", &add_interactive, "interactive picking"),
    po.boolean('p', "patch", &patch_interactive, "select hunks interactively"),
    po.boolean(0, "auto-advance", &auto_advance, "auto advance to the next file when selecting hunks interactively"),
    .{ .short = 'U', .long = "unified", .kind = .int, .i = &context, .argh = "n", .help = "generate diffs with <n> lines context", .noneg = true },
    .{ .long = "inter-hunk-context", .kind = .int, .i = &interhunk, .argh = "n", .help = "show context between diff hunks up to the specified number of lines", .noneg = true },
    po.boolean('e', "edit", &edit_interactive, "edit current diff and apply"),
    po.counter('f', "force", &ignored_too, "allow adding otherwise ignored files"),
    po.boolean('u', "update", &take_worktree_changes, "update tracked files"),
    po.boolean(0, "renormalize", &add_renormalize, "renormalize EOL of tracked files (implies -u)"),
    po.boolean(0, "resolved", &add_resolved, "add conflict-resolved tracked files"),
    po.boolean('N', "intent-to-add", &intent_to_add, "record only the fact that the path will be added later"),
    .{ .short = 'A', .long = "all", .kind = .callback, .cb = allCb, .noarg = true, .help = "add changes from all tracked and untracked files" },
    .{ .long = "ignore-removal", .kind = .callback, .cb = ignoreRemovalCb, .noarg = true, .help = "ignore paths removed in the working tree (same as --no-all)" },
    po.boolean(0, "refresh", &refresh_only, "don't add, only refresh the index"),
    po.boolean(0, "ignore-errors", &ignore_add_errors, "just skip files which cannot be added because of errors"),
    po.boolean(0, "ignore-missing", &ignore_missing, "check if - even missing - files are ignored in dry run"),
    po.boolean(0, "sparse", &include_sparse, "allow updating entries outside of the sparse-checkout cone"),
    po.string(0, "chmod", &chmod_arg, "(+|-)x", "override the executable bit of the listed files"),
    .{ .long = "warn-embedded-repo", .kind = .boolean, .b = &warn_on_embedded_repo, .help = "warn when adding an embedded repository", .hidden = true },
    po.filename(0, "pathspec-from-file", &pathspec_from_file, "file", "read pathspec from file"),
    po.boolean(0, "pathspec-file-nul", &pathspec_file_nul, "with --pathspec-from-file, pathspec elements are separated with NUL character"),
};

const ignore_error = "The following paths are ignored by one of your .gitignore files:\n";

const embedded_advice =
    "You've added another git repository inside your current repository.\n" ++
    "Clones of the outer repository will not contain the contents of\n" ++
    "the embedded repository and will not know how to obtain it.\n" ++
    "If you meant to add a submodule, use:\n" ++
    "\n" ++
    "\tgit submodule add <url> {s}\n" ++
    "\n" ++
    "If you added this path by mistake, you can remove it from the\n" ++
    "index with:\n" ++
    "\n" ++
    "\tgit rm --cached {s}\n" ++
    "\n" ++
    "See \"git help submodule\" for more information.";

var adviced_on_embedded_repo = false;

fn checkEmbeddedRepo(path: []const u8) void {
    if (!warn_on_embedded_repo) return;
    if (!util.endsWith(path, "/")) return;
    const name = path[0 .. path.len - 1];
    util.warn("adding embedded git repository: {s}", .{name});
    if (!adviced_on_embedded_repo) {
        advice.adviseIfEnabled("addEmbeddedRepo", util.fmt(embedded_advice, .{ name, name }));
        adviced_on_embedded_repo = true;
    }
}

fn addFiles(idx: *index_mod.Index, dir: *dir_mod.Dir, flags: u32) u8 {
    var exit_status: u8 = 0;
    if (dir.ignored.items.len > 0) {
        util.ewrite(ignore_error);
        for (dir.ignored.items) |e| util.eprint("{s}\n", .{e.name});
        advice.adviseIfEnabled("addIgnoredFile", "Use -f if you really want to add them.");
        exit_status = 1;
    }
    for (dir.entries.items) |e| {
        if (index_mod.addFileToIndex(idx, e.name, flags)) {
            if (!ignore_add_errors) util.die("adding files failed", .{});
            exit_status = 1;
        } else checkEmbeddedRepo(e.name);
    }
    return exit_status;
}

fn addResolvedFiles(idx: *index_mod.Index, ps: *const pathspec_mod.Pathspec, flags: u32) u8 {
    var unmerged: std.ArrayList([]const u8) = .empty;
    for (idx.entries.items) |*e| {
        if (e.stage() == 0) continue;
        if (ps.items.len > 0 and !ps.matches(e.path, e.mode == 0o160000)) continue;
        if (unmerged.items.len == 0 or !util.eql(unmerged.items[unmerged.items.len - 1], e.path))
            unmerged.append(gpa, e.path) catch util.oom();
    }
    if (unmerged.items.len == 0) return 0;
    var b: util.Buf = .empty;
    for (unmerged.items) |p| {
        if (os.lstatPath(p)) |st| {
            if (st.isReg() and index_mod.hasConflictMarkers(p)) util.bufPrint(&b, "\t{s}\n", .{p});
        }
    }
    if (b.items.len > 0) util.die("the following paths still have conflict markers:\n{s}", .{b.items});
    var exit_status: u8 = 0;
    for (unmerged.items) |p| {
        if (os.lstatPath(p) == null) {
            index_mod.removeFileWithFlags(idx, p, flags);
        } else if (index_mod.addFileToIndex(idx, p, flags)) {
            if (flags & index_mod.ADD_IGNORE_ERRORS == 0) util.die("updating file '{s}' failed", .{p});
            exit_status = 1;
        }
    }
    return exit_status;
}

fn renormalizeTracked(idx: *index_mod.Index, ps: *const pathspec_mod.Pathspec, flags: u32) u8 {
    var paths: std.ArrayList([]const u8) = .empty;
    for (idx.entries.items) |*e| {
        if (!include_sparse and e.skipWorktree()) continue;
        if (e.stage() != 0) continue;
        const t = e.mode & 0o170000;
        if (t != 0o100000 and t != 0o120000) continue;
        if (ps.items.len > 0 and !ps.matches(e.path, false)) continue;
        paths.append(gpa, e.path) catch util.oom();
    }
    var ret: u8 = 0;
    for (paths.items) |p| {
        if (index_mod.addFileToIndex(idx, p, flags | index_mod.ADD_RENORMALIZE)) ret = 1;
    }
    return ret;
}

fn refresh(idx: *index_mod.Index, ps: *const pathspec_mod.Pathspec) u8 {
    const flags: u32 = index_mod.REFRESH_IGNORE_SKIP_WORKTREE |
        (if (verbose != 0) index_mod.REFRESH_IN_PORCELAIN else index_mod.REFRESH_QUIET);
    const seen = ps.newSeen();
    ps.matchAgainstIndex(idx, seen, true);
    _ = index_mod.refresh(idx, flags, @as(?*const pathspec_mod.Pathspec, ps), "Unstaged changes after refreshing the index:");
    for (ps.items, 0..) |it, i| {
        if (seen[i] == 0) util.die("pathspec '{s}' did not match any files", .{it.original});
    }
    return 0;
}

fn chmodPathspec(idx: *index_mod.Index, ps: *const pathspec_mod.Pathspec, flip: u8) u8 {
    var ret: u8 = 0;
    for (idx.entries.items) |*e| {
        if (!include_sparse and e.skipWorktree()) continue;
        if (!ps.matches(e.path, e.mode == 0o160000)) continue;
        const ok = if (!show_only) index_mod.chmodEntry(idx, e, flip) else e.mode & 0o170000 == 0o100000;
        if (!ok) {
            util.err("cannot chmod {c}x '{s}'", .{ flip, e.path });
            ret = 1;
        }
    }
    return ret;
}

pub fn cmdAdd(args: []const []const u8) u8 {
    if (repo_mod.cfg.getBool("add.ignoreerrors") orelse repo_mod.cfg.getBool("add.ignore-errors")) |v| ignore_add_errors = v;
    const rest = po.parse(args[1..], &options, &usage, .{});
    const r = repo_mod.repo();
    if (context < -1) util.die("'{s}' cannot be negative", .{"--unified"});
    if (interhunk < -1) util.die("'{s}' cannot be negative", .{"--inter-hunk-context"});
    if (patch_interactive) add_interactive = true;
    if (add_interactive) {
        if (show_only) util.die("options '{s}' and '{s}' cannot be used together", .{ "--dry-run", "--interactive/--patch" });
        if (pathspec_from_file != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "--interactive/--patch" });
        util.die("interactive add is not supported", .{});
    } else {
        if (context != -1) util.die("the option '{s}' requires '{s}'", .{ "--unified", "--interactive/--patch" });
        if (interhunk != -1) util.die("the option '{s}' requires '{s}'", .{ "--inter-hunk-context", "--interactive/--patch" });
        if (!auto_advance) util.die("the option '{s}' requires '{s}'", .{ "--no-auto-advance", "--interactive/--patch" });
    }
    if (edit_interactive) {
        if (pathspec_from_file != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "--edit" });
        util.die("editing patch failed", .{});
    }
    var addremove = true;
    if (addremove_explicit >= 0) {
        addremove = addremove_explicit != 0;
    } else if (take_worktree_changes) addremove = false;

    {
        var n: usize = 0;
        var names: [3][]const u8 = undefined;
        if (take_worktree_changes) {
            names[n] = "-u/--update";
            n += 1;
        }
        if (addremove_explicit > 0) {
            names[n] = "-A/--all";
            n += 1;
        }
        if (add_resolved) {
            names[n] = "--resolved";
            n += 1;
        }
        if (n == 3) util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ names[0], names[1], names[2] });
        if (n == 2) util.die("options '{s}' and '{s}' cannot be used together", .{ names[0], names[1] });
    }
    if (!show_only and ignore_missing) util.die("the option '{s}' requires '{s}'", .{ "--ignore-missing", "--dry-run" });
    if (chmod_arg) |c| {
        if (c.len != 2 or (c[0] != '-' and c[0] != '+') or c[1] != 'x')
            util.die("--chmod param '{s}' must be either -x or +x", .{c});
    }
    const add_new_files = !take_worktree_changes and !refresh_only and !add_renormalize and !add_resolved;
    const require_pathspec = !(take_worktree_changes or addremove_explicit > 0 or add_resolved);

    const idx = index_mod.lockAndRead();
    const ps_flags = pathspec_mod.Flags{ .prefer_full = true, .symlink_leading_path = true };
    var ps = pathspec_mod.parse(r.prefix, rest, ps_flags);
    if (pathspec_from_file) |pf| {
        if (ps.items.len > 0) util.die("'{s}' and pathspec arguments cannot be used together", .{"--pathspec-from-file"});
        ps = pathspec_mod.parse(r.prefix, pathspec_mod.readPathspecFile(pf, pathspec_file_nul), ps_flags);
    } else if (pathspec_file_nul) {
        util.die("the option '{s}' requires '{s}'", .{ "--pathspec-file-nul", "--pathspec-from-file" });
    }
    if (require_pathspec and ps.items.len == 0) {
        util.ewrite("Nothing specified, nothing added.\n");
        advice.adviseIfEnabled("addEmptyPathspec", "Maybe you wanted to say 'git add .'?");
        idx.rollback();
        return 0;
    }
    if (!take_worktree_changes and !add_resolved and addremove_explicit < 0 and ps.items.len > 0) addremove = true;

    var flags: u32 = 0;
    if (verbose != 0) flags |= index_mod.ADD_VERBOSE;
    if (show_only) flags |= index_mod.ADD_PRETEND;
    if (intent_to_add) flags |= index_mod.ADD_INTENT;
    if (ignore_add_errors) flags |= index_mod.ADD_IGNORE_ERRORS;
    if (!(addremove or take_worktree_changes)) flags |= index_mod.ADD_IGNORE_REMOVAL;

    // die_path_inside_submodule()
    for (ps.items) |it| {
        for (idx.entries.items) |*e| {
            if (e.mode != 0o160000) continue;
            if (it.match.len > e.path.len and util.startsWith(it.match, e.path) and it.match[e.path.len] == '/') {
                if (it.match.len == e.path.len + 1) continue;
                util.die("Pathspec '{s}' is in submodule '{s}'", .{ it.original, e.path });
            }
        }
    }

    var exit_status: u8 = 0;
    var dir = dir_mod.Dir.init();
    var seen: ?[]u8 = null;
    if (add_new_files) {
        if (ignored_too == 0) {
            dir.flags.collect_ignored = true;
            dir.setupStandardExcludes();
        }
        const baselen = dir.fill(idx, &ps);
        if (ps.items.len > 0) {
            // prune_directory()
            const s = ps.newSeen();
            var kept: std.ArrayList(dir_mod.Entry) = .empty;
            for (dir.entries.items) |e| {
                const is_dir = e.name.len > 0 and e.name[e.name.len - 1] == '/';
                if (ps.matchFlags(e.name, baselen, s, if (is_dir) pathspec_mod.DO_MATCH_DIRECTORY else 0) != 0)
                    kept.append(gpa, e) catch util.oom();
            }
            dir.entries = kept;
            ps.matchAgainstIndex(idx, s, true);
            seen = s;
        }
    }
    if (refresh_only) {
        exit_status |= refresh(idx, &ps);
        finish(idx);
        return exit_status;
    }
    if (ps.items.len > 0) {
        const s = seen orelse blk: {
            const x = ps.newSeen();
            ps.matchAgainstIndex(idx, x, true);
            break :blk x;
        };
        for (ps.items, 0..) |it, i| {
            if (it.magic & pathspec_mod.MAGIC_EXCLUDE != 0) continue;
            if (s[i] != 0) continue;
            if (it.match.len == 0) continue;
            if (it.magic & (pathspec_mod.MAGIC_GLOB | pathspec_mod.MAGIC_ICASE) != 0 or !dir_mod.fileExists(it.match)) {
                if (ignore_missing) {
                    var dtype: u8 = dir_mod.DT_UNKNOWN;
                    if (dir.isExcluded(it.match, &dtype)) {
                        if (dir_mod.indexNameIsOther(idx, it.match))
                            dir.ignored.append(gpa, .{ .name = util.dupe(it.match) }) catch util.oom();
                    }
                } else util.die("pathspec '{s}' did not match any files", .{it.original});
            }
        }
    }
    const ps_matched = ps.newSeen();
    if (add_resolved) {
        exit_status |= addResolvedFiles(idx, &ps, flags);
    } else if (add_renormalize) {
        exit_status |= renormalizeTracked(idx, &ps, flags);
    } else {
        const pp: ?*const pathspec_mod.Pathspec = if (ps.items.len > 0) &ps else null;
        if (index_mod.addFilesToCache(idx, pp, ps_matched, flags)) exit_status |= 1;
    }
    if (take_worktree_changes and !add_renormalize and !ignore_add_errors and ps.reportPathError(ps_matched) > 0) os.exit(128);
    if (add_new_files) exit_status |= addFiles(idx, &dir, flags);
    if (chmod_arg) |c| {
        if (ps.items.len > 0) exit_status |= chmodPathspec(idx, &ps, c[0]);
    }
    finish(idx);
    return exit_status;
}

fn finish(idx: *index_mod.Index) void {
    if (idx.changed) idx.write() else idx.rollback();
}
