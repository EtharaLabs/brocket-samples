//! git prune-packed (builtin/prune-packed.c)

const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const prunepacked = @import("../prunepacked.zig");

const usage = [_][]const u8{"git prune-packed [-n | --dry-run] [-q | --quiet]"};
const DRY_RUN: i32 = 1;
const VERBOSE: i32 = 2;

pub fn cmdPrunePacked(args: []const []const u8) u8 {
    var opts: i32 = if (os.isatty(2)) VERBOSE else 0;
    const options = [_]po.Opt{
        po.bit('n', "dry-run", &opts, DRY_RUN, "dry run"),
        .{ .short = 'q', .long = "quiet", .kind = .negbit, .i = &opts, .val = VERBOSE, .help = "be quiet" },
    };
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len > 0) {
        util.eprint("fatal: too many arguments\n\n", .{});
        po.usageWithOptions(&usage, &options);
    }
    prunepacked.prunePacked(opts & DRY_RUN != 0, opts & VERBOSE == 0);
    return 0;
}
