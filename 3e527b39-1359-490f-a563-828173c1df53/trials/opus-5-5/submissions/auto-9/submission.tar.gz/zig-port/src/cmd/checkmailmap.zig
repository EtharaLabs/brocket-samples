//! git check-mailmap (builtin/check-mailmap.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const mailmap = @import("../mailmap.zig");
const gpa = util.gpa;

const usage = [_][]const u8{"git check-mailmap [<options>] <contact>..."};

var use_stdin = false;
var mailmap_file: ?[]const u8 = null;
var mailmap_blob: ?[]const u8 = null;

const options = [_]po.Opt{
    po.boolean(0, "stdin", &use_stdin, "also read contacts from stdin"),
    po.filename(0, "mailmap-file", &mailmap_file, "file", "read additional mailmap entries from file"),
    po.string(0, "mailmap-blob", &mailmap_blob, "blob", "read additional mailmap entries from blob"),
};

fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r' or ch == 0x0b or ch == 0x0c;
}

const NameMail = struct { name: []const u8, mail: []const u8 };

/// The name/mail part of split_ident_line().
fn splitIdent(line: []const u8) ?NameMail {
    const lt = std.mem.indexOfScalar(u8, line, '<') orelse return null;
    var name_end: usize = 0;
    var cp: usize = lt;
    while (cp > 0) {
        cp -= 1;
        if (!isSpace(line[cp])) {
            name_end = cp + 1;
            break;
        }
    }
    const gt = std.mem.indexOfScalarPos(u8, line, lt + 1, '>') orelse return null;
    return .{ .name = line[0..name_end], .mail = line[lt + 1 .. gt] };
}

fn checkMailmap(m: *mailmap.Map, contact: []const u8) void {
    var name: []const u8 = "";
    var mail: []const u8 = contact;
    if (splitIdent(contact)) |s| {
        name = s.name;
        mail = s.mail;
    }
    if (m.mapUser(name, mail)) |r| {
        name = r.name;
        mail = r.email;
    }
    if (name.len > 0) util.outf("{s} ", .{name});
    util.outf("<{s}>\n", .{mail});
}

pub fn cmdCheckMailmap(args: []const []const u8) u8 {
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len == 0 and !use_stdin) util.die("no contacts specified", .{});
    const m = mailmap.newMap();
    mailmap.readMailmapInto(m);
    if (mailmap_blob) |b| m.readBlob(b);
    if (mailmap_file) |f| m.readFile(f, false);
    for (rest) |c| checkMailmap(m, c);
    util.flushStdout();
    if (use_stdin) {
        // read and answer line by line so that interactive use works
        var line: util.Buf = .empty;
        var buf: [1]u8 = undefined;
        while (true) {
            const n = std.c.read(0, &buf, 1);
            if (n <= 0) {
                if (n < 0 and os.errno() == os.EINTR) continue;
                if (line.items.len > 0) {
                    checkMailmap(m, line.items);
                    util.flushStdout();
                }
                break;
            }
            if (buf[0] == '\n') {
                checkMailmap(m, line.items);
                util.flushStdout();
                line.clearRetainingCapacity();
            } else util.bufByte(&line, buf[0]);
        }
    }
    return 0;
}
