//! Date parsing and formatting: a port of git's date.c (plus strbuf_addftime).
//!
//! Conventions:
//!  * Timestamps are i64 in the API. git uses an unsigned `timestamp_t`; where the
//!    difference is observable (printing, comparisons) the value is treated as u64,
//!    exactly like git does.
//!  * `Parsed.tz` (from parseDate / parseDateBasic) and parseTzOffset/formatTz use
//!    *minutes east of UTC* (e.g. -420 for -0700), matching git's parse_date_basic offset.
//!  * showDate() and localTzOffset() use git's "decimal HHMM" integer form
//!    (e.g. -700 for -0700, 530 for +0530), matching git's show_date().
//!    Use tzMinutesToHhmm()/tzHhmmToMinutes() to convert.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");

const Tm = os.Tm;
const Buf = util.Buf;

extern "c" fn localtime_r(t: *const i64, tm: *Tm) ?*Tm;
extern "c" fn gmtime_r(t: *const i64, tm: *Tm) ?*Tm;
extern "c" fn mktime(tm: *Tm) i64;
extern "c" fn time(t: ?*i64) i64;
extern "c" fn gettimeofday(tv: *[2]i64, tz: ?*anyopaque) c_int;
extern "c" fn strftime(s: [*]u8, max: usize, format: [*:0]const u8, tm: *const Tm) usize;

pub const Parsed = struct { time: i64, tz: i32 };

pub const Mode = enum { normal, human, relative, short, iso8601, iso8601_strict, rfc2822, strftime, raw, unix };

pub const DateMode = struct {
    mode: Mode = .normal,
    local: bool = false,
    strftime_fmt: ?[]const u8 = null,

    pub fn of(m: Mode) DateMode {
        return .{ .mode = m };
    }
};

// ---------------------------------------------------------------------------
// small C-like helpers

fn at(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}
fn isDigit(c: u8) bool {
    return c >= '0' and c <= '9';
}
fn isAlpha(c: u8) bool {
    return std.ascii.isAlphabetic(c);
}
fn isAlnum(c: u8) bool {
    return std.ascii.isAlphanumeric(c);
}
fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == 0x0b or c == 0x0c or c == '\r';
}

const UlRes = struct { val: u64, end: usize };
const LRes = struct { val: i64, end: usize };

/// strtoul/strtoumax (base 10) starting at s[start].
fn cStrtoul(s: []const u8, start: usize) UlRes {
    var i = start;
    while (isSpace(at(s, i))) i += 1;
    var neg = false;
    if (at(s, i) == '+' or at(s, i) == '-') {
        neg = at(s, i) == '-';
        i += 1;
    }
    if (!isDigit(at(s, i))) return .{ .val = 0, .end = start };
    var v: u64 = 0;
    var ovf = false;
    while (isDigit(at(s, i))) : (i += 1) {
        const m = @mulWithOverflow(v, 10);
        const a = @addWithOverflow(m[0], at(s, i) - '0');
        if (m[1] != 0 or a[1] != 0) ovf = true;
        v = a[0];
    }
    if (ovf) return .{ .val = std.math.maxInt(u64), .end = i };
    return .{ .val = if (neg) 0 -% v else v, .end = i };
}

/// strtol (base 10, 64-bit long) starting at s[start].
fn cStrtol(s: []const u8, start: usize) LRes {
    var i = start;
    while (isSpace(at(s, i))) i += 1;
    var neg = false;
    if (at(s, i) == '+' or at(s, i) == '-') {
        neg = at(s, i) == '-';
        i += 1;
    }
    if (!isDigit(at(s, i))) return .{ .val = 0, .end = start };
    var v: u64 = 0;
    var ovf = false;
    while (isDigit(at(s, i))) : (i += 1) {
        const m = @mulWithOverflow(v, 10);
        const a = @addWithOverflow(m[0], at(s, i) - '0');
        if (m[1] != 0 or a[1] != 0) ovf = true;
        v = a[0];
    }
    const lim: u64 = if (neg) @as(u64, 1) << 63 else std.math.maxInt(i64);
    if (ovf or v > lim) return .{ .val = if (neg) std.math.minInt(i64) else std.math.maxInt(i64), .end = i };
    const r: i64 = if (neg) @bitCast(0 -% v) else @intCast(v);
    return .{ .val = r, .end = i };
}

fn atoi(s: []const u8) i32 {
    const r = cStrtol(s, 0);
    return @truncate(r.val);
}


/// Append an integer printf-style: width, zero padding, forced '+' sign.
fn addInt(b: *Buf, v: i64, width: usize, zero: bool, plus: bool) void {
    var digits: [24]u8 = undefined;
    const neg = v < 0;
    var mag: u64 = if (neg) @bitCast(0 -% v) else @intCast(v);
    var n: usize = 0;
    while (true) {
        digits[n] = @intCast('0' + mag % 10);
        n += 1;
        mag /= 10;
        if (mag == 0) break;
    }
    const sign: ?u8 = if (neg) '-' else if (plus) '+' else null;
    const total = n + @intFromBool(sign != null);
    const pad = if (width > total) width - total else 0;
    if (!zero) {
        var k: usize = 0;
        while (k < pad) : (k += 1) util.bufByte(b, ' ');
    }
    if (sign) |c| util.bufByte(b, c);
    if (zero) {
        var k: usize = 0;
        while (k < pad) : (k += 1) util.bufByte(b, '0');
    }
    while (n > 0) {
        n -= 1;
        util.bufByte(b, digits[n]);
    }
}

fn addU(b: *Buf, v: u64) void {
    util.bufPrint(b, "{d}", .{v});
}

fn u(t: i64) u64 {
    return @bitCast(t);
}

// ---------------------------------------------------------------------------
// public tz helpers (kept for existing callers)

/// tz in minutes east of UTC from "+hhmm"/"-hhmm"
pub fn parseTzOffset(s: []const u8) ?i32 {
    if (s.len != 5 or (s[0] != '+' and s[0] != '-')) return null;
    for (s[1..]) |ch| if (!isDigit(ch)) return null;
    const n = std.fmt.parseInt(i32, s[1..], 10) catch return null;
    const m = @divTrunc(n, 100) * 60 + @mod(n, 100);
    return if (s[0] == '-') -m else m;
}

/// "+hhmm"/"-hhmm" from minutes east of UTC (git's date_string formatting).
pub fn formatTz(tz: i32) []const u8 {
    const sign: u8 = if (tz < 0) '-' else '+';
    const a: u32 = @intCast(if (tz < 0) -tz else tz);
    return util.fmt("{c}{d:0>2}{d:0>2}", .{ sign, a / 60, a % 60 });
}

/// Minutes east (e.g. -420) -> git HHMM int (e.g. -700).
pub fn tzMinutesToHhmm(m: i32) i32 {
    const a = if (m < 0) -m else m;
    const v = @divTrunc(a, 60) * 100 + @rem(a, 60);
    return if (m < 0) -v else v;
}

/// git HHMM int (e.g. -700) -> minutes east (e.g. -420).
pub fn tzHhmmToMinutes(tz: i32) i32 {
    const a = if (tz < 0) -tz else tz;
    const v = @divTrunc(a, 100) * 60 + @rem(a, 100);
    return if (tz < 0) -v else v;
}

/// Local tz offset in minutes east at time t (uses tm_gmtoff).
pub fn localTz(t: i64) i32 {
    const tm = os.localtime(t);
    return @intCast(@divTrunc(tm.gmtoff, 60));
}

/// git's datestamp(): "<now> +hhmm" using the local timezone.
pub fn nowString() []const u8 {
    return datestamp();
}

// ---------------------------------------------------------------------------
// core helpers

/// Like mktime, but without normalization of tm_wday and tm_yday.
pub fn tmToTimeT(tm: *const Tm) i64 {
    const mdays = [_]i64{ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
    const year: i64 = @as(i64, tm.year) - 70;
    const month: i64 = tm.mon;
    var day: i64 = tm.mday;
    if (year < 0 or year > 129) return -1;
    if (month < 0 or month > 11) return -1;
    if (month < 2 or @rem(year + 2, 4) != 0) day -= 1;
    if (tm.hour < 0 or tm.min < 0 or tm.sec < 0) return -1;
    return (year * 365 + @divTrunc(year + 1, 4) + mdays[@intCast(month)] + day) *% (24 * 60 * 60) +%
        @as(i64, tm.hour) * 3600 + @as(i64, tm.min) * 60 + @as(i64, tm.sec);
}

const month_names = [_][]const u8{
    "January", "February", "March",     "April",   "May",      "June",
    "July",    "August",   "September", "October", "November", "December",
};

const weekday_names = [_][]const u8{
    "Sundays", "Mondays", "Tuesdays", "Wednesdays", "Thursdays", "Fridays", "Saturdays",
};

/// git's date_overflows()
pub fn dateOverflows(t: i64) bool {
    // (uintmax_t)t >= TIME_MAX, or does not fit a signed time_t
    return t < 0;
}

fn tzFmt04(b: *Buf, tz: i32) void {
    addInt(b, tz, 4, true, false);
}

fn gmTimeT(t: i64, tz: i32) i64 {
    var minutes: i32 = if (tz < 0) -tz else tz;
    minutes = @divTrunc(minutes, 100) * 60 + @rem(minutes, 100);
    minutes = if (tz < 0) -minutes else minutes;
    const delta: i64 = @as(i64, minutes) * 60;
    if (minutes > 0) {
        if (@addWithOverflow(u(t), @as(u64, @intCast(delta)))[1] != 0) {
            var b: Buf = .empty;
            tzFmt04(&b, tz);
            util.die("Timestamp+tz too large: {d} +{s}", .{ u(t), b.items });
        }
    } else if (u(t) < @as(u64, @intCast(-delta))) {
        var b: Buf = .empty;
        tzFmt04(&b, tz);
        util.die("Timestamp before Unix epoch: {d} {s}", .{ u(t), b.items });
    }
    const r = t +% delta;
    if (dateOverflows(r)) util.die("Timestamp too large for this system: {d}", .{u(r)});
    return r;
}

fn timeToTm(t: i64, tz: i32, tm: *Tm) bool {
    const g = gmTimeT(t, tz);
    return gmtime_r(&g, tm) != null;
}

fn timeToTmLocal(t: i64, tm: *Tm) bool {
    return localtime_r(&t, tm) != null;
}

/// Fill in the localtime tm for t and return the local tz (HHMM form).
fn localTimeTzoffset(t: i64, tm: *Tm) i32 {
    _ = localtime_r(&t, tm);
    const t_local = tmToTimeT(tm);
    if (t_local == -1) return 0;
    var eastwest: i32 = undefined;
    var offset: i32 = undefined;
    if (t_local < t) {
        eastwest = -1;
        offset = @truncate(t - t_local);
    } else {
        eastwest = 1;
        offset = @truncate(t_local - t);
    }
    offset = @divTrunc(offset, 60);
    offset = @rem(offset, 60) + @divTrunc(offset, 60) * 100;
    return offset * eastwest;
}

/// git's local_tzoffset(): local tz at `t`, in HHMM integer form (e.g. -700).
pub fn localTzOffset(t: i64) i32 {
    if (dateOverflows(t)) util.die("Timestamp too large for this system: {d}", .{u(t)});
    var tm: Tm = std.mem.zeroes(Tm);
    return localTimeTzoffset(t, &tm);
}

/// Current time, honoring GIT_TEST_DATE_NOW (git's get_time()).
pub fn getTime() i64 {
    if (os.getenv("GIT_TEST_DATE_NOW")) |x| return atoi(x);
    var tv: [2]i64 = undefined;
    _ = gettimeofday(&tv, null);
    return tv[0];
}

fn plural(b: *Buf, n: u64, sing: []const u8, plur: []const u8) void {
    addU(b, n);
    util.bufAppend(b, if (n == 1) sing else plur);
}

fn showDateRelativeInto(t: i64, b: *Buf) void {
    const now = getTime();
    if (u(now) < u(t)) {
        util.bufAppend(b, "in the future");
        return;
    }
    var diff: u64 = u(now) -% u(t);
    if (diff < 90) return plural(b, diff, " second ago", " seconds ago");
    diff = (diff + 30) / 60;
    if (diff < 90) return plural(b, diff, " minute ago", " minutes ago");
    diff = (diff + 30) / 60;
    if (diff < 36) return plural(b, diff, " hour ago", " hours ago");
    diff = (diff + 12) / 24;
    if (diff < 14) return plural(b, diff, " day ago", " days ago");
    if (diff < 70) return plural(b, (diff + 3) / 7, " week ago", " weeks ago");
    if (diff < 365) return plural(b, (diff + 15) / 30, " month ago", " months ago");
    if (diff < 1825) {
        const totalmonths = (diff * 12 * 2 + 365) / (365 * 2);
        const years = totalmonths / 12;
        const months = totalmonths % 12;
        if (months != 0) {
            plural(b, years, " year", " years");
            util.bufAppend(b, ", ");
            plural(b, months, " month ago", " months ago");
        } else plural(b, years, " year ago", " years ago");
        return;
    }
    plural(b, (diff + 183) / 365, " year ago", " years ago");
}

/// git's show_date_relative()
pub fn showDateRelative(t: i64) []const u8 {
    var b: Buf = .empty;
    showDateRelativeInto(t, &b);
    return b.items;
}

fn rtrim(b: *Buf) void {
    while (b.items.len > 0 and isSpace(b.items[b.items.len - 1])) b.items.len -= 1;
}

fn showDateNormal(b: *Buf, t: i64, tm: *const Tm, tz: i32, human_tm: *const Tm, human_tz: i32, local: bool) void {
    var hide_year = false;
    var hide_date = false;
    var hide_wday = false;
    var hide_time = false;
    var hide_seconds = false;
    var hide_tz = local or tz == human_tz;
    hide_year = tm.year == human_tm.year;
    if (hide_year) {
        if (tm.mon == human_tm.mon) {
            if (tm.mday > human_tm.mday) {
                // future date: think timezones
            } else if (tm.mday == human_tm.mday) {
                hide_date = true;
                hide_wday = true;
            } else if (tm.mday + 5 > human_tm.mday) {
                hide_date = true;
            }
        }
    }
    if (hide_wday) {
        showDateRelativeInto(t, b);
        return;
    }
    if (human_tm.year != 0) {
        hide_seconds = true;
        hide_tz = hide_tz or !hide_date;
        hide_wday = !hide_year;
        hide_time = !hide_year;
    }
    if (!hide_wday) {
        util.bufAppend(b, weekday_names[@intCast(tm.wday)][0..3]);
        util.bufByte(b, ' ');
    }
    if (!hide_date) {
        util.bufAppend(b, month_names[@intCast(tm.mon)][0..3]);
        util.bufByte(b, ' ');
        addInt(b, tm.mday, 0, false, false);
        util.bufByte(b, ' ');
    }
    if (!hide_time) {
        addInt(b, tm.hour, 2, true, false);
        util.bufByte(b, ':');
        addInt(b, tm.min, 2, true, false);
        if (!hide_seconds) {
            util.bufByte(b, ':');
            addInt(b, tm.sec, 2, true, false);
        }
    } else rtrim(b);
    if (!hide_year) {
        util.bufByte(b, ' ');
        addInt(b, @as(i64, tm.year) + 1900, 0, false, false);
    }
    if (!hide_tz) {
        util.bufByte(b, ' ');
        addInt(b, tz, 5, true, true);
    }
}

/// Port of strbuf_addftime(): strftime with git's handling of %z, %Z and %s.
/// tz_offset is in HHMM integer form.
pub fn addFtime(b: *Buf, fmt_in: []const u8, tm: *const Tm, tz_offset: i32, suppress_tz_name: bool) void {
    if (fmt_in.len == 0) return;
    var m: Buf = .empty;
    var i: usize = 0;
    while (i < fmt_in.len) {
        const c = fmt_in[i];
        if (c != '%') {
            util.bufByte(&m, c);
            i += 1;
            continue;
        }
        i += 1;
        const n = at(fmt_in, i);
        if (n == '%') {
            util.bufAppend(&m, "%%");
            i += 1;
        } else if (n == 's') {
            const v: i64 = tmToTimeT(tm) -% 3600 * @as(i64, @divTrunc(tz_offset, 100)) -% 60 * @as(i64, @rem(tz_offset, 100));
            addU(&m, u(v));
            i += 1;
        } else if (n == 'z') {
            addInt(&m, tz_offset, 5, true, true);
            i += 1;
        } else if (suppress_tz_name and n == 'Z') {
            i += 1;
        } else {
            util.bufByte(&m, '%');
        }
    }
    // Append a space so the output is never empty; drop it afterwards.
    util.bufAppend(&m, " ");
    util.bufByte(&m, 0);
    const fmtz: [*:0]const u8 = @ptrCast(m.items.ptr);
    var hint: usize = 256;
    while (true) {
        const buf = util.gpa.alloc(u8, hint) catch util.oom();
        const len = strftime(buf.ptr, hint, fmtz, tm);
        if (len != 0) {
            util.bufAppend(b, buf[0 .. len - 1]);
            util.gpa.free(buf);
            return;
        }
        util.gpa.free(buf);
        hint *= 2;
        if (hint > 1 << 24) return;
    }
}

/// git's show_date(). `tz` is in git's HHMM integer form (e.g. -700 for -0700).
pub fn showDate(t: i64, tz_in: i32, mode: DateMode) []const u8 {
    var tz = tz_in;
    var b: Buf = .empty;
    if (mode.mode == .unix) {
        addU(&b, u(t));
        return b.items;
    }
    var human_tm: Tm = std.mem.zeroes(Tm);
    var human_tz: i32 = -1;
    if (mode.mode == .human) {
        const now = getTime();
        human_tz = localTimeTzoffset(now, &human_tm);
    }
    if (mode.local) tz = localTzOffset(t);
    if (mode.mode == .raw) {
        addU(&b, u(t));
        util.bufByte(&b, ' ');
        addInt(&b, tz, 5, true, true);
        return b.items;
    }
    if (mode.mode == .relative) {
        showDateRelativeInto(t, &b);
        return b.items;
    }
    var tm: Tm = std.mem.zeroes(Tm);
    const ok = if (mode.local) timeToTmLocal(t, &tm) else timeToTm(t, tz, &tm);
    if (!ok) {
        _ = timeToTm(0, 0, &tm);
        tz = 0;
    }
    const year: i64 = @as(i64, tm.year) + 1900;
    switch (mode.mode) {
        .short => {
            addInt(&b, year, 4, true, false);
            util.bufByte(&b, '-');
            addInt(&b, tm.mon + 1, 2, true, false);
            util.bufByte(&b, '-');
            addInt(&b, tm.mday, 2, true, false);
        },
        .iso8601, .iso8601_strict => {
            addInt(&b, year, 4, true, false);
            util.bufByte(&b, '-');
            addInt(&b, tm.mon + 1, 2, true, false);
            util.bufByte(&b, '-');
            addInt(&b, tm.mday, 2, true, false);
            util.bufByte(&b, if (mode.mode == .iso8601) ' ' else 'T');
            addInt(&b, tm.hour, 2, true, false);
            util.bufByte(&b, ':');
            addInt(&b, tm.min, 2, true, false);
            util.bufByte(&b, ':');
            addInt(&b, tm.sec, 2, true, false);
            if (mode.mode == .iso8601) {
                util.bufByte(&b, ' ');
                addInt(&b, tz, 5, true, true);
            } else if (tz == 0) {
                util.bufByte(&b, 'Z');
            } else {
                util.bufByte(&b, if (tz >= 0) '+' else '-');
                const a: i32 = if (tz < 0) -tz else tz;
                addInt(&b, @divTrunc(a, 100), 2, true, false);
                util.bufByte(&b, ':');
                addInt(&b, @rem(a, 100), 2, true, false);
            }
        },
        .rfc2822 => {
            util.bufAppend(&b, weekday_names[@intCast(tm.wday)][0..3]);
            util.bufAppend(&b, ", ");
            addInt(&b, tm.mday, 0, false, false);
            util.bufByte(&b, ' ');
            util.bufAppend(&b, month_names[@intCast(tm.mon)][0..3]);
            util.bufByte(&b, ' ');
            addInt(&b, year, 0, false, false);
            util.bufByte(&b, ' ');
            addInt(&b, tm.hour, 2, true, false);
            util.bufByte(&b, ':');
            addInt(&b, tm.min, 2, true, false);
            util.bufByte(&b, ':');
            addInt(&b, tm.sec, 2, true, false);
            util.bufByte(&b, ' ');
            addInt(&b, tz, 5, true, true);
        },
        .strftime => addFtime(&b, mode.strftime_fmt orelse "", &tm, tz, !mode.local),
        else => showDateNormal(&b, t, &tm, tz, &human_tm, human_tz, mode.local),
    }
    return b.items;
}

// ---------------------------------------------------------------------------
// parsing

const TzName = struct { name: []const u8, offset: i32, dst: i32 };
const timezone_names = [_]TzName{
    .{ .name = "IDLW", .offset = -12, .dst = 0 },
    .{ .name = "NT", .offset = -11, .dst = 0 },
    .{ .name = "CAT", .offset = -10, .dst = 0 },
    .{ .name = "HST", .offset = -10, .dst = 0 },
    .{ .name = "HDT", .offset = -10, .dst = 1 },
    .{ .name = "YST", .offset = -9, .dst = 0 },
    .{ .name = "YDT", .offset = -9, .dst = 1 },
    .{ .name = "PST", .offset = -8, .dst = 0 },
    .{ .name = "PDT", .offset = -8, .dst = 1 },
    .{ .name = "MST", .offset = -7, .dst = 0 },
    .{ .name = "MDT", .offset = -7, .dst = 1 },
    .{ .name = "CST", .offset = -6, .dst = 0 },
    .{ .name = "CDT", .offset = -6, .dst = 1 },
    .{ .name = "EST", .offset = -5, .dst = 0 },
    .{ .name = "EDT", .offset = -5, .dst = 1 },
    .{ .name = "AST", .offset = -3, .dst = 0 },
    .{ .name = "ADT", .offset = -3, .dst = 1 },
    .{ .name = "WAT", .offset = -1, .dst = 0 },
    .{ .name = "GMT", .offset = 0, .dst = 0 },
    .{ .name = "UTC", .offset = 0, .dst = 0 },
    .{ .name = "Z", .offset = 0, .dst = 0 },
    .{ .name = "WET", .offset = 0, .dst = 0 },
    .{ .name = "BST", .offset = 0, .dst = 1 },
    .{ .name = "CET", .offset = 1, .dst = 0 },
    .{ .name = "MET", .offset = 1, .dst = 0 },
    .{ .name = "MEWT", .offset = 1, .dst = 0 },
    .{ .name = "MEST", .offset = 1, .dst = 1 },
    .{ .name = "CEST", .offset = 1, .dst = 1 },
    .{ .name = "MESZ", .offset = 1, .dst = 1 },
    .{ .name = "FWT", .offset = 1, .dst = 0 },
    .{ .name = "FST", .offset = 1, .dst = 1 },
    .{ .name = "EET", .offset = 2, .dst = 0 },
    .{ .name = "EEST", .offset = 2, .dst = 1 },
    .{ .name = "WAST", .offset = 7, .dst = 0 },
    .{ .name = "WADT", .offset = 7, .dst = 1 },
    .{ .name = "CCT", .offset = 8, .dst = 0 },
    .{ .name = "JST", .offset = 9, .dst = 0 },
    .{ .name = "EAST", .offset = 10, .dst = 0 },
    .{ .name = "EADT", .offset = 10, .dst = 1 },
    .{ .name = "GST", .offset = 10, .dst = 0 },
    .{ .name = "NZT", .offset = 12, .dst = 0 },
    .{ .name = "NZST", .offset = 12, .dst = 0 },
    .{ .name = "NZDT", .offset = 12, .dst = 1 },
    .{ .name = "IDLE", .offset = 12, .dst = 0 },
};

/// git's match_string(): s[p..] against str.
fn matchString(s: []const u8, p: usize, str: []const u8) usize {
    var i: usize = 0;
    while (at(s, p + i) != 0) : (i += 1) {
        const d = at(s, p + i);
        const c = at(str, i);
        if (d == c) continue;
        if (std.ascii.toUpper(d) == std.ascii.toUpper(c)) continue;
        if (!isAlnum(d)) break;
        return 0;
    }
    return i;
}

fn skipAlpha(s: []const u8, p: usize) usize {
    var i: usize = 0;
    while (true) {
        i += 1;
        if (!isAlpha(at(s, p + i))) break;
    }
    return i;
}

fn matchAlpha(s: []const u8, p: usize, tm: *Tm, offset: *i32) usize {
    for (month_names, 0..) |mn, i| {
        const m = matchString(s, p, mn);
        if (m >= 3) {
            tm.mon = @intCast(i);
            return m;
        }
    }
    for (weekday_names, 0..) |wn, i| {
        const m = matchString(s, p, wn);
        if (m >= 3) {
            tm.wday = @intCast(i);
            return m;
        }
    }
    for (timezone_names) |z| {
        const m = matchString(s, p, z.name);
        if (m >= 3 or m == z.name.len) {
            var off = z.offset;
            off += z.dst;
            if (offset.* == -1) offset.* = 60 * off;
            return m;
        }
    }
    if (matchString(s, p, "PM") == 2) {
        tm.hour = @rem(tm.hour, 12) + 12;
        return 2;
    }
    if (matchString(s, p, "AM") == 2) {
        tm.hour = @rem(tm.hour, 12) + 0;
        return 2;
    }
    if (at(s, p) == 'T' and isDigit(at(s, p + 1)) and tm.hour == -1) {
        tm.min = 0;
        tm.sec = 0;
        return 1;
    }
    return skipAlpha(s, p);
}

fn setDate(year: i32, month: i32, day: i32, now_tm: ?*const Tm, now: i64, tm: *Tm) i32 {
    if (month > 0 and month < 13 and day > 0 and day < 32) {
        var check = tm.*;
        const r: *Tm = if (now_tm != null) &check else tm;
        r.mon = month - 1;
        r.mday = day;
        if (year == -1) {
            if (now_tm == null) return 1;
            r.year = now_tm.?.year;
        } else if (year >= 1970 and year < 2100) {
            r.year = year - 1900;
        } else if (year > 70 and year < 100) {
            r.year = year;
        } else if (year < 38) {
            r.year = year + 100;
        } else return -1;
        if (now_tm == null) return 0;
        const specified = tmToTimeT(r);
        if (specified != -1 and now +% 10 * 24 * 3600 < specified) return -1;
        tm.mon = r.mon;
        tm.mday = r.mday;
        if (year != -1) tm.year = r.year;
        return 0;
    }
    return -1;
}

fn setTime(hour: i64, minute: i64, second: i64, tm: *Tm) i32 {
    if (0 <= hour and hour <= 24 and 0 <= minute and minute < 60 and 0 <= second and second <= 60) {
        tm.hour = @intCast(hour);
        tm.min = @intCast(minute);
        tm.sec = @intCast(second);
        return 0;
    }
    return -1;
}

fn isDateKnown(tm: *const Tm) bool {
    return tm.year != -1 and tm.mon != -1 and tm.mday != -1;
}

/// `endp` is the index of the separator character c (just after num).
fn matchMultiNumber(num: u64, c: u8, s: []const u8, p: usize, endp: usize, tm: *Tm, now_in: i64) usize {
    var now = now_in;
    var end = endp;
    var r = cStrtol(s, end + 1);
    const num2 = r.val;
    end = r.end;
    var num3: i64 = -1;
    if (at(s, end) == c and isDigit(at(s, end + 1))) {
        r = cStrtol(s, end + 1);
        num3 = r.val;
        end = r.end;
    }
    switch (c) {
        ':' => {
            if (num3 < 0) num3 = 0;
            if (setTime(@bitCast(num), num2, num3, tm) == 0) {
                if (at(s, end) == '.' and isDigit(at(s, end + 1)) and isDateKnown(tm))
                    end = cStrtol(s, end + 1).end;
            } else return 0;
        },
        '-', '/', '.' => {
            if (now == 0) now = time(null);
            var now_tm: Tm = undefined;
            var refuse_future: ?*const Tm = null;
            if (gmtime_r(&now, &now_tm) != null) refuse_future = &now_tm;
            const n1: i32 = @truncate(@as(i64, @bitCast(num)));
            const n2: i32 = @truncate(num2);
            const n3: i32 = @truncate(num3);
            blk: {
                if (num > 70) {
                    if (setDate(n1, n2, n3, null, now, tm) == 0) break :blk;
                    if (setDate(n1, n3, n2, null, now, tm) == 0) break :blk;
                }
                if (c != '.' and setDate(n3, n1, n2, refuse_future, now, tm) == 0) break :blk;
                if (setDate(n3, n2, n1, refuse_future, now, tm) == 0) break :blk;
                if (c == '.' and setDate(n3, n1, n2, refuse_future, now, tm) == 0) break :blk;
                return 0;
            }
        },
        else => {},
    }
    return end - p;
}

fn nodate(tm: *const Tm) bool {
    return (tm.year & tm.mon & tm.mday & tm.hour & tm.min & tm.sec) < 0;
}

fn maybeIso8601(tm: *const Tm) bool {
    return tm.hour == -1 and tm.min == 0 and tm.sec == 0;
}

fn matchDigit(s: []const u8, p: usize, tm: *Tm, offset: *i32, tm_gmt: *bool) usize {
    const r = cStrtoul(s, p);
    const num = r.val;
    var end = r.end;

    if (num >= 100000000 and nodate(tm)) {
        const t: i64 = @bitCast(num);
        if (gmtime_r(&t, tm) != null) {
            tm_gmt.* = true;
            return end - p;
        }
    }

    switch (at(s, end)) {
        ':', '.', '/', '-' => {
            if (isDigit(at(s, end + 1))) {
                const m = matchMultiNumber(num, at(s, end), s, p, end, tm, 0);
                if (m != 0) return m;
            }
        },
        else => {},
    }

    var n: usize = 0;
    while (true) {
        n += 1;
        if (!isDigit(at(s, p + n))) break;
    }

    if (n == 8 or n == 6) {
        const num1: u32 = @truncate(num / 10000);
        const num2: u32 = @truncate((num % 10000) / 100);
        const num3: u32 = @truncate(num % 100);
        if (n == 8) {
            _ = setDate(@bitCast(num1), @bitCast(num2), @bitCast(num3), null, time(null), tm);
        } else if (n == 6 and setTime(num1, num2, num3, tm) == 0 and
            at(s, end) == '.' and isDigit(at(s, end + 1)))
        {
            end = cStrtoul(s, end + 1).end;
        }
        return end - p;
    }

    if (maybeIso8601(tm)) {
        var num1: u32 = @truncate(num);
        var num2: u32 = 0;
        if (n == 4) {
            num1 = @truncate(num / 100);
            num2 = @truncate(num % 100);
        }
        if ((n == 4 or n == 2) and !nodate(tm) and setTime(num1, num2, 0, tm) == 0)
            return n;
        tm.min = -1;
        tm.sec = -1;
    }

    if (n == 4) {
        if (num <= 1400 and offset.* == -1) {
            const minutes: u32 = @intCast(num % 100);
            const hours: u32 = @intCast(num / 100);
            offset.* = @intCast(hours * 60 + minutes);
        } else if (num > 1900 and num < 2100) {
            tm.year = @intCast(num - 1900);
        }
        return n;
    }

    if (n > 2) return n;

    if (num > 0 and num < 32 and tm.mday < 0) {
        tm.mday = @intCast(num);
        return n;
    }

    if (n == 2 and tm.year < 0) {
        if (num < 10 and tm.mday >= 0) {
            tm.year = @intCast(num + 100);
            return n;
        }
        if (num >= 70) {
            tm.year = @intCast(num);
            return n;
        }
    }

    if (num > 0 and num < 13 and tm.mon < 0) tm.mon = @intCast(num - 1);

    return n;
}

fn matchTz(s: []const u8, p: usize, offp: *i32) usize {
    var r = cStrtoul(s, p + 1);
    var end = r.end;
    var hour: i32 = @truncate(@as(i64, @bitCast(r.val)));
    const n = end - (p + 1);
    var min: i32 = 0;
    if (n == 4) {
        min = @rem(hour, 100);
        hour = @divTrunc(hour, 100);
    } else if (n != 2) {
        min = 99;
    } else if (at(s, end) == ':') {
        r = cStrtoul(s, end + 1);
        end = r.end;
        min = @truncate(@as(i64, @bitCast(r.val)));
        if (end - (p + 1) != 5) min = 99;
    }
    if (min < 60 and hour < 24) {
        var offset = hour *% 60 +% min;
        if (at(s, p) == '-') offset = -%offset;
        offp.* = offset;
    }
    return end - p;
}

fn dateString(t: i64, offset_in: i32) []const u8 {
    var offset = offset_in;
    var sign: u8 = '+';
    if (offset < 0) {
        offset = -offset;
        sign = '-';
    }
    var b: Buf = .empty;
    addU(&b, u(t));
    util.bufByte(&b, ' ');
    util.bufByte(&b, sign);
    addInt(&b, @divTrunc(offset, 60), 2, true, false);
    addInt(&b, @rem(offset, 60), 2, true, false);
    return b.items;
}

fn matchObjectHeaderDate(s: []const u8, p0: usize, timestamp: *i64, offset: *i32) bool {
    const c0 = at(s, p0);
    if (c0 < '0' or c0 > '9') return false;
    const r = cStrtoul(s, p0);
    const stamp = r.val;
    var end = r.end;
    if (at(s, end) != ' ' or stamp == std.math.maxInt(u64) or (at(s, end + 1) != '+' and at(s, end + 1) != '-'))
        return false;
    const d = end + 2;
    const r2 = cStrtol(s, d);
    end = r2.end;
    if ((at(s, end) != 0 and at(s, end) != '\n') or end != d + 4) return false;
    var ofs: i32 = @truncate(r2.val);
    ofs = @divTrunc(ofs, 100) * 60 + @rem(ofs, 100);
    if (at(s, d - 1) == '-') ofs = -ofs;
    timestamp.* = @bitCast(stamp);
    offset.* = ofs;
    return true;
}

const timestamp_max: u64 = ((2100 - 1970) * 365 + 32) * 24 * 60 * 60 - 1;

fn initTm() Tm {
    var tm = std.mem.zeroes(Tm);
    tm.year = -1;
    tm.mon = -1;
    tm.mday = -1;
    tm.isdst = -1;
    tm.hour = -1;
    tm.min = -1;
    tm.sec = -1;
    return tm;
}

/// git's parse_date_basic(). Returns time and offset (minutes east of UTC).
pub fn parseDateBasic(s: []const u8) ?Parsed {
    var tm = initTm();
    var offset: i32 = -1;
    var tm_gmt = false;
    var timestamp: i64 = 0;

    if (at(s, 0) == '@' and matchObjectHeaderDate(s, 1, &timestamp, &offset))
        return .{ .time = timestamp, .tz = offset };

    var p: usize = 0;
    while (true) {
        const c = at(s, p);
        if (c == 0 or c == '\n') break;
        var m: usize = 0;
        if (isAlpha(c)) {
            m = matchAlpha(s, p, &tm, &offset);
        } else if (isDigit(c)) {
            m = matchDigit(s, p, &tm, &offset, &tm_gmt);
        } else if ((c == '-' or c == '+') and isDigit(at(s, p + 1))) {
            m = matchTz(s, p, &offset);
        }
        if (m == 0) m = 1;
        p += m;
    }

    timestamp = tmToTimeT(&tm);
    if (timestamp == -1) return null;

    if (offset == -1) {
        tm.isdst = -1;
        const temp_time = mktime(&tm);
        if (timestamp > temp_time) {
            offset = @truncate(@divTrunc(timestamp - temp_time, 60));
        } else {
            offset = -@as(i32, @truncate(@divTrunc(temp_time - timestamp, 60)));
        }
    }

    if (!tm_gmt) {
        const off60: i64 = @as(i64, offset) * 60;
        if (offset > 0 and u(off60) > u(timestamp)) return null;
        if (offset < 0 and u(-off60) > timestamp_max -% u(timestamp)) return null;
        timestamp = timestamp -% off60;
    }
    return .{ .time = timestamp, .tz = offset };
}

/// git's parse_date(): Parsed{time, tz (minutes east)} or null on failure.
pub fn parseDate(s: []const u8) ?Parsed {
    return parseDateBasic(s);
}

/// git's parse_date() producing "<time> +hhmm".
pub fn parseDateString(s: []const u8) ?[]const u8 {
    const p = parseDateBasic(s) orelse return null;
    return dateString(p.time, p.tz);
}

/// git's parse_expiry_date(). "never"/"false" -> 0; "all"/"now" -> maxInt(i64) (TIME_MAX).
/// Returns null on error.
pub fn parseExpiryDate(s: []const u8) ?i64 {
    if (util.eql(s, "never") or util.eql(s, "false")) return 0;
    if (util.eql(s, "all") or util.eql(s, "now")) return std.math.maxInt(i64);
    var e = false;
    const t = approxidateCareful(s, &e);
    if (e) return null;
    return t;
}

fn parseDateType(f: []const u8, end: *[]const u8) ?Mode {
    const table = [_]struct { p: []const u8, m: Mode }{
        .{ .p = "relative", .m = .relative },
        .{ .p = "iso8601-strict", .m = .iso8601_strict },
        .{ .p = "iso-strict", .m = .iso8601_strict },
        .{ .p = "iso8601", .m = .iso8601 },
        .{ .p = "iso", .m = .iso8601 },
        .{ .p = "rfc2822", .m = .rfc2822 },
        .{ .p = "rfc", .m = .rfc2822 },
        .{ .p = "short", .m = .short },
        .{ .p = "default", .m = .normal },
        .{ .p = "human", .m = .human },
        .{ .p = "raw", .m = .raw },
        .{ .p = "unix", .m = .unix },
        .{ .p = "format", .m = .strftime },
    };
    for (table) |e| {
        if (util.startsWith(f, e.p)) {
            end.* = f[e.p.len..];
            return e.m;
        }
    }
    return null;
}

pub const DateFormatError = enum { unknown, missing_colon };

fn pagerInUse() bool {
    const v = os.getenv("GIT_PAGER_IN_USE") orelse return false;
    if (v.len == 0) return false;
    const l = util.lower(v);
    if (util.eql(l, "false") or util.eql(l, "no") or util.eql(l, "off")) return false;
    if (util.parseInt(i64, v)) |n| return n != 0;
    return true;
}

fn parseDateFormatImpl(format_in: []const u8, err: *DateFormatError, errfmt: *[]const u8) ?DateMode {
    var format = format_in;
    if (util.skipPrefix(format, "auto:")) |p| {
        format = if (os.isatty(1) or pagerInUse()) p else "default";
    }
    if (util.eql(format, "local")) format = "default-local";
    errfmt.* = format;
    var p: []const u8 = undefined;
    const t = parseDateType(format, &p) orelse {
        err.* = .unknown;
        return null;
    };
    var mode = DateMode{ .mode = t };
    if (util.skipPrefix(p, "-local")) |q| {
        mode.local = true;
        p = q;
    }
    if (t == .strftime) {
        const q = util.skipPrefix(p, ":") orelse {
            err.* = .missing_colon;
            return null;
        };
        mode.strftime_fmt = util.dupe(q);
    } else if (p.len != 0) {
        err.* = .unknown;
        return null;
    }
    return mode;
}

/// git's parse_date_format(); null if the format is invalid.
pub fn parseDateFormat(s: []const u8) ?DateMode {
    var e: DateFormatError = .unknown;
    var f: []const u8 = s;
    return parseDateFormatImpl(s, &e, &f);
}

/// git's parse_date_format() including its die() messages.
pub fn parseDateFormatOrDie(s: []const u8) DateMode {
    var e: DateFormatError = .unknown;
    var f: []const u8 = s;
    if (parseDateFormatImpl(s, &e, &f)) |m| return m;
    switch (e) {
        .unknown => util.die("unknown date format {s}", .{f}),
        .missing_colon => util.die("date format missing colon separator: {s}", .{f}),
    }
}

/// git's datestamp(): "<now> +hhmm" using the local time zone (real clock).
pub fn datestamp() []const u8 {
    const now = time(null);
    var tm: Tm = std.mem.zeroes(Tm);
    _ = localtime_r(&now, &tm);
    var offset: i64 = tmToTimeT(&tm) - now;
    offset = @divTrunc(offset, 60);
    return dateString(now, @truncate(offset));
}

// ---------------------------------------------------------------------------
// approxidate

fn updateTm(tm: *Tm, now: *const Tm, sec_in: i64) i64 {
    var sec = sec_in;
    if (tm.mday < 0) {
        const offset = tm.mday + 1;
        if (sec == 0 and offset < 0) sec = @as(i64, -offset) * 24 * 60 * 60;
        tm.mday = now.mday;
    }
    if (tm.mon < 0) tm.mon = now.mon;
    if (tm.year < 0) {
        tm.year = now.year;
        if (tm.mon > now.mon) tm.year -= 1;
    }
    const n = mktime(tm) -% sec;
    _ = localtime_r(&n, tm);
    return n;
}

fn pendingNumber(tm: *Tm, num: *i32) void {
    const number = num.*;
    if (number != 0) {
        num.* = 0;
        if (tm.mday < 0 and number < 32) {
            tm.mday = number;
        } else if (tm.mon < 0 and number < 13) {
            tm.mon = number - 1;
        } else if (tm.year < 0) {
            if (number > 1969 and number < 2100) {
                tm.year = number - 1900;
            } else if (number > 69 and number < 100) {
                tm.year = number;
            } else if (number < 38) {
                tm.year = 100 + number;
            }
        }
    }
}

fn dateTime(tm: *Tm, hour: i32) void {
    if (tm.mday < 0 and tm.hour < hour) tm.mday = -2;
    tm.hour = hour;
    tm.min = 0;
    tm.sec = 0;
}

const Special = enum { yesterday, noon, midnight, tea, pm, am, never, now, today };
const specials = [_]struct { name: []const u8, s: Special }{
    .{ .name = "yesterday", .s = .yesterday },
    .{ .name = "noon", .s = .noon },
    .{ .name = "midnight", .s = .midnight },
    .{ .name = "tea", .s = .tea },
    .{ .name = "PM", .s = .pm },
    .{ .name = "AM", .s = .am },
    .{ .name = "never", .s = .never },
    .{ .name = "now", .s = .now },
    .{ .name = "today", .s = .today },
};

fn runSpecial(sp: Special, tm: *Tm, now: *const Tm, num: *i32) void {
    switch (sp) {
        .now => {
            num.* = 0;
            _ = updateTm(tm, now, 0);
        },
        .yesterday => {
            num.* = 0;
            tm.mday = -1;
            _ = updateTm(tm, now, 24 * 60 * 60);
        },
        .midnight => {
            pendingNumber(tm, num);
            dateTime(tm, 0);
        },
        .noon => {
            pendingNumber(tm, num);
            dateTime(tm, 12);
        },
        .tea => {
            pendingNumber(tm, num);
            dateTime(tm, 17);
        },
        .pm, .am => {
            const n = num.*;
            num.* = 0;
            var hour = tm.hour;
            if (n != 0) {
                hour = n;
                tm.min = 0;
                tm.sec = 0;
            }
            tm.hour = @rem(hour, 12) + (if (sp == .pm) @as(i32, 12) else 0);
        },
        .never => {
            const z: i64 = 0;
            _ = localtime_r(&z, tm);
            num.* = 0;
        },
        .today => {
            if (tm.hour == now.hour and tm.min == now.min and tm.sec == now.sec)
                dateTime(tm, 0);
            num.* = 0;
            tm.mday = -1;
            _ = updateTm(tm, now, 0);
        },
    }
}

const number_name = [_][]const u8{
    "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
};

const typelen = [_]struct { t: []const u8, len: i32 }{
    .{ .t = "seconds", .len = 1 },
    .{ .t = "minutes", .len = 60 },
    .{ .t = "hours", .len = 60 * 60 },
    .{ .t = "days", .len = 24 * 60 * 60 },
    .{ .t = "weeks", .len = 7 * 24 * 60 * 60 },
};

fn approxidateAlpha(s: []const u8, p: usize, tm: *Tm, now: *const Tm, num: *i32, touched: *bool) usize {
    var end = p;
    while (true) {
        end += 1;
        if (!isAlpha(at(s, end))) break;
    }

    for (month_names, 0..) |mn, i| {
        if (matchString(s, p, mn) >= 3) {
            tm.mon = @intCast(i);
            touched.* = true;
            return end;
        }
    }

    for (specials) |sp| {
        if (matchString(s, p, sp.name) == sp.name.len) {
            runSpecial(sp.s, tm, now, num);
            touched.* = true;
            return end;
        }
    }

    if (num.* == 0) {
        var i: usize = 1;
        while (i < 11) : (i += 1) {
            if (matchString(s, p, number_name[i]) == number_name[i].len) {
                num.* = @intCast(i);
                touched.* = true;
                return end;
            }
        }
        if (matchString(s, p, "last") == 4) {
            num.* = 1;
            touched.* = true;
        }
        return end;
    }

    for (typelen) |tl| {
        if (matchString(s, p, tl.t) >= tl.t.len - 1) {
            _ = updateTm(tm, now, @as(i64, tl.len *% num.*));
            num.* = 0;
            touched.* = true;
            return end;
        }
    }

    for (weekday_names, 0..) |wn, i| {
        if (matchString(s, p, wn) >= 3) {
            var n: i32 = num.* - 1;
            num.* = 0;
            var diff: i32 = tm.wday - @as(i32, @intCast(i));
            if (diff <= 0) n += 1;
            diff +%= 7 *% n;
            _ = updateTm(tm, now, @as(i64, diff *% (24 * 60 * 60)));
            touched.* = true;
            return end;
        }
    }

    if (matchString(s, p, "months") >= 5) {
        _ = updateTm(tm, now, 0);
        var n = tm.mon - num.*;
        num.* = 0;
        while (n < 0) {
            n += 12;
            tm.year -= 1;
        }
        tm.mon = n;
        touched.* = true;
        return end;
    }

    if (matchString(s, p, "years") >= 4) {
        _ = updateTm(tm, now, 0);
        tm.year -= num.*;
        num.* = 0;
        touched.* = true;
        return end;
    }

    return end;
}

fn approxidateDigit(s: []const u8, p: usize, tm: *Tm, num: *i32, now: i64) usize {
    const r = cStrtoul(s, p);
    const number = r.val;
    const end = r.end;
    switch (at(s, end)) {
        ':', '.', '/', '-' => {
            if (isDigit(at(s, end + 1))) {
                const m = matchMultiNumber(number, at(s, end), s, p, end, tm, now);
                if (m != 0) return p + m;
            }
        },
        else => {},
    }
    if (at(s, p) != '0' or end - p <= 2) num.* = @truncate(@as(i64, @bitCast(number)));
    return end;
}

fn approxidateStr(s: []const u8, tv: i64, error_ret: *bool) i64 {
    var number: i32 = 0;
    var touched = false;
    var tm: Tm = std.mem.zeroes(Tm);
    const time_sec = tv;
    _ = localtime_r(&time_sec, &tm);
    const now = tm;

    tm.year = -1;
    tm.mon = -1;
    tm.mday = -1;

    var p: usize = 0;
    while (true) {
        const c = at(s, p);
        if (c == 0) break;
        p += 1;
        if (isDigit(c)) {
            pendingNumber(&tm, &number);
            p = approxidateDigit(s, p - 1, &tm, &number, time_sec);
            touched = true;
            continue;
        }
        if (isAlpha(c)) p = approxidateAlpha(s, p - 1, &tm, &now, &number, &touched);
    }
    pendingNumber(&tm, &number);
    if (!touched) error_ret.* = true;
    return updateTm(&tm, &now, 0);
}

/// git's approxidate_careful(); sets error_ret.* = true if nothing could be parsed.
pub fn approxidateCareful(s: []const u8, error_ret: ?*bool) i64 {
    var dummy = false;
    const e = error_ret orelse &dummy;
    if (parseDateBasic(s)) |p| {
        e.* = false;
        return p.time;
    }
    return approxidateStr(s, getTime(), e);
}

/// git's approxidate()
pub fn approxidate(s: []const u8) i64 {
    return approxidateCareful(s, null);
}

// ---------------------------------------------------------------------------
// tests (run with: zig test src/date.zig -lc, with TZ=UTC)

fn expectShow(f: []const u8, t: i64, tz: i32, want: []const u8) !void {
    const m = parseDateFormat(f) orelse return error.BadFormat;
    try std.testing.expectEqualStrings(want, showDate(t, tz, m));
}

fn expectParse(s: []const u8, want: []const u8) !void {
    if (parseDate(s)) |p| {
        const got = showDate(p.time, tzMinutesToHhmm(p.tz), DateMode.of(.iso8601));
        std.testing.expectEqualStrings(want, got) catch |e| {
            std.debug.print("input: {s}\n", .{s});
            return e;
        };
    } else {
        std.testing.expectEqualStrings(want, "bad") catch |e| {
            std.debug.print("input: {s}\n", .{s});
            return e;
        };
    }
}

fn expectApprox(s: []const u8, want: []const u8) !void {
    const t = approxidate(s);
    std.testing.expectEqualStrings(want, showDate(t, 0, DateMode.of(.iso8601))) catch |e| {
        std.debug.print("input: {s}\n", .{s});
        return e;
    };
}

test "t0006" {
    // Requires TZ=UTC and GIT_TEST_DATE_NOW=1251660000 in the environment.
    const now: i64 = 1251660000;
    const rel = [_]struct { d: i64, s: []const u8 }{
        .{ .d = 5, .s = "5 seconds ago" },
        .{ .d = 300, .s = "5 minutes ago" },
        .{ .d = 18000, .s = "5 hours ago" },
        .{ .d = 432000, .s = "5 days ago" },
        .{ .d = 1728000, .s = "3 weeks ago" },
        .{ .d = 13000000, .s = "5 months ago" },
        .{ .d = 37500000, .s = "1 year, 2 months ago" },
        .{ .d = 55188000, .s = "1 year, 9 months ago" },
        .{ .d = 630000000, .s = "20 years ago" },
        .{ .d = 31449600, .s = "12 months ago" },
        .{ .d = 62985600, .s = "2 years ago" },
    };
    for (rel) |r| try std.testing.expectEqualStrings(r.s, showDate(now - r.d, 0, DateMode.of(.relative)));

    const T: i64 = 1466000000;
    try expectShow("iso8601", T, 200, "2016-06-15 16:13:20 +0200");
    try expectShow("iso8601-strict", T, 200, "2016-06-15T16:13:20+02:00");
    try expectShow("iso8601-strict", T, 0, "2016-06-15T14:13:20Z");
    try expectShow("rfc2822", T, 200, "Wed, 15 Jun 2016 16:13:20 +0200");
    try expectShow("short", T, 200, "2016-06-15");
    try expectShow("default", T, 200, "Wed Jun 15 16:13:20 2016 +0200");
    try expectShow("raw", T, 200, "1466000000 +0200");
    try expectShow("unix", T, 200, "1466000000");
    try expectShow("iso-local", T, 200, "2016-06-15 14:13:20 +0000");
    try expectShow("raw-local", T, 200, "1466000000 +0000");
    try expectShow("unix-local", T, 200, "1466000000");
    try expectShow("format:%z", T, 200, "+0200");
    try expectShow("format-local:%z", T, 200, "+0000");
    try expectShow("format:%Z", T, 200, "");
    try expectShow("format-local:%Z", T, 200, "UTC");
    try expectShow("format:%%z", T, 200, "%z");
    try expectShow("format-local:%%z", T, 200, "%z");
    try expectShow("format:%Y-%m-%d %H:%M:%S", T, 200, "2016-06-15 16:13:20");
    try expectShow("format:%s", 123456789, 1234, "123456789");
    try expectShow("format:%s", 123456789, -1234, "123456789");
    try expectShow("format-local:%s", 123456789, -1234, "123456789");
    try expectShow("iso", 5758122296, -400, "2152-06-19 18:24:56 -0400");
    try expectShow("iso-local", 5758122296, -400, "2152-06-19 22:24:56 +0000");
    try expectShow("default", 0, 0, "Thu Jan 1 00:00:00 1970 +0000");

    try expectParse("2008", "bad");
    try expectParse("2008-02", "bad");
    try expectParse("2008-02-14", "bad");
    try expectParse("2008-02-14 20:30:45", "2008-02-14 20:30:45 +0000");
    try expectParse("2008-02-14 20:30:45 -0500", "2008-02-14 20:30:45 -0500");
    try expectParse("2008.02.14 20:30:45 -0500", "2008-02-14 20:30:45 -0500");
    try expectParse("20080214T20:30:45", "2008-02-14 20:30:45 +0000");
    try expectParse("20080214T20:30", "2008-02-14 20:30:00 +0000");
    try expectParse("20080214T20", "2008-02-14 20:00:00 +0000");
    try expectParse("20080214T203045", "2008-02-14 20:30:45 +0000");
    try expectParse("20080214T2030", "2008-02-14 20:30:00 +0000");
    try expectParse("20080214T000000.20", "2008-02-14 00:00:00 +0000");
    try expectParse("20080214T00:00:00.20", "2008-02-14 00:00:00 +0000");
    try expectParse("20080214T203045-04:00", "2008-02-14 20:30:45 -0400");
    try expectParse("20080214T203045 -04:00", "2008-02-14 20:30:45 -0400");
    try expectParse("20080214T203045.019-04:00", "2008-02-14 20:30:45 -0400");
    try expectParse("2008-02-14 20:30:45.019-04:00", "2008-02-14 20:30:45 -0400");
    try expectParse("2008-02-14 20:30:45 -0015", "2008-02-14 20:30:45 -0015");
    try expectParse("2008-02-14 20:30:45 -5", "2008-02-14 20:30:45 +0000");
    try expectParse("2008-02-14 20:30:45 -5:", "2008-02-14 20:30:45 +0000");
    try expectParse("2008-02-14 20:30:45 -05", "2008-02-14 20:30:45 -0500");
    try expectParse("2008-02-14 20:30:45 -:30", "2008-02-14 20:30:45 +0000");
    try expectParse("2008-02-14 20:30:45 -05:00", "2008-02-14 20:30:45 -0500");
    try expectParse("Thu, 7 Apr 2005 15:14:13 -0700", "2005-04-07 15:14:13 -0700");
    try expectParse("1970-01-01 00:00:00", "1970-01-01 00:00:00 +0000");
    try expectParse("1970-01-01 00:00:00 +00", "1970-01-01 00:00:00 +0000");
    try expectParse("1970-01-01 00:00:00 Z", "1970-01-01 00:00:00 +0000");
    try expectParse("1970-01-01 00:00:00 -01", "1970-01-01 00:00:00 -0100");
    try expectParse("1970-01-01 00:00:00 +01", "bad");
    try expectParse("1970-01-01 00:00:00 +11", "bad");
    try expectParse("2099-12-31 23:59:59", "2099-12-31 23:59:59 +0000");
    try expectParse("2099-12-31 23:59:59 +00", "2099-12-31 23:59:59 +0000");
    try expectParse("2099-12-31 23:59:59 Z", "2099-12-31 23:59:59 +0000");
    try expectParse("2099-12-31 23:59:59 +01", "2099-12-31 23:59:59 +0100");
    try expectParse("2099-12-31 23:59:59 -01", "bad");
    try expectParse("2099-12-31 23:59:59 -11", "bad");
    try expectParse("@1466000000 +0200", "2016-06-15 16:13:20 +0200");
    try expectParse("1466000000 +0200", "2016-06-15 16:13:20 +0200");
    try expectParse("@0 +0000", "1970-01-01 00:00:00 +0000");

    try expectApprox("now", "2009-08-30 19:20:00 +0000");
    try expectApprox("5 seconds ago", "2009-08-30 19:19:55 +0000");
    try expectApprox("5.seconds.ago", "2009-08-30 19:19:55 +0000");
    try expectApprox("10.minutes.ago", "2009-08-30 19:10:00 +0000");
    try expectApprox("yesterday", "2009-08-29 19:20:00 +0000");
    try expectApprox("3.days.ago", "2009-08-27 19:20:00 +0000");
    try expectApprox("12:34:56.3.days.ago", "2009-08-27 12:34:56 +0000");
    try expectApprox("3.weeks.ago", "2009-08-09 19:20:00 +0000");
    try expectApprox("3.months.ago", "2009-05-30 19:20:00 +0000");
    try expectApprox("2.years.3.months.ago", "2007-05-30 19:20:00 +0000");
    try expectApprox("6am yesterday", "2009-08-29 06:00:00 +0000");
    try expectApprox("6pm yesterday", "2009-08-29 18:00:00 +0000");
    try expectApprox("3:00", "2009-08-30 03:00:00 +0000");
    try expectApprox("15:00", "2009-08-30 15:00:00 +0000");
    try expectApprox("noon today", "2009-08-30 12:00:00 +0000");
    try expectApprox("noon yesterday", "2009-08-29 12:00:00 +0000");
    try expectApprox("January 5th noon pm", "2009-01-05 12:00:00 +0000");
    try expectApprox("10am noon", "2009-08-29 12:00:00 +0000");
    try expectApprox("last tuesday", "2009-08-25 19:20:00 +0000");
    try expectApprox("July 5th", "2009-07-05 19:20:00 +0000");
    try expectApprox("06/05/2009", "2009-06-05 19:20:00 +0000");
    try expectApprox("06.05.2009", "2009-05-06 19:20:00 +0000");
    try expectApprox("Jun 6, 5AM", "2009-06-06 05:00:00 +0000");
    try expectApprox("5AM Jun 6", "2009-06-06 05:00:00 +0000");
    try expectApprox("6AM, June 7, 2009", "2009-06-07 06:00:00 +0000");
    try expectApprox("2008-12-01", "2008-12-01 19:20:00 +0000");
    try expectApprox("2009-12-01", "2009-12-01 19:20:00 +0000");
    try expectApprox("Dec 02", "2008-12-02 19:20:00 +0000");
    try expectApprox("never", "1970-01-01 00:00:00 +0000");

    const human = [_]struct { d: i64, s: []const u8 }{
        .{ .d = 18000, .s = "5 hours ago" },
        .{ .d = 432000, .s = "Tue Aug 25 19:20" },
        .{ .d = 1728000, .s = "Mon Aug 10 19:20" },
        .{ .d = 13000000, .s = "Thu Apr 2 08:13" },
        .{ .d = 31449600, .s = "Aug 31 2008" },
        .{ .d = 37500000, .s = "Jun 22 2008" },
        .{ .d = 55188000, .s = "Dec 1 2007" },
        .{ .d = 630000000, .s = "Sep 13 1989" },
    };
    for (human) |h| try std.testing.expectEqualStrings(h.s, showDate(now - h.d, 0, DateMode.of(.human)));

    try std.testing.expect(parseDateFormat("bogus") == null);
    try std.testing.expect(parseDateFormat("format") == null);
    try std.testing.expect(parseDateFormat("local").?.local);
    try std.testing.expect(parseDateFormat("relative-local").?.mode == .relative);
}
