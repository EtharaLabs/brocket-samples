//! Git configuration: parsing (port of config.c), includes, lookup and
//! file editing.
//!
//! Low-level API (used by `git config`):
//!   - `Parser` / `parseSource()`: git_parse_source() with value callback
//!     and optional event callback.
//!   - `configWithOptions(spec, cb, opts)`: config_with_options(), i.e. read
//!     a file / stdin / blob / the standard sequence, honoring includes.
//!   - `fromParameters(cb)`: GIT_CONFIG_COUNT + GIT_CONFIG_PARAMETERS.
//!   - `setMultivarInFile()`, `renameSectionInFile()`: file editing with
//!     git's exact return codes.
//!   - typed value helpers: `configInt`, `configInt64`, `configBool`,
//!     `configBoolOrInt`, `parseMaybeBool`, `configPathname`, `interpolatePath`.
//!   - urlmatch: `urlNormalize`, `matchUrls`, `cmpMatches`, `UrlMatchConfig`.
//! High-level API: `Config` (a flat list of entries) used by everything else.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const gpa = util.gpa;

pub const Scope = enum {
    system,
    global,
    local,
    worktree,
    command,
    unknown,
    pub fn name(self: Scope) []const u8 {
        return switch (self) {
            .system => "system",
            .global => "global",
            .local => "local",
            .worktree => "worktree",
            .command => "command",
            .unknown => "unknown",
        };
    }
};

pub const OriginType = enum {
    file,
    cmdline,
    stdin,
    blob,
    pub fn name(self: OriginType) []const u8 {
        return switch (self) {
            .file => "file",
            .cmdline => "command line",
            .stdin => "standard input",
            .blob => "blob",
        };
    }
};

pub const Entry = struct {
    key: []const u8,
    value: ?[]const u8,
    origin: []const u8, // file name, or "" for command line
    origin_type: OriginType,
    scope: Scope,
    line: u32,

    pub fn kvi(self: Entry) KvInfo {
        return .{
            .filename = if (self.origin_type == .cmdline) null else self.origin,
            .origin_type = self.origin_type,
            .scope = self.scope,
            .linenr = if (self.origin_type == .cmdline) -1 else @intCast(self.line),
        };
    }
};

/// key_value_info
pub const KvInfo = struct {
    filename: ?[]const u8 = null,
    origin_type: OriginType = .cmdline,
    scope: Scope = .command,
    linenr: i32 = -1,
};

/// kvi_from_param()
pub const kvi_param = KvInfo{};

// ---------------------------------------------------------------------------
// character classes (git's sane ctype)

pub fn isKeyChar(ch: u8) bool {
    return std.ascii.isAlphanumeric(ch) or ch == '-';
}

pub fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r';
}

// ---------------------------------------------------------------------------
// The parser

pub const ValueFn = *const fn (ctx: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const KvInfo) i32;
pub const Callback = struct {
    f: ValueFn,
    ctx: *anyopaque,
    pub fn call(self: Callback, key: []const u8, value: ?[]const u8, kvi: *const KvInfo) i32 {
        return self.f(self.ctx, key, value, kvi);
    }
};

pub const EventType = enum { whitespace, comment, section, entry, eof, err };
pub const EventFn = *const fn (ctx: *anyopaque, t: EventType, begin: usize, end: usize, p: *Parser) i32;

pub const ErrorAction = enum { die, err, silent };

pub const Source = struct {
    data: []const u8,
    origin_type: OriginType,
    /// file name (as given), "" for stdin, blob name for blobs
    name: []const u8,
    scope: Scope,
    error_action: ErrorAction = .die,
};

pub const Parser = struct {
    data: []const u8,
    pos: usize = 0,
    linenr: i32 = 1,
    eof: bool = false,
    var_: util.Buf = .empty,
    value: util.Buf = .empty,
    subsection_case_sensitive: bool = true,
    event_fn: ?EventFn = null,
    event_ctx: *anyopaque = undefined,
    prev_type: EventType = .eof,
    prev_offset: usize = 0,

    fn getc(self: *Parser) i32 {
        if (self.pos >= self.data.len) return -1;
        const ch = self.data[self.pos];
        self.pos += 1;
        return ch;
    }

    fn nextChar(self: *Parser) u8 {
        var ch = self.getc();
        if (ch == '\r') {
            ch = self.getc();
            if (ch != '\n') {
                if (ch != -1) self.pos -= 1;
                ch = '\r';
            }
        }
        if (ch == '\n') self.linenr += 1;
        if (ch == -1) {
            self.eof = true;
            self.linenr += 1;
            ch = '\n';
        }
        return @intCast(ch);
    }

    fn doEvent(self: *Parser, t: EventType) i32 {
        const f = self.event_fn orelse return 0;
        if (t == .whitespace and self.prev_type == .whitespace) return 0;
        var offset = self.pos;
        if (t != .eof and offset > 0) offset -= 1;
        if (self.prev_type != .eof) {
            if (f(self.event_ctx, self.prev_type, self.prev_offset, offset, self) < 0) return -1;
        }
        self.prev_type = t;
        self.prev_offset = offset;
        return 0;
    }

    fn parseValue(self: *Parser) bool {
        var quote = false;
        var comment = false;
        var trim_len: usize = 0;
        self.value.clearRetainingCapacity();
        while (true) {
            var ch = self.nextChar();
            if (ch == '\n') {
                if (quote) {
                    self.linenr -= 1;
                    return false;
                }
                if (trim_len != 0) self.value.items.len = trim_len;
                return true;
            }
            if (comment) continue;
            if (isSpace(ch) and !quote) {
                if (trim_len == 0) trim_len = self.value.items.len;
                if (self.value.items.len != 0) util.bufByte(&self.value, ch);
                continue;
            }
            if (!quote) {
                if (ch == ';' or ch == '#') {
                    comment = true;
                    continue;
                }
            }
            if (trim_len != 0) trim_len = 0;
            if (ch == '\\') {
                ch = self.nextChar();
                switch (ch) {
                    '\n' => continue,
                    't' => ch = '\t',
                    'b' => ch = 8,
                    'n' => ch = '\n',
                    '\\', '"' => {},
                    else => return false,
                }
                util.bufByte(&self.value, ch);
                continue;
            }
            if (ch == '"') {
                quote = !quote;
                continue;
            }
            util.bufByte(&self.value, ch);
        }
    }

    fn getValue(self: *Parser, src: *const Source, cb: Callback) i32 {
        var ch: u8 = undefined;
        while (true) {
            ch = self.nextChar();
            if (self.eof) break;
            if (!isKeyChar(ch)) break;
            util.bufByte(&self.var_, std.ascii.toLower(ch));
        }
        while (ch == ' ' or ch == '\t') ch = self.nextChar();
        var value: ?[]const u8 = null;
        if (ch != '\n') {
            if (ch != '=') return -1;
            if (!self.parseValue()) return -1;
            value = self.value.items;
        }
        self.linenr -= 1;
        const kvi = KvInfo{
            .filename = src.name,
            .origin_type = src.origin_type,
            .scope = src.scope,
            .linenr = self.linenr,
        };
        const ret = cb.call(self.var_.items, value, &kvi);
        if (ret >= 0) self.linenr += 1;
        return ret;
    }

    fn getExtendedBaseVar(self: *Parser, c0: u8) bool {
        var ch = c0;
        self.subsection_case_sensitive = false;
        while (true) {
            if (ch == '\n') {
                self.linenr -= 1;
                return false;
            }
            ch = self.nextChar();
            if (!isSpace(ch)) break;
        }
        if (ch != '"') return false;
        util.bufByte(&self.var_, '.');
        while (true) {
            var c2 = self.nextChar();
            if (c2 == '\n') {
                self.linenr -= 1;
                return false;
            }
            if (c2 == '"') break;
            if (c2 == '\\') {
                c2 = self.nextChar();
                if (c2 == '\n') {
                    self.linenr -= 1;
                    return false;
                }
            }
            util.bufByte(&self.var_, c2);
        }
        if (self.nextChar() != ']') return false;
        return true;
    }

    fn getBaseVar(self: *Parser) bool {
        self.subsection_case_sensitive = true;
        while (true) {
            const ch = self.nextChar();
            if (self.eof) return false;
            if (ch == ']') return true;
            if (isSpace(ch)) return self.getExtendedBaseVar(ch);
            if (!isKeyChar(ch) and ch != '.') return false;
            util.bufByte(&self.var_, std.ascii.toLower(ch));
        }
    }

    /// git_parse_source()
    pub fn run(self: *Parser, src: *const Source, cb: Callback) i32 {
        var comment = false;
        var baselen: usize = 0;
        const bom = "\xef\xbb\xbf";
        var bomi: usize = 0;
        var bom_done = false;
        while (true) {
            const ch = self.nextChar();
            if (!bom_done) {
                if (ch == bom[bomi] and !self.eof) {
                    bomi += 1;
                    if (bomi == bom.len) bom_done = true;
                    continue;
                } else {
                    if (bomi != 0) break;
                    bom_done = true;
                }
            }
            if (ch == '\n') {
                if (self.eof) {
                    if (self.doEvent(.eof) < 0) return -1;
                    return 0;
                }
                if (self.doEvent(.whitespace) < 0) return -1;
                comment = false;
                continue;
            }
            if (comment) continue;
            if (isSpace(ch)) {
                if (self.doEvent(.whitespace) < 0) return -1;
                continue;
            }
            if (ch == '#' or ch == ';') {
                if (self.doEvent(.comment) < 0) return -1;
                comment = true;
                continue;
            }
            if (ch == '[') {
                if (self.doEvent(.section) < 0) return -1;
                self.var_.clearRetainingCapacity();
                if (!self.getBaseVar() or self.var_.items.len < 1) break;
                util.bufByte(&self.var_, '.');
                baselen = self.var_.items.len;
                continue;
            }
            if (!std.ascii.isAlphabetic(ch)) break;
            if (self.doEvent(.entry) < 0) return -1;
            self.var_.items.len = baselen;
            util.bufByte(&self.var_, std.ascii.toLower(ch));
            if (self.getValue(src, cb) < 0) break;
        }
        if (self.doEvent(.err) < 0) return -1;
        const msg = switch (src.origin_type) {
            .blob => util.fmt("bad config line {d} in blob {s}", .{ self.linenr, src.name }),
            .file => util.fmt("bad config line {d} in file {s}", .{ self.linenr, src.name }),
            .stdin => util.fmt("bad config line {d} in standard input", .{self.linenr}),
            .cmdline => util.fmt("bad config line {d} in command line {s}", .{ self.linenr, src.name }),
        };
        switch (src.error_action) {
            .die => util.die("{s}", .{msg}),
            .err => util.err("{s}", .{msg}),
            .silent => {},
        }
        return -1;
    }
};

/// Parse a buffer, calling `cb` for every key/value.
pub fn parseSource(src: Source, cb: Callback, event_fn: ?EventFn, event_ctx: ?*anyopaque) i32 {
    var p = Parser{ .data = src.data };
    if (event_fn) |f| {
        p.event_fn = f;
        p.event_ctx = event_ctx.?;
    }
    return p.run(&src, cb);
}

// ---------------------------------------------------------------------------
// Reading sources, includes

pub const Options = struct {
    respect_includes: bool = true,
    /// for includeIf.gitdir: (absolute or relative to cwd)
    git_dir: ?[]const u8 = null,
    /// repository common dir: the sequence reads <commondir>/config
    common_dir: ?[]const u8 = null,
    /// <gitdir>/config.worktree when extensions.worktreeConfig is on
    worktree_config: ?[]const u8 = null,
    /// for includeIf.onbranch: (branch name without refs/heads/)
    branch: ?[]const u8 = null,
    /// for includeIf.worktree:
    work_tree: ?[]const u8 = null,
    unconditional_remote_url: bool = false,
    ignore_cmdline: bool = false,
};

pub const SourceSpec = union(enum) {
    sequence,
    file: []const u8,
    stdin,
    blob: []const u8,
};

var stdin_data: ?[]const u8 = null;

fn readStdinOnce() []const u8 {
    if (stdin_data != null) return "";
    stdin_data = os.readAllFd(0) catch "";
    return stdin_data.?;
}

/// git_config_from_file_with_options() (with warn_on_fopen_errors()).
pub fn fromFile(cb: Callback, path: []const u8, scope: Scope, event_fn: ?EventFn, event_ctx: ?*anyopaque) i32 {
    const data = os.readFile(path) orelse blk: {
        const e = os.errno();
        if (e == os.EISDIR) break :blk @as([]u8, &.{});
        if (e != os.ENOENT and e != os.ENOTDIR) util.warn("unable to access '{s}': {s}", .{ path, os.strErr(e) });
        return -1;
    };
    return parseSource(.{ .data = data, .origin_type = .file, .name = path, .scope = scope }, cb, event_fn, event_ctx);
}

pub fn fromStdin(cb: Callback, scope: Scope) i32 {
    return parseSource(.{ .data = readStdinOnce(), .origin_type = .stdin, .name = "", .scope = scope }, cb, null, null);
}

pub fn fromBlobRef(cb: Callback, name: []const u8, scope: Scope) i32 {
    const revparse = @import("revparse.zig");
    const repo_mod = @import("repo.zig");
    const oid = revparse.getOid(name) orelse {
        util.err("unable to resolve config blob '{s}'", .{name});
        return -1;
    };
    const obj = repo_mod.repo().odb().read(oid) orelse {
        util.err("unable to load config blob object '{s}'", .{name});
        return -1;
    };
    if (obj.typ != .blob) {
        util.err("reference '{s}' does not point to a blob", .{name});
        return -1;
    }
    return parseSource(.{ .data = obj.data, .origin_type = .blob, .name = name, .scope = scope, .error_action = .err }, cb, null, null);
}

/// access_or_die(): true if readable; dies on unexpected errors.
fn accessOrDie(path: []const u8, eacces_ok: bool) bool {
    if (os.access(path, 4)) return true;
    const e = os.errno();
    if (e == os.ENOENT or e == os.ENOTDIR) return false;
    if (eacces_ok and e == os.EACCES) return false;
    util.die("unable to access '{s}': {s}", .{ path, os.strErr(e) });
}

fn accessOrWarn(path: []const u8) bool {
    if (os.access(path, 4)) return true;
    const e = os.errno();
    if (e != os.ENOENT and e != os.ENOTDIR) util.warn("unable to access '{s}': {s}", .{ path, os.strErr(e) });
    return false;
}

fn envBool(name: []const u8, def: bool) bool {
    const v = os.getenv(name) orelse return def;
    return configBool(name, v);
}

/// git_system_config()
pub fn systemConfigPath() []const u8 {
    if (os.getenv("GIT_CONFIG_SYSTEM")) |p| return p;
    return "/etc/gitconfig";
}

/// git_config_system(): whether the system config should be read.
pub fn useSystemConfig() bool {
    return !envBool("GIT_CONFIG_NOSYSTEM", false);
}

pub const GlobalPaths = struct { user: ?[]const u8, xdg: ?[]const u8 };

/// git_global_config_paths()
pub fn globalConfigPaths() GlobalPaths {
    if (os.getenv("GIT_CONFIG_GLOBAL")) |g| return .{ .user = g, .xdg = null };
    return .{ .user = interpolatePath("~/.gitconfig", false), .xdg = xdgConfigHome("config") };
}

pub fn xdgConfigHome(file: []const u8) ?[]const u8 {
    if (os.getenv("XDG_CONFIG_HOME")) |x| {
        if (x.len > 0) return util.concat(&.{ x, "/git/", file });
    }
    const home = os.getenv("HOME") orelse return null;
    return util.concat(&.{ home, "/.config/git/", file });
}

/// git_global_config(): the file `git config --global` reads/writes.
pub fn globalConfigFile() ?[]const u8 {
    const g = globalConfigPaths();
    const user = g.user orelse return null;
    if (!accessOrWarn(user)) {
        if (g.xdg) |x| {
            if (accessOrWarn(x)) return x;
        }
    }
    return user;
}

/// do_git_config_sequence()
fn configSequence(opts: *const Options, cb: Callback) i32 {
    var ret: i32 = 0;
    const sys = systemConfigPath();
    if (useSystemConfig() and accessOrDie(sys, false)) ret += fromFile(cb, sys, .system, null, null);
    const g = globalConfigPaths();
    if (g.xdg) |x| {
        if (accessOrDie(x, true)) ret += fromFile(cb, x, .global, null, null);
    }
    if (g.user) |u| {
        if (accessOrDie(u, true)) ret += fromFile(cb, u, .global, null, null);
    }
    if (opts.common_dir) |cd| {
        const p = util.concat(&.{ cd, "/config" });
        if (accessOrDie(p, false)) ret += fromFile(cb, p, .local, null, null);
    }
    if (opts.worktree_config) |p| {
        if (accessOrDie(p, false)) ret += fromFile(cb, p, .worktree, null, null);
    }
    if (!opts.ignore_cmdline and fromParameters(cb) < 0) util.die("unable to parse command-line config", .{});
    return ret;
}

const IncludeData = struct {
    depth: u32 = 0,
    cb: Callback,
    opts: *const Options,
    spec: SourceSpec,
    remote_urls: ?std.ArrayList([]const u8) = null,
};

pub const ConfigKeyParts = struct { sub: ?[]const u8, key: []const u8 };

/// parse_config_key(): splits "<section>[.<sub>].<key>" if var starts
/// with "<section>.".
pub fn parseConfigKey(var_: []const u8, section: []const u8) ?ConfigKeyParts {
    const rest = util.skipPrefix(var_, section) orelse return null;
    if (rest.len == 0 or rest[0] != '.') return null;
    const r = rest[1..];
    const dot = std.mem.lastIndexOfScalar(u8, r, '.') orelse return .{ .sub = null, .key = r };
    return .{ .sub = r[0..dot], .key = r[dot + 1 ..] };
}

fn includeFn(ctx: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const KvInfo) i32 {
    const inc: *IncludeData = @ptrCast(@alignCast(ctx));
    var ret = inc.cb.call(key, value, kvi);
    if (ret < 0) return ret;
    if (util.eql(key, "include.path")) {
        ret = handlePathInclude(kvi, value, inc);
    } else if (parseConfigKey(key, "includeif")) |pk| {
        if (pk.sub) |cond| {
            if (includeConditionIsTrue(kvi, inc, cond) and util.eql(pk.key, "path")) {
                const old = inc.cb;
                if (inc.opts.unconditional_remote_url) inc.cb = .{ .f = forbidRemoteUrl, .ctx = inc };
                ret = handlePathInclude(kvi, value, inc);
                inc.cb = old;
            }
        }
    }
    return ret;
}

fn forbidRemoteUrl(_: *anyopaque, key: []const u8, _: ?[]const u8, _: *const KvInfo) i32 {
    if (parseConfigKey(key, "remote")) |pk| {
        if (pk.sub != null and util.eql(pk.key, "url"))
            util.die("remote URLs cannot be configured in file directly or indirectly included by includeIf.hasconfig:remote.*.url", .{});
    }
    return 0;
}

fn handlePathInclude(kvi: *const KvInfo, path0: ?[]const u8, inc: *IncludeData) i32 {
    const p0 = path0 orelse return errorNonbool("include.path");
    var path = interpolatePath(p0, false) orelse {
        util.err("could not expand include path '{s}'", .{p0});
        return -1;
    };
    if (path.len == 0 or path[0] != '/') {
        if (kvi.origin_type != .file) {
            util.err("relative config includes must come from files", .{});
            return -1;
        }
        const fname = kvi.filename.?;
        if (std.mem.lastIndexOfScalar(u8, fname, '/')) |sl| path = util.concat(&.{ fname[0 .. sl + 1], path });
    }
    var ret: i32 = 0;
    if (accessOrDie(path, false)) {
        inc.depth += 1;
        if (inc.depth > 10) util.die("exceeded maximum include depth ({d}) while including\n\t{s}\nfrom\n\t{s}\nThis might be due to circular includes.", .{ 10, path, kvi.filename orelse "the command line" });
        ret = fromFile(.{ .f = includeFn, .ctx = inc }, path, kvi.scope, null, null);
        inc.depth -= 1;
    }
    return ret;
}

fn addTrailingStarstar(p: []const u8) []const u8 {
    if (p.len > 0 and p[p.len - 1] == '/') return util.concat(&.{ p, "**" });
    return p;
}

/// strbuf_add_absolute_path()
pub fn absolutePath(path: []const u8) []const u8 {
    if (path.len > 0 and path[0] == '/') return path;
    const cwd = os.getcwd();
    var base: []const u8 = cwd;
    if (os.getenv("PWD")) |pwd| {
        if (pwd.len > 0 and pwd[0] == '/' and !util.eql(pwd, cwd)) {
            if (os.statPath(cwd)) |cs| {
                if (os.statPath(pwd)) |ps| {
                    if (cs.dev == ps.dev and cs.ino == ps.ino) base = pwd;
                }
            }
        }
    }
    if (base.len > 0 and base[base.len - 1] == '/') return util.concat(&.{ base, path });
    return util.concat(&.{ base, "/", path });
}

fn includeByPath(kvi: *const KvInfo, path: []const u8, cond: []const u8, icase: bool) bool {
    const wildmatch = @import("wildmatch.zig");
    var text: []const u8 = os.realPath(path) orelse absolutePath(path);
    // prepare_include_condition_pattern()
    var pat: []const u8 = interpolatePath(cond, true) orelse cond;
    var prefix: usize = 0;
    if (pat.len >= 2 and pat[0] == '.' and pat[1] == '/') {
        if (kvi.origin_type != .file) {
            util.err("relative config include conditionals must come from files", .{});
            return false;
        }
        const real = os.realPath(kvi.filename.?) orelse absolutePath(kvi.filename.?);
        const slash = std.mem.lastIndexOfScalar(u8, real, '/') orelse 0;
        pat = util.concat(&.{ real[0..slash], pat[1..] });
        prefix = slash + 1;
    } else if (pat.len == 0 or pat[0] != '/') {
        pat = util.concat(&.{ "**/", pat });
    }
    pat = addTrailingStarstar(pat);
    const flags: u32 = wildmatch.PATHNAME | (if (icase) wildmatch.CASEFOLD else 0);
    var tried_absolute = false;
    while (true) {
        if (prefix > 0) {
            if (text.len < prefix) return false;
            if (!icase and !std.mem.eql(u8, pat[0..prefix], text[0..prefix])) return false;
            if (icase and !std.ascii.eqlIgnoreCase(pat[0..prefix], text[0..prefix])) return false;
        }
        if (wildmatch.match(pat[prefix..], text[prefix..], flags)) return true;
        if (tried_absolute) return false;
        text = absolutePath(path);
        tried_absolute = true;
    }
}

fn addRemoteUrl(ctx: *anyopaque, key: []const u8, value: ?[]const u8, _: *const KvInfo) i32 {
    const list: *std.ArrayList([]const u8) = @ptrCast(@alignCast(ctx));
    if (parseConfigKey(key, "remote")) |pk| {
        if (pk.sub != null and util.eql(pk.key, "url")) {
            if (value) |v| list.append(gpa, util.dupe(v)) catch util.oom();
        }
    }
    return 0;
}

fn includeConditionIsTrue(kvi: *const KvInfo, inc: *IncludeData, cond: []const u8) bool {
    const opts = inc.opts;
    const wildmatch = @import("wildmatch.zig");
    if (util.skipPrefix(cond, "gitdir:")) |c| {
        const gd = opts.git_dir orelse return false;
        return includeByPath(kvi, gd, c, false);
    } else if (util.skipPrefix(cond, "gitdir/i:")) |c| {
        const gd = opts.git_dir orelse return false;
        return includeByPath(kvi, gd, c, true);
    } else if (util.skipPrefix(cond, "onbranch:")) |c| {
        const br = opts.branch orelse return false;
        return wildmatch.match(addTrailingStarstar(c), br, wildmatch.PATHNAME);
    } else if (util.skipPrefix(cond, "hasconfig:remote.*.url:")) |c| {
        if (opts.unconditional_remote_url) return true;
        if (inc.remote_urls == null) {
            var o2 = opts.*;
            o2.unconditional_remote_url = true;
            var urls: std.ArrayList([]const u8) = .empty;
            _ = configWithOptions(inc.spec, .{ .f = addRemoteUrl, .ctx = &urls }, &o2);
            inc.remote_urls = urls;
        }
        for (inc.remote_urls.?.items) |u| {
            if (wildmatch.match(c, u, wildmatch.PATHNAME)) return true;
        }
        return false;
    }
    return false;
}

/// config_with_options(). File/stdin/blob sources get the `command` scope.
pub fn configWithOptions(spec: SourceSpec, cb0: Callback, opts: *const Options) i32 {
    return configWithOptionsScoped(spec, .command, cb0, opts);
}

/// Like configWithOptions, but with an explicit scope for file/stdin/blob.
pub fn configWithOptionsScoped(spec: SourceSpec, scope: Scope, cb0: Callback, opts: *const Options) i32 {
    var inc = IncludeData{ .cb = cb0, .opts = opts, .spec = spec };
    var cb = cb0;
    if (opts.respect_includes) cb = .{ .f = includeFn, .ctx = &inc };
    return switch (spec) {
        .stdin => fromStdin(cb, scope),
        .file => |f| fromFile(cb, f, scope, null, null),
        .blob => |b| fromBlobRef(cb, b, scope),
        .sequence => configSequence(opts, cb),
    };
}

/// Options describing the current repository (for the sequence and for
/// conditional includes).
pub fn repoOptions() Options {
    const repo_mod = @import("repo.zig");
    var o = Options{};
    if (repo_mod.repo_) |r| {
        o.git_dir = r.git_dir;
        o.common_dir = r.common_dir;
        if (r.worktree_config) o.worktree_config = r.gitPath("config.worktree");
        o.work_tree = r.work_tree;
        o.branch = repo_mod.currentBranchForConfig();
    }
    return o;
}

// ---------------------------------------------------------------------------
// command line config

fn sqDequoteStep(s: []const u8, pos: *usize, next_null: *bool) ?[]u8 {
    var i = pos.*;
    if (i >= s.len or s[i] != '\'') return null;
    var b: util.Buf = .empty;
    while (true) {
        i += 1;
        if (i >= s.len) return null;
        const ch = s[i];
        if (ch != '\'') {
            util.bufByte(&b, ch);
            continue;
        }
        // stepped out of sq
        i += 1;
        if (i >= s.len) {
            next_null.* = true;
            pos.* = i;
            return b.items;
        }
        if (s[i] == '\\' and i + 2 < s.len and (s[i + 1] == '\'' or s[i + 1] == '!') and s[i + 2] == '\'') {
            util.bufByte(&b, s[i + 1]);
            i += 2; // now at the reopening quote
            continue;
        }
        next_null.* = false;
        pos.* = i;
        return b.items;
    }
}

fn parsePair(key: []const u8, value: ?[]const u8, cb: Callback) i32 {
    if (key.len == 0) {
        util.err("empty config key", .{});
        return -1;
    }
    const ck = switch (parseKeyFull(key, false)) {
        .ok => |k| k.key,
        .err => return -1,
    };
    const kvi = kvi_param;
    return if (cb.call(ck, value, &kvi) < 0) -1 else 0;
}

/// git_config_parse_parameter(): "key=value" or "key"
pub fn parseParameter(text: []const u8, cb: Callback) i32 {
    var key: []const u8 = text;
    var value: ?[]const u8 = null;
    if (std.mem.indexOfScalar(u8, text, '=')) |eq| {
        key = text[0..eq];
        value = text[eq + 1 ..];
    }
    if (key.len == 0) {
        util.err("bogus config parameter: {s}", .{text});
        return -1;
    }
    return parsePair(key, value, cb);
}

fn parseEnvList(env: []const u8, cb: Callback) i32 {
    var pos: usize = 0;
    while (pos < env.len) {
        var next_null = false;
        const key = sqDequoteStep(env, &pos, &next_null) orelse {
            util.err("bogus format in GIT_CONFIG_PARAMETERS", .{});
            return -1;
        };
        if (next_null or isSpace(env[pos])) {
            if (parseParameter(key, cb) < 0) return -1;
        } else if (env[pos] == '=') {
            pos += 1;
            var value: ?[]const u8 = null;
            if (pos < env.len and env[pos] == '\'') {
                var nn = false;
                const v = sqDequoteStep(env, &pos, &nn);
                if (v == null or (!nn and !isSpace(env[pos]))) {
                    util.err("bogus format in GIT_CONFIG_PARAMETERS", .{});
                    return -1;
                }
                value = v;
                next_null = nn;
            } else if (pos >= env.len or isSpace(env[pos])) {
                value = null;
                if (pos >= env.len) next_null = true;
            } else {
                util.err("bogus format in GIT_CONFIG_PARAMETERS", .{});
                return -1;
            }
            if (parsePair(key, value, cb) < 0) return -1;
        } else {
            util.err("bogus format in GIT_CONFIG_PARAMETERS", .{});
            return -1;
        }
        if (next_null) break;
        while (pos < env.len and isSpace(env[pos])) pos += 1;
    }
    return 0;
}

/// git_config_from_parameters(): GIT_CONFIG_COUNT/KEY_n/VALUE_n, then
/// GIT_CONFIG_PARAMETERS. Returns <0 on error (messages already printed).
pub fn fromParameters(cb: Callback) i32 {
    if (os.getenv("GIT_CONFIG_COUNT")) |env| {
        var i: usize = 0;
        while (i < env.len and (isSpace(env[i]) or env[i] == 11 or env[i] == 12)) i += 1;
        var neg = false;
        if (i < env.len and (env[i] == '+' or env[i] == '-')) {
            neg = env[i] == '-';
            i += 1;
        }
        var count: u64 = 0;
        var overflow = false;
        const dstart = i;
        while (i < env.len and std.ascii.isDigit(env[i])) : (i += 1) {
            const m = @mulWithOverflow(count, 10);
            const a = @addWithOverflow(m[0], env[i] - '0');
            if (m[1] != 0 or a[1] != 0) overflow = true;
            count = a[0];
        }
        if (i == dstart) i = 0; // no digits: endp = start
        if (i < env.len) {
            util.err("bogus count in GIT_CONFIG_COUNT", .{});
            return -1;
        }
        if (neg and count != 0) overflow = true;
        if (overflow or count > std.math.maxInt(i32)) {
            util.err("too many entries in GIT_CONFIG_COUNT", .{});
            return -1;
        }
        var n: u64 = 0;
        while (n < count) : (n += 1) {
            const kname = util.fmt("GIT_CONFIG_KEY_{d}", .{n});
            const key = os.getenv(kname) orelse {
                util.err("missing config key {s}", .{kname});
                return -1;
            };
            const vname = util.fmt("GIT_CONFIG_VALUE_{d}", .{n});
            const value = os.getenv(vname) orelse {
                util.err("missing config value {s}", .{vname});
                return -1;
            };
            if (parsePair(key, value, cb) < 0) return -1;
        }
    }
    if (os.getenv("GIT_CONFIG_PARAMETERS")) |env| {
        if (parseEnvList(env, cb) < 0) return -1;
    }
    return 0;
}

// ---------------------------------------------------------------------------
// keys

pub const KeyError = struct { code: i32, msg: []const u8 };
pub const ParsedKey = struct { key: []const u8, baselen: usize };
pub const KeyResult = union(enum) { ok: ParsedKey, err: KeyError };

/// git_config_parse_key(). Error codes: 1 = invalid key, 2 = no section
/// or name. Prints "error: ..." unless quiet.
pub fn parseKeyFull(key: []const u8, quiet: bool) KeyResult {
    const r = parseKeyImpl(key);
    switch (r) {
        .err => |e| if (!quiet) util.err("{s}", .{e.msg}),
        .ok => {},
    }
    return r;
}

fn parseKeyImpl(key: []const u8) KeyResult {
    const last_dot = std.mem.lastIndexOfScalar(u8, key, '.');
    if (last_dot == null or last_dot.? == 0)
        return .{ .err = .{ .code = 2, .msg = util.fmt("key does not contain a section: {s}", .{key}) } };
    const baselen = last_dot.?;
    if (baselen + 1 >= key.len)
        return .{ .err = .{ .code = 2, .msg = util.fmt("key does not contain variable name: {s}", .{key}) } };
    const out = util.dupe(key);
    var dot = false;
    for (key, 0..) |ch0, i| {
        var ch = ch0;
        if (ch == '.') dot = true;
        if (!dot or i > baselen) {
            if (!isKeyChar(ch) or (i == baselen + 1 and !std.ascii.isAlphabetic(ch)))
                return .{ .err = .{ .code = 1, .msg = util.fmt("invalid key: {s}", .{key}) } };
            ch = std.ascii.toLower(ch);
        } else if (ch == '\n') {
            return .{ .err = .{ .code = 1, .msg = util.fmt("invalid key (newline): {s}", .{key}) } };
        }
        out[i] = ch;
    }
    return .{ .ok = .{ .key = out, .baselen = baselen } };
}

/// git_config_key_is_valid()
pub fn keyIsValid(key: []const u8) bool {
    return parseKeyImpl(key) == .ok;
}

/// Canonicalize a key: lowercase section and name; keep subsection.
pub fn canonicalKey(key: []const u8) ?[]const u8 {
    const first = std.mem.indexOfScalar(u8, key, '.') orelse return null;
    const last = std.mem.lastIndexOfScalar(u8, key, '.').?;
    const r = util.dupe(key);
    for (r[0..first]) |*ch| ch.* = std.ascii.toLower(ch.*);
    for (r[last + 1 ..]) |*ch| ch.* = std.ascii.toLower(ch.*);
    return r;
}

/// Validate key per git_config_parse_key. Returns canonical or error message.
pub fn parseKey(key: []const u8) union(enum) { ok: []const u8, err: []const u8 } {
    return switch (parseKeyImpl(key)) {
        .ok => |k| .{ .ok = k.key },
        .err => |e| .{ .err = e.msg },
    };
}

pub fn canonicalSection(s: []const u8) []const u8 {
    const first = std.mem.indexOfScalar(u8, s, '.') orelse return util.lower(s);
    const r = util.dupe(s);
    for (r[0..first]) |*ch| ch.* = std.ascii.toLower(ch.*);
    return r;
}

// ---------------------------------------------------------------------------
// typed values

pub const NumError = enum { invalid_unit, out_of_range };
pub const NumResult = union(enum) { ok: i64, err: NumError };

/// git_parse_signed(): strtoimax(base 0) + k/m/g unit, bounded by max.
pub fn parseSigned(value: ?[]const u8, max: i64) NumResult {
    const v = value orelse return .{ .err = .invalid_unit };
    if (v.len == 0) return .{ .err = .invalid_unit };
    var i: usize = 0;
    while (i < v.len and (isSpace(v[i]) or v[i] == 11 or v[i] == 12)) i += 1;
    var neg = false;
    if (i < v.len and (v[i] == '+' or v[i] == '-')) {
        neg = v[i] == '-';
        i += 1;
    }
    var base: u8 = 10;
    if (i + 2 < v.len and v[i] == '0' and (v[i + 1] == 'x' or v[i + 1] == 'X') and std.ascii.isHex(v[i + 2])) {
        base = 16;
        i += 2;
    } else if (i < v.len and v[i] == '0') {
        base = 8;
    }
    const dstart = i;
    var mag: u128 = 0;
    var overflow = false;
    while (i < v.len) : (i += 1) {
        const d: u8 = switch (v[i]) {
            '0'...'9' => v[i] - '0',
            'a'...'z' => v[i] - 'a' + 10,
            'A'...'Z' => v[i] - 'A' + 10,
            else => 255,
        };
        if (d >= base) break;
        mag = mag * base + d;
        if (mag > (@as(u128, 1) << 64)) {
            overflow = true;
            mag = @as(u128, 1) << 64;
        }
    }
    if (i == dstart) return .{ .err = .invalid_unit };
    const limit: u128 = if (neg) @as(u128, 1) << 63 else (@as(u128, 1) << 63) - 1;
    if (overflow or mag > limit) return .{ .err = .out_of_range };
    const val: i64 = if (neg) @intCast(-@as(i128, @intCast(mag))) else @intCast(mag);
    const unit = v[i..];
    var factor: i64 = 0;
    if (unit.len == 0) {
        factor = 1;
    } else if (std.ascii.eqlIgnoreCase(unit, "k")) {
        factor = 1024;
    } else if (std.ascii.eqlIgnoreCase(unit, "m")) {
        factor = 1024 * 1024;
    } else if (std.ascii.eqlIgnoreCase(unit, "g")) {
        factor = 1024 * 1024 * 1024;
    }
    if (factor == 0) return .{ .err = .invalid_unit };
    if ((val < 0 and @divTrunc(-max - 1, factor) > val) or (val > 0 and @divTrunc(max, factor) < val))
        return .{ .err = .out_of_range };
    return .{ .ok = val * factor };
}

pub fn dieBadNumber(name: []const u8, value: ?[]const u8, kvi: *const KvInfo, e: NumError) noreturn {
    const et = if (e == .out_of_range) "out of range" else "invalid unit";
    const v = value orelse "";
    const fname = kvi.filename orelse util.die("bad numeric config value '{s}' for '{s}': {s}", .{ v, name, et });
    switch (kvi.origin_type) {
        .blob => util.die("bad numeric config value '{s}' for '{s}' in blob {s}: {s}", .{ v, name, fname, et }),
        .file => util.die("bad numeric config value '{s}' for '{s}' in file {s}: {s}", .{ v, name, fname, et }),
        .stdin => util.die("bad numeric config value '{s}' for '{s}' in standard input: {s}", .{ v, name, et }),
        .cmdline => util.die("bad numeric config value '{s}' for '{s}' in command line {s}: {s}", .{ v, name, fname, et }),
    }
}

/// git_config_int(): 32-bit, dies on error
pub fn configInt(name: []const u8, value: ?[]const u8, kvi: *const KvInfo) i32 {
    return switch (parseSigned(value, std.math.maxInt(i32))) {
        .ok => |n| @intCast(n),
        .err => |e| dieBadNumber(name, value, kvi, e),
    };
}

/// git_config_int64()
pub fn configInt64(name: []const u8, value: ?[]const u8, kvi: *const KvInfo) i64 {
    return switch (parseSigned(value, std.math.maxInt(i64))) {
        .ok => |n| n,
        .err => |e| dieBadNumber(name, value, kvi, e),
    };
}

/// git_parse_maybe_bool_text(): 1, 0 or -1
pub fn parseMaybeBoolText(value: ?[]const u8) i32 {
    const v = value orelse return 1;
    if (v.len == 0) return 0;
    if (std.ascii.eqlIgnoreCase(v, "true") or std.ascii.eqlIgnoreCase(v, "yes") or std.ascii.eqlIgnoreCase(v, "on")) return 1;
    if (std.ascii.eqlIgnoreCase(v, "false") or std.ascii.eqlIgnoreCase(v, "no") or std.ascii.eqlIgnoreCase(v, "off")) return 0;
    return -1;
}

/// git_parse_maybe_bool(): 1, 0 or -1
pub fn parseMaybeBool(value: ?[]const u8) i32 {
    const t = parseMaybeBoolText(value);
    if (t >= 0) return t;
    return switch (parseSigned(value, std.math.maxInt(i32))) {
        .ok => |n| @intFromBool(n != 0),
        .err => -1,
    };
}

/// git_config_bool(): dies on a non-boolean value
pub fn configBool(name: []const u8, value: ?[]const u8) bool {
    const v = parseMaybeBool(value);
    if (v < 0) util.die("bad boolean config value '{s}' for '{s}'", .{ value orelse "", name });
    return v != 0;
}

/// git_config_bool_or_int()
pub fn configBoolOrInt(name: []const u8, value: ?[]const u8, kvi: *const KvInfo, is_bool: *bool) i32 {
    const v = parseMaybeBoolText(value);
    if (v >= 0) {
        is_bool.* = true;
        return v;
    }
    is_bool.* = false;
    return configInt(name, value, kvi);
}

pub fn parseBool(v: []const u8) ?bool {
    const r = parseMaybeBool(v);
    if (r < 0) return null;
    return r != 0;
}

pub fn parseInt(v: []const u8) ?i64 {
    return switch (parseSigned(v, std.math.maxInt(i64))) {
        .ok => |n| n,
        .err => null,
    };
}

/// config_error_nonbool()
pub fn errorNonbool(var_: []const u8) i32 {
    util.err("missing value for '{s}'", .{var_});
    return -1;
}

const Passwd = extern struct {
    pw_name: ?[*:0]const u8,
    pw_passwd: ?[*:0]const u8,
    pw_uid: u32,
    pw_gid: u32,
    pw_gecos: ?[*:0]const u8,
    pw_dir: ?[*:0]const u8,
    pw_shell: ?[*:0]const u8,
};
extern "c" fn getpwnam(name: [*:0]const u8) ?*Passwd;

/// system_path(""): the installation prefix (parent of the bin directory).
pub fn systemPrefix() []const u8 {
    const exe = os.readLink("/proc/self/exe") orelse return "/usr/local";
    const bin = util.dirname(exe);
    const pre = util.dirname(bin);
    return if (pre.len == 0) "/" else pre;
}

/// interpolate_path(): expands "~/", "~user/" and "%(prefix)/".
pub fn interpolatePath(path: []const u8, real_home: bool) ?[]const u8 {
    if (util.skipPrefix(path, "%(prefix)/")) |rest| return util.concat(&.{ systemPrefix(), "/", rest });
    if (path.len > 0 and path[0] == '~') {
        const slash = std.mem.indexOfScalar(u8, path, '/') orelse path.len;
        const username = path[1..slash];
        var home: []const u8 = undefined;
        if (username.len == 0) {
            const h = os.getenv("HOME") orelse return null;
            home = if (real_home) (os.realPath(h) orelse h) else h;
        } else {
            const pw = getpwnam(os.z(username)) orelse return null;
            home = util.dupe(std.mem.span(pw.pw_dir orelse return null));
        }
        return util.concat(&.{ home, path[slash..] });
    }
    return path;
}

pub fn expandPath(v: []const u8) []const u8 {
    return interpolatePath(v, false) orelse v;
}

pub const PathResult = union(enum) { ok: ?[]const u8, err };

/// git_config_pathname(): err for a missing value; ok(null) for a missing
/// ":(optional)" path.
pub fn configPathname(var_: []const u8, value: ?[]const u8) PathResult {
    const v0 = value orelse {
        _ = errorNonbool(var_);
        return .err;
    };
    var v = v0;
    var optional = false;
    if (util.skipPrefix(v, ":(optional)")) |r| {
        v = r;
        optional = true;
    }
    const p = interpolatePath(v, false) orelse util.die("failed to expand user dir in: '{s}'", .{v});
    if (optional and os.lstatPath(p) == null and os.errno() == os.ENOENT) return .{ .ok = null };
    return .{ .ok = p };
}

// ---------------------------------------------------------------------------
// The flat Config store

pub const Config = struct {
    entries: std.ArrayList(Entry) = .empty,
    git_dir: ?[]const u8 = null,
    current_branch: ?[]const u8 = null,

    pub fn add(self: *Config, e: Entry) void {
        self.entries.append(gpa, e) catch util.oom();
    }

    pub fn get(self: *const Config, key: []const u8) ?[]const u8 {
        const e = self.getEntry(key) orelse return null;
        return e.value orelse "";
    }

    /// Returns the entry (to distinguish "no value" from "").
    pub fn getEntry(self: *const Config, key: []const u8) ?Entry {
        const k = canonicalKey(key) orelse return null;
        var i = self.entries.items.len;
        while (i > 0) {
            i -= 1;
            const e = self.entries.items[i];
            if (util.eql(e.key, k)) return e;
        }
        return null;
    }

    pub fn getAll(self: *const Config, key: []const u8) [][]const u8 {
        var l: std.ArrayList([]const u8) = .empty;
        const k = canonicalKey(key) orelse return l.items;
        for (self.entries.items) |e| {
            if (util.eql(e.key, k)) l.append(gpa, e.value orelse "") catch util.oom();
        }
        return l.items;
    }

    pub fn getBool(self: *const Config, key: []const u8) ?bool {
        const e = self.getEntry(key) orelse return null;
        return configBool(e.key, e.value);
    }

    pub fn getBoolDefault(self: *const Config, key: []const u8, def: bool) bool {
        return self.getBool(key) orelse def;
    }

    pub fn getInt(self: *const Config, key: []const u8) ?i64 {
        const e = self.getEntry(key) orelse return null;
        const kv = e.kvi();
        return configInt64(e.key, e.value, &kv);
    }

    pub fn includeFile(self: *Config, ctx: *LoadCtx, path: []const u8) void {
        includeFileImpl(self, ctx, path);
    }

    pub fn includeCondition(self: *Config, ctx: *LoadCtx, cond: []const u8) bool {
        var opts = self.options();
        var sc = StoreCtx{ .cfg = self };
        var inc = IncludeData{ .cb = .{ .f = storeFn, .ctx = &sc }, .opts = &opts, .spec = .{ .file = ctx.file }, .depth = ctx.depth };
        const kvi = KvInfo{ .filename = ctx.file, .origin_type = ctx.origin_type, .scope = ctx.scope, .linenr = 0 };
        return includeConditionIsTrue(&kvi, &inc, cond);
    }

    /// git_config_pathname(): expanded path, or null when unset (or an
    /// optional path that does not exist).
    pub fn getPath(self: *const Config, key: []const u8) ?[]const u8 {
        const e = self.getEntry(key) orelse return null;
        return switch (configPathname(e.key, e.value)) {
            .ok => |p| p,
            .err => util.die("bad config variable '{s}'", .{e.key}),
        };
    }

    fn options(self: *const Config) Options {
        var o = Options{};
        if (self.git_dir) |g| {
            o = repoOptions();
            o.git_dir = g;
            if (self.current_branch) |b| o.branch = b;
        }
        return o;
    }
};

pub const LoadCtx = struct {
    cfg: *Config,
    file: []const u8,
    origin_type: OriginType,
    scope: Scope,
    depth: u32,
};

const StoreCtx = struct { cfg: *Config };

fn storeFn(ctx: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const KvInfo) i32 {
    const sc: *StoreCtx = @ptrCast(@alignCast(ctx));
    sc.cfg.add(.{
        .key = util.dupe(key),
        .value = if (value) |v| util.dupe(v) else null,
        .origin = kvi.filename orelse "",
        .origin_type = kvi.origin_type,
        .scope = kvi.scope,
        .line = if (kvi.linenr < 0) 0 else @intCast(kvi.linenr),
    });
    return 0;
}

/// A Callback that appends every entry to cfg.
pub fn storeCallback(sc: *StoreCtx) Callback {
    return .{ .f = storeFn, .ctx = sc };
}

/// Read one config file (with includes) into cfg. Returns false if the
/// file does not exist / cannot be read. Dies on syntax errors.
pub fn readFileInto(cfg: *Config, path: []const u8, scope: Scope) bool {
    const data = os.readFile(path) orelse return false;
    var opts = cfg.options();
    var sc = StoreCtx{ .cfg = cfg };
    var inc = IncludeData{ .cb = .{ .f = storeFn, .ctx = &sc }, .opts = &opts, .spec = .{ .file = path } };
    _ = parseSource(.{ .data = data, .origin_type = .file, .name = path, .scope = scope }, .{ .f = includeFn, .ctx = &inc }, null, null);
    return true;
}

pub fn includeFileImpl(cfg: *Config, ctx: *LoadCtx, path: []const u8) void {
    var opts = cfg.options();
    var sc = StoreCtx{ .cfg = cfg };
    var inc = IncludeData{ .cb = .{ .f = storeFn, .ctx = &sc }, .opts = &opts, .spec = .{ .file = ctx.file }, .depth = ctx.depth };
    const kvi = KvInfo{ .filename = ctx.file, .origin_type = ctx.origin_type, .scope = ctx.scope, .linenr = 0 };
    _ = handlePathInclude(&kvi, path, &inc);
}

/// Add one "key=value" / "key" command line item (git -c) to cfg.
pub fn addCmdline(cfg: *Config, kv: []const u8) void {
    var sc = StoreCtx{ .cfg = cfg };
    if (parseParameter(kv, .{ .f = storeFn, .ctx = &sc }) < 0) util.die("unable to parse command-line config", .{});
}

/// Parse GIT_CONFIG_PARAMETERS ('key=value' 'key2'='value2' ...) into cfg
/// (with includes). Dies like git on malformed input.
pub fn parseConfigParameters(cfg: *Config, env: []const u8) void {
    var opts = cfg.options();
    var sc = StoreCtx{ .cfg = cfg };
    var inc = IncludeData{ .cb = .{ .f = storeFn, .ctx = &sc }, .opts = &opts, .spec = .sequence };
    if (parseEnvList(env, .{ .f = includeFn, .ctx = &inc }) < 0) util.die("unable to parse command-line config", .{});
}

/// Faithful git_config_from_parameters() into cfg (GIT_CONFIG_COUNT and
/// GIT_CONFIG_PARAMETERS, with includes); dies on errors.
pub fn loadCmdline(cfg: *Config) void {
    var opts = cfg.options();
    var sc = StoreCtx{ .cfg = cfg };
    var inc = IncludeData{ .cb = .{ .f = storeFn, .ctx = &sc }, .opts = &opts, .spec = .sequence };
    if (fromParameters(.{ .f = includeFn, .ctx = &inc }) < 0) util.die("unable to parse command-line config", .{});
}

// ---------------------------------------------------------------------------
// Writing

fn needsQuoting(v: []const u8) bool {
    if (v.len == 0) return false;
    if (v[0] == ' ' or v[v.len - 1] == ' ') return true;
    for (v) |ch| {
        if (ch == ';' or ch == '#' or ch == '\r') return true;
    }
    return false;
}

/// Quote a value the way write_pair() does.
pub fn formatValue(v: []const u8) []const u8 {
    var b: util.Buf = .empty;
    const q = needsQuoting(v);
    if (q) util.bufByte(&b, '"');
    for (v) |ch| {
        switch (ch) {
            '\n' => util.bufAppend(&b, "\\n"),
            '\t' => util.bufAppend(&b, "\\t"),
            '"' => util.bufAppend(&b, "\\\""),
            '\\' => util.bufAppend(&b, "\\\\"),
            else => util.bufByte(&b, ch),
        }
    }
    if (q) util.bufByte(&b, '"');
    return b.items;
}

/// store_create_section()
fn createSection(b: *util.Buf, key: []const u8, baselen: usize) void {
    if (std.mem.indexOfScalar(u8, key[0..baselen], '.')) |dot| {
        util.bufByte(b, '[');
        util.bufAppend(b, key[0..dot]);
        util.bufAppend(b, " \"");
        for (key[dot + 1 .. baselen]) |ch| {
            if (ch == '"' or ch == '\\') util.bufByte(b, '\\');
            util.bufByte(b, ch);
        }
        util.bufAppend(b, "\"]\n");
    } else {
        util.bufByte(b, '[');
        util.bufAppend(b, key[0..baselen]);
        util.bufAppend(b, "]\n");
    }
}

/// write_pair()
fn writePair(b: *util.Buf, key: []const u8, baselen: usize, value: []const u8, comment: ?[]const u8) void {
    const quote: []const u8 = if (needsQuoting(value)) "\"" else "";
    util.bufByte(b, '\t');
    util.bufAppend(b, key[baselen + 1 ..]);
    util.bufAppend(b, " = ");
    util.bufAppend(b, quote);
    for (value) |ch| {
        switch (ch) {
            '\n' => util.bufAppend(b, "\\n"),
            '\t' => util.bufAppend(b, "\\t"),
            '"', '\\' => {
                util.bufByte(b, '\\');
                util.bufByte(b, ch);
            },
            else => util.bufByte(b, ch),
        }
    }
    util.bufAppend(b, quote);
    if (comment) |c| util.bufAppend(b, c);
    util.bufByte(b, '\n');
}

/// Follow symlinks like the lockfile code does (so the target is updated).
fn resolveSymlinks(path: []const u8) []const u8 {
    var p: []const u8 = path;
    var depth: usize = 0;
    while (depth < 5) : (depth += 1) {
        const st = os.lstatPath(p) orelse break;
        if (!st.isLnk()) break;
        const target = os.readLink(p) orelse break;
        if (target.len > 0 and target[0] == '/') {
            p = target;
        } else if (std.mem.lastIndexOfScalar(u8, p, '/')) |sl| {
            p = util.concat(&.{ p[0 .. sl + 1], target });
        } else {
            p = target;
        }
    }
    return p;
}

pub const ValuePattern = union(enum) {
    /// no pattern: every value matches
    any,
    /// CONFIG_REGEX_NONE: never matches (used for --add)
    none,
    pattern: []const u8,
};

pub const SetFlags = struct {
    fixed_value: bool = false,
    multi_replace: bool = false,
};

// return codes (config.h)
pub const CONFIG_INVALID_KEY: i32 = 1;
pub const CONFIG_NO_SECTION_OR_NAME: i32 = 2;
pub const CONFIG_INVALID_FILE: i32 = 3;
pub const CONFIG_NO_WRITE: i32 = 4;
pub const CONFIG_NOTHING_SET: i32 = 5;
pub const CONFIG_INVALID_PATTERN: i32 = 6;
pub const CONFIG_NO_LOCK: i32 = -1;

const Parsed = struct { begin: usize, end: usize, t: EventType, is_keys_section: bool = false };

const Store = struct {
    key: []const u8,
    baselen: usize,
    fixed_value: ?[]const u8 = null,
    regex: ?@import("regex.zig").Regex = null,
    has_pattern: bool = false,
    never: bool = false,
    do_not_match: bool = false,
    multi_replace: bool = false,
    parsed: std.ArrayList(Parsed) = .empty,
    seen: std.ArrayList(usize) = .empty,
    seen_nr: usize = 0,
    section_seen: bool = false,
    key_seen: bool = false,
    is_keys_section: bool = false,

    fn setSeen(self: *Store, idx: usize, v: usize) void {
        while (self.seen.items.len <= idx) self.seen.append(gpa, 0) catch util.oom();
        self.seen.items[idx] = v;
    }

    fn parsedAt(self: *Store, i: usize) Parsed {
        if (i < self.parsed.items.len) return self.parsed.items[i];
        return .{ .begin = 0, .end = 0, .t = .eof };
    }

    fn matches(self: *Store, key: []const u8, value: ?[]const u8) bool {
        if (!util.eql(key, self.key)) return false;
        if (self.fixed_value) |fv| {
            if (value) |v| return util.eql(fv, v);
        }
        if (!self.has_pattern) return true;
        if (self.never) return false;
        const m = if (value) |v| self.regex.?.isMatch(v) else false;
        return self.do_not_match != m;
    }
};

fn storeAux(ctx: *anyopaque, key: []const u8, value: ?[]const u8, _: *const KvInfo) i32 {
    const s: *Store = @ptrCast(@alignCast(ctx));
    if (s.key_seen) {
        if (s.matches(key, value)) {
            if (s.seen_nr == 1 and !s.multi_replace) util.warn("{s} has multiple values", .{key});
            s.setSeen(s.seen_nr, s.parsed.items.len);
            s.seen_nr += 1;
        }
    } else if (s.is_keys_section) {
        s.setSeen(s.seen_nr, s.parsed.items.len);
        s.section_seen = true;
        if (s.matches(key, value)) {
            s.seen_nr += 1;
            s.key_seen = true;
        }
    }
    return 0;
}

fn storeAuxEvent(ctx: *anyopaque, t: EventType, begin: usize, end: usize, p: *Parser) i32 {
    const s: *Store = @ptrCast(@alignCast(ctx));
    var ev = Parsed{ .begin = begin, .end = end, .t = t };
    if (t == .section) {
        const v = p.var_.items;
        if (v.len < 2 or v[v.len - 1] != '.') {
            util.err("invalid section name '{s}'", .{v});
            return -1;
        }
        // compare the first baselen bytes of var with the key
        const n = @min(s.baselen, v.len);
        var same = n == s.baselen;
        if (same) {
            same = if (p.subsection_case_sensitive)
                std.ascii.eqlIgnoreCase(v[0..n], s.key[0..n])
            else
                std.mem.eql(u8, v[0..n], s.key[0..n]);
        }
        s.is_keys_section = v.len - 1 == s.baselen and same;
        ev.is_keys_section = s.is_keys_section;
        if (s.is_keys_section) {
            s.section_seen = true;
            s.setSeen(s.seen_nr, s.parsed.items.len);
        }
    }
    s.parsed.append(gpa, ev) catch util.oom();
    return 0;
}

fn maybeRemoveSection(s: *Store, begin_offset: *usize, end_offset: *usize, seen_ptr: *usize) void {
    var section_seen = false;
    var seen = seen_ptr.*;
    // first, find the beginning of the section header
    var i: usize = s.seen.items[seen];
    while (i > 0) : (i -= 1) {
        const t = s.parsed.items[i - 1].t;
        if (t == .comment) return;
        if (t == .entry) {
            if (!section_seen) return;
            break;
        }
        if (t == .section) {
            if (!s.parsed.items[i - 1].is_keys_section) break;
            section_seen = true;
        }
    }
    // i is one past the event that stopped us (C uses i = seen; i > 0; i--
    // and the begin is parsed[i] after the loop)
    const begin = s.parsed.items[i].begin;
    // next, find the end of the section
    i = s.seen.items[seen] + 1;
    while (i < s.parsed.items.len) : (i += 1) {
        const t = s.parsed.items[i].t;
        if (t == .comment) return;
        if (t == .section) {
            if (s.parsed.items[i].is_keys_section) continue;
            break;
        }
        if (t == .entry) {
            seen += 1;
            if (seen < s.seen_nr and i == s.seen.items[seen]) continue;
            return;
        }
    }
    seen_ptr.* = seen;
    begin_offset.* = begin;
    if (i < s.parsed.items.len) {
        end_offset.* = s.parsed.items[i].begin;
    } else {
        end_offset.* = s.parsed.items[s.parsed.items.len - 1].end;
    }
}

fn lockFor(path: []const u8) ?*@import("lockfile.zig").Lock {
    const lockfile = @import("lockfile.zig");
    return switch (lockfile.tryLock(resolveSymlinks(path))) {
        .ok => |l| l,
        .err => |e| {
            os.setErrno(e);
            return null;
        },
    };
}

/// repo_config_set_multivar_in_file_gently(). value == null unsets.
/// `comment` must already be prepared (see prepareComment).
/// Returns 0 or one of the CONFIG_* codes (messages already printed).
pub fn setMultivarInFile(path: []const u8, key: []const u8, value: ?[]const u8, pattern: ValuePattern, comment: ?[]const u8, flags: SetFlags) i32 {
    const pk = switch (parseKeyFull(key, false)) {
        .ok => |k| k,
        .err => |e| return e.code,
    };
    var store = Store{ .key = pk.key, .baselen = pk.baselen, .multi_replace = flags.multi_replace };
    const lock = lockFor(path) orelse {
        util.err("could not lock config file {s}: {s}", .{ path, os.lastErr() });
        return CONFIG_NO_LOCK;
    };
    defer lock.rollback();
    var out: util.Buf = .empty;
    const contents_opt = os.readFile(path);
    if (contents_opt == null and os.errno() != os.EISDIR) {
        const e = os.errno();
        if (e != os.ENOENT) {
            util.err("opening {s}: {s}", .{ path, os.strErr(e) });
            return CONFIG_INVALID_FILE;
        }
        const v = value orelse return CONFIG_NOTHING_SET;
        createSection(&out, key, store.baselen);
        writePair(&out, key, store.baselen, v, comment);
    } else {
        const contents: []const u8 = contents_opt orelse "";
        switch (pattern) {
            .any => {},
            .none => {
                store.has_pattern = true;
                store.never = true;
            },
            .pattern => |p0| {
                if (flags.fixed_value) {
                    store.fixed_value = p0;
                } else {
                    var p = p0;
                    if (p.len > 0 and p[0] == '!') {
                        store.do_not_match = true;
                        p = p[1..];
                    }
                    switch (@import("regex.zig").Regex.compile(p, .{ .extended = true })) {
                        .ok => |r| store.regex = r,
                        .err => {
                            util.err("invalid pattern: {s}", .{p});
                            return CONFIG_INVALID_PATTERN;
                        },
                    }
                    store.has_pattern = true;
                }
            },
        }
        if (parseSource(.{ .data = contents, .origin_type = .file, .name = path, .scope = .unknown }, .{ .f = storeAux, .ctx = &store }, storeAuxEvent, &store) != 0) {
            util.err("invalid config file {s}", .{path});
            return CONFIG_INVALID_FILE;
        }
        if ((store.seen_nr == 0 and value == null) or (store.seen_nr > 1 and !store.multi_replace))
            return CONFIG_NOTHING_SET;
        if (os.statPath(path)) |st| {
            if (!os.chmod(lock.lock_path, st.mode & 0o7777)) {
                util.err("chmod on {s} failed: {s}", .{ lock.lock_path, os.lastErr() });
                return CONFIG_NO_WRITE;
            }
        }
        if (store.seen_nr == 0) {
            if (store.seen.items.len == 0) {
                const n = store.parsed.items.len;
                store.setSeen(0, n - @intFromBool(n != 0));
            }
            store.seen_nr = 1;
        }
        var copy_begin: usize = 0;
        var i: usize = 0;
        while (i < store.seen_nr) : (i += 1) {
            var copy_end: usize = undefined;
            var replace_end: usize = undefined;
            const j = store.seen.items[i];
            if (!store.key_seen) {
                copy_end = store.parsedAt(j).end;
                if (copy_end > 0 and copy_end < contents.len and contents[copy_end - 1] != '\n' and contents[copy_end] == '\n')
                    copy_end += 1;
                replace_end = copy_end;
            } else {
                replace_end = store.parsedAt(j).end;
                copy_end = store.parsedAt(j).begin;
                if (value == null) maybeRemoveSection(&store, &copy_end, &replace_end, &i);
                while (copy_end > 0) {
                    const ch = contents[copy_end - 1];
                    if (isSpace(ch) and ch != '\n') copy_end -= 1 else break;
                }
            }
            const new_line = copy_end > 0 and contents[copy_end - 1] != '\n';
            if (copy_end > copy_begin) {
                util.bufAppend(&out, contents[copy_begin..copy_end]);
                if (new_line) util.bufByte(&out, '\n');
            }
            copy_begin = replace_end;
        }
        if (value) |v| {
            if (!store.section_seen) createSection(&out, key, store.baselen);
            writePair(&out, key, store.baselen, v, comment);
        }
        if (copy_begin < contents.len) util.bufAppend(&out, contents[copy_begin..]);
    }
    os.writeAll(lock.fd, out.items) catch {
        util.err("failed to write new configuration file {s}", .{lock.lock_path});
        return CONFIG_NO_WRITE;
    };
    if (!lock.commit()) {
        util.err("could not write config file {s}: {s}", .{ path, os.lastErr() });
        return CONFIG_NO_WRITE;
    }
    return 0;
}

/// repo_config_set_in_file_gently()
pub fn setInFileGently(path: []const u8, key: []const u8, comment: ?[]const u8, value: ?[]const u8) i32 {
    return setMultivarInFile(path, key, value, .any, comment, .{});
}

pub const ValueMatcher = struct {
    regex: ?[]const u8 = null,
    fixed: bool = false,
    negate: bool = false,

    pub fn matches(self: ValueMatcher, v: ?[]const u8) bool {
        const pat = self.regex orelse return true;
        const val = v orelse "";
        var r: bool = undefined;
        if (self.fixed) {
            r = util.eql(pat, val);
        } else {
            const regex = @import("regex.zig");
            r = regex.matchSimple(pat, val, .{ .extended = true });
        }
        return if (self.negate) !r else r;
    }
};

pub const SetResult = enum { ok, multiple, invalid_file, lock_failed, nothing };

/// Set (or unset when value == null) key in file. If `all`, replace/remove
/// all matching. `append_` adds a new entry without touching existing ones.
pub fn setInFile(path: []const u8, key: []const u8, value: ?[]const u8, matcher: ValueMatcher, all: bool, append_: bool, comment: ?[]const u8) SetResult {
    var pat: ValuePattern = .any;
    if (append_) {
        pat = .none;
    } else if (matcher.regex) |r| {
        pat = .{ .pattern = if (matcher.negate and !matcher.fixed) util.concat(&.{ "!", r }) else r };
    }
    const cmt: ?[]const u8 = if (comment) |c| prepareComment(c) else null;
    const ret = setMultivarInFile(path, key, value, pat, cmt, .{ .fixed_value = matcher.fixed, .multi_replace = all });
    return switch (ret) {
        0 => .ok,
        CONFIG_NOTHING_SET => if (value == null) .nothing else .multiple,
        CONFIG_NO_LOCK, CONFIG_NO_WRITE => .lock_failed,
        else => .invalid_file,
    };
}

/// git_config_prepare_comment_string() (dies on multi-line comments)
pub fn prepareComment(comment: []const u8) []const u8 {
    if (std.mem.indexOfScalar(u8, comment, '\n') != null) util.die("no multi-line comment allowed: '{s}'", .{comment});
    var lb: usize = 0;
    while (lb < comment.len and (comment[lb] == ' ' or comment[lb] == '\t')) lb += 1;
    if (lb > 0 and lb < comment.len and comment[lb] == '#') return comment;
    if (comment.len > 0 and comment[0] == '#') return util.concat(&.{ " ", comment });
    return util.concat(&.{ " # ", comment });
}

fn sectionNameIsOk(name: []const u8) bool {
    if (name.len == 0) return false;
    for (name) |ch| {
        if (ch == '.') break;
        if (ch != '-' and !std.ascii.isAlphanumeric(ch)) return false;
    }
    return true;
}

fn at0(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

/// section_name_match(): offset past "]" and trailing whitespace, or 0.
fn sectionNameMatch(buf: []const u8, name: []const u8) usize {
    var i: usize = 0;
    var j: usize = 0;
    var dot = false;
    if (at0(buf, 0) != '[') return 0;
    i = 1;
    while (at0(buf, i) != 0 and at0(buf, i) != ']') : (i += 1) {
        if (!dot and isSpace(at0(buf, i))) {
            dot = true;
            const nc = at0(name, j);
            j += 1;
            if (nc != '.') break;
            i += 1;
            while (isSpace(at0(buf, i))) i += 1;
            if (at0(buf, i) != '"') break;
            continue;
        }
        if (at0(buf, i) == '\\' and dot) {
            i += 1;
        } else if (at0(buf, i) == '"' and dot) {
            i += 1;
            while (isSpace(at0(buf, i))) i += 1;
            break;
        }
        const nc = at0(name, j);
        j += 1;
        if (at0(buf, i) != nc) break;
    }
    if (at0(buf, i) == ']' and at0(name, j) == 0) {
        i += 1;
        while (at0(buf, i) != 0 and isSpace(at0(buf, i))) i += 1;
        return i;
    }
    return 0;
}

/// repo_config_copy_or_rename_section_in_file(). new_name == null removes.
/// Returns the number of sections changed, or -1 on error.
pub fn renameSectionInFile(path: []const u8, old_name: []const u8, new_name: ?[]const u8, copy: bool) i32 {
    if (new_name) |nn| {
        if (!sectionNameIsOk(nn)) {
            util.err("invalid section name: {s}", .{nn});
            return -1;
        }
    }
    const lock = lockFor(path) orelse {
        util.err("could not lock config file {s}", .{path});
        return -1;
    };
    defer lock.rollback();
    var ret: i32 = 0;
    var out: util.Buf = .empty;
    const contents = os.readFile(path) orelse blk: {
        const e = os.errno();
        if (e == os.EISDIR) break :blk @as([]u8, &.{});
        if (e != os.ENOENT and e != os.ENOTDIR) {
            util.warn("unable to access '{s}': {s}", .{ path, os.strErr(e) });
            return -1;
        }
        if (!lock.commit()) {
            util.err("could not write config file {s}: {s}", .{ path, os.lastErr() });
            return -1;
        }
        return 0;
    };
    if (os.statPath(path)) |st| {
        if (!os.chmod(lock.lock_path, st.mode & 0o7777)) {
            util.err("chmod on {s} failed: {s}", .{ lock.lock_path, os.lastErr() });
            return -1;
        }
    }
    var copystr: util.Buf = .empty;
    var remove = false;
    var pos: usize = 0;
    while (pos < contents.len) {
        const nl = std.mem.indexOfScalarPos(u8, contents, pos, '\n');
        const line_end = if (nl) |n| n + 1 else contents.len;
        const line_full = contents[pos..line_end];
        pos = line_end;
        const line = if (std.mem.indexOfScalar(u8, line_full, 0)) |zi| line_full[0..zi] else line_full;
        var output: []const u8 = line;
        var prefix_tab = false;
        var is_section = false;
        var i: usize = 0;
        while (i < line.len and isSpace(line[i])) i += 1;
        if (i < line.len and line[i] == '[') {
            is_section = true;
            if (copystr.items.len > 0) {
                util.bufAppend(&out, copystr.items);
                copystr.clearRetainingCapacity();
            }
            const offset = sectionNameMatch(line[i..], old_name);
            if (offset > 0) {
                ret += 1;
                if (new_name == null) {
                    remove = true;
                    continue;
                }
                const nn = new_name.?;
                if (!copy) {
                    createSection(&out, nn, nn.len);
                    output = line[@min(line.len, offset + i)..];
                    if (output.len > 0) prefix_tab = true;
                    if (output.len == 0) {
                        remove = false;
                        continue;
                    }
                } else {
                    copystr.clearRetainingCapacity();
                    createSection(&copystr, nn, nn.len);
                }
            }
            remove = false;
        }
        if (remove) continue;
        if (!is_section and copystr.items.len > 0) util.bufAppend(&copystr, output);
        if (prefix_tab) util.bufByte(&out, '\t');
        util.bufAppend(&out, output);
    }
    if (copystr.items.len > 0) util.bufAppend(&out, copystr.items);
    os.writeAll(lock.fd, out.items) catch {
        util.err("failed to write new configuration file {s}", .{lock.lock_path});
        return -1;
    };
    if (!lock.commit()) {
        util.err("could not write config file {s}: {s}", .{ path, os.lastErr() });
        return -1;
    }
    return ret;
}

/// Rename (new != null) or remove a section. Returns the number of
/// sections changed, or -1 on error.
pub fn renameSection(path: []const u8, old: []const u8, new: ?[]const u8) i32 {
    return renameSectionInFile(path, old, new, false);
}

/// Copy a section (git branch -c).
pub fn copySection(path: []const u8, old: []const u8, new: []const u8) i32 {
    return renameSectionInFile(path, old, new, true);
}

// ---------------------------------------------------------------------------
// urlmatch.c

pub const UrlInfo = struct {
    url: []const u8 = "",
    scheme_len: usize = 0,
    user_off: usize = 0,
    user_len: usize = 0,
    passwd_off: usize = 0,
    passwd_len: usize = 0,
    host_off: usize = 0,
    host_len: usize = 0,
    port_off: usize = 0,
    port_len: usize = 0,
    path_off: usize = 0,
    path_len: usize = 0,
};

pub const UrlMatch = struct {
    hostmatch_len: usize = 0,
    pathmatch_len: usize = 0,
    user_matched: bool = false,
};

const URL_ALPHA = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
const URL_DIGIT = "0123456789";
const URL_SCHEME_CHARS = URL_ALPHA ++ URL_DIGIT ++ "+.-";
const URL_HOST_CHARS = URL_ALPHA ++ URL_DIGIT ++ ".-_[:]";
const URL_UNSAFE_CHARS = " <>\"%{}|\\^`";
const URL_RESERVED = ":/?#[]@" ++ "!$&'()*+,;=";

fn strspn(s: []const u8, set: []const u8) usize {
    var i: usize = 0;
    while (i < s.len and std.mem.indexOfScalar(u8, set, s[i]) != null) i += 1;
    return i;
}

fn strcspn(s: []const u8, set: []const u8) usize {
    var i: usize = 0;
    while (i < s.len and std.mem.indexOfScalar(u8, set, s[i]) == null) i += 1;
    return i;
}

fn appendNormalizedEscapes(b: *util.Buf, from0: []const u8, esc_extra: []const u8, esc_ok: []const u8) bool {
    var from = from0;
    while (from.len > 0) {
        var ch = from[0];
        from = from[1..];
        var was_esc = false;
        if (ch == '%') {
            if (from.len < 2) return false;
            const hi = std.fmt.charToDigit(from[0], 16) catch return false;
            const lo = std.fmt.charToDigit(from[1], 16) catch return false;
            ch = hi * 16 + lo;
            from = from[2..];
            was_esc = true;
        }
        if (ch <= 0x1f or ch >= 0x7f or std.mem.indexOfScalar(u8, URL_UNSAFE_CHARS, ch) != null or
            std.mem.indexOfScalar(u8, esc_extra, ch) != null or
            (was_esc and std.mem.indexOfScalar(u8, esc_ok, ch) != null))
        {
            util.bufPrint(b, "%{X:0>2}", .{ch});
        } else {
            util.bufByte(b, ch);
        }
    }
    return true;
}

pub const UrlResult = union(enum) { ok: UrlInfo, err: []const u8 };

/// url_normalize(): returns the normalized URL info or an error message.
pub fn urlNormalize(url_in: []const u8, allow_globs: bool) UrlResult {
    var url = url_in;
    var norm: util.Buf = .empty;
    var info = UrlInfo{};
    var spanned = strspn(url, URL_SCHEME_CHARS);
    if (spanned == 0 or !std.ascii.isAlphabetic(url[0]) or spanned + 3 > url.len or
        url[spanned] != ':' or url[spanned + 1] != '/' or url[spanned + 2] != '/')
        return .{ .err = "invalid URL scheme name or missing '://' suffix" };
    info.scheme_len = spanned;
    spanned += 3;
    for (url[0..spanned]) |ch| util.bufByte(&norm, std.ascii.toLower(ch));
    url = url[spanned..];

    // user:password@
    const at_pos = std.mem.indexOfScalar(u8, url, '@');
    var slash_pos = strcspn(url, "/?#");
    if (at_pos != null and at_pos.? < slash_pos) {
        const at = at_pos.?;
        info.user_off = norm.items.len;
        if (at > 0) {
            if (!appendNormalizedEscapes(&norm, url[0..at], "", URL_RESERVED)) return .{ .err = "invalid %XX escape sequence" };
            const base = info.user_off;
            if (std.mem.indexOfScalarPos(u8, norm.items, base, ':')) |colon| {
                info.passwd_off = colon + 1;
                info.passwd_len = norm.items.len - info.passwd_off;
                info.user_len = (info.passwd_off - 1) - base;
            } else {
                info.user_len = norm.items.len - base;
            }
        }
        util.bufByte(&norm, '@');
        url = url[at + 1 ..];
        slash_pos = strcspn(url, "/?#");
    }

    // host
    if (url.len == 0 or std.mem.indexOfScalar(u8, ":/?#", url[0]) != null) {
        if (!util.startsWith(norm.items, "file:")) return .{ .err = "missing host and scheme is not 'file:'" };
    } else {
        info.host_off = norm.items.len;
    }
    var colon_pos: usize = slash_pos;
    if (slash_pos > 0) {
        var cp = slash_pos - 1;
        while (cp > 0 and url[cp] != ':' and url[cp] != ']') cp -= 1;
        if (url[cp] == ':') {
            if (info.host_off == 0 and cp + 1 != slash_pos) return .{ .err = "a 'file:' URL may not have a port number" };
            colon_pos = cp;
        }
    }
    spanned = if (allow_globs) strspn(url, URL_HOST_CHARS ++ "*") else strspn(url, URL_HOST_CHARS);
    if (spanned < colon_pos) return .{ .err = "invalid characters in host name" };
    for (url[0..colon_pos]) |ch| util.bufByte(&norm, std.ascii.toLower(ch));

    // port
    if (colon_pos < slash_pos) {
        var p = colon_pos + 1;
        p += strspn(url[p..slash_pos], "0");
        if (p == slash_pos and url[p - 1] == '0') p -= 1;
        const port = url[p..slash_pos];
        if (port.len == 0) {
            // ":" with no number: same as default
        } else if (port.len == 2 and util.startsWith(norm.items, "http:") and util.eql(port, "80")) {
            // default
        } else if (port.len == 3 and util.startsWith(norm.items, "https:") and util.eql(port, "443")) {
            // default
        } else {
            if (strspn(port, URL_DIGIT) < port.len) return .{ .err = "invalid port number" };
            var pnum: u64 = 0;
            if (port.len <= 5) pnum = std.fmt.parseInt(u64, port, 10) catch 0;
            if (pnum == 0 or pnum > 65535) return .{ .err = "invalid port number" };
            util.bufByte(&norm, ':');
            info.port_off = norm.items.len;
            util.bufAppend(&norm, port);
            info.port_len = port.len;
        }
        url = url[slash_pos..];
    } else {
        url = url[colon_pos..];
    }
    if (info.host_off != 0) info.host_len = norm.items.len - info.host_off - (if (info.port_len != 0) info.port_len + 1 else 0);

    // path
    info.path_off = norm.items.len;
    const path_start = info.path_off;
    util.bufByte(&norm, '/');
    if (url.len > 0 and url[0] == '/') url = url[1..];
    while (true) {
        const seg_start = norm.items.len;
        const next_slash = strcspn(url, "/?#");
        var skip_add_slash = false;
        if (!appendNormalizedEscapes(&norm, url[0..next_slash], "", URL_RESERVED)) return .{ .err = "invalid %XX escape sequence" };
        const seg = norm.items[seg_start..];
        if (util.eql(seg, ".")) {
            if (seg_start == path_start + 1) {
                norm.items.len -= 1;
                skip_add_slash = true;
            } else {
                norm.items.len -= 2;
            }
        } else if (util.eql(seg, "..")) {
            var prev = norm.items.len - 3;
            if (prev == path_start) return .{ .err = "invalid '..' path segment" };
            prev -= 1;
            while (norm.items[prev] != '/') prev -= 1;
            if (prev == path_start) {
                norm.items.len = prev + 1;
                skip_add_slash = true;
            } else {
                norm.items.len = prev;
            }
        }
        url = url[next_slash..];
        if (url.len == 0 or url[0] != '/') break;
        url = url[1..];
        if (!skip_add_slash) util.bufByte(&norm, '/');
    }
    info.path_len = norm.items.len - info.path_off;

    if (url.len > 0) {
        if (!appendNormalizedEscapes(&norm, url, "", URL_RESERVED)) return .{ .err = "invalid %XX escape sequence" };
    }
    info.url = norm.items;
    return .{ .ok = info };
}

fn matchHost(url_info: *const UrlInfo, pat_info: *const UrlInfo) bool {
    var url = url_info.url[url_info.host_off .. url_info.host_off + url_info.host_len];
    var pat = pat_info.url[pat_info.host_off .. pat_info.host_off + pat_info.host_len];
    while (url.len > 0 and pat.len > 0) {
        const un = std.mem.indexOfScalar(u8, url, '.') orelse url.len;
        const pn = std.mem.indexOfScalar(u8, pat, '.') orelse pat.len;
        if (pn == 1 and pat[0] == '*') {
            // wildcard matches anything
        } else if (pn == un and std.mem.eql(u8, url[0..un], pat[0..pn])) {
            // same component
        } else return false;
        url = url[@min(url.len, un + 1)..];
        pat = pat[@min(pat.len, pn + 1)..];
    }
    return url.len == 0 and pat.len == 0;
}

fn urlMatchPrefix(url: []const u8, prefix0: []const u8) usize {
    var prefix = prefix0;
    if (prefix.len == 0 or (prefix.len == 1 and prefix[0] == '/'))
        return if (url.len == 0 or url[0] == '/') 1 else 0;
    if (prefix[prefix.len - 1] == '/') prefix = prefix[0 .. prefix.len - 1];
    if (!util.startsWith(url, prefix)) return 0;
    if (url.len == prefix.len or url[prefix.len] == '/') return prefix.len + 1;
    return 0;
}

/// match_urls(): does pattern `prefix` match `url`?
pub fn matchUrls(url: *const UrlInfo, prefix: *const UrlInfo) ?UrlMatch {
    if (prefix.scheme_len != url.scheme_len or !std.mem.eql(u8, url.url[0..url.scheme_len], prefix.url[0..url.scheme_len])) return null;
    var usermatched = false;
    if (prefix.user_off != 0) {
        if (url.user_off == 0 or url.user_len != prefix.user_len or
            !std.mem.eql(u8, url.url[url.user_off .. url.user_off + url.user_len], prefix.url[prefix.user_off .. prefix.user_off + url.user_len]))
            return null;
        usermatched = true;
    }
    if (!matchHost(url, prefix)) return null;
    if (prefix.port_len != url.port_len or !std.mem.eql(u8, url.url[url.port_off .. url.port_off + url.port_len], prefix.url[prefix.port_off .. prefix.port_off + url.port_len])) return null;
    const pm = urlMatchPrefix(url.url[url.path_off..], prefix.url[prefix.path_off..]);
    if (pm == 0) return null;
    return .{ .hostmatch_len = prefix.host_len, .pathmatch_len = pm, .user_matched = usermatched };
}

/// cmp_matches(): <0 if a is a worse match than b
pub fn cmpMatches(a: *const UrlMatch, b: *const UrlMatch) i32 {
    if (a.hostmatch_len != b.hostmatch_len) return if (a.hostmatch_len < b.hostmatch_len) -1 else 1;
    if (a.pathmatch_len != b.pathmatch_len) return if (a.pathmatch_len < b.pathmatch_len) -1 else 1;
    if (a.user_matched != b.user_matched) return if (b.user_matched) -1 else 1;
    return 0;
}

/// urlmatch_config_entry() state. `collect` is called with the synthetic
/// key "<section>.<key>" for each better-or-equal match.
pub const UrlMatchConfig = struct {
    url: UrlInfo,
    section: []const u8,
    key: ?[]const u8 = null,
    collect: Callback,
    vars: std.StringHashMapUnmanaged(UrlMatch) = .empty,

    pub fn callback(self: *UrlMatchConfig) Callback {
        return .{ .f = entryFn, .ctx = self };
    }

    fn entryFn(ctx: *anyopaque, var_: []const u8, value: ?[]const u8, kvi: *const KvInfo) i32 {
        const self: *UrlMatchConfig = @ptrCast(@alignCast(ctx));
        const rest = util.skipPrefix(var_, self.section) orelse return 0;
        if (rest.len == 0 or rest[0] != '.') return 0;
        var key = rest[1..];
        var matched = UrlMatch{};
        if (std.mem.lastIndexOfScalar(u8, key, '.')) |dot| {
            const config_url = key[0..dot];
            switch (urlNormalize(config_url, true)) {
                .ok => |ni| {
                    matched = matchUrls(&self.url, &ni) orelse return 0;
                },
                .err => return 0,
            }
            key = key[dot + 1 ..];
        }
        if (self.key) |k| {
            if (!util.eql(key, k)) return 0;
        }
        const gop = self.vars.getOrPut(gpa, util.dupe(key)) catch util.oom();
        if (gop.found_existing) {
            if (cmpMatches(&matched, gop.value_ptr) < 0) return 0;
        }
        gop.value_ptr.* = matched;
        const synth = util.concat(&.{ self.section, ".", key });
        return self.collect.call(synth, value, kvi);
    }
};

/// Parse config text from a blob (e.g. ":.gitmodules") into cfg, silently
/// ignoring parse errors. Returns false on a parse error.
pub fn readBlobInto(cfg: *Config, data: []const u8, name: []const u8, scope: Scope) bool {
    var sc = StoreCtx{ .cfg = cfg };
    return parseSource(.{ .data = data, .origin_type = .blob, .name = name, .scope = scope, .error_action = .silent }, .{ .f = storeFn, .ctx = &sc }, null, null) >= 0;
}
