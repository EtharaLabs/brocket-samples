//! git worktree (builtin/worktree.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const advice = @import("../advice.zig");
const config = @import("../config.zig");
const ident = @import("../ident.zig");
const hook = @import("../hook.zig");
const date = @import("../date.zig");
const proc = @import("../proc.zig");
const branchcreate = @import("../branchcreate.zig");
const wtm = @import("../worktree.zig");
const commands = @import("../commands.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Worktree = wtm.Worktree;

const add_usage_str = "git worktree add [-f] [--detach] [--checkout] [--lock [--reason <string>]]\n" ++
    "                 [--orphan] [(-b | -B) <new-branch>] <path> [<commit-ish>]";
const list_usage_str = "git worktree list [-v | --porcelain [-z]]";
const lock_usage_str = "git worktree lock [--reason <string>] <worktree>";
const move_usage_str = "git worktree move <worktree> <new-path>";
const prune_usage_str = "git worktree prune [-n] [-v] [--expire <expire>]";
const remove_usage_str = "git worktree remove [-f] <worktree>";
const repair_usage_str = "git worktree repair [<path>...]";
const unlock_usage_str = "git worktree unlock <worktree>";

const worktree_usage = [_][]const u8{
    add_usage_str,  list_usage_str,   lock_usage_str,   move_usage_str,
    prune_usage_str, remove_usage_str, repair_usage_str, unlock_usage_str,
};

const time_max: i64 = std.math.maxInt(i64);

var show_only = false;
var verbose: i32 = 0;
var guess_remote = false;
var use_relative_paths = false;
var expire: i64 = time_max;

fn readConfig() void {
    if (repo_mod.cfg.getBool("worktree.guessremote")) |b| guess_remote = b;
    if (repo_mod.cfg.getBool("worktree.userelativepaths")) |b| use_relative_paths = b;
}

fn gitBin() []const u8 {
    return proc.gitBinary();
}

fn runGit(args: []const []const u8, env: []const [2][]const u8) u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, gitBin()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return os.run(argv.items, .{ .env = env }).status;
}

fn expireCb(arg: ?[]const u8, unset: bool) void {
    if (unset or arg == null) {
        expire = 0;
        return;
    }
    expire = date.parseExpiryDate(arg.?) orelse {
        util.err("malformed expiration date '{s}'", .{arg.?});
        os.exit(129);
    };
}

// ---------------- prune ----------------

fn deleteGitDir(id: []const u8) bool {
    const r = repo_mod.repo();
    const p = util.concat(&.{ r.common_dir, "/worktrees/", id });
    const st = os.lstatPath(p);
    if (st) |s| {
        if (s.isDir()) os.removeTree(p) else _ = os.unlink(p);
    }
    if (os.lstatPath(p) != null) {
        util.err("failed to delete '{s}': {s}", .{ p, os.lastErr() });
        return false;
    }
    return true;
}

fn deleteWorktreesDirIfEmpty() void {
    _ = os.rmdir(repo_mod.repo().commonPath("worktrees"));
}

fn pruneWorktree(id: []const u8, reason: []const u8) void {
    if (show_only or verbose > 0) {
        util.flushStdout();
        util.eprint("Removing {s}/{s}: {s}\n", .{ "worktrees", id, reason });
    }
    if (!show_only) _ = deleteGitDir(id);
}

const Kept = struct { path: []const u8, id: ?[]const u8 };

fn keptLess(_: void, a: Kept, b: Kept) bool {
    const c = std.mem.order(u8, a.path, b.path);
    if (c != .eq) return c == .lt;
    if (a.id == null) return b.id != null;
    if (b.id == null) return false;
    return std.mem.order(u8, a.id.?, b.id.?) == .lt;
}

fn pruneWorktrees() void {
    const r = repo_mod.repo();
    const ents = os.listDir(r.commonPath("worktrees")) orelse return;
    var kept: std.ArrayList(Kept) = .empty;
    for (ents) |e| {
        var p: ?[]const u8 = null;
        if (wtm.shouldPrune(e.name, &p, expire)) |reason| {
            pruneWorktree(e.name, reason);
        } else if (p) |pp| {
            kept.append(gpa, .{ .path = pp, .id = e.name }) catch util.oom();
        }
    }
    var main_path = wtm.absolutePath(r.common_dir);
    if (util.endsWith(main_path, "/.")) main_path = main_path[0 .. main_path.len - 2];
    kept.append(gpa, .{ .path = main_path, .id = null }) catch util.oom();
    std.mem.sort(Kept, kept.items, {}, keptLess);
    var i: usize = 1;
    while (i < kept.items.len) : (i += 1) {
        if (util.eql(kept.items[i].path, kept.items[i - 1].path))
            pruneWorktree(kept.items[i].id.?, "duplicate entry");
    }
    if (!show_only) deleteWorktreesDirIfEmpty();
}

fn cmdPrune(args: []const []const u8) u8 {
    const usage = [_][]const u8{prune_usage_str};
    const opts = [_]po.Opt{
        po.boolean('n', "dry-run", &show_only, "do not remove, show only"),
        po.counter('v', "verbose", &verbose, "report pruned working trees"),
        .{ .long = "expire", .kind = .callback, .cb = expireCb, .argh = "expiry-date", .help = "prune missing working trees older than <time>" },
    };
    expire = time_max;
    const rest = po.parse(args, &opts, &usage, .{});
    if (rest.len != 0) po.usageWithOptions(&usage, &opts);
    pruneWorktrees();
    return 0;
}

// ---------------- add ----------------

var junk_work_tree: ?[]const u8 = null;
var junk_git_dir: ?[]const u8 = null;
var is_junk = false;
var junk_pid: c_int = 0;
var atexit_registered = false;

extern "c" fn atexit(f: *const fn () callconv(.c) void) c_int;
extern "c" fn getpid() c_int;

fn removeJunk() callconv(.c) void {
    if (!is_junk or getpid() != junk_pid) return;
    if (junk_git_dir) |d| os.removeTree(d);
    if (junk_work_tree) |d| os.removeTree(d);
}

fn worktreeBasename(path: []const u8) []const u8 {
    var len = path.len;
    while (len > 0 and path[len - 1] == '/') len -= 1;
    var start = len;
    while (start > 0 and path[start - 1] != '/') start -= 1;
    return path[start..len];
}

fn isEmptyDir(path: []const u8) bool {
    const ents = os.listDir(path) orelse return false;
    return ents.len == 0;
}

fn checkCandidatePath(path: []const u8, force: i32, worktrees: []*Worktree, cmd: []const u8) void {
    if (os.exists(path) and !isEmptyDir(path)) util.die("'{s}' already exists", .{path});
    const wt = wtm.findByPath(worktrees, path) orelse return;
    const locked = wtm.lockReason(wt) != null;
    if ((!locked and force > 0) or (locked and force > 1)) {
        if (!deleteGitDir(wt.id.?)) util.die("unusable worktree destination '{s}'", .{path});
        return;
    }
    if (locked)
        util.die("'{s}' is a missing but locked worktree;\nuse '{s} -f -f' to override, or 'unlock' and 'prune' or 'remove' to clear", .{ path, cmd });
    util.die("'{s}' is a missing but already registered worktree;\nuse '{s} -f' to override, or 'prune' or 'remove' to clear", .{ path, cmd });
}

fn copyFile(from: []const u8, to: []const u8) bool {
    const data = os.readFile(from) orelse return false;
    if (!os.mkdirLeading(to)) return false;
    os.writeFile(to, data, 0o666) catch return false;
    return true;
}

fn copySparseCheckout(wt_git_dir: []const u8) void {
    const from = repo_mod.repo().gitPath("info/sparse-checkout");
    const to = util.concat(&.{ wt_git_dir, "/info/sparse-checkout" });
    if (os.exists(from)) {
        if (!copyFile(from, to))
            util.err("failed to copy '{s}' to '{s}'; sparse-checkout may not work correctly", .{ from, to });
    }
}

fn copyFilteredWorktreeConfig(wt_git_dir: []const u8) void {
    const from = repo_mod.repo().gitPath("config.worktree");
    const to = util.concat(&.{ wt_git_dir, "/config.worktree" });
    if (!os.exists(from)) return;
    if (!copyFile(from, to)) {
        util.err("failed to copy worktree config from '{s}' to '{s}'", .{ from, to });
        return;
    }
    var c: config.Config = .{};
    _ = config.readFileInto(&c, from, .worktree);
    if (c.getBool("core.bare") orelse false) {
        if (config.setInFileGently(to, "core.bare", null, "true") != 0)
            util.err("failed to unset '{s}' in '{s}'", .{ "core.bare", to });
    }
    if (c.get("core.worktree") != null) {
        if (config.setInFileGently(to, "core.worktree", null, null) != 0)
            util.err("failed to unset '{s}' in '{s}'", .{ "core.worktree", to });
    }
}

const AddOpts = struct {
    force: i32 = 0,
    detach: bool = false,
    quiet: bool = false,
    checkout: bool = true,
    orphan: bool = false,
    relative_paths: bool = false,
    keep_locked: ?[]const u8 = null,
};

fn appendHeadReflog(wt_git_dir: []const u8, new: Oid) void {
    if (!refs.shouldAutocreateReflog("HEAD")) return;
    const p = util.concat(&.{ wt_git_dir, "/logs/HEAD" });
    if (!os.mkdirLeading(p)) return;
    const line = util.concat(&.{ hash.zero_hex, " ", &hash.hex(new), " ", ident.committer(), "\n" });
    os.appendFile(p, line) catch {};
}

fn addWorktree(path: []const u8, refname: []const u8, opts: *const AddOpts) u8 {
    const r = repo_mod.repo();
    checkCandidatePath(path, opts.force, wtm.getAll(), "add");

    var is_branch = false;
    var symref: []const u8 = "";
    if (branchcreate.checkBranchRef(refname)) |sr| {
        symref = sr;
        if (!opts.detach and refs.exists(sr)) {
            is_branch = true;
            if (opts.force == 0) wtm.dieIfCheckedOut(sr, false);
        }
    } else {
        symref = util.concat(&.{ "refs/heads/", refname });
    }
    const commit = revparse.getCommit(refname);
    if (commit == null and !opts.orphan) util.die("invalid reference: {s}", .{refname});

    const name0 = worktreeBasename(path);
    if (name0.len == 0) util.die("invalid path '{s}'", .{path});
    const name = refs.sanitizeRefnameComponent(name0);
    const base = util.concat(&.{ r.common_dir, "/worktrees/", name });
    if (!os.mkdirLeading(base)) util.dieErrno("could not create leading directories of '{s}'", .{base});
    var sb_repo: []const u8 = base;
    var counter: u32 = 0;
    while (!os.mkdir(sb_repo, 0o777)) {
        counter += 1;
        if (os.errno() != os.EEXIST) util.dieErrno("could not create directory of '{s}'", .{sb_repo});
        sb_repo = util.fmt("{s}{d}", .{ base, counter });
    }
    const id = util.basename(sb_repo);

    junk_pid = getpid();
    if (!atexit_registered) {
        _ = atexit(removeJunk);
        atexit_registered = true;
    }
    junk_git_dir = sb_repo;
    is_junk = true;

    const locked_path = util.concat(&.{ sb_repo, "/locked" });
    wtm.writeFile(locked_path, opts.keep_locked orelse "initializing");

    const sb_git = util.concat(&.{ path, "/.git" });
    if (!os.mkdirLeading(sb_git)) util.dieErrno("could not create leading directories of '{s}'", .{sb_git});
    junk_work_tree = path;

    wtm.writeLinkingFiles(sb_git, util.concat(&.{ sb_repo, "/gitdir" }), opts.relative_paths);
    wtm.writeFile(util.concat(&.{ sb_repo, "/commondir" }), "../..");

    var ret: u8 = 0;
    if (wtm.getLinked(id, true) == null) {
        util.err("could not find created worktree '{s}'", .{id});
        ret = 1;
    }
    if (ret == 0) {
        _ = os.mkdir(util.concat(&.{ sb_repo, "/refs" }), 0o777);
        const head_path = util.concat(&.{ sb_repo, "/HEAD" });
        if (!is_branch and commit != null) {
            os.writeFile(head_path, util.concat(&.{ &hash.hex(commit.?), "\n" }), 0o666) catch {
                ret = 1;
            };
            if (ret == 0) appendHeadReflog(sb_repo, commit.?);
        } else {
            os.writeFile(head_path, util.concat(&.{ "ref: ", symref, "\n" }), 0o666) catch {
                ret = 1;
            };
            if (ret == 0) {
                if (refs.resolve(symref)) |res| appendHeadReflog(sb_repo, res.oid);
            }
        }
    }
    if (ret == 0) {
        if (repo_mod.cfg.getBool("core.sparsecheckout") orelse false) copySparseCheckout(sb_repo);
        if (r.worktree_config) copyFilteredWorktreeConfig(sb_repo);

        const env = [_][2][]const u8{ .{ "GIT_DIR", sb_git }, .{ "GIT_WORK_TREE", path } };
        if (opts.orphan) {
            var a: std.ArrayList([]const u8) = .empty;
            a.appendSlice(gpa, &.{ "symbolic-ref", "HEAD", symref }) catch util.oom();
            if (opts.quiet) a.append(gpa, "--quiet") catch util.oom();
            ret = runGit(a.items, &env);
        }
        if (ret == 0 and opts.checkout) {
            var a: std.ArrayList([]const u8) = .empty;
            a.appendSlice(gpa, &.{ "reset", "--hard", "--no-recurse-submodules" }) catch util.oom();
            if (opts.quiet) a.append(gpa, "--quiet") catch util.oom();
            ret = runGit(a.items, &env);
        }
        if (ret == 0) {
            is_junk = false;
            junk_work_tree = null;
            junk_git_dir = null;
        }
    }
    if (ret != 0 or opts.keep_locked == null) {
        if (!os.unlink(locked_path) and os.errno() != os.ENOENT)
            util.warn("unable to unlink '{s}': {s}", .{ locked_path, os.lastErr() });
    }
    if (ret == 0 and opts.checkout and !opts.orphan) {
        if (hook.find("post-checkout")) |hp| {
            const res = os.run(&.{ hp, hash.zero_hex, &hash.hex(commit.?), "1" }, .{
                .cwd = path,
                .unset_env = &.{ "GIT_DIR", "GIT_WORK_TREE" },
                .no_stdin = true,
                .stdout_to_stderr = true,
            });
            ret = res.status;
        }
    }
    if (ret != 0) {
        removeJunk();
        is_junk = false;
    }
    return ret;
}

fn branchRefExists(name: []const u8) bool {
    const sr = branchcreate.checkBranchRef(name) orelse return false;
    return refs.exists(sr);
}

fn printPreparingLine(detach: bool, branch: []const u8, new_branch: ?[]const u8, force_new_branch: bool) void {
    util.flushStdout();
    if (force_new_branch) {
        const nb = new_branch.?;
        if (revparse.getCommit(nb)) |c| {
            util.eprint("Preparing worktree (resetting branch '{s}'; was at {s})\n", .{ nb, revparse.abbrev(c, 0) });
        } else util.eprint("Preparing worktree (new branch '{s}')\n", .{nb});
    } else if (new_branch) |nb| {
        util.eprint("Preparing worktree (new branch '{s}')\n", .{nb});
    } else {
        if (!detach and branchRefExists(branch)) {
            util.eprint("Preparing worktree (checking out '{s}')\n", .{branch});
        } else {
            const c = revparse.getCommit(branch) orelse util.die("BUG: unreachable: invalid reference: {s}", .{branch});
            util.eprint("Preparing worktree (detached HEAD {s})\n", .{revparse.abbrev(c, 0)});
        }
    }
}

fn headValid() bool {
    return refs.resolve("HEAD") != null;
}

fn anyBranchValid() bool {
    return refs.list("refs/heads/").len > 0;
}

fn canUseLocalRefs(opts: *const AddOpts) bool {
    if (headValid()) return true;
    if (anyBranchValid()) {
        if (!opts.quiet) util.warn("HEAD points to an invalid (or orphaned) reference.\n", .{});
        return true;
    }
    return false;
}

fn canUseRemoteRefs(opts: *const AddOpts) bool {
    if (!guess_remote) return false;
    if (refs.list("refs/remotes/").len > 0) return true;
    if (opts.force == 0 and branchcreate.remoteNames().len > 0)
        util.die("No local or remote refs exist despite at least one remote\npresent, stopping; use 'add -f' to override or fetch a remote first", .{});
    return false;
}

fn dwimOrphan(opts: *const AddOpts, opt_track: bool, remote: bool) bool {
    if (canUseLocalRefs(opts)) return false;
    if (remote and canUseRemoteRefs(opts)) return false;
    if (!opts.quiet) {
        util.flushStdout();
        util.eprint("No possible source branch, inferring '--orphan'\n", .{});
    }
    if (opt_track) util.die("options '{s}' and '{s}' cannot be used together", .{ "--orphan", "--track" });
    if (!opts.checkout) util.die("options '{s}' and '{s}' cannot be used together", .{ "--orphan", "--no-checkout" });
    return true;
}

/// unique_tracking_name() (checkout.c), simplified: refs/remotes/<remote>/<name>.
fn uniqueTrackingName(name: []const u8, num_matches: *usize, matched: *std.ArrayList([]const u8)) ?[]const u8 {
    num_matches.* = 0;
    var found: ?[]const u8 = null;
    var default_found: ?[]const u8 = null;
    const default_remote = repo_mod.cfg.get("checkout.defaultremote");
    const src = util.concat(&.{ "refs/heads/", name });
    for (branchcreate.remoteNames()) |rn| {
        const dst = util.concat(&.{ "refs/remotes/", rn, "/", name });
        if (!refs.exists(dst)) continue;
        if (branchcreate.remoteFindTrackingSrc(rn, dst)) |s| {
            if (!util.eql(s, src)) continue;
        }
        num_matches.* += 1;
        matched.append(gpa, rn) catch util.oom();
        if (found == null) found = dst;
        if (default_remote) |dr| {
            if (util.eql(dr, rn)) default_found = dst;
        }
    }
    if (default_found) |d| return d;
    if (num_matches.* == 1) return found;
    return null;
}

fn adviseDisambiguatingRemotes(path: []const u8, branch: []const u8, matched: []const []const u8) void {
    advice.advise(util.fmt("Branch name '{s}' appears in multiple remotes:", .{branch}));
    for (matched) |m| advice.advise(util.fmt("  {s}", .{m}));
    advice.advise(util.fmt("If you meant to create a worktree from a remote tracking branch on\n" ++
        "<remote>, you can do so by:\n" ++
        "\n" ++
        "    git worktree add -b {s} {s} <remote>/{s}\n" ++
        "\n" ++
        "If you'd like to always prefer some remote, e.g. 'origin',\n" ++
        "consider setting checkout.defaultRemote=origin in your config.", .{ branch, path, branch }));
}

fn dwimBranch(opts: *const AddOpts, path: []const u8, new_branch: *?[]const u8) ?[]const u8 {
    const branchname = worktreeBasename(path);
    if (branchRefExists(branchname)) return branchname;
    new_branch.* = branchname;
    if (guess_remote) {
        var n: usize = 0;
        var matched: std.ArrayList([]const u8) = .empty;
        const remote = uniqueTrackingName(branchname, &n, &matched);
        if (remote == null and n > 1) {
            if (!opts.quiet and advice.enabled("checkoutAmbiguousRemoteBranchName"))
                adviseDisambiguatingRemotes(path, branchname, matched.items);
            util.die("'{s}' matched multiple ({d}) remote tracking branches", .{ branchname, n });
        }
        return remote;
    }
    return null;
}

var add_track: ?[]const u8 = null;

fn trackCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        add_track = "--no-track";
    } else if (arg) |a| {
        add_track = util.concat(&.{ "--track=", a });
    } else add_track = "--track";
}

fn cmdAdd(args: []const []const u8) u8 {
    const usage = [_][]const u8{add_usage_str};
    var opts = AddOpts{};
    var new_branch_opt: ?[]const u8 = null;
    var new_branch_force: ?[]const u8 = null;
    var keep_locked = false;
    var lock_reason: ?[]const u8 = null;
    var quiet = false;
    var relative = use_relative_paths;
    add_track = null;
    const options = [_]po.Opt{
        po.counter('f', "force", &opts.force, "checkout <branch> even if already checked out in other worktree"),
        po.string('b', "", &new_branch_opt, "branch", "create a new branch"),
        po.string('B', "", &new_branch_force, "branch", "create or reset a branch"),
        po.boolean(0, "orphan", &opts.orphan, "create unborn branch"),
        po.boolean('d', "detach", &opts.detach, "detach HEAD at named commit"),
        po.boolean(0, "checkout", &opts.checkout, "populate the new working tree"),
        po.boolean(0, "lock", &keep_locked, "keep the new working tree locked"),
        po.string(0, "reason", &lock_reason, "string", "reason for locking"),
        po.boolean('q', "quiet", &quiet, "suppress progress reporting"),
        .{ .long = "track", .kind = .callback, .cb = trackCb, .optarg = true, .help = "set up tracking mode (see git-branch(1))" },
        po.boolean(0, "guess-remote", &guess_remote, "try to match the new branch name with a remote-tracking branch"),
        po.boolean(0, "relative-paths", &relative, "use relative paths for worktrees"),
    };
    const av = po.parse(args, &options, &usage, .{});
    opts.quiet = quiet;
    opts.relative_paths = relative;
    var new_branch = new_branch_opt;
    const nset = @as(u32, @intFromBool(opts.detach)) + @intFromBool(new_branch != null) + @intFromBool(new_branch_force != null);
    if (nset > 1) util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ "-b", "-B", "--detach" });
    if (opts.detach and opts.orphan) util.die("options '{s}' and '{s}' cannot be used together", .{ "--orphan", "--detach" });
    if (opts.orphan and add_track != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--orphan", "--track" });
    if (opts.orphan and !opts.checkout) util.die("options '{s}' and '{s}' cannot be used together", .{ "--orphan", "--no-checkout" });
    if (opts.orphan and av.len == 2) util.die("option '{s}' and commit-ish cannot be used together", .{"--orphan"});
    if (lock_reason != null and !keep_locked) util.die("the option '{s}' requires '{s}'", .{ "--reason", "--lock" });
    if (lock_reason) |lr| {
        opts.keep_locked = lr;
    } else if (keep_locked) opts.keep_locked = "added with --lock";

    if (av.len < 1 or av.len > 2) po.usageWithOptions(&usage, &options);

    const prefix = repo_mod.repo().prefix;
    const path = wtm.prefixFilename(prefix, av[0]);
    var branch: []const u8 = if (av.len < 2) "HEAD" else av[1];
    const used_new_branch_options = new_branch != null or new_branch_force != null;
    if (util.eql(branch, "-")) branch = "@{-1}";

    if (new_branch_force) |nbf| {
        new_branch = nbf;
        if (opts.force == 0) {
            if (branchcreate.checkBranchRef(nbf)) |sr| {
                if (refs.exists(sr)) wtm.dieIfCheckedOut(sr, false);
            }
        }
    }

    if (opts.orphan and new_branch == null) {
        new_branch = worktreeBasename(path);
    } else if (opts.orphan) {
        // no-op
    } else if (opts.detach) {
        if (util.eql(branch, "HEAD")) _ = canUseLocalRefs(&opts);
    } else if (av.len < 2 and new_branch != null) {
        opts.orphan = dwimOrphan(&opts, add_track != null, false);
    } else if (av.len < 2) {
        var nb: ?[]const u8 = null;
        const s = dwimBranch(&opts, path, &nb);
        if (s) |ss| branch = ss;
        new_branch = nb;
        opts.orphan = s == null and dwimOrphan(&opts, add_track != null, true);
    } else if (av.len == 2 and new_branch != null) {
        if (util.eql(branch, "HEAD")) _ = canUseLocalRefs(&opts);
    } else if (av.len == 2) {
        if (revparse.getCommit(branch) == null) {
            var n: usize = 0;
            var matched: std.ArrayList([]const u8) = .empty;
            if (uniqueTrackingName(branch, &n, &matched)) |remote| {
                new_branch = branch;
                branch = remote;
            } else if (n > 1) {
                if (!opts.quiet and advice.enabled("checkoutAmbiguousRemoteBranchName"))
                    adviseDisambiguatingRemotes(path, branch, matched.items);
                util.die("'{s}' matched multiple ({d}) remote tracking branches", .{ branch, n });
            }
        }
        if (util.eql(branch, "HEAD")) _ = canUseLocalRefs(&opts);
    }

    if (!opts.orphan and revparse.getCommit(branch) == null) {
        const attempt_hint = !opts.quiet and av.len < 2;
        if (attempt_hint and used_new_branch_options) {
            advice.adviseIfEnabled("worktreeAddOrphan", util.fmt("If you meant to create a worktree containing a new unborn branch\n" ++
                "(branch with no commits) for this repository, you can do so\n" ++
                "using the --orphan flag:\n" ++
                "\n" ++
                "    git worktree add --orphan -b {s} {s}\n", .{ new_branch.?, path }));
        } else if (attempt_hint) {
            advice.adviseIfEnabled("worktreeAddOrphan", util.fmt("If you meant to create a worktree containing a new unborn branch\n" ++
                "(branch with no commits) for this repository, you can do so\n" ++
                "using the --orphan flag:\n" ++
                "\n" ++
                "    git worktree add --orphan {s}\n", .{path}));
        }
        util.die("invalid reference: {s}", .{branch});
    }

    if (!opts.quiet) printPreparingLine(opts.detach, branch, new_branch, new_branch_force != null);

    if (opts.orphan) {
        branch = new_branch.?;
    } else if (new_branch) |nb| {
        if (commands.find("branch") != null) {
            var a: std.ArrayList([]const u8) = .empty;
            a.append(gpa, "branch") catch util.oom();
            if (new_branch_force != null) a.append(gpa, "--force") catch util.oom();
            if (opts.quiet) a.append(gpa, "--quiet") catch util.oom();
            a.append(gpa, nb) catch util.oom();
            a.append(gpa, branch) catch util.oom();
            if (add_track) |t| a.append(gpa, t) catch util.oom();
            if (runGit(a.items, &.{}) != 0) return 1;
        } else {
            branchcreate.createBranch(nb, branch, new_branch_force != null, false, false, opts.quiet, branchcreate.configBranchTrack(), false);
        }
        branch = nb;
    } else if (add_track != null) {
        util.die("--[no-]track can only be used if a new branch is created", .{});
    }
    return addWorktree(path, branch, &opts);
}

// ---------------- list ----------------

fn showPorcelain(wt: *Worktree, term: u8) void {
    util.outf("worktree {s}{c}", .{ wt.path, term });
    if (wt.is_bare) {
        util.outf("bare{c}", .{term});
    } else {
        util.outf("HEAD {s}{c}", .{ hash.hex(wt.head_oid), term });
        if (wt.is_detached) {
            util.outf("detached{c}", .{term});
        } else if (wt.head_ref) |h| util.outf("branch {s}{c}", .{ h, term });
    }
    if (wtm.lockReason(wt)) |reason| {
        util.out("locked");
        if (reason.len > 0) {
            util.out(" ");
            util.out(if (term == 0) reason else util.cquote(reason));
        }
        util.outf("{c}", .{term});
    }
    if (wtm.pruneReason(wt, expire)) |reason| util.outf("prunable {s}{c}", .{ reason, term });
    util.outf("{c}", .{term});
}

fn showWorktree(wt: *Worktree, disp: []const u8, path_maxwidth: usize, abbrev_len: usize) void {
    var b: util.Buf = .empty;
    util.bufAppend(&b, disp);
    var pad = 1 + path_maxwidth - disp.len;
    while (pad > 0) : (pad -= 1) util.bufByte(&b, ' ');
    if (wt.is_bare) {
        util.bufAppend(&b, "(bare)");
    } else {
        const ab = revparse.abbrev(wt.head_oid, 0);
        util.bufAppend(&b, ab);
        var k = ab.len;
        while (k < abbrev_len) : (k += 1) util.bufByte(&b, ' ');
        util.bufByte(&b, ' ');
        if (wt.is_detached) {
            util.bufAppend(&b, "(detached HEAD)");
        } else if (wt.head_ref) |h| {
            util.bufPrint(&b, "[{s}]", .{refs.shortenUnambiguous(h)});
        } else util.bufAppend(&b, "(error)");
    }
    const reason = wtm.lockReason(wt);
    if (verbose > 0 and reason != null and reason.?.len > 0) {
        util.bufPrint(&b, "\n\tlocked: {s}", .{reason.?});
    } else if (reason != null) util.bufAppend(&b, " locked");
    const pr = wtm.pruneReason(wt, expire);
    if (verbose > 0 and pr != null) {
        util.bufPrint(&b, "\n\tprunable: {s}", .{pr.?});
    } else if (pr != null) util.bufAppend(&b, " prunable");
    util.outf("{s}\n", .{b.items});
}

fn wtLess(_: void, a: *Worktree, b: *Worktree) bool {
    return std.mem.order(u8, a.path, b.path) == .lt;
}

fn cmdList(args: []const []const u8) u8 {
    const usage = [_][]const u8{list_usage_str};
    var porcelain = false;
    var term: i32 = '\n';
    const options = [_]po.Opt{
        po.boolean(0, "porcelain", &porcelain, "machine-readable output"),
        po.counter('v', "verbose", &verbose, "show extended annotations and reasons, if available"),
        .{ .long = "expire", .kind = .callback, .cb = expireCb, .argh = "expiry-date", .help = "add 'prunable' annotation to missing worktrees older than <time>" },
        po.setInt('z', "", &term, 0, "terminate records with a NUL character"),
    };
    expire = time_max;
    const rest = po.parse(args, &options, &usage, .{});
    if (rest.len != 0) po.usageWithOptions(&usage, &options);
    if (verbose > 0 and porcelain) util.die("options '{s}' and '{s}' cannot be used together", .{ "--verbose", "--porcelain" });
    if (term == 0 and !porcelain) util.die("the option '{s}' requires '{s}'", .{ "-z", "--porcelain" });
    const list = wtm.getAll();
    std.mem.sort(*Worktree, list[1..], {}, wtLess);
    if (porcelain) {
        for (list) |wt| showPorcelain(wt, @intCast(term));
        return 0;
    }
    var maxw: usize = 0;
    var abbrev_len: usize = 0;
    const disp = gpa.alloc([]const u8, list.len) catch util.oom();
    for (list, 0..) |wt, i| {
        disp[i] = util.cquote(wt.path);
        if (disp[i].len > maxw) maxw = disp[i].len;
        const l = revparse.abbrev(wt.head_oid, 0).len;
        if (l > abbrev_len) abbrev_len = l;
    }
    for (list, 0..) |wt, i| showWorktree(wt, disp[i], maxw, abbrev_len);
    return 0;
}

// ---------------- lock / unlock ----------------

fn cmdLock(args: []const []const u8) u8 {
    const usage = [_][]const u8{lock_usage_str};
    var reason: ?[]const u8 = null;
    const options = [_]po.Opt{po.string(0, "reason", &reason, "string", "reason for locking")};
    const av = po.parse(args, &options, &usage, .{});
    if (av.len != 1) po.usageWithOptions(&usage, &options);
    const list = wtm.getAll();
    const wt = wtm.find(list, repo_mod.repo().prefix, av[0]) orelse util.die("'{s}' is not a working tree", .{av[0]});
    if (wt.isMain()) util.die("The main working tree cannot be locked or unlocked", .{});
    if (wtm.lockReason(wt)) |old| {
        if (old.len > 0) util.die("'{s}' is already locked, reason: {s}", .{ av[0], old });
        util.die("'{s}' is already locked", .{av[0]});
    }
    wtm.writeFile(wt.gitPath("locked"), reason orelse "");
    return 0;
}

fn cmdUnlock(args: []const []const u8) u8 {
    const usage = [_][]const u8{unlock_usage_str};
    const av = po.parse(args, &.{}, &usage, .{});
    if (av.len != 1) po.usageWithOptions(&usage, &.{});
    const list = wtm.getAll();
    const wt = wtm.find(list, repo_mod.repo().prefix, av[0]) orelse util.die("'{s}' is not a working tree", .{av[0]});
    if (wt.isMain()) util.die("The main working tree cannot be locked or unlocked", .{});
    if (wtm.lockReason(wt) == null) util.die("'{s}' is not locked", .{av[0]});
    const p = wt.gitPath("locked");
    if (!os.unlink(p)) {
        util.warn("unable to unlink '{s}': {s}", .{ p, os.lastErr() });
        return 1;
    }
    return 0;
}

// ---------------- move / remove ----------------

fn validateNoSubmodules(wt: *Worktree) void {
    var found = false;
    if (os.isDir(wt.gitPath("modules"))) {
        found = true;
    } else {
        const ip = wt.gitPath("index");
        if (os.exists(ip)) {
            const idx = index_mod.readFrom(ip);
            for (idx.entries.items) |e| {
                if (e.mode != 0o160000) continue;
                const sp = util.concat(&.{ wt.path, "/", e.path, "/.git" });
                if (!os.exists(sp)) continue;
                found = true;
                break;
            }
        }
    }
    if (found) util.die("working trees containing submodules cannot be moved or removed", .{});
}

fn cmdMove(args: []const []const u8) u8 {
    const usage = [_][]const u8{move_usage_str};
    var force: i32 = 0;
    const options = [_]po.Opt{
        po.counter('f', "force", &force, "force move even if worktree is dirty or locked"),
        po.boolean(0, "relative-paths", &use_relative_paths, "use relative paths for worktrees"),
    };
    const av = po.parse(args, &options, &usage, .{});
    if (av.len != 2) po.usageWithOptions(&usage, &options);
    const prefix = repo_mod.repo().prefix;
    var dst: []const u8 = wtm.prefixFilename(prefix, av[1]);
    const list = wtm.getAll();
    const wt = wtm.find(list, prefix, av[0]) orelse util.die("'{s}' is not a working tree", .{av[0]});
    if (wt.isMain()) util.die("'{s}' is a main working tree", .{av[0]});
    if (os.isDir(dst)) {
        const sep = std.mem.lastIndexOfScalar(u8, wt.path, '/') orelse
            util.die("could not figure out destination name from '{s}'", .{wt.path});
        var d = dst;
        while (d.len > 1 and d[d.len - 1] == '/') d = d[0 .. d.len - 1];
        dst = util.concat(&.{ d, wt.path[sep..] });
    }
    checkCandidatePath(dst, force, list, "move");
    validateNoSubmodules(wt);
    var reason: ?[]const u8 = null;
    if (force < 2) reason = wtm.lockReason(wt);
    if (reason) |rs| {
        if (rs.len > 0) util.die("cannot move a locked working tree, lock reason: {s}\nuse 'move -f -f' to override or unlock first", .{rs});
        util.die("cannot move a locked working tree;\nuse 'move -f -f' to override or unlock first", .{});
    }
    if (wtm.validate(wt, false)) |m| util.die("validation failed, cannot move working tree: {s}", .{m});
    if (!os.rename(wt.path, dst)) util.dieErrno("failed to move '{s}' to '{s}'", .{ wt.path, dst });
    wtm.updateLocation(wt, dst, use_relative_paths);
    return 0;
}

fn checkCleanWorktree(wt: *Worktree, original_path: []const u8) void {
    validateNoSubmodules(wt);
    const res = os.run(&.{ gitBin(), "status", "--porcelain", "--ignore-submodules=none" }, .{
        .env = &.{ .{ "GIT_DIR", util.concat(&.{ wt.path, "/.git" }) }, .{ "GIT_WORK_TREE", wt.path } },
        .cwd = wt.path,
        .capture_stdout = true,
        .no_stdin = true,
    });
    if (res.stdout.len > 0) util.die("'{s}' contains modified or untracked files, use --force to delete it", .{original_path});
    if (res.status != 0) util.die("failed to run 'git status' on '{s}', code {d}", .{ original_path, res.status });
}

fn cmdRemove(args: []const []const u8) u8 {
    const usage = [_][]const u8{remove_usage_str};
    var force: i32 = 0;
    const options = [_]po.Opt{
        po.counter('f', "force", &force, "force removal even if worktree is dirty or locked"),
    };
    const av = po.parse(args, &options, &usage, .{});
    if (av.len != 1) po.usageWithOptions(&usage, &options);
    const list = wtm.getAll();
    const wt = wtm.find(list, repo_mod.repo().prefix, av[0]) orelse util.die("'{s}' is not a working tree", .{av[0]});
    if (wt.isMain()) util.die("'{s}' is a main working tree", .{av[0]});
    var reason: ?[]const u8 = null;
    if (force < 2) reason = wtm.lockReason(wt);
    if (reason) |rs| {
        if (rs.len > 0) util.die("cannot remove a locked working tree, lock reason: {s}\nuse 'remove -f -f' to override or unlock first", .{rs});
        util.die("cannot remove a locked working tree;\nuse 'remove -f -f' to override or unlock first", .{});
    }
    if (wtm.validate(wt, true)) |m| util.die("validation failed, cannot remove working tree: {s}", .{m});
    var ret: u8 = 0;
    if (os.exists(wt.path)) {
        if (force == 0) checkCleanWorktree(wt, av[0]);
        os.removeTree(wt.path);
        if (os.lstatPath(wt.path) != null) {
            util.err("failed to delete '{s}': {s}", .{ wt.path, os.lastErr() });
            ret = 1;
        }
    }
    if (!deleteGitDir(wt.id.?)) ret = 1;
    deleteWorktreesDirIfEmpty();
    return ret;
}

// ---------------- repair ----------------

fn reportRepair(iserr: bool, path: []const u8, msg: []const u8, cb: ?*anyopaque) void {
    util.flushStdout();
    if (!iserr) {
        util.eprint("repair: {s}: {s}\n", .{ msg, path });
    } else {
        util.eprint("error: {s}: {s}\n", .{ msg, path });
        const rc: *u8 = @ptrCast(cb.?);
        rc.* = 1;
    }
}

fn cmdRepair(args: []const []const u8) u8 {
    const usage = [_][]const u8{repair_usage_str};
    const options = [_]po.Opt{
        po.boolean(0, "relative-paths", &use_relative_paths, "use relative paths for worktrees"),
    };
    const av = po.parse(args, &options, &usage, .{});
    var rc: u8 = 0;
    const self = [_][]const u8{"."};
    const paths: []const []const u8 = if (av.len > 0) av else &self;
    for (paths) |p| wtm.repairAtPath(p, reportRepair, @ptrCast(&rc), use_relative_paths);
    wtm.repairAll(reportRepair, @ptrCast(&rc), use_relative_paths);
    return rc;
}

pub fn cmdWorktree(args: []const []const u8) u8 {
    readConfig();
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&worktree_usage, &.{});
    }
    const sub = args[1];
    const rest = args[2..];
    if (util.eql(sub, "-h") or util.eql(sub, "--help-all")) po.usageExit(&worktree_usage, &.{}, false);
    if (util.eql(sub, "add")) return cmdAdd(rest);
    if (util.eql(sub, "prune")) return cmdPrune(rest);
    if (util.eql(sub, "list")) return cmdList(rest);
    if (util.eql(sub, "lock")) return cmdLock(rest);
    if (util.eql(sub, "unlock")) return cmdUnlock(rest);
    if (util.eql(sub, "move")) return cmdMove(rest);
    if (util.eql(sub, "remove")) return cmdRemove(rest);
    if (util.eql(sub, "repair")) return cmdRepair(rest);
    if (sub.len > 0 and sub[0] == '-') {
        if (util.startsWith(sub, "--")) {
            util.err("unknown option `{s}'", .{sub[2..]});
        } else util.err("unknown switch `{c}'", .{if (sub.len > 1) sub[1] else '-'});
    } else util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&worktree_usage, &.{});
}
