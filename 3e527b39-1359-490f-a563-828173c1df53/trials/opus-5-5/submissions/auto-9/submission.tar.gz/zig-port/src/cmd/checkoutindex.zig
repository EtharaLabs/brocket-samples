//! git checkout-index (builtin/checkout-index.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const entry = @import("../entry.zig");
const gpa = util.gpa;

const CHECKOUT_ALL: u32 = 4;

const usage = [_][]const u8{"git checkout-index [<options>] [--] [<file>...]"};

var nul_term_line = false;
var checkout_stage: u32 = 0;
var ignore_skip_worktree = false;
var to_tempfile: ?bool = null;
var topath: [4]?[]const u8 = .{ null, null, null, null };
var state: entry.State = .{};

fn writeTempfileRecord(name: []const u8, prefix: []const u8) void {
    var have = false;
    if (checkout_stage == CHECKOUT_ALL) {
        for (1..4) |i| {
            if (topath[i] != null) have = true;
        }
        if (have) {
            for (1..4) |i| {
                if (i > 1) util.out(" ");
                util.out(topath[i] orelse ".");
            }
        }
    } else if (topath[checkout_stage]) |t| {
        have = true;
        util.out(t);
    }
    if (have) {
        util.out("\t");
        const rel = util.relativePath(name, prefix);
        if (nul_term_line) {
            util.out(rel);
            util.out("\x00");
        } else {
            util.out(util.cquote(rel));
            util.out("\n");
        }
    }
    topath = .{ null, null, null, null };
}

fn doCheckout(e: *index_mod.Entry) bool {
    if (to_tempfile.?) {
        const fmt = e.mode & os.S_IFMT;
        if (fmt == os.S_IFREG or fmt == os.S_IFLNK) {
            const t = entry.checkoutEntryTemp(e, &state) orelse return true;
            topath[e.stage()] = t;
            return false;
        }
    }
    return entry.checkoutEntry(e, &state, null);
}

fn checkoutFile(idx: *index_mod.Index, name: []const u8, prefix: []const u8) bool {
    var p: usize = switch (idx.pos(name, 0)) {
        .found => |x| x,
        .missing => |x| x,
    };
    var has_same_name = false;
    var is_skipped = true;
    var did_checkout = false;
    var errs: usize = 0;
    while (p < idx.entries.items.len) {
        const e = &idx.entries.items[p];
        if (!util.eql(e.path, name)) break;
        has_same_name = true;
        p += 1;
        if (!ignore_skip_worktree and e.skipWorktree()) break;
        is_skipped = false;
        if (e.stage() != checkout_stage and (checkout_stage != CHECKOUT_ALL or e.stage() == 0)) continue;
        did_checkout = true;
        if (doCheckout(e)) errs += 1;
    }
    if (did_checkout) {
        if (to_tempfile.?) writeTempfileRecord(name, prefix);
        return errs > 0;
    }
    if (has_same_name and checkout_stage == CHECKOUT_ALL) return false;
    if (!state.quiet) {
        util.flushStdout();
        if (!has_same_name) {
            util.eprint("git checkout-index: {s} is not in the cache\n", .{name});
        } else if (is_skipped) {
            util.eprint("git checkout-index: {s} has skip-worktree enabled; use '--ignore-skip-worktree-bits' to checkout\n", .{name});
        } else if (checkout_stage != 0) {
            util.eprint("git checkout-index: {s} does not exist at stage {d}\n", .{ name, checkout_stage });
        } else {
            util.eprint("git checkout-index: {s} is unmerged\n", .{name});
        }
    }
    return true;
}

fn checkoutAll(idx: *index_mod.Index, prefix: []const u8) bool {
    var errs: usize = 0;
    var last: ?[]const u8 = null;
    var i: usize = 0;
    while (i < idx.entries.items.len) : (i += 1) {
        const e = &idx.entries.items[i];
        if (!ignore_skip_worktree and e.skipWorktree()) continue;
        if (e.stage() != checkout_stage and (checkout_stage != CHECKOUT_ALL or e.stage() == 0)) continue;
        if (prefix.len > 0 and (e.path.len <= prefix.len or !util.startsWith(e.path, prefix))) continue;
        if (last != null and to_tempfile.?) {
            if (!util.eql(last.?, e.path)) writeTempfileRecord(last.?, prefix);
        }
        if (doCheckout(e)) errs += 1;
        last = e.path;
    }
    if (last != null and to_tempfile.?) writeTempfileRecord(last.?, prefix);
    return errs > 0;
}

fn stageCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg.?;
    if (util.eql(a, "all")) {
        checkout_stage = CHECKOUT_ALL;
    } else if (a.len > 0 and a[0] >= '1' and a[0] <= '3') {
        checkout_stage = a[0] - '0';
    } else util.die("stage should be between 1 and 3 or all", .{});
}

var temp_flag = false;
var temp_set = false;
fn tempCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    temp_set = true;
    temp_flag = !unset;
}

pub fn run(args: []const []const u8) u8 {
    var all = false;
    var read_from_stdin = false;
    var force = false;
    var quiet: i32 = 0;
    var not_new = false;
    var index_opt = false;
    var base_dir: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.boolean('a', "all", &all, "check out all files in the index"),
        po.boolean(0, "ignore-skip-worktree-bits", &ignore_skip_worktree, "do not skip files with skip-worktree set"),
        po.boolean('f', "force", &force, "force overwrite of existing files"),
        po.counter('q', "quiet", &quiet, "no warning for existing files and files not in index"),
        po.boolean('n', "no-create", &not_new, "don't checkout new files"),
        po.boolean('u', "index", &index_opt, "update stat information in the index file"),
        po.boolean('z', "", &nul_term_line, "paths are separated with NUL character"),
        po.boolean(0, "stdin", &read_from_stdin, "read list of paths from the standard input"),
        po.callbackNoArg(0, "temp", tempCb, "write the content to temporary files"),
        po.string(0, "prefix", &base_dir, "string", "when creating files, prepend <string>"),
        .{ .kind = .callback, .long = "stage", .cb = stageCb, .argh = "(1|2|3|all)", .literal_argh = true, .noneg = true, .help = "copy out the files from named stage" },
    };
    const rest = po.parse(args[1..], &options, &usage, .{});
    const r = repo_mod.repo();
    const prefix = r.prefix;

    state.force = force;
    state.quiet = quiet > 0;
    state.not_new = not_new;
    state.base_dir = base_dir orelse "";
    to_tempfile = if (temp_set) temp_flag else (checkout_stage == CHECKOUT_ALL);
    if (!to_tempfile.? and checkout_stage == CHECKOUT_ALL)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--stage=all", "--no-temp" });

    var locked = false;
    const idx = if (index_opt and state.base_dir.len == 0 and !to_tempfile.?) blk: {
        locked = true;
        state.refresh_cache = true;
        break :blk index_mod.lockAndRead();
    } else index_mod.get();
    state.istate = idx;

    var err = false;
    for (rest) |arg| {
        if (all) util.die("git checkout-index: don't mix '--all' and explicit filenames", .{});
        if (read_from_stdin) util.die("git checkout-index: don't mix '--stdin' and explicit filenames", .{});
        const p = repo_mod.prefixPath(arg) orelse util.die("'{s}' is outside repository at '{s}'", .{ arg, r.work_tree orelse "" });
        if (checkoutFile(idx, p, prefix)) err = true;
    }
    if (read_from_stdin) {
        if (all) util.die("git checkout-index: don't mix '--all' and '--stdin'", .{});
        const data = os.readAllFd(0) catch util.die("could not read from stdin", .{});
        const term: u8 = if (nul_term_line) 0 else '\n';
        var it = std.mem.splitScalar(u8, data, term);
        while (it.next()) |line0| {
            if (it.index == null and line0.len == 0) break;
            var line = line0;
            if (!nul_term_line and line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
            if (!nul_term_line and line.len > 0 and line[0] == '"') {
                const uq = util.cunquote(line) orelse util.die("line is badly quoted", .{});
                if (uq.rest.len != 0) util.die("line is badly quoted", .{});
                line = uq.value;
            }
            const p = repo_mod.prefixPath(line) orelse util.die("'{s}' is outside repository at '{s}'", .{ line, r.work_tree orelse "" });
            if (checkoutFile(idx, p, prefix)) err = true;
        }
    }
    if (all) {
        if (checkoutAll(idx, prefix)) err = true;
    }
    if (err) return 1;
    if (locked) {
        idx.writeToLock();
        const l = idx.lock.?;
        if (!l.commit()) util.die("Unable to write new index file", .{});
        idx.lock = null;
    }
    return 0;
}
