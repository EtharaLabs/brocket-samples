//! Launching the user's editor (editor.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const advice = @import("advice.zig");

pub fn isTerminalDumb() bool {
    const t = os.getenv("TERM") orelse return true;
    return util.eql(t, "dumb");
}

pub fn gitEditor() ?[]const u8 {
    var editor = os.getenv("GIT_EDITOR");
    const dumb = isTerminalDumb();
    if (editor == null) editor = repo_mod.cfg.get("core.editor");
    if (editor == null and !dumb) editor = os.getenv("VISUAL");
    if (editor == null) editor = os.getenv("EDITOR");
    if (editor == null and dumb) return null;
    return editor orelse "vi";
}

pub fn gitSequenceEditor() ?[]const u8 {
    if (os.getenv("GIT_SEQUENCE_EDITOR")) |e| return e;
    if (repo_mod.cfg.get("sequence.editor")) |e| return e;
    return gitEditor();
}

/// Returns true on error (after printing the error).
pub fn launchSpecified(editor_opt: ?[]const u8, path: []const u8, env: []const [2][]const u8) bool {
    const editor = editor_opt orelse {
        util.err("Terminal is dumb, but EDITOR unset", .{});
        return true;
    };
    if (util.eql(editor, ":")) return false;
    const show_wait = advice.enabled("waitingForEditor") and os.isatty(2);
    if (show_wait) {
        util.eprint("hint: Waiting for your editor to close the file...{c}", .{@as(u8, if (isTerminalDumb()) '\n' else ' ')});
    }
    const real = os.realPath(path) orelse util.concat(&.{ os.getcwd(), "/", path });
    const res = os.run(&.{ editor, real }, .{ .use_shell = true, .env = env });
    if (show_wait and !isTerminalDumb()) util.ewrite("\r\x1b[K");
    if (res.status != 0) {
        util.err("there was a problem with the editor '{s}'", .{editor});
        return true;
    }
    return false;
}

pub fn launch(path: []const u8, env: []const [2][]const u8) bool {
    return launchSpecified(gitEditor(), path, env);
}

pub fn launchSequence(path: []const u8, env: []const [2][]const u8) bool {
    return launchSpecified(gitSequenceEditor(), path, env);
}
