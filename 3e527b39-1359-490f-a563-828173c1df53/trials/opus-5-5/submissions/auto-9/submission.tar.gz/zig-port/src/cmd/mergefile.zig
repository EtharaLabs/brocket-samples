//! git merge-file (port of builtin/merge-file.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const repo_mod = @import("../repo.zig");
const xdiff = @import("../xdiff.zig");
const mo = @import("../merge_ort.zig");

const usage = [_][]const u8{
    "git merge-file [<options>] [-L <name1> [-L <orig> [-L <name2>]]] <file1> <orig-file> <file2>",
};

var names: [3]?[]const u8 = .{ null, null, null };
var label_count: usize = 0;
var label_error = false;
var algo: ?xdiff.Algorithm = null;
var algo_error = false;

fn labelCb(arg: ?[]const u8, _: bool) void {
    if (label_count >= 3) {
        util.err("too many labels on the command line", .{});
        label_error = true;
        return;
    }
    names[label_count] = arg;
    label_count += 1;
}

fn algoCb(arg: ?[]const u8, _: bool) void {
    algo = mo.parseAlgorithmValue(arg orelse "") orelse blk: {
        util.err("option diff-algorithm accepts \"myers\", \"minimal\", \"patience\" and \"histogram\"", .{});
        algo_error = true;
        break :blk null;
    };
}

fn readMmfile(path: []const u8) ?[]const u8 {
    if (os.statPath(path) == null) {
        util.err("Could not stat {s}: {s}", .{ path, os.lastErr() });
        return null;
    }
    return os.readFile(path) orelse {
        util.err("Could not open {s}: {s}", .{ path, os.lastErr() });
        return null;
    };
}

pub fn cmdMergeFile(args: []const []const u8) u8 {
    var to_stdout = false;
    var object_id = false;
    var style: i32 = 0;
    var favor: i32 = 0;
    var marker_size: i32 = xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
    var quiet: i32 = 0;
    const opts = [_]po.Opt{
        po.boolean('p', "stdout", &to_stdout, "send results to standard output"),
        po.boolean(0, "object-id", &object_id, "use object IDs instead of filenames"),
        po.setInt(0, "diff3", &style, 1, "use a diff3 based merge"),
        po.setInt(0, "zdiff3", &style, 2, "use a zealous diff3 based merge"),
        po.setInt(0, "ours", &favor, 1, "for conflicts, use our version"),
        po.setInt(0, "theirs", &favor, 2, "for conflicts, use their version"),
        po.setInt(0, "union", &favor, 3, "for conflicts, use a union version"),
        .{ .long = "diff-algorithm", .kind = .callback, .cb = algoCb, .argh = "<algorithm>", .help = "choose a diff algorithm", .noneg = true },
        po.integer(0, "marker-size", &marker_size, "", "for conflicts, use this marker size"),
        po.quiet(&quiet),
        .{ .short = 'L', .kind = .callback, .cb = labelCb, .argh = "name", .help = "set labels for file1/orig-file/file2" },
    };

    mo.loadXmergeConfig();
    if (mo.xmerge_style >= 0) style = mo.xmerge_style;

    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (label_error or algo_error) return 129;
    if (rest.len != 3) po.usageWithOptions(&usage, &opts);
    if (quiet != 0) {
        const fd = os.openFile("/dev/null", os.O_WRONLY, 0);
        if (fd < 0) {
            util.err("failed to redirect stderr to /dev/null: {s}", .{os.lastErr()});
            return 255;
        }
        _ = std.c.dup2(fd, 2);
    }
    if (object_id) _ = repo_mod.repo();
    const prefix: []const u8 = if (repo_mod.repo_) |r| r.prefix else "";

    var mmfs: [3][]const u8 = .{ "", "", "" };
    for (0..3) |i| {
        if (names[i] == null) names[i] = rest[i];
        const fname = if (prefix.len > 0 and rest[i].len > 0 and rest[i][0] != '/') util.concat(&.{ prefix, rest[i] }) else rest[i];
        var ok = true;
        if (object_id) {
            if (revparse.getOid(rest[i])) |oid| {
                if (!hash.eql(oid, hash.fromHex(hash.empty_blob_hex).?)) {
                    const o = repo_mod.repo().odb().read(oid) orelse util.die("unable to read {s}", .{hash.hex(oid)});
                    if (o.typ != .blob) util.die("unable to read {s}", .{hash.hex(oid)});
                    mmfs[i] = o.data;
                }
            } else {
                util.err("object '{s}' does not exist", .{rest[i]});
                return 255;
            }
        } else {
            if (readMmfile(fname)) |d| mmfs[i] = d else ok = false;
        }
        if (!ok) return 255;
        if (mmfs[i].len > 1024 * 1024 * 1023 or mo.bufferIsBinary(mmfs[i])) {
            util.err("Cannot merge binary files: {s}", .{rest[i]});
            return 255;
        }
    }

    var mopts = xdiff.MergeOpts{};
    if (algo) |a| mopts.flags.algorithm = a else mopts.flags.algorithm = .myers;
    mopts.style = @enumFromInt(@as(u2, @intCast(style)));
    mopts.favor = @enumFromInt(@as(u2, @intCast(favor)));
    mopts.marker_size = marker_size;
    mopts.ancestor_name = names[1];
    mopts.ours_name = names[0];
    mopts.theirs_name = names[2];
    const res = xdiff.merge(mmfs[1], mmfs[0], mmfs[2], mopts) catch {
        return 255;
    };
    var ret: i32 = @intCast(@min(res.conflicts, 1000));
    if (object_id and !to_stdout) {
        const oid = if (res.result.len > 0) repo_mod.repo().odb().write(.blob, res.result) else hash.fromHex(hash.empty_blob_hex).?;
        util.out(util.fmt("{s}\n", .{hash.hex(oid)}));
    } else if (to_stdout) {
        util.out(res.result);
    } else {
        const fpath = if (prefix.len > 0 and rest[0][0] != '/') util.concat(&.{ prefix, rest[0] }) else rest[0];
        os.writeFile(fpath, res.result, 0o666) catch {
            util.err("Could not open {s} for writing: {s}", .{ rest[0], os.lastErr() });
            return 255;
        };
    }
    if (ret > 127) ret = 127;
    return @intCast(ret);
}
