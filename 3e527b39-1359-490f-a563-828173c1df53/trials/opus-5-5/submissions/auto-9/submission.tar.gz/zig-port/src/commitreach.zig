//! Port of commit-reach.c: merge bases, reachability queries, ahead/behind.
//!
//! There is no commit-graph support, so generation numbers are "infinity"
//! unless computed in memory by `ensureGenerationsValid` (as ahead_behind()
//! does in git).

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const cn = @import("commitnode.zig");
const refs = @import("refs.zig");
const Oid = hash.Oid;
const Commit = cn.Commit;
const CommitList = cn.CommitList;
const gpa = util.gpa;

const PARENT1 = cn.PARENT1;
const PARENT2 = cn.PARENT2;
const STALE = cn.STALE;
const RESULT = cn.RESULT;
const ENQUEUED = cn.ENQUEUED;
const all_flags: u32 = PARENT1 | PARENT2 | STALE | RESULT | ENQUEUED;

pub const Error = error{Failed};

// ---------------- generation numbers ----------------

pub const GEN_INFINITY: u64 = (1 << 63) - 1;
pub const GEN_ZERO: u64 = 0;
pub const GEN_V1_MAX: u64 = 0x3FFFFFFF;

var gens = cn.Slab(u64).init(0);

/// commit_graph_generation()
pub fn generation(c: *const Commit) u64 {
    if (gens.peek(c)) |g| {
        if (g.* != 0) return g.*;
    }
    return GEN_INFINITY;
}

fn rawGen(c: *const Commit) u64 {
    if (gens.peek(c)) |g| return g.*;
    return 0;
}

/// compare_commits_by_gen_then_commit_date (generation-aware)
pub fn compareByGenThenDate(a: *Commit, b: *Commit, _: ?*anyopaque) i32 {
    const ga = generation(a);
    const gb = generation(b);
    if (ga < gb) return 1;
    if (ga > gb) return -1;
    if (a.date < b.date) return 1;
    if (a.date > b.date) return -1;
    return 0;
}

/// compare_commits_by_gen (ascending; for sorting arrays)
fn lessByGen(_: void, a: *Commit, b: *Commit) bool {
    const ga = generation(a);
    const gb = generation(b);
    if (ga != gb) return ga < gb;
    return a.date < b.date;
}

/// ensure_generations_valid(): compute corrected commit dates (generation v2)
/// for everything reachable from `commits`.
pub fn ensureGenerationsValid(commits: []const *Commit) void {
    for (commits) |c0| {
        _ = cn.parse(c0);
        const g0 = rawGen(c0);
        if (g0 != GEN_ZERO and g0 != GEN_INFINITY) continue;
        var list: ?*CommitList = null;
        _ = cn.listInsert(c0, &list);
        while (list) |top| {
            const current = top.item;
            var all_parents_computed = true;
            var max_gen: u64 = 0;
            var p = current.parents;
            while (p) |x| : (p = x.next) {
                _ = cn.parse(x.item);
                const g = rawGen(x.item);
                if (g == GEN_ZERO) {
                    all_parents_computed = false;
                    _ = cn.listInsert(x.item, &list);
                    break;
                }
                if (g > max_gen) max_gen = g;
            }
            if (all_parents_computed) {
                _ = cn.popCommit(&list);
                if (current.date != 0 and current.date > max_gen) max_gen = current.date - 1;
                gens.at(current).* = max_gen + 1;
            }
        }
    }
}

/// repo_parse_commit() that reports missing objects like git does.
fn parseLoud(c: *Commit) bool {
    if (cn.parse(c)) return true;
    util.err("Could not read {s}", .{hash.hex(c.obj.oid)});
    return false;
}

// ---------------- paint_down_to_common ----------------

const MB_IGNORE_MISSING: u32 = 1 << 0;
const MB_FIND_ALL: u32 = 1 << 1;

pub const MergeBaseFlags = struct {
    ignore_missing: bool = false,
    find_all: bool = false,
    fn bits(self: MergeBaseFlags) u32 {
        return (if (self.ignore_missing) MB_IGNORE_MISSING else 0) | (if (self.find_all) MB_FIND_ALL else 0);
    }
};

const PaintState = struct {
    queue: cn.PrioQueue = .{ .compare = compareByGenThenDate },
    parent1_count: usize = 0,
    parent2_count: usize = 0,
    mb_candidate_count: usize = 0,
    min_generation: u64 = 0,
    last_gen: u64 = GEN_INFINITY,
    topo_ceiling: u64 = GEN_V1_MAX,

    fn countUpdate(s: *PaintState, flags: u32, delta: isize) void {
        switch (flags & (PARENT1 | PARENT2 | STALE)) {
            PARENT1 => s.parent1_count = @intCast(@as(isize, @intCast(s.parent1_count)) + delta),
            PARENT2 => s.parent2_count = @intCast(@as(isize, @intCast(s.parent2_count)) + delta),
            PARENT1 | PARENT2 => s.mb_candidate_count = @intCast(@as(isize, @intCast(s.mb_candidate_count)) + delta),
            PARENT1 | PARENT2 | STALE => {},
            else => {},
        }
    }

    fn put(s: *PaintState, c: *Commit, add_flags: u32) void {
        const old = c.obj.flags;
        c.obj.flags |= add_flags;
        if (old & ENQUEUED != 0) {
            s.countUpdate(old, -1);
            s.countUpdate(c.obj.flags, 1);
        } else {
            c.obj.flags |= ENQUEUED;
            s.queue.put(c);
            s.countUpdate(c.obj.flags, 1);
        }
    }

    fn get(s: *PaintState) ?*Commit {
        const c = s.queue.get() orelse return null;
        c.obj.flags &= ~ENQUEUED;
        const g = generation(c);
        s.last_gen = g;
        if (g < s.min_generation) return null;
        if (s.mb_candidate_count == 0) {
            if (s.parent1_count == 0 and s.parent2_count == 0) return null;
            if ((s.parent1_count == 0 or s.parent2_count == 0) and g < s.topo_ceiling) return null;
        }
        s.countUpdate(c.obj.flags, -1);
        return c;
    }
};

fn paintDownToCommon(one: *Commit, twos: []const *Commit, min_generation: u64, mb_flags: u32) Error!?*CommitList {
    var state = PaintState{};
    state.min_generation = min_generation;
    var result: ?*CommitList = null;
    var tail = &result;

    one.obj.flags |= PARENT1;
    if (twos.len == 0) {
        _ = cn.listAppend(one, &result);
        return result;
    }
    state.put(one, 0);
    for (twos) |t| state.put(t, PARENT2);

    while (state.get()) |commit| {
        var flags = commit.obj.flags & (PARENT1 | PARENT2 | STALE);
        if (flags == (PARENT1 | PARENT2)) {
            if (commit.obj.flags & RESULT == 0) {
                commit.obj.flags |= RESULT;
                tail = cn.listAppend(commit, tail);
                if (mb_flags & MB_FIND_ALL == 0 and state.last_gen < state.topo_ceiling) break;
            }
            flags |= STALE;
        }
        var parents = commit.parents;
        while (parents) |pl| {
            const p = pl.item;
            parents = pl.next;
            if (p.obj.flags & flags == flags) continue;
            if (!cn.parse(p)) {
                state.queue.clear();
                util.err("Could not read {s}", .{hash.hex(p.obj.oid)});
                if (mb_flags & MB_IGNORE_MISSING != 0) return null;
                util.err("could not parse commit {s}", .{hash.hex(p.obj.oid)});
                return error.Failed;
            }
            state.put(p, flags);
        }
    }
    state.queue.clear();
    cn.listSortByDate(&result);
    return result;
}

fn mergeBasesMany(one_opt: ?*Commit, twos: []const ?*Commit, mb_flags: u32) Error!?*CommitList {
    var result: ?*CommitList = null;
    for (twos) |t| {
        if (one_opt != null and one_opt == t) {
            _ = cn.listInsert(one_opt.?, &result);
            return result;
        }
    }
    const one = one_opt orelse return null;
    if (!cn.parse(one)) {
        util.err("Could not read {s}", .{hash.hex(one.obj.oid)});
        util.err("could not parse commit {s}", .{hash.hex(one.obj.oid)});
        return error.Failed;
    }
    var arr: std.ArrayList(*Commit) = .empty;
    for (twos) |t_opt| {
        const t = t_opt orelse return null;
        if (!cn.parse(t)) {
            util.err("Could not read {s}", .{hash.hex(t.obj.oid)});
            util.err("could not parse commit {s}", .{hash.hex(t.obj.oid)});
            return error.Failed;
        }
        arr.append(gpa, t) catch util.oom();
    }
    var list = try paintDownToCommon(one, arr.items, 0, mb_flags);
    var tail = &result;
    while (cn.popCommit(&list)) |c| {
        if (c.obj.flags & STALE == 0) tail = cn.listAppend(c, tail);
    }
    cn.listSortByDate(&result);
    return result;
}

/// get_octopus_merge_bases
pub fn getOctopusMergeBasesChecked(in: ?*CommitList) Error!?*CommitList {
    const first = in orelse return null;
    var result: ?*CommitList = null;
    _ = cn.listInsert(first.item, &result);
    var i = first.next;
    while (i) |il| : (i = il.next) {
        var new_commits: ?*CommitList = null;
        var end: ?*CommitList = null;
        var j = result;
        while (j) |jl| : (j = jl.next) {
            const bases = try getMergeBasesChecked(il.item, jl.item);
            if (new_commits == null) new_commits = bases else end.?.next = bases;
            var k = bases;
            while (k) |kl| : (k = kl.next) end = kl;
        }
        result = new_commits;
    }
    return result;
}

pub fn getOctopusMergeBases(in: ?*CommitList) ?*CommitList {
    return getOctopusMergeBasesChecked(in) catch null;
}

fn removeRedundantNoGen(array: []*Commit) Error!usize {
    const cnt = array.len;
    const work = gpa.alloc(*Commit, cnt) catch util.oom();
    const redundant = gpa.alloc(bool, cnt) catch util.oom();
    @memset(redundant, false);
    const filled_index = gpa.alloc(usize, cnt) catch util.oom();
    for (array) |c| _ = parseLoud(c);
    for (0..cnt) |i| {
        if (redundant[i]) continue;
        var min_generation = generation(array[i]);
        var filled: usize = 0;
        for (0..cnt) |j| {
            if (i == j or redundant[j]) continue;
            filled_index[filled] = j;
            work[filled] = array[j];
            filled += 1;
            const cg = generation(array[j]);
            if (cg < min_generation) min_generation = cg;
        }
        _ = paintDownToCommon(array[i], work[0..filled], min_generation, MB_FIND_ALL) catch {
            cn.clearCommitMarks(array[i], all_flags);
            cn.clearCommitMarksMany(work[0..filled], all_flags);
            return error.Failed;
        };
        if (array[i].obj.flags & PARENT2 != 0) redundant[i] = true;
        for (0..filled) |j| {
            if (work[j].obj.flags & PARENT1 != 0) redundant[filled_index[j]] = true;
        }
        cn.clearCommitMarks(array[i], all_flags);
        cn.clearCommitMarksMany(work[0..filled], all_flags);
    }
    @memcpy(work, array);
    var filled: usize = 0;
    for (0..cnt) |i| {
        if (!redundant[i]) {
            array[filled] = work[i];
            filled += 1;
        }
    }
    return filled;
}

fn removeRedundantWithGen(array: []*Commit) usize {
    const cnt = array.len;
    var count_still_independent = cnt;
    const sorted = gpa.dupe(*Commit, array) catch util.oom();
    std.sort.block(*Commit, sorted, {}, lessByGen);
    var min_generation = generation(sorted[0]);
    var walk_start: std.ArrayList(*Commit) = .empty;
    var min_gen_pos: usize = 0;

    for (array) |c| {
        _ = parseLoud(c);
        c.obj.flags |= RESULT;
        var parents = c.parents;
        while (parents) |pl| : (parents = pl.next) {
            _ = parseLoud(pl.item);
            if (pl.item.obj.flags & STALE == 0) {
                pl.item.obj.flags |= STALE;
                walk_start.append(gpa, pl.item) catch util.oom();
            }
        }
    }
    std.sort.block(*Commit, walk_start.items, {}, lessByGen);
    for (walk_start.items) |c| c.obj.flags &= ~STALE;

    var i = walk_start.items.len;
    while (i > 0 and count_still_independent > 1) : (i -= 1) {
        var stack: ?*CommitList = null;
        _ = cn.listInsert(walk_start.items[i - 1], &stack);
        walk_start.items[i - 1].obj.flags |= STALE;
        while (stack) |top| {
            const c = top.item;
            _ = parseLoud(c);
            if (c.obj.flags & RESULT != 0) {
                c.obj.flags &= ~RESULT;
                count_still_independent -= 1;
                if (count_still_independent <= 1) break;
                if (hash.eql(c.obj.oid, sorted[min_gen_pos].obj.oid)) {
                    while (min_gen_pos < cnt - 1 and sorted[min_gen_pos].obj.flags & STALE != 0) min_gen_pos += 1;
                    min_generation = generation(sorted[min_gen_pos]);
                }
            }
            if (generation(c) < min_generation) {
                _ = cn.popCommit(&stack);
                continue;
            }
            var parents = c.parents;
            var pushed = false;
            while (parents) |pl| : (parents = pl.next) {
                if (pl.item.obj.flags & STALE == 0) {
                    pl.item.obj.flags |= STALE;
                    _ = cn.listInsert(pl.item, &stack);
                    pushed = true;
                    break;
                }
            }
            if (!pushed) _ = cn.popCommit(&stack);
        }
    }
    for (array) |c| c.obj.flags &= ~RESULT;
    var count_non_stale: usize = 0;
    for (0..cnt) |k| {
        if (array[k].obj.flags & STALE == 0) {
            array[count_non_stale] = array[k];
            count_non_stale += 1;
        }
    }
    cn.clearCommitMarksMany(walk_start.items, STALE);
    return count_non_stale;
}

/// Without a commit-graph, generation numbers are only "enabled" if computed in memory;
/// git checks generation_numbers_enabled() which requires a commit-graph file, so
/// the _no_gen variant is always used.
fn removeRedundant(array: []*Commit) Error!usize {
    return removeRedundantNoGen(array);
}

fn getMergeBasesMany0(one: ?*Commit, twos: []const ?*Commit, cleanup: bool, mb_flags: u32) Error!?*CommitList {
    var result = try mergeBasesMany(one, twos, mb_flags);
    for (twos) |t| {
        if (one == t) return result;
    }
    if (result == null or result.?.next == null) {
        if (cleanup) {
            if (one) |o| cn.clearCommitMarks(o, all_flags);
            for (twos) |t| if (t) |tt| cn.clearCommitMarks(tt, all_flags);
        }
        return result;
    }
    var rslt: std.ArrayList(*Commit) = .empty;
    var l = result;
    while (l) |x| : (l = x.next) rslt.append(gpa, x.item) catch util.oom();
    result = null;
    if (one) |o| cn.clearCommitMarks(o, all_flags);
    for (twos) |t| if (t) |tt| cn.clearCommitMarks(tt, all_flags);
    const cnt = try removeRedundant(rslt.items);
    var tail = &result;
    for (rslt.items[0..cnt]) |c| tail = cn.listAppend(c, tail);
    cn.listSortByDate(&result);
    return result;
}

fn optSlice(twos: []const *Commit) []const ?*Commit {
    const a = gpa.alloc(?*Commit, twos.len) catch util.oom();
    for (twos, 0..) |t, i| a[i] = t;
    return a;
}

/// repo_get_merge_bases_many (errors reported as error.Failed)
pub fn getMergeBasesManyChecked(one: *Commit, twos: []const *Commit) Error!?*CommitList {
    return getMergeBasesMany0(one, optSlice(twos), true, MB_FIND_ALL);
}

/// repo_get_merge_bases_many_dirty
pub fn getMergeBasesManyDirtyChecked(one: ?*Commit, twos: []const *Commit, flags: MergeBaseFlags) Error!?*CommitList {
    return getMergeBasesMany0(one, optSlice(twos), false, flags.bits());
}

/// repo_get_merge_bases
pub fn getMergeBasesChecked(one: *Commit, two: *Commit) Error!?*CommitList {
    const twos = [_]?*Commit{two};
    return getMergeBasesMany0(one, &twos, true, MB_FIND_ALL);
}

/// Convenience wrappers: on error (missing commits) they exit with 128 like most callers.
pub fn getMergeBases(one: *Commit, two: *Commit) ?*CommitList {
    return getMergeBasesChecked(one, two) catch @import("os.zig").exit(128);
}
pub fn getMergeBasesMany(one: *Commit, twos: []const *Commit) ?*CommitList {
    return getMergeBasesManyChecked(one, twos) catch @import("os.zig").exit(128);
}
pub fn getMergeBasesManyDirty(one: *Commit, twos: []const *Commit) ?*CommitList {
    return getMergeBasesManyDirtyChecked(one, twos, .{ .find_all = true }) catch @import("os.zig").exit(128);
}

// ---------------- descendant / ancestor queries ----------------

/// repo_in_merge_bases_many: is `commit` an ancestor of one of `reference`?
pub fn inMergeBasesManyChecked(commit: *Commit, reference: []const *Commit, ignore_missing: bool) Error!bool {
    var mb_flags: u32 = MB_FIND_ALL;
    if (ignore_missing) mb_flags |= MB_IGNORE_MISSING;
    if (!parseLoud(commit)) {
        if (ignore_missing) return false;
        return error.Failed;
    }
    var max_generation: u64 = GEN_ZERO;
    for (reference) |r| {
        if (!parseLoud(r)) {
            if (ignore_missing) return false;
            return error.Failed;
        }
        const g = generation(r);
        if (g > max_generation) max_generation = g;
    }
    const g = generation(commit);
    if (g > max_generation) return false;
    var ret: Error!bool = false;
    if (paintDownToCommon(commit, reference, g, mb_flags)) |_| {
        ret = commit.obj.flags & PARENT2 != 0;
    } else |e| ret = e;
    cn.clearCommitMarks(commit, all_flags);
    cn.clearCommitMarksMany(reference, all_flags);
    return ret;
}

pub fn inMergeBasesMany(commit: *Commit, refs_: []const *Commit, ignore_missing: bool) bool {
    return inMergeBasesManyChecked(commit, refs_, ignore_missing) catch @import("os.zig").exit(128);
}

/// repo_is_descendant_of: is `commit` a descendant of one of `with`?
pub fn isDescendantOfChecked(commit: *Commit, with: ?*CommitList) Error!bool {
    if (with == null) return true;
    var w = with;
    while (w) |x| : (w = x.next) {
        const one = [_]*Commit{commit};
        if (try inMergeBasesManyChecked(x.item, &one, false)) return true;
    }
    return false;
}

pub fn isDescendantOf(commit: *Commit, with: ?*CommitList) bool {
    return isDescendantOfChecked(commit, with) catch @import("os.zig").exit(128);
}

/// repo_in_merge_bases: is `commit` reachable from `reference`?
pub fn inMergeBasesChecked(commit: *Commit, reference: *Commit) Error!bool {
    var list: ?*CommitList = null;
    _ = cn.listAppend(commit, &list);
    return isDescendantOfChecked(reference, list);
}

pub fn inMergeBases(commit: *Commit, reference: *Commit) bool {
    return inMergeBasesChecked(commit, reference) catch @import("os.zig").exit(128);
}

/// reduce_heads: remove commits reachable from others (keeps input order).
pub fn reduceHeads(heads: ?*CommitList) ?*CommitList {
    if (heads == null) return null;
    var p = heads;
    while (p) |x| : (p = x.next) x.item.obj.flags &= ~STALE;
    var array: std.ArrayList(*Commit) = .empty;
    p = heads;
    while (p) |x| : (p = x.next) {
        if (x.item.obj.flags & STALE != 0) continue;
        x.item.obj.flags |= STALE;
        array.append(gpa, x.item) catch util.oom();
    }
    for (array.items) |c| c.obj.flags &= ~STALE;
    const n = removeRedundant(array.items) catch return null;
    var result: ?*CommitList = null;
    var tail = &result;
    for (array.items[0..n]) |c| tail = cn.listAppend(c, tail);
    return result;
}

/// ref_newer: is new_oid (commit-ish) a descendant of old_oid?
pub fn refNewer(new_oid: Oid, old_oid: Oid) bool {
    const oo = cn.parseObject(old_oid) orelse return false;
    const od = cn.derefTag(oo) orelse return false;
    if (od.typ != .commit) return false;
    const old_commit = Commit.fromObj(od);
    const no = cn.parseObject(new_oid) orelse return false;
    const nd = cn.derefTag(no) orelse return false;
    if (nd.typ != .commit) return false;
    const new_commit = Commit.fromObj(nd);
    if (!cn.parse(new_commit)) return false;
    var list: ?*CommitList = null;
    _ = cn.listInsert(old_commit, &list);
    return isDescendantOfChecked(new_commit, list) catch @import("os.zig").exit(128);
}

// ---------------- contains (tag --contains algorithm) ----------------

pub const ContainsResult = enum(u8) { unknown = 0, no, yes, in_progress };
pub const ContainsCache = cn.Slab(ContainsResult);

pub fn newContainsCache() ContainsCache {
    return ContainsCache.init(.unknown);
}

fn inCommitList(want: ?*CommitList, c: *Commit) bool {
    var w = want;
    while (w) |x| : (w = x.next) if (hash.eql(x.item.obj.oid, c.obj.oid)) return true;
    return false;
}

fn containsTest(candidate: *Commit, want: ?*CommitList, cache: *ContainsCache, cutoff: u64) ContainsResult {
    const cached = cache.at(candidate);
    if (cached.* != .unknown) return cached.*;
    if (inCommitList(want, candidate)) {
        cached.* = .yes;
        return .yes;
    }
    cn.parseOrDie(candidate);
    if (generation(candidate) < cutoff) return .no;
    return .unknown;
}

fn containsTagAlgo(candidate: *Commit, want: ?*CommitList, cache: *ContainsCache) ContainsResult {
    var cutoff: u64 = GEN_INFINITY;
    var p = want;
    while (p) |x| : (p = x.next) {
        const g = generation(x.item);
        if (g < cutoff) cutoff = g;
    }
    const r = containsTest(candidate, want, cache, cutoff);
    if (r != .unknown) return r;
    const Entry = struct { commit: *Commit, parents: ?*CommitList };
    var stack: std.ArrayList(Entry) = .empty;
    cache.at(candidate).* = .in_progress;
    stack.append(gpa, .{ .commit = candidate, .parents = candidate.parents }) catch util.oom();
    while (stack.items.len > 0) {
        const entry = &stack.items[stack.items.len - 1];
        const commit = entry.commit;
        const parents = entry.parents;
        if (parents == null) {
            cache.at(commit).* = .no;
            stack.items.len -= 1;
            continue;
        }
        const pl = parents.?;
        switch (containsTest(pl.item, want, cache, cutoff)) {
            .yes => {
                cache.at(commit).* = .yes;
                stack.items.len -= 1;
            },
            .no => entry.parents = pl.next,
            .in_progress => util.die("commit ancestry contains a cycle", .{}),
            .unknown => {
                cache.at(pl.item).* = .in_progress;
                stack.append(gpa, .{ .commit = pl.item, .parents = pl.item.parents }) catch util.oom();
            },
        }
    }
    return containsTest(candidate, want, cache, cutoff);
}

/// commit_contains: does `commit` contain (descend from) any of `list`?
pub fn commitContains(commit: *Commit, list: ?*CommitList, cache: *ContainsCache, with_tag_algo: bool) bool {
    if (with_tag_algo) return containsTagAlgo(commit, list, cache) == .yes;
    return isDescendantOfChecked(commit, list) catch util.die("failed to check reachability", .{});
}

// ---------------- can_all_from_reach ----------------

/// can_all_from_reach_with_flag. `from` are objects (tags are peeled).
pub fn canAllFromReachWithFlag(from: []const *cn.Obj, with_flag: u32, assign_flag: u32, min_commit_date: u64, min_generation: u64) bool {
    var list: std.ArrayList(*Commit) = .empty;
    var result = true;
    blk: {
        for (from) |from_one0| {
            if (from_one0.flags & assign_flag != 0) continue;
            const from_one = cn.derefTag(from_one0);
            if (from_one == null or from_one.?.typ != .commit) {
                from_one0.flags |= assign_flag;
                continue;
            }
            const c = Commit.fromObj(from_one.?);
            list.append(gpa, c) catch util.oom();
            if (!parseLoud(c) or generation(c) < min_generation) {
                result = false;
                break :blk;
            }
        }
        std.sort.block(*Commit, list.items, {}, lessByGen);
        for (list.items) |start| {
            var stack: ?*CommitList = null;
            start.obj.flags |= assign_flag;
            _ = cn.listInsert(start, &stack);
            while (stack) |top| {
                if (top.item.obj.flags & (with_flag | RESULT) != 0) {
                    _ = cn.popCommit(&stack);
                    if (stack) |s| s.item.obj.flags |= RESULT;
                    continue;
                }
                var parent = top.item.parents;
                while (parent) |pl| : (parent = pl.next) {
                    if (pl.item.obj.flags & (with_flag | RESULT) != 0) top.item.obj.flags |= RESULT;
                    if (pl.item.obj.flags & assign_flag == 0) {
                        pl.item.obj.flags |= assign_flag;
                        if (!parseLoud(pl.item) or pl.item.date < min_commit_date or generation(pl.item) < min_generation) continue;
                        _ = cn.listInsert(pl.item, &stack);
                        break;
                    }
                }
                if (parent == null) _ = cn.popCommit(&stack);
            }
            if (start.obj.flags & (with_flag | RESULT) == 0) {
                result = false;
                break :blk;
            }
        }
    }
    cn.clearCommitMarksMany(list.items, RESULT | assign_flag);
    for (from) |o| o.flags &= ~assign_flag;
    return result;
}

/// can_all_from_reach: can every commit in `from` reach some commit in `to`?
pub fn canAllFromReach(from: ?*CommitList, to: ?*CommitList, cutoff_by_min_date: bool) bool {
    var objs: std.ArrayList(*cn.Obj) = .empty;
    var min_commit_date: u64 = if (cutoff_by_min_date and from != null) from.?.item.date else 0;
    var min_generation: u64 = GEN_INFINITY;
    var it = from;
    while (it) |x| : (it = x.next) {
        objs.append(gpa, &x.item.obj) catch util.oom();
        if (cn.parse(x.item)) {
            if (x.item.date < min_commit_date) min_commit_date = x.item.date;
            const g = generation(x.item);
            if (g < min_generation) min_generation = g;
        }
    }
    it = to;
    while (it) |x| : (it = x.next) {
        if (cn.parse(x.item)) {
            if (x.item.date < min_commit_date) min_commit_date = x.item.date;
            const g = generation(x.item);
            if (g < min_generation) min_generation = g;
        }
        x.item.obj.flags |= PARENT2;
    }
    const result = canAllFromReachWithFlag(objs.items, PARENT2, PARENT1, min_commit_date, min_generation);
    it = from;
    while (it) |x| : (it = x.next) cn.clearCommitMarks(x.item, PARENT1);
    it = to;
    while (it) |x| : (it = x.next) cn.clearCommitMarks(x.item, PARENT2);
    return result;
}

/// get_reachable_subset: commits of `to` reachable from some commit of `from`
/// (each gets `reachable_flag`).
pub fn getReachableSubset(from: []const *Commit, to: []const *Commit, reachable_flag: u32) ?*CommitList {
    var found: ?*CommitList = null;
    var min_generation: u64 = GEN_INFINITY;
    var num_to_find: usize = 0;
    var queue = cn.PrioQueue{ .compare = compareByGenThenDate };
    for (to) |c| {
        _ = parseLoud(c);
        const g = generation(c);
        if (g < min_generation) min_generation = g;
        if (c.obj.flags & PARENT1 == 0) {
            c.obj.flags |= PARENT1;
            num_to_find += 1;
        }
    }
    for (from) |c| {
        if (c.obj.flags & PARENT2 == 0) {
            c.obj.flags |= PARENT2;
            _ = parseLoud(c);
            queue.put(c);
        }
    }
    while (num_to_find > 0) {
        const current = queue.get() orelse break;
        if (current.obj.flags & PARENT1 != 0) {
            current.obj.flags &= ~PARENT1;
            current.obj.flags |= reachable_flag;
            _ = cn.listInsert(current, &found);
            num_to_find -= 1;
        }
        var parents = current.parents;
        while (parents) |pl| : (parents = pl.next) {
            const p = pl.item;
            _ = parseLoud(p);
            if (generation(p) < min_generation) continue;
            if (p.obj.flags & PARENT2 != 0) continue;
            p.obj.flags |= PARENT2;
            queue.put(p);
        }
    }
    queue.clear();
    cn.clearCommitMarksMany(to, PARENT1);
    cn.clearCommitMarksMany(from, PARENT2);
    return found;
}

// ---------------- ahead_behind ----------------

pub const AheadBehindCount = struct {
    tip_index: usize,
    base_index: usize,
    ahead: u32 = 0,
    behind: u32 = 0,
};

const NonstaleQueue = struct {
    pq: cn.PrioQueue = .{ .compare = compareByGenThenDate },
    max_nonstale: ?*Commit = null,

    fn put(q: *NonstaleQueue, c: *Commit) void {
        const old = q.max_nonstale;
        q.pq.put(c);
        if (c.obj.flags & STALE != 0) return;
        if (old == null or q.pq.compare.?(old.?, c, null) <= 0) q.max_nonstale = c;
    }
    fn get(q: *NonstaleQueue) ?*Commit {
        const c = q.pq.get();
        if (c != null and c == q.max_nonstale) q.max_nonstale = null;
        return c;
    }
};

/// ahead_behind(): compute ahead/behind counts for each pair in `counts`.
pub fn aheadBehind(commits: []const *Commit, counts: []AheadBehindCount) void {
    if (commits.len == 0 or counts.len == 0) return;
    for (counts) |*c| {
        c.ahead = 0;
        c.behind = 0;
    }
    ensureGenerationsValid(commits);
    const width = (commits.len + 63) / 64;
    var bits = cn.Slab(?[]u64).init(null);
    const Helper = struct {
        fn getBits(s: *cn.Slab(?[]u64), c: *Commit, w: usize) []u64 {
            const slot = s.at(c);
            if (slot.* == null) {
                const b = gpa.alloc(u64, w) catch util.oom();
                @memset(b, 0);
                slot.* = b;
            }
            return slot.*.?;
        }
        fn insertNoDup(q: *NonstaleQueue, c: *Commit) void {
            if (c.obj.flags & PARENT2 != 0) return;
            q.put(c);
            c.obj.flags |= PARENT2;
        }
        fn getBit(b: []const u64, i: usize) bool {
            return (b[i / 64] >> @intCast(i % 64)) & 1 != 0;
        }
    };
    var queue = NonstaleQueue{};
    for (commits, 0..) |c, i| {
        const b = Helper.getBits(&bits, c, width);
        b[i / 64] |= @as(u64, 1) << @intCast(i % 64);
        Helper.insertNoDup(&queue, c);
    }
    while (queue.max_nonstale != null) {
        const c = queue.get() orelse break;
        const bc = Helper.getBits(&bits, c, width);
        for (counts) |*cnt| {
            const from_tip = Helper.getBit(bc, cnt.tip_index);
            const from_base = Helper.getBit(bc, cnt.base_index);
            if (from_tip != from_base) {
                if (from_base) cnt.behind += 1 else cnt.ahead += 1;
            }
        }
        var p = c.parents;
        while (p) |pl| : (p = pl.next) {
            _ = parseLoud(pl.item);
            const bp = Helper.getBits(&bits, pl.item, width);
            var pop: usize = 0;
            for (bp, bc) |*x, y| {
                x.* |= y;
                pop += @popCount(x.*);
            }
            if (pop == commits.len) pl.item.obj.flags |= STALE;
            Helper.insertNoDup(&queue, pl.item);
        }
        bits.at(c).* = null;
    }
    cn.clearAllObjectFlags(PARENT2 | STALE);
}

/// Count commits in ours..theirs symmetric difference: ahead = reachable from ours
/// but not theirs, behind = reachable from theirs but not ours.
pub fn countAheadBehind(ours: *Commit, theirs: *Commit) struct { ahead: usize, behind: usize } {
    // keep in-memory generation numbers unchanged for the rest of the process
    const saved = gpa.dupe(u64, gens.data.items) catch util.oom();
    const commits = [_]*Commit{ ours, theirs };
    var counts = [_]AheadBehindCount{.{ .tip_index = 0, .base_index = 1 }};
    aheadBehind(&commits, &counts);
    gens.data.clearRetainingCapacity();
    gens.data.appendSlice(gpa, saved) catch util.oom();
    return .{ .ahead = counts[0].ahead, .behind = counts[0].behind };
}

// ---------------- tips_reachable_from_bases ----------------

pub fn tipsReachableFromBases(bases: ?*CommitList, tips: []const *Commit, mark: u32) void {
    if (bases == null or tips.len == 0) return;
    const CI = struct { commit: *Commit, gen: u64 };
    const commits = gpa.alloc(CI, tips.len) catch util.oom();
    for (tips, 0..) |t, i| commits[i] = .{ .commit = t, .gen = generation(t) };
    std.sort.block(CI, commits, {}, struct {
        fn lt(_: void, a: CI, b: CI) bool {
            return a.gen < b.gen;
        }
    }.lt);
    var min_generation_index: usize = 0;
    var min_generation = commits[0].gen;
    for (commits) |c| c.commit.obj.flags |= RESULT;
    var stack: ?*CommitList = null;
    var b = bases;
    while (b) |x| : (b = x.next) {
        _ = parseLoud(x.item);
        _ = cn.listInsert(x.item, &stack);
    }
    outer: while (stack) |top| {
        var explored_all = true;
        const c = top.item;
        if (c.obj.flags & RESULT != 0) {
            c.obj.flags |= mark;
            if (commits[min_generation_index].commit.obj.flags & mark != 0) {
                var k = min_generation_index + 1;
                while (k < tips.len and commits[k].commit.obj.flags & mark != 0) k += 1;
                if (k >= tips.len) break :outer;
                min_generation_index = k;
                min_generation = commits[k].gen;
            }
        }
        var p = c.parents;
        while (p) |pl| : (p = pl.next) {
            _ = parseLoud(pl.item);
            if (pl.item.obj.flags & cn.SEEN != 0) continue;
            if (generation(pl.item) < min_generation) continue;
            pl.item.obj.flags |= cn.SEEN;
            explored_all = false;
            _ = cn.listInsert(pl.item, &stack);
            break;
        }
        if (explored_all) _ = cn.popCommit(&stack);
    }
    for (commits) |c| c.commit.obj.flags &= ~RESULT;
    cn.clearAllObjectFlags(cn.SEEN);
}

// ---------------- get_branch_base_for_tip ----------------

pub fn getBranchBaseForTip(tip: *Commit, bases: []const *Commit) i32 {
    if (bases.len == 0) return -1;
    var best_index: i32 = -1;
    var branch_point: ?*Commit = null;
    var queue = cn.PrioQueue{ .compare = compareByGenThenDate };
    var found_missing_gen = false;
    _ = parseLoud(tip);
    if (generation(tip) == GEN_INFINITY) found_missing_gen = true;
    for (bases) |c| {
        _ = parseLoud(c);
        if (generation(c) == GEN_INFINITY) found_missing_gen = true;
    }
    if (found_missing_gen) {
        var all: std.ArrayList(*Commit) = .empty;
        all.appendSlice(gpa, bases) catch util.oom();
        all.append(gpa, tip) catch util.oom();
        ensureGenerationsValid(all.items);
    }
    var best = cn.Slab(i32).init(0);
    best.at(tip).* = -1;
    queue.put(tip);
    for (bases, 0..) |c, i| {
        const bv = best.at(c).*;
        if (bv != 0) {
            if (bv == -1) {
                best_index = @intCast(i + 1);
                return best_index - 1;
            }
            continue;
        }
        best.at(c).* = @intCast(i + 1);
        queue.put(c);
    }
    while (queue.get()) |c| {
        const best_for_c = best.at(c).*;
        if (c == branch_point) break;
        _ = parseLoud(c);
        const pl = c.parents orelse continue;
        const parent = pl.item;
        _ = parseLoud(parent);
        const best_for_p = best.at(parent).*;
        if (best_for_p == 0) {
            best.at(parent).* = best_for_c;
            queue.put(parent);
            continue;
        }
        if (best_for_p > 0 and best_for_c > 0) {
            if (best_for_c < best_for_p) best.at(parent).* = best_for_c;
            continue;
        }
        const positive = if (best_for_c < 0) best_for_p else best_for_c;
        if (best_index < 0 or positive < best_index) best_index = positive;
        best.at(parent).* = -1;
        branch_point = parent;
    }
    return if (best_index > 0) best_index - 1 else -1;
}

// ---------------- fork point ----------------

/// get_fork_point(): find where `commit` forked from the history of `refname`
/// (using its reflog). Dies on unknown/ambiguous refname.
pub fn forkPoint(refname: []const u8, commit: ?*Commit) ?*Commit {
    const d = refs.dwimRef(refname) orelse util.die("No such ref: '{s}'", .{refname});
    if (d.count > 1) util.die("Ambiguous refname: '{s}'", .{refname});
    const full = if (refs.resolve(d.name)) |r| r.name else d.name;
    var stack: std.ArrayList(*Commit) = .empty;
    const Add = struct {
        fn one(st: *std.ArrayList(*Commit), oid: Oid) void {
            if (hash.isZero(oid)) return;
            const c = cn.lookupCommit(oid) orelse return;
            if (c.obj.flags & cn.TMP_MARK != 0) return;
            if (!parseLoud(c)) return;
            st.append(gpa, c) catch util.oom();
            c.obj.flags |= cn.TMP_MARK;
        }
    };
    const entries = refs.readReflog(full);
    for (entries, 0..) |e, i| {
        if (i == 0) Add.one(&stack, e.old);
        Add.one(&stack, e.new);
    }
    if (stack.items.len == 0) Add.one(&stack, d.oid);
    for (stack.items) |c| c.obj.flags &= ~cn.TMP_MARK;
    const bases = getMergeBasesMany0(commit, optSlice(stack.items), true, MB_FIND_ALL) catch @import("os.zig").exit(128);
    const b = bases orelse return null;
    if (b.next != null) return null;
    for (stack.items) |c| {
        if (c == b.item) return c;
    }
    return null;
}
