//! git fsck / git fsck-objects / git mktag (port of builtin/fsck.c and
//! builtin/mktag.c).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const odb_mod = @import("../odb.zig");
const refs = @import("../refs.zig");
const index_mod = @import("../index.zig");
const revparse = @import("../revparse.zig");
const worktree = @import("../worktree.zig");
const fsck = @import("../fsck.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const Obj = fsck.Obj;

const REACHABLE: u32 = 0x1;
const SEEN: u32 = 0x2;
const HAS_OBJ: u32 = 0x4;
const USED: u32 = 0x8;

const ERROR_OBJECT: u8 = 0o1;
const ERROR_REACHABLE: u8 = 0o2;
const ERROR_REFS: u8 = 0o10;

var show_root = false;
var show_tags = false;
var show_unreachable = false;
var include_reflogs = true;
var connectivity_only = false;
var check_strict = false;
var write_lost_and_found = false;
var verbose: i32 = 0;
var show_progress: i32 = -1;
var show_dangling = true;
var now: i64 = 0;
var errors_found: u8 = 0;
var default_refs: usize = 0;

var walk_opts: fsck.Options = .{};
var obj_opts: fsck.Options = .{};
var pending: std.ArrayList(*Obj) = .empty;

fn describe(oid: Oid) []const u8 {
    return fsck.describeObject(&walk_opts, oid);
}

fn printableType(oid: Oid, typ: ObjType) []const u8 {
    var t = typ;
    if (t == .none) t = fsck.readObjectType(oid) orelse .none;
    return fsck.typeName(t) orelse "unknown";
}

fn objerror(obj: *Obj, msg: []const u8) i32 {
    errors_found |= ERROR_OBJECT;
    util.eprint("error in {s} {s}: {s}\n", .{ printableType(obj.oid, obj.typ), describe(obj.oid), msg });
    return -1;
}

fn objectsErrorFunc(o: *fsck.Options, oid: ?Oid, typ: ObjType, mt: fsck.MsgType, id: fsck.MsgId, msg: []const u8) i32 {
    _ = o;
    _ = id;
    const x = oid orelse hash.zero;
    if (mt == .warn) {
        util.eprint("warning in {s} {s}: {s}\n", .{ printableType(x, typ), describe(x), msg });
        return 0;
    }
    util.eprint("error in {s} {s}: {s}\n", .{ printableType(x, typ), describe(x), msg });
    return 1;
}

fn markObject(obj0: ?*Obj, typ: ?ObjType, data: ?*Obj, o: *fsck.Options) i32 {
    _ = o;
    const obj = obj0 orelse {
        const parent = data.?;
        util.outf("broken link from {s:>7} {s}\n", .{ printableType(parent.oid, parent.typ), describe(parent.oid) });
        util.outf("broken link from {s:>7} {s}\n", .{ if (typ) |t| t.name() else "unknown", "unknown" });
        errors_found |= ERROR_REACHABLE;
        return 1;
    };
    if (typ) |t| {
        if (obj.typ != t) _ = objerror(data.?, "wrong object type in link");
    }
    if (obj.flags & REACHABLE != 0) return 0;
    obj.flags |= REACHABLE;
    if (obj.flags & HAS_OBJ == 0) {
        if (data) |parent| {
            if (!fsck.hasObject(obj.oid)) {
                util.outf("broken link from {s:>7} {s}\n              to {s:>7} {s}\n", .{
                    printableType(parent.oid, parent.typ), describe(parent.oid),
                    printableType(obj.oid, obj.typ),       describe(obj.oid),
                });
                errors_found |= ERROR_REACHABLE;
            }
        }
        return 1;
    }
    pending.append(gpa, obj) catch util.oom();
    return 0;
}

fn markObjectReachable(obj: *Obj) void {
    _ = markObject(obj, null, null, &walk_opts);
}

fn freeTreeBuffer(obj: *Obj) void {
    if (obj.typ == .tree) {
        obj.buffer = null;
        obj.parsed = false;
    }
}

fn traverseReachable() void {
    while (pending.pop()) |obj| {
        _ = fsck.fsckWalk(obj, obj, &walk_opts);
        freeTreeBuffer(obj);
    }
}

fn markUsed(obj0: ?*Obj, typ: ?ObjType, data: ?*Obj, o: *fsck.Options) i32 {
    _ = typ;
    _ = data;
    _ = o;
    const obj = obj0 orelse return 1;
    obj.flags |= USED;
    return 0;
}

fn markUnreachableReferents(oid: Oid) void {
    const obj = fsck.lookupObject(oid) orelse return;
    if (obj.flags & HAS_OBJ == 0) return;
    if (obj.flags & REACHABLE != 0) return;
    if (obj.typ == .none) {
        if (fsck.readObjectType(oid)) |t| _ = fsck.objectAsType(obj, t, false);
    }
    var options: fsck.Options = .{ .walk = markUsed };
    _ = fsck.fsckWalk(obj, null, &options);
    freeTreeBuffer(obj);
}

fn checkReachableObject(obj: *Obj) void {
    if (obj.flags & HAS_OBJ == 0) {
        if (repo_mod.repo().odb().findPacked(obj.oid) != null) return;
        util.outf("missing {s} {s}\n", .{ printableType(obj.oid, obj.typ), describe(obj.oid) });
        errors_found |= ERROR_REACHABLE;
    }
}

fn checkUnreachableObject(obj: *Obj) void {
    if (obj.flags & HAS_OBJ == 0) return;
    if (show_unreachable) {
        util.outf("unreachable {s} {s}\n", .{ printableType(obj.oid, obj.typ), describe(obj.oid) });
        return;
    }
    if (obj.flags & USED == 0) {
        if (show_dangling) util.outf("dangling {s} {s}\n", .{ printableType(obj.oid, obj.typ), describe(obj.oid) });
        if (write_lost_and_found) {
            const r = repo_mod.repo();
            const filename = r.gitPath(util.concat(&.{ "lost-found/", if (obj.typ == .commit) "commit" else "other", "/", describe(obj.oid) }));
            if (!os.mkdirLeading(filename)) {
                util.err("could not create lost-found", .{});
                return;
            }
            var content: []const u8 = undefined;
            if (obj.typ == .blob) {
                const rd = fsck.readObject(obj.oid, true) orelse util.dieErrno("could not write '{s}'", .{filename});
                content = rd.data;
            } else content = util.concat(&.{ describe(obj.oid), "\n" });
            os.writeFile(filename, content, 0o666) catch util.dieErrno("could not finish '{s}'", .{filename});
        }
    }
}

fn checkObject(obj: *Obj) void {
    if (verbose > 0) util.eprint("Checking {s}\n", .{describe(obj.oid)});
    if (obj.flags & REACHABLE != 0) checkReachableObject(obj) else checkUnreachableObject(obj);
}

fn checkConnectivity() void {
    traverseReachable();
    if (connectivity_only and (show_dangling or write_lost_and_found)) {
        for (repo_mod.repo().odb().allObjects(true)) |oid| markUnreachableReferents(oid);
    }
    const max = fsck.obj_hash.len;
    if (verbose > 0) util.eprint("Checking connectivity ({d} objects)\n", .{max});
    var i: usize = 0;
    while (i < fsck.obj_hash.len) : (i += 1) {
        if (fsck.obj_hash[i]) |obj| checkObject(obj);
    }
}

fn fsckObjBuffer(oid: Oid, typ: ObjType, data: []const u8) i32 {
    const obj = fsck.parseObjectBuffer(oid, typ, data) orelse {
        errors_found |= ERROR_OBJECT;
        util.err("{s}: object corrupt or missing", .{&hash.hex(oid)});
        return -1;
    };
    defer freeTreeBuffer(obj);
    obj.flags &= ~REACHABLE;
    obj.flags |= HAS_OBJ | SEEN;
    if (verbose > 0) util.eprint("Checking {s} {s}\n", .{ printableType(obj.oid, obj.typ), describe(obj.oid) });
    if (fsck.fsckWalk(obj, null, &obj_opts) != 0) _ = objerror(obj, "broken links");
    const e = fsck.fsckObject(obj, data, &obj_opts);
    if (e != 0) return e;
    if (obj.typ == .commit and obj.parents.len == 0 and show_root)
        util.outf("root {s}\n", .{describe(obj.oid)});
    if (obj.typ == .tag and show_tags) {
        if (obj.tagged) |t| {
            util.outf("tagged {s} {s} ({s}) in {s}\n", .{ printableType(t.oid, t.typ), describe(t.oid), obj.tag_name, describe(obj.oid) });
        }
    }
    return 0;
}

// ---------------------------------------------------------------------------
// object database checks

fn fsckLooseDir(dir: []const u8) bool {
    var error_found = false;
    if (verbose > 0) util.eprint("Checking object directory\n", .{});
    var b: usize = 0;
    while (b < 256) : (b += 1) {
        const hx = util.fmt("{x:0>2}", .{b});
        const sub = util.concat(&.{ dir, "/", hx });
        const ents = os.listDir(sub) orelse continue;
        for (ents) |e| {
            const path = util.concat(&.{ sub, "/", e.name });
            if (e.name.len == 38) {
                if (hash.fromHex(util.concat(&.{ hx, e.name }))) |oid| {
                    const r = fsck.readLooseObject(path, oid, false);
                    if (!r.ok) {
                        if (r.contents != null and !hash.eql(r.real, oid)) {
                            util.err("{s}: hash-path mismatch, found at: {s}", .{ &hash.hex(r.real), path });
                        } else util.err("{s}: object corrupt or missing: {s}", .{ &hash.hex(oid), path });
                        error_found = true;
                        continue;
                    }
                    if (fsckObjBuffer(oid, r.typ.?, r.contents.?) != 0) error_found = true;
                    continue;
                }
            }
            if (!util.startsWith(e.name, "tmp_obj_")) util.eprint("bad sha1 file: {s}\n", .{path});
        }
    }
    return !error_found;
}

fn sha1(data: []const u8) Oid {
    var h = hash.Hasher.init(.{});
    h.update(data);
    var o: Oid = undefined;
    h.final(&o);
    return o;
}

const IdxEntry = struct { offset: u64, nr: u32 };

fn verifyPack(p: *odb_mod.Pack) bool {
    var ok = true;
    const idx = p.idx;
    if (idx.len < 40 or !std.mem.eql(u8, &sha1(idx[0 .. idx.len - 20]), idx[idx.len - 20 ..])) {
        util.err("Packfile index for {s} hash mismatch", .{p.pack_path});
        ok = false;
    }
    const data = os.readFile(p.pack_path) orelse {
        util.err("packfile {s} cannot be accessed", .{p.pack_path});
        return false;
    };
    if (data.len < 32 or !std.mem.eql(u8, data[0..4], "PACK") or std.mem.readInt(u32, data[8..12], .big) != p.num) {
        util.err("packfile {s} cannot be accessed", .{p.pack_path});
        return false;
    }
    const sig_ofs = data.len - 20;
    if (!std.mem.eql(u8, &sha1(data[0..sig_ofs]), data[sig_ofs..])) {
        util.err("{s} pack checksum mismatch", .{p.pack_path});
        ok = false;
    }
    if (!std.mem.eql(u8, idx[idx.len - 40 .. idx.len - 20], data[sig_ofs..])) {
        util.err("{s} pack checksum does not match its index", .{p.pack_path});
        ok = false;
    }
    const entries = gpa.alloc(IdxEntry, p.num + 1) catch util.oom();
    entries[p.num] = .{ .offset = sig_ofs, .nr = 0 };
    var i: u32 = 0;
    while (i < p.num) : (i += 1) entries[i] = .{ .offset = p.offsetAt(i), .nr = i };
    std.mem.sort(IdxEntry, entries[0..p.num], {}, struct {
        fn lt(_: void, a: IdxEntry, b: IdxEntry) bool {
            return a.offset < b.offset;
        }
    }.lt);
    const odb = repo_mod.repo().odb();
    i = 0;
    while (i < p.num) : (i += 1) {
        const ent = entries[i];
        const oid = p.oidAt(ent.nr);
        if (p.version > 1) {
            const off: usize = @intCast(ent.offset);
            const end: usize = @intCast(@min(entries[i + 1].offset, data.len));
            const crc_pos = 8 + 1024 + @as(usize, p.num) * 20 + @as(usize, ent.nr) * 4;
            const want = if (crc_pos + 4 <= idx.len) std.mem.readInt(u32, idx[crc_pos..][0..4], .big) else 0;
            const got: u32 = if (off <= end) @truncate(@import("../zlib.zig").crc(0, data[off..end])) else 0;
            if (got != want) {
                util.err("index CRC mismatch for object {s} from {s} at offset {d}", .{ &hash.hex(oid), p.pack_path, ent.offset });
                ok = false;
            }
        }
        const obj = odb.readPacked(p, ent.offset) orelse {
            util.err("cannot unpack {s} from {s} at offset {d}", .{ &hash.hex(oid), p.pack_path, ent.offset });
            ok = false;
            continue;
        };
        if (!hash.eql(odb_mod.hashObject(obj.typ, obj.data), oid)) {
            util.err("packed {s} from {s} is corrupt", .{ &hash.hex(oid), p.pack_path });
            ok = false;
            continue;
        }
        if (fsckObjBuffer(oid, obj.typ, obj.data) != 0) ok = false;
    }
    return ok;
}

fn odbFsck(full: bool) bool {
    const odb = repo_mod.repo().odb();
    odb.reloadPacks();
    var ok = true;
    for (odb.allDirs(), 0..) |dir, di| {
        if (!full and di > 0) continue;
        if (!fsckLooseDir(dir)) ok = false;
        if (full) {
            const pfx = util.concat(&.{ dir, "/pack/" });
            for (odb.packs.items) |p| {
                if (!util.startsWith(p.idx_path, pfx)) continue;
                if (!verifyPack(p)) ok = false;
            }
        }
    }
    return ok;
}

// ---------------------------------------------------------------------------
// refs, reflogs, index

const Snap = struct { name: []const u8, oid: Oid };
var snapshot: std.ArrayList(Snap) = .empty;

fn snapshotRef(name: []const u8, oid: Oid) void {
    const obj = fsck.parseObject(oid) orelse {
        util.err("{s}: invalid sha1 pointer {s}", .{ name, &hash.hex(oid) });
        errors_found |= ERROR_REACHABLE;
        return;
    };
    if (obj.typ != .commit and util.startsWith(name, "refs/heads/")) {
        util.err("{s}: not a commit", .{name});
        errors_found |= ERROR_REFS;
    }
    default_refs += 1;
    snapshot.append(gpa, .{ .name = util.dupe(name), .oid = oid }) catch util.oom();
}

fn worktreeRef(wt: *const worktree.Worktree, name: []const u8) []const u8 {
    if (!wt.is_current) {
        if (wt.isMain()) return util.concat(&.{ "main-worktree/", name });
        return util.concat(&.{ "worktrees/", wt.id.?, "/", name });
    }
    return name;
}

fn snapshotRefs(args: []const []const u8) void {
    for (args) |arg| {
        if (revparse.getOid(arg)) |oid| {
            snapshotRef(arg, oid);
            continue;
        }
        util.err("invalid parameter: expected sha1, got '{s}'", .{arg});
        errors_found |= ERROR_OBJECT;
    }
    if (args.len > 0) {
        include_reflogs = false;
        return;
    }
    for (refs.iterate("refs/", .{ .include_broken = true, .check_objects = false })) |r| snapshotRef(r.name, r.oid);
    for (worktree.getAllWithoutHead()) |wt| {
        const name = worktreeRef(wt, "HEAD");
        const res = refs.resolveFull(name, false);
        if (!res.broken and !hash.isZero(res.oid)) snapshotRef(name, res.oid);
    }
    now = os.now();
}

fn reflogTimestamp(ident: []const u8) i64 {
    const gt = std.mem.lastIndexOfScalar(u8, ident, '>') orelse return 0;
    var s = ident[gt + 1 ..];
    s = std.mem.trimStart(u8, s, " ");
    var end: usize = 0;
    while (end < s.len and std.ascii.isDigit(s[end])) end += 1;
    return std.fmt.parseInt(i64, s[0..end], 10) catch 0;
}

fn handleReflogOid(refname: []const u8, oid: Oid, timestamp: i64) void {
    if (hash.isZero(oid)) return;
    if (fsck.lookupObject(oid)) |obj| {
        if (obj.flags & HAS_OBJ != 0) {
            if (timestamp != 0) fsck.putObjectName(&walk_opts, oid, "{s}@{{{d}}}", .{ refname, timestamp });
            obj.flags |= USED;
            markObjectReachable(obj);
            return;
        }
    }
    util.err("{s}: invalid reflog entry {s}", .{ refname, &hash.hex(oid) });
    errors_found |= ERROR_REACHABLE;
}

fn handleReflog(refname: []const u8) void {
    for (refs.readReflog(refname)) |e| {
        const ts = reflogTimestamp(e.ident);
        if (now != 0 and ts > now) continue;
        if (verbose > 0) util.eprint("Checking reflog {s}->{s}\n", .{ &hash.hex(e.old), &hash.hex(e.new) });
        handleReflogOid(refname, e.old, 0);
        handleReflogOid(refname, e.new, ts);
    }
}

fn collectLogs(base: []const u8, rel: []const u8, out: *std.ArrayList([]const u8)) void {
    const dir = if (rel.len == 0) base else util.concat(&.{ base, "/", rel });
    const ents = os.listDir(dir) orelse return;
    for (ents) |e| {
        const name = if (rel.len == 0) e.name else util.concat(&.{ rel, "/", e.name });
        const full = util.concat(&.{ base, "/", name });
        if (os.isDir(full)) collectLogs(base, name, out) else if (os.isFile(full)) out.append(gpa, name) catch util.oom();
    }
}

fn worktreeReflogs(wt: *const worktree.Worktree) [][]const u8 {
    if (wt.is_current) return refs.listReflogs();
    const r = repo_mod.repo();
    var names: std.ArrayList([]const u8) = .empty;
    var tmp: std.ArrayList([]const u8) = .empty;
    collectLogs(util.concat(&.{ wt.gitDir(), "/logs" }), "", &tmp);
    for (tmp.items) |n| {
        if (!wt.isMain() and !refs.isPerWorktreeRef(n)) continue;
        if (refs.checkRefnameFormat(n, refs.ALLOW_ONELEVEL)) names.append(gpa, n) catch util.oom();
    }
    if (!wt.isMain()) {
        tmp = .empty;
        collectLogs(util.concat(&.{ r.common_dir, "/logs" }), "", &tmp);
        for (tmp.items) |n| {
            if (refs.isPerWorktreeRef(n)) continue;
            if (refs.checkRefnameFormat(n, refs.ALLOW_ONELEVEL)) names.append(gpa, n) catch util.oom();
        }
    }
    util.sortStrings(names.items);
    return names.items;
}

fn processRefs() void {
    for (snapshot.items) |s| {
        const obj = fsck.parseObject(s.oid) orelse continue;
        obj.flags |= USED;
        fsck.putObjectName(&walk_opts, s.oid, "{s}", .{s.name});
        markObjectReachable(obj);
    }
    if (include_reflogs) {
        for (worktree.getAllWithoutHead()) |wt| {
            for (worktreeReflogs(wt)) |n| handleReflog(worktreeRef(wt, n));
        }
    }
    if (default_refs == 0) {
        util.eprint("notice: No default references\n", .{});
        show_unreachable = false;
    }
}

fn fsckCacheTree(it: *index_mod.CacheTree, index_path: []const u8) i32 {
    var e: i32 = 0;
    if (verbose > 0) util.eprint("Checking cache tree of {s}\n", .{index_path});
    if (it.entry_count >= 0) {
        const obj = fsck.parseObject(it.oid) orelse {
            util.err("{s}: invalid sha1 pointer in cache-tree of {s}", .{ &hash.hex(it.oid), index_path });
            errors_found |= ERROR_REFS;
            return 1;
        };
        obj.flags |= USED;
        fsck.putObjectName(&walk_opts, it.oid, ":", .{});
        markObjectReachable(obj);
        if (obj.typ != .tree) e |= objerror(obj, "non-tree in cache-tree");
    }
    for (it.children.items) |c| e |= fsckCacheTree(c, index_path);
    return e;
}

fn fsckIndex(idx: *index_mod.Index, index_path: []const u8, is_current: bool) void {
    for (idx.entries.items) |*ce| {
        if (ce.mode & os.S_IFMT == os.S_IFGITLINK) continue;
        const obj = fsck.lookupTyped(ce.oid, .blob) orelse continue;
        obj.flags |= USED;
        fsck.putObjectName(&walk_opts, obj.oid, "{s}:{s}", .{ if (is_current) "" else index_path, ce.path });
        markObjectReachable(obj);
    }
    if (idx.cache_tree) |ct| _ = fsckCacheTree(ct, index_path);
    for (idx.reuc.items) |ru| {
        for (0..3) |i| {
            if (ru.modes[i] == 0 or ru.modes[i] & os.S_IFMT != os.S_IFREG) continue;
            const obj = fsck.parseObject(ru.oids[i]) orelse {
                util.err("{s}: invalid sha1 pointer in resolve-undo of {s}", .{ &hash.hex(ru.oids[i]), index_path });
                errors_found |= ERROR_REFS;
                continue;
            };
            obj.flags |= USED;
            fsck.putObjectName(&walk_opts, ru.oids[i], ":({d}):{s}", .{ i, ru.path });
            markObjectReachable(obj);
        }
    }
}

fn fsckRefs() void {
    if (verbose > 0) util.eprint("Checking ref database\n", .{});
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ os.readLink("/proc/self/exe") orelse "git", "refs", "verify" }) catch util.oom();
    if (verbose > 0) argv.append(gpa, "--verbose") catch util.oom();
    if (check_strict) argv.append(gpa, "--strict") catch util.oom();
    const res = os.run(argv.items, .{});
    if (res.status != 0 or res.signaled) errors_found |= ERROR_REFS;
}

const fsck_usage = [_][]const u8{
    "git fsck [--tags] [--root] [--unreachable] [--cache] [--no-reflogs]\n" ++
        "         [--[no-]full] [--strict] [--verbose] [--lost-found]\n" ++
        "         [--[no-]dangling] [--[no-]progress] [--connectivity-only]\n" ++
        "         [--[no-]name-objects] [--[no-]references] [<object>...]",
};

var keep_cache_objects = false;
var name_objects = false;
var check_references = true;
var full_flag: i32 = 1;

pub fn cmdFsck(args: []const []const u8) u8 {
    const options = [_]po.Opt{
        po.verbose(&verbose),
        po.boolean(0, "unreachable", &show_unreachable, "show unreachable objects"),
        po.boolean(0, "dangling", &show_dangling, "show dangling objects"),
        po.boolean(0, "tags", &show_tags, "report tags"),
        po.boolean(0, "root", &show_root, "report root nodes"),
        po.boolean(0, "cache", &keep_cache_objects, "make index objects head nodes"),
        po.boolean(0, "reflogs", &include_reflogs, "make reflogs head nodes (default)"),
        po.bit(0, "full", &full_flag, 1, "also consider packs and alternate objects"),
        po.boolean(0, "connectivity-only", &connectivity_only, "check only connectivity"),
        po.boolean(0, "strict", &check_strict, "enable more strict checking"),
        po.boolean(0, "lost-found", &write_lost_and_found, "write dangling objects in .git/lost-found"),
        po.setInt(0, "progress", &show_progress, 1, "show progress"),
        po.boolean(0, "name-objects", &name_objects, "show verbose names for reachable objects"),
        po.boolean(0, "references", &check_references, "check reference database consistency"),
    };
    const rest = po.parse(args[1..], &options, &fsck_usage, .{});

    walk_opts = .{ .walk = markObject };
    obj_opts = .{ .walk = markUsed, .error_func = objectsErrorFunc, .strict = check_strict };

    if (show_progress == -1) show_progress = if (os.isatty(2)) 1 else 0;
    if (verbose > 0) show_progress = 0;
    if (write_lost_and_found) {
        full_flag |= 1;
        include_reflogs = false;
    }
    if (name_objects) fsck.enableObjectNames(&walk_opts);
    fsck.applyConfig(&obj_opts);

    if (check_references) fsckRefs();

    snapshotRefs(rest);

    repo_mod.repo().odb().reloadPacks();

    if (connectivity_only) {
        for (repo_mod.repo().odb().allObjects(true)) |oid| {
            const obj = fsck.lookupUnknown(oid);
            obj.flags |= HAS_OBJ;
        }
    } else {
        if (!odbFsck(full_flag & 1 != 0)) errors_found |= ERROR_OBJECT;
        if (fsck.fsckFinish(&obj_opts) != 0) errors_found |= ERROR_OBJECT;
    }

    processRefs();

    if (rest.len == 0) keep_cache_objects = true;
    if (keep_cache_objects) {
        const r = repo_mod.repo();
        for (worktree.getAllWithoutHead()) |wt| {
            const path = if (wt.is_current) r.indexPath() else wt.gitPath("index");
            const idx = index_mod.readFrom(path);
            fsckIndex(idx, path, wt.is_current);
        }
    }

    checkConnectivity();
    util.flushStdout();
    return errors_found;
}

// ---------------------------------------------------------------------------
// mktag

var mktag_strict = true;

fn mktagErrorFunc(o: *fsck.Options, oid: ?Oid, typ: ObjType, mt: fsck.MsgType, id: fsck.MsgId, msg: []const u8) i32 {
    _ = o;
    _ = oid;
    _ = typ;
    _ = id;
    if (mt == .warn and !mktag_strict) {
        util.eprint("warning: tag input does not pass fsck: {s}\n", .{msg});
        return 0;
    }
    util.eprint("error: tag input does not pass fsck: {s}\n", .{msg});
    return 1;
}

pub fn cmdMktag(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git mktag"};
    const options = [_]po.Opt{
        po.boolean(0, "strict", &mktag_strict, "enable more strict checking"),
    };
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len > 0) po.usageWithOptions(&usage, &options);
    const buf = os.readAllFd(0) catch util.dieErrno("could not read from stdin", .{});

    var o: fsck.Options = .{ .strict = true, .error_func = mktagErrorFunc };
    fsck.setMsgTypeFromId(&o, .extra_header_entry, .warn);
    fsck.applyConfig(&o);
    var tagged_oid: Oid = hash.zero;
    var tagged_type: ?ObjType = null;
    if (fsck.fsckTagStandalone(null, buf, &o, &tagged_oid, &tagged_type) != 0)
        util.die("tag on stdin did not pass our strict fsck check", .{});

    const tt = tagged_type orelse util.die("tag on stdin did not pass our strict fsck check", .{});
    const rd = fsck.readObject(tagged_oid, true) orelse util.die("could not read tagged object '{s}'", .{&hash.hex(tagged_oid)});
    if (rd.typ != tt) util.die("object '{s}' tagged as '{s}', but is a '{s}' type", .{ &hash.hex(tagged_oid), tt.name(), rd.typ.name() });
    if (!hash.eql(odb_mod.hashObject(rd.typ, rd.data), tagged_oid)) {
        util.err("hash mismatch {s}", .{&hash.hex(tagged_oid)});
        util.die("tag on stdin did not refer to a valid object", .{});
    }
    const result = repo_mod.repo().odb().write(.tag, buf);
    util.outf("{s}\n", .{&hash.hex(result)});
    util.flushStdout();
    return 0;
}
