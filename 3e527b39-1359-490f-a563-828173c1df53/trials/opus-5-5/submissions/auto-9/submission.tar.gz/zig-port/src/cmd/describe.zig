//! git describe (port of builtin/describe.c) and git name-rev (port of
//! builtin/name-rev.c). name-rev lives here because `describe --contains`
//! runs it in-process.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const cn = @import("../commitnode.zig");
const objects = @import("../objects.zig");
const refs = @import("../refs.zig");
const repo_mod = @import("../repo.zig");
const wildmatch = @import("../wildmatch.zig");
const index_mod = @import("../index.zig");
const lockfile = @import("../lockfile.zig");
const main = @import("../main.zig");
const Commit = cn.Commit;
const CommitList = cn.CommitList;
const Oid = hash.Oid;
const gpa = util.gpa;

const TIME_MAX: u64 = std.math.maxInt(u64);

// ---------------------------------------------------------------------------
// shared helpers
// ---------------------------------------------------------------------------

/// repo_parse_commit(): loud on missing objects.
fn parseCommitLoud(c: *Commit) bool {
    if (cn.parse(c)) return true;
    util.err("Could not read {s}", .{hash.hex(c.obj.oid)});
    return false;
}

/// parse_tag_date(): timestamp after the first '>' on the tagger line.
fn tagDate(t: objects.Tag) u64 {
    const tg = t.tagger orelse return 0;
    const gt = std.mem.indexOfScalar(u8, tg, '>') orelse return 0;
    if (gt + 1 >= tg.len) return 0;
    return cn.parseTimestamp(tg[gt + 1 ..]);
}

const TagInfo = struct {
    tag: []const u8,
    date: u64,
    tagged: Oid,
};

/// lookup_tag() + parse_tag(): null on failure.
fn lookupTag(oid: Oid) ?TagInfo {
    const obj = repo_mod.repo().odb().read(oid) orelse return null;
    if (obj.typ != .tag) return null;
    const t = objects.parseTag(obj.data) orelse return null;
    if (t.typ == .none) return null;
    if (std.mem.indexOf(u8, obj.data, "\ntag ") == null) return null;
    return .{ .tag = t.tag, .date = tagDate(t), .tagged = t.object };
}

/// repo_find_unique_abbrev() with git's len semantics (-1 default, 0 full).
fn findUniqueAbbrev(oid: Oid, len: i32) []const u8 {
    if (len == 0) return hash.hexAlloc(oid);
    if (len < 0) return revparse.abbrev(oid, 0);
    const l: usize = @intCast(@min(len, 40));
    return revparse.abbrev(oid, l);
}

// ---------------------------------------------------------------------------
// name-rev
// ---------------------------------------------------------------------------

const CUTOFF_DATE_SLOP: u64 = 86400;
const MERGE_TRAVERSAL_WEIGHT: i32 = 65535;
const GEN_INFINITY: u64 = (1 << 63) - 1;

const RevName = struct {
    tip_name: ?[]const u8 = null,
    taggerdate: u64 = 0,
    generation: i32 = 0,
    distance: i32 = 0,
    from_tag: bool = false,
};

var rev_names: cn.Slab(RevName) = cn.Slab(RevName).init(.{});
var generation_cutoff: u64 = GEN_INFINITY;
var cutoff: u64 = TIME_MAX;

fn disableCutoff() void {
    generation_cutoff = 0;
    cutoff = 0;
}

fn setCommitCutoff(c: *Commit) void {
    if (cutoff > c.date) cutoff = c.date;
    // no commit-graph: generation is always infinity, generation_cutoff stays.
}

fn adjustCutoffForSlop() void {
    if (cutoff != 0) {
        if (cutoff > CUTOFF_DATE_SLOP) cutoff -= CUTOFF_DATE_SLOP else cutoff = 0;
    }
}

fn isBeforeCutoff(c: *Commit) bool {
    if (generation_cutoff < GEN_INFINITY) {
        return generation_cutoff != 0 and GEN_INFINITY < generation_cutoff;
    }
    return c.date < cutoff;
}

fn getCommitRevName(c: *const Commit) ?*RevName {
    const n = rev_names.peek(c) orelse return null;
    if (n.tip_name == null) return null;
    return n;
}

fn effectiveDistance(distance: i32, generation: i32) i32 {
    return distance +% (if (generation > 0) MERGE_TRAVERSAL_WEIGHT else 0);
}

fn isBetterName(name: *RevName, taggerdate: u64, generation: i32, distance: i32, from_tag: bool) bool {
    const name_distance = effectiveDistance(name.distance, name.generation);
    const new_distance = effectiveDistance(distance, generation);
    if (from_tag and name.from_tag) return name_distance > new_distance;
    if (name.from_tag != from_tag) return from_tag;
    if (name_distance != new_distance) return name_distance > new_distance;
    if (name.taggerdate != taggerdate) return name.taggerdate > taggerdate;
    return false;
}

fn createOrUpdateName(c: *Commit, taggerdate: u64, generation: i32, distance: i32, from_tag: bool) ?*RevName {
    const name = rev_names.at(c);
    if (name.tip_name != null and !isBetterName(name, taggerdate, generation, distance, from_tag)) return null;
    name.taggerdate = taggerdate;
    name.generation = generation;
    name.distance = distance;
    name.from_tag = from_tag;
    return name;
}

fn stripCaret0(s: []const u8) []const u8 {
    if (util.endsWith(s, "^0")) return s[0 .. s.len - 2];
    return s;
}

fn getParentName(name: *const RevName, parent_number: i32) []const u8 {
    const base = stripCaret0(name.tip_name.?);
    if (name.generation > 0) return util.fmt("{s}~{d}^{d}", .{ base, name.generation, parent_number });
    return util.fmt("{s}^{d}", .{ base, parent_number });
}

fn nameRev(start: *Commit, tip_name: []const u8, taggerdate: u64, from_tag: bool, deref: bool) void {
    _ = parseCommitLoud(start);
    if (isBeforeCutoff(start)) return;
    const start_name = createOrUpdateName(start, taggerdate, 0, 0, from_tag) orelse return;
    start_name.tip_name = if (deref) util.fmt("{s}^0", .{tip_name}) else util.dupe(tip_name);

    var stack: std.ArrayList(*Commit) = .empty;
    var to_queue: std.ArrayList(*Commit) = .empty;
    stack.append(gpa, start) catch util.oom();
    while (stack.pop()) |commit| {
        to_queue.clearRetainingCapacity();
        var parent_number: i32 = 1;
        var parents = commit.parents;
        while (parents) |pl| : ({
            parents = pl.next;
            parent_number += 1;
        }) {
            const parent = pl.item;
            _ = parseCommitLoud(parent);
            if (isBeforeCutoff(parent)) continue;
            const name = getCommitRevName(commit).?;
            var generation: i32 = undefined;
            var distance: i32 = undefined;
            if (parent_number > 1) {
                generation = 0;
                distance = name.distance +% MERGE_TRAVERSAL_WEIGHT;
            } else {
                generation = name.generation +% 1;
                distance = name.distance +% 1;
            }
            if (createOrUpdateName(parent, taggerdate, generation, distance, from_tag)) |pn| {
                // name may have been invalidated by slab growth; re-fetch
                const cur = getCommitRevName(commit).?;
                if (parent_number > 1) pn.tip_name = getParentName(cur, parent_number) else pn.tip_name = cur.tip_name;
                to_queue.append(gpa, parent) catch util.oom();
            }
        }
        while (to_queue.pop()) |p| stack.append(gpa, p) catch util.oom();
    }
}

fn subpathMatches(path: []const u8, filter: []const u8) i32 {
    var off: usize = 0;
    while (true) {
        if (wildmatch.match(filter, path[off..], 0)) return @intCast(off);
        const slash = std.mem.indexOfScalarPos(u8, path, off, '/') orelse return -1;
        off = slash + 1;
    }
}

const TipEntry = struct {
    oid: Oid,
    refname: []const u8,
    commit: ?*Commit,
    taggerdate: u64,
    from_tag: bool,
    deref: bool,
};

var tip_table: std.ArrayList(TipEntry) = .empty;
var tip_sorted = false;

const NameRefData = struct {
    tags_only: bool = false,
    name_only: bool = false,
    ref_filters: std.ArrayList([]const u8) = .empty,
    exclude_filters: std.ArrayList([]const u8) = .empty,
};

fn addToTipTable(oid: Oid, refname0: []const u8, shorten: bool, commit: ?*Commit, taggerdate: u64, from_tag: bool, deref: bool) void {
    var refname = refname0;
    if (shorten) {
        refname = refs.shortenUnambiguous(refname0);
    } else if (util.skipPrefix(refname, "refs/heads/")) |r| {
        refname = r;
    } else if (util.skipPrefix(refname, "refs/")) |r| {
        refname = r;
    }
    tip_table.append(gpa, .{
        .oid = oid,
        .refname = util.dupe(refname),
        .commit = commit,
        .taggerdate = taggerdate,
        .from_tag = from_tag,
        .deref = deref,
    }) catch util.oom();
    tip_sorted = false;
}

fn nameRef(ref: refs.Ref, data: *const NameRefData) void {
    var o: ?*cn.Obj = cn.parseObject(ref.oid);
    var can_abbreviate = data.tags_only and data.name_only;
    var deref = false;
    var from_tag = false;
    var commit: ?*Commit = null;
    var taggerdate: u64 = TIME_MAX;

    if (data.tags_only and !util.startsWith(ref.name, "refs/tags/")) return;
    for (data.exclude_filters.items) |f| {
        if (subpathMatches(ref.name, f) >= 0) return;
    }
    if (data.ref_filters.items.len > 0) {
        var matched = false;
        for (data.ref_filters.items) |f| {
            const r = subpathMatches(ref.name, f);
            if (r == 0) {
                matched = true;
            } else if (r > 0) {
                matched = true;
                can_abbreviate = true;
            }
        }
        if (!matched) return;
    }
    while (o) |obj| {
        if (obj.typ != .tag) break;
        const raw = repo_mod.repo().odb().read(obj.oid) orelse break;
        const t = objects.parseTag(raw.data) orelse break;
        o = cn.parseObject(t.object);
        deref = true;
        taggerdate = tagDate(t);
    }
    if (o) |obj| {
        if (obj.typ == .commit) {
            const c = Commit.fromObj(obj);
            commit = c;
            from_tag = util.startsWith(ref.name, "refs/tags/");
            if (taggerdate == TIME_MAX) taggerdate = c.date;
        }
    }
    addToTipTable(ref.oid, ref.name, can_abbreviate, commit, taggerdate, from_tag, deref);
}

fn cmpByTagAndAge(_: void, a: TipEntry, b: TipEntry) bool {
    if (a.from_tag != b.from_tag) return a.from_tag;
    return a.taggerdate < b.taggerdate;
}

fn nameTips() void {
    std.sort.block(TipEntry, tip_table.items, {}, cmpByTagAndAge);
    for (tip_table.items) |e| {
        if (e.commit) |c| nameRev(c, e.refname, e.taggerdate, e.from_tag, e.deref);
    }
}

fn tipLess(_: void, a: TipEntry, b: TipEntry) bool {
    return hash.order(a.oid, b.oid) == .lt;
}

fn take2(o: Oid, ofs: usize) usize {
    return (@as(usize, o[ofs]) << 8) | o[ofs + 1];
}

/// oid_pos() from hash-lookup.c
fn oidPos(oid: Oid, table: []const TipEntry) ?usize {
    const nr = table.len;
    if (nr == 0) return null;
    var hi = nr;
    var lo: usize = 0;
    var mi: usize = 0;
    if (nr != 1) {
        var ofs: usize = 0;
        while (ofs < 20 - 2) : (ofs += 2) {
            const lov = take2(table[0].oid, ofs);
            const hiv = take2(table[nr - 1].oid, ofs);
            const miv = take2(oid, ofs);
            if (miv < lov) return null;
            if (hiv < miv) return null;
            if (lov != hiv) {
                mi = (nr - 1) * (miv - lov) / (hiv - lov);
                break;
            }
        }
    }
    while (true) {
        const c = hash.order(table[mi].oid, oid);
        if (c == .eq) return mi;
        if (c == .gt) hi = mi else lo = mi + 1;
        mi = lo + (hi - lo) / 2;
        if (!(lo < hi)) break;
    }
    return null;
}

fn getExactRefMatch(o: *const cn.Obj) ?[]const u8 {
    if (tip_table.items.len == 0) return null;
    if (!tip_sorted) {
        std.sort.block(TipEntry, tip_table.items, {}, tipLess);
        tip_sorted = true;
    }
    const i = oidPos(o.oid, tip_table.items) orelse return null;
    return tip_table.items[i].refname;
}

fn getRevName(o: *cn.Obj) ?[]const u8 {
    if (o.typ != .commit) return getExactRefMatch(o);
    const c = Commit.fromObj(o);
    const n = getCommitRevName(c) orelse return null;
    if (n.generation == 0) return n.tip_name.?;
    return util.fmt("{s}~{d}", .{ stripCaret0(n.tip_name.?), n.generation });
}

fn showName(obj: *cn.Obj, caller_name: ?[]const u8, always: bool, allow_undefined: bool, name_only: bool) void {
    if (!name_only) {
        if (caller_name) |cname| util.outf("{s} ", .{cname}) else util.outf("{s} ", .{hash.hex(obj.oid)});
    }
    if (getRevName(obj)) |name| {
        util.outf("{s}\n", .{name});
    } else if (allow_undefined) {
        util.out("undefined\n");
    } else if (always) {
        util.outf("{s}\n", .{revparse.abbrev(obj.oid, 0)});
    } else {
        util.die("cannot describe '{s}'", .{hash.hex(obj.oid)});
    }
}

fn isHex(ch: u8) bool {
    return std.ascii.isDigit(ch) or (ch >= 'a' and ch <= 'f');
}

fn nameRevLine(line: []const u8, name_only: bool) void {
    var counter: usize = 0;
    var p_start: usize = 0;
    var p: usize = 0;
    while (p < line.len) : (p += 1) {
        if (!isHex(line[p])) {
            counter = 0;
            continue;
        }
        counter += 1;
        if (counter == 40 and !(p + 1 < line.len and isHex(line[p + 1]))) {
            counter = 0;
            const p_len = p - p_start + 1;
            const hex = line[p - 39 .. p + 1];
            var name: ?[]const u8 = null;
            if (hash.fromHex(hex)) |oid| {
                if (cn.lookupAny(oid)) |o| name = getRevName(o);
            }
            const nm = name orelse continue;
            if (name_only) {
                util.out(line[p_start .. p_start + p_len - 40]);
                util.out(nm);
            } else {
                util.out(line[p_start .. p_start + p_len]);
                util.outf(" ({s})", .{nm});
            }
            p_start = p + 1;
        }
    }
    if (p_start != line.len) util.out(line[p_start..]);
}

const name_rev_usage = [_][]const u8{
    "git name-rev [<options>] <commit>...",
    "git name-rev [<options>] --all",
    "git name-rev [<options>] --annotate-stdin",
};

const RevArg = struct { obj: *cn.Obj, name: []const u8 };

pub fn cmdNameRev(args: []const []const u8) u8 {
    var transform_stdin = false;
    var all = false;
    var annotate_stdin = false;
    var allow_undefined = true;
    var always = false;
    var peel_tag = false;
    var data = NameRefData{};

    var o_stdin = po.boolean(0, "stdin", &transform_stdin, "deprecated: use --annotate-stdin instead");
    o_stdin.hidden = true;
    var o_peel = po.boolean(0, "peel-tag", &peel_tag, "dereference tags in the input (internal use)");
    o_peel.hidden = true;
    const opts = [_]po.Opt{
        po.boolean(0, "name-only", &data.name_only, "print only ref-based names (no object names)"),
        po.boolean(0, "tags", &data.tags_only, "only use tags to name the commits"),
        po.list(0, "refs", &data.ref_filters, "pattern", "only use refs matching <pattern>"),
        po.list(0, "exclude", &data.exclude_filters, "pattern", "ignore refs matching <pattern>"),
        po.group(""),
        po.boolean(0, "all", &all, "list all commits reachable from all refs"),
        o_stdin,
        po.boolean(0, "annotate-stdin", &annotate_stdin, "annotate text from stdin"),
        po.boolean(0, "undefined", &allow_undefined, "allow to print `undefined` names (default)"),
        po.boolean(0, "always", &always, "show abbreviated commit object as fallback"),
        o_peel,
    };
    const rest = po.parse(args[1..], &opts, &name_rev_usage, .{});

    if (transform_stdin) {
        util.warn("--stdin is deprecated. Please use --annotate-stdin instead, which is functionally equivalent.\nThis option will be removed in a future release.", .{});
        annotate_stdin = true;
    }
    const nargs: u32 = @intFromBool(rest.len > 0);
    if (@as(u32, @intFromBool(all)) + @intFromBool(annotate_stdin) + nargs > 1) {
        util.err("Specify either a list, or --all, not both!", .{});
        po.usageWithOptions(&name_rev_usage, &opts);
    }
    if (all or annotate_stdin) disableCutoff();

    var revs: std.ArrayList(RevArg) = .empty;
    for (rest) |arg| {
        const oid = revparse.getOid(arg) orelse {
            util.eprint("Could not get sha1 for {s}. Skipping.\n", .{arg});
            continue;
        };
        var commit: ?*Commit = null;
        var object = cn.parseObject(oid);
        if (object) |obj| {
            const peeled = derefTagWarn(obj, arg);
            if (peeled) |pe| {
                if (pe.typ == .commit) commit = Commit.fromObj(pe);
            }
        }
        if (object == null) {
            util.eprint("Could not get object for {s}. Skipping.\n", .{arg});
            continue;
        }
        if (commit) |c| setCommitCutoff(c);
        if (peel_tag) {
            const c = commit orelse {
                util.eprint("Could not get commit for {s}. Skipping.\n", .{arg});
                continue;
            };
            object = &c.obj;
        }
        revs.append(gpa, .{ .obj = object.?, .name = arg }) catch util.oom();
    }

    adjustCutoffForSlop();

    for (refs.iterate("refs/", .{})) |r| nameRef(r, &data);
    nameTips();

    if (annotate_stdin) {
        const input = os.readAllFd(0) catch "";
        var pos: usize = 0;
        while (pos < input.len) {
            const nl = std.mem.indexOfScalarPos(u8, input, pos, '\n');
            var line = if (nl) |n| input[pos..n] else input[pos..];
            pos = if (nl) |n| n + 1 else input.len;
            if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
            nameRevLine(util.concat(&.{ line, "\n" }), data.name_only);
        }
    } else if (all) {
        var i: usize = 0;
        while (i < cn.all_commits.items.len) : (i += 1) {
            const c = cn.all_commits.items[i];
            showName(&c.obj, null, always, allow_undefined, data.name_only);
        }
    } else {
        for (revs.items) |r| showName(r.obj, r.name, always, allow_undefined, data.name_only);
    }
    return 0;
}

/// deref_tag() with the "missing object referenced by" warning.
fn derefTagWarn(o0: *cn.Obj, warn_name: []const u8) ?*cn.Obj {
    var o = o0;
    while (o.typ == .tag) {
        const raw = repo_mod.repo().odb().read(o.oid) orelse return null;
        const t = objects.parseTag(raw.data) orelse return null;
        o = cn.parseObject(t.object) orelse {
            util.err("missing object referenced by '{s}'", .{warn_name});
            return null;
        };
    }
    return o;
}

// ---------------------------------------------------------------------------
// describe
// ---------------------------------------------------------------------------

const MAX_TAGS: i32 = 28;
const DEFAULT_CANDIDATES: i32 = 10;

const describe_usage = [_][]const u8{
    "git describe [--all] [--tags] [--contains] [--abbrev=<n>] [<commit-ish>...]",
    "git describe [--all] [--tags] [--contains] [--abbrev=<n>] --dirty[=<mark>]",
    "git describe <blob>",
};

var debug = false;
var d_all = false;
var d_tags = false;
var longformat = false;
var first_parent = false;
var abbrev: i32 = -1;
var max_candidates: i32 = DEFAULT_CANDIDATES;
var patterns: std.ArrayList([]const u8) = .empty;
var exclude_patterns: std.ArrayList([]const u8) = .empty;
var d_always = false;
var suffix: ?[]const u8 = null;
var dirty: ?[]const u8 = null;
var broken: ?[]const u8 = null;

const CommitName = struct {
    peeled: Oid,
    tag: ?TagInfo = null,
    prio: u2 = 0,
    name_checked: bool = false,
    misnamed: bool = false,
    oid: Oid,
    path: []const u8,
};

var names: std.AutoHashMapUnmanaged(Oid, *CommitName) = .empty;

const prio_names = [_][]const u8{ "head", "lightweight", "annotated" };

fn replaceName(e0: ?*CommitName, prio: u2, oid: Oid, tag: *?TagInfo) bool {
    const e = e0 orelse return true;
    if (e.prio < prio) return true;
    if (e.prio == 2 and prio == 2) {
        if (e.tag == null) {
            e.tag = lookupTag(e.oid) orelse return true;
        }
        const t = lookupTag(oid) orelse return false;
        tag.* = t;
        if (e.tag.?.date < t.date) return true;
    }
    return false;
}

fn addToKnownNames(path: []const u8, peeled: Oid, prio: u2, oid: Oid) void {
    var e = names.get(peeled);
    var tag: ?TagInfo = null;
    if (replaceName(e, prio, oid, &tag)) {
        if (e == null) {
            const n = gpa.create(CommitName) catch util.oom();
            n.* = .{ .peeled = peeled, .oid = oid, .path = "" };
            names.put(gpa, peeled, n) catch util.oom();
            e = n;
        }
        const n = e.?;
        n.tag = tag;
        n.prio = prio;
        n.name_checked = false;
        n.misnamed = false;
        n.oid = oid;
        n.path = util.dupe(path);
    }
}

fn getName(ref: refs.Ref) void {
    var is_tag = false;
    var path_to_match: []const u8 = "";
    if (util.skipPrefix(ref.name, "refs/tags/")) |p| {
        is_tag = true;
        path_to_match = p;
    } else if (d_all) {
        if (exclude_patterns.items.len > 0 or patterns.items.len > 0) {
            if (util.skipPrefix(ref.name, "refs/heads/")) |p| {
                path_to_match = p;
            } else if (util.skipPrefix(ref.name, "refs/remotes/")) |p| {
                path_to_match = p;
            } else return;
        }
    } else return;

    for (exclude_patterns.items) |pat| {
        if (wildmatch.match(pat, path_to_match, 0)) return;
    }
    if (patterns.items.len > 0) {
        var found = false;
        for (patterns.items) |pat| {
            if (wildmatch.match(pat, path_to_match, 0)) {
                found = true;
                break;
            }
        }
        if (!found) return;
    }

    var peeled = ref.oid;
    var is_annotated = false;
    if (ref.peeled) |pl| {
        peeled = pl;
        is_annotated = !hash.eql(ref.oid, pl);
    } else if (objects.peel(ref.oid)) |pl| {
        peeled = pl.oid;
        is_annotated = !hash.eql(ref.oid, pl.oid);
    }
    const prio: u2 = if (is_annotated) 2 else if (is_tag) 1 else 0;
    const path = if (d_all) ref.name[5..] else ref.name[10..];
    addToKnownNames(path, peeled, prio, ref.oid);
}

const PossibleTag = struct {
    name: *CommitName,
    depth: i32,
    found_order: i32,
    flag_within: u32,
};

fn comparePt(_: void, a: PossibleTag, b: PossibleTag) bool {
    if (a.depth != b.depth) return a.depth < b.depth;
    return a.found_order < b.found_order;
}

fn finishDepthComputation(queue: *cn.PrioQueue, best: *PossibleTag) u64 {
    var seen_commits: u64 = 0;
    var unflagged: std.AutoHashMapUnmanaged(Oid, void) = .empty;
    for (queue.items()) |it| {
        if (it.data.obj.flags & best.flag_within == 0) unflagged.put(gpa, it.data.obj.oid, {}) catch util.oom();
    }
    while (queue.get()) |c| {
        seen_commits += 1;
        if (c.obj.flags & best.flag_within != 0) {
            if (unflagged.count() == 0) break;
        } else {
            _ = unflagged.remove(c.obj.oid);
            best.depth += 1;
        }
        var parents = c.parents;
        while (parents) |pl| : (parents = pl.next) {
            const p = pl.item;
            _ = parseCommitLoud(p);
            const seen = p.obj.flags & cn.SEEN != 0;
            if (!seen) queue.put(p);
            const flag_before = p.obj.flags & best.flag_within;
            p.obj.flags |= c.obj.flags;
            const flag_after = p.obj.flags & best.flag_within;
            if (!seen and flag_after == 0) unflagged.put(gpa, p.obj.oid, {}) catch util.oom();
            if (seen and flag_before == 0 and flag_after != 0) _ = unflagged.remove(p.obj.oid);
        }
    }
    return seen_commits;
}

fn appendName(n: *CommitName, dst: *util.Buf) void {
    if (n.prio == 2 and n.tag == null) {
        n.tag = lookupTag(n.oid) orelse util.die("annotated tag {s} not available", .{n.path});
    }
    if (n.tag) |t| {
        if (!n.name_checked) {
            const cmp_path = if (d_all) n.path[5..] else n.path;
            if (!util.eql(t.tag, cmp_path)) {
                util.warn("tag '{s}' is externally known as '{s}'", .{ n.path, t.tag });
                n.misnamed = true;
            }
            n.name_checked = true;
        }
        if (d_all) util.bufAppend(dst, "tags/");
        util.bufAppend(dst, t.tag);
    } else {
        util.bufAppend(dst, n.path);
    }
}

fn appendSuffix(depth: i32, oid: Oid, dst: *util.Buf) void {
    util.bufPrint(dst, "-{d}-g{s}", .{ depth, findUniqueAbbrev(oid, abbrev) });
}

fn describeCommit(cmit: *Commit, dst: *util.Buf) void {
    if (names.get(cmit.obj.oid)) |n| {
        if (d_tags or d_all or n.prio == 2) {
            appendName(n, dst);
            if (n.misnamed or longformat) appendSuffix(0, if (n.tag) |t| t.tagged else cmit.obj.oid, dst);
            if (suffix) |s| util.bufAppend(dst, s);
            return;
        }
    }
    if (max_candidates == 0) util.die("no tag exactly matches '{s}'", .{hash.hex(cmit.obj.oid)});
    if (debug) util.ewrite("No exact match on refs or tags, searching to describe\n");

    var queue = cn.PrioQueue{ .compare = cn.compareByCommitDate };
    var all_matches: [MAX_TAGS]PossibleTag = undefined;
    var match_cnt: u32 = 0;
    var annotated_cnt: u32 = 0;
    var unannotated_cnt: u32 = 0;
    var seen_commits: u64 = 0;
    var gave_up_on: ?*Commit = null;
    const maxc: u32 = @intCast(max_candidates);

    cmit.obj.flags = cn.SEEN;
    queue.put(cmit);
    while (queue.get()) |c| {
        seen_commits += 1;
        if (match_cnt == maxc or match_cnt == names.count()) {
            gave_up_on = c;
            break;
        }
        if (commitName(c)) |n| {
            if (!d_tags and !d_all and n.prio < 2) {
                unannotated_cnt += 1;
            } else if (match_cnt < maxc) {
                const t = &all_matches[match_cnt];
                match_cnt += 1;
                t.name = n;
                t.depth = @intCast(seen_commits - 1);
                t.flag_within = @as(u32, 1) << @intCast(match_cnt);
                t.found_order = @intCast(match_cnt);
                c.obj.flags |= t.flag_within;
                if (n.prio == 2) annotated_cnt += 1;
            }
        }
        for (all_matches[0..match_cnt]) |*t| {
            if (c.obj.flags & t.flag_within == 0) t.depth += 1;
        }
        if (annotated_cnt != 0 and queue.count() == 0) {
            var best_depth: i32 = std.math.maxInt(i32);
            var best_within: u32 = 0;
            for (all_matches[0..match_cnt]) |*t| {
                if (t.depth < best_depth) {
                    best_depth = t.depth;
                    best_within = t.flag_within;
                } else if (t.depth == best_depth) {
                    best_within |= t.flag_within;
                }
            }
            if (c.obj.flags & best_within == best_within) {
                if (debug) util.eprint("finished search at {s}\n", .{hash.hex(c.obj.oid)});
                break;
            }
        }
        var parents = c.parents;
        while (parents) |pl| : (parents = pl.next) {
            const p = pl.item;
            _ = parseCommitLoud(p);
            if (p.obj.flags & cn.SEEN == 0) queue.put(p);
            p.obj.flags |= c.obj.flags;
            if (first_parent) break;
        }
    }

    if (match_cnt == 0) {
        const h = hash.hex(cmit.obj.oid);
        if (d_always) {
            util.bufAppend(dst, findUniqueAbbrev(cmit.obj.oid, abbrev));
            if (suffix) |s| util.bufAppend(dst, s);
            queue.clear();
            return;
        }
        if (unannotated_cnt != 0)
            util.die("No annotated tags can describe '{s}'.\nHowever, there were unannotated tags: try --tags.", .{h});
        util.die("No tags can describe '{s}'.\nTry --always, or create some tags.", .{h});
    }

    std.sort.block(PossibleTag, all_matches[0..match_cnt], {}, comparePt);

    if (gave_up_on) |g| {
        queue.put(g);
        seen_commits -= 1;
    }
    seen_commits += finishDepthComputation(&queue, &all_matches[0]);
    queue.clear();

    if (debug) {
        for (all_matches[0..match_cnt]) |*t| {
            util.eprint(" {s: <11} {s: >8} {s}\n", .{ prio_names[t.name.prio], util.fmt("{d}", .{t.depth}), t.name.path });
        }
        util.eprint("traversed {d} commits\n", .{seen_commits});
        if (gave_up_on) |g| {
            util.eprint("found {d} tags; gave up search at {s}\n", .{ max_candidates, hash.hex(g.obj.oid) });
        }
    }

    appendName(all_matches[0].name, dst);
    if (all_matches[0].name.misnamed or abbrev != 0) appendSuffix(all_matches[0].depth, cmit.obj.oid, dst);
    if (suffix) |s| util.bufAppend(dst, s);
}

/// commit_names slab lookup: the name whose peeled object is this commit.
fn commitName(c: *Commit) ?*CommitName {
    return names.get(c.obj.oid);
}

fn describeBlob(oid: Oid, dst: *util.Buf) void {
    const head = revparse.getOid("HEAD") orelse
        util.die("cannot search for blob '{s}' on an unborn branch", .{hash.hex(oid)});

    // rev-list --objects --in-commit-order --reverse HEAD
    var seen_commits: std.AutoHashMapUnmanaged(Oid, void) = .empty;
    var order: std.ArrayList(*Commit) = .empty;
    var list: ?*CommitList = null;
    if (cn.lookupCommitReference(head)) |start| {
        seen_commits.put(gpa, start.obj.oid, {}) catch util.oom();
        _ = cn.listInsertByDate(start, &list);
    }
    while (cn.popCommit(&list)) |c| {
        if (!cn.parse(c)) continue;
        order.append(gpa, c) catch util.oom();
        var parents = c.parents;
        while (parents) |pl| : (parents = pl.next) {
            const p = pl.item;
            if (!cn.parse(p)) continue;
            if (seen_commits.contains(p.obj.oid)) continue;
            seen_commits.put(gpa, p.obj.oid, {}) catch util.oom();
            _ = cn.listInsertByDate(p, &list);
        }
    }
    var seen_objs: std.AutoHashMapUnmanaged(Oid, void) = .empty;
    var i = order.items.len;
    while (i > 0) {
        i -= 1;
        const c = order.items[i];
        if (findBlobInTree(c.tree, "", oid, &seen_objs)) |path| {
            cn.clearAllObjectFlags(cn.SEEN | cn.ADDED | cn.SHOWN | cn.TOPO_WALK_EXPLORED | cn.TOPO_WALK_INDEGREE);
            describeCommit(c, dst);
            util.bufPrint(dst, ":{s}", .{path});
            break;
        }
    }
    if (dst.items.len == 0) util.die("blob '{s}' not reachable from HEAD", .{hash.hex(oid)});
}

fn findBlobInTree(tree: Oid, base: []const u8, want: Oid, seen: *std.AutoHashMapUnmanaged(Oid, void)) ?[]const u8 {
    if (seen.contains(tree)) return null;
    seen.put(gpa, tree, {}) catch util.oom();
    const entries = objects.readTree(tree) orelse return null;
    for (entries) |e| {
        const p = if (base.len == 0) util.dupe(e.name) else util.concat(&.{ base, "/", e.name });
        if (e.isDir()) {
            if (findBlobInTree(e.oid, p, want, seen)) |r| return r;
        } else if (e.mode & 0o170000 == 0o160000) {
            continue;
        } else {
            if (seen.contains(e.oid)) continue;
            seen.put(gpa, e.oid, {}) catch util.oom();
            if (hash.eql(e.oid, want)) return p;
        }
    }
    return null;
}

fn describe(arg: []const u8, last_one: bool) void {
    if (debug) util.eprint("describe {s}\n", .{arg});
    const oid = revparse.getOid(arg) orelse util.die("Not a valid object name {s}", .{arg});
    const cmit = cn.lookupCommitReference(oid);
    var sb: util.Buf = .empty;
    if (cmit) |c| {
        describeCommit(c, &sb);
    } else if (cn.objType(oid) == .blob) {
        describeBlob(oid, &sb);
    } else util.die("{s} is neither a commit nor blob", .{arg});
    util.outf("{s}\n", .{sb.items});
    if (!last_one) {
        if (cmit) |c| cn.clearCommitMarks(c, 0xffffffff);
    }
}

fn cbExactMatch(_: ?[]const u8, unset: bool) void {
    max_candidates = if (unset) DEFAULT_CANDIDATES else 0;
}

fn cbAbbrev(arg: ?[]const u8, unset: bool) void {
    const a = arg orelse {
        abbrev = if (unset) 0 else -1;
        return;
    };
    var i: usize = 0;
    while (i < a.len and std.ascii.isWhitespace(a[i])) i += 1;
    var neg = false;
    if (i < a.len and (a[i] == '-' or a[i] == '+')) {
        neg = a[i] == '-';
        i += 1;
    }
    const digits_start = i;
    var v: i64 = 0;
    while (i < a.len and std.ascii.isDigit(a[i])) : (i += 1) {
        v = @min(v * 10 + (a[i] - '0'), @as(i64, std.math.maxInt(i32)));
    }
    if (a.len == 0 or i == digits_start or i != a.len) {
        util.err("option `abbrev' expects a numerical value", .{});
        os.exit(129);
    }
    if (neg) v = -v;
    var r: i32 = @intCast(v);
    if (r != 0 and r < 4) r = 4;
    abbrev = r;
}

/// diff-index --quiet HEAD -- (after refreshing the index); true if dirty.
fn worktreeIsDirty() bool {
    const r = repo_mod.requireWorkTree("describe");
    _ = r;
    const idx = index_mod.get();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET | index_mod.REFRESH_UNMERGED, null, null);
    switch (lockfile.tryLock(repo_mod.repo().indexPath())) {
        .ok => |l| {
            if (idx.changed) {
                idx.lock = l;
                idx.write();
            } else {
                idx.lock = l;
                idx.rollback();
            }
        },
        .err => {},
    }
    const tree = revparse.getTreeish("HEAD") orelse util.die("bad revision 'HEAD'", .{});
    var flat: std.ArrayList(objects.FlatEntry) = .empty;
    objects.flattenTree(tree, "", &flat);
    var head_map: std.StringHashMapUnmanaged(objects.FlatEntry) = .empty;
    for (flat.items) |e| head_map.put(gpa, e.path, e) catch util.oom();

    var seen_paths: usize = 0;
    var last_path: ?[]const u8 = null;
    for (idx.entries.items) |*e| {
        if (e.removed) continue;
        const in_head = head_map.get(e.path);
        if (last_path == null or !util.eql(last_path.?, e.path)) {
            if (in_head != null) seen_paths += 1;
            last_path = e.path;
        }
        if (e.stage() != 0 or e.intentToAdd()) return true;
        const h = in_head orelse return true;
        if (!hash.eql(h.oid, e.oid) or h.mode != e.mode) return true;
        if (e.mode & 0o170000 == 0o160000) {
            if (index_mod.gitlinkHead(e.path)) |sub| {
                if (!hash.eql(sub, e.oid)) return true;
            }
            continue;
        }
        if (e.skipWorktree()) continue;
        if (!e.uptodate) return true;
    }
    return seen_paths != flat.items.len;
}

fn selfExe() []const u8 {
    return os.readLink("/proc/self/exe") orelse main.argv0;
}

pub fn cmdDescribe(args: []const []const u8) u8 {
    var contains = false;
    var o_abbrev = po.Opt{ .long = "abbrev", .kind = .callback, .cb = cbAbbrev, .optarg = true, .argh = "n", .help = "use <n> digits to display object names" };
    _ = &o_abbrev;
    const opts = [_]po.Opt{
        po.boolean(0, "contains", &contains, "find the tag that comes after the commit"),
        po.boolean(0, "debug", &debug, "debug search strategy on stderr"),
        po.boolean(0, "all", &d_all, "use any ref"),
        po.boolean(0, "tags", &d_tags, "use any tag, even unannotated"),
        po.boolean(0, "long", &longformat, "always use long format"),
        po.boolean(0, "first-parent", &first_parent, "only follow first parent"),
        o_abbrev,
        po.callbackNoArg(0, "exact-match", cbExactMatch, "only output exact matches"),
        po.integer(0, "candidates", &max_candidates, "n", "consider <n> most recent tags (default: 10)"),
        po.list(0, "match", &patterns, "pattern", "only consider tags matching <pattern>"),
        po.list(0, "exclude", &exclude_patterns, "pattern", "do not consider tags matching <pattern>"),
        po.boolean(0, "always", &d_always, "show abbreviated commit object as fallback"),
        po.optString(0, "dirty", &dirty, "-dirty", "mark", "append <mark> on dirty working tree (default: \"-dirty\")"),
        po.optString(0, "broken", &broken, "-broken", "mark", "append <mark> on broken working tree (default: \"-broken\")"),
    };
    const rest = po.parse(args[1..], &opts, &describe_usage, .{});

    if (max_candidates < 0) max_candidates = 0 else if (max_candidates > MAX_TAGS) max_candidates = MAX_TAGS;

    if (longformat and abbrev == 0)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--long", "--abbrev=0" });

    if (contains) {
        var a: std.ArrayList([]const u8) = .empty;
        a.appendSlice(gpa, &.{ "name-rev", "--peel-tag", "--name-only", "--no-undefined" }) catch util.oom();
        if (d_always) a.append(gpa, "--always") catch util.oom();
        if (!d_all) a.append(gpa, "--tags") catch util.oom();
        for (patterns.items) |p| a.append(gpa, util.fmt("--refs=refs/tags/{s}", .{p})) catch util.oom();
        for (exclude_patterns.items) |p| a.append(gpa, util.fmt("--exclude=refs/tags/{s}", .{p})) catch util.oom();
        if (d_all) {
            for (patterns.items) |p| a.append(gpa, util.fmt("--refs=refs/heads/{s}", .{p})) catch util.oom();
            for (exclude_patterns.items) |p| a.append(gpa, util.fmt("--exclude=refs/heads/{s}", .{p})) catch util.oom();
            for (patterns.items) |p| a.append(gpa, util.fmt("--refs=refs/remotes/{s}", .{p})) catch util.oom();
            for (exclude_patterns.items) |p| a.append(gpa, util.fmt("--exclude=refs/remotes/{s}", .{p})) catch util.oom();
        }
        if (rest.len > 0) a.appendSlice(gpa, rest) catch util.oom() else a.append(gpa, "HEAD") catch util.oom();
        return cmdNameRev(a.items);
    }

    const prefix: []const u8 = if (d_all) "refs/" else "refs/tags/";
    for (refs.iterate(prefix, .{ .include_broken = true })) |r| getName(r);
    if (names.count() == 0 and !d_always) util.die("No names found, cannot describe anything.", .{});

    if (rest.len == 0) {
        if (broken) |b| {
            const exe = selfExe();
            _ = os.run(&.{ exe, "update-index", "--unmerged", "-q", "--refresh" }, .{ .no_stdin = true, .capture_stdout = true });
            const res = os.run(&.{ exe, "diff-index", "--quiet", "HEAD", "--" }, .{ .no_stdin = true, .capture_stdout = true });
            if (dirty == null) dirty = "-dirty";
            if (res.signaled) {
                suffix = b;
            } else switch (res.status) {
                0 => suffix = null,
                1 => suffix = dirty,
                else => suffix = b,
            }
        } else if (dirty) |d| {
            suffix = if (worktreeIsDirty()) d else null;
        }
        describe("HEAD", true);
    } else if (dirty != null) {
        util.die("option '{s}' and commit-ishes cannot be used together", .{"--dirty"});
    } else if (broken != null) {
        util.die("option '{s}' and commit-ishes cannot be used together", .{"--broken"});
    } else {
        for (rest, 0..) |a, i| describe(a, i + 1 == rest.len);
    }
    return 0;
}
