const std = @import("std");
const util = @import("util.zig");

pub const Oid = [20]u8;
pub const HEXSZ = 40;
pub const RAWSZ = 20;
pub const zero: Oid = @splat(0);
pub const zero_hex = "0000000000000000000000000000000000000000";
pub const empty_tree_hex = "4b825dc642cb6eb9a060e54bf8d69288fbee4904";
pub const empty_blob_hex = "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391";

pub fn hex(oid: Oid) [40]u8 {
    return std.fmt.bytesToHex(oid, .lower);
}

pub fn hexAlloc(oid: Oid) []u8 {
    const h = hex(oid);
    return util.dupe(&h);
}

pub fn fromHex(s: []const u8) ?Oid {
    if (s.len < 40) return null;
    var o: Oid = undefined;
    _ = std.fmt.hexToBytes(&o, s[0..40]) catch return null;
    return o;
}

pub fn isZero(o: Oid) bool {
    return std.mem.eql(u8, &o, &zero);
}

pub fn eql(a: Oid, b: Oid) bool {
    return std.mem.eql(u8, &a, &b);
}

pub fn order(a: Oid, b: Oid) std.math.Order {
    return std.mem.order(u8, &a, &b);
}

pub fn lessThan(_: void, a: Oid, b: Oid) bool {
    return std.mem.order(u8, &a, &b) == .lt;
}

pub const Hasher = std.crypto.hash.Sha1;

pub fn hashData(data: []const u8) Oid {
    var h = Hasher.init(.{});
    h.update(data);
    var o: Oid = undefined;
    h.final(&o);
    return o;
}

pub const OidContext = struct {
    pub fn hash(_: OidContext, k: Oid) u64 {
        return std.mem.readInt(u64, k[0..8], .little);
    }
    pub fn eql(_: OidContext, a: Oid, b: Oid) bool {
        return std.mem.eql(u8, &a, &b);
    }
};

pub fn OidMap(comptime V: type) type {
    return std.HashMapUnmanaged(Oid, V, OidContext, 80);
}

pub const OidSet = OidMap(void);
