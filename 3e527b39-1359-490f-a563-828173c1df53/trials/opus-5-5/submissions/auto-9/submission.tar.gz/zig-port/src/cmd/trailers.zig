//! git interpret-trailers

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const pt = @import("../pretty_trailer.zig");
const trailer = @import("../trailer.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git interpret-trailers [--in-place] [--trim-empty]\n" ++
        "                       [(--trailer (<key>|<key-alias>)[(=|:)<value>])...]\n" ++
        "                       [--parse] [<file>...]",
};

var opts: pt.Options = .{};
var where: trailer.Where = .default;
var if_exists: trailer.IfExists = .default;
var if_missing: trailer.IfMissing = .default;
var new_trailers: std.ArrayList(trailer.NewTrailer) = .empty;

fn optWhere(arg: ?[]const u8, _: bool) void {
    if (trailer.setWhere(arg)) |w| where = w else {
        util.err("unknown value for --where: {s}", .{arg.?});
        os.exit(129);
    }
}
fn optIfExists(arg: ?[]const u8, _: bool) void {
    if (trailer.setIfExists(arg)) |w| if_exists = w else {
        util.err("unknown value for --if-exists: {s}", .{arg.?});
        os.exit(129);
    }
}
fn optIfMissing(arg: ?[]const u8, _: bool) void {
    if (trailer.setIfMissing(arg)) |w| if_missing = w else {
        util.err("unknown value for --if-missing: {s}", .{arg.?});
        os.exit(129);
    }
}
fn optTrailer(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        new_trailers.clearRetainingCapacity();
        return;
    }
    new_trailers.append(gpa, .{ .text = arg.?, .where = where, .if_exists = if_exists, .if_missing = if_missing }) catch util.oom();
}
fn optParse(_: ?[]const u8, _: bool) void {
    opts.only_trailers = true;
    opts.only_input = true;
    opts.unfold = true;
}

const options = [_]po.Opt{
    po.boolean(0, "in-place", &opts.in_place, "edit files in place"),
    po.boolean(0, "trim-empty", &opts.trim_empty, "trim empty trailers"),
    po.callback(0, "where", optWhere, "placement", "where to place the new trailer"),
    po.callback(0, "if-exists", optIfExists, "action", "action if trailer already exists"),
    po.callback(0, "if-missing", optIfMissing, "action", "action if trailer is missing"),
    po.boolean(0, "only-trailers", &opts.only_trailers, "output only the trailers"),
    po.boolean(0, "only-input", &opts.only_input, "do not apply trailer.<key-alias> configuration variables"),
    po.boolean(0, "unfold", &opts.unfold, "reformat multiline trailer values as single-line values"),
    .{ .long = "parse", .kind = .callback, .cb = optParse, .noarg = true, .noneg = true, .help = "alias for --only-trailers --only-input --unfold" },
    po.boolean(0, "no-divider", &opts.no_divider, "do not treat \"---\" as the end of input"),
    po.callback(0, "trailer", optTrailer, "trailer", "trailer(s) to add"),
};

fn interpret(file: ?[]const u8) void {
    var input: []const u8 = undefined;
    if (file) |f| {
        input = os.readFile(f) orelse util.dieErrno("could not read input file '{s}'", .{f});
    } else {
        input = os.readAllFd(0) catch util.dieErrno("could not read from stdin", .{});
    }
    if (input.len > 0 and input[input.len - 1] != '\n') input = util.concat(&.{ input, "\n" });
    if (opts.in_place) {
        const f = file.?;
        const st = os.statPath(f) orelse {
            util.eprint("error: could not stat {s}: {s}\n", .{ f, os.lastErr() });
            util.die("", .{});
        };
        if (!st.isReg()) {
            util.err("file {s} is not a regular file", .{f});
            os.exit(128);
        }
    }
    var out: util.Buf = .empty;
    trailer.process(&opts, new_trailers.items, input, &out);
    if (opts.in_place) {
        os.writeFile(file.?, out.items, 0o666) catch util.dieErrno("could not write to temporary file '{s}'", .{file.?});
    } else {
        util.out(out.items);
    }
}

pub fn cmdInterpretTrailers(args: []const []const u8) u8 {
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (opts.only_input and new_trailers.items.len > 0) {
        util.eprint("error: --trailer with --only-input does not make sense\n", .{});
        po.usageExit(&usage, &options, true);
    }
    if (rest.len > 0) {
        for (rest) |f| interpret(f);
    } else {
        if (opts.in_place) util.die("no input file given for in-place editing", .{});
        interpret(null);
    }
    return 0;
}
