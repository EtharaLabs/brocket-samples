//! git patch-id (builtin/patch-id.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const gpa = util.gpa;

const usage = [_][]const u8{"git patch-id [--stable | --unstable | --verbatim]"};

var mode: i32 = 0;
var mode_name: []const u8 = "";

fn setMode(m: i32, name: []const u8) void {
    if (mode != 0 and mode != m) {
        util.err("options '--{s}' and '--{s}' cannot be used together", .{ name, mode_name });
        os.exit(129);
    }
    mode = m;
    mode_name = name;
}
fn cbUnstable(_: ?[]const u8, _: bool) void {
    setMode(1, "unstable");
}
fn cbStable(_: ?[]const u8, _: bool) void {
    setMode(2, "stable");
}
fn cbVerbatim(_: ?[]const u8, _: bool) void {
    setMode(3, "verbatim");
}

fn cmdmodeOpt(long: []const u8, cb: po.Callback, help: []const u8) po.Opt {
    var o = po.callbackNoArg(0, long, cb, help);
    o.noneg = true;
    return o;
}

const options = [_]po.Opt{
    cmdmodeOpt("unstable", cbUnstable, "use the unstable patch ID algorithm"),
    cmdmodeOpt("stable", cbStable, "use the stable patch ID algorithm"),
    cmdmodeOpt("verbatim", cbVerbatim, "don't strip whitespace from the patch"),
};

// ---------------------------------------------------------------------------
// stdin line reader emulating strbuf_getwholeline() + feof()

var input: []const u8 = "";
var pos: usize = 0;
var at_eof = false;

fn getLine() ?[]const u8 {
    if (at_eof) return null;
    if (pos >= input.len) {
        at_eof = true;
        return null;
    }
    if (std.mem.indexOfScalarPos(u8, input, pos, '\n')) |nl| {
        const l = input[pos .. nl + 1];
        pos = nl + 1;
        return l;
    }
    const l = input[pos..];
    pos = input.len;
    at_eof = true;
    return l;
}

const Ctx = hash.Hasher;

fn flushOneHunk(result: *hash.Oid, ctx: *Ctx) void {
    var h: hash.Oid = undefined;
    ctx.final(&h);
    ctx.* = Ctx.init(.{});
    var carry: u16 = 0;
    for (0..hash.RAWSZ) |i| {
        carry += @as(u16, result[i]) + h[i];
        result[i] = @truncate(carry);
        carry >>= 8;
    }
}

fn cIsSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r' or ch == 0x0b or ch == 0x0c;
}

fn cIsAlpha(ch: u8) bool {
    return (ch >= 'a' and ch <= 'z') or (ch >= 'A' and ch <= 'Z');
}

fn spanDigits(s: []const u8, from: usize) usize {
    var n: usize = 0;
    while (from + n < s.len and std.ascii.isDigit(s[from + n])) n += 1;
    return n;
}

fn atoi(s: []const u8, from: usize) i32 {
    const n = spanDigits(s, from);
    if (n == 0) return 0;
    return std.fmt.parseInt(i32, s[from .. from + n], 10) catch std.math.maxInt(i32);
}

fn charAt(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

fn scanHunkHeader(p: []const u8, before: *i32, after: *i32) bool {
    var q: usize = 4;
    var n = spanDigits(p, q);
    if (charAt(p, q + n) == ',') {
        q += n + 1;
        before.* = atoi(p, q);
        n = spanDigits(p, q);
    } else before.* = 1;
    if (n == 0 or charAt(p, q + n) != ' ' or charAt(p, q + n + 1) != '+') return false;
    var r = q + n + 2;
    n = spanDigits(p, r);
    if (charAt(p, r + n) == ',') {
        r += n + 1;
        after.* = atoi(p, r);
        n = spanDigits(p, r);
    } else after.* = 1;
    return n != 0;
}

fn isOidHex(s: []const u8) ?hash.Oid {
    if (s.len < hash.HEXSZ) return null;
    return hash.fromHex(s[0..hash.HEXSZ]);
}

fn cstrlen(s: []const u8) usize {
    return std.mem.indexOfScalar(u8, s, 0) orelse s.len;
}

fn getOnePatchid(next_oid: *hash.Oid, result: *hash.Oid, stable: bool, verbatim: bool) usize {
    var patchlen: usize = 0;
    var found_next = false;
    var before: i32 = -1;
    var after: i32 = -1;
    var diff_is_binary = false;
    var pre_buf: [64]u8 = undefined;
    var post_buf: [64]u8 = undefined;
    var pre: []const u8 = "";
    var post: []const u8 = "";
    var ctx = Ctx.init(.{});
    result.* = hash.zero;
    var stripped: util.Buf = .empty;

    while (getLine()) |line_full| {
        // C string semantics: stop at an embedded NUL
        const line = line_full[0..cstrlen(line_full)];
        var p = line;
        if (util.skipPrefix(line, "commit ")) |r| {
            p = r;
        } else if (util.skipPrefix(line, "From ")) |r| {
            p = r;
        } else if (util.startsWith(line, "\\ ") and 12 < line.len) {
            if (verbatim) ctx.update(line);
            continue;
        }

        if (isOidHex(p)) |o| {
            next_oid.* = o;
            found_next = true;
            break;
        }

        // Ignore commit comments
        if (patchlen == 0 and !util.startsWith(line, "diff ")) continue;

        // Parsing diff header?
        if (before == -1) {
            if (util.startsWith(line, "GIT binary patch") or util.startsWith(line, "Binary files")) {
                diff_is_binary = true;
                before = 0;
                ctx.update(pre);
                ctx.update(post);
                if (stable) flushOneHunk(result, &ctx);
                continue;
            } else if (util.skipPrefix(line, "index ")) |rest| {
                const off = line.len - rest.len;
                const oid1_end = std.mem.indexOf(u8, line, "..");
                var oid2_end: ?usize = null;
                if (oid1_end) |e1| oid2_end = std.mem.indexOfScalarPos(u8, line, e1, ' ');
                if (oid2_end == null and line.len > 0) oid2_end = line.len - 1;
                if (oid1_end) |e1| {
                    if (oid2_end) |e2| {
                        // *oid1_end = *oid2_end = '\0'
                        const pre_end = if (e2 < e1) e2 else e1;
                        const pre_src = if (off <= pre_end) line[off..pre_end] else "";
                        const plen = @min(pre_src.len, 64);
                        @memcpy(pre_buf[0..plen], pre_src[0..plen]);
                        pre = pre_buf[0..plen];
                        var post_src: []const u8 = "";
                        if (e1 + 2 <= line.len) {
                            post_src = line[e1 + 2 ..];
                            if (e2 >= e1 + 2) post_src = line[e1 + 2 .. e2];
                        }
                        const qlen = @min(post_src.len, 64);
                        @memcpy(post_buf[0..qlen], post_src[0..qlen]);
                        post = post_buf[0..qlen];
                    }
                }
                continue;
            } else if (util.startsWith(line, "--- ")) {
                before = 1;
                after = 1;
            } else if (!cIsAlpha(charAt(line, 0))) {
                break;
            }
        }

        if (diff_is_binary) {
            if (util.startsWith(line, "diff ")) {
                diff_is_binary = false;
                before = -1;
            }
            continue;
        }

        // Looking for a valid hunk header?
        if (before == 0 and after == 0) {
            if (util.startsWith(line, "@@ -")) {
                _ = scanHunkHeader(line, &before, &after);
                continue;
            }
            // Split at the end of the patch.
            if (!util.startsWith(line, "diff ")) break;
            // Else we're parsing another header.
            if (stable) flushOneHunk(result, &ctx);
            before = -1;
            after = -1;
        }

        // If we get here, we're inside a hunk.
        const c0 = charAt(line, 0);
        if (c0 == '-' or c0 == ' ') before -= 1;
        if (c0 == '+' or c0 == ' ') after -= 1;

        if (verbatim) {
            patchlen += line.len;
            ctx.update(line);
        } else {
            stripped.clearRetainingCapacity();
            for (line) |ch| {
                if (!cIsSpace(ch)) util.bufByte(&stripped, ch);
            }
            patchlen += stripped.items.len;
            ctx.update(stripped.items);
        }
    }

    if (!found_next) next_oid.* = hash.zero;
    flushOneHunk(result, &ctx);
    return patchlen;
}

fn generateIdList(stable: bool, verbatim: bool) void {
    var oid = hash.zero;
    var n = hash.zero;
    var result = hash.zero;
    while (!at_eof) {
        const patchlen = getOnePatchid(&n, &result, stable, verbatim);
        if (patchlen != 0) util.outf("{s} {s}\n", .{ hash.hex(result), hash.hex(oid) });
        oid = n;
    }
}

pub fn cmdPatchId(args: []const []const u8) u8 {
    var stable = false;
    var verbatim = false;
    for (repo_mod.cfg.entries.items) |e| {
        if (util.eql(e.key, "patchid.stable")) {
            stable = configBool(e.key, e.value);
        } else if (util.eql(e.key, "patchid.verbatim")) {
            verbatim = configBool(e.key, e.value);
        }
    }
    if (verbatim) stable = true;
    _ = po.parse(args[1..], &options, &usage, .{});
    input = os.readAllFd(0) catch "";
    pos = 0;
    at_eof = false;
    generateIdList(if (mode != 0) mode > 1 else stable, if (mode != 0) mode == 3 else verbatim);
    return 0;
}

fn configBool(k: []const u8, v: ?[]const u8) bool {
    return @import("../config.zig").configBool(k, v);
}
