//! Author/committer identities.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const date = @import("date.zig");

fn isCrud(ch: u8) bool {
    return ch <= 32 or ch == '.' or ch == ',' or ch == ':' or ch == ';' or ch == '<' or ch == '>' or ch == '"' or ch == '\\' or ch == '\'';
}

/// Strip leading/trailing crud and remove '<', '>' and newlines.
pub fn sanitize(s: []const u8) []const u8 {
    var start: usize = 0;
    var end: usize = s.len;
    while (start < end and isCrud(s[start])) start += 1;
    while (end > start and isCrud(s[end - 1])) end -= 1;
    var b: util.Buf = .empty;
    for (s[start..end]) |ch| {
        if (ch == '<' or ch == '>' or ch == '\n') continue;
        util.bufByte(&b, ch);
    }
    return b.items;
}

pub const Who = enum { author, committer };

pub fn getName(who: Who) ?[]const u8 {
    const env = if (who == .author) "GIT_AUTHOR_NAME" else "GIT_COMMITTER_NAME";
    if (os.getenv(env)) |v| return v;
    const key = if (who == .author) "author.name" else "committer.name";
    if (repo_mod.cfg.get(key)) |v| return v;
    if (repo_mod.cfg.get("user.name")) |v| return v;
    return null;
}

pub fn getEmail(who: Who) ?[]const u8 {
    const env = if (who == .author) "GIT_AUTHOR_EMAIL" else "GIT_COMMITTER_EMAIL";
    if (os.getenv(env)) |v| return v;
    const key = if (who == .author) "author.email" else "committer.email";
    if (repo_mod.cfg.get(key)) |v| return v;
    if (repo_mod.cfg.get("user.email")) |v| return v;
    if (os.getenv("EMAIL")) |v| return v;
    return null;
}

const Passwd = extern struct {
    pw_name: ?[*:0]const u8,
    pw_passwd: ?[*:0]const u8,
    pw_uid: u32,
    pw_gid: u32,
    pw_gecos: ?[*:0]const u8,
    pw_dir: ?[*:0]const u8,
    pw_shell: ?[*:0]const u8,
};
extern "c" fn getpwuid(uid: u32) ?*Passwd;
extern "c" fn getuid() u32;

var default_name_cache: ?[]const u8 = null;
var default_email_cache: ?[]const u8 = null;
var default_name_is_bogus = false;
var default_email_is_bogus = false;

fn pwSelf(is_bogus: ?*bool) struct { name: []const u8, gecos: []const u8 } {
    if (getpwuid(getuid())) |pw| {
        const n: []const u8 = if (pw.pw_name) |p| std.mem.span(p) else "";
        const g: []const u8 = if (pw.pw_gecos) |p| std.mem.span(p) else n;
        return .{ .name = n, .gecos = g };
    }
    if (is_bogus) |b| b.* = true;
    return .{ .name = "unknown", .gecos = "Unknown" };
}

fn defaultName() []const u8 {
    if (default_name_cache) |n| return n;
    const pw = pwSelf(&default_name_is_bogus);
    var b: util.Buf = .empty;
    for (pw.gecos) |ch| {
        if (ch == ',') break;
        if (ch != '&') {
            util.bufByte(&b, ch);
        } else if (pw.name.len > 0) {
            util.bufByte(&b, std.ascii.toUpper(pw.name[0]));
            util.bufAppend(&b, pw.name[1..]);
        }
    }
    default_name_cache = std.mem.trim(u8, b.items, " \t\n\r");
    return default_name_cache.?;
}

const AddrInfo = extern struct {
    ai_flags: c_int,
    ai_family: c_int,
    ai_socktype: c_int,
    ai_protocol: c_int,
    ai_addrlen: u32,
    ai_addr: ?*anyopaque,
    ai_canonname: ?[*:0]const u8,
    ai_next: ?*AddrInfo,
};
extern "c" fn getaddrinfo(node: [*:0]const u8, service: ?[*:0]const u8, hints: *const AddrInfo, res: *?*AddrInfo) c_int;
extern "c" fn freeaddrinfo(res: *AddrInfo) void;

fn canonicalName(host: [:0]const u8) ?[]const u8 {
    var hints = std.mem.zeroes(AddrInfo);
    hints.ai_flags = 2; // AI_CANONNAME
    var res: ?*AddrInfo = null;
    if (getaddrinfo(host.ptr, null, &hints, &res) != 0) return null;
    const ai = res orelse return null;
    defer freeaddrinfo(ai);
    const cn = std.mem.span(ai.ai_canonname orelse return null);
    if (std.mem.indexOfScalar(u8, cn, '.') == null) return null;
    return util.gpa.dupe(u8, cn) catch util.oom();
}

fn defaultEmail() []const u8 {
    if (default_email_cache) |e| return e;
    var result: []const u8 = undefined;
    if (os.getenv("EMAIL")) |e| {
        if (e.len > 0) {
            default_email_cache = std.mem.trim(u8, e, " \t\n\r");
            return default_email_cache.?;
        }
    }
    const pw = pwSelf(&default_email_is_bogus);
    if (os.readFile("/etc/mailname")) |mn| {
        const line = mn[0 .. std.mem.indexOfScalar(u8, mn, '\n') orelse mn.len];
        result = util.concat(&.{ pw.name, "@", line });
    } else {
        var buf: [256]u8 = undefined;
        if (std.c.gethostname(&buf, buf.len) != 0) {
            util.warn("cannot get host name: {s}", .{os.lastErr()});
            result = util.concat(&.{ pw.name, "@(none)" });
            default_email_is_bogus = true;
        } else {
            buf[buf.len - 1] = 0;
            const host = std.mem.sliceTo(&buf, 0);
            if (std.mem.indexOfScalar(u8, host, '.') != null) {
                result = util.concat(&.{ pw.name, "@", host });
            } else if (canonicalName(buf[0..host.len :0])) |cn| {
                result = util.concat(&.{ pw.name, "@", cn });
            } else {
                result = util.concat(&.{ pw.name, "@", host, ".(none)" });
                default_email_is_bogus = true;
            }
        }
    }
    default_email_cache = std.mem.trim(u8, result, " \t\n\r");
    return default_email_cache.?;
}

fn envHint(who: Who) void {
    util.eprint("{s} identity unknown\n", .{if (who == .author) "Author" else "Committer"});
    util.eprint(
        \\
        \\*** Please tell me who you are.
        \\
        \\Run
        \\
        \\  git config --global user.email "you@example.com"
        \\  git config --global user.name "Your Name"
        \\
        \\to set your account's default identity.
        \\Omit --global to set the identity only in this repository.
        \\
        \\
    , .{});
}

pub fn identityUnknown() noreturn {
    envHint(.author);
    util.die("unable to auto-detect email address (got '{s}')", .{defaultEmail()});
}

fn useConfigOnly() bool {
    const v = repo_mod.cfg.get("user.useconfigonly") orelse return false;
    return @import("config.zig").parseBool(v) orelse false;
}

pub fn dateFor(who: Who) []const u8 {
    const env = if (who == .author) "GIT_AUTHOR_DATE" else "GIT_COMMITTER_DATE";
    if (os.getenv(env)) |v| {
        if (v.len > 0) {
            if (date.parseDate(v)) |d| return util.fmt("{d} {s}", .{ d.time, date.formatTz(d.tz) });
            util.die("invalid date format: {s}", .{v});
        }
    }
    return date.nowString();
}

fn configName(who: Who) ?[]const u8 {
    const key = if (who == .author) "author.name" else "committer.name";
    if (repo_mod.cfg.get(key)) |v| return v;
    return repo_mod.cfg.get("user.name");
}
fn configEmail(who: Who) ?[]const u8 {
    const key = if (who == .author) "author.email" else "committer.email";
    if (repo_mod.cfg.get(key)) |v| return v;
    return repo_mod.cfg.get("user.email");
}

/// "Name <email> time tz"
pub fn ident(who: Who, strict: bool) []const u8 {
    const env_name = if (who == .author) "GIT_AUTHOR_NAME" else "GIT_COMMITTER_NAME";
    const env_email = if (who == .author) "GIT_AUTHOR_EMAIL" else "GIT_COMMITTER_EMAIL";
    const email = os.getenv(env_email) orelse configEmail(who) orelse blk: {
        if (strict and useConfigOnly()) {
            envHint(who);
            util.die("no email was given and auto-detection is disabled", .{});
        }
        const e = defaultEmail();
        if (strict and default_email_is_bogus) {
            envHint(who);
            util.die("unable to auto-detect email address (got '{s}')", .{e});
        }
        break :blk e;
    };
    var using_default = false;
    var name = os.getenv(env_name) orelse configName(who) orelse blk: {
        if (strict and useConfigOnly()) {
            envHint(who);
            util.die("no name was given and auto-detection is disabled", .{});
        }
        using_default = true;
        const n = defaultName();
        if (strict and default_name_is_bogus) {
            envHint(who);
            util.die("unable to auto-detect name (got '{s}')", .{n});
        }
        break :blk n;
    };
    if (name.len == 0) {
        if (strict) {
            if (using_default) envHint(who);
            util.die("empty ident name (for <{s}>) not allowed", .{email});
        }
        name = pwSelf(null).name;
    }
    const sname = sanitize(name);
    if (strict and sname.len == 0) util.die("name consists only of disallowed characters: {s}", .{name});
    return util.fmt("{s} <{s}> {s}", .{ sname, sanitize(email), dateFor(who) });
}

pub fn committer() []const u8 {
    return ident(.committer, false);
}
pub fn author() []const u8 {
    return ident(.author, false);
}
pub fn committerStrict() []const u8 {
    return ident(.committer, true);
}
pub fn authorStrict() []const u8 {
    return ident(.author, true);
}

pub const Split = struct {
    name: []const u8,
    email: []const u8,
    date: []const u8, // "time tz" (may be empty)
    time: i64 = 0,
    tz: i32 = 0,
};

/// Parse "Name <email> time tz"
pub fn split(line: []const u8) ?Split {
    const lt = std.mem.indexOfScalar(u8, line, '<') orelse return null;
    const gt = std.mem.lastIndexOfScalar(u8, line, '>') orelse return null;
    if (gt < lt) return null;
    var name = line[0..lt];
    while (name.len > 0 and name[name.len - 1] == ' ') name = name[0 .. name.len - 1];
    const email = line[lt + 1 .. gt];
    var rest = line[gt + 1 ..];
    while (rest.len > 0 and rest[0] == ' ') rest = rest[1..];
    var s = Split{ .name = name, .email = email, .date = rest };
    var it = std.mem.tokenizeScalar(u8, rest, ' ');
    if (it.next()) |t| s.time = std.fmt.parseInt(i64, t, 10) catch 0;
    if (it.next()) |z| s.tz = date.parseTzOffset(z) orelse 0;
    return s;
}
