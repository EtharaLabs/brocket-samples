//! Port of builtin/tag.c
const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const ident = @import("../ident.zig");
const date_mod = @import("../date.zig");
const cn = @import("../commitnode.zig");
const rf = @import("../reffilter.zig");
const color_mod = @import("../color.zig");
const advice = @import("../advice.zig");
const editor = @import("../editor.zig");
const trailer_cfg = @import("../pretty_trailer.zig");
const trailer_mod = @import("../trailer.zig");
const column = @import("../column.zig");
const Oid = hash.Oid;
const gpa = util.gpa;
const Buf = util.Buf;

const tag_usage = [_][]const u8{
    "git tag [-a | -s | -u <key-id>] [-f] [-m <msg> | -F <file>] [-e]\n" ++
        "        [(--trailer <token>[(=|:)<value>])...]\n" ++
        "        <tagname> [<commit> | <object>]",
    "git tag -d <tagname>...",
    "git tag [-n[<num>]] -l [--contains <commit>] [--no-contains <commit>]\n" ++
        "        [--points-at <object>] [--column[=<options>] | --no-column]\n" ++
        "        [--create-reflog] [--sort=<key>] [--format=<format>]\n" ++
        "        [--merged <commit>] [--no-merged <commit>] [<pattern>...]",
    "git tag -v [--format=<format>] <tagname>...",
};

// ---------------------------------------------------------------------------
// cmdmode handling (OPT_CMDMODE)

var cmdmode: u8 = 0;
var cmdmode_opt: ?*const po.Opt = null;

fn optDisplayName(o: *const po.Opt) []const u8 {
    if (o.short != 0) return util.fmt("-{c}", .{o.short});
    return util.fmt("--{s}", .{o.long});
}

fn cmdmodeCb(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    const v: u8 = @intCast(o.val);
    if (cmdmode != 0 and cmdmode != v) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ optDisplayName(o), optDisplayName(cmdmode_opt.?) });
        os.exit(129);
    }
    cmdmode = v;
    cmdmode_opt = o;
}

// -m callback
var msg_given = false;
var msg_buf: Buf = .empty;

fn msgCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse return;
    if (msg_buf.items.len > 0) util.bufAppend(&msg_buf, "\n\n");
    util.bufAppend(&msg_buf, a);
    msg_given = true;
}

var colopts: u32 = 0;
var column_explicit = false;

fn columnCb(arg: ?[]const u8, unset: bool) void {
    if (!column.parseoptColumn(&colopts, arg, unset)) os.exit(129);
    column_explicit = true;
}

// ---------------------------------------------------------------------------

fn listTags(filter: *rf.Filter, sorting: ?*rf.Sorting, format: *rf.Format) u8 {
    if (filter.lines == -1) filter.lines = 0;
    if (format.format.len == 0) {
        if (filter.lines != 0) {
            format.format = util.fmt("%(align:15)%(refname:lstrip=2)%(end) %(contents:lines={d})", .{filter.lines});
        } else format.format = "%(refname:lstrip=2)";
    }
    if (!rf.verifyFormat(format)) util.die("unable to parse format string", .{});
    filter.with_commit_tag_algo = true;
    if (column.columnActive(colopts)) {
        const lines = rf.filterAndFormatCollect(filter, rf.FILTER_REFS_TAGS, sorting, format);
        column.printColumns(lines, colopts, .{ .padding = 2 });
        return 0;
    }
    rf.filterAndFormat(filter, rf.FILTER_REFS_TAGS, sorting, format);
    return 0;
}

fn readTagRef(ref: []const u8) ?Oid {
    const r = refs.resolveFull(ref, true);
    if (r.missing or r.broken) return null;
    return r.oid;
}

fn deleteTags(names: []const []const u8) u8 {
    var result: u8 = 0;
    var to_delete: std.ArrayList([]const u8) = .empty;
    var oids: std.ArrayList(Oid) = .empty;
    for (names) |n| {
        const ref = util.concat(&.{ "refs/tags/", n });
        const oid = readTagRef(ref) orelse {
            util.err("tag '{s}' not found.", .{n});
            result = 1;
            continue;
        };
        to_delete.append(gpa, ref) catch util.oom();
        oids.append(gpa, oid) catch util.oom();
    }
    if (!refs.deleteRefs(to_delete.items, refs.F_NO_DEREF, null)) result = 1;
    for (to_delete.items, 0..) |ref, i| {
        if (!refs.exists(ref)) {
            util.outf("Deleted tag '{s}' (was {s})\n", .{ ref[10..], revparse.abbrev(oids.items[i], 0) });
        }
    }
    return result;
}

fn hasSignature(buf: []const u8) bool {
    var pos: usize = 0;
    while (pos < buf.len) {
        const line = buf[pos..];
        if (util.startsWith(line, "-----BEGIN PGP SIGNATURE-----") or util.startsWith(line, "-----BEGIN PGP MESSAGE-----") or
            util.startsWith(line, "-----BEGIN SIGNED MESSAGE-----") or util.startsWith(line, "-----BEGIN SSH SIGNATURE-----"))
            return true;
        const nl = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse break;
        pos = nl + 1;
    }
    return false;
}

fn verifyTags(names: []const []const u8, format: *rf.Format) u8 {
    var had_error: u8 = 0;
    const odb = repo_mod.repo().odb();
    for (names) |n| {
        const ref = util.concat(&.{ "refs/tags/", n });
        const oid = readTagRef(ref) orelse {
            util.err("tag '{s}' not found.", .{n});
            had_error = 1;
            continue;
        };
        const obj = odb.read(oid);
        if (obj == null or obj.?.typ != .tag) {
            const tn = if (obj) |o| o.typ.name() else "unknown";
            util.err("{s}: cannot verify a non-tag object of type {s}.", .{ n, tn });
            had_error = 1;
            continue;
        }
        if (!hasSignature(obj.?.data)) {
            if (format.format.len == 0) {
                util.flushStdout();
                util.out(obj.?.data);
                util.flushStdout();
            }
            util.err("no signature found", .{});
            had_error = 1;
            continue;
        }
        // No GPG available: signature cannot be verified.
        util.err("cannot run gpg: No such file or directory", .{});
        had_error = 1;
    }
    return had_error;
}

fn writeTagBody(b: *Buf, oid: Oid) void {
    const obj = repo_mod.repo().odb().read(oid) orelse return;
    var data: []const u8 = obj.data;
    // strip signature
    var pos: usize = 0;
    var sig: usize = data.len;
    while (pos < data.len) {
        const line = data[pos..];
        if (util.startsWith(line, "-----BEGIN PGP SIGNATURE-----") or util.startsWith(line, "-----BEGIN SSH SIGNATURE-----") or
            util.startsWith(line, "-----BEGIN PGP MESSAGE-----") or util.startsWith(line, "-----BEGIN SIGNED MESSAGE-----"))
        {
            sig = pos;
            break;
        }
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n') orelse break;
        pos = nl + 1;
    }
    data = data[0..sig];
    const sp = std.mem.indexOf(u8, data, "\n\n") orelse return;
    if (data.len == 0 or obj.typ != .tag) return;
    util.bufAppend(b, data[sp + 2 ..]);
}

fn commentedAdd(b: *Buf, text: []const u8, prefix: []const u8) void {
    var rest = text;
    while (rest.len > 0) {
        const nl = std.mem.indexOfScalar(u8, rest, '\n');
        const end = if (nl) |x| x + 1 else rest.len;
        util.bufAppend(b, prefix);
        if (rest[0] != '\n' and rest[0] != '\t') util.bufByte(b, ' ');
        util.bufAppend(b, rest[0..end]);
        rest = rest[end..];
    }
    if (b.items.len > 0 and b.items[b.items.len - 1] != '\n') util.bufByte(b, '\n');
}

const Cleanup = enum { none, space, all };

fn createTag(object: Oid, object_ref: []const u8, tag: []const u8, buf: *Buf, message_given: bool, use_editor: bool, sign: bool, cleanup: Cleanup, prev: Oid, trailers: []const []const u8, path: []const u8) Oid {
    const odb = repo_mod.repo().odb();
    const typ = odb.readType(object) orelse util.die("bad object type.", .{});
    if (typ == .tag) {
        advice.adviseIfEnabled("nestedTag", util.fmt("You have created a nested tag. The object referred to by your new tag is\n" ++
            "already a tag. If you meant to tag the object that it points to, use:\n" ++
            "\n" ++
            "\tgit tag -f {s} {s}^{{}}", .{ tag, object_ref }));
    }
    const header = util.fmt("object {s}\ntype {s}\ntag {s}\ntagger {s}\n\n", .{ hash.hex(object), typ.name(), tag, ident.committerStrict() });

    const should_edit = use_editor or !message_given;
    if (should_edit or trailers.len > 0) {
        var tmpl: Buf = .empty;
        if (message_given and buf.items.len > 0) {
            if (buf.items[buf.items.len - 1] != '\n') util.bufByte(buf, '\n');
            util.bufAppend(&tmpl, buf.items);
            buf.clearRetainingCapacity();
        } else if (!hash.isZero(prev)) {
            writeTagBody(&tmpl, prev);
        } else {
            const cstr = trailer_cfg.commentLineStr();
            util.bufByte(&tmpl, '\n');
            const t = if (cleanup == .all)
                util.fmt("\nWrite a message for tag:\n  {s}\nLines starting with '{s}' will be ignored.\n", .{ tag, cstr })
            else
                util.fmt("\nWrite a message for tag:\n  {s}\nLines starting with '{s}' will be kept; you may remove them yourself if you want to.\n", .{ tag, cstr });
            commentedAdd(&tmpl, t, cstr);
        }
        os.writeFile(path, tmpl.items, 0o600) catch util.die("could not create file '{s}'", .{path});
        if (trailers.len > 0 and trailer_mod.amendFile(path, trailers)) util.die("unable to pass trailers to --trailers", .{});
        if (should_edit) {
            if (editor.launch(path, &.{})) {
                util.ewrite("Please supply the message using either -m or -F option.\n");
                os.exit(1);
            }
            buf.clearRetainingCapacity();
            util.bufAppend(buf, os.readFile(path) orelse "");
        } else {
            buf.clearRetainingCapacity();
            util.bufAppend(buf, os.readFile(path) orelse util.die("failed to read '{s}'", .{path}));
        }
    }

    if (cleanup != .none) {
        const s = util.stripspace(buf.items, if (cleanup == .all) trailer_cfg.commentLineStr() else null);
        buf.clearRetainingCapacity();
        util.bufAppend(buf, s);
    }
    if (!message_given and buf.items.len == 0) util.die("no tag message?", .{});

    if (sign) {
        util.err("gpg failed to sign the data", .{});
        util.err("unable to sign the tag", .{});
        if (path.len > 0) util.eprint("The tag message has been left in {s}\n", .{path});
        os.exit(128);
    }
    const full = util.concat(&.{ header, buf.items });
    return odb.write(.tag, full);
}

fn findCommitSubject(buf: []const u8) []const u8 {
    var p: usize = 0;
    while (p < buf.len and (buf[p] != '\n' or (p + 1 < buf.len and buf[p + 1] != '\n') or p + 1 >= buf.len)) {
        if (buf[p] == '\n' and p + 1 >= buf.len) {
            p += 1;
            break;
        }
        p += 1;
    }
    if (p < buf.len) {
        p += 2;
        // skip_blank_lines
        while (p < buf.len) {
            var q = p;
            while (q < buf.len and buf[q] != '\n' and std.ascii.isWhitespace(buf[q])) q += 1;
            if (q < buf.len and buf[q] == '\n') {
                p = q + 1;
            } else break;
        }
        const eol = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse buf.len;
        return buf[p..eol];
    }
    return "";
}

fn createReflogMsg(oid: Oid) []const u8 {
    var sb: Buf = .empty;
    if (os.getenv("GIT_REFLOG_ACTION")) |rla| {
        util.bufAppend(&sb, rla);
    } else {
        util.bufAppend(&sb, "tag: tagging ");
        util.bufAppend(&sb, revparse.abbrev(oid, 0));
    }
    util.bufAppend(&sb, " (");
    const odb = repo_mod.repo().odb();
    const typ = odb.readType(oid);
    if (typ) |t| {
        switch (t) {
            .commit => {
                if (odb.read(oid)) |o| {
                    util.bufAppend(&sb, findCommitSubject(o.data));
                } else util.bufAppend(&sb, "commit object");
                if (cn.lookupCommitReference(oid)) |c| {
                    _ = cn.parse(c);
                    util.bufAppend(&sb, ", ");
                    util.bufAppend(&sb, date_mod.showDate(@intCast(c.date), 0, date_mod.DateMode.of(.short)));
                }
            },
            .tree => util.bufAppend(&sb, "tree object"),
            .blob => util.bufAppend(&sb, "blob object"),
            .tag => util.bufAppend(&sb, "other tag object"),
            else => util.bufAppend(&sb, "object of unknown type"),
        }
    } else util.bufAppend(&sb, "object of unknown type");
    util.bufByte(&sb, ')');
    return sb.items;
}

/// check_tag_ref: returns the full ref name or null when invalid.
pub fn checkTagRef(name: []const u8) ?[]const u8 {
    if ((name.len > 0 and name[0] == '-') or util.eql(name, "HEAD")) return null;
    const ref = util.concat(&.{ "refs/tags/", name });
    if (!refs.checkRefnameFormat(ref, 0)) return null;
    return ref;
}

/// Apply color.ui to a format's use_color when not set explicitly (git_color_config).
pub fn applyColorUi(format: *rf.Format) void {
    if (format.use_color != .unknown) return;
    if (repo_mod.cfg.get("color.ui")) |v| {
        const cb = color_mod.configColorBool("color.ui", v);
        if (cb != .unknown) format.use_color = cb;
    }
}

pub fn cmdTag(args: []const []const u8) u8 {
    var filter = rf.Filter{};
    var format = rf.Format{};
    rf.cur_filter = &filter;
    rf.cur_color = &format.use_color;
    filter.lines = -1;
    var sort_opts: std.ArrayList([]const u8) = .empty;
    const cfg = &repo_mod.cfg;
    for (cfg.getAll("tag.sort")) |v| sort_opts.append(gpa, v) catch util.oom();
    var config_sign_tag: i32 = -1;
    if (cfg.getBool("tag.gpgsign")) |b| config_sign_tag = @intFromBool(b);
    const force_sign_annotate = cfg.getBool("tag.forcesignannotated") orelse false;
    column.applyRepoConfig("tag", &colopts);

    var annotate = false;
    var force: i32 = 0;
    var create_reflog = false;
    var msgfile: ?[]const u8 = null;
    var keyid: ?[]const u8 = null;
    var trailer_args: std.ArrayList([]const u8) = .empty;
    var edit_flag = false;
    var sign_set = false;
    var sign_val = false;
    var cleanup_arg: ?[]const u8 = null;
    var icase = false;
    var fmt_s: ?[]const u8 = null;

    const opts = [_]po.Opt{
        .{ .short = 'l', .long = "list", .kind = .callback, .cbx = cmdmodeCb, .noarg = true, .val = 'l', .help = "list tag names", .noneg = true },
        .{ .short = 'n', .kind = .int, .i = &filter.lines, .argh = "n", .help = "print <n> lines of each tag message", .optarg = true, .val = 1 },
        .{ .short = 'd', .long = "delete", .kind = .callback, .cbx = cmdmodeCb, .noarg = true, .val = 'd', .help = "delete tags", .noneg = true },
        .{ .short = 'v', .long = "verify", .kind = .callback, .cbx = cmdmodeCb, .noarg = true, .val = 'v', .help = "verify tags", .noneg = true },
        po.group("Tag creation options"),
        po.boolean('a', "annotate", &annotate, "annotated tag, needs a message"),
        .{ .short = 'm', .long = "message", .kind = .callback, .cb = msgCb, .argh = "message", .help = "tag message", .noneg = true },
        po.filename('F', "file", &msgfile, "file", "read message from file"),
        po.list(0, "trailer", &trailer_args, "trailer", "add custom trailer(s)"),
        po.boolean('e', "edit", &edit_flag, "force edit of tag message"),
        .{ .short = 's', .long = "sign", .kind = .callback, .cbx = signCb, .noarg = true, .help = "annotated and GPG-signed tag" },
        po.string(0, "cleanup", &cleanup_arg, "mode", "how to strip spaces and #comments from message"),
        po.string('u', "local-user", &keyid, "key-id", "use another key to sign the tag"),
        .{ .short = 'f', .long = "force", .kind = .counter, .i = &force, .help = "replace the tag if exists" },
        po.boolean(0, "create-reflog", &create_reflog, "create a reflog"),
        po.group("Tag listing options"),
        .{ .long = "column", .kind = .callback, .cb = columnCb, .argh = "style", .help = "show tag list in columns", .optarg = true },
        rf.containsOpt("contains", "print only tags that contain the commit", false),
        rf.containsOpt("no-contains", "print only tags that don't contain the commit", false),
        rf.containsOpt("with", "print only tags that contain the commit", true),
        rf.containsOpt("without", "print only tags that don't contain the commit", true),
        rf.mergedOpt("merged", "print only tags that are merged"),
        rf.mergedOpt("no-merged", "print only tags that are not merged"),
        po.boolean(0, "omit-empty", &format.omit_empty, "do not output a newline after empty formatted refs"),
        po.list(0, "sort", &sort_opts, "key", "field name to sort on"),
        .{ .long = "points-at", .kind = .callback, .cbx = pointsAtCb, .argh = "object", .help = "print only tags of the object", .lastarg_default = true, .def = "HEAD" },
        po.string(0, "format", &fmt_s, "format", "format to use for the output"),
        rf.colorOpt("respect format colors"),
        po.boolean('i', "ignore-case", &icase, "sorting and filtering are case insensitive"),
    };
    sign_ptr_set = &sign_set;
    sign_ptr_val = &sign_val;
    const argv = po.parse(args[1..], &opts, &tag_usage, .{});
    if (sort_opts.items.len == 0) sort_opts.append(gpa, "refname") catch util.oom();
    if (fmt_s) |f| format.format = f;
    applyColorUi(&format);

    if (cmdmode == 0) {
        if (argv.len == 0) {
            cmdmode = 'l';
        } else if (filter.with_commit != null or filter.no_commit != null or filter.reachable_from != null or
            filter.unreachable_from != null or filter.points_at.items.len > 0 or filter.lines != -1)
            cmdmode = 'l';
    }
    if (cmdmode == 'l') {
        const pc = cfg.getBool("pager.tag");
        if (@import("../main.zig").use_pager orelse (pc orelse true)) @import("../commands.zig").setupPager();
    }

    var sign: bool = if (sign_set) sign_val else (if (cmdmode != 0) false else config_sign_tag > 0);
    if (keyid != null) sign = true;
    const create_tag_object = sign or annotate or msg_given or msgfile != null or edit_flag or trailer_args.items.len > 0;
    if ((create_tag_object or force != 0) and cmdmode != 0) po.usageWithOptions(&tag_usage, &opts);

    column.finalizeColopts(&colopts, -1);
    if (cmdmode == 'l' and filter.lines != -1) {
        if (column.explicitlyEnabled(colopts)) util.die("options '{s}' and '{s}' cannot be used together", .{ "--column", "-n" });
        colopts = 0;
    }
    const sorting = rf.sortingOptions(sort_opts.items);
    rf.setSortFlagsAll(sorting, rf.SORT_ICASE, icase);
    filter.ignore_case = icase;
    if (cmdmode == 'l') {
        filter.name_patterns = argv;
        return listTags(&filter, sorting, &format);
    }
    var only_in_list: ?[]const u8 = null;
    if (filter.lines != -1) {
        only_in_list = "-n";
    } else if (filter.with_commit != null) {
        only_in_list = "--contains";
    } else if (filter.no_commit != null) {
        only_in_list = "--no-contains";
    } else if (filter.points_at.items.len > 0) {
        only_in_list = "--points-at";
    } else if (filter.reachable_from != null) {
        only_in_list = "--merged";
    } else if (filter.unreachable_from != null) only_in_list = "--no-merged";
    if (only_in_list) |o| util.die("the '{s}' option is only allowed in list mode", .{o});
    if (cmdmode == 'd') return deleteTags(argv);
    if (cmdmode == 'v') {
        if (format.format.len > 0 and !rf.verifyFormat(&format)) po.usageWithOptions(&tag_usage, &opts);
        return verifyTags(argv, &format);
    }

    var buf: Buf = .empty;
    if (msg_given or msgfile != null) {
        if (msg_given and msgfile != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "-F", "-m" });
        if (msg_given) {
            util.bufAppend(&buf, msg_buf.items);
        } else if (util.eql(msgfile.?, "-")) {
            util.bufAppend(&buf, os.readAllFd(0) catch util.die("cannot read '{s}'", .{msgfile.?}));
        } else {
            util.bufAppend(&buf, os.readFile(msgfile.?) orelse util.die("could not open or read '{s}': {s}", .{ msgfile.?, os.lastErr() }));
        }
    }

    const tag = argv[0];
    const object_ref = if (argv.len == 2) argv[1] else "HEAD";
    if (argv.len > 2) util.die("too many arguments", .{});
    var object = revparse.getOid(object_ref) orelse util.die("Failed to resolve '{s}' as a valid ref.", .{object_ref});
    const ref = checkTagRef(tag) orelse util.die("'{s}' is not a valid tag name.", .{tag});
    var prev: Oid = hash.zero;
    if (readTagRef(ref)) |p| {
        prev = p;
        if (force == 0) util.die("tag '{s}' already exists", .{tag});
    }

    var cleanup: Cleanup = .all;
    if (cleanup_arg) |c| {
        if (util.eql(c, "strip")) {
            cleanup = .all;
        } else if (util.eql(c, "verbatim")) {
            cleanup = .none;
        } else if (util.eql(c, "whitespace")) {
            cleanup = .space;
        } else util.die("Invalid cleanup mode {s}", .{c});
    }

    const reflog_msg = createReflogMsg(object);
    var path: ?[]const u8 = null;
    if (create_tag_object) {
        if (force_sign_annotate and !annotate) sign = true;
        path = repo_mod.repo().gitPath("TAG_EDITMSG");
        object = createTag(object, object_ref, tag, &buf, msg_given or msgfile != null, edit_flag, sign, cleanup, prev, trailer_args.items, path.?);
    }

    const t = refs.Transaction.init();
    var e = t.update(ref, object, prev, null, null, if (create_reflog) refs.F_FORCE_CREATE_REFLOG else 0, reflog_msg);
    if (e == .ok) e = t.commit();
    if (e != .ok) {
        if (path) |p| util.eprint("The tag message has been left in {s}\n", .{p});
        util.die("{s}", .{t.errMsg()});
    }
    if (path) |p| {
        if (!os.unlink(p) and os.exists(p)) util.warn("unable to unlink '{s}'", .{p});
    }
    if (force != 0 and !hash.isZero(prev) and !hash.eql(prev, object))
        util.outf("Updated tag '{s}' (was {s})\n", .{ tag, revparse.abbrev(prev, 0) });
    return 0;
}

var sign_ptr_set: *bool = undefined;
var sign_ptr_val: *bool = undefined;

fn signCb(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = o;
    _ = arg;
    sign_ptr_set.* = true;
    sign_ptr_val.* = !unset;
}

fn pointsAtCb(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    rf.parseOptPointsAt(o, arg, unset);
}
