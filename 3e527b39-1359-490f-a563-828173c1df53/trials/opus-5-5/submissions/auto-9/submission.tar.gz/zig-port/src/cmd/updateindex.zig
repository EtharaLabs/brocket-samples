//! git update-index

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const objects = @import("../objects.zig");
const refs = @import("../refs.zig");
const index_mod = @import("../index.zig");
const pathspec = @import("../pathspec.zig");
const Oid = hash.Oid;
const Entry = index_mod.Entry;
const Index = index_mod.Index;
const gpa = util.gpa;

const Mark = enum { none, mark, unmark };

var allow_add = false;
var allow_remove = false;
var allow_replace = false;
var info_only = false;
var force_remove = false;
var verbose = false;
var mark_valid_only: Mark = .none;
var mark_skip_worktree_only: Mark = .none;
var mark_fsmonitor_only: Mark = .none;
var ignore_skip_worktree_entries = false;
var idx: *Index = undefined;

const usage = [_][]const u8{"git update-index [<options>] [--] [<file>...]"};

var d_bool = false;
var d_int: i32 = 0;
var d_str: ?[]const u8 = null;
fn dcb(_: ?[]const u8, _: bool) void {}

const usage_opts = [_]po.Opt{
    po.bit('q', "", &d_int, 1, "continue refresh even when index needs update"),
    po.bit(0, "ignore-submodules", &d_int, 1, "refresh: ignore submodules"),
    po.setInt(0, "add", &d_int, 1, "do not ignore new files"),
    po.setInt(0, "replace", &d_int, 1, "let files replace directories and vice-versa"),
    po.setInt(0, "remove", &d_int, 1, "notice files missing from worktree"),
    po.bit(0, "unmerged", &d_int, 1, "refresh even if index contains unmerged entries"),
    .{ .kind = .callback, .long = "refresh", .cb = dcb, .noarg = true, .noneg = true, .help = "refresh stat information" },
    .{ .kind = .callback, .long = "really-refresh", .cb = dcb, .noarg = true, .noneg = true, .help = "like --refresh, but ignore assume-unchanged setting" },
    .{ .kind = .callback, .long = "cacheinfo", .cb = dcb, .noarg = true, .noneg = true, .literal_argh = true, .argh = "<mode>,<object>,<path>", .help = "add the specified entry to the index" },
    .{ .kind = .callback, .long = "chmod", .cb = dcb, .noneg = true, .literal_argh = true, .argh = "(+|-)x", .help = "override the executable bit of the listed files" },
    .{ .kind = .set_int, .long = "assume-unchanged", .i = &d_int, .noarg = true, .noneg = true, .help = "mark files as \"not changing\"" },
    .{ .kind = .set_int, .long = "no-assume-unchanged", .i = &d_int, .noarg = true, .noneg = true, .help = "clear assumed-unchanged bit" },
    .{ .kind = .set_int, .long = "skip-worktree", .i = &d_int, .noarg = true, .noneg = true, .help = "mark files as \"index-only\"" },
    .{ .kind = .set_int, .long = "no-skip-worktree", .i = &d_int, .noarg = true, .noneg = true, .help = "clear skip-worktree bit" },
    po.boolean(0, "ignore-skip-worktree-entries", &d_bool, "do not touch index-only entries"),
    po.setInt(0, "info-only", &d_int, 1, "add to index only; do not add content to object database"),
    po.setInt(0, "force-remove", &d_int, 1, "remove named paths even if present in worktree"),
    po.boolean('z', "", &d_bool, "with --stdin: input lines are terminated by null bytes"),
    .{ .kind = .callback, .long = "stdin", .cb = dcb, .noarg = true, .noneg = true, .help = "read list of paths to be updated from standard input" },
    .{ .kind = .callback, .long = "index-info", .cb = dcb, .noarg = true, .noneg = true, .help = "add entries from standard input to the index" },
    .{ .kind = .callback, .long = "unresolve", .cb = dcb, .noarg = true, .noneg = true, .help = "repopulate stages #2 and #3 for the listed paths" },
    .{ .kind = .callback, .short = 'g', .long = "again", .cb = dcb, .noarg = true, .noneg = true, .help = "only update entries that differ from HEAD" },
    po.bit(0, "ignore-missing", &d_int, 1, "ignore files missing from worktree"),
    po.setInt(0, "verbose", &d_int, 1, "report actions to standard output"),
    .{ .kind = .callback, .long = "clear-resolve-undo", .cb = dcb, .noarg = true, .noneg = true, .help = "(for porcelains) forget saved unresolved conflicts" },
    po.integer(0, "index-version", &d_int, "<n>", "write index in this format"),
    po.setInt(0, "show-index-version", &d_int, -1, "report on-disk index format version"),
    po.boolean(0, "split-index", &d_bool, "enable or disable split index"),
    po.boolean(0, "untracked-cache", &d_bool, "enable/disable untracked cache"),
    po.setInt(0, "test-untracked-cache", &d_int, 1, "test if the filesystem supports untracked cache"),
    po.setInt(0, "force-untracked-cache", &d_int, 1, "enable untracked cache without testing the filesystem"),
    po.setInt(0, "force-write-index", &d_int, 1, "write out the index even if is not flagged as changed"),
    po.boolean(0, "fsmonitor", &d_bool, "enable or disable file system monitor"),
    .{ .kind = .set_int, .long = "fsmonitor-valid", .i = &d_int, .noarg = true, .noneg = true, .help = "mark files as fsmonitor valid" },
    .{ .kind = .set_int, .long = "no-fsmonitor-valid", .i = &d_int, .noarg = true, .noneg = true, .help = "clear fsmonitor valid bit" },
};

fn report(comptime f: []const u8, args: anytype) void {
    if (!verbose) return;
    util.outf(f ++ "\n", args);
}

fn usageError() noreturn {
    po.usageExit(&usage, &usage_opts, true);
}

fn removeOnePath(path: []const u8) bool {
    if (!allow_remove) {
        util.err("{s}: does not exist and --remove not passed", .{path});
        return false;
    }
    _ = idx.removePath(path);
    return true;
}

fn addOnePath(old: ?*const Entry, path: []const u8, st: os.Stat) bool {
    if (old) |o| {
        if (o.stage() == 0 and idx.matchStat(o, st, false) == 0) return true;
    }
    var e = Entry{ .path = util.dupe(path) };
    e.fillStat(st);
    e.mode = index_mod.ceModeFromStat(old, st);
    if (st.isDir()) {
        e.oid = index_mod.gitlinkHead(path) orelse return false;
    } else {
        const ne = index_mod.entryFromFile(e.path, st, old, !info_only) orelse {
            util.err("{s}: failed to insert into database", .{path});
            return false;
        };
        e.oid = ne.oid;
    }
    if (!idx.add(e, .{ .ok_to_add = allow_add, .ok_to_replace = allow_replace })) {
        util.err("{s}: cannot add to the index - missing --add option?", .{path});
        return false;
    }
    return true;
}

fn processDirectory(path: []const u8, st: os.Stat) bool {
    switch (idx.pos(path, 0)) {
        .found => |i| {
            const ce = &idx.entries.items[i];
            if (ce.mode & os.S_IFMT == os.S_IFGITLINK) {
                if (index_mod.gitlinkHead(path) == null) return true;
                const copy = ce.*;
                return addOnePath(&copy, path, st);
            }
            return removeOnePath(path);
        },
        .missing => |start| {
            var p = start;
            while (p < idx.entries.items.len) : (p += 1) {
                const n = idx.entries.items[p].path;
                if (n.len < path.len or !std.mem.eql(u8, n[0..path.len], path)) break;
                if (n.len == path.len) continue;
                if (n[path.len] > '/') break;
                if (n[path.len] < '/') continue;
                util.err("{s}: is a directory - add individual files instead", .{path});
                return false;
            }
        },
    }
    if (index_mod.gitlinkHead(path) != null) return addOnePath(null, path, st);
    util.err("{s}: is a directory - add files inside instead", .{path});
    return false;
}

fn processPath(path: []const u8, st: ?os.Stat) bool {
    if (pathspec.hasSymlinkLeadingPath(path)) {
        util.err("'{s}' is beyond a symbolic link", .{path});
        return false;
    }
    const ce: ?Entry = if (idx.findPos(path)) |i| idx.entries.items[i] else null;
    if (ce) |c| {
        if (c.skipWorktree()) {
            if (!ignore_skip_worktree_entries and allow_remove) _ = idx.removePath(path);
            return true;
        }
    }
    const s = st orelse return removeOnePath(path);
    if (s.isDir()) return processDirectory(path, s);
    if (ce) |c| {
        const copy = c;
        return addOnePath(&copy, path, s);
    }
    return addOnePath(null, path, s);
}

fn markFlags(path: []const u8, is_skip: bool, mark: bool) bool {
    const i = idx.findPos(path) orelse return false;
    const e = &idx.entries.items[i];
    if (is_skip) {
        if (mark) e.ext_flags |= index_mod.CE_SKIP_WORKTREE else e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
    } else {
        if (mark) e.flags |= index_mod.CE_VALID else e.flags &= ~index_mod.CE_VALID;
    }
    idx.invalidatePath(path);
    return true;
}

fn updateOne(path: []const u8) void {
    var st: ?os.Stat = null;
    if (mark_valid_only == .none and mark_skip_worktree_only == .none and !force_remove and mark_fsmonitor_only == .none)
        st = os.lstatPath(path);
    const mode: u32 = if (st) |s| s.mode else 0;
    if (!index_mod.verifyPath(path, mode)) {
        util.eprint("Ignoring path {s}\n", .{path});
        return;
    }
    if (mark_valid_only != .none) {
        if (!markFlags(path, false, mark_valid_only == .mark)) util.die("Unable to mark file {s}", .{path});
        return;
    }
    if (mark_skip_worktree_only != .none) {
        if (!markFlags(path, true, mark_skip_worktree_only == .mark)) util.die("Unable to mark file {s}", .{path});
        return;
    }
    if (mark_fsmonitor_only != .none) {
        if (idx.findPos(path) == null) util.die("Unable to mark file {s}", .{path});
        return;
    }
    if (force_remove) {
        _ = idx.removePath(path);
        report("remove '{s}'", .{path});
        return;
    }
    if (!processPath(path, st)) util.die("Unable to process path {s}", .{path});
    report("add '{s}'", .{path});
}

fn chmodPath(flip: u8, path: []const u8) void {
    const i = idx.findPos(path) orelse util.die("git update-index: cannot chmod {c}x '{s}'", .{ flip, path });
    const e = &idx.entries.items[i];
    if (e.mode & os.S_IFMT != os.S_IFREG) util.die("git update-index: cannot chmod {c}x '{s}'", .{ flip, path });
    e.mode = if (flip == '+') 0o100755 else 0o100644;
    idx.invalidatePath(path);
    report("chmod {c}x '{s}'", .{ flip, path });
}

fn addCacheinfo(mode: u32, oid: Oid, path: []const u8, stage: u32) bool {
    if (!index_mod.verifyPath(path, mode)) {
        util.err("Invalid path '{s}'", .{path});
        return false;
    }
    var e = Entry{ .path = util.dupe(path), .oid = oid, .mode = index_mod.canonMode(mode) };
    e.setStage(stage);
    if (mark_valid_only == .mark) e.flags |= index_mod.CE_VALID;
    if (!idx.add(e, .{ .ok_to_add = allow_add, .ok_to_replace = allow_replace })) {
        util.err("{s}: cannot add to the index - missing --add option?", .{path});
        return false;
    }
    report("add '{s}'", .{path});
    return true;
}

fn parseOctal(s: []const u8) ?u32 {
    if (s.len == 0) return null;
    return std.fmt.parseInt(u32, s, 8) catch null;
}

fn readLines(nul: bool) [][]const u8 {
    const data = os.readAllFd(0) catch util.die("could not read from stdin", .{});
    var l: std.ArrayList([]const u8) = .empty;
    const sep: u8 = if (nul) 0 else '\n';
    var it = std.mem.splitScalar(u8, data, sep);
    while (it.next()) |line0| {
        var line = line0;
        if (!nul and line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
        l.append(gpa, line) catch util.oom();
    }
    // drop the trailing empty element after the last terminator
    if (l.items.len > 0 and l.items[l.items.len - 1].len == 0) _ = l.pop();
    return l.items;
}

fn readIndexInfo(nul: bool) void {
    for (readLines(nul)) |line| {
        const sp = std.mem.indexOfScalar(u8, line, ' ') orelse badLine(line);
        const mode = parseOctal(line[0..sp]) orelse badLine(line);
        const tab = std.mem.indexOfScalar(u8, line, '\t') orelse badLine(line);
        if (tab < sp + 41) badLine(line);
        var stage: u32 = 0;
        var oid_end = tab;
        if (line[tab - 2] == ' ' and line[tab - 1] >= '0' and line[tab - 1] <= '3') {
            stage = line[tab - 1] - '0';
            oid_end = tab - 2;
        }
        if (oid_end < 41) badLine(line);
        const oid = hash.fromHex(line[oid_end - 40 .. oid_end]) orelse badLine(line);
        if (line[oid_end - 41] != ' ') badLine(line);
        var path: []const u8 = line[tab + 1 ..];
        if (!nul and path.len > 0 and path[0] == '"') {
            const uq = util.cunquote(path) orelse util.die("git update-index: bad quoting of path name", .{});
            path = uq.value;
        }
        if (!index_mod.verifyPath(path, mode)) {
            util.eprint("Ignoring path {s}\n", .{path});
            continue;
        }
        if (mode == 0) {
            _ = idx.removePath(path);
        } else {
            if (!addCacheinfo(mode, oid, path, stage)) util.die("git update-index: unable to update {s}", .{path});
        }
    }
}

fn badLine(line: []const u8) noreturn {
    util.die("malformed index info {s}", .{line});
}

fn prefixed(arg: []const u8) []const u8 {
    return repo_mod.prefixPath(arg) orelse util.die("'{s}' is outside repository at '{s}'", .{ arg, repo_mod.repo().work_tree orelse "" });
}

fn doReupdate(paths: []const []const u8) bool {
    const r = repo_mod.repo();
    const ps = pathspec.parse(r.prefix, paths, .{ .prefer_cwd = true });
    const head = refs.readOid("HEAD");
    const head_tree: ?Oid = if (head) |h| (if (objects.readCommit(h)) |c| c.tree else null) else null;
    redo: while (true) {
        var i: usize = 0;
        while (i < idx.entries.items.len) : (i += 1) {
            const e = idx.entries.items[i];
            if (e.stage() != 0 or !ps.matches(e.path, false)) continue;
            if (head_tree) |t| {
                if (objects.treeLookup(t, e.path)) |te| {
                    if (te.mode == e.mode and hash.eql(te.oid, e.oid)) continue;
                }
            }
            const save = idx.entries.items.len;
            updateOne(e.path);
            if (save != idx.entries.items.len) continue :redo;
        }
        break;
    }
    return false;
}

pub fn cmdUpdateIndex(args: []const []const u8) u8 {
    if (args.len == 2 and util.eql(args[1], "-h")) po.usageExit(&usage, &usage_opts, false);
    const r = repo_mod.repo();
    idx = index_mod.lockAndRead();
    var has_errors = false;
    var refresh_flags: u32 = 0;
    var nul = false;
    var read_stdin = false;
    var flip: u8 = 0;
    var preferred_version: i32 = 0;
    var force_write = false;
    var done_opts = false;
    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (done_opts or a.len < 2 or a[0] != '-') {
            _ = repo_mod.requireWorkTree("update-index");
            const p = prefixed(a);
            updateOne(p);
            if (flip != 0) chmodPath(flip, p);
            continue;
        }
        if (util.eql(a, "--")) {
            done_opts = true;
            continue;
        }
        if (a[1] != '-') {
            // short option cluster
            for (a[1..]) |ch| switch (ch) {
                'q' => refresh_flags |= index_mod.REFRESH_QUIET,
                'z' => nul = true,
                'g' => {
                    _ = repo_mod.requireWorkTree("update-index");
                    has_errors = doReupdate(args[i + 1 ..]);
                    i = args.len;
                    break;
                },
                'h' => po.usageExit(&usage, &usage_opts, false),
                else => {
                    util.err("unknown switch '{c}'", .{ch});
                    usageError();
                },
            };
            continue;
        }
        const name = a[2..];
        const eq = std.mem.indexOfScalar(u8, name, '=');
        const key = if (eq) |e| name[0..e] else name;
        const val: ?[]const u8 = if (eq) |e| name[e + 1 ..] else null;
        if (util.eql(key, "add")) {
            allow_add = true;
        } else if (util.eql(key, "replace")) {
            allow_replace = true;
        } else if (util.eql(key, "remove")) {
            allow_remove = true;
        } else if (util.eql(key, "unmerged")) {
            refresh_flags |= index_mod.REFRESH_UNMERGED;
        } else if (util.eql(key, "ignore-missing")) {
            refresh_flags |= index_mod.REFRESH_IGNORE_MISSING;
        } else if (util.eql(key, "ignore-submodules")) {
            refresh_flags |= index_mod.REFRESH_IGNORE_SUBMODULES;
        } else if (util.eql(key, "refresh") or util.eql(key, "really-refresh")) {
            _ = repo_mod.requireWorkTree("update-index");
            const really: u32 = if (util.eql(key, "really-refresh")) index_mod.REFRESH_REALLY else 0;
            if (index_mod.refresh(idx, refresh_flags | really, null, null)) has_errors = true;
        } else if (util.eql(key, "cacheinfo")) {
            if (val != null) {
                util.err("option `cacheinfo' takes no value", .{});
                usageError();
            }
            if (i + 1 < args.len) {
                if (parseNewStyle(args[i + 1])) |ci| {
                    if (!addCacheinfo(ci.mode, ci.oid, ci.path, 0)) util.die("git update-index: --cacheinfo cannot add {s}", .{ci.path});
                    i += 1;
                    continue;
                }
            }
            if (i + 3 >= args.len) {
                util.err("option 'cacheinfo' expects <mode>,<sha1>,<path>", .{});
                usageError();
            }
            const mode = parseOctal(args[i + 1]);
            const oid = hash.fromHex(args[i + 2]);
            if (mode == null or oid == null or args[i + 2].len != 40 or !addCacheinfo(mode.?, oid.?, args[i + 3], 0))
                util.die("git update-index: --cacheinfo cannot add {s}", .{args[i + 3]});
            i += 3;
        } else if (util.eql(key, "chmod")) {
            const v = val orelse blk: {
                i += 1;
                if (i >= args.len) {
                    util.err("option `chmod' requires a value", .{});
                    usageError();
                }
                break :blk args[i];
            };
            if (v.len != 2 or (v[0] != '-' and v[0] != '+') or v[1] != 'x') {
                util.err("option 'chmod' expects \"+x\" or \"-x\"", .{});
                usageError();
            }
            flip = v[0];
        } else if (util.eql(key, "assume-unchanged")) {
            mark_valid_only = .mark;
        } else if (util.eql(key, "no-assume-unchanged")) {
            mark_valid_only = .unmark;
        } else if (util.eql(key, "skip-worktree")) {
            mark_skip_worktree_only = .mark;
        } else if (util.eql(key, "no-skip-worktree")) {
            mark_skip_worktree_only = .unmark;
        } else if (util.eql(key, "fsmonitor-valid")) {
            mark_fsmonitor_only = .mark;
        } else if (util.eql(key, "no-fsmonitor-valid")) {
            mark_fsmonitor_only = .unmark;
        } else if (util.eql(key, "ignore-skip-worktree-entries")) {
            ignore_skip_worktree_entries = true;
        } else if (util.eql(key, "no-ignore-skip-worktree-entries")) {
            ignore_skip_worktree_entries = false;
        } else if (util.eql(key, "info-only")) {
            info_only = true;
        } else if (util.eql(key, "force-remove")) {
            force_remove = true;
        } else if (util.eql(key, "stdin")) {
            if (i + 1 != args.len) {
                util.err("option 'stdin' must be the last argument", .{});
                usageError();
            }
            read_stdin = true;
        } else if (util.eql(key, "index-info")) {
            if (i + 1 != args.len) {
                util.err("option 'index-info' must be the last argument", .{});
                usageError();
            }
            allow_add = true;
            allow_replace = true;
            allow_remove = true;
            readIndexInfo(nul);
        } else if (util.eql(key, "unresolve")) {
            var err = false;
            for (args[i + 1 ..]) |p| {
                if (!idx.unmergeEntry(prefixed(p))) err = true;
            }
            if (err) {
                has_errors = true;
                idx.changed = false;
            }
            i = args.len;
        } else if (util.eql(key, "again")) {
            _ = repo_mod.requireWorkTree("update-index");
            has_errors = doReupdate(args[i + 1 ..]);
            i = args.len;
        } else if (util.eql(key, "verbose")) {
            verbose = true;
        } else if (util.eql(key, "clear-resolve-undo")) {
            if (idx.reuc.items.len > 0) idx.changed = true;
            idx.reuc.clearRetainingCapacity();
        } else if (util.eql(key, "index-version")) {
            const v = val orelse blk: {
                i += 1;
                if (i >= args.len) {
                    util.err("option `index-version' requires a value", .{});
                    usageError();
                }
                break :blk args[i];
            };
            preferred_version = std.fmt.parseInt(i32, v, 10) catch {
                util.err("option `index-version' expects a numerical value", .{});
                usageError();
            };
        } else if (util.eql(key, "show-index-version")) {
            preferred_version = -1;
        } else if (util.eql(key, "force-write-index")) {
            force_write = true;
        } else if (util.eql(key, "split-index") or util.eql(key, "no-split-index") or
            util.eql(key, "untracked-cache") or util.eql(key, "no-untracked-cache") or
            util.eql(key, "force-untracked-cache") or util.eql(key, "test-untracked-cache") or
            util.eql(key, "fsmonitor") or util.eql(key, "no-fsmonitor"))
        {
            // accepted; not implemented
        } else if (util.eql(key, "help-all") or util.eql(key, "help")) {
            po.usageExit(&usage, &usage_opts, false);
        } else {
            util.err("unknown option '{s}'", .{name});
            usageError();
        }
    }

    if (preferred_version != 0) {
        if (preferred_version < 0) {
            util.outf("{d}\n", .{idx.version});
        } else if (preferred_version < 2 or preferred_version > 4) {
            util.die("index-version {d} not in range: 2..4", .{preferred_version});
        } else {
            if (idx.version != preferred_version) idx.changed = true;
            report("index-version: was {d}, set to {d}", .{ idx.version, preferred_version });
            idx.version = @intCast(preferred_version);
            idx.loaded_from_disk = true;
        }
    }

    if (read_stdin) {
        _ = repo_mod.requireWorkTree("update-index");
        for (readLines(nul)) |line0| {
            var line = line0;
            if (!nul and line.len > 0 and line[0] == '"') {
                const uq = util.cunquote(line) orelse util.die("line is badly quoted", .{});
                line = uq.value;
            }
            const p = prefixed(line);
            updateOne(p);
            if (flip != 0) chmodPath(flip, p);
        }
    }
    _ = r;

    if (idx.changed or force_write) {
        idx.write();
    } else {
        idx.rollback();
    }
    return if (has_errors) 1 else 0;
}

const CacheInfo = struct { mode: u32, oid: Oid, path: []const u8 };

fn parseNewStyle(arg: []const u8) ?CacheInfo {
    const c1 = std.mem.indexOfScalar(u8, arg, ',') orelse return null;
    const mode = parseOctal(arg[0..c1]) orelse return null;
    const rest = arg[c1 + 1 ..];
    if (rest.len < 41 or rest[40] != ',') return null;
    const oid = hash.fromHex(rest[0..40]) orelse return null;
    return .{ .mode = mode, .oid = oid, .path = rest[41..] };
}
