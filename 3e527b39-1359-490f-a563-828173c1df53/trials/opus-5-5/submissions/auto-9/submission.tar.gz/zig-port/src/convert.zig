//! Content conversion between worktree and repository (port of convert.c):
//! text/eol/crlf attributes, core.autocrlf, core.eol, core.safecrlf, ident,
//! filter.<driver>.clean/smudge/required (single-file filters run via sh),
//! filter.<driver>.process (long running filter protocol v2), working-tree-encoding.
//!
//! API:
//!   toGit(path, data) []const u8                     // clean (no safecrlf checks)
//!   toGitChecked(path, data, write_object) []const u8 // with core.safecrlf warnings/dies when write_object
//!   toGitFlags(path, data, flags) []const u8          // CONV_* flags
//!   toWorktree(path, data) []const u8                 // smudge
//!   renormalize(path, data) []const u8                // renormalize_buffer
//!   wouldConvertToGit(path) bool                      // for racy/stat checks: content may change on clean
//!   convertAttrs(path) ConvAttrs
//!   getConvertAttrAscii(path), getCachedConvertStatsAscii(idx, path), getWtConvertStatsAscii(path),
//!   gatherConvertStatsAscii(data)                     // for ls-files --eol
//!   reencode(data, to, from) ?[]u8                    // iconv wrapper
//!   reset()                                           // drop cached config/attributes

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const attr = @import("attr.zig");
const index_mod = @import("index.zig");
const config = @import("config.zig");
const hash = @import("hash.zig");
const gpa = util.gpa;

pub const CONV_EOL_RNDTRP_DIE: u32 = 1 << 0;
pub const CONV_EOL_RNDTRP_WARN: u32 = 1 << 1;
pub const CONV_EOL_RENORMALIZE: u32 = 1 << 2;
pub const CONV_EOL_KEEP_CRLF: u32 = 1 << 3;
pub const CONV_WRITE_OBJECT: u32 = 1 << 4;

pub const CrlfAction = enum {
    undefined,
    binary,
    text,
    text_input,
    text_crlf,
    auto,
    auto_crlf,
    auto_input,
};

const Eol = enum { unset, lf, crlf };
const AutoCrlf = enum { false_, true_, input };

pub const Driver = struct {
    name: []const u8,
    smudge: ?[]const u8 = null,
    clean: ?[]const u8 = null,
    process: ?[]const u8 = null,
    required: bool = false,
};

pub const ConvAttrs = struct {
    drv: ?*Driver = null,
    attr_action: CrlfAction = .undefined,
    crlf_action: CrlfAction = .undefined,
    ident: bool = false,
    working_tree_encoding: ?[]const u8 = null,
};

// ---------------------------------------------------------------------------
// config

var cfg_loaded = false;
var auto_crlf: AutoCrlf = .false_;
var core_eol: Eol = .unset;
var global_conv_flags_eol: u32 = CONV_EOL_RNDTRP_WARN;
var drivers: std.ArrayList(*Driver) = .empty;

fn loadConfig() void {
    if (cfg_loaded) return;
    cfg_loaded = true;
    const cfg = &repo_mod.cfg;
    if (cfg.getEntry("core.autocrlf")) |ent| {
        const v = ent.value;
        if (v != null and std.ascii.eqlIgnoreCase(v.?, "input")) {
            auto_crlf = .input;
        } else {
            auto_crlf = if (cfgBool(v)) .true_ else .false_;
        }
    }
    if (cfg.getEntry("core.safecrlf")) |ent| {
        const v = ent.value;
        if (v != null and std.ascii.eqlIgnoreCase(v.?, "warn")) {
            global_conv_flags_eol = CONV_EOL_RNDTRP_WARN;
        } else {
            global_conv_flags_eol = if (cfgBool(v)) CONV_EOL_RNDTRP_DIE else 0;
        }
    }
    if (cfg.get("core.eol")) |v| {
        if (std.ascii.eqlIgnoreCase(v, "lf")) {
            core_eol = .lf;
        } else if (std.ascii.eqlIgnoreCase(v, "crlf")) {
            core_eol = .crlf;
        } else core_eol = .unset; // native == lf on this platform
    }
    // filter.<name>.<key>
    for (cfg.entries.items) |e| {
        const key = e.key;
        if (!util.startsWith(key, "filter.")) continue;
        const rest = key["filter.".len..];
        const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse continue;
        const name = rest[0..dot];
        const k = rest[dot + 1 ..];
        var drv: ?*Driver = null;
        for (drivers.items) |d| {
            if (util.eql(d.name, name)) drv = d;
        }
        if (drv == null) {
            const d = gpa.create(Driver) catch util.oom();
            d.* = .{ .name = util.dupe(name) };
            drivers.append(gpa, d) catch util.oom();
            drv = d;
        }
        if (util.eql(k, "smudge")) {
            drv.?.smudge = e.value orelse util.die("missing value for '{s}'", .{key});
        } else if (util.eql(k, "clean")) {
            drv.?.clean = e.value orelse util.die("missing value for '{s}'", .{key});
        } else if (util.eql(k, "process")) {
            drv.?.process = e.value orelse util.die("missing value for '{s}'", .{key});
        } else if (util.eql(k, "required")) {
            drv.?.required = cfgBool(e.value);
        }
    }
}

fn cfgBool(v: ?[]const u8) bool {
    const s = v orelse return true;
    return config.parseBool(s) orelse blk: {
        if (config.parseInt(s)) |n| break :blk n != 0;
        break :blk false;
    };
}

pub fn reset() void {
    cfg_loaded = false;
    auto_crlf = .false_;
    core_eol = .unset;
    global_conv_flags_eol = CONV_EOL_RNDTRP_WARN;
    drivers.items.len = 0;
    attr.reset();
}

/// core.safecrlf derived flags (global_conv_flags_eol)
pub fn globalConvFlags() u32 {
    loadConfig();
    return global_conv_flags_eol;
}

// ---------------------------------------------------------------------------
// stats

const TextStat = struct {
    nul: u32 = 0,
    lonecr: u32 = 0,
    lonelf: u32 = 0,
    crlf: u32 = 0,
    printable: u32 = 0,
    nonprintable: u32 = 0,
};

fn gatherStats(buf: []const u8) TextStat {
    var s = TextStat{};
    var i: usize = 0;
    while (i < buf.len) : (i += 1) {
        const c = buf[i];
        if (c == '\r') {
            if (i + 1 < buf.len and buf[i + 1] == '\n') {
                s.crlf += 1;
                i += 1;
            } else s.lonecr += 1;
            continue;
        }
        if (c == '\n') {
            s.lonelf += 1;
            continue;
        }
        if (c == 127) {
            s.nonprintable += 1;
        } else if (c < 32) {
            switch (c) {
                8, '\t', 0o33, 0o14 => s.printable += 1,
                0 => {
                    s.nul += 1;
                    s.nonprintable += 1;
                },
                else => s.nonprintable += 1,
            }
        } else s.printable += 1;
    }
    if (buf.len >= 1 and buf[buf.len - 1] == 0o32) s.nonprintable -%= 1;
    return s;
}

fn isBinary(s: *const TextStat) bool {
    if (s.lonecr != 0) return true;
    if (s.nul != 0) return true;
    if ((s.printable >> 7) < s.nonprintable) return true;
    return false;
}

const STAT_LF: u32 = 1;
const STAT_CRLF: u32 = 2;
const STAT_BIN: u32 = 4;

fn gatherConvertStats(data: []const u8) u32 {
    if (data.len == 0) return 0;
    const s = gatherStats(data);
    var r: u32 = 0;
    if (isBinary(&s)) r |= STAT_BIN;
    if (s.crlf != 0) r |= STAT_CRLF;
    if (s.lonelf != 0) r |= STAT_LF;
    return r;
}

pub fn gatherConvertStatsAscii(data: []const u8) []const u8 {
    const st = gatherConvertStats(data);
    if (st & STAT_BIN != 0) return "-text";
    return switch (st) {
        STAT_LF => "lf",
        STAT_CRLF => "crlf",
        STAT_LF | STAT_CRLF => "mixed",
        else => "none",
    };
}

fn readBlobFromIndex(idx: ?*index_mod.Index, path: []const u8) ?[]const u8 {
    const ix = idx orelse return null;
    var e: ?*index_mod.Entry = null;
    switch (ix.pos(path, 0)) {
        .found => |p| e = &ix.entries.items[p],
        .missing => |p0| {
            // unmerged: prefer stage #2
            var p = p0;
            while (p < ix.entries.items.len and util.eql(ix.entries.items[p].path, path)) : (p += 1) {
                if (ix.entries.items[p].stage() == 2) {
                    e = &ix.entries.items[p];
                    break;
                }
            }
        },
    }
    const ent = e orelse return null;
    const obj = repo_mod.repo().odb().read(ent.oid) orelse return null;
    if (obj.typ != .blob) return null;
    return obj.data;
}

fn theIndex() ?*index_mod.Index {
    if (repo_mod.repo_ == null) return null;
    return index_mod.get();
}

pub fn getCachedConvertStatsAscii(idx: ?*index_mod.Index, path: []const u8) []const u8 {
    const data = readBlobFromIndex(idx, path) orelse "";
    return gatherConvertStatsAscii(data);
}

pub fn getWtConvertStatsAscii(path: []const u8) []const u8 {
    const data = os.readFile(path) orelse return "";
    return gatherConvertStatsAscii(data);
}

fn textEolIsCrlf() bool {
    if (auto_crlf == .true_) return true;
    if (auto_crlf == .input) return false;
    if (core_eol == .crlf) return true;
    return false;
}

fn outputEol(a: CrlfAction) Eol {
    return switch (a) {
        .binary => .unset,
        .text_crlf => .crlf,
        .text_input => .lf,
        .undefined, .auto_crlf => .crlf,
        .auto_input => .lf,
        .text, .auto => if (textEolIsCrlf()) .crlf else .lf,
    };
}

fn isAuto(a: CrlfAction) bool {
    return a == .auto or a == .auto_input or a == .auto_crlf;
}

fn checkGlobalConvFlagsEol(path: []const u8, old: *const TextStat, new: *const TextStat, flags: u32) void {
    if (old.crlf != 0 and new.crlf == 0) {
        if (flags & CONV_EOL_RNDTRP_DIE != 0) {
            util.die("CRLF would be replaced by LF in {s}", .{path});
        } else if (flags & CONV_EOL_RNDTRP_WARN != 0) {
            util.warn("in the working copy of '{s}', CRLF will be replaced by LF the next time Git touches it", .{path});
        }
    } else if (old.lonelf != 0 and new.lonelf == 0) {
        if (flags & CONV_EOL_RNDTRP_DIE != 0) {
            util.die("LF would be replaced by CRLF in {s}", .{path});
        } else if (flags & CONV_EOL_RNDTRP_WARN != 0) {
            util.warn("in the working copy of '{s}', LF will be replaced by CRLF the next time Git touches it", .{path});
        }
    }
}

fn hasCrlfInIndex(path: []const u8) bool {
    const data = readBlobFromIndex(theIndex(), path) orelse return false;
    if (std.mem.indexOfScalar(u8, data, '\r') == null) return false;
    const st = gatherConvertStats(data);
    return st & STAT_BIN == 0 and st & STAT_CRLF != 0;
}

fn willConvertLfToCrlf(s: *const TextStat, a: CrlfAction) bool {
    if (outputEol(a) != .crlf) return false;
    if (s.lonelf == 0) return false;
    if (isAuto(a)) {
        if (s.lonecr != 0 or s.crlf != 0) return false;
        if (isBinary(s)) return false;
    }
    return true;
}

/// crlf_to_git. data == null means dry run ("would convert?").
fn crlfToGit(path: []const u8, data: ?[]const u8, a: CrlfAction, flags: u32) ?[]const u8 {
    if (a == .binary) return null;
    const src = data orelse return ""; // dry run: would convert
    if (src.len == 0) return null;
    const s = gatherStats(src);
    var convert = s.crlf != 0;
    if (isAuto(a)) {
        if (isBinary(&s)) return null;
        if (flags & CONV_EOL_RENORMALIZE == 0 and hasCrlfInIndex(path)) convert = false;
    }
    if (flags & CONV_EOL_RNDTRP_WARN != 0 or (flags & CONV_EOL_RNDTRP_DIE != 0 and src.len > 0)) {
        var ns = s;
        if (convert) {
            ns.lonelf += ns.crlf;
            ns.crlf = 0;
        }
        if (willConvertLfToCrlf(&ns, a)) {
            ns.crlf += ns.lonelf;
            ns.lonelf = 0;
        }
        checkGlobalConvFlagsEol(path, &s, &ns, flags);
    }
    if (!convert) return null;
    var out: util.Buf = .empty;
    out.ensureTotalCapacity(gpa, src.len) catch util.oom();
    if (isAuto(a)) {
        for (src) |c| {
            if (c != '\r') out.appendAssumeCapacity(c);
        }
    } else {
        for (src, 0..) |c, i| {
            if (!(c == '\r' and i + 1 < src.len and src[i + 1] == '\n')) out.appendAssumeCapacity(c);
        }
    }
    return out.items;
}

fn crlfToWorktree(src: []const u8, a: CrlfAction) ?[]const u8 {
    if (src.len == 0 or outputEol(a) != .crlf) return null;
    const s = gatherStats(src);
    if (!willConvertLfToCrlf(&s, a)) return null;
    var out: util.Buf = .empty;
    out.ensureTotalCapacity(gpa, src.len + s.lonelf) catch util.oom();
    var rest = src;
    while (std.mem.indexOfScalar(u8, rest, '\n')) |nl| {
        if (nl > 0 and rest[nl - 1] == '\r') {
            util.bufAppend(&out, rest[0 .. nl + 1]);
        } else {
            util.bufAppend(&out, rest[0..nl]);
            util.bufAppend(&out, "\r\n");
        }
        rest = rest[nl + 1 ..];
    }
    util.bufAppend(&out, rest);
    return out.items;
}

// ---------------------------------------------------------------------------
// ident

fn countIdent(buf: []const u8) usize {
    var cnt: usize = 0;
    var i: usize = 0;
    while (i < buf.len) {
        const ch = buf[i];
        i += 1;
        if (ch != '$') continue;
        if (buf.len - i < 3) break;
        if (!std.mem.eql(u8, buf[i .. i + 2], "Id")) continue;
        const c2 = buf[i + 2];
        i += 3;
        if (c2 == '$') cnt += 1;
        if (c2 != ':') continue;
        while (i < buf.len) {
            const c3 = buf[i];
            i += 1;
            if (c3 == '$') {
                cnt += 1;
                break;
            }
            if (c3 == '\n') break;
        }
    }
    return cnt;
}

fn identToGit(data: ?[]const u8, ident: bool) ?[]const u8 {
    if (!ident) return null;
    const src0 = data orelse return "";
    if (countIdent(src0) == 0) return null;
    var out: util.Buf = .empty;
    var src = src0;
    while (true) {
        const dollar = std.mem.indexOfScalar(u8, src, '$') orelse break;
        util.bufAppend(&out, src[0 .. dollar + 1]);
        src = src[dollar + 1 ..];
        if (src.len > 3 and std.mem.eql(u8, src[0..3], "Id:")) {
            const d2 = std.mem.indexOfScalarPos(u8, src, 3, '$') orelse break;
            if (std.mem.indexOfScalar(u8, src[3..d2], '\n') != null) continue;
            util.bufAppend(&out, "Id$");
            src = src[d2 + 1 ..];
        }
    }
    util.bufAppend(&out, src);
    return out.items;
}

fn identToWorktree(src0: []const u8, ident: bool) ?[]const u8 {
    if (!ident) return null;
    if (countIdent(src0) == 0) return null;
    const oid = @import("odb.zig").hashObject(.blob, src0);
    const hex = hash.hex(oid);
    var out: util.Buf = .empty;
    var src = src0;
    while (true) {
        const dollar = std.mem.indexOfScalar(u8, src, '$') orelse break;
        util.bufAppend(&out, src[0 .. dollar + 1]);
        src = src[dollar + 1 ..];
        if (src.len < 3 or !std.mem.eql(u8, src[0..2], "Id")) continue;
        if (src[2] == '$') {
            src = src[3..];
        } else if (src[2] == ':') {
            const d2 = std.mem.indexOfScalarPos(u8, src, 3, '$') orelse break;
            if (std.mem.indexOfScalar(u8, src[3..d2], '\n') != null) continue;
            if (d2 >= 4) {
                if (std.mem.indexOfScalar(u8, src[4..d2], ' ')) |sp| {
                    if (4 + sp < d2 - 1) continue;
                }
            }
            src = src[d2 + 1 ..];
        } else continue;
        util.bufAppend(&out, "Id: ");
        util.bufAppend(&out, &hex);
        util.bufAppend(&out, " $");
    }
    util.bufAppend(&out, src);
    return out.items;
}

// ---------------------------------------------------------------------------
// encodings

const iconv_t = ?*anyopaque;
extern "c" fn iconv_open(tocode: [*:0]const u8, fromcode: [*:0]const u8) iconv_t;
extern "c" fn iconv(cd: iconv_t, inbuf: *?[*]u8, inbytesleft: *usize, outbuf: *?[*]u8, outbytesleft: *usize) usize;
extern "c" fn iconv_close(cd: iconv_t) c_int;

fn sameUtfEncoding(a0: []const u8, b0: []const u8) bool {
    if (a0.len < 3 or b0.len < 3) return false;
    if (!std.ascii.eqlIgnoreCase(a0[0..3], "utf") or !std.ascii.eqlIgnoreCase(b0[0..3], "utf")) return false;
    var a = a0[3..];
    var b = b0[3..];
    if (a.len > 0 and a[0] == '-') a = a[1..];
    if (b.len > 0 and b[0] == '-') b = b[1..];
    return std.ascii.eqlIgnoreCase(a, b);
}

pub fn isEncodingUtf8(name: ?[]const u8) bool {
    const n = name orelse return true;
    return sameUtfEncoding("utf-8", n);
}

pub fn sameEncoding(a: ?[]const u8, b: ?[]const u8) bool {
    const x = a orelse "UTF-8";
    const y = b orelse "UTF-8";
    if (sameUtfEncoding(x, y)) return true;
    return std.ascii.eqlIgnoreCase(x, y);
}

fn zstr(s: []const u8) [:0]u8 {
    const b = gpa.allocSentinel(u8, s.len, 0) catch util.oom();
    @memcpy(b[0..s.len], s);
    return b;
}

fn iconvConvert(data: []const u8, to: []const u8, from: []const u8) ?[]u8 {
    var cd = iconv_open(zstr(to).ptr, zstr(from).ptr);
    if (@intFromPtr(cd) == std.math.maxInt(usize)) {
        const f2 = if (isEncodingUtf8(from)) "UTF-8" else from;
        const t2 = if (isEncodingUtf8(to)) "UTF-8" else to;
        cd = iconv_open(zstr(t2).ptr, zstr(f2).ptr);
        if (@intFromPtr(cd) == std.math.maxInt(usize)) return null;
    }
    defer _ = iconv_close(cd);
    const inbuf = gpa.dupe(u8, data) catch util.oom();
    var inp: ?[*]u8 = inbuf.ptr;
    var inleft: usize = inbuf.len;
    var cap: usize = data.len * 4 + 16;
    var out = gpa.alloc(u8, cap) catch util.oom();
    var used: usize = 0;
    while (true) {
        var outp: ?[*]u8 = out.ptr + used;
        var outleft: usize = cap - used;
        const r = iconv(cd, &inp, &inleft, &outp, &outleft);
        used = cap - outleft;
        if (r == std.math.maxInt(usize)) {
            if (os.errno() == 7) { // E2BIG
                cap *= 2;
                out = gpa.realloc(out, cap) catch util.oom();
                continue;
            }
            return null;
        }
        break;
    }
    // flush
    var outp2: ?[*]u8 = out.ptr + used;
    var outleft2: usize = cap - used;
    var nullin: ?[*]u8 = null;
    var zero: usize = 0;
    _ = iconv(cd, &nullin, &zero, &outp2, &outleft2);
    used = cap - outleft2;
    return out[0..used];
}

/// reencode_string_len()
pub fn reencode(data: []const u8, out_enc0: []const u8, in_enc0: []const u8) ?[]u8 {
    var in_enc = in_enc0;
    var out_enc = out_enc0;
    if (sameUtfEncoding("UTF-16LE-BOM", in_enc)) in_enc = "UTF-16";
    var bom: []const u8 = "";
    if (sameUtfEncoding("UTF-16LE-BOM", out_enc)) {
        bom = "\xff\xfe";
        out_enc = "UTF-16LE";
    } else if (sameUtfEncoding("UTF-16BE-BOM", out_enc)) {
        bom = "\xfe\xff";
        out_enc = "UTF-16BE";
    }
    const r = iconvConvert(data, out_enc, in_enc) orelse return null;
    if (bom.len == 0) return r;
    return util.concat(&.{ bom, r });
}

fn hasBom(data: []const u8, bom: []const u8) bool {
    return util.startsWith(data, bom);
}

const utf16_be_bom = "\xfe\xff";
const utf16_le_bom = "\xff\xfe";
const utf32_be_bom = "\x00\x00\xfe\xff";
const utf32_le_bom = "\xff\xfe\x00\x00";

fn hasProhibitedUtfBom(enc: []const u8, data: []const u8) bool {
    return ((sameUtfEncoding("UTF-16BE", enc) or sameUtfEncoding("UTF-16LE", enc)) and
        (hasBom(data, utf16_be_bom) or hasBom(data, utf16_le_bom))) or
        ((sameUtfEncoding("UTF-32BE", enc) or sameUtfEncoding("UTF-32LE", enc)) and
            (hasBom(data, utf32_be_bom) or hasBom(data, utf32_le_bom)));
}

fn isMissingRequiredUtfBom(enc: []const u8, data: []const u8) bool {
    return (sameUtfEncoding(enc, "UTF-16") and !(hasBom(data, utf16_be_bom) or hasBom(data, utf16_le_bom))) or
        (sameUtfEncoding(enc, "UTF-32") and !(hasBom(data, utf32_be_bom) or hasBom(data, utf32_le_bom)));
}

fn validateEncoding(path: []const u8, enc: []const u8, data: []const u8, die_on_error: bool) bool {
    if (enc.len >= 3 and std.ascii.eqlIgnoreCase(enc[0..3], "UTF")) {
        var stripped = enc[3..];
        if (stripped.len > 0 and stripped[0] == '-') stripped = stripped[1..];
        const advice = @import("advice.zig");
        if (hasProhibitedUtfBom(enc, data)) {
            const sl = if (stripped.len >= 2) stripped.len - 2 else 0;
            advice.advise(util.fmt("The file '{s}' contains a byte order mark (BOM). Please use UTF-{s} as working-tree-encoding.", .{ path, stripped[0..sl] }));
            if (die_on_error) util.die("BOM is prohibited in '{s}' if encoded as {s}", .{ path, enc });
            util.err("BOM is prohibited in '{s}' if encoded as {s}", .{ path, enc });
            return false;
        } else if (isMissingRequiredUtfBom(enc, data)) {
            advice.advise(util.fmt("The file '{s}' is missing a byte order mark (BOM). Please use UTF-{s}BE or UTF-{s}LE (depending on the byte order) as working-tree-encoding.", .{ path, stripped, stripped }));
            if (die_on_error) util.die("BOM is required in '{s}' if encoded as {s}", .{ path, enc });
            util.err("BOM is required in '{s}' if encoded as {s}", .{ path, enc });
            return false;
        }
    }
    return true;
}

fn checkRoundtrip(enc: []const u8) bool {
    const list = repo_mod.cfg.get("core.checkroundtripencoding") orelse "SHIFT-JIS";
    var i: usize = 0;
    while (i + enc.len <= list.len) : (i += 1) {
        if (!std.ascii.eqlIgnoreCase(list[i .. i + enc.len], enc)) continue;
        const before_ok = i == 0 or std.ascii.isWhitespace(list[i - 1]) or list[i - 1] == ',';
        const n = i + enc.len;
        const after_ok = n == list.len or std.ascii.isWhitespace(list[n]) or list[n] == ',';
        return before_ok and after_ok;
    }
    return false;
}

fn encodeToGit(path: []const u8, data: ?[]const u8, enc0: ?[]const u8, flags: u32) ?[]const u8 {
    const enc = enc0 orelse return null;
    const src = data orelse return ""; // dry run
    if (src.len == 0) return null;
    const die_on_error = flags & CONV_WRITE_OBJECT != 0;
    if (!validateEncoding(path, enc, src, die_on_error)) return null;
    const dst = reencode(src, "UTF-8", enc) orelse {
        if (die_on_error) util.die("failed to encode '{s}' from {s} to {s}", .{ path, enc, "UTF-8" });
        util.err("failed to encode '{s}' from {s} to {s}", .{ path, enc, "UTF-8" });
        return null;
    };
    if (die_on_error and checkRoundtrip(enc)) {
        const re = reencode(dst, enc, "UTF-8");
        if (re == null or !util.eql(re.?, src))
            util.die("encoding '{s}' from {s} to {s} and back is not the same", .{ path, enc, "UTF-8" });
    }
    return dst;
}

fn encodeToWorktree(path: []const u8, src: []const u8, enc0: ?[]const u8) ?[]const u8 {
    const enc = enc0 orelse return null;
    if (src.len == 0) return null;
    return reencode(src, enc, "UTF-8") orelse {
        util.err("failed to encode '{s}' from {s} to {s}", .{ path, "UTF-8", enc });
        return null;
    };
}

// ---------------------------------------------------------------------------
// filters

fn expandFilterCmd(cmd: []const u8, path: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (i < cmd.len) : (i += 1) {
        if (cmd[i] == '%' and i + 1 < cmd.len) {
            if (cmd[i + 1] == '%') {
                util.bufByte(&b, '%');
                i += 1;
                continue;
            } else if (cmd[i + 1] == 'f') {
                util.sqQuote(&b, path);
                i += 1;
                continue;
            }
        }
        util.bufByte(&b, cmd[i]);
    }
    return b.items;
}

fn applySingleFileFilter(path: []const u8, src: []const u8, cmd: []const u8) ?[]const u8 {
    const full = expandFilterCmd(cmd, path);
    const r = os.run(&.{full}, .{ .use_shell = true, .stdin_data = src, .capture_stdout = true });
    if (r.status != 0) {
        util.err("external filter '{s}' failed {d}", .{ cmd, r.status });
        util.err("external filter '{s}' failed", .{cmd});
        return null;
    }
    return r.stdout;
}

const CAP_CLEAN: u32 = 1;
const CAP_SMUDGE: u32 = 2;
const CAP_DELAY: u32 = 4;

/// returns converted data, "" sentinel for dry-run 'would convert', or null if not applied.
fn applyFilter(path: []const u8, src: ?[]const u8, drv0: ?*Driver, cap: u32) ?[]const u8 {
    const drv = drv0 orelse return null;
    const s = src orelse return "";
    var cmd: ?[]const u8 = null;
    if (cap & CAP_CLEAN != 0 and drv.process == null and drv.clean != null) {
        cmd = drv.clean;
    } else if (cap & CAP_SMUDGE != 0 and drv.process == null and drv.smudge != null) cmd = drv.smudge;
    if (cmd) |c| {
        if (c.len > 0) return applySingleFileFilter(path, s, c);
    }
    if (drv.process) |p| {
        if (p.len > 0) return @import("convert_process.zig").apply(path, s, p, cap);
    }
    return null;
}

// ---------------------------------------------------------------------------
// attributes

fn checkCrlf(v: attr.Value) CrlfAction {
    return switch (v) {
        .set => .text,
        .unset => .binary,
        .unspecified => .undefined,
        .value => |s| if (util.eql(s, "input")) .text_input else if (util.eql(s, "auto")) .auto else .undefined,
    };
}

fn checkEol(v: attr.Value) Eol {
    return switch (v) {
        .value => |s| if (util.eql(s, "lf")) .lf else if (util.eql(s, "crlf")) .crlf else .unset,
        else => .unset,
    };
}

pub fn convertAttrs(path: []const u8) ConvAttrs {
    loadConfig();
    const vals = attr.check(path, &.{ "crlf", "ident", "filter", "eol", "text", "working-tree-encoding" });
    var ca = ConvAttrs{};
    ca.crlf_action = checkCrlf(vals[4]);
    if (ca.crlf_action == .undefined) ca.crlf_action = checkCrlf(vals[0]);
    ca.ident = vals[1] == .set;
    switch (vals[2]) {
        .value => |s| {
            for (drivers.items) |d| {
                if (util.eql(d.name, s)) ca.drv = d;
            }
        },
        else => {},
    }
    if (ca.crlf_action != .binary) {
        const e = checkEol(vals[3]);
        if (ca.crlf_action == .auto and e == .lf) {
            ca.crlf_action = .auto_input;
        } else if (ca.crlf_action == .auto and e == .crlf) {
            ca.crlf_action = .auto_crlf;
        } else if (e == .lf) {
            ca.crlf_action = .text_input;
        } else if (e == .crlf) ca.crlf_action = .text_crlf;
    }
    switch (vals[5]) {
        .value => |s| {
            if (s.len > 0 and !sameEncoding(s, "UTF-8")) ca.working_tree_encoding = s;
        },
        .set, .unset => util.die("true/false are no valid working-tree-encodings", .{}),
        .unspecified => {},
    }
    ca.attr_action = ca.crlf_action;
    if (ca.crlf_action == .text) ca.crlf_action = if (textEolIsCrlf()) .text_crlf else .text_input;
    if (ca.crlf_action == .undefined and auto_crlf == .false_) ca.crlf_action = .binary;
    if (ca.crlf_action == .undefined and auto_crlf == .true_) ca.crlf_action = .auto_crlf;
    if (ca.crlf_action == .undefined and auto_crlf == .input) ca.crlf_action = .auto_input;
    return ca;
}

pub fn getConvertAttrAscii(path: []const u8) []const u8 {
    const ca = convertAttrs(path);
    return switch (ca.attr_action) {
        .undefined => "",
        .binary => "-text",
        .text => "text",
        .text_input => "text eol=lf",
        .text_crlf => "text eol=crlf",
        .auto => "text=auto",
        .auto_crlf => "text=auto eol=crlf",
        .auto_input => "text=auto eol=lf",
    };
}

// ---------------------------------------------------------------------------
// conversions

/// convert_to_git(). Returns converted data (or the input if nothing changed).
pub fn toGitFlags(path: []const u8, data: []const u8, flags: u32) []const u8 {
    const ca = convertAttrs(path);
    var src = data;
    if (applyFilter(path, src, ca.drv, CAP_CLEAN)) |r| {
        src = r;
    } else if (ca.drv != null and ca.drv.?.required) {
        util.die("{s}: clean filter '{s}' failed", .{ path, ca.drv.?.name });
    }
    if (encodeToGit(path, src, ca.working_tree_encoding, flags)) |r| src = r;
    if (flags & CONV_EOL_KEEP_CRLF == 0) {
        if (crlfToGit(path, src, ca.crlf_action, flags)) |r| src = r;
    }
    if (identToGit(src, ca.ident)) |r| src = r;
    return src;
}

/// Convert worktree content to repository form (clean).
pub fn toGit(path: []const u8, data: []const u8) []const u8 {
    return toGitFlags(path, data, 0);
}

/// Like toGit, but performs safecrlf checks (may warn/die) when `write_object`.
pub fn toGitChecked(path: []const u8, data: []const u8, write_object: bool) []const u8 {
    const flags: u32 = if (write_object) globalConvFlags() | CONV_WRITE_OBJECT else 0;
    return toGitFlags(path, data, flags);
}

/// would_convert_to_git(): might the clean conversion change the content?
pub fn wouldConvertToGit(path: []const u8) bool {
    const ca = convertAttrs(path);
    if (ca.drv != null) return true;
    if (ca.working_tree_encoding != null) return true;
    if (ca.crlf_action != .binary) return true;
    if (ca.ident) return true;
    return false;
}

fn toWorktreeInternal(ca: *const ConvAttrs, path: []const u8, data: []const u8, normalizing: bool) []const u8 {
    var src = data;
    if (identToWorktree(src, ca.ident)) |r| src = r;
    if ((ca.drv != null and (ca.drv.?.smudge != null or ca.drv.?.process != null)) or !normalizing) {
        if (crlfToWorktree(src, ca.crlf_action)) |r| src = r;
    }
    if (encodeToWorktree(path, src, ca.working_tree_encoding)) |r| src = r;
    if (applyFilter(path, src, ca.drv, CAP_SMUDGE)) |r| {
        src = r;
    } else if (ca.drv != null and ca.drv.?.required) {
        util.die("{s}: smudge filter {s} failed", .{ path, ca.drv.?.name });
    }
    return src;
}

/// Convert repository content to worktree form (smudge).
pub fn toWorktree(path: []const u8, data: []const u8) []const u8 {
    const ca = convertAttrs(path);
    return toWorktreeInternal(&ca, path, data, false);
}

/// renormalize_buffer()
pub fn renormalize(path: []const u8, data: []const u8) []const u8 {
    const ca = convertAttrs(path);
    const s = toWorktreeInternal(&ca, path, data, true);
    return toGitFlags(path, s, CONV_EOL_RENORMALIZE);
}
