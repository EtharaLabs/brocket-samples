//! Port of remote.c tracking helpers: stat_branch_pair(), stat_tracking_info()
//! and format_tracking_info() (git v2.56.1).
//!
//! Branch upstream/push resolution reuses reffilter.zig's remote.c subset
//! (branchGet / branchGetUpstream / branchGetPush / pushremoteForBranch).
//!
//! Public API:
//!   AheadBehind                     enum ahead_behind_flags (.quick / .full)
//!   statBranchPair(refname, base, abf) Pair      stat_branch_pair
//!   statTrackingInfo(branch_name, for_push, abf) Info   stat_tracking_info
//!   formatTrackingInfo(branch_name, *Buf, abf, show_divergence_advice) bool
//!   branchGetUpstream(branch_name) ?[]const u8   full ref of @{upstream}
//!   branchGetPush(branch_name) ?[]const u8       full ref of @{push}
//! `branch_name` is the short branch name ("main", not "refs/heads/main").

const std = @import("std");
const util = @import("util.zig");
const refs = @import("refs.zig");
const repo_mod = @import("repo.zig");
const cn = @import("commitnode.zig");
const reach = @import("commitreach.zig");
const advice = @import("advice.zig");
const rf = @import("reffilter.zig");
const gpa = util.gpa;

pub const AheadBehind = enum { quick, full };

pub const Pair = struct {
    /// -1: cannot stat (ref missing), 0: identical, 1: different
    cmp: i32,
    ours: usize = 0,
    theirs: usize = 0,
};

/// stat_branch_pair(): compare `branch_refname` with `base` (full refnames).
pub fn statBranchPair(branch_refname: []const u8, base: []const u8, abf: AheadBehind) Pair {
    const toid = refs.readOid(base) orelse return .{ .cmp = -1 };
    const theirs = cn.lookupCommitReference(toid) orelse return .{ .cmp = -1 };
    const ooid = refs.readOid(branch_refname) orelse return .{ .cmp = -1 };
    const ours = cn.lookupCommitReference(ooid) orelse return .{ .cmp = -1 };
    if (theirs == ours) return .{ .cmp = 0 };
    if (abf == .quick) return .{ .cmp = 1 };
    const ab = reach.countAheadBehind(ours, theirs);
    return .{ .cmp = 1, .ours = ab.ahead, .theirs = ab.behind };
}

pub const Info = struct {
    cmp: i32,
    ours: usize = 0,
    theirs: usize = 0,
    /// full refname of the tracking branch, null if none is configured
    tracking_name: ?[]const u8 = null,
};

/// branch_get_upstream() for a short branch name.
pub fn branchGetUpstream(branch_name: []const u8) ?[]const u8 {
    return rf.branchGetUpstream(rf.branchGet(branch_name), null);
}

/// branch_get_push() for a short branch name.
pub fn branchGetPush(branch_name: []const u8) ?[]const u8 {
    return rf.branchGetPush(rf.branchGet(branch_name), null);
}

/// stat_tracking_info()
pub fn statTrackingInfo(branch_name: []const u8, for_push: bool, abf: AheadBehind) Info {
    const b = rf.branchGet(branch_name);
    const base = if (for_push) rf.branchGetPush(b, null) else rf.branchGetUpstream(b, null);
    const bs = base orelse return .{ .cmp = -1 };
    const p = statBranchPair(b.refname, bs, abf);
    return .{ .cmp = p.cmp, .ours = p.ours, .theirs = p.theirs, .tracking_name = bs };
}

fn resolveCompareBranch(b: *rf.Branch, name: []const u8) ?[]const u8 {
    if (std.ascii.eqlIgnoreCase(name, "@{upstream}")) return rf.branchGetUpstream(b, null);
    if (std.ascii.eqlIgnoreCase(name, "@{push}")) return rf.branchGetPush(b, null);
    util.warn("ignoring value '{s}' for status.compareBranches, only @{{upstream}} and @{{push}} are supported", .{name});
    return null;
}

const ADVICE_PUSH: u32 = 1;
const ADVICE_PULL: u32 = 2;
const ADVICE_DIVERGENCE: u32 = 4;

fn plural(n: usize, one: []const u8, many: []const u8) []const u8 {
    return if (n == 1) one else many;
}

fn formatBranchComparison(sb: *util.Buf, up_to_date: bool, ours: usize, theirs: usize, branch_name: []const u8, push_remote_name: ?[]const u8, push_branch_name: ?[]const u8, abf: AheadBehind, flags: u32) void {
    const hints = advice.enabled("statusHints");
    if (up_to_date) {
        util.bufPrint(sb, "Your branch is up to date with '{s}'.\n", .{branch_name});
    } else if (abf == .quick) {
        util.bufPrint(sb, "Your branch and '{s}' refer to different commits.\n", .{branch_name});
        if (flags & ADVICE_PUSH != 0 and hints)
            util.bufPrint(sb, "  (use \"{s}\" for details)\n", .{"git status --ahead-behind"});
    } else if (theirs == 0) {
        util.bufPrint(sb, "Your branch is ahead of '{s}' by {d} {s}.\n", .{ branch_name, ours, plural(ours, "commit", "commits") });
        if (flags & ADVICE_PUSH != 0 and hints)
            util.bufAppend(sb, "  (use \"git push\" to publish your local commits)\n");
    } else if (ours == 0) {
        util.bufPrint(sb, "Your branch is behind '{s}' by {d} {s}, and can be fast-forwarded.\n", .{ branch_name, theirs, plural(theirs, "commit", "commits") });
        if (flags & ADVICE_PULL != 0 and hints) {
            if (push_remote_name != null and push_branch_name != null) {
                util.bufPrint(sb, "  (use \"git pull {s} {s}\" to update your local branch)\n", .{ push_remote_name.?, push_branch_name.? });
            } else util.bufAppend(sb, "  (use \"git pull\" to update your local branch)\n");
        }
    } else {
        util.bufPrint(sb, "Your branch and '{s}' have diverged,\nand have {d} and {d} different {s} each, respectively.\n", .{ branch_name, ours, theirs, plural(ours + theirs, "commit", "commits") });
        if (flags & ADVICE_DIVERGENCE != 0 and hints) {
            if (push_remote_name != null and push_branch_name != null) {
                util.bufPrint(sb, "  (use \"git pull {s} {s}\" if you want to integrate the remote branch with yours)\n", .{ push_remote_name.?, push_branch_name.? });
            } else util.bufAppend(sb, "  (use \"git pull\" if you want to integrate the remote branch with yours)\n");
        }
    }
}

/// format_tracking_info(): append the "Your branch is ..." paragraph(s) for
/// the short branch name to `sb`. Returns true if anything was reported.
pub fn formatTrackingInfo(branch_name: []const u8, sb: *util.Buf, abf: AheadBehind, show_divergence_advice: bool) bool {
    const b = rf.branchGet(branch_name);
    var branches: std.ArrayList([]const u8) = .empty;
    if (repo_mod.cfg.get("status.comparebranches")) |cb| {
        var it = std.mem.splitScalar(u8, cb, ' ');
        while (it.next()) |w| {
            if (w.len > 0) branches.append(gpa, w) catch util.oom();
        }
    } else branches.append(gpa, "@{upstream}") catch util.oom();

    const upstream_ref = rf.branchGetUpstream(b, null);
    const push_ref = rf.branchGetPush(b, null);
    var processed: std.StringHashMapUnmanaged(void) = .empty;
    var reported = false;

    for (branches.items) |name| {
        const full_ref = resolveCompareBranch(b, name) orelse continue;
        const gop = processed.getOrPut(gpa, full_ref) catch util.oom();
        if (gop.found_existing) continue;
        const short_ref = refs.shortenUnambiguous(full_ref);
        const is_upstream = upstream_ref != null and util.eql(full_ref, upstream_ref.?);
        var is_push = push_ref != null and util.eql(full_ref, push_ref.?);
        if (is_upstream and (push_ref == null or util.eql(upstream_ref.?, push_ref.?))) is_push = true;

        const p = statBranchPair(b.refname, full_ref, abf);
        if (p.cmp < 0) {
            if (is_upstream) {
                util.bufPrint(sb, "Your branch is based on '{s}', but the upstream is gone.\n", .{short_ref});
                if (advice.enabled("statusHints"))
                    util.bufAppend(sb, "  (use \"git branch --unset-upstream\" to fixup)\n");
                reported = true;
            }
            continue;
        }
        if (reported) util.bufAppend(sb, "\n");

        var flags: u32 = 0;
        var push_remote_name: ?[]const u8 = null;
        var push_branch_name: ?[]const u8 = null;
        if (is_upstream) flags |= ADVICE_PULL;
        if (show_divergence_advice and is_upstream) flags |= ADVICE_DIVERGENCE;
        if (is_push) {
            flags |= ADVICE_PUSH;
            if (upstream_ref == null or !util.eql(upstream_ref.?, full_ref)) {
                var explicit = false;
                const prn = rf.pushremoteForBranch(b, &explicit);
                if (util.skipPrefix(full_ref, "refs/remotes/")) |r1| {
                    if (util.skipPrefix(r1, prn)) |r2| {
                        if (r2.len > 0 and r2[0] == '/') {
                            push_remote_name = prn;
                            push_branch_name = r2[1..];
                            flags |= ADVICE_PULL;
                        }
                    }
                }
            } else flags |= ADVICE_PULL;
        }
        formatBranchComparison(sb, p.cmp == 0, p.ours, p.theirs, short_ref, push_remote_name, push_branch_name, abf, flags);
        reported = true;
    }
    return reported;
}

