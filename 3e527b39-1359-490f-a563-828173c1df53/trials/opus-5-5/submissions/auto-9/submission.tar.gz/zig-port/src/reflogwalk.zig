//! Reflog walking (port of reflog-walk.c).

const std = @import("std");
const util = @import("util.zig");
const cn = @import("commitnode.zig");
const date = @import("date.zig");
const refs = @import("refs.zig");
const hash = @import("hash.zig");
const gpa = util.gpa;

pub const Entry = struct {
    ooid: hash.Oid,
    noid: hash.Oid,
    /// "Name <email>"
    email: []const u8,
    timestamp: u64,
    tz: i32,
    /// message including trailing newline (as in C)
    message: []const u8,
};

pub const CompleteReflogs = struct {
    ref: []const u8,
    short_ref: ?[]const u8 = null,
    items: []Entry = &.{},
};

const Selector = enum { none, index, date };

pub const CommitReflog = struct {
    recno: i64,
    selector: Selector,
    reflogs: *CompleteReflogs,
};

pub const Info = struct {
    logs: std.ArrayList(*CommitReflog) = .empty,
    complete: std.StringHashMap(*CompleteReflogs) = std.StringHashMap(*CompleteReflogs).init(util.gpa),
    last: ?*CommitReflog = null,
};

pub fn init() *Info {
    const i = gpa.create(Info) catch util.oom();
    i.* = .{};
    return i;
}

fn parseIdent(id: []const u8) struct { email: []const u8, ts: u64, tz: i32 } {
    const gt = std.mem.lastIndexOfScalar(u8, id, '>') orelse return .{ .email = id, .ts = 0, .tz = 0 };
    const email = id[0 .. gt + 1];
    var rest = std.mem.trim(u8, id[gt + 1 ..], " ");
    var ts: u64 = 0;
    var tz: i32 = 0;
    const sp = std.mem.indexOfScalar(u8, rest, ' ') orelse rest.len;
    ts = cn.parseTimestamp(rest[0..sp]);
    rest = std.mem.trim(u8, rest[sp..], " ");
    if (rest.len > 0) tz = std.fmt.parseInt(i32, rest, 10) catch 0;
    return .{ .email = email, .ts = ts, .tz = tz };
}

fn readEntries(ref: []const u8) []Entry {
    const raw = refs.readReflog(ref);
    var out: std.ArrayList(Entry) = .empty;
    for (raw) |e| {
        const p = parseIdent(e.ident);
        out.append(gpa, .{
            .ooid = e.old,
            .noid = e.new,
            .email = p.email,
            .timestamp = p.ts,
            .tz = p.tz,
            .message = util.concat(&.{ e.msg, "\n" }),
        }) catch util.oom();
    }
    return out.items;
}

fn readCompleteReflog(ref: []const u8) *CompleteReflogs {
    const r = gpa.create(CompleteReflogs) catch util.oom();
    r.* = .{ .ref = util.dupe(ref) };
    r.items = readEntries(ref);
    if (r.items.len == 0) {
        if (refs.resolve(ref)) |_| {
            const name = refs.resolveTarget(ref);
            if (!util.eql(name, ref)) r.items = readEntries(name);
        }
    }
    if (r.items.len == 0) {
        r.items = readEntries(util.concat(&.{ "refs/", ref }));
        if (r.items.len == 0) r.items = readEntries(util.concat(&.{ "refs/heads/", ref }));
    }
    return r;
}

fn dwimLog(name: []const u8) struct { count: usize, first: []const u8 } {
    const rules = [_][]const u8{ "{s}", "refs/{s}", "refs/tags/{s}", "refs/heads/{s}", "refs/remotes/{s}", "refs/remotes/{s}/HEAD" };
    var count: usize = 0;
    var first: []const u8 = "";
    inline for (rules) |rule| {
        const full = util.fmt(rule, .{name});
        if (refs.reflogExists(full)) {
            if (count == 0) first = full;
            count += 1;
        }
    }
    return .{ .count = count, .first = first };
}

/// add_reflog_for_walk; returns false on failure.
pub fn addReflogForWalk(info: *Info, commit: *cn.Commit, name: []const u8) bool {
    if (commit.obj.flags & cn.UNINTERESTING != 0)
        util.die("cannot walk reflogs for {s}", .{name});
    var timestamp: u64 = 0;
    var recno: i64 = -1;
    var selector: Selector = .none;
    var branch: []const u8 = name;
    if (std.mem.indexOfScalar(u8, name, '@')) |at| {
        if (at + 1 < name.len and name[at + 1] == '{') {
            branch = name[0..at];
            const rest = name[at + 2 ..];
            var j: usize = 0;
            while (j < rest.len and std.ascii.isDigit(rest[j])) j += 1;
            if (j < rest.len and rest[j] == '}') {
                recno = std.fmt.parseInt(i64, rest[0..j], 10) catch 0;
                selector = .index;
            } else {
                recno = -1;
                timestamp = @bitCast(date.approxidate(rest));
                selector = .date;
            }
        } else recno = 0;
    } else recno = 0;

    var reflogs: *CompleteReflogs = undefined;
    if (info.complete.get(branch)) |r| {
        reflogs = r;
    } else {
        if (branch.len == 0) {
            const res = refs.resolveFull("HEAD", false);
            if (res.broken) util.die("no current branch", .{});
            branch = refs.resolveTarget("HEAD");
        }
        reflogs = readCompleteReflog(branch);
        if (reflogs.items.len == 0) {
            const d = dwimLog(branch);
            if (d.count == 1) {
                branch = d.first;
                reflogs = readCompleteReflog(branch);
            }
        }
        if (reflogs.items.len == 0) return false;
        info.complete.put(util.dupe(branch), reflogs) catch util.oom();
    }
    const cr = gpa.create(CommitReflog) catch util.oom();
    if (recno < 0) {
        var i: i64 = @as(i64, @intCast(reflogs.items.len)) - 1;
        while (i >= 0) : (i -= 1) {
            if (timestamp >= reflogs.items[@intCast(i)].timestamp) break;
        }
        if (i < 0) return false;
        cr.recno = i;
    } else cr.recno = @as(i64, @intCast(reflogs.items.len)) - recno - 1;
    cr.selector = selector;
    cr.reflogs = reflogs;
    info.logs.append(gpa, cr) catch util.oom();
    return true;
}

fn cur(info: *Info) ?*Entry {
    const l = info.last orelse return null;
    const idx = l.recno + 1;
    if (idx < 0 or idx >= l.reflogs.items.len) return null;
    return &l.reflogs.items[@intCast(idx)];
}

/// get_reflog_selector: append "refs/heads/x@{N}" (or @{date}) to b.
pub fn getReflogSelector(b: *util.Buf, info: *Info, dmode: date.DateMode, force_date: bool, shorten: bool) void {
    const l = info.last orelse return;
    var printed: []const u8 = undefined;
    if (shorten) {
        if (l.reflogs.short_ref == null) l.reflogs.short_ref = refs.shortenUnambiguous(l.reflogs.ref);
        printed = l.reflogs.short_ref.?;
    } else printed = l.reflogs.ref;
    util.bufAppend(b, printed);
    util.bufAppend(b, "@{");
    if (l.selector == .date or (l.selector == .none and force_date)) {
        const e = cur(info) orelse return;
        util.bufAppend(b, date.showDate(@intCast(e.timestamp), e.tz, dmode));
    } else {
        util.bufPrint(b, "{d}", .{@as(i64, @intCast(l.reflogs.items.len)) - 2 - l.recno});
    }
    util.bufByte(b, '}');
}

/// get_reflog_message: the reflog message (without trailing newline).
pub fn getReflogMessage(b: *util.Buf, info: *Info) void {
    const e = cur(info) orelse return;
    var m = e.message;
    if (m.len > 0) m = m[0 .. m.len - 1];
    util.bufAppend(b, m);
}

/// get_reflog_ident: "Name <email>" of the current reflog entry, or null.
pub fn getReflogIdent(info: *Info) ?[]const u8 {
    const e = cur(info) orelse return null;
    return e.email;
}

pub fn getReflogTimestamp(info: *Info) u64 {
    const e = cur(info) orelse return 0;
    return e.timestamp;
}

/// show_reflog_message
pub fn showReflogMessage(info: ?*Info, oneline: bool, dmode: date.DateMode, force_date: bool) void {
    const i = info orelse return;
    if (i.last == null) return;
    const e = cur(i) orelse return;
    var sel: util.Buf = .empty;
    getReflogSelector(&sel, i, dmode, force_date, false);
    if (oneline) {
        util.outf("{s}: {s}", .{ sel.items, e.message });
    } else {
        util.outf("Reflog: {s} ({s})\nReflog message: {s}", .{ sel.items, e.email, e.message });
    }
}

pub fn walkEmpty(info: ?*Info) bool {
    const i = info orelse return true;
    return i.logs.items.len == 0;
}

fn nextReflogCommit(log: *CommitReflog) ?*cn.Commit {
    while (log.recno >= 0) : (log.recno -= 1) {
        const e = &log.reflogs.items[@intCast(log.recno)];
        if (cn.parseObject(e.noid)) |o| {
            if (o.typ == .commit) return cn.Commit.fromObj(o);
        }
    }
    return null;
}

fn logTimestamp(log: *CommitReflog) u64 {
    return log.reflogs.items[@intCast(log.recno)].timestamp;
}

/// next_reflog_entry
pub fn nextReflogEntry(walk: *Info) ?*cn.Commit {
    var best: ?*CommitReflog = null;
    var best_commit: ?*cn.Commit = null;
    for (walk.logs.items) |log| {
        const c = nextReflogCommit(log) orelse continue;
        if (best == null or logTimestamp(log) > logTimestamp(best.?)) {
            best = log;
            best_commit = c;
        }
    }
    if (best) |b| {
        b.recno -= 1;
        walk.last = b;
        return best_commit;
    }
    return null;
}
