//! git merge-base (port of builtin/merge-base.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const cn = @import("../commitnode.zig");
const reach = @import("../commitreach.zig");
const objects = @import("../objects.zig");
const Commit = cn.Commit;
const CommitList = cn.CommitList;
const gpa = util.gpa;

const usage = [_][]const u8{
    "git merge-base [-a | --all] <commit> <commit>...",
    "git merge-base [-a | --all] --octopus <commit>...",
    "git merge-base --is-ancestor <commit> <commit>",
    "git merge-base --independent <commit>...",
    "git merge-base --fork-point <ref> [<commit>]",
};

/// lookup_commit_reference() with git's error message for non-commits.
pub fn lookupCommitReferenceLoud(oid: hash.Oid) ?*Commit {
    const p = objects.peel(oid) orelse return null;
    if (p.typ != .commit) {
        util.err("object {s} is a {s}, not a commit", .{ hash.hex(oid), p.typ.name() });
        return null;
    }
    const c = cn.lookupCommit(p.oid) orelse return null;
    if (!cn.parse(c)) {
        util.err("Could not read {s}", .{hash.hex(c.obj.oid)});
        return null;
    }
    return c;
}

fn getCommitReference(arg: []const u8) *Commit {
    const oid = revparse.getOid(arg) orelse util.die("Not a valid object name {s}", .{arg});
    return lookupCommitReferenceLoud(oid) orelse util.die("Not a valid commit name {s}", .{arg});
}

var cmdmode: u8 = 0;
var cmdmode_name: []const u8 = "";
var show_all: bool = false;
var opts_ref: []const po.Opt = &.{};

fn setMode(mode: u8, name: []const u8) void {
    if (cmdmode != 0 and cmdmode != mode) {
        util.err("options '--{s}' and '--{s}' cannot be used together", .{ name, cmdmode_name });
        po.usageExit(&usage, opts_ref, true);
    }
    cmdmode = mode;
    cmdmode_name = name;
}

fn cbOctopus(_: ?[]const u8, unset: bool) void {
    if (unset) cmdmode = 0 else setMode('o', "octopus");
}
fn cbIndependent(_: ?[]const u8, unset: bool) void {
    if (unset) cmdmode = 0 else setMode('r', "independent");
}
fn cbIsAncestor(_: ?[]const u8, unset: bool) void {
    if (unset) cmdmode = 0 else setMode('a', "is-ancestor");
}
fn cbForkPoint(_: ?[]const u8, unset: bool) void {
    if (unset) cmdmode = 0 else setMode('f', "fork-point");
}

fn cmdmodeOpt(long: []const u8, cb: po.Callback, help: []const u8) po.Opt {
    var o = po.callbackNoArg(0, long, cb, help);
    o.noneg = true;
    return o;
}

fn printHex(c: *Commit) void {
    util.outf("{s}\n", .{hash.hex(c.obj.oid)});
}

fn showMergeBase(revs: []*Commit) u8 {
    const result = reach.getMergeBasesManyDirtyChecked(revs[0], revs[1..], .{ .find_all = show_all }) catch return 255;
    const r = result orelse return 1;
    var l: ?*CommitList = r;
    while (l) |x| : (l = x.next) {
        printHex(x.item);
        if (!show_all) break;
    }
    return 0;
}

fn handleIndependent(args: []const []const u8) u8 {
    var revs: ?*CommitList = null;
    var i = args.len;
    while (i > 0) {
        i -= 1;
        _ = cn.listInsert(getCommitReference(args[i]), &revs);
    }
    const res = reach.reduceHeads(revs) orelse return 1;
    var l: ?*CommitList = res;
    while (l) |x| : (l = x.next) printHex(x.item);
    return 0;
}

fn handleOctopus(args: []const []const u8) u8 {
    var revs: ?*CommitList = null;
    var i = args.len;
    while (i > 0) {
        i -= 1;
        _ = cn.listInsert(getCommitReference(args[i]), &revs);
    }
    const result = reach.getOctopusMergeBasesChecked(revs) catch return 128;
    const red = reach.reduceHeads(result) orelse return 1;
    var l: ?*CommitList = red;
    while (l) |x| : (l = x.next) {
        printHex(x.item);
        if (!show_all) break;
    }
    return 0;
}

fn handleIsAncestor(args: []const []const u8) u8 {
    if (args.len != 2) util.die("--is-ancestor takes exactly two commits", .{});
    const one = getCommitReference(args[0]);
    const two = getCommitReference(args[1]);
    const ret = reach.inMergeBasesChecked(one, two) catch os.exit(128);
    return if (ret) 0 else 1;
}

fn handleForkPoint(args: []const []const u8) u8 {
    const commitname = if (args.len == 2) args[1] else "HEAD";
    const oid = revparse.getOid(commitname) orelse util.die("Not a valid object name: '{s}'", .{commitname});
    const derived = lookupCommitReferenceLoud(oid);
    const fp = reach.forkPoint(args[0], derived) orelse return 1;
    printHex(fp);
    return 0;
}

pub fn cmdMergeBase(args: []const []const u8) u8 {
    const opts = [_]po.Opt{
        po.boolean('a', "all", &show_all, "output all common ancestors"),
        cmdmodeOpt("octopus", cbOctopus, "find ancestors for a single n-way merge"),
        cmdmodeOpt("independent", cbIndependent, "list revs not reachable from others"),
        cmdmodeOpt("is-ancestor", cbIsAncestor, "is the first one ancestor of the other?"),
        cmdmodeOpt("fork-point", cbForkPoint, "find where <commit> forked from reflog of <ref>"),
    };
    opts_ref = &opts;
    const rest = po.parse(args[1..], &opts, &usage, .{});

    if (cmdmode == 'a') {
        if (rest.len < 2) po.usageWithOptions(&usage, &opts);
        if (show_all) util.die("options '{s}' and '{s}' cannot be used together", .{ "--is-ancestor", "--all" });
        return handleIsAncestor(rest);
    }
    if (cmdmode == 'r' and show_all)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--independent", "--all" });
    if (cmdmode == 'o') return handleOctopus(rest);
    if (cmdmode == 'r') return handleIndependent(rest);
    if (cmdmode == 'f') {
        if (rest.len < 1 or rest.len > 2) po.usageWithOptions(&usage, &opts);
        return handleForkPoint(rest);
    }
    if (rest.len < 2) po.usageWithOptions(&usage, &opts);
    var revs: std.ArrayList(*Commit) = .empty;
    for (rest) |a| revs.append(gpa, getCommitReference(a)) catch util.oom();
    return showMergeBase(revs.items);
}
