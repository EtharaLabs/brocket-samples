//! Trailer processing (the "apply new trailers" half of trailer.c):
//! process_trailers, amend_file_with_trailers. Parsing lives in pretty_trailer.zig.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const pt = @import("pretty_trailer.zig");
const gpa = util.gpa;

pub const Where = enum { default, end, after, start, before };
pub const IfExists = enum { default, add_if_different, add_if_different_neighbor, add, replace, do_nothing };
pub const IfMissing = enum { default, do_nothing, add };

pub const NewTrailer = struct {
    text: []const u8,
    where: Where = .default,
    if_exists: IfExists = .default,
    if_missing: IfMissing = .default,
};

const Conf = struct {
    name: []const u8 = "",
    key: ?[]const u8 = null,
    command: ?[]const u8 = null,
    cmd: ?[]const u8 = null,
    where: Where = .end,
    if_exists: IfExists = .add_if_different_neighbor,
    if_missing: IfMissing = .add,
};

const ArgItem = struct {
    token: []const u8,
    value: []const u8,
    conf: Conf,
};

pub fn setWhere(v: ?[]const u8) ?Where {
    const s = v orelse return .default;
    if (std.ascii.eqlIgnoreCase(s, "after")) return .after;
    if (std.ascii.eqlIgnoreCase(s, "before")) return .before;
    if (std.ascii.eqlIgnoreCase(s, "end")) return .end;
    if (std.ascii.eqlIgnoreCase(s, "start")) return .start;
    return null;
}

pub fn setIfExists(v: ?[]const u8) ?IfExists {
    const s = v orelse return .default;
    if (std.ascii.eqlIgnoreCase(s, "addIfDifferent")) return .add_if_different;
    if (std.ascii.eqlIgnoreCase(s, "addIfDifferentNeighbor")) return .add_if_different_neighbor;
    if (std.ascii.eqlIgnoreCase(s, "add")) return .add;
    if (std.ascii.eqlIgnoreCase(s, "replace")) return .replace;
    if (std.ascii.eqlIgnoreCase(s, "doNothing")) return .do_nothing;
    return null;
}

pub fn setIfMissing(v: ?[]const u8) ?IfMissing {
    const s = v orelse return .default;
    if (std.ascii.eqlIgnoreCase(s, "doNothing")) return .do_nothing;
    if (std.ascii.eqlIgnoreCase(s, "add")) return .add;
    return null;
}

var default_conf: Conf = .{};
var confs: std.ArrayList(Conf) = .empty;
var configured = false;

fn getConf(name: []const u8) *Conf {
    for (confs.items) |*c| {
        if (std.ascii.eqlIgnoreCase(c.name, name)) return c;
    }
    var c = default_conf;
    c.name = name;
    confs.append(gpa, c) catch util.oom();
    return &confs.items[confs.items.len - 1];
}

fn configInit() void {
    if (configured) return;
    configured = true;
    pt.configInit();
    const entries = repo_mod.cfg.entries.items;
    for (entries) |e| {
        const item = util.skipPrefix(e.key, "trailer.") orelse continue;
        if (std.mem.lastIndexOfScalar(u8, item, '.') != null) continue;
        if (util.eql(item, "where")) {
            if (setWhere(e.value)) |w| default_conf.where = w else util.warn("unknown value '{s}' for key '{s}'", .{ e.value orelse "", e.key });
        } else if (util.eql(item, "ifexists")) {
            if (setIfExists(e.value)) |w| default_conf.if_exists = w else util.warn("unknown value '{s}' for key '{s}'", .{ e.value orelse "", e.key });
        } else if (util.eql(item, "ifmissing")) {
            if (setIfMissing(e.value)) |w| default_conf.if_missing = w else util.warn("unknown value '{s}' for key '{s}'", .{ e.value orelse "", e.key });
        }
    }
    for (entries) |e| {
        const item = util.skipPrefix(e.key, "trailer.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, item, '.') orelse continue;
        const variable = item[dot + 1 ..];
        const known = [_][]const u8{ "key", "command", "cmd", "where", "ifexists", "ifmissing" };
        var found = false;
        for (known) |k| {
            if (util.eql(k, variable)) found = true;
        }
        if (!found) continue;
        const c = getConf(item[0..dot]);
        if (util.eql(variable, "key")) {
            if (c.key != null) util.warn("more than one {s}", .{e.key});
            c.key = e.value orelse continue;
        } else if (util.eql(variable, "command")) {
            if (c.command != null) util.warn("more than one {s}", .{e.key});
            c.command = e.value orelse continue;
        } else if (util.eql(variable, "cmd")) {
            if (c.cmd != null) util.warn("more than one {s}", .{e.key});
            c.cmd = e.value orelse continue;
        } else if (util.eql(variable, "where")) {
            if (setWhere(e.value)) |w| c.where = w else util.warn("unknown value '{s}' for key '{s}'", .{ e.value orelse "", e.key });
        } else if (util.eql(variable, "ifexists")) {
            if (setIfExists(e.value)) |w| c.if_exists = w else util.warn("unknown value '{s}' for key '{s}'", .{ e.value orelse "", e.key });
        } else if (util.eql(variable, "ifmissing")) {
            if (setIfMissing(e.value)) |w| c.if_missing = w else util.warn("unknown value '{s}' for key '{s}'", .{ e.value orelse "", e.key });
        }
    }
}

fn tokenLenWithoutSeparator(t: []const u8) usize {
    var n = t.len;
    while (n > 0 and !std.ascii.isAlphanumeric(t[n - 1])) n -= 1;
    return n;
}

fn strncaseEq(a: []const u8, b: []const u8, n: usize) bool {
    var i: usize = 0;
    while (i < n) : (i += 1) {
        const ca = if (i < a.len) std.ascii.toLower(a[i]) else 0;
        const cb = if (i < b.len) std.ascii.toLower(b[i]) else 0;
        if (ca != cb) return false;
        if (ca == 0) return true;
    }
    return true;
}

fn sameToken(a: pt.Item, b: *const ArgItem) bool {
    const at = a.token orelse return false;
    const al = tokenLenWithoutSeparator(at);
    const bl = tokenLenWithoutSeparator(b.token);
    return strncaseEq(at, b.token, @min(al, bl));
}

fn sameTrailer(a: pt.Item, b: *const ArgItem) bool {
    return sameToken(a, b) and std.ascii.eqlIgnoreCase(a.value, b.value);
}

fn afterOrEnd(w: Where) bool {
    return w == .after or w == .end;
}

fn applyCommand(conf: *const Conf, arg: []const u8) []const u8 {
    var cmdline: []const u8 = undefined;
    var argv: std.ArrayList([]const u8) = .empty;
    if (conf.cmd) |c| {
        cmdline = c;
        argv.append(gpa, c) catch util.oom();
        argv.append(gpa, arg) catch util.oom();
    } else {
        cmdline = conf.command.?;
        if (std.mem.indexOf(u8, cmdline, "$ARG")) |p| cmdline = util.concat(&.{ cmdline[0..p], arg, cmdline[p + 4 ..] });
        argv.append(gpa, cmdline) catch util.oom();
    }
    const res = os.run(argv.items, .{ .use_shell = true, .no_stdin = true, .capture_stdout = true, .unset_env = &.{ "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_PREFIX", "GIT_OBJECT_DIRECTORY", "GIT_COMMON_DIR" } });
    if (res.status != 0 or res.signaled) {
        util.err("running trailer command '{s}' failed", .{cmdline});
        return "";
    }
    return std.mem.trim(u8, res.stdout, " \t\r\n");
}

fn applyItemCommand(in_tok: ?pt.Item, arg: *ArgItem) void {
    if (arg.conf.command == null and arg.conf.cmd == null) return;
    const a = if (arg.value.len > 0) arg.value else if (in_tok) |t| t.value else "";
    arg.value = applyCommand(&arg.conf, a);
}

fn addArgToInputList(head: *std.ArrayList(pt.Item), on_tok: usize, arg: *const ArgItem) usize {
    const item = pt.Item{ .token = arg.token, .value = arg.value };
    const at = if (afterOrEnd(arg.conf.where)) on_tok + 1 else on_tok;
    head.insert(gpa, at, item) catch util.oom();
    return at;
}

fn checkIfDifferent(head: []const pt.Item, in_tok0: usize, arg: *const ArgItem, check_all: bool) bool {
    var in_tok = in_tok0;
    while (true) {
        if (sameTrailer(head[in_tok], arg)) return false;
        if (afterOrEnd(arg.conf.where)) {
            if (in_tok == 0) break;
            in_tok -= 1;
        } else {
            if (in_tok + 1 >= head.len) break;
            in_tok += 1;
        }
        if (!check_all) break;
    }
    return true;
}

fn findSameAndApply(head: *std.ArrayList(pt.Item), arg: *ArgItem) bool {
    if (head.items.len == 0) return false;
    const where = arg.conf.where;
    const middle = where == .after or where == .before;
    const backwards = afterOrEnd(where);
    const n = head.items.len;
    const start_tok: usize = if (backwards) n - 1 else 0;
    var k: usize = 0;
    while (k < n) : (k += 1) {
        const in_tok = if (backwards) n - 1 - k else k;
        if (!sameToken(head.items[in_tok], arg)) continue;
        const on_tok = if (middle) in_tok else start_tok;
        switch (arg.conf.if_exists) {
            .do_nothing => {},
            .replace => {
                applyItemCommand(head.items[in_tok], arg);
                const ins = addArgToInputList(head, on_tok, arg);
                _ = head.orderedRemove(if (ins <= in_tok) in_tok + 1 else in_tok);
            },
            .add, .default => {
                applyItemCommand(head.items[in_tok], arg);
                _ = addArgToInputList(head, on_tok, arg);
            },
            .add_if_different => {
                applyItemCommand(head.items[in_tok], arg);
                if (checkIfDifferent(head.items, in_tok, arg, true)) _ = addArgToInputList(head, on_tok, arg);
            },
            .add_if_different_neighbor => {
                applyItemCommand(head.items[in_tok], arg);
                if (checkIfDifferent(head.items, on_tok, arg, false)) _ = addArgToInputList(head, on_tok, arg);
            },
        }
        return true;
    }
    return false;
}

fn applyIfMissing(head: *std.ArrayList(pt.Item), arg: *ArgItem) void {
    switch (arg.conf.if_missing) {
        .do_nothing => {},
        .add, .default => {
            applyItemCommand(null, arg);
            const item = pt.Item{ .token = arg.token, .value = arg.value };
            if (afterOrEnd(arg.conf.where)) head.append(gpa, item) catch util.oom() else head.insert(gpa, 0, item) catch util.oom();
        },
    }
}

fn tokenFromConf(c: *const Conf, tok: ?[]const u8) []const u8 {
    if (c.key) |k| return k;
    if (tok) |t| return t;
    return c.name;
}

fn parseArg(text: []const u8, seps: []const u8) ?ArgItem {
    const sp = pt.findSeparator(text, seps);
    if (sp != null and sp.? == 0) {
        util.err("empty trailer token in trailer '{s}'", .{std.mem.trim(u8, text, " \t\r\n")});
        return null;
    }
    var tok: []const u8 = undefined;
    var val: []const u8 = "";
    if (sp) |p| {
        tok = std.mem.trim(u8, text[0..p], " \t\r\n");
        val = std.mem.trim(u8, text[p + 1 ..], " \t\r\n");
    } else tok = std.mem.trim(u8, text, " \t\r\n");
    const tl = tokenLenWithoutSeparator(tok);
    var conf = default_conf;
    for (confs.items) |*c| {
        if (strncaseEq(tok, c.name, tl) or (c.key != null and strncaseEq(tok, c.key.?, tl))) {
            conf = c.*;
            tok = tokenFromConf(c, tok);
            break;
        }
    }
    return .{ .token = tok, .value = val, .conf = conf };
}

pub fn process(opts: *const pt.Options, new_trailers: []const NewTrailer, input: []const u8, out: *util.Buf) void {
    configInit();
    var head: std.ArrayList(pt.Item) = .empty;
    const block = pt.parseTrailers(opts, input, &head);
    if (!opts.only_trailers) util.bufAppend(out, input[0..block.start]);
    if (!opts.only_trailers and !block.blank_line_before_trailer) util.bufByte(out, '\n');

    if (!opts.only_input) {
        var args: std.ArrayList(ArgItem) = .empty;
        for (confs.items) |*c| {
            if (c.command != null) args.append(gpa, .{ .token = tokenFromConf(c, null), .value = "", .conf = c.* }) catch util.oom();
        }
        const cl_seps = util.concat(&.{ "=", pt.separators });
        for (new_trailers) |nt| {
            var a = parseArg(nt.text, cl_seps) orelse continue;
            if (nt.where != .default) a.conf.where = nt.where;
            if (nt.if_exists != .default) a.conf.if_exists = nt.if_exists;
            if (nt.if_missing != .default) a.conf.if_missing = nt.if_missing;
            args.append(gpa, a) catch util.oom();
        }
        for (args.items) |*a| {
            if (!findSameAndApply(&head, a)) applyIfMissing(&head, a);
        }
    }

    pt.formatTrailers(opts, head.items, out);
    if (!opts.only_trailers) util.bufAppend(out, input[block.end..]);
}

/// validate_trailer_args; returns true on error.
pub fn validateArgs(args: []const []const u8) bool {
    configInit();
    const cl_seps = util.concat(&.{ "=", pt.separators });
    for (args) |t| {
        if (t.len == 0) {
            util.err("empty --trailer argument", .{});
            return true;
        }
        if (pt.findSeparator(t, cl_seps)) |p| {
            if (p == 0) {
                util.err("invalid trailer '{s}': missing key before separator", .{t});
                return true;
            }
        }
    }
    return false;
}

/// amend_file_with_trailers; returns true on error.
pub fn amendFile(path: []const u8, args: []const []const u8) bool {
    if (args.len == 0) return false;
    if (validateArgs(args)) return true;
    const data = os.readFile(path) orelse {
        util.err("could not read '{s}': {s}", .{ path, os.lastErr() });
        return true;
    };
    var nts: std.ArrayList(NewTrailer) = .empty;
    for (args) |a| nts.append(gpa, .{ .text = a }) catch util.oom();
    var out: util.Buf = .empty;
    const opts = pt.Options{ .no_divider = true };
    process(&opts, nts.items, data, &out);
    os.writeFile(path, out.items, 0o666) catch {
        util.err("could not write to temporary file", .{});
        return true;
    };
    return false;
}
