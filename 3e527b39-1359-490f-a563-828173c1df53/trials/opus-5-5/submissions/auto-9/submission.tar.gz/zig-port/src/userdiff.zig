//! userdiff drivers (port of userdiff.c): builtin funcname/word-regex patterns,
//! diff.<driver>.* configuration and lookup by the "diff" attribute.

const std = @import("std");
const util = @import("util.zig");
const attr = @import("attr.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");

pub const Driver = struct {
    name: []const u8,
    /// -1 auto, 0 text, 1 binary
    binary: i8 = -1,
    funcname: ?[]const u8 = null,
    funcname_extended: bool = false,
    funcname_icase: bool = false,
    word_regex: ?[]const u8 = null,
    textconv: ?[]const u8 = null,
    textconv_want_cache: bool = false,
    external_cmd: ?[]const u8 = null,
    trust_exit_code: bool = false,
    algorithm: ?[]const u8 = null,
};

fn pp(comptime name: []const u8, comptime rx: []const u8, comptime wrx: []const u8) Driver {
    return .{ .name = name, .funcname = rx, .funcname_extended = true, .word_regex = wrx ++ "|[^[:space:]]|[\xc0-\xff][\x80-\xbf]+" };
}
fn ip(comptime name: []const u8, comptime rx: []const u8, comptime wrx: []const u8) Driver {
    return .{ .name = name, .funcname = rx, .funcname_extended = true, .funcname_icase = true, .word_regex = wrx ++ "|[^[:space:]]|[\xc0-\xff][\x80-\xbf]+" };
}

var builtin_drivers = [_]Driver{
ip("ada",
     "!^(.*[ \t])?(is[ \t]+new|renames|is[ \t]+separate)([ \t].*)?$\n" ++ "!^[ \t]*with[ \t].*$\n" ++ "^[ \t]*((procedure|function)[ \t]+.*)$\n" ++ "^[ \t]*((package|protected|task)[ \t]+.*)$",
     "[a-zA-Z][a-zA-Z0-9_]*" ++ "|[-+]?[0-9][0-9#_.aAbBcCdDeEfF]*([eE][+-]?[0-9_]+)?" ++ "|=>|\\.\\.|\\*\\*|:=|/=|>=|<=|<<|>>|<>"),
pp("bash",
     "^[ \t]*" ++ "(" ++ "(" ++ "([a-zA-Z_][a-zA-Z0-9_]*[ \t]*\\([ \t]*\\))" ++ "|" ++ "(function[ \t]+[a-zA-Z_][a-zA-Z0-9_]*(([ \t]*\\([ \t]*\\))|([ \t]+)))" ++ ")" ++ ".*$" ++ ")",
      "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|\\$[a-zA-Z0-9_]+|\\$\\{" ++ "|\\|\\||&&|<<|>>" ++ "|==|!=|<=|>=|[-+*/%&|^]=" ++ "|:=|:-|:\\+|:\\?|##|%%|\\^\\^|,," ++ "|[-a-zA-Z0-9_]+" ++ "|\\(|\\)|\\{|\\}|\\[|\\]"),
pp("bibtex",
     "(@[a-zA-Z]{1,}[ \t]*\\{{0,1}[ \t]*[^ \t\"@',\\#}{~%]*).*$",
     "[={}\"]|[^={}\" \t]+"),
pp("cpp",
     "!^[ \t]*[A-Za-z_][A-Za-z_0-9]*:[[:space:]]*($|/[/*])\n" ++ "^((::[[:space:]]*)?[A-Za-z_].*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[0-9][0-9.]*([Ee][-+]?[0-9]+)?[fFlLuU]*" ++ "|0[xXbB][0-9a-fA-F]+[lLuU]*" ++ "|\\.[0-9][0-9]*([Ee][-+]?[0-9]+)?[fFlL]?" ++ "|[-+*/<>%&^|=!]=|--|\\+\\+|<<=?|>>=?|&&|\\|\\||::|->\\*?|\\.\\*|<=>"),
pp("csharp",
     "!(^|[ \t]+)" ++ "(do|while|for|foreach|if|else|new|default|return|switch|case|throw" ++ "|catch|using|lock|fixed)" ++ "([ \t(]+|$)\n" ++ "^[ \t]*" ++ "(" ++ "(" ++ "[][[:alnum:]@_.]" ++ "(<[][[:alnum:]@_, \t<>]+>)?" ++ ")+" ++ "([ \t]+" ++ "([][[:alnum:]@_.](<[][[:alnum:]@_, \t<>]+>)?)+" ++ ")+" ++ "[ \t]*" ++ "\\(" ++ "[^;]*" ++ ")$\n" ++ "^[ \t]*(" ++ "([][[:alnum:]@_.](<[][[:alnum:]@_, \t<>]+>)?)+" ++ "([ \t]+" ++ "([][[:alnum:]@_.](<[][[:alnum:]@_, \t<>]+>)?)+" ++ ")+" ++ "[^;=:,()]*" ++ ")$\n" ++ "^[ \t]*(((static|public|internal|private|protected|new|unsafe|sealed|abstract|partial)[ \t]+)*(class|enum|interface|struct|record)[ \t]+.*)$\n" ++ "^[ \t]*(namespace[ \t]+.*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[-+0-9.e]+[fFlL]?|0[xXbB]?[0-9a-fA-F]+[lL]?" ++ "|[-+*/<>%&^|=!]=|--|\\+\\+|<<=?|>>=?|&&|\\|\\||::|->"),
ip("css",
     "![:;][[:space:]]*$\n" ++ "^[:[@.#]?[_a-z0-9].*$",
     "-?[_a-zA-Z][-_a-zA-Z0-9]*" ++ "|-?[0-9]+|\\#[0-9a-fA-F]+" 
),
pp("dts",
     "!;\n" ++ "!=\n" ++ "^[ \t]*((/[ \t]*\\{|&?[a-zA-Z_]).*)",
     "[a-zA-Z0-9,._+?#-]+" ++ "|[-+*/%&^|!~]|>>|<<|&&|\\|\\|"),
pp("elixir",
     "^[ \t]*((def(macro|module|impl|protocol|p)?|test)[ \t].*)$",
     "[@:]?[a-zA-Z0-9@_?!]+" ++ "|[-+]?0[xob][0-9a-fA-F]+" ++ "|[-+]?[0-9][0-9_.]*([eE][-+]?[0-9_]+)?" ++ "|:?(\\+\\+|--|\\.\\.|~~~|<>|\\^\\^\\^|<?\\|>|<<<?|>?>>|<<?~|~>?>|<~>|<=|>=|===?|!==?|=~|&&&?|\\|\\|\\|?|=>|<-|\\\\\\\\|->)" ++ "|:?%[A-Za-z0-9_.]\\{\\}?"),
ip("fortran",
     "!^([C*]|[ \t]*!)\n" ++ "!^[ \t]*MODULE[ \t]+PROCEDURE[ \t]\n" ++ "^[ \t]*((END[ \t]+)?(PROGRAM|MODULE|BLOCK[ \t]+DATA" ++ "|([^!'\" \t]+[ \t]+)*(SUBROUTINE|FUNCTION))[ \t]+[A-Z].*)$",
     "[a-zA-Z][a-zA-Z0-9_]*" ++ "|\\.([Ee][Qq]|[Nn][Ee]|[Gg][TtEe]|[Ll][TtEe]|[Tt][Rr][Uu][Ee]|[Ff][Aa][Ll][Ss][Ee]|[Aa][Nn][Dd]|[Oo][Rr]|[Nn]?[Ee][Qq][Vv]|[Nn][Oo][Tt])\\." ++ "|[-+]?[0-9.]+([AaIiDdEeFfLlTtXx][Ss]?[-+]?[0-9.]*)?(_[a-zA-Z0-9][a-zA-Z0-9_]*)?" ++ "|//|\\*\\*|::|[/<>=]="),
ip("fountain",
     "^((\\.[^.]|(int|ext|est|int\\.?/ext|i/e)[. ]).*)$",
     "[^ \t-]+"),
pp("golang",
     "^[ \t]*(func[ \t]*.*(\\{[ \t]*)?)\n" ++ "^[ \t]*(type[ \t].*(struct|interface)[ \t]*(\\{[ \t]*)?)",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[-+0-9.eE]+i?|0[xX]?[0-9a-fA-F]+i?" ++ "|[-+*/<>%&^|=!:]=|--|\\+\\+|<<=?|>>=?|&\\^=?|&&|\\|\\||<-|\\.{3}"),
pp("html",
     "^[ \t]*(<[Hh][1-6]([ \t].*)?>.*)$",
     "[^<>= \t]+"),
pp("ini",
     "^[ \t]*\\[[^]]+\\]",
     "[^ \t]+"),
pp("java",
     "!^[ \t]*(catch|do|for|if|instanceof|new|return|switch|throw|while)\n" ++ "^[ \t]*(([a-z-]+[ \t]+)*(class|enum|interface|record)[ \t]+.*)$\n" ++ "^[ \t]*(([A-Za-z_<>&][][?&<>.,A-Za-z_0-9]*[ \t]+)+[A-Za-z_][A-Za-z_0-9]*[ \t]*\\([^;]*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[-+0-9.e]+[fFlL]?|0[xXbB]?[0-9a-fA-F]+[lL]?" ++ "|[-+*/<>%&^|=!]=" ++ "|--|\\+\\+|<<=?|>>>?=?|&&|\\|\\|"),
pp("kotlin",
     "^[ \t]*(([a-z]+[ \t]+)*(fun|class|interface)[ \t]+.*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|0[xXbB][0-9a-fA-F_]+[lLuU]*" ++ "|[0-9][0-9_]*([.][0-9_]*)?([Ee][-+]?[0-9]+)?[fFlLuU]*" ++ "|[.][0-9][0-9_]*([Ee][-+]?[0-9]+)?[fFlLuU]?" ++ "|[-+*/<>%&^|=!]==?|--|\\+\\+|<<=|>>=|&&|\\|\\||->|\\.\\*|!!|[?:.][.:]"),
pp("markdown",
     "^ {0,3}#{1,6}[ \t].*",
     "[^<>= \t]+"),
pp("matlab",
     "^[[:space:]]*((classdef|function)[[:space:]].*)$|^(%%%?|##)[[:space:]].*$",
     "[a-zA-Z_][a-zA-Z0-9_]*|[-+0-9.e]+|[=~<>]=|\\.[*/\\^']|\\|\\||&&"),
pp("objc",
     "!^[ \t]*(do|for|if|else|return|switch|while)\n" ++ "^[ \t]*([-+][ \t]*\\([ \t]*[A-Za-z_][A-Za-z_0-9* \t]*\\)[ \t]*[A-Za-z_].*)$\n" ++ "^[ \t]*(([A-Za-z_][A-Za-z_0-9]*[ \t]+)+[A-Za-z_][A-Za-z_0-9]*[ \t]*\\([^;]*)$\n" ++ "^(@(implementation|interface|protocol)[ \t].*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[-+0-9.e]+[fFlL]?|0[xXbB]?[0-9a-fA-F]+[lL]?" ++ "|[-+*/<>%&^|=!]=|--|\\+\\+|<<=?|>>=?|&&|\\|\\||::|->"),
pp("pascal",
     "^(((class[ \t]+)?(procedure|function)|constructor|destructor|interface" ++ "|implementation|initialization|finalization)[ \t]*.*)$\n" ++ "^(.*=[ \t]*(class|record).*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[-+0-9.e]+|0[xXbB]?[0-9a-fA-F]+" ++ "|<>|<=|>=|:=|\\.\\."),
pp("perl",
     "^package .*\n" ++ "^sub [[:alnum:]_':]+[ \t]*" ++ "(\\([^)]*\\)[ \t]*)?" ++ "(:[^;#]*)?" ++ "(\\{[ \t]*)?" ++ "(#.*)?$\n" ++ "^(BEGIN|END|INIT|CHECK|UNITCHECK|AUTOLOAD|DESTROY)[ \t]*" ++ "(\\{[ \t]*)?" ++ "(#.*)?$\n" ++ "^=head[0-9] .*",    
     "[[:alpha:]_'][[:alnum:]_']*" ++ "|0[xb]?[0-9a-fA-F_]*" ++ "|[0-9a-fA-F_]+(\\.[0-9a-fA-F_]+)?([eE][-+]?[0-9_]+)?" ++ "|=>|-[rwxoRWXOezsfdlpSugkbctTBMAC>]|~~|::" ++ "|&&=|\\|\\|=|//=|\\*\\*=" ++ "|&&|\\|\\||//|\\+\\+|--|\\*\\*|\\.\\.\\.?" ++ "|[-+*/%.^&<>=!|]=" ++ "|=~|!~" ++ "|<<|<>|<=>|>>"),
pp("php",
     "^[\t ]*(((public|protected|private|static|abstract|final)[\t ]+)*function.*)$\n" ++ "^[\t ]*((((final|abstract)[\t ]+)?class|enum|interface|trait).*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[-+0-9.e]+|0[xXbB]?[0-9a-fA-F]+" ++ "|[-+*/<>%&^|=!.]=|--|\\+\\+|<<=?|>>=?|===|&&|\\|\\||::|->"),
pp("python",
     "^[ \t]*((class|(async[ \t]+)?def)[ \t].*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[-+0-9.e]+[jJlL]?|0[xX]?[0-9a-fA-F]+[lL]?" ++ "|[-+*/<>%&^|=!]=|//=?|<<=?|>>=?|\\*\\*=?"),
pp("r",
    "^[ \t]*([a-zA-z][a-zA-Z0-9_.]*[ \t]*(<-|=)[ \t]*function.*)$",
    "[^ \t]+"),
pp("ruby",
     "^[ \t]*((class|module|def)[ \t].*)$",
     "(@|@@|\\$)?[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[-+0-9.e]+|0[xXbB]?[0-9a-fA-F]+|\\?(\\\\C-)?(\\\\M-)?." ++ "|//=?|[-+*/<>%&^|=!]=|<<=?|>>=?|===|\\.{1,3}|::|[!=]~"),
pp("rust",
     "^[\t ]*((pub(\\([^\\)]+\\))?[\t ]+)?((async|const|unsafe|extern([\t ]+\"[^\"]+\"))[\t ]+)?(struct|enum|union|mod|trait|fn|impl|macro_rules!)[< \t]+[^;]*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|[0-9][0-9_a-fA-Fiosuxz]*(\\.([0-9]*[eE][+-]?)?[0-9_fF]*)?" ++ "|[-+*\\/<>%&^|=!:]=|<<=?|>>=?|&&|\\|\\||->|=>|\\.{2}=|\\.{3}|::"),
pp("scheme",
     "^(\\(.*)$\n" ++ "^[\t ]*(\\(((define|def(struct|syntax|class|method|rules|record|proto|alias)?)[-*/ \t]|(library|module|struct|class)[*+ \t]).*)$\n" ++ "^  ?(\\([Dd][Ee][Ff].*)$",
     "\\|([^|\\\\]|\\\\.)*\\|" ++ "|([^][)(}{ \t])+"),
pp("swift",
     "^[ \t]*((@[A-Za-z_][A-Za-z0-9_]*(\\([^()]*\\))?[ \t]+)*([a-z]+[ \t]+)*(func|init|deinit|subscript|class|struct|enum|protocol|extension|actor)[ \t(?!<].*)$",
     "[a-zA-Z_][a-zA-Z0-9_]*" ++ "|0[xX][0-9a-fA-F_]+|0[oO][0-7_]+|0[bB][01_]+" ++ "|[0-9][0-9_]*([.][0-9_]+)?([eE][-+]?[0-9]+)?" ++ "|[-+*/%<>=!&|^~?]=|&&|\\|\\||<<=?|>>=?|\\?\\?|\\.\\.[.<]|->"),
pp("tex", "^(\\\\((sub)*section|chapter|part)\\*{0,1}\\{.*)$",
     "\\\\[a-zA-Z@]+|\\\\.|([a-zA-Z0-9]|[^\x01-\x7f])+"),
.{ .name = "default" },
};

var driver_true = Driver{ .name = "diff=true", .binary = 0 };
var driver_false = Driver{ .name = "!diff", .binary = 1 };

var custom: std.ArrayList(*Driver) = .empty;
var loaded = false;

fn cfgBool(k: []const u8, v: ?[]const u8) bool {
    const val = v orelse return true;
    return config.parseBool(val) orelse util.die("bad boolean config value '{s}' for '{s}'", .{ val, k });
}

fn findCustom(name: []const u8) ?*Driver {
    for (custom.items) |d| {
        if (util.eql(d.name, name)) return d;
    }
    return null;
}

fn findByNameRaw(name: []const u8) ?*Driver {
    if (findCustom(name)) |d| return d;
    for (&builtin_drivers) |*d| {
        if (util.eql(d.name, name)) return d;
    }
    return null;
}

/// userdiff_config over all configured diff.<name>.<key> entries (in config order).
pub fn loadConfig() void {
    if (loaded) return;
    loaded = true;
    for (repo_mod.cfg.entries.items) |e| {
        const rest = util.skipPrefix(e.key, "diff.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse continue;
        const name = rest[0..dot];
        const typ = rest[dot + 1 ..];
        var drv = findByNameRaw(name);
        if (drv == null) {
            const d = util.gpa.create(Driver) catch util.oom();
            d.* = .{ .name = name };
            custom.append(util.gpa, d) catch util.oom();
            drv = d;
        }
        const d = drv.?;
        const v = e.value;
        if (util.eql(typ, "funcname") or util.eql(typ, "xfuncname")) {
            const val = v orelse util.die("missing value for '{s}'", .{e.key});
            d.funcname = val;
            d.funcname_extended = util.eql(typ, "xfuncname");
            d.funcname_icase = false;
        } else if (util.eql(typ, "binary")) {
            if (v != null and std.ascii.eqlIgnoreCase(v.?, "auto")) d.binary = -1 else d.binary = if (cfgBool(e.key, v)) 1 else 0;
        } else if (util.eql(typ, "command")) {
            d.external_cmd = v orelse util.die("missing value for '{s}'", .{e.key});
        } else if (util.eql(typ, "trustexitcode")) {
            d.trust_exit_code = cfgBool(e.key, v);
        } else if (util.eql(typ, "textconv")) {
            d.textconv = v orelse util.die("missing value for '{s}'", .{e.key});
        } else if (util.eql(typ, "cachetextconv")) {
            d.textconv_want_cache = cfgBool(e.key, v);
        } else if (util.eql(typ, "wordregex")) {
            d.word_regex = v orelse util.die("missing value for '{s}'", .{e.key});
        } else if (util.eql(typ, "algorithm")) {
            d.algorithm = v orelse util.die("missing value for '{s}'", .{e.key});
        }
    }
}

pub fn findByName(name: []const u8) ?*Driver {
    loadConfig();
    return findByNameRaw(name);
}

/// userdiff_find_by_path: driver selected by the "diff" attribute of path.
pub fn findByPath(path: ?[]const u8) ?*Driver {
    const p = path orelse return null;
    if (repo_mod.repo_ == null) return null;
    loadConfig();
    return switch (attr.get(p, "diff")) {
        .set => &driver_true,
        .unset => &driver_false,
        .unspecified => null,
        .value => |v| findByNameRaw(v),
    };
}

/// userdiff_get_textconv
pub fn getTextconv(d: *Driver) ?*Driver {
    if (d.textconv == null) return null;
    return d;
}

/// Names of all builtin drivers (for tests / completeness).
pub fn builtinNames() []const []const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    for (builtin_drivers) |d| l.append(util.gpa, d.name) catch util.oom();
    return l.items;
}
