//! git pack-objects (builtin/pack-objects.c), simplified: no delta/object
//! reuse from existing packs, no bitmaps; deltas are recomputed.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const odb_mod = @import("../odb.zig");
const pack = @import("../pack.zig");
const progress = @import("../progress.zig");
const refs = @import("../refs.zig");
const objects = @import("../objects.zig");
const revision = @import("../revision.zig");
const cn = @import("../commitnode.zig");
const zlib = @import("../zlib.zig");
const date = @import("../date.zig");
const config = @import("../config.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

const usage = [_][]const u8{
    "git pack-objects [-q | --progress | --all-progress] [--all-progress-implied]\n" ++
        "                 [--no-reuse-delta] [--delta-base-offset] [--non-empty]\n" ++
        "                 [--local] [--incremental] [--window=<n>] [--depth=<n>]\n" ++
        "                 [--revs [--unpacked | --all]] [--keep-pack=<pack-name>]\n" ++
        "                 [--cruft] [--cruft-expiration=<time>]\n" ++
        "                 [--stdout [--filter=<filter-spec>] | <base-name>]\n" ++
        "                 [--shallow] [--keep-true-parents] [--[no-]sparse]\n" ++
        "                 [--name-hash-version=<n>] [--path-walk] < <object-list>",
};

const Entry = struct {
    oid: Oid,
    typ: ObjType,
    size: usize,
    name_hash: u32,
    preferred_base: bool = false,
    tagged: bool = false,
    no_try_delta: bool = false,
    delta: ?u32 = null,
    delta_data: ?[]u8 = null,
    depth: u32 = 0,
    offset: u64 = 0,
    written: bool = false,
    crc: u32 = 0,
    filled: bool = false,
    delta_child: ?u32 = null,
    delta_sibling: ?u32 = null,
    mtime: u32 = 0,
    pack_no: u32 = 0,
};

var entries: std.ArrayList(Entry) = .empty;
var index: hash.OidMap(u32) = .empty;
var nr_result: u32 = 0;
var odb: *odb_mod.Odb = undefined;

// options
var progress_level: i32 = 0;
var all_progress_implied = false;
var index_version: ?[]const u8 = null;
var max_pack_size: ?[]const u8 = null;
var local = false;
var incremental = false;
var window: i32 = 10;
var depth: i32 = 50;
var reuse_delta = true;
var reuse_object = true;
var allow_ofs_delta = false;
var threads: i32 = 0;
var non_empty = false;
var use_revs = false;
var rev_unpacked: i32 = 0;
var rev_all: i32 = 0;
var rev_reflog: i32 = 0;
var rev_index: i32 = 0;
var pack_to_stdout = false;
var include_tag = false;
var keep_unreachable = false;
var pack_loose_unreachable = false;
var unpack_unreachable: ?[]const u8 = null;
var sparse = false;
var thin = false;
var shallow = false;
var honor_pack_keep = false;
var keep_pack_list: std.ArrayList([]const u8) = .empty;
var compression: i32 = -2;
var keep_true_parents = false;
var use_bitmap_index = false;
var write_bitmap_index: i32 = 0;
var filter: ?[]const u8 = null;
var missing: ?[]const u8 = null;
var exclude_promisor = false;
var exclude_promisor_best_effort = false;
var delta_islands = false;
var uri_protocols: std.ArrayList([]const u8) = .empty;
var name_hash_version: i32 = -1;
var path_walk = false;
var window_memory: i32 = 0;
var cruft = false;
var cruft_expiration: ?[]const u8 = null;
var stdin_packs: ?[]const u8 = null;
var progress_explicit = false;

fn quietCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    if (!unset) progress_level = 0 else if (progress_level == 0) progress_level = 1;
    progress_explicit = true;
}
fn progressCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    progress_level = if (unset) 0 else 1;
    progress_explicit = true;
}
fn allProgressCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    progress_level = if (unset) 0 else 2;
    progress_explicit = true;
}

const options = [_]po.Opt{
    .{ .short = 'q', .long = "quiet", .kind = .callback, .cb = quietCb, .noarg = true, .help = "do not show progress meter" },
    .{ .long = "progress", .kind = .callback, .cb = progressCb, .noarg = true, .help = "show progress meter" },
    .{ .long = "all-progress", .kind = .callback, .cb = allProgressCb, .noarg = true, .help = "show progress meter during object writing phase" },
    po.boolean(0, "all-progress-implied", &all_progress_implied, "similar to --all-progress when progress meter is shown"),
    .{ .long = "index-version", .kind = .string, .s = &index_version, .argh = "<version>[,<offset>]", .literal_argh = true, .noneg = true, .help = "write the pack index file in the specified idx format version" },
    po.string(0, "max-pack-size", &max_pack_size, "n", "maximum size of each output pack file"),
    po.boolean(0, "local", &local, "ignore borrowed objects from alternate object store"),
    po.boolean(0, "incremental", &incremental, "ignore packed objects"),
    po.integer(0, "window", &window, "n", "limit pack window by objects"),
    po.integer(0, "window-memory", &window_memory, "n", "limit pack window by memory in addition to object limit"),
    po.integer(0, "depth", &depth, "n", "maximum length of delta chain allowed in the resulting pack"),
    po.boolean(0, "reuse-delta", &reuse_delta, "reuse existing deltas"),
    po.boolean(0, "reuse-object", &reuse_object, "reuse existing objects"),
    po.boolean(0, "delta-base-offset", &allow_ofs_delta, "use OFS_DELTA objects"),
    po.integer(0, "threads", &threads, "n", "use threads when searching for best delta matches"),
    po.boolean(0, "non-empty", &non_empty, "do not create an empty pack output"),
    po.boolean(0, "revs", &use_revs, "read revision arguments from standard input"),
    .{ .long = "unpacked", .kind = .set_int, .i = &rev_unpacked, .val = 1, .noneg = true, .help = "limit the objects to those that are not yet packed" },
    .{ .long = "all", .kind = .set_int, .i = &rev_all, .val = 1, .noneg = true, .help = "include objects reachable from any reference" },
    .{ .long = "reflog", .kind = .set_int, .i = &rev_reflog, .val = 1, .noneg = true, .help = "include objects referred by reflog entries" },
    .{ .long = "indexed-objects", .kind = .set_int, .i = &rev_index, .val = 1, .noneg = true, .help = "include objects referred to by the index" },
    .{ .long = "stdin-packs", .kind = .string, .s = &stdin_packs, .optarg = true, .def = "", .argh = "mode", .help = "read packs from stdin" },
    po.boolean(0, "stdout", &pack_to_stdout, "output pack to stdout"),
    po.boolean(0, "include-tag", &include_tag, "include tag objects that refer to objects to be packed"),
    po.boolean(0, "keep-unreachable", &keep_unreachable, "keep unreachable objects"),
    po.boolean(0, "pack-loose-unreachable", &pack_loose_unreachable, "pack loose unreachable objects"),
    .{ .long = "unpack-unreachable", .kind = .string, .s = &unpack_unreachable, .optarg = true, .def = "", .argh = "time", .help = "unpack unreachable objects newer than <time>" },
    po.boolean(0, "cruft", &cruft, "create a cruft pack"),
    .{ .long = "cruft-expiration", .kind = .string, .s = &cruft_expiration, .optarg = true, .def = "", .argh = "time", .help = "expire cruft objects older than <time>" },
    po.boolean(0, "sparse", &sparse, "use the sparse reachability algorithm"),
    po.boolean(0, "thin", &thin, "create thin packs"),
    po.boolean(0, "path-walk", &path_walk, "use the path-walk API to walk objects when possible"),
    po.boolean(0, "shallow", &shallow, "create packs suitable for shallow fetches"),
    po.boolean(0, "honor-pack-keep", &honor_pack_keep, "ignore packs that have companion .keep file"),
    po.list(0, "keep-pack", &keep_pack_list, "name", "ignore this pack"),
    po.integer(0, "compression", &compression, "n", "pack compression level"),
    po.boolean(0, "keep-true-parents", &keep_true_parents, "do not hide commits by grafts"),
    po.boolean(0, "use-bitmap-index", &use_bitmap_index, "use a bitmap index if available to speed up counting objects"),
    po.setInt(0, "write-bitmap-index", &write_bitmap_index, 1, "write a bitmap index together with the pack index"),
    .{ .long = "write-bitmap-index-quiet", .kind = .set_int, .i = &write_bitmap_index, .val = 2, .hidden = true, .help = "write a bitmap index if possible" },
    po.string(0, "filter", &filter, "args", "object filtering"),
    .{ .long = "missing", .kind = .string, .s = &missing, .noneg = true, .argh = "action", .help = "handling for missing objects" },
    po.boolean(0, "exclude-promisor-objects", &exclude_promisor, "do not pack objects in promisor packfiles"),
    po.boolean(0, "exclude-promisor-objects-best-effort", &exclude_promisor_best_effort, "implies --missing=allow-any"),
    po.boolean(0, "delta-islands", &delta_islands, "respect islands during delta compression"),
    po.list(0, "uri-protocol", &uri_protocols, "protocol", "exclude any configured uploadpack.blobpackfileuri with this protocol"),
    po.integer(0, "name-hash-version", &name_hash_version, "n", "use the specified name-hash function to group similar objects"),
};

// ---------------------------------------------------------------- pack membership

const PackInfo = struct {
    p: *odb_mod.Pack,
    local: bool,
    keep: bool,
    kept_by_option: bool,
    keep_in_core: bool = false,
    keep_in_core_open: bool = false,
    is_cruft: bool = false,
    mtime: i64 = 0,
    mtimes: ?[]const u8 = null,
};
var ignore_keep_in_core = false;
var ignore_keep_in_core_open = false;
var keep_in_core_has_cruft = false;
var want_mtime: u32 = 0;
var pack_infos: std.ArrayList(PackInfo) = .empty;

fn loadPackInfos() void {
    odb.loadPacks();
    for (odb.packs.items) |p| {
        const is_local = util.startsWith(p.idx_path, odb.objects_dir);
        const base = p.pack_path[0 .. p.pack_path.len - 5];
        const keep = os.exists(util.concat(&.{ base, ".keep" }));
        var kept = false;
        const bn = util.basename(p.pack_path);
        for (keep_pack_list.items) |k| {
            if (util.eql(k, bn)) kept = true;
        }
        const st = os.statPath(p.pack_path);
        pack_infos.append(gpa, .{
            .p = p,
            .local = is_local,
            .keep = keep,
            .kept_by_option = kept,
            .is_cruft = os.exists(util.concat(&.{ base, ".mtimes" })),
            .mtimes = os.readFile(util.concat(&.{ base, ".mtimes" })),
            .mtime = if (st) |s| s.mtime else 0,
        }) catch util.oom();
    }
}

fn hasLocalLoose(oid: Oid) bool {
    return os.exists(odb.looseObjectPath(odb.objects_dir, oid));
}

/// want_object_in_pack(): false if the object should be excluded.
fn wantObject(oid: Oid, exclude: bool) bool {
    if (exclude) return true;
    var found_local = false;
    var found_nonlocal_pack = false;
    for (pack_infos.items) |pi| {
        if (pi.p.find(oid) == null) continue;
        if (incremental) return false;
        if (honor_pack_keep and pi.keep and pi.local) return false;
        if (pi.kept_by_option) return false;
        if (ignore_keep_in_core_open and pi.keep_in_core_open) return false;
        if (ignore_keep_in_core and pi.keep_in_core) {
            if (!keep_in_core_has_cruft or !pi.is_cruft) return false;
            if (want_mtime <= packMtimeAt(pi, pi.p.find(oid).?)) return false;
        }
        if (pi.local) found_local = true else found_nonlocal_pack = true;
    }
    if (local and found_nonlocal_pack and !found_local) return false;
    if (local and !found_local and !found_nonlocal_pack) {
        // loose: only local loose objects are wanted
        if (!hasLocalLoose(oid) and odb.alternates.items.len > 0) return false;
    }
    return true;
}

fn isPacked(oid: Oid) bool {
    for (pack_infos.items) |pi| {
        if (pi.p.find(oid) != null) return true;
    }
    return false;
}

// ---------------------------------------------------------------- entries

fn addObjectEntry(oid: Oid, typ0: ObjType, name: ?[]const u8, exclude: bool) void {
    if (index.get(oid)) |i| {
        if (exclude and !entries.items[i].preferred_base) {} // already in
        return;
    }
    if (!wantObject(oid, exclude)) return;
    var typ = typ0;
    var size: usize = 0;
    if (odb.read(oid)) |o| {
        typ = o.typ;
        size = o.data.len;
    } else if (!exclude) {
        if (typ == .none) util.die("unable to get type of object {s}", .{hash.hex(oid)});
    } else return;
    const idx: u32 = @intCast(entries.items.len);
    entries.append(gpa, .{
        .oid = oid,
        .typ = typ,
        .size = size,
        .name_hash = if (name) |n| pack.nameHash(n) else 0,
        .preferred_base = exclude,
    }) catch util.oom();
    index.put(gpa, oid, idx) catch util.oom();
    if (!exclude) nr_result += 1;
}

var enum_progress: ?*progress.Progress = null;

fn showCommit(c: *cn.Commit, data: ?*anyopaque) void {
    _ = data;
    addObjectEntry(c.oid(), .commit, null, false);
    progress.update(enum_progress, nr_result);
}

fn showObject(obj: *cn.Obj, name: []const u8, data: ?*anyopaque) void {
    _ = data;
    if (missing_allow_any and !odb.has(obj.oid)) return;
    addObjectEntry(obj.oid, obj.typ, name, false);
    progress.update(enum_progress, nr_result);
}

var missing_allow_any = false;

var edges: std.ArrayList(Oid) = .empty;
fn showEdge(c: *cn.Commit) void {
    edges.append(gpa, c.oid()) catch util.oom();
}

/// Add preferred bases (thin packs): walk trees of edge objects, adding
/// entries whose path matches a path of an object being packed.
fn addPreferredBases() void {
    if (edges.items.len == 0) return;
    var names = std.StringHashMap(void).init(gpa);
    for (pending_names.items) |n| names.put(n, {}) catch util.oom();
    var count: usize = 0;
    for (edges.items) |e| {
        const o = odb.read(e) orelse continue;
        var tree: Oid = undefined;
        if (o.typ == .commit) {
            const c = objects.parseCommit(e, o.data) orelse continue;
            tree = c.tree;
        } else if (o.typ == .tree) {
            tree = e;
        } else continue;
        walkPreferred(tree, "", &names, &count);
        if (count > 50000) break;
    }
}

fn walkPreferred(tree: Oid, base: []const u8, names: *std.StringHashMap(void), count: *usize) void {
    if (!names.contains(base)) return;
    addObjectEntry(tree, .tree, base, true);
    count.* += 1;
    const ents = objects.readTree(tree) orelse return;
    for (ents) |e| {
        if (e.mode == 0o160000) continue;
        const full = if (base.len == 0) util.dupe(e.name) else util.concat(&.{ base, "/", e.name });
        if (e.isDir()) {
            walkPreferred(e.oid, full, names, count);
        } else if (names.contains(full)) {
            addObjectEntry(e.oid, .blob, full, true);
            count.* += 1;
        }
    }
}

var pending_names: std.ArrayList([]const u8) = .empty;

fn readStdinLines() [][]const u8 {
    const data = os.readAllFd(0) catch util.die("read error", .{});
    var out: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |l| out.append(gpa, l) catch util.oom();
    if (out.items.len > 0 and out.items[out.items.len - 1].len == 0 and util.endsWith(data, "\n")) out.items.len -= 1;
    return out.items;
}

fn readObjectListFromStdin() void {
    const lines = readStdinLines();
    for (lines) |line| {
        if (line.len > 0 and line[0] == '-') {
            const oid = if (line.len >= 41) hash.fromHex(line[1..41]) else null;
            if (oid == null) util.die("expected edge object ID, got garbage:\n {s}", .{line});
            edges.append(gpa, oid.?) catch util.oom();
            continue;
        }
        const oid = if (line.len >= 40) hash.fromHex(line[0..40]) else null;
        if (oid == null or (line.len > 40 and line[40] != ' ')) util.die("expected object ID, got garbage:\n {s}", .{line});
        const name: []const u8 = if (line.len > 41) line[41..] else "";
        pending_names.append(gpa, name) catch util.oom();
        addObjectEntry(oid.?, .none, name, false);
        progress.update(enum_progress, nr_result);
    }
}

fn getObjectList(rp: []const []const u8) void {
    var revs = revision.RevInfo.init("");
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "pack-objects") catch util.oom();
    argv.appendSlice(gpa, rp) catch util.oom();
    _ = revision.setupRevisions(&revs, argv.items, .{});
    if (filter) |f| revs.obj_filter = @import("../objfilter.zig").parse(f);
    if (use_revs) {
        const lines = readStdinLines();
        var flags: u32 = 0;
        for (lines) |line| {
            if (line.len == 0) break;
            if (line[0] == '-') {
                if (util.eql(line, "--not")) {
                    flags ^= cn.UNINTERESTING;
                    continue;
                }
                if (util.startsWith(line, "--shallow ")) {
                    const so = hash.fromHex(line[10..]) orelse util.die("not an object name '{s}'", .{line[10..]});
                    objects.registerShallow(so);
                    continue;
                }
                util.die("not a rev '{s}'", .{line});
            }
            if (revision.handleRevisionArg(line, &revs, flags, revision.REVARG_CANNOT_BE_FILENAME) != 0)
                util.die("bad revision '{s}'", .{line});
        }
    }
    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    revision.markEdgesUninteresting(&revs, showEdge);
    revision.traverseCommitList(&revs, showCommit, showObjectNamed, null);
    if (unpack_expiration != 0) {
        var revs2 = revision.RevInfo.init("");
        revs2.tag_objects = true;
        revs2.tree_objects = true;
        revs2.blob_objects = true;
        revs2.ignore_missing_links = true;
        addUnseenRecentObjects(&revs2, unpack_expiration, false, false);
        if (!revision.prepareRevisionWalk(&revs2)) util.die("revision walk setup failed", .{});
        revision.traverseCommitList(&revs2, recordRecentCommit, recordRecentObject, null);
    }
    if (keep_unreachable) addObjectsInUnpackedPacks();
    if (pack_loose_unreachable) addUnreachable();
    if (unpack_unreachable != null) loosenUnusedPackedObjects();
}

fn showObjectNamed(obj: *cn.Obj, name: []const u8, data: ?*anyopaque) void {
    pending_names.append(gpa, util.dupe(name)) catch util.oom();
    showObject(obj, name, data);
}

fn addUnreachable() void {
    {
        for (odb.allObjects(false)) |oid| {
            if (index.contains(oid)) continue;
            if (!hasLocalLoose(oid)) continue;
            addObjectEntryNoCheck(oid);
        }
    }
}

fn addObjectEntryNoCheck(oid: Oid) void {
    const o = odb.read(oid) orelse return;
    const idx: u32 = @intCast(entries.items.len);
    entries.append(gpa, .{ .oid = oid, .typ = o.typ, .size = o.data.len, .name_hash = 0 }) catch util.oom();
    index.put(gpa, oid, idx) catch util.oom();
    nr_result += 1;
}

// ---------------------------------------------------------------- cruft packs

fn packMtimeAt(pi: PackInfo, pos: u32) u32 {
    if (pi.mtimes) |m| {
        const off = 12 + 4 * @as(usize, pos);
        if (m.len >= off + 4 and std.mem.eql(u8, m[0..4], "MTME")) return std.mem.readInt(u32, m[off..][0..4], .big);
    }
    return @intCast(@max(pi.mtime, 0));
}

fn inKeptInCorePack(oid: Oid) bool {
    for (pack_infos.items) |pi| {
        if (pi.keep_in_core and pi.p.find(oid) != null) return true;
    }
    return false;
}

var nr_seen: u64 = 0;

fn addCruftEntry(oid: Oid, typ0: ObjType, name: ?[]const u8, mtime: u32) void {
    nr_seen += 1;
    progress.update(enum_progress, nr_seen);
    if (index.get(oid)) |i| {
        const e = &entries.items[i];
        if (name) |n| e.name_hash = pack.nameHash(n);
        if (mtime > e.mtime) e.mtime = mtime;
        return;
    }
    want_mtime = mtime;
    if (!wantObject(oid, false)) return;
    if (typ0 == .blob and !isPacked(oid) and !odb.hasLoose(oid)) return;
    const o = odb.read(oid) orelse return;
    const idx: u32 = @intCast(entries.items.len);
    entries.append(gpa, .{
        .oid = oid,
        .typ = o.typ,
        .size = o.data.len,
        .name_hash = if (name) |n| pack.nameHash(n) else 0,
        .mtime = mtime,
    }) catch util.oom();
    index.put(gpa, oid, idx) catch util.oom();
    nr_result += 1;
}

fn offsetLess(p: *odb_mod.Pack, a: u32, b: u32) bool {
    return p.offsetAt(a) < p.offsetAt(b);
}

/// Index positions of a pack's objects in pack (offset) order.
fn packOrder(p: *odb_mod.Pack) []u32 {
    const out = gpa.alloc(u32, p.num) catch util.oom();
    for (out, 0..) |*x, i| x.* = @intCast(i);
    std.mem.sort(u32, out, p, offsetLess);
    return out;
}

/// Loose objects in the local object directory, with their mtimes.
const LooseObj = struct { oid: Oid, mtime: i64 };
fn localLooseObjects() []LooseObj {
    var out: std.ArrayList(LooseObj) = .empty;
    var d: usize = 0;
    while (d < 256) : (d += 1) {
        const sub = util.fmt("{x:0>2}", .{d});
        const dir = util.concat(&.{ odb.objects_dir, "/", sub });
        const ents = os.listDir(dir) orelse continue;
        for (ents) |e| {
            if (e.name.len != 38) continue;
            const oid = hash.fromHex(util.concat(&.{ sub, e.name })) orelse continue;
            const st = os.statPath(util.concat(&.{ dir, "/", e.name })) orelse continue;
            out.append(gpa, .{ .oid = oid, .mtime = st.mtime }) catch util.oom();
        }
    }
    return out.items;
}

fn clampMtime(t: i64) u32 {
    if (t < 0) return 0;
    if (t > std.math.maxInt(u32)) return std.math.maxInt(u32);
    return @intCast(t);
}

/// add_objects_in_unpacked_packs()
fn addObjectsInUnpackedPacks() void {
    for (pack_infos.items) |pi| {
        if (!pi.local or pi.keep or pi.keep_in_core) continue;
        for (packOrder(pi.p)) |j| {
            const oid = pi.p.oidAt(j);
            if (cruft) {
                addCruftEntry(oid, .none, null, packMtimeAt(pi, j));
            } else if (!index.contains(oid)) {
                addObjectEntryNoCheck(oid);
            }
        }
    }
}

var cruft_expiration_ts: i64 = 0;

fn showCruftCommit(c: *cn.Commit, data: ?*anyopaque) void {
    showCruftObject(&c.obj, "", data);
}

fn showCruftObject(obj: *cn.Obj, name: []const u8, data: ?*anyopaque) void {
    _ = data;
    if (inKeptInCorePack(obj.oid)) return;
    addCruftEntry(obj.oid, obj.typ, if (name.len > 0) name else null, clampMtime(cruft_expiration_ts));
}

/// add_unseen_recent_objects_to_traversal(): local objects newer than
/// `ts` become traversal tips. When `cb_cruft` is set, they are also
/// added as cruft entries with their own mtime.
fn addUnseenRecentObjects(revs: *revision.RevInfo, ts: i64, cb_cruft: bool, skip_in_core: bool) void {
    const Ctx = struct {
        fn one(rv: *revision.RevInfo, oid: Oid, mtime: i64, cbc: bool, skip: bool, t: i64) void {
            if (skip and inKeptInCorePack(oid)) return;
            if (mtime <= t) return;
            const typ = odb.readType(oid) orelse return;
            const obj: *cn.Obj = switch (typ) {
                .commit, .tag => cn.parseObject(oid) orelse util.die("unable to parse object: {s}", .{hash.hex(oid)}),
                .tree, .blob => cn.lookup(oid, typ) orelse util.die("unable to lookup {s}", .{hash.hex(oid)}),
                else => util.die("unknown object type for {s}: {s}", .{ hash.hex(oid), typ.name() }),
            };
            if (obj.flags & cn.SEEN != 0) return;
            rv.addPendingObject(obj, "");
            if (cbc) addCruftEntry(oid, typ, null, clampMtime(mtime));
        }
    };
    for (localLooseObjects()) |lo| Ctx.one(revs, lo.oid, lo.mtime, cb_cruft, skip_in_core, ts);
    for (pack_infos.items) |pi| {
        if (!pi.local) continue;
        if (skip_in_core and pi.keep_in_core) continue;
        for (packOrder(pi.p)) |j| Ctx.one(revs, pi.p.oidAt(j), packMtimeAt(pi, j), cb_cruft, skip_in_core, ts);
    }
}

var stdin_packs_follow = false;

fn findPackInfo(name: []const u8) ?*PackInfo {
    for (pack_infos.items) |*pi| {
        if (util.eql(util.basename(pi.p.pack_path), name)) return pi;
    }
    return null;
}

fn mtimeDescLess(_: void, a: *PackInfo, b: *PackInfo) bool {
    return a.mtime > b.mtime;
}

/// read_stdin_packs(): pack all objects in the listed packs, minus those
/// in "^"-excluded packs; with =follow, also objects reachable from them.
fn readStdinPacks() void {
    const KIND_INCLUDE: u8 = 1;
    const KIND_CLOSED: u8 = 2;
    const KIND_OPEN: u8 = 4;
    var names: std.ArrayList([]const u8) = .empty;
    var kinds: std.ArrayList(u8) = .empty;
    for (readStdinLines()) |line0| {
        if (line0.len == 0) continue;
        var key = line0;
        var kind = KIND_INCLUDE;
        if (key[0] == '^') {
            kind = KIND_CLOSED;
        } else if (key[0] == '!' and stdin_packs_follow) kind = KIND_OPEN;
        if (kind != KIND_INCLUDE) key = key[1..];
        var found = false;
        for (names.items, 0..) |n, k| {
            if (util.eql(n, key)) {
                kinds.items[k] |= kind;
                found = true;
            }
        }
        if (!found) {
            names.append(gpa, key) catch util.oom();
            kinds.append(gpa, kind) catch util.oom();
        }
    }
    var infos = gpa.alloc(?*PackInfo, names.items.len) catch util.oom();
    for (names.items, 0..) |n, k| {
        infos[k] = findPackInfo(n);
        const pi = infos[k] orelse continue;
        if (kinds.items[k] & KIND_INCLUDE != 0 and !os.exists(pi.p.pack_path))
            util.die("packfile {s} cannot be accessed", .{pi.p.pack_path});
        if (kinds.items[k] & KIND_CLOSED != 0) pi.keep_in_core = true;
        if (kinds.items[k] & KIND_OPEN != 0) pi.keep_in_core_open = true;
    }
    ignore_keep_in_core = true;
    if (stdin_packs_follow) ignore_keep_in_core_open = true;
    var order: std.ArrayList(*PackInfo) = .empty;
    var order_kind: std.ArrayList(u8) = .empty;
    for (names.items, 0..) |n, k| {
        const pi = infos[k] orelse util.die("could not find pack '{s}'", .{n});
        order.append(gpa, pi) catch util.oom();
        order_kind.append(gpa, kinds.items[k]) catch util.oom();
    }
    // stable sort by descending mtime, keeping kinds paired
    const idxs = gpa.alloc(usize, order.items.len) catch util.oom();
    for (idxs, 0..) |*x, k| x.* = k;
    const Cmp = struct {
        fn less(ctx: []const *PackInfo, a: usize, b: usize) bool {
            return ctx[a].mtime > ctx[b].mtime;
        }
    };
    std.mem.sort(usize, idxs, @as([]const *PackInfo, order.items), Cmp.less);

    var revs = revision.RevInfo.init("");
    revs.tag_objects = true;
    revs.tree_objects = true;
    revs.blob_objects = true;
    revs.ignore_missing_links = true;
    for (idxs) |k| {
        const pi = order.items[k];
        const kind = order_kind.items[k];
        if (kind & (KIND_INCLUDE | KIND_OPEN) == 0) continue;
        for (packOrder(pi.p)) |j| {
            const oid = pi.p.oidAt(j);
            progress.update(enum_progress, nr_result);
            if (index.contains(oid)) continue;
            const typ = odb.readType(oid) orelse util.die("could not get type of object {s} in pack {s}", .{ hash.hex(oid), pi.p.pack_path });
            if (typ == .commit) {
                if (cn.parseObject(oid)) |obj| revs.addPendingObject(obj, "");
            }
            addObjectEntry(oid, typ, null, false);
        }
    }
    if (rev_unpacked != 0) {
        for (localLooseObjects()) |lo| {
            const typ = odb.readType(lo.oid) orelse {
                util.warn("loose object at {s} could not be examined", .{odb.looseObjectPath(odb.objects_dir, lo.oid)});
                continue;
            };
            addObjectEntry(lo.oid, typ, "", false);
            if (typ == .commit) {
                if (cn.parseObject(lo.oid)) |obj| revs.addPendingObject(obj, "");
            }
        }
    }
    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    revision.traverseCommitList(&revs, showCommitPackHint, showObjectPackHint, null);
}

fn showCommitPackHint(c: *cn.Commit, data: ?*anyopaque) void {
    if (stdin_packs_follow) showObjectPackHint(&c.obj, "", data);
}

fn showObjectPackHint(obj: *cn.Obj, name: []const u8, data: ?*anyopaque) void {
    _ = data;
    if (stdin_packs_follow) {
        if (obj.typ == .blob and !odb.has(obj.oid)) return;
        addObjectEntry(obj.oid, obj.typ, name, false);
        return;
    }
    const i = index.get(obj.oid) orelse return;
    entries.items[i].name_hash = pack.nameHash(name);
}

fn readCruftObjects() void {
    ignore_keep_in_core = true;
    var fresh: std.ArrayList([]const u8) = .empty;
    var discard: std.ArrayList([]const u8) = .empty;
    for (readStdinLines()) |line| {
        if (line.len == 0) continue;
        if (line[0] == '-') discard.append(gpa, line[1..]) catch util.oom() else fresh.append(gpa, line) catch util.oom();
    }
    const findPack = struct {
        fn f(name: []const u8) ?*PackInfo {
            for (pack_infos.items) |*pi| {
                if (util.eql(util.basename(pi.p.pack_path), name)) return pi;
            }
            return null;
        }
    }.f;
    for (pack_infos.items) |*pi| {
        const bn = util.basename(pi.p.pack_path);
        var listed = false;
        for (fresh.items) |n| {
            if (util.eql(n, bn)) listed = true;
        }
        for (discard.items) |n| {
            if (util.eql(n, bn)) listed = true;
        }
        if (!listed) pi.keep_in_core = true;
    }
    for (fresh.items) |n| {
        const pi = findPack(n) orelse util.die("could not find pack '{s}'", .{n});
        if (pi.is_cruft) keep_in_core_has_cruft = true;
        pi.keep_in_core = true;
    }
    for (discard.items) |n| {
        const pi = findPack(n) orelse util.die("could not find pack '{s}'", .{n});
        pi.keep_in_core = false;
    }

    if (cruft_expiration_ts != 0) {
        var revs = revision.RevInfo.init("");
        revs.tag_objects = true;
        revs.tree_objects = true;
        revs.blob_objects = true;
        revs.ignore_missing_links = true;
        if (progress_level != 0) enum_progress = progress.start("Enumerating cruft objects", 0);
        addUnseenRecentObjects(&revs, cruft_expiration_ts, true, true);
        if (enum_progress) |p| p.stop();
        enum_progress = null;
        for (pack_infos.items) |*pi| pi.keep_in_core = false;
        for (fresh.items) |n| findPack(n).?.keep_in_core = true;
        if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
        if (progress_level != 0) enum_progress = progress.start("Traversing cruft objects", 0);
        nr_seen = 0;
        revision.traverseCommitList(&revs, showCruftCommit, showCruftObject, null);
        if (enum_progress) |p| p.stop();
        enum_progress = null;
    } else {
        if (progress_level != 0) enum_progress = progress.start("Enumerating cruft objects", 0);
        addObjectsInUnpackedPacks();
        for (localLooseObjects()) |lo| {
            const typ = odb.readType(lo.oid) orelse {
                util.warn("loose object at {s} could not be examined", .{odb.looseObjectPath(odb.objects_dir, lo.oid)});
                continue;
            };
            addCruftEntry(lo.oid, typ, null, clampMtime(lo.mtime));
        }
        if (enum_progress) |p| p.stop();
        enum_progress = null;
    }
}

fn oidLess(_: void, a: Oid, b: Oid) bool {
    return std.mem.order(u8, &a, &b) == .lt;
}

fn buildMtimes(sum: Oid) []u8 {
    var oids: std.ArrayList(Oid) = .empty;
    for (idx_entries.items) |e| oids.append(gpa, e.oid) catch util.oom();
    std.mem.sort(Oid, oids.items, {}, oidLess);
    var b: util.Buf = .empty;
    util.bufAppend(&b, "MTME");
    var w: [4]u8 = undefined;
    std.mem.writeInt(u32, &w, 1, .big);
    util.bufAppend(&b, &w);
    util.bufAppend(&b, &w);
    for (oids.items) |o| {
        std.mem.writeInt(u32, &w, entries.items[index.get(o).?].mtime, .big);
        util.bufAppend(&b, &w);
    }
    util.bufAppend(&b, &sum);
    var h = hash.Hasher.init(.{});
    h.update(b.items);
    var cs: Oid = undefined;
    h.final(&cs);
    util.bufAppend(&b, &cs);
    return b.items;
}

// ---------------------------------------------------------------- --unpack-unreachable

var unpack_expiration: i64 = 0;
var recent_objects: hash.OidSet = .empty;

fn recordRecentCommit(c: *cn.Commit, data: ?*anyopaque) void {
    _ = data;
    recent_objects.put(gpa, c.oid(), {}) catch util.oom();
}
fn recordRecentObject(obj: *cn.Obj, name: []const u8, data: ?*anyopaque) void {
    _ = name;
    _ = data;
    recent_objects.put(gpa, obj.oid, {}) catch util.oom();
}

fn inKeptOrNonlocalPack(oid: Oid) bool {
    for (pack_infos.items) |pi| {
        if ((!pi.local or pi.keep or pi.keep_in_core) and pi.p.find(oid) != null) return true;
    }
    return false;
}

const Utimbuf = extern struct { actime: i64, modtime: i64 };
extern "c" fn utime(path: [*:0]const u8, times: *const Utimbuf) c_int;

/// force_object_loose(): write `oid` as a loose object with the given mtime.
fn forceObjectLoose(oid: Oid, mtime: i64) void {
    for (odb.allDirs()) |dir| {
        if (os.exists(odb.looseObjectPath(dir, oid))) return;
    }
    const o = odb.read(oid) orelse util.die("unable to force loose object", .{});
    const hdr = util.fmt("{s} {d}\x00", .{ o.typ.name(), o.data.len });
    const comp = zlib.compress(util.concat(&.{ hdr, o.data }), odb.compression);
    const path = odb.looseObjectPath(odb.objects_dir, oid);
    const dir = path[0 .. path.len - 39];
    _ = os.mkdirAll(dir);
    const tmp = os.tmpFile(dir, "tmp_obj_");
    if (tmp.fd < 0) util.die("unable to force loose object", .{});
    os.writeAll(tmp.fd, comp) catch util.die("unable to force loose object", .{});
    os.close(tmp.fd);
    _ = os.chmod(tmp.path, 0o444);
    const ut = Utimbuf{ .actime = mtime, .modtime = mtime };
    _ = utime(util.concat(&.{ tmp.path, "\x00" })[0..tmp.path.len :0], &ut);
    if (!os.rename(tmp.path, path)) _ = os.unlink(tmp.path);
}

fn loosenUnusedPackedObjects() void {
    for (pack_infos.items) |pi| {
        if (!pi.local or pi.keep or pi.keep_in_core) continue;
        var j: u32 = 0;
        while (j < pi.p.num) : (j += 1) {
            const oid = pi.p.oidAt(j);
            if (index.contains(oid)) continue;
            if (inKeptOrNonlocalPack(oid)) continue;
            if (unpack_expiration != 0 and pi.mtime <= unpack_expiration and !recent_objects.contains(oid)) continue;
            forceObjectLoose(oid, pi.mtime);
        }
    }
}

fn addTagChain(oid0: Oid) void {
    if (index.get(oid0)) |i| {
        if (!entries.items[i].preferred_base) return;
    }
    var oid = oid0;
    while (true) {
        const o = odb.read(oid) orelse util.die("unable to pack objects reachable from tag {s}", .{hash.hex(oid0)});
        if (o.typ != .tag) util.die("unable to pack objects reachable from tag {s}", .{hash.hex(oid0)});
        const t = objects.parseTag(o.data) orelse util.die("unable to pack objects reachable from tag {s}", .{hash.hex(oid0)});
        addObjectEntry(oid, .tag, null, false);
        if (t.typ != .tag) return;
        oid = t.object;
    }
}

fn inPack(oid: Oid) bool {
    const i = index.get(oid) orelse return false;
    return !entries.items[i].preferred_base;
}

fn addRefTags() void {
    for (refs.iterate("refs/tags/", .{ .check_objects = false })) |r| {
        const p = objects.peel(r.oid) orelse continue;
        if (inPack(p.oid)) addTagChain(r.oid);
    }
}

fn markTagged() void {
    for (refs.iterate("refs/tags/", .{ .check_objects = false })) |r| {
        if (index.get(r.oid)) |i| entries.items[i].tagged = true;
        if (objects.peel(r.oid)) |p| {
            if (index.get(p.oid)) |i| entries.items[i].tagged = true;
        }
    }
}

// ---------------------------------------------------------------- delta search

fn typeRank(t: ObjType) u8 {
    return @intFromEnum(t);
}

fn typeSizeLess(_: void, a: u32, b: u32) bool {
    const ea = &entries.items[a];
    const eb = &entries.items[b];
    if (typeRank(ea.typ) != typeRank(eb.typ)) return typeRank(ea.typ) > typeRank(eb.typ);
    if (ea.name_hash != eb.name_hash) return ea.name_hash > eb.name_hash;
    if (ea.preferred_base != eb.preferred_base) return ea.preferred_base;
    if (ea.size != eb.size) return ea.size > eb.size;
    return a > b;
}

const WinSlot = struct {
    entry: u32,
    data: []const u8,
    di: ?pack.DeltaIndex = null,
    depth: u32,
};

fn objData(i: u32) []const u8 {
    const o = odb.read(entries.items[i].oid) orelse util.die("unable to read {s}", .{hash.hex(entries.items[i].oid)});
    return o.data;
}

fn findDeltas(list: []u32, win: usize, max_depth: u32, prog: ?*progress.Progress) u32 {
    var slots = gpa.alloc(?WinSlot, win + 1) catch util.oom();
    defer gpa.free(slots);
    @memset(slots, null);
    var pos: usize = 0;
    var processed: u32 = 0;
    for (list) |ei| {
        const e = &entries.items[ei];
        const data = objData(ei);
        if (slots[pos]) |*old| {
            if (old.di) |*d| d.deinit();
        }
        slots[pos] = .{ .entry = ei, .data = data, .depth = 0 };
        if (!e.preferred_base) {
            processed += 1;
            progress.update(prog, processed);
        }
        if (!e.preferred_base and !e.no_try_delta and e.size >= 50) {
            // try all other slots
            var best_depth: u32 = 0;
            var k: usize = 1;
            while (k <= win) : (k += 1) {
                const sp = (pos + win + 1 - k) % (win + 1);
                const s = &(slots[sp] orelse continue);
                if (s.entry == ei) continue;
                const src_e = &entries.items[s.entry];
                if (src_e.typ != e.typ) continue;
                if (s.depth >= max_depth) continue;
                const trg_size = e.size;
                var max_size: usize = 0;
                var ref_depth: u32 = 1;
                if (e.delta_data) |dd| {
                    max_size = dd.len;
                    ref_depth = best_depth;
                } else {
                    if (trg_size / 2 <= 20) continue;
                    max_size = trg_size / 2 - 20;
                }
                max_size = @intCast(@as(u64, max_size) * (max_depth - s.depth) / (max_depth - ref_depth + 1));
                if (max_size == 0) continue;
                const src_size = src_e.size;
                const sizediff = if (src_size < trg_size) trg_size - src_size else 0;
                if (sizediff >= max_size) continue;
                if (trg_size < src_size / 32) continue;
                if (s.di == null) s.di = pack.DeltaIndex.init(s.data);
                const d = pack.createDelta(&s.di.?, data, max_size) orelse continue;
                if (e.delta_data) |old| {
                    if (d.len == old.len and s.depth + 1 >= best_depth) {
                        gpa.free(d);
                        continue;
                    }
                    gpa.free(old);
                }
                e.delta_data = d;
                e.delta = s.entry;
                best_depth = s.depth + 1;
            }
            if (e.delta != null) {
                e.depth = best_depth;
                slots[pos].?.depth = best_depth;
            }
        }
        pos = (pos + 1) % (win + 1);
    }
    for (slots) |*s| {
        if (s.*) |*x| {
            if (x.di) |*d| d.deinit();
        }
    }
    return processed;
}

/// Break delta chains that are deeper than allowed after selection (depth of a
/// base can grow if its own base was chosen after it was used).
fn fixDepths(max_depth: u32) void {
    for (entries.items, 0..) |_, i| {
        var d: u32 = 0;
        var cur: u32 = @intCast(i);
        while (entries.items[cur].delta) |b| {
            d += 1;
            cur = b;
            if (d > max_depth + 1) break;
        }
        if (d > max_depth) {
            entries.items[i].delta = null;
            entries.items[i].delta_data = null;
        }
    }
}

// ---------------------------------------------------------------- writing

var writer: pack.Writer = undefined;
var written: u32 = 0;
var written_delta: u32 = 0;
var idx_entries: std.ArrayList(pack.IdxEntry) = .empty;
var level: c_int = 6;
var write_prog: ?*progress.Progress = null;
var pack_size_limit: u64 = 0;
var write_rev = true;
var idx_opts: pack.IdxOpts = .{};
/// current output pack number (1-based); entries written to an earlier
/// pack have written=true and pack_no < cur_pack.
var cur_pack: u32 = 1;
var nr_written: u32 = 0;
/// in-memory pack being built (file output); stdout streams via `writer`.
var packbuf: util.Buf = .empty;
var cur_off: u64 = 0;

fn emit(d: []const u8) void {
    if (pack_to_stdout) writer.write(d) else util.bufAppend(&packbuf, d);
    cur_off += d.len;
}

const WriteRes = enum { skip, brk, written };

fn writeOne(i: u32) WriteRes {
    const e = &entries.items[i];
    if (e.written or e.preferred_base) return .skip;
    if (e.delta) |b| {
        const be = &entries.items[b];
        if (!be.preferred_base and !be.written) {
            // mark to avoid recursion loops
            e.written = true;
            const r = writeOne(b);
            e.written = false;
            if (r == .brk) return .brk;
        }
    }
    const off = cur_off;
    const limit: u64 = if (pack_size_limit == 0 or nr_written == 0) 0 else if (pack_size_limit <= off) 1 else pack_size_limit - off;
    var usable_delta = false;
    var base_here = false;
    if (e.delta) |b| {
        const be = &entries.items[b];
        base_here = be.written and be.pack_no == cur_pack;
        usable_delta = be.preferred_base or base_here;
    }
    var out: util.Buf = .empty;
    var hb: [16]u8 = undefined;
    if (usable_delta) {
        const be = &entries.items[e.delta.?];
        const dd = e.delta_data.?;
        const comp = zlib.compress(dd, level);
        if (!base_here or !allow_ofs_delta) {
            const hl = pack.encodeEntryHeader(&hb, .ref_delta, dd.len);
            util.bufAppend(&out, hb[0..hl]);
            util.bufAppend(&out, &be.oid);
        } else {
            const hl = pack.encodeEntryHeader(&hb, .ofs_delta, dd.len);
            util.bufAppend(&out, hb[0..hl]);
            var ob: [16]u8 = undefined;
            util.bufAppend(&out, pack.encodeOfs(&ob, off - be.offset));
        }
        util.bufAppend(&out, comp);
    } else {
        const data = objData(i);
        const hl = pack.encodeEntryHeader(&hb, e.typ, data.len);
        util.bufAppend(&out, hb[0..hl]);
        util.bufAppend(&out, zlib.compress(data, level));
    }
    if (limit != 0 and out.items.len + @sizeOf(Oid) >= limit) return .brk;
    emit(out.items);
    if (usable_delta) written_delta += 1;
    e.offset = off;
    e.crc = zlib.crc(0, out.items);
    e.written = true;
    e.pack_no = cur_pack;
    written += 1;
    nr_written += 1;
    idx_entries.append(gpa, .{ .oid = e.oid, .offset = off, .crc = e.crc }) catch util.oom();
    progress.update(write_prog, written);
    return .written;
}

/// write_pack_file(): writes one or more packs (several when
/// pack_size_limit splits the output).
fn writePackFiles(base_name: ?[]const u8) void {
    if (progress_level > @as(i32, if (pack_to_stdout) 1 else 0)) write_prog = progress.start("Writing objects", nr_result);
    const wo = computeWriteOrder();
    var nr_remaining: u32 = nr_result;
    var i: usize = 0;
    var last_mtime: i64 = 0;
    while (true) {
        nr_written = 0;
        idx_entries.items.len = 0;
        var h: [12]u8 = undefined;
        @memcpy(h[0..4], "PACK");
        std.mem.writeInt(u32, h[4..8], 2, .big);
        std.mem.writeInt(u32, h[8..12], nr_remaining, .big);
        cur_off = 0;
        if (pack_to_stdout) {
            writer = .{ .fd = 1 };
        } else packbuf.items.len = 0;
        emit(&h);
        while (i < wo.len) : (i += 1) {
            if (writeOne(wo[i]) == .brk) break;
        }
        var sum: Oid = undefined;
        if (pack_to_stdout) {
            sum = writer.finish();
        } else {
            if (nr_written != nr_remaining) {
                std.mem.writeInt(u32, packbuf.items[8..12], nr_written, .big);
                if (write_bitmap_index != 0) {
                    if (write_bitmap_index != 2) util.warn("disabling bitmap writing, packs are split due to pack.packSizeLimit", .{});
                    write_bitmap_index = 0;
                }
            }
            var hs = hash.Hasher.init(.{});
            hs.update(packbuf.items);
            hs.final(&sum);
            util.bufAppend(&packbuf, &sum);
            const pdir = util.concat(&.{ odb.objects_dir, "/pack" });
            _ = os.mkdirAll(pdir);
            const t = os.tmpFile(pdir, "tmp_pack_");
            if (t.fd < 0) util.dieErrno("unable to create temporary file", .{});
            os.writeAll(t.fd, packbuf.items) catch util.dieErrno("write error", .{});
            os.close(t.fd);
            if (os.statPath(t.path)) |st| {
                if (last_mtime == 0) {
                    last_mtime = st.mtime;
                } else {
                    last_mtime -= 1;
                    const ut = Utimbuf{ .actime = st.mtime, .modtime = last_mtime };
                    _ = utime(util.concat(&.{ t.path, "\x00" })[0..t.path.len :0], &ut);
                }
            }
            const prefix = util.concat(&.{ base_name.?, "-", &hash.hex(sum), "." });
            const idx_data = pack.buildIdx(idx_entries.items, sum, idx_opts);
            const pack_final = util.concat(&.{ prefix, "pack" });
            _ = os.chmod(t.path, 0o444);
            if (!os.rename(t.path, pack_final)) util.dieErrno("unable to rename temporary pack file", .{});
            if (write_rev) pack.writeNewFile(util.concat(&.{ prefix, "rev" }), pack.buildRev(idx_entries.items, sum), 0o444);
            if (cruft) pack.writeNewFile(util.concat(&.{ prefix, "mtimes" }), buildMtimes(sum), 0o444);
            pack.writeNewFile(util.concat(&.{ prefix, "idx" }), idx_data, 0o444);
            util.outf("{s}\n", .{hash.hex(sum)});
        }
        cur_pack += 1;
        nr_remaining -= nr_written;
        if (nr_remaining == 0 or i >= wo.len) break;
    }
    if (write_prog) |p| p.stop();
}

fn addToWriteOrder(wo: *std.ArrayList(u32), i: u32) void {
    const e = &entries.items[i];
    if (e.filled or e.preferred_base) return;
    e.filled = true;
    wo.append(gpa, i) catch util.oom();
}

fn addDescendants(wo: *std.ArrayList(u32), start: u32) void {
    var e: ?u32 = start;
    var add = true;
    while (e) |cur| {
        if (add) {
            addToWriteOrder(wo, cur);
            var s = entries.items[cur].delta_sibling;
            while (s) |x| : (s = entries.items[x].delta_sibling) addToWriteOrder(wo, x);
        }
        if (entries.items[cur].delta_child) |ch| {
            add = true;
            e = ch;
        } else {
            add = false;
            if (entries.items[cur].delta_sibling) |sb| {
                e = sb;
                continue;
            }
            var up = entries.items[cur].delta;
            while (up) |u| {
                if (entries.items[u].delta_sibling != null) break;
                up = entries.items[u].delta;
            }
            if (up == null) return;
            e = entries.items[up.?].delta_sibling;
        }
    }
}

fn addFamily(wo: *std.ArrayList(u32), i: u32) void {
    var root = i;
    while (entries.items[root].delta) |b| root = b;
    addDescendants(wo, root);
}

fn computeWriteOrder() []u32 {
    const n = entries.items.len;
    var i: usize = n;
    while (i > 0) {
        i -= 1;
        const e = &entries.items[i];
        if (e.delta) |b| {
            e.delta_sibling = entries.items[b].delta_child;
            entries.items[b].delta_child = @intCast(i);
        }
    }
    markTagged();
    var wo: std.ArrayList(u32) = .empty;
    i = 0;
    while (i < n) : (i += 1) {
        if (entries.items[i].tagged) break;
        addToWriteOrder(&wo, @intCast(i));
    }
    const last_untagged = i;
    while (i < n) : (i += 1) {
        if (entries.items[i].tagged) addToWriteOrder(&wo, @intCast(i));
    }
    i = last_untagged;
    while (i < n) : (i += 1) {
        const t = entries.items[i].typ;
        if (t == .commit or t == .tag) addToWriteOrder(&wo, @intCast(i));
    }
    i = last_untagged;
    while (i < n) : (i += 1) {
        if (entries.items[i].typ == .tree) addToWriteOrder(&wo, @intCast(i));
    }
    i = last_untagged;
    while (i < n) : (i += 1) {
        if (!entries.items[i].filled) addFamily(&wo, @intCast(i));
    }
    return wo.items;
}

fn parseIndexVersion(v: []const u8, opts: *pack.IdxOpts) void {
    var it = std.mem.splitScalar(u8, v, ',');
    const ver = it.next().?;
    opts.version = std.fmt.parseInt(u32, ver, 10) catch util.die("bad index version '{s}'", .{v});
    if (opts.version > 2) util.die("unsupported index version {s}", .{v});
    if (it.next()) |o| {
        opts.off32_limit = std.fmt.parseInt(u64, o, 0) catch util.die("bad index version '{s}'", .{v});
        if (opts.off32_limit & 0x80000000 != 0) util.die("bad index version '{s}'", .{v});
    }
}

pub fn cmdPackObjects(args: []const []const u8) u8 {
    const cfg = &repo_mod.cfg;
    odb = repo_mod.repo().odb();
    idx_opts = .{};
    write_rev = true;
    if (cfg.getBool("pack.writereverseindex")) |b| write_rev = b;
    if (os.getenv("GIT_TEST_NO_WRITE_REV_INDEX")) |v| {
        if (util.eql(v, "1") or util.eql(v, "true")) write_rev = false;
    }
    if (cfg.getInt("pack.window")) |v| window = @intCast(v);
    if (cfg.getInt("pack.depth")) |v| depth = @intCast(v);
    if (cfg.getInt("pack.indexversion")) |v| idx_opts.version = @intCast(v);
    if (cfg.getBool("repack.usedeltabaseoffset")) |_| {}
    progress_level = if (os.isatty(2)) 1 else 0;

    const rest = po.parse(args[1..], &options, &usage, .{});
    var base_name: ?[]const u8 = null;
    var nrest = rest.len;
    if (nrest > 0) {
        base_name = rest[0];
        nrest -= 1;
    }
    if (pack_to_stdout != (base_name == null) or nrest > 0) po.usageWithOptions(&usage, &options);
    if (index_version) |v| parseIndexVersion(v, &idx_opts);
    if (depth < 0) depth = 0;
    if (depth >= 4096) {
        util.warn("delta chain depth {d} is too deep, forcing {d}", .{ depth, 4095 });
        depth = 4095;
    }
    if (window < 0) window = 0;

    var rp: std.ArrayList([]const u8) = .empty;
    if (thin) {
        use_revs = true;
        rp.append(gpa, if (shallow) "--objects-edge-aggressive" else "--objects-edge") catch util.oom();
    } else rp.append(gpa, "--objects") catch util.oom();
    if (rev_all != 0) {
        use_revs = true;
        rp.append(gpa, "--all") catch util.oom();
    }
    if (rev_reflog != 0) {
        use_revs = true;
        rp.append(gpa, "--reflog") catch util.oom();
    }
    if (rev_index != 0) {
        use_revs = true;
        rp.append(gpa, "--indexed-objects") catch util.oom();
    }
    if (rev_unpacked != 0 and stdin_packs == null) {
        use_revs = true;
        rp.append(gpa, "--unpacked") catch util.oom();
    }
    if (exclude_promisor and exclude_promisor_best_effort)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--exclude-promisor-objects", "--exclude-promisor-objects-best-effort" });
    if (exclude_promisor_best_effort) {
        use_revs = true;
        missing_allow_any = true;
    }
    if (missing) |m| {
        if (util.eql(m, "allow-any") or util.eql(m, "allow-promisor")) {
            missing_allow_any = true;
        } else if (!util.eql(m, "error")) util.die("invalid value for '{s}': '{s}'", .{ "--missing", m });
    }
    if (unpack_unreachable != null or keep_unreachable or pack_loose_unreachable) use_revs = true;
    if (cruft_expiration) |ce| {
        cruft = true;
        if (ce.len > 0) cruft_expiration_ts = date.approxidate(ce);
    }
    if (unpack_unreachable) |u| {
        if (u.len > 0) unpack_expiration = date.approxidate(u);
    }
    if (rev_all == 0 or rev_reflog == 0 or rev_index == 0) unpack_expiration = 0;
    if (!reuse_object) reuse_delta = false;
    if (compression == -2) {
        level = pack.packCompressionLevel();
    } else if (compression == -1) {
        level = 6;
    } else if (compression < 0 or compression > 9) {
        util.die("bad pack compression level {d}", .{compression});
    } else level = @intCast(compression);
    if (max_pack_size) |m| {
        const v = config.parseInt(m) orelse -1;
        if (v < 0) {
            util.err("option `{s}' expects a non-negative integer value with an optional k/m/g suffix", .{"max-pack-size"});
            os.exit(129);
        }
        pack_size_limit = @intCast(v);
    }
    if (!pack_to_stdout and pack_size_limit == 0) {
        if (cfg.getInt("pack.packsizelimit")) |v| pack_size_limit = @intCast(@max(v, 0));
    }
    if (pack_to_stdout and pack_size_limit != 0) util.die("--max-pack-size cannot be used to build a pack for transfer", .{});
    if (pack_size_limit != 0 and pack_size_limit < 1024 * 1024) {
        util.warn("minimum pack size limit is 1 MiB", .{});
        pack_size_limit = 1024 * 1024;
    }
    if (!pack_to_stdout and thin) util.die("--thin cannot be used to build an indexable pack", .{});
    if (keep_unreachable and unpack_unreachable != null)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--keep-unreachable", "--unpack-unreachable" });
    if (stdin_packs) |m| {
        if (util.eql(m, "follow")) {
            stdin_packs_follow = true;
        } else if (m.len != 0) util.die("invalid value for '{s}': '{s}'", .{ "stdin-packs", m });
        if (filter != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--stdin-packs", "--filter" });
    }
    if (stdin_packs != null and use_revs) util.die("cannot use internal rev list with --stdin-packs", .{});
    if (cruft and use_revs) util.die("cannot use internal rev list with --cruft", .{});
    if (cruft and stdin_packs != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--stdin-packs", "--cruft" });
    if (progress_level != 0 and all_progress_implied) progress_level = 2;
    if (missing_allow_any) {}

    loadPackInfos();

    if (progress_level != 0 and !cruft) enum_progress = progress.start("Enumerating objects", 0);
    if (stdin_packs != null) {
        readStdinPacks();
    } else if (cruft) {
        readCruftObjects();
    } else if (!use_revs) {
        readObjectListFromStdin();
    } else {
        getObjectList(rp.items);
    }
    addPreferredBases();
    if (include_tag and nr_result > 0) addRefTags();
    if (enum_progress) |p| {
        p.stop();
        enum_progress = null;
    }

    if (non_empty and nr_result == 0) return 0;

    // delta search
    var delta_list: std.ArrayList(u32) = .empty;
    for (entries.items, 0..) |e, i| {
        if (e.preferred_base) {
            delta_list.append(gpa, @intCast(i)) catch util.oom();
            continue;
        }
        if (e.size < 50) continue;
        delta_list.append(gpa, @intCast(i)) catch util.oom();
    }
    var nr_deltas: u32 = 0;
    for (delta_list.items) |i| {
        if (!entries.items[i].preferred_base) nr_deltas += 1;
    }
    if (window > 0 and nr_deltas > 0) {
        std.mem.sort(u32, delta_list.items, {}, typeSizeLess);
        var cprog: ?*progress.Progress = null;
        if (progress_level != 0) {
            const nthreads: i32 = if (threads > 0) threads else @intCast(std.Thread.getCpuCount() catch 1);
            util.eprint("Delta compression using up to {d} threads\n", .{nthreads});
            cprog = progress.start("Compressing objects", nr_deltas);
        }
        _ = findDeltas(delta_list.items, @intCast(window), @intCast(depth), cprog);
        fixDepths(@intCast(depth));
        if (cprog) |p| p.stop();
    }

    // write
    writePackFiles(base_name);
    if (progress_level != 0) {
        util.eprint("Total {d} (delta {d}), reused {d} (delta {d}), pack-reused {d} (from {d})\n", .{ written, written_delta, 0, 0, 0, 0 });
    }
    return 0;
}
