//! Thin libc layer. Everything that touches the operating system goes through here.

const std = @import("std");
const c = std.c;
const util = @import("util.zig");
const gpa = util.gpa;

pub const Stat = extern struct {
    dev: u64,
    ino: u64,
    nlink: u64,
    mode: u32,
    uid: u32,
    gid: u32,
    __pad0: i32 = 0,
    rdev: u64,
    size: i64,
    blksize: i64,
    blocks: i64,
    atime: i64,
    atime_ns: i64,
    mtime: i64,
    mtime_ns: i64,
    ctime: i64,
    ctime_ns: i64,
    __unused: [3]i64,

    pub fn isDir(self: Stat) bool {
        return self.mode & S_IFMT == S_IFDIR;
    }
    pub fn isReg(self: Stat) bool {
        return self.mode & S_IFMT == S_IFREG;
    }
    pub fn isLnk(self: Stat) bool {
        return self.mode & S_IFMT == S_IFLNK;
    }
};

pub const S_IFMT: u32 = 0o170000;
pub const S_IFDIR: u32 = 0o040000;
pub const S_IFREG: u32 = 0o100000;
pub const S_IFLNK: u32 = 0o120000;
pub const S_IFGITLINK: u32 = 0o160000;

const Dirent = extern struct { ino: u64, off: i64, reclen: u16, typ: u8, name: [256]u8 };

extern "c" fn lstat(path: [*:0]const u8, st: *Stat) c_int;
extern "c" fn stat(path: [*:0]const u8, st: *Stat) c_int;
extern "c" fn fstat(fd: c_int, st: *Stat) c_int;
extern "c" fn readdir(d: *anyopaque) ?*Dirent;
extern "c" fn opendir(p: [*:0]const u8) ?*anyopaque;
extern "c" fn closedir(d: *anyopaque) c_int;
extern "c" fn __errno_location() *c_int;
extern "c" fn strerror(e: c_int) [*:0]const u8;
extern "c" fn fork() c_int;
extern "c" fn execvp(file: [*:0]const u8, argv: [*:null]const ?[*:0]const u8) c_int;
extern "c" fn setenv(name: [*:0]const u8, value: [*:0]const u8, overwrite: c_int) c_int;
extern "c" fn unsetenv(name: [*:0]const u8) c_int;
extern "c" fn time(t: ?*i64) i64;
extern "c" fn mkstemp(template: [*:0]u8) c_int;
extern "c" fn realpath(path: [*:0]const u8, resolved: ?[*]u8) ?[*:0]u8;
extern "c" fn gettimeofday(tv: *[2]i64, tz: ?*anyopaque) c_int;
extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn localtime_r(t: *const i64, tm: *Tm) ?*Tm;
extern "c" fn gmtime_r(t: *const i64, tm: *Tm) ?*Tm;
extern "c" fn mktime(tm: *Tm) i64;
extern "c" fn timegm(tm: *Tm) i64;
extern "c" fn tzset() void;
pub extern "c" var environ: [*:null]?[*:0]u8;

pub const Tm = extern struct {
    sec: c_int,
    min: c_int,
    hour: c_int,
    mday: c_int,
    mon: c_int,
    year: c_int,
    wday: c_int,
    yday: c_int,
    isdst: c_int,
    gmtoff: c_long,
    zone: ?[*:0]const u8,
};

pub fn localtime(t: i64) Tm {
    var tm: Tm = undefined;
    _ = localtime_r(&t, &tm);
    return tm;
}
pub fn gmtime(t: i64) Tm {
    var tm: Tm = undefined;
    _ = gmtime_r(&t, &tm);
    return tm;
}
pub fn mkTime(tm: *Tm) i64 {
    return mktime(tm);
}
pub fn timeGm(tm: *Tm) i64 {
    return timegm(tm);
}

pub fn errno() c_int {
    return __errno_location().*;
}
pub fn setErrno(e: c_int) void {
    __errno_location().* = e;
}
pub fn strErr(e: c_int) []const u8 {
    return std.mem.span(strerror(e));
}
pub fn lastErr() []const u8 {
    return strErr(errno());
}

pub const ENOENT = 2;
pub const EEXIST = 17;
pub const ENOTDIR = 20;
pub const EISDIR = 21;
pub const EINTR = 4;
pub const ENOTEMPTY = 39;
pub const EACCES = 13;

pub fn now() i64 {
    return time(null);
}

pub fn nowMicros() i64 {
    var tv: [2]i64 = undefined;
    _ = gettimeofday(&tv, null);
    return tv[0] * 1000000 + tv[1];
}

/// Null-terminated copy of a path (temporary, leaked into the arena).
pub fn z(path: []const u8) [*:0]const u8 {
    const buf = gpa.allocSentinel(u8, path.len, 0) catch util.oom();
    @memcpy(buf, path);
    return buf.ptr;
}

pub fn lstatPath(path: []const u8) ?Stat {
    var st: Stat = undefined;
    if (lstat(z(path), &st) != 0) return null;
    return st;
}
pub fn statPath(path: []const u8) ?Stat {
    var st: Stat = undefined;
    if (stat(z(path), &st) != 0) return null;
    return st;
}
pub fn fstatFd(fd: c_int) ?Stat {
    var st: Stat = undefined;
    if (fstat(fd, &st) != 0) return null;
    return st;
}

pub fn exists(path: []const u8) bool {
    return lstatPath(path) != null;
}
pub fn isDir(path: []const u8) bool {
    const st = statPath(path) orelse return false;
    return st.isDir();
}
pub fn isFile(path: []const u8) bool {
    const st = statPath(path) orelse return false;
    return st.isReg();
}

pub const O_RDONLY = 0;
pub const O_WRONLY = 1;
pub const O_RDWR = 2;
pub const O_CREAT = 0o100;
pub const O_EXCL = 0o200;
pub const O_TRUNC = 0o1000;
pub const O_APPEND = 0o2000;
pub const O_CLOEXEC = 0o2000000;
pub const O_NOFOLLOW = 0o400000;

extern "c" fn open(path: [*:0]const u8, flags: c_int, ...) c_int;

pub fn openFile(path: []const u8, flags: c_int, mode: c_uint) c_int {
    return open(z(path), flags, mode);
}

pub fn close(fd: c_int) void {
    _ = c.close(fd);
}

pub fn readAllFd(fd: c_int) ![]u8 {
    var list: std.ArrayList(u8) = .empty;
    var buf: [65536]u8 = undefined;
    while (true) {
        const n = c.read(fd, &buf, buf.len);
        if (n < 0) {
            if (errno() == EINTR) continue;
            return error.ReadFailed;
        }
        if (n == 0) break;
        try list.appendSlice(gpa, buf[0..@intCast(n)]);
    }
    return list.items;
}

/// Read a whole file. Returns null if it cannot be opened.
pub fn readFile(path: []const u8) ?[]u8 {
    const fd = openFile(path, O_RDONLY | O_CLOEXEC, 0);
    if (fd < 0) return null;
    defer close(fd);
    if (fstatFd(fd)) |st| {
        if (st.isDir()) {
            setErrno(EISDIR);
            return null;
        }
        if (st.isReg() and st.size > 0) {
            const size: usize = @intCast(st.size);
            const buf = gpa.alloc(u8, size) catch util.oom();
            var off: usize = 0;
            while (off < size) {
                const n = c.read(fd, buf.ptr + off, size - off);
                if (n < 0) {
                    if (errno() == EINTR) continue;
                    return null;
                }
                if (n == 0) break;
                off += @intCast(n);
            }
            if (off < size) return buf[0..off];
            // file may have grown
            const rest = readAllFd(fd) catch return null;
            if (rest.len == 0) return buf;
            const all = gpa.alloc(u8, size + rest.len) catch util.oom();
            @memcpy(all[0..size], buf);
            @memcpy(all[size..], rest);
            return all;
        }
    }
    return readAllFd(fd) catch null;
}

pub fn writeAll(fd: c_int, data: []const u8) !void {
    var off: usize = 0;
    while (off < data.len) {
        const n = c.write(fd, data.ptr + off, data.len - off);
        if (n < 0) {
            if (errno() == EINTR) continue;
            return error.WriteFailed;
        }
        off += @intCast(n);
    }
}

pub fn writeFile(path: []const u8, data: []const u8, mode: c_uint) !void {
    const fd = openFile(path, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, mode);
    if (fd < 0) return error.OpenFailed;
    defer close(fd);
    try writeAll(fd, data);
}

pub fn appendFile(path: []const u8, data: []const u8) !void {
    const fd = openFile(path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0o666);
    if (fd < 0) return error.OpenFailed;
    defer close(fd);
    try writeAll(fd, data);
}

pub fn mkdir(path: []const u8, mode: c_uint) bool {
    return c.mkdir(z(path), @intCast(mode)) == 0;
}

/// mkdir -p for the leading directories of `path` (not path itself).
pub fn mkdirLeading(path: []const u8) bool {
    var i: usize = 1;
    while (i < path.len) : (i += 1) {
        if (path[i] == '/') {
            const d = path[0..i];
            if (!mkdir(d, 0o777)) {
                const e = errno();
                if (e != EEXIST) {
                    return false;
                }
                // EEXIST but may be a file
                if (!isDir(d)) {
                    // A symlink to a dir is OK, a regular file is not
                    return false;
                }
            }
        }
    }
    return true;
}

pub fn mkdirAll(path: []const u8) bool {
    if (isDir(path)) return true;
    if (!mkdirLeading(path)) return false;
    if (!mkdir(path, 0o777)) return errno() == EEXIST and isDir(path);
    return true;
}

pub fn unlink(path: []const u8) bool {
    return c.unlink(z(path)) == 0;
}
pub fn rmdir(path: []const u8) bool {
    return c.rmdir(z(path)) == 0;
}
pub fn rename(from: []const u8, to: []const u8) bool {
    return c.rename(z(from), z(to)) == 0;
}
pub fn symlink(target: []const u8, path: []const u8) bool {
    return c.symlink(z(target), z(path)) == 0;
}
pub fn link(from: []const u8, to: []const u8) bool {
    return c.link(z(from), z(to)) == 0;
}
pub fn chmod(path: []const u8, mode: c_uint) bool {
    return c.chmod(z(path), @intCast(mode)) == 0;
}
pub fn chdir(path: []const u8) bool {
    return c.chdir(z(path)) == 0;
}
pub fn access(path: []const u8, mode: c_int) bool {
    return c.access(z(path), @intCast(mode)) == 0;
}

pub fn readLink(path: []const u8) ?[]u8 {
    var buf: [4096]u8 = undefined;
    const n = c.readlink(z(path), &buf, buf.len);
    if (n < 0) return null;
    return gpa.dupe(u8, buf[0..@intCast(n)]) catch util.oom();
}

pub fn getcwd() []u8 {
    var buf: [4096]u8 = undefined;
    const p = c.getcwd(&buf, buf.len) orelse util.die("unable to get current working directory", .{});
    return gpa.dupe(u8, std.mem.span(@as([*:0]u8, @ptrCast(p)))) catch util.oom();
}

pub fn realPath(path: []const u8) ?[]u8 {
    var buf: [4097]u8 = undefined;
    const p = realpath(z(path), &buf) orelse return null;
    return gpa.dupe(u8, std.mem.span(p)) catch util.oom();
}

pub fn getenv(name: []const u8) ?[]const u8 {
    const p = c.getenv(z(name)) orelse return null;
    return std.mem.span(p);
}
pub fn setEnv(name: []const u8, value: []const u8) void {
    _ = setenv(z(name), z(value), 1);
}
pub fn unsetEnv(name: []const u8) void {
    _ = unsetenv(z(name));
}

pub fn isatty(fd: c_int) bool {
    return c.isatty(fd) != 0;
}

pub const DirEntry = struct {
    name: []const u8,
    typ: u8, // DT_*
};
pub const DT_UNKNOWN = 0;
pub const DT_DIR = 4;
pub const DT_REG = 8;
pub const DT_LNK = 10;

/// List directory entries (excluding . and ..). Returns null if not a directory.
pub fn listDir(path: []const u8) ?[]DirEntry {
    const d = opendir(z(if (path.len == 0) "." else path)) orelse return null;
    defer _ = closedir(d);
    var list: std.ArrayList(DirEntry) = .empty;
    while (readdir(d)) |e| {
        const nm = std.mem.sliceTo(@as([*:0]const u8, @ptrCast(&e.name)), 0);
        if (std.mem.eql(u8, nm, ".") or std.mem.eql(u8, nm, "..")) continue;
        list.append(gpa, .{ .name = gpa.dupe(u8, nm) catch util.oom(), .typ = e.typ }) catch util.oom();
    }
    return list.items;
}

/// rm -rf
pub fn removeTree(path: []const u8) void {
    const st = lstatPath(path) orelse return;
    if (st.isDir()) {
        if (listDir(path)) |ents| {
            for (ents) |e| {
                removeTree(util.joinPath(path, e.name));
            }
        }
        _ = rmdir(path);
    } else {
        _ = unlink(path);
    }
}

/// Remove empty parent directories of `path` up to (but excluding) `stop`.
pub fn removeEmptyParents(path: []const u8, stop_len: usize) void {
    var p = path;
    while (std.mem.lastIndexOfScalar(u8, p, '/')) |idx| {
        if (idx <= stop_len) break;
        p = p[0..idx];
        if (!rmdir(p)) break;
    }
}

pub fn exit(code: u8) noreturn {
    @import("trace2.zig").cmdExit(code);
    @import("lockfile.zig").cleanupAll();
    util.flushStdout();
    waitPager();
    @import("trace2.zig").atexit();
    c.exit(code);
}

// ---------------- processes ----------------

pub const ChildResult = struct {
    status: u8,
    signaled: bool = false,
    stdout: []u8 = &.{},
};

pub const SpawnOpts = struct {
    stdin_data: ?[]const u8 = null,
    capture_stdout: bool = false,
    stdout_to_stderr: bool = false,
    no_stderr: bool = false,
    no_stdin: bool = false,
    cwd: ?[]const u8 = null,
    env: []const [2][]const u8 = &.{},
    unset_env: []const []const u8 = &.{},
    use_shell: bool = false,
};

fn waitChild(pid: c_int) ChildResult {
    var status: c_int = 0;
    while (true) {
        const r = c.waitpid(pid, &status, 0);
        if (r < 0 and errno() == EINTR) continue;
        break;
    }
    const st: u32 = @bitCast(status);
    if (st & 0x7f == 0) {
        return .{ .status = @intCast((st >> 8) & 0xff) };
    }
    return .{ .status = @intCast(128 + (st & 0x7f)), .signaled = true };
}

/// Run a command. argv[0] is looked up in PATH. If use_shell, argv[0] is a shell snippet
/// run with sh -c, with the remaining args as positional parameters.
pub fn run(argv_in: []const []const u8, opts: SpawnOpts) ChildResult {
    util.flushStdout();
    var argv_list: std.ArrayList([]const u8) = .empty;
    if (opts.use_shell) {
        const cmd = argv_in[0];
        // Like git's prepare_shell_cmd: if no shell metachars and no args, run directly
        if (std.mem.indexOfAny(u8, cmd, "|&;<>()$`\\\"' \t\n*?[#~=%") == null) {
            argv_list.appendSlice(gpa, argv_in) catch util.oom();
        } else {
            argv_list.append(gpa, "/bin/sh") catch util.oom();
            argv_list.append(gpa, "-c") catch util.oom();
            if (argv_in.len > 1) {
                argv_list.append(gpa, util.concat(&.{ cmd, " \"$@\"" })) catch util.oom();
            } else {
                argv_list.append(gpa, cmd) catch util.oom();
            }
            argv_list.appendSlice(gpa, argv_in) catch util.oom();
        }
    } else {
        argv_list.appendSlice(gpa, argv_in) catch util.oom();
    }
    const cargv = gpa.allocSentinel(?[*:0]const u8, argv_list.items.len, null) catch util.oom();
    for (argv_list.items, 0..) |a, i| cargv[i] = z(a);

    var in_pipe: [2]c_int = .{ -1, -1 };
    var out_pipe: [2]c_int = .{ -1, -1 };
    if (opts.stdin_data != null) _ = c.pipe(&in_pipe);
    if (opts.capture_stdout) _ = c.pipe(&out_pipe);

    const pid = fork();
    if (pid < 0) util.die("fork failed: {s}", .{lastErr()});
    if (pid == 0) {
        if (opts.stdin_data != null) {
            _ = c.dup2(in_pipe[0], 0);
            _ = c.close(in_pipe[0]);
            _ = c.close(in_pipe[1]);
        } else if (opts.no_stdin) {
            const fd = open("/dev/null", O_RDONLY);
            _ = c.dup2(fd, 0);
            _ = c.close(fd);
        }
        if (opts.capture_stdout) {
            _ = c.dup2(out_pipe[1], 1);
            _ = c.close(out_pipe[0]);
            _ = c.close(out_pipe[1]);
        } else if (opts.stdout_to_stderr) {
            _ = c.dup2(2, 1);
        }
        if (opts.no_stderr) {
            const fd2 = open("/dev/null", O_WRONLY);
            _ = c.dup2(fd2, 2);
            _ = c.close(fd2);
        }
        if (opts.cwd) |d| {
            if (d.len > 0 and c.chdir(z(d)) != 0) c._exit(127);
        }
        for (opts.unset_env) |n| _ = unsetenv(z(n));
        for (opts.env) |kv| _ = setenv(z(kv[0]), z(kv[1]), 1);
        _ = execvp(cargv[0].?, cargv.ptr);
        const e = errno();
        if (e == ENOENT) {
            util.eprint("error: cannot run {s}: No such file or directory\n", .{argv_list.items[0]});
            c._exit(127);
        }
        util.eprint("error: cannot exec '{s}': {s}\n", .{ argv_list.items[0], strErr(e) });
        c._exit(126);
    }
    if (opts.stdin_data) |data| {
        _ = c.close(in_pipe[0]);
        // ignore SIGPIPE while writing
        const old = signal(13, 1);
        if (opts.capture_stdout) {
            // avoid deadlock: write in a forked writer
            const wpid = fork();
            if (wpid == 0) {
                _ = c.close(out_pipe[0]);
                writeAll(in_pipe[1], data) catch {};
                c._exit(0);
            }
            _ = c.close(in_pipe[1]);
            _ = c.close(out_pipe[1]);
            const out = readAllFd(out_pipe[0]) catch @constCast(&[_]u8{});
            _ = c.close(out_pipe[0]);
            _ = waitChild(wpid);
            var r = waitChild(pid);
            _ = signal(13, old);
            r.stdout = out;
            return r;
        }
        writeAll(in_pipe[1], data) catch {};
        _ = c.close(in_pipe[1]);
        _ = signal(13, old);
    }
    if (opts.capture_stdout) {
        _ = c.close(out_pipe[1]);
        const out = readAllFd(out_pipe[0]) catch @constCast(&[_]u8{});
        _ = c.close(out_pipe[0]);
        var r = waitChild(pid);
        r.stdout = out;
        return r;
    }
    return waitChild(pid);
}

pub fn ignoreSigpipe() void {
    _ = signal(13, 1);
}

pub fn tmpFile(dir: []const u8, prefix: []const u8) struct { fd: c_int, path: []u8 } {
    const tmpl = gpa.allocSentinel(u8, dir.len + 1 + prefix.len + 6, 0) catch util.oom();
    @memcpy(tmpl[0..dir.len], dir);
    tmpl[dir.len] = '/';
    @memcpy(tmpl[dir.len + 1 ..][0..prefix.len], prefix);
    @memcpy(tmpl[dir.len + 1 + prefix.len ..][0..6], "XXXXXX");
    const fd = mkstemp(tmpl.ptr);
    return .{ .fd = fd, .path = tmpl[0..tmpl.len] };
}

// ---------------- pager ----------------

pub var pager_pid: c_int = 0;

pub fn startPager(cmd: []const u8) void {
    var pipefd: [2]c_int = undefined;
    if (c.pipe(&pipefd) != 0) return;
    util.flushStdout();
    const pid = fork();
    if (pid < 0) return;
    if (pid == 0) {
        _ = c.dup2(pipefd[0], 0);
        _ = c.close(pipefd[0]);
        _ = c.close(pipefd[1]);
        if (getenv("LESS") == null) _ = setenv("LESS", "FRX", 1);
        if (getenv("LV") == null) _ = setenv("LV", "-c", 1);
        const argv = [_:null]?[*:0]const u8{ "/bin/sh", "-c", z(cmd), null };
        _ = execvp("/bin/sh", &argv);
        c._exit(127);
    }
    _ = c.dup2(pipefd[1], 1);
    if (isatty(2)) _ = c.dup2(pipefd[1], 2);
    _ = c.close(pipefd[0]);
    _ = c.close(pipefd[1]);
    pager_pid = pid;
}

pub fn waitPager() void {
    if (pager_pid == 0) return;
    util.flushStdout();
    _ = c.close(1);
    _ = c.close(2);
    _ = waitChild(pager_pid);
    pager_pid = 0;
}
