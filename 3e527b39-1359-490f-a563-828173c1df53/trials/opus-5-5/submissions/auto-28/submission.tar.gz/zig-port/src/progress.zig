//! Minimal port of progress.c (no timer: counters without a total are only
//! shown in the final ", done." line).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const gpa = util.gpa;

pub const Progress = struct {
    title: []const u8,
    total: u64,
    last_value: i64 = -1,
    last_percent: i64 = -1,
    sparse: bool = false,
    counters_len: usize = 0,
    suppressed: bool = false,

    fn display(self: *Progress, n: u64, done: ?[]const u8, force: bool) void {
        if (self.suppressed) return;
        self.last_value = @intCast(n);
        var counters: util.Buf = .empty;
        var show = false;
        if (self.total > 0) {
            const percent: i64 = @intCast(n * 100 / self.total);
            if (percent != self.last_percent or force) {
                self.last_percent = percent;
                util.bufPrint(&counters, "{d: >3}% ({d}/{d})", .{ @as(u64, @intCast(percent)), n, self.total });
                show = true;
            }
        } else if (force) {
            util.bufPrint(&counters, "{d}", .{n});
            show = true;
        }
        if (!show) return;
        const eol = done orelse "\r";
        const clear_len: usize = if (counters.items.len < self.counters_len) self.counters_len - counters.items.len + 1 else 0;
        self.counters_len = counters.items.len;
        var line: util.Buf = .empty;
        util.bufPrint(&line, "{s}: {s}", .{ self.title, counters.items });
        var k: usize = eol.len;
        while (k < clear_len) : (k += 1) util.bufByte(&line, ' ');
        util.bufAppend(&line, eol);
        util.ewrite(line.items);
    }

    pub fn update(self: *Progress, n: u64) void {
        self.display(n, null, false);
    }

    pub fn stop(self: *Progress) void {
        self.stopMsg("done");
    }

    pub fn stopMsg(self: *Progress, msg: []const u8) void {
        if (self.sparse and self.last_value != @as(i64, @intCast(self.total))) self.display(self.total, null, false);
        if (self.last_value != -1) {
            self.display(@intCast(self.last_value), util.fmt(", {s}.\n", .{msg}), true);
        }
    }
};

pub fn start(title: []const u8, total: u64) *Progress {
    const p = gpa.create(Progress) catch util.oom();
    p.* = .{ .title = title, .total = total };
    return p;
}

pub fn startSparse(title: []const u8, total: u64) *Progress {
    const p = start(title, total);
    p.sparse = true;
    return p;
}

/// start_delayed_progress: we have no timer, so unless GIT_PROGRESS_DELAY=0
/// the meter never becomes visible (git's default delay is 2 seconds).
pub fn startDelayed(title: []const u8, total: u64) *Progress {
    const p = start(title, total);
    const d = os.getenv("GIT_PROGRESS_DELAY") orelse "2";
    if (!util.eql(d, "0")) p.suppressed = true;
    return p;
}

pub fn update(p: ?*Progress, n: u64) void {
    if (p) |x| x.update(n);
}

pub fn stop(p: *?*Progress) void {
    if (p.*) |x| x.stop();
    p.* = null;
}
