//! Object database: loose objects, packfiles, alternates.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const zlib = @import("zlib.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const ObjType = enum(u3) {
    none = 0,
    commit = 1,
    tree = 2,
    blob = 3,
    tag = 4,
    ofs_delta = 6,
    ref_delta = 7,

    pub fn name(self: ObjType) []const u8 {
        return switch (self) {
            .commit => "commit",
            .tree => "tree",
            .blob => "blob",
            .tag => "tag",
            else => "bad",
        };
    }
    pub fn fromName(s: []const u8) ?ObjType {
        if (util.eql(s, "commit")) return .commit;
        if (util.eql(s, "tree")) return .tree;
        if (util.eql(s, "blob")) return .blob;
        if (util.eql(s, "tag")) return .tag;
        return null;
    }
};

pub const Object = struct {
    typ: ObjType,
    data: []const u8,
};

pub const Pack = struct {
    idx_path: []const u8,
    pack_path: []const u8,
    idx: []const u8,
    pack: ?[]const u8 = null,
    num: u32,
    version: u32,
    fanout_off: usize,

    fn loadPack(self: *Pack) ?[]const u8 {
        if (self.pack == null) {
            self.pack = os.readFile(self.pack_path);
        }
        return self.pack;
    }

    fn fanout(self: *const Pack, i: usize) u32 {
        return std.mem.readInt(u32, self.idx[self.fanout_off + i * 4 ..][0..4], .big);
    }

    pub fn oidAt(self: *const Pack, i: u32) Oid {
        if (self.version == 2) {
            const off = 8 + 1024 + @as(usize, i) * 20;
            return self.idx[off..][0..20].*;
        } else {
            const off = 1024 + @as(usize, i) * 24 + 4;
            return self.idx[off..][0..20].*;
        }
    }

    pub fn offsetAt(self: *const Pack, i: u32) u64 {
        if (self.version == 2) {
            const n: usize = self.num;
            const base = 8 + 1024 + n * 20 + n * 4;
            const v = std.mem.readInt(u32, self.idx[base + @as(usize, i) * 4 ..][0..4], .big);
            if (v & 0x80000000 != 0) {
                const big = base + n * 4 + @as(usize, v & 0x7fffffff) * 8;
                return std.mem.readInt(u64, self.idx[big..][0..8], .big);
            }
            return v;
        } else {
            const off = 1024 + @as(usize, i) * 24;
            return std.mem.readInt(u32, self.idx[off..][0..4], .big);
        }
    }

    pub fn find(self: *const Pack, oid: Oid) ?u32 {
        var lo: u32 = if (oid[0] == 0) 0 else self.fanout(oid[0] - 1);
        var hi: u32 = self.fanout(oid[0]);
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            const o = self.oidAt(mid);
            switch (hash.order(oid, o)) {
                .eq => return mid,
                .lt => hi = mid,
                .gt => lo = mid + 1,
            }
        }
        return null;
    }

    /// First index whose oid >= prefix bytes
    pub fn lowerBound(self: *const Pack, oid: Oid) u32 {
        var lo: u32 = if (oid[0] == 0) 0 else self.fanout(oid[0] - 1);
        var hi: u32 = self.fanout(oid[0]);
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            const o = self.oidAt(mid);
            if (hash.order(o, oid) == .lt) lo = mid + 1 else hi = mid;
        }
        return lo;
    }
};

pub const Odb = struct {
    objects_dir: []const u8,
    alternates: std.ArrayList([]const u8) = .empty,
    packs: std.ArrayList(*Pack) = .empty,
    packs_loaded: bool = false,
    cache: hash.OidMap(Object) = .empty,
    compression: c_int = 1,
    /// Replace-object map (refs/replace/*), loaded lazily.
    replace_map: ?hash.OidMap(Oid) = null,

    pub fn init(objects_dir: []const u8) *Odb {
        const o = gpa.create(Odb) catch util.oom();
        o.* = .{ .objects_dir = objects_dir };
        o.loadAlternates(objects_dir, 0);
        if (os.getenv("GIT_ALTERNATE_OBJECT_DIRECTORIES")) |alts| {
            var it = std.mem.splitScalar(u8, alts, ':');
            while (it.next()) |a| {
                if (a.len > 0) o.alternates.append(gpa, util.dupe(a)) catch util.oom();
            }
        }
        return o;
    }

    fn loadAlternates(self: *Odb, dir: []const u8, depth: u32) void {
        if (depth > 5) return;
        const data = os.readFile(util.concat(&.{ dir, "/info/alternates" })) orelse return;
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line0| {
            const line = util.trimRight(line0);
            if (line.len == 0 or line[0] == '#') continue;
            var p: []const u8 = line;
            if (p[0] != '/') p = util.joinPath(dir, p);
            const real = os.realPath(p) orelse p;
            var dup = false;
            for (self.alternates.items) |a| {
                if (util.eql(a, real)) dup = true;
            }
            if (dup or util.eql(real, os.realPath(self.objects_dir) orelse self.objects_dir)) continue;
            self.alternates.append(gpa, real) catch util.oom();
            self.loadAlternates(real, depth + 1);
        }
    }

    pub fn allDirs(self: *Odb) []const []const u8 {
        var l: std.ArrayList([]const u8) = .empty;
        l.append(gpa, self.objects_dir) catch util.oom();
        l.appendSlice(gpa, self.alternates.items) catch util.oom();
        return l.items;
    }

    pub fn reloadPacks(self: *Odb) void {
        self.packs_loaded = false;
        self.packs.clearRetainingCapacity();
        self.loadPacks();
    }

    pub fn loadPacks(self: *Odb) void {
        if (self.packs_loaded) return;
        self.packs_loaded = true;
        for (self.allDirs()) |dir| {
            const pdir = util.concat(&.{ dir, "/pack" });
            const ents = os.listDir(pdir) orelse continue;
            // sort by mtime desc is what git does; we just sort by name for determinism
            for (ents) |e| {
                if (!util.endsWith(e.name, ".idx")) continue;
                const idx_path = util.concat(&.{ pdir, "/", e.name });
                const pack_path = util.concat(&.{ pdir, "/", e.name[0 .. e.name.len - 4], ".pack" });
                if (!os.exists(pack_path)) continue;
                if (openIdx(idx_path, pack_path)) |p| self.packs.append(gpa, p) catch util.oom();
            }
        }
    }

    pub fn looseObjectPath(self: *Odb, dir: []const u8, oid: Oid) []u8 {
        _ = self;
        const h = hash.hex(oid);
        return util.concat(&.{ dir, "/", h[0..2], "/", h[2..] });
    }

    pub fn hasLoose(self: *Odb, oid: Oid) bool {
        for (self.allDirs()) |dir| {
            if (os.exists(self.looseObjectPath(dir, oid))) return true;
        }
        return false;
    }

    pub fn findPacked(self: *Odb, oid: Oid) ?struct { pack: *Pack, idx: u32 } {
        self.loadPacks();
        for (self.packs.items) |p| {
            if (p.find(oid)) |i| return .{ .pack = p, .idx = i };
        }
        return null;
    }

    pub fn has(self: *Odb, oid: Oid) bool {
        if (self.cache.contains(oid)) return true;
        if (self.hasLoose(oid)) return true;
        if (self.findPacked(oid) != null) return true;
        // maybe a new pack appeared
        if (self.packs_loaded) {
            self.reloadPacks();
            if (self.findPacked(oid) != null) return true;
        }
        return false;
    }


    fn prepareReplaceMap(self: *Odb) *hash.OidMap(Oid) {
        if (self.replace_map == null) {
            self.replace_map = .empty;
            const refs_mod = @import("refs.zig");
            const base = replaceRefBase();
            for (refs_mod.iterate(base, .{ .check_objects = false })) |r| {
                const slash = std.mem.lastIndexOfScalar(u8, r.name, '/');
                const h = if (slash) |s| r.name[s + 1 ..] else r.name;
                const orig = hash.fromHex(h) orelse {
                    util.warn("bad replace ref name: {s}", .{r.name});
                    continue;
                };
                const gop = self.replace_map.?.getOrPut(gpa, orig) catch util.oom();
                if (gop.found_existing) util.die("duplicate replace ref: {s}", .{r.name});
                gop.value_ptr.* = r.oid;
            }
        }
        return &self.replace_map.?;
    }

    /// Follow refs/replace/ for oid when replacement is enabled.
    pub fn lookupReplace(self: *Odb, oid: Oid) Oid {
        if (!replaceRefsEnabled()) return oid;
        const map = self.prepareReplaceMap();
        if (map.count() == 0) return oid;
        var cur = oid;
        var depth: u32 = 5;
        while (depth > 0) : (depth -= 1) {
            cur = map.get(cur) orelse return cur;
        }
        util.die("replace depth too high for object {s}", .{hash.hex(oid)});
    }

    /// Like read() but never follows replace refs.
    pub fn readNoReplace(self: *Odb, oid: Oid) ?Object {
        if (self.cache.get(oid)) |o| return o;
        const obj = self.readUncached(oid) orelse return null;
        self.cache.put(gpa, oid, obj) catch util.oom();
        return obj;
    }

    pub fn read(self: *Odb, oid: Oid) ?Object {
        const real = self.lookupReplace(oid);
        if (!hash.eql(real, oid)) {
            return self.readNoReplace(real) orelse util.die("replacement {s} not found for {s}", .{ hash.hex(real), hash.hex(oid) });
        }
        return self.readNoReplace(oid);
    }

    fn readUncached(self: *Odb, oid: Oid) ?Object {
        if (util.eql(&hash.hex(oid), hash.empty_tree_hex)) return .{ .typ = .tree, .data = "" };
        for (self.allDirs()) |dir| {
            const path = self.looseObjectPath(dir, oid);
            if (os.readFile(path)) |raw| {
                return parseLoose(raw) orelse util.die("loose object {s} (stored in {s}) is corrupt", .{ hash.hex(oid), path });
            }
        }
        // try every pack holding the object, so that a corrupt copy can be
        // recovered from a redundant pack
        var found = false;
        self.loadPacks();
        for (self.packs.items) |p| {
            const i = p.find(oid) orelse continue;
            found = true;
            if (self.readPacked(p, p.offsetAt(i))) |o| return o;
        }
        if (found) return null;
        self.reloadPacks();
        for (self.packs.items) |p| {
            const i = p.find(oid) orelse continue;
            if (self.readPacked(p, p.offsetAt(i))) |o| return o;
        }
        return null;
    }

    pub fn readPacked(self: *Odb, pack: *Pack, offset: u64) ?Object {
        const data = pack.loadPack() orelse return null;
        return readPackEntry(self, pack, data, offset, 0);
    }

    /// Read object header (type and size) cheaply where possible.
    pub fn readType(self: *Odb, oid: Oid) ?ObjType {
        const o = self.read(oid) orelse return null;
        return o.typ;
    }

    pub fn write(self: *Odb, typ: ObjType, data: []const u8) Oid {
        const hdr = util.fmt("{s} {d}\x00", .{ typ.name(), data.len });
        var h = hash.Hasher.init(.{});
        h.update(hdr);
        h.update(data);
        var oid: Oid = undefined;
        h.final(&oid);
        if (self.cache.contains(oid) or self.hasLoose(oid) or self.findPacked(oid) != null) return oid;
        if (write_in_memory_only) {
            self.cache.put(gpa, oid, .{ .typ = typ, .data = util.dupe(data) }) catch util.oom();
            return oid;
        }
        const full = util.concat(&.{ hdr, data });
        const comp = zlib.compress(full, self.compression);
        const path = self.looseObjectPath(self.objects_dir, oid);
        const dir = path[0 .. path.len - 39];
        if (!os.isDir(dir)) {
            if (!os.mkdir(dir, 0o777) and os.errno() != os.EEXIST) {
                util.dieErrno("unable to create directory {s}", .{dir});
            }
        }
        const tmp = os.tmpFile(dir, "tmp_obj_");
        if (tmp.fd < 0) util.dieErrno("insufficient permission for adding an object to repository database {s}", .{self.objects_dir});
        os.writeAll(tmp.fd, comp) catch util.die("unable to write loose object file", .{});
        os.close(tmp.fd);
        _ = os.chmod(tmp.path, 0o444);
        if (!os.rename(tmp.path, path)) {
            _ = os.unlink(tmp.path);
        }
        self.cache.put(gpa, oid, .{ .typ = typ, .data = util.dupe(data) }) catch util.oom();
        return oid;
    }

    /// Find all object ids matching a hex prefix.
    pub fn findByPrefix(self: *Odb, prefix: []const u8, out: *std.ArrayList(Oid)) void {
        if (prefix.len < 2) return;
        var lowbuf: [40]u8 = undefined;
        for (prefix, 0..) |ch, i| lowbuf[i] = std.ascii.toLower(ch);
        const pre = lowbuf[0..prefix.len];
        for (self.allDirs()) |dir| {
            const sub = util.concat(&.{ dir, "/", pre[0..2] });
            const ents = os.listDir(sub) orelse continue;
            for (ents) |e| {
                if (e.name.len != 38) continue;
                if (!util.startsWith(e.name, pre[2..])) continue;
                const full = util.concat(&.{ pre[0..2], e.name });
                const o = hash.fromHex(full) orelse continue;
                addUnique(out, o);
            }
        }
        self.loadPacks();
        var key: Oid = hash.zero;
        var i: usize = 0;
        while (i + 1 < pre.len) : (i += 2) {
            key[i / 2] = std.fmt.parseInt(u8, pre[i .. i + 2], 16) catch return;
        }
        if (pre.len % 2 == 1) {
            key[pre.len / 2] = (std.fmt.parseInt(u8, pre[pre.len - 1 .. pre.len], 16) catch return) << 4;
        }
        for (self.packs.items) |p| {
            var j = p.lowerBound(key);
            while (j < p.num) : (j += 1) {
                const o = p.oidAt(j);
                const h = hash.hex(o);
                if (!util.startsWith(&h, pre)) break;
                addUnique(out, o);
            }
        }
    }

    /// Iterate over all objects (loose and packed).
    pub fn allObjects(self: *Odb, include_alternates: bool) []Oid {
        var out: std.ArrayList(Oid) = .empty;
        var seen: hash.OidSet = .empty;
        const dirs = if (include_alternates) self.allDirs() else &[_][]const u8{self.objects_dir};
        for (dirs) |dir| {
            var b: usize = 0;
            while (b < 256) : (b += 1) {
                const hx = util.fmt("{x:0>2}", .{b});
                const ents = os.listDir(util.concat(&.{ dir, "/", hx })) orelse continue;
                for (ents) |e| {
                    if (e.name.len != 38) continue;
                    const o = hash.fromHex(util.concat(&.{ hx, e.name })) orelse continue;
                    if ((seen.fetchPut(gpa, o, {}) catch util.oom()) == null) out.append(gpa, o) catch util.oom();
                }
            }
        }
        self.loadPacks();
        for (self.packs.items) |p| {
            if (!include_alternates and !util.startsWith(p.idx_path, self.objects_dir)) continue;
            var j: u32 = 0;
            while (j < p.num) : (j += 1) {
                const o = p.oidAt(j);
                if ((seen.fetchPut(gpa, o, {}) catch util.oom()) == null) out.append(gpa, o) catch util.oom();
            }
        }
        return out.items;
    }
};

fn addUnique(out: *std.ArrayList(Oid), o: Oid) void {
    for (out.items) |x| {
        if (hash.eql(x, o)) return;
    }
    out.append(gpa, o) catch util.oom();
}

pub fn hashObject(typ: ObjType, data: []const u8) Oid {
    const hdr = util.fmt("{s} {d}\x00", .{ typ.name(), data.len });
    var h = hash.Hasher.init(.{});
    h.update(hdr);
    h.update(data);
    var oid: Oid = undefined;
    h.final(&oid);
    return oid;
}

pub fn parseLoose(raw: []const u8) ?Object {
    const res = zlib.decompress(raw, null) orelse return null;
    const d = res.data;
    const sp = std.mem.indexOfScalar(u8, d, ' ') orelse return null;
    const nul = std.mem.indexOfScalar(u8, d, 0) orelse return null;
    if (nul < sp) return null;
    const typ = ObjType.fromName(d[0..sp]) orelse return null;
    const size = util.parseInt(usize, d[sp + 1 .. nul]) orelse return null;
    if (d.len - nul - 1 != size) return null;
    return .{ .typ = typ, .data = d[nul + 1 ..] };
}

pub fn openIdx(idx_path: []const u8, pack_path: []const u8) ?*Pack {
    const idx = os.readFile(idx_path) orelse return null;
    if (idx.len < 1024 + 40) return null;
    const p = gpa.create(Pack) catch util.oom();
    if (std.mem.eql(u8, idx[0..4], "\xfftOc")) {
        const ver = std.mem.readInt(u32, idx[4..8], .big);
        if (ver != 2) return null;
        p.* = .{ .idx_path = idx_path, .pack_path = pack_path, .idx = idx, .num = 0, .version = 2, .fanout_off = 8 };
    } else {
        p.* = .{ .idx_path = idx_path, .pack_path = pack_path, .idx = idx, .num = 0, .version = 1, .fanout_off = 0 };
    }
    p.num = p.fanout(255);
    return p;
}

pub const EntryHeader = struct {
    typ: ObjType,
    size: usize,
    hdr_len: usize,
};

pub fn parseEntryHeader(data: []const u8, offset: usize) ?EntryHeader {
    var pos = offset;
    if (pos >= data.len) return null;
    var c = data[pos];
    pos += 1;
    const typ: ObjType = @enumFromInt(@as(u3, @intCast((c >> 4) & 7)));
    var size: usize = c & 15;
    var shift: u6 = 4;
    while (c & 0x80 != 0) {
        if (pos >= data.len) return null;
        c = data[pos];
        pos += 1;
        size |= @as(usize, c & 0x7f) << shift;
        shift += 7;
    }
    return .{ .typ = typ, .size = size, .hdr_len = pos - offset };
}

pub fn parseOfsDelta(data: []const u8, pos: *usize) u64 {
    var c = data[pos.*];
    pos.* += 1;
    var ofs: u64 = c & 127;
    while (c & 128 != 0) {
        ofs += 1;
        c = data[pos.*];
        pos.* += 1;
        ofs = (ofs << 7) + (c & 127);
    }
    return ofs;
}

fn readPackEntry(odb: *Odb, pack: *const Pack, data: []const u8, offset: u64, depth: u32) ?Object {
    if (depth > 10000) return null;
    const off: usize = @intCast(offset);
    const h = parseEntryHeader(data, off) orelse return null;
    var pos = off + h.hdr_len;
    switch (h.typ) {
        .commit, .tree, .blob, .tag => {
            const r = zlib.decompress(data[pos..], h.size) orelse return null;
            return .{ .typ = h.typ, .data = r.data };
        },
        .ofs_delta => {
            const rel = parseOfsDelta(data, &pos);
            const base = readPackEntry(odb, pack, data, offset - rel, depth + 1) orelse
                retryBadPackedOffset(odb, pack, offset - rel) orelse return null;
            const delta = zlib.decompress(data[pos..], h.size) orelse return null;
            const res = applyDelta(base.data, delta.data) orelse return null;
            return .{ .typ = base.typ, .data = res };
        },
        .ref_delta => {
            const base_oid: Oid = data[pos..][0..20].*;
            pos += 20;
            const base = odb.read(base_oid) orelse return null;
            const delta = zlib.decompress(data[pos..], h.size) orelse return null;
            const res = applyDelta(base.data, delta.data) orelse return null;
            return .{ .typ = base.typ, .data = res };
        },
        else => return null,
    }
}

/// retry_bad_packed_offset(): the base at `offset` could not be read from
/// this pack; look up its object id and try to get another copy (loose or
/// in another pack).
fn retryBadPackedOffset(odb: *Odb, pack: *const Pack, offset: u64) ?Object {
    var i: u32 = 0;
    while (i < pack.num) : (i += 1) {
        if (pack.offsetAt(i) != offset) continue;
        const oid = pack.oidAt(i);
        for (odb.allDirs()) |dir| {
            if (os.readFile(odb.looseObjectPath(dir, oid))) |raw| return parseLoose(raw);
        }
        for (odb.packs.items) |p| {
            if (p == pack) continue;
            const j = p.find(oid) orelse continue;
            if (odb.readPacked(p, p.offsetAt(j))) |o| return o;
        }
        return null;
    }
    return null;
}

fn deltaVarint(d: []const u8, pos: *usize) usize {
    var r: usize = 0;
    var shift: u6 = 0;
    while (pos.* < d.len) {
        const c = d[pos.*];
        pos.* += 1;
        r |= @as(usize, c & 0x7f) << shift;
        shift += 7;
        if (c & 0x80 == 0) break;
    }
    return r;
}

pub fn applyDelta(base: []const u8, delta: []const u8) ?[]u8 {
    var pos: usize = 0;
    const src_size = deltaVarint(delta, &pos);
    if (src_size != base.len) return null;
    const dst_size = deltaVarint(delta, &pos);
    const out = gpa.alloc(u8, dst_size) catch util.oom();
    var o: usize = 0;
    while (pos < delta.len) {
        const op = delta[pos];
        pos += 1;
        if (op & 0x80 != 0) {
            var cp_off: usize = 0;
            var cp_size: usize = 0;
            inline for (0..4) |i| {
                if (op & (1 << i) != 0) {
                    cp_off |= @as(usize, delta[pos]) << (8 * i);
                    pos += 1;
                }
            }
            inline for (0..3) |i| {
                if (op & (0x10 << i) != 0) {
                    cp_size |= @as(usize, delta[pos]) << (8 * i);
                    pos += 1;
                }
            }
            if (cp_size == 0) cp_size = 0x10000;
            if (cp_off + cp_size > base.len or o + cp_size > dst_size) return null;
            @memcpy(out[o..][0..cp_size], base[cp_off..][0..cp_size]);
            o += cp_size;
        } else if (op != 0) {
            const n: usize = op;
            if (pos + n > delta.len or o + n > dst_size) return null;
            @memcpy(out[o..][0..n], delta[pos..][0..n]);
            o += n;
            pos += n;
        } else return null;
    }
    if (o != dst_size) return null;
    return out;
}

/// Process-wide switch (git's disable_replace_refs()).
/// Keep newly written objects in the in-memory cache only (remerge-diff
/// uses this instead of a temporary object directory).
pub var write_in_memory_only: bool = false;

pub var read_replace_refs: bool = true;

pub fn disableReplaceRefs() void {
    read_replace_refs = false;
}

pub fn replaceRefBase() []const u8 {
    return os.getenv("GIT_REPLACE_REF_BASE") orelse "refs/replace/";
}

pub fn replaceRefsEnabled() bool {
    if (!read_replace_refs) return false;
    if (os.getenv("GIT_NO_REPLACE_OBJECTS") != null) return false;
    const repo_mod = @import("repo.zig");
    if (repo_mod.repo_ == null) return false;
    return repo_mod.cfg.getBoolDefault("core.usereplacerefs", true);
}
