//! git merge (port of builtin/merge.c and merge.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const objects = @import("../objects.zig");
const cn = @import("../commitnode.zig");
const creach = @import("../commitreach.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const ut = @import("../unpacktrees.zig");
const mo = @import("../merge_ort.zig");
const fmm = @import("../fmt_merge_msg.zig");
const advice = @import("../advice.zig");
const branchstate = @import("../branchstate.zig");
const hook = @import("../hook.zig");
const editor = @import("../editor.zig");
const commit_mod = @import("../commit.zig");
const wtstatus = @import("../wtstatus.zig");
const trailer = @import("../pretty_trailer.zig");
const pretty = @import("../pretty.zig");
const revision = @import("../revision.zig");
const diff = @import("../diff.zig");
const transport = @import("../transport.zig");
const proc = @import("../proc.zig");
const commands = @import("../commands.zig");
const c_commit = @import("commit.zig");
const c_reset = @import("reset.zig");
const Oid = hash.Oid;
const Commit = cn.Commit;
const gpa = util.gpa;

const usage = [_][]const u8{
    "git merge [<options>] [<commit>...]",
    "git merge --abort",
    "git merge --continue",
};

const MERGE_SHOW_DIFFSTAT: i32 = 1;
const MERGE_SHOW_COMPACTSUMMARY: i32 = 2;

const DEFAULT_TWOHEAD: u32 = 1 << 0;
const DEFAULT_OCTOPUS: u32 = 1 << 1;
const NO_FAST_FORWARD: u32 = 1 << 2;
const NO_TRIVIAL: u32 = 1 << 3;

const Strategy = struct { name: []const u8, attr: u32 };

const all_strategy = [_]Strategy{
    .{ .name = "recursive", .attr = NO_TRIVIAL },
    .{ .name = "octopus", .attr = DEFAULT_OCTOPUS },
    .{ .name = "ort", .attr = DEFAULT_TWOHEAD | NO_TRIVIAL },
    .{ .name = "resolve", .attr = 0 },
    .{ .name = "ours", .attr = NO_FAST_FORWARD | NO_TRIVIAL },
    .{ .name = "subtree", .attr = NO_FAST_FORWARD | NO_TRIVIAL },
};

const FF_NO: i32 = 0;
const FF_ALLOW: i32 = 1;
const FF_ONLY: i32 = 2;

var show_diffstat: i32 = MERGE_SHOW_DIFFSTAT;
var shortlog_len: i32 = -1;
var squash: i32 = 0;
var option_commit: i32 = -1;
var option_edit: i32 = -1;
var allow_trivial = true;
var have_message = false;
var verify_signatures: i32 = 0;
var overwrite_ignore: i32 = 1;
var merge_msg: util.Buf = .empty;
var use_strategies: std.ArrayList(Strategy) = .empty;
var xopts: std.ArrayList([]const u8) = .empty;
var branch: ?[]const u8 = null;
var branch_mergeoptions: ?[]const u8 = null;
var verbosity: i32 = 0;
var allow_rerere_auto: u32 = 0;
var abort_current_merge: i32 = 0;
var quit_current_merge: i32 = 0;
var continue_current_merge: i32 = 0;
var allow_unrelated_histories: i32 = 0;
var show_progress: i32 = -1;
var default_to_upstream = true;
var signoff: i32 = 0;
var sign_commit: ?[]const u8 = null;
var autostash: i32 = 0;
var no_verify: i32 = 0;
var into_name: ?[]const u8 = null;
var pull_twohead: ?[]const u8 = null;
var pull_octopus: ?[]const u8 = null;
var fast_forward: i32 = FF_ALLOW;
var cleanup_arg: ?[]const u8 = null;
var cleanup_mode: c_commit.Cleanup = .space;
var opt_error = false;

// ---------------------------------------------------------------------------
// merge_remote_desc

const RemoteDesc = struct { name: []const u8, obj_oid: Oid, obj_typ: cn.ObjType };
var remote_descs: std.AutoHashMapUnmanaged(*Commit, RemoteDesc) = .empty;

fn remoteUtil(c: *Commit) ?RemoteDesc {
    return remote_descs.get(c);
}

/// get_merge_parent() (commit.c)
fn getMergeParent(name: []const u8) ?*Commit {
    const oid = revparse.getOid(name) orelse return null;
    const obj = cn.parseObject(oid) orelse return null;
    const p = cn.derefTag(obj) orelse return null;
    if (p.typ != .commit) {
        util.err("{s}: expected commit type, but the object dereferences to {s} type", .{ name, @tagName(p.typ) });
        return null;
    }
    const c = Commit.fromObj(p);
    if (!cn.parse(c)) return null;
    if (!remote_descs.contains(c)) {
        remote_descs.put(gpa, c, .{ .name = name, .obj_oid = obj.oid, .obj_typ = obj.typ }) catch util.oom();
    }
    return c;
}

// ---------------------------------------------------------------------------
// option callbacks

fn cbMessage(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        merge_msg.clearRetainingCapacity();
    } else if (arg) |a| {
        if (merge_msg.items.len > 0) util.bufAppend(&merge_msg, "\n\n");
        util.bufAppend(&merge_msg, a);
        have_message = true;
    }
}

fn cbFile(arg: ?[]const u8, _: bool) void {
    const a0 = arg orelse return;
    if (merge_msg.items.len > 0) util.bufByte(&merge_msg, '\n');
    var a = a0;
    const prefix = repo_mod.repo().prefix;
    if (prefix.len > 0 and a.len > 0 and a[0] != '/') a = util.concat(&.{ prefix, a });
    const data = os.readFile(a) orelse {
        util.err("could not read file '{s}'", .{a});
        os.exit(129);
    };
    util.bufAppend(&merge_msg, data);
    have_message = true;
}

fn cbStrategy(arg: ?[]const u8, unset: bool) void {
    if (unset) return;
    use_strategies.append(gpa, getStrategy(arg.?)) catch util.oom();
}

fn cbCompact(_: ?[]const u8, unset: bool) void {
    show_diffstat = if (unset) 0 else MERGE_SHOW_COMPACTSUMMARY;
}

fn cbVerbose(_: ?[]const u8, unset: bool) void {
    if (unset) {
        verbosity = 0;
    } else if (verbosity < 0) verbosity = 1 else verbosity += 1;
}
fn cbQuiet(_: ?[]const u8, unset: bool) void {
    if (unset) {
        verbosity = 0;
    } else if (verbosity > 0) verbosity = -1 else verbosity -= 1;
}

fn cbRerere(_: ?[]const u8, unset: bool) void {
    allow_rerere_auto = if (unset) @import("../rerere.zig").NOAUTOUPDATE else @import("../rerere.zig").AUTOUPDATE;
}

const options = [_]po.Opt{
    .{ .short = 'n', .kind = .set_int, .i = &show_diffstat, .val = 0, .help = "do not show a diffstat at the end of the merge" },
    .{ .long = "stat", .kind = .set_int, .i = &show_diffstat, .val = 1, .help = "show a diffstat at the end of the merge" },
    .{ .long = "summary", .kind = .set_int, .i = &show_diffstat, .val = 1, .help = "(synonym to --stat)" },
    .{ .long = "compact-summary", .kind = .callback, .cb = cbCompact, .noarg = true, .help = "show a compact-summary at the end of the merge" },
    .{ .long = "log", .kind = .int, .i = &shortlog_len, .optarg = true, .val = fmm.DEFAULT_MERGE_LOG_LEN, .argh = "n", .help = "add (at most <n>) entries from shortlog to merge commit message" },
    .{ .long = "squash", .kind = .set_int, .i = &squash, .val = 1, .help = "create a single commit instead of doing a merge" },
    .{ .long = "commit", .kind = .set_int, .i = &option_commit, .val = 1, .help = "perform a commit if the merge succeeds (default)" },
    .{ .short = 'e', .long = "edit", .kind = .set_int, .i = &option_edit, .val = 1, .help = "edit message before committing" },
    po.string(0, "cleanup", &cleanup_arg, "mode", "how to strip spaces and #comments from message"),
    .{ .long = "ff", .kind = .set_int, .i = &fast_forward, .val = FF_ALLOW, .help = "allow fast-forward (default)" },
    .{ .long = "ff-only", .kind = .set_int, .i = &fast_forward, .val = FF_ONLY, .noneg = true, .help = "abort if fast-forward is not possible" },
    .{ .long = "rerere-autoupdate", .kind = .callback, .cb = cbRerere, .noarg = true, .help = "update the index with reused conflict resolution if possible" },
    .{ .long = "verify-signatures", .kind = .set_int, .i = &verify_signatures, .val = 1, .help = "verify that the named commit has a valid GPG signature" },
    .{ .short = 's', .long = "strategy", .kind = .callback, .cb = cbStrategy, .argh = "strategy", .help = "merge strategy to use" },
    po.list('X', "strategy-option", &xopts, "option=value", "option for selected merge strategy"),
    .{ .short = 'm', .long = "message", .kind = .callback, .cb = cbMessage, .argh = "message", .help = "merge commit message (for a non-fast-forward merge)" },
    .{ .short = 'F', .long = "file", .kind = .callback, .cb = cbFile, .noneg = true, .argh = "path", .help = "read message from file" },
    po.string(0, "into-name", &into_name, "name", "use <name> instead of the real target"),
    .{ .short = 'v', .long = "verbose", .kind = .callback, .cb = cbVerbose, .noarg = true, .help = "be more verbose" },
    .{ .short = 'q', .long = "quiet", .kind = .callback, .cb = cbQuiet, .noarg = true, .help = "be more quiet" },
    .{ .long = "abort", .kind = .set_int, .i = &abort_current_merge, .val = 1, .help = "abort the current in-progress merge" },
    .{ .long = "quit", .kind = .set_int, .i = &quit_current_merge, .val = 1, .help = "--abort but leave index and working tree alone" },
    .{ .long = "continue", .kind = .set_int, .i = &continue_current_merge, .val = 1, .help = "continue the current in-progress merge" },
    .{ .long = "allow-unrelated-histories", .kind = .set_int, .i = &allow_unrelated_histories, .val = 1, .help = "allow merging unrelated histories" },
    .{ .long = "progress", .kind = .set_int, .i = &show_progress, .val = 1, .help = "force progress reporting" },
    po.optString('S', "gpg-sign", &sign_commit, "", "key-id", "GPG sign commit"),
    .{ .long = "autostash", .kind = .set_int, .i = &autostash, .val = 1, .help = "automatically stash/stash pop before and after" },
    .{ .long = "overwrite-ignore", .kind = .set_int, .i = &overwrite_ignore, .val = 1, .help = "update ignored files (default)" },
    .{ .long = "signoff", .kind = .set_int, .i = &signoff, .val = 1, .help = "add a Signed-off-by trailer" },
    .{ .long = "no-verify", .kind = .set_int, .i = &no_verify, .val = 1, .help = "bypass pre-merge-commit and commit-msg hooks" },
};

// ---------------------------------------------------------------------------
// strategies

fn isExecutable(path: []const u8) bool {
    return os.access(path, 1);
}

fn customStrategies() [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    const path = os.getenv("PATH") orelse return l.items;
    var it = std.mem.splitScalar(u8, path, ':');
    while (it.next()) |dir| {
        if (dir.len == 0) continue;
        const ents = os.listDir(dir) orelse continue;
        for (ents) |e| {
            const n = util.skipPrefix(e.name, "git-merge-") orelse continue;
            if (n.len == 0) continue;
            var known = false;
            for (all_strategy) |s| {
                if (util.eql(s.name, n)) known = true;
            }
            for ([_][]const u8{ "base", "file", "index", "one-file", "tree" }) |s| {
                if (util.eql(s, n)) known = true;
            }
            if (known) continue;
            if (!isExecutable(util.concat(&.{ dir, "/", e.name }))) continue;
            var dup = false;
            for (l.items) |x| {
                if (util.eql(x, n)) dup = true;
            }
            if (!dup) l.append(gpa, n) catch util.oom();
        }
    }
    std.mem.sort([]const u8, l.items, {}, util.strLess);
    return l.items;
}

fn getStrategy(name: []const u8) Strategy {
    for (all_strategy) |s| {
        if (util.eql(s.name, name)) return s;
    }
    const custom = customStrategies();
    for (custom) |c| {
        if (util.eql(c, name)) return .{ .name = name, .attr = NO_TRIVIAL };
    }
    util.flushStdout();
    var b: util.Buf = .empty;
    util.bufPrint(&b, "Could not find merge strategy '{s}'.\n", .{name});
    util.bufAppend(&b, "Available strategies are: octopus ours recursive resolve subtree.\n");
    if (custom.len > 0) {
        util.bufAppend(&b, "Available custom strategies are:");
        for (custom) |c| util.bufPrint(&b, " {s}", .{c});
        util.bufAppend(&b, ".\n");
    }
    util.ewrite(b.items);
    os.exit(1);
}

fn addStrategies(string: ?[]const u8, attr: u32) void {
    if (string) |s| {
        var it = std.mem.splitScalar(u8, s, ' ');
        while (it.next()) |w| {
            use_strategies.append(gpa, getStrategy(w)) catch util.oom();
        }
        return;
    }
    for (all_strategy) |s| {
        if (s.attr & attr != 0) use_strategies.append(gpa, s) catch util.oom();
    }
}

// ---------------------------------------------------------------------------
// config

fn loadConfig() i32 {
    const merge_log = fmm.loadConfig();
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        const v = e.value;
        if (branch) |b| {
            if (util.skipPrefix(k, "branch.")) |r1| {
                if (util.skipPrefix(r1, b)) |r2| {
                    if (util.eql(r2, ".mergeoptions")) {
                        branch_mergeoptions = v orelse "";
                        continue;
                    }
                }
            }
        }
        if (util.eql(k, "merge.diffstat") or util.eql(k, "merge.stat")) {
            const val = config.parseMaybeBoolText(v);
            switch (val) {
                0 => show_diffstat = 0,
                1 => show_diffstat = MERGE_SHOW_DIFFSTAT,
                else => show_diffstat = if (v != null and util.eql(v.?, "compact")) MERGE_SHOW_COMPACTSUMMARY else MERGE_SHOW_DIFFSTAT,
            }
        } else if (util.eql(k, "merge.verifysignatures")) {
            verify_signatures = @intFromBool(config.configBool(k, v));
        } else if (util.eql(k, "pull.twohead")) {
            pull_twohead = v orelse util.die("missing value for '{s}'", .{k});
        } else if (util.eql(k, "pull.octopus")) {
            pull_octopus = v orelse util.die("missing value for '{s}'", .{k});
        } else if (util.eql(k, "commit.cleanup")) {
            cleanup_arg = v orelse util.die("missing value for '{s}'", .{k});
        } else if (util.eql(k, "merge.ff")) {
            const bv = config.parseMaybeBool(v);
            if (bv >= 0) {
                fast_forward = if (bv != 0) FF_ALLOW else FF_NO;
            } else if (v != null and util.eql(v.?, "only")) fast_forward = FF_ONLY;
        } else if (util.eql(k, "merge.defaulttoupstream")) {
            default_to_upstream = config.configBool(k, v);
        } else if (util.eql(k, "commit.gpgsign")) {
            sign_commit = if (config.configBool(k, v)) "" else null;
        } else if (util.eql(k, "merge.autostash")) {
            autostash = @intFromBool(config.configBool(k, v));
        }
    }
    return merge_log;
}

// ---------------------------------------------------------------------------
// helpers

fn gitPath(name: []const u8) []const u8 {
    return repo_mod.repo().gitPath(name);
}

fn writeFileOrDie(path: []const u8, data: []const u8) void {
    os.writeFile(path, data, 0o666) catch util.dieErrno("could not write to '{s}'", .{path});
}

fn runGit(args: []const []const u8) u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    util.flushStdout();
    const r = os.run(argv.items, .{});
    return r.status;
}

fn runGitCapture(args: []const []const u8) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    util.flushStdout();
    return os.run(argv.items, .{ .capture_stdout = true });
}

fn refreshAndWriteIndex() bool {
    const idx = index_mod.lockAndRead();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
    if (idx.changed) idx.write() else idx.rollback();
    return true;
}

fn commitTreeOid(c: *Commit) Oid {
    _ = cn.parse(c);
    return c.tree;
}

fn helpUnknownRef(ref: []const u8, cmd: []const u8, msg: []const u8) noreturn {
    util.flushStdout();
    var b: util.Buf = .empty;
    util.bufPrint(&b, "{s}: {s} - {s}\n", .{ cmd, ref, msg });
    var suggested: std.ArrayList([]const u8) = .empty;
    for (refs.list("refs/")) |r| {
        if (!util.startsWith(r.name, "refs/remotes/")) continue;
        const slash = std.mem.lastIndexOfScalar(u8, r.name, '/').?;
        if (util.eql(r.name[slash + 1 ..], ref)) suggested.append(gpa, refs.shortenUnambiguous(r.name)) catch util.oom();
    }
    if (suggested.items.len > 0) {
        util.bufAppend(&b, if (suggested.items.len == 1) "\nDid you mean this?\n" else "\nDid you mean one of these?\n");
        for (suggested.items) |s| util.bufPrint(&b, "\t{s}\n", .{s});
    }
    util.ewrite(b.items);
    os.exit(1);
}

fn dieFfImpossible() noreturn {
    advice.adviseIfEnabled("diverging", "Diverging branches can't be fast-forwarded, you need to either:\n" ++
        "\n" ++
        "\tgit merge --no-ff\n" ++
        "\n" ++
        "or:\n" ++
        "\n" ++
        "\tgit rebase\n");
    util.die("Not possible to fast-forward, aborting.", .{});
}

// ---------------------------------------------------------------------------
// state save / restore

fn saveState() ?Oid {
    {
        const idx = index_mod.lockAndRead();
        _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
        if (idx.changed) idx.write() else idx.rollback();
    }
    const r = runGitCapture(&.{ "stash", "create" });
    if (r.status != 0) util.die("stash failed", .{});
    var out = r.stdout;
    if (out.len == 0) return null;
    if (out[out.len - 1] == '\n') out = out[0 .. out.len - 1];
    return revparse.getOid(out) orelse util.die("not a valid object: {s}", .{out});
}

fn resetHard(oid: Oid) void {
    if (runGit(&.{ "read-tree", "-v", "--reset", "-u", &hash.hex(oid) }) != 0) util.die("read-tree failed", .{});
}

fn restoreState(head: Oid, stash: ?Oid) void {
    resetHard(head);
    if (stash) |s| {
        _ = runGit(&.{ "stash", "apply", "--index", "--quiet", &hash.hex(s) });
    }
    index_mod.discard();
    _ = index_mod.get();
}

// ---------------------------------------------------------------------------
// autostash

fn createAutostash() void {
    const r = runGitCapture(&.{ "stash", "create", "autostash" });
    if (r.status != 0) util.die("cannot autostash", .{});
    var out = r.stdout;
    if (out.len > 0 and out[out.len - 1] == '\n') out = out[0 .. out.len - 1];
    if (out.len == 0) return;
    const oid = revparse.getOid(out) orelse util.die("Unexpected stash response: '{s}'", .{out});
    refs.updateOrDie("", "MERGE_AUTOSTASH", oid, null, refs.F_NO_DEREF);
    util.outf("Created autostash: {s}\n", .{revparse.abbrev(oid, 0)});
    resetHard(revparse.getOid("HEAD").?);
    index_mod.discard();
}

fn applyAutostash() void {
    const oid = refs.readOid("MERGE_AUTOSTASH") orelse return;
    const hex = hash.hex(oid);
    util.flushStdout();
    const r = os.run(&.{ proc.gitBinary(), "stash", "apply", &hex }, .{ .capture_stdout = true });
    if (r.status == 0) {
        util.ewrite("Applied autostash.\n");
    } else {
        _ = runGitCapture(&.{ "stash", "store", "-m", "autostash", "-q", &hex });
        util.ewrite("Applying autostash resulted in conflicts.\nYour changes are safe in the stash.\nYou can run \"git stash pop\" or \"git stash drop\" at any time.\n");
    }
    refs.deleteRef("MERGE_AUTOSTASH", null, refs.F_NO_DEREF, "") catch {};
}

fn saveAutostash() void {
    const oid = refs.readOid("MERGE_AUTOSTASH") orelse return;
    const hex = hash.hex(oid);
    if (runGitCapture(&.{ "stash", "store", "-m", "autostash", "-q", &hex }).status != 0) {
        util.die("cannot store {s}", .{&hex});
    }
    util.ewrite("Autostash exists; creating a new stash entry.\nYour changes are safe in the stash.\nYou can run \"git stash pop\" or \"git stash drop\" at any time.\n");
    refs.deleteRef("MERGE_AUTOSTASH", null, refs.F_NO_DEREF, "") catch {};
}

fn removeMergeBranchState() void {
    branchstate.removeMergeBranchState();
    saveAutostash();
}

// ---------------------------------------------------------------------------

fn finishUpToDate() void {
    if (verbosity >= 0) {
        if (squash != 0) util.out("Already up to date. (nothing to squash)\n") else util.out("Already up to date.\n");
    }
    removeMergeBranchState();
}

fn squashMessage(head: *Commit, remoteheads: []const *Commit) void {
    util.out("Squash commit -- not updating HEAD\n");
    var revs = revision.RevInfo.init("");
    revision.diffMergesSuppress(&revs);
    head.obj.flags |= cn.UNINTERESTING;
    revs.addPendingObject(&head.obj, "");
    for (remoteheads) |c| revs.addPendingObject(&c.obj, "");
    _ = revision.setupRevisions(&revs, &.{"merge"}, .{});
    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    var out: util.Buf = .empty;
    util.bufAppend(&out, "Squashed commit of the following:\n");
    var ctx = pretty.Context{ .fmt = .medium };
    ctx.abbrev = revs.abbrev;
    ctx.date_mode = revs.date_mode;
    while (revision.getRevision(&revs)) |c| {
        util.bufByte(&out, '\n');
        util.bufPrint(&out, "commit {s}\n", .{&c.hex()});
        pretty.prettyPrintCommit(&ctx, c, &out);
    }
    writeFileOrDie(gitPath("SQUASH_MSG"), out.items);
    cn.clearAllObjectFlags(cn.ALL_REV_FLAGS);
}

fn finish(head_commit: *Commit, remoteheads: []const *Commit, new_head: ?Oid, msg: ?[]const u8) void {
    const head = head_commit.oid();
    const action = os.getenv("GIT_REFLOG_ACTION") orelse "merge";
    var reflog_message: []const u8 = action;
    if (msg) |m| {
        if (verbosity >= 0) util.outf("{s}\n", .{m});
        reflog_message = util.fmt("{s}: {s}", .{ action, m });
    }
    if (squash != 0) {
        squashMessage(head_commit, remoteheads);
    } else {
        if (verbosity >= 0 and merge_msg.items.len == 0) {
            util.out("No merge message -- not updating HEAD\n");
        } else {
            refs.updateOrDie(reflog_message, "HEAD", new_head.?, head, 0);
        }
    }
    if (new_head != null and show_diffstat != 0) {
        var o = diff.DiffOptions.init();
        o.stat_width = -1;
        o.stat_name_width = -1;
        o.stat_graph_width = -1;
        switch (show_diffstat) {
            MERGE_SHOW_DIFFSTAT => o.output_format |= diff.FMT_SUMMARY | diff.FMT_DIFFSTAT,
            MERGE_SHOW_COMPACTSUMMARY => {
                o.output_format |= diff.FMT_DIFFSTAT;
                o.flags.stat_with_summary = true;
            },
            else => {},
        }
        o.detect_rename = diff.DETECT_RENAME;
        o.setupDone();
        const new_c = cn.lookupCommitReference(new_head.?);
        const old_tree = commitTreeOid(head_commit);
        const new_tree = if (new_c) |c| commitTreeOid(c) else new_head.?;
        diff.diffTree(&o, old_tree, new_tree, "");
        diff.diffcoreStd(&o);
        diff.flush(&o);
    }
    util.flushStdout();
    _ = hook.run("post-merge", &.{if (squash != 0) "1" else "0"}, .{});
    if (new_head != null) applyAutostash();
}

/// merge_name()
fn mergeName(remote0: []const u8, msg: *util.Buf) void {
    const remote = revparse.interpretBranchName(remote0);
    const remote_head = getMergeParent(remote) orelse util.die("'{s}' does not point to a commit", .{remote});
    if (refs.dwimRef(remote)) |d| {
        if (d.count > 0) {
            const hex = hash.hex(d.oid);
            if (util.startsWith(d.name, "refs/heads/")) {
                util.bufPrint(msg, "{s}\t\tbranch '{s}' of .\n", .{ &hex, remote });
                return;
            }
            if (util.startsWith(d.name, "refs/tags/")) {
                util.bufPrint(msg, "{s}\t\ttag '{s}' of .\n", .{ &hex, remote });
                return;
            }
            if (util.startsWith(d.name, "refs/remotes/")) {
                util.bufPrint(msg, "{s}\t\tremote-tracking branch '{s}' of .\n", .{ &hex, remote });
                return;
            }
        }
    }
    // <name>^^^ or <name>~<number>
    var len: usize = 0;
    var early = false;
    var p = remote.len;
    while (p > 0 and remote[p - 1] == '^') : (p -= 1) len += 1;
    if (len > 0) {
        early = true;
    } else if (std.mem.lastIndexOfScalar(u8, remote, '~')) |t| {
        var seen_nonzero = false;
        len = 1;
        var i = t + 1;
        while (i < remote.len and std.ascii.isDigit(remote[i])) : (i += 1) {
            if (remote[i] != '0') seen_nonzero = true;
            len += 1;
        }
        if (i < remote.len) {
            len = 0;
        } else if (seen_nonzero) {
            early = true;
        } else if (len == 1) early = true;
    }
    if (len > 0) {
        const truname = util.concat(&.{ "refs/heads/", remote[0 .. remote.len - len] });
        if (refs.exists(truname)) {
            util.bufPrint(msg, "{s}\t\tbranch '{s}'{s} of .\n", .{ &remote_head.hex(), truname[11..], if (early) " (early part)" else "" });
            return;
        }
    }
    if (remoteUtil(remote_head)) |desc| {
        if (desc.obj_typ == .tag) {
            util.bufPrint(msg, "{s}\t\ttag '{s}'\n", .{ &hash.hex(desc.obj_oid), remote });
            return;
        }
    }
    util.bufPrint(msg, "{s}\t\tcommit '{s}'\n", .{ &remote_head.hex(), remote });
}

fn parseBranchMergeOptions(bmo: ?[]const u8) void {
    const s = bmo orelse return;
    const argv = commands.splitCmdline(s) orelse util.die("Bad branch.{s}.mergeoptions string: {s}", .{ branch.?, "unclosed quote" });
    _ = po.parse(argv, &options, &usage, .{});
}

fn readTreeTrivial(common: Oid, head: Oid, one: Oid) bool {
    const idx = index_mod.get();
    var o = ut.Options{};
    o.head_idx = 2;
    o.src_index = idx;
    o.dst_index = idx;
    o.update = true;
    o.verbose_update = true;
    o.trivial_merges_only = true;
    o.merge = true;
    o.func = &ut.threewayMerge;
    idx.cache_tree = null;
    const t1 = objects.peelTo(common, .tree) orelse return false;
    const t2 = objects.peelTo(head, .tree) orelse return false;
    const t3 = objects.peelTo(one, .tree) orelse return false;
    return ut.unpackTrees(&.{ t1, t2, t3 }, &o) == 0;
}

fn writeTreeTrivial() Oid {
    const idx = index_mod.get();
    const t = idx.writeTree(false) orelse util.die("git write-tree failed to write a tree", .{});
    return t;
}

fn countUnmergedEntries() i32 {
    var n: i32 = 0;
    for (index_mod.get().entries.items) |e| {
        if (e.stage() != 0) n += 1;
    }
    return n;
}

/// try_merge_command() (merge.c)
fn tryMergeCommand(strategy: []const u8, common: []const *Commit, head_arg: []const u8, remotes: []const *Commit) i32 {
    var args: std.ArrayList([]const u8) = .empty;
    args.append(gpa, util.fmt("merge-{s}", .{strategy})) catch util.oom();
    for (xopts.items) |x| args.append(gpa, util.fmt("--{s}", .{x})) catch util.oom();
    for (common) |c| args.append(gpa, util.dupe(&c.hex())) catch util.oom();
    args.append(gpa, "--") catch util.oom();
    args.append(gpa, head_arg) catch util.oom();
    for (remotes) |c| args.append(gpa, util.dupe(&c.hex())) catch util.oom();
    const ret = runGit(args.items);
    index_mod.discard();
    const idx = index_mod.get();
    idx.reuc = .empty;
    return ret;
}

fn tryMergeStrategy(strategy: []const u8, common: []const *Commit, remoteheads: []const *Commit, head: *Commit) i32 {
    const head_arg = "HEAD";
    _ = refreshAndWriteIndex();
    if (util.eql(strategy, "recursive") or util.eql(strategy, "subtree") or util.eql(strategy, "ort")) {
        if (remoteheads.len > 1) {
            util.err("Not handling anything other than two heads merge.", .{});
            return 2;
        }
        var o = mo.initMergeOptions(true);
        if (util.eql(strategy, "subtree")) o.subtree_shift = "";
        o.show_rename_progress = if (show_progress == -1) os.isatty(2) else show_progress != 0;
        for (xopts.items) |x| {
            if (!mo.parseMergeOpt(&o, x)) util.die("unknown strategy option: -X{s}", .{x});
        }
        o.branch1 = head_arg;
        o.branch2 = remoteUtil(remoteheads[0]).?.name;
        var reversed: ?*cn.CommitList = null;
        for (common) |c| _ = cn.listInsert(c, &reversed);
        const idx = index_mod.lockAndRead();
        const clean = mo.mergeOrtRecursive(&o, head, remoteheads[0], reversed);
        if (clean < 0) {
            idx.rollback();
            return 2;
        }
        const cur = index_mod.get();
        if (cur.changed or true) cur.write();
        return if (clean != 0) 0 else 1;
    }
    if (util.eql(strategy, "ours")) {
        // builtin merge-ours, in-process
        const ret: i32 = if (mergeOursDiffers()) 2 else 0;
        index_mod.discard();
        index_mod.get().reuc = .empty;
        return ret;
    }
    return tryMergeCommand(strategy, common, head_arg, remoteheads);
}

fn mergeOursDiffers() bool {
    index_mod.discard();
    const head = revparse.getOid("HEAD") orelse return true;
    const tree = objects.peelTo(head, .tree) orelse return true;
    return mo.indexChangesAgainst(tree).len > 0;
}

fn readMergeMsg() []const u8 {
    const f = gitPath("MERGE_MSG");
    return os.readFile(f) orelse util.dieErrno("Could not read from '{s}'", .{f});
}

fn writeMergeHeads(remoteheads: []const *Commit) void {
    var buf: util.Buf = .empty;
    for (remoteheads) |c| {
        const oid = if (remoteUtil(c)) |d| d.obj_oid else c.oid();
        util.bufPrint(&buf, "{s}\n", .{&hash.hex(oid)});
    }
    writeFileOrDie(gitPath("MERGE_HEAD"), buf.items);
    writeFileOrDie(gitPath("MERGE_MODE"), if (fast_forward == FF_NO) "no-ff" else "");
}

fn writeMergeState(remoteheads: []const *Commit) void {
    writeMergeHeads(remoteheads);
    util.bufByte(&merge_msg, '\n');
    writeFileOrDie(gitPath("MERGE_MSG"), merge_msg.items);
}

fn abortCommit(remoteheads: []const *Commit, err_msg: ?[]const u8) noreturn {
    if (err_msg) |e| util.err("{s}", .{e});
    util.eprint("Not committing merge; use 'git commit' to complete the merge.\n", .{});
    writeMergeState(remoteheads);
    os.exit(1);
}

const merge_editor_comment =
    "Please enter a commit message to explain why this merge is necessary,\n" ++
    "especially if it merges an updated upstream into a topic branch.\n" ++
    "\n";
const scissors_editor_comment = "An empty message aborts the commit.\n";

fn commentedAdd(buf: *util.Buf, text: []const u8) void {
    const incomplete = buf.items.len > 0 and buf.items[buf.items.len - 1] != '\n';
    wtstatus.addCommentedLines(buf, trailer.commentLineStr(), text);
    if (incomplete) buf.items.len -= 1;
}

fn prepareToCommit(remoteheads: []const *Commit) void {
    const index_file = repo_mod.repo().indexPath();
    if (no_verify == 0) {
        var invoked = false;
        if (hook.runCommitHook(option_edit > 0, index_file, &invoked, "pre-merge-commit", &.{}) != 0)
            abortCommit(remoteheads, null);
        if (invoked) index_mod.discard();
    }
    _ = index_mod.get();
    var msg: util.Buf = .empty;
    util.bufAppend(&msg, merge_msg.items);
    if (option_edit > 0) {
        util.bufByte(&msg, '\n');
        if (cleanup_mode == .scissors) {
            wtstatus.appendCutLine(&msg);
            commentedAdd(&msg, "\n");
        }
        commentedAdd(&msg, merge_editor_comment);
        if (cleanup_mode == .scissors) {
            commentedAdd(&msg, scissors_editor_comment);
        } else {
            commentedAdd(&msg, util.fmt("Lines starting with '{s}' will be ignored, and an empty message aborts\nthe commit.\n", .{trailer.commentLineStr()}));
        }
    }
    if (signoff != 0) c_commit.appendSignoff(&msg, trailer.ignoredLogMessageBytes(msg.items, msg.items.len), false);
    writeMergeHeads(remoteheads);
    const merge_msg_path = gitPath("MERGE_MSG");
    writeFileOrDie(merge_msg_path, msg.items);
    if (hook.runCommitHook(option_edit > 0, index_file, null, "prepare-commit-msg", &.{ merge_msg_path, "merge" }) != 0)
        abortCommit(remoteheads, null);
    if (option_edit > 0) {
        if (editor.launch(merge_msg_path, &.{})) abortCommit(remoteheads, null);
    }
    if (no_verify == 0 and hook.runCommitHook(option_edit > 0, index_file, null, "commit-msg", &.{merge_msg_path}) != 0)
        abortCommit(remoteheads, null);
    const m = c_commit.cleanupMessage(readMergeMsg(), cleanup_mode, 0);
    if (m.len == 0) abortCommit(remoteheads, "Empty commit message.");
    merge_msg = .empty;
    util.bufAppend(&merge_msg, m);
}

/// append_merge_tag_headers() (commit.c)
fn mergeTagHeaders(parents: []const *Commit) []const u8 {
    var b: util.Buf = .empty;
    for (parents) |p| {
        const d = remoteUtil(p) orelse continue;
        if (d.obj_typ != .tag) continue;
        const o = repo_mod.repo().odb().read(d.obj_oid) orelse continue;
        util.bufAppend(&b, "mergetag");
        var it = o.data;
        while (it.len > 0) {
            const nl = std.mem.indexOfScalar(u8, it, '\n');
            const line = if (nl) |n| it[0..n] else it;
            util.bufByte(&b, ' ');
            util.bufAppend(&b, line);
            util.bufByte(&b, '\n');
            it = if (nl) |n| it[n + 1 ..] else it[it.len..];
        }
    }
    return b.items;
}

fn commitTree(tree: Oid, parents: []const *Commit) Oid {
    var poids: std.ArrayList(Oid) = .empty;
    for (parents) |p| poids.append(gpa, p.oid()) catch util.oom();
    return commit_mod.create(.{
        .tree = tree,
        .parents = poids.items,
        .message = merge_msg.items,
        .extra_headers = mergeTagHeaders(parents),
    });
}

fn mergeTrivial(head: *Commit, remoteheads: []const *Commit) i32 {
    _ = refreshAndWriteIndex();
    const result_tree = writeTreeTrivial();
    util.out("Wonderful.\n");
    prepareToCommit(remoteheads);
    const result_commit = commitTree(result_tree, &.{ head, remoteheads[0] });
    finish(head, remoteheads, result_commit, "In-index merge");
    removeMergeBranchState();
    return 0;
}

fn finishAutomerge(head: *Commit, head_subsumed: bool, remoteheads: []const *Commit, wt_strategy: []const u8) i32 {
    const result_tree = writeTreeTrivial();
    var parents: std.ArrayList(*Commit) = .empty;
    if (!head_subsumed or fast_forward == FF_NO) parents.append(gpa, head) catch util.oom();
    parents.appendSlice(gpa, remoteheads) catch util.oom();
    prepareToCommit(remoteheads);
    const result_commit = commitTree(result_tree, parents.items);
    finish(head, remoteheads, result_commit, util.fmt("Merge made by the '{s}' strategy.", .{wt_strategy}));
    removeMergeBranchState();
    return 0;
}

/// append_conflicts_hint() (sequencer.c)
fn appendConflictsHint(msgbuf: *util.Buf, mode: c_commit.Cleanup) void {
    const cs = trailer.commentLineStr();
    if (mode == .scissors) {
        util.bufByte(msgbuf, '\n');
        wtstatus.appendCutLine(msgbuf);
        util.bufAppend(msgbuf, cs);
    }
    util.bufByte(msgbuf, '\n');
    commentedAdd(msgbuf, "Conflicts:\n");
    const ents = index_mod.get().entries.items;
    var i: usize = 0;
    while (i < ents.len) {
        const ce = ents[i];
        i += 1;
        if (ce.stage() != 0) {
            commentedAdd(msgbuf, util.fmt("\t{s}\n", .{ce.path}));
            while (i < ents.len and util.eql(ce.path, ents[i].path)) i += 1;
        }
    }
}

fn suggestConflicts() i32 {
    const filename = gitPath("MERGE_MSG");
    var msgbuf: util.Buf = .empty;
    appendConflictsHint(&msgbuf, c_commit.getCleanupMode(cleanup_arg, true));
    os.appendFile(filename, msgbuf.items) catch util.dieErrno("could not open '{s}'", .{filename});
    _ = @import("../rerere.zig").rerere(allow_rerere_auto);
    util.out("Automatic merge failed; fix conflicts and then commit the result.\n");
    return 1;
}

fn setupWithUpstream() []const []const u8 {
    const b = transport.branchGet(null) orelse util.die("No current branch.", .{});
    if (b.remote_name == null) util.die("No remote for the current branch.", .{});
    if (b.merge.items.len == 0) util.die("No default upstream defined for the current branch.", .{});
    transport.branchMergeDsts(b);
    var args: std.ArrayList([]const u8) = .empty;
    for (b.merge.items, 0..) |m, i| {
        const dst = b.merge_dst.items[i] orelse util.die("No remote-tracking branch for {s} from {s}", .{ m, b.remote_name.? });
        args.append(gpa, dst) catch util.oom();
    }
    return args.items;
}

fn defaultEditOption() i32 {
    if (have_message) return 0;
    if (os.getenv("GIT_MERGE_AUTOEDIT")) |e| {
        const v = config.parseMaybeBool(e);
        if (v < 0) util.die("Bad value '{s}' in environment '{s}'", .{ e, "GIT_MERGE_AUTOEDIT" });
        return v;
    }
    if (!os.isatty(0) or !os.isatty(1)) return 0;
    const s0 = os.fstatFd(0) orelse return 0;
    const s1 = os.fstatFd(1) orelse return 0;
    return @intFromBool(s0.dev == s1.dev and s0.ino == s1.ino and s0.mode == s1.mode);
}

fn reduceParents(head_commit: ?*Commit, head_subsumed: *bool, remoteheads: ?*cn.CommitList) std.ArrayList(*Commit) {
    head_subsumed.* = true;
    var parents = creach.reduceHeads(remoteheads);
    var out: std.ArrayList(*Commit) = .empty;
    while (cn.popCommit(&parents)) |c| {
        if (head_commit != null and c == head_commit.?) {
            head_subsumed.* = false;
        } else out.append(gpa, c) catch util.oom();
    }
    return out;
}

fn handleFetchHead(remotes: *?*cn.CommitList, tail0: *?*cn.CommitList, merge_names: ?*util.Buf) void {
    _ = remotes;
    var tail = tail0;
    const filename = gitPath("FETCH_HEAD");
    const data = os.readFile(filename) orelse util.dieErrno("could not open '{s}' for reading", .{filename});
    if (merge_names) |mn| util.bufAppend(mn, data);
    var pos: usize = 0;
    while (pos < data.len) {
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n');
        const npos = if (nl) |n| n + 1 else data.len;
        const line = data[pos..npos];
        var commit: ?*Commit = null;
        if (line.len < 42 or hash.fromHex(line[0..40]) == null) {
            commit = null;
        } else if (!util.eql(line[40..42], "\t\t")) {
            pos = npos;
            continue;
        } else {
            commit = getMergeParent(line[0..40]);
        }
        const c = commit orelse util.die("not something we can merge in {s}: {s}", .{ filename, std.mem.trimEnd(u8, line, "\n") });
        tail = cn.listAppend(c, tail);
        pos = npos;
    }
}

fn prepareMergeMessage(merge_names: []const u8, msg: *util.Buf) void {
    const o = fmm.Opts{
        .add_title = !have_message,
        .shortlog_len = shortlog_len,
        .credit_people = option_edit > 0,
        .into_name = into_name,
    };
    fmm.fmtMergeMsg(merge_names, msg, &o);
    if (msg.items.len > 0) msg.items.len -= 1;
}

fn collectParents(head_commit: ?*Commit, head_subsumed: *bool, argv: []const []const u8, msg: ?*util.Buf) std.ArrayList(*Commit) {
    var list: ?*cn.CommitList = null;
    var tail: *?*cn.CommitList = &list;
    var merge_names: util.Buf = .empty;
    const want_autogen = msg != null and (!have_message or shortlog_len != 0);
    if (head_commit) |h| tail = cn.listAppend(h, tail);
    var remoteheads: std.ArrayList(*Commit) = undefined;
    if (argv.len == 1 and util.eql(argv[0], "FETCH_HEAD")) {
        handleFetchHead(&list, tail, if (want_autogen) &merge_names else null);
        remoteheads = reduceParents(head_commit, head_subsumed, list);
    } else {
        for (argv) |a| {
            const c = getMergeParent(a) orelse helpUnknownRef(a, "merge", "not something we can merge");
            tail = cn.listAppend(c, tail);
        }
        remoteheads = reduceParents(head_commit, head_subsumed, list);
        if (want_autogen) {
            for (remoteheads.items) |c| mergeName(remoteUtil(c).?.name, &merge_names);
        }
    }
    if (want_autogen) prepareMergeMessage(merge_names.items, msg.?);
    return remoteheads;
}

fn mergingAThrowawayTag(c: *Commit) bool {
    const d = remoteUtil(c) orelse return false;
    if (d.obj_typ != .tag) return false;
    const o = repo_mod.repo().odb().read(d.obj_oid) orelse return true;
    const t = objects.parseTag(o.data) orelse return true;
    const tag_ref = util.fmt("refs/tags/{s}", .{t.tag});
    if (refs.readOid(tag_ref)) |oid| {
        if (hash.eql(oid, d.obj_oid)) return false;
    }
    return true;
}

fn verifyMergeSignature(c: *Commit) void {
    _ = cn.parse(c);
    const hex = revparse.abbrev(c.oid(), 0);
    if (std.mem.indexOf(u8, c.buffer, "\ngpgsig ") == null and !util.startsWith(c.buffer, "gpgsig ")) {
        util.die("Commit {s} does not have a GPG signature.", .{hex});
    }
    util.die("Commit {s} has a bad GPG signature allegedly by {s}.", .{ hex, "(unknown)" });
}

/// checkout_fast_forward() (merge.c)
fn checkoutFastForward(head: Oid, remote: Oid) bool {
    const idx = index_mod.lockAndRead();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
    const t1 = objects.peelTo(head, .tree) orelse {
        idx.rollback();
        return false;
    };
    const t2 = objects.peelTo(remote, .tree) orelse {
        idx.rollback();
        return false;
    };
    var o = ut.Options{};
    o.preserve_ignored = overwrite_ignore == 0;
    o.head_idx = 1;
    o.src_index = idx;
    o.dst_index = idx;
    o.update = true;
    o.verbose_update = true;
    o.merge = true;
    o.func = &ut.twowayMerge;
    ut.setupPorcelain(&o, "merge");
    if (ut.unpackTrees(&.{ t1, t2 }, &o) != 0) {
        index_mod.get().rollback();
        idx.rollback();
        return false;
    }
    index_mod.get().write();
    return true;
}

fn toList(items: []const *Commit) ?*cn.CommitList {
    var list: ?*cn.CommitList = null;
    var tail: *?*cn.CommitList = &list;
    for (items) |c| tail = cn.listAppend(c, tail);
    return list;
}

fn listToSlice(l: ?*cn.CommitList) []*Commit {
    var out: std.ArrayList(*Commit) = .empty;
    var p = l;
    while (p) |n| : (p = n.next) out.append(gpa, n.item) catch util.oom();
    return out.items;
}

pub fn cmdMerge(args: []const []const u8) u8 {
    if (args.len == 2 and util.eql(args[1], "-h")) po.usageExit(&usage, &options, false);

    const hr = refs.resolveFull("HEAD", false);
    var head_oid: ?Oid = null;
    if (!hr.broken and !hr.missing) head_oid = hr.oid;
    if (!hr.broken) {
        branch = util.skipPrefix(hr.name, "refs/heads/") orelse hr.name;
    }
    const merge_log_config = loadConfig();

    var head_commit: ?*Commit = null;
    if (branch != null and head_oid != null and !hash.eql(head_oid.?, hash.zero)) {
        head_commit = cn.lookupCommitReference(head_oid.?) orelse util.die("could not parse HEAD", .{});
    }
    if (branch_mergeoptions) |bmo| parseBranchMergeOptions(bmo);
    var argv = po.parse(args[1..], &options, &usage, .{});
    const orig_argc = args.len;

    if (shortlog_len < 0) shortlog_len = if (merge_log_config > 0) merge_log_config else 0;
    if (verbosity < 0 and show_progress == -1) show_progress = 0;

    if (abort_current_merge != 0) {
        if (orig_argc != 2) {
            util.err("--abort expects no arguments", .{});
            po.usageExit(&usage, &options, true);
        }
        if (!os.exists(gitPath("MERGE_HEAD"))) util.die("There is no merge to abort (MERGE_HEAD missing).", .{});
        const stash_oid = refs.readOid("MERGE_AUTOSTASH");
        if (stash_oid != null) refs.deleteRef("MERGE_AUTOSTASH", stash_oid, refs.F_NO_DEREF, "") catch {};
        const ret = c_reset.run(&.{ "reset", "--merge" });
        if (stash_oid) |s| {
            refs.updateOrDie("", "MERGE_AUTOSTASH", s, null, refs.F_NO_DEREF);
            applyAutostash();
        }
        return ret;
    }
    if (quit_current_merge != 0) {
        if (orig_argc != 2) {
            util.err("--quit expects no arguments", .{});
            po.usageExit(&usage, &options, true);
        }
        removeMergeBranchState();
        return 0;
    }
    if (continue_current_merge != 0) {
        if (orig_argc != 2) {
            util.err("--continue expects no arguments", .{});
            po.usageExit(&usage, &options, true);
        }
        if (!os.exists(gitPath("MERGE_HEAD"))) util.die("There is no merge in progress (MERGE_HEAD missing).", .{});
        return c_commit.cmdCommit(&.{"commit"});
    }

    if (ut.readIndexUnmerged(index_mod.get())) advice.dieResolveConflict("merge");
    if (os.exists(gitPath("MERGE_HEAD"))) {
        if (advice.enabled("resolveConflict")) {
            util.die("You have not concluded your merge (MERGE_HEAD exists).\nPlease, commit your changes before you merge.", .{});
        } else util.die("You have not concluded your merge (MERGE_HEAD exists).", .{});
    }
    if (refs.exists("CHERRY_PICK_HEAD")) {
        if (advice.enabled("resolveConflict")) {
            util.die("You have not concluded your cherry-pick (CHERRY_PICK_HEAD exists).\nPlease, commit your changes before you merge.", .{});
        } else util.die("You have not concluded your cherry-pick (CHERRY_PICK_HEAD exists).", .{});
    }
    index_mod.get().reuc = .empty;

    if (option_edit < 0) option_edit = defaultEditOption();
    cleanup_mode = c_commit.getCleanupMode(cleanup_arg, option_edit > 0);
    if (verbosity < 0) show_diffstat = 0;

    if (squash != 0) {
        if (fast_forward == FF_NO) util.die("options '{s}' and '{s}' cannot be used together", .{ "--squash", "--no-ff." });
        if (option_commit > 0) util.die("options '{s}' and '{s}' cannot be used together", .{ "--squash", "--commit." });
        option_commit = 0;
    }
    if (option_commit < 0) option_commit = 1;

    if (argv.len == 0) {
        if (default_to_upstream) {
            argv = @constCast(setupWithUpstream());
        } else util.die("No commit specified and merge.defaultToUpstream not set.", .{});
    } else if (argv.len == 1 and util.eql(argv[0], "-")) {
        argv[0] = "@{-1}";
    }
    if (argv.len == 0) po.usageWithOptions(&usage, &options);

    var head_subsumed = false;
    if (head_commit == null) {
        if (squash != 0) util.die("Squash commit into empty head not supported yet", .{});
        if (fast_forward == FF_NO) util.die("Non-fast-forward commit does not make sense into an empty head", .{});
        const rh = collectParents(null, &head_subsumed, argv, null);
        if (rh.items.len == 0) util.die("{s} - not something we can merge", .{argv[0]});
        if (rh.items.len > 1) util.die("Can merge only exactly one commit into empty head", .{});
        if (verify_signatures != 0) verifyMergeSignature(rh.items[0]);
        const remote_oid = rh.items[0].oid();
        if (runGit(&.{ "read-tree", "-m", "-u", hash.empty_tree_hex, &hash.hex(remote_oid) }) != 0) util.die("read-tree failed", .{});
        refs.updateOrDie("initial pull", "HEAD", remote_oid, null, 0);
        return 0;
    }
    const head = head_commit.?;

    const remoteheads_l = collectParents(head, &head_subsumed, argv, &merge_msg);
    const remoteheads = remoteheads_l.items;

    if (verify_signatures != 0) {
        for (remoteheads) |c| verifyMergeSignature(c);
    }

    {
        var b: util.Buf = .empty;
        util.bufAppend(&b, "merge");
        for (remoteheads) |c| util.bufPrint(&b, " {s}", .{remoteUtil(c).?.name});
        if (os.getenv("GIT_REFLOG_ACTION") == null) os.setEnv("GIT_REFLOG_ACTION", b.items);
        for (remoteheads) |c| {
            os.setEnv(util.fmt("GITHEAD_{s}", .{&c.hex()}), remoteUtil(c).?.name);
            if (fast_forward != FF_ONLY and mergingAThrowawayTag(c)) fast_forward = FF_NO;
        }
    }

    if (use_strategies.items.len == 0) {
        if (remoteheads.len == 0) {} else if (remoteheads.len == 1) addStrategies(pull_twohead, DEFAULT_TWOHEAD) else addStrategies(pull_octopus, DEFAULT_OCTOPUS);
    }
    for (use_strategies.items) |s| {
        if (s.attr & NO_FAST_FORWARD != 0) fast_forward = FF_NO;
        if (s.attr & NO_TRIVIAL != 0) allow_trivial = false;
    }

    var common_l: ?*cn.CommitList = null;
    if (remoteheads.len == 0) {} else if (remoteheads.len == 1) {
        common_l = creach.getMergeBasesChecked(head, remoteheads[0]) catch return 2;
    } else {
        var list = toList(remoteheads);
        _ = cn.listInsert(head, &list);
        common_l = creach.getOctopusMergeBasesChecked(list) catch return 2;
    }
    const common = listToSlice(common_l);

    refs.updateOrDie("updating ORIG_HEAD", "ORIG_HEAD", head.oid(), null, 0);

    if (remoteheads.len > 0 and common.len == 0) {
        if (allow_unrelated_histories == 0) util.die("refusing to merge unrelated histories", .{});
    } else if (remoteheads.len == 0 or (remoteheads.len == 1 and common.len == 1 and common[0] == remoteheads[0])) {
        finishUpToDate();
        return 0;
    } else if (fast_forward != FF_NO and remoteheads.len == 1 and common.len == 1 and hash.eql(common[0].oid(), head.oid())) {
        const msg = if (have_message) "Fast-forward (no commit created; -m option ignored)" else "Fast-forward";
        if (verbosity >= 0) {
            util.outf("Updating {s}..{s}\n", .{ revparse.abbrev(head.oid(), 0), revparse.abbrev(remoteheads[0].oid(), 0) });
        }
        const c = remoteheads[0];
        if (autostash != 0) createAutostash();
        if (!checkoutFastForward(head.oid(), c.oid())) {
            applyAutostash();
            return 1;
        }
        finish(head, remoteheads, c.oid(), msg);
        removeMergeBranchState();
        return 0;
    } else if (remoteheads.len == 1 and common.len > 1) {
        // need a real merge
    } else if (remoteheads.len == 1 and common.len == 1 and option_commit != 0) {
        const idx = index_mod.get();
        _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
        if (allow_trivial and fast_forward != FF_ONLY) {
            const ch = mo.indexChangesAgainst(commitTreeOid(head));
            if (ch.len > 0) {
                util.err("Your local changes to the following files would be overwritten by merge:\n  {s}", .{ch});
                return 2;
            }
            _ = @import("../ident.zig").committerStrict();
            util.out("Trying really trivial in-index merge...\n");
            const lidx = index_mod.lockAndRead();
            _ = lidx;
            if (readTreeTrivial(common[0].oid(), head.oid(), remoteheads[0].oid())) {
                index_mod.get().write();
                return @intCast(mergeTrivial(head, remoteheads));
            }
            index_mod.get().rollback();
            index_mod.discard();
            util.out("Nope.\n");
        }
    } else {
        var up_to_date = true;
        for (remoteheads) |j| {
            if (!creach.inMergeBases(j, head)) {
                up_to_date = false;
                break;
            }
        }
        if (up_to_date) {
            finishUpToDate();
            return 0;
        }
    }

    if (fast_forward == FF_ONLY) dieFfImpossible();
    if (autostash != 0) createAutostash();
    _ = @import("../ident.zig").committerStrict();

    const stash = saveState();

    var best_cnt: i32 = -1;
    var merge_was_ok = false;
    var best_strategy: ?[]const u8 = null;
    var wt_strategy: []const u8 = "";
    var ret: i32 = 0;
    const nstrat = use_strategies.items.len;
    for (use_strategies.items, 0..) |s, i| {
        if (i > 0) {
            util.out("Rewinding the tree to pristine...\n");
            restoreState(head.oid(), stash);
        }
        if (nstrat != 1) util.outf("Trying merge strategy {s}...\n", .{s.name});
        wt_strategy = s.name;
        const r = tryMergeStrategy(wt_strategy, common, remoteheads, head);
        if (r < 2) {
            if (r == 0) {
                merge_was_ok = true;
                best_strategy = wt_strategy;
                break;
            }
            const cnt: i32 = if (nstrat > 1) countUnmergedEntries() else 0;
            if (best_cnt <= 0 or cnt <= best_cnt) {
                best_strategy = wt_strategy;
                best_cnt = cnt;
            }
        }
    }

    if (merge_was_ok and option_commit != 0) {
        return @intCast(finishAutomerge(head, head_subsumed, remoteheads, wt_strategy));
    }

    if (best_strategy == null) {
        restoreState(head.oid(), stash);
        if (nstrat > 1) {
            util.eprint("No merge strategy handled the merge.\n", .{});
        } else util.eprint("Merge with strategy {s} failed.\n", .{use_strategies.items[0].name});
        applyAutostash();
        return 2;
    } else if (util.eql(best_strategy.?, wt_strategy) and best_strategy.?.ptr == wt_strategy.ptr) {
        // already have its result in the working tree
    } else {
        util.out("Rewinding the tree to pristine...\n");
        restoreState(head.oid(), stash);
        util.outf("Using the {s} strategy to prepare resolving by hand.\n", .{best_strategy.?});
        _ = tryMergeStrategy(best_strategy.?, common, remoteheads, head);
    }

    if (squash != 0) {
        finish(head, remoteheads, null, null);
    } else writeMergeState(remoteheads);

    if (merge_was_ok) {
        util.eprint("Automatic merge went well; stopped before committing as requested\n", .{});
    } else ret = suggestConflicts();
    if (autostash != 0) util.out("When finished, apply stashed changes with `git stash pop`\n");
    return @intCast(ret);
}

/// git merge-ours
pub fn cmdMergeOurs(args: []const []const u8) u8 {
    if (args.len == 2 and util.eql(args[1], "-h")) {
        util.out("usage: git merge-ours <base>... -- HEAD <remote>...\n");
        util.flushStdout();
        os.exit(0);
    }
    return if (mergeOursDiffers()) 2 else 0;
}

fn betterBranchName(b: []const u8) []const u8 {
    if (b.len != 40) return b;
    return os.getenv(util.concat(&.{ "GITHEAD_", b })) orelse b;
}

/// cmd_merge_recursive() (builtin/merge-recursive.c); also serves
/// merge-subtree and merge-recursive-ours/-theirs.
pub fn cmdMergeRecursive(args: []const []const u8) u8 {
    const name = args[0];
    var o = mo.initMergeOptions(false);
    if (std.mem.endsWith(u8, name, "-subtree")) o.subtree_shift = "";
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.out(util.fmt("usage: git {s} <base>... -- <head> <remote> ...\n", .{name}));
        util.flushStdout();
        os.exit(0);
    }
    if (args.len < 4) {
        util.eprint("usage: git {s} <base>... -- <head> <remote> ...\n", .{name});
        os.exit(129);
    }
    var bases: std.ArrayList(hash.Oid) = .empty;
    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (std.mem.startsWith(u8, arg, "--")) {
            if (arg.len == 2) break;
            if (!mo.parseMergeOpt(&o, arg[2..])) util.die("unknown option {s}", .{arg});
            continue;
        }
        if (bases.items.len < 20) {
            const oid = revparse.getOid(arg) orelse util.die("could not parse object '{s}'", .{arg});
            bases.append(gpa, oid) catch util.oom();
        } else {
            util.warn("cannot handle more than 20 bases. Ignoring {s}.", .{arg});
        }
    }
    if (args.len - i != 3) util.die("not handling anything other than two heads merge.", .{});
    if (ut.readIndexUnmerged(index_mod.get())) advice.dieResolveConflict("merge");
    const b1 = args[i + 1];
    const b2 = args[i + 2];
    const h1 = revparse.getOid(b1) orelse util.die("could not resolve ref '{s}'", .{b1});
    const h2 = revparse.getOid(b2) orelse util.die("could not resolve ref '{s}'", .{b2});
    o.branch1 = betterBranchName(b1);
    o.branch2 = betterBranchName(b2);
    if (o.verbosity >= 3) util.out(util.fmt("Merging {s} with {s}\n", .{ o.branch1, o.branch2 }));
    index_mod.discard();
    const failed = mo.mergeOrtGeneric(&o, h1, h2, bases.items);
    if (failed < 0) return 128;
    return @intCast(failed);
}
