//! git bisect (builtin/bisect.c + bisect.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const objects = @import("../objects.zig");
const pretty = @import("../pretty.zig");
const proc = @import("../proc.zig");
const revision = @import("../revision.zig");
const cn = @import("../commitnode.zig");
const creach = @import("../commitreach.zig");
const findbisect = @import("../findbisect.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Commit = cn.Commit;
const CommitList = cn.CommitList;

const BISECT_OK: i32 = 0;
const BISECT_FAILED: i32 = -1;
const BISECT_ONLY_SKIPPED_LEFT: i32 = -2;
const BISECT_MERGE_BASE_CHECK: i32 = -3;
const BISECT_NO_TESTABLE_COMMIT: i32 = -4;
const BISECT_INTERNAL_SUCCESS_1ST_BAD_FOUND: i32 = -10;
const BISECT_INTERNAL_SUCCESS_MERGE_BASE: i32 = -11;

const bisect_usage = [_][]const u8{
    "git bisect start [--term-(bad|new)=<term-new> --term-(good|old)=<term-old>]\n" ++
        "                 [--no-checkout] [--first-parent] [--reset-when-found[=<where>]] [<bad> [<good>...]] [--] [<pathspec>...]",
    "git bisect (bad|new|<term-new>) [<rev>]",
    "git bisect (good|old|<term-old>) [<rev>...]",
    "git bisect terms [--term-(good|old) | --term-(bad|new)]",
    "git bisect skip [(<rev>|<range>)...]",
    "git bisect next",
    "git bisect reset [<commit>]",
    "git bisect (visualize|view)",
    "git bisect replay <logfile>",
    "git bisect log",
    "git bisect run [--reset-when-found[=<where>]] <cmd> [<arg>...]",
    "git bisect help",
};

const vocab_bad = "bad|new";
const vocab_good = "good|old";

const ResetMode = enum { none, original, found };

const Terms = struct {
    bad: []const u8 = "bad",
    good: []const u8 = "good",
};

fn gp(name: []const u8) []const u8 {
    return repo_mod.repo().gitPath(name);
}

fn oneOf(term: []const u8, list: []const []const u8) bool {
    for (list) |l| if (util.eql(term, l)) return true;
    return false;
}

fn isBisectSuccess(res: i32) bool {
    return res == 0 or res == BISECT_INTERNAL_SUCCESS_1ST_BAD_FOUND or res == BISECT_INTERNAL_SUCCESS_MERGE_BASE;
}

fn isEmptyOrMissing(path: []const u8) bool {
    const st = os.statPath(path) orelse return true;
    return st.size == 0;
}

fn errRet(comptime f: []const u8, args: anytype) i32 {
    util.err(f, args);
    return -1;
}

fn writeFileStr(path: []const u8, data: []const u8) void {
    os.writeFile(path, data, 0o666) catch util.dieErrno("could not write '{s}'", .{path});
}

fn appendFile(path: []const u8, data: []const u8) i32 {
    os.appendFile(path, data) catch return errRet("cannot open file '{s}' in mode '{s}'", .{ path, "a" });
    return 0;
}

fn subjectOf(oid: Oid) []const u8 {
    const c = objects.readCommit(oid) orelse return "";
    var b: util.Buf = .empty;
    _ = pretty.formatSubject(&b, c.message, pretty.skipBlankLines(c.message, 0), " ");
    return b.items;
}

fn sqQuoteArgv(b: *util.Buf, argv: []const []const u8) void {
    for (argv) |a| {
        util.bufByte(b, ' ');
        util.sqQuote(b, a);
    }
}

/// sq_dequote_to_strvec(); returns null on bad quoting.
fn sqDequote(s: []const u8) ?[][]const u8 {
    var out: std.ArrayList([]const u8) = .empty;
    var i: usize = 0;
    while (true) {
        while (i < s.len and std.ascii.isWhitespace(s[i])) i += 1;
        if (i >= s.len) break;
        if (s[i] != '\'') return null;
        i += 1;
        var w: util.Buf = .empty;
        while (true) {
            if (i >= s.len) return null;
            const ch = s[i];
            i += 1;
            if (ch != '\'') {
                util.bufByte(&w, ch);
                continue;
            }
            // closing quote; maybe \x' continuation
            if (i < s.len and s[i] == '\\') {
                if (i + 2 < s.len + 0 and (s[i + 1] == '\'' or s[i + 1] == '!') and i + 2 < s.len and s[i + 2] == '\'') {
                    util.bufByte(&w, s[i + 1]);
                    i += 3;
                    continue;
                }
                return null;
            }
            break;
        }
        if (i < s.len and !std.ascii.isWhitespace(s[i])) return null;
        out.append(gpa, w.items) catch util.oom();
    }
    return out.items;
}

// ---------------- bisect.c state ----------------

var good_revs: std.ArrayList(Oid) = .empty;
var skipped_revs: std.ArrayList(Oid) = .empty;
var current_bad_oid: ?Oid = null;
var lib_term_bad: []const u8 = "bad";
var lib_term_good: []const u8 = "good";

fn oidIn(list: []const Oid, oid: Oid) bool {
    for (list) |o| if (hash.eql(o, oid)) return true;
    return false;
}

fn readBisectTerms() void {
    const data = os.readFile(gp("BISECT_TERMS")) orelse {
        if (os.errno() == os.ENOENT) {
            lib_term_bad = "bad";
            lib_term_good = "good";
            return;
        }
        util.dieErrno("could not read file '{s}'", .{gp("BISECT_TERMS")});
    };
    var it = std.mem.splitScalar(u8, data, '\n');
    const b = it.next() orelse util.die("could not read bad term from file '{s}'", .{gp("BISECT_TERMS")});
    const g = it.next();
    if (b.len == 0 and data.len == 0) util.die("could not read bad term from file '{s}'", .{gp("BISECT_TERMS")});
    if (g == null or (g.?.len == 0 and it.peek() == null)) util.die("could not read good term from file '{s}'", .{gp("BISECT_TERMS")});
    lib_term_bad = b;
    lib_term_good = g.?;
}

fn readBisectRefs() void {
    good_revs = .empty;
    skipped_revs = .empty;
    current_bad_oid = null;
    const good_prefix = util.concat(&.{ lib_term_good, "-" });
    for (refs.list("refs/bisect/")) |r| {
        const name = r.name["refs/bisect/".len..];
        if (util.eql(name, lib_term_bad)) {
            current_bad_oid = r.oid;
        } else if (util.startsWith(name, good_prefix)) {
            good_revs.append(gpa, r.oid) catch util.oom();
        } else if (util.startsWith(name, "skip-")) {
            skipped_revs.append(gpa, r.oid) catch util.oom();
        }
    }
}

fn readBisectPaths(out: *std.ArrayList([]const u8)) void {
    const fname = gp("BISECT_NAMES");
    const data = os.readFile(fname) orelse util.dieErrno("could not open '{s}' for reading", .{fname});
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        if (it.peek() == null and line0.len == 0) break;
        const line = util.trim(line0);
        const words = sqDequote(line) orelse util.die("Badly quoted content in file '{s}': {s}", .{ fname, line });
        out.appendSlice(gpa, words) catch util.oom();
    }
}

fn filterSkipped(list0: ?*CommitList, tried: *?*CommitList, show_all: bool, count: ?*i32, skipped_first: ?*i32) ?*CommitList {
    var filtered: ?*CommitList = null;
    var f: *?*CommitList = &filtered;
    tried.* = null;
    var t: *?*CommitList = tried;
    if (skipped_first) |s| s.* = 0;
    if (count) |c| c.* = 0;
    if (skipped_revs.items.len == 0) return list0;
    var list = list0;
    while (list) |l| {
        const next = l.next;
        l.next = null;
        if (oidIn(skipped_revs.items, l.item.obj.oid)) {
            if (skipped_first) |s| {
                if (s.* == 0) s.* = 1;
            }
            t.* = l;
            t = &l.next;
        } else {
            if (!show_all) {
                if (skipped_first == null or skipped_first.?.* == 0) return l;
            } else if (skipped_first != null and skipped_first.?.* == 0) {
                skipped_first.?.* = -1;
            }
            f.* = l;
            f = &l.next;
            if (count) |c| c.* += 1;
        }
        list = next;
    }
    if (skipped_first) |s| {
        if (s.* == -1) s.* = 0;
    }
    return filtered;
}

const PRN_MODULO: u32 = 32768;

fn getPrn(count: u32) u32 {
    const c = count *% 1103515245 +% 12345;
    return (c / 65536) % PRN_MODULO;
}

fn sqrti(val: i32) i32 {
    if (val == 0) return 0;
    const v: f32 = @floatFromInt(val);
    var x: f32 = v;
    while (true) {
        const y: f32 = (x + v / x) / 2;
        const d: f32 = if (y > x) y - x else x - y;
        x = y;
        if (!(d >= 0.5)) break;
    }
    return @intFromFloat(x);
}

fn skipAway(list: ?*CommitList, count: i32) ?*CommitList {
    const prn: i32 = @intCast(getPrn(@bitCast(count)));
    const index = @divTrunc(@divTrunc(count * prn, @as(i32, PRN_MODULO)) * sqrti(prn), sqrti(PRN_MODULO));
    var result = list;
    var cur = list;
    var previous: ?*CommitList = null;
    var i: i32 = 0;
    while (cur) |c| : ({
        cur = c.next;
        i += 1;
    }) {
        if (i == index) {
            if (!hash.eql(c.item.obj.oid, current_bad_oid.?)) {
                result = c;
            } else if (previous) |p| {
                result = p;
            } else result = list;
            break;
        }
        previous = c;
    }
    return result;
}

fn managedSkipped(list: ?*CommitList, tried: *?*CommitList) ?*CommitList {
    tried.* = null;
    if (skipped_revs.items.len == 0) return list;
    var count: i32 = 0;
    var skipped_first: i32 = 0;
    const l = filterSkipped(list, tried, false, &count, &skipped_first);
    if (skipped_first == 0) return l;
    return skipAway(l, count);
}

fn bisectRevSetup(revs: *revision.RevInfo, prefix: []const u8, bad_neg: bool, read_paths: bool) void {
    revs.* = revision.RevInfo.init(prefix);
    revs.abbrev = 0;
    revs.commit_format = .unspecified;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "bisect_rev_setup") catch util.oom();
    const bad_hex = util.dupe(&hash.hex(current_bad_oid.?));
    argv.append(gpa, if (bad_neg) util.concat(&.{ "^", bad_hex }) else bad_hex) catch util.oom();
    for (good_revs.items) |g| {
        const h = util.dupe(&hash.hex(g));
        argv.append(gpa, if (bad_neg) h else util.concat(&.{ "^", h })) catch util.oom();
    }
    argv.append(gpa, "--") catch util.oom();
    if (read_paths) readBisectPaths(&argv);
    _ = revision.setupRevisions(revs, argv.items, .{});
}

fn bisectCommon(revs: *revision.RevInfo) void {
    if (!revision.prepareRevisionWalk(revs)) util.die("revision walk setup failed", .{});
}

fn errorIfSkippedCommits(tried0: ?*CommitList, bad: ?Oid) i32 {
    if (tried0 == null) return BISECT_OK;
    util.outf("There are only 'skip'ped commits left to test.\nThe first '{s}' commit could be any of:\n", .{lib_term_bad});
    var tried = tried0;
    while (tried) |t| : (tried = t.next) util.outf("{s}\n", .{hash.hex(t.item.obj.oid)});
    if (bad) |b| util.outf("{s}\n", .{hash.hex(b)});
    util.out("We cannot bisect more!\n");
    return BISECT_ONLY_SKIPPED_LEFT;
}

fn isExpectedRev(oid: Oid) bool {
    const r = refs.resolve("BISECT_EXPECTED_REV") orelse return false;
    return hash.eql(r.oid, oid);
}

fn updateRefDie(name: []const u8, oid: Oid) void {
    refs.updateFlags(name, oid, null, "", refs.F_NO_DEREF) catch util.die("{s}", .{refs.last_error});
}

fn bisectCheckout(rev: Oid, no_checkout: bool) i32 {
    updateRefDie("BISECT_EXPECTED_REV", rev);
    const hx = util.dupe(&hash.hex(rev));
    if (no_checkout) {
        updateRefDie("BISECT_HEAD", rev);
    } else {
        util.flushStdout();
        const r = os.run(&.{ proc.gitBinary(), "checkout", "-q", hx, "--" }, .{});
        if (r.status != 0 or r.signaled) return BISECT_FAILED;
    }
    util.outf("[{s}] {s}\n", .{ hx, subjectOf(rev) });
    return BISECT_OK;
}

fn joinGoodHex() []const u8 {
    var b: util.Buf = .empty;
    for (good_revs.items, 0..) |g, i| {
        if (i > 0) util.bufByte(&b, ' ');
        util.bufAppend(&b, &hash.hex(g));
    }
    return b.items;
}

fn handleBadMergeBase() i32 {
    const bad = current_bad_oid.?;
    if (isExpectedRev(bad)) {
        const bad_hex = hash.hex(bad);
        const good_hex = joinGoodHex();
        if (util.eql(lib_term_bad, "bad") and util.eql(lib_term_good, "good")) {
            util.eprint("The merge base {s} is bad.\nThis means the bug has been fixed between {s} and [{s}].\n", .{ bad_hex, bad_hex, good_hex });
        } else if (util.eql(lib_term_bad, "new") and util.eql(lib_term_good, "old")) {
            util.eprint("The merge base {s} is new.\nThe property has changed between {s} and [{s}].\n", .{ bad_hex, bad_hex, good_hex });
        } else {
            util.eprint("The merge base {s} is '{s}'.\nThis means the first '{s}' commit is between {s} and [{s}].\n", .{ bad_hex, lib_term_bad, lib_term_good, bad_hex, good_hex });
        }
        return BISECT_MERGE_BASE_CHECK;
    }
    util.eprint("Some '{s}' revs are not ancestors of the '{s}' rev.\ngit bisect cannot work properly in this case.\nMaybe you mistook '{s}' and '{s}' revs?\n", .{ lib_term_good, lib_term_bad, lib_term_good, lib_term_bad });
    return BISECT_FAILED;
}

fn handleSkippedMergeBase(mb: Oid) void {
    const bad_hex = hash.hex(current_bad_oid.?);
    util.warn("the merge base between {s} and [{s}] must be skipped.\nSo we cannot be sure the first '{s}' commit is between {s} and {s}.\nWe continue anyway.", .{ bad_hex, joinGoodHex(), lib_term_bad, hash.hex(mb), bad_hex });
}

fn getCommitRef(oid: Oid) *Commit {
    return cn.lookupCommitReference(oid) orelse util.die("Not a valid commit name {s}", .{hash.hex(oid)});
}

fn checkMergeBases(rev: []const *Commit, no_checkout: bool) i32 {
    var res: i32 = BISECT_OK;
    const result = creach.getMergeBasesMany(rev[0], rev[1..]);
    var l = result;
    while (l) |e| : (l = e.next) {
        const mb = e.item.obj.oid;
        if (hash.eql(mb, current_bad_oid.?)) {
            res = handleBadMergeBase();
            break;
        } else if (oidIn(good_revs.items, mb)) {
            continue;
        } else if (oidIn(skipped_revs.items, mb)) {
            handleSkippedMergeBase(mb);
        } else {
            util.out("Bisecting: a merge base must be tested\n");
            res = bisectCheckout(mb, no_checkout);
            if (res == 0) res = BISECT_INTERNAL_SUCCESS_MERGE_BASE;
            break;
        }
    }
    return res;
}

fn checkAncestors(prefix: []const u8) bool {
    var revs: revision.RevInfo = undefined;
    bisectRevSetup(&revs, prefix, true, false);
    bisectCommon(&revs);
    const res = revs.commits != null;
    cn.clearAllObjectFlags(cn.ALL_REV_FLAGS);
    return res;
}

fn checkGoodAreAncestorsOfBad(prefix: []const u8, no_checkout: bool) i32 {
    if (current_bad_oid == null) return errRet("a '{s}' revision is needed", .{lib_term_bad});
    const fname = gp("BISECT_ANCESTORS_OK");
    if (os.statPath(fname)) |st| {
        if (st.isReg()) return BISECT_OK;
    }
    if (good_revs.items.len == 0) return BISECT_OK;
    var rev: std.ArrayList(*Commit) = .empty;
    rev.append(gpa, getCommitRef(current_bad_oid.?)) catch util.oom();
    for (good_revs.items) |g| rev.append(gpa, getCommitRef(g)) catch util.oom();
    var res: i32 = BISECT_OK;
    if (checkAncestors(prefix)) res = checkMergeBases(rev.items, no_checkout);
    cn.clearAllObjectFlags(cn.ALL_REV_FLAGS);
    if (res == 0) {
        os.writeFile(fname, "", 0o600) catch util.warn("could not create file '{s}'", .{fname});
    }
    return res;
}

fn showCommit(oid: Oid) void {
    util.flushStdout();
    const hx = util.dupe(&hash.hex(oid));
    const r = os.run(&.{ proc.gitBinary(), "--no-pager", "show", "--stat", "--summary", "--no-abbrev-commit", "--diff-merges=first-parent", hx }, .{});
    if (r.status != 0 or r.signaled) util.die("unable to start 'show' for object '{s}'", .{hx});
}

fn bisectNextAll(prefix: []const u8) i32 {
    const no_checkout = refs.exists("BISECT_HEAD");
    var bflags: u32 = 0;
    readBisectTerms();
    readBisectRefs();
    if (os.exists(gp("BISECT_FIRST_PARENT"))) bflags |= findbisect.FIND_BISECTION_FIRST_PARENT_ONLY;
    if (skipped_revs.items.len > 0) bflags |= findbisect.FIND_BISECTION_ALL;

    var res = checkGoodAreAncestorsOfBad(prefix, no_checkout);
    if (res != 0) return res;

    var revs: revision.RevInfo = undefined;
    bisectRevSetup(&revs, prefix, false, true);
    revs.first_parent_only = bflags & findbisect.FIND_BISECTION_FIRST_PARENT_ONLY != 0;
    revs.limited = true;
    bisectCommon(&revs);
    var reaches: i32 = 0;
    var all: i32 = 0;
    findbisect.findBisection(&revs.commits, &reaches, &all, bflags);
    var tried: ?*CommitList = null;
    revs.commits = managedSkipped(revs.commits, &tried);
    const first = revs.commits orelse {
        res = errorIfSkippedCommits(tried, null);
        if (res < 0) return res;
        util.outf("{s} was both '{s}' and '{s}'\n", .{ hash.hex(current_bad_oid.?), lib_term_good, lib_term_bad });
        return BISECT_FAILED;
    };
    if (all == 0) {
        util.eprint("No testable commit found.\nMaybe you started with bad path arguments?\n", .{});
        return BISECT_NO_TESTABLE_COMMIT;
    }
    const bisect_rev = first.item.obj.oid;
    if (hash.eql(bisect_rev, current_bad_oid.?)) {
        res = errorIfSkippedCommits(tried, current_bad_oid);
        if (res != 0) return res;
        util.outf("{s} is the first '{s}' commit\n", .{ hash.hex(bisect_rev), lib_term_bad });
        showCommit(bisect_rev);
        return BISECT_INTERNAL_SUCCESS_1ST_BAD_FOUND;
    }
    const nr = all - reaches - 1;
    const steps = findbisect.estimateBisectSteps(all);
    const steps_msg = if (steps == 1) util.fmt("(roughly {d} step)", .{steps}) else util.fmt("(roughly {d} steps)", .{steps});
    if (nr == 1) {
        util.outf("Bisecting: {d} revision left to test after this {s}\n", .{ nr, steps_msg });
    } else util.outf("Bisecting: {d} revisions left to test after this {s}\n", .{ nr, steps_msg });
    cn.clearAllObjectFlags(cn.ALL_REV_FLAGS);
    return bisectCheckout(bisect_rev, no_checkout);
}

fn unlinkOrWarn(path: []const u8) void {
    if (!os.unlink(path) and os.errno() != os.ENOENT) util.warn("unable to unlink '{s}': {s}", .{ path, os.lastErr() });
}

fn bisectCleanState() i32 {
    var names: std.ArrayList([]const u8) = .empty;
    for (refs.list("refs/bisect/")) |r| names.append(gpa, r.name) catch util.oom();
    if (refs.exists("BISECT_HEAD")) names.append(gpa, "BISECT_HEAD") catch util.oom();
    if (refs.exists("BISECT_EXPECTED_REV")) names.append(gpa, "BISECT_EXPECTED_REV") catch util.oom();
    var result: i32 = 0;
    if (names.items.len > 0 and !refs.deleteRefs(names.items, refs.F_NO_DEREF, "bisect: remove")) result = -1;
    for ([_][]const u8{ "BISECT_ANCESTORS_OK", "BISECT_LOG", "BISECT_NAMES", "BISECT_RUN", "BISECT_TERMS", "BISECT_FIRST_PARENT", "BISECT_RESET_WHEN_FOUND", "BISECT_START" }) |f|
        unlinkOrWarn(gp(f));
    return result;
}

// ---------------- builtin/bisect.c ----------------

fn checkTermFormat(term: []const u8, orig_term: []const u8) i32 {
    if (!refs.checkRefnameFormat(util.concat(&.{ "refs/bisect/", term }), 0))
        return errRet("'{s}' is not a valid term", .{term});
    if (oneOf(term, &.{ "help", "start", "skip", "next", "reset", "visualize", "view", "replay", "log", "run", "terms" }))
        return errRet("can't use the builtin command '{s}' as a term", .{term});
    if ((!util.eql(orig_term, "bad") and oneOf(term, &.{ "bad", "new" })) or
        (!util.eql(orig_term, "good") and oneOf(term, &.{ "good", "old" })))
        return errRet("can't change the meaning of the term '{s}'", .{term});
    return 0;
}

fn writeTerms(bad: []const u8, good: []const u8) i32 {
    if (util.eql(bad, good)) return errRet("please use two different terms", .{});
    if (checkTermFormat(bad, "bad") != 0 or checkTermFormat(good, "good") != 0) return -1;
    writeFileStr(gp("BISECT_TERMS"), util.fmt("{s}\n{s}\n", .{ bad, good }));
    return 0;
}

fn bisectReset(commit: ?[]const u8, quiet: bool) i32 {
    var branch: []const u8 = "";
    if (commit) |c| {
        if (revparse.getCommit(c) == null) return errRet("'{s}' is not a valid commit", .{c});
        branch = c;
    } else {
        const data = os.readFile(gp("BISECT_START")) orelse "";
        if (data.len == 0) {
            util.out("We are not bisecting.\n");
        } else branch = util.trimRight(data);
    }
    if (branch.len > 0 and !refs.exists("BISECT_HEAD")) {
        var argv: std.ArrayList([]const u8) = .empty;
        argv.appendSlice(gpa, &.{ proc.gitBinary(), "checkout", "--ignore-other-worktrees" }) catch util.oom();
        if (quiet) argv.append(gpa, "--quiet") catch util.oom();
        argv.appendSlice(gpa, &.{ branch, "--" }) catch util.oom();
        util.flushStdout();
        const r = os.run(argv.items, .{});
        if (r.status != 0 or r.signaled) {
            return errRet("could not check out original HEAD '{s}'. Try 'git bisect reset <commit>'.", .{branch});
        }
    }
    return 0;
}

fn parseResetWhenFound(value: []const u8, mode: *ResetMode) i32 {
    if (util.eql(value, "original")) {
        mode.* = .original;
    } else if (util.eql(value, "found")) {
        mode.* = .found;
    } else return errRet("invalid value for '--reset-when-found': '{s}'", .{value});
    return 0;
}

fn readResetWhenFound(mode: *ResetMode) i32 {
    mode.* = .none;
    const p = gp("BISECT_RESET_WHEN_FOUND");
    if (isEmptyOrMissing(p)) return 0;
    const data = os.readFile(p) orelse return errRet("could not read '{s}'", .{p});
    if (parseResetWhenFound(util.trim(data), mode) != 0) return -1;
    return 0;
}

fn bisectResetWhenFound(mode: ResetMode) i32 {
    var commit: ?[]const u8 = null;
    if (mode == .found) {
        readBisectTerms();
        commit = util.concat(&.{ "refs/bisect/", lib_term_bad });
    }
    var res = bisectReset(commit, true);
    if (res == 0) res = bisectCleanState();
    return res;
}

fn bisectWrite(state: []const u8, rev: []const u8, terms: *const Terms, nolog: bool) i32 {
    var tag: []const u8 = undefined;
    if (util.eql(state, terms.bad)) {
        tag = util.fmt("refs/bisect/{s}", .{state});
    } else if (oneOf(state, &.{ terms.good, "skip" })) {
        tag = util.fmt("refs/bisect/{s}-{s}", .{ state, rev });
    } else return errRet("Bad bisect_write argument: {s}", .{state});
    const oid = revparse.getOid(rev) orelse return errRet("couldn't get the oid of the rev '{s}'", .{rev});
    refs.updateFlags(tag, oid, null, "", 0) catch {
        util.err("{s}", .{refs.last_error});
        return -1;
    };
    var b: util.Buf = .empty;
    const c = cn.lookupCommitReference(oid);
    const coid = if (c) |cc| cc.obj.oid else oid;
    util.bufPrint(&b, "# {s}: [{s}] {s}\n", .{ state, hash.hex(coid), subjectOf(coid) });
    if (!nolog) util.bufPrint(&b, "git bisect {s} {s}\n", .{ state, rev });
    os.appendFile(gp("BISECT_LOG"), b.items) catch return errRet("couldn't open the file '{s}'", .{gp("BISECT_LOG")});
    return 0;
}

fn checkAndSetTerms(terms: *Terms, cmd: []const u8) i32 {
    const has_term_file = !isEmptyOrMissing(gp("BISECT_TERMS"));
    if (oneOf(cmd, &.{ "skip", "start", "terms" })) return 0;
    if (has_term_file and !util.eql(cmd, terms.bad) and !util.eql(cmd, terms.good))
        return errRet("Invalid command: you're currently in a {s}/{s} bisect", .{ terms.bad, terms.good });
    if (!has_term_file) {
        if (oneOf(cmd, &.{ "bad", "good" })) {
            terms.* = .{ .bad = "bad", .good = "good" };
            return writeTerms(terms.bad, terms.good);
        }
        if (oneOf(cmd, &.{ "new", "old" })) {
            terms.* = .{ .bad = "new", .good = "old" };
            return writeTerms(terms.bad, terms.good);
        }
    }
    return 0;
}

fn prompt(msg: []const u8) []const u8 {
    util.flushStdout();
    util.eprint("{s}", .{msg});
    var buf: [256]u8 = undefined;
    var n: usize = 0;
    while (n < buf.len) {
        var ch: [1]u8 = undefined;
        const r = std.c.read(0, &ch, 1);
        if (r <= 0 or ch[0] == '\n') break;
        buf[n] = ch[0];
        n += 1;
    }
    return util.dupe(buf[0..n]);
}

fn decideNext(terms: *const Terms, current_term: ?[]const u8, missing_good: bool, missing_bad: bool) i32 {
    if (!missing_good and !missing_bad) return 0;
    const cur = current_term orelse return -1;
    if (missing_good and !missing_bad and util.eql(cur, terms.good)) {
        util.warn("bisecting only with a {s} commit", .{terms.bad});
        if (!os.isatty(0)) return 0;
        const yesno = prompt("Are you sure [Y/n]? ");
        if (util.startsWith(yesno, "N") or util.startsWith(yesno, "n")) return -1;
        return 0;
    }
    if (!isEmptyOrMissing(gp("BISECT_START"))) {
        return errRet("You need to give me at least one {s} and {s} revision.\nYou can use \"git bisect {s}\" and \"git bisect {s}\" for that.", .{ vocab_bad, vocab_good, vocab_bad, vocab_good });
    }
    return errRet("You need to start by \"git bisect start\".\nYou then need to give me at least one {s} and {s} revision.\nYou can use \"git bisect {s}\" and \"git bisect {s}\" for that.", .{ vocab_good, vocab_bad, vocab_good, vocab_bad });
}

const State = struct { nr_good: usize = 0, nr_bad: usize = 0 };

fn bisectStatus(terms: *const Terms) State {
    var st = State{};
    if (refs.exists(util.concat(&.{ "refs/bisect/", terms.bad }))) st.nr_bad = 1;
    const gpfx = util.concat(&.{ "refs/bisect/", terms.good, "-" });
    for (refs.list("refs/bisect/")) |r| {
        if (util.startsWith(r.name, gpfx)) st.nr_good += 1;
    }
    return st;
}

fn bisectLogPrintf(msg: []const u8) void {
    util.out(msg);
    _ = appendFile(gp("BISECT_LOG"), util.concat(&.{ "# ", msg }));
}

fn bisectPrintStatus(terms: *const Terms) void {
    const st = bisectStatus(terms);
    if (st.nr_good > 0 and st.nr_bad > 0) return;
    if (st.nr_good == 0 and st.nr_bad == 0) {
        bisectLogPrintf(util.fmt("status: waiting for both '{s}' and '{s}' commits\n", .{ terms.good, terms.bad }));
    } else if (st.nr_good > 0) {
        if (st.nr_good == 1) {
            bisectLogPrintf(util.fmt("status: waiting for '{s}' commit, {d} '{s}' commit known\n", .{ terms.bad, st.nr_good, terms.good }));
        } else bisectLogPrintf(util.fmt("status: waiting for '{s}' commit, {d} '{s}' commits known\n", .{ terms.bad, st.nr_good, terms.good }));
    } else {
        bisectLogPrintf(util.fmt("status: waiting for '{s}' commit(s), '{s}' commit known\n", .{ terms.good, terms.bad }));
    }
}

fn bisectNextCheck(terms: *const Terms, current_term: ?[]const u8) i32 {
    const st = bisectStatus(terms);
    return decideNext(terms, current_term, st.nr_good == 0, st.nr_bad == 0);
}

fn getTerms(terms: *Terms, file_missing_is_ok: bool) i32 {
    const data = os.readFile(gp("BISECT_TERMS")) orelse return if (file_missing_is_ok) 0 else -1;
    var it = std.mem.splitScalar(u8, data, '\n');
    const b = it.next().?;
    if (data.len == 0) return -1;
    const g = it.next() orelse return -1;
    if (g.len == 0 and it.peek() == null) return -1;
    terms.* = .{ .bad = b, .good = g };
    return 0;
}

fn bisectTerms(terms: *Terms, option: ?[]const u8) i32 {
    if (getTerms(terms, false) != 0) return errRet("no terms defined", .{});
    const opt = option orelse {
        util.outf("Your current terms are '{s}' for the old state\nand '{s}' for the new state.\n", .{ terms.good, terms.bad });
        return 0;
    };
    if (oneOf(opt, &.{ "--term-good", "--term-old" })) {
        util.outf("{s}\n", .{terms.good});
    } else if (oneOf(opt, &.{ "--term-bad", "--term-new" })) {
        util.outf("{s}\n", .{terms.bad});
    } else return errRet("invalid argument {s} for 'git bisect terms'.\nSupported options are: --term-good|--term-old and --term-bad|--term-new.", .{opt});
    return 0;
}

fn bisectSkippedCommits(terms: *const Terms) i32 {
    revision.resetRevisionWalk();
    var revs = revision.RevInfo.init("");
    _ = revision.setupRevisions(&revs, &.{"bisect"}, .{});
    const bpfx = util.concat(&.{ "refs/bisect/", terms.bad });
    const gpfx = util.concat(&.{ "refs/bisect/", terms.good, "-" });
    const all = refs.list("refs/bisect/");
    for (all) |r| if (util.startsWith(r.name, bpfx)) revision.addPendingOid(&revs, r.name, r.oid, 0);
    for (all) |r| if (util.startsWith(r.name, gpfx)) revision.addPendingOid(&revs, r.name, r.oid, cn.UNINTERESTING);
    if (!revision.prepareRevisionWalk(&revs)) return errRet("revision walk setup failed", .{});
    var b: util.Buf = .empty;
    util.bufAppend(&b, "# only skipped commits left to test\n");
    while (revision.getRevision(&revs)) |c| {
        util.bufPrint(&b, "# possible first '{s}' commit: [{s}] {s}\n", .{ terms.bad, hash.hex(c.obj.oid), subjectOf(c.obj.oid) });
    }
    revision.resetRevisionWalk();
    os.appendFile(gp("BISECT_LOG"), b.items) catch return errRet("could not open '{s}' for appending", .{gp("BISECT_LOG")});
    return 0;
}

fn bisectSuccessful(terms: *const Terms) i32 {
    const bad_ref = util.concat(&.{ "refs/bisect/", terms.bad });
    const oid = revparse.getCommit(bad_ref) orelse {
        util.err("could not find commit for '{s}'", .{bad_ref});
        return BISECT_FAILED;
    };
    return appendFile(gp("BISECT_LOG"), util.fmt("# first '{s}' commit: [{s}] {s}\n", .{ terms.bad, hash.hex(oid), subjectOf(oid) }));
}

fn bisectNext(terms: *Terms, prefix: []const u8) i32 {
    if (bisectAutostart(terms) != 0) return BISECT_FAILED;
    if (bisectNextCheck(terms, terms.good) != 0) return BISECT_FAILED;
    var res = bisectNextAll(prefix);
    if (res == BISECT_INTERNAL_SUCCESS_1ST_BAD_FOUND) {
        res = bisectSuccessful(terms);
        return if (res != 0) res else BISECT_INTERNAL_SUCCESS_1ST_BAD_FOUND;
    } else if (res == BISECT_ONLY_SKIPPED_LEFT) {
        res = bisectSkippedCommits(terms);
        return if (res != 0) res else BISECT_ONLY_SKIPPED_LEFT;
    }
    return res;
}

fn bisectAutoNext(terms: *Terms, prefix: []const u8) i32 {
    if (bisectNextCheck(terms, null) != 0) {
        bisectPrintStatus(terms);
        return BISECT_OK;
    }
    return bisectNext(terms, prefix);
}

fn bisectStart(terms: *Terms, argv: []const []const u8) i32 {
    const r = repo_mod.repo();
    var no_checkout = r.work_tree == null;
    var first_parent_only = false;
    var has_double_dash = false;
    var must_write_terms = false;
    var reset_when_found: ResetMode = .none;
    var revs: std.ArrayList([]const u8) = .empty;
    var states: std.ArrayList([]const u8) = .empty;
    for (argv) |a| {
        if (util.eql(a, "--")) {
            has_double_dash = true;
            break;
        }
    }
    var i: usize = 0;
    var res: i32 = BISECT_OK;
    while (i < argv.len) : (i += 1) {
        const arg = argv[i];
        if (util.eql(arg, "--")) {
            break;
        } else if (util.eql(arg, "--no-checkout")) {
            no_checkout = true;
        } else if (util.eql(arg, "--first-parent")) {
            first_parent_only = true;
        } else if (util.eql(arg, "--reset-when-found")) {
            reset_when_found = .original;
        } else if (util.skipPrefix(arg, "--reset-when-found=")) |v| {
            if (parseResetWhenFound(v, &reset_when_found) != 0) return BISECT_FAILED;
        } else if (util.eql(arg, "--term-good") or util.eql(arg, "--term-old")) {
            i += 1;
            if (argv.len <= i) return errRet("'' is not a valid term", .{});
            must_write_terms = true;
            terms.good = argv[i];
        } else if (util.skipPrefix(arg, "--term-good=") orelse util.skipPrefix(arg, "--term-old=")) |v| {
            must_write_terms = true;
            terms.good = v;
        } else if (util.eql(arg, "--term-bad") or util.eql(arg, "--term-new")) {
            i += 1;
            if (argv.len <= i) return errRet("'' is not a valid term", .{});
            must_write_terms = true;
            terms.bad = argv[i];
        } else if (util.skipPrefix(arg, "--term-bad=") orelse util.skipPrefix(arg, "--term-new=")) |v| {
            must_write_terms = true;
            terms.bad = v;
        } else if (util.startsWith(arg, "--")) {
            return errRet("unrecognized option: '{s}'", .{arg});
        } else if (revparse.getOid(util.concat(&.{ arg, "^{commit}" }))) |oid| {
            revs.append(gpa, util.dupe(&hash.hex(oid))) catch util.oom();
        } else if (has_double_dash) {
            util.die("'{s}' does not appear to be a valid revision", .{arg});
        } else break;
    }
    if (reset_when_found != .none and no_checkout) {
        return errRet("options '{s}' and '{s}' cannot be used together", .{ "--reset-when-found", "--no-checkout" });
    }
    const pathspec_pos = i;
    if (revs.items.len > 0) must_write_terms = true;
    for (revs.items, 0..) |_, k| {
        states.append(gpa, if (k == 0) terms.bad else terms.good) catch util.oom();
    }

    // Verify HEAD
    const rf = refs.resolveFull("HEAD", true);
    var head: []const u8 = "HEAD";
    var head_ok = false;
    if (!rf.broken) {
        head = rf.name;
        head_ok = true;
    }
    if (!head_ok or rf.missing) {
        if (revparse.getOid("HEAD") == null) return errRet("bad HEAD - I need a HEAD", .{});
        head = "HEAD";
    }

    var start_head: []const u8 = "";
    if (!isEmptyOrMissing(gp("BISECT_START"))) {
        start_head = util.trim(os.readFile(gp("BISECT_START")) orelse "");
        if (!no_checkout) {
            util.flushStdout();
            const cr = os.run(&.{ proc.gitBinary(), "checkout", start_head, "--" }, .{});
            if (cr.status != 0 or cr.signaled) {
                return errRet("checking out '{s}' failed. Try 'git bisect start <valid-branch>'.", .{start_head});
            }
        }
    } else {
        const hoid = revparse.getOid(head);
        if (hoid != null and !util.startsWith(head, "refs/heads/")) {
            start_head = util.dupe(&hash.hex(hoid.?));
        } else if (hoid != null) {
            start_head = head["refs/heads/".len..];
        } else return errRet("bad HEAD - strange symbolic ref", .{});
    }

    if (bisectCleanState() != 0) return BISECT_FAILED;

    writeFileStr(gp("BISECT_START"), util.concat(&.{ start_head, "\n" }));
    if (first_parent_only) writeFileStr(gp("BISECT_FIRST_PARENT"), "\n");
    if (reset_when_found != .none) writeFileStr(gp("BISECT_RESET_WHEN_FOUND"), util.concat(&.{ @tagName(reset_when_found), "\n" }));
    finish: {
        if (no_checkout) {
            const oid = revparse.getOid(start_head) orelse {
                res = errRet("invalid ref: '{s}'", .{start_head});
                break :finish;
            };
            refs.updateFlags("BISECT_HEAD", oid, null, "", 0) catch {
                util.err("{s}", .{refs.last_error});
                res = BISECT_FAILED;
                break :finish;
            };
        }
        var names: util.Buf = .empty;
        if (argv.len > 0 and pathspec_pos < argv.len - 1) sqQuoteArgv(&names, argv[pathspec_pos..]);
        writeFileStr(gp("BISECT_NAMES"), util.concat(&.{ names.items, "\n" }));
        for (states.items, 0..) |s, k| {
            if (bisectWrite(s, revs.items[k], terms, true) != 0) {
                res = BISECT_FAILED;
                break :finish;
            }
        }
        if (must_write_terms and writeTerms(terms.bad, terms.good) != 0) {
            res = BISECT_FAILED;
            break :finish;
        }
        var lb: util.Buf = .empty;
        util.bufAppend(&lb, "git bisect start");
        sqQuoteArgv(&lb, argv);
        util.bufByte(&lb, '\n');
        if (appendFile(gp("BISECT_LOG"), lb.items) != 0) res = BISECT_FAILED;
    }
    if (res != 0) return res;
    res = bisectAutoNext(terms, "");
    if (!isBisectSuccess(res)) _ = bisectCleanState();
    return res;
}

fn bisectAutostart(terms: *Terms) i32 {
    if (!isEmptyOrMissing(gp("BISECT_START"))) return 0;
    util.eprint("You need to start by \"git bisect start\"\n\n", .{});
    if (!os.isatty(0)) return -1;
    const yesno = prompt("Do you want me to do it for you [Y/n]? ");
    if (yesno.len > 0 and std.ascii.toLower(yesno[0]) == 'n') return -1;
    return bisectStart(terms, &.{});
}

fn bisectState(terms: *Terms, argv0: []const []const u8) i32 {
    var argv = argv0;
    if (argv.len == 0) return errRet("Please call `--bisect-state` with at least one argument", .{});
    if (bisectAutostart(terms) != 0) return BISECT_FAILED;
    const state = argv[0];
    if (checkAndSetTerms(terms, state) != 0 or !oneOf(state, &.{ terms.good, terms.bad, "skip" })) return BISECT_FAILED;
    argv = argv[1..];
    if (argv.len > 1 and util.eql(state, terms.bad))
        return errRet("'git bisect {s}' can take only one argument.", .{terms.bad});
    var revs: std.ArrayList(Oid) = .empty;
    if (argv.len == 0) {
        var head: []const u8 = "BISECT_HEAD";
        var oid = revparse.getOid(head);
        if (oid == null) {
            head = "HEAD";
            oid = revparse.getOid(head);
        }
        if (oid == null) util.err("Bad rev input: {s}", .{head});
        revs.append(gpa, oid orelse hash.zero) catch util.oom();
    }
    for (argv) |a| {
        const oid = revparse.getOid(a) orelse {
            return errRet("Bad rev input: {s}", .{a});
        };
        const c = cn.lookupCommitReference(oid) orelse util.die("Bad rev input (not a commit): {s}", .{a});
        revs.append(gpa, c.obj.oid) catch util.oom();
    }
    var verify_expected = true;
    const expected = if (refs.resolve("BISECT_EXPECTED_REV")) |e| e.oid else blk: {
        verify_expected = false;
        break :blk hash.zero;
    };
    for (revs.items) |o| {
        if (bisectWrite(state, util.dupe(&hash.hex(o)), terms, false) != 0) return BISECT_FAILED;
        if (verify_expected and !hash.eql(o, expected)) {
            unlinkOrWarn(gp("BISECT_ANCESTORS_OK"));
            refs.deleteRef("BISECT_EXPECTED_REV", null, refs.F_NO_DEREF, null) catch {};
            verify_expected = false;
        }
    }
    return bisectAutoNext(terms, "");
}

fn bisectLog() i32 {
    const f = gp("BISECT_LOG");
    if (isEmptyOrMissing(f)) return errRet("We are not bisecting.", .{});
    const data = os.readFile(f) orelse return BISECT_FAILED;
    util.out(data);
    return BISECT_OK;
}

fn processReplayLine(terms: *Terms, line: []const u8) i32 {
    var p = std.mem.trimStart(u8, line, " \t");
    p = util.skipPrefix(p, "git bisect") orelse util.skipPrefix(p, "git-bisect") orelse return 0;
    if (p.len == 0 or !std.ascii.isWhitespace(p[0])) return 0;
    p = std.mem.trimStart(u8, p, " \t");
    const we = std.mem.indexOfAny(u8, p, " \t") orelse p.len;
    const word = p[0..we];
    const rev = std.mem.trimStart(u8, p[we..], " \t");
    if (getTerms(terms, true) != 0) return errRet("no terms defined", .{});
    if (checkAndSetTerms(terms, word) != 0) return -1;
    if (util.eql(word, "start")) {
        const args = sqDequote(rev) orelse &.{};
        return bisectStart(terms, args);
    }
    if (oneOf(word, &.{ terms.good, terms.bad, "skip" })) return bisectWrite(word, rev, terms, false);
    if (util.eql(word, "terms")) {
        const args = sqDequote(rev) orelse &.{};
        return bisectTerms(terms, if (args.len == 1) args[0] else null);
    }
    return errRet("'{s}'?? what are you talking about?", .{word});
}

fn bisectReplay(terms: *Terms, filename: []const u8) i32 {
    if (isEmptyOrMissing(filename)) return errRet("cannot read file '{s}' for replaying", .{filename});
    if (bisectCleanState() != 0) return BISECT_FAILED;
    const data = os.readFile(filename) orelse return BISECT_FAILED;
    var it = std.mem.splitScalar(u8, data, '\n');
    var res: i32 = 0;
    while (it.next()) |l0| {
        if (it.peek() == null and l0.len == 0) break;
        const l = if (l0.len > 0 and l0[l0.len - 1] == '\r') l0[0 .. l0.len - 1] else l0;
        res = processReplayLine(terms, l);
        if (res != 0) break;
    }
    if (res != 0) return BISECT_FAILED;
    return bisectAutoNext(terms, "");
}

fn bisectSkip(terms: *Terms, argv: []const []const u8) i32 {
    var st: std.ArrayList([]const u8) = .empty;
    st.append(gpa, "skip") catch util.oom();
    for (argv) |a| {
        if (std.mem.indexOf(u8, a, "..") != null) {
            var revs = revision.RevInfo.init("");
            _ = revision.setupRevisions(&revs, &.{ "skip", a }, .{});
            if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
            while (revision.getRevision(&revs)) |c| st.append(gpa, util.dupe(&hash.hex(c.obj.oid))) catch util.oom();
            revision.resetRevisionWalk();
        } else st.append(gpa, a) catch util.oom();
    }
    return bisectState(terms, st.items);
}

fn bisectVisualize(terms: *Terms, argv: []const []const u8) i32 {
    if (bisectNextCheck(terms, null) != 0) return BISECT_FAILED;
    var args: std.ArrayList([]const u8) = .empty;
    if (argv.len == 0) {
        args.appendSlice(gpa, &.{ proc.gitBinary(), "log" }) catch util.oom();
    } else {
        if (argv[0].len > 0 and argv[0][0] == '-') {
            args.appendSlice(gpa, &.{ proc.gitBinary(), "log" }) catch util.oom();
        } else if (!util.eql(argv[0], "tig") and !util.startsWith(argv[0], "git")) {
            args.append(gpa, proc.gitBinary()) catch util.oom();
        }
        args.appendSlice(gpa, argv) catch util.oom();
    }
    args.appendSlice(gpa, &.{ "--bisect", "--" }) catch util.oom();
    if (os.readFile(gp("BISECT_NAMES"))) |names| {
        if (sqDequote(util.trim(names))) |w| args.appendSlice(gpa, w) catch util.oom();
    }
    util.flushStdout();
    const r = os.run(args.items, .{ .no_stdin = true });
    if (r.signaled) return -1;
    return @intCast(r.status);
}

fn doBisectRun(command: []const u8) i32 {
    util.outf("running {s}\n", .{command});
    util.flushStdout();
    const r = os.run(&.{command}, .{ .use_shell = true });
    if (r.signaled) return -1;
    return @intCast(r.status);
}

fn verifyGood(terms: *const Terms, command: []const u8) i32 {
    const no_checkout = refs.exists("BISECT_HEAD");
    const gpfx = util.concat(&.{ "refs/bisect/", terms.good, "-" });
    var good_rev: Oid = hash.zero;
    for (refs.list("refs/bisect/")) |r| {
        if (util.startsWith(r.name, gpfx)) {
            good_rev = r.oid;
            break;
        }
    }
    const cur = refs.resolve(if (no_checkout) "BISECT_HEAD" else "HEAD") orelse return -1;
    if (bisectCheckout(good_rev, no_checkout) != BISECT_OK) return -1;
    const rc = doBisectRun(command);
    if (bisectCheckout(cur.oid, no_checkout) != BISECT_OK) return -1;
    return rc;
}

extern "c" fn dup(fd: c_int) c_int;
extern "c" fn dup2(old: c_int, new: c_int) c_int;
extern "c" fn close(fd: c_int) c_int;
extern "c" fn open(path: [*:0]const u8, flags: c_int, ...) c_int;

fn bisectRun(terms: *Terms, argv0: []const []const u8) i32 {
    var argv = argv0;
    if (bisectNextCheck(terms, null) != 0) return BISECT_FAILED;
    var mode: ResetMode = .none;
    if (argv.len > 0 and util.eql(argv[0], "--reset-when-found")) {
        mode = .original;
    } else if (argv.len > 0) {
        if (util.skipPrefix(argv[0], "--reset-when-found=")) |v| {
            if (parseResetWhenFound(v, &mode) != 0) return BISECT_FAILED;
        }
    }
    if (mode != .none and refs.exists("BISECT_HEAD"))
        return errRet("options '{s}' and '{s}' cannot be used together", .{ "--reset-when-found", "--no-checkout" });
    if (mode != .none) {
        writeFileStr(gp("BISECT_RESET_WHEN_FOUND"), util.concat(&.{ @tagName(mode), "\n" }));
        argv = argv[1..];
    }
    if (argv.len == 0) {
        util.err("bisect run failed: no command provided.", .{});
        return BISECT_FAILED;
    }
    var cb: util.Buf = .empty;
    sqQuoteArgv(&cb, argv);
    const command = std.mem.trimStart(u8, cb.items, " \t\n");
    var is_first_run = true;
    var res: i32 = BISECT_OK;
    while (true) {
        res = doBisectRun(command);
        if (is_first_run and (res == 126 or res == 127)) {
            const rc = verifyGood(terms, command);
            is_first_run = false;
            if (rc < 0 or 128 <= rc) {
                util.err("unable to verify {s} on '{s}' revision", .{ command, terms.good });
                res = BISECT_FAILED;
                break;
            }
            if (rc == res) {
                util.err("bogus exit code {d} for '{s}' revision", .{ rc, terms.good });
                res = BISECT_FAILED;
                break;
            }
        }
        if (res < 0 or 128 <= res) {
            util.err("bisect run failed: exit code {d} from {s} is < 0 or >= 128", .{ res, command });
            break;
        }
        const new_state: []const u8 = if (res == 125) "skip" else if (res == 0) terms.good else terms.bad;
        const run_path = gp("BISECT_RUN");
        os.writeFile(run_path, "", 0o666) catch {
            res = errRet("cannot open file '{s}' for writing", .{run_path});
            break;
        };
        const pz = os.z(run_path);
        const tmp_fd = open(pz, 1); // O_WRONLY
        if (tmp_fd < 0) {
            res = errRet("cannot open file '{s}' for writing", .{run_path});
            break;
        }
        util.flushStdout();
        const saved = dup(1);
        if (saved < 0 or dup2(tmp_fd, 1) < 0) {
            res = errRet("could not duplicate stdout", .{});
            if (saved >= 0) _ = close(saved);
            _ = close(tmp_fd);
            break;
        }
        res = bisectState(terms, &.{new_state});
        util.flushStdout();
        _ = dup2(saved, 1);
        _ = close(saved);
        _ = close(tmp_fd);
        if (os.readFile(run_path)) |d| util.out(d) else util.err("cannot open file '{s}' for reading", .{run_path});
        if (res == BISECT_ONLY_SKIPPED_LEFT) {
            util.err("bisect run cannot continue any more", .{});
        } else if (res == BISECT_INTERNAL_SUCCESS_MERGE_BASE) {
            util.out("bisect run success\n");
            res = BISECT_OK;
        } else if (res == BISECT_INTERNAL_SUCCESS_1ST_BAD_FOUND) {
            util.outf("bisect found first '{s}' commit\n", .{terms.bad});
        } else if (res != 0) {
            util.err("bisect run failed: 'git bisect {s}' exited with error code {d}", .{ new_state, res });
        } else continue;
        break;
    }
    return res;
}

// ---------------- dispatch ----------------

fn needCommand() noreturn {
    util.eprint("fatal: need a command\n\n", .{});
    po.usageExit(&bisect_usage, &.{}, true);
}

pub fn cmdBisect(args: []const []const u8) u8 {
    const argv = args[1..];
    const prefix = repo_mod.repo().prefix;
    var res: i32 = 0;
    if (argv.len == 0) needCommand();
    const sub = argv[0];
    const rest = argv[1..];
    if (util.eql(sub, "-h") or util.eql(sub, "--help-all")) po.usageExit(&bisect_usage, &.{}, false);
    var terms = Terms{};
    if (util.eql(sub, "reset")) {
        if (rest.len > 1) {
            res = errRet("'{s}' requires either no argument or a commit", .{"git bisect reset"});
        } else {
            res = bisectReset(if (rest.len == 1) rest[0] else null, false);
            if (res == 0) res = bisectCleanState();
        }
    } else if (util.eql(sub, "terms")) {
        if (rest.len > 1) {
            res = errRet("'{s}' requires 0 or 1 argument", .{"git bisect terms"});
        } else res = bisectTerms(&terms, if (rest.len == 1) rest[0] else null);
    } else if (util.eql(sub, "start")) {
        res = bisectStart(&terms, rest);
    } else if (util.eql(sub, "next")) {
        if (rest.len > 0) {
            res = errRet("'{s}' requires 0 arguments", .{"git bisect next"});
        } else if (getTerms(&terms, true) != 0) {
            res = errRet("no terms defined", .{});
        } else res = bisectNext(&terms, prefix);
    } else if (util.eql(sub, "log")) {
        res = bisectLog();
    } else if (util.eql(sub, "replay")) {
        if (rest.len != 1) {
            res = errRet("no logfile given", .{});
        } else res = bisectReplay(&terms, rest[0]);
    } else if (util.eql(sub, "skip")) {
        if (getTerms(&terms, true) != 0) {
            res = errRet("no terms defined", .{});
        } else res = bisectSkip(&terms, rest);
    } else if (util.eql(sub, "visualize") or util.eql(sub, "view")) {
        if (getTerms(&terms, true) != 0) {
            res = errRet("no terms defined", .{});
        } else res = bisectVisualize(&terms, rest);
    } else if (util.eql(sub, "run")) {
        if (rest.len == 0) {
            res = errRet("'{s}' failed: no command provided.", .{"git bisect run"});
        } else if (getTerms(&terms, true) != 0) {
            res = errRet("no terms defined", .{});
        } else res = bisectRun(&terms, rest);
    } else if (util.eql(sub, "help")) {
        po.usageWithOptions(&bisect_usage, &.{});
    } else if (sub.len > 1 and sub[0] == '-') {
        if (util.startsWith(sub, "--")) {
            util.err("unknown option `{s}'", .{sub[2..]});
        } else util.err("unknown switch `{c}'", .{sub[1]});
        po.usageWithOptions(&bisect_usage, &.{});
    } else {
        if (getTerms(&terms, true) != 0) {
            res = errRet("no terms defined", .{});
        } else if (checkAndSetTerms(&terms, sub) != 0 or !oneOf(sub, &.{ terms.good, terms.bad })) {
            util.eprint("fatal: unknown command: '{s}'\n\n", .{sub});
            po.usageExit(&bisect_usage, &.{}, true);
        } else res = bisectState(&terms, argv);
    }
    if (res == BISECT_INTERNAL_SUCCESS_1ST_BAD_FOUND) {
        var mode: ResetMode = .none;
        if (readResetWhenFound(&mode) != 0) {
            res = BISECT_FAILED;
        } else if (mode != .none and bisectResetWhenFound(mode) != 0) res = BISECT_FAILED;
    }
    if (isBisectSuccess(res)) return 0;
    const neg: i32 = -res;
    return @truncate(@as(u32, @bitCast(neg)));
}
