//! Builtin command table and dispatch (port of git.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const main = @import("main.zig");
const gpa = util.gpa;

pub const Fn = *const fn (args: []const []const u8) u8;

pub const RUN_SETUP: u8 = 1;
pub const RUN_SETUP_GENTLY: u8 = 2;
pub const USE_PAGER: u8 = 4;
pub const NEED_WORK_TREE: u8 = 8;
pub const NO_PARSEOPT: u8 = 16;

pub const Cmd = struct { name: []const u8, f: Fn, flags: u8 };

const c_init = @import("cmd/init.zig");
const c_gc = @import("cmd/gc.zig");
const c_prunepacked = @import("cmd/prunepacked.zig");
const c_repack = @import("cmd/repack.zig");
const c_countobjects = @import("cmd/countobjects.zig");
const c_grep = @import("cmd/grep.zig");
const c_indexpack = @import("cmd/indexpack.zig");
const c_packobjects = @import("cmd/packobjects.zig");
const c_misc = @import("cmd/misc.zig");
const c_plumb = @import("cmd/plumbing.zig");
const c_updidx = @import("cmd/updateindex.zig");
const c_revparse = @import("cmd/revparse.zig");
const c_add = @import("cmd/add.zig");
const c_rm = @import("cmd/rm.zig");
const c_fastimport = @import("cmd/fastimport.zig");
const c_fastexport = @import("cmd/fastexport.zig");
const c_replace = @import("cmd/replace.zig");
const c_bundle = @import("cmd/bundle.zig");
const c_archive = @import("cmd/archive.zig");
const c_readtree = @import("cmd/readtree.zig");
const c_trailers = @import("cmd/trailers.zig");
const c_reset = @import("cmd/reset.zig");
const c_checkoutindex = @import("cmd/checkoutindex.zig");
const c_checkout = @import("cmd/checkout.zig");
const c_mv = @import("cmd/mv.zig");
const c_commit = @import("cmd/commit.zig");
const c_mergebase = @import("cmd/mergebase.zig");
const c_mergefile = @import("cmd/mergefile.zig");
const c_mergetree = @import("cmd/mergetree.zig");
const c_fmtmergemsg = @import("cmd/fmtmergemsg.zig");
const c_merge = @import("cmd/merge.zig");
const c_mergescripts = @import("cmd/mergescripts.zig");
const c_revert = @import("cmd/revert.zig");
const c_describe = @import("cmd/describe.zig");
const c_log = @import("cmd/log.zig");
const c_lsfiles = @import("cmd/lsfiles.zig");
const c_chkign = @import("cmd/checkignore.zig");
const c_clean = @import("cmd/clean.zig");
const c_refs = @import("cmd/refs.zig");
const c_status = @import("cmd/status.zig");
const c_column = @import("cmd/column.zig");
const c_blame = @import("cmd/blame.zig");
const c_showbranch = @import("cmd/showbranch.zig");
const c_notes = @import("cmd/notes.zig");
const c_patchid = @import("cmd/patchid.zig");
const c_apply = @import("cmd/apply.zig");
const c_am = @import("cmd/am.zig");
const c_rebase = @import("cmd/rebase.zig");
const c_checkmailmap = @import("cmd/checkmailmap.zig");
const c_tag = @import("cmd/tag.zig");
const c_branch = @import("cmd/branch.zig");
const c_config = @import("cmd/config.zig");
const c_uploadpack = @import("cmd/uploadpack.zig");
const c_lsremote = @import("cmd/lsremote.zig");
const c_remote = @import("cmd/remote.zig");
const c_fetch = @import("cmd/fetch.zig");
const c_clone = @import("cmd/clone.zig");
const c_receivepack = @import("cmd/receivepack.zig");
const c_push = @import("cmd/push.zig");
const c_pull = @import("cmd/pull.zig");
const c_worktree = @import("cmd/worktree.zig");
const c_stash = @import("cmd/stash.zig");
const c_bisect = @import("cmd/bisect.zig");
const c_fsck = @import("cmd/fsck.zig");
const c_prune = @import("cmd/prune.zig");
const c_diff = @import("cmd/diff.zig");
const c_rerere = @import("cmd/rerere.zig");
const c_hook = @import("cmd/hook.zig");
const c_sparse = @import("cmd/sparsecheckout.zig");
const c_commitgraph = @import("cmd/commitgraph.zig");
const c_midx = @import("cmd/midx.zig");
const c_submodule = @import("cmd/submodule.zig");
const c_rangediff = @import("cmd/rangediff.zig");
const c_verify = @import("cmd/verify.zig");

pub const table = [_]Cmd{
    .{ .name = "diff", .f = c_diff.cmdDiff, .flags = RUN_SETUP_GENTLY | USE_PAGER },
    .{ .name = "diff-files", .f = c_diff.cmdDiffFiles, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "diff-index", .f = c_diff.cmdDiffIndex, .flags = RUN_SETUP },
    .{ .name = "diff-tree", .f = c_diff.cmdDiffTree, .flags = RUN_SETUP },
    .{ .name = "difftool", .f = @import("cmd/difftool.zig").cmdDifftool, .flags = RUN_SETUP_GENTLY },
    .{ .name = "send-email", .f = @import("cmd/sendemail.zig").cmdSendEmail, .flags = 0 },
    .{ .name = "difftool--helper", .f = @import("cmd/difftool.zig").cmdDifftoolHelper, .flags = 0 },
    .{ .name = "mergetool", .f = @import("cmd/mergetool.zig").cmdMergetool, .flags = RUN_SETUP_GENTLY },
    .{ .name = "grep", .f = c_grep.cmdGrep, .flags = RUN_SETUP_GENTLY },
    .{ .name = "column", .f = c_column.cmdColumn, .flags = RUN_SETUP_GENTLY },
    .{ .name = "blame", .f = c_blame.cmdBlame, .flags = RUN_SETUP },
    .{ .name = "pickaxe", .f = c_blame.cmdBlame, .flags = RUN_SETUP },
    .{ .name = "annotate", .f = c_blame.cmdAnnotate, .flags = RUN_SETUP },
    .{ .name = "show-branch", .f = c_showbranch.cmdShowBranch, .flags = RUN_SETUP },
    .{ .name = "notes", .f = c_notes.cmdNotes, .flags = RUN_SETUP },
    .{ .name = "patch-id", .f = c_patchid.cmdPatchId, .flags = RUN_SETUP_GENTLY | NO_PARSEOPT },
    .{ .name = "apply", .f = c_apply.cmdApply, .flags = RUN_SETUP_GENTLY },
    .{ .name = "am", .f = c_am.cmdAm, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "rebase", .f = c_rebase.cmdRebase, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "check-mailmap", .f = c_checkmailmap.cmdCheckMailmap, .flags = RUN_SETUP },
    .{ .name = "mailinfo", .f = @import("cmd/mailinfo.zig").cmdMailinfo, .flags = RUN_SETUP_GENTLY | NO_PARSEOPT },
    .{ .name = "mailsplit", .f = @import("cmd/mailsplit.zig").cmdMailsplit, .flags = NO_PARSEOPT },
    .{ .name = "init", .f = c_init.cmdInit, .flags = 0 },
    .{ .name = "init-db", .f = c_init.cmdInit, .flags = 0 },
    .{ .name = "version", .f = c_misc.cmdVersion, .flags = RUN_SETUP_GENTLY },
    .{ .name = "credential", .f = @import("cmd/credential.zig").cmdCredential, .flags = RUN_SETUP_GENTLY },
    .{ .name = "credential-store", .f = @import("cmd/credential.zig").cmdCredentialStore, .flags = RUN_SETUP_GENTLY },
    .{ .name = "credential-cache", .f = @import("cmd/credential_cache.zig").cmdCredentialCache, .flags = RUN_SETUP_GENTLY },
    .{ .name = "credential-cache--daemon", .f = @import("cmd/credential_cache.zig").cmdCredentialCacheDaemon, .flags = RUN_SETUP_GENTLY },
    .{ .name = "var", .f = c_misc.cmdVar, .flags = RUN_SETUP_GENTLY },
    .{ .name = "stripspace", .f = c_misc.cmdStripspace, .flags = RUN_SETUP_GENTLY },
    .{ .name = "help", .f = @import("help.zig").cmdHelp, .flags = 0 },
    .{ .name = "web--browse", .f = @import("help.zig").cmdWebBrowse, .flags = RUN_SETUP_GENTLY },
    .{ .name = "hash-object", .f = c_plumb.cmdHashObject, .flags = 0 },
    .{ .name = "cat-file", .f = c_plumb.cmdCatFile, .flags = RUN_SETUP },
    .{ .name = "write-tree", .f = c_plumb.cmdWriteTree, .flags = RUN_SETUP },
    .{ .name = "commit-tree", .f = c_plumb.cmdCommitTree, .flags = RUN_SETUP },
    .{ .name = "mktree", .f = c_plumb.cmdMktree, .flags = RUN_SETUP },
    .{ .name = "repack", .f = c_repack.cmdRepack, .flags = RUN_SETUP },
    .{ .name = "gc", .f = c_gc.cmdGc, .flags = RUN_SETUP },
    .{ .name = "prune-packed", .f = c_prunepacked.cmdPrunePacked, .flags = RUN_SETUP },
    .{ .name = "update-server-info", .f = c_repack.cmdUpdateServerInfo, .flags = RUN_SETUP },
    .{ .name = "count-objects", .f = c_countobjects.cmdCountObjects, .flags = RUN_SETUP },
    .{ .name = "show-index", .f = c_indexpack.cmdShowIndex, .flags = RUN_SETUP_GENTLY },
    .{ .name = "verify-pack", .f = c_indexpack.cmdVerifyPack, .flags = 0 },
    .{ .name = "unpack-objects", .f = c_indexpack.cmdUnpackObjects, .flags = RUN_SETUP|NO_PARSEOPT },
    .{ .name = "index-pack", .f = c_indexpack.cmdIndexPack, .flags = RUN_SETUP_GENTLY|NO_PARSEOPT },
    .{ .name = "pack-objects", .f = c_packobjects.cmdPackObjects, .flags = RUN_SETUP },
    .{ .name = "update-index", .f = c_updidx.cmdUpdateIndex, .flags = RUN_SETUP },
    .{ .name = "rev-parse", .f = c_revparse.cmdRevParse, .flags = 0 },
    .{ .name = "add", .f = c_add.cmdAdd, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "stage", .f = c_add.cmdAdd, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "rm", .f = c_rm.cmdRm, .flags = RUN_SETUP },
    .{ .name = "fast-import", .f = c_fastimport.cmdFastImport, .flags = RUN_SETUP },
    .{ .name = "fast-export", .f = c_fastexport.cmdFastExport, .flags = RUN_SETUP },
    .{ .name = "replace", .f = c_replace.cmdReplace, .flags = RUN_SETUP },
    .{ .name = "bundle", .f = c_bundle.cmdBundle, .flags = RUN_SETUP_GENTLY },
    .{ .name = "archive", .f = c_archive.cmdArchive, .flags = RUN_SETUP_GENTLY },
    .{ .name = "interpret-trailers", .f = c_trailers.cmdInterpretTrailers, .flags = RUN_SETUP_GENTLY },
    .{ .name = "mv", .f = c_mv.cmdMv, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "read-tree", .f = c_readtree.run, .flags = RUN_SETUP },
    .{ .name = "reset", .f = c_reset.run, .flags = RUN_SETUP },
    .{ .name = "checkout-index", .f = c_checkoutindex.run, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "checkout", .f = c_checkout.runCheckout, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "switch", .f = c_checkout.runSwitch, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "restore", .f = c_checkout.runRestore, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "commit", .f = c_commit.cmdCommit, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "merge-base", .f = c_mergebase.cmdMergeBase, .flags = RUN_SETUP },
    .{ .name = "merge-file", .f = c_mergefile.cmdMergeFile, .flags = RUN_SETUP_GENTLY },
    .{ .name = "merge-tree", .f = c_mergetree.cmdMergeTree, .flags = RUN_SETUP },
    .{ .name = "fmt-merge-msg", .f = c_fmtmergemsg.cmdFmtMergeMsg, .flags = RUN_SETUP },
    .{ .name = "merge", .f = c_merge.cmdMerge, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "cherry-pick", .f = c_revert.cmdCherryPick, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "revert", .f = c_revert.cmdRevert, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "merge-ours", .f = c_merge.cmdMergeOurs, .flags = RUN_SETUP },
    .{ .name = "merge-recursive", .f = c_merge.cmdMergeRecursive, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "merge-recursive-ours", .f = c_merge.cmdMergeRecursive, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "merge-recursive-theirs", .f = c_merge.cmdMergeRecursive, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "merge-subtree", .f = c_merge.cmdMergeRecursive, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "merge-index", .f = c_mergescripts.cmdMergeIndex, .flags = RUN_SETUP },
    .{ .name = "merge-one-file", .f = c_mergescripts.cmdMergeOneFile, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "merge-octopus", .f = c_mergescripts.cmdMergeOctopus, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "merge-resolve", .f = c_mergescripts.cmdMergeResolve, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "unpack-file", .f = c_mergescripts.cmdUnpackFile, .flags = RUN_SETUP },
    .{ .name = "describe", .f = c_describe.cmdDescribe, .flags = RUN_SETUP },
    .{ .name = "name-rev", .f = c_describe.cmdNameRev, .flags = RUN_SETUP },
    .{ .name = "log", .f = c_log.cmdLog, .flags = RUN_SETUP | USE_PAGER },
    .{ .name = "show", .f = c_log.cmdShow, .flags = RUN_SETUP | USE_PAGER },
    .{ .name = "whatchanged", .f = c_log.cmdWhatchanged, .flags = RUN_SETUP | USE_PAGER },
    .{ .name = "rev-list", .f = c_log.cmdRevList, .flags = RUN_SETUP },
    .{ .name = "shortlog", .f = c_log.cmdShortlog, .flags = RUN_SETUP_GENTLY | USE_PAGER },
    .{ .name = "format-patch", .f = c_log.cmdFormatPatch, .flags = RUN_SETUP },
    .{ .name = "cherry", .f = c_log.cmdCherry, .flags = RUN_SETUP },
    .{ .name = "ls-files", .f = c_lsfiles.cmdLsFiles, .flags = RUN_SETUP },
    .{ .name = "ls-tree", .f = c_lsfiles.cmdLsTree, .flags = RUN_SETUP },
    .{ .name = "check-ignore", .f = c_chkign.cmdCheckIgnore, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "check-attr", .f = c_chkign.cmdCheckAttr, .flags = RUN_SETUP },
    .{ .name = "clean", .f = c_clean.cmdClean, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "status", .f = c_status.cmdStatus, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "update-ref", .f = c_refs.cmdUpdateRef, .flags = RUN_SETUP },
    .{ .name = "symbolic-ref", .f = c_refs.cmdSymbolicRef, .flags = RUN_SETUP },
    .{ .name = "show-ref", .f = c_refs.cmdShowRef, .flags = RUN_SETUP },
    .{ .name = "check-ref-format", .f = c_refs.cmdCheckRefFormat, .flags = RUN_SETUP_GENTLY },
    .{ .name = "pack-refs", .f = c_refs.cmdPackRefs, .flags = RUN_SETUP },
    .{ .name = "reflog", .f = c_refs.cmdReflog, .flags = RUN_SETUP },
    .{ .name = "refs", .f = c_refs.cmdRefs, .flags = RUN_SETUP },
    .{ .name = "fsck", .f = c_fsck.cmdFsck, .flags = RUN_SETUP },
    .{ .name = "fsck-objects", .f = c_fsck.cmdFsck, .flags = RUN_SETUP },
    .{ .name = "mktag", .f = c_fsck.cmdMktag, .flags = RUN_SETUP },
    .{ .name = "prune", .f = c_prune.cmdPrune, .flags = RUN_SETUP },
    .{ .name = "for-each-ref", .f = c_refs.cmdForEachRef, .flags = RUN_SETUP },
    .{ .name = "tag", .f = c_tag.cmdTag, .flags = RUN_SETUP },
    .{ .name = "branch", .f = c_branch.cmdBranch, .flags = RUN_SETUP },
    .{ .name = "config", .f = c_config.cmdConfig, .flags = RUN_SETUP_GENTLY },
    .{ .name = "upload-pack", .f = c_uploadpack.cmdUploadPack, .flags = 0 },
    .{ .name = "ls-remote", .f = c_lsremote.cmdLsRemote, .flags = RUN_SETUP_GENTLY },
    .{ .name = "remote", .f = c_remote.cmdRemote, .flags = RUN_SETUP },
    .{ .name = "fetch", .f = c_fetch.cmdFetch, .flags = RUN_SETUP },
    .{ .name = "clone", .f = c_clone.cmdClone, .flags = 0 },
    .{ .name = "receive-pack", .f = c_receivepack.cmdReceivePack, .flags = 0 },
    .{ .name = "remote-ext", .f = @import("cmd/remotehelpers.zig").cmdRemoteExt, .flags = NO_PARSEOPT },
    .{ .name = "remote-fd", .f = @import("cmd/remotehelpers.zig").cmdRemoteFd, .flags = NO_PARSEOPT },
    .{ .name = "push", .f = c_push.cmdPush, .flags = RUN_SETUP },
    .{ .name = "pull", .f = c_pull.cmdPull, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "fetch-pack", .f = @import("cmd/fetchpack_cmd.zig").cmdFetchPack, .flags = RUN_SETUP | NO_PARSEOPT },
    .{ .name = "send-pack", .f = c_push.cmdSendPack, .flags = RUN_SETUP | NO_PARSEOPT },
    .{ .name = "worktree", .f = c_worktree.cmdWorktree, .flags = RUN_SETUP },
    .{ .name = "stash", .f = c_stash.cmdStash, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "bisect", .f = c_bisect.cmdBisect, .flags = RUN_SETUP },
    .{ .name = "rerere", .f = c_rerere.cmdRerere, .flags = RUN_SETUP },
    .{ .name = "hook", .f = c_hook.cmdHook, .flags = RUN_SETUP_GENTLY },
    .{ .name = "sparse-checkout", .f = c_sparse.cmdSparseCheckout, .flags = RUN_SETUP },
    .{ .name = "commit-graph", .f = c_commitgraph.cmdCommitGraph, .flags = RUN_SETUP },
    .{ .name = "multi-pack-index", .f = c_midx.cmdMultiPackIndex, .flags = RUN_SETUP },
    .{ .name = "submodule", .f = c_submodule.cmdSubmodule, .flags = RUN_SETUP | NEED_WORK_TREE },
    .{ .name = "submodule--helper", .f = c_submodule.cmdSubmoduleHelper, .flags = RUN_SETUP },
    .{ .name = "range-diff", .f = c_rangediff.cmdRangeDiff, .flags = RUN_SETUP | USE_PAGER },
    .{ .name = "verify-tag", .f = c_verify.cmdVerifyTag, .flags = RUN_SETUP },
    .{ .name = "verify-commit", .f = c_verify.cmdVerifyCommit, .flags = RUN_SETUP },
    .{ .name = "maintenance", .f = @import("cmd/maintenance.zig").cmdMaintenance, .flags = RUN_SETUP },
    .{ .name = "for-each-repo", .f = @import("cmd/maintenance.zig").cmdForEachRepo, .flags = RUN_SETUP_GENTLY },
    .{ .name = "replay", .f = @import("cmd/replay.zig").cmdReplay, .flags = RUN_SETUP },
    .{ .name = "get-tar-commit-id", .f = @import("cmd/smallcmds.zig").cmdGetTarCommitId, .flags = NO_PARSEOPT },
    .{ .name = "url-parse", .f = @import("cmd/smallcmds.zig").cmdUrlParse, .flags = 0 },
    .{ .name = "diff-pairs", .f = @import("cmd/smallcmds.zig").cmdDiffPairs, .flags = RUN_SETUP | NO_PARSEOPT },
    .{ .name = "pack-redundant", .f = @import("cmd/smallcmds.zig").cmdPackRedundant, .flags = RUN_SETUP | NO_PARSEOPT },
    .{ .name = "request-pull", .f = @import("cmd/requestpull.zig").cmdRequestPull, .flags = RUN_SETUP },
    .{ .name = "filter-branch", .f = @import("cmd/filterbranch.zig").cmdFilterBranch, .flags = 0 },
    .{ .name = "quiltimport", .f = @import("cmd/quiltimport.zig").cmdQuiltimport, .flags = 0 },
    .{ .name = "shell", .f = @import("cmd/gitshell.zig").cmdShell, .flags = 0 },
    .{ .name = "bugreport", .f = @import("cmd/bugreport.zig").cmdBugreport, .flags = RUN_SETUP_GENTLY },
    .{ .name = "diagnose", .f = @import("cmd/bugreport.zig").cmdDiagnose, .flags = RUN_SETUP_GENTLY },
    .{ .name = "format-rev", .f = @import("cmd/formatrev.zig").cmdFormatRev, .flags = RUN_SETUP },
    .{ .name = "repo", .f = @import("cmd/repo.zig").cmdRepo, .flags = RUN_SETUP },
    .{ .name = "last-modified", .f = @import("cmd/lastmodified.zig").cmdLastModified, .flags = RUN_SETUP },
    .{ .name = "upload-archive", .f = @import("cmd/uploadarchive.zig").cmdUploadArchive, .flags = NO_PARSEOPT },
    .{ .name = "upload-archive--writer", .f = @import("cmd/uploadarchive.zig").cmdUploadArchiveWriter, .flags = NO_PARSEOPT },
    .{ .name = "backfill", .f = @import("cmd/backfill.zig").cmdBackfill, .flags = RUN_SETUP },
    .{ .name = "history", .f = @import("cmd/history.zig").cmdHistory, .flags = RUN_SETUP },
};

pub fn find(name: []const u8) ?*const Cmd {
    for (&table) |*c| {
        if (util.eql(c.name, name)) return c;
    }
    return null;
}

pub fn listCommands() void {
    for (table) |c| util.outf("{s}\n", .{c.name});
}

pub fn dispatchName(name: []const u8, args: []const []const u8) u8 {
    var l: std.ArrayList([]const u8) = .empty;
    l.append(gpa, name) catch util.oom();
    l.appendSlice(gpa, args) catch util.oom();
    return dispatch(l.items);
}

pub fn runBuiltin(c: *const Cmd, args: []const []const u8) u8 {
    const help = args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"));
    if (c.flags & RUN_SETUP != 0 and !help) {
        repo_mod.setup(false);
    } else if (c.flags & (RUN_SETUP | RUN_SETUP_GENTLY) != 0) {
        repo_mod.setup(true);
        // `git <cmd> -h` outside a repository must still show usage: give
        // commands a placeholder repo so they reach option parsing.
        if (help and c.flags & RUN_SETUP != 0 and repo_mod.repo_ == null) {
            const d = gpa.create(repo_mod.Repo) catch util.oom();
            d.* = .{ .git_dir = ".git", .common_dir = ".git", .work_tree = "." };
            repo_mod.repo_ = d;
        }
    } else {
        // commands not needing setup still read config lazily
        repo_mod.loadConfig();
    }
    if (c.flags & (RUN_SETUP | RUN_SETUP_GENTLY) != 0 and repo_mod.have_repository) repo_mod.traceRepoSetup();
    if (c.flags & NEED_WORK_TREE != 0 and !help) {
        _ = repo_mod.requireWorkTree(c.name);
    }
    @import("trace.zig").argv("git.c", 0, "trace: built-in: git", args);
    // cmd_reset() calls setup_work_tree() itself for non-soft resets.
    if (!help and util.eql(c.name, "reset") and repo_mod.outside_worktree) {
        if (repo_mod.repo_) |r| if (r.work_tree != null) {
            var soft = false;
            for (args) |a| {
                if (util.eql(a, "--")) break;
                if (util.eql(a, "--soft")) soft = true;
            }
            if (!soft) _ = repo_mod.requireWorkTree(c.name);
        };
    }
    if (repo_mod.repo_) |r| {
        @import("parseopt.zig").prefix = r.prefix;
    }
    const pager_on = main.use_pager orelse false;
    if (pager_on) setupPager();
    // Commands that call disable_replace_refs() in git (or run such
    // commands as subprocesses whose work we do in-process).
    for ([_][]const u8{ "fsck", "index-pack", "pack-objects", "replace", "multi-pack-index", "upload-pack", "unpack-objects", "prune", "commit-graph", "repack", "gc", "clone", "fetch", "push", "receive-pack", "fetch-pack", "send-pack", "bundle" }) |n| {
        if (util.eql(c.name, n)) @import("odb.zig").disableReplaceRefs();
    }
    @import("notes.zig").installHooks();
    return c.f(args);
}

pub fn setupPager() void {
    if (!os.isatty(1)) return;
    const pager = os.getenv("GIT_PAGER") orelse repo_mod.cfg.get("core.pager") orelse os.getenv("PAGER") orelse "less";
    if (pager.len == 0 or util.eql(pager, "cat")) return;
    util.flushStdout();
    os.startPager(pager);
}

pub fn splitCmdline(s: []const u8) ?[][]const u8 {
    var res: std.ArrayList([]const u8) = .empty;
    var cur: util.Buf = .empty;
    var in_word = false;
    var quote: u8 = 0;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        const ch = s[i];
        if (quote != 0) {
            if (ch == quote) {
                quote = 0;
            } else if (ch == '\\' and quote == '"' and i + 1 < s.len) {
                i += 1;
                util.bufByte(&cur, s[i]);
            } else util.bufByte(&cur, ch);
            continue;
        }
        if (std.ascii.isWhitespace(ch)) {
            if (in_word) {
                res.append(gpa, util.dupe(cur.items)) catch util.oom();
                cur = .empty;
                in_word = false;
            }
            continue;
        }
        in_word = true;
        if (ch == '"' or ch == '\'') {
            quote = ch;
        } else if (ch == '\\' and i + 1 < s.len) {
            i += 1;
            util.bufByte(&cur, s[i]);
        } else util.bufByte(&cur, ch);
    }
    if (quote != 0) return null;
    if (in_word) res.append(gpa, cur.items) catch util.oom();
    return res.items;
}

fn findExternal(name: []const u8) ?[]const u8 {
    const exe = util.concat(&.{ "git-", name });
    if (main.exec_path.len > 0) {
        const p = util.concat(&.{ main.exec_path, "/", exe });
        if (os.access(p, 1) and !os.isDir(p)) {
            // avoid finding ourselves for builtins
            return p;
        }
    }
    const path = os.getenv("PATH") orelse return null;
    var it = std.mem.splitScalar(u8, path, ':');
    while (it.next()) |d| {
        const dir = if (d.len == 0) "." else d;
        const p = util.concat(&.{ dir, "/", exe });
        if (os.access(p, 1) and !os.isDir(p)) return p;
    }
    return null;
}

pub fn dispatch(args_in: []const []const u8) u8 {
    var args = args_in;
    var seen: std.ArrayList([]const u8) = .empty;
    while (true) {
        const name = args[0];
        if (find(name)) |c| return runBuiltin(c, args);
        // external command?
        if (findExternal(name)) |p| {
            // make sure PATH includes exec_path
            var a: std.ArrayList([]const u8) = .empty;
            a.append(gpa, p) catch util.oom();
            a.appendSlice(gpa, args[1..]) catch util.oom();
            util.flushStdout();
            const r = os.run(a.items, .{});
            if (r.signaled) return 128 + @as(u8, @intCast(r.status & 0x7f));
            return @intCast(r.status & 0xff);
        }
        // alias?
        repo_mod.setup(true);
        const alias = repo_mod.cfg.get(util.concat(&.{ "alias.", name })) orelse aliasSubsection(name);
        if (alias) |a| {
            for (seen.items) |s| {
                if (util.eql(s, name)) {
                    var b: util.Buf = .empty;
                    for (seen.items) |s2| util.bufPrint(&b, "\n  {s}", .{s2});
                    util.bufPrint(&b, "\n  {s} <==", .{name});
                    util.die("recursive alias: {s}{s}", .{ seen.items[0], "" });
                }
            }
            seen.append(gpa, name) catch util.oom();
            if (a.len > 0 and a[0] == '!') {
                // shell alias
                var argv: std.ArrayList([]const u8) = .empty;
                argv.append(gpa, a[1..]) catch util.oom();
                argv.appendSlice(gpa, args[1..]) catch util.oom();
                util.flushStdout();
                // run relative to the top of the worktree
                if (repo_mod.repo_) |r| {
                    if (r.work_tree != null and r.prefix.len > 0) {
                        // setup chdir'ed to top already
                    }
                }
                const r = os.run(argv.items, .{ .use_shell = true });
                if (r.signaled) return 128 + @as(u8, @intCast(r.status & 0x7f));
                return @intCast(r.status & 0xff);
            }
            const words = splitCmdline(a) orelse util.die("bad alias.{s} string: unclosed quote", .{name});
            if (words.len == 0) util.die("empty alias for {s}", .{name});
            var na: std.ArrayList([]const u8) = .empty;
            na.appendSlice(gpa, words) catch util.oom();
            na.appendSlice(gpa, args[1..]) catch util.oom();
            args = na.items;
            continue;
        }
        util.eprint("git: '{s}' is not a git command. See 'git --help'.\n", .{name});
        return 1;
    }
}

fn aliasSubsection(name: []const u8) ?[]const u8 {
    return repo_mod.cfg.get(util.concat(&.{ "alias.", name, ".command" }));
}
