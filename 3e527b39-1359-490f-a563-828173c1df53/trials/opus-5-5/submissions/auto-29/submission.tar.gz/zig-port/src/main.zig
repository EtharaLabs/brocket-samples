//! git in Zig: entry point and command dispatch (port of git.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const cmds = @import("commands.zig");
const help = @import("help.zig");
const trace = @import("trace.zig");
const gpa = util.gpa;

pub const version = "2.56.1";

pub var argv0: []const u8 = "git";
pub var exec_path: []const u8 = "";
pub var use_pager: ?bool = null;

fn usage() noreturn {
    util.eprint("usage: {s}\n", .{help.git_usage_string});
    os.exit(129);
}

fn computeExecPath() []const u8 {
    if (os.getenv("GIT_EXEC_PATH")) |p| return p;
    // directory of the running binary
    if (os.readLink("/proc/self/exe")) |p| return util.dirname(p);
    return "/usr/libexec/git-core";
}

pub export fn main(argc: c_int, argv: [*][*:0]u8) callconv(.c) c_int {
    var args: std.ArrayList([]const u8) = .empty;
    var i: usize = 0;
    while (i < @as(usize, @intCast(argc))) : (i += 1) {
        args.append(gpa, std.mem.span(argv[i])) catch util.oom();
    }
    @import("trace2.zig").initialize(args.items);
    const code = run(args.items);
    @import("trace2.zig").cmdExit(code);
    @import("lockfile.zig").cleanupAll();
    util.flushStdout();
    os.waitPager();
    @import("trace2.zig").atexit();
    return code;
}

/// setup_path(): prepend the exec path to $PATH.
fn setupPath() void {
    var b: util.Buf = .empty;
    if (exec_path.len > 0) {
        util.bufAppend(&b, exec_path);
        util.bufByte(&b, ':');
    }
    util.bufAppend(&b, os.getenv("PATH") orelse "/usr/local/bin:/usr/bin:/bin");
    os.setEnv("PATH", b.items);
}

/// handle_options(): consumes leading global options from args.
pub fn handleOptions(args: *[]const []const u8, envchanged: ?*bool) void {
    const changed = struct {
        fn set(e: ?*bool) void {
            if (e) |p| p.* = true;
        }
    }.set;
    while (args.len > 0) {
        const a = args.*[0];
        if (a.len == 0 or a[0] != '-') break;
        if (util.eql(a, "--help") or util.eql(a, "-h") or util.eql(a, "--version") or util.eql(a, "-v")) break;
        if (util.skipPrefix(a, "--exec-path")) |rest| {
            if (rest.len > 0 and rest[0] == '=') {
                exec_path = rest[1..];
                os.setEnv("GIT_EXEC_PATH", exec_path);
            } else {
                @import("trace2.zig").cmdName("_query_");
                util.outf("{s}\n", .{exec_path});
                os.exit(0);
            }
        } else if (util.eql(a, "--html-path")) {
            @import("trace2.zig").cmdName("_query_");
            util.outf("{s}\n", .{help.htmlPath()});
            os.exit(0);
        } else if (util.eql(a, "--man-path")) {
            @import("trace2.zig").cmdName("_query_");
            util.outf("{s}\n", .{help.manPath()});
            os.exit(0);
        } else if (util.eql(a, "--info-path")) {
            @import("trace2.zig").cmdName("_query_");
            util.outf("{s}\n", .{help.infoPath()});
            os.exit(0);
        } else if (util.eql(a, "-p") or util.eql(a, "--paginate")) {
            use_pager = true;
        } else if (util.eql(a, "-P") or util.eql(a, "--no-pager")) {
            use_pager = false;
            changed(envchanged);
        } else if (util.eql(a, "--no-lazy-fetch")) {
            os.setEnv("GIT_NO_LAZY_FETCH", "1");
            changed(envchanged);
        } else if (util.eql(a, "--no-replace-objects")) {
            os.setEnv("GIT_NO_REPLACE_OBJECTS", "1");
            changed(envchanged);
        } else if (util.eql(a, "--git-dir") or util.eql(a, "--namespace") or util.eql(a, "--work-tree") or
            util.eql(a, "--shallow-file") or util.eql(a, "--attr-source"))
        {
            if (args.len < 2) {
                if (util.eql(a, "--namespace")) {
                    util.eprint("no namespace given for --namespace\n", .{});
                } else if (util.eql(a, "--shallow-file")) {
                    util.eprint("no file given for '{s}' option\n", .{a});
                } else if (util.eql(a, "--attr-source")) {
                    util.eprint("no attribute source given for --attr-source\n", .{});
                } else util.eprint("no directory given for '{s}' option\n", .{a});
                usage();
            }
            os.setEnv(envFor(a), args.*[1]);
            changed(envchanged);
            args.* = args.*[1..];
        } else if (eqPrefix(a, "--git-dir=") orelse eqPrefix(a, "--namespace=") orelse eqPrefix(a, "--work-tree=") orelse eqPrefix(a, "--attr-source=")) |kv| {
            os.setEnv(envFor(kv[0]), kv[1]);
            changed(envchanged);
        } else if (util.eql(a, "--bare")) {
            repo_mod.force_bare_repository = true;
            if (os.getenv("GIT_DIR") == null) os.setEnv("GIT_DIR", os.getcwd());
            os.setEnv("GIT_IMPLICIT_WORK_TREE", "0");
            changed(envchanged);
        } else if (util.eql(a, "-c")) {
            if (args.len < 2) {
                util.eprint("-c expects a configuration string\n", .{});
                usage();
            }
            const kv = args.*[1];
            const eq = std.mem.indexOfScalar(u8, kv, '=');
            const key = if (eq) |e| kv[0..e] else kv;
            switch (@import("config.zig").parseKey(key)) {
                .ok => {},
                .err => |m| {
                    util.err("{s}", .{m});
                    util.die("unable to parse command-line config", .{});
                },
            }
            repo_mod.addCmdlineConfig(kv);
            help.invalidateEarlyConfig();
            args.* = args.*[1..];
        } else if (util.eql(a, "--config-env") or util.startsWith(a, "--config-env=")) {
            var spec: []const u8 = undefined;
            if (util.skipPrefix(a, "--config-env=")) |p| {
                spec = p;
            } else {
                if (args.len < 2) {
                    util.eprint("no config key given for --config-env\n", .{});
                    usage();
                }
                spec = args.*[1];
                args.* = args.*[1..];
            }
            const eq = std.mem.lastIndexOfScalar(u8, spec, '=') orelse util.die("invalid config format: {s}", .{spec});
            const env_name = spec[eq + 1 ..];
            if (env_name.len == 0) util.die("missing environment variable name for configuration '{s}'", .{spec[0..eq]});
            const val = os.getenv(env_name) orelse util.die("missing environment variable '{s}' for configuration '{s}'", .{ env_name, spec[0..eq] });
            repo_mod.addCmdlineConfig(util.concat(&.{ spec[0..eq], "=", val }));
            help.invalidateEarlyConfig();
        } else if (util.eql(a, "--literal-pathspecs")) {
            os.setEnv("GIT_LITERAL_PATHSPECS", "1");
            changed(envchanged);
        } else if (util.eql(a, "--no-literal-pathspecs")) {
            os.setEnv("GIT_LITERAL_PATHSPECS", "0");
            changed(envchanged);
        } else if (util.eql(a, "--glob-pathspecs")) {
            os.setEnv("GIT_GLOB_PATHSPECS", "1");
            changed(envchanged);
        } else if (util.eql(a, "--noglob-pathspecs")) {
            os.setEnv("GIT_NOGLOB_PATHSPECS", "1");
            changed(envchanged);
        } else if (util.eql(a, "--icase-pathspecs")) {
            os.setEnv("GIT_ICASE_PATHSPECS", "1");
            changed(envchanged);
        } else if (util.eql(a, "--no-optional-locks")) {
            os.setEnv("GIT_OPTIONAL_LOCKS", "0");
            changed(envchanged);
        } else if (util.eql(a, "-C")) {
            if (args.len < 2) {
                util.eprint("no directory given for '{s}' option\n", .{"-C"});
                usage();
            }
            const d = args.*[1];
            if (d.len > 0) {
                if (!os.chdir(d)) util.dieErrno("cannot change to '{s}'", .{d});
                help.invalidateEarlyConfig();
                changed(envchanged);
            }
            args.* = args.*[1..];
        } else if (util.skipPrefix(a, "--list-cmds=")) |spec| {
            @import("trace2.zig").cmdName("_query_");
            os.exit(help.listCmds(spec));
        } else if (util.eql(a, "--no-advice")) {
            os.setEnv("GIT_ADVICE", "0");
            changed(envchanged);
        } else {
            util.eprint("unknown option: {s}\n", .{a});
            usage();
        }
        args.* = args.*[1..];
    }
}

fn eqPrefix(a: []const u8, p: []const u8) ?[2][]const u8 {
    const v = util.skipPrefix(a, p) orelse return null;
    return .{ p[0 .. p.len - 1], v };
}

fn envFor(opt: []const u8) []const u8 {
    if (util.eql(opt, "--git-dir")) return "GIT_DIR";
    if (util.eql(opt, "--namespace")) return "GIT_NAMESPACE";
    if (util.eql(opt, "--work-tree")) return "GIT_WORK_TREE";
    if (util.eql(opt, "--shallow-file")) return "GIT_SHALLOW_FILE";
    return "GIT_ATTR_SOURCE";
}

fn run(all: []const []const u8) u8 {
    if (all.len > 0) argv0 = all[0];
    exec_path = computeExecPath();
    var args = if (all.len > 0) all[1..] else all;
    // invoked as git-foo?
    const base = util.basename(argv0);
    if (util.eql(base, "scalar")) return @import("cmd/scalar.zig").scalarMain(all);
    if (util.skipPrefix(base, "git-")) |name| {
        var l: std.ArrayList([]const u8) = .empty;
        l.append(gpa, name) catch util.oom();
        l.appendSlice(gpa, args) catch util.oom();
        if (handleBuiltin(l.items)) |code| return code;
        util.die("cannot handle {s} as a builtin", .{name});
    }
    handleOptions(&args, null);
    if (args.len == 0) {
        commitPagerChoice();
        help.printMainUsage();
        return 1;
    }
    var l: std.ArrayList([]const u8) = .empty;
    l.appendSlice(gpa, args) catch util.oom();
    if (util.eql(l.items[0], "--version") or util.eql(l.items[0], "-v")) {
        l.items[0] = "version";
    } else if (util.eql(l.items[0], "--help") or util.eql(l.items[0], "-h")) {
        l.items[0] = "help";
    }
    var cmd = l.items[0];
    setupPath();
    var argv: []const []const u8 = l.items;
    var done_help = false;
    while (true) {
        const r = runArgv(&argv);
        if (r.code) |code| return code;
        if (r.was_alias) {
            util.eprint("expansion of alias '{s}' failed; '{s}' is not a git command\n", .{ cmd, argv[0] });
            return 1;
        }
        if (done_help) break;
        const assumed = help.helpUnknownCmd(cmd);
        var n: std.ArrayList([]const u8) = .empty;
        n.append(gpa, assumed) catch util.oom();
        n.appendSlice(gpa, argv[1..]) catch util.oom();
        argv = n.items;
        cmd = assumed;
        done_help = true;
    }
    util.eprint("failed to run command '{s}': No such file or directory\n", .{cmd});
    return 1;
}

/// Kept for callers that dispatch a full command line in-process.
fn dispatch(args: []const []const u8) u8 {
    return cmds.dispatch(args);
}

fn commitPagerChoice() void {
    if (use_pager) |p| {
        if (p) cmds.setupPager() else os.setEnv("GIT_PAGER", "cat");
    }
}

/// handle_builtin(): runs a builtin (returning its exit code) or returns null.
fn handleBuiltin(args_in: []const []const u8) ?u8 {
    var args = args_in;
    if (args.len > 1 and util.eql(args[1], "--help")) {
        var l: std.ArrayList([]const u8) = .empty;
        l.append(gpa, "help") catch util.oom();
        l.append(gpa, args[0]) catch util.oom();
        l.append(gpa, "--exclude-guides") catch util.oom();
        l.appendSlice(gpa, args[2..]) catch util.oom();
        args = l.items;
    }
    const c = cmds.find(args[0]) orelse return null;
    return cmds.runBuiltin(c, args);
}

const RunResult = struct { code: ?u8 = null, was_alias: bool = false };

fn statusCode(r: os.ChildResult) u8 {
    if (r.signaled) return @intCast(r.status & 0xff);
    return @intCast(r.status & 0xff);
}

/// run_argv(): returns a code when a command ran; null code means ENOENT.
fn runArgv(argv: *[]const []const u8) RunResult {
    var done_alias = false;
    var expanded: std.ArrayList([]const u8) = .empty;
    while (true) {
        if (help.isDeprecated(argv.*[0]) and handleAlias(argv, &expanded)) {
            done_alias = true;
            continue;
        }
        if (!done_alias) {
            if (handleBuiltin(argv.*)) |code| return .{ .code = code };
        } else if (cmds.find(argv.*[0]) != null) {
            @import("trace2.zig").cmdName("_run_git_alias_");
            commitPagerChoice();
            var a: std.ArrayList([]const u8) = .empty;
            a.append(gpa, "git") catch util.oom();
            a.appendSlice(gpa, argv.*) catch util.oom();
            trace.argv("git.c", 0, "trace: exec:", a.items);
            traceRunCommand(a.items, false);
            if (help.locateInPath("git") == null) util.die("could not execute builtin {s}", .{argv.*[0]});
            return .{ .code = statusCode(os.run(a.items, .{ .trace2_class = "git_alias" })) };
        }
        // execv_dashed_external()
        if (execDashedExternal(argv.*)) |code| return .{ .code = code, .was_alias = done_alias };
        if (!handleAlias(argv, &expanded)) break;
        done_alias = true;
    }
    return .{ .was_alias = done_alias };
}

/// trace_run_command() + the start_command trace of the prepared argv.
pub fn traceRunCommand(args: []const []const u8, use_shell: bool) void {
    if (!trace.want(&trace.default_key)) return;
    trace.argv("run-command.c", 0, "trace: run_command:", args);
    var prepared: std.ArrayList([]const u8) = .empty;
    if (use_shell and std.mem.indexOfAny(u8, args[0], "|&;<>()$`\\\"' \t\n*?[#~=%") != null) {
        prepared.append(gpa, "/bin/sh") catch util.oom();
        prepared.append(gpa, "-c") catch util.oom();
        prepared.append(gpa, if (args.len > 1) util.concat(&.{ args[0], " \"$@\"" }) else args[0]) catch util.oom();
        prepared.appendSlice(gpa, args) catch util.oom();
    } else {
        prepared.appendSlice(gpa, args) catch util.oom();
    }
    if (std.mem.indexOfScalar(u8, prepared.items[0], '/') == null) {
        prepared.items[0] = help.locateInPath(prepared.items[0]) orelse return;
    }
    trace.argv("run-command.c", 0, "trace: start_command:", prepared.items);
}

fn execDashedExternal(argv: []const []const u8) ?u8 {
    if (use_pager == null and cmds.find(argv[0]) == null) {
        // check_pager_config(): pager.<cmd>
        const cfg = help.earlyConfig();
        if (cfg.get(util.concat(&.{ "pager.", argv[0] }))) |v| {
            switch (@import("config.zig").parseMaybeBoolText(v)) {
                1 => use_pager = true,
                0 => use_pager = false,
                else => {
                    use_pager = true;
                    os.setEnv("GIT_PAGER", v);
                },
            }
        }
    }
    commitPagerChoice();
    var a: std.ArrayList([]const u8) = .empty;
    a.append(gpa, util.concat(&.{ "git-", argv[0] })) catch util.oom();
    a.appendSlice(gpa, argv[1..]) catch util.oom();
    @import("trace2.zig").cmdName("_run_dashed_");
    trace.argv("git.c", 0, "trace: exec:", a.items);
    traceRunCommand(a.items, false);
    const p = help.locateInPath(a.items[0]) orelse {
        dashedNotFound(a.items);
        return null;
    };
    if (os.isDir(p)) {
        dashedNotFound(a.items);
        return null;
    }
    const r = os.run(a.items, .{ .trace2_class = "dashed" });
    return statusCode(r);
}

/// run_command() of a missing dashed command: child_start + child_exit(-1).
fn dashedNotFound(a: []const []const u8) void {
    const t2 = @import("trace2.zig");
    if (!t2.enabled) return;
    const ch = t2.childStart(.{ .argv = a, .class = "dashed" });
    t2.childExit(ch, -1, -1);
}

/// handle_alias()
fn handleAlias(argv: *[]const []const u8, expanded: *std.ArrayList([]const u8)) bool {
    const alias_command = argv.*[0];
    const alias_string = help.aliasLookup(alias_command) orelse return false;
    if (argv.len == 2 and util.eql(argv.*[1], "-h"))
        util.eprint("'{s}' is aliased to '{s}'\n", .{ alias_command, alias_string });
    if (alias_string.len > 0 and alias_string[0] == '!') {
        repo_mod.setup(true);
        commitPagerChoice();
        var a: std.ArrayList([]const u8) = .empty;
        a.append(gpa, alias_string[1..]) catch util.oom();
        a.appendSlice(gpa, argv.*[1..]) catch util.oom();
        @import("trace2.zig").cmdAlias(alias_command, a.items);
        @import("trace2.zig").cmdName("_run_shell_alias_");
        traceRunCommand(a.items, true);
        const r = os.run(a.items, .{ .use_shell = true, .trace2_class = "shell_alias" });
        os.exit(statusCode(r));
    }
    const words = cmds.splitCmdline(alias_string) orelse util.die("bad alias.{s} string: unclosed quote", .{alias_command});
    var nargv: []const []const u8 = words;
    var envchanged = false;
    handleOptions(&nargv, &envchanged);
    if (envchanged) util.die("alias '{s}' changes environment variables.\nYou can use '!git' in the alias to do this", .{alias_command});
    if (nargv.len < 1) util.die("empty alias for {s}", .{alias_command});
    if (util.eql(alias_command, nargv[0])) util.die("recursive alias: {s}", .{alias_command});
    expanded.append(gpa, alias_command) catch util.oom();
    for (expanded.items, 0..) |s, si| {
        if (!util.eql(s, nargv[0])) continue;
        var b: util.Buf = .empty;
        for (expanded.items, 0..) |item, i| {
            util.bufPrint(&b, "\n  {s}", .{item});
            if (i == si) {
                util.bufAppend(&b, " <==");
            } else if (i == expanded.items.len - 1) util.bufAppend(&b, " ==>");
        }
        util.die("alias loop detected: expansion of '{s}' does not terminate:{s}", .{ expanded.items[0], b.items });
    }
    trace.argv("git.c", 0, util.fmt("trace: alias expansion: {s} =>", .{alias_command}), nargv);
    @import("trace2.zig").cmdAlias(alias_command, nargv);
    var n: std.ArrayList([]const u8) = .empty;
    n.appendSlice(gpa, nargv) catch util.oom();
    n.appendSlice(gpa, argv.*[1..]) catch util.oom();
    argv.* = n.items;
    return true;
}
