//! The index (dircache): reading/writing .git/index, cache-tree, stat matching.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const objects = @import("objects.zig");
const lockfile = @import("lockfile.zig");
const ewah = @import("ewah.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const CE_NAMEMASK: u16 = 0x0fff;
pub const CE_STAGEMASK: u16 = 0x3000;
pub const CE_STAGESHIFT = 12;
pub const CE_EXTENDED: u16 = 0x4000;
pub const CE_VALID: u16 = 0x8000;
// extended flags (stored in ext_flags)
pub const CE_INTENT_TO_ADD: u16 = 0x2000;
pub const CE_SKIP_WORKTREE: u16 = 0x4000;

pub const Entry = struct {
    ctime_s: u32 = 0,
    ctime_ns: u32 = 0,
    mtime_s: u32 = 0,
    mtime_ns: u32 = 0,
    dev: u32 = 0,
    ino: u32 = 0,
    mode: u32 = 0,
    uid: u32 = 0,
    gid: u32 = 0,
    size: u32 = 0,
    oid: Oid = hash.zero,
    flags: u16 = 0, // assume-valid, stage (namelen recomputed on write)
    ext_flags: u16 = 0,
    path: []const u8,
    // in-core only
    removed: bool = false,
    uptodate: bool = false,
    /// in-core flags used by unpack-trees (CE_UPDATE, CE_WT_REMOVE, ...)
    uflags: u32 = 0,
    /// split index: 1-based position in the shared index (0 = not shared)
    base_index: u32 = 0,
    /// split index: CE_UPDATE_IN_BASE
    update_in_base: bool = false,

    pub fn stage(self: *const Entry) u32 {
        return (self.flags & CE_STAGEMASK) >> CE_STAGESHIFT;
    }
    pub fn setStage(self: *Entry, s: u32) void {
        self.flags = (self.flags & ~CE_STAGEMASK) | @as(u16, @intCast(s << CE_STAGESHIFT));
    }
    pub fn intentToAdd(self: *const Entry) bool {
        return self.ext_flags & CE_INTENT_TO_ADD != 0;
    }
    pub fn skipWorktree(self: *const Entry) bool {
        return self.ext_flags & CE_SKIP_WORKTREE != 0;
    }
    pub fn assumeValid(self: *const Entry) bool {
        return self.flags & CE_VALID != 0;
    }
    pub fn fillStat(self: *Entry, st: os.Stat) void {
        self.ctime_s = @truncate(@as(u64, @bitCast(st.ctime)));
        self.ctime_ns = @truncate(@as(u64, @bitCast(st.ctime_ns)));
        self.mtime_s = @truncate(@as(u64, @bitCast(st.mtime)));
        self.mtime_ns = @truncate(@as(u64, @bitCast(st.mtime_ns)));
        self.dev = @truncate(st.dev);
        self.ino = @truncate(st.ino);
        self.uid = st.uid;
        self.gid = st.gid;
        self.size = @truncate(@as(u64, @bitCast(st.size)));
    }
};

pub fn compareName(a: []const u8, sa: u32, b: []const u8, sb: u32) std.math.Order {
    const o = std.mem.order(u8, a, b);
    if (o != .eq) return o;
    return std.math.order(sa, sb);
}

pub fn entryLess(_: void, a: Entry, b: Entry) bool {
    return compareName(a.path, a.stage(), b.path, b.stage()) == .lt;
}

/// mode for a file on disk
pub fn modeFromStat(st: os.Stat) u32 {
    if (st.isLnk()) return 0o120000;
    if (st.isDir()) return 0o160000;
    return if (st.mode & 0o100 != 0) 0o100755 else 0o100644;
}

/// canonicalize mode as in create_ce_mode / ce_mode_from_stat
pub fn ceModeFromStat(old: ?*const Entry, st: os.Stat) u32 {
    const trust_exec = repo_mod.cfg.getBool("core.filemode") orelse true;
    const has_symlinks = repo_mod.cfg.getBool("core.symlinks") orelse true;
    if (st.isReg()) {
        if (!has_symlinks) {
            if (old) |o| {
                if (o.mode == 0o120000) return o.mode;
            }
        }
        if (!trust_exec) {
            if (old) |o| {
                if (o.mode & 0o170000 == 0o100000) return o.mode;
            }
            return 0o100644;
        }
    }
    if (old) |o| {
        if (st.isDir() and o.mode == 0o160000) return 0o160000;
    }
    return modeFromStat(st);
}

pub fn canonMode(mode: u32) u32 {
    if (mode & 0o170000 == 0o100000) return if (mode & 0o100 != 0) 0o100755 else 0o100644;
    if (mode & 0o170000 == 0o120000) return 0o120000;
    if (mode & 0o170000 == 0o040000) return 0o040000;
    return 0o160000;
}

// ---------------- cache tree ----------------

pub const CacheTree = struct {
    name: []const u8 = "",
    entry_count: i32 = -1,
    oid: Oid = hash.zero,
    children: std.ArrayList(*CacheTree) = .empty,

    pub fn find(self: *CacheTree, name: []const u8) ?*CacheTree {
        for (self.children.items) |c| {
            if (util.eql(c.name, name)) return c;
        }
        return null;
    }

    pub fn findOrCreate(self: *CacheTree, name: []const u8) *CacheTree {
        if (self.find(name)) |c| return c;
        const c = gpa.create(CacheTree) catch util.oom();
        c.* = .{ .name = util.dupe(name) };
        // keep sorted by (len, name) as git's subtree_name_cmp
        var pos: usize = 0;
        while (pos < self.children.items.len) : (pos += 1) {
            const o = self.children.items[pos];
            if (subtreeLess(name, o.name)) break;
        }
        self.children.insert(gpa, pos, c) catch util.oom();
        return c;
    }

    pub fn invalidate(self: *CacheTree, path: []const u8) void {
        self.entry_count = -1;
        if (std.mem.indexOfScalar(u8, path, '/')) |sl| {
            if (self.find(path[0..sl])) |c| c.invalidate(path[sl + 1 ..]);
        }
    }
};

fn subtreeLess(a: []const u8, b: []const u8) bool {
    if (a.len != b.len) return a.len < b.len;
    return std.mem.order(u8, a, b) == .lt;
}

fn parseCacheTree(data: []const u8, pos: *usize) ?*CacheTree {
    const nul = std.mem.indexOfScalarPos(u8, data, pos.*, 0) orelse return null;
    const t = gpa.create(CacheTree) catch util.oom();
    t.* = .{ .name = data[pos.*..nul] };
    var p = nul + 1;
    const sp = std.mem.indexOfScalarPos(u8, data, p, ' ') orelse return null;
    t.entry_count = std.fmt.parseInt(i32, data[p..sp], 10) catch return null;
    p = sp + 1;
    const nl = std.mem.indexOfScalarPos(u8, data, p, '\n') orelse return null;
    const subtrees = std.fmt.parseInt(usize, data[p..nl], 10) catch return null;
    p = nl + 1;
    if (t.entry_count >= 0) {
        if (p + 20 > data.len) return null;
        t.oid = data[p..][0..20].*;
        p += 20;
    }
    pos.* = p;
    var i: usize = 0;
    while (i < subtrees) : (i += 1) {
        const c = parseCacheTree(data, pos) orelse return null;
        t.children.append(gpa, c) catch util.oom();
    }
    return t;
}

fn writeCacheTree(b: *util.Buf, t: *CacheTree) void {
    util.bufAppend(b, t.name);
    util.bufByte(b, 0);
    util.bufPrint(b, "{d} {d}\n", .{ t.entry_count, t.children.items.len });
    if (t.entry_count >= 0) util.bufAppend(b, &t.oid);
    for (t.children.items) |c| writeCacheTree(b, c);
}

// ---------------- resolve-undo ----------------

pub const Reuc = struct {
    path: []const u8,
    modes: [3]u32 = .{ 0, 0, 0 },
    oids: [3]Oid = .{ hash.zero, hash.zero, hash.zero },
};

// ---------------- index ----------------

/// split-index.c struct split_index
pub const Split = struct {
    base_oid: Oid = hash.zero,
    /// entries of the shared index; base[i].base_index == i + 1
    base: ?[]Entry = null,
    delete_bm: ?ewah.Bitmap = null,
    replace_bm: ?ewah.Bitmap = null,
};


pub const Index = struct {
    entries: std.ArrayList(Entry) = .empty,
    version: u32 = 2,
    cache_tree: ?*CacheTree = null,
    reuc: std.ArrayList(Reuc) = .empty,
    /// mtime of index file when read (racy-git detection)
    timestamp_s: u32 = 0,
    timestamp_ns: u32 = 0,
    path: []const u8 = "",
    lock: ?*lockfile.Lock = null,
    loaded_from_disk: bool = false,
    /// other extensions preserved verbatim (e.g. "link", "UNTR"): dropped for simplicity
    changed: bool = false,
    has_split: bool = false,
    /// split index state (split-index.c struct split_index)
    split: ?*Split = null,
    /// cache_changed & SOMETHING_CHANGED: forces a full (non-split) write
    something_changed: bool = false,
    /// cache_changed & SPLIT_INDEX_ORDERED: write a new shared index
    split_ordered: bool = false,
    /// set_alternate_index_output() in effect: never write a split index
    alt_output: bool = false,
    /// trailing checksum of the file this index was read from
    oid: Oid = hash.zero,

    // ---- lookup ----

    /// Binary search for path at stage. Returns index or -(insert_pos)-1 semantics via union.
    pub fn pos(self: *const Index, path: []const u8, stg: u32) union(enum) { found: usize, missing: usize } {
        var lo: usize = 0;
        var hi: usize = self.entries.items.len;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            const e = &self.entries.items[mid];
            switch (compareName(path, stg, e.path, e.stage())) {
                .eq => return .{ .found = mid },
                .lt => hi = mid,
                .gt => lo = mid + 1,
            }
        }
        return .{ .missing = lo };
    }

    pub fn findPos(self: *const Index, path: []const u8) ?usize {
        return switch (self.pos(path, 0)) {
            .found => |i| i,
            .missing => null,
        };
    }

    pub fn get(self: *Index, path: []const u8) ?*Entry {
        const i = self.findPos(path) orelse return null;
        return &self.entries.items[i];
    }

    /// First position with entry.path >= path (any stage)
    pub fn firstPos(self: *const Index, path: []const u8) usize {
        return switch (self.pos(path, 0)) {
            .found => |i| i,
            .missing => |i| i,
        };
    }

    /// Does any entry (any stage) have this exact path?
    pub fn hasPath(self: *const Index, path: []const u8) bool {
        const i = self.firstPos(path);
        return i < self.entries.items.len and util.eql(self.entries.items[i].path, path);
    }

    pub fn unmerged(self: *const Index) bool {
        for (self.entries.items) |e| {
            if (e.stage() != 0) return true;
        }
        return false;
    }

    pub fn invalidatePath(self: *Index, path: []const u8) void {
        if (self.cache_tree) |t| t.invalidate(path);
        self.changed = true;
    }

    /// record_resolve_undo: remember a higher-stage entry being removed.
    pub fn recordResolveUndo(self: *Index, e: *const Entry) void {
        const stg = e.stage();
        if (stg == 0) return;
        var lo: usize = 0;
        var hi: usize = self.reuc.items.len;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            switch (std.mem.order(u8, self.reuc.items[mid].path, e.path)) {
                .eq => {
                    lo = mid;
                    hi = mid;
                    break;
                },
                .lt => lo = mid + 1,
                .gt => hi = mid,
            }
        }
        if (lo >= self.reuc.items.len or !util.eql(self.reuc.items[lo].path, e.path)) {
            self.reuc.insert(gpa, lo, .{ .path = e.path }) catch util.oom();
        }
        self.reuc.items[lo].modes[stg - 1] = e.mode;
        self.reuc.items[lo].oids[stg - 1] = e.oid;
    }

    pub fn findReuc(self: *Index, path: []const u8) ?usize {
        for (self.reuc.items, 0..) |r, i| {
            if (util.eql(r.path, path)) return i;
        }
        return null;
    }

    /// unmerge_index_entry: restore higher stages from resolve-undo info. Returns false on error.
    pub fn unmergeEntry(self: *Index, path: []const u8) bool {
        const ri = self.findReuc(path) orelse return true;
        const r = self.reuc.items[ri];
        switch (self.pos(path, 0)) {
            .found => |i| self.removeAt(i),
            .missing => |i| {
                if (i < self.entries.items.len and util.eql(self.entries.items[i].path, path)) return true;
            },
        }
        for (0..3) |s| {
            if (r.modes[s] == 0) continue;
            var e = Entry{ .path = path, .mode = r.modes[s], .oid = r.oids[s] };
            e.setStage(@intCast(s + 1));
            if (!self.add(e, .{ .ok_to_add = true, .ok_to_replace = false })) {
                util.err("cannot unmerge '{s}'", .{path});
                return false;
            }
        }
        _ = self.reuc.orderedRemove(ri);
        self.changed = true;
        return true;
    }

    pub fn removeAt(self: *Index, i: usize) void {
        self.recordResolveUndo(&self.entries.items[i]);
        self.invalidatePath(self.entries.items[i].path);
        _ = self.entries.orderedRemove(i);
        self.changed = true;
    }

    /// Remove all stages of path. Returns true if anything was removed.
    pub fn removePath(self: *Index, path: []const u8) bool {
        const i = self.firstPos(path);
        var any = false;
        while (i < self.entries.items.len and util.eql(self.entries.items[i].path, path)) {
            self.removeAt(i);
            any = true;
        }
        return any;
    }

    pub const AddOpts = struct {
        ok_to_add: bool = true,
        ok_to_replace: bool = true,
        skip_df_check: bool = false,
        keep_cache_tree: bool = false,
    };

    /// Add or replace an entry. Handles D/F conflicts when ok_to_replace. Returns false on error.
    pub fn add(self: *Index, e: Entry, opts: AddOpts) bool {
        if (!opts.keep_cache_tree) self.invalidatePath(e.path);
        const stg = e.stage();
        switch (self.pos(e.path, stg)) {
            .found => |i| {
                // replace_index_entry(): the new entry takes over the shared slot
                const old_bi = self.entries.items[i].base_index;
                self.entries.items[i] = e;
                if (old_bi != 0) {
                    self.entries.items[i].base_index = old_bi;
                    self.entries.items[i].update_in_base = true;
                }
                return true;
            },
            .missing => |ins| {
                var at = ins;
                var ok_to_add = opts.ok_to_add;
                // adding stage 0 removes higher stages of the same path
                if (stg == 0) {
                    while (at < self.entries.items.len and util.eql(self.entries.items[at].path, e.path)) {
                        ok_to_add = true;
                        self.recordResolveUndo(&self.entries.items[at]);
                        _ = self.entries.orderedRemove(at);
                    }
                }
                if (!ok_to_add) return false;
                if (!opts.skip_df_check) {
                    if (!self.checkDF(e, opts.ok_to_replace)) {
                        util.err("'{s}' appears as both a file and as a directory", .{e.path});
                        return false;
                    }
                    at = switch (self.pos(e.path, stg)) {
                        .found => |i| i,
                        .missing => |i| i,
                    };
                }
                self.entries.insert(gpa, at, e) catch util.oom();
                return true;
            },
        }
    }

    /// Check directory/file conflicts. If replace, remove conflicting entries.
    fn checkDF(self: *Index, e: Entry, replace: bool) bool {
        const stg = e.stage();
        var conflict = false;
        // 1. a parent dir of e.path exists as a file
        var p: usize = 0;
        while (std.mem.indexOfScalarPos(u8, e.path, p, '/')) |sl| {
            const parent = e.path[0..sl];
            switch (self.pos(parent, stg)) {
                .found => |i| {
                    if (!replace) return false;
                    self.removeAt(i);
                    conflict = true;
                },
                .missing => {},
            }
            p = sl + 1;
        }
        // 2. e.path exists as a directory (entries under path/)
        const pref = util.concat(&.{ e.path, "/" });
        var i = self.firstPos(pref);
        while (i < self.entries.items.len and util.startsWith(self.entries.items[i].path, pref)) {
            if (self.entries.items[i].stage() != stg) {
                i += 1;
                continue;
            }
            if (!replace) return false;
            self.removeAt(i);
            conflict = true;
        }
        return true;
    }

    // ---- reading ----

    pub fn readFile(self: *Index, path: []const u8) void {
        self.path = path;
        const data = os.readFile(path) orelse {
            self.postRead();
            return;
        };
        if (os.statPath(path)) |st| {
            self.timestamp_s = @truncate(@as(u64, @bitCast(st.mtime)));
            self.timestamp_ns = @truncate(@as(u64, @bitCast(st.mtime_ns)));
        }
        self.loaded_from_disk = true;
        self.parse(data, path);
        if (self.split) |si| {
            if (!hash.isZero(si.base_oid)) self.readSharedIndex(path);
        }
        self.postRead();
    }

    /// post_read_index_from(): apply core.splitIndex.
    fn postRead(self: *Index) void {
        if (repo_mod.repo_ == null) return;
        const v = repo_mod.cfg.getBool("core.splitindex") orelse return;
        if (v) self.addSplitIndex() else self.removeSplitIndex();
    }

    /// add_split_index()
    pub fn addSplitIndex(self: *Index) void {
        if (self.split == null) {
            _ = self.initSplit();
            self.split_ordered = true;
        }
    }

    /// remove_split_index()
    pub fn removeSplitIndex(self: *Index) void {
        if (self.split != null) {
            self.split = null;
            for (self.entries.items) |*e| {
                e.base_index = 0;
                e.update_in_base = false;
            }
            self.something_changed = true;
        }
    }

    /// init_split_index()
    pub fn initSplit(self: *Index) *Split {
        if (self.split) |s| return s;
        const s = gpa.create(Split) catch util.oom();
        s.* = .{};
        self.split = s;
        return s;
    }

    /// read_link_extension()
    fn readLinkExtension(self: *Index, ext: []const u8) void {
        if (ext.len < 20) {
            util.err("corrupt link extension (too short)", .{});
            util.die("index file corrupt", .{});
        }
        const si = self.initSplit();
        si.base_oid = ext[0..20].*;
        const rest = ext[20..];
        if (rest.len == 0) return;
        const d = ewah.Bitmap.read(rest) orelse {
            util.err("corrupt delete bitmap in link extension", .{});
            util.die("index file corrupt", .{});
        };
        si.delete_bm = d.bm;
        const r = ewah.Bitmap.read(rest[d.len..]) orelse {
            util.err("corrupt replace bitmap in link extension", .{});
            util.die("index file corrupt", .{});
        };
        si.replace_bm = r.bm;
        if (r.len != rest.len - d.len) {
            util.err("garbage at the end of link extension", .{});
            util.die("index file corrupt", .{});
        }
    }

    /// The part of read_index_from() that loads $GIT_DIR/sharedindex.<oid>
    /// and merges it (merge_base_index()).
    fn readSharedIndex(self: *Index, path: []const u8) void {
        const si = self.split.?;
        const hex = hash.hex(si.base_oid);
        const name = util.concat(&.{ "sharedindex.", &hex });
        const gitdir = if (repo_mod.repo_ != null) repo_mod.repo().git_dir else std.fs.path.dirname(path) orelse ".";
        const base_path = util.concat(&.{ gitdir, "/", name });
        var data: []const u8 = undefined;
        var used_path = base_path;
        if (os.readFile(base_path)) |d| {
            data = d;
        } else {
            const dn = std.fs.path.dirname(path) orelse ".";
            used_path = util.concat(&.{ dn, "/", name });
            data = os.readFile(used_path) orelse util.dieErrno("{s}: index file open failed", .{used_path});
        }
        var base = Index{};
        base.parse(data, used_path);
        if (!hash.eql(base.oid, si.base_oid))
            util.die("broken index, expect {s} in {s}, got {s}", .{ &hex, base_path, &hash.hex(base.oid) });
        _ = freshenFile(base_path);
        for (base.entries.items, 0..) |*e, i| e.base_index = @intCast(i + 1);
        si.base = base.entries.items;
        self.mergeBaseIndex();
    }

    /// merge_base_index()
    fn mergeBaseIndex(self: *Index) void {
        const si = self.split.?;
        const base = si.base.?;
        const saved = self.entries.items;
        var ents: std.ArrayList(Entry) = .empty;
        ents.appendSlice(gpa, base) catch util.oom();
        var nr_repl: usize = 0;
        if (si.replace_bm) |*bm| {
            for (bm.bits()) |p| {
                if (p >= ents.items.len) util.die("position for replacement {d} exceeds base index size {d}", .{ p, ents.items.len });
                if (nr_repl >= saved.len) util.die("too many replacements ({d} vs {d})", .{ nr_repl, saved.len });
                const dst = &ents.items[p];
                if (dst.removed) util.die("entry {d} is marked as both replaced and deleted", .{p});
                var src = saved[nr_repl];
                if (src.path.len != 0) util.die("corrupt link extension, entry {d} should have zero length name", .{p});
                src.path = dst.path;
                src.base_index = @intCast(p + 1);
                src.update_in_base = true;
                dst.* = src;
                nr_repl += 1;
            }
        }
        var nr_del: usize = 0;
        if (si.delete_bm) |*bm| {
            for (bm.bits()) |p| {
                if (p >= ents.items.len) util.die("position for delete {d} exceeds base index size {d}", .{ p, ents.items.len });
                ents.items[p].removed = true;
                nr_del += 1;
            }
        }
        if (nr_del > 0) {
            var w: usize = 0;
            for (ents.items) |e| {
                if (e.removed) continue;
                ents.items[w] = e;
                w += 1;
            }
            ents.items.len = w;
        }
        self.entries = ents;
        var i = nr_repl;
        while (i < saved.len) : (i += 1) {
            if (saved[i].path.len == 0) util.die("corrupt link extension, entry {d} should have non-zero length name", .{i});
            _ = self.add(saved[i], .{ .ok_to_add = true, .skip_df_check = true, .keep_cache_tree = true });
        }
        si.delete_bm = null;
        si.replace_bm = null;
    }


    fn parse(self: *Index, data: []const u8, path: []const u8) void {
        if (data.len < 12 + 20) util.die("{s}: index file smaller than expected", .{path});
        if (!std.mem.eql(u8, data[0..4], "DIRC")) {
            util.err("bad signature 0x{x:0>8}", .{std.mem.readInt(u32, data[0..4], .little)});
            util.die("index file corrupt", .{});
        }
        const ver = std.mem.readInt(u32, data[4..8], .big);
        if (ver < 2 or ver > 4) {
            util.err("bad index version {d}", .{ver});
            util.die("index file corrupt", .{});
        }
        self.version = ver;
        const body = data[0 .. data.len - 20];
        var h = hash.Hasher.init(.{});
        h.update(body);
        var sum: Oid = undefined;
        h.final(&sum);
        if (!std.mem.eql(u8, &sum, data[data.len - 20 ..])) {
            if (!hash.isZero(data[data.len - 20 ..][0..20].*)) {
                util.err("bad index file sha1 signature", .{});
                util.die("index file corrupt", .{});
            }
        }
        self.oid = data[data.len - 20 ..][0..20].*;
        const n = std.mem.readInt(u32, data[8..12], .big);
        var p: usize = 12;
        var prev_name: []const u8 = "";
        self.entries.ensureTotalCapacity(gpa, n) catch util.oom();
        var k: u32 = 0;
        while (k < n) : (k += 1) {
            if (p + 62 > body.len) util.die("index file corrupt", .{});
            var e = Entry{ .path = "" };
            const rd = struct {
                fn r(d: []const u8, o: usize) u32 {
                    return std.mem.readInt(u32, d[o..][0..4], .big);
                }
            }.r;
            e.ctime_s = rd(data, p);
            e.ctime_ns = rd(data, p + 4);
            e.mtime_s = rd(data, p + 8);
            e.mtime_ns = rd(data, p + 12);
            e.dev = rd(data, p + 16);
            e.ino = rd(data, p + 20);
            e.mode = rd(data, p + 24);
            e.uid = rd(data, p + 28);
            e.gid = rd(data, p + 32);
            e.size = rd(data, p + 36);
            e.oid = data[p + 40 ..][0..20].*;
            const flags = std.mem.readInt(u16, data[p + 60 ..][0..2], .big);
            e.flags = flags & ~CE_NAMEMASK;
            var q = p + 62;
            if (flags & CE_EXTENDED != 0) {
                if (ver < 3) util.die("index file corrupt", .{});
                e.ext_flags = std.mem.readInt(u16, data[q..][0..2], .big);
                q += 2;
            }
            e.flags &= ~CE_EXTENDED;
            if (ver == 4) {
                // varint strip length
                var strip: usize = 0;
                var c = data[q];
                q += 1;
                strip = c & 0x7f;
                while (c & 0x80 != 0) {
                    strip += 1;
                    c = data[q];
                    q += 1;
                    strip = (strip << 7) + (c & 0x7f);
                }
                const nul = std.mem.indexOfScalarPos(u8, data, q, 0) orelse util.die("index file corrupt", .{});
                if (strip > prev_name.len) util.die("malformed name field in the index, near path '{s}'", .{prev_name});
                const name = util.concat(&.{ prev_name[0 .. prev_name.len - strip], data[q..nul] });
                e.path = name;
                q = nul + 1;
                p = q;
            } else {
                const namelen = flags & CE_NAMEMASK;
                var nul: usize = undefined;
                if (namelen < CE_NAMEMASK) {
                    nul = q + namelen;
                } else {
                    nul = std.mem.indexOfScalarPos(u8, data, q, 0) orelse util.die("index file corrupt", .{});
                }
                e.path = data[q..nul];
                const entsize = ((q - p) + (nul - q) + 8) & ~@as(usize, 7);
                p += entsize;
            }
            prev_name = e.path;
            self.entries.appendAssumeCapacity(e);
        }
        // extensions
        while (p + 8 <= body.len) {
            const sig = data[p..][0..4];
            const sz = std.mem.readInt(u32, data[p + 4 ..][0..4], .big);
            const ext = data[p + 8 .. @min(body.len, p + 8 + sz)];
            if (std.mem.eql(u8, sig, "TREE")) {
                var tp: usize = 0;
                self.cache_tree = parseCacheTree(ext, &tp);
            } else if (std.mem.eql(u8, sig, "REUC")) {
                self.parseReuc(ext);
            } else if (std.mem.eql(u8, sig, "link")) {
                self.has_split = true;
                self.readLinkExtension(ext);
            } else if (sig[0] >= 'A' and sig[0] <= 'Z') {
                // optional extension: ignore
            } else {
                util.die("index uses {s} extension, which we do not understand", .{sig});
            }
            p += 8 + sz;
        }
    }

    fn parseReuc(self: *Index, d: []const u8) void {
        var p: usize = 0;
        while (p < d.len) {
            const nul = std.mem.indexOfScalarPos(u8, d, p, 0) orelse return;
            var r = Reuc{ .path = d[p..nul] };
            p = nul + 1;
            var i: usize = 0;
            while (i < 3) : (i += 1) {
                const n2 = std.mem.indexOfScalarPos(u8, d, p, 0) orelse return;
                r.modes[i] = std.fmt.parseInt(u32, d[p..n2], 8) catch return;
                p = n2 + 1;
            }
            i = 0;
            while (i < 3) : (i += 1) {
                if (r.modes[i] != 0) {
                    r.oids[i] = d[p..][0..20].*;
                    p += 20;
                }
            }
            self.reuc.append(gpa, r) catch util.oom();
        }
    }

    // ---- writing ----

    fn serializeEntries(self: *Index, entries: []const Entry, ver_in: u32, link: ?[]const u8, exts: bool, ver_out: *u32) []u8 {
        var b: util.Buf = .empty;
        var ver = ver_in;
        var need_ext = false;
        var count: u32 = 0;
        for (entries) |e| {
            if (e.removed) continue;
            count += 1;
            if (e.ext_flags != 0) need_ext = true;
        }
        if (need_ext and ver < 3) ver = 3;
        if (!need_ext and ver == 3) ver = 2;
        ver_out.* = ver;
        util.bufAppend(&b, "DIRC");
        var tmp: [4]u8 = undefined;
        std.mem.writeInt(u32, &tmp, ver, .big);
        util.bufAppend(&b, &tmp);
        std.mem.writeInt(u32, &tmp, count, .big);
        util.bufAppend(&b, &tmp);
        var prev: []const u8 = "";
        for (entries) |*e| {
            if (e.removed) continue;
            const start = b.items.len;
            for ([_]u32{ e.ctime_s, e.ctime_ns, e.mtime_s, e.mtime_ns, e.dev, e.ino, e.mode, e.uid, e.gid, e.size }) |v| {
                std.mem.writeInt(u32, &tmp, v, .big);
                util.bufAppend(&b, &tmp);
            }
            util.bufAppend(&b, &e.oid);
            var flags: u16 = e.flags & ~(CE_NAMEMASK | CE_EXTENDED);
            flags |= @intCast(@min(e.path.len, CE_NAMEMASK));
            if (e.ext_flags != 0) flags |= CE_EXTENDED;
            var t2: [2]u8 = undefined;
            std.mem.writeInt(u16, &t2, flags, .big);
            util.bufAppend(&b, &t2);
            if (e.ext_flags != 0) {
                std.mem.writeInt(u16, &t2, e.ext_flags, .big);
                util.bufAppend(&b, &t2);
            }
            if (ver == 4) {
                var common: usize = 0;
                while (common < prev.len and common < e.path.len and prev[common] == e.path[common]) common += 1;
                const strip = prev.len - common;
                writeVarint(&b, strip);
                util.bufAppend(&b, e.path[common..]);
                util.bufByte(&b, 0);
                prev = e.path;
            } else {
                util.bufAppend(&b, e.path);
                const len = b.items.len - start;
                const padded = (len + 8) & ~@as(usize, 7);
                b.appendNTimes(gpa, 0, padded - len) catch util.oom();
            }
        }
        if (link) |lk| {
            util.bufAppend(&b, "link");
            std.mem.writeInt(u32, &tmp, @intCast(lk.len), .big);
            util.bufAppend(&b, &tmp);
            util.bufAppend(&b, lk);
        }
        if (exts and self.cache_tree != null) {
            const t = self.cache_tree.?;
            var tb: util.Buf = .empty;
            writeCacheTree(&tb, t);
            util.bufAppend(&b, "TREE");
            std.mem.writeInt(u32, &tmp, @intCast(tb.items.len), .big);
            util.bufAppend(&b, &tmp);
            util.bufAppend(&b, tb.items);
        }
        if (exts and self.reuc.items.len > 0) {
            var rb: util.Buf = .empty;
            for (self.reuc.items) |r| {
                util.bufAppend(&rb, r.path);
                util.bufByte(&rb, 0);
                for (r.modes) |m| util.bufPrint(&rb, "{o}\x00", .{m});
                for (r.modes, 0..) |m, i| {
                    if (m != 0) util.bufAppend(&rb, &r.oids[i]);
                }
            }
            util.bufAppend(&b, "REUC");
            std.mem.writeInt(u32, &tmp, @intCast(rb.items.len), .big);
            util.bufAppend(&b, &tmp);
            util.bufAppend(&b, rb.items);
        }
        var h = hash.Hasher.init(.{});
        h.update(b.items);
        var sum: Oid = undefined;
        h.final(&sum);
        util.bufAppend(&b, &sum);
        return b.items;
    }

    /// Smudge racily clean entries before writing (ce_smudge_racily_clean_entry).
    fn smudgeRacy(self: *Index, now_s: u32) void {
        for (self.entries.items) |*e| {
            if (e.removed or e.stage() != 0) continue;
            if (e.mtime_s < now_s) continue;
            if (e.size == 0) continue;
            const wt = repo_mod.repo().work_tree orelse return;
            _ = wt;
            const st = os.lstatPath(e.path) orelse continue;
            if (matchStatBasic(e, st) != 0) continue;
            if (contentChanged(e, st)) e.size = 0;
        }
    }

    pub fn lockIndex(self: *Index) void {
        if (self.lock != null) return;
        self.lock = lockfile.lockOrDie(self.path);
    }

    /// Write index to its lock file and commit.
    pub fn write(self: *Index) void {
        self.writeToLock();
        const l = self.lock.?;
        if (!l.commit()) util.dieErrno("unable to write new index file", .{});
        self.lock = null;
        if (os.statPath(self.path)) |st| {
            self.timestamp_s = @truncate(@as(u64, @bitCast(st.mtime)));
            self.timestamp_ns = @truncate(@as(u64, @bitCast(st.mtime_ns)));
        }
    }

    /// Write index into its (held) lock file, keeping the lock (write_locked_index without COMMIT_LOCK).
    pub fn writeToLock(self: *Index) void {
        if (self.lock == null) self.lockIndex();
        const l = self.lock.?;
        // determine index version
        if (!self.loaded_from_disk) {
            self.version = defaultVersion();
        }
        // racy check: timestamp of the new index file ~ now
        const now: u32 = @intCast(os.now());
        if (repo_mod.repo().work_tree != null) self.smudgeRacy(now);
        l.rewrite(self.serializeForWrite());
    }

    /// The split-index decision of write_locked_index(); returns the bytes
    /// of the main index file (writing a new shared index when needed).
    fn serializeForWrite(self: *Index) []u8 {
        const test_split = envBool("GIT_TEST_SPLIT_INDEX");
        if ((self.split == null and !test_split) or self.alt_output or self.something_changed)
            return self.serializeEntries(self.entries.items, self.version, null, true, &self.version);
        if (test_split) {
            if (self.split) |si| {
                if (si.base_oid[0] & 15 < 6) self.split_ordered = true;
            } else {
                _ = self.initSplit();
                self.split_ordered = true;
            }
        }
        if (self.tooManyNotSharedEntries()) self.split_ordered = true;
        const new_shared = self.split_ordered;
        if (new_shared) {
            if (!self.writeSharedIndex())
                return self.serializeEntries(self.entries.items, self.version, null, true, &self.version);
            self.split_ordered = false;
        }
        const data = self.serializeSplit();
        const si = self.split.?;
        if (!new_shared and !hash.isZero(si.base_oid)) {
            const hex = hash.hex(si.base_oid);
            const p = repo_mod.repo().gitPath(util.concat(&.{ "sharedindex.", &hex }));
            if (!freshenFile(p)) util.warn("could not freshen shared index '{s}'", .{p});
        }
        return data;
    }

    /// too_many_not_shared_entries()
    fn tooManyNotSharedEntries(self: *const Index) bool {
        var max_split: i64 = 20;
        if (repo_mod.cfg.getInt("splitindex.maxpercentchange")) |v| {
            if (v >= 0 and v <= 100) {
                max_split = v;
            } else util.err("splitIndex.maxPercentChange value '{d}' should be between 0 and 100", .{v});
        }
        if (max_split == 0) return true;
        if (max_split == 100) return false;
        var not_shared: i64 = 0;
        for (self.entries.items) |e| {
            if (e.base_index == 0) not_shared += 1;
        }
        return @as(i64, @intCast(self.entries.items.len)) * max_split < not_shared * 100;
    }

    /// write_shared_index(): move all entries to a new shared index file.
    fn writeSharedIndex(self: *Index) bool {
        const si = self.initSplit();
        var base: std.ArrayList(Entry) = .empty;
        for (self.entries.items) |*e| {
            if (e.removed) continue;
            e.update_in_base = false;
            e.base_index = @intCast(base.items.len + 1);
            base.append(gpa, e.*) catch util.oom();
        }
        var ver: u32 = undefined;
        const data = self.serializeEntries(base.items, self.version, null, false, &ver);
        const r = repo_mod.repo();
        const tmp = r.gitPath(util.fmt("sharedindex_{d}", .{std.c.getpid()}));
        os.writeFile(tmp, data, 0o666) catch {
            util.err("unable to create temporary file '{s}'", .{tmp});
            return false;
        };
        if (!adjustSharedPerm(tmp)) {
            util.err("cannot fix permission bits on '{s}'", .{tmp});
            _ = os.unlink(tmp);
            return false;
        }
        const oid: Oid = data[data.len - 20 ..][0..20].*;
        const hex = hash.hex(oid);
        if (!os.rename(tmp, r.gitPath(util.concat(&.{ "sharedindex.", &hex })))) {
            _ = os.unlink(tmp);
            return false;
        }
        si.base_oid = oid;
        si.base = base.items;
        cleanSharedIndexFiles(&hex);
        return true;
    }

    /// prepare_to_write_split_index() + do_write_index(WRITE_ALL_EXTENSIONS)
    fn serializeSplit(self: *Index) []u8 {
        const si = self.split.?;
        var del = ewah.new();
        var rep = ewah.new();
        var out: std.ArrayList(Entry) = .empty;
        if (si.base) |base| {
            const slot = gpa.alloc(?*Entry, base.len) catch util.oom();
            @memset(slot, null);
            for (self.entries.items) |*e| {
                if (e.base_index == 0) continue;
                if (e.base_index > base.len) {
                    e.base_index = 0;
                    continue;
                }
                const bi = e.base_index - 1;
                const be = &base[bi];
                if (!util.eql(e.path, be.path)) {
                    e.base_index = 0;
                    continue;
                }
                if (!e.update_in_base) {
                    if (!e.uptodate and self.isRacy(e)) {
                        e.update_in_base = true;
                    } else if (ceContentDiffers(e, be)) e.update_in_base = true;
                }
                slot[bi] = e;
            }
            for (slot, 0..) |s, i| {
                if (s == null or s.?.removed) {
                    del.set(i);
                } else if (s.?.update_in_base) {
                    rep.set(i);
                    var x = s.?.*;
                    x.path = "";
                    out.append(gpa, x) catch util.oom();
                }
            }
        }
        for (self.entries.items) |e| {
            if ((si.base == null or e.base_index == 0) and !e.removed) out.append(gpa, e) catch util.oom();
        }
        var link: util.Buf = .empty;
        util.bufAppend(&link, &si.base_oid);
        del.serialize(&link);
        rep.serialize(&link);
        return self.serializeEntries(out.items, self.version, link.items, true, &self.version);
    }


    pub fn rollback(self: *Index) void {
        if (self.lock) |l| l.rollback();
        self.lock = null;
    }

    pub fn isRacy(self: *const Index, e: *const Entry) bool {
        return self.timestamp_s != 0 and self.timestamp_s <= e.mtime_s;
    }

    /// ie_match_stat: returns 0 if entry matches the stat info (and contents for racy entries).
    pub fn matchStat(self: *const Index, e: *const Entry, st: os.Stat, racy_is_dirty: bool) u32 {
        if (e.skipWorktree()) return 0;
        if (e.assumeValid()) return 0;
        if (e.intentToAdd()) return DATA_CHANGED | TYPE_CHANGED | MODE_CHANGED;
        var changed = matchStatBasic(e, st);
        if (changed == 0 and self.isRacy(e)) {
            if (racy_is_dirty) {
                changed |= DATA_CHANGED;
            } else if (contentChanged(e, st)) changed |= DATA_CHANGED;
        }
        return changed;
    }

    /// Like ie_modified: stat check then content check if stat differs only in metadata.
    pub fn modified(self: *const Index, e: *const Entry, st: os.Stat) bool {
        const changed = self.matchStat(e, st, false);
        if (changed == 0) return false;
        if (changed & (MODE_CHANGED | TYPE_CHANGED) != 0) return true;
        // racily-smudged entries (size 0) need content check too
        if (changed & DATA_CHANGED != 0 and e.size != 0) return true;
        return contentChanged(e, st);
    }

    /// Recompute tree objects for the whole index (write-tree). Returns root oid.
    pub fn writeTree(self: *Index, missing_ok: bool) ?Oid {
        if (self.unmerged()) return null;
        if (self.cache_tree == null) {
            const t = gpa.create(CacheTree) catch util.oom();
            t.* = .{};
            self.cache_tree = t;
        }
        var i: usize = 0;
        const r = self.updateTree(self.cache_tree.?, "", &i, missing_ok) orelse return null;
        return r;
    }

    fn updateTree(self: *Index, t: *CacheTree, base: []const u8, i: *usize, missing_ok: bool) ?Oid {
        const start = i.*;
        // find range of entries under base
        var end = start;
        while (end < self.entries.items.len and util.startsWith(self.entries.items[end].path, base)) end += 1;
        if (t.entry_count >= 0 and odbHas(t.oid)) {
            // still valid; but make sure count matches
            if (@as(usize, @intCast(t.entry_count)) == countNonRemoved(self.entries.items[start..end])) {
                i.* = end;
                return t.oid;
            }
        }
        var tes: std.ArrayList(objects.TreeEntry) = .empty;
        var seen_children: std.ArrayList(*CacheTree) = .empty;
        var k = start;
        var count: usize = 0;
        while (k < end) {
            const e = &self.entries.items[k];
            if (e.removed) {
                k += 1;
                continue;
            }
            const rel = e.path[base.len..];
            if (std.mem.indexOfScalar(u8, rel, '/')) |sl| {
                const dname = rel[0..sl];
                const sub = t.findOrCreate(dname);
                seen_children.append(gpa, sub) catch util.oom();
                var kk = k;
                const sub_base = util.concat(&.{ base, dname, "/" });
                const before = kk;
                const oid = self.updateTree(sub, sub_base, &kk, missing_ok) orelse return null;
                _ = before;
                count += @intCast(@max(sub.entry_count, 0));
                // an empty subtree (only intent-to-add entries) is omitted
                if (!(hash.eql(oid, emptyTreeOid()) and anyItaUnder(self.entries.items[k..kk]))) {
                    tes.append(gpa, .{ .mode = 0o40000, .name = dname, .oid = oid }) catch util.oom();
                }
                k = kk;
            } else {
                count += 1;
                if (e.intentToAdd()) {
                    k += 1;
                    continue;
                }
                if (!missing_ok and e.mode != 0o160000 and !odbHas(e.oid)) {
                    util.err("invalid object {o} {s} for '{s}'", .{ e.mode, &hash.hex(e.oid), e.path });
                    return null;
                }
                tes.append(gpa, .{ .mode = e.mode, .name = rel, .oid = e.oid }) catch util.oom();
                k += 1;
            }
        }
        // drop stale children
        var ci: usize = 0;
        while (ci < t.children.items.len) {
            var found = false;
            for (seen_children.items) |s| {
                if (s == t.children.items[ci]) found = true;
            }
            if (!found) {
                _ = t.children.orderedRemove(ci);
            } else ci += 1;
        }
        const data = objects.formatTree(tes.items);
        const oid = repo_mod.repo().odb().write(.tree, data);
        t.oid = oid;
        t.entry_count = @intCast(count);
        i.* = end;
        return oid;
    }
};

fn anyItaUnder(es: []const Entry) bool {
    for (es) |e| {
        if (e.intentToAdd()) return true;
    }
    return false;
}

fn countNonRemoved(es: []const Entry) usize {
    var n: usize = 0;
    for (es) |e| {
        if (!e.removed) n += 1;
    }
    return n;
}

var empty_tree_cache: ?Oid = null;
fn emptyTreeOid() Oid {
    if (empty_tree_cache == null) empty_tree_cache = hash.fromHex(hash.empty_tree_hex).?;
    return empty_tree_cache.?;
}

fn odbHas(oid: Oid) bool {
    return repo_mod.repo().odb().has(oid);
}

fn writeVarint(b: *util.Buf, value0: usize) void {
    var varint: [16]u8 = undefined;
    var value = value0;
    var p: usize = varint.len - 1;
    varint[p] = @intCast(value & 127);
    while (true) {
        value >>= 7;
        if (value == 0) break;
        value -= 1;
        p -= 1;
        varint[p] = @intCast(128 | (value & 127));
    }
    util.bufAppend(b, varint[p..]);
}

pub const MTIME_CHANGED: u32 = 0x0001;
pub const CTIME_CHANGED: u32 = 0x0002;
pub const OWNER_CHANGED: u32 = 0x0004;
pub const MODE_CHANGED: u32 = 0x0008;
pub const INODE_CHANGED: u32 = 0x0010;
pub const DATA_CHANGED: u32 = 0x0020;
pub const TYPE_CHANGED: u32 = 0x0040;

pub fn matchStatBasic(e: *const Entry, st: os.Stat) u32 {
    var changed: u32 = 0;
    const trust_exec = repo_mod.cfg.getBool("core.filemode") orelse true;
    const has_symlinks = repo_mod.cfg.getBool("core.symlinks") orelse true;
    switch (e.mode & 0o170000) {
        0o100000 => {
            if (!st.isReg()) changed |= TYPE_CHANGED;
            if (trust_exec and (0o100 & (e.mode ^ st.mode)) != 0) changed |= MODE_CHANGED;
        },
        0o120000 => {
            if (!st.isLnk() and (has_symlinks or !st.isReg())) changed |= TYPE_CHANGED;
        },
        0o160000 => {
            if (!st.isDir()) changed |= TYPE_CHANGED;
            if (st.isDir()) {
                if (gitlinkHead(e.path)) |h| {
                    if (!hash.eql(h, e.oid)) changed |= DATA_CHANGED;
                }
            }
            return changed;
        },
        else => return TYPE_CHANGED,
    }
    changed |= matchStatData(e, st);
    if (e.size == 0) {
        if (!util.eql(&hash.hex(e.oid), hash.empty_blob_hex)) changed |= DATA_CHANGED;
    }
    return changed;
}

pub fn matchStatData(e: *const Entry, st: os.Stat) u32 {
    var changed: u32 = 0;
    const trust_ctime = repo_mod.cfg.getBool("core.trustctime") orelse true;
    const check_stat_s = repo_mod.cfg.get("core.checkstat") orelse "default";
    const check_stat = !util.eql(check_stat_s, "minimal");
    if (e.mtime_s != @as(u32, @truncate(@as(u64, @bitCast(st.mtime))))) changed |= MTIME_CHANGED;
    if (trust_ctime and check_stat and e.ctime_s != @as(u32, @truncate(@as(u64, @bitCast(st.ctime))))) changed |= CTIME_CHANGED;
    if (check_stat) {
        if (e.uid != st.uid or e.gid != st.gid) changed |= OWNER_CHANGED;
        if (e.ino != @as(u32, @truncate(st.ino))) changed |= INODE_CHANGED;
    }
    if (e.size != @as(u32, @truncate(@as(u64, @bitCast(st.size))))) changed |= DATA_CHANGED;
    return changed;
}

/// Compare file content against entry's blob.
pub fn contentChanged(e: *const Entry, st: os.Stat) bool {
    switch (e.mode & 0o170000) {
        0o100000 => {
            if (!st.isReg()) return true;
            const oid = hashWorktreeFile(e.path, st, e.mode) orelse return true;
            return !hash.eql(oid, e.oid);
        },
        0o120000 => {
            if (st.isLnk()) {
                const t = os.readLink(e.path) orelse return true;
                return !hash.eql(odb_mod.hashObject(.blob, t), e.oid);
            }
            const data = os.readFile(e.path) orelse return true;
            return !hash.eql(odb_mod.hashObject(.blob, data), e.oid);
        },
        0o160000 => {
            if (!st.isDir()) return true;
            const head = gitlinkHead(e.path) orelse return false;
            return !hash.eql(head, e.oid);
        },
        else => return true,
    }
}

/// HEAD commit of a submodule checkout (for gitlink comparison)
pub fn gitlinkHead(path: []const u8) ?Oid {
    const dotgit = util.concat(&.{ path, "/.git" });
    var gd: []const u8 = dotgit;
    if (os.isFile(dotgit)) {
        const data = os.readFile(dotgit) orelse return null;
        const rest = util.skipPrefix(data, "gitdir: ") orelse return null;
        const p = util.trimRight(rest);
        gd = if (p.len > 0 and p[0] == '/') p else util.concat(&.{ path, "/", p });
    } else if (!os.isDir(dotgit)) return null;
    var name: []const u8 = "HEAD";
    var depth: usize = 0;
    while (depth < 10) : (depth += 1) {
        const data = os.readFile(util.concat(&.{ gd, "/", name })) orelse {
            // packed?
            const pk = os.readFile(util.concat(&.{ gd, "/packed-refs" })) orelse return null;
            var it = std.mem.splitScalar(u8, pk, '\n');
            while (it.next()) |line| {
                if (line.len > 41 and util.eql(line[41..], name)) return hash.fromHex(line[0..40]);
            }
            return null;
        };
        const t = util.trimRight(data);
        if (util.skipPrefix(t, "ref: ")) |r| {
            name = r;
            continue;
        }
        return hash.fromHex(t);
    }
    return null;
}

/// Hash a worktree file as a blob applying conversion (crlf/filters).
pub fn hashWorktreeFile(path: []const u8, st: os.Stat, mode: u32) ?Oid {
    _ = mode;
    if (st.isLnk()) {
        const t = os.readLink(path) orelse return null;
        return odb_mod.hashObject(.blob, t);
    }
    const data = os.readFile(path) orelse return null;
    const conv = @import("convert.zig");
    const converted = conv.toGit(path, data);
    return odb_mod.hashObject(.blob, converted);
}

pub fn defaultVersion() u32 {
    if (os.getenv("GIT_INDEX_VERSION")) |v| {
        const n = std.fmt.parseInt(u32, v, 10) catch 0;
        if (n >= 2 and n <= 4) return n;
        util.warn("GIT_INDEX_VERSION set, but the value is invalid.\nUsing version {d}", .{@as(u32, 2)});
        return 2;
    }
    if (repo_mod.cfg.getInt("index.version")) |v| {
        if (v >= 2 and v <= 4) return @intCast(v);
        util.warn("index.version set, but the value is invalid.\nUsing version {d}", .{@as(u32, 2)});
        return 2;
    }
    if (repo_mod.cfg.getBool("feature.manyfiles") orelse false) return 4;
    return 2;
}

// ---------------- global index ----------------

var the_index: ?*Index = null;

/// Read the repository index (cached).
pub fn get() *Index {
    if (the_index) |i| return i;
    const idx = gpa.create(Index) catch util.oom();
    idx.* = .{};
    idx.readFile(repo_mod.repo().indexPath());
    if (!idx.loaded_from_disk) idx.version = defaultVersion();
    the_index = idx;
    return idx;
}

/// Lock and read the index fresh (for modifications).
pub fn lockAndRead() *Index {
    const path = repo_mod.repo().indexPath();
    const l = lockfile.lockOrDie(path);
    const idx = gpa.create(Index) catch util.oom();
    idx.* = .{};
    idx.readFile(path);
    if (!idx.loaded_from_disk) idx.version = defaultVersion();
    idx.lock = l;
    the_index = idx;
    return idx;
}

/// Lock the index without reading it (a fresh, empty in-core index).
pub fn lockFresh() *Index {
    const path = repo_mod.repo().indexPath();
    const l = lockfile.lockOrDie(path);
    const idx = gpa.create(Index) catch util.oom();
    idx.* = .{};
    idx.path = path;
    idx.version = defaultVersion();
    idx.lock = l;
    the_index = idx;
    return idx;
}

pub fn readFrom(path: []const u8) *Index {
    const idx = gpa.create(Index) catch util.oom();
    idx.* = .{};
    idx.readFile(path);
    return idx;
}

pub fn discard() void {
    the_index = null;
}

/// Build an Entry for a worktree path from lstat; returns null if missing.
pub fn entryFromFile(path: []const u8, st: os.Stat, old: ?*const Entry, write_object: bool) ?Entry {
    var e = Entry{ .path = path };
    e.fillStat(st);
    e.mode = ceModeFromStat(old, st);
    if (st.isDir()) {
        e.oid = gitlinkHead(path) orelse return null;
        return e;
    }
    if (st.isLnk()) {
        const t = os.readLink(path) orelse return null;
        e.oid = if (write_object) repo_mod.repo().odb().write(.blob, t) else odb_mod.hashObject(.blob, t);
        return e;
    }
    const data = os.readFile(path) orelse return null;
    const conv = @import("convert.zig");
    const converted = conv.toGitChecked(path, data, write_object);
    e.oid = if (write_object) repo_mod.repo().odb().write(.blob, converted) else odb_mod.hashObject(.blob, converted);
    return e;
}

/// Read a tree into an index (stage 0), like read_tree.
pub fn addTreeRecursive(idx: *Index, tree: Oid, base: []const u8, stage: u32) void {
    const entries = objects.readTree(tree) orelse return;
    for (entries) |te| {
        const p = util.concat(&.{ base, te.name });
        if (te.isDir()) {
            addTreeRecursive(idx, te.oid, util.concat(&.{ p, "/" }), stage);
        } else {
            var e = Entry{ .path = p, .mode = te.mode, .oid = te.oid };
            e.setStage(stage);
            idx.entries.append(gpa, e) catch util.oom();
        }
    }
}

/// Replace index contents with the given tree (read-tree <tree>), keeping stat info where unchanged.
pub fn resetToTree(idx: *Index, tree: ?Oid) void {
    var old = idx.entries;
    idx.entries = .empty;
    if (tree) |t| addTreeRecursive(idx, t, "", 0);
    std.mem.sort(Entry, idx.entries.items, {}, entryLess);
    // carry over stat data
    var j: usize = 0;
    for (idx.entries.items) |*e| {
        while (j < old.items.len and compareName(old.items[j].path, old.items[j].stage(), e.path, 0) == .lt) j += 1;
        if (j < old.items.len and util.eql(old.items[j].path, e.path) and old.items[j].stage() == 0) {
            const o = old.items[j];
            if (hash.eql(o.oid, e.oid) and o.mode == e.mode) {
                var n = o;
                n.path = e.path;
                n.ext_flags &= ~CE_INTENT_TO_ADD;
                e.* = n;
            }
        }
    }
    old.deinit(gpa);
    idx.cache_tree = null;
    if (tree) |t| primeCacheTree(idx, t);
    idx.changed = true;
}

/// Fill cache tree from a tree object (prime_cache_tree).
pub fn primeCacheTree(idx: *Index, tree: Oid) void {
    const t = gpa.create(CacheTree) catch util.oom();
    t.* = .{};
    primeRec(t, tree);
    idx.cache_tree = t;
}

fn primeRec(t: *CacheTree, tree: Oid) void {
    t.oid = tree;
    const entries = objects.readTree(tree) orelse return;
    var cnt: i32 = 0;
    for (entries) |te| {
        if (te.isDir()) {
            const sub = t.findOrCreate(te.name);
            primeRec(sub, te.oid);
            cnt += sub.entry_count;
        } else cnt += 1;
    }
    t.entry_count = cnt;
}

// ---------------- refresh ----------------

pub const REFRESH_REALLY: u32 = 1 << 0;
pub const REFRESH_UNMERGED: u32 = 1 << 1;
pub const REFRESH_QUIET: u32 = 1 << 2;
pub const REFRESH_IGNORE_MISSING: u32 = 1 << 3;
pub const REFRESH_IGNORE_SUBMODULES: u32 = 1 << 4;
pub const REFRESH_IN_PORCELAIN: u32 = 1 << 5;
pub const REFRESH_IGNORE_SKIP_WORKTREE: u32 = 1 << 7;

const RefreshErr = enum { none, missing, modified };

/// refresh_cache_ent: returns updated entry, or null with err set.
fn refreshEntry(idx: *Index, e: *Entry, really: bool, ignore_missing: bool, err: *RefreshErr, changed_out: *u32) ?Entry {
    if (e.uptodate) return e.*;
    if (e.skipWorktree()) {
        e.uptodate = true;
        return e.*;
    }
    if (!really and e.assumeValid()) {
        e.uptodate = true;
        return e.*;
    }
    const ps = @import("pathspec.zig");
    if (ps.hasSymlinkLeadingPath(e.path)) {
        if (ignore_missing) return e.*;
        err.* = .missing;
        return null;
    }
    const st = os.lstatPath(e.path) orelse {
        if (ignore_missing) return e.*;
        err.* = .missing;
        return null;
    };
    var tmp = e.*;
    if (really) tmp.flags &= ~CE_VALID;
    const changed = idx.matchStat(&tmp, st, false);
    changed_out.* = changed;
    if (changed == 0) {
        if (e.mode & os.S_IFMT != os.S_IFGITLINK) e.uptodate = true;
        if (!(really and e.assumeValid())) return e.*;
    }
    if (idx.modified(&tmp, st)) {
        err.* = .modified;
        return null;
    }
    var n = e.*;
    n.fillStat(st);
    n.uptodate = true;
    return n;
}

/// refresh_index(): returns true if there were errors (needs update/merge).
pub fn refresh(idx: *Index, flags: u32, pspec: anytype, header_msg: ?[]const u8) bool {
    const really = flags & REFRESH_REALLY != 0;
    const allow_unmerged = flags & REFRESH_UNMERGED != 0;
    const quiet = flags & REFRESH_QUIET != 0;
    const not_new = flags & REFRESH_IGNORE_MISSING != 0;
    const porcelain = flags & REFRESH_IN_PORCELAIN != 0;
    var has_errors = false;
    var first = true;
    var i: usize = 0;
    while (i < idx.entries.items.len) : (i += 1) {
        const e = &idx.entries.items[i];
        if (flags & REFRESH_IGNORE_SUBMODULES != 0 and e.mode & os.S_IFMT == os.S_IFGITLINK) continue;
        if (flags & REFRESH_IGNORE_SKIP_WORKTREE != 0 and e.skipWorktree()) continue;
        var filtered = false;
        if (@TypeOf(pspec) != @TypeOf(null)) {
            if (pspec) |p| {
                if (!p.matches(e.path, false)) filtered = true;
            }
        }
        if (e.stage() != 0) {
            const name = e.path;
            while (i < idx.entries.items.len and util.eql(idx.entries.items[i].path, name)) i += 1;
            i -= 1;
            if (allow_unmerged) continue;
            if (!filtered) {
                if (porcelain) showRefreshFile("U\t{s}\n", name, porcelain, &first, header_msg) else showRefreshFile("{s}: needs merge\n", name, porcelain, &first, header_msg);
            }
            has_errors = true;
            continue;
        }
        if (filtered) continue;
        var err: RefreshErr = .none;
        var changed: u32 = 0;
        const n = refreshEntry(idx, e, really, not_new, &err, &changed) orelse {
            if (really and err == .modified and e.assumeValid()) {
                e.flags &= ~CE_VALID;
                idx.changed = true;
            }
            if (quiet) continue;
            const f: []const u8 = if (!porcelain) "needs update" else if (err == .missing) "D" else if (e.intentToAdd()) "A" else if (changed & TYPE_CHANGED != 0) "T" else "M";
            if (porcelain) {
                if (first) {
                    if (header_msg) |h| util.outf("{s}\n", .{h});
                    first = false;
                }
                util.outf("{s}\t{s}\n", .{ f, e.path });
            } else util.outf("{s}: needs update\n", .{e.path});
            has_errors = true;
            continue;
        };
        if (!statEqual(e, &n) or e.flags != n.flags) {
            idx.entries.items[i] = n;
            idx.changed = true;
        }
    }
    return has_errors;
}

fn statEqual(a: *const Entry, b: *const Entry) bool {
    return a.ctime_s == b.ctime_s and a.ctime_ns == b.ctime_ns and a.mtime_s == b.mtime_s and a.mtime_ns == b.mtime_ns and
        a.dev == b.dev and a.ino == b.ino and a.uid == b.uid and a.gid == b.gid and a.size == b.size;
}

fn showRefreshFile(comptime f: []const u8, name: []const u8, porcelain: bool, first: *bool, header_msg: ?[]const u8) void {
    if (porcelain and first.*) {
        if (header_msg) |h| util.outf("{s}\n", .{h});
        first.* = false;
    }
    util.outf(f, .{name});
}

fn verifyDotfile(rest: []const u8, mode: u32) bool {
    if (rest.len == 0 or rest[0] == '/') return false;
    switch (rest[0]) {
        'g', 'G' => {
            if (rest.len < 3) return true;
            if (rest[1] != 'i' and rest[1] != 'I') return true;
            if (rest[2] != 't' and rest[2] != 'T') return true;
            if (rest.len == 3 or rest[3] == '/') return false;
            if (mode & os.S_IFMT == os.S_IFLNK) {
                const r = rest[3..];
                if (r.len >= 7 and std.ascii.eqlIgnoreCase(r[0..7], "modules") and (r.len == 7 or r[7] == '/')) return false;
            }
        },
        '.' => {
            if (rest.len == 1 or rest[1] == '/') return false;
        },
        else => {},
    }
    return true;
}

/// is_ntfs_dotgit-lite: ".git" followed by spaces/dots, or "git~1".
fn ntfsDotgit(comp: []const u8) bool {
    if (std.ascii.eqlIgnoreCase(comp, "git~1")) return true;
    if (comp.len < 4 or comp[0] != '.' or !std.ascii.eqlIgnoreCase(comp[1..4], "git")) return false;
    for (comp[4..]) |ch| {
        if (ch != ' ' and ch != '.') return false;
    }
    return true;
}

/// verify_path(): is this a valid path to store in the index?
pub fn verifyPath(path: []const u8, mode: u32) bool {
    if (path.len == 0) return false;
    var i: usize = 0;
    while (true) {
        // at start of a component
        const end = std.mem.indexOfScalarPos(u8, path, i, '/') orelse path.len;
        const comp = path[i..end];
        if (comp.len == 0) {
            // empty component: leading "/", "//" or trailing "/"
            if (end == path.len and i > 0) return mode & os.S_IFMT == os.S_IFDIR;
            return false;
        }
        if (comp[0] == '.' and !verifyDotfile(path[i + 1 ..], mode)) return false;
        if (ntfsDotgit(comp)) return false;
        if (end == path.len) return true;
        i = end + 1;
    }
}

// ---------------- add_to_index & friends (read-cache.c) ----------------

pub const ADD_VERBOSE: u32 = 1;
pub const ADD_PRETEND: u32 = 2;
pub const ADD_IGNORE_ERRORS: u32 = 4;
pub const ADD_IGNORE_REMOVAL: u32 = 8;
pub const ADD_INTENT: u32 = 16;
pub const ADD_RENORMALIZE: u32 = 32;
/// add_files_to_cache(): skip paths outside the sparse-checkout definition (!include_sparse)
pub const ADD_SKIP_NONSPARSE: u32 = 1 << 10;

/// index_name_pos_also_unmerged(): preferred entry for a path (stage 0, else 2, else first).
pub fn posAlsoUnmerged(idx: *const Index, path: []const u8) ?usize {
    const first = idx.firstPos(path);
    const items = idx.entries.items;
    if (first >= items.len or !util.eql(items[first].path, path)) return null;
    if (items[first].stage() == 1 and first + 1 < items.len and items[first + 1].stage() == 2 and util.eql(items[first + 1].path, path)) return first + 1;
    return first;
}

/// add_to_index(); returns true on error (error already printed).
pub fn addToIndex(idx: *Index, path0: []const u8, st: os.Stat, flags: u32) bool {
    const verbose = flags & (ADD_VERBOSE | ADD_PRETEND) != 0;
    const pretend = flags & ADD_PRETEND != 0;
    const intent = flags & ADD_INTENT != 0;
    if (!st.isReg() and !st.isLnk() and !st.isDir()) {
        util.err("{s}: can only add regular files, symbolic links or git-directories", .{path0});
        return true;
    }
    var path = path0;
    if (st.isDir()) {
        while (path.len > 0 and path[path.len - 1] == '/') path = path[0 .. path.len - 1];
    }
    path = util.dupe(path);
    const old: ?Entry = if (posAlsoUnmerged(idx, path)) |p| idx.entries.items[p] else null;
    var alias: ?*Entry = null;
    if (flags & ADD_RENORMALIZE == 0) {
        if (idx.findPos(path)) |ap| {
            const a = &idx.entries.items[ap];
            alias = a;
            if (a.stage() == 0) {
                var changed: u32 = 0;
                if (a.intentToAdd()) {
                    changed = DATA_CHANGED | TYPE_CHANGED | MODE_CHANGED;
                } else {
                    changed = matchStatBasic(a, st);
                    if (changed == 0 and idx.isRacy(a)) changed |= DATA_CHANGED;
                }
                if (changed == 0) {
                    if (a.mode != 0o160000) a.uptodate = true;
                    return false;
                }
            }
        }
    }
    var e: Entry = undefined;
    if (!intent) {
        e = entryFromFile(path, st, if (old) |*o| o else null, !pretend) orelse {
            // index_path() error, then add_to_index() error (both use the original path)
            if (st.isDir()) {
                util.err("'{s}' does not have a commit checked out", .{path0});
            } else if (st.isReg()) {
                const fd = os.openFile(path0, os.O_RDONLY | os.O_CLOEXEC, 0);
                if (fd < 0) util.err("open(\"{s}\"): {s}", .{ path0, os.strErr(os.errno()) }) else os.close(fd);
            }
            util.err("unable to index file '{s}'", .{path0});
            return true;
        };
    } else {
        e = Entry{ .path = path };
        e.mode = ceModeFromStat(if (old) |*o| o else null, st);
        e.ext_flags |= CE_INTENT_TO_ADD;
        e.oid = repo_mod.repo().odb().write(.blob, "");
    }
    const was_same = if (alias) |a| a.stage() == 0 and hash.eql(a.oid, e.oid) and a.mode == e.mode else false;
    if (!pretend) {
        const exists0 = switch (idx.pos(path, 0)) {
            .found => true,
            .missing => false,
        };
        if (intent and exists0) {
            // ADD_CACHE_NEW_ONLY: keep the existing entry
        } else {
            if (!exists0 and !verifyPath(path, e.mode)) {
                util.err("invalid path '{s}'", .{path});
                util.err("unable to add '{s}' to index", .{path});
                return true;
            }
            if (!idx.add(e, .{})) {
                util.err("unable to add '{s}' to index", .{path});
                return true;
            }
            idx.changed = true;
        }
    }
    if (verbose and !was_same) util.outf("add '{s}'\n", .{path0});
    return false;
}

/// add_file_to_index()
pub fn addFileToIndex(idx: *Index, path: []const u8, flags: u32) bool {
    const st = os.lstatPath(path) orelse util.dieErrno("unable to stat '{s}'", .{path});
    return addToIndex(idx, path, st, flags);
}

/// remove_file_from_index_with_flags()
pub fn removeFileWithFlags(idx: *Index, path: []const u8, flags: u32) void {
    if (flags & (ADD_VERBOSE | ADD_PRETEND) != 0) util.outf("remove '{s}'\n", .{path});
    if (flags & ADD_PRETEND != 0) return;
    if (idx.removePath(path)) idx.changed = true;
    idx.invalidatePath(path);
}

/// check_removed() of diff-lib.c: is the worktree file for e gone (or unusable)?
fn checkRemoved(e: *const Entry) ?os.Stat {
    const pathspec_mod = @import("pathspec.zig");
    const st = os.lstatPath(e.path) orelse return null;
    if (pathspec_mod.hasSymlinkLeadingPath(e.path)) return null;
    if (st.isDir() and e.mode != 0o160000) {
        if (gitlinkHead(e.path) == null) return null;
    }
    return st;
}

const PendingKind = enum { modified, deleted };
const Pending = struct { path: []const u8, kind: PendingKind };

/// Worktree changes of tracked files (run_diff_files with DIFF_RACY_IS_MODIFIED);
/// returns paths in index order.
fn collectWorktreeChanges(idx: *Index, pspec: anytype, seen: ?[]u8, flags: u32) []Pending {
    var list: std.ArrayList(Pending) = .empty;
    var i: usize = 0;
    const items = idx.entries.items;
    while (i < items.len) : (i += 1) {
        const e = &items[i];
        if (@TypeOf(pspec) != @TypeOf(null)) {
            if (pspec) |p| {
                if (p.matchSeen(e.path, e.mode == 0o160000, seen) == 0) {
                    if (e.stage() != 0) {
                        while (i + 1 < items.len and util.eql(items[i + 1].path, e.path)) i += 1;
                    }
                    continue;
                }
            }
        }
        if (e.stage() != 0) {
            const name = e.path;
            while (i + 1 < items.len and util.eql(items[i + 1].path, name)) i += 1;
            const gone = os.lstatPath(name) == null;
            const kind: PendingKind = if (flags & ADD_IGNORE_REMOVAL == 0 and gone) .deleted else .modified;
            list.append(gpa, .{ .path = name, .kind = kind }) catch util.oom();
            continue;
        }
        if (e.uptodate or e.skipWorktree()) continue;
        const st = checkRemoved(e) orelse {
            list.append(gpa, .{ .path = e.path, .kind = .deleted }) catch util.oom();
            continue;
        };
        if (idx.matchStat(e, st, true) == 0) {
            e.uptodate = true;
            continue;
        }
        list.append(gpa, .{ .path = e.path, .kind = .modified }) catch util.oom();
    }
    return list.items;
}

/// add_files_to_cache(); returns true if there were add errors.
pub fn addFilesToCache(idx: *Index, pspec: anytype, seen: ?[]u8, flags: u32) bool {
    var errors = false;
    for (collectWorktreeChanges(idx, pspec, seen, flags)) |p| {
        if (flags & ADD_SKIP_NONSPARSE != 0 and !@import("sparse.zig").pathInSparseCheckout(p.path)) continue;
        switch (p.kind) {
            .modified => {
                if (addFileToIndex(idx, p.path, flags)) {
                    if (flags & ADD_IGNORE_ERRORS == 0) util.die("updating files failed", .{});
                    errors = true;
                }
            },
            .deleted => {
                if (flags & ADD_IGNORE_REMOVAL != 0) continue;
                removeFileWithFlags(idx, p.path, flags);
            },
        }
    }
    return errors;
}

/// has_conflict_markers() from merge-ll.c (marker size 7 unless conflict-marker-size attr)
pub fn hasConflictMarkers(path: []const u8) bool {
    const data = os.readFile(path) orelse return false;
    const marker_size: usize = 7;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |l0| {
        const line = if (it.index != null) data[@intFromPtr(l0.ptr) - @intFromPtr(data.ptr) ..][0 .. l0.len + 1] else l0;
        if (isConflictMarkerLine(line, marker_size)) return true;
        if (std.mem.indexOfScalar(u8, line, 0) != null) break;
    }
    return false;
}

fn isConflictMarkerLine(line: []const u8, marker_size: usize) bool {
    if (line.len < marker_size + 1) return false;
    const c = line[0];
    if (c != '=' and c != '>' and c != '<' and c != '|') return false;
    for (line[1..marker_size]) |x| {
        if (x != c) return false;
    }
    if ((c == '<' or c == '>') and line[marker_size] != ' ') return false;
    return std.ascii.isWhitespace(line[marker_size]);
}

/// chmod_index_entry()
pub fn chmodEntry(idx: *Index, e: *Entry, flip: u8) bool {
    if (e.mode & 0o170000 != 0o100000) return false;
    if (flip == '+') e.mode |= 0o111 else e.mode &= ~@as(u32, 0o111);
    idx.invalidatePath(e.path);
    idx.changed = true;
    return true;
}

/// remove_path() from dir.c: unlink the file and prune now-empty leading
/// directories, but never the directory git was started in.
pub fn removeWorktreePath(name: []const u8) bool {
    if (!os.unlink(name)) {
        const e = os.errno();
        if (e != os.ENOENT and e != os.ENOTDIR) return false;
    }
    const r = repo_mod.repo();
    const cwd = if (r.prefix.len > 0) r.prefix[0 .. r.prefix.len - 1] else "";
    var dirs = name;
    while (std.mem.lastIndexOfScalar(u8, dirs, '/')) |sl| {
        dirs = dirs[0..sl];
        if (cwd.len > 0 and util.eql(dirs, cwd)) break;
        if (!os.rmdir(dirs)) break;
    }
    return true;
}

/// Temporarily make `idx` the global index returned by get(); returns the
/// previous one (null if none was loaded) so callers can restore it.
pub fn swapCurrent(idx: ?*Index) ?*Index {
    const prev = the_index;
    the_index = idx;
    return prev;
}

/// The global index if it has already been read (istate->cache != NULL), else null.
pub fn peek() ?*Index {
    return the_index;
}

// ---------------- split index helpers ----------------

extern "c" fn utime(path: [*:0]const u8, times: ?*const anyopaque) c_int;

/// check_and_freshen_file(path, 1)
fn freshenFile(path: []const u8) bool {
    if (!os.exists(path)) return false;
    const z = util.concat(&.{ path, "\x00" });
    return utime(z[0..path.len :0], null) == 0;
}

fn envBool(name: []const u8) bool {
    const v = os.getenv(name) orelse return false;
    return @import("config.zig").parseBool(v) orelse util.die("bad boolean environment value '{s}' for '{s}'", .{ v, name });
}

/// git_config_perm("core.sharedrepository"): 0 = umask, >0 = OR mask, <0 = exact mode
fn sharedRepositoryPerm() i32 {
    const v = repo_mod.cfg.get("core.sharedrepository") orelse return 0;
    if (util.eql(v, "umask")) return 0;
    if (util.eql(v, "group")) return 0o660;
    if (util.eql(v, "all") or util.eql(v, "world") or util.eql(v, "everybody")) return 0o664;
    const n = std.fmt.parseInt(i32, v, 8) catch {
        return if (@import("config.zig").parseBool(v) orelse false) 0o660 else 0;
    };
    return switch (n) {
        0 => 0,
        1 => 0o660,
        2 => 0o664,
        else => -(n & 0o666),
    };
}

/// adjust_shared_perm() for a regular file
fn adjustSharedPerm(path: []const u8) bool {
    const shared = sharedRepositoryPerm();
    if (shared == 0) return true;
    const st = os.statPath(path) orelse return false;
    const old: u32 = st.mode & 0o7777;
    var tweak: u32 = @intCast(if (shared < 0) -shared else shared);
    if (old & 0o200 == 0) tweak &= ~@as(u32, 0o222);
    if (old & 0o100 != 0) tweak |= (tweak & 0o444) >> 2;
    const new = if (shared < 0) (old & ~@as(u32, 0o777)) | tweak else old | tweak;
    if (new != old) return os.chmod(path, new);
    return true;
}

/// compare_ce_content(): stat data and object name only
fn ceContentDiffers(a: *const Entry, b: *const Entry) bool {
    return !(a.ctime_s == b.ctime_s and a.ctime_ns == b.ctime_ns and a.mtime_s == b.mtime_s and a.mtime_ns == b.mtime_ns and
        a.dev == b.dev and a.ino == b.ino and a.uid == b.uid and a.gid == b.gid and a.size == b.size and hash.eql(a.oid, b.oid));
}

var shared_index_expire: ?i64 = null;

fn sharedIndexExpireDate() i64 {
    if (shared_index_expire) |e| return e;
    const date = @import("date.zig");
    const v = repo_mod.cfg.get("splitindex.sharedindexexpire") orelse "2.weeks.ago";
    const e = date.approxidate(v);
    shared_index_expire = e;
    return e;
}

/// clean_shared_index_files()
fn cleanSharedIndexFiles(current_hex: []const u8) void {
    const gd = repo_mod.repo().git_dir;
    const ents = os.listDir(gd) orelse {
        util.err("unable to open git dir: {s}", .{gd});
        return;
    };
    for (ents) |de| {
        if (!util.startsWith(de.name, "sharedindex.")) continue;
        if (util.eql(de.name["sharedindex.".len..], current_hex)) continue;
        const p = util.concat(&.{ gd, "/", de.name });
        const expiration = sharedIndexExpireDate();
        if (expiration == 0) continue;
        const st = os.statPath(p) orelse {
            util.err("could not stat '{s}'", .{p});
            continue;
        };
        if (st.mtime > expiration) continue;
        if (!os.unlink(p)) util.warn("unable to unlink: {s}", .{p});
    }
}
