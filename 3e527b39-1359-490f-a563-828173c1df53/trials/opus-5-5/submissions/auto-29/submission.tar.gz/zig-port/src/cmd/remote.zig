//! git remote (port of builtin/remote.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const tp = @import("../transport.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const config = @import("../config.zig");
const repo_mod = @import("../repo.zig");
const proc = @import("../proc.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git remote [-v | --verbose]",
    "git remote add [-t <branch>] [-m <master>] [-f] [--tags | --no-tags] [--mirror=<fetch|push>] <name> <url>",
    "git remote rename [--[no-]progress] <old> <new>",
    "git remote remove <name>",
    "git remote set-head <name> (-a | --auto | -d | --delete | <branch>)",
    "git remote [-v | --verbose] show [-n] <name>",
    "git remote prune [-n | --dry-run] <name>",
    "git remote [-v | --verbose] update [-p | --prune] [(<group> | <remote>)...]",
    "git remote set-branches [--add] <name> <branch>...",
    "git remote get-url [--push] [--all] <name>",
    "git remote set-url [--push] <name> <newurl> [<oldurl>]",
    "git remote set-url --add <name> <newurl>",
    "git remote set-url --delete <name> <url>",
};

var verbose: i32 = 0;

fn configPath() []const u8 {
    return repo_mod.repo().commonPath("config");
}

fn cfgSet(key: []const u8, value: ?[]const u8) void {
    const r = config.setInFileGently(configPath(), key, null, value);
    if (r != 0) {
        if (value == null and r == config.CONFIG_NOTHING_SET) return;
        if (value != null) util.die("could not set '{s}' to '{s}'", .{ key, value.? });
        util.die("could not unset '{s}'", .{key});
    }
}

fn cfgSetGently(key: []const u8, value: ?[]const u8) i32 {
    return config.setInFileGently(configPath(), key, null, value);
}

fn cfgAdd(key: []const u8, value: []const u8) void {
    if (config.setMultivarInFile(configPath(), key, value, .{ .pattern = "^$" }, null, .{}) < 0)
        util.die("could not set '{s}' to '{s}'", .{ key, value });
}

fn reload() void {
    repo_mod.loadConfig();
    tp.invalidate();
}

fn fetchRemote(name: []const u8) bool {
    var args: std.ArrayList([]const u8) = .empty;
    args.append(gpa, "fetch") catch util.oom();
    if (verbose > 0) args.append(gpa, "-v") catch util.oom();
    args.append(gpa, name) catch util.oom();
    util.outf("Updating {s}\n", .{name});
    util.flushStdout();
    const ch = proc.spawnGit(args.items, .{});
    if (proc.wait(ch.pid) != 0) {
        util.err("Could not fetch {s}", .{name});
        return false;
    }
    return true;
}

const MIRROR_FETCH: i32 = 1;
const MIRROR_PUSH: i32 = 2;

fn addBranch(key: []const u8, branchname: []const u8, remotename: []const u8, mirror: bool) void {
    const v = if (mirror)
        util.fmt("+refs/{s}:refs/{s}", .{ branchname, branchname })
    else
        util.fmt("+refs/heads/{s}:refs/remotes/{s}/{s}", .{ branchname, remotename, branchname });
    cfgAdd(key, v);
}

// ---------------- add ----------------

var add_fetch = false;
var add_tags: i32 = 1;
var add_track: std.ArrayList([]const u8) = .empty;
var add_master: ?[]const u8 = null;
var add_mirror: i32 = 0;

fn mirrorCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        add_mirror = 0;
    } else if (arg == null) {
        util.warn("--mirror is dangerous and deprecated; please\n\t use --mirror=fetch or --mirror=push instead", .{});
        add_mirror = MIRROR_FETCH | MIRROR_PUSH;
    } else if (util.eql(arg.?, "fetch")) {
        add_mirror = MIRROR_FETCH;
    } else if (util.eql(arg.?, "push")) {
        add_mirror = MIRROR_PUSH;
    } else {
        util.err("unknown --mirror argument: {s}", .{arg.?});
        po.usageWithOptions(&add_usage, &add_options);
    }
}

const add_usage = [_][]const u8{"git remote add [<options>] <name> <url>"};
const add_options = [_]po.Opt{
    po.boolean('f', "fetch", &add_fetch, "fetch the remote branches"),
    .{ .long = "tags", .kind = .set_int, .i = &add_tags, .val = 2, .help = "import all tags and associated objects when fetching\nor do not fetch any tag at all (--no-tags)" },
    po.list('t', "track", &add_track, "branch", "branch(es) to track"),
    po.string('m', "master", &add_master, "branch", "master branch"),
    .{ .long = "mirror", .kind = .callback, .cb = mirrorCb, .optarg = true, .argh = "(push|fetch)", .help = "set up remote as a mirror to push to or fetch from", .literal_argh = true, .comp_arg = true },
};

fn cmdAdd(args: []const []const u8) u8 {
    const rest = po.parse(args, &add_options, &add_usage, .{});
    if (rest.len != 2) po.usageWithOptions(&add_usage, &add_options);
    if (add_mirror != 0 and add_master != null) util.die("specifying a master branch makes no sense with --mirror", .{});
    if (add_mirror != 0 and (add_mirror & MIRROR_FETCH) == 0 and add_track.items.len > 0)
        util.die("specifying branches to track makes sense only with fetch mirrors", .{});
    const name = rest[0];
    const url = rest[1];
    const remote = tp.remoteGet(name);
    if (remote) |r| {
        if (tp.remoteIsConfigured(r, true)) {
            util.err("remote {s} already exists.", .{name});
            os.exit(3);
        }
    }
    if (!tp.validRemoteName(name)) util.die("'{s}' is not a valid remote name", .{name});
    for (tp.allRemotes()) |r| {
        if (util.skipPrefix(name, r.name)) |p| {
            if (p.len > 0 and p[0] == '/') util.die("remote name '{s}' is a subset of existing remote '{s}'", .{ name, r.name });
        }
        if (util.skipPrefix(r.name, name)) |p| {
            if (p.len > 0 and p[0] == '/') util.die("remote name '{s}' is a superset of existing remote '{s}'", .{ name, r.name });
        }
    }
    cfgSet(util.fmt("remote.{s}.url", .{name}), url);
    if (add_mirror == 0 or (add_mirror & MIRROR_FETCH) != 0) {
        const key = util.fmt("remote.{s}.fetch", .{name});
        if (add_track.items.len == 0) add_track.append(gpa, "*") catch util.oom();
        for (add_track.items) |t| addBranch(key, t, name, add_mirror != 0);
    }
    if ((add_mirror & MIRROR_PUSH) != 0) cfgSet(util.fmt("remote.{s}.mirror", .{name}), "true");
    if (add_tags != 1) cfgSet(util.fmt("remote.{s}.tagOpt", .{name}), if (add_tags == 2) "--tags" else "--no-tags");
    reload();
    if (add_fetch and !fetchRemote(name)) return 1;
    if (add_master) |m| {
        const head = util.fmt("refs/remotes/{s}/HEAD", .{name});
        const target = util.fmt("refs/remotes/{s}/{s}", .{ name, m });
        refs.writeSymref(head, target, "remote add") catch {
            util.err("Could not setup master '{s}'", .{m});
            return 1;
        };
    }
    return 0;
}

// ---------------- branch info ----------------

const BranchInfo = struct {
    name: []const u8,
    remote_name: ?[]const u8 = null,
    merge: std.ArrayList([]const u8) = .empty,
    rebase: i32 = 0, // 0 false, 1 true, 2 merges, 3 interactive
    push_remote_name: ?[]const u8 = null,
};

var branch_list: std.ArrayList(*BranchInfo) = .empty;
var branches_read = false;

fn abbrevBranch(n: []const u8) []const u8 {
    return util.skipPrefix(n, "refs/heads/") orelse n;
}

fn getBranchInfo(name: []const u8) *BranchInfo {
    for (branch_list.items) |b| {
        if (util.eql(b.name, name)) return b;
    }
    const b = gpa.create(BranchInfo) catch util.oom();
    b.* = .{ .name = name };
    // sorted insert
    var i: usize = 0;
    while (i < branch_list.items.len and std.mem.order(u8, branch_list.items[i].name, name) == .lt) i += 1;
    branch_list.insert(gpa, i, b) catch util.oom();
    return b;
}

fn readBranches() void {
    if (branches_read) return;
    branches_read = true;
    for (repo_mod.cfg.entries.items) |e| {
        const k = util.skipPrefix(e.key, "branch.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, k, '.') orelse continue;
        const name = k[0..dot];
        const sub = k[dot + 1 ..];
        const v = e.value orelse "";
        if (util.eql(sub, "remote")) {
            const b = getBranchInfo(name);
            if (b.remote_name != null) util.warn("more than one {s}", .{e.key});
            b.remote_name = v;
        } else if (util.eql(sub, "merge")) {
            const b = getBranchInfo(name);
            var val = abbrevBranch(v);
            while (std.mem.indexOfScalar(u8, val, ' ')) |sp| {
                b.merge.append(gpa, val[0..sp]) catch util.oom();
                val = abbrevBranch(val[sp + 1 ..]);
            }
            b.merge.append(gpa, val) catch util.oom();
        } else if (util.eql(sub, "rebase")) {
            const b = getBranchInfo(name);
            if (config.parseBool(v)) |bv| {
                b.rebase = if (bv) 1 else 0;
            } else if (util.eql(v, "merges") or util.eql(v, "m")) {
                b.rebase = 2;
            } else if (util.eql(v, "interactive") or util.eql(v, "i")) {
                b.rebase = 3;
            } else {
                util.warn("unhandled branch.{s}.rebase={s}; assuming 'true'", .{ name, v });
                b.rebase = -1;
            }
        } else if (util.eql(sub, "pushremote")) {
            const b = getBranchInfo(name);
            if (b.push_remote_name != null) util.warn("more than one {s}", .{e.key});
            b.push_remote_name = v;
        }
    }
}

// ---------------- rename ----------------

var mv_progress = false;
const mv_usage = [_][]const u8{"git remote rename [--[no-]progress] <old> <new>"};
const mv_options = [_]po.Opt{
    po.boolean(0, "progress", &mv_progress, "force progress reporting"),
};

fn handlePushDefault(old_name: []const u8, new_name: ?[]const u8) void {
    var found: ?config.Entry = null;
    for (repo_mod.cfg.entries.items) |e| {
        if (!util.eql(e.key, "remote.pushdefault")) continue;
        const v = e.value orelse continue;
        if (!util.eql(v, old_name)) continue;
        found = e;
    }
    const e = found orelse return;
    switch (e.scope) {
        .command, .unknown => {},
        .local, .worktree => {
            const r = cfgSetGently("remote.pushDefault", new_name);
            if (r != 0 and r != config.CONFIG_NOTHING_SET) {
                if (new_name != null) util.die("could not set '{s}'", .{"remote.pushDefault"});
                util.die("could not unset '{s}'", .{"remote.pushDefault"});
            }
        },
        .system, .global => {
            util.warn("The {s} configuration remote.pushDefault in:\n\t{s}:{d}\nnow names the non-existent remote '{s}'", .{ e.scope.name(), e.origin, e.line, old_name });
        },
    }
}

fn cmdRename(args: []const []const u8) u8 {
    mv_progress = os.isatty(2);
    const rest = po.parse(args, &mv_options, &mv_usage, .{});
    if (rest.len != 2) po.usageWithOptions(&mv_usage, &mv_options);
    const old_name = rest[0];
    const new_name = rest[1];
    const oldremote = tp.remoteGet(old_name);
    if (oldremote == null or !tp.remoteIsConfigured(oldremote.?, true)) {
        util.err("No such remote: '{s}'", .{old_name});
        os.exit(2);
    }
    const old = oldremote.?;
    if (tp.remoteGet(new_name)) |nr| {
        if (tp.remoteIsConfigured(nr, true)) {
            util.err("remote {s} already exists.", .{new_name});
            os.exit(3);
        }
    }
    if (!tp.validRemoteName(new_name)) util.die("'{s}' is not a valid remote name", .{new_name});
    const old_sec = util.fmt("remote.{s}", .{old_name});
    const new_sec = util.fmt("remote.{s}", .{new_name});
    if (config.renameSectionInFile(configPath(), old_sec, new_sec, false) < 1) {
        util.err("Could not rename config section '{s}' to '{s}'", .{ old_sec, new_sec });
        return 1;
    }
    const ctx = util.fmt(":refs/remotes/{s}/", .{old_name});
    var need_update = false;
    for (old.fetch.items.items) |it| {
        if (std.mem.indexOf(u8, it.raw, ctx) != null) {
            need_update = true;
            break;
        }
    }
    if (old.fetch.items.items.len > 0) {
        const key = util.fmt("remote.{s}.fetch", .{new_name});
        _ = config.setMultivarInFile(configPath(), key, null, .any, null, .{ .multi_replace = true });
        for (old.fetch.items.items) |it| {
            var v: []const u8 = it.raw;
            if (std.mem.indexOf(u8, v, ctx)) |pos| {
                const start = pos + ":refs/remotes/".len;
                v = util.concat(&.{ v[0..start], new_name, v[start + old_name.len ..] });
            } else {
                util.warn("Not updating non-default fetch refspec\n\t{s}\n\tPlease update the configuration manually if necessary.", .{v});
            }
            cfgAdd(key, v);
        }
    }
    readBranches();
    for (branch_list.items) |b| {
        if (b.remote_name) |rn| {
            if (util.eql(rn, old_name)) cfgSet(util.fmt("branch.{s}.remote", .{b.name}), new_name);
        }
        if (b.push_remote_name) |rn| {
            if (util.eql(rn, old_name)) cfgSet(util.fmt("branch.{s}.pushRemote", .{b.name}), new_name);
        }
    }
    if (need_update) {
        const prefix = util.fmt("refs/remotes/{s}/", .{old_name});
        const list = refs.iterate(prefix, .{ .include_broken = true, .check_objects = false });
        const newpfx = util.fmt("refs/remotes/{s}/", .{new_name});
        // symrefs last so their targets exist
        for (list) |r| {
            if (r.flags & refs.REF_ISSYMREF != 0) continue;
            const nn = util.concat(&.{ newpfx, r.name[prefix.len..] });
            if (!refs.renameRef(r.name, nn, util.fmt("remote: renamed {s} to {s}", .{ r.name, nn }), false))
                util.die("renaming remote refs failed: {s}", .{r.name});
        }
        for (list) |r| {
            if (r.flags & refs.REF_ISSYMREF == 0) continue;
            const nn = util.concat(&.{ newpfx, r.name[prefix.len..] });
            var target = refs.readSymbolic(r.name) orelse continue;
            if (util.skipPrefix(target, prefix)) |t| target = util.concat(&.{ newpfx, t });
            refs.deleteRef(r.name, null, refs.F_NO_DEREF, null) catch {};
            refs.writeSymref(nn, target, null) catch util.die("renaming remote refs failed: {s}", .{r.name});
        }
        reload();
        handlePushDefault(old_name, new_name);
    }
    return 0;
}

// ---------------- rm ----------------

const rm_usage = [_][]const u8{"git remote remove <name>"};
const rm_options = [_]po.Opt{};

fn cmdRm(args: []const []const u8) u8 {
    const rest = po.parse(args, &rm_options, &rm_usage, .{});
    if (rest.len != 1) po.usageWithOptions(&rm_usage, &rm_options);
    const remote = tp.remoteGet(rest[0]);
    if (remote == null or !tp.remoteIsConfigured(remote.?, true)) {
        util.err("No such remote: '{s}'", .{rest[0]});
        os.exit(2);
    }
    const r = remote.?;
    var others: std.ArrayList(*tp.Remote) = .empty;
    for (tp.allRemotes()) |o| {
        if (!util.eql(o.name, r.name)) others.append(gpa, o) catch util.oom();
    }
    readBranches();
    for (branch_list.items) |b| {
        if (b.remote_name) |rn| {
            if (util.eql(rn, r.name)) {
                for ([_][]const u8{ "remote", "merge" }) |k| {
                    const key = util.fmt("branch.{s}.{s}", .{ b.name, k });
                    const res = cfgSetGently(key, null);
                    if (res != 0 and res != config.CONFIG_NOTHING_SET) util.die("could not unset '{s}'", .{key});
                }
            }
        }
        if (b.push_remote_name) |rn| {
            if (util.eql(rn, r.name)) {
                const key = util.fmt("branch.{s}.pushremote", .{b.name});
                const res = cfgSetGently(key, null);
                if (res != 0 and res != config.CONFIG_NOTHING_SET) util.die("could not unset '{s}'", .{key});
            }
        }
    }
    var to_delete: std.ArrayList([]const u8) = .empty;
    var skipped: std.ArrayList([]const u8) = .empty;
    outer: for (refs.iterate("", .{ .check_objects = false })) |lr| {
        if (r.fetch.findMatch(null, lr.name) == null) continue;
        for (others.items) |o| {
            if (o.fetch.findMatch(null, lr.name) != null) continue :outer;
        }
        if (!util.startsWith(lr.name, "refs/remotes/")) {
            if (util.startsWith(lr.name, "refs/heads/")) skipped.append(gpa, abbrevBranch(lr.name)) catch util.oom();
            continue;
        }
        to_delete.append(gpa, lr.name) catch util.oom();
    }
    var result: u8 = 0;
    if (!refs.deleteRefs(to_delete.items, refs.F_NO_DEREF, "remote: remove")) result = 1;
    if (skipped.items.len > 0) {
        if (skipped.items.len == 1) {
            util.eprint("Note: A branch outside the refs/remotes/ hierarchy was not removed;\nto delete it, use:\n", .{});
        } else util.eprint("Note: Some branches outside the refs/remotes/ hierarchy were not removed;\nto delete them, use:\n", .{});
        for (skipped.items) |s| util.eprint("  git branch -d {s}\n", .{s});
    }
    if (result == 0) {
        const sec = util.fmt("remote.{s}", .{r.name});
        if (config.renameSectionInFile(configPath(), sec, null, false) < 1) {
            util.err("Could not remove config section '{s}'", .{sec});
            return 1;
        }
        reload();
        handlePushDefault(r.name, null);
    }
    return result;
}

// ---------------- show ----------------

const PushInfo = struct {
    src: []const u8,
    dest: []const u8,
    forced: bool = false,
    status: enum { create, delete, uptodate, fastforward, outofdate, notqueried } = .notqueried,
};

const RefStates = struct {
    remote: *tp.Remote = undefined,
    new_refs: std.ArrayList([]const u8) = .empty,
    skipped: std.ArrayList([]const u8) = .empty,
    stale: std.ArrayList([]const u8) = .empty,
    stale_full: std.ArrayList([]const u8) = .empty,
    tracked: std.ArrayList([]const u8) = .empty,
    heads: std.ArrayList([]const u8) = .empty,
    push: std.ArrayList(PushInfo) = .empty,
    queried: bool = false,
};

const GET_REF_STATES: u32 = 1;
const GET_HEAD_NAMES: u32 = 2;
const GET_PUSH_REF_STATES: u32 = 4;

fn strLess(_: void, a: []const u8, b: []const u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

fn sortStrings(l: *std.ArrayList([]const u8)) void {
    std.sort.block([]const u8, l.items, {}, strLess);
}

fn hasString(l: []const []const u8, s: []const u8) bool {
    for (l) |x| {
        if (util.eql(x, s)) return true;
    }
    return false;
}

fn getRefStates(remote_refs: []const *tp.Ref, st: *RefStates) void {
    var fetch_map: std.ArrayList(*tp.Ref) = .empty;
    for (st.remote.fetch.items.items) |it| tp.getFetchMap(remote_refs, it, &fetch_map, true);
    for (fetch_map.items) |r| {
        if (st.remote.fetch.matchesNegative(r.name)) {
            st.skipped.append(gpa, abbrevBranch(r.name)) catch util.oom();
        } else if (r.peer_ref == null or !refs.exists(r.peer_ref.?.name)) {
            st.new_refs.append(gpa, abbrevBranch(r.name)) catch util.oom();
        } else st.tracked.append(gpa, abbrevBranch(r.name)) catch util.oom();
    }
    // stale: sorted with full names kept parallel
    const stale = tp.getStaleHeads(&st.remote.fetch, fetch_map.items);
    const Pair = struct { short: []const u8, full: []const u8 };
    var pairs: std.ArrayList(Pair) = .empty;
    for (stale) |r| pairs.append(gpa, .{ .short = abbrevBranch(r.name), .full = r.name }) catch util.oom();
    std.sort.block(Pair, pairs.items, {}, struct {
        fn f(_: void, a: Pair, b: Pair) bool {
            return std.mem.order(u8, a.short, b.short) == .lt;
        }
    }.f);
    for (pairs.items) |p| {
        st.stale.append(gpa, p.short) catch util.oom();
        st.stale_full.append(gpa, p.full) catch util.oom();
    }
    sortStrings(&st.new_refs);
    sortStrings(&st.skipped);
    sortStrings(&st.tracked);
}

fn getPushRefStates(remote_refs: []const *tp.Ref, st: *RefStates) void {
    const remote = st.remote;
    if (remote.mirror) return;
    const local = tp.getLocalHeads();
    var push_map: std.ArrayList(*tp.Ref) = .empty;
    for (remote_refs) |r| push_map.append(gpa, tp.copyRef(r)) catch util.oom();
    var rs = remote.push;
    _ = tp.matchPushRefs(local, &push_map, &rs, 0);
    const cr = @import("../commitreach.zig");
    const odbm = repo_mod.repo().odb();
    for (push_map.items) |r| {
        const p = r.peer_ref orelse continue;
        r.new_oid = p.new_oid;
        var info = PushInfo{ .src = abbrevBranch(p.name), .dest = abbrevBranch(r.name), .forced = r.force };
        if (hash.isZero(r.new_oid)) {
            info.status = .delete;
        } else if (hash.eql(r.old_oid, r.new_oid)) {
            info.status = .uptodate;
        } else if (hash.isZero(r.old_oid)) {
            info.status = .create;
        } else if (odbm.has(r.old_oid) and cr.refNewer(r.new_oid, r.old_oid)) {
            info.status = .fastforward;
        } else info.status = .outofdate;
        st.push.append(gpa, info) catch util.oom();
    }
}

fn getPushRefStatesNoquery(st: *RefStates) void {
    const remote = st.remote;
    if (remote.mirror) return;
    if (remote.push.items.items.len == 0) {
        st.push.append(gpa, .{ .src = "(matching)", .dest = "(matching)" }) catch util.oom();
    }
    for (remote.push.items.items) |spec| {
        const s: []const u8 = if (spec.matching) "(matching)" else if (spec.src.?.len > 0) spec.src.? else "(delete)";
        st.push.append(gpa, .{ .src = s, .dest = spec.dst orelse s, .forced = spec.force }) catch util.oom();
    }
}

fn getHeadNames(remote_refs: []const *tp.Ref, st: *RefStates) void {
    var fetch_map: std.ArrayList(*tp.Ref) = .empty;
    const spec = tp.RefspecItem{ .pattern = true, .src = "refs/heads/*", .dst = "refs/heads/*" };
    tp.getFetchMap(remote_refs, spec, &fetch_map, false);
    const matches = tp.guessRemoteHead(tp.findRefByName(remote_refs, "HEAD"), fetch_map.items, true);
    for (matches) |m| st.heads.append(gpa, abbrevBranch(m.name)) catch util.oom();
}

fn getRemoteRefStates(name: []const u8, st: *RefStates, query: u32) bool {
    st.remote = tp.remoteGet(name) orelse {
        util.err("No such remote: '{s}'", .{name});
        return false;
    };
    readBranches();
    if (query != 0) {
        const t = tp.transportGet(st.remote, st.remote.urls.items[0]);
        const rr = tp.getRemoteRefs(t, &.{});
        st.queried = true;
        if (query & GET_REF_STATES != 0) getRefStates(rr, st);
        if (query & GET_HEAD_NAMES != 0) getHeadNames(rr, st);
        if (query & GET_PUSH_REF_STATES != 0) getPushRefStates(rr, st);
        _ = tp.disconnect(t);
    } else {
        for (refs.iterate("", .{ .check_objects = false })) |lr| {
            if (lr.flags & refs.REF_ISSYMREF != 0) continue;
            if (st.remote.fetch.findMatch(null, lr.name)) |m| st.tracked.append(gpa, abbrevBranch(m.value)) catch util.oom();
        }
        sortStrings(&st.tracked);
        getPushRefStatesNoquery(st);
    }
    return true;
}

fn showAll() u8 {
    const Item = struct { name: []const u8, info: ?[]const u8 };
    var list: std.ArrayList(Item) = .empty;
    for (tp.allRemotes()) |r| {
        if (r.urls.items.len > 0) {
            var s = util.fmt("{s} (fetch)", .{r.urls.items[0]});
            if (repo_mod.cfg.get(util.fmt("remote.{s}.partialclonefilter", .{r.name}))) |f| s = util.fmt("{s} [{s}]", .{ s, f });
            list.append(gpa, .{ .name = r.name, .info = s }) catch util.oom();
        } else list.append(gpa, .{ .name = r.name, .info = null }) catch util.oom();
        for (tp.pushUrls(r)) |u| list.append(gpa, .{ .name = r.name, .info = util.fmt("{s} (push)", .{u}) }) catch util.oom();
    }
    std.sort.block(Item, list.items, {}, struct {
        fn f(_: void, a: Item, b: Item) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.f);
    for (list.items, 0..) |it, i| {
        if (verbose > 0) {
            util.outf("{s}\t{s}\n", .{ it.name, it.info orelse "" });
        } else {
            if (i > 0 and util.eql(list.items[i - 1].name, it.name)) continue;
            util.outf("{s}\n", .{it.name});
        }
    }
    return 0;
}

fn pad(s: []const u8, w: usize) []const u8 {
    if (s.len >= w) return s;
    var b: util.Buf = .empty;
    util.bufAppend(&b, s);
    var i: usize = s.len;
    while (i < w) : (i += 1) util.bufByte(&b, ' ');
    return b.items;
}

var show_no_query = false;
const show_usage = [_][]const u8{"git remote show [<options>] <name>"};
const show_options = [_]po.Opt{
    po.boolean('n', "", &show_no_query, "do not query remotes"),
};

fn cmdShow(args: []const []const u8) u8 {
    const rest = po.parse(args, &show_options, &show_usage, .{});
    if (rest.len < 1) return showAll();
    const query: u32 = if (show_no_query) 0 else GET_REF_STATES | GET_HEAD_NAMES | GET_PUSH_REF_STATES;
    for (rest) |name| {
        var st = RefStates{};
        if (!getRemoteRefStates(name, &st, query)) continue;
        util.outf("* remote {s}\n", .{name});
        util.outf("  Fetch URL: {s}\n", .{st.remote.urls.items[0]});
        const purls = tp.pushUrls(st.remote);
        for (purls) |u| util.outf("  Push  URL: {s}\n", .{u});
        if (purls.len == 0) util.outf("  Push  URL: {s}\n", .{"(no URL)"});
        if (show_no_query) {
            util.outf("  HEAD branch: {s}\n", .{"(not queried)"});
        } else if (st.heads.items.len == 0) {
            util.outf("  HEAD branch: {s}\n", .{"(unknown)"});
        } else if (st.heads.items.len == 1) {
            util.outf("  HEAD branch: {s}\n", .{st.heads.items[0]});
        } else {
            util.outf("  HEAD branch (remote HEAD is ambiguous, may be one of the following):\n", .{});
            for (st.heads.items) |h| util.outf("    {s}\n", .{h});
        }
        // remote branches (sorted unique list)
        var lst: std.ArrayList([]const u8) = .empty;
        var width: usize = 0;
        for ([_]*std.ArrayList([]const u8){ &st.new_refs, &st.skipped, &st.tracked, &st.stale }) |l| {
            for (l.items) |s| {
                if (s.len > width) width = s.len;
                if (!hasString(lst.items, s)) lst.append(gpa, s) catch util.oom();
            }
        }
        sortStrings(&lst);
        if (lst.items.len > 0) {
            util.outf("  Remote branch{s}:{s}\n", .{ if (lst.items.len == 1) "" else "es", if (show_no_query) " (status not queried)" else "" });
        }
        for (lst.items) |s| {
            if (st.queried) {
                util.outf("    {s}", .{pad(s, width)});
                if (hasString(st.new_refs.items, s)) {
                    util.outf(" new (next fetch will store in remotes/{s})", .{st.remote.name});
                } else if (hasString(st.tracked.items, s)) {
                    util.out(" tracked");
                } else if (hasString(st.skipped.items, s)) {
                    util.out(" skipped");
                } else if (hasString(st.stale.items, s)) {
                    util.out(" stale (use 'git remote prune' to remove)");
                } else util.out(" ???");
                util.out("\n");
            } else util.outf("    {s}\n", .{s});
        }
        // pull info
        var locals: std.ArrayList(*BranchInfo) = .empty;
        width = 0;
        var any_rebase = false;
        for (branch_list.items) |b| {
            if (b.merge.items.len == 0) continue;
            const rn = b.remote_name orelse continue;
            if (!util.eql(rn, st.remote.name)) continue;
            if (b.name.len > width) width = b.name.len;
            if (b.rebase >= 1) any_rebase = true;
            locals.append(gpa, b) catch util.oom();
        }
        if (locals.items.len > 0) {
            util.outf("  Local branch{s} configured for 'git pull':\n", .{if (locals.items.len == 1) "" else "es"});
        }
        for (locals.items) |b| {
            if (b.rebase >= 1 and b.merge.items.len > 1) {
                util.err("invalid branch.{s}.merge; cannot rebase onto > 1 branch", .{b.name});
                continue;
            }
            util.outf("    {s} ", .{pad(b.name, width)});
            var w2 = width + 4;
            if (b.rebase >= 1) {
                if (b.rebase == 3) {
                    util.outf("rebases interactively onto remote {s}\n", .{b.merge.items[0]});
                } else if (b.rebase == 2) {
                    util.outf("rebases interactively (with merges) onto remote {s}\n", .{b.merge.items[0]});
                } else util.outf("rebases onto remote {s}\n", .{b.merge.items[0]});
                continue;
            } else if (any_rebase) {
                util.outf(" merges with remote {s}\n", .{b.merge.items[0]});
                w2 += 1;
            } else util.outf("merges with remote {s}\n", .{b.merge.items[0]});
            for (b.merge.items[1..]) |m| util.outf("{s}    and with remote {s}\n", .{ pad("", w2), m });
        }
        if (st.remote.mirror) util.out("  Local refs will be mirrored by 'git push'\n");
        width = 0;
        var width2: usize = 0;
        for (st.push.items) |p| {
            if (p.src.len > width) width = p.src.len;
            if (p.dest.len > width2) width2 = p.dest.len;
        }
        std.sort.block(PushInfo, st.push.items, {}, struct {
            fn f(_: void, a: PushInfo, b: PushInfo) bool {
                const o = std.mem.order(u8, a.src, b.src);
                if (o != .eq) return o == .lt;
                return std.mem.order(u8, a.dest, b.dest) == .lt;
            }
        }.f);
        if (st.push.items.len > 0) {
            util.outf("  Local ref{s} configured for 'git push'{s}:\n", .{ if (st.push.items.len == 1) "" else "s", if (show_no_query) " (status not queried)" else "" });
        }
        for (st.push.items) |p| {
            var src = p.src;
            const status: ?[]const u8 = switch (p.status) {
                .create => "create",
                .delete => blk: {
                    src = "(none)";
                    break :blk "delete";
                },
                .uptodate => "up to date",
                .fastforward => "fast-forwardable",
                .outofdate => "local out of date",
                .notqueried => null,
            };
            const verb: []const u8 = if (p.forced) "forces to" else "pushes to";
            if (status) |s| {
                util.outf("    {s} {s} {s} ({s})\n", .{ pad(src, width), verb, pad(p.dest, width2), s });
            } else util.outf("    {s} {s} {s}\n", .{ pad(src, width), verb, p.dest });
        }
    }
    return 0;
}

// ---------------- set-head ----------------

var sh_auto = false;
var sh_delete = false;
const sh_usage = [_][]const u8{"git remote set-head <name> (-a | --auto | -d | --delete | <branch>)"};
const sh_options = [_]po.Opt{
    po.boolean('a', "auto", &sh_auto, "set refs/remotes/<name>/HEAD according to remote"),
    po.boolean('d', "delete", &sh_delete, "delete refs/remotes/<name>/HEAD"),
};

fn cmdSetHead(args: []const []const u8) u8 {
    const rest = po.parse(args, &sh_options, &sh_usage, .{});
    if (rest.len == 0) po.usageWithOptions(&sh_usage, &sh_options);
    const name = rest[0];
    const b_head = util.fmt("refs/remotes/{s}/HEAD", .{name});
    const remote = tp.remoteGet(name);
    var result: u8 = 0;
    var head_name: ?[]const u8 = null;
    if (!sh_auto and !sh_delete and rest.len == 2) {
        head_name = rest[1];
    } else if (sh_auto and !sh_delete and rest.len == 1) {
        var st = RefStates{};
        _ = getRemoteRefStates(name, &st, GET_HEAD_NAMES);
        if (st.heads.items.len == 0) {
            util.err("Cannot determine remote HEAD", .{});
            result = 1;
        } else if (st.heads.items.len > 1) {
            util.err("Multiple remote HEAD branches. Please choose one explicitly with:", .{});
            for (st.heads.items) |h| util.eprint("  git remote set-head {s} {s}\n", .{ name, h });
            result = 1;
        } else head_name = st.heads.items[0];
    } else if (sh_delete and !sh_auto and rest.len == 1) {
        refs.deleteRef(b_head, null, refs.F_NO_DEREF, null) catch {
            util.err("Could not delete {s}", .{b_head});
            result = 1;
        };
    } else po.usageWithOptions(&sh_usage, &sh_options);
    const hn = head_name orelse return result;
    const b_remote_head = util.fmt("refs/remotes/{s}/{s}", .{ name, hn });
    if (!refs.exists(b_remote_head)) {
        util.err("Not a valid ref: {s}", .{b_remote_head});
        return 1;
    }
    // previous value
    var prev: []const u8 = "";
    var was_detached = false;
    switch (refs.readRawFull(b_head)) {
        .symref => |t| prev = t,
        .oid => |o| {
            prev = util.dupe(&hash.hex(o));
            was_detached = true;
        },
        else => {},
    }
    refs.writeSymref(b_head, b_remote_head, "remote set-head") catch {
        util.err("Could not set up {s}", .{b_head});
        return 1;
    };
    if (sh_auto) reportSetHeadAuto(name, hn, prev, was_detached);
    if (remote) |r| {
        if (r.follow_remote_head == .always) cfgSet(util.fmt("remote.{s}.followremotehead", .{r.name}), "warn");
    }
    return result;
}

pub fn reportSetHeadAuto(remote: []const u8, head_name: []const u8, local_head: []const u8, was_detached: bool) void {
    const pfx = util.fmt("refs/remotes/{s}/", .{remote});
    const prev = util.skipPrefix(local_head, pfx);
    if (prev != null and util.eql(prev.?, head_name)) {
        util.outf("'{s}/HEAD' is unchanged and points to '{s}'\n", .{ remote, head_name });
    } else if (prev) |p| {
        util.outf("'{s}/HEAD' has changed from '{s}' and now points to '{s}'\n", .{ remote, p, head_name });
    } else if (local_head.len == 0) {
        util.outf("'{s}/HEAD' is now created and points to '{s}'\n", .{ remote, head_name });
    } else if (was_detached) {
        util.outf("'{s}/HEAD' was detached at '{s}' and now points to '{s}'\n", .{ remote, local_head, head_name });
    } else {
        util.outf("'{s}/HEAD' used to point to '{s}' (which is not a remote branch), but now points to '{s}'\n", .{ remote, local_head, head_name });
    }
}

// ---------------- prune ----------------

var prune_dry = false;
const prune_usage = [_][]const u8{"git remote prune [<options>] <name>"};
const prune_options = [_]po.Opt{
    po.boolean('n', "dry-run", &prune_dry, "dry run"),
};

fn pruneRemote(name: []const u8, dry: bool) u8 {
    var st = RefStates{};
    if (!getRemoteRefStates(name, &st, GET_REF_STATES)) return 1;
    if (st.stale.items.len == 0) return 0;
    util.outf("Pruning {s}\n", .{name});
    util.outf("URL: {s}\n", .{st.remote.urls.items[0]});
    var result: u8 = 0;
    var to_prune: std.ArrayList([]const u8) = .empty;
    to_prune.appendSlice(gpa, st.stale_full.items) catch util.oom();
    sortStrings(&to_prune);
    if (!dry) {
        if (!refs.deleteRefs(to_prune.items, 0, "remote: prune")) result = 1;
    }
    for (st.stale_full.items) |full| {
        const short = util.skipPrefix(full, "refs/remotes/") orelse full;
        if (dry) {
            util.outf(" * [would prune] {s}\n", .{short});
        } else util.outf(" * [pruned] {s}\n", .{short});
    }
    warnDanglingSymrefs(" ", dry, to_prune.items);
    return result;
}

pub fn warnDanglingSymrefs(indent: []const u8, dry: bool, deleted: []const []const u8) void {
    for (refs.iterate("", .{ .include_broken = true, .check_objects = false })) |lr| {
        if (lr.flags & refs.REF_ISSYMREF == 0) continue;
        const target = refs.readSymbolic(lr.name) orelse continue;
        if (!hasString(deleted, target)) continue;
        if (dry) {
            util.outf("{s}{s} will become dangling after {s} is deleted\n", .{ indent, lr.name, target });
        } else util.outf("{s}{s} has become dangling after {s} was deleted\n", .{ indent, lr.name, target });
    }
}

fn cmdPrune(args: []const []const u8) u8 {
    const rest = po.parse(args, &prune_options, &prune_usage, .{});
    if (rest.len < 1) po.usageWithOptions(&prune_usage, &prune_options);
    var result: u8 = 0;
    for (rest) |r| result |= pruneRemote(r, prune_dry);
    return result;
}

// ---------------- update ----------------

var upd_prune: i32 = -1;
const upd_usage = [_][]const u8{"git remote update [<options>] [<group> | <remote>]..."};
const upd_options = [_]po.Opt{
    .{ .short = 'p', .long = "prune", .kind = .set_int, .i = &upd_prune, .val = 1, .help = "prune remotes after fetching" },
};

fn cmdUpdate(args: []const []const u8) u8 {
    // --no-prune handling: set_int negation sets 0
    const rest = po.parse(args, &upd_options, &upd_usage, .{});
    var a: std.ArrayList([]const u8) = .empty;
    a.append(gpa, "fetch") catch util.oom();
    if (upd_prune != -1) a.append(gpa, if (upd_prune != 0) "--prune" else "--no-prune") catch util.oom();
    if (verbose > 0) a.append(gpa, "-v") catch util.oom();
    a.append(gpa, "--multiple") catch util.oom();
    if (rest.len < 1) a.append(gpa, "default") catch util.oom();
    a.appendSlice(gpa, rest) catch util.oom();
    if (util.eql(a.items[a.items.len - 1], "default")) {
        if (repo_mod.cfg.getEntry("remotes.default") == null) {
            a.items[a.items.len - 1] = "--all";
        }
    }
    const ch = proc.spawnGit(a.items, .{});
    return proc.wait(ch.pid);
}

// ---------------- set-branches ----------------

var sb_add = false;
const sb_usage = [_][]const u8{ "git remote set-branches <name> <branch>...", "git remote set-branches --add <name> <branch>..." };
const sb_options = [_]po.Opt{
    po.boolean(0, "add", &sb_add, "add branch"),
};

fn cmdSetBranches(args: []const []const u8) u8 {
    const rest = po.parse(args, &sb_options, &sb_usage, .{});
    if (rest.len == 0) {
        util.err("no remote specified", .{});
        po.usageWithOptions(&sb_usage, &sb_options);
    }
    const name = rest[0];
    const key = util.fmt("remote.{s}.fetch", .{name});
    const remote = tp.remoteGet(name);
    if (remote == null or !tp.remoteIsConfigured(remote.?, true)) {
        util.err("No such remote '{s}'", .{name});
        os.exit(2);
    }
    if (!sb_add) {
        const r = config.setMultivarInFile(configPath(), key, null, .any, null, .{ .multi_replace = true });
        if (r != 0 and r != config.CONFIG_NOTHING_SET) return 1;
    }
    for (rest[1..]) |b| addBranch(key, b, remote.?.name, remote.?.mirror);
    return 0;
}

// ---------------- get-url / set-url ----------------

var gu_push = false;
var gu_all = false;
const gu_usage = [_][]const u8{"git remote get-url [--push] [--all] <name>"};
const gu_options = [_]po.Opt{
    po.boolean(0, "push", &gu_push, "query push URLs rather than fetch URLs"),
    po.boolean(0, "all", &gu_all, "return all URLs"),
};

fn cmdGetUrl(args: []const []const u8) u8 {
    const rest = po.parse(args, &gu_options, &gu_usage, .{});
    if (rest.len != 1) po.usageWithOptions(&gu_usage, &gu_options);
    const remote = tp.remoteGet(rest[0]);
    if (remote == null or !tp.remoteIsConfigured(remote.?, true)) {
        util.err("No such remote '{s}'", .{rest[0]});
        os.exit(2);
    }
    const urls = if (gu_push) tp.pushUrls(remote.?) else remote.?.urls.items;
    if (gu_all) {
        for (urls) |u| util.outf("{s}\n", .{u});
    } else util.outf("{s}\n", .{urls[0]});
    return 0;
}

var su_push = false;
var su_add = false;
var su_delete = false;
const su_usage = [_][]const u8{
    "git remote set-url [--push] <name> <newurl> [<oldurl>]",
    "git remote set-url --add <name> <newurl>",
    "git remote set-url --delete <name> <url>",
};
const su_options = [_]po.Opt{
    po.boolean(0, "push", &su_push, "manipulate push URLs"),
    po.boolean(0, "add", &su_add, "add URL"),
    po.boolean(0, "delete", &su_delete, "delete URLs"),
};

fn cmdSetUrl(args: []const []const u8) u8 {
    const rest = po.parse(args, &su_options, &su_usage, .{});
    if (su_add and su_delete) util.die("--add --delete doesn't make sense", .{});
    if (rest.len < 2 or rest.len > 3 or ((su_add or su_delete) and rest.len != 2))
        po.usageWithOptions(&su_usage, &su_options);
    const name = rest[0];
    const newurl = rest[1];
    var oldurl: ?[]const u8 = if (rest.len > 2) rest[2] else null;
    if (su_delete) oldurl = newurl;
    const remote = tp.remoteGet(name);
    if (remote == null or !tp.remoteIsConfigured(remote.?, true)) {
        util.err("No such remote '{s}'", .{name});
        os.exit(2);
    }
    const key = if (su_push) util.fmt("remote.{s}.pushurl", .{name}) else util.fmt("remote.{s}.url", .{name});
    const urlset = if (su_push) remote.?.pushurls.items else remote.?.urls.items;
    if ((oldurl == null and !su_delete) or su_add) {
        if (su_add) cfgAdd(key, newurl) else cfgSet(key, newurl);
        return 0;
    }
    const regex = @import("../regex.zig");
    var matches: usize = 0;
    var neg: usize = 0;
    for (urlset) |u| {
        if (regex.matchSimple(oldurl.?, u, .{ .extended = true })) matches += 1 else neg += 1;
    }
    if (!su_delete and matches == 0) util.die("No such URL found: {s}", .{oldurl.?});
    if (su_delete and neg == 0 and !su_push) util.die("Will not delete all non-push URLs", .{});
    if (!su_delete) {
        _ = config.setMultivarInFile(configPath(), key, newurl, .{ .pattern = oldurl.? }, null, .{});
    } else {
        _ = config.setMultivarInFile(configPath(), key, null, .{ .pattern = oldurl.? }, null, .{ .multi_replace = true });
    }
    return 0;
}

// ---------------- main ----------------

const main_options = [_]po.Opt{
    .{ .short = 'v', .long = "verbose", .kind = .counter, .i = &verbose, .help = "be verbose; must be placed before a subcommand" },
};

pub fn cmdRemote(args: []const []const u8) u8 {
    const rest = po.parse(args[1..], &main_options, &usage, .{ .stop_at_non_option = true });
    if (rest.len == 0) return showAll();
    const sub = rest[0];
    const sargs = rest[1..];
    const Sub = struct { n: []const u8, f: *const fn ([]const []const u8) u8 };
    const subs = [_]Sub{
        .{ .n = "add", .f = cmdAdd },
        .{ .n = "rename", .f = cmdRename },
        .{ .n = "rm", .f = cmdRm },
        .{ .n = "remove", .f = cmdRm },
        .{ .n = "set-head", .f = cmdSetHead },
        .{ .n = "set-branches", .f = cmdSetBranches },
        .{ .n = "get-url", .f = cmdGetUrl },
        .{ .n = "set-url", .f = cmdSetUrl },
        .{ .n = "show", .f = cmdShow },
        .{ .n = "prune", .f = cmdPrune },
        .{ .n = "update", .f = cmdUpdate },
    };
    for (subs) |s| {
        if (util.eql(s.n, sub)) return if (s.f(sargs) != 0) 1 else 0;
    }
    util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&usage, &main_options);
}
