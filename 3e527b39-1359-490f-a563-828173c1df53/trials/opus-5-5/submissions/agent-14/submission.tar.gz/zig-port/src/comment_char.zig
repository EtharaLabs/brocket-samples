//! core.commentChar / core.commentString handling (environment.c,
//! builtin/commit.c adjust_comment_line_char, config.c deprecation warning
//! for "auto").

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const advice = @import("advice.zig");
const gpa = util.gpa;

/// Set by adjust() when core.commentChar=auto picked a character.
pub var override: ?[]const u8 = null;

fn isCommentKey(k: []const u8) bool {
    return util.eql(k, "core.commentchar") or util.eql(k, "core.commentstring");
}

/// comment_line_str: the last core.commentChar/core.commentString wins;
/// "auto" (case-insensitive) means "#" until adjust() runs.
pub fn str() []const u8 {
    if (override) |o| return o;
    var res: []const u8 = "#";
    for (repo_mod.cfg.entries.items) |e| {
        if (!isCommentKey(e.key)) continue;
        const v = e.value orelse continue;
        if (std.ascii.eqlIgnoreCase(v, "auto")) {
            res = "#";
        } else if (v.len > 0 and std.mem.indexOfScalar(u8, v, '\n') == null) {
            res = v;
        }
    }
    return res;
}

/// auto_comment_line_char
pub fn isAuto() bool {
    var auto = false;
    for (repo_mod.cfg.entries.items) |e| {
        if (!isCommentKey(e.key)) continue;
        const v = e.value orelse continue;
        if (std.ascii.eqlIgnoreCase(v, "auto")) {
            auto = true;
        } else if (v.len > 0 and std.mem.indexOfScalar(u8, v, '\n') == null) {
            auto = false;
        }
    }
    return auto;
}

/// adjust_comment_line_char (builtin/commit.c)
pub fn adjust(sb: []const u8, ignored_bytes: usize) void {
    var candidates = "#;@!$%^&|:".*;
    const cutoff = sb.len - ignored_bytes;
    if (std.mem.indexOfScalar(u8, sb, candidates[0]) == null) {
        override = "#";
        return;
    }
    if (sb.len > 0) {
        if (std.mem.indexOfScalar(u8, &candidates, sb[0])) |i| candidates[i] = ' ';
    }
    var p: usize = 0;
    while (p + 1 < cutoff) : (p += 1) {
        if ((sb[p] == '\n' or sb[p] == '\r') and sb[p + 1] != 0) {
            if (std.mem.indexOfScalar(u8, &candidates, sb[p + 1])) |i| candidates[i] = ' ';
        }
    }
    for (candidates) |ch| {
        if (ch != ' ') {
            override = util.dupe(&.{ch});
            return;
        }
    }
    util.die("unable to select a comment character that is not used\nin the current commit message", .{});
}

const Item = struct { key_id: u1, path: []const u8, scope: config.Scope, twice: bool = false };

const key_names = [_][]const u8{ "core.commentChar", "core.commentString" };

fn scopeArg(b: *util.Buf, it: *const Item) void {
    const r = repo_mod.repo_;
    if (it.scope == .system and !os.access(it.path, 2)) {
        util.bufAppend(b, "--global ");
    } else if (util.eql(it.path, config.systemConfigPath())) {
        util.bufAppend(b, "--system ");
    } else if (config.globalConfigFile() != null and util.eql(it.path, config.globalConfigFile().?)) {
        util.bufAppend(b, "--global ");
    } else if (r != null and util.eql(it.path, util.concat(&.{ r.?.git_dir, "/config" }))) {
        // --local is the default
    } else if (r != null and util.eql(it.path, util.concat(&.{ r.?.common_dir, "/config.worktree" }))) {
        util.bufAppend(b, "--worktree ");
    } else {
        var path = it.path;
        util.bufAppend(b, "--file ");
        if (os.getenv("HOME")) |home| {
            if (util.startsWith(path, home)) {
                path = path[home.len..];
                if (util.startsWith(path, "/")) path = path[1..];
                util.bufAppend(b, "~/");
            }
        }
        sqQuotePretty(b, path);
        util.bufByte(b, ' ');
    }
}

fn sqQuotePretty(b: *util.Buf, s: []const u8) void {
    if (s.len == 0) return util.bufAppend(b, "''");
    for (s) |ch| {
        if (!std.ascii.isAlphanumeric(ch) and std.mem.indexOfScalar(u8, "+,-./:=@_^", ch) == null) {
            return util.sqQuote(b, s);
        }
    }
    util.bufAppend(b, s);
}

/// check_auto_comment_char_config (config.c): warn once per process tree
/// when the effective comment char setting is "auto".
pub fn warnIfAuto() void {
    var last_key: u1 = 0;
    var auto_set = false;
    var auto_set_in_file = false;
    var items: std.ArrayList(Item) = .empty;
    for (repo_mod.cfg.entries.items) |e| {
        const id: u1 = if (util.eql(e.key, "core.commentchar")) 0 else if (util.eql(e.key, "core.commentstring")) 1 else continue;
        last_key = id;
        auto_set = e.value != null and util.eql(e.value.?, "auto");
        if (e.origin_type != .file) continue;
        var seen = false;
        for (items.items) |*it| {
            if (it.key_id == id and util.eql(it.path, e.origin)) {
                it.twice = true;
                seen = true;
            }
        }
        if (!seen) items.append(gpa, .{ .key_id = id, .path = e.origin, .scope = e.scope }) catch util.oom();
        auto_set_in_file = auto_set;
    }
    if (!auto_set) return;
    const env = "GIT_AUTO_COMMENT_CHAR_CONFIG_WARNING_GIVEN";
    if (os.getenv(env)) |v| {
        if (config.configBool(env, v)) return;
    }
    os.setEnv(env, "true");
    util.warn("Support for '{s}=auto' is deprecated and will be removed in Git 3.0", .{key_names[last_key]});
    if (!auto_set_in_file or items.items.len == 0) return;

    var can_unset = true;
    for (items.items) |*it| {
        if (it.scope == .system and !os.access(it.path, 2)) can_unset = false;
    }
    if (can_unset) {
        var b: util.Buf = .empty;
        for (items.items) |*it| {
            util.bufAppend(&b, "    git config unset ");
            scopeArg(&b, it);
            if (it.twice) util.bufAppend(&b, "--all ");
            util.bufPrint(&b, "{s}\n", .{key_names[it.key_id]});
        }
        advice.advise(util.fmt("\nTo use the default comment string (#) please run\n\n{s}", .{b.items}));
    }
    const last = &items.items[items.items.len - 1];
    var b: util.Buf = .empty;
    util.bufAppend(&b, "    git config set ");
    scopeArg(&b, last);
    util.bufPrint(&b, "{s} <comment string>\n", .{key_names[last.key_id]});
    advice.advise(util.fmt("\nTo set a custom comment string please run\n\n{s}\nwhere '<comment string>' is the string you wish to use.\n", .{b.items}));
}
