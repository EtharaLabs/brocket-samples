//! Reuse recorded resolution of conflicted merges (port of rerere.c).
//!
//! API for mergy commands (merge, cherry-pick, revert, am, rebase, commit):
//!   rerere.rerere(flags) i32   -- repo_rerere(); call after writing the index with conflicts
//!                                 (and before committing). flags: AUTOUPDATE / NOAUTOUPDATE
//!                                 (from --[no-]rerere-autoupdate) or 0.
//!   rerere.clear()             -- rerere_clear() (am/rebase --skip/--abort, merge --abort ...)
//! The index is re-read from disk (index.discard()) so make sure it was written first.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const lockfile = @import("lockfile.zig");
const hash = @import("hash.zig");
const attr = @import("attr.zig");
const merge_ort = @import("merge_ort.zig");
const pathspec_mod = @import("pathspec.zig");
const date = @import("date.zig");
const xdiff = @import("xdiff.zig");
const gpa = util.gpa;

pub const AUTOUPDATE: u32 = 1;
pub const NOAUTOUPDATE: u32 = 2;
pub const READONLY: u32 = 4;

const RR_HAS_POSTIMAGE: u8 = 1;
const RR_HAS_PREIMAGE: u8 = 2;

const RrDir = struct {
    name: []const u8,
    status: std.ArrayList(u8) = .empty,
};

pub const Id = struct {
    dir: *RrDir,
    variant: i32 = -1,
};

pub const Item = struct {
    path: []const u8,
    id: ?*Id = null,
    resolved: bool = false,
};

/// Sorted list of paths (string_list with util).
pub const MergeRr = struct {
    items: std.ArrayList(Item) = .empty,

    fn find(self: *MergeRr, path: []const u8) struct { found: bool, pos: usize } {
        var lo: usize = 0;
        var hi: usize = self.items.items.len;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            switch (std.mem.order(u8, self.items.items[mid].path, path)) {
                .eq => return .{ .found = true, .pos = mid },
                .lt => lo = mid + 1,
                .gt => hi = mid,
            }
        }
        return .{ .found = false, .pos = lo };
    }

    pub fn insert(self: *MergeRr, path: []const u8) *Item {
        const f = self.find(path);
        if (!f.found) self.items.insert(gpa, f.pos, .{ .path = util.dupe(path) }) catch util.oom();
        return &self.items.items[f.pos];
    }

    pub fn lookup(self: *MergeRr, path: []const u8) ?*Item {
        const f = self.find(path);
        if (!f.found) return null;
        return &self.items.items[f.pos];
    }

    pub fn remove(self: *MergeRr, path: []const u8) void {
        const f = self.find(path);
        if (f.found) _ = self.items.orderedRemove(f.pos);
    }
};

var rerere_enabled: i32 = -1;
var rerere_autoupdate: bool = false;
var write_lock: ?*lockfile.Lock = null;
var rerere_dirs: std.StringHashMapUnmanaged(*RrDir) = .empty;

fn freeDirs() void {
    rerere_dirs = .empty;
}

fn rrCachePath() []const u8 {
    return repo_mod.repo().commonPath("rr-cache");
}

fn mergeRrPath() []const u8 {
    return repo_mod.repo().gitPath("MERGE_RR");
}

fn fitVariant(d: *RrDir, variant0: i32) void {
    const variant: usize = @intCast(variant0 + 1);
    while (d.status.items.len < variant) d.status.append(gpa, 0) catch util.oom();
}

fn assignVariant(id: *Id) void {
    const d = id.dir;
    var variant = id.variant;
    if (variant < 0) {
        variant = 0;
        while (variant < d.status.items.len) : (variant += 1) {
            if (d.status.items[@intCast(variant)] == 0) break;
        }
    }
    fitVariant(d, variant);
    id.variant = variant;
}

/// rerere_path()
pub fn rrPath(id: *const Id, file: ?[]const u8) []const u8 {
    const base = util.concat(&.{ rrCachePath(), "/", id.dir.name });
    const f = file orelse return base;
    if (id.variant <= 0) return util.concat(&.{ base, "/", f });
    return util.fmt("{s}/{s}.{d}", .{ base, f, id.variant });
}

fn isRrFile(name: []const u8, filename: []const u8) ?i32 {
    if (util.eql(name, filename)) return 0;
    const suffix = util.skipPrefix(name, filename) orelse return null;
    if (suffix.len == 0 or suffix[0] != '.') return null;
    const num = suffix[1..];
    // strtol semantics: optional whitespace/sign, digits, must consume all
    if (num.len == 0) return 0;
    return std.fmt.parseInt(i32, num, 10) catch null;
}

fn scanDir(d: *RrDir) void {
    const entries = os.listDir(util.concat(&.{ rrCachePath(), "/", d.name })) orelse return;
    for (entries) |e| {
        if (isRrFile(e.name, "postimage")) |v| {
            if (v < 0) continue;
            fitVariant(d, v);
            d.status.items[@intCast(v)] |= RR_HAS_POSTIMAGE;
        } else if (isRrFile(e.name, "preimage")) |v| {
            if (v < 0) continue;
            fitVariant(d, v);
            d.status.items[@intCast(v)] |= RR_HAS_PREIMAGE;
        }
    }
}

fn findDir(hex: []const u8) *RrDir {
    if (rerere_dirs.get(hex)) |d| return d;
    const d = gpa.create(RrDir) catch util.oom();
    d.* = .{ .name = util.dupe(hex) };
    rerere_dirs.put(gpa, d.name, d) catch util.oom();
    scanDir(d);
    return d;
}

fn hasResolution(id: *const Id) bool {
    if (id.variant < 0) return false;
    const both = RR_HAS_POSTIMAGE | RR_HAS_PREIMAGE;
    return (id.dir.status.items[@intCast(id.variant)] & both) == both;
}

fn newIdHex(hex: []const u8) *Id {
    const id = gpa.create(Id) catch util.oom();
    id.* = .{ .dir = findDir(hex), .variant = -1 };
    return id;
}

fn readRr(rr: *MergeRr) void {
    const data = os.readFile(mergeRrPath()) orelse {
        if (os.errno() != 2) util.warn("unable to access '{s}': {s}", .{ mergeRrPath(), os.lastErr() });
        return;
    };
    var it = std.mem.splitScalar(u8, data, 0);
    while (it.next()) |rec| {
        if (rec.len == 0 and it.index == null) break;
        if (rec.len < hash.HEXSZ + 2 or !util.isHex(rec[0..hash.HEXSZ]))
            util.die("corrupt MERGE_RR", .{});
        var variant: i32 = 0;
        var rest = rec[hash.HEXSZ..];
        if (rest[0] == '.') {
            var j: usize = 1;
            while (j < rest.len and std.ascii.isDigit(rest[j])) j += 1;
            variant = std.fmt.parseInt(i32, rest[1..j], 10) catch 0;
            rest = rest[j..];
        }
        if (rest.len == 0 or rest[0] != '\t') util.die("corrupt MERGE_RR", .{});
        const path = rest[1..];
        const id = newIdHex(rec[0..hash.HEXSZ]);
        id.variant = variant;
        fitVariant(id.dir, variant);
        rr.insert(path).id = id;
    }
}

fn writeRr(rr: *MergeRr) i32 {
    const l = write_lock.?;
    var b: util.Buf = .empty;
    for (rr.items.items) |item| {
        const id = item.id orelse continue;
        if (id.variant > 0) {
            util.bufPrint(&b, "{s}.{d}\t{s}\x00", .{ id.dir.name, id.variant, item.path });
        } else {
            util.bufPrint(&b, "{s}\t{s}\x00", .{ id.dir.name, item.path });
        }
    }
    l.write(b.items);
    if (!l.commit()) util.die("unable to write rerere record", .{});
    write_lock = null;
    return 0;
}

// ---------------------------------------------------------------------------
// conflict normalization

const Reader = struct {
    data: []const u8,
    pos: usize = 0,

    fn next(self: *Reader) ?[]const u8 {
        if (self.pos >= self.data.len) return null;
        const start = self.pos;
        const end = if (std.mem.indexOfScalarPos(u8, self.data, start, '\n')) |i| i + 1 else self.data.len;
        self.pos = end;
        return self.data[start..end];
    }
};

fn conflictMarker(line: []const u8, marker_size: usize) u8 {
    if (line.len < marker_size + 1) return 0;
    const first = line[0];
    switch (first) {
        '=', '>', '<', '|' => {},
        else => return 0,
    }
    for (1..marker_size) |i| {
        if (line[i] != first) return 0;
    }
    if ((first == '<' or first == '>') and line[marker_size] != ' ') return 0;
    // git's isspace(): only SP, HT, LF, CR
    switch (line[marker_size]) {
        ' ', '\t', '\n', '\r' => {},
        else => return 0,
    }
    return first;
}

fn putConflict(b: *util.Buf, ch: u8, size: usize) void {
    for (0..size) |_| util.bufByte(b, ch);
    util.bufByte(b, '\n');
}

fn handleConflict(out: *util.Buf, rd: *Reader, marker_size: usize, ctx: ?*hash.Hasher) i32 {
    const Hunk = enum { side1, side2, original };
    var hunk: Hunk = .side1;
    var one: util.Buf = .empty;
    var two: util.Buf = .empty;
    var has_conflicts: i32 = -1;
    while (rd.next()) |line| {
        const marker = conflictMarker(line, marker_size);
        if (marker == '<') {
            var conflict: util.Buf = .empty;
            if (handleConflict(&conflict, rd, marker_size, null) < 0) break;
            if (hunk == .side1) util.bufAppend(&one, conflict.items) else util.bufAppend(&two, conflict.items);
        } else if (marker == '|') {
            if (hunk != .side1) break;
            hunk = .original;
        } else if (marker == '=') {
            if (hunk != .side1 and hunk != .original) break;
            hunk = .side2;
        } else if (marker == '>') {
            if (hunk != .side2) break;
            if (std.mem.order(u8, one.items, two.items) == .gt) {
                const t = one;
                one = two;
                two = t;
            }
            has_conflicts = 1;
            putConflict(out, '<', marker_size);
            util.bufAppend(out, one.items);
            putConflict(out, '=', marker_size);
            util.bufAppend(out, two.items);
            putConflict(out, '>', marker_size);
            if (ctx) |c| {
                c.update(one.items);
                c.update("\x00");
                c.update(two.items);
                c.update("\x00");
            }
            break;
        } else if (hunk == .side1) {
            util.bufAppend(&one, line);
        } else if (hunk == .side2) {
            util.bufAppend(&two, line);
        }
    }
    return has_conflicts;
}

/// handle_path(): normalize; returns 1 if conflicts, 0 if none, -1 on error.
fn handlePath(want_hash: ?*hash.Oid, data: []const u8, output: ?*util.Buf, marker_size: usize) i32 {
    var h = hash.Hasher.init(.{});
    var rd = Reader{ .data = data };
    var has_conflicts: i32 = 0;
    var out: util.Buf = .empty;
    while (rd.next()) |line| {
        if (conflictMarker(line, marker_size) == '<') {
            has_conflicts = handleConflict(&out, &rd, marker_size, if (want_hash != null) &h else null);
            if (has_conflicts < 0) break;
            if (output) |o| util.bufAppend(o, out.items);
            out.clearRetainingCapacity();
        } else if (output) |o| util.bufAppend(o, line);
    }
    if (want_hash) |p| h.final(p);
    return has_conflicts;
}

fn markerSize(path: []const u8) usize {
    switch (attr.get(path, "conflict-marker-size")) {
        .value => |v| {
            const n = std.fmt.parseInt(i64, v, 10) catch {
                util.warn("invalid marker-size '{s}', expecting an integer", .{v});
                return xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
            };
            if (n <= 0) return xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
            return @intCast(n);
        },
        .set => {
            util.warn("invalid marker-size '{s}', expecting an integer", .{"true"});
            return xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
        },
        else => return xdiff.DEFAULT_CONFLICT_MARKER_SIZE,
    }
}

fn writeOut(output: []const u8, data: []const u8) bool {
    os.writeFile(output, data, 0o666) catch {
        util.err("could not write '{s}': {s}", .{ output, os.lastErr() });
        return false;
    };
    return true;
}

/// handle_file()
fn handleFile(path: []const u8, want_hash: ?*hash.Oid, output: ?[]const u8) i32 {
    const ms = markerSize(path);
    const data = os.readFile(path) orelse {
        util.err("could not open '{s}': {s}", .{ path, os.lastErr() });
        return -1;
    };
    var out: util.Buf = .empty;
    const has = handlePath(want_hash, data, if (output != null) &out else null, ms);
    if (has < 0) {
        if (output) |o| {
            // git created (and now removes) the output file
            if (!os.unlink(o) and os.errno() != 2) util.warn("unable to unlink '{s}': {s}", .{ o, os.lastErr() });
        }
        util.err("could not parse conflict hunks in '{s}'", .{path});
        return -1;
    }
    if (output) |o| {
        if (!writeOut(o, out.items)) return -1;
    }
    return has;
}

// ---------------------------------------------------------------------------

const ConflictType = enum { resolved, punted, three_staged };

fn checkOneConflict(idx: *index_mod.Index, start: usize, typ: *ConflictType) usize {
    const ents = idx.entries.items;
    const e = &ents[start];
    var i = start;
    if (e.stage() == 0) {
        typ.* = .resolved;
        return i + 1;
    }
    typ.* = .punted;
    while (i < ents.len and ents[i].stage() == 1) i += 1;
    if (i + 1 < ents.len) {
        const e2 = &ents[i];
        const e3 = &ents[i + 1];
        if (e2.stage() == 2 and e3.stage() == 3 and util.eql(e.path, e3.path) and
            e2.mode & 0o170000 == 0o100000 and e3.mode & 0o170000 == 0o100000)
            typ.* = .three_staged;
    }
    while (i < ents.len and util.eql(e.path, ents[i].path)) i += 1;
    return i;
}

fn readIndex() *index_mod.Index {
    index_mod.discard();
    return index_mod.get();
}

fn findConflict(idx: *index_mod.Index, out: *std.ArrayList([]const u8)) void {
    var i: usize = 0;
    while (i < idx.entries.items.len) {
        var t: ConflictType = .resolved;
        const name = idx.entries.items[i].path;
        i = checkOneConflict(idx, i, &t);
        if (t == .three_staged) {
            if (out.items.len == 0 or !util.eql(out.items[out.items.len - 1], name))
                out.append(gpa, name) catch util.oom();
        }
    }
}

fn contains(list: []const []const u8, s: []const u8) bool {
    for (list) |x| if (util.eql(x, s)) return true;
    return false;
}

/// try_merge(): returns true on clean merge, result in *result.
fn tryMerge(id: *const Id, path: []const u8, cur: []const u8, result: *[]const u8) bool {
    const base = os.readFile(rrPath(id, "preimage")) orelse return false;
    const other = os.readFile(rrPath(id, "postimage")) orelse return false;
    const opts = merge_ort.LlOpts{};
    const r = merge_ort.llMerge(path, base, "", cur, "", other, "", &opts);
    if (r.status != .ok) return false;
    result.* = r.result orelse "";
    return true;
}

extern "c" fn utimes(path: [*:0]const u8, times: ?*const anyopaque) c_int;

/// merge(): replay; true on success.
fn mergeOne(id: *const Id, path: []const u8) bool {
    const thisimage = rrPath(id, "thisimage");
    if (handleFile(path, null, thisimage) < 0) return false;
    const cur = os.readFile(thisimage) orelse return false;
    var result: []const u8 = "";
    if (!tryMerge(id, path, cur, &result)) return false;
    const post = rrPath(id, "postimage");
    if (utimes(os.z(post), null) < 0) util.warn("failed utime() on '{s}': {s}", .{ post, os.lastErr() });
    os.writeFile(path, result, 0o666) catch {
        util.err("could not open '{s}': {s}", .{ path, os.lastErr() });
        return false;
    };
    return true;
}

fn unlinkOrWarn(p: []const u8) void {
    if (!os.unlink(p) and os.errno() != 2) util.warn("unable to unlink '{s}': {s}", .{ p, os.lastErr() });
}

fn removeVariant(id: *Id) void {
    unlinkOrWarn(rrPath(id, "postimage"));
    unlinkOrWarn(rrPath(id, "preimage"));
    id.dir.status.items[@intCast(id.variant)] = 0;
}

fn copyFile(dst: []const u8, src: []const u8) void {
    const data = os.readFile(src) orelse {
        util.err("could not open '{s}': {s}", .{ src, os.lastErr() });
        return;
    };
    _ = writeOut(dst, data);
}

fn doOnePath(item: *Item, update: *std.ArrayList([]const u8)) void {
    const path = item.path;
    const id = item.id.?;
    const d = id.dir;

    if (id.variant >= 0) {
        if (handleFile(path, null, null) == 0) {
            copyFile(rrPath(id, "postimage"), path);
            d.status.items[@intCast(id.variant)] |= RR_HAS_POSTIMAGE;
            util.eprint("Recorded resolution for '{s}'.\n", .{path});
            item.id = null;
            return;
        }
    }

    var variant: i32 = 0;
    while (variant < d.status.items.len) : (variant += 1) {
        const both = RR_HAS_PREIMAGE | RR_HAS_POSTIMAGE;
        if (d.status.items[@intCast(variant)] & both != both) continue;
        var vid = id.*;
        vid.variant = variant;
        if (!mergeOne(&vid, path)) continue;
        if (0 <= id.variant and id.variant != variant) removeVariant(id);
        if (rerere_autoupdate) {
            update.append(gpa, path) catch util.oom();
        } else {
            util.eprint("Resolved '{s}' using previous resolution.\n", .{path});
        }
        item.id = null;
        return;
    }

    assignVariant(id);
    _ = handleFile(path, null, rrPath(id, "preimage"));
    const vi: usize = @intCast(id.variant);
    if (d.status.items[vi] & RR_HAS_POSTIMAGE != 0) {
        const p = rrPath(id, "postimage");
        if (!os.unlink(p)) util.dieErrno("cannot unlink stray '{s}'", .{p});
        d.status.items[vi] &= ~RR_HAS_POSTIMAGE;
    }
    d.status.items[vi] |= RR_HAS_PREIMAGE;
    util.eprint("Recorded preimage for '{s}'\n", .{path});
}

fn updatePaths(update: []const []const u8) void {
    const idx = index_mod.lockAndRead();
    for (update) |p| {
        if (index_mod.addFileToIndex(idx, p, 0)) os.exit(128);
        util.eprint("Staged '{s}' using previous resolution.\n", .{p});
    }
    if (idx.changed) {
        idx.write();
    } else idx.rollback();
}

fn safeCreateDir(p: []const u8) void {
    if (os.isDir(p)) return;
    if (!os.mkdir(p, 0o777) and !os.isDir(p)) {
        util.err("unable to create directory '{s}': {s}", .{ p, os.lastErr() });
    }
}

fn doPlainRerere(rr: *MergeRr) i32 {
    var conflict: std.ArrayList([]const u8) = .empty;
    var update: std.ArrayList([]const u8) = .empty;
    const idx = readIndex();
    findConflict(idx, &conflict);

    for (conflict.items) |path| {
        var h: hash.Oid = undefined;
        const ret = handleFile(path, &h, null);
        if (ret != 0) {
            if (rr.lookup(path)) |it| {
                if (it.id) |id| {
                    if (id.variant >= 0) removeVariant(id);
                }
                rr.remove(path);
            }
        }
        if (ret < 1) continue;
        const hx = hash.hex(h);
        const id = newIdHex(&hx);
        rr.insert(path).id = id;
        safeCreateDir(rrPath(id, null));
    }

    for (rr.items.items) |*item| {
        if (item.id == null) continue;
        doOnePath(item, &update);
    }
    if (update.items.len > 0) updatePaths(update.items);
    return writeRr(rr);
}

fn loadConfig() void {
    if (repo_mod.cfg.getBool("rerere.enabled")) |b| rerere_enabled = if (b) 1 else 0;
    if (repo_mod.cfg.getBool("rerere.autoupdate")) |b| rerere_autoupdate = b;
}

fn isEnabled() bool {
    if (rerere_enabled == 0) return false;
    const p = rrCachePath();
    const exists = os.isDir(p);
    if (rerere_enabled < 0) return exists;
    if (!exists) {
        if (!os.mkdir(p, 0o777) and !os.isDir(p)) util.die("could not create directory '{s}'", .{p});
    }
    return true;
}

/// setup_rerere(): false if rerere is disabled.
pub fn setup(rr: *MergeRr, flags: u32) bool {
    loadConfig();
    if (!isEnabled()) return false;
    if (flags & (AUTOUPDATE | NOAUTOUPDATE) != 0) rerere_autoupdate = flags & AUTOUPDATE != 0;
    if (flags & READONLY == 0) write_lock = lockfile.lockOrDie(mergeRrPath());
    readRr(rr);
    return true;
}

/// repo_rerere(): the main entry point used by mergy commands.
pub fn rerere(flags: u32) i32 {
    if (repo_mod.repo_ == null) return 0;
    const r = repo_mod.repo();
    if (r.work_tree == null) return 0;
    var rr: MergeRr = .{};
    if (!setup(&rr, flags)) return 0;
    const status = doPlainRerere(&rr);
    freeDirs();
    return status;
}

// ---------------------------------------------------------------------------
// forget

fn handleCache(idx: *index_mod.Index, path: []const u8, h: ?*hash.Oid, output: ?[]const u8) i32 {
    const ms = markerSize(path);
    if (idx.findPos(path) != null) return -1;
    var bufs: [3]?[]const u8 = .{ null, null, null };
    var i = idx.firstPos(path);
    const odb = repo_mod.repo().odb();
    while (i < idx.entries.items.len) : (i += 1) {
        const e = &idx.entries.items[i];
        if (!util.eql(e.path, path)) break;
        const s = e.stage();
        if (s == 0) continue;
        if (bufs[s - 1] == null) {
            const o = odb.read(e.oid) orelse util.die("unable to read {s}", .{hash.hex(e.oid)});
            bufs[s - 1] = o.data;
        }
    }
    const opts = merge_ort.LlOpts{};
    const r = merge_ort.llMerge(path, bufs[0] orelse "", null, bufs[1] orelse "", "ours", bufs[2] orelse "", "theirs", &opts);
    const result = r.result orelse "";
    var out: util.Buf = .empty;
    const has = handlePath(h, result, if (output != null) &out else null, ms);
    if (output) |o| _ = writeOut(o, out.items);
    return has;
}

fn forgetOnePath(idx: *index_mod.Index, path: []const u8, rr: *MergeRr) i32 {
    var h: hash.Oid = undefined;
    if (handleCache(idx, path, &h, null) < 1) {
        util.err("could not parse conflict hunks in '{s}'", .{path});
        return -1;
    }
    const hx = hash.hex(h);
    const id = newIdHex(&hx);
    id.variant = 0;
    while (id.variant < id.dir.status.items.len) : (id.variant += 1) {
        if (!hasResolution(id)) continue;
        const thisimage = rrPath(id, "thisimage");
        _ = handleCache(idx, path, &h, thisimage);
        const cur = os.readFile(thisimage) orelse {
            util.err("failed to update conflicted state in '{s}'", .{path});
            return -1;
        };
        var result: []const u8 = "";
        if (tryMerge(id, path, cur, &result)) break;
    }
    if (id.dir.status.items.len <= id.variant) {
        util.err("no remembered resolution for '{s}'", .{path});
        return -1;
    }
    const filename = rrPath(id, "postimage");
    if (!os.unlink(filename)) {
        if (os.errno() == 2) {
            util.err("no remembered resolution for '{s}'", .{path});
        } else util.err("cannot unlink '{s}': {s}", .{ filename, os.lastErr() });
        return -1;
    }
    _ = handleCache(idx, path, &h, rrPath(id, "preimage"));
    util.eprint("Updated preimage for '{s}'\n", .{path});
    rr.insert(path).id = id;
    util.eprint("Forgot resolution for '{s}'\n", .{path});
    return 0;
}

/// rerere_forget()
pub fn forget(ps: *const pathspec_mod.Pathspec) i32 {
    const idx = readIndex();
    var rr: MergeRr = .{};
    if (!setup(&rr, NOAUTOUPDATE)) return 0;
    // unmerge_index()
    var paths: std.ArrayList([]const u8) = .empty;
    for (idx.reuc.items) |r| {
        if (ps.matches(r.path, false)) paths.append(gpa, r.path) catch util.oom();
    }
    for (paths.items) |p| _ = idx.unmergeEntry(p);
    var conflict: std.ArrayList([]const u8) = .empty;
    findConflict(idx, &conflict);
    for (conflict.items) |p| {
        if (!ps.matches(p, false)) continue;
        _ = forgetOnePath(idx, p, &rr);
    }
    return writeRr(&rr);
}

// ---------------------------------------------------------------------------
// remaining / clear / gc

/// rerere_remaining(): fills rr with paths; resolved ones are marked.
pub fn remaining(rr: *MergeRr) void {
    if (!setup(rr, READONLY)) return;
    const idx = readIndex();
    var i: usize = 0;
    while (i < idx.entries.items.len) {
        var t: ConflictType = .resolved;
        const name = idx.entries.items[i].path;
        i = checkOneConflict(idx, i, &t);
        if (t == .punted) {
            _ = rr.insert(name);
        } else if (t == .resolved) {
            if (rr.lookup(name)) |it| {
                it.id = null;
                it.resolved = true;
            }
        }
    }
}

fn unlinkRrItem(id: *Id) void {
    unlinkOrWarn(rrPath(id, "thisimage"));
    removeVariant(id);
}

/// rerere_clear()
pub fn clear() void {
    var rr: MergeRr = .{};
    if (repo_mod.repo_ == null) return;
    if (!setup(&rr, 0)) return;
    for (rr.items.items) |item| {
        const id = item.id orelse continue;
        if (!hasResolution(id)) {
            unlinkRrItem(id);
            _ = os.rmdir(rrPath(id, null));
        }
    }
    unlinkOrWarn(mergeRrPath());
    if (write_lock) |l| l.rollback();
    write_lock = null;
}

fn expiryInDays(key: []const u8, now: i64) ?i64 {
    const v = repo_mod.cfg.get(key) orelse return null;
    if (std.fmt.parseInt(i32, util.trim(v), 10)) |days| {
        return now - @as(i64, days) * 86400;
    } else |_| {}
    return date.parseExpiryDate(v);
}

fn mtimeOf(p: []const u8) i64 {
    const st = os.statPath(p) orelse return 0;
    return st.mtime;
}

/// rerere_gc()
pub fn gc() void {
    var rr: MergeRr = .{};
    if (!setup(&rr, 0)) return;
    const now = os.now();
    const cutoff_resolve = expiryInDays("gc.rerereresolved", now) orelse now - 60 * 86400;
    const cutoff_noresolve = expiryInDays("gc.rerereunresolved", now) orelse now - 15 * 86400;
    const entries = os.listDir(rrCachePath()) orelse util.dieErrno("unable to open rr-cache directory", .{});
    var to_remove: std.ArrayList([]const u8) = .empty;
    for (entries) |e| {
        if (e.name.len != hash.HEXSZ or !util.isHex(e.name)) continue;
        const d = findDir(e.name);
        var now_empty = true;
        var id = Id{ .dir = d, .variant = 0 };
        while (id.variant < d.status.items.len) : (id.variant += 1) {
            var then = mtimeOf(rrPath(&id, "postimage"));
            var cutoff = cutoff_resolve;
            var stale = false;
            if (then != 0) {
                stale = then < cutoff;
            } else {
                then = mtimeOf(rrPath(&id, "preimage"));
                cutoff = cutoff_noresolve;
                stale = then != 0 and then < cutoff;
            }
            if (stale) unlinkRrItem(&id);
            if (d.status.items[@intCast(id.variant)] != 0) now_empty = false;
        }
        if (now_empty) to_remove.append(gpa, e.name) catch util.oom();
    }
    for (to_remove.items) |n| _ = os.rmdir(util.concat(&.{ rrCachePath(), "/", n }));
    if (write_lock) |l| l.rollback();
    write_lock = null;
}

// ---------------------------------------------------------------------------
// helpers for builtin/rerere.c

/// `git rerere diff` for one item. Returns false on failure.
pub fn diffItem(item: *const Item) bool {
    const id = item.id orelse return true;
    const minus = os.readFile(rrPath(id, "preimage")) orelse return false;
    const plus = os.readFile(item.path) orelse return false;
    util.outf("--- a/{s}\n+++ b/{s}\n", .{ item.path, item.path });
    const d = xdiff.unifiedDiff(minus, plus, .{ .indent_heuristic = false }, .{ .context = 3, .funcnames = false }) catch return false;
    util.out(d);
    return true;
}
