//! git daemon (port of daemon.c). Instead of re-executing itself with
//! --serve for every connection, the listening process fork()s.

const std = @import("std");
const c = std.c;
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const pkt = @import("../pktline.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const gpa = util.gpa;
const Buf = util.Buf;

// ---------------- libc ----------------

const AddrInfo = extern struct {
    ai_flags: c_int,
    ai_family: c_int,
    ai_socktype: c_int,
    ai_protocol: c_int,
    ai_addrlen: u32,
    ai_addr: ?*anyopaque,
    ai_canonname: ?[*:0]u8,
    ai_next: ?*AddrInfo,
};
const PollFd = extern struct { fd: c_int, events: i16, revents: i16 };
const Passwd = extern struct {
    pw_name: ?[*:0]const u8,
    pw_passwd: ?[*:0]const u8,
    pw_uid: u32,
    pw_gid: u32,
    pw_gecos: ?[*:0]const u8,
    pw_dir: ?[*:0]const u8,
    pw_shell: ?[*:0]const u8,
};
const Group = extern struct {
    gr_name: ?[*:0]const u8,
    gr_passwd: ?[*:0]const u8,
    gr_gid: u32,
    gr_mem: ?*anyopaque,
};

extern "c" fn getaddrinfo(node: ?[*:0]const u8, service: ?[*:0]const u8, hints: *const AddrInfo, res: *?*AddrInfo) c_int;
extern "c" fn freeaddrinfo(ai: *AddrInfo) void;
extern "c" fn gai_strerror(e: c_int) [*:0]const u8;
extern "c" fn inet_ntop(af: c_int, src: *const anyopaque, dst: [*]u8, size: u32) ?[*:0]const u8;
extern "c" fn socket(domain: c_int, ty: c_int, protocol: c_int) c_int;
extern "c" fn bind(fd: c_int, addr: ?*const anyopaque, len: u32) c_int;
extern "c" fn listen(fd: c_int, backlog: c_int) c_int;
extern "c" fn accept(fd: c_int, addr: ?*anyopaque, len: ?*u32) c_int;
extern "c" fn setsockopt(fd: c_int, level: c_int, name: c_int, val: *const anyopaque, len: u32) c_int;
extern "c" fn fcntl(fd: c_int, cmd: c_int, ...) c_int;
extern "c" fn poll(fds: [*]PollFd, n: c_ulong, timeout: c_int) c_int;
extern "c" fn fork() c_int;
extern "c" fn kill(pid: c_int, sig: c_int) c_int;
extern "c" fn alarm(secs: c_uint) c_uint;
extern "c" fn sleep(secs: c_uint) c_uint;
extern "c" fn setsid() c_int;
extern "c" fn getpid() c_int;
extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn openlog(ident: [*:0]const u8, option: c_int, facility: c_int) void;
extern "c" fn syslog(pri: c_int, f: [*:0]const u8, ...) void;
extern "c" fn getpwnam(name: [*:0]const u8) ?*Passwd;
extern "c" fn getgrnam(name: [*:0]const u8) ?*Group;
extern "c" fn initgroups(user: [*:0]const u8, group: u32) c_int;
extern "c" fn setgid(gid: u32) c_int;
extern "c" fn setuid(uid: u32) c_int;
extern "c" fn setenv(name: [*:0]const u8, value: [*:0]const u8, overwrite: c_int) c_int;

const AF_INET = 2;
const AF_INET6 = 10;
const SOL_SOCKET = 1;
const SO_REUSEADDR = 2;
const SO_KEEPALIVE = 9;
const IPPROTO_IPV6 = 41;
const IPV6_V6ONLY = 26;
const SIGTERM = 15;
const SIGCHLD = 17;
const LOG_ERR = 3;
const LOG_INFO = 6;

// ---------------- state ----------------

const LogDest = enum { unset, none, stderr, syslog };
var log_destination: LogDest = .unset;
var verbose = false;
var reuseaddr = false;
var informative_errors = false;

const daemon_usage =
    "git daemon [--verbose] [--syslog] [--export-all]\n" ++
    "           [--timeout=<n>] [--init-timeout=<n>] [--max-connections=<n>]\n" ++
    "           [--strict-paths] [--base-path=<path>] [--base-path-relaxed]\n" ++
    "           [--user-path | --user-path=<path>]\n" ++
    "           [--interpolated-path=<path>]\n" ++
    "           [--reuseaddr] [--pid-file=<file>]\n" ++
    "           [--(enable|disable|allow-override|forbid-override)=<service>]\n" ++
    "           [--access-hook=<path>]\n" ++
    "           [--inetd | [--listen=<host_or_ipaddr>] [--port=<n>]\n" ++
    "                      [--detach] [--user=<user> [--group=<group>]]\n" ++
    "           [--log-destination=(stderr|syslog|none)]\n" ++
    "           [<directory>...]";

var ok_paths: []const []const u8 = &.{};
var strict_paths = false;
var export_all_trees = false;
var base_path: ?[]const u8 = null;
var interpolated_path: ?[]const u8 = null;
var base_path_relaxed = false;
var user_path: ?[]const u8 = null;
var timeout: c_uint = 0;
var init_timeout: c_uint = 0;
var access_hook: ?[]const u8 = null;
var max_connections: c_uint = 32;

const HostInfo = struct {
    hostname: Buf = .empty,
    canon_hostname: Buf = .empty,
    ip_address: Buf = .empty,
    tcp_port: Buf = .empty,
    hostname_lookup_done: bool = false,
    saw_extended_args: bool = false,
};

const Service = struct {
    name: []const u8,
    config_name: []const u8,
    cmd: []const []const u8,
    enabled: bool,
    overridable: bool,
};

var services = [_]Service{
    .{ .name = "upload-archive", .config_name = "uploadarch", .cmd = &.{"upload-archive"}, .enabled = false, .overridable = true },
    .{ .name = "upload-pack", .config_name = "uploadpack", .cmd = &.{ "upload-pack", "--strict" }, .enabled = true, .overridable = true },
    .{ .name = "receive-pack", .config_name = "receivepack", .cmd = &.{"receive-pack"}, .enabled = false, .overridable = true },
};

// ---------------- logging ----------------

fn logreport(priority: c_int, msg: []const u8) void {
    switch (log_destination) {
        .syslog => syslog(priority, "%s", os.z(msg)),
        .stderr => {
            const s = util.fmt("[{d}] {s}\n", .{ getpid(), msg });
            os.writeAll(2, s) catch {};
        },
        .none => {},
        .unset => util.die("BUG: log destination not initialized correctly", .{}),
    }
}

fn logerror(comptime f: []const u8, args: anytype) void {
    logreport(LOG_ERR, util.fmt(f, args));
}

fn loginfo(comptime f: []const u8, args: anytype) void {
    if (!verbose) return;
    logreport(LOG_INFO, util.fmt(f, args));
}

/// die routine when logging to syslog (daemon_die)
fn syslogDieHook(msg: []const u8) void {
    logreport(LOG_ERR, msg);
    c.exit(1);
}

// ---------------- paths ----------------

/// daemon_avoid_alias(): nonzero for paths with //, /./, /../ etc.
fn avoidAlias(p: []const u8) bool {
    if (p.len == 0 or (p[0] != '/' and p[0] != '~')) return true;
    var sl = true;
    var ndot: usize = 0;
    var i: usize = 1;
    while (true) : (i += 1) {
        const ch: u8 = if (i < p.len) p[i] else 0;
        if (sl) {
            if (ch == '.') {
                ndot += 1;
            } else if (ch == '/') {
                if (ndot < 3) return true;
                ndot = 0;
            } else if (ch == 0) {
                if (0 < ndot and ndot < 3) return true;
                return false;
            } else {
                sl = false;
                ndot = 0;
            }
        } else if (ch == 0) {
            return false;
        } else if (ch == '/') {
            sl = true;
            ndot = 0;
        }
    }
}

/// enter_repo(): returns the validated path or null.
fn enterRepo(path_in: []const u8, strict: bool) ?[]const u8 {
    var result: []const u8 = path_in;
    if (!strict) {
        var len = path_in.len;
        while (len > 1 and path_in[len - 1] == '/') len -= 1;
        if (len >= 4096) return null;
        const validated = path_in[0..len];
        var used: []const u8 = validated;
        if (used.len > 0 and used[0] == '~') used = config.interpolatePath(used, false) orelse return null;
        const suffixes = [_][]const u8{ "/.git", "", ".git/.git", ".git" };
        var found: ?usize = null;
        for (suffixes, 0..) |s, i| {
            const p = util.concat(&.{ used, s });
            if (os.statPath(p)) |st| {
                if (st.isReg() or (st.isDir() and repo_mod.isGitDirectory(p))) {
                    found = i;
                    break;
                }
            }
        }
        const idx = found orelse return null;
        var target = util.concat(&.{ used, suffixes[idx] });
        const gitfile = repo_mod.readGitfile(target);
        repo_mod.dieUponDubiousOwnership(gitfile, null, target);
        if (gitfile) |g| target = util.dupe(g);
        if (!os.chdir(target)) return null;
        result = util.concat(&.{ validated, suffixes[idx] });
    } else {
        var target = path_in;
        const gitfile = repo_mod.readGitfile(path_in);
        repo_mod.dieUponDubiousOwnership(gitfile, null, path_in);
        if (gitfile) |g| target = g;
        if (!os.chdir(target)) return null;
    }
    if (!repo_mod.isGitDirectory(".")) return null;
    os.setEnv("GIT_DIR", ".");
    os.unsetEnv("GIT_WORK_TREE");
    os.setEnv("GIT_IMPLICIT_WORK_TREE", "0");
    repo_mod.setup(false);
    os.unsetEnv("GIT_IMPLICIT_WORK_TREE");
    return result;
}

fn pathOk(directory: []const u8, hi: *HostInfo) ?[]const u8 {
    var dir = directory;
    if (avoidAlias(dir)) {
        logerror("'{s}': aliased", .{dir});
        return null;
    }
    if (dir[0] == '~') {
        const up = user_path orelse {
            logerror("'{s}': User-path not allowed", .{dir});
            return null;
        };
        if (up.len > 0) {
            const slash = std.mem.indexOfScalar(u8, dir, '/') orelse dir.len;
            const rest = dir[slash..];
            loginfo("userpath <{s}>, request <{s}>, namlen {d}, restlen {d}, slash <{s}>", .{ up, dir, slash, rest.len, rest });
            const rpath = util.concat(&.{ dir[0..slash], "/", up, rest });
            if (rpath.len >= 4096) {
                logerror("user-path too large: {s}", .{rpath[0..4095]});
                return null;
            }
            dir = rpath;
        }
    } else if (interpolated_path != null and hi.saw_extended_args) {
        if (dir[0] != '/') {
            logerror("'{s}': Non-absolute path denied (interpolated-path active)", .{dir});
            return null;
        }
        const f = interpolated_path.?;
        var b: Buf = .empty;
        var i: usize = 0;
        while (i < f.len) {
            if (f[i] != '%') {
                util.bufByte(&b, f[i]);
                i += 1;
                continue;
            }
            i += 1;
            const r = f[i..];
            if (util.startsWith(r, "%")) {
                util.bufByte(&b, '%');
                i += 1;
            } else if (util.startsWith(r, "H")) {
                util.bufAppend(&b, hi.hostname.items);
                i += 1;
            } else if (util.startsWith(r, "CH")) {
                util.bufAppend(&b, getCanonHostname(hi));
                i += 2;
            } else if (util.startsWith(r, "IP")) {
                util.bufAppend(&b, getIpAddress(hi));
                i += 2;
            } else if (util.startsWith(r, "P")) {
                util.bufAppend(&b, hi.tcp_port.items);
                i += 1;
            } else if (util.startsWith(r, "D")) {
                util.bufAppend(&b, directory);
                i += 1;
            } else {
                util.bufByte(&b, '%');
            }
        }
        if (b.items.len >= 4096) {
            logerror("interpolated path too large: {s}", .{b.items[0..4095]});
            return null;
        }
        loginfo("Interpolated dir '{s}'", .{b.items});
        dir = b.items;
    } else if (base_path) |bp| {
        if (dir[0] != '/') {
            logerror("'{s}': Non-absolute path denied (base-path active)", .{dir});
            return null;
        }
        const rpath = util.concat(&.{ bp, dir });
        if (rpath.len >= 4096) {
            logerror("base-path too large: {s}", .{rpath[0..4095]});
            return null;
        }
        dir = rpath;
    }

    var path = enterRepo(dir, strict_paths);
    if (path == null and base_path != null and base_path_relaxed) {
        dir = directory;
        path = enterRepo(dir, strict_paths);
    }
    const p = path orelse {
        logerror("'{s}' does not appear to be a git repository", .{dir});
        return null;
    };

    if (ok_paths.len > 0) {
        for (ok_paths) |pp| {
            if (pp.len <= p.len and std.mem.eql(u8, pp, p[0..pp.len]) and
                (p.len == pp.len or (!strict_paths and p[pp.len] == '/')))
                return p;
        }
    } else {
        if (!strict_paths) return p;
    }
    logerror("'{s}': not in directory list", .{p});
    return null;
}

// ---------------- services ----------------

fn daemonError(dir: []const u8, msg_in: []const u8) u8 {
    const msg = if (!informative_errors) "access denied or repository not exported" else msg_in;
    pkt.writeFmt(1, "ERR {s}: {s}", .{ msg, dir });
    return 255;
}

fn runAccessHook(svc: *const Service, dir: []const u8, path: []const u8, hi: *HostInfo) bool {
    const hook = access_hook.?;
    const argv = [_][]const u8{
        hook,            svc.name,             path, hi.hostname.items,
        getCanonHostname(hi), getIpAddress(hi), hi.tcp_port.items,
    };
    const r = os.run(&argv, .{ .use_shell = true, .no_stdin = true, .no_stderr = true, .capture_stdout = true });
    if (r.status == 0) return true;
    var msg: []const u8 = std.mem.trimStart(u8, r.stdout, " \t\n\r\x0b\x0c");
    if (msg.len == 0) msg = "service rejected";
    if (std.mem.indexOfScalar(u8, msg, '\n')) |e| msg = msg[0..e];
    _ = daemonError(dir, msg);
    return false;
}

fn runService(dir: []const u8, svc: *const Service, hi: *HostInfo, env: []const [2][]const u8) u8 {
    var enabled = svc.enabled;
    loginfo("Request {s} for '{s}'", .{ svc.name, dir });
    if (!enabled and !svc.overridable) {
        logerror("'{s}': service not enabled.", .{svc.name});
        return daemonError(dir, "service not enabled");
    }
    const path = pathOk(dir, hi) orelse return daemonError(dir, "no such repository");

    if (!export_all_trees and !os.exists("git-daemon-export-ok")) {
        logerror("'{s}': repository not exported.", .{path});
        return daemonError(dir, "repository not exported");
    }
    if (svc.overridable) {
        if (repo_mod.cfg.getBool(util.concat(&.{ "daemon.", svc.config_name }))) |v| enabled = v;
    }
    if (!enabled) {
        logerror("'{s}': service not enabled for '{s}'", .{ svc.name, path });
        return daemonError(dir, "service not enabled");
    }
    if (access_hook != null and !runAccessHook(svc, dir, path, hi)) return 255;

    _ = signal(SIGTERM, 1);

    // run_service_command()
    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, svc.cmd) catch util.oom();
    if (util.eql(svc.name, "upload-pack")) args.append(gpa, util.fmt("--timeout={d}", .{timeout})) catch util.oom();
    args.append(gpa, ".") catch util.oom();
    const ch = proc.spawnGit(args.items, .{ .pipe_err = true, .env = env });
    _ = c.close(0);
    _ = c.close(1);
    copyToLog(ch.err);
    return proc.wait(ch.pid);
}

fn copyToLog(fd: c_int) void {
    var line: Buf = .empty;
    var buf: [4096]u8 = undefined;
    while (true) {
        const n = c.read(fd, &buf, buf.len);
        if (n < 0) {
            if (os.errno() == 4) continue;
            break;
        }
        if (n == 0) break;
        for (buf[0..@intCast(n)]) |b| {
            if (b == '\n') {
                logerror("{s}", .{line.items});
                line.clearRetainingCapacity();
            } else util.bufByte(&line, b);
        }
    }
    if (line.items.len > 0) logerror("{s}", .{line.items});
    _ = c.close(fd);
}

fn findService(name: []const u8) *Service {
    for (&services) |*s| {
        if (util.eql(s.name, name)) return s;
    }
    util.die("No such service {s}", .{name});
}

// ---------------- request parsing ----------------

fn sanitizeClient(out: *Buf, in: []const u8) void {
    for (in) |ch| {
        if (ch == '/') continue;
        if (ch == '.' and (out.items.len == 0 or out.items[out.items.len - 1] == '.')) continue;
        util.bufByte(out, ch);
    }
    while (out.items.len > 0 and out.items[out.items.len - 1] == '.') out.items.len -= 1;
}

fn canonicalizeClient(out: *Buf, in: []const u8) void {
    sanitizeClient(out, in);
    for (out.items) |*ch| ch.* = std.ascii.toLower(ch.*);
}

fn cstrLen(s: []const u8) usize {
    return std.mem.indexOfScalar(u8, s, 0) orelse s.len;
}

fn parseHostArg(hi: *HostInfo, extra: []const u8) []const u8 {
    var rest = extra;
    if (rest.len > 0 and rest[0] != 0) {
        hi.saw_extended_args = true;
        if (rest.len >= 5 and std.ascii.eqlIgnoreCase(rest[0..5], "host=")) {
            const after = rest[5..];
            const vlen = cstrLen(after);
            const val = after[0..vlen];
            loginfo("Extended attribute \"host\": {s}", .{val});
            if (val.len > 0) {
                var host: []const u8 = val;
                var port: ?[]const u8 = null;
                if (val[0] == '[') {
                    const end = std.mem.indexOfScalar(u8, val, ']') orelse util.die("Invalid request ('[' without ']')", .{});
                    host = val[1..end];
                    if (end + 1 == val.len) {
                        port = null;
                    } else if (val[end + 1] == ':') {
                        port = val[end + 2 ..];
                    } else util.die("Garbage after end of host part", .{});
                } else if (std.mem.lastIndexOfScalar(u8, val, ':')) |colon| {
                    host = val[0..colon];
                    port = val[colon + 1 ..];
                }
                if (port) |p| sanitizeClient(&hi.tcp_port, p);
                canonicalizeClient(&hi.hostname, host);
                hi.hostname_lookup_done = false;
            }
            rest = if (vlen + 1 <= after.len) after[vlen + 1 ..] else after[after.len..];
        }
        if (rest.len > 0 and rest[0] != 0) util.die("Invalid request", .{});
    }
    return rest;
}

fn parseExtraArgs(hi: *HostInfo, env: *std.ArrayList([2][]const u8), extra: []const u8) void {
    const rest = parseHostArg(hi, extra);
    var proto: Buf = .empty;
    var it = std.mem.splitScalar(u8, rest, 0);
    while (it.next()) |arg| {
        if (arg.len == 0) continue;
        if (proto.items.len > 0) util.bufByte(&proto, ':');
        util.bufAppend(&proto, arg);
    }
    if (proto.items.len > 0) {
        loginfo("Extended attribute \"protocol\": {s}", .{proto.items});
        env.append(gpa, .{ "GIT_PROTOCOL", proto.items }) catch util.oom();
    }
}

fn lookupHostname(hi: *HostInfo) void {
    if (hi.hostname_lookup_done or hi.hostname.items.len == 0) return;
    var hints = std.mem.zeroes(AddrInfo);
    hints.ai_flags = 2; // AI_CANONNAME
    var res: ?*AddrInfo = null;
    if (getaddrinfo(os.z(hi.hostname.items), null, &hints, &res) == 0) {
        if (res) |ai| {
            var buf: [256]u8 = undefined;
            const addr: ?*const anyopaque = switch (ai.ai_family) {
                AF_INET => @ptrCast(@as([*]const u8, @ptrCast(ai.ai_addr.?)) + 4),
                AF_INET6 => @ptrCast(@as([*]const u8, @ptrCast(ai.ai_addr.?)) + 8),
                else => util.die("unexpected address family: {d}", .{ai.ai_family}),
            };
            if (inet_ntop(ai.ai_family, addr.?, &buf, buf.len)) |s| util.bufAppend(&hi.ip_address, std.mem.span(s));
            if (ai.ai_canonname) |cn| {
                sanitizeClient(&hi.canon_hostname, std.mem.span(cn));
            } else util.bufAppend(&hi.canon_hostname, hi.ip_address.items);
            freeaddrinfo(ai);
        }
    }
    hi.hostname_lookup_done = true;
}

fn getCanonHostname(hi: *HostInfo) []const u8 {
    lookupHostname(hi);
    return hi.canon_hostname.items;
}

fn getIpAddress(hi: *HostInfo) []const u8 {
    lookupHostname(hi);
    return hi.ip_address.items;
}

fn setKeepAlive(fd: c_int) void {
    const ka: c_int = 1;
    if (setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &ka, @sizeOf(c_int)) < 0) {
        if (os.errno() != 88) // ENOTSOCK
            logerror("unable to set SO_KEEPALIVE on socket: {s}", .{os.lastErr()});
    }
}

fn readExact(fd: c_int, dst: []u8) bool {
    var off: usize = 0;
    while (off < dst.len) {
        const n = c.read(fd, dst[off..].ptr, dst.len - off);
        if (n < 0) {
            if (os.errno() == 4) continue;
            util.die("read error: {s}", .{os.lastErr()});
        }
        if (n == 0) return false;
        off += @intCast(n);
    }
    return true;
}

/// packet_read(0, ...) without read-ahead; returns the payload.
fn readFirstPacket() []u8 {
    var hdr: [4]u8 = undefined;
    if (!readExact(0, &hdr)) util.die("the remote end hung up unexpectedly", .{});
    const len = std.fmt.parseInt(usize, &hdr, 16) catch
        util.die("protocol error: bad line length character: {s}", .{hdr});
    if (len == 0 or len == 1 or len == 2) return &.{};
    if (len < 4) util.die("protocol error: bad line length {d}", .{len});
    if (len > pkt.LARGE_PACKET_MAX) util.die("protocol error: bad line length {d}", .{len});
    const data = gpa.alloc(u8, len - 4) catch util.oom();
    if (!readExact(0, data)) util.die("the remote end hung up unexpectedly", .{});
    pkt.packetTrace(data, false);
    return data;
}

fn execute() u8 {
    const addr = os.getenv("REMOTE_ADDR");
    const port = os.getenv("REMOTE_PORT");
    if (addr) |a| loginfo("Connection from {s}:{s}", .{ a, port orelse "?" });

    setKeepAlive(0);
    _ = alarm(if (init_timeout != 0) init_timeout else timeout);
    const data = readFirstPacket();
    _ = alarm(0);

    const len = cstrLen(data);
    var line = data[0..len];
    if (line.len > 0 and line[line.len - 1] == '\n') line = line[0 .. line.len - 1];

    var hi = HostInfo{};
    var env: std.ArrayList([2][]const u8) = .empty;
    if (len != data.len) parseExtraArgs(&hi, &env, data[len + 1 ..]);

    for (&services) |*s| {
        const a = util.skipPrefix(line, "git-") orelse continue;
        const b = util.skipPrefix(a, s.name) orelse continue;
        if (b.len == 0 or b[0] != ' ') continue;
        return runService(b[1..], s, &hi, env.items);
    }
    logerror("Protocol error: '{s}'", .{line});
    return 255;
}

// ---------------- listening ----------------

const Child = struct { pid: c_int, family: u16, addr: [16]u8 };
var children: std.ArrayList(Child) = .empty;

fn addrEq(a: *const Child, b: *const Child) bool {
    return a.family == b.family and std.mem.eql(u8, &a.addr, &b.addr);
}

fn addChild(pid: c_int, sa: []const u8) void {
    var ch = Child{ .pid = pid, .family = std.mem.readInt(u16, sa[0..2], .little), .addr = @splat(0) };
    if (ch.family == AF_INET) {
        @memcpy(ch.addr[0..4], sa[4..8]);
    } else if (ch.family == AF_INET6) {
        @memcpy(ch.addr[0..16], sa[8..24]);
    }
    var i: usize = 0;
    while (i < children.items.len) : (i += 1) {
        if (addrEq(&children.items[i], &ch)) break;
    }
    children.insert(gpa, i, ch) catch util.oom();
}

fn killSomeChild() void {
    const items = children.items;
    if (items.len < 2) return;
    for (0..items.len - 1) |i| {
        if (addrEq(&items[i], &items[i + 1])) {
            _ = kill(items[i].pid, SIGTERM);
            break;
        }
    }
}

fn checkDeadChildren() void {
    var i: usize = 0;
    while (i < children.items.len) {
        var status: c_int = 0;
        const pid = c.waitpid(children.items[i].pid, &status, 1);
        if (pid > 1) {
            const dead = if (status != 0) " (with error)" else "";
            loginfo("[{d}] Disconnected{s}", .{ pid, dead });
            _ = children.orderedRemove(i);
        } else i += 1;
    }
}

fn childHandler(_: c_int) callconv(.c) void {}

var listen_socks: std.ArrayList(c_int) = .empty;

fn handle(incoming: c_int, sa: []const u8) void {
    if (max_connections != 0 and children.items.len >= max_connections) {
        killSomeChild();
        _ = sleep(1);
        checkDeadChildren();
        if (children.items.len >= max_connections) {
            _ = c.close(incoming);
            logerror("Too many children, dropping connection", .{});
            return;
        }
    }
    var remote_addr: ?[]const u8 = null;
    var remote_port: u16 = 0;
    const family = std.mem.readInt(u16, sa[0..2], .little);
    var buf: [128]u8 = @splat(0);
    if (family == AF_INET) {
        if (inet_ntop(AF_INET, sa[4..8].ptr, &buf, buf.len)) |s| remote_addr = util.dupe(std.mem.span(s));
        remote_port = std.mem.readInt(u16, sa[2..4], .big);
    } else if (family == AF_INET6) {
        if (inet_ntop(AF_INET6, sa[8..24].ptr, &buf, buf.len)) |s| remote_addr = util.fmt("[{s}]", .{std.mem.span(s)});
        remote_port = std.mem.readInt(u16, sa[2..4], .big);
    }
    util.flushStdout();
    const pid = fork();
    if (pid < 0) {
        logerror("unable to fork", .{});
        _ = c.close(incoming);
        return;
    }
    if (pid == 0) {
        _ = signal(SIGCHLD, 0);
        for (listen_socks.items) |fd| _ = c.close(fd);
        children = .empty;
        if (remote_addr) |ra| {
            _ = setenv("REMOTE_ADDR", os.z(ra), 1);
            _ = setenv("REMOTE_PORT", os.z(util.fmt("{d}", .{remote_port})), 1);
        }
        _ = c.dup2(incoming, 0);
        _ = c.dup2(incoming, 1);
        if (incoming > 1) _ = c.close(incoming);
        const rc = execute();
        os.exit(rc);
    }
    _ = c.close(incoming);
    addChild(pid, sa);
}

fn ip2str(family: c_int, sa: [*]const u8) []const u8 {
    var buf: [64]u8 = undefined;
    const src: [*]const u8 = switch (family) {
        AF_INET6 => sa + 8,
        AF_INET => sa + 4,
        else => return "<unknown>",
    };
    const s = inet_ntop(family, src, &buf, buf.len) orelse return "<unknown>";
    return util.dupe(std.mem.span(s));
}

fn setupNamedSock(listen_addr: ?[]const u8, listen_port: u32) usize {
    var socknum: usize = 0;
    var hints = std.mem.zeroes(AddrInfo);
    hints.ai_family = 0;
    hints.ai_socktype = 1;
    hints.ai_protocol = 6;
    hints.ai_flags = 1; // AI_PASSIVE
    var res: ?*AddrInfo = null;
    const node: ?[*:0]const u8 = if (listen_addr) |a| os.z(a) else null;
    const gai = getaddrinfo(node, os.z(util.fmt("{d}", .{listen_port})), &hints, &res);
    if (gai != 0) {
        logerror("getaddrinfo() for {s} failed: {s}", .{ listen_addr orelse "(null)", std.mem.span(gai_strerror(gai)) });
        return 0;
    }
    var it = res;
    while (it) |ai| : (it = ai.ai_next) {
        const fd = socket(ai.ai_family, ai.ai_socktype, ai.ai_protocol);
        if (fd < 0) continue;
        const on: c_int = 1;
        if (ai.ai_family == AF_INET6) _ = setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, &on, @sizeOf(c_int));
        if (reuseaddr and setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, @sizeOf(c_int)) != 0) {
            logerror("Could not set SO_REUSEADDR: {s}", .{os.lastErr()});
            _ = c.close(fd);
            continue;
        }
        setKeepAlive(fd);
        const sa: [*]const u8 = @ptrCast(ai.ai_addr.?);
        if (bind(fd, ai.ai_addr, ai.ai_addrlen) < 0) {
            const e = os.lastErr();
            logerror("Could not bind to {s}: {s}", .{ ip2str(ai.ai_family, sa), e });
            _ = c.close(fd);
            continue;
        }
        if (listen(fd, 5) < 0) {
            const e = os.lastErr();
            logerror("Could not listen to {s}: {s}", .{ ip2str(ai.ai_family, sa), e });
            _ = c.close(fd);
            continue;
        }
        const flags = fcntl(fd, 1); // F_GETFD
        if (flags >= 0) _ = fcntl(fd, 2, flags | 1); // F_SETFD, FD_CLOEXEC
        listen_socks.append(gpa, fd) catch util.oom();
        socknum += 1;
    }
    if (res) |r| freeaddrinfo(r);
    return socknum;
}

fn serve(listen_addrs: []const []const u8, listen_port: u32, cred: ?Cred) u8 {
    if (listen_addrs.len == 0) {
        _ = setupNamedSock(null, listen_port);
    } else {
        for (listen_addrs) |a| {
            if (setupNamedSock(a, listen_port) == 0)
                logerror("unable to allocate any listen sockets for host {s} on port {d}", .{ a, listen_port });
        }
    }
    if (listen_socks.items.len == 0) util.die("unable to allocate any listen sockets on port {d}", .{listen_port});

    if (cred) |cr| {
        if (initgroups(cr.name, cr.gid) != 0 or setgid(cr.gid) != 0 or setuid(cr.uid) != 0)
            util.die("cannot drop privileges", .{});
    }

    loginfo("Ready to rumble", .{});

    const pfd = gpa.alloc(PollFd, listen_socks.items.len) catch util.oom();
    for (listen_socks.items, 0..) |fd, i| pfd[i] = .{ .fd = fd, .events = 1, .revents = 0 };
    _ = signal(SIGCHLD, @intFromPtr(&childHandler));

    while (true) {
        checkDeadChildren();
        if (poll(pfd.ptr, pfd.len, -1) < 0) {
            if (os.errno() != 4) {
                logerror("Poll failed, resuming: {s}", .{os.lastErr()});
                _ = sleep(1);
            }
            continue;
        }
        for (pfd) |p| {
            if (p.revents & 1 == 0) continue;
            var ss: [128]u8 align(8) = @splat(0);
            var retry: usize = 3;
            while (true) {
                var sslen: u32 = ss.len;
                const incoming = accept(p.fd, &ss, &sslen);
                if (incoming < 0) {
                    const e = os.errno();
                    if (e == 4) {
                        retry -= 1;
                        if (retry > 0) continue;
                        break;
                    }
                    if (e == 11 or e == 103) break; // EAGAIN, ECONNABORTED
                    util.die("accept returned: {s}", .{os.lastErr()});
                }
                handle(incoming, ss[0..@max(sslen, 24)]);
                break;
            }
        }
    }
}

const Cred = struct { name: [*:0]const u8, uid: u32, gid: u32 };

fn prepareCredentials(user_name: []const u8, group_name: ?[]const u8) Cred {
    const pw = getpwnam(os.z(user_name)) orelse util.die("user not found - {s}", .{user_name});
    var cr = Cred{ .name = pw.pw_name orelse os.z(user_name), .uid = pw.pw_uid, .gid = pw.pw_gid };
    if (group_name) |g| {
        const gr = getgrnam(os.z(g)) orelse util.die("group not found - {s}", .{g});
        cr.gid = gr.gr_gid;
    }
    return cr;
}

fn usage() noreturn {
    util.eprint("usage: " ++ daemon_usage ++ "\n", .{});
    os.exit(129);
}

fn parseUint(v: []const u8) ?c_uint {
    if (v.len == 0 or std.mem.indexOfScalar(u8, v, '-') != null) return null;
    return std.fmt.parseInt(c_uint, v, 10) catch null;
}

/// strtoul(v, &end, 0)
fn parsePort(v: []const u8) ?u32 {
    if (v.len == 0) return null;
    var s = v;
    var base: u8 = 10;
    if (s.len > 2 and s[0] == '0' and (s[1] == 'x' or s[1] == 'X')) {
        base = 16;
        s = s[2..];
    } else if (s.len > 1 and s[0] == '0') {
        base = 8;
        s = s[1..];
    }
    const n = std.fmt.parseInt(u64, s, base) catch return null;
    return @truncate(n);
}

pub fn cmdDaemon(args: []const []const u8) u8 {
    var listen_port: u32 = 0;
    var listen_addrs: std.ArrayList([]const u8) = .empty;
    var serve_mode = false;
    var inetd_mode = false;
    var pid_file: ?[]const u8 = null;
    var user_name: ?[]const u8 = null;
    var group_name: ?[]const u8 = null;
    var detach = false;

    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (util.skipPrefix(arg, "--listen=")) |v| {
            const l = util.dupe(v);
            for (l) |*ch| ch.* = std.ascii.toLower(ch.*);
            listen_addrs.append(gpa, l) catch util.oom();
            continue;
        }
        if (util.skipPrefix(arg, "--port=")) |v| {
            if (parsePort(v)) |n| {
                listen_port = n;
                continue;
            }
        }
        if (util.eql(arg, "--serve")) {
            serve_mode = true;
            continue;
        }
        if (util.eql(arg, "--inetd")) {
            inetd_mode = true;
            continue;
        }
        if (util.eql(arg, "--verbose")) {
            verbose = true;
            continue;
        }
        if (util.eql(arg, "--syslog")) {
            log_destination = .syslog;
            continue;
        }
        if (util.skipPrefix(arg, "--log-destination=")) |v| {
            if (util.eql(v, "syslog")) {
                log_destination = .syslog;
            } else if (util.eql(v, "stderr")) {
                log_destination = .stderr;
            } else if (util.eql(v, "none")) {
                log_destination = .none;
            } else util.die("unknown log destination '{s}'", .{v});
            continue;
        }
        if (util.eql(arg, "--export-all")) {
            export_all_trees = true;
            continue;
        }
        if (util.skipPrefix(arg, "--access-hook=")) |v| {
            access_hook = v;
            continue;
        }
        if (util.skipPrefix(arg, "--timeout=")) |v| {
            timeout = parseUint(v) orelse util.die("invalid timeout '{s}', expecting a non-negative integer", .{v});
            continue;
        }
        if (util.skipPrefix(arg, "--init-timeout=")) |v| {
            init_timeout = parseUint(v) orelse util.die("invalid init-timeout '{s}', expecting a non-negative integer", .{v});
            continue;
        }
        if (util.skipPrefix(arg, "--max-connections=")) |v| {
            const n = std.fmt.parseInt(c_int, v, 10) catch util.die("invalid max-connections '{s}', expecting an integer", .{v});
            max_connections = if (n < 0) 0 else @intCast(n);
            continue;
        }
        if (util.eql(arg, "--strict-paths")) {
            strict_paths = true;
            continue;
        }
        if (util.skipPrefix(arg, "--base-path=")) |v| {
            base_path = v;
            continue;
        }
        if (util.eql(arg, "--base-path-relaxed")) {
            base_path_relaxed = true;
            continue;
        }
        if (util.skipPrefix(arg, "--interpolated-path=")) |v| {
            interpolated_path = v;
            continue;
        }
        if (util.eql(arg, "--reuseaddr")) {
            reuseaddr = true;
            continue;
        }
        if (util.eql(arg, "--user-path")) {
            user_path = "";
            continue;
        }
        if (util.skipPrefix(arg, "--user-path=")) |v| {
            user_path = v;
            continue;
        }
        if (util.skipPrefix(arg, "--pid-file=")) |v| {
            pid_file = v;
            continue;
        }
        if (util.eql(arg, "--detach")) {
            detach = true;
            continue;
        }
        if (util.skipPrefix(arg, "--user=")) |v| {
            user_name = v;
            continue;
        }
        if (util.skipPrefix(arg, "--group=")) |v| {
            group_name = v;
            continue;
        }
        if (util.skipPrefix(arg, "--enable=")) |v| {
            findService(v).enabled = true;
            continue;
        }
        if (util.skipPrefix(arg, "--disable=")) |v| {
            findService(v).enabled = false;
            continue;
        }
        if (util.skipPrefix(arg, "--allow-override=")) |v| {
            findService(v).overridable = true;
            continue;
        }
        if (util.skipPrefix(arg, "--forbid-override=")) |v| {
            findService(v).overridable = false;
            continue;
        }
        if (util.eql(arg, "--informative-errors")) {
            informative_errors = true;
            continue;
        }
        if (util.eql(arg, "--no-informative-errors")) {
            informative_errors = false;
            continue;
        }
        if (util.eql(arg, "--")) {
            ok_paths = args[i + 1 ..];
            break;
        } else if (arg.len == 0 or arg[0] != '-') {
            ok_paths = args[i..];
            break;
        }
        usage();
    }

    if (log_destination == .unset) {
        log_destination = if (inetd_mode or detach) .syslog else .stderr;
    }
    if (log_destination == .syslog) {
        openlog("git-daemon", 1, 3 << 3);
        util.die_hook = &syslogDieHook;
    }

    if (inetd_mode and (detach or group_name != null or user_name != null))
        util.die("--detach, --user and --group are incompatible with --inetd", .{});
    if (inetd_mode and (listen_port != 0 or listen_addrs.items.len > 0)) {
        util.die("--listen= and --port= are incompatible with --inetd", .{});
    } else if (listen_port == 0) listen_port = 9418;

    if (group_name != null and user_name == null) util.die("--group supplied without --user", .{});
    var cred: ?Cred = null;
    if (user_name) |u| cred = prepareCredentials(u, group_name);

    if (strict_paths and ok_paths.len == 0) util.die("option --strict-paths requires '<directory>' arguments", .{});
    if (base_path) |bp| {
        if (!os.isDir(bp)) util.die("base-path '{s}' does not exist or is not a directory", .{bp});
    }

    if (log_destination != .stderr) {
        const fd = os.openFile("/dev/null", 1, 0);
        if (fd < 0) util.dieErrno("failed to redirect stderr to /dev/null", .{});
        _ = c.dup2(fd, 2);
        _ = c.close(fd);
    }

    if (inetd_mode or serve_mode) return execute();

    if (detach) {
        util.flushStdout();
        const pid = fork();
        if (pid < 0) util.dieErrno("fork failed", .{});
        if (pid > 0) c.exit(0);
        if (setsid() == -1) util.dieErrno("setsid failed", .{});
        const fd = os.openFile("/dev/null", 2, 0);
        if (fd >= 0) {
            _ = c.dup2(fd, 0);
            _ = c.dup2(fd, 1);
            _ = c.dup2(fd, 2);
            if (fd > 2) _ = c.close(fd);
        }
    }
    if (pid_file) |pf| {
        os.writeFile(pf, util.fmt("{d}\n", .{getpid()}), 0o666) catch
            util.dieErrno("could not open '{s}' for writing", .{pf});
    }
    return serve(listen_addrs.items, listen_port, cred);
}
