//! Small commands: version, help.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const main = @import("../main.zig");
const commands = @import("../commands.zig");

pub fn cmdVersion(args: []const []const u8) u8 {
    var build_options = false;
    const opts = [_]po.Opt{po.boolean(0, "build-options", &build_options, "also print build options")};
    _ = po.parse(args[1..], &opts, &.{"git version [--build-options]"}, .{});
    util.outf("git version {s}\n", .{main.version});
    if (build_options) {
        util.out("cpu: x86_64\nbuilt from commit: (none)\nsizeof-long: 8\nsizeof-size_t: 8\nshell-path: /bin/sh\nzlib: 1.3.1\nSHA-1: SHA1_DC\nSHA-256: SHA256_BLK\ndefault-ref-format: files\ndefault-hash: sha1\n");
    }
    return 0;
}

pub fn cmdHelp(args: []const []const u8) u8 {
    if (args.len < 2) {
        util.out(
            \\usage: git [-v | --version] [-h | --help] [-C <path>] [-c <name>=<value>]
            \\           [--exec-path[=<path>]] [--html-path] [--man-path] [--info-path]
            \\           [-p | --paginate | -P | --no-pager] [--no-replace-objects] [--no-lazy-fetch]
            \\           [--no-optional-locks] [--no-advice] [--bare] [--git-dir=<path>]
            \\           [--work-tree=<path>] [--namespace=<name>] [--config-env=<name>=<envvar>]
            \\           <command> [<args>]
            \\
            \\
        );
        return 0;
    }
    var i: usize = 1;
    while (i < args.len and args[i].len > 0 and args[i][0] == '-') : (i += 1) {
        if (util.eql(args[i], "-a") or util.eql(args[i], "--all")) {
            commands.listCommands();
            return 0;
        }
    }
    if (i >= args.len) return 0;
    const name = args[i];
    if (commands.find(name) == null) {
        util.eprint("git: '{s}' is not a git command. See 'git --help'.\n", .{name});
        return 1;
    }
    util.die("no man viewer handled the request", .{});
}

var stripspace_mode: i32 = 0;
var stripspace_mode_name: []const u8 = "";

fn stripspaceSet(mode: i32, name: []const u8) void {
    if (stripspace_mode != 0 and stripspace_mode != mode) {
        util.eprint("error: options '{s}' and '{s}' cannot be used together\n", .{ name, stripspace_mode_name });
        os.exit(129);
    }
    stripspace_mode = mode;
    stripspace_mode_name = name;
}
fn stripspaceS(_: ?[]const u8, _: bool) void {
    stripspaceSet(1, "-s");
}
fn stripspaceC(_: ?[]const u8, _: bool) void {
    stripspaceSet(2, "-c");
}

pub fn cmdStripspace(args: []const []const u8) u8 {
    const usage = [_][]const u8{ "git stripspace [-s | --strip-comments]", "git stripspace [-c | --comment-lines]" };
    const opts = [_]po.Opt{
        .{ .short = 's', .long = "strip-comments", .kind = .callback, .cb = stripspaceS, .noarg = true, .noneg = true, .help = "skip and remove all lines starting with comment character" },
        .{ .short = 'c', .long = "comment-lines", .kind = .callback, .cb = stripspaceC, .noarg = true, .noneg = true, .help = "prepend comment character and space to each line" },
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len > 0) po.usageWithOptions(&usage, &opts);
    const input = os.readAllFd(0) catch util.dieErrno("could not read the input", .{});
    const prefix = @import("../pretty_trailer.zig").commentLineStr();
    if (stripspace_mode != 2) {
        util.out(util.stripspace(input, if (stripspace_mode == 1) prefix else null));
    } else {
        var b: util.Buf = .empty;
        var rem = input;
        while (rem.len > 0) {
            const nl = std.mem.indexOfScalar(u8, rem, '\n');
            const end = if (nl) |p| p + 1 else rem.len;
            util.bufAppend(&b, prefix);
            if (rem[0] != '\n' and rem[0] != '\t') util.bufByte(&b, ' ');
            util.bufAppend(&b, rem[0..end]);
            rem = rem[end..];
        }
        if (b.items.len > 0 and b.items[b.items.len - 1] != '\n') util.bufByte(&b, '\n');
        util.out(b.items);
    }
    return 0;
}

const var_usage = "git var (-l | <variable>)";

fn varRead(name: []const u8, strict: bool) ?[]const u8 {
    const ident_mod = @import("../ident.zig");
    const config = @import("../config.zig");
    const repo_mod = @import("../repo.zig");
    if (util.eql(name, "GIT_COMMITTER_IDENT")) return ident_mod.ident(.committer, strict);
    if (util.eql(name, "GIT_AUTHOR_IDENT")) return ident_mod.ident(.author, strict);
    if (util.eql(name, "GIT_EDITOR")) return @import("../editor.zig").gitEditor();
    if (util.eql(name, "GIT_SEQUENCE_EDITOR")) return @import("../editor.zig").gitSequenceEditor();
    if (util.eql(name, "GIT_PAGER")) {
        const p = os.getenv("GIT_PAGER") orelse repo_mod.cfg.get("core.pager") orelse os.getenv("PAGER") orelse "less";
        return if (p.len == 0 or util.eql(p, "cat")) "cat" else p;
    }
    if (util.eql(name, "GIT_DEFAULT_BRANCH")) return @import("init.zig").defaultBranchName(true);
    if (util.eql(name, "GIT_SHELL_PATH")) return "/bin/sh";
    if (util.eql(name, "GIT_ATTR_SYSTEM")) {
        if (os.getenv("GIT_ATTR_NOSYSTEM")) |v| {
            if (config.parseBool(v) orelse false) return null;
        }
        return "/etc/gitattributes";
    }
    if (util.eql(name, "GIT_ATTR_GLOBAL")) {
        const f = repo_mod.cfg.get("core.attributesfile") orelse config.xdgConfigHome("attributes") orelse return null;
        return util.normalizePath(config.absolutePath(f)) orelse f;
    }
    if (util.eql(name, "GIT_CONFIG_SYSTEM")) {
        if (!config.useSystemConfig()) return null;
        return util.normalizePath(config.systemConfigPath()) orelse config.systemConfigPath();
    }
    if (util.eql(name, "GIT_CONFIG_GLOBAL")) {
        const g = config.globalConfigPaths();
        var b: util.Buf = .empty;
        if (g.xdg) |x| if (x.len > 0) util.bufPrint(&b, "{s}\n", .{util.normalizePath(x) orelse x});
        if (g.user) |u| if (u.len > 0) util.bufPrint(&b, "{s}\n", .{util.normalizePath(u) orelse u});
        if (b.items.len == 0) return null;
        return b.items[0 .. b.items.len - 1];
    }
    return null;
}

const var_names = [_][]const u8{ "GIT_COMMITTER_IDENT", "GIT_AUTHOR_IDENT", "GIT_EDITOR", "GIT_SEQUENCE_EDITOR", "GIT_PAGER", "GIT_DEFAULT_BRANCH", "GIT_SHELL_PATH", "GIT_ATTR_SYSTEM", "GIT_ATTR_GLOBAL", "GIT_CONFIG_SYSTEM", "GIT_CONFIG_GLOBAL" };

pub fn cmdVar(args: []const []const u8) u8 {
    if (args.len == 2 and util.eql(args[1], "-h")) {
        util.outf("usage: {s}\n", .{var_usage});
        util.flushStdout();
        os.exit(0);
    }
    if (args.len != 2) {
        util.eprint("usage: {s}\n", .{var_usage});
        os.exit(129);
    }
    if (util.eql(args[1], "-l")) {
        for (@import("../repo.zig").cfg.entries.items) |e| {
            if (e.value) |v| util.outf("{s}={s}\n", .{ e.key, v }) else util.outf("{s}\n", .{e.key});
        }
        for (var_names) |n| {
            const v = varRead(n, false) orelse continue;
            if (util.eql(n, "GIT_CONFIG_GLOBAL") and v.len > 0) {
                var it = std.mem.splitScalar(u8, v, '\n');
                while (it.next()) |l| util.outf("{s}={s}\n", .{ n, l });
            } else util.outf("{s}={s}\n", .{ n, v });
        }
        return 0;
    }
    var known = false;
    for (var_names) |n| {
        if (util.eql(n, args[1])) known = true;
    }
    if (!known) {
        util.eprint("usage: {s}\n", .{var_usage});
        os.exit(129);
    }
    const v = varRead(args[1], true) orelse return 1;
    util.outf("{s}\n", .{v});
    return 0;
}
