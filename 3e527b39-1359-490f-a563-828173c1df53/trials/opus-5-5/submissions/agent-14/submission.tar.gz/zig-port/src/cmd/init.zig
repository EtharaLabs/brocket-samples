//! git init

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const refs = @import("../refs.zig");
const advice = @import("../advice.zig");
const gpa = util.gpa;
const template_hooks = @import("../template_hooks.zig");

const usage = [_][]const u8{
    "git init [-q | --quiet] [--bare] [--template=<template-directory>]\n" ++
        "         [--separate-git-dir <git-dir>] [--object-format=<format>]\n" ++
        "         [--ref-format=<format>]\n" ++
        "         [-b <branch-name> | --initial-branch=<branch-name>]\n" ++
        "         [--shared[=<permissions>]] [<directory>]",
};

var shared: ?[]const u8 = null;

fn guessBare(git_dir: []const u8) i32 {
    if (util.eql(git_dir, ".")) return 1;
    if (util.eql(git_dir, os.getcwd())) return 1;
    if (util.eql(git_dir, ".git")) return 0;
    if (util.endsWith(git_dir, "/.git")) return 0;
    return -1;
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return util.normalizePath(p) orelse p;
    return util.normalizePath(util.joinPath(os.getcwd(), p)) orelse p;
}

fn realOrAbs(p: []const u8) []const u8 {
    if (os.realPath(p)) |r| return r;
    // resolve the existing parent
    const parent = util.dirname(p);
    if (parent.len > 0 and !util.eql(parent, p)) {
        if (os.realPath(parent)) |rp| return util.joinPath(rp, util.basename(p));
    }
    return absPath(p);
}

pub const default_description = "Unnamed repository; edit this file 'description' to name the repository.\n";
pub const default_exclude =
    \\# git ls-files --others --exclude-from=.git/info/exclude
    \\# Lines that start with '#' are comments.
    \\# For a project mostly in C, the following would be a good set of
    \\# exclude patterns (uncomment them if you want to use them):
    \\# *.[oa]
    \\# *~
    \\
;

fn copyTemplatesDir(dst: []const u8, src: []const u8) void {
    _ = os.mkdir(dst, 0o777);
    const entries = os.listDir(src) orelse return;
    for (entries) |e| {
        if (e.name.len > 0 and e.name[0] == '.') continue;
        const d = util.concat(&.{ dst, "/", e.name });
        const s = util.concat(&.{ src, "/", e.name });
        const exists = os.lstatPath(d) != null;
        const st = os.lstatPath(s) orelse util.dieErrno("cannot stat template '{s}'", .{s});
        if (st.isDir()) {
            copyTemplatesDir(d, s);
        } else if (exists) {
            continue;
        } else if (st.isLnk()) {
            const t = os.readLink(s) orelse util.dieErrno("cannot readlink '{s}'", .{s});
            if (!os.symlink(t, d)) util.dieErrno("cannot symlink '{s}' '{s}'", .{ t, d });
        } else if (st.isReg()) {
            const data = os.readFile(s) orelse util.dieErrno("cannot copy '{s}' to '{s}'", .{ s, d });
            os.writeFile(d, data, @intCast(if (st.mode & 0o111 != 0) @as(u32, 0o777) else 0o666)) catch util.dieErrno("cannot copy '{s}' to '{s}'", .{ s, d });
        } else {
            util.err("ignoring template {s}", .{s});
        }
    }
}

fn templateDir(opt: ?[]const u8) ?[]const u8 {
    if (opt) |t| return t;
    if (os.getenv("GIT_TEMPLATE_DIR")) |t| return t;
    if (repo_mod.cfg.getPath("init.templatedir")) |t| return t;
    return null;
}

fn copyTemplates(common_dir: []const u8, opt: ?[]const u8) void {
    const td = templateDir(opt) orelse {
        // built-in default templates
        const desc = util.concat(&.{ common_dir, "/description" });
        if (!os.exists(desc)) os.writeFile(desc, default_description, 0o666) catch {};
        _ = os.mkdir(util.concat(&.{ common_dir, "/hooks" }), 0o777);
        for (template_hooks.hooks) |h| {
            const hp = util.concat(&.{ common_dir, "/hooks/", h.name });
            if (!os.exists(hp)) os.writeFile(hp, h.data, 0o777) catch {};
        }
        _ = os.mkdir(util.concat(&.{ common_dir, "/info" }), 0o777);
        const ex = util.concat(&.{ common_dir, "/info/exclude" });
        if (!os.exists(ex)) os.writeFile(ex, default_exclude, 0o666) catch {};
        return;
    };
    if (td.len == 0) return;
    if (!os.isDir(td)) {
        util.warn("templates not found in {s}", .{td});
        return;
    }
    // verify template config version
    if (os.readFile(util.concat(&.{ td, "/config" }))) |_| {
        var tcfg: config.Config = .{};
        _ = config.readFileInto(&tcfg, util.concat(&.{ td, "/config" }), .local);
        if (tcfg.getInt("core.repositoryformatversion")) |v| {
            if (v > 1) {
                util.warn("not copying templates from '{s}': Expected git repo version <= 1, found {d}", .{ td, v });
                return;
            }
        }
    }
    copyTemplatesDir(common_dir, td);
}

fn setCfg(path: []const u8, key: []const u8, value: []const u8) void {
    _ = config.setInFile(path, key, value, .{}, false, false, null);
}

pub fn defaultBranchName(quiet: bool) []const u8 {
    var ret: ?[]const u8 = null;
    if (os.getenv("GIT_TEST_DEFAULT_INITIAL_BRANCH_NAME")) |e| {
        if (e.len > 0) ret = e;
    }
    if (ret == null) ret = repo_mod.cfg.get("init.defaultbranch");
    if (ret == null) {
        ret = "master";
        if (!quiet) advice.adviseIfEnabled("defaultBranchName", "Using 'master' as the name for the initial branch. This default branch name\n" ++
            "will change to \"main\" in Git 3.0. To configure the initial branch name\n" ++
            "to use in all of your new repositories, which will suppress this warning,\n" ++
            "call:\n\n\tgit config --global init.defaultBranch <name>\n\n" ++
            "Names commonly chosen instead of 'master' are 'main', 'trunk' and\n" ++
            "'development'. The just-created branch can be renamed via this command:\n\n\tgit branch -m <name>\n");
    }
    if (!refs.checkRefnameFormat(util.concat(&.{ "refs/heads/", ret.? }), 0))
        util.die("invalid branch name: init.defaultBranch = {s}", .{ret.?});
    return ret.?;
}

/// git_config_perm(): 0 = umask, >0 = OR mask (0660/0664), <0 = exact mode
pub fn parseShared(var_: []const u8, v: []const u8) i32 {
    if (util.eql(v, "umask")) return 0;
    if (util.eql(v, "group")) return 0o660;
    if (util.eql(v, "all") or util.eql(v, "world") or util.eql(v, "everybody")) return 0o664;
    var i: usize = 0;
    var n: i64 = 0;
    while (i < v.len and v[i] >= '0' and v[i] <= '7') : (i += 1) {
        n = n * 8 + (v[i] - '0');
        if (n > 0o7777777) n = 0o7777777;
    }
    if (i != v.len) {
        const b = config.parseBool(v) orelse util.die("bad boolean config value '{s}' for '{s}'", .{ v, var_ });
        return if (b) 0o660 else 0;
    }
    switch (n) {
        0 => return 0,
        1 => return 0o660,
        2 => return 0o664,
        else => {},
    }
    const m: i32 = @intCast(n & 0o7777777);
    if (m & 0o600 != 0o600) util.die("problem with core.sharedRepository filemode value (0{o:0>3}).\nThe owner of files must always have read and write permissions.", .{@as(u32, @intCast(m))});
    return -(m & 0o666);
}

pub const InitOpts = struct {
    git_dir: []const u8,
    real_git_dir: ?[]const u8 = null,
    work_tree: ?[]const u8 = null,
    template: ?[]const u8 = null,
    initial_branch: ?[]const u8 = null,
    shared: ?[]const u8 = null,
    quiet: bool = false,
    bare: bool = false,
    object_format: ?[]const u8 = null,
    ref_format: ?[]const u8 = null,
    skip_refdb: bool = false,
};

/// Initialize (or re-initialize) a repository; returns absolute git dir.
pub fn initDb(o: InitOpts) []const u8 {
    var git_dir = o.git_dir;
    const original_git_dir = realOrAbs(git_dir);
    if (o.real_git_dir) |rgd| {
        // move existing git dir if any, then write a gitfile
        const real = realOrAbs(rgd);
        if (os.statPath(original_git_dir)) |st| {
            var src: []const u8 = original_git_dir;
            if (st.isReg()) {
                src = repo_mod.readGitfile(original_git_dir) orelse original_git_dir;
            } else if (!st.isDir()) util.die("unable to handle file type {d}", .{st.mode});
            if (!os.rename(src, real)) util.dieErrno("unable to move {s} to {s}", .{ src, real });
        }
        _ = os.mkdirLeading(real);
        os.writeFile(original_git_dir, util.concat(&.{ "gitdir: ", real, "\n" }), 0o666) catch util.dieErrno("could not write '{s}'", .{original_git_dir});
        git_dir = real;
    } else if (os.statPath(git_dir)) |st| {
        if (st.isReg()) git_dir = repo_mod.readGitfile(git_dir) orelse git_dir;
    }
    if (!os.isDir(git_dir)) {
        if (!os.mkdirAll(git_dir)) util.dieErrno("cannot mkdir {s}", .{git_dir});
    }
    const abs_git_dir = realOrAbs(git_dir);
    // read existing format
    const cfg_path = util.concat(&.{ git_dir, "/config" });
    var existing: config.Config = .{};
    _ = config.readFileInto(&existing, cfg_path, .local);
    if (existing.getInt("core.repositoryformatversion")) |v| {
        if (v > 1) util.die("Expected git repo version <= 1, found {d}", .{v});
    }
    if (o.object_format) |f| {
        if (!util.eql(f, "sha1")) {
            if (!util.eql(f, "sha256")) util.die("unknown hash algorithm '{s}'", .{f});
        }
    }
    if (o.ref_format) |f| {
        if (!util.eql(f, "files") and !util.eql(f, "reftable")) util.die("unknown ref storage format '{s}'", .{f});
    }
    const fmt_version: i64 = existing.getInt("core.repositoryformatversion") orelse -1;
    const existing_hash: []const u8 = existing.get("extensions.objectformat") orelse "sha1";
    const existing_ref: []const u8 = existing.get("extensions.refstorage") orelse "files";

    // set up repo state for config reading
    const r = gpa.create(repo_mod.Repo) catch util.oom();
    r.* = .{ .git_dir = git_dir, .common_dir = git_dir, .work_tree = o.work_tree, .bare = o.bare };
    repo_mod.repo_ = r;

    copyTemplates(git_dir, o.template);
    repo_mod.loadConfig();

    const reinit = os.exists(util.concat(&.{ git_dir, "/HEAD" })) or os.readLink(util.concat(&.{ git_dir, "/HEAD" })) != null;

    var shared_val: i32 = 0;
    if (o.shared) |s| {
        shared_val = parseShared("arg", s);
    } else if (repo_mod.cfg.get("core.sharedrepository")) |s| {
        shared_val = parseShared("core.sharedrepository", s);
    }

    // repository format version
    // repository_format_configure()
    var cfg_hash: ?[]const u8 = null;
    var cfg_ref: ?[]const u8 = null;
    for (repo_mod.cfg.entries.items) |e| {
        if (e.scope == .local or e.scope == .worktree) continue;
        const v = e.value orelse continue;
        if (std.ascii.eqlIgnoreCase(e.key, "init.defaultobjectformat")) {
            if (util.eql(v, "sha1") or util.eql(v, "sha256")) cfg_hash = v else {
                util.warn("unknown hash algorithm '{s}'", .{v});
                cfg_hash = null;
            }
        } else if (std.ascii.eqlIgnoreCase(e.key, "init.defaultrefformat")) {
            if (util.eql(v, "files") or util.eql(v, "reftable")) cfg_ref = v else {
                util.warn("unknown ref storage format '{s}'", .{v});
                cfg_ref = null;
            }
        } else if (std.ascii.eqlIgnoreCase(e.key, "feature.experimental") and cfg_ref == null) {
            if (config.parseBool(v) orelse false) cfg_ref = "reftable";
        }
    }
    var eff_hash: []const u8 = existing_hash;
    if (fmt_version >= 0 and o.object_format != null and !util.eql(o.object_format.?, existing_hash)) {
        util.die("attempt to reinitialize repository with different hash", .{});
    } else if (o.object_format) |f| {
        eff_hash = f;
    } else if (os.getenv("GIT_DEFAULT_HASH")) |env| {
        if (!util.eql(env, "sha1") and !util.eql(env, "sha256")) util.die("unknown hash algorithm '{s}'", .{env});
        if (fmt_version < 0) eff_hash = env;
    } else if (cfg_hash) |h| {
        if (fmt_version < 0) eff_hash = h;
    }
    var eff_ref: []const u8 = existing_ref;
    if (fmt_version >= 0 and o.ref_format != null and !util.eql(o.ref_format.?, existing_ref)) {
        util.die("attempt to reinitialize repository with different reference storage format", .{});
    } else if (o.ref_format) |f| {
        eff_ref = f;
    } else if (os.getenv("GIT_DEFAULT_REF_FORMAT")) |env| {
        if (!util.eql(env, "files") and !util.eql(env, "reftable")) util.die("unknown ref storage format '{s}'", .{env});
        if (fmt_version < 0) eff_ref = env;
    } else if (cfg_ref) |r_| {
        if (fmt_version < 0) eff_ref = r_;
    }
    var target_version: []const u8 = "0";
    if (util.eql(eff_hash, "sha256")) target_version = "1";
    if (util.eql(eff_ref, "reftable")) target_version = "1";
    if (repo_mod.cfg.getBool("init.defaultsubmodulepathconfig") orelse false) {
        target_version = "1";
    }
    if (util.eql(eff_hash, "sha256")) setCfg(cfg_path, "extensions.objectformat", eff_hash);
    if (util.eql(eff_ref, "reftable")) setCfg(cfg_path, "extensions.refstorage", eff_ref);
    if (repo_mod.cfg.getBool("init.defaultsubmodulepathconfig") orelse false) {
        setCfg(cfg_path, "extensions.submodulepathconfig", "true");
    }
    if (reinit) {
        // keep version 1 when v1-only extensions exist
        for (repo_mod.cfg.entries.items) |e| {
            if (e.scope == .local and util.startsWith(e.key, "extensions.")) target_version = "1";
        }
    }
    setCfg(cfg_path, "core.repositoryformatversion", target_version);

    // filemode
    var filemode = true;
    if (os.lstatPath(cfg_path)) |st1| {
        filemode = os.chmod(cfg_path, (st1.mode ^ 0o100) & 0o7777);
        if (filemode) {
            if (os.lstatPath(cfg_path)) |st2| {
                filemode = st1.mode != st2.mode and os.chmod(cfg_path, st1.mode & 0o7777);
            } else filemode = false;
        }
        if (filemode and !reinit and (st1.mode & 0o100 != 0)) filemode = false;
    }
    setCfg(cfg_path, "core.filemode", if (filemode) "true" else "false");
    if (o.work_tree == null) {
        setCfg(cfg_path, "core.bare", "true");
    } else {
        setCfg(cfg_path, "core.bare", "false");
        if (repo_mod.cfg.get("core.logallrefupdates") == null) setCfg(cfg_path, "core.logallrefupdates", "true");
        const wt = o.work_tree.?;
        const needs = blk: {
            if (util.eql(wt, "/") and util.eql(original_git_dir, "/.git")) break :blk false;
            if (util.skipPrefix(original_git_dir, wt)) |rest| {
                if (util.eql(rest, "/.git")) break :blk false;
            }
            break :blk true;
        };
        if (needs) setCfg(cfg_path, "core.worktree", wt);
    }
    if (!reinit) {
        // symlink check
        const t = util.concat(&.{ git_dir, "/tXXXXXX" });
        if (os.symlink("testing", t)) {
            _ = os.unlink(t);
        } else {
            setCfg(cfg_path, "core.symlinks", "false");
        }
        if (os.exists(util.concat(&.{ git_dir, "/CoNfIg" }))) setCfg(cfg_path, "core.ignorecase", "true");
    }
    if (shared_val != 0) {
        const buf = if (shared_val < 0) util.fmt("0{o}", .{-shared_val}) else if (shared_val == 0o660) "1" else "2";
        setCfg(cfg_path, "core.sharedrepository", buf);
        setCfg(cfg_path, "receive.denyNonFastforwards", "true");
    }
    repo_mod.loadConfig();

    // refs
    r.ref_storage = eff_ref;
    @import("../reftable_backend.zig").reset();
    if (!o.skip_refdb) {
        if (util.eql(eff_ref, "reftable")) {
            if (!reinit) @import("../reftable_backend.zig").createOnDisk(git_dir);
        } else {
            _ = os.mkdir(util.concat(&.{ git_dir, "/refs" }), 0o777);
            _ = os.mkdir(util.concat(&.{ git_dir, "/refs/heads" }), 0o777);
            _ = os.mkdir(util.concat(&.{ git_dir, "/refs/tags" }), 0o777);
        }
        if (!reinit) {
            const branch = o.initial_branch orelse defaultBranchName(o.quiet);
            const ref = util.concat(&.{ "refs/heads/", branch });
            if (!refs.checkRefnameFormat(ref, 0)) util.die("invalid initial branch name: '{s}'", .{branch});
            refs.writeSymref("HEAD", ref, null) catch util.die("unable to write HEAD", .{});
        } else if (o.initial_branch) |b| {
            util.warn("re-init: ignored --initial-branch={s}", .{b});
        }
    }
    // objects
    if (os.getenv("GIT_OBJECT_DIRECTORY") == null) {
        _ = os.mkdir(util.concat(&.{ git_dir, "/objects" }), 0o777);
    }
    const objdir = os.getenv("GIT_OBJECT_DIRECTORY") orelse util.concat(&.{ git_dir, "/objects" });
    _ = os.mkdirAll(objdir);
    _ = os.mkdir(util.concat(&.{ objdir, "/info" }), 0o777);
    _ = os.mkdir(util.concat(&.{ objdir, "/pack" }), 0o777);

    if (shared_val != 0) {
        if (reinit) {
            adjustSharedPerm(git_dir, shared_val);
            adjustSharedPerm(cfg_path, shared_val);
        } else adjustSharedTree(git_dir, shared_val);
    }

    if (!o.quiet) {
        const slash = if (abs_git_dir.len > 0 and abs_git_dir[abs_git_dir.len - 1] != '/') "/" else "";
        const sh = if (shared_val != 0) "shared " else "";
        if (reinit) {
            util.outf("Reinitialized existing {s}Git repository in {s}{s}\n", .{ sh, abs_git_dir, slash });
        } else {
            util.outf("Initialized empty {s}Git repository in {s}{s}\n", .{ sh, abs_git_dir, slash });
        }
    }
    return abs_git_dir;
}

/// adjust_shared_perm()
fn adjustSharedPerm(path: []const u8, shared_val: i32) void {
    const st = os.lstatPath(path) orelse return;
    if (st.isLnk()) return;
    const old: u32 = st.mode & 0o7777;
    var tweak: u32 = @intCast(if (shared_val < 0) -shared_val else shared_val);
    if (old & 0o200 == 0) tweak &= ~@as(u32, 0o222);
    if (old & 0o100 != 0) tweak |= (tweak & 0o444) >> 2;
    var new: u32 = if (shared_val < 0) (old & ~@as(u32, 0o777)) | tweak else old | tweak;
    if (st.isDir()) {
        new |= (new & 0o444) >> 2;
        if (new & 0o060 != 0) new |= 0o2000;
    }
    if (new != old) _ = os.chmod(path, new);
}

fn adjustSharedTree(dir: []const u8, shared_val: i32) void {
    adjustSharedPerm(dir, shared_val);
    const st = os.lstatPath(dir) orelse return;
    if (!st.isDir()) return;
    const entries = os.listDir(dir) orelse return;
    for (entries) |e| adjustSharedTree(util.concat(&.{ dir, "/", e.name }), shared_val);
}
pub fn cmdInit(args: []const []const u8) u8 {
    var template: ?[]const u8 = null;
    var bare: i32 = -1;
    var quiet: i32 = 0;
    var real_git_dir: ?[]const u8 = null;
    var initial_branch: ?[]const u8 = null;
    var object_format: ?[]const u8 = null;
    var ref_format: ?[]const u8 = null;
    if (os.getenv("GIT_DIR")) |_| {} // handled below
    if (forced_bare or repo_mod.force_bare_repository) bare = 1;
    const opts = [_]po.Opt{
        po.string(0, "template", &template, "template-directory", "directory from which templates will be used"),
        po.setInt(0, "bare", &bare, 1, "create a bare repository"),
        .{ .long = "shared", .kind = .string, .s = &shared, .optarg = true, .noneg = true, .def = "group", .argh = "permissions", .help = "specify that the git repository is to be shared amongst several users" },
        po.counter('q', "quiet", &quiet, "be quiet"),
        po.string(0, "separate-git-dir", &real_git_dir, "gitdir", "separate git dir from working tree"),
        po.string('b', "initial-branch", &initial_branch, "name", "override the name of the initial branch"),
        po.string(0, "object-format", &object_format, "hash", "specify the hash algorithm to use"),
        po.string(0, "ref-format", &ref_format, "format", "specify the reference format to use"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (real_git_dir != null and bare == 1) util.die("options '{s}' and '{s}' cannot be used together", .{ "--separate-git-dir", "--bare" });
    if (real_git_dir) |r| {
        if (r.len > 0 and r[0] != '/') real_git_dir = realOrAbs(r);
    }
    if (template) |t| {
        if (t.len > 0 and t[0] != '/') template = absPath(t);
    }
    if (rest.len == 1) {
        const d = rest[0];
        if (!os.chdir(d)) {
            if (!os.mkdirAll(d)) util.dieErrno("cannot mkdir {s}", .{d});
            if (!os.chdir(d)) util.dieErrno("cannot chdir to {s}", .{d});
        }
    } else if (rest.len > 1) {
        util.usageDie("usage: {s}", .{usage[0]});
    }
    if (bare == 1) {
        if (rest.len > 0 or os.getenv("GIT_DIR") == null) os.setEnv("GIT_DIR", os.getcwd());
    }
    if (object_format) |f| {
        if (!util.eql(f, "sha1") and !util.eql(f, "sha256")) util.die("unknown hash algorithm '{s}'", .{f});
    }
    if (ref_format) |f| {
        if (!util.eql(f, "files") and !util.eql(f, "reftable")) util.die("unknown ref storage format '{s}'", .{f});
    }
    var git_dir = os.getenv("GIT_DIR");
    var work_tree = os.getenv("GIT_WORK_TREE");
    if ((git_dir == null or bare == 1) and work_tree != null)
        util.die("GIT_WORK_TREE (or --work-tree=<directory>) not allowed without specifying GIT_DIR (or --git-dir=<directory>)", .{});
    if (git_dir == null) git_dir = ".git";
    if (real_git_dir != null) {
        if (os.statPath(git_dir.?)) |st| {
            if (st.isReg()) {
                if (repo_mod.readGitfile(git_dir.?)) |p| {
                    // relocate common dir of a linked worktree
                    const cd = util.concat(&.{ p, "/commondir" });
                    if (os.readFile(cd)) |c| {
                        var common = util.trimRight(c);
                        if (common.len > 0 and common[0] != '/') common = util.normalizePath(util.concat(&.{ p, "/", common })) orelse common;
                        var mainwt = common;
                        if (util.endsWith(mainwt, "/.git")) mainwt = mainwt[0 .. mainwt.len - 5];
                        if (!os.chdir(mainwt)) util.dieErrno("cannot chdir to {s}", .{mainwt});
                        git_dir = common;
                    }
                }
            }
        }
    }
    const bare_v: i32 = if (bare >= 0) bare else guessBare(git_dir.?);
    if (bare_v == 0) {
        if (work_tree == null) {
            if (std.mem.lastIndexOfScalar(u8, git_dir.?, '/')) |sl| {
                const rel = git_dir.?[0..sl];
                work_tree = realOrAbs(if (rel.len == 0) "/" else rel);
            } else {
                work_tree = os.getcwd();
            }
        } else {
            work_tree = realOrAbs(work_tree.?);
        }
        if (!os.access(work_tree.?, 1)) util.dieErrno("Cannot access work tree '{s}'", .{work_tree.?});
    } else if (real_git_dir != null) {
        util.die("--separate-git-dir incompatible with bare repository", .{});
    } else if (work_tree) |wt| {
        work_tree = realOrAbs(wt);
    }
    const is_bare = work_tree == null;
    // read global config (for init.defaultBranch / templateDir)
    repo_mod.repo_ = null;
    repo_mod.loadConfig();
    _ = initDb(.{
        .git_dir = git_dir.?,
        .real_git_dir = real_git_dir,
        .work_tree = if (is_bare) null else work_tree,
        .template = template,
        .initial_branch = initial_branch,
        .shared = shared,
        .quiet = quiet != 0,
        .bare = is_bare,
        .object_format = object_format,
        .ref_format = ref_format,
    });
    return 0;
}

pub var forced_bare = false;
