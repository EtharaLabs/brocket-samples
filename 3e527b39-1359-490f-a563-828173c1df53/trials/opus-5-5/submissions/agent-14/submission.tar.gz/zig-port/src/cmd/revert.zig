//! builtin/revert.c: git revert / git cherry-pick

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const revision = @import("../revision.zig");
const seq = @import("../sequencer.zig");
const branchstate = @import("../branchstate.zig");
const c_commit = @import("commit.zig");

const revert_usage = [_][]const u8{
    "git revert [--[no-]edit] [-n] [-m <parent-number>] [-s] [-S[<keyid>]] <commit>...",
    "git revert (--continue | --skip | --abort | --quit)",
};
const cherry_pick_usage = [_][]const u8{
    "git cherry-pick [--edit] [-n] [-m <parent-number>] [-s] [-x] [--ff]\n                [-S[<keyid>]] <commit>...",
    "git cherry-pick (--continue | --skip | --abort | --quit)",
};

var opts: seq.Opts = .{};
var cmd: u8 = 0;
var cmd_name: []const u8 = "";
var cleanup_arg: ?[]const u8 = null;
var strategy: ?[]const u8 = null;
var strategy_set = false;
var gpg_sign: ?[]const u8 = null;
var gpg_set = false;
var empty_opt: u8 = 0; // 0 unspecified, 's' stop, 'd' drop, 'k' keep
var noop_r = false;

fn setCmd(c: u8, name: []const u8) void {
    if (cmd != 0 and cmd != c) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ name, cmd_name });
        os.exit(129);
    }
    cmd = c;
    cmd_name = name;
}
fn cbQuit(_: ?[]const u8, _: bool) void {
    setCmd('q', "--quit");
}
fn cbContinue(_: ?[]const u8, _: bool) void {
    setCmd('c', "--continue");
}
fn cbAbort(_: ?[]const u8, _: bool) void {
    setCmd('a', "--abort");
}
fn cbSkip(_: ?[]const u8, _: bool) void {
    setCmd('s', "--skip");
}
fn cbEdit(_: ?[]const u8, unset: bool) void {
    opts.edit = if (unset) 0 else 1;
}
fn cbMainline(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        opts.mainline = 0;
        return;
    }
    const a = arg.?;
    const n = std.fmt.parseInt(i32, a, 10) catch 0;
    if (n <= 0) {
        util.err("option `mainline' expects a number greater than zero", .{});
        os.exit(129);
    }
    opts.mainline = n;
}
fn cbRerere(_: ?[]const u8, unset: bool) void {
    opts.allow_rerere_auto = if (unset) seq.RERERE_NOAUTOUPDATE else seq.RERERE_AUTOUPDATE;
}
fn cbStrategy(arg: ?[]const u8, unset: bool) void {
    strategy_set = true;
    strategy = if (unset) null else arg;
}
fn cbGpg(arg: ?[]const u8, unset: bool) void {
    gpg_set = true;
    gpg_sign = if (unset) null else (arg orelse "");
}
fn cbEmpty(arg: ?[]const u8, _: bool) void {
    const a = arg.?;
    if (util.eql(a, "stop")) {
        empty_opt = 's';
    } else if (util.eql(a, "drop")) {
        empty_opt = 'd';
    } else if (util.eql(a, "keep")) {
        empty_opt = 'k';
    } else {
        util.err("invalid value for '{s}': '{s}'", .{ "--empty", a });
        os.exit(129);
    }
}

const base_options = [_]po.Opt{
    .{ .long = "quit", .kind = .callback, .cb = cbQuit, .noarg = true, .noneg = true, .help = "end revert or cherry-pick sequence" },
    .{ .long = "continue", .kind = .callback, .cb = cbContinue, .noarg = true, .noneg = true, .help = "resume revert or cherry-pick sequence" },
    .{ .long = "abort", .kind = .callback, .cb = cbAbort, .noarg = true, .noneg = true, .help = "cancel revert or cherry-pick sequence" },
    .{ .long = "skip", .kind = .callback, .cb = cbSkip, .noarg = true, .noneg = true, .help = "skip current commit and continue" },
    po.string(0, "cleanup", &cleanup_arg, "mode", "how to strip spaces and #comments from message"),
    po.boolean('n', "no-commit", &opts.no_commit, "don't automatically commit"),
    .{ .short = 'e', .long = "edit", .kind = .callback, .cb = cbEdit, .noarg = true, .help = "edit the commit message" },
    .{ .short = 'r', .kind = .boolean, .b = &noop_r, .hidden = true, .help = "no-op (backward compatibility)" },
    po.boolean('s', "signoff", &opts.signoff, "add a Signed-off-by trailer"),
    .{ .short = 'm', .long = "mainline", .kind = .callback, .cb = cbMainline, .argh = "parent-number", .help = "select mainline parent" },
    .{ .long = "rerere-autoupdate", .kind = .callback, .cb = cbRerere, .noarg = true, .help = "update the index with reused conflict resolution if possible" },
    .{ .long = "strategy", .kind = .callback, .cb = cbStrategy, .argh = "strategy", .help = "merge strategy" },
    po.list('X', "strategy-option", &opts.xopts, "option", "option for merge strategy"),
    .{ .short = 'S', .long = "gpg-sign", .kind = .callback, .cb = cbGpg, .optarg = true, .argh = "key-id", .help = "GPG sign commit" },
};

const pick_options = base_options ++ [_]po.Opt{
    po.boolean('x', "", &opts.record_origin, "append commit name"),
    po.boolean(0, "ff", &opts.allow_ff, "allow fast-forward"),
    po.boolean(0, "allow-empty", &opts.allow_empty, "preserve initially empty commits"),
    po.boolean(0, "allow-empty-message", &opts.allow_empty_message, "allow commits with empty messages"),
    po.boolean(0, "keep-redundant-commits", &opts.keep_redundant_commits, "deprecated: use --empty=keep instead"),
    .{ .long = "empty", .kind = .callback, .cb = cbEmpty, .argh = "(stop|drop|keep)", .noneg = true, .literal_argh = true, .help = "how to handle commits that become empty" },
};

const revert_options = base_options ++ [_]po.Opt{
    po.boolean(0, "reference", &opts.commit_use_reference, "use the 'reference' format to refer to commits"),
};

fn verifyOptCompatible(me: []const u8, base_opt: []const u8, pairs: []const struct { []const u8, bool }) void {
    for (pairs) |p| {
        if (p[1]) util.die("{s}: {s} cannot be used with {s}", .{ me, base_opt, p[0] });
    }
}

fn runSequencer(args: []const []const u8, prefix: []const u8) i32 {
    const usage: []const []const u8 = if (opts.action == .revert) &revert_usage else &cherry_pick_usage;
    const options: []const po.Opt = if (opts.action == .pick) &pick_options else &revert_options;
    const me = seq.actionName(&opts);

    const rest = po.parse(args[1..], options, usage, .{ .keep_unknown = true });
    @import("../sparse_index.zig").commandIsSparseAware();

    if (opts.action == .pick) {
        opts.drop_redundant_commits = empty_opt == 'd';
        opts.keep_redundant_commits = opts.keep_redundant_commits or empty_opt == 'k';
    }
    if (opts.keep_redundant_commits) opts.allow_empty = true;
    if (cleanup_arg) |ca| {
        opts.default_msg_cleanup = c_commit.getCleanupMode(ca, true);
        opts.explicit_cleanup = true;
    }

    if (cmd != 0) {
        const this_operation: []const u8 = switch (cmd) {
            'q' => "--quit",
            'c' => "--continue",
            's' => "--skip",
            else => "--abort",
        };
        verifyOptCompatible(me, this_operation, &.{
            .{ "--no-commit", opts.no_commit },
            .{ "--signoff", opts.signoff },
            .{ "--mainline", opts.mainline != 0 },
            .{ "--strategy", opts.strategy != null },
            .{ "--strategy-option", opts.xopts.items.len != 0 },
            .{ "-x", opts.record_origin },
            .{ "--ff", opts.allow_ff },
            .{ "--rerere-autoupdate", opts.allow_rerere_auto == seq.RERERE_AUTOUPDATE },
            .{ "--no-rerere-autoupdate", opts.allow_rerere_auto == seq.RERERE_NOAUTOUPDATE },
            .{ "--keep-redundant-commits", opts.keep_redundant_commits },
            .{ "--empty", empty_opt != 0 },
        });
    }

    if (opts.strategy == null and opts.default_strategy != null) {
        opts.strategy = opts.default_strategy;
        opts.default_strategy = null;
    }

    if (opts.allow_ff) {
        verifyOptCompatible(me, "--ff", &.{
            .{ "--signoff", opts.signoff },
            .{ "--no-commit", opts.no_commit },
            .{ "-x", opts.record_origin },
            .{ "--edit", opts.edit > 0 },
        });
    }

    var leftover: usize = rest.len;
    if (cmd == 0) {
        const revs = util.gpa.create(revision.RevInfo) catch util.oom();
        revs.* = revision.RevInfo.init(prefix);
        revs.no_walk = true;
        revs.unsorted_input = true;
        if (rest.len < 1) po.usageWithOptions(usage, options);
        var argv: std.ArrayList([]const u8) = .empty;
        argv.append(util.gpa, args[0]) catch util.oom();
        for (rest, 0..) |a, i| {
            argv.append(util.gpa, if (i == 0 and util.eql(a, "-")) "@{-1}" else a) catch util.oom();
        }
        const left = revision.setupRevisions(revs, argv.items, .{ .assume_dashdash = true });
        leftover = left.len - 1;
        opts.revs = revs;
    }
    if (leftover > 0) po.usageWithOptions(usage, options);

    if (gpg_set) opts.gpg_sign = gpg_sign;
    if (strategy_set) opts.strategy = strategy;

    switch (cmd) {
        'q' => {
            const ret = seq.removeState(&opts);
            if (ret == 0) branchstate.removeBranchState(false);
            return ret;
        },
        'c' => return seq.sequencerContinue(&opts),
        'a' => return seq.rollback(&opts),
        's' => return seq.skip(&opts),
        else => return seq.pickRevisions(&opts),
    }
}

fn prefixOf() []const u8 {
    return @import("../repo.zig").repo().prefix;
}

pub fn cmdRevert(args: []const []const u8) u8 {
    @import("../comment_char.zig").warnIfAuto();
    opts = .{ .action = .revert };
    seq.initConfig(&opts);
    const res = runSequencer(args, prefixOf());
    if (res < 0) util.die("revert failed", .{});
    return @intCast(res);
}

pub fn cmdCherryPick(args: []const []const u8) u8 {
    @import("../comment_char.zig").warnIfAuto();
    opts = .{ .action = .pick };
    seq.initConfig(&opts);
    const res = runSequencer(args, prefixOf());
    if (res < 0) util.die("cherry-pick failed", .{});
    return @intCast(res);
}
