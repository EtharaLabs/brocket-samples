//! `git add -i` (add-interactive.c): the interactive command menu.
//! Index manipulation is delegated to plumbing child processes.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const proc = @import("proc.zig");
const repo_mod = @import("repo.zig");
const revparse = @import("revparse.zig");
const hash = @import("hash.zig");
const color = @import("color.zig");
const add_patch = @import("add_patch.zig");
const pathspec_mod = @import("pathspec.zig");

const gpa = util.gpa;

const AddDel = struct {
    add: u64 = 0,
    del: u64 = 0,
    seen: bool = false,
    unmerged: bool = false,
    binary: bool = false,
};

const Item = struct {
    name: []const u8,
    prefix_length: usize = 0,
    index: AddDel = .{},
    worktree: AddDel = .{},
};

const ItemList = struct {
    items: std.ArrayList(Item) = .empty,
    /// indices into items, sorted by name
    sorted: std.ArrayList(usize) = .empty,
    selected: []bool = &.{},
    min_length: usize = 1,
    max_length: usize = 4,

    fn clear(self: *ItemList) void {
        self.items = .empty;
        self.sorted = .empty;
        self.selected = &.{};
    }
};

const Cfg = struct {
    use_color: bool = false,
    header: []const u8 = "",
    help: []const u8 = "",
    prompt: []const u8 = "",
    err: []const u8 = "",
    reset: []const u8 = "",
    context: i32 = -1,
    interhunkcontext: i32 = -1,
    auto_advance: bool = true,
};

var cfg: Cfg = .{};
var index_file: []const u8 = "";

fn initColor(slot: []const u8, default: []const u8) []const u8 {
    if (!cfg.use_color) return "";
    if (repo_mod.cfg.get(util.concat(&.{ "color.", slot }))) |v| {
        if (color.parseColor(v)) |c| return c;
    }
    return default;
}

fn initConfig(opts: add_patch.Options) void {
    var cb: color.ColorBool = .unknown;
    if (repo_mod.cfg.getEntry("color.interactive")) |e| cb = color.configColorBool("color.interactive", e.value);
    if (cb == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| cb = color.configColorBool("color.ui", e.value);
    }
    cfg.use_color = color.wantColorBool(cb, null);
    cfg.header = initColor("interactive.header", color.BOLD);
    cfg.help = initColor("interactive.help", color.BOLD_RED);
    cfg.prompt = initColor("interactive.prompt", color.BOLD_BLUE);
    cfg.err = initColor("interactive.error", color.BOLD_RED);
    cfg.reset = if (cfg.use_color) color.RESET else "";
    if (repo_mod.cfg.getInt("diff.context")) |c| {
        if (c < 0) util.die("{s} cannot be negative", .{"diff.context"});
        cfg.context = @intCast(c);
    }
    if (repo_mod.cfg.getInt("diff.interhunkcontext")) |c| {
        if (c < 0) util.die("{s} cannot be negative", .{"diff.interHunkContext"});
        cfg.interhunkcontext = @intCast(c);
    }
    if (opts.context != -1) {
        if (opts.context < 0) util.die("{s} cannot be negative", .{"--unified"});
        cfg.context = opts.context;
    }
    if (opts.interhunkcontext != -1) {
        if (opts.interhunkcontext < 0) util.die("{s} cannot be negative", .{"--inter-hunk-context"});
        cfg.interhunkcontext = opts.interhunkcontext;
    }
    cfg.auto_advance = opts.auto_advance;
}

/// color_fprintf_ln() to stdout
fn colorLn(c: []const u8, s: []const u8) void {
    if (c.len > 0) {
        util.out(c);
        util.out(s);
        util.out(color.RESET);
    } else util.out(s);
    util.out("\n");
}

fn colorLnErr(c: []const u8, s: []const u8) void {
    if (c.len > 0) {
        util.eprint("{s}{s}{s}\n", .{ c, s, color.RESET });
    } else util.eprint("{s}\n", .{s});
}

fn runGit(args: []const []const u8, stdin_data: ?[]const u8, capture: bool) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    const env = [_][2][]const u8{.{ "GIT_INDEX_FILE", index_file }};
    return os.run(argv.items, .{ .env = &env, .stdin_data = stdin_data, .capture_stdout = capture });
}

// ---------------- prefix item list ----------------

fn lessThanName(list: *const ItemList, a: usize, b: usize) bool {
    return std.mem.order(u8, list.items.items[a].name, list.items.items[b].name) == .lt;
}

fn extendPrefixLength(item: *Item, other: []const u8, max_length: usize) void {
    const len = &item.prefix_length;
    if (len.* == 0 or other.len < len.* or !std.mem.eql(u8, item.name[0..len.*], other[0..len.*])) return;
    while (true) {
        const c: u8 = if (len.* < item.name.len) item.name[len.*] else 0;
        len.* += 1;
        if (c == 0 or len.* > max_length or c >= 0x80) {
            len.* = 0;
            break;
        }
        const oc: u8 = if (len.* - 1 < other.len) other[len.* - 1] else 0;
        if (c != oc) break;
    }
}

fn findUniquePrefixes(list: *ItemList) void {
    if (list.sorted.items.len == list.items.items.len) return;
    list.sorted = .empty;
    for (0..list.items.items.len) |i| list.sorted.append(gpa, i) catch util.oom();
    std.mem.sort(usize, list.sorted.items, @as(*const ItemList, list), lessThanName);
    const n = list.sorted.items.len;
    for (0..n) |i| {
        const item = &list.items.items[list.sorted.items[i]];
        item.prefix_length = 0;
        while (item.prefix_length < list.min_length) {
            const c: u8 = if (item.prefix_length < item.name.len) item.name[item.prefix_length] else 0;
            item.prefix_length += 1;
            if (c == 0 or c >= 0x80) {
                item.prefix_length = 0;
                break;
            }
        }
        if (i > 0) extendPrefixLength(item, list.items.items[list.sorted.items[i - 1]].name, list.max_length);
        if (i + 1 < n) extendPrefixLength(item, list.items.items[list.sorted.items[i + 1]].name, list.max_length);
    }
}

fn findUnique(s: []const u8, list: *const ItemList) ?usize {
    const sorted = list.sorted.items;
    const names = list.items.items;
    // string_list_find_insert_index
    var index: usize = 0;
    var exact = false;
    while (index < sorted.len) : (index += 1) {
        const o = std.mem.order(u8, names[sorted[index]].name, s);
        if (o == .eq) {
            exact = true;
            break;
        }
        if (o == .gt) break;
    }
    if (exact) return sorted[index];
    if (index > 0 and util.startsWith(names[sorted[index - 1]].name, s)) return null;
    if (index + 1 < sorted.len and util.startsWith(names[sorted[index + 1]].name, s)) return null;
    if (index < sorted.len and util.startsWith(names[sorted[index]].name, s)) return sorted[index];
    return null;
}

fn isValidPrefix(name: []const u8, len: usize) bool {
    if (len == 0) return false;
    const sep = std.mem.indexOfAny(u8, name, " \t\r\n,") orelse name.len;
    if (sep < len) return false;
    if (name.len == 0) return false;
    if (name[0] == '-' or std.ascii.isDigit(name[0])) return false;
    if (len == 1 and (name[0] == '*' or name[0] == '?')) return false;
    return true;
}

// ---------------- list / list_and_choose ----------------

const PrintKind = enum { command, file, name_only };

const ListOpts = struct {
    columns: usize = 0,
    header: ?[]const u8 = null,
    kind: PrintKind = .file,
};

fn highlighted(item: *const Item, hl_color: []const u8, hl_reset: []const u8) []const u8 {
    if (item.prefix_length > 0 and isValidPrefix(item.name, item.prefix_length))
        return util.concat(&.{ hl_color, item.name[0..item.prefix_length], hl_reset, item.name[item.prefix_length..] });
    return item.name;
}

fn renderAddDel(ad: *const AddDel, no_changes: []const u8) []const u8 {
    if (ad.binary) return "binary";
    if (ad.seen) return util.fmt("+{d}/-{d}", .{ ad.add, ad.del });
    return no_changes;
}

fn hlColor() []const u8 {
    return if (cfg.use_color) cfg.prompt else "[";
}
fn hlReset() []const u8 {
    return if (cfg.use_color) cfg.reset else "]";
}

fn printItem(i: usize, selected: bool, item: *const Item, kind: PrintKind) void {
    switch (kind) {
        .command => {
            if (item.prefix_length == 0 or !isValidPrefix(item.name, item.prefix_length)) {
                util.outf(" {d:>2}: {s}", .{ i + 1, item.name });
            } else util.outf(" {d:>2}: {s}", .{ i + 1, highlighted(item, hlColor(), hlReset()) });
        },
        .name_only => util.outf("{c}{d:>2}: {s}", .{ @as(u8, if (selected) '*' else ' '), i + 1, highlighted(item, hlColor(), hlReset()) }),
        .file => {
            const wt = renderAddDel(&item.worktree, "nothing");
            const ix = renderAddDel(&item.index, "unchanged");
            util.outf("{c}{d:>2}: {s:>12} {s:>12} {s}", .{ @as(u8, if (selected) '*' else ' '), i + 1, ix, wt, highlighted(item, hlColor(), hlReset()) });
        },
    }
}

fn listItems(l: *const ItemList, selected: []const bool, opts: ListOpts) void {
    if (l.items.items.len == 0) return;
    if (opts.header) |h| colorLn(cfg.header, h);
    var last_lf = false;
    for (l.items.items, 0..) |*it, i| {
        printItem(i, if (selected.len > i) selected[i] else false, it, opts.kind);
        if (opts.columns != 0 and (i + 1) % opts.columns != 0) {
            util.out("\t");
            last_lf = false;
        } else {
            util.out("\n");
            last_lf = true;
        }
    }
    if (!last_lf) util.out("\n");
}

const SINGLETON: u32 = 1;
const IMMEDIATE: u32 = 2;
const LAC_ERROR: i64 = -1;
const LAC_QUIT: i64 = -2;

const HelpKind = enum { command, choose };

const ChooseOpts = struct {
    list: ListOpts = .{},
    prompt: []const u8 = "",
    flags: u32 = 0,
    help: HelpKind = .choose,
};

fn printHelp(kind: HelpKind) void {
    const h = cfg.help;
    colorLn(h, "Prompt help:");
    switch (kind) {
        .command => {
            colorLn(h, "1          - select a numbered item");
            colorLn(h, "foo        - select item based on unique prefix");
            colorLn(h, "           - (empty) select nothing");
        },
        .choose => {
            colorLn(h, "1          - select a single item");
            colorLn(h, "3-5        - select a range of items");
            colorLn(h, "2-3,6-9    - select multiple ranges");
            colorLn(h, "foo        - select item based on unique prefix");
            colorLn(h, "-...       - unselect specified items");
            colorLn(h, "*          - choose all items");
            colorLn(h, "           - (empty) finish selecting");
        },
    }
}

fn parseUl(b: []const u8, pos: *usize) i64 {
    var v: i64 = 0;
    while (pos.* < b.len and std.ascii.isDigit(b[pos.*])) : (pos.* += 1) {
        v = v *| 10 +| @as(i64, b[pos.*] - '0');
    }
    return v;
}

fn listAndChoose(items: *ItemList, opts: *const ChooseOpts) i64 {
    const singleton = opts.flags & SINGLETON != 0;
    const immediate = opts.flags & IMMEDIATE != 0;
    var res: i64 = if (singleton) LAC_ERROR else 0;
    if (!singleton) {
        items.selected = gpa.alloc(bool, items.items.items.len) catch util.oom();
        @memset(items.selected, false);
    }
    findUniquePrefixes(items);
    var input: util.Buf = .empty;
    const nr: i64 = @intCast(items.items.items.len);
    while (true) {
        listItems(items, items.selected, opts.list);
        if (cfg.prompt.len > 0) {
            util.out(cfg.prompt);
            util.out(opts.prompt);
            util.out(color.RESET);
        } else util.out(opts.prompt);
        util.out(if (singleton) "> " else ">> ");
        if (!add_patch.readLine(&input)) {
            util.out("\n");
            if (immediate) res = LAC_QUIT;
            break;
        }
        if (input.items.len == 0) break;
        if (util.eql(input.items, "?")) {
            printHelp(opts.help);
            continue;
        }
        const buf = input.items; // mutable; NULs get inserted like C
        var p: usize = 0;
        while (true) {
            const rest = buf[p..];
            const end0 = std.mem.indexOfScalar(u8, rest, 0) orelse rest.len;
            var sep = std.mem.indexOfAny(u8, rest[0..end0], " \t\r\n,") orelse end0;
            var choose = true;
            var from: i64 = -1;
            var to: i64 = -1;
            if (sep == 0) {
                if (end0 == 0) break;
                p += 1;
                continue;
            }
            if (buf[p] == '-') {
                choose = false;
                p += 1;
                sep -= 1;
            }
            if (sep == 1 and buf[p] == '*') {
                from = 0;
                to = nr;
            } else if (p < buf.len and std.ascii.isDigit(buf[p])) {
                var endp = p;
                from = parseUl(buf, &endp) - 1;
                if (endp == p + sep) {
                    to = from + 1;
                } else if (endp < buf.len and buf[endp] == '-') {
                    endp += 1;
                    if (endp < buf.len and std.ascii.isDigit(buf[endp])) {
                        to = parseUl(buf, &endp);
                    } else to = nr;
                    if (endp != p + sep) from = -1;
                }
            }
            const tok = buf[p .. p + sep];
            if (p + sep < buf.len and buf[p + sep] != 0) {
                buf[p + sep] = 0;
                sep += 1;
            }
            if (from < 0) {
                if (findUnique(tok, items)) |f| {
                    from = @intCast(f);
                    to = from + 1;
                }
            }
            if (from < 0 or from >= nr or (singleton and from + 1 != to)) {
                colorLnErr(cfg.err, util.fmt("Huh ({s})?", .{tok}));
                break;
            } else if (singleton) {
                res = from;
                break;
            }
            if (to > nr) to = nr;
            while (from < to) : (from += 1) {
                const f: usize = @intCast(from);
                if (items.selected[f] != choose) {
                    items.selected[f] = choose;
                    res += if (choose) 1 else -1;
                }
            }
            p += sep;
        }
        const first = std.mem.indexOfScalar(u8, buf, 0) orelse buf.len;
        if ((immediate and res != LAC_ERROR) or util.eql(buf[0..first], "*")) break;
    }
    return res;
}

// ---------------- collecting files ----------------

const Filter = enum { none, worktree_only, index_only };

fn headTreeish() []const u8 {
    if (revparse.getOid("HEAD")) |o| return hash.hexAlloc(o);
    return hash.empty_tree_hex;
}

fn findItem(l: *ItemList, name: []const u8) ?*Item {
    for (l.items.items) |*it| if (util.eql(it.name, name)) return it;
    return null;
}

fn unmergedPaths(ps: []const []const u8) std.StringHashMapUnmanaged(void) {
    var set: std.StringHashMapUnmanaged(void) = .empty;
    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, &.{ "ls-files", "-u", "-z", "--" }) catch util.oom();
    args.appendSlice(gpa, ps) catch util.oom();
    const r = runGit(args.items, null, true);
    var it = std.mem.splitScalar(u8, r.stdout, 0);
    while (it.next()) |rec| {
        const tab = std.mem.indexOfScalar(u8, rec, '\t') orelse continue;
        set.put(gpa, rec[tab + 1 ..], {}) catch util.oom();
    }
    return set;
}

fn getModifiedFiles(filter: Filter, files: *ItemList, ps: []const []const u8, unmerged_count: ?*usize, binary_count: ?*usize) void {
    files.clear();
    var nu: usize = 0;
    var nb: usize = 0;
    var unmerged = unmergedPaths(ps);
    for (0..2) |i| {
        const from_index = if (filter == .index_only) i == 0 else i == 1;
        const skip_unseen = filter != .none and i == 1;
        var args: std.ArrayList([]const u8) = .empty;
        if (from_index) {
            args.appendSlice(gpa, &.{ "diff-index", "--cached", "--numstat", "-z", "--no-renames", headTreeish() }) catch util.oom();
        } else {
            args.appendSlice(gpa, &.{ "diff-files", "--numstat", "-z", "--no-renames", "--ignore-submodules=dirty" }) catch util.oom();
        }
        args.append(gpa, "--") catch util.oom();
        args.appendSlice(gpa, ps) catch util.oom();
        const r = runGit(args.items, null, true);
        var it = std.mem.splitScalar(u8, r.stdout, 0);
        while (it.next()) |rec| {
            if (rec.len == 0) continue;
            const t1 = std.mem.indexOfScalar(u8, rec, '\t') orelse continue;
            const t2 = std.mem.indexOfScalarPos(u8, rec, t1 + 1, '\t') orelse continue;
            const name = rec[t2 + 1 ..];
            const is_binary = rec[0] == '-';
            const item = findItem(files, name) orelse blk: {
                if (skip_unseen) break :blk null;
                files.items.append(gpa, .{ .name = gpa.dupe(u8, name) catch util.oom() }) catch util.oom();
                break :blk &files.items.items[files.items.items.len - 1];
            } orelse continue;
            const ad = if (from_index) &item.index else &item.worktree;
            const other = if (from_index) &item.worktree else &item.index;
            ad.seen = true;
            ad.add = std.fmt.parseInt(u64, rec[0..t1], 10) catch 0;
            ad.del = std.fmt.parseInt(u64, rec[t1 + 1 .. t2], 10) catch 0;
            if (is_binary) {
                if (!other.binary) nb += 1;
                ad.binary = true;
            }
            if (unmerged.contains(name)) {
                if (!other.unmerged) nu += 1;
                ad.unmerged = true;
                ad.add = 0;
                ad.del = 0;
            }
        }
    }
    if (unmerged_count) |u| u.* = nu;
    if (binary_count) |b| b.* = nb;
    std.mem.sort(Item, files.items.items, {}, struct {
        fn lt(_: void, a: Item, b: Item) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
}

fn selectedNames(files: *const ItemList) std.ArrayList([]const u8) {
    var names: std.ArrayList([]const u8) = .empty;
    for (files.items.items, 0..) |it, i| {
        if (i < files.selected.len and files.selected[i]) names.append(gpa, it.name) catch util.oom();
    }
    return names;
}

// ---------------- commands ----------------

fn runStatus(ps: []const []const u8, files: *ItemList, opts: *ChooseOpts) i32 {
    getModifiedFiles(.none, files, ps, null, null);
    listItems(files, &.{}, opts.list);
    util.out("\n");
    return 0;
}

fn runUpdate(ps: []const []const u8, files: *ItemList, opts: *ChooseOpts) i32 {
    getModifiedFiles(.worktree_only, files, ps, null, null);
    if (files.items.items.len == 0) {
        util.out("\n");
        return 0;
    }
    opts.prompt = "Update";
    const count = listAndChoose(files, opts);
    if (count <= 0) {
        util.out("\n");
        return 0;
    }
    var res: i32 = 0;
    const names = selectedNames(files);
    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, &.{ "update-index", "--add", "--remove", "--" }) catch util.oom();
    args.appendSlice(gpa, names.items) catch util.oom();
    if (runGit(args.items, null, false).status != 0) {
        util.err("could not write index", .{});
        res = -1;
    }
    if (res == 0) util.outf("updated {d} path{s}\n", .{ count, if (count == 1) "" else "s" });
    util.out("\n");
    return res;
}

fn literal(names: []const []const u8) []const []const u8 {
    var out: std.ArrayList([]const u8) = .empty;
    for (names) |n| out.append(gpa, util.concat(&.{ ":(literal)", n })) catch util.oom();
    return out.items;
}

fn runRevert(ps: []const []const u8, files: *ItemList, opts: *ChooseOpts) i32 {
    getModifiedFiles(.index_only, files, ps, null, null);
    if (files.items.items.len == 0) {
        util.out("\n");
        return 0;
    }
    opts.prompt = "Revert";
    var res: i32 = 0;
    const count = listAndChoose(files, opts);
    if (count > 0) blk: {
        const tree = headTreeish();
        const names = selectedNames(files);
        var args: std.ArrayList([]const u8) = .empty;
        args.appendSlice(gpa, &.{ "diff-index", "--cached", "--raw", "-z", "--no-renames", "--ignore-submodules=none", tree, "--" }) catch util.oom();
        args.appendSlice(gpa, literal(names.items)) catch util.oom();
        const d = runGit(args.items, null, true);
        if (d.status != 0) {
            res = -1;
            break :blk;
        }
        var info: util.Buf = .empty;
        var it = std.mem.splitScalar(u8, d.stdout, 0);
        while (it.next()) |meta| {
            if (meta.len == 0 or meta[0] != ':') continue;
            const path = it.next() orelse break;
            var f = std.mem.tokenizeScalar(u8, meta[1..], ' ');
            const omode = f.next() orelse continue;
            _ = f.next();
            const ooid = f.next() orelse continue;
            const null_oid = std.mem.indexOfNone(u8, ooid, "0") == null;
            if (util.eql(omode, "000000") or null_oid) {
                util.bufAppend(&info, util.fmt("0 {s}\t{s}\n", .{ ooid, path }));
                util.outf("note: {s} is untracked now.\n", .{path});
            } else {
                util.bufAppend(&info, util.fmt("{s} {s}\t{s}\n", .{ omode, ooid, path }));
            }
        }
        if (runGit(&.{ "update-index", "--index-info" }, info.items, false).status != 0) {
            res = -1;
        } else {
            _ = runGit(&.{ "update-index", "-q", "--refresh" }, null, false);
        }
        if (res == 0) util.outf("reverted {d} path{s}\n", .{ count, if (count == 1) "" else "s" });
    }
    util.out("\n");
    return res;
}

fn runAddUntracked(ps: []const []const u8, files: *ItemList, opts: *ChooseOpts) i32 {
    files.clear();
    var res: i32 = 0;
    {
        var args: std.ArrayList([]const u8) = .empty;
        args.appendSlice(gpa, &.{ "ls-files", "-o", "--exclude-standard", "-z", "--" }) catch util.oom();
        args.appendSlice(gpa, ps) catch util.oom();
        const r = runGit(args.items, null, true);
        var it = std.mem.splitScalar(u8, r.stdout, 0);
        while (it.next()) |n| {
            if (n.len == 0) continue;
            files.items.append(gpa, .{ .name = n }) catch util.oom();
        }
    }
    if (files.items.items.len == 0) {
        util.out("No untracked files.\n");
    } else {
        opts.prompt = "Add untracked";
        const saved = opts.list.kind;
        opts.list.kind = .name_only;
        const count = listAndChoose(files, opts);
        opts.list.kind = saved;
        if (count > 0) {
            const names = selectedNames(files);
            var args: std.ArrayList([]const u8) = .empty;
            args.appendSlice(gpa, &.{ "update-index", "--add", "--" }) catch util.oom();
            args.appendSlice(gpa, names.items) catch util.oom();
            if (runGit(args.items, null, false).status != 0) {
                util.err("could not write index", .{});
                res = -1;
            }
            if (res == 0) util.outf("added {d} path{s}\n", .{ count, if (count == 1) "" else "s" });
        }
    }
    util.out("\n");
    return res;
}

fn runPatch(ps: []const []const u8, files: *ItemList, opts: *ChooseOpts) i32 {
    var unmerged_count: usize = 0;
    var binary_count: usize = 0;
    getModifiedFiles(.worktree_only, files, ps, &unmerged_count, &binary_count);
    if (unmerged_count > 0 or binary_count > 0) {
        var j: usize = 0;
        for (files.items.items) |it| {
            if (it.index.binary or it.worktree.binary) continue;
            if (it.index.unmerged or it.worktree.unmerged) {
                colorLnErr(cfg.err, util.fmt("ignoring unmerged: {s}", .{it.name}));
                continue;
            }
            files.items.items[j] = it;
            j += 1;
        }
        files.items.items.len = j;
    }
    if (files.items.items.len == 0) {
        if (binary_count > 0) {
            util.eprint("Only binary files changed.\n", .{});
        } else util.eprint("No changes.\n", .{});
        return 0;
    }
    opts.prompt = "Patch update";
    const count = listAndChoose(files, opts);
    if (count > 0) {
        const names = selectedNames(files);
        const popts = add_patch.Options{ .context = cfg.context, .interhunkcontext = cfg.interhunkcontext, .auto_advance = cfg.auto_advance };
        return add_patch.run(.add, popts, null, index_file, names.items, 0);
    }
    return 0;
}

fn runDiff(ps: []const []const u8, files: *ItemList, opts: *ChooseOpts) i32 {
    getModifiedFiles(.index_only, files, ps, null, null);
    if (files.items.items.len == 0) {
        util.out("\n");
        return 0;
    }
    opts.prompt = "Review diff";
    opts.flags = IMMEDIATE;
    const count = listAndChoose(files, opts);
    opts.flags = 0;
    var res: i32 = 0;
    if (count > 0) {
        var args: std.ArrayList([]const u8) = .empty;
        args.appendSlice(gpa, &.{ "diff", "-p", "--cached" }) catch util.oom();
        if (cfg.context != -1) args.append(gpa, util.fmt("--unified={d}", .{cfg.context})) catch util.oom();
        if (cfg.interhunkcontext != -1) args.append(gpa, util.fmt("--inter-hunk-context={d}", .{cfg.interhunkcontext})) catch util.oom();
        args.appendSlice(gpa, &.{ headTreeish(), "--" }) catch util.oom();
        args.appendSlice(gpa, selectedNames(files).items) catch util.oom();
        res = runGit(args.items, null, false).status;
    }
    util.out("\n");
    return res;
}

fn runHelp() i32 {
    const h = cfg.help;
    colorLn(h, "status        - show paths with changes");
    colorLn(h, "update        - add working tree state to the staged set of changes");
    colorLn(h, "revert        - revert staged set of changes back to the HEAD version");
    colorLn(h, "patch         - pick hunks and update selectively");
    colorLn(h, "diff          - view diff between HEAD and index");
    colorLn(h, "add untracked - add contents of untracked files to the staged set of changes");
    return 0;
}

const Command = enum { status, update, revert, add_untracked, patch, diff, quit, help };

/// run_add_i()
pub fn run(ps: *const pathspec_mod.Pathspec, opts: add_patch.Options) i32 {
    const r = repo_mod.repo();
    if (r.work_tree) |wt| {
        if (!util.eql(os.getcwd(), wt)) _ = repo_mod.chdirNotify(wt);
    }
    index_file = add_patch.index_override orelse r.indexPath();
    var psargs: std.ArrayList([]const u8) = .empty;
    for (ps.items) |it| psargs.append(gpa, it.original) catch util.oom();
    const pa = psargs.items;

    initConfig(opts);
    var commands = ItemList{};
    const command_names = [_][]const u8{ "status", "update", "revert", "add untracked", "patch", "diff", "quit", "help" };
    for (command_names) |n| commands.items.append(gpa, .{ .name = n }) catch util.oom();
    const main_opts = ChooseOpts{
        .list = .{ .columns = 4, .header = "*** Commands ***", .kind = .command },
        .prompt = "What now",
        .flags = SINGLETON | IMMEDIATE,
        .help = .command,
    };
    var fopts = ChooseOpts{
        .list = .{ .columns = 0, .header = util.fmt("     {s:>12} {s:>12} {s}", .{ "staged", "unstaged", "path" }), .kind = .file },
    };
    var files = ItemList{};

    // unmerged or modified entries only make refresh_index() report 1,
    // which repo_refresh_and_write_index() does not treat as failure.
    _ = runGit(&.{ "update-index", "-q", "--refresh" }, null, false);

    var res = runStatus(pa, &files, &fopts);
    while (true) {
        const i = listAndChoose(&commands, &main_opts);
        const cmd: ?Command = if (i < 0 or i >= commands.items.items.len) null else @enumFromInt(@as(usize, @intCast(i)));
        if (i == LAC_QUIT or cmd == .quit) {
            util.out("Bye.\n");
            res = 0;
            break;
        }
        if (cmd) |c| res = switch (c) {
            .status => runStatus(pa, &files, &fopts),
            .update => runUpdate(pa, &files, &fopts),
            .revert => runRevert(pa, &files, &fopts),
            .add_untracked => runAddUntracked(pa, &files, &fopts),
            .patch => runPatch(pa, &files, &fopts),
            .diff => runDiff(pa, &files, &fopts),
            .help => runHelp(),
            .quit => unreachable,
        };
    }
    return res;
}
