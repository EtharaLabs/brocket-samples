//! Long-running filter process protocol (filter.<driver>.process), port of the
//! multi-file filter part of convert.c + sub-process.c + pkt-line.c.
//!
//! API:
//!   apply(path, src, cmd, cap, meta, dco) ?[]const u8
//!     cap: CAP_CLEAN or CAP_SMUDGE. Returns filtered content ("" when the
//!     filter delayed the path, which is then recorded in dco) or null on
//!     failure (errors already reported as git does).
//!   queryAvailableBlobs(cmd, *list) bool   // async_query_available_blobs()
const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const convert = @import("convert.zig");
const gpa = util.gpa;

extern "c" fn fork() c_int;
extern "c" fn pipe(fds: *[2]c_int) c_int;
extern "c" fn dup2(a: c_int, b: c_int) c_int;
extern "c" fn execvp(file: [*:0]const u8, argv: [*:null]const ?[*:0]const u8) c_int;
extern "c" fn close(fd: c_int) c_int;
extern "c" fn read(fd: c_int, buf: [*]u8, n: usize) isize;
extern "c" fn write(fd: c_int, buf: [*]const u8, n: usize) isize;
extern "c" fn waitpid(pid: c_int, status: *c_int, opts: c_int) c_int;
extern "c" fn kill(pid: c_int, sig: c_int) c_int;
extern "c" fn _exit(code: c_int) noreturn;
extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn atexit(f: *const fn () callconv(.c) void) c_int;
extern "c" fn __errno_location() *c_int;

pub const CAP_CLEAN: u32 = 1;
pub const CAP_SMUDGE: u32 = 2;
pub const CAP_DELAY: u32 = 4;

const LARGE_PACKET_DATA_MAX: usize = 65520 - 4;

const Proc = struct {
    cmd: []const u8,
    pid: c_int,
    in_fd: c_int, // we write here
    out_fd: c_int, // we read here
    caps: u32,
    rbuf: [8192]u8 = undefined,
    rpos: usize = 0,
    rlen: usize = 0,
    alive: bool = true,
};

var procs: std.ArrayList(*Proc) = .empty;
var atexit_registered = false;

/// subprocess_exit_handler(): closing the pipes signals the filter to shut
/// down; then wait for it.
fn exitHandler() callconv(.c) void {
    for (procs.items) |p| {
        if (!p.alive) continue;
        p.alive = false;
        _ = close(p.in_fd);
        _ = close(p.out_fd);
        waitChild(p.pid);
    }
}

fn waitChild(pid: c_int) void {
    var st: c_int = 0;
    while (waitpid(pid, &st, 0) < 0 and __errno_location().* == 4) {}
}

/// subprocess_stop(): SIGTERM + finish_command, and forget the entry.
fn stopProc(p: *Proc) void {
    if (p.alive) {
        p.alive = false;
        _ = kill(p.pid, 15);
        _ = close(p.in_fd);
        _ = close(p.out_fd);
        waitChild(p.pid);
    }
    for (procs.items, 0..) |q, i| {
        if (q == p) {
            _ = procs.orderedRemove(i);
            break;
        }
    }
}

// ---------------- pkt-line ----------------

fn writeAllFd(fd: c_int, data: []const u8) bool {
    var off: usize = 0;
    while (off < data.len) {
        const n = write(fd, data[off..].ptr, data.len - off);
        if (n < 0) {
            if (__errno_location().* == 4) continue;
            return false;
        }
        if (n == 0) return false;
        off += @intCast(n);
    }
    return true;
}

fn pktWrite(p: *Proc, data: []const u8) bool {
    var hdr: [4]u8 = undefined;
    _ = std.fmt.bufPrint(&hdr, "{x:0>4}", .{data.len + 4}) catch unreachable;
    var buf: util.Buf = .empty;
    buf.appendSlice(gpa, &hdr) catch util.oom();
    buf.appendSlice(gpa, data) catch util.oom();
    return writeAllFd(p.in_fd, buf.items);
}

fn pktLine(p: *Proc, line: []const u8) bool {
    return pktWrite(p, util.concat(&.{ line, "\n" }));
}

fn pktFlush(p: *Proc) bool {
    return writeAllFd(p.in_fd, "0000");
}

fn pktContent(p: *Proc, data: []const u8) bool {
    var off: usize = 0;
    while (off < data.len) {
        const n = @min(LARGE_PACKET_DATA_MAX, data.len - off);
        if (!pktWrite(p, data[off .. off + n])) return false;
        off += n;
    }
    return true;
}

fn readExact(p: *Proc, out: []u8) bool {
    var got: usize = 0;
    while (got < out.len) {
        if (p.rpos == p.rlen) {
            const n = read(p.out_fd, &p.rbuf, p.rbuf.len);
            if (n < 0) {
                if (__errno_location().* == 4) continue;
                return false;
            }
            if (n == 0) return false;
            p.rpos = 0;
            p.rlen = @intCast(n);
        }
        const k = @min(out.len - got, p.rlen - p.rpos);
        @memcpy(out[got .. got + k], p.rbuf[p.rpos .. p.rpos + k]);
        p.rpos += k;
        got += k;
    }
    return true;
}

const Pkt = union(enum) { flush, data: []u8, eof };

/// packet_read() with PACKET_READ_GENTLE_ON_EOF; dies on malformed lengths
/// (like pkt-line.c) and, when !gentle, on EOF.
fn pktReadMode(p: *Proc, gentle: bool) Pkt {
    var hdr: [4]u8 = undefined;
    if (!readExact(p, &hdr)) {
        if (!gentle) util.die("the remote end hung up unexpectedly", .{});
        return .eof;
    }
    const len = std.fmt.parseInt(usize, &hdr, 16) catch
        util.die("protocol error: bad line length character: {s}", .{hdr[0..]});
    if (len == 0) return .flush;
    if (len < 4) util.die("protocol error: bad line length {d}", .{len});
    const d = gpa.alloc(u8, len - 4) catch util.oom();
    if (!readExact(p, d)) {
        if (!gentle) util.die("the remote end hung up unexpectedly", .{});
        return .eof;
    }
    return .{ .data = d };
}

fn pktRead(p: *Proc) Pkt {
    return pktReadMode(p, true);
}

/// Read a text line (trailing newline stripped); null on flush; error on eof.
fn pktReadLine(p: *Proc) error{Eof}!?[]const u8 {
    switch (pktRead(p)) {
        .flush => return null,
        .eof => return error.Eof,
        .data => |d| {
            var s: []const u8 = d;
            if (s.len > 0 and s[s.len - 1] == '\n') s = s[0 .. s.len - 1];
            return s;
        },
    }
}

// ---------------- process start / handshake ----------------

const shell_meta = "|&;<>()$`\\\"' \t\n*?[#~=%";

fn spawn(cmd: []const u8) ?*Proc {
    util.flushStdout();
    var argv_list: std.ArrayList([]const u8) = .empty;
    if (std.mem.indexOfAny(u8, cmd, shell_meta) == null) {
        // run directly; start_command() reports a missing program itself
        if (cmd.len == 0 or !@import("gpg.zig").findProgram(cmd)) {
            util.err("cannot run {s}: No such file or directory", .{cmd});
            return null;
        }
        argv_list.append(gpa, cmd) catch util.oom();
    } else {
        argv_list.appendSlice(gpa, &.{ "/bin/sh", "-c", cmd, cmd }) catch util.oom();
    }
    var in_pipe: [2]c_int = .{ -1, -1 };
    var out_pipe: [2]c_int = .{ -1, -1 };
    if (pipe(&in_pipe) != 0) return null;
    if (pipe(&out_pipe) != 0) return null;
    const cargv = gpa.allocSentinel(?[*:0]const u8, argv_list.items.len, null) catch util.oom();
    for (argv_list.items, 0..) |a, i| cargv[i] = os.z(a);
    const pid = fork();
    if (pid < 0) return null;
    if (pid == 0) {
        _ = dup2(in_pipe[0], 0);
        _ = dup2(out_pipe[1], 1);
        _ = close(in_pipe[0]);
        _ = close(in_pipe[1]);
        _ = close(out_pipe[0]);
        _ = close(out_pipe[1]);
        _ = signal(13, 0); // SIGPIPE back to default for the child
        _ = execvp(cargv[0].?, cargv.ptr);
        util.eprint("error: cannot run {s}: No such file or directory\n", .{argv_list.items[0]});
        _exit(127);
    }
    _ = close(in_pipe[0]);
    _ = close(out_pipe[1]);
    const p = gpa.create(Proc) catch util.oom();
    p.* = .{ .cmd = cmd, .pid = pid, .in_fd = in_pipe[1], .out_fd = out_pipe[0], .caps = 0 };
    return p;
}

fn flushOr(line: ?[]const u8) []const u8 {
    return line orelse "<flush packet>";
}

/// handshake_version() + handshake_capabilities(); false on error (already reported).
fn handshake(p: *Proc) bool {
    if (!pktLine(p, "git-filter-client")) {
        util.err("Could not write client identification", .{});
        return false;
    }
    if (!pktLine(p, "version=2")) {
        util.err("Could not write requested version", .{});
        return false;
    }
    if (!pktFlush(p)) {
        util.err("Could not write flush packet", .{});
        return false;
    }
    const welcome = pktReadLine(p) catch {
        util.err("could not read greeting from subprocess '{s}'", .{p.cmd});
        return false;
    };
    if (welcome == null or !util.eql(welcome.?, "git-filter-server")) {
        util.err("Unexpected line '{s}', expected git-filter-server", .{flushOr(welcome)});
        return false;
    }
    const vline = pktReadLine(p) catch {
        util.err("could not read version from subprocess '{s}'", .{p.cmd});
        return false;
    };
    var version: i64 = 0;
    if (vline == null or !util.startsWith(vline.?, "version=") or blk: {
        version = std.fmt.parseInt(i32, vline.?["version=".len..], 10) catch break :blk true;
        break :blk false;
    }) {
        util.err("Unexpected line '{s}', expected version", .{flushOr(vline)});
        return false;
    }
    const fl = pktReadLine(p) catch {
        util.err("could not read version flush from subprocess '{s}'", .{p.cmd});
        return false;
    };
    if (fl) |l| {
        util.err("Unexpected line '{s}', expected flush", .{l});
        return false;
    }
    if (version != 2) {
        util.err("Version {d} not supported", .{version});
        return false;
    }

    for ([_][]const u8{ "capability=clean", "capability=smudge", "capability=delay" }) |c| {
        if (!pktLine(p, c)) {
            util.err("Could not write requested capability", .{});
            return false;
        }
    }
    if (!pktFlush(p)) {
        util.err("Could not write flush packet", .{});
        return false;
    }
    while (true) {
        const l = (pktReadLine(p) catch {
            util.err("could not read capabilities from subprocess '{s}'", .{p.cmd});
            return false;
        }) orelse break;
        if (!util.startsWith(l, "capability=")) continue;
        const c = l["capability=".len..];
        if (util.eql(c, "clean")) {
            p.caps |= CAP_CLEAN;
        } else if (util.eql(c, "smudge")) {
            p.caps |= CAP_SMUDGE;
        } else if (util.eql(c, "delay")) {
            p.caps |= CAP_DELAY;
        } else {
            util.die("subprocess '{s}' requested unsupported capability '{s}'", .{ p.cmd, c });
        }
    }
    return true;
}

fn find(cmd: []const u8) ?*Proc {
    for (procs.items) |p| if (util.eql(p.cmd, cmd)) return p;
    return null;
}

fn findOrStart(cmd: []const u8) ?*Proc {
    if (find(cmd)) |p| return p;
    // ignore SIGPIPE for the whole lifetime: the filter may die at any time
    _ = signal(13, 1);
    if (!atexit_registered) {
        atexit_registered = true;
        _ = atexit(&exitHandler);
    }
    const p = spawn(cmd) orelse {
        util.err("cannot fork to run subprocess '{s}'", .{cmd});
        return null;
    };
    procs.append(gpa, p) catch util.oom();
    if (!handshake(p)) {
        util.err("initialization for subprocess '{s}' failed", .{cmd});
        stopProc(p);
        return null;
    }
    return p;
}

/// subprocess_read_status(): the last "status=<foo>" line wins. Returns
/// false on read error.
fn readStatus(p: *Proc, status: *[]const u8) bool {
    while (true) {
        const l = (pktReadLine(p) catch return false) orelse return true;
        if (util.startsWith(l, "status=")) status.* = l["status=".len..];
    }
}

/// handle_filter_error()
fn handleFilterError(status: []const u8, p: *Proc, wanted: u32) void {
    if (util.eql(status, "error")) {
        // the filter signaled a problem with the file
    } else if (util.eql(status, "abort") and wanted != 0) {
        p.caps &= ~wanted;
    } else {
        util.err("external filter '{s}' failed", .{p.cmd});
        stopProc(p);
    }
}

/// apply_multi_file_filter()
pub fn apply(path: []const u8, src: ?[]const u8, cmd: []const u8, cap: u32, meta: ?*const convert.Meta, dco: ?*convert.Dco) ?[]const u8 {
    const p = findOrStart(cmd) orelse return null;
    if (p.caps & cap == 0) return null;

    var status: []const u8 = "";
    var result: util.Buf = .empty;
    var ok = false;
    send: {
        if (!pktLine(p, if (cap & CAP_CLEAN != 0) "command=clean" else "command=smudge")) break :send;
        if (path.len > LARGE_PACKET_DATA_MAX - "pathname=\n".len) {
            util.err("path name too long for external filter", .{});
            break :send;
        }
        if (!pktLine(p, util.concat(&.{ "pathname=", path }))) break :send;
        if (meta) |m| {
            if (m.refname) |r| {
                if (!pktLine(p, util.concat(&.{ "ref=", r }))) break :send;
            }
            if (m.treeish) |t| {
                if (!hash.isZero(t) and !pktLine(p, util.concat(&.{ "treeish=", &hash.hex(t) }))) break :send;
            }
            if (m.blob) |b| {
                if (!hash.isZero(b) and !pktLine(p, util.concat(&.{ "blob=", &hash.hex(b) }))) break :send;
            }
        }
        var can_delay = false;
        if (p.caps & CAP_DELAY != 0) {
            if (dco) |d| {
                if (d.state == .can_delay) {
                    can_delay = true;
                    if (!pktLine(p, "can-delay=1")) break :send;
                }
            }
        }
        if (!pktFlush(p)) break :send;
        if (!pktContent(p, src orelse "")) break :send;
        if (!pktFlush(p)) break :send;
        if (!readStatus(p, &status)) break :send;
        if (can_delay and util.eql(status, "delayed")) {
            dco.?.addFilter(cmd);
            dco.?.addPath(path);
            ok = true;
            break :send;
        }
        if (!util.eql(status, "success")) break :send;
        while (true) {
            switch (pktRead(p)) {
                .flush => break,
                .eof => break :send,
                .data => |d| result.appendSlice(gpa, d) catch util.oom(),
            }
        }
        if (!readStatus(p, &status)) break :send;
        ok = util.eql(status, "success");
    }
    if (!ok) {
        handleFilterError(status, p, cap);
        return null;
    }
    return result.items;
}

/// async_query_available_blobs(): ask the filter which delayed paths are
/// ready; appends them (sorted, unique) to `out`. false on error.
pub fn queryAvailableBlobs(cmd: []const u8, out: *std.ArrayList([]const u8)) bool {
    const p = find(cmd) orelse {
        util.err("external filter '{s}' is not available anymore although not all paths have been filtered", .{cmd});
        return false;
    };
    var status: []const u8 = "";
    var ok = false;
    send: {
        if (!pktLine(p, "command=list_available_blobs")) break :send;
        if (!pktFlush(p)) break :send;
        while (true) {
            switch (pktReadMode(p, false)) {
                .flush, .eof => break,
                .data => |d| {
                    var s: []const u8 = d;
                    if (s.len > 0 and s[s.len - 1] == '\n') s = s[0 .. s.len - 1];
                    if (util.startsWith(s, "pathname=")) sortedInsert(out, s["pathname=".len..]);
                },
            }
        }
        if (!readStatus(p, &status)) break :send;
        ok = util.eql(status, "success");
    }
    if (!ok) handleFilterError(status, p, 0);
    return ok;
}

pub fn sortedInsert(list: *std.ArrayList([]const u8), s: []const u8) void {
    var lo: usize = 0;
    var hi: usize = list.items.len;
    while (lo < hi) {
        const mid = (lo + hi) / 2;
        switch (std.mem.order(u8, list.items[mid], s)) {
            .eq => return,
            .lt => lo = mid + 1,
            .gt => hi = mid,
        }
    }
    list.insert(gpa, lo, util.dupe(s)) catch util.oom();
}
