//! Signing and signature verification (gpg-interface.c plus the signature
//! helpers of commit.c: parse_buffer_signed_by_header, remove_signature,
//! add_header_signature, verify_commit_buffer, verify_merge_signature).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const proc = @import("proc.zig");
const config = @import("config.zig");
const repo_mod = @import("repo.zig");
const gpa = util.gpa;
const c = std.c;

pub const VERIFY_VERBOSE: u32 = 1 << 0;
pub const VERIFY_RAW: u32 = 1 << 1;
pub const VERIFY_OMIT_STATUS: u32 = 1 << 2;

pub const TrustLevel = enum(u8) { undefined, never, marginal, fully, ultimate };

pub const PayloadType = enum { undefined, commit, tag, push_cert };

pub const SigCheck = struct {
    payload: []const u8 = "",
    payload_type: PayloadType = .undefined,
    payload_timestamp: i64 = 0,
    output: ?[]const u8 = null,
    gpg_status: ?[]const u8 = null,
    /// 0 (not checked), 'N', 'G', 'B', 'U', 'X', 'Y', 'R', 'E'
    result: u8 = 0,
    signer: ?[]const u8 = null,
    key: ?[]const u8 = null,
    fingerprint: ?[]const u8 = null,
    primary_key_fingerprint: ?[]const u8 = null,
    trust_level: TrustLevel = .undefined,
};

const Kind = enum { openpgp, x509, ssh };

const Format = struct {
    name: []const u8,
    program: []const u8,
    verify_args: []const []const u8,
    sigs: []const []const u8,
    kind: Kind,
};

var formats = [_]Format{
    .{ .name = "openpgp", .program = "gpg", .verify_args = &.{"--keyid-format=long"}, .sigs = &.{ "-----BEGIN PGP SIGNATURE-----", "-----BEGIN PGP MESSAGE-----" }, .kind = .openpgp },
    .{ .name = "x509", .program = "gpgsm", .verify_args = &.{}, .sigs = &.{"-----BEGIN SIGNED MESSAGE-----"}, .kind = .x509 },
    .{ .name = "ssh", .program = "ssh-keygen", .verify_args = &.{}, .sigs = &.{"-----BEGIN SSH SIGNATURE-----"}, .kind = .ssh },
};

var use_format: *Format = &formats[0];
var configured_signing_key: ?[]const u8 = null;
var ssh_default_key_command: ?[]const u8 = null;
var ssh_allowed_signers: ?[]const u8 = null;
var ssh_revocation_file: ?[]const u8 = null;
var configured_min_trust_level: TrustLevel = .undefined;
var lazy_done = false;

fn formatByName(s: []const u8) ?*Format {
    for (&formats) |*f| if (util.eql(f.name, s)) return f;
    return null;
}

fn formatBySig(sig: []const u8) ?*Format {
    for (&formats) |*f| {
        for (f.sigs) |m| if (util.startsWith(sig, m)) return f;
    }
    return null;
}

/// get_signature_format()
pub fn signatureFormat(buf: []const u8) []const u8 {
    return if (formatBySig(buf)) |f| f.name else "unknown";
}

/// valid_signature_format()
pub fn validSignatureFormat(f: []const u8) bool {
    return formatByName(f) != null or util.eql(f, "unknown");
}

const trust_keys = [_][]const u8{ "UNDEFINED", "NEVER", "MARGINAL", "FULLY", "ULTIMATE" };
const trust_display = [_][]const u8{ "undefined", "never", "marginal", "fully", "ultimate" };

fn parseTrustLevel(s: []const u8) ?TrustLevel {
    for (trust_keys, 0..) |k, i| if (util.eql(k, s)) return @enumFromInt(i);
    return null;
}

/// gpg_trust_level_to_str()
pub fn trustLevelStr(l: TrustLevel) []const u8 {
    return trust_display[@intFromEnum(l)];
}

fn dieBadConfig(e: *const config.Entry) noreturn {
    if (e.origin_type == .cmdline) util.die("unable to parse '{s}' from command-line config", .{e.key});
    util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
}

/// gpg_interface_lazy_init() / git_gpg_config()
fn lazyInit() void {
    if (lazy_done) return;
    lazy_done = true;
    for (repo_mod.cfg.entries.items) |*e| {
        const k = e.key;
        if (util.eql(k, "user.signingkey")) {
            const v = e.value orelse {
                _ = config.errorNonbool(k);
                dieBadConfig(e);
            };
            configured_signing_key = v;
        } else if (util.eql(k, "gpg.format")) {
            const v = e.value orelse {
                _ = config.errorNonbool(k);
                dieBadConfig(e);
            };
            use_format = formatByName(v) orelse {
                util.err("invalid value for '{s}': '{s}'", .{ k, v });
                dieBadConfig(e);
            };
        } else if (util.eql(k, "gpg.mintrustlevel")) {
            const v = e.value orelse {
                _ = config.errorNonbool(k);
                dieBadConfig(e);
            };
            const up = util.dupe(v);
            for (up) |*ch| ch.* = std.ascii.toUpper(ch.*);
            configured_min_trust_level = parseTrustLevel(up) orelse {
                util.err("invalid value for '{s}': '{s}'", .{ k, v });
                dieBadConfig(e);
            };
        } else if (util.eql(k, "gpg.ssh.defaultkeycommand")) {
            ssh_default_key_command = e.value orelse {
                _ = config.errorNonbool(k);
                dieBadConfig(e);
            };
        } else if (util.eql(k, "gpg.ssh.allowedsignersfile")) {
            ssh_allowed_signers = pathOrDie(e);
        } else if (util.eql(k, "gpg.ssh.revocationfile")) {
            ssh_revocation_file = pathOrDie(e);
        } else {
            const fmtname: ?[]const u8 = if (util.eql(k, "gpg.program") or util.eql(k, "gpg.openpgp.program"))
                "openpgp"
            else if (util.eql(k, "gpg.x509.program"))
                "x509"
            else if (util.eql(k, "gpg.ssh.program"))
                "ssh"
            else
                null;
            if (fmtname) |fname| {
                if (pathOrDie(e)) |p| formatByName(fname).?.program = p;
            }
        }
    }
}

fn pathOrDie(e: *const config.Entry) ?[]const u8 {
    return switch (config.configPathname(e.key, e.value)) {
        .ok => |p| p,
        .err => dieBadConfig(e),
    };
}

/// set_signing_key()
pub fn setSigningKey(key: []const u8) void {
    lazyInit();
    configured_signing_key = key;
}

// ---------------------------------------------------------------- processes

extern "c" fn poll(fds: [*]PollFd, n: c_ulong, timeout: c_int) c_int;
const PollFd = extern struct { fd: c_int, events: i16, revents: i16 };
extern "c" fn fcntl(fd: c_int, cmd: c_int, ...) c_int;
extern "c" fn access(path: [*:0]const u8, mode: c_int) c_int;

const PipeResult = struct { ret: i32, out: []u8 = &.{}, err: []u8 = &.{} };

pub fn findProgram(name: []const u8) bool {
    if (std.mem.indexOfScalar(u8, name, '/') != null) return true;
    const path = os.getenv("PATH") orelse return false;
    var it = std.mem.splitScalar(u8, path, ':');
    while (it.next()) |d| {
        const full = util.concat(&.{ if (d.len == 0) "." else d, "/", name });
        if (access(os.z(full), 1) == 0) return true;
    }
    return false;
}

/// pipe_command(): run argv feeding `input`, capturing stdout and stderr.
/// Returns -1 when the program cannot be started, else its exit status.
fn pipeCommand(argv: []const []const u8, input: ?[]const u8) PipeResult {
    return pipeCommandOpt(argv, input, true);
}

fn pipeCommandOpt(argv: []const []const u8, input: ?[]const u8, capture_err: bool) PipeResult {
    if (argv[0].len == 0 or !findProgram(argv[0])) {
        util.err("cannot run {s}: No such file or directory", .{argv[0]});
        return .{ .ret = -1 };
    }
    proc.ignoreSigpipe();
    var ch = proc.spawn(argv, .{ .pipe_in = input != null, .no_stdin = input == null, .pipe_out = true, .pipe_err = capture_err });
    var out: std.ArrayList(u8) = .empty;
    var errb: std.ArrayList(u8) = .empty;
    var in_off: usize = 0;
    if (input != null) {
        if (input.?.len == 0) proc.closeFd(&ch.in) else _ = fcntl(ch.in, 4, @as(c_int, 0o4000)); // F_SETFL O_NONBLOCK
    }
    var buf: [8192]u8 = undefined;
    while (ch.in >= 0 or ch.out >= 0 or ch.err >= 0) {
        var fds: [3]PollFd = undefined;
        var n: usize = 0;
        if (ch.in >= 0) {
            fds[n] = .{ .fd = ch.in, .events = 4, .revents = 0 };
            n += 1;
        }
        if (ch.out >= 0) {
            fds[n] = .{ .fd = ch.out, .events = 1, .revents = 0 };
            n += 1;
        }
        if (ch.err >= 0) {
            fds[n] = .{ .fd = ch.err, .events = 1, .revents = 0 };
            n += 1;
        }
        if (poll(&fds, n, -1) < 0) {
            if (os.errno() == 4) continue;
            break;
        }
        for (fds[0..n]) |f| {
            if (f.revents == 0) continue;
            if (f.fd == ch.in) {
                const data = input.?[in_off..];
                const w = c.write(ch.in, data.ptr, @min(data.len, 65536));
                if (w < 0) {
                    const e = os.errno();
                    if (e == 11 or e == 4) continue;
                    proc.closeFd(&ch.in);
                    continue;
                }
                in_off += @intCast(w);
                if (in_off >= input.?.len) proc.closeFd(&ch.in);
            } else {
                const got = c.read(f.fd, &buf, buf.len);
                if (got <= 0) {
                    if (f.fd == ch.out) proc.closeFd(&ch.out) else proc.closeFd(&ch.err);
                    continue;
                }
                const dst = if (f.fd == ch.out) &out else &errb;
                dst.appendSlice(gpa, buf[0..@intCast(got)]) catch util.oom();
            }
        }
    }
    const st = proc.wait(ch.pid);
    return .{ .ret = st, .out = out.items, .err = errb.items };
}

fn tmpDir() []const u8 {
    return os.getenv("TMPDIR") orelse "/tmp";
}

/// mks_tempfile_t() + write; returns the path.
fn writeTemp(prefix: []const u8, data: []const u8) ?[]const u8 {
    const t = os.tmpFile(tmpDir(), prefix);
    os.writeAll(t.fd, data) catch {
        util.err("failed writing detached signature to '{s}': {s}", .{ t.path, os.lastErr() });
        _ = c.close(t.fd);
        _ = os.unlink(t.path);
        return null;
    };
    _ = c.close(t.fd);
    return t.path;
}

// ---------------------------------------------------------------- verify

const ST_EXCLUSIVE: u32 = 1;
const ST_KEYID: u32 = 2;
const ST_UID: u32 = 4;
const ST_FINGERPRINT: u32 = 8;
const ST_TRUST: u32 = 16;
const ST_STDSIG = ST_EXCLUSIVE | ST_KEYID | ST_UID;

const status_table = [_]struct { result: u8, check: []const u8, flags: u32 }{
    .{ .result = 'G', .check = "GOODSIG ", .flags = ST_STDSIG },
    .{ .result = 'B', .check = "BADSIG ", .flags = ST_STDSIG },
    .{ .result = 'E', .check = "ERRSIG ", .flags = ST_EXCLUSIVE | ST_KEYID },
    .{ .result = 'X', .check = "EXPSIG ", .flags = ST_STDSIG },
    .{ .result = 'Y', .check = "EXPKEYSIG ", .flags = ST_STDSIG },
    .{ .result = 'R', .check = "REVKEYSIG ", .flags = ST_STDSIG },
    .{ .result = 0, .check = "VALIDSIG ", .flags = ST_FINGERPRINT },
    .{ .result = 0, .check = "TRUST_", .flags = ST_TRUST },
};

fn strchrnul(s: []const u8, from: usize, ch: u8) usize {
    return std.mem.indexOfScalarPos(u8, s, from, ch) orelse s.len;
}

/// parse_gpg_output()
fn parseGpgOutput(sigc: *SigCheck) void {
    const buf = sigc.gpg_status orelse "";
    var seen_exclusive: u32 = 0;
    var pos: usize = 0;
    outer: while (pos < buf.len) {
        while (pos < buf.len and buf[pos] == '\n') pos += 1;
        if (pos >= buf.len) break;
        const line_start = pos;
        // next line start for the loop: strchrnul(line+1, '\n')
        const next_line = strchrnul(buf, line_start + 1, '\n');
        defer pos = next_line;
        if (!util.startsWith(buf[line_start..], "[GNUPG:] ")) continue;
        var line = line_start + 9;
        for (status_table) |st| {
            if (!util.startsWith(buf[line..], st.check)) continue;
            line += st.check.len;
            if (st.flags & ST_EXCLUSIVE != 0) {
                seen_exclusive += 1;
                if (seen_exclusive > 1) break :outer gpgError(sigc);
            }
            if (st.result != 0) sigc.result = st.result;
            if (st.flags & ST_KEYID != 0) {
                const next = strchrnul(buf, line, ' ');
                sigc.key = util.dupe(buf[line..next]);
                if (next < buf.len and st.flags & ST_UID != 0) {
                    const l2 = next + 1;
                    const n2 = strchrnul(buf, l2, '\n');
                    sigc.signer = util.dupe(buf[l2..n2]);
                }
            }
            if (st.flags & ST_TRUST != 0) {
                var e = line;
                while (e < buf.len and buf[e] != ' ' and buf[e] != '\n') e += 1;
                sigc.trust_level = parseTrustLevel(buf[line..e]) orelse break :outer gpgError(sigc);
            }
            if (st.flags & ST_FINGERPRINT != 0) {
                var next = strchrnul(buf, line, ' ');
                sigc.fingerprint = util.dupe(buf[line..next]);
                const limit = strchrnul(buf, line, '\n');
                var j: u32 = 9;
                while (j > 0) : (j -= 1) {
                    if (next >= buf.len or limit <= next) break;
                    line = next + 1;
                    next = strchrnul(buf, line, ' ');
                }
                if (j == 0) {
                    next = strchrnul(buf, line, '\n');
                    sigc.primary_key_fingerprint = util.dupe(buf[line..next]);
                } else sigc.primary_key_fingerprint = null;
            }
            break;
        }
    }
}

fn gpgError(sigc: *SigCheck) void {
    sigc.result = 'E';
    sigc.primary_key_fingerprint = null;
    sigc.fingerprint = null;
    sigc.signer = null;
    sigc.key = null;
}

fn verifyGpg(sigc: *SigCheck, fmt: *Format, sig: []const u8) i32 {
    const path = writeTemp(".git_vtag_tmp", sig) orelse return -1;
    defer _ = os.unlink(path);
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, fmt.program) catch util.oom();
    argv.appendSlice(gpa, fmt.verify_args) catch util.oom();
    argv.appendSlice(gpa, &.{ "--status-fd=1", "--verify", path, "-" }) catch util.oom();
    const r = pipeCommand(argv.items, sigc.payload);
    var ret: i32 = if (r.ret != 0) 1 else 0;
    if (std.mem.indexOf(u8, r.out, "\n[GNUPG:] GOODSIG ") == null and std.mem.indexOf(u8, r.out, "\n[GNUPG:] EXPKEYSIG ") == null) ret = 1;
    if (r.ret < 0) {
        // start_command failed: pipe_command returned -1 and nothing was captured
        sigc.output = "";
        sigc.gpg_status = "";
        parseGpgOutput(sigc);
        return -1;
    }
    sigc.output = r.err;
    sigc.gpg_status = r.out;
    parseGpgOutput(sigc);
    return ret;
}

/// parse_ssh_output()
fn parseSshOutput(sigc: *SigCheck) void {
    sigc.result = 'B';
    sigc.trust_level = .never;
    const out = sigc.output orelse "";
    var line = out[0 .. std.mem.indexOfScalar(u8, out, '\n') orelse out.len];
    if (util.skipPrefix(line, "Good \"git\" signature for ")) |rest| {
        const principal = rest;
        var l = rest;
        while (std.mem.indexOf(u8, l, " with ")) |ix| l = l[ix + 1 ..];
        if (l.ptr == principal.ptr) return;
        sigc.result = 'G';
        sigc.trust_level = .fully;
        const plen = @intFromPtr(l.ptr) - @intFromPtr(principal.ptr) - 1;
        sigc.signer = util.dupe(principal[0..plen]);
        line = l;
    } else if (util.skipPrefix(line, "Good \"git\" signature with ")) |rest| {
        sigc.result = 'G';
        sigc.trust_level = .undefined;
        line = rest;
    } else return;
    if (std.mem.indexOf(u8, line, "key ")) |k| {
        sigc.fingerprint = util.dupe(line[k + 4 ..]);
        sigc.key = sigc.fingerprint;
    } else sigc.result = 'B';
}

fn verifySsh(sigc: *SigCheck, fmt: *Format, sig: []const u8) i32 {
    const allowed = ssh_allowed_signers orelse {
        util.err("gpg.ssh.allowedSignersFile needs to be configured and exist for ssh signature verification", .{});
        return -1;
    };
    const path = writeTemp(".git_vtag_tmp", sig) orelse return -1;
    defer _ = os.unlink(path);
    var verify_time: []const u8 = "";
    if (sigc.payload_timestamp != 0) {
        const date = @import("date.zig");
        verify_time = util.concat(&.{ "-Overify-time=", date.showDate(sigc.payload_timestamp, 0, .{ .mode = .strftime, .strftime_fmt = "%Y%m%d%H%M%S", .local = true }) });
    }
    var ret: i32 = -1;
    const pr = pipeCommand(&.{ fmt.program, "-Y", "find-principals", "-f", allowed, "-s", path, verify_time }, null);
    ret = pr.ret;
    if (ret != 0 and std.mem.indexOf(u8, pr.err, "usage:") != null) {
        util.err("ssh-keygen -Y find-principals/verify is needed for ssh signature verification (available in openssh version 8.2p1+)", .{});
        return ret;
    }
    var kout: []const u8 = "";
    var kerr: []const u8 = "";
    if (ret != 0 or pr.out.len == 0) {
        const r = pipeCommand(&.{ fmt.program, "-Y", "check-novalidate", "-n", "git", "-s", path, verify_time }, sigc.payload);
        kout = r.out;
        kerr = r.err;
        ret = -1;
    } else {
        var rest: []const u8 = pr.out;
        while (rest.len > 0) {
            const nl = std.mem.indexOfScalar(u8, rest, '\n');
            var line = rest[0 .. nl orelse rest.len];
            rest = if (nl) |x| rest[x + 1 ..] else rest[rest.len..];
            if (nl != null and line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
            if (line.len == 0) continue;
            var argv: std.ArrayList([]const u8) = .empty;
            argv.appendSlice(gpa, &.{ fmt.program, "-Y", "verify", "-n", "git", "-f", allowed, "-I", line, "-s", path, verify_time }) catch util.oom();
            if (ssh_revocation_file) |rf| {
                if (os.exists(rf)) {
                    argv.appendSlice(gpa, &.{ "-r", rf }) catch util.oom();
                } else util.warn("ssh signing revocation file configured but not found: {s}", .{rf});
            }
            const r = pipeCommand(argv.items, sigc.payload);
            kout = r.out;
            kerr = r.err;
            ret = r.ret;
            if (ret == 0) ret = if (util.startsWith(kout, "Good")) 0 else 1;
            if (ret == 0) break;
        }
    }
    var o: util.Buf = .empty;
    util.bufAppend(&o, util.stripspace(kout, null));
    util.bufAppend(&o, util.stripspace(kerr, null));
    _ = &o;
    var final: util.Buf = .empty;
    util.bufAppend(&final, util.stripspace(kout, null));
    util.bufAppend(&final, pr.err);
    util.bufAppend(&final, util.stripspace(kerr, null));
    sigc.output = final.items;
    sigc.gpg_status = util.dupe(final.items);
    parseSshOutput(sigc);
    return ret;
}

/// parse_payload_metadata(); returns true on failure.
fn parsePayloadMetadata(sigc: *SigCheck) bool {
    const hdr = switch (sigc.payload_type) {
        .commit => "committer",
        .tag => "tagger",
        else => return false,
    };
    const cn = @import("commitnode.zig");
    const line = cn.findHeader(sigc.payload, hdr) orelse return true;
    if (line.len == 0) return true;
    const gt = std.mem.lastIndexOfScalar(u8, line, '>') orelse return true;
    if (std.mem.indexOfScalar(u8, line, '<') == null) return true;
    if (sigc.payload_timestamp == 0) {
        var rest = line[gt + 1 ..];
        while (rest.len > 0 and rest[0] == ' ') rest = rest[1..];
        var e: usize = 0;
        while (e < rest.len and std.ascii.isDigit(rest[e])) e += 1;
        if (e > 0) sigc.payload_timestamp = std.fmt.parseInt(i64, rest[0..e], 10) catch 0;
    }
    return false;
}

/// check_signature(): 0 when the signature is good (and trusted enough).
pub fn checkSignature(sigc: *SigCheck, sig: []const u8) i32 {
    lazyInit();
    sigc.result = 'N';
    sigc.trust_level = .undefined;
    const fmt = formatBySig(sig) orelse util.die("bad/incompatible signature '{s}'", .{sig});
    if (parsePayloadMetadata(sigc)) return 1;
    var status = switch (fmt.kind) {
        .ssh => verifySsh(sigc, fmt, sig),
        else => verifyGpg(sigc, fmt, sig),
    };
    if (status != 0 and sigc.output == null) return 1;
    if (status != 0 and fmt.kind != .ssh and sigc.output != null and sigc.output.?.len == 0 and sigc.gpg_status != null and sigc.gpg_status.?.len == 0 and status < 0) {
        // program could not be run: C leaves output as an empty string
    }
    if (sigc.result != 'G' and sigc.result != 'Y') status = 1;
    if (@intFromEnum(sigc.trust_level) < @intFromEnum(configured_min_trust_level)) status = 1;
    return if (status != 0) 1 else 0;
}

/// print_signature_buffer()
pub fn printSignatureBuffer(sigc: *const SigCheck, flags: u32) void {
    const output = if (flags & VERIFY_RAW != 0) sigc.gpg_status else sigc.output;
    if (flags & VERIFY_VERBOSE != 0 and sigc.payload.len > 0) {
        util.out(sigc.payload);
        util.flushStdout();
    }
    if (output) |o| util.ewrite(o);
}

/// parse_signed_buffer(): offset of the signature (or buf.len).
pub fn parseSignedBuffer(buf: []const u8) usize {
    var len: usize = 0;
    var match = buf.len;
    while (len < buf.len) {
        if (formatBySig(buf[len..]) != null) match = len;
        const eol = std.mem.indexOfScalarPos(u8, buf, len, '\n');
        len = if (eol) |e| e + 1 else buf.len;
    }
    return match;
}

/// parse_signature(): split a tag buffer into payload and signature.
pub fn parseSignature(buf: []const u8, payload: *util.Buf, sig: *util.Buf) bool {
    const m = parseSignedBuffer(buf);
    if (m == buf.len) return false;
    var p: util.Buf = .empty;
    util.bufAppend(&p, buf[0..m]);
    _ = removeSignature(&p);
    util.bufAppend(payload, p.items);
    util.bufAppend(sig, buf[m..]);
    return true;
}

const sig_headers = [_][]const u8{ "gpgsig", "gpgsig-sha256" };

/// remove_signature() (commit.c)
pub fn removeSignature(buf: *util.Buf) bool {
    var final: util.Buf = .empty;
    var found = false;
    var in_sig = false;
    const b = buf.items;
    var pos: usize = 0;
    while (pos < b.len) {
        var next = if (std.mem.indexOfScalarPos(u8, b, pos, '\n')) |x| x + 1 else b.len;
        const line = b[pos..next];
        if (in_sig and line[0] == ' ') {
            // inside a signature
        } else if (util.startsWith(line, "gpgsig")) {
            for (sig_headers) |h| {
                if (util.startsWith(line, h) and line.len > h.len and line[h.len] == ' ') {
                    found = true;
                    in_sig = true;
                }
            }
        } else {
            if (line[0] == '\n') next = b.len;
            in_sig = false;
            util.bufAppend(&final, b[pos..next]);
        }
        pos = next;
    }
    buf.* = final;
    return found;
}

/// parse_buffer_signed_by_header() (commit.c), sha1 repositories.
pub fn parseBufferSignedByHeader(buf: []const u8, payload: *util.Buf, sig: *util.Buf) bool {
    const hdr = sigHeader();
    var in_sig = false;
    var saw = false;
    var other = false;
    var pos: usize = 0;
    while (pos < buf.len) {
        var next = if (std.mem.indexOfScalarPos(u8, buf, pos, '\n')) |x| x + 1 else buf.len;
        const line = buf[pos..next];
        var s: ?usize = null;
        if (in_sig and line[0] == ' ') {
            s = pos + 1;
        } else if (util.startsWith(line, hdr) and line.len > hdr.len and line[hdr.len] == ' ') {
            s = pos + hdr.len + 1;
            other = false;
        } else if (util.startsWith(line, "gpgsig")) {
            other = true;
        } else if (other and line[0] != ' ') {
            other = false;
        }
        if (s) |x| {
            util.bufAppend(sig, buf[x..next]);
            saw = true;
            in_sig = true;
        } else {
            if (line[0] == '\n') next = buf.len;
            if (!other) util.bufAppend(payload, buf[pos..next]);
            in_sig = false;
        }
        pos = next;
    }
    return saw;
}

fn sigHeader() []const u8 {
    return "gpgsig";
}

/// add_header_signature() (commit.c)
pub fn addHeaderSignature(buf: *util.Buf, sig: []const u8) void {
    const hdr = sigHeader();
    const inspos: usize = if (std.mem.indexOf(u8, buf.items, "\n\n")) |e| e + 1 else buf.items.len;
    var ins: util.Buf = .empty;
    var pos: usize = 0;
    while (pos < sig.len) {
        const eol = std.mem.indexOfScalarPos(u8, sig, pos, '\n');
        const end = if (eol) |e| e + 1 else sig.len;
        if (pos == 0) util.bufAppend(&ins, hdr);
        util.bufByte(&ins, ' ');
        util.bufAppend(&ins, sig[pos..end]);
        pos = end;
    }
    buf.insertSlice(gpa, inspos, ins.items) catch util.oom();
}

/// verify_commit_buffer()
pub fn verifyCommitBuffer(buf: []const u8, sigc: *SigCheck) i32 {
    sigc.result = 'N';
    var payload: util.Buf = .empty;
    var sig: util.Buf = .empty;
    if (!parseBufferSignedByHeader(buf, &payload, &sig)) return 1;
    sigc.payload_type = .commit;
    sigc.payload = payload.items;
    return checkSignature(sigc, sig.items);
}

/// verify_merge_signature(): `abbrev` is the abbreviated commit name.
pub fn verifyMergeSignature(buf: []const u8, abbrev: []const u8, verbosity: i32, check_trust: bool) void {
    var sigc: SigCheck = .{};
    const ret = verifyCommitBuffer(buf, &sigc);
    switch (sigc.result) {
        'G' => if (ret != 0 or (check_trust and @intFromEnum(sigc.trust_level) < @intFromEnum(TrustLevel.marginal)))
            util.die("Commit {s} has an untrusted GPG signature, allegedly by {s}.", .{ abbrev, sigc.signer orelse "(null)" }),
        'B' => util.die("Commit {s} has a bad GPG signature allegedly by {s}.", .{ abbrev, sigc.signer orelse "(null)" }),
        else => util.die("Commit {s} does not have a GPG signature.", .{abbrev}),
    }
    if (verbosity >= 0 and sigc.result == 'G')
        util.outf("Commit {s} has a good GPG signature by {s}\n", .{ abbrev, sigc.signer orelse "(null)" });
}

// ---------------------------------------------------------------- signing

fn isLiteralSshKey(s: []const u8) ?[]const u8 {
    if (util.skipPrefix(s, "key::")) |k| return k;
    if (util.startsWith(s, "ssh-")) return s;
    return null;
}

fn sshKeyFingerprint(signing_key: []const u8) []const u8 {
    const r = if (isLiteralSshKey(signing_key)) |lit|
        pipeCommandOpt(&.{ "ssh-keygen", "-lf", "-" }, lit, false)
    else
        pipeCommandOpt(&.{ "ssh-keygen", "-lf", configured_signing_key orelse signing_key }, null, false);
    if (r.ret != 0) util.die("failed to get the ssh fingerprint for key '{s}': {s}", .{ signing_key, os.lastErr() });
    const out = r.out;
    const d1 = std.mem.indexOfScalar(u8, out, ' ') orelse util.die("failed to get the ssh fingerprint for key {s}", .{signing_key});
    const begin = d1 + 1;
    const d2 = std.mem.indexOfScalarPos(u8, out, begin, ' ') orelse util.die("failed to get the ssh fingerprint for key {s}", .{signing_key});
    return util.dupe(out[begin..d2]);
}

fn defaultSshSigningKey() ?[]const u8 {
    const cmd = ssh_default_key_command orelse util.die("either user.signingkey or gpg.ssh.defaultKeyCommand needs to be configured", .{});
    const argv = @import("commands.zig").splitCmdline(cmd) orelse util.die("malformed build-time gpg.ssh.defaultKeyCommand: {s}", .{"unclosed quote"});
    if (argv.len == 0) return null;
    const r = pipeCommand(argv, null);
    if (r.ret == 0) {
        const first = r.out[0 .. std.mem.indexOfScalar(u8, r.out, '\n') orelse r.out.len];
        if (isLiteralSshKey(first) != null) return util.dupe(first);
        util.warn("gpg.ssh.defaultKeyCommand succeeded but returned no keys: {s} {s}", .{ r.err, r.out });
    } else util.warn("gpg.ssh.defaultKeyCommand failed: {s} {s}", .{ r.err, r.out });
    return null;
}

/// get_signing_key()
pub fn getSigningKey() ?[]const u8 {
    lazyInit();
    if (configured_signing_key) |k| return k;
    if (use_format.kind == .ssh) return defaultSshSigningKey();
    const id = @import("ident.zig").committerStrict();
    const gt = std.mem.lastIndexOfScalar(u8, id, '>') orelse id.len - 1;
    return id[0 .. gt + 1];
}

/// get_signing_key_id()
pub fn getSigningKeyId() ?[]const u8 {
    lazyInit();
    if (use_format.kind == .ssh) {
        const k = getSigningKey() orelse return sshKeyFingerprint("");
        return sshKeyFingerprint(k);
    }
    return getSigningKey();
}

fn stripCrBeforeLf(buf: *util.Buf, offset: usize) void {
    var j = offset;
    var i = offset;
    const b = buf.items;
    while (i < b.len) : (i += 1) {
        if (b[i] == '\r' and i + 1 < b.len and b[i + 1] == '\n') continue;
        b[j] = b[i];
        j += 1;
    }
    buf.shrinkRetainingCapacity(j);
}

fn signGpg(buffer: []const u8, sig: *util.Buf, key: []const u8) i32 {
    const r = pipeCommand(&.{ use_format.program, "--status-fd=2", "-bsau", key }, buffer);
    const bottom = sig.items.len;
    var found = false;
    var p: usize = 0;
    while (std.mem.indexOfPos(u8, r.err, p, "[GNUPG:] SIG_CREATED ")) |ix| {
        if (ix == 0 or r.err[ix - 1] == '\n') {
            found = true;
            break;
        }
        p = ix + 1;
    }
    if (r.ret != 0 or !found) {
        util.err("gpg failed to sign the data:\n{s}", .{if (r.err.len > 0) r.err else "(no gpg output)"});
        return -1;
    }
    util.bufAppend(sig, r.out);
    stripCrBeforeLf(sig, bottom);
    return 0;
}

fn signSsh(buffer: []const u8, sig: *util.Buf, key_opt: ?[]const u8) i32 {
    const key = key_opt orelse "";
    if (key.len == 0) {
        util.err("user.signingKey needs to be set for ssh signing", .{});
        return -1;
    }
    var key_file: ?[]const u8 = null;
    var key_path: []const u8 = undefined;
    const literal = isLiteralSshKey(key);
    if (literal) |lit| {
        key_file = writeTemp(".git_signing_key_tmp", lit) orelse return -1;
        key_path = key_file.?;
    } else key_path = config.interpolatePath(key, true) orelse key;
    defer if (key_file) |k| {
        _ = os.unlink(k);
    };
    const bfile = writeTemp(".git_signing_buffer_tmp", buffer) orelse return -1;
    defer _ = os.unlink(bfile);
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ use_format.program, "-Y", "sign", "-n", "git", "-f", key_path }) catch util.oom();
    if (literal != null) argv.append(gpa, "-U") catch util.oom();
    argv.append(gpa, bfile) catch util.oom();
    const r = pipeCommand(argv.items, null);
    const sigfile = util.concat(&.{ bfile, ".sig" });
    defer _ = os.unlink(sigfile);
    if (r.ret != 0) {
        if (std.mem.indexOf(u8, r.err, "usage:") != null)
            util.err("ssh-keygen -Y sign is needed for ssh signing (available in openssh version 8.2p1+)", .{});
        util.err("{s}", .{r.err});
        return -1;
    }
    const bottom = sig.items.len;
    const data = os.readFile(sigfile) orelse {
        util.err("failed reading ssh signing data buffer from '{s}': {s}", .{ sigfile, os.lastErr() });
        return -1;
    };
    util.bufAppend(sig, data);
    stripCrBeforeLf(sig, bottom);
    return 0;
}

/// sign_buffer(): `use_default` == SIGN_BUFFER_USE_DEFAULT_KEY.
pub fn signBuffer(buffer: []const u8, sig: *util.Buf, signing_key: ?[]const u8, use_default: bool) i32 {
    lazyInit();
    var key = signing_key;
    if (use_default and (key == null or key.?.len == 0)) key = getSigningKey();
    return switch (use_format.kind) {
        .ssh => signSsh(buffer, sig, key),
        else => signGpg(buffer, sig, key orelse ""),
    };
}

/// Sign a commit buffer in place (commit_tree_extended with sign_commit).
/// Returns false (after reporting) when signing failed.
pub fn signCommitBuffer(buf: *util.Buf, keyid: []const u8) bool {
    var sig: util.Buf = .empty;
    if (signBuffer(buf.items, &sig, keyid, true) != 0) return false;
    addHeaderSignature(buf, sig.items);
    return true;
}

pub const SignMode = enum { abort, abort_if_invalid, warn_verbatim, verbatim, warn_strip, strip, strip_if_invalid, sign_if_invalid };

/// parse_sign_mode()
pub fn parseSignMode(arg: []const u8, keyid: ?*?[]const u8) ?SignMode {
    if (util.eql(arg, "abort")) return .abort;
    if (util.eql(arg, "verbatim") or util.eql(arg, "ignore")) return .verbatim;
    if (util.eql(arg, "warn-verbatim") or util.eql(arg, "warn")) return .warn_verbatim;
    if (util.eql(arg, "warn-strip")) return .warn_strip;
    if (util.eql(arg, "strip")) return .strip;
    if (util.eql(arg, "abort-if-invalid")) return .abort_if_invalid;
    if (util.eql(arg, "strip-if-invalid")) return .strip_if_invalid;
    if (util.eql(arg, "sign-if-invalid")) return .sign_if_invalid;
    if (util.skipPrefix(arg, "sign-if-invalid=")) |k| {
        if (keyid) |p| p.* = k;
        return .sign_if_invalid;
    }
    return null;
}
