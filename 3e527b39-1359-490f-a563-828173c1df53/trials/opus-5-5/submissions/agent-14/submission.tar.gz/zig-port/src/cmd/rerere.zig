//! git rerere (builtin/rerere.c)

const std = @import("std");
const util = @import("../util.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const pathspec_mod = @import("../pathspec.zig");
const rr = @import("../rerere.zig");

const usage = [_][]const u8{
    "git rerere [clear | forget <pathspec>... | diff | status | remaining | gc]",
};

pub fn cmdRerere(args: []const []const u8) u8 {
    var autoupdate: i32 = -1;
    const opts = [_]po.Opt{
        po.setInt(0, "rerere-autoupdate", &autoupdate, 1, "register clean resolutions in index"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    var flags: u32 = 0;
    if (autoupdate == 1) flags = rr.AUTOUPDATE;
    if (autoupdate == 0) flags = rr.NOAUTOUPDATE;

    if (rest.len < 1) {
        const s = rr.rerere(flags);
        return if (s < 0) 255 else @intCast(s);
    }
    const sub = rest[0];
    if (util.eql(sub, "forget")) {
        if (rest.len < 2) util.warn("'git rerere forget' without paths is deprecated", .{});
        const ps = pathspec_mod.parse(repo_mod.repo().prefix, rest[1..], .{ .prefer_cwd = true });
        const ret = rr.forget(&ps);
        return if (ret < 0) 255 else 0;
    }
    if (util.eql(sub, "clear")) {
        rr.clear();
    } else if (util.eql(sub, "gc")) {
        rr.gc();
    } else if (util.eql(sub, "status")) {
        var m: rr.MergeRr = .{};
        if (!rr.setup(&m, flags | rr.READONLY)) return 0;
        for (m.items.items) |it| util.outf("{s}\n", .{it.path});
    } else if (util.eql(sub, "remaining")) {
        var m: rr.MergeRr = .{};
        rr.remaining(&m);
        for (m.items.items) |it| {
            if (!it.resolved) util.outf("{s}\n", .{it.path});
        }
    } else if (util.eql(sub, "diff")) {
        var m: rr.MergeRr = .{};
        if (!rr.setup(&m, flags | rr.READONLY)) return 0;
        for (m.items.items) |*it| {
            if (!rr.diffItem(it)) {
                util.die("unable to generate diff for '{s}'", .{rr.rrPath(it.id.?, null)});
            }
        }
    } else {
        po.usageWithOptions(&usage, &opts);
    }
    return 0;
}
