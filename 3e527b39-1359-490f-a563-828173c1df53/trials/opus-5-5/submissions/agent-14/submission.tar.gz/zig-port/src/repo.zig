//! Repository discovery and global repository state (port of setup.c's
//! discovery part).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const config = @import("config.zig");
const odb_mod = @import("odb.zig");
const trace = @import("trace.zig");
const gpa = util.gpa;

pub const Repo = struct {
    git_dir: []const u8,
    common_dir: []const u8,
    work_tree: ?[]const u8,
    /// "" when git's prefix is NULL, else "<dir>/"
    prefix: []const u8 = "",
    bare: bool = false,
    odb_: ?*odb_mod.Odb = null,
    format_version: i64 = 0,
    worktree_config: bool = false,
    object_format: []const u8 = "sha1",
    worktree_config_is_bogus: bool = false,
    /// core.bare as read from the repository format: -1 unknown
    bare_cfg: i8 = -1,
    precious_objects: bool = false,
    partial_clone: ?[]const u8 = null,
    ref_storage: []const u8 = "files",

    pub fn odb(self: *Repo) *odb_mod.Odb {
        if (self.odb_ == null) {
            const dir = os.getenv("GIT_OBJECT_DIRECTORY") orelse util.concat(&.{ self.common_dir, "/objects" });
            self.odb_ = odb_mod.Odb.init(dir);
            if (cfg.getInt("core.loosecompression") orelse cfg.getInt("core.compression")) |lvl| {
                self.odb_.?.compression = @intCast(if (lvl == -1) 6 else lvl);
            }
        }
        return self.odb_.?;
    }

    /// Path inside the per-worktree git dir.
    pub fn gitPath(self: *Repo, name: []const u8) []u8 {
        return util.concat(&.{ self.git_dir, "/", name });
    }
    /// Path inside the common dir.
    pub fn commonPath(self: *Repo, name: []const u8) []u8 {
        return util.concat(&.{ self.common_dir, "/", name });
    }

    pub fn indexPath(self: *Repo) []const u8 {
        if (os.getenv("GIT_INDEX_FILE")) |p| return p;
        return self.gitPath("index");
    }
};

pub var repo_: ?*Repo = null;
pub var cfg: config.Config = .{};
pub var cmdline_config: std.ArrayList([]const u8) = .empty;

pub fn repo() *Repo {
    return repo_ orelse util.die("not a git repository (or any of the parent directories): .git", .{});
}

/// setup_work_tree(): make sure we have a work tree and chdir to its top.
pub fn requireWorkTree(cmd: []const u8) *Repo {
    _ = cmd;
    const r = repo();
    if (r.worktree_config_is_bogus) util.die("unable to set up work tree using invalid config", .{});
    const wt = r.work_tree orelse util.die("this operation must be run in a work tree", .{});
    if (!chdirNotify(wt)) util.die("this operation must be run in a work tree", .{});
    if (os.getenv("GIT_WORK_TREE") != null) os.setEnv("GIT_WORK_TREE", ".");
    return r;
}

/// chdir_notify(): chdir and re-anchor a relative $GIT_DIR.
pub fn chdirNotify(new_cwd: []const u8) bool {
    return chdirNotifyImpl(new_cwd, true);
}

fn chdirNotifyImpl(new_cwd: []const u8, do_trace: bool) bool {
    const old = os.getcwd();
    if (!os.chdir(new_cwd)) return false;
    if (do_trace) trace.printf(&trace.setup_key, "setup.c", 0, "setup: chdir from '{s}' to '{s}'", .{ old, new_cwd });
    if (repo_) |r| {
        if (r.git_dir.len > 0 and r.git_dir[0] != '/') {
            const p = reparentRelativePath(old, new_cwd, r.git_dir);
            if (do_trace) trace.printf(&trace.setup_key, "setup.c", 0, "setup: move $GIT_DIR to '{s}'", .{p});
            const common_rel = r.common_dir.len > 0 and r.common_dir[0] != '/';
            const old_gd = r.git_dir;
            r.git_dir = p;
            if (common_rel) {
                if (util.eql(r.common_dir, old_gd)) {
                    r.common_dir = p;
                } else {
                    r.common_dir = reparentRelativePath(old, new_cwd, r.common_dir);
                }
            }
            os.setEnv("GIT_DIR", p);
        }
    }
    return true;
}

fn reparentRelativePath(old_cwd: []const u8, new_cwd: []const u8, path: []const u8) []const u8 {
    if (path.len > 0 and path[0] == '/') return path;
    const full = util.concat(&.{ old_cwd, "/", path });
    return util.dupe(removeLeadingPath(full, new_cwd));
}

/// remove_leading_path()
pub fn removeLeadingPath(in: []const u8, prefix: []const u8) []const u8 {
    if (prefix.len == 0) return in;
    var i: usize = 0;
    var j: usize = 0;
    while (i < prefix.len) {
        if (prefix[i] == '/') {
            if (j >= in.len or in[j] != '/') return in;
            while (i < prefix.len and prefix[i] == '/') i += 1;
            while (j < in.len and in[j] == '/') j += 1;
            continue;
        } else if (j >= in.len or in[j] != prefix[i]) {
            return in;
        }
        i += 1;
        j += 1;
    }
    if (j < in.len and prefix[i - 1] != '/' and in[j] != '/') return in;
    while (j < in.len and in[j] == '/') j += 1;
    if (j >= in.len) return ".";
    return in[j..];
}

// ---------------------------------------------------------------------------
// realpath (abspath.c)

fn stripLastComponent(b: *util.Buf) void {
    const offset: usize = if (b.items.len > 0 and b.items[0] == '/') 1 else 0;
    var len = b.items.len;
    while (offset < len and b.items[len - 1] != '/') len -= 1;
    while (offset < len and b.items[len - 1] == '/') len -= 1;
    b.shrinkRetainingCapacity(len);
}

/// strbuf_realpath_1(). Returns null on error unless die_on_error.
pub fn realPathFlags(path: []const u8, many_missing: bool, die_on_error: bool) ?[]const u8 {
    if (path.len == 0) {
        if (die_on_error) util.die("The empty string is not a valid path", .{});
        return null;
    }
    var resolved: util.Buf = .empty;
    var remaining: util.Buf = .empty;
    if (path[0] == '/') {
        util.bufByte(&resolved, '/');
        util.bufAppend(&remaining, path[1..]);
    } else {
        util.bufAppend(&resolved, os.getcwd());
        util.bufAppend(&remaining, path);
    }
    var num_symlinks: u32 = 0;
    while (remaining.items.len > 0) {
        // get_next_component
        var s: usize = 0;
        while (s < remaining.items.len and remaining.items[s] == '/') s += 1;
        var e = s;
        while (e < remaining.items.len and remaining.items[e] != '/') e += 1;
        const next = util.dupe(remaining.items[s..e]);
        const rest = util.dupe(remaining.items[e..]);
        remaining.clearRetainingCapacity();
        util.bufAppend(&remaining, rest);

        if (next.len == 0) continue;
        if (util.eql(next, ".")) continue;
        if (util.eql(next, "..")) {
            stripLastComponent(&resolved);
            continue;
        }
        if (resolved.items[resolved.items.len - 1] != '/') util.bufByte(&resolved, '/');
        util.bufAppend(&resolved, next);
        if (os.lstatPath(resolved.items)) |st| {
            if (st.isLnk()) {
                num_symlinks += 1;
                if (num_symlinks > 33) {
                    if (die_on_error) util.die("More than {d} nested symlinks on path '{s}'", .{ 32, path });
                    return null;
                }
                var target = os.readLink(resolved.items) orelse {
                    if (die_on_error) util.dieErrno("Invalid symlink '{s}'", .{resolved.items});
                    return null;
                };
                var sym: util.Buf = .empty;
                if (target.len > 0 and target[0] == '/') {
                    resolved.clearRetainingCapacity();
                    util.bufByte(&resolved, '/');
                    target = target[1..];
                } else {
                    stripLastComponent(&resolved);
                }
                util.bufAppend(&sym, target);
                if (remaining.items.len > 0) {
                    util.bufByte(&sym, '/');
                    util.bufAppend(&sym, remaining.items);
                }
                remaining = sym;
            }
        } else {
            const en = os.errno();
            if (en != os.ENOENT or (!many_missing and remaining.items.len > 0)) {
                if (die_on_error) util.dieErrno("Invalid path '{s}'", .{resolved.items});
                return null;
            }
        }
    }
    return resolved.items;
}

/// real_pathdup(path, die_on_error)
pub fn realPathDup(path: []const u8, die_on_error: bool) ?[]const u8 {
    return realPathFlags(path, false, die_on_error);
}

// ---------------------------------------------------------------------------
// git directory validation

fn validateHeadRef(path: []const u8) bool {
    const st = os.lstatPath(path) orelse return false;
    if (st.isLnk()) {
        const t = os.readLink(path) orelse return false;
        return util.startsWith(t, "refs/");
    }
    const data = os.readFile(path) orelse return false;
    const buf = data[0..@min(data.len, 255)];
    if (util.startsWith(buf, "ref:")) {
        var rest = buf[4..];
        while (rest.len > 0 and std.ascii.isWhitespace(rest[0])) rest = rest[1..];
        if (util.startsWith(rest, "refs/")) return true;
    }
    if (buf.len >= 40 and util.isHex(buf[0..40])) {
        if (buf.len == 40 or !std.ascii.isHex(buf[40])) return true;
        if (buf.len >= 64 and util.isHex(buf[0..64]) and (buf.len == 64 or !std.ascii.isHex(buf[64]))) return true;
    }
    return false;
}

pub const CommonDir = struct { dir: []const u8, has_common: bool };

/// get_common_dir_noenv()
pub fn getCommonDirNoenv(gitdir: []const u8) CommonDir {
    const path = util.concat(&.{ gitdir, "/commondir" });
    if (!os.exists(path)) return .{ .dir = gitdir, .has_common = false };
    const data = os.readFile(path) orelse util.dieErrno("failed to read {s}", .{path});
    if (data.len == 0) util.dieErrno("failed to read {s}", .{path});
    var t: []const u8 = data;
    while (t.len > 0 and (t[t.len - 1] == '\n' or t[t.len - 1] == '\r')) t = t[0 .. t.len - 1];
    const p = if (t.len > 0 and t[0] == '/') t else util.concat(&.{ gitdir, "/", t });
    return .{ .dir = realPathDup(p, true).?, .has_common = true };
}

/// get_common_dir()
pub fn getCommonDirFull(gitdir: []const u8) CommonDir {
    if (os.getenv("GIT_COMMON_DIR")) |c| return .{ .dir = c, .has_common = true };
    return getCommonDirNoenv(gitdir);
}

fn getCommonDir(gitdir: []const u8) []const u8 {
    return getCommonDirFull(gitdir).dir;
}

/// is_git_directory()
pub fn isGitDirectory(suspect: []const u8) bool {
    const head = if (suspect.len > 0 and suspect[suspect.len - 1] == '/')
        util.concat(&.{ suspect, "HEAD" })
    else
        util.concat(&.{ suspect, "/HEAD" });
    if (!validateHeadRef(head)) return false;
    const common = getCommonDir(suspect);
    if (os.getenv("GIT_OBJECT_DIRECTORY")) |o| {
        if (!os.access(o, 1)) return false;
    } else if (!os.access(util.concat(&.{ common, "/objects" }), 1)) return false;
    if (!os.access(util.concat(&.{ common, "/refs" }), 1)) return false;
    return true;
}

pub const GitfileErr = enum { none, stat_failed, not_a_file, open_failed, read_failed, invalid_format, no_path, not_a_repo, too_large, missing, is_a_dir };

/// read_gitfile_raw()
fn readGitfileRaw(path: []const u8, out: *[]const u8) GitfileErr {
    const st = os.statPath(path) orelse {
        const e = os.errno();
        return if (e == os.ENOENT or e == os.ENOTDIR) .missing else .stat_failed;
    };
    if (st.isDir()) return .is_a_dir;
    if (!st.isReg()) return .not_a_file;
    if (st.size > (1 << 20)) return .too_large;
    const data = os.readFile(path) orelse return .open_failed;
    if (data.len != @as(usize, @intCast(st.size))) return .read_failed;
    if (!util.startsWith(data, "gitdir: ")) return .invalid_format;
    var len = data.len;
    while (len > 0 and (data[len - 1] == '\n' or data[len - 1] == '\r')) len -= 1;
    if (len < 9) return .no_path;
    out.* = data[8..len];
    return .none;
}

/// read_gitfile_gently(): returns the real path of the gitdir.
pub fn readGitfileGently(path: []const u8, err_out: ?*GitfileErr) ?[]const u8 {
    var contents: []const u8 = "";
    var code = readGitfileRaw(path, &contents);
    var result: ?[]const u8 = null;
    if (code == .none) {
        if (!(contents.len > 0 and contents[0] == '/')) {
            if (std.mem.lastIndexOfScalar(u8, path, '/')) |slash| {
                contents = util.concat(&.{ path[0 .. slash + 1], contents });
            }
        }
        if (!isGitDirectory(contents)) {
            code = .not_a_repo;
        } else {
            result = realPathDup(contents, true).?;
        }
    }
    if (err_out) |e| {
        e.* = code;
    } else if (code != .none) {
        readGitfileErrorDie(code, path);
    }
    return result;
}

pub fn readGitfileErrorDie(code: GitfileErr, path: []const u8) void {
    switch (code) {
        .none, .not_a_file, .stat_failed, .missing, .is_a_dir => {},
        .open_failed => util.dieErrno("error opening '{s}'", .{path}),
        .too_large => util.die("too large to be a .git file: '{s}'", .{path}),
        .read_failed => util.die("error reading {s}", .{path}),
        .invalid_format => util.die("invalid gitfile format: {s}", .{path}),
        .no_path => util.die("no path in gitfile: {s}", .{path}),
        .not_a_repo => util.die("gitfile does not point to a valid repository: {s}", .{path}),
    }
}

/// read_gitfile(): returns the gitdir path or null if `path` is not a
/// gitfile; dies on a malformed gitfile.
pub fn readGitfile(path: []const u8) ?[]const u8 {
    return readGitfileGently(path, null);
}

/// resolve_gitdir_gently()
pub fn resolveGitdir(suspect: []const u8) ?[]const u8 {
    if (isGitDirectory(suspect)) return suspect;
    var e: GitfileErr = .none;
    return readGitfileGently(suspect, &e);
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return util.normalizePath(p) orelse p;
    return util.normalizePath(util.joinPath(os.getcwd(), p)) orelse p;
}

// ---------------------------------------------------------------------------
// repository format

pub const RepoFormat = struct {
    version: i32 = -1,
    is_bare: i8 = -1,
    work_tree: ?[]const u8 = null,
    worktree_config: bool = false,
    object_format: []const u8 = "sha1",
    compat_object_format: ?[]const u8 = null,
    ref_storage: []const u8 = "files",
    precious_objects: bool = false,
    partial_clone: ?[]const u8 = null,
    relative_worktrees: bool = false,
    unknown_extensions: std.ArrayList([]const u8) = .empty,
    v1_only_extensions: std.ArrayList([]const u8) = .empty,
};

fn readWorktreeConfig(data: *RepoFormat, key: []const u8, value: ?[]const u8) i32 {
    if (util.eql(key, "core.bare")) {
        data.is_bare = @intFromBool(config.configBool(key, value));
    } else if (util.eql(key, "core.worktree")) {
        const v = value orelse {
            util.err("missing value for '{s}'", .{key});
            return -1;
        };
        data.work_tree = util.dupe(v);
    }
    return 0;
}

fn worktreeConfigCb(ctx: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo) i32 {
    _ = kvi;
    return readWorktreeConfig(@ptrCast(@alignCast(ctx)), key, value);
}

fn nonbool(key: []const u8) i32 {
    util.err("missing value for '{s}'", .{key});
    return -1;
}

const ExtResult = enum { err, unknown, ok };

fn handleExtensionV0(key: []const u8, value: ?[]const u8, ext: []const u8, data: *RepoFormat) ExtResult {
    if (util.eql(ext, "noop")) return .ok;
    if (util.eql(ext, "preciousobjects")) {
        data.precious_objects = config.configBool(key, value);
        return .ok;
    }
    if (util.eql(ext, "partialclone")) {
        const v = value orelse {
            _ = nonbool(key);
            return .err;
        };
        data.partial_clone = util.dupe(v);
        return .ok;
    }
    if (util.eql(ext, "worktreeconfig")) {
        data.worktree_config = config.configBool(key, value);
        return .ok;
    }
    return .unknown;
}

fn handleExtension(key: []const u8, value: ?[]const u8, ext: []const u8, data: *RepoFormat) ExtResult {
    if (util.eql(ext, "noop-v1")) return .ok;
    if (util.eql(ext, "objectformat")) {
        const v = value orelse {
            _ = nonbool(key);
            return .err;
        };
        if (!util.eql(v, "sha1") and !util.eql(v, "sha256")) {
            util.err("invalid value for '{s}': '{s}'", .{ "extensions.objectformat", v });
            return .err;
        }
        data.object_format = util.dupe(v);
        return .ok;
    }
    if (util.eql(ext, "compatobjectformat")) {
        const v = value orelse {
            _ = nonbool(key);
            return .err;
        };
        if (!util.eql(v, "sha1") and !util.eql(v, "sha256")) {
            util.err("invalid value for '{s}': '{s}'", .{ "extensions.compatobjectformat", v });
            return .err;
        }
        for (data.v1_only_extensions.items) |e| {
            if (util.eql(e, "compatobjectformat")) {
                util.err("'{s}' already specified as '{s}'", .{ "extensions.compatobjectformat", data.compat_object_format orelse "" });
                return .err;
            }
        }
        data.compat_object_format = util.dupe(v);
        return .ok;
    }
    if (util.eql(ext, "refstorage")) {
        const v = value orelse {
            _ = nonbool(key);
            return .err;
        };
        const fmt_ = if (std.mem.indexOf(u8, v, "://")) |i| v[0..i] else v;
        if (!util.eql(fmt_, "files") and !util.eql(fmt_, "reftable")) {
            util.err("invalid value for '{s}': '{s}'", .{ "extensions.refstorage", v });
            return .err;
        }
        data.ref_storage = util.dupe(fmt_);
        return .ok;
    }
    if (util.eql(ext, "relativeworktrees")) {
        data.relative_worktrees = config.configBool(key, value);
        return .ok;
    }
    if (util.eql(ext, "submodulepathconfig")) {
        _ = config.configBool(key, value);
        return .ok;
    }
    return .unknown;
}

fn checkRepoFormatCb(ctx: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo) i32 {
    const data: *RepoFormat = @ptrCast(@alignCast(ctx));
    if (util.eql(key, "core.repositoryformatversion")) {
        data.version = config.configInt(key, value, kvi);
    } else if (util.skipPrefix(key, "extensions.")) |ext| {
        switch (handleExtensionV0(key, value, ext, data)) {
            .err => return -1,
            .ok => return 0,
            .unknown => {},
        }
        switch (handleExtension(key, value, ext, data)) {
            .err => return -1,
            .ok => {
                data.v1_only_extensions.append(gpa, util.dupe(ext)) catch util.oom();
                return 0;
            },
            .unknown => {
                data.unknown_extensions.append(gpa, util.dupe(ext)) catch util.oom();
                return 0;
            },
        }
    }
    return readWorktreeConfig(data, key, value);
}

/// read_repository_format()
pub fn readRepositoryFormat(path: []const u8) RepoFormat {
    var f = RepoFormat{};
    _ = config.fromFile(.{ .f = checkRepoFormatCb, .ctx = &f }, path, .local, null, null);
    if (f.version == -1) f = RepoFormat{};
    return f;
}

/// verify_repository_format(); returns the error message or null.
pub fn verifyRepositoryFormat(f: *const RepoFormat) ?[]const u8 {
    if (f.version > 1) return util.fmt("Expected git repo version <= {d}, found {d}", .{ 1, f.version });
    if (f.version >= 1 and f.unknown_extensions.items.len > 0) {
        var b: util.Buf = .empty;
        util.bufAppend(&b, if (f.unknown_extensions.items.len == 1) "unknown repository extension found:" else "unknown repository extensions found:");
        for (f.unknown_extensions.items) |e| util.bufPrint(&b, "\n\t{s}", .{e});
        return b.items;
    }
    if (f.version == 0 and f.v1_only_extensions.items.len > 0) {
        var b: util.Buf = .empty;
        util.bufAppend(&b, if (f.v1_only_extensions.items.len == 1) "repo version is 0, but v1-only extension found:" else "repo version is 0, but v1-only extensions found:");
        for (f.v1_only_extensions.items) |e| util.bufPrint(&b, "\n\t{s}", .{e});
        return b.items;
    }
    return null;
}

pub var force_bare_repository = false;

/// read_and_verify_repository_format(); returns -1 when nongit_ok handled an error.
fn readAndVerifyRepositoryFormat(f: *RepoFormat, gitdir: []const u8, nongit_ok: ?*bool) i32 {
    const cd = getCommonDirFull(gitdir);
    var has_common = cd.has_common;
    f.* = readRepositoryFormat(util.concat(&.{ cd.dir, "/config" }));
    if (f.version < 0) return 0;
    if (verifyRepositoryFormat(f)) |e| {
        if (nongit_ok) |n| {
            util.warn("{s}", .{e});
            n.* = true;
            nongit_err = true;
            return -1;
        }
        util.die("{s}", .{e});
    }
    if (f.worktree_config) {
        _ = config.fromFile(.{ .f = worktreeConfigCb, .ctx = f }, util.concat(&.{ gitdir, "/config.worktree" }), .worktree, null, null);
        has_common = false;
    }
    if (force_bare_repository) {
        f.is_bare = 1;
        f.work_tree = null;
    } else if (has_common) {
        f.is_bare = -1;
        f.work_tree = null;
    }
    return 0;
}
var nongit_err = false;

// ---------------------------------------------------------------------------
// discovery

const Discovery = struct {
    format: RepoFormat = .{},
    gitdir: ?[]const u8 = null,
    worktree: ?[]const u8 = null,
    prefix: ?[]const u8 = null,

    fn setGitdir(self: *Discovery, gitdir: []const u8, make_realpath: bool) void {
        self.gitdir = if (make_realpath) realPathDup(gitdir, true).? else util.dupe(gitdir);
    }
    fn setWorktree(self: *Discovery, wt: []const u8) void {
        self.worktree = realPathDup(wt, true).?;
    }
};

fn envBool(name: []const u8, def: bool) bool {
    const v = os.getenv(name) orelse return def;
    return config.configBool(name, v);
}

/// dir_inside_of(): offset of the remainder of subdir, or null.
pub fn dirInsideOf(subdir: []const u8, dir: []const u8) ?usize {
    var i: usize = 0;
    while (i < dir.len and i < subdir.len and dir[i] == subdir[i]) i += 1;
    if (i < dir.len and i < subdir.len) return null;
    if (i == subdir.len) return if (i == dir.len) i else null;
    if (i < dir.len) return null;
    // dir exhausted, subdir continues
    if (dir.len > 0 and dir[dir.len - 1] == '/') return if (subdir[i - 1] == '/') i else null;
    return if (subdir[i] == '/') i + 1 else null;
}

fn discoverExplicit(d: *Discovery, gitdirenv0: []const u8, cwd: []const u8, nongit_ok: ?*bool) void {
    const work_tree_env = os.getenv("GIT_WORK_TREE");
    var gitdirenv = gitdirenv0;
    if (readGitfile(gitdirenv)) |g| gitdirenv = g;
    if (!isGitDirectory(gitdirenv)) {
        if (nongit_ok) |n| {
            n.* = true;
            return;
        }
        util.die("not a git repository: '{s}'", .{gitdirenv});
    }
    if (readAndVerifyRepositoryFormat(&d.format, gitdirenv, nongit_ok) != 0) return;

    if (work_tree_env) |wt| {
        d.format.work_tree = null;
        d.setWorktree(wt);
    } else if (d.format.is_bare > 0) {
        d.setGitdir(gitdirenv, false);
        return;
    } else if (d.format.work_tree) |cwt| {
        if (cwt.len > 0 and cwt[0] == '/') {
            d.setWorktree(cwt);
        } else {
            if (!os.chdir(gitdirenv)) util.dieErrno("cannot chdir to '{s}'", .{gitdirenv});
            if (!os.chdir(cwt)) util.dieErrno("cannot chdir to '{s}'", .{cwt});
            const core_wt = os.getcwd();
            if (!os.chdir(cwd)) util.dieErrno("cannot come back to cwd", .{});
            d.setWorktree(core_wt);
        }
    } else if (!envBool("GIT_IMPLICIT_WORK_TREE", true)) {
        d.setGitdir(gitdirenv, false);
        return;
    } else {
        d.setWorktree(".");
    }

    const wt = d.worktree.?;
    if (util.eql(cwd, wt)) {
        d.setGitdir(gitdirenv, false);
        return;
    }
    if (dirInsideOf(cwd, wt)) |off| {
        d.setGitdir(gitdirenv, true);
        if (!os.chdir(wt)) util.dieErrno("cannot chdir to '{s}'", .{wt});
        d.prefix = util.concat(&.{ cwd[off..], "/" });
        return;
    }
    d.setGitdir(gitdirenv, false);
}

fn discoverImplicit(d: *Discovery, gitdir0: []const u8, cwd: []const u8, offset: usize, nongit_ok: ?*bool) void {
    var gitdir = gitdir0;
    if (readAndVerifyRepositoryFormat(&d.format, gitdir, nongit_ok) != 0) return;
    if (os.getenv("GIT_WORK_TREE") != null or d.format.work_tree != null) {
        if (offset != cwd.len and !(gitdir.len > 0 and gitdir[0] == '/')) gitdir = realPathDup(gitdir, true).?;
        if (!os.chdir(cwd)) util.dieErrno("cannot come back to cwd", .{});
        discoverExplicit(d, gitdir, cwd, nongit_ok);
        return;
    }
    if (d.format.is_bare > 0) {
        d.setGitdir(gitdir, offset != cwd.len);
        if (!os.chdir(cwd)) util.dieErrno("cannot come back to cwd", .{});
        return;
    }
    d.setWorktree(".");
    if (!util.eql(gitdir, ".git")) d.setGitdir(gitdir, false);
    if (offset >= cwd.len) return;
    var off = offset;
    if (off != 1) off += 1;
    d.prefix = util.concat(&.{ cwd[off..], "/" });
}

fn discoverBare(d: *Discovery, cwd: []const u8, offset: usize, nongit_ok: ?*bool) void {
    if (readAndVerifyRepositoryFormat(&d.format, ".", nongit_ok) != 0) return;
    os.setEnv("GIT_IMPLICIT_WORK_TREE", "0");
    if (os.getenv("GIT_WORK_TREE") != null or d.format.work_tree != null) {
        const gitdir = if (offset == cwd.len) "." else util.dupe(cwd[0..offset]);
        if (!os.chdir(cwd)) util.dieErrno("cannot come back to cwd", .{});
        discoverExplicit(d, gitdir, cwd, nongit_ok);
        return;
    }
    if (offset != cwd.len) {
        if (!os.chdir(cwd)) util.dieErrno("cannot come back to cwd", .{});
        const root_len: usize = 1;
        d.setGitdir(cwd[0..@max(offset, root_len)], false);
    } else {
        d.setGitdir(".", false);
    }
}

const FindResult = enum { explicit, discovered, bare, hit_ceiling, hit_mount_point, invalid_ownership, disallowed_bare, invalid_gitfile };

// protected config (system, global, command line)
var protected_cfg: ?config.Config = null;
fn protectedConfig() *config.Config {
    if (protected_cfg == null) {
        protected_cfg = .{};
        const o = config.Options{};
        config.loadSequenceInto(&protected_cfg.?, &o);
    }
    return &protected_cfg.?;
}

extern "c" fn geteuid() u32;

fn ownedByCurrentUser(path: []const u8) bool {
    const st = os.lstatPath(path) orelse return false;
    var euid = geteuid();
    if (euid == 0) {
        if (st.uid == 0) return true;
        if (os.getenv("SUDO_UID")) |s| {
            if (s.len > 0) {
                if (std.fmt.parseInt(u32, s, 10)) |v| euid = v else |_| {}
            }
        }
    }
    return st.uid == euid;
}

/// ensure_valid_ownership()
fn ensureValidOwnership(gitfile: ?[]const u8, worktree: ?[]const u8, gitdir: ?[]const u8) bool {
    if (!envBool("GIT_TEST_ASSUME_DIFFERENT_OWNER", false) and
        (gitfile == null or ownedByCurrentUser(gitfile.?)) and
        (worktree == null or ownedByCurrentUser(worktree.?)) and
        (gitdir == null or ownedByCurrentUser(gitdir.?))) return true;
    const path = realPathDup(worktree orelse gitdir.?, false) orelse return false;
    var is_safe = false;
    for (protectedConfig().entries.items) |e| {
        if (!util.eql(e.key, "safe.directory")) continue;
        const v = e.value orelse "";
        if (v.len == 0) {
            is_safe = false;
        } else if (util.eql(v, "*")) {
            is_safe = true;
        } else {
            const allowed = config.interpolatePath(v, false) orelse continue;
            if (!(allowed.len > 0 and allowed[0] == '/') and !util.eql(allowed, ".")) {
                util.warn("safe.directory '{s}' not absolute", .{allowed});
                continue;
            }
            const normalized = realPathDup(allowed, false) orelse continue;
            if (util.endsWith(normalized, "/*")) {
                if (util.startsWith(path, normalized[0 .. normalized.len - 1])) is_safe = true;
            } else if (util.eql(path, normalized)) {
                is_safe = true;
            }
        }
    }
    return is_safe;
}

/// die_upon_dubious_ownership()
pub fn dieUponDubiousOwnership(gitfile: ?[]const u8, worktree: ?[]const u8, gitdir: []const u8) void {
    if (ensureValidOwnership(gitfile, worktree, gitdir)) return;
    const path = gitfile orelse gitdir;
    var q: util.Buf = .empty;
    @import("trace.zig").quoteArg(&q, path);
    util.die("detected dubious ownership in repository at '{s}'\nTo add an exception for this directory, call:\n\n\tgit config --global --add safe.directory {s}", .{ path, q.items });
}

fn allowedBareRepo() []const u8 {
    var result: []const u8 = "all";
    for (protectedConfig().entries.items) |e| {
        if (!util.eql(e.key, "safe.barerepository")) continue;
        const v = e.value orelse "";
        if (util.eql(v, "explicit") or util.eql(v, "all")) {
            result = if (util.eql(v, "explicit")) "explicit" else "all";
        } else {
            if (e.origin.len > 0) {
                util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ "safe.bareRepository", e.origin, e.line });
            }
            util.die("bad config variable '{s}'", .{"safe.bareRepository"});
        }
    }
    return result;
}

fn isImplicitBareRepo(path: []const u8) bool {
    if (util.eql(path, ".git") or util.endsWith(path, "/.git")) return true;
    if (std.mem.indexOf(u8, path, "/.git/worktrees/") != null) return true;
    if (std.mem.indexOf(u8, path, "/.git/modules/") != null) return true;
    return false;
}

fn longestAncestorLength(path: []const u8, prefixes: []const []const u8) i64 {
    if (util.eql(path, "/")) return -1;
    var max_len: i64 = -1;
    for (prefixes) |ceil| {
        var len = ceil.len;
        if (len > 0 and ceil[len - 1] == '/') len -= 1;
        if (path.len <= len + 1) continue;
        if (!util.eql(path[0..len], ceil[0..len]) or path[len] != '/') continue;
        if (@as(i64, @intCast(len)) > max_len) max_len = @intCast(len);
    }
    return max_len;
}

/// repo_discovery_find_dir()
fn findDir(dir: *util.Buf, gitdir: *util.Buf, die_on_error: bool) FindResult {
    if (os.getenv("GIT_DIR")) |g| {
        util.bufAppend(gitdir, g);
        return .explicit;
    }
    const min_offset: i64 = 1;
    var ceil_offset: i64 = -1;
    if (os.getenv("GIT_CEILING_DIRECTORIES")) |env| {
        var list: std.ArrayList([]const u8) = .empty;
        var empty_found = false;
        var it = std.mem.splitScalar(u8, env, ':');
        while (it.next()) |c0| {
            if (c0.len == 0) {
                empty_found = true;
                continue;
            }
            if (c0[0] != '/') continue;
            if (empty_found) {
                list.append(gpa, c0) catch util.oom();
                continue;
            }
            const rp = realPathDup(c0, false) orelse continue;
            list.append(gpa, rp) catch util.oom();
        }
        ceil_offset = longestAncestorLength(dir.items, list.items);
    }
    if (ceil_offset < 0) ceil_offset = min_offset - 2;

    const one_fs = !envBool("GIT_DISCOVERY_ACROSS_FILESYSTEM", false);
    var cur_dev: u64 = 0;
    if (one_fs) {
        const st = os.statPath(dir.items) orelse util.dieErrno("failed to stat '{s}'", .{dir.items});
        cur_dev = st.dev;
    }
    while (true) {
        var offset: i64 = @intCast(dir.items.len);
        if (offset > min_offset) util.bufByte(dir, '/');
        util.bufAppend(dir, ".git");
        var code: GitfileErr = .none;
        var found = readGitfileGently(dir.items, &code);
        var gitdir_path: ?[]const u8 = null;
        var gitfile: ?[]const u8 = null;
        if (found == null) {
            switch (code) {
                .missing => {},
                .is_a_dir => {
                    if (isGitDirectory(dir.items)) {
                        found = ".git";
                        gitdir_path = util.dupe(dir.items);
                    }
                },
                .stat_failed => {
                    if (die_on_error) util.die("error reading '{s}'", .{dir.items});
                    return .invalid_gitfile;
                },
                .not_a_file => {
                    if (die_on_error) util.die("not a regular file: '{s}'", .{dir.items});
                    return .invalid_gitfile;
                },
                else => {
                    if (die_on_error) readGitfileErrorDie(code, dir.items);
                    return .invalid_gitfile;
                },
            }
        } else {
            gitfile = util.dupe(dir.items);
        }
        dir.shrinkRetainingCapacity(@intCast(offset));
        if (found) |g| {
            if (ensureValidOwnership(gitfile, dir.items, gitdir_path orelse g)) {
                util.bufAppend(gitdir, g);
                return .discovered;
            }
            return .invalid_ownership;
        }
        if (isGitDirectory(dir.items)) {
            @import("trace2.zig").dataString("setup", false, "implicit-bare-repository", dir.items);
            if (util.eql(allowedBareRepo(), "explicit") and !isImplicitBareRepo(dir.items)) return .disallowed_bare;
            if (!ensureValidOwnership(null, null, dir.items)) return .invalid_ownership;
            util.bufAppend(gitdir, ".");
            return .bare;
        }
        if (offset <= min_offset) return .hit_ceiling;
        offset -= 1;
        while (offset > ceil_offset and dir.items[@intCast(offset)] != '/') offset -= 1;
        if (offset <= ceil_offset) return .hit_ceiling;
        dir.shrinkRetainingCapacity(@intCast(if (offset > min_offset) offset else min_offset));
        if (one_fs) {
            const st = os.statPath(dir.items) orelse util.dieErrno("failed to stat '{s}'", .{dir.items});
            if (st.dev != cur_dev) return .hit_mount_point;
        }
    }
}

/// discover_git_directory(): find the repository without changing any
/// state (for early config). Returns gitdir (absolute or relative to cwd).
pub fn discoverGitDirectory() ?struct { gitdir: []const u8, commondir: []const u8 } {
    const cwd = os.getcwd();
    var dir: util.Buf = .empty;
    util.bufAppend(&dir, cwd);
    var gitdir: util.Buf = .empty;
    const r = findDir(&dir, &gitdir, false);
    switch (r) {
        .explicit, .discovered, .bare => {},
        else => return null,
    }
    var gd: []const u8 = gitdir.items;
    if (dir.items.len < cwd.len and !(gd.len > 0 and gd[0] == '/')) {
        gd = if (util.eql(gd, ".")) util.dupe(dir.items) else util.concat(&.{ dir.items, "/", gd });
    }
    const cd = getCommonDir(gd);
    const f = readRepositoryFormat(util.concat(&.{ cd, "/config" }));
    if (verifyRepositoryFormat(&f)) |e| {
        util.warn("ignoring git dir '{s}': {s}", .{ gd, e });
        return null;
    }
    return .{ .gitdir = gd, .commondir = cd };
}

pub var outside_worktree = false;
/// cwd at the time of setup (before any chdir to the worktree root)
pub var original_cwd: []const u8 = "";
pub var have_repository = false;

var setup_done = false;

/// setup_git_directory_gently(). If nongit_ok, returns without error when
/// not in a repository.
pub fn setup(nongit_ok: bool) void {
    if (setup_done) {
        if (repo_ == null and !nongit_ok) util.die("not a git repository (or any of the parent directories): .git", .{});
        return;
    }
    setup_done = true;
    var no_repo = false;
    const nptr: ?*bool = if (nongit_ok) &no_repo else null;
    const cwd = os.getcwd();
    original_cwd = cwd;
    var d = Discovery{};

    var dir: util.Buf = .empty;
    util.bufAppend(&dir, cwd);
    var gitdir: util.Buf = .empty;
    switch (findDir(&dir, &gitdir, true)) {
        .explicit => discoverExplicit(&d, gitdir.items, cwd, nptr),
        .discovered => {
            if (dir.items.len < cwd.len and !os.chdir(dir.items)) util.die("cannot change to '{s}'", .{dir.items});
            discoverImplicit(&d, gitdir.items, cwd, dir.items.len, nptr);
        },
        .bare => {
            if (dir.items.len < cwd.len and !os.chdir(dir.items)) util.die("cannot change to '{s}'", .{dir.items});
            discoverBare(&d, cwd, dir.items.len, nptr);
        },
        .hit_ceiling => {
            if (!nongit_ok) util.die("not a git repository (or any of the parent directories): {s}", .{".git"});
            no_repo = true;
        },
        .hit_mount_point => {
            if (!nongit_ok) util.die("not a git repository (or any parent up to mount point {s})\nStopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).", .{dir.items});
            no_repo = true;
        },
        .invalid_ownership => {
            if (!nongit_ok) {
                var q: util.Buf = .empty;
                @import("trace.zig").quoteArg(&q, dir.items);
                util.die("detected dubious ownership in repository at '{s}'\nTo add an exception for this directory, call:\n\n\tgit config --global --add safe.directory {s}", .{ dir.items, q.items });
            }
            no_repo = true;
        },
        .disallowed_bare => {
            if (!nongit_ok) util.die("cannot use bare repository '{s}' (safe.bareRepository is '{s}')", .{ dir.items, allowedBareRepo() });
            no_repo = true;
        },
        .invalid_gitfile => unreachable,
    }
    have_repository = !no_repo;

    if (have_repository) {
        var git_dir: []const u8 = undefined;
        if (d.gitdir) |g| {
            git_dir = g;
            os.setEnv("GIT_DIR", g);
        } else {
            git_dir = os.getenv("GIT_DIR") orelse ".git";
        }
        // repo_set_gitdir(): follow a gitfile
        if (readGitfile(git_dir)) |g| git_dir = g;
        const common = if (os.getenv("GIT_COMMON_DIR")) |c| c else getCommonDirNoenv(git_dir).dir;
        const f = d.format;
        const r = gpa.create(Repo) catch util.oom();
        r.* = .{
            .git_dir = git_dir,
            .common_dir = common,
            .work_tree = d.worktree,
            .prefix = d.prefix orelse "",
            .bare_cfg = f.is_bare,
            .format_version = if (f.version < 0) 0 else f.version,
            .worktree_config = f.worktree_config,
            .object_format = f.object_format,
            .precious_objects = f.precious_objects,
            .partial_clone = f.partial_clone,
            .ref_storage = f.ref_storage,
        };
        if (os.getenv("GIT_REFERENCE_BACKEND")) |uri| {
            const fmt_ = if (std.mem.indexOf(u8, uri, "://")) |i| uri[0..i] else uri;
            if (!util.eql(fmt_, "files") and !util.eql(fmt_, "reftable")) util.die("unknown ref storage format: '{s}'", .{fmt_});
            r.ref_storage = fmt_;
        }
        if (f.is_bare > 0 and f.work_tree != null) {
            util.warn("core.bare and core.worktree do not make sense", .{});
            r.worktree_config_is_bogus = true;
        }
        r.bare = r.bare_cfg != 0 and r.work_tree == null;
        repo_ = r;
        if (r.work_tree) |wt| {
            @import("trace2.zig").defRepo(wt);
            outside_worktree = d.prefix == null and !util.eql(cwd, wt) and dirInsideOf(cwd, wt) == null;
        }
    }
    os.setEnv("GIT_PREFIX", d.prefix orelse "");
    loadConfig();
}

/// trace_repo_setup()
pub fn traceRepoSetup() void {
    if (!trace.want(&trace.setup_key)) return;
    const r = repo_ orelse return;
    const cwd = os.getcwd();
    trace.printf(&trace.setup_key, "trace.c", 316, "setup: git_dir: {s}", .{trace.quoteCrnl(r.git_dir)});
    trace.printf(&trace.setup_key, "trace.c", 317, "setup: git_common_dir: {s}", .{trace.quoteCrnl(r.common_dir)});
    trace.printf(&trace.setup_key, "trace.c", 318, "setup: worktree: {s}", .{trace.quoteCrnl(r.work_tree orelse "(null)")});
    trace.printf(&trace.setup_key, "trace.c", 319, "setup: cwd: {s}", .{trace.quoteCrnl(cwd)});
    trace.printf(&trace.setup_key, "trace.c", 320, "setup: prefix: {s}", .{trace.quoteCrnl(if (r.prefix.len == 0) "(null)" else r.prefix)});
}

pub fn currentBranchForConfig() ?[]const u8 {
    const r = repo_ orelse return null;
    const data = @import("refs.zig").headContentsAt(r.git_dir) orelse return null;
    const rest = util.skipPrefix(data, "ref: refs/heads/") orelse return null;
    return util.trimRight(rest);
}

pub fn globalConfigPaths() struct { xdg: ?[]const u8, home: ?[]const u8 } {
    const g = config.globalConfigPaths();
    return .{ .xdg = g.xdg, .home = g.user };
}

pub fn systemConfigPath() ?[]const u8 {
    if (!config.useSystemConfig()) return null;
    return config.systemConfigPath();
}

/// (Re)load the configuration for the current repository state.
pub fn loadConfig() void {
    cfg = .{};
    if (repo_) |r| {
        cfg.git_dir = r.git_dir;
        cfg.current_branch = currentBranchForConfig();
    }
    const o = config.repoOptions();
    config.loadSequenceInto(&cfg, &o);
    // git_default_core_config(): core.quotepath applies to every command
    util.quote_path_fully = cfg.getBool("core.quotepath") orelse true;
}

/// The value checks git_default_core_config() performs on every core.*
/// entry when a builtin reads its config: bad booleans/numbers die.
pub fn validateDefaultConfig() void {
    const bool_keys = [_][]const u8{ "core.filemode", "core.trustctime", "core.quotepath", "core.symlinks", "core.ignorecase", "core.bare", "core.ignorestat", "core.fsyncobjectfiles", "core.lockfilepid", "core.sparsecheckout", "core.sparsecheckoutcone", "core.precomposeunicode", "core.protecthfs", "core.protectntfs" };
    for (cfg.entries.items) |e| {
        if (!std.mem.startsWith(u8, e.key, "core.")) continue;
        const kv = e.kvi();
        var bad = false;
        for (bool_keys) |k| {
            if (util.eql(e.key, k)) _ = config.configBool(e.key, e.value);
        }
        if (util.eql(e.key, "core.autocrlf")) {
            if (!(e.value != null and std.ascii.eqlIgnoreCase(e.value.?, "input"))) _ = config.configBool(e.key, e.value);
        } else if (util.eql(e.key, "core.safecrlf")) {
            if (!(e.value != null and std.ascii.eqlIgnoreCase(e.value.?, "warn"))) _ = config.configBool(e.key, e.value);
        } else if (util.eql(e.key, "core.compression") or util.eql(e.key, "core.loosecompression")) {
            const lvl = config.configInt(e.key, e.value, &kv);
            if (lvl < -1 or lvl > 9) {
                util.die("bad zlib compression level {d}", .{lvl});
            }
        } else if (util.eql(e.key, "core.abbrev")) {
            if (e.value) |v| {
                if (!std.ascii.eqlIgnoreCase(v, "auto") and config.parseMaybeBoolText(v) != 0) {
                    const n = config.configInt(e.key, v, &kv);
                    if (n < 4) {
                        util.err("abbrev length out of range: {d}", .{n});
                        bad = true;
                    }
                }
            } else bad = config.errorNonbool(e.key) < 0;
        } else if (util.eql(e.key, "core.checkstat")) {
            if (e.value) |v| {
                if (!std.ascii.eqlIgnoreCase(v, "default") and !std.ascii.eqlIgnoreCase(v, "minimal")) {
                    util.err("invalid value for '{s}': '{s}'", .{ e.key, v });
                    bad = true;
                }
            } else bad = config.errorNonbool(e.key) < 0;
        }
        if (bad) {
            if (e.origin_type == .cmdline) util.die("unable to parse '{s}' from command-line config", .{e.key});
            util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
        }
    }
}

/// Record a -c option: exported via GIT_CONFIG_PARAMETERS for children.
pub fn addCmdlineConfig(kv: []const u8) void {
    var b: util.Buf = .empty;
    if (os.getenv("GIT_CONFIG_PARAMETERS")) |old| {
        util.bufAppend(&b, old);
        util.bufByte(&b, ' ');
    }
    if (std.mem.indexOfScalar(u8, kv, '=')) |eq| {
        util.sqQuote(&b, kv[0..eq]);
        util.bufByte(&b, '=');
        util.sqQuote(&b, kv[eq + 1 ..]);
    } else {
        util.sqQuote(&b, kv);
    }
    os.setEnv("GIT_CONFIG_PARAMETERS", b.items);
}

/// Path relative to worktree root, given a user-supplied path relative to cwd (prefix).
pub fn prefixPath(arg: []const u8) ?[]const u8 {
    const r = repo();
    var full: []const u8 = undefined;
    if (arg.len > 0 and arg[0] == '/') {
        const wt = r.work_tree orelse return null;
        const n = util.normalizePath(arg) orelse return null;
        if (util.eql(n, wt)) return "";
        if (util.startsWith(n, wt) and n.len > wt.len and n[wt.len] == '/') return n[wt.len + 1 ..];
        // try realpath
        if (os.realPath(util.dirname(arg))) |rp| {
            const n2 = util.joinPath(rp, util.basename(arg));
            if (util.startsWith(n2, wt) and n2.len > wt.len and n2[wt.len] == '/') return n2[wt.len + 1 ..];
            if (util.eql(rp, wt) and util.basename(arg).len == 0) return "";
        }
        return null;
    }
    full = util.concat(&.{ r.prefix, arg });
    const n = util.normalizePath(full) orelse return null;
    return n;
}
