//! Content conversion between worktree and repository (crlf, ident, filters).
//! Placeholder implementation: identity conversion. Full port lives here later.

const std = @import("std");
const util = @import("util.zig");

/// Convert worktree content to repository form (clean).
pub fn toGit(path: []const u8, data: []const u8) []const u8 {
    _ = path;
    return data;
}

/// Like toGit, but performs safecrlf checks (may warn/die) when `write_object`.
pub fn toGitChecked(path: []const u8, data: []const u8, write_object: bool) []const u8 {
    _ = write_object;
    return toGit(path, data);
}

/// Convert repository content to worktree form (smudge).
pub fn toWorktree(path: []const u8, data: []const u8) []const u8 {
    _ = path;
    return data;
}
