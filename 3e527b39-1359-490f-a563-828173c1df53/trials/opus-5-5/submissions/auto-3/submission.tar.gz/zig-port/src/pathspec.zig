//! Pathspec parsing and matching (port of pathspec.c / dir.c match_pathspec).

const std = @import("std");
const util = @import("util.zig");
const repo_mod = @import("repo.zig");
const wildmatch = @import("wildmatch.zig");
const gpa = util.gpa;

pub const Item = struct {
    /// pattern relative to the top of the worktree (prefix applied)
    match: []const u8,
    /// original argument
    original: []const u8,
    /// length of leading part without glob chars
    nowildcard_len: usize,
    literal: bool = false,
    glob: bool = false,
    icase: bool = false,
    exclude: bool = false,
    top: bool = false,
};

pub const Flags = struct {
    /// die if a path is outside the repository
    keep_outside: bool = false,
    /// treat all pathspecs literally
    literal: bool = false,
    /// no magic allowed
    no_magic: bool = false,
    /// pathspec is relative to the prefix
    prefer_full: bool = false,
};

pub const Pathspec = struct {
    items: []Item = &.{},

    pub fn isEmpty(self: *const Pathspec) bool {
        return self.items.len == 0;
    }

    /// Does `path` match? `is_dir` allows matching "dir/" items against directories.
    pub fn matches(self: *const Pathspec, path: []const u8, is_dir: bool) bool {
        if (self.items.len == 0) return true;
        var any_pos = false;
        var matched = false;
        for (self.items) |*it| {
            if (it.exclude) continue;
            any_pos = true;
            if (matchItem(it, path, is_dir) != .none) {
                matched = true;
                break;
            }
        }
        if (!any_pos) matched = true;
        if (!matched) return false;
        for (self.items) |*it| {
            if (!it.exclude) continue;
            if (matchItem(it, path, is_dir) != .none) return false;
        }
        return true;
    }

    /// Index of the first item matching path, or null. Used for "did not match" reporting.
    pub fn matchingItem(self: *const Pathspec, path: []const u8, is_dir: bool) ?usize {
        for (self.items, 0..) |*it, i| {
            if (it.exclude) continue;
            if (matchItem(it, path, is_dir) != .none) return i;
        }
        return null;
    }

    /// Could anything under directory `dir` (no trailing slash) match?
    pub fn couldMatchUnder(self: *const Pathspec, dir: []const u8) bool {
        if (self.items.len == 0) return true;
        for (self.items) |*it| {
            if (it.exclude) continue;
            const m = it.match;
            // pattern is inside dir
            if (m.len == 0) return true;
            if (util.startsWith(m, dir) and (m.len == dir.len or m[dir.len] == '/')) return true;
            // dir is inside the pattern's directory
            if (util.startsWith(dir, m[0..it.nowildcard_len]) or util.startsWith(m[0..it.nowildcard_len], dir)) return true;
        }
        return false;
    }
};

pub const MatchKind = enum { none, exact, leading_dir, wildcard };

pub fn matchItem(it: *const Item, path: []const u8, is_dir: bool) MatchKind {
    var m = it.match;
    if (m.len == 0) return .leading_dir;
    var want_dir = false;
    if (m[m.len - 1] == '/') {
        m = m[0 .. m.len - 1];
        want_dir = true;
    }
    const eq = if (it.icase) std.ascii.eqlIgnoreCase else util.eql;
    if (path.len == m.len and eq(path, m)) {
        if (want_dir and !is_dir) {
            // "dir/" matches only a directory
        } else return .exact;
    }
    // leading directory: pattern "a/b" matches "a/b/c"
    if (path.len > m.len and path[m.len] == '/' and eq(path[0..m.len], m)) return .leading_dir;
    if (!it.literal and it.nowildcard_len < it.match.len) {
        var flags: u32 = 0;
        if (it.icase) flags |= wildmatch.CASEFOLD;
        if (it.glob) flags |= wildmatch.PATHNAME;
        if (wildmatch.match(it.match, path, flags)) return .wildcard;
    }
    return .none;
}

fn globalLiteral() bool {
    return envBool("GIT_LITERAL_PATHSPECS");
}
fn globalGlob() bool {
    return envBool("GIT_GLOB_PATHSPECS");
}
fn globalNoglob() bool {
    return envBool("GIT_NOGLOB_PATHSPECS");
}
fn globalIcase() bool {
    return envBool("GIT_ICASE_PATHSPECS");
}

fn envBool(name: []const u8) bool {
    const v = @import("os.zig").getenv(name) orelse return false;
    return @import("config.zig").parseBool(v) orelse false;
}

fn noWildcardLen(s: []const u8) usize {
    for (s, 0..) |ch, i| {
        if (ch == '*' or ch == '?' or ch == '[' or ch == '\\') return i;
    }
    return s.len;
}

/// Parse pathspec arguments relative to `prefix` (e.g. "sub/" or "").
pub fn parse(prefix: []const u8, args: []const []const u8, flags: Flags) Pathspec {
    var items: std.ArrayList(Item) = .empty;
    const lit_all = flags.literal or globalLiteral();
    for (args) |arg| {
        var it = Item{ .match = "", .original = arg, .nowildcard_len = 0 };
        var elt = arg;
        var use_prefix = true;
        if (!lit_all and elt.len > 0 and elt[0] == ':') {
            // magic
            if (elt.len > 1 and elt[1] == '(') {
                const close = std.mem.indexOfScalar(u8, elt, ')') orelse util.die("Missing ')' at the end of pathspec magic in '{s}'", .{arg});
                var mit = std.mem.splitScalar(u8, elt[2..close], ',');
                while (mit.next()) |word| {
                    if (util.eql(word, "top")) {
                        use_prefix = false;
                        it.top = true;
                    } else if (util.eql(word, "literal")) {
                        it.literal = true;
                    } else if (util.eql(word, "glob")) {
                        it.glob = true;
                    } else if (util.eql(word, "icase")) {
                        it.icase = true;
                    } else if (util.eql(word, "exclude")) {
                        it.exclude = true;
                    } else if (util.startsWith(word, "prefix:")) {
                        // internal
                    } else if (util.startsWith(word, "attr:")) {
                        // attr magic not supported yet
                    } else if (word.len == 0) {} else {
                        util.die("Invalid pathspec magic '{s}' in '{s}'", .{ word, arg });
                    }
                }
                elt = elt[close + 1 ..];
            } else {
                var i: usize = 1;
                while (i < elt.len and elt[i] != ':') : (i += 1) {
                    switch (elt[i]) {
                        '/' => {
                            use_prefix = false;
                            it.top = true;
                        },
                        '!', '^' => it.exclude = true,
                        else => {
                            if (std.ascii.isAlphanumeric(elt[i])) break;
                            util.die("Unimplemented pathspec magic '{c}' in '{s}'", .{ elt[i], arg });
                        },
                    }
                }
                if (i < elt.len and elt[i] == ':') i += 1;
                elt = elt[i..];
            }
        }
        if (lit_all) it.literal = true;
        if (globalIcase()) it.icase = true;
        if (globalGlob() and !it.literal) it.glob = true;
        if (globalNoglob() and !it.glob) it.literal = true;
        var full: []const u8 = undefined;
        if (use_prefix) {
            if (elt.len > 0 and elt[0] == '/') {
                full = absToRel(elt, arg, flags);
            } else {
                const joined = util.concat(&.{ prefix, elt });
                const trailing = elt.len > 0 and elt[elt.len - 1] == '/';
                const n = util.normalizePath(joined) orelse
                    util.die("{s}: '{s}' is outside repository at '{s}'", .{ arg, arg, repoTop() });
                full = if (trailing and n.len > 0 and n[n.len - 1] != '/') util.concat(&.{ n, "/" }) else n;
            }
        } else {
            const n = util.normalizePath(elt) orelse util.die("{s}: '{s}' is outside repository at '{s}'", .{ arg, arg, repoTop() });
            full = n;
        }
        if (util.eql(full, ".") or util.eql(full, "./")) full = "";
        it.match = full;
        it.nowildcard_len = if (it.literal) full.len else noWildcardLen(full);
        items.append(gpa, it) catch util.oom();
    }
    return .{ .items = items.items };
}

fn repoTop() []const u8 {
    if (repo_mod.repo_) |r| return r.work_tree orelse r.git_dir;
    return "";
}

fn absToRel(elt: []const u8, arg: []const u8, flags: Flags) []const u8 {
    _ = flags;
    if (repo_mod.repo_ != null) {
        if (repo_mod.prefixPath(elt)) |p| return p;
    }
    util.die("{s}: '{s}' is outside repository at '{s}'", .{ arg, arg, repoTop() });
}
