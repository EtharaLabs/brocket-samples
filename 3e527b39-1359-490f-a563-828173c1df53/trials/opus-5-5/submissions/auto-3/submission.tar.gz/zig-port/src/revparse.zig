//! Object name parsing (port of object-name.c): get_oid and friends.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const objects = @import("objects.zig");
const index_mod = @import("index.zig");
const date = @import("date.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

pub const Want = enum { any, commit, committish, tree, treeish, blob };

pub const Opts = struct {
    want: Want = .any,
    /// die with helpful messages (only_to_die / GET_OID_ONLY_TO_DIE semantics)
    die_on_error: bool = false,
    /// quiet: don't print ambiguity errors
    quiet: bool = false,
};

pub const Result = struct {
    oid: Oid,
    /// for "<tree>:<path>" lookups
    path: ?[]const u8 = null,
    mode: u32 = 0,
    /// full ref name if resolved from a ref
    ref: ?[]const u8 = null,
};

/// Set to an error message by the last failed lookup (if any).
pub var last_error: ?[]const u8 = null;

pub fn getOid(name: []const u8) ?Oid {
    const r = resolve(name, .{}) orelse return null;
    return r.oid;
}

pub fn getOidCommittish(name: []const u8) ?Oid {
    const r = resolve(name, .{ .want = .committish }) orelse return null;
    return r.oid;
}

/// Resolve name to a commit oid (peeling tags). Returns null if not a commit.
pub fn getCommit(name: []const u8) ?Oid {
    const r = resolve(name, .{ .want = .committish }) orelse return null;
    return objects.peelTo(r.oid, .commit);
}

pub fn getTreeish(name: []const u8) ?Oid {
    const r = resolve(name, .{ .want = .treeish }) orelse return null;
    return objects.peelTo(r.oid, .tree);
}

pub fn resolve(name: []const u8, opts: Opts) ?Result {
    last_error = null;
    if (name.len == 0) return null;
    // ":path" / ":N:path" / ":/regex"
    if (name[0] == ':') return resolveColon(name, opts);
    // find a ':' not inside @{...} or ^{...}
    var depth: usize = 0;
    var i: usize = 0;
    while (i < name.len) : (i += 1) {
        const ch = name[i];
        if (ch == '{') depth += 1 else if (ch == '}' and depth > 0) depth -= 1 else if (ch == ':' and depth == 0) {
            const base = name[0..i];
            const path = name[i + 1 ..];
            const tr = resolve(base, .{ .want = .treeish, .die_on_error = opts.die_on_error, .quiet = opts.quiet }) orelse return null;
            const tree = objects.peelTo(tr.oid, .tree) orelse {
                if (opts.die_on_error) util.die("invalid object name '{s}'.", .{base});
                return null;
            };
            const full_path = if (util.startsWith(path, "./") or util.startsWith(path, "../") or util.eql(path, ".") or util.eql(path, ".."))
                resolveRelative(path, opts) orelse return null
            else
                path;
            if (full_path.len == 0) return .{ .oid = tree, .path = "", .mode = 0o40000 };
            const ent = objects.treeLookup(tree, full_path) orelse {
                if (opts.die_on_error) diePathInTree(base, full_path, path);
                return null;
            };
            return .{ .oid = ent.oid, .path = full_path, .mode = ent.mode };
        }
    }
    const oid = getOidBasicWithSuffix(name, opts) orelse return null;
    return .{ .oid = oid };
}

fn resolveRelative(path: []const u8, opts: Opts) ?[]const u8 {
    _ = opts;
    const prefix = if (repo_mod.repo_) |r| r.prefix else "";
    const joined = util.concat(&.{ prefix, path });
    const n = util.normalizePath(joined) orelse util.die("'{s}' is outside repository", .{path});
    var s: []const u8 = n;
    if (s.len > 0 and s[s.len - 1] == '/') s = s[0 .. s.len - 1];
    return s;
}

fn diePathInTree(base: []const u8, full: []const u8, given: []const u8) noreturn {
    const r = repo_mod.repo_;
    if (r != null and r.?.work_tree != null) {
        const prefix = r.?.prefix;
        // exists on disk?
        if (os.lstatPath(full) != null) {
            util.die("path '{s}' exists on disk, but not in '{s}'", .{ full, base });
        }
        if (prefix.len > 0) {
            const alt = util.concat(&.{ prefix, given });
            if (objects.treeLookup(objects.peelTo(getOid(base).?, .tree).?, alt) != null) {
                util.die("path '{s}' exists, but not '{s}'\nhint: Did you mean '{s}:{s}' aka '{s}:./{s}'?", .{ alt, given, base, alt, base, given });
            }
        }
    }
    util.die("path '{s}' does not exist in '{s}'", .{ full, base });
}

fn resolveColon(name: []const u8, opts: Opts) ?Result {
    var rest = name[1..];
    if (rest.len > 0 and rest[0] == '/') {
        // :/regex  search commit messages reachable from all refs
        const pat = rest[1..];
        if (pat.len > 0 and pat[0] == '!' and !(pat.len > 1 and pat[1] == '!')) {
            if (opts.die_on_error) util.die("bad revision ':{s}'", .{rest});
            return null;
        }
        const oid = searchMessage(if (util.startsWith(pat, "!!")) pat[1..] else pat, null) orelse {
            if (opts.die_on_error) util.die("bad revision '{s}'", .{name});
            return null;
        };
        return .{ .oid = oid };
    }
    var stage: u32 = 0;
    if (rest.len >= 2 and rest[0] >= '0' and rest[0] <= '3' and rest[1] == ':') {
        stage = rest[0] - '0';
        rest = rest[2..];
    }
    const path = if (util.startsWith(rest, "./") or util.startsWith(rest, "../") or util.eql(rest, ".") or util.eql(rest, ".."))
        resolveRelative(rest, opts) orelse return null
    else
        rest;
    if (repo_mod.repo_ == null) return null;
    const idx = index_mod.get();
    switch (idx.pos(path, stage)) {
        .found => |i| {
            const e = &idx.entries.items[i];
            return .{ .oid = e.oid, .path = path, .mode = e.mode };
        },
        .missing => {},
    }
    if (opts.die_on_error) {
        if (stage == 0 and idx.hasPath(path)) {
            util.die("path '{s}' is in the index, but not at stage 0\nhint: Did you mean ':{d}:{s}'?", .{ path, idx.entries.items[idx.firstPos(path)].stage(), path });
        }
        if (idx.hasPath(path)) {
            util.die("path '{s}' is in the index, but not at stage {d}", .{ path, stage });
        }
        if (os.lstatPath(path) != null) util.die("path '{s}' exists on disk, but not in the index", .{path});
        util.die("path '{s}' does not exist (neither on disk nor in the index)", .{path});
    }
    return null;
}

/// Search commits reachable from `start` (or all refs) for a message matching regex.
pub fn searchMessage(pattern: []const u8, start: ?[]const Oid) ?Oid {
    const regex = @import("regex.zig");
    const re = switch (regex.Regex.compile(pattern, .{})) {
        .ok => |r| r,
        .err => return null,
    };
    var heap: std.ArrayList(*objects.Commit) = .empty;
    var seen: hash.OidSet = .empty;
    var starts: std.ArrayList(Oid) = .empty;
    if (start) |s| {
        starts.appendSlice(gpa, s) catch util.oom();
    } else {
        for (refs.list("refs/")) |rf| starts.append(gpa, rf.oid) catch util.oom();
        if (refs.readOid("HEAD")) |h| starts.append(gpa, h) catch util.oom();
    }
    for (starts.items) |o| {
        const co = objects.peelTo(o, .commit) orelse continue;
        if (seen.contains(co)) continue;
        seen.put(gpa, co, {}) catch util.oom();
        if (objects.readCommit(co)) |c| heap.append(gpa, c) catch util.oom();
    }
    while (heap.items.len > 0) {
        // pop newest
        var best: usize = 0;
        for (heap.items, 0..) |c, k| {
            if (c.commitTime() > heap.items[best].commitTime()) best = k;
        }
        const c = heap.swapRemove(best);
        if (re.isMatch(c.message)) return c.oid;
        for (c.parents) |p| {
            if (seen.contains(p)) continue;
            seen.put(gpa, p, {}) catch util.oom();
            if (objects.readCommit(p)) |pc| heap.append(gpa, pc) catch util.oom();
        }
    }
    return null;
}

/// Handle suffixes ^, ~, ^{...}
fn getOidBasicWithSuffix(name: []const u8, opts: Opts) ?Oid {
    // find last suffix operator
    if (name.len == 0) return null;
    // ^{...}
    if (name[name.len - 1] == '}') {
        if (std.mem.lastIndexOf(u8, name, "^{")) |p| {
            const base = name[0..p];
            const what = name[p + 2 .. name.len - 1];
            const o = getOidBasicWithSuffix(base, .{ .want = .any, .die_on_error = opts.die_on_error, .quiet = opts.quiet }) orelse return null;
            return peelSpec(o, what, opts);
        }
    }
    // trailing digits after ^ or ~
    var i = name.len;
    while (i > 0 and std.ascii.isDigit(name[i - 1])) i -= 1;
    if (i > 0 and (name[i - 1] == '^' or name[i - 1] == '~')) {
        const op = name[i - 1];
        const base = name[0 .. i - 1];
        if (base.len == 0) return getOidBasic(name, opts);
        const num: usize = if (i == name.len) 1 else (std.fmt.parseInt(usize, name[i..], 10) catch return null);
        const o = getOidBasicWithSuffix(base, .{ .want = .committish, .die_on_error = opts.die_on_error, .quiet = opts.quiet }) orelse return null;
        if (op == '^') {
            if (num == 0) return objects.peelTo(o, .commit);
            const co = objects.peelTo(o, .commit) orelse return null;
            const c = objects.readCommit(co) orelse return null;
            if (num > c.parents.len) return null;
            return c.parents[num - 1];
        } else {
            var co = objects.peelTo(o, .commit) orelse return null;
            var k: usize = 0;
            while (k < num) : (k += 1) {
                const c = objects.readCommit(co) orelse return null;
                if (c.parents.len == 0) return null;
                co = c.parents[0];
            }
            return co;
        }
    }
    return getOidBasic(name, opts);
}

fn peelSpec(o: Oid, what: []const u8, opts: Opts) ?Oid {
    _ = opts;
    if (what.len == 0) {
        // peel tags fully
        var cur = o;
        while (true) {
            const t = objects.typeOf(cur) orelse return null;
            if (t != .tag) return cur;
            const obj = repo_mod.repo().odb().read(cur) orelse return null;
            const tag = objects.parseTag(obj.data) orelse return null;
            cur = tag.object;
        }
    }
    if (util.eql(what, "commit")) return objects.peelTo(o, .commit);
    if (util.eql(what, "tree")) return objects.peelTo(o, .tree);
    if (util.eql(what, "blob")) return objects.peelTo(o, .blob);
    if (util.eql(what, "tag")) {
        const t = objects.typeOf(o) orelse return null;
        return if (t == .tag) o else null;
    }
    if (util.eql(what, "object")) {
        return if (objects.typeOf(o) != null) o else null;
    }
    if (what[0] == '/') {
        const co = objects.peelTo(o, .commit) orelse return null;
        var pat = what[1..];
        if (pat.len > 0 and pat[0] == '!') {
            if (pat.len > 1 and pat[1] == '!') pat = pat[1..] else return null;
        }
        return searchMessage(pat, &.{co});
    }
    return null;
}

fn isHexPrefix(s: []const u8) bool {
    if (s.len < 4 or s.len > 40) return false;
    for (s) |ch| if (!std.ascii.isHex(ch)) return false;
    return true;
}

/// Resolve a ref-ish or hex name without suffix operators.
fn getOidBasic(name: []const u8, opts: Opts) ?Oid {
    // full hex
    if (name.len == 40) {
        if (hash.fromHex(name)) |o| {
            // a ref with this name takes precedence only with warning; git prefers hex
            return o;
        }
    }
    // @{...} forms
    if (std.mem.indexOf(u8, name, "@{")) |at| {
        if (name[name.len - 1] == '}') return resolveAtBrace(name, at, opts);
    }
    if (util.eql(name, "@")) return refs.readOid("HEAD");
    // refs
    if (refs.checkRefnameFormat(name, refs.ALLOW_ONELEVEL) or util.eql(name, "HEAD")) {
        if (refs.dwimRef(name)) |d| {
            // ambiguity with hex?
            if (d.count > 1 and !opts.quiet) {
                if (repo_mod.cfg.getBool("core.warnambiguousrefs") orelse true)
                    util.warn("refname '{s}' is ambiguous.", .{name});
            }
            return d.oid;
        }
    }
    // abbreviated hex
    if (isHexPrefix(name)) {
        return resolveShortHex(name, opts);
    }
    return null;
}

pub fn resolveShortHex(name: []const u8, opts: Opts) ?Oid {
    var cands: std.ArrayList(Oid) = .empty;
    repo_mod.repo().odb().findByPrefix(name, &cands);
    if (cands.items.len == 1) return cands.items[0];
    if (cands.items.len == 0) return null;
    // disambiguate by wanted type
    var filtered: std.ArrayList(Oid) = .empty;
    const want = if (opts.want == .any) defaultDisambiguate() else opts.want;
    for (cands.items) |o| {
        if (matchesWant(o, want)) filtered.append(gpa, o) catch util.oom();
    }
    if (filtered.items.len == 1) return filtered.items[0];
    if (!opts.quiet) {
        util.err("short object ID {s} is ambiguous", .{name});
        reportCandidates(cands.items);
    }
    return null;
}

fn defaultDisambiguate() Want {
    const v = repo_mod.cfg.get("core.disambiguate") orelse return .any;
    if (util.eql(v, "commit")) return .commit;
    if (util.eql(v, "committish")) return .committish;
    if (util.eql(v, "tree")) return .tree;
    if (util.eql(v, "treeish")) return .treeish;
    if (util.eql(v, "blob")) return .blob;
    return .any;
}

fn matchesWant(o: Oid, want: Want) bool {
    const t = objects.typeOf(o) orelse return false;
    return switch (want) {
        .any => true,
        .commit => t == .commit,
        .committish => t == .commit or (t == .tag and objects.peelTo(o, .commit) != null),
        .tree => t == .tree,
        .treeish => t == .tree or t == .commit or (t == .tag and objects.peelTo(o, .tree) != null),
        .blob => t == .blob,
    };
}

fn reportCandidates(cands: []Oid) void {
    std.mem.sort(Oid, cands, {}, struct {
        fn lt(_: void, a: Oid, b: Oid) bool {
            const ta = objects.typeOf(a) orelse ObjType.none;
            const tb = objects.typeOf(b) orelse ObjType.none;
            const ra = typeRank(ta);
            const rb = typeRank(tb);
            if (ra != rb) return ra < rb;
            return hash.order(a, b) == .lt;
        }
    }.lt);
    var b: util.Buf = .empty;
    util.bufAppend(&b, "The candidates are:\n");
    for (cands) |o| {
        const t = objects.typeOf(o) orelse ObjType.none;
        const ab = abbrev(o, 0);
        switch (t) {
            .commit => {
                const c = objects.readCommit(o);
                if (c) |cc| {
                    const ds = date.showDate(objects.identTime(cc.committer), 0, date.DateMode.of(.short));
                    const subj = firstLine(cc.message);
                    util.bufPrint(&b, "  {s} commit {s} - {s}\n", .{ ab, ds, subj });
                } else util.bufPrint(&b, "  {s} commit\n", .{ab});
            },
            .tag => {
                const obj = repo_mod.repo().odb().read(o);
                var tname: []const u8 = "";
                if (obj) |ob| {
                    if (objects.parseTag(ob.data)) |tg| tname = tg.tag;
                }
                util.bufPrint(&b, "  {s} tag {s}\n", .{ ab, tname });
            },
            .tree => util.bufPrint(&b, "  {s} tree\n", .{ab}),
            .blob => util.bufPrint(&b, "  {s} blob\n", .{ab}),
            else => util.bufPrint(&b, "  {s} unknown type\n", .{ab}),
        }
    }
    var it = std.mem.splitScalar(u8, util.trimRight(b.items), '\n');
    while (it.next()) |line| util.eprint("hint: {s}\n", .{line});
}

fn typeRank(t: ObjType) u8 {
    return switch (t) {
        .tag => 0,
        .commit => 1,
        .tree => 2,
        .blob => 3,
        else => 4,
    };
}

fn firstLine(s: []const u8) []const u8 {
    const nl = std.mem.indexOfScalar(u8, s, '\n') orelse s.len;
    return s[0..nl];
}

/// Resolve @{-N} to a branch name (e.g. "master"), or null.
pub fn previousBranch(n: usize) ?[]const u8 {
    const entries = refs.readReflog("HEAD");
    var count: usize = 0;
    var i = entries.len;
    while (i > 0) {
        i -= 1;
        const msg = entries[i].msg;
        const rest = util.skipPrefix(msg, "checkout: moving from ") orelse continue;
        const to = std.mem.indexOf(u8, rest, " to ") orelse continue;
        count += 1;
        if (count == n) return rest[0..to];
    }
    return null;
}

/// Interpret branch names like @{-1}, @{upstream}; returns expanded name for branch-taking commands.
pub fn interpretBranchName(name: []const u8) []const u8 {
    if (util.startsWith(name, "@{-") and util.endsWith(name, "}")) {
        const n = std.fmt.parseInt(usize, name[3 .. name.len - 1], 10) catch return name;
        if (previousBranch(n)) |b| return b;
        return name;
    }
    if (util.eql(name, "@")) return "HEAD";
    return name;
}

pub fn upstreamOf(branch: []const u8, push: bool) union(enum) { ok: []const u8, err: []const u8 } {
    if (push) {
        // push: remote.pushDefault / branch.<b>.pushRemote; fall back to upstream
        const remote = repo_mod.cfg.get(util.concat(&.{ "branch.", branch, ".pushremote" })) orelse
            repo_mod.cfg.get("remote.pushdefault") orelse
            repo_mod.cfg.get(util.concat(&.{ "branch.", branch, ".remote" }));
        if (remote) |rm| {
            const default = repo_mod.cfg.get("push.default") orelse "simple";
            if (util.eql(default, "current") or util.eql(default, "simple") or util.eql(default, "upstream")) {
                if (util.eql(default, "upstream")) return upstreamOf(branch, false);
                return .{ .ok = util.concat(&.{ "refs/remotes/", rm, "/", branch }) };
            }
        }
        return upstreamOf(branch, false);
    }
    const merge = repo_mod.cfg.get(util.concat(&.{ "branch.", branch, ".merge" })) orelse
        return .{ .err = util.fmt("no upstream configured for branch '{s}'", .{branch}) };
    const remote = repo_mod.cfg.get(util.concat(&.{ "branch.", branch, ".remote" })) orelse ".";
    if (util.eql(remote, ".")) return .{ .ok = merge };
    // map through fetch refspec
    const fetches = repo_mod.cfg.getAll(util.concat(&.{ "remote.", remote, ".fetch" }));
    for (fetches) |f0| {
        var f = f0;
        if (f.len > 0 and f[0] == '+') f = f[1..];
        const colon = std.mem.indexOfScalar(u8, f, ':') orelse continue;
        const src = f[0..colon];
        const dst = f[colon + 1 ..];
        if (std.mem.indexOfScalar(u8, src, '*')) |star| {
            const pre = src[0..star];
            const suf = src[star + 1 ..];
            if (util.startsWith(merge, pre) and util.endsWith(merge, suf) and merge.len >= pre.len + suf.len) {
                const mid = merge[pre.len .. merge.len - suf.len];
                const dstar = std.mem.indexOfScalar(u8, dst, '*') orelse continue;
                return .{ .ok = util.concat(&.{ dst[0..dstar], mid, dst[dstar + 1 ..] }) };
            }
        } else if (util.eql(src, merge)) return .{ .ok = dst };
    }
    return .{ .err = util.fmt("upstream branch '{s}' not stored as a remote-tracking branch", .{merge}) };
}

fn resolveAtBrace(name: []const u8, at: usize, opts: Opts) ?Oid {
    const base0 = name[0..at];
    const inner = name[at + 2 .. name.len - 1];
    // @{-N}
    if (base0.len == 0 and inner.len > 0 and inner[0] == '-') {
        const n = std.fmt.parseInt(usize, inner[1..], 10) catch return null;
        const b = previousBranch(n) orelse {
            if (opts.die_on_error) util.die("{s}", .{util.fmt("'{s}' does not point to a branch", .{name})});
            return null;
        };
        if (refs.dwimRef(b)) |d| return d.oid;
        return hash.fromHex(b) orelse getOid(b);
    }
    var branch_ref: []const u8 = undefined;
    var base = base0;
    if (base.len == 0) base = "HEAD";
    if (util.startsWith(base, "@{-")) base = interpretBranchName(base);
    const lower = util.lower(inner);
    if (util.eql(lower, "u") or util.eql(lower, "upstream") or util.eql(lower, "push")) {
        var br: []const u8 = undefined;
        if (util.eql(base, "HEAD") or util.eql(base, "@")) {
            br = refs.currentBranch() orelse {
                if (opts.die_on_error) util.die("HEAD does not point to a branch", .{});
                return null;
            };
        } else {
            br = util.skipPrefix(base, "refs/heads/") orelse base;
            if (!refs.exists(util.concat(&.{ "refs/heads/", br }))) {
                if (opts.die_on_error) util.die("no such branch: '{s}'", .{br});
                return null;
            }
        }
        switch (upstreamOf(br, util.eql(lower, "push"))) {
            .ok => |u| {
                const o = refs.readOid(u) orelse {
                    if (opts.die_on_error) util.die("upstream branch '{s}' not stored as a remote-tracking branch", .{u});
                    return null;
                };
                return o;
            },
            .err => |e| {
                if (opts.die_on_error) util.die("{s}", .{e});
                return null;
            },
        }
    }
    // reflog @{N} / @{date}
    if (util.eql(base, "HEAD") and base0.len == 0) {
        // "@{N}" refers to current branch's reflog
        branch_ref = if (refs.headSymref()) |s| s else "HEAD";
    } else if (refs.dwimRef(base)) |d| {
        branch_ref = d.name;
        if (util.eql(base, "HEAD")) branch_ref = "HEAD";
    } else return null;
    const entries = refs.readReflog(branch_ref);
    const is_num = blk: {
        for (inner) |ch| if (!std.ascii.isDigit(ch)) break :blk false;
        break :blk inner.len > 0;
    };
    if (is_num) {
        const n = std.fmt.parseInt(usize, inner, 10) catch return null;
        if (n == 0 and entries.len == 0) return refs.readOid(branch_ref);
        if (n >= entries.len) {
            if (n == entries.len and entries.len > 0) return entries[0].old;
            if (opts.die_on_error) util.die("log for '{s}' only has {d} entries", .{ base, entries.len });
            return null;
        }
        return entries[entries.len - 1 - n].new;
    }
    // date
    var errflag = false;
    const t = date.approxidateCareful(inner, &errflag);
    if (errflag) return null;
    if (entries.len == 0) return null;
    var i = entries.len;
    while (i > 0) {
        i -= 1;
        const et = objects.identTime(entries[i].ident);
        if (et <= t) return entries[i].new;
    }
    if (!opts.quiet) util.warn("log for '{s}' only goes back to {s}", .{ base, date.showDate(objects.identTime(entries[0].ident), 0, date.DateMode.of(.rfc2822)) });
    return entries[0].old;
}

// ---------------- abbreviation ----------------

var default_abbrev_cache: ?usize = null;

pub fn defaultAbbrev() usize {
    if (default_abbrev_cache) |a| return a;
    var a: usize = 7;
    if (repo_mod.cfg.get("core.abbrev")) |v| {
        if (util.eql(v, "auto")) {
            a = 7;
        } else if (config_parseBool(v)) |b| {
            a = if (b) 7 else 40;
        } else if (std.fmt.parseInt(usize, v, 10)) |n| {
            a = if (n < 4) 4 else if (n > 40) 40 else n;
        } else |_| {}
    }
    default_abbrev_cache = a;
    return a;
}

fn config_parseBool(v: []const u8) ?bool {
    if (util.eql(v, "no") or util.eql(v, "false") or util.eql(v, "off")) return false;
    return null;
}

/// Shortest unique abbreviation, at least min_len (0 = default).
pub fn abbrev(o: Oid, min_len: usize) []const u8 {
    const h = hash.hexAlloc(o);
    var len = if (min_len == 0) defaultAbbrev() else min_len;
    if (len >= 40) return h;
    if (repo_mod.repo_ == null) return h[0..len];
    const odb = repo_mod.repo().odb();
    while (len < 40) : (len += 1) {
        var cands: std.ArrayList(Oid) = .empty;
        odb.findByPrefix(h[0..len], &cands);
        var other = false;
        for (cands.items) |c| {
            if (!hash.eql(c, o)) other = true;
        }
        if (!other) break;
    }
    return h[0..len];
}
