//! Port of merge-ort.c, merge-ort-wrappers.c, merge-ll.c and the parts of
//! diffcore-rename.c / diffcore-delta.c that merge-ort needs.
//!
//! Memory is never freed (process-lifetime allocations via util.gpa).

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const os = @import("os.zig");
const objects = @import("objects.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const xdiff = @import("xdiff.zig");
const attr = @import("attr.zig");
const config = @import("config.zig");
const index_mod = @import("index.zig");
const ut = @import("unpacktrees.zig");
const refs = @import("refs.zig");
const cn = @import("commitnode.zig");
const creach = @import("commitreach.zig");
const revparse = @import("revparse.zig");

const Oid = hash.Oid;
const gpa = util.gpa;
const oom = util.oom;

fn StrMap(comptime V: type) type {
    return std.StringArrayHashMapUnmanaged(V);
}
const IntMap = StrMap(i32);

fn iget(m: *const IntMap, k: []const u8, def: i32) i32 {
    return m.get(k) orelse def;
}
fn iset(m: *IntMap, k: []const u8, v: i32) void {
    m.put(gpa, k, v) catch oom();
}
fn mput(comptime V: type, m: *StrMap(V), k: []const u8, v: V) void {
    m.put(gpa, k, v) catch oom();
}
fn appendT(comptime T: type, l: *std.ArrayList(T), v: T) void {
    l.append(gpa, v) catch oom();
}

const S_IFMT = os.S_IFMT;
fn isReg(m: u32) bool {
    return m & S_IFMT == os.S_IFREG;
}
fn isLnk(m: u32) bool {
    return m & S_IFMT == os.S_IFLNK;
}
fn isGitlink(m: u32) bool {
    return m & S_IFMT == os.S_IFGITLINK;
}
fn isDirMode(m: u32) bool {
    return m & S_IFMT == os.S_IFDIR;
}

const empty_tree: Oid = hash.fromHex(hash.empty_tree_hex).?;
const empty_blob: Oid = hash.fromHex(hash.empty_blob_hex).?;

// ---------------------------------------------------------------------------
// Public options

pub const DirRenames = enum(u8) { none = 0, conflict = 1, true_ = 2 };
pub const Variant = enum(u8) { normal = 0, ours = 1, theirs = 2 };

pub const Options = struct {
    branch1: []const u8 = "",
    branch2: []const u8 = "",
    ancestor: ?[]const u8 = null,
    detect_renames: i32 = -1,
    detect_directory_renames: DirRenames = .conflict,
    rename_limit: i32 = -1,
    rename_score: i32 = 0,
    show_rename_progress: bool = false,
    verbosity: i32 = 2,
    renormalize: bool = false,
    recursive_variant: Variant = .normal,
    xdl_flags: xdiff.Flags = .{ .algorithm = .histogram, .indent_heuristic = false },
    conflict_style: i32 = -1,
    subtree_shift: ?[]const u8 = null,
    record_conflict_msgs_as_headers: bool = false,
    msg_header_prefix: ?[]const u8 = null,
    mergeability_only: bool = false,
    priv: ?*Priv = null,
};

pub const Result = struct {
    clean: i32 = 0,
    tree: Oid = hash.zero,
    priv: ?*Priv = null,
};

// ---------------------------------------------------------------------------
// merge-ll

/// git_xmerge_style (merge.conflictstyle), -1 if unset.
pub var xmerge_style: i32 = -1;
var xmerge_loaded = false;

pub fn parseConflictStyleName(v: []const u8) i32 {
    if (util.eql(v, "merge")) return 0;
    if (util.eql(v, "diff3")) return 1;
    if (util.eql(v, "zdiff3")) return 2;
    return -1;
}

/// git_xmerge_config
pub fn loadXmergeConfig() void {
    if (xmerge_loaded) return;
    xmerge_loaded = true;
    if (repo_mod.cfg.getEntry("merge.conflictstyle")) |e| {
        const v = e.value orelse {
            util.err("missing value for '{s}'", .{"merge.conflictstyle"});
            return;
        };
        xmerge_style = parseConflictStyleName(v);
        if (xmerge_style == -1) util.err("unknown style '{s}' given for '{s}'", .{ v, "merge.conflictstyle" });
    }
}

pub fn styleFromInt(s: i32) xdiff.MergeStyle {
    return switch (s) {
        1 => .diff3,
        2 => .zdiff3,
        else => .merge,
    };
}

pub const LlStatus = enum(i8) { err = -1, ok = 0, conflict = 1, binary_conflict = 2 };

pub const LlOpts = struct {
    virtual_ancestor: bool = false,
    variant: xdiff.MergeFavor = .none,
    renormalize: bool = false,
    extra_marker_size: i32 = 0,
    xdl_flags: xdiff.Flags = .{ .indent_heuristic = false },
    conflict_style: i32 = -1,
};

pub const LlResult = struct { status: LlStatus, result: ?[]const u8 };

const DriverKind = enum { binary, text, union_, ext };
const Driver = struct {
    name: []const u8,
    description: ?[]const u8 = null,
    kind: DriverKind,
    recursive: ?[]const u8 = null,
    cmdline: ?[]const u8 = null,
};

var builtin_drivers = [_]Driver{
    .{ .name = "binary", .description = "built-in binary merge", .kind = .binary },
    .{ .name = "text", .description = "built-in 3-way text merge", .kind = .text },
    .{ .name = "union", .description = "built-in union merge", .kind = .union_ },
};
var user_drivers: std.ArrayList(*Driver) = .empty;
var default_ll_merge: ?[]const u8 = null;
var ll_initialized = false;

fn initializeLlMerge() void {
    if (ll_initialized) return;
    ll_initialized = true;
    for (repo_mod.cfg.entries.items) |e| {
        if (util.eql(e.key, "merge.default")) {
            default_ll_merge = e.value;
            continue;
        }
        const rest = util.skipPrefix(e.key, "merge.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse continue;
        const name = rest[0..dot];
        const key = rest[dot + 1 ..];
        var fnp: ?*Driver = null;
        for (user_drivers.items) |d| {
            if (util.eql(d.name, name)) {
                fnp = d;
                break;
            }
        }
        const d = fnp orelse blk: {
            const nd = gpa.create(Driver) catch oom();
            nd.* = .{ .name = name, .kind = .ext };
            appendT(*Driver, &user_drivers, nd);
            break :blk nd;
        };
        if (util.eql(key, "name")) {
            d.description = e.value;
        } else if (util.eql(key, "driver")) {
            if (e.value) |v| d.cmdline = v else util.err("missing value for '{s}'", .{e.key});
        } else if (util.eql(key, "recursive")) {
            d.recursive = e.value;
        }
    }
}

fn findDriverByName(name: []const u8) *Driver {
    for (user_drivers.items) |d| if (util.eql(d.name, name)) return d;
    for (&builtin_drivers) |*d| if (util.eql(d.name, name)) return d;
    return &builtin_drivers[1];
}

fn findLlMergeDriver(v: attr.Value) *Driver {
    initializeLlMerge();
    switch (v) {
        .set => return &builtin_drivers[1],
        .unset => return &builtin_drivers[0],
        .unspecified => {
            const n = default_ll_merge orelse return &builtin_drivers[1];
            return findDriverByName(n);
        },
        .value => |n| return findDriverByName(n),
    }
}

pub fn bufferIsBinary(b: []const u8) bool {
    const n = @min(b.len, 8000);
    return std.mem.indexOfScalar(u8, b[0..n], 0) != null;
}

fn llBinaryMerge(orig: []const u8, src1: []const u8, src2: []const u8, opts: *const LlOpts) LlResult {
    if (opts.virtual_ancestor) return .{ .status = .ok, .result = orig };
    return switch (opts.variant) {
        .ours => .{ .status = .ok, .result = src1 },
        .theirs => .{ .status = .ok, .result = src2 },
        else => .{ .status = .binary_conflict, .result = src1 },
    };
}

fn llXdlMerge(orig: []const u8, orig_name: ?[]const u8, src1: []const u8, name1: ?[]const u8, src2: []const u8, name2: ?[]const u8, opts: *const LlOpts, marker_size: i32) LlResult {
    if (bufferIsBinary(orig) or bufferIsBinary(src1) or bufferIsBinary(src2))
        return llBinaryMerge(orig, src1, src2, opts);
    loadXmergeConfig();
    var mo = xdiff.MergeOpts{
        .flags = opts.xdl_flags,
        .level = .zealous,
        .favor = opts.variant,
        .ancestor_name = orig_name,
        .ours_name = name1,
        .theirs_name = name2,
    };
    if (opts.conflict_style >= 0) {
        mo.style = styleFromInt(opts.conflict_style);
    } else if (xmerge_style >= 0) mo.style = styleFromInt(xmerge_style);
    if (marker_size > 0) mo.marker_size = marker_size;
    const r = xdiff.merge(orig, src1, src2, mo) catch return .{ .status = .err, .result = null };
    return .{ .status = if (r.conflicts > 0) .conflict else .ok, .result = r.result };
}

fn createTemp(data: []const u8) []const u8 {
    const t = os.tmpFile(".", ".merge_file_");
    if (t.fd < 0) util.dieErrno("unable to create temp-file", .{});
    os.writeAll(t.fd, data) catch util.dieErrno("unable to write temp-file", .{});
    os.close(t.fd);
    return util.skipPrefix(t.path, "./") orelse t.path;
}

fn llExtMerge(d: *const Driver, path: []const u8, orig: []const u8, orig_name: ?[]const u8, src1: []const u8, name1: ?[]const u8, src2: []const u8, name2: ?[]const u8, marker_size: i32) LlResult {
    const format = d.cmdline orelse util.die("custom merge driver {s} lacks command line.", .{d.name});
    var temp: [3][]const u8 = undefined;
    temp[0] = createTemp(orig);
    temp[1] = createTemp(src1);
    temp[2] = createTemp(src2);
    var cmd: util.Buf = .empty;
    var i: usize = 0;
    while (i < format.len) {
        const ch = format[i];
        if (ch != '%') {
            util.bufByte(&cmd, ch);
            i += 1;
            continue;
        }
        i += 1;
        if (i >= format.len) {
            util.bufByte(&cmd, '%');
            break;
        }
        const f = format[i];
        switch (f) {
            '%' => util.bufByte(&cmd, '%'),
            'O' => util.bufAppend(&cmd, temp[0]),
            'A' => util.bufAppend(&cmd, temp[1]),
            'B' => util.bufAppend(&cmd, temp[2]),
            'L' => util.bufPrint(&cmd, "{d}", .{marker_size}),
            'P' => util.sqQuote(&cmd, path),
            'S' => util.sqQuote(&cmd, orig_name orelse ""),
            'X' => util.sqQuote(&cmd, name1 orelse ""),
            'Y' => util.sqQuote(&cmd, name2 orelse ""),
            else => {
                util.bufByte(&cmd, '%');
                continue;
            },
        }
        i += 1;
    }
    const res = os.run(&.{cmd.items}, .{ .use_shell = true });
    const out = os.readFile(temp[1]);
    for (temp) |t| {
        if (!os.unlink(t)) util.warn("unable to unlink '{s}': {s}", .{ t, os.lastErr() });
    }
    const st: LlStatus = if (res.status == 0) .ok else if (res.status <= 128) .conflict else .err;
    return .{ .status = st, .result = out };
}

/// ll_merge()
pub fn llMerge(path: []const u8, ancestor: []const u8, ancestor_label: ?[]const u8, ours: []const u8, our_label: ?[]const u8, theirs: []const u8, their_label: ?[]const u8, opts: *const LlOpts) LlResult {
    const vals = attr.check(path, &.{ "merge", "conflict-marker-size" });
    var marker_size: i32 = xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
    switch (vals[1]) {
        .value => |v| {
            if (std.fmt.parseInt(i32, v, 10)) |n| {
                marker_size = n;
            } else |_| {
                marker_size = xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
                util.warn("invalid marker-size '{s}', expecting an integer", .{v});
            }
            if (marker_size <= 0) marker_size = xdiff.DEFAULT_CONFLICT_MARKER_SIZE;
        },
        .set => {
            // value "true": strtol_i fails
            util.warn("invalid marker-size '{s}', expecting an integer", .{"true"});
        },
        .unset => {
            util.warn("invalid marker-size '{s}', expecting an integer", .{"false"});
        },
        .unspecified => {},
    }
    var driver = findLlMergeDriver(vals[0]);
    if (opts.virtual_ancestor) {
        if (driver.recursive) |r| driver = findLlMergeDriver(.{ .value = r });
    }
    if (opts.extra_marker_size != 0) marker_size += opts.extra_marker_size;
    return switch (driver.kind) {
        .binary => llBinaryMerge(ancestor, ours, theirs, opts),
        .text => llXdlMerge(ancestor, ancestor_label, ours, our_label, theirs, their_label, opts, marker_size),
        .union_ => blk: {
            var o = opts.*;
            o.variant = .union_;
            break :blk llXdlMerge(ancestor, ancestor_label, ours, our_label, theirs, their_label, &o, marker_size);
        },
        .ext => llExtMerge(driver, path, ancestor, ancestor_label, ours, our_label, theirs, their_label, marker_size),
    };
}

// ---------------------------------------------------------------------------
// Internal data

const MERGE_BASE = 0;
const MERGE_SIDE1 = 1;
const MERGE_SIDE2 = 2;

const NOT_RELEVANT: i32 = 0;
const RELEVANT_FOR_ANCESTOR: i32 = 1;
const RELEVANT_FOR_SELF: i32 = 2;

const RELEVANT_NO_MORE: i32 = 0;
const RELEVANT_CONTENT: i32 = 1;
const RELEVANT_LOCATION: i32 = 2;

const MAX_SCORE: i32 = 60000;
const DEFAULT_RENAME_SCORE: i32 = 30000;

pub const Ct = enum(u8) {
    INFO_AUTO_MERGING = 0,
    CONFLICT_CONTENTS,
    CONFLICT_BINARY,
    CONFLICT_FILE_DIRECTORY,
    CONFLICT_DISTINCT_MODES,
    CONFLICT_MODIFY_DELETE,
    CONFLICT_RENAME_RENAME,
    CONFLICT_RENAME_COLLIDES,
    CONFLICT_RENAME_DELETE,
    CONFLICT_DIR_RENAME_SUGGESTED,
    INFO_DIR_RENAME_APPLIED,
    INFO_DIR_RENAME_SKIPPED_DUE_TO_RERENAME,
    CONFLICT_DIR_RENAME_FILE_IN_WAY,
    CONFLICT_DIR_RENAME_COLLISION,
    CONFLICT_DIR_RENAME_SPLIT,
    INFO_SUBMODULE_FAST_FORWARDING,
    CONFLICT_SUBMODULE_FAILED_TO_MERGE,
    CONFLICT_SUBMODULE_FAILED_TO_MERGE_BUT_POSSIBLE_RESOLUTION,
    CONFLICT_SUBMODULE_NOT_INITIALIZED,
    CONFLICT_SUBMODULE_HISTORY_NOT_AVAILABLE,
    CONFLICT_SUBMODULE_MAY_HAVE_REWINDS,
    CONFLICT_SUBMODULE_NULL_MERGE_BASE,
    NB_REGULAR_CONFLICT_TYPES,
    ERROR_SUBMODULE_CORRUPT,
    ERROR_THREEWAY_CONTENT_MERGE_FAILED,
    ERROR_OBJECT_WRITE_FAILED,
    ERROR_OBJECT_READ_FAILED,
    ERROR_OBJECT_NOT_A_BLOB,
};

fn shortDesc(t: Ct) []const u8 {
    return switch (t) {
        .INFO_AUTO_MERGING => "Auto-merging",
        .CONFLICT_CONTENTS => "CONFLICT (contents)",
        .CONFLICT_BINARY => "CONFLICT (binary)",
        .CONFLICT_FILE_DIRECTORY => "CONFLICT (file/directory)",
        .CONFLICT_DISTINCT_MODES => "CONFLICT (distinct modes)",
        .CONFLICT_MODIFY_DELETE => "CONFLICT (modify/delete)",
        .CONFLICT_RENAME_RENAME => "CONFLICT (rename/rename)",
        .CONFLICT_RENAME_COLLIDES => "CONFLICT (rename involved in collision)",
        .CONFLICT_RENAME_DELETE => "CONFLICT (rename/delete)",
        .CONFLICT_DIR_RENAME_SUGGESTED => "CONFLICT (directory rename suggested)",
        .INFO_DIR_RENAME_APPLIED => "Path updated due to directory rename",
        .INFO_DIR_RENAME_SKIPPED_DUE_TO_RERENAME => "Directory rename skipped since directory was renamed on both sides",
        .CONFLICT_DIR_RENAME_FILE_IN_WAY => "CONFLICT (file in way of directory rename)",
        .CONFLICT_DIR_RENAME_COLLISION => "CONFLICT(directory rename collision)",
        .CONFLICT_DIR_RENAME_SPLIT => "CONFLICT(directory rename unclear split)",
        .INFO_SUBMODULE_FAST_FORWARDING => "Fast forwarding submodule",
        .CONFLICT_SUBMODULE_FAILED_TO_MERGE => "CONFLICT (submodule)",
        .CONFLICT_SUBMODULE_FAILED_TO_MERGE_BUT_POSSIBLE_RESOLUTION => "CONFLICT (submodule with possible resolution)",
        .CONFLICT_SUBMODULE_NOT_INITIALIZED => "CONFLICT (submodule not initialized)",
        .CONFLICT_SUBMODULE_HISTORY_NOT_AVAILABLE => "CONFLICT (submodule history not available)",
        .CONFLICT_SUBMODULE_MAY_HAVE_REWINDS => "CONFLICT (submodule may have rewinds)",
        .CONFLICT_SUBMODULE_NULL_MERGE_BASE => "CONFLICT (submodule lacks merge base)",
        .NB_REGULAR_CONFLICT_TYPES => "",
        .ERROR_SUBMODULE_CORRUPT => "ERROR (submodule corrupt)",
        .ERROR_THREEWAY_CONTENT_MERGE_FAILED => "ERROR (three-way content merge failed)",
        .ERROR_OBJECT_WRITE_FAILED => "ERROR (object write failed)",
        .ERROR_OBJECT_READ_FAILED => "ERROR (object read failed)",
        .ERROR_OBJECT_NOT_A_BLOB => "ERROR (object is not a blob)",
    };
}

const VersionInfo = struct {
    oid: Oid = hash.zero,
    mode: u32 = 0,
};

/// merged_info + conflict_info combined.
const Info = struct {
    result: VersionInfo = .{},
    is_null: bool = false,
    clean: bool = false,
    basename_offset: usize = 0,
    directory_name: []const u8 = "",
    stages: [3]VersionInfo = .{ .{}, .{}, .{} },
    pathnames: [3][]const u8 = .{ "", "", "" },
    df_conflict: bool = false,
    path_conflict: bool = false,
    filemask: u8 = 0,
    dirmask: u8 = 0,
    match_mask: u8 = 0,
};

fn newInfo() *Info {
    const p = gpa.create(Info) catch oom();
    p.* = .{};
    return p;
}

const Spec = struct {
    path: []const u8,
    oid: Oid = hash.zero,
    mode: u32 = 0,
    rename_used: u32 = 0,
    data: ?[]const u8 = null,
    cnt: ?[]const Span = null,
    fn valid(s: *const Spec) bool {
        return s.mode != 0;
    }
};

const Pair = struct {
    one: *Spec,
    two: *Spec,
    status: u8 = 0,
    score: i32 = 0,
    renamed_pair: bool = false,
};

const Msg = struct {
    typ: Ct,
    paths: []const []const u8,
    text: []const u8,
};

const SideInfo = struct {
    pairs: std.ArrayList(*Pair) = .empty,
    dirs_removed: IntMap = .empty, // default NOT_RELEVANT
    dir_rename_count: StrMap(*IntMap) = .empty,
    dir_renames: StrMap([]const u8) = .empty,
    relevant_sources: IntMap = .empty, // default -1
    possible_trivial_merges: IntMap = .empty, // default 0
    trivial_merges_okay: bool = true,
};

pub const Priv = struct {
    paths: StrMap(*Info) = .empty,
    conflicted: StrMap(*Info) = .empty,
    conflicts: StrMap(*std.ArrayList(Msg)) = .empty,
    sides: [3]SideInfo = .{ .{}, .{}, .{} },
    dir_rename_mask: u8 = 0,
    current_dir_name: []const u8 = "",
    call_depth: i32 = 0,
    needed_limit: i32 = 0,
};

fn clearOrReinit(p: *Priv, reinitialize: bool) void {
    p.paths = .empty;
    p.conflicted = .empty;
    var i: usize = 1;
    while (i <= 2) : (i += 1) {
        const s = &p.sides[i];
        s.dirs_removed = .empty;
        s.dir_renames = .empty;
        s.relevant_sources = .empty;
        s.dir_rename_count = .empty;
        s.possible_trivial_merges = .empty;
        s.trivial_merges_okay = true;
        s.pairs = .empty;
    }
    p.dir_rename_mask = 0;
    if (!reinitialize) p.conflicts = .empty;
}

// ---------------------------------------------------------------------------
// path_msg

fn pathMsg(opt: *Options, typ: Ct, omittable_hint: bool, primary_path: []const u8, other1: ?[]const u8, other2: ?[]const u8, others: ?[]const []const u8, text: []const u8) void {
    const priv = opt.priv.?;
    if (opt.record_conflict_msgs_as_headers and omittable_hint) return;
    if (priv.call_depth != 0 and opt.verbosity < 5) return;
    const gop = priv.conflicts.getOrPut(gpa, primary_path) catch oom();
    if (!gop.found_existing) {
        const l = gpa.create(std.ArrayList(Msg)) catch oom();
        l.* = .empty;
        gop.value_ptr.* = l;
    }
    var paths: std.ArrayList([]const u8) = .empty;
    appendT([]const u8, &paths, primary_path);
    if (other1) |o| appendT([]const u8, &paths, o);
    if (other2) |o| appendT([]const u8, &paths, o);
    if (others) |os_| for (os_) |o| appendT([]const u8, &paths, o);

    var dest: util.Buf = .empty;
    if (priv.call_depth != 0) {
        util.bufAppend(&dest, "  From inner merge:");
        var k: i32 = 0;
        while (k < priv.call_depth * 2) : (k += 1) util.bufByte(&dest, ' ');
    }
    util.bufAppend(&dest, text);
    var buf: util.Buf = .empty;
    if (opt.record_conflict_msgs_as_headers) {
        if (opt.msg_header_prefix) |pfx| util.bufPrint(&buf, "{s} ", .{pfx});
        for (dest.items) |ch| {
            util.bufByte(&buf, ch);
            if (ch == '\n') util.bufByte(&buf, ' ');
        }
    } else buf = dest;
    appendT(Msg, gop.value_ptr.*, .{ .typ = typ, .paths = paths.items, .text = buf.items });
}

fn uniquePath(opt: *Options, path: []const u8, branch: []const u8) []const u8 {
    var b: util.Buf = .empty;
    util.bufPrint(&b, "{s}~", .{path});
    for (branch) |ch| util.bufByte(&b, if (ch == '/') '_' else ch);
    const base_len = b.items.len;
    var suffix: i32 = 0;
    while (opt.priv.?.paths.contains(b.items)) {
        b.items.len = base_len;
        util.bufPrint(&b, "_{d}", .{suffix});
        suffix += 1;
    }
    return b.items;
}

// ---------------------------------------------------------------------------
// Tree traversal (traverse_trees equivalent for 3 trees)

const NameEntry = struct {
    name: []const u8 = "",
    mode: u32 = 0,
    oid: Oid = hash.zero,
};

const CbData = struct {
    mask: u8,
    dirmask: u8,
    names: [3]NameEntry,
};

fn readTreeEntries(oid: ?Oid) []const objects.TreeEntry {
    const o = oid orelse return &.{};
    if (hash.eql(o, empty_tree)) return &.{};
    return objects.readTree(o) orelse &.{};
}

const UnionItem = struct {
    key: []const u8,
    data: CbData,
};

fn unionLess(_: void, a: UnionItem, b: UnionItem) bool {
    return std.mem.order(u8, a.key, b.key) == .lt;
}

/// Collect the entries of one directory level across 3 trees, in the order
/// traverse_trees() would visit them.
fn levelEntries(trees: [3]?Oid) []CbData {
    var map: StrMap(usize) = .empty;
    var items: std.ArrayList(UnionItem) = .empty;
    for (0..3) |i| {
        const ents = readTreeEntries(trees[i]);
        for (ents) |e| {
            const gop = map.getOrPut(gpa, e.name) catch oom();
            if (!gop.found_existing) {
                gop.value_ptr.* = items.items.len;
                appendT(UnionItem, &items, .{ .key = e.name, .data = .{ .mask = 0, .dirmask = 0, .names = .{ .{}, .{}, .{} } } });
            }
            const it = &items.items[gop.value_ptr.*];
            const bit: u8 = @as(u8, 1) << @intCast(i);
            if (it.data.mask & bit != 0) continue; // duplicate entry
            it.data.mask |= bit;
            if (isDirMode(e.mode)) it.data.dirmask |= bit;
            it.data.names[i] = .{ .name = e.name, .mode = e.mode, .oid = e.oid };
        }
    }
    for (items.items) |*it| {
        // all present entries are directories -> sorts as "name/"
        if (it.data.dirmask == it.data.mask) it.key = util.concat(&.{ it.key, "/" });
    }
    std.mem.sort(UnionItem, items.items, {}, unionLess);
    const out = gpa.alloc(CbData, items.items.len) catch oom();
    for (items.items, 0..) |it, i| out[i] = it.data;
    return out;
}

const TraverseInfo = struct {
    /// full path of the directory being traversed ("" for toplevel)
    base: []const u8,
    /// length of prefix for children (0 at toplevel, else base.len+1)
    pathlen: usize,
};

fn traverseTrees(opt: *Options, trees: [3]?Oid, info: TraverseInfo) i32 {
    const ents = levelEntries(trees);
    for (ents) |*e| {
        const r = collectMergeInfoCallback(opt, e.mask, e.dirmask, &e.names, info);
        if (r < 0) return -1;
    }
    return 0;
}

fn traverseTreesWrapper(opt: *Options, trees: [3]?Oid, info: TraverseInfo) i32 {
    const priv = opt.priv.?;
    const ents = levelEntries(trees);
    for (ents) |e| {
        const filemask = e.mask & ~e.dirmask;
        if (filemask != 0 and filemask == priv.dir_rename_mask) priv.dir_rename_mask = 0x07;
    }
    for (ents) |*e| {
        const r = collectMergeInfoCallback(opt, e.mask, e.dirmask, &e.names, info);
        if (r < 0) return -1;
    }
    return 0;
}

fn setupPathInfo(opt: *Options, current_dir_name: []const u8, current_dir_name_len: usize, fullpath: []const u8, names: *const [3]NameEntry, merged_version: ?*const NameEntry, is_null: bool, df_conflict: bool, filemask: u8, dirmask: u8, resolved: bool) ?*Info {
    const mi = newInfo();
    mi.directory_name = current_dir_name;
    mi.basename_offset = current_dir_name_len;
    mi.clean = resolved;
    if (resolved) {
        mi.result.mode = merged_version.?.mode;
        mi.result.oid = merged_version.?.oid;
        mi.is_null = is_null;
    } else {
        for (0..3) |i| {
            mi.pathnames[i] = fullpath;
            mi.stages[i].mode = names[i].mode;
            mi.stages[i].oid = names[i].oid;
        }
        mi.filemask = filemask;
        mi.dirmask = dirmask;
        mi.df_conflict = df_conflict;
        if (dirmask != 0) mi.is_null = true;
    }
    const gop = opt.priv.?.paths.getOrPut(gpa, fullpath) catch oom();
    if (gop.found_existing) {
        gop.value_ptr.* = mi;
        util.err("tree has duplicate entries for '{s}'", .{fullpath});
        return null;
    }
    gop.value_ptr.* = mi;
    return mi;
}

fn newSpec(path: []const u8) *Spec {
    const s = gpa.create(Spec) catch oom();
    s.* = .{ .path = path };
    return s;
}

fn addPair(opt: *Options, names: *const [3]NameEntry, pathname: []const u8, side: usize, is_add: bool, match_mask: u8, dir_rename_mask: u8) void {
    const priv = opt.priv.?;
    const names_idx: usize = if (is_add) side else 0;
    if (!is_add) {
        const content_relevant = (match_mask == 0);
        const location_relevant = (dir_rename_mask == 0x07);
        if (content_relevant or location_relevant) {
            iset(&priv.sides[side].relevant_sources, pathname, if (content_relevant) RELEVANT_CONTENT else RELEVANT_LOCATION);
        }
    }
    const one = newSpec(pathname);
    const two = newSpec(pathname);
    const s = if (is_add) two else one;
    s.oid = names[names_idx].oid;
    s.mode = names[names_idx].mode;
    const p = gpa.create(Pair) catch oom();
    p.* = .{ .one = one, .two = two };
    appendT(*Pair, &priv.sides[side].pairs, p);
}

fn collectRenameInfo(opt: *Options, names: *const [3]NameEntry, dirname: []const u8, fullname: []const u8, filemask: u8, dirmask: u8, match_mask: u8) void {
    const priv = opt.priv.?;
    if (priv.dir_rename_mask != 0x07 and (dirmask == 3 or dirmask == 5)) {
        priv.dir_rename_mask = dirmask & ~@as(u8, 1);
    }
    if (dirmask == 1 or dirmask == 3 or dirmask == 5) {
        const sides = (0x07 - dirmask) / 2;
        const relevance: i32 = if (priv.dir_rename_mask == 0x07) RELEVANT_FOR_ANCESTOR else NOT_RELEVANT;
        if (sides & 1 != 0) iset(&priv.sides[1].dirs_removed, fullname, relevance);
        if (sides & 2 != 0) iset(&priv.sides[2].dirs_removed, fullname, relevance);
    }
    if (priv.dir_rename_mask == 0x07 and (filemask == 2 or filemask == 4)) {
        const side: usize = 3 - (filemask >> 1);
        iset(&priv.sides[side].dirs_removed, dirname, RELEVANT_FOR_SELF);
    }
    if (filemask == 0 or filemask == 7) return;
    var side: usize = 1;
    while (side <= 2) : (side += 1) {
        const side_mask: u8 = @as(u8, 1) << @intCast(side);
        if ((filemask & 1) != 0 and (filemask & side_mask) == 0)
            addPair(opt, names, fullname, side, false, match_mask & filemask, priv.dir_rename_mask);
        if ((filemask & 1) == 0 and (filemask & side_mask) != 0)
            addPair(opt, names, fullname, side, true, match_mask & filemask, priv.dir_rename_mask);
    }
}

fn collectMergeInfoCallback(opt: *Options, mask: u8, dirmask0: u8, names: *const [3]NameEntry, info: TraverseInfo) i32 {
    const priv = opt.priv.?;
    const dirname = priv.current_dir_name;
    const prev_dir_rename_mask = priv.dir_rename_mask;
    const filemask = mask & ~dirmask0;
    var dirmask = dirmask0;
    var match_mask: u8 = 0;
    const mbase_null = (mask & 1) == 0;
    const side1_null = (mask & 2) == 0;
    const side2_null = (mask & 4) == 0;
    const side1_matches_mbase = (!side1_null and !mbase_null and names[0].mode == names[1].mode and hash.eql(names[0].oid, names[1].oid));
    const side2_matches_mbase = (!side2_null and !mbase_null and names[0].mode == names[2].mode and hash.eql(names[0].oid, names[2].oid));
    const sides_match = (!side1_null and !side2_null and names[1].mode == names[2].mode and hash.eql(names[1].oid, names[2].oid));
    const df_conflict = (filemask != 0) and (dirmask != 0);

    if (side1_matches_mbase) {
        match_mask = if (side2_matches_mbase) 7 else 3;
    } else if (side2_matches_mbase) {
        match_mask = 5;
    } else if (sides_match) match_mask = 6;

    var pidx: usize = 0;
    while (names[pidx].mode == 0) pidx += 1;
    const pname = names[pidx].name;
    const fullpath = if (info.base.len == 0) util.dupe(pname) else util.concat(&.{ info.base, "/", pname });

    if (side1_matches_mbase and side2_matches_mbase) {
        if (setupPathInfo(opt, dirname, info.pathlen, fullpath, names, &names[0], mbase_null, false, filemask, dirmask, true) == null) return -1;
        return mask;
    }
    if (sides_match and filemask == 0x07) {
        if (setupPathInfo(opt, dirname, info.pathlen, fullpath, names, &names[1], side1_null, false, filemask, dirmask, true) == null) return -1;
        return mask;
    }
    if (side1_matches_mbase and filemask == 0x07) {
        if (setupPathInfo(opt, dirname, info.pathlen, fullpath, names, &names[2], side2_null, false, filemask, dirmask, true) == null) return -1;
        return mask;
    }
    if (side2_matches_mbase and filemask == 0x07) {
        if (setupPathInfo(opt, dirname, info.pathlen, fullpath, names, &names[1], side1_null, false, filemask, dirmask, true) == null) return -1;
        return mask;
    }
    collectRenameInfo(opt, names, dirname, fullpath, filemask, dirmask, match_mask);
    const ci = setupPathInfo(opt, dirname, info.pathlen, fullpath, names, null, false, df_conflict, filemask, dirmask, false) orelse return -1;
    ci.match_mask = match_mask;
    if (dirmask != 0) {
        var side: usize = if (side1_matches_mbase) MERGE_SIDE2 else if (side2_matches_mbase) MERGE_SIDE1 else MERGE_BASE;
        if (filemask == 0 and (dirmask == 2 or dirmask == 4)) {
            ci.match_mask = 7 - dirmask;
            side = dirmask / 2;
        }
        if (priv.dir_rename_mask != 0x07 and side != MERGE_BASE and priv.sides[side].trivial_merges_okay) {
            iset(&priv.sides[side].possible_trivial_merges, fullpath, priv.dir_rename_mask);
            priv.dir_rename_mask = prev_dir_rename_mask;
            return mask;
        }
        ci.match_mask &= filemask;
        var t: [3]?Oid = .{ null, null, null };
        for (0..3) |i| {
            if (i == 1 and side1_matches_mbase) {
                t[1] = t[0];
            } else if (i == 2 and side2_matches_mbase) {
                t[2] = t[0];
            } else if (i == 2 and sides_match) {
                t[2] = t[1];
            } else {
                if (dirmask & 1 != 0) t[i] = names[i].oid;
            }
            dirmask >>= 1;
        }
        const original_dir_name = priv.current_dir_name;
        priv.current_dir_name = fullpath;
        const newinfo = TraverseInfo{ .base = fullpath, .pathlen = fullpath.len + 1 };
        const ret = if (priv.dir_rename_mask == 0 or priv.dir_rename_mask == 0x07)
            traverseTrees(opt, t, newinfo)
        else
            traverseTreesWrapper(opt, t, newinfo);
        priv.current_dir_name = original_dir_name;
        priv.dir_rename_mask = prev_dir_rename_mask;
        if (ret < 0) return -1;
    }
    return mask;
}

fn resolveTrivialDirectoryMerge(ci: *Info, side: usize) void {
    ci.result.oid = ci.stages[side].oid;
    ci.result.mode = ci.stages[side].mode;
    ci.is_null = hash.isZero(ci.stages[side].oid);
    ci.dirmask &= ~ci.match_mask;
    ci.filemask &= ~ci.match_mask;
    ci.match_mask = 0;
    ci.clean = !ci.df_conflict or ci.dirmask != 0;
    ci.df_conflict = false;
}

fn handleDeferredEntries(opt: *Options) i32 {
    const priv = opt.priv.?;
    var side: usize = 1;
    while (side <= 2) : (side += 1) {
        const s = &priv.sides[side];
        // No rename cache: optimization is only okay when there are no
        // relevant sources at all.
        const optimization_okay = s.relevant_sources.count() == 0;
        s.trivial_merges_okay = optimization_okay;
        const copy = s.possible_trivial_merges;
        s.possible_trivial_merges = .empty;
        var it = copy.iterator();
        while (it.next()) |entry| {
            const path = entry.key_ptr.*;
            const dir_rename_mask: u8 = @intCast(entry.value_ptr.*);
            const ci = priv.paths.get(path).?;
            var dirmask = ci.dirmask;
            if (optimization_okay) {
                resolveTrivialDirectoryMerge(ci, side);
                continue;
            }
            var t: [3]?Oid = .{ null, null, null };
            for (0..3) |i| {
                if (i == 1 and ci.match_mask == 3) {
                    t[1] = t[0];
                } else if (i == 2 and ci.match_mask == 5) {
                    t[2] = t[0];
                } else if (i == 2 and ci.match_mask == 6) {
                    t[2] = t[1];
                } else {
                    if (dirmask & 1 != 0) t[i] = ci.stages[i].oid;
                }
                dirmask >>= 1;
            }
            ci.match_mask &= ci.filemask;
            priv.current_dir_name = path;
            priv.dir_rename_mask = dir_rename_mask;
            const info = TraverseInfo{ .base = path, .pathlen = path.len + 1 };
            const ret = if (priv.dir_rename_mask == 0 or priv.dir_rename_mask == 0x07)
                traverseTrees(opt, t, info)
            else
                traverseTreesWrapper(opt, t, info);
            if (ret < 0) return ret;
        }
        var it2 = s.possible_trivial_merges.iterator();
        while (it2.next()) |entry| {
            const ci = priv.paths.get(entry.key_ptr.*).?;
            resolveTrivialDirectoryMerge(ci, side);
        }
    }
    return 0;
}

fn collectMergeInfo(opt: *Options, merge_base: Oid, side1: Oid, side2: Oid) i32 {
    const priv = opt.priv.?;
    priv.current_dir_name = "";
    const info = TraverseInfo{ .base = "", .pathlen = 0 };
    var ret = traverseTrees(opt, .{ merge_base, side1, side2 }, info);
    if (ret == 0) ret = handleDeferredEntries(opt);
    return ret;
}

// ---------------------------------------------------------------------------
// diffcore-delta / diffcore-rename (subset used by merge-ort)

const Span = struct { hashval: u32, cnt: u32 };

fn spanLess(_: void, a: Span, b: Span) bool {
    return a.hashval < b.hashval;
}

fn hashChars(buf: []const u8) []const Span {
    const is_text = !bufferIsBinary(buf);
    var map: std.AutoArrayHashMapUnmanaged(u32, u32) = .empty;
    var n: u32 = 0;
    var a1: u32 = 0;
    var a2: u32 = 0;
    var i: usize = 0;
    while (i < buf.len) {
        const c: u32 = buf[i];
        i += 1;
        const old1 = a1;
        if (is_text and c == '\r' and i < buf.len and buf[i] == '\n') continue;
        a1 = (a1 << 7) ^ (a2 >> 25);
        a2 = (a2 << 7) ^ (old1 >> 25);
        a1 +%= c;
        n += 1;
        if (n < 64 and c != '\n') continue;
        const hv = (a1 +% a2 *% 0x61) % 107927;
        const gop = map.getOrPut(gpa, hv) catch oom();
        if (gop.found_existing) gop.value_ptr.* += n else gop.value_ptr.* = n;
        n = 0;
        a1 = 0;
        a2 = 0;
    }
    if (n > 0) {
        const hv = (a1 +% a2 *% 0x61) % 107927;
        const gop = map.getOrPut(gpa, hv) catch oom();
        if (gop.found_existing) gop.value_ptr.* += n else gop.value_ptr.* = n;
    }
    const out = gpa.alloc(Span, map.count()) catch oom();
    var it = map.iterator();
    var k: usize = 0;
    while (it.next()) |e| : (k += 1) out[k] = .{ .hashval = e.key_ptr.*, .cnt = e.value_ptr.* };
    std.mem.sort(Span, out, {}, spanLess);
    return out;
}

fn countChanges(s: []const Span, d: []const Span) struct { sc: u64, la: u64 } {
    var sc: u64 = 0;
    var la: u64 = 0;
    var di: usize = 0;
    for (s) |se| {
        while (di < d.len and d[di].hashval < se.hashval) : (di += 1) la += d[di].cnt;
        const src_cnt: u64 = se.cnt;
        var dst_cnt: u64 = 0;
        if (di < d.len and d[di].hashval == se.hashval) {
            dst_cnt = d[di].cnt;
            di += 1;
        }
        if (src_cnt < dst_cnt) {
            la += dst_cnt - src_cnt;
            sc += src_cnt;
        } else sc += dst_cnt;
    }
    while (di < d.len) : (di += 1) la += d[di].cnt;
    return .{ .sc = sc, .la = la };
}

fn specData(s: *Spec) []const u8 {
    if (s.data) |d| return d;
    const o = repo_mod.repo().odb().read(s.oid);
    s.data = if (o) |ob| ob.data else "";
    return s.data.?;
}

fn specCnt(s: *Spec) []const Span {
    if (s.cnt) |c| return c;
    s.cnt = hashChars(specData(s));
    return s.cnt.?;
}

fn estimateSimilarity(src: *Spec, dst: *Spec, minimum_score: i32) i32 {
    if (!isReg(src.mode) or !isReg(dst.mode)) return 0;
    const ss: u64 = specData(src).len;
    const ds: u64 = specData(dst).len;
    const max_size = @max(ss, ds);
    const base_size = @min(ss, ds);
    const delta_size = max_size - base_size;
    if (max_size * @as(u64, @intCast(MAX_SCORE - minimum_score)) < delta_size * @as(u64, @intCast(MAX_SCORE))) return 0;
    const r = countChanges(specCnt(src), specCnt(dst));
    if (ds == 0) return 0;
    return @intCast(r.sc * @as(u64, @intCast(MAX_SCORE)) / max_size);
}

fn basenameSame(src: []const u8, dst: []const u8) bool {
    var sl = src.len;
    var dl = dst.len;
    while (sl > 0 and dl > 0) {
        sl -= 1;
        dl -= 1;
        const c1 = src[sl];
        const c2 = dst[dl];
        if (c1 != c2) return false;
        if (c1 == '/') return true;
    }
    return (sl == 0 or src[sl - 1] == '/') and (dl == 0 or dst[dl - 1] == '/');
}

const RenameDst = struct { p: *Pair, is_rename: bool = false };
const RenameSrc = struct { p: *Pair, score: i32 };

const DirRenameInfo = struct {
    idx_map: IntMap = .empty, // default -1
    guess: StrMap([]const u8) = .empty,
    count: *StrMap(*IntMap) = undefined,
    relevant_source_dirs: *IntMap = undefined,
    setup: bool = false,
};

const UNKNOWN_DIR = "/";

fn getDirname(f: []const u8) []const u8 {
    const i = std.mem.lastIndexOfScalar(u8, f, '/') orelse return "";
    return f[0..i];
}
fn getBasename(f: []const u8) []const u8 {
    const i = std.mem.lastIndexOfScalar(u8, f, '/') orelse return f;
    return f[i + 1 ..];
}

fn getHighestRenamePath(counts: *const IntMap) ?[]const u8 {
    var highest: i32 = 0;
    var best: ?[]const u8 = null;
    var it = counts.iterator();
    while (it.next()) |e| {
        if (e.value_ptr.* > highest) {
            highest = e.value_ptr.*;
            best = e.key_ptr.*;
        }
    }
    return best;
}

fn dirRenameAlreadyDeterminable(counts: *const IntMap) bool {
    var first: i32 = 0;
    var second: i32 = 0;
    var unknown: i32 = 0;
    var it = counts.iterator();
    while (it.next()) |e| {
        const c = e.value_ptr.*;
        if (util.eql(e.key_ptr.*, UNKNOWN_DIR)) {
            unknown = c;
        } else if (c >= first) {
            second = first;
            first = c;
        } else if (c >= second) second = c;
    }
    return first > second + unknown;
}

fn incrementCount(info: *DirRenameInfo, old_dir: []const u8, new_dir: []const u8) void {
    const gop = info.count.getOrPut(gpa, util.dupe(old_dir)) catch oom();
    if (!gop.found_existing) {
        const m = gpa.create(IntMap) catch oom();
        m.* = .empty;
        gop.value_ptr.* = m;
    }
    const g2 = gop.value_ptr.*.getOrPut(gpa, util.dupe(new_dir)) catch oom();
    if (g2.found_existing) g2.value_ptr.* += 1 else g2.value_ptr.* = 1;
}

/// Emulates C's dirname_munge on a NUL-terminated buffer: returns new
/// length; when no slash, the first byte is clobbered.
fn munge(buf: []u8, len: usize) usize {
    if (std.mem.lastIndexOfScalar(u8, buf[0..len], '/')) |i| {
        buf[i] = 0;
        return i;
    }
    if (buf.len > 0) buf[0] = 0;
    return 0;
}

fn updateDirRenameCounts(info: *DirRenameInfo, dirs_removed: *IntMap, oldname: []const u8, newname: []const u8) void {
    if (!info.setup) return;
    const old_dir = util.dupe(oldname);
    const new_dir = util.dupe(newname);
    const new_first: u8 = if (newname.len > 0) newname[0] else 0;
    var olen: usize = old_dir.len;
    var nlen: usize = new_dir.len;
    var first_time = true;
    while (true) {
        var drd_flag: i32 = NOT_RELEVANT;
        const prev_olen = olen;
        olen = munge(old_dir, olen);
        if (!info.relevant_source_dirs.contains(old_dir[0..olen])) break;
        const prev_nlen = nlen;
        nlen = munge(new_dir, nlen);
        if (!first_time) {
            const old_sub = if (olen + 1 <= prev_olen) old_dir[olen + 1 .. prev_olen] else "";
            const new_sub = if (nlen + 1 <= prev_nlen) new_dir[nlen + 1 .. prev_nlen] else "";
            if (nlen == 0) {
                const c0: u8 = if (old_sub.len > 0) old_sub[0] else 0;
                const rest = if (old_sub.len > 0) old_sub[1..] else "";
                if (new_first != c0 or !util.eql(rest, new_sub)) break;
            } else {
                if (!util.eql(old_sub, new_sub)) break;
            }
        }
        drd_flag = iget(dirs_removed, old_dir[0..olen], NOT_RELEVANT);
        if (drd_flag == RELEVANT_FOR_SELF or first_time)
            incrementCount(info, old_dir[0..olen], new_dir[0..nlen]);
        first_time = false;
        if (drd_flag == NOT_RELEVANT) break;
        if (olen == 0 or nlen == 0) break;
    }
}

fn idxPossibleRename(filename: []const u8, info: *DirRenameInfo) i32 {
    if (!info.setup) return -1;
    const new_dir = info.guess.get(getDirname(filename)) orelse return -1;
    const np = util.concat(&.{ new_dir, "/", getBasename(filename) });
    return iget(&info.idx_map, np, -1);
}

fn recordRenamePair(dsts: []RenameDst, srcs: []RenameSrc, dst_index: usize, src_index: usize, score: i32) void {
    const src = srcs[src_index].p;
    const dst = dsts[dst_index].p;
    if (dst.renamed_pair) util.die("internal error: dst already matched.", .{});
    src.one.rename_used += 1;
    dsts[dst_index].is_rename = true;
    dst.one = src.one;
    dst.renamed_pair = true;
    if (util.eql(dst.one.path, dst.two.path)) {
        dst.score = srcs[src_index].score;
    } else dst.score = score;
}

const DiffScore = struct { src: i32, dst: i32, score: i32, name_score: i32 };

fn scoreCompare(a: DiffScore, b: DiffScore) i32 {
    if (a.dst < 0) return if (0 <= b.dst) 1 else 0;
    if (b.dst < 0) return -1;
    if (a.score == b.score) return b.name_score - a.name_score;
    return b.score - a.score;
}

fn scoreLess(_: void, a: DiffScore, b: DiffScore) bool {
    return scoreCompare(a, b) < 0;
}

fn recordIfBetter(m: []DiffScore, o: DiffScore) void {
    var worst: usize = 0;
    var i: usize = 1;
    while (i < 4) : (i += 1) {
        if (scoreCompare(m[i], m[worst]) > 0) worst = i;
    }
    if (scoreCompare(m[worst], o) > 0) m[worst] = o;
}

/// diffcore_rename_extended() restricted to what merge-ort uses.
/// Returns needed_rename_limit.
fn diffcoreRename(pairs: *std.ArrayList(*Pair), relevant_sources: *IntMap, dirs_removed: *IntMap, dir_rename_count: *StrMap(*IntMap), rename_limit: i32, rename_score: i32) i32 {
    var minimum_score = rename_score;
    if (minimum_score == 0) minimum_score = DEFAULT_RENAME_SCORE;
    var needed: i32 = 0;
    var dsts: std.ArrayList(RenameDst) = .empty;
    var srcs: std.ArrayList(RenameSrc) = .empty;
    var info = DirRenameInfo{};

    for (pairs.items) |p| {
        if (!p.one.valid()) {
            if (!p.two.valid()) continue;
            if (hash.eql(p.two.oid, empty_blob)) continue;
            appendT(RenameDst, &dsts, .{ .p = p });
        } else if (hash.eql(p.one.oid, empty_blob)) {
            continue;
        } else if (!p.two.valid()) {
            appendT(RenameSrc, &srcs, .{ .p = p, .score = p.score });
        }
    }
    cleanup: {
        if (dsts.items.len == 0 or srcs.items.len == 0) break :cleanup;
        var rename_count: usize = 0;
        // exact renames
        {
            var table: hash.OidMap(std.ArrayList(usize)) = .empty;
            for (srcs.items, 0..) |s, i| {
                const gop = table.getOrPut(gpa, s.p.one.oid) catch oom();
                if (!gop.found_existing) gop.value_ptr.* = .empty;
                gop.value_ptr.append(gpa, i) catch oom();
            }
            for (dsts.items, 0..) |d, di| {
                const target = d.p.two;
                const lst = table.get(target.oid) orelse continue;
                var best: ?usize = null;
                var best_score: i32 = -1;
                var lim: i32 = 100;
                for (lst.items) |si| {
                    const source = srcs.items[si].p.one;
                    if (!isReg(source.mode) or !isReg(target.mode)) {
                        if (source.mode != target.mode) continue;
                    }
                    if (source.rename_used != 0) continue;
                    var score: i32 = 1;
                    if (basenameSame(source.path, target.path)) score += 1;
                    if (score > best_score) {
                        best = si;
                        best_score = score;
                        if (score == 2) break;
                    }
                    lim -= 1;
                    if (lim == 0) break;
                }
                if (best) |b| {
                    recordRenamePair(dsts.items, srcs.items, di, b, MAX_SCORE);
                    rename_count += 1;
                }
            }
        }
        if (minimum_score == MAX_SCORE) break :cleanup;

        var factor: f64 = 0.5;
        if (os.getenv("GIT_BASENAME_FACTOR")) |bf| {
            const v = std.fmt.parseInt(i64, bf, 10) catch 0;
            factor = @as(f64, @floatFromInt(v)) / 100.0;
        }
        const min_basename_score: i32 = minimum_score + @as(i32, @intFromFloat(factor * @as(f64, @floatFromInt(MAX_SCORE - minimum_score))));
        // remove_unneeded_paths_from_src(0, NULL)
        {
            var k: usize = 0;
            for (srcs.items) |s| {
                if (s.p.one.rename_used != 0) continue;
                srcs.items[k] = s;
                k += 1;
            }
            srcs.items.len = k;
        }
        // initialize_dir_rename_info
        info.setup = true;
        info.count = dir_rename_count;
        info.relevant_source_dirs = dirs_removed;
        for (dsts.items, 0..) |d, i| {
            if (!d.is_rename) {
                iset(&info.idx_map, d.p.two.path, @intCast(i));
                continue;
            }
            updateDirRenameCounts(&info, dirs_removed, d.p.one.path, d.p.two.path);
        }
        {
            var it = info.count.iterator();
            while (it.next()) |e| {
                if (getHighestRenamePath(e.value_ptr.*)) |b| mput([]const u8, &info.guess, e.key_ptr.*, b);
            }
        }
        // find_basename_matches
        {
            var sources: IntMap = .empty;
            var dests: IntMap = .empty;
            for (srcs.items, 0..) |s, i| {
                const base = getBasename(s.p.one.path);
                if (sources.contains(base)) iset(&sources, base, -1) else iset(&sources, base, @intCast(i));
            }
            for (dsts.items, 0..) |d, i| {
                if (d.is_rename) continue;
                const base = getBasename(d.p.two.path);
                if (dests.contains(base)) iset(&dests, base, -1) else iset(&dests, base, @intCast(i));
            }
            for (srcs.items, 0..) |s, i| {
                const filename = s.p.one.path;
                if (!relevant_sources.contains(filename)) continue;
                const base = getBasename(filename);
                var src_index: i32 = iget(&sources, base, -1);
                if (dests.contains(base)) {
                    var dst_index = iget(&dests, base, -1);
                    if (src_index == -1 or dst_index == -1) {
                        src_index = @intCast(i);
                        dst_index = idxPossibleRename(filename, &info);
                    }
                    if (dst_index == -1) continue;
                    const du: usize = @intCast(dst_index);
                    const su: usize = @intCast(src_index);
                    if (dsts.items[du].is_rename) continue;
                    const one = srcs.items[su].p.one;
                    const two = dsts.items[du].p.two;
                    const score = estimateSimilarity(one, two, min_basename_score);
                    if (score < min_basename_score) continue;
                    recordRenamePair(dsts.items, srcs.items, du, su, score);
                    rename_count += 1;
                    updateDirRenameCounts(&info, dirs_removed, one.path, two.path);
                }
            }
        }
        // remove_unneeded_paths_from_src(0, relevant_sources)
        {
            var k: usize = 0;
            for (srcs.items) |s| {
                if (s.p.one.rename_used != 0) continue;
                if (!relevant_sources.contains(s.p.one.path)) continue;
                srcs.items[k] = s;
                k += 1;
            }
            srcs.items.len = k;
        }
        // handle_early_known_dir_renames
        {
            for (srcs.items) |s| {
                var old_dir = getDirname(s.p.one.path);
                while (old_dir.len != 0 and iget(dirs_removed, old_dir, NOT_RELEVANT) != NOT_RELEVANT) {
                    incrementCount(&info, old_dir, UNKNOWN_DIR);
                    old_dir = getDirname(old_dir);
                }
            }
            var it = info.count.iterator();
            while (it.next()) |e| {
                if (iget(dirs_removed, e.key_ptr.*, NOT_RELEVANT) == RELEVANT_FOR_SELF and dirRenameAlreadyDeterminable(e.value_ptr.*))
                    iset(dirs_removed, e.key_ptr.*, RELEVANT_FOR_ANCESTOR);
            }
            var k: usize = 0;
            for (srcs.items) |s| {
                const val = iget(relevant_sources, s.p.one.path, -1);
                if (val == RELEVANT_LOCATION) {
                    var removable = true;
                    var dir = getDirname(s.p.one.path);
                    while (true) {
                        const res = iget(dirs_removed, dir, NOT_RELEVANT);
                        if (res == NOT_RELEVANT) break;
                        if (res == RELEVANT_FOR_SELF) {
                            removable = false;
                            break;
                        }
                        if (dir.len == 0) break;
                        dir = getDirname(dir);
                    }
                    if (removable) {
                        iset(relevant_sources, s.p.one.path, RELEVANT_NO_MORE);
                        continue;
                    }
                }
                srcs.items[k] = s;
                k += 1;
            }
            srcs.items.len = k;
        }
        const num_destinations = dsts.items.len - rename_count;
        const num_sources = srcs.items.len;
        if (num_destinations == 0 or num_sources == 0) break :cleanup;
        if (rename_limit > 0) {
            const lim: u64 = @intCast(rename_limit);
            if (@as(u64, num_destinations) * @as(u64, num_sources) > lim * lim) {
                needed = @intCast(@max(num_sources, num_destinations));
                break :cleanup;
            }
        }
        const mx = gpa.alloc(DiffScore, 4 * num_destinations) catch oom();
        var dst_cnt: usize = 0;
        for (dsts.items, 0..) |d, i| {
            if (d.is_rename) continue;
            const two = d.p.two;
            const m = mx[dst_cnt * 4 .. dst_cnt * 4 + 4];
            for (m) |*x| x.* = .{ .src = 0, .dst = -1, .score = 0, .name_score = 0 };
            for (srcs.items, 0..) |s, j| {
                const one = s.p.one;
                const this_src = DiffScore{
                    .score = estimateSimilarity(one, two, minimum_score),
                    .name_score = if (basenameSame(one.path, two.path)) 1 else 0,
                    .dst = @intCast(i),
                    .src = @intCast(j),
                };
                recordIfBetter(m, this_src);
            }
            dst_cnt += 1;
        }
        const all = mx[0 .. dst_cnt * 4];
        std.mem.sort(DiffScore, all, {}, scoreLess);
        for (all) |x| {
            if (x.dst < 0 or x.score < minimum_score) break;
            const du: usize = @intCast(x.dst);
            const su: usize = @intCast(x.src);
            if (dsts.items[du].is_rename) continue;
            if (srcs.items[su].p.one.rename_used != 0) continue;
            recordRenamePair(dsts.items, srcs.items, du, su, x.score);
            updateDirRenameCounts(&info, dirs_removed, srcs.items[su].p.one.path, dsts.items[du].p.two.path);
        }
    }
    // write back
    var outq: std.ArrayList(*Pair) = .empty;
    for (pairs.items) |p| {
        if (!p.one.valid() and p.two.valid()) {
            appendT(*Pair, &outq, p);
        } else if (p.one.valid() and !p.two.valid()) {
            if (p.one.rename_used == 0) appendT(*Pair, &outq, p);
        } else if (p.renamed_pair) {
            appendT(*Pair, &outq, p);
        }
    }
    pairs.* = outq;
    // cleanup_dir_rename_info(keep = 1)
    if (info.setup) {
        var to_remove: std.ArrayList([]const u8) = .empty;
        var it = info.count.iterator();
        while (it.next()) |e| {
            if (iget(dirs_removed, e.key_ptr.*, NOT_RELEVANT) == 0) {
                appendT([]const u8, &to_remove, e.key_ptr.*);
                continue;
            }
            _ = e.value_ptr.*.orderedRemove(UNKNOWN_DIR);
        }
        for (to_remove.items) |k| _ = info.count.orderedRemove(k);
    }
    return needed;
}

fn resolveDiffpairStatuses(q: []*Pair) void {
    for (q) |p| {
        p.status = 0;
        if (!p.one.valid()) {
            p.status = 'A';
        } else if (!p.two.valid()) {
            p.status = 'D';
        } else if (p.renamed_pair) p.status = 'R';
    }
}

fn detectRegularRenames(opt: *Options, side: usize) bool {
    const priv = opt.priv.?;
    const s = &priv.sides[side];
    if (!(s.pairs.items.len > 0 and s.relevant_sources.count() > 0)) {
        resolveDiffpairStatuses(s.pairs.items);
        return false;
    }
    s.dir_rename_count = .empty;
    const limit: i32 = if (opt.rename_limit <= 0) 7000 else opt.rename_limit;
    const needed = diffcoreRename(&s.pairs, &s.relevant_sources, &s.dirs_removed, &s.dir_rename_count, limit, opt.rename_score);
    resolveDiffpairStatuses(s.pairs.items);
    if (needed > priv.needed_limit) priv.needed_limit = needed;
    return true;
}

// ---------------------------------------------------------------------------
// Directory renames

const Collision = struct {
    source_files: std.ArrayList([]const u8) = .empty, // sorted unique
    reported_already: bool = false,
};

fn applyDirRename(old_dir: []const u8, new_dir: []const u8, old_path: []const u8) []const u8 {
    var oldlen = old_dir.len;
    if (new_dir.len == 0) oldlen += 1;
    const rest = if (oldlen <= old_path.len) old_path[oldlen..] else "";
    return util.concat(&.{ new_dir, rest });
}

fn pathInWay(paths: *StrMap(*Info), path: []const u8, side_mask: u8, p: *Pair) bool {
    const mi = paths.get(path) orelse return false;
    return mi.clean or (side_mask & (mi.filemask | mi.dirmask)) != 0 or
        ((mi.filemask & 1) != 0 and !util.eql(p.one.path, path));
}

const DirRenameEntry = struct { key: []const u8, value: []const u8 };

fn joinList(l: []const []const u8, sep: []const u8) []const u8 {
    var b: util.Buf = .empty;
    for (l, 0..) |s, i| {
        if (i > 0) util.bufAppend(&b, sep);
        util.bufAppend(&b, s);
    }
    return b.items;
}

fn handlePathLevelConflicts(opt: *Options, path: []const u8, side_index: usize, p: *Pair, ri: DirRenameEntry, collisions: *StrMap(*Collision)) ?[]const u8 {
    const new_path = applyDirRename(ri.key, ri.value, path);
    const c = collisions.get(new_path) orelse util.die("BUG: c_info is NULL", .{});
    var clean = true;
    if (c.reported_already) {
        clean = false;
    } else if (pathInWay(&opt.priv.?.paths, new_path, @as(u8, 1) << @intCast(side_index), p)) {
        c.reported_already = true;
        const cp = joinList(c.source_files.items, ", ");
        pathMsg(opt, .CONFLICT_DIR_RENAME_FILE_IN_WAY, false, new_path, null, null, c.source_files.items, util.fmt("CONFLICT (implicit dir rename): Existing file/dir at {s} in the way of implicit directory rename(s) putting the following path(s) there: {s}.", .{ new_path, cp }));
        clean = false;
    } else if (c.source_files.items.len > 1) {
        c.reported_already = true;
        const cp = joinList(c.source_files.items, ", ");
        pathMsg(opt, .CONFLICT_DIR_RENAME_COLLISION, false, new_path, null, null, c.source_files.items, util.fmt("CONFLICT (implicit dir rename): Cannot map more than one path to {s}; implicit directory renames tried to put these paths there: {s}", .{ new_path, cp }));
        clean = false;
    }
    if (!clean) return null;
    return new_path;
}

fn getProvisionalDirectoryRenames(opt: *Options, side: usize, clean: *i32) void {
    const priv = opt.priv.?;
    var it = priv.sides[side].dir_rename_count.iterator();
    while (it.next()) |e| {
        const source_dir = e.key_ptr.*;
        var max: i32 = 0;
        var bad_max: i32 = 0;
        var best: []const u8 = "";
        var cit = e.value_ptr.*.iterator();
        while (cit.next()) |ce| {
            const count = ce.value_ptr.*;
            if (count == max) {
                bad_max = max;
            } else if (count > max) {
                max = count;
                best = ce.key_ptr.*;
            }
        }
        if (max == 0) continue;
        if (bad_max == max) {
            pathMsg(opt, .CONFLICT_DIR_RENAME_SPLIT, false, source_dir, null, null, null, util.fmt("CONFLICT (directory rename split): Unclear where to rename {s} to; it was renamed to multiple other directories, with no destination getting a majority of the files.", .{source_dir}));
            clean.* = 0;
        } else {
            mput([]const u8, &priv.sides[side].dir_renames, source_dir, best);
        }
    }
}

fn handleDirectoryLevelConflicts(opt: *Options) void {
    const priv = opt.priv.?;
    var dup: std.ArrayList([]const u8) = .empty;
    for (priv.sides[1].dir_renames.keys()) |k| {
        if (priv.sides[2].dir_renames.contains(k)) appendT([]const u8, &dup, k);
    }
    for (dup.items) |k| {
        _ = priv.sides[1].dir_renames.orderedRemove(k);
        _ = priv.sides[2].dir_renames.orderedRemove(k);
    }
}

fn checkDirRenamed(path: []const u8, dir_renames: *StrMap([]const u8)) ?DirRenameEntry {
    var temp = path;
    while (std.mem.lastIndexOfScalar(u8, temp, '/')) |i| {
        temp = temp[0..i];
        if (dir_renames.getEntry(temp)) |e| return .{ .key = e.key_ptr.*, .value = e.value_ptr.* };
    }
    return null;
}

fn sortedInsert(l: *std.ArrayList([]const u8), s: []const u8) void {
    var lo: usize = 0;
    var hi: usize = l.items.len;
    while (lo < hi) {
        const mid = (lo + hi) / 2;
        switch (std.mem.order(u8, l.items[mid], s)) {
            .eq => return,
            .lt => lo = mid + 1,
            .gt => hi = mid,
        }
    }
    l.insert(gpa, lo, s) catch oom();
}

fn computeCollisions(collisions: *StrMap(*Collision), dir_renames: *StrMap([]const u8), pairs: []*Pair) void {
    collisions.* = .empty;
    if (dir_renames.count() == 0) return;
    for (pairs) |pair| {
        if (pair.status != 'A' and pair.status != 'R') continue;
        const ri = checkDirRenamed(pair.two.path, dir_renames) orelse continue;
        const new_path = applyDirRename(ri.key, ri.value, pair.two.path);
        const gop = collisions.getOrPut(gpa, new_path) catch oom();
        if (!gop.found_existing) {
            const c = gpa.create(Collision) catch oom();
            c.* = .{};
            gop.value_ptr.* = c;
        }
        sortedInsert(&gop.value_ptr.*.source_files, pair.two.path);
    }
}

fn checkForDirectoryRename(opt: *Options, path: []const u8, side_index: usize, p: *Pair, dir_renames: *StrMap([]const u8), exclusions: *StrMap([]const u8), collisions: *[3]StrMap(*Collision), clean_merge: *i32) ?[]const u8 {
    if (dir_renames.count() == 0) return null;
    const other_side = 3 - side_index;
    if (collisions[other_side].get(path) != null) return null;
    const ri = checkDirRenamed(path, dir_renames) orelse return null;
    const new_dir = ri.value;
    if (exclusions.contains(new_dir)) {
        pathMsg(opt, .INFO_DIR_RENAME_SKIPPED_DUE_TO_RERENAME, true, ri.key, path, new_dir, null, util.fmt("WARNING: Avoiding applying {s} -> {s} rename to {s}, because {s} itself was renamed.", .{ ri.key, new_dir, path, new_dir }));
        return null;
    }
    const np = handlePathLevelConflicts(opt, path, side_index, p, ri, &collisions[side_index]);
    if (np == null) clean_merge.* = 0;
    return np;
}

fn applyDirectoryRenameModifications(opt: *Options, pair: *Pair, new_path: []const u8) void {
    const priv = opt.priv.?;
    const entry = priv.paths.getEntry(pair.two.path).?;
    const old_path = entry.key_ptr.*;
    var ci = entry.value_ptr.*;
    var dirs_to_insert: std.ArrayList([]const u8) = .empty;
    var cur_path = new_path;
    var parent_name: []const u8 = "";
    while (true) {
        if (std.mem.lastIndexOfScalar(u8, cur_path, '/')) |i| {
            parent_name = cur_path[0..i];
        } else {
            parent_name = "";
            break;
        }
        if (priv.paths.getEntry(parent_name)) |e| {
            parent_name = e.key_ptr.*;
            break;
        }
        appendT([]const u8, &dirs_to_insert, parent_name);
        cur_path = parent_name;
    }
    var i: usize = dirs_to_insert.items.len;
    while (i > 0) {
        i -= 1;
        const cur_dir = dirs_to_insert.items[i];
        const dir_ci = newInfo();
        dir_ci.directory_name = parent_name;
        dir_ci.basename_offset = if (parent_name.len > 0) parent_name.len + 1 else 0;
        dir_ci.dirmask = ci.filemask;
        mput(*Info, &priv.paths, cur_dir, dir_ci);
        parent_name = cur_dir;
    }
    if (ci.dirmask == 0) {
        _ = priv.paths.orderedRemove(old_path);
    } else {
        const new_ci = newInfo();
        new_ci.* = ci.*;
        new_ci.dirmask = 0;
        new_ci.stages[1] = .{};
        ci.filemask = 0;
        ci.clean = true;
        for (0..3) |k| {
            if (ci.dirmask & (@as(u8, 1) << @intCast(k)) != 0) continue;
            ci.stages[k] = .{};
        }
        ci = new_ci;
    }
    const branch_with_new_path = if (ci.filemask == 2) opt.branch1 else opt.branch2;
    const branch_with_dir_rename = if (ci.filemask == 2) opt.branch2 else opt.branch1;
    ci.directory_name = parent_name;
    ci.basename_offset = if (parent_name.len > 0) parent_name.len + 1 else 0;
    if (priv.paths.get(new_path)) |new_ci| {
        new_ci.filemask |= ci.filemask;
        if (new_ci.dirmask != 0) new_ci.df_conflict = true;
        const index: usize = ci.filemask >> 1;
        new_ci.pathnames[index] = ci.pathnames[index];
        new_ci.stages[index] = ci.stages[index];
        ci = new_ci;
    } else {
        mput(*Info, &priv.paths, new_path, ci);
    }
    if (opt.detect_directory_renames == .true_) {
        if (pair.status == 'A') {
            pathMsg(opt, .INFO_DIR_RENAME_APPLIED, true, new_path, old_path, null, null, util.fmt("Path updated: {s} added in {s} inside a directory that was renamed in {s}; moving it to {s}.", .{ old_path, branch_with_new_path, branch_with_dir_rename, new_path }));
        } else {
            pathMsg(opt, .INFO_DIR_RENAME_APPLIED, true, new_path, old_path, null, null, util.fmt("Path updated: {s} renamed to {s} in {s}, inside a directory that was renamed in {s}; moving it to {s}.", .{ pair.one.path, old_path, branch_with_new_path, branch_with_dir_rename, new_path }));
        }
    } else {
        ci.path_conflict = true;
        if (pair.status == 'A') {
            pathMsg(opt, .CONFLICT_DIR_RENAME_SUGGESTED, true, new_path, old_path, null, null, util.fmt("CONFLICT (file location): {s} added in {s} inside a directory that was renamed in {s}, suggesting it should perhaps be moved to {s}.", .{ old_path, branch_with_new_path, branch_with_dir_rename, new_path }));
        } else {
            pathMsg(opt, .CONFLICT_DIR_RENAME_SUGGESTED, true, new_path, old_path, null, null, util.fmt("CONFLICT (file location): {s} renamed to {s} in {s}, inside a directory that was renamed in {s}, suggesting it should perhaps be moved to {s}.", .{ pair.one.path, old_path, branch_with_new_path, branch_with_dir_rename, new_path }));
        }
    }
    // pair.two may be shared? No: two specs are per pair.
    pair.two.path = new_path;
}

fn collectRenames(opt: *Options, result: *std.ArrayList(*Pair), side_index: usize, collisions: *[3]StrMap(*Collision), dir_renames_for_side: *StrMap([]const u8), rename_exclusions: *StrMap([]const u8)) i32 {
    const priv = opt.priv.?;
    var clean: i32 = 1;
    for (priv.sides[side_index].pairs.items) |p| {
        if (p.status != 'A' and p.status != 'R') continue;
        if (!(opt.detect_directory_renames == .none and p.status == 'R')) {
            const new_path = checkForDirectoryRename(opt, p.two.path, side_index, p, dir_renames_for_side, rename_exclusions, collisions, &clean);
            if (p.status != 'R' and new_path == null) continue;
            if (new_path) |np| applyDirectoryRenameModifications(opt, p, np);
        }
        p.score = @intCast(side_index);
        appendT(*Pair, result, p);
    }
    return clean;
}

fn comparePairsLess(_: void, a: *Pair, b: *Pair) bool {
    return std.mem.order(u8, a.one.path, b.one.path) == .lt;
}

fn processRenames(opt: *Options, renames: []*Pair) i32 {
    const priv = opt.priv.?;
    var clean_merge: i32 = 1;
    var i: usize = 0;
    while (i < renames.len) : (i += 1) {
        const pair = renames[i];
        var oldpath: ?[]const u8 = null;
        var oldinfo: ?*Info = null;
        var newinfo: ?*Info = null;
        if (priv.paths.getEntry(pair.one.path)) |e| {
            oldpath = e.key_ptr.*;
            oldinfo = e.value_ptr.*;
        }
        var newpath: []const u8 = pair.two.path;
        if (priv.paths.getEntry(pair.two.path)) |e| {
            newpath = e.key_ptr.*;
            newinfo = e.value_ptr.*;
        }
        if (oldpath != null and newinfo != null and util.eql(oldpath.?, newpath)) continue;
        if (oldinfo == null or oldinfo.?.clean) continue;
        const op = oldpath.?;
        const oi = oldinfo.?;
        if (i + 1 < renames.len and util.eql(op, renames[i + 1].one.path)) {
            var pathnames: [3][]const u8 = .{ op, newpath, renames[i + 1].two.path };
            const base = priv.paths.get(pathnames[0]).?;
            const side1 = priv.paths.get(pathnames[1]).?;
            const side2 = priv.paths.get(pathnames[2]).?;
            if (util.eql(pathnames[1], pathnames[2])) {
                side1.stages[0] = base.stages[0];
                side1.filemask |= 1;
                base.is_null = true;
                base.clean = true;
                i += 1;
                continue;
            }
            var merged: VersionInfo = .{};
            clean_merge = handleContentMerge(opt, pair.one.path, base.stages[0], side1.stages[1], side2.stages[2], &pathnames, 1 + 2 * priv.call_depth, true, &merged);
            if (clean_merge < 0) return -1;
            var was_binary_blob = false;
            if (clean_merge == 0 and merged.mode == side1.stages[1].mode and hash.eql(merged.oid, side1.stages[1].oid))
                was_binary_blob = true;
            side1.stages[1] = merged;
            if (was_binary_blob) {
                merged.oid = side2.stages[2].oid;
                merged.mode = side2.stages[2].mode;
            }
            side2.stages[2] = merged;
            side1.path_conflict = true;
            side2.path_conflict = true;
            base.path_conflict = true;
            pathMsg(opt, .CONFLICT_RENAME_RENAME, false, pathnames[0], pathnames[1], pathnames[2], null, util.fmt("CONFLICT (rename/rename): {s} renamed to {s} in {s} and to {s} in {s}.", .{ pathnames[0], pathnames[1], opt.branch1, pathnames[2], opt.branch2 }));
            i += 1;
            continue;
        }
        const ni = newinfo orelse util.die("BUG: newinfo missing for {s}", .{newpath});
        const target_index: usize = @intCast(pair.score);
        const other_source_index = 3 - target_index;
        const old_sidemask: u8 = @as(u8, 1) << @intCast(other_source_index);
        const source_deleted = oi.filemask == 1;
        var collision = (ni.filemask & old_sidemask) != 0;
        const type_changed = !source_deleted and (isReg(oi.stages[other_source_index].mode) != isReg(ni.stages[target_index].mode));
        if (type_changed and collision) collision = false;
        var rename_branch: []const u8 = "";
        var delete_branch: []const u8 = "";
        if (source_deleted) {
            if (target_index == 1) {
                rename_branch = opt.branch1;
                delete_branch = opt.branch2;
            } else {
                rename_branch = opt.branch2;
                delete_branch = opt.branch1;
            }
        }
        if (collision and !source_deleted) {
            var pathnames: [3][]const u8 = undefined;
            pathnames[0] = op;
            pathnames[other_source_index] = op;
            pathnames[target_index] = newpath;
            const base = priv.paths.get(pathnames[0]).?;
            const side1 = priv.paths.get(pathnames[1]).?;
            const side2 = priv.paths.get(pathnames[2]).?;
            var merged: VersionInfo = .{};
            const clean = handleContentMerge(opt, pair.one.path, base.stages[0], side1.stages[1], side2.stages[2], &pathnames, 1 + 2 * priv.call_depth, true, &merged);
            if (clean < 0) return -1;
            ni.stages[target_index] = merged;
            if (clean == 0) {
                pathMsg(opt, .CONFLICT_RENAME_COLLIDES, false, newpath, op, null, null, util.fmt("CONFLICT (rename involved in collision): rename of {s} -> {s} has content conflicts AND collides with another path; this may result in nested conflict markers.", .{ op, newpath }));
            }
        } else if (collision and source_deleted) {
            ni.path_conflict = true;
            pathMsg(opt, .CONFLICT_RENAME_DELETE, false, newpath, op, null, null, util.fmt("CONFLICT (rename/delete): {s} renamed to {s} in {s}, but deleted in {s}.", .{ op, newpath, rename_branch, delete_branch }));
        } else {
            ni.stages[0] = oi.stages[0];
            ni.filemask |= 1;
            ni.pathnames[0] = op;
            if (type_changed) {
                oi.stages[0] = .{};
                oi.filemask &= 0x06;
            } else if (source_deleted) {
                ni.path_conflict = true;
                pathMsg(opt, .CONFLICT_RENAME_DELETE, false, newpath, op, null, null, util.fmt("CONFLICT (rename/delete): {s} renamed to {s} in {s}, but deleted in {s}.", .{ op, newpath, rename_branch, delete_branch }));
            } else {
                ni.stages[other_source_index] = oi.stages[other_source_index];
                ni.filemask |= old_sidemask;
                ni.pathnames[other_source_index] = op;
            }
        }
        if (!type_changed) {
            oi.is_null = true;
            oi.clean = true;
        }
    }
    return clean_merge;
}

fn detectAndProcessRenames(opt: *Options) i32 {
    const priv = opt.priv.?;
    var clean: i32 = 1;
    const possible = (priv.sides[1].pairs.items.len > 0 and priv.sides[1].relevant_sources.count() > 0) or
        (priv.sides[2].pairs.items.len > 0 and priv.sides[2].relevant_sources.count() > 0);
    defer {
        priv.sides[1].pairs = .empty;
        priv.sides[2].pairs = .empty;
    }
    if (!possible) return clean;
    if (opt.detect_renames == 0) return clean;
    _ = detectRegularRenames(opt, 1);
    _ = detectRegularRenames(opt, 2);
    const need_dir_renames = priv.call_depth == 0 and (opt.detect_directory_renames == .true_ or opt.detect_directory_renames == .conflict);
    if (need_dir_renames) {
        getProvisionalDirectoryRenames(opt, 1, &clean);
        getProvisionalDirectoryRenames(opt, 2, &clean);
        handleDirectoryLevelConflicts(opt);
    }
    var collisions: [3]StrMap(*Collision) = .{ .empty, .empty, .empty };
    computeCollisions(&collisions[1], &priv.sides[2].dir_renames, priv.sides[1].pairs.items);
    computeCollisions(&collisions[2], &priv.sides[1].dir_renames, priv.sides[2].pairs.items);
    var combined: std.ArrayList(*Pair) = .empty;
    clean &= collectRenames(opt, &combined, 1, &collisions, &priv.sides[2].dir_renames, &priv.sides[1].dir_renames);
    clean &= collectRenames(opt, &combined, 2, &collisions, &priv.sides[1].dir_renames, &priv.sides[2].dir_renames);
    std.mem.sort(*Pair, combined.items, {}, comparePairsLess);
    const r = processRenames(opt, combined.items);
    if (r < 0) return -1;
    clean &= r;
    return clean;
}

// ---------------------------------------------------------------------------
// Content merges

fn readBlob(oid: Oid) []const u8 {
    if (hash.isZero(oid)) return "";
    const o = repo_mod.repo().odb().read(oid) orelse return "";
    return o.data;
}

fn merge3way(opt: *Options, path: []const u8, o: Oid, a: Oid, b: Oid, pathnames: *const [3][]const u8, extra_marker_size: i32) LlResult {
    const priv = opt.priv.?;
    var ll = LlOpts{
        .renormalize = opt.renormalize,
        .extra_marker_size = extra_marker_size,
        .xdl_flags = opt.xdl_flags,
        .conflict_style = opt.conflict_style,
    };
    if (priv.call_depth != 0) {
        ll.virtual_ancestor = true;
        ll.variant = .none;
    } else {
        ll.variant = switch (opt.recursive_variant) {
            .ours => .ours,
            .theirs => .theirs,
            .normal => .none,
        };
    }
    const anc = opt.ancestor orelse "";
    var base: []const u8 = undefined;
    var name1: []const u8 = undefined;
    var name2: []const u8 = undefined;
    if (util.eql(pathnames[0], pathnames[1]) and util.eql(pathnames[1], pathnames[2])) {
        base = anc;
        name1 = opt.branch1;
        name2 = opt.branch2;
    } else {
        base = util.fmt("{s}:{s}", .{ anc, pathnames[0] });
        name1 = util.fmt("{s}:{s}", .{ opt.branch1, pathnames[1] });
        name2 = util.fmt("{s}:{s}", .{ opt.branch2, pathnames[2] });
    }
    const r = llMerge(path, readBlob(o), base, readBlob(a), name1, readBlob(b), name2, &ll);
    if (r.status == .binary_conflict)
        pathMsg(opt, .CONFLICT_BINARY, false, path, null, null, null, util.fmt("warning: Cannot merge binary files: {s} ({s} vs. {s})", .{ path, name1, name2 }));
    return r;
}

const SubmoduleItem = struct { path: []const u8, flag: Ct, abbrev: ?[]const u8 };
var conflicted_submodules: std.ArrayList(SubmoduleItem) = .empty;

const sub_local_repo_env = [_][]const u8{
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CONFIG",           "GIT_OBJECT_DIRECTORY",
    "GIT_DIR",                          "GIT_WORK_TREE",        "GIT_IMPLICIT_WORK_TREE",
    "GIT_GRAFT_FILE",                   "GIT_INDEX_FILE",       "GIT_NO_REPLACE_OBJECTS",
    "GIT_REPLACE_REF_BASE",             "GIT_PREFIX",           "GIT_SHALLOW_FILE",
    "GIT_COMMON_DIR",
};

/// repo_submodule_init(): locate the submodule's git dir.
fn submoduleGitDir(path: []const u8) ?[]const u8 {
    const r = repo_mod.repo();
    if (r.work_tree) |wt| {
        const dotgit = util.concat(&.{ wt, "/", path, "/.git" });
        const gd = repo_mod.readGitfile(dotgit) orelse dotgit;
        if (repo_mod.isGitDirectory(gd)) return gd;
    }
    const md = util.concat(&.{ r.common_dir, "/modules/", path });
    if (repo_mod.isGitDirectory(md)) return md;
    return null;
}

fn subGit(gitdir: []const u8, args: []const []const u8) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, @import("proc.zig").gitBinary()) catch oom();
    argv.appendSlice(gpa, args) catch oom();
    return os.run(argv.items, .{ .capture_stdout = true, .no_stdin = true, .no_stderr = true, .env = &.{.{ "GIT_DIR", gitdir }}, .unset_env = &sub_local_repo_env });
}

/// repo_in_merge_bases(a, b) in the submodule: 1 if a is an ancestor of b, 0 if not, -1 on error.
fn subIsAncestor(gitdir: []const u8, a: Oid, b: Oid) i32 {
    const r = subGit(gitdir, &.{ "merge-base", "--is-ancestor", &hash.hex(a), &hash.hex(b) });
    if (r.signaled) return -1;
    return switch (r.status) {
        0 => 1,
        1 => 0,
        else => -1,
    };
}

fn subHasCommit(gitdir: []const u8, o: Oid) bool {
    const r = subGit(gitdir, &.{ "rev-parse", "-q", "--verify", util.concat(&.{ &hash.hex(o), "^{commit}" }) });
    return !r.signaled and r.status == 0;
}

fn subFormatCommit(sb: *util.Buf, gitdir: []const u8, o: Oid) void {
    const r = subGit(gitdir, &.{ "show", "-s", "--no-color", "--format=%h %s", &hash.hex(o) });
    util.bufAppend(sb, "    ");
    util.bufAppend(sb, util.trimRight(r.stdout));
    util.bufByte(sb, '\n');
}

/// find_first_merges(); returns -1 on error.
fn subFindFirstMerges(gitdir: []const u8, a: Oid, b: Oid, result: *std.ArrayList(Oid)) i32 {
    const r = subGit(gitdir, &.{ "rev-list", "--merges", "--ancestry-path", "--all", util.concat(&.{ "^", &hash.hex(a) }) });
    if (r.signaled or r.status != 0) return -1;
    var merges: std.ArrayList(Oid) = .empty;
    var it = std.mem.tokenizeScalar(u8, r.stdout, '\n');
    while (it.next()) |line| {
        const m = hash.fromHex(util.trimRight(line)) orelse continue;
        const ret = subIsAncestor(gitdir, b, m);
        if (ret < 0) return ret;
        if (ret > 0) merges.append(gpa, m) catch oom();
    }
    for (merges.items, 0..) |m1, i| {
        var contains_another = false;
        for (merges.items, 0..) |m2, j| {
            if (i == j) continue;
            const ret = subIsAncestor(gitdir, m2, m1);
            if (ret < 0) return ret;
            if (ret > 0) {
                contains_another = true;
                break;
            }
        }
        if (!contains_another) result.append(gpa, m1) catch oom();
    }
    return @intCast(result.items.len);
}

fn mergeSubmodule(opt: *Options, path: []const u8, o: Oid, a: Oid, b: Oid, result: *Oid) i32 {
    const priv = opt.priv.?;
    const search = priv.call_depth == 0;
    var ret: i32 = 0;
    var sub_flag: Ct = .CONFLICT_SUBMODULE_FAILED_TO_MERGE;
    result.* = if (priv.call_depth != 0) o else a;
    const gitdir_opt = submoduleGitDir(path);
    body: {
        const gitdir = gitdir_opt orelse {
            pathMsg(opt, .CONFLICT_SUBMODULE_NOT_INITIALIZED, false, path, null, null, null, util.fmt("Failed to merge submodule {s} (not checked out)", .{path}));
            sub_flag = .CONFLICT_SUBMODULE_NOT_INITIALIZED;
            break :body;
        };
        if (hash.isZero(o)) {
            pathMsg(opt, .CONFLICT_SUBMODULE_NULL_MERGE_BASE, false, path, null, null, null, util.fmt("Failed to merge submodule {s} (no merge base)", .{path}));
            break :body;
        }
        if (!subHasCommit(gitdir, o) or !subHasCommit(gitdir, a) or !subHasCommit(gitdir, b)) {
            pathMsg(opt, .CONFLICT_SUBMODULE_HISTORY_NOT_AVAILABLE, false, path, null, null, null, util.fmt("Failed to merge submodule {s} (commits not present)", .{path}));
            sub_flag = .CONFLICT_SUBMODULE_HISTORY_NOT_AVAILABLE;
            break :body;
        }
        const corrupt = util.fmt("error: failed to merge submodule {s} (repository corrupt)", .{path});
        var ret2 = subIsAncestor(gitdir, o, a);
        if (ret2 > 0) ret2 = subIsAncestor(gitdir, o, b);
        if (ret2 < 0) {
            pathMsg(opt, .ERROR_SUBMODULE_CORRUPT, false, path, null, null, null, corrupt);
            ret = -1;
            break :body;
        }
        if (ret2 == 0) {
            pathMsg(opt, .CONFLICT_SUBMODULE_MAY_HAVE_REWINDS, false, path, null, null, null, util.fmt("Failed to merge submodule {s} (commits don't follow merge-base)", .{path}));
            break :body;
        }
        ret2 = subIsAncestor(gitdir, a, b);
        if (ret2 < 0) {
            pathMsg(opt, .ERROR_SUBMODULE_CORRUPT, false, path, null, null, null, corrupt);
            ret = -1;
            break :body;
        }
        if (ret2 > 0) {
            result.* = b;
            pathMsg(opt, .INFO_SUBMODULE_FAST_FORWARDING, true, path, null, null, null, util.fmt("Note: Fast-forwarding submodule {s} to {s}", .{ path, &hash.hex(b) }));
            ret = 1;
            break :body;
        }
        ret2 = subIsAncestor(gitdir, b, a);
        if (ret2 < 0) {
            pathMsg(opt, .ERROR_SUBMODULE_CORRUPT, false, path, null, null, null, corrupt);
            ret = -1;
            break :body;
        }
        if (ret2 > 0) {
            result.* = a;
            pathMsg(opt, .INFO_SUBMODULE_FAST_FORWARDING, true, path, null, null, null, util.fmt("Note: Fast-forwarding submodule {s} to {s}", .{ path, &hash.hex(a) }));
            ret = 1;
            break :body;
        }
        if (!search) break :body;
        var merges: std.ArrayList(Oid) = .empty;
        const n = subFindFirstMerges(gitdir, a, b, &merges);
        if (n < 0) {
            pathMsg(opt, .ERROR_SUBMODULE_CORRUPT, false, path, null, null, null, corrupt);
            ret = -1;
        } else if (n == 0) {
            pathMsg(opt, .CONFLICT_SUBMODULE_FAILED_TO_MERGE, false, path, null, null, null, util.fmt("Failed to merge submodule {s}", .{path}));
        } else {
            var sb: util.Buf = .empty;
            for (merges.items) |m| subFormatCommit(&sb, gitdir, m);
            if (n == 1) {
                pathMsg(opt, .CONFLICT_SUBMODULE_FAILED_TO_MERGE_BUT_POSSIBLE_RESOLUTION, false, path, null, null, null, util.fmt("Failed to merge submodule {s}, but a possible merge resolution exists: {s}", .{ path, sb.items }));
            } else {
                pathMsg(opt, .CONFLICT_SUBMODULE_FAILED_TO_MERGE_BUT_POSSIBLE_RESOLUTION, false, path, null, null, null, util.fmt("Failed to merge submodule {s}, but multiple possible merges exist:\n{s}", .{ path, sb.items }));
            }
        }
    }
    if (priv.call_depth == 0 and ret == 0) {
        var abbrev: ?[]const u8 = null;
        if (gitdir_opt) |gd| {
            const r = subGit(gd, &.{ "rev-parse", "--short", &hash.hex(b) });
            abbrev = util.dupe(util.trimRight(r.stdout));
        }
        appendT(SubmoduleItem, &conflicted_submodules, .{ .path = path, .flag = sub_flag, .abbrev = abbrev });
    }
    return ret;
}

fn handleContentMerge(opt: *Options, path: []const u8, o: VersionInfo, a: VersionInfo, b: VersionInfo, pathnames: *const [3][]const u8, extra_marker_size: i32, record_object: bool, result: *VersionInfo) i32 {
    const priv = opt.priv.?;
    var clean: i32 = 1;
    if (a.mode == b.mode or a.mode == o.mode) {
        result.mode = b.mode;
    } else {
        result.mode = a.mode;
        clean = if (b.mode == o.mode) 1 else 0;
    }
    if (hash.eql(a.oid, b.oid) or hash.eql(a.oid, o.oid)) {
        result.oid = b.oid;
    } else if (hash.eql(b.oid, o.oid)) {
        result.oid = a.oid;
    } else if (isReg(a.mode)) {
        const two_way = (S_IFMT & o.mode) != (S_IFMT & a.mode);
        const r = merge3way(opt, path, if (two_way) hash.zero else o.oid, a.oid, b.oid, pathnames, extra_marker_size);
        if (r.status == .err or r.result == null) {
            pathMsg(opt, .ERROR_THREEWAY_CONTENT_MERGE_FAILED, false, pathnames[0], pathnames[1], pathnames[2], null, util.fmt("error: failed to execute internal merge for {s}", .{path}));
            return -1;
        }
        if (record_object) result.oid = repo_mod.repo().odb().write(.blob, r.result.?);
        if (@intFromEnum(r.status) > 0) clean = 0;
        pathMsg(opt, .INFO_AUTO_MERGING, true, path, null, null, null, util.fmt("Auto-merging {s}", .{path}));
    } else if (isGitlink(a.mode)) {
        const two_way = (S_IFMT & o.mode) != (S_IFMT & a.mode);
        clean = mergeSubmodule(opt, pathnames[0], if (two_way) hash.zero else o.oid, a.oid, b.oid, &result.oid);
        if (clean < 0) return -1;
        if (priv.call_depth != 0 and two_way and clean == 0) {
            result.mode = o.mode;
            result.oid = o.oid;
        }
    } else if (isLnk(a.mode)) {
        if (priv.call_depth != 0) {
            clean = 0;
            result.mode = o.mode;
            result.oid = o.oid;
        } else switch (opt.recursive_variant) {
            .normal => {
                clean = 0;
                result.oid = a.oid;
            },
            .ours => result.oid = a.oid,
            .theirs => result.oid = b.oid,
        }
    } else util.die("BUG: unsupported object type in the tree: {o:0>6} for {s}", .{ a.mode, path });
    return clean;
}

// ---------------------------------------------------------------------------
// process_entries

fn sortDirsNextToChildren(one: []const u8, two: []const u8) i32 {
    var i: usize = 0;
    while (i < one.len and i < two.len and one[i] == two[i]) i += 1;
    const c1: u8 = if (i < one.len) one[i] else '/';
    const c2: u8 = if (i < two.len) two[i] else '/';
    if (c1 == c2) return if (i < one.len) 1 else -1;
    return @as(i32, c1) - @as(i32, c2);
}

const PEntry = struct { path: []const u8, info: *Info };

fn plistLess(_: void, a: PEntry, b: PEntry) bool {
    return sortDirsNextToChildren(a.path, b.path) < 0;
}

const VEntry = struct { name: []const u8, mi: *Info };
const OEntry = struct { dir: []const u8, offset: usize };

const DirMeta = struct {
    versions: std.ArrayList(VEntry) = .empty,
    offsets: std.ArrayList(OEntry) = .empty,
    last_directory: ?[]const u8 = null,
};

fn vLess(_: void, a: VEntry, b: VEntry) bool {
    return objects.baseNameCompare(a.name, a.mi.result.mode, b.name, b.mi.result.mode) == .lt;
}

fn writeTreeObj(versions: []VEntry) Oid {
    std.mem.sort(VEntry, versions, {}, vLess);
    var b: util.Buf = .empty;
    for (versions) |v| {
        util.bufPrint(&b, "{o} {s}\x00", .{ v.mi.result.mode, v.name });
        util.bufAppend(&b, &v.mi.result.oid);
    }
    return repo_mod.repo().odb().write(.tree, b.items);
}

fn recordEntryForTree(dm: *DirMeta, path: []const u8, mi: *Info) void {
    if (mi.is_null) return;
    appendT(VEntry, &dm.versions, .{ .name = path[mi.basename_offset..], .mi = mi });
}

fn writeCompletedDirectory(opt: *Options, new_dir: []const u8, dm: *DirMeta) void {
    const priv = opt.priv.?;
    if (dm.last_directory) |ld| {
        if (util.eql(new_dir, ld)) return;
    }
    if (dm.last_directory == null or util.startsWith(new_dir, dm.last_directory.?)) {
        dm.last_directory = new_dir;
        appendT(OEntry, &dm.offsets, .{ .dir = new_dir, .offset = dm.versions.items.len });
        return;
    }
    const dir_info = priv.paths.get(dm.last_directory.?).?;
    const offset = dm.offsets.items[dm.offsets.items.len - 1].offset;
    if (offset == dm.versions.items.len) {
        dir_info.is_null = true;
    } else {
        const record_tree = !opt.mergeability_only or priv.call_depth != 0;
        dir_info.is_null = false;
        dir_info.result.mode = os.S_IFDIR;
        if (record_tree) dir_info.result.oid = writeTreeObj(dm.versions.items[offset..]);
    }
    dm.offsets.items.len -= 1;
    dm.versions.items.len = offset;
    const prev_dir: ?[]const u8 = if (dm.offsets.items.len == 0) null else dm.offsets.items[dm.offsets.items.len - 1].dir;
    if (prev_dir == null or !util.eql(new_dir, prev_dir.?)) {
        appendT(OEntry, &dm.offsets, .{ .dir = new_dir, .offset = dm.versions.items.len });
    }
    dm.last_directory = new_dir;
}

fn processEntry(opt: *Options, path0: []const u8, ci0: *Info, dm: *DirMeta) i32 {
    const priv = opt.priv.?;
    var path = path0;
    var ci = ci0;
    var df_file_index: usize = 0;
    if (ci.dirmask != 0) {
        recordEntryForTree(dm, path, ci);
        if (ci.filemask == 0) return 0;
    }
    if (ci.df_conflict and ci.result.mode == 0) {
        ci.df_conflict = false;
        ci.clean = false;
        ci.is_null = false;
        ci.match_mask = ci.match_mask & ~ci.dirmask;
        ci.dirmask = 0;
        for (0..3) |i| {
            if (ci.filemask & (@as(u8, 1) << @intCast(i)) != 0) continue;
            ci.stages[i] = .{};
        }
    } else if (ci.df_conflict and ci.result.mode != 0) {
        const old_path = path;
        if (ci.filemask == 1) {
            ci.filemask = 0;
            return 0;
        }
        const new_ci = newInfo();
        new_ci.* = ci.*;
        new_ci.match_mask = new_ci.match_mask & ~new_ci.dirmask;
        new_ci.dirmask = 0;
        for (0..3) |i| {
            if (new_ci.filemask & (@as(u8, 1) << @intCast(i)) != 0) continue;
            new_ci.stages[i] = .{};
        }
        df_file_index = if (ci.dirmask & 2 != 0) 2 else 1;
        const branch = if (df_file_index == 1) opt.branch1 else opt.branch2;
        path = uniquePath(opt, path, branch);
        mput(*Info, &priv.paths, path, new_ci);
        pathMsg(opt, .CONFLICT_FILE_DIRECTORY, false, path, old_path, null, null, util.fmt("CONFLICT (file/directory): directory in the way of {s} from {s}; moving it to {s} instead.", .{ old_path, branch, path }));
        ci.filemask = 0;
        ci = new_ci;
    }

    if (ci.match_mask != 0) {
        ci.clean = !ci.df_conflict and !ci.path_conflict;
        if (ci.match_mask == 6) {
            ci.result = ci.stages[1];
        } else {
            const othermask: u8 = 7 & ~ci.match_mask;
            const side: usize = if (othermask == 4) 2 else 1;
            ci.result = ci.stages[side];
            ci.is_null = ci.result.mode == 0;
            if (ci.is_null) ci.clean = true;
        }
    } else if (ci.filemask >= 6 and (S_IFMT & ci.stages[1].mode) != (S_IFMT & ci.stages[2].mode)) {
        if (priv.call_depth != 0) {
            ci.clean = false;
            ci.result = ci.stages[0];
            ci.is_null = ci.result.mode == 0;
        } else {
            const o_mode = ci.stages[0].mode;
            const a_mode = ci.stages[1].mode;
            const b_mode = ci.stages[2].mode;
            var rename_a = false;
            var rename_b = false;
            if (isReg(a_mode)) {
                rename_a = true;
            } else if (isReg(b_mode)) {
                rename_b = true;
            } else {
                rename_a = true;
                rename_b = true;
            }
            var a_path: ?[]const u8 = null;
            var b_path: ?[]const u8 = null;
            if (rename_a) a_path = uniquePath(opt, path, opt.branch1);
            if (rename_b) b_path = uniquePath(opt, path, opt.branch2);
            if (rename_a and rename_b) {
                pathMsg(opt, .CONFLICT_DISTINCT_MODES, false, path, a_path, b_path, null, util.fmt("CONFLICT (distinct types): {s} had different types on each side; renamed both of them so each can be recorded somewhere.", .{path}));
            } else {
                pathMsg(opt, .CONFLICT_DISTINCT_MODES, false, path, if (rename_a) a_path else b_path, null, null, util.fmt("CONFLICT (distinct types): {s} had different types on each side; renamed one of them so each can be recorded somewhere.", .{path}));
            }
            ci.clean = false;
            const new_ci = newInfo();
            new_ci.* = ci.*;
            new_ci.result = ci.stages[2];
            new_ci.stages[1] = .{};
            new_ci.filemask = 5;
            if ((S_IFMT & b_mode) != (S_IFMT & o_mode)) {
                new_ci.stages[0] = .{};
                new_ci.filemask = 4;
            }
            ci.result = ci.stages[1];
            ci.stages[2] = .{};
            ci.filemask = 3;
            if ((S_IFMT & a_mode) != (S_IFMT & o_mode)) {
                ci.stages[0] = .{};
                ci.filemask = 2;
            }
            if (rename_a) mput(*Info, &priv.paths, a_path.?, ci);
            if (!rename_b) b_path = path;
            mput(*Info, &priv.paths, b_path.?, new_ci);
            if (rename_a and rename_b) _ = priv.paths.orderedRemove(path);
            mput(*Info, &priv.conflicted, b_path.?, new_ci);
            recordEntryForTree(dm, b_path.?, new_ci);
            if (a_path) |ap| path = ap;
        }
    } else if (ci.filemask >= 6) {
        var merged_file: VersionInfo = .{};
        const record_object = !opt.mergeability_only or priv.call_depth != 0;
        const clean_merge = handleContentMerge(opt, path, ci.stages[0], ci.stages[1], ci.stages[2], &ci.pathnames, priv.call_depth * 2, record_object, &merged_file);
        if (clean_merge < 0) return -1;
        ci.clean = clean_merge != 0 and !ci.df_conflict and !ci.path_conflict;
        ci.result = merged_file;
        ci.is_null = merged_file.mode == 0;
        if (clean_merge != 0 and ci.df_conflict) {
            ci.filemask = @as(u8, 1) << @intCast(df_file_index);
            ci.stages[df_file_index] = merged_file;
        }
        if (clean_merge == 0) {
            var reason: []const u8 = "content";
            if (ci.filemask == 6) reason = "add/add";
            if (isGitlink(merged_file.mode)) reason = "submodule";
            pathMsg(opt, .CONFLICT_CONTENTS, false, path, null, null, null, util.fmt("CONFLICT ({s}): Merge conflict in {s}", .{ reason, path }));
        }
    } else if (ci.filemask == 3 or ci.filemask == 5) {
        const side: usize = if (ci.filemask == 5) 2 else 1;
        const index: usize = if (priv.call_depth != 0) 0 else side;
        ci.result = ci.stages[index];
        ci.clean = false;
        const modify_branch = if (side == 1) opt.branch1 else opt.branch2;
        const delete_branch = if (side == 1) opt.branch2 else opt.branch1;
        if (opt.renormalize and blobUnchanged(ci.stages[0], ci.stages[side], path)) {
            if (!ci.path_conflict) {
                ci.is_null = true;
                ci.clean = true;
                ci.df_conflict = false;
            }
        } else if (ci.path_conflict and hash.eql(ci.stages[0].oid, ci.stages[side].oid)) {
            // rename/delete already reported
        } else {
            pathMsg(opt, .CONFLICT_MODIFY_DELETE, false, path, null, null, null, util.fmt("CONFLICT (modify/delete): {s} deleted in {s} and modified in {s}.  Version {s} of {s} left in tree.", .{ path, delete_branch, modify_branch, modify_branch, path }));
        }
    } else if (ci.filemask == 2 or ci.filemask == 4) {
        const side: usize = if (ci.filemask == 4) 2 else 1;
        ci.result = ci.stages[side];
        ci.clean = !ci.df_conflict and !ci.path_conflict;
    } else if (ci.filemask == 1) {
        ci.is_null = true;
        ci.result = .{};
        ci.clean = !ci.path_conflict;
    }
    if (!ci.clean) mput(*Info, &priv.conflicted, path, ci);
    recordEntryForTree(dm, path, ci);
    return 0;
}

fn blobUnchanged(base: VersionInfo, side: VersionInfo, path: []const u8) bool {
    _ = path;
    if (base.mode != side.mode) return false;
    if (hash.eql(base.oid, side.oid)) return true;
    // renormalization is not supported; compare raw content
    return std.mem.eql(u8, readBlob(base.oid), readBlob(side.oid));
}

fn processEntries(opt: *Options, result_oid: *Oid) i32 {
    const priv = opt.priv.?;
    if (priv.paths.count() == 0) {
        result_oid.* = empty_tree;
        return 0;
    }
    var plist: std.ArrayList(PEntry) = .empty;
    var it = priv.paths.iterator();
    while (it.next()) |e| appendT(PEntry, &plist, .{ .path = e.key_ptr.*, .info = e.value_ptr.* });
    std.mem.sort(PEntry, plist.items, {}, plistLess);
    var dm = DirMeta{};
    var k: usize = plist.items.len;
    while (k > 0) {
        k -= 1;
        const path = plist.items[k].path;
        const mi = plist.items[k].info;
        writeCompletedDirectory(opt, mi.directory_name, &dm);
        if (mi.clean) {
            recordEntryForTree(&dm, path, mi);
        } else {
            if (processEntry(opt, path, mi, &dm) < 0) return -1;
            if (!mi.clean and opt.mergeability_only and priv.call_depth == 0) return 0;
        }
    }
    if (dm.offsets.items.len != 1 or dm.offsets.items[0].offset != 0)
        util.die("BUG: dir_metadata accounting completely off; shouldn't happen", .{});
    const record_tree = !opt.mergeability_only or priv.call_depth != 0;
    if (record_tree) result_oid.* = writeTreeObj(dm.versions.items);
    return 0;
}

// ---------------------------------------------------------------------------
// Merge drivers: nonrecursive / recursive

fn mergeStart(opt: *Options, result: *Result) void {
    if (result.priv) |p| {
        opt.priv = p;
        result.priv = null;
        clearOrReinit(p, true);
        conflicted_submodules = .empty;
        return;
    }
    const p = gpa.create(Priv) catch oom();
    p.* = .{};
    opt.priv = p;
    conflicted_submodules = .empty;
}

fn moveOptPrivToResult(opt: *Options, result: *Result) void {
    result.priv = opt.priv;
    opt.priv = null;
}

fn mergeOrtNonrecursiveInternal(opt: *Options, merge_base0: Oid, side1: Oid, side2_0: Oid, result: *Result) void {
    var merge_base = merge_base0;
    var side2 = side2_0;
    if (opt.subtree_shift) |shift| {
        side2 = shiftTreeObject(side1, side2, shift);
        merge_base = shiftTreeObject(side1, merge_base, shift);
    }
    if (collectMergeInfo(opt, merge_base, side1, side2) != 0) {
        util.err("collecting merge info failed for trees {s}, {s}, {s}", .{ hash.hexAlloc(merge_base), hash.hexAlloc(side1), hash.hexAlloc(side2) });
        result.clean = -1;
        moveOptPrivToResult(opt, result);
        return;
    }
    result.clean = detectAndProcessRenames(opt);
    var working_tree_oid: Oid = empty_tree;
    if (processEntries(opt, &working_tree_oid) < 0) result.clean = -1;
    if (result.clean >= 0) {
        if (!opt.mergeability_only) result.tree = working_tree_oid;
        if (opt.priv.?.conflicted.count() != 0) result.clean &= 0;
    }
    if (opt.priv.?.call_depth == 0 or result.clean < 0) moveOptPrivToResult(opt, result);
}

var virtual_counter: u32 = 0;

fn makeVirtualCommit(tree: Oid) *cn.Commit {
    virtual_counter += 1;
    var fake: Oid = hash.zero;
    // An oid that cannot collide with a real object in practice.
    fake[0] = 0xff;
    fake[1] = 0xfe;
    std.mem.writeInt(u32, fake[16..20], virtual_counter, .big);
    const o = cn.lookup(fake, .commit) orelse util.die("BUG: virtual commit allocation", .{});
    const c = cn.Commit.fromObj(o);
    c.tree = tree;
    c.obj.parsed = true;
    c.parents = null;
    c.date = 0;
    return c;
}

fn commitTree(c: *cn.Commit) Oid {
    _ = cn.parse(c);
    return c.tree;
}

fn mergeOrtInternal(opt: *Options, merge_bases0: ?*cn.CommitList, h1: *cn.Commit, h2: *cn.Commit, result: *Result) void {
    var merge_bases = cn.listCopy(merge_bases0);
    if (merge_bases == null) {
        merge_bases = cn.listReverse(creach.getMergeBases(h1, h2));
    }
    var merged_merge_bases: *cn.Commit = undefined;
    var ancestor_name: []const u8 = undefined;
    if (cn.popCommit(&merge_bases)) |mb| {
        merged_merge_bases = mb;
        if (merge_bases != null) {
            ancestor_name = "merged common ancestors";
        } else if (opt.ancestor) |a| {
            ancestor_name = a;
        } else {
            ancestor_name = revparse.abbrev(mb.obj.oid, revparse.defaultAbbrev());
        }
    } else {
        merged_merge_bases = makeVirtualCommit(empty_tree);
        ancestor_name = "empty tree";
    }
    while (cn.popCommit(&merge_bases)) |next| {
        const prev = merged_merge_bases;
        opt.priv.?.call_depth += 1;
        const saved_b1 = opt.branch1;
        const saved_b2 = opt.branch2;
        opt.branch1 = "Temporary merge branch 1";
        opt.branch2 = "Temporary merge branch 2";
        mergeOrtInternal(opt, null, prev, next, result);
        if (result.clean < 0) return;
        opt.branch1 = saved_b1;
        opt.branch2 = saved_b2;
        opt.priv.?.call_depth -= 1;
        merged_merge_bases = makeVirtualCommit(result.tree);
        _ = cn.listInsert(prev, &merged_merge_bases.parents);
        _ = cn.listInsert(next, &merged_merge_bases.parents.?.next);
        clearOrReinit(opt.priv.?, true);
    }
    opt.ancestor = ancestor_name;
    mergeOrtNonrecursiveInternal(opt, commitTree(merged_merge_bases), commitTree(h1), commitTree(h2), result);
    opt.ancestor = null;
}

pub fn mergeIncoreNonrecursive(opt: *Options, merge_base: Oid, side1: Oid, side2: Oid, result: *Result) void {
    mergeStart(opt, result);
    mergeOrtNonrecursiveInternal(opt, merge_base, side1, side2, result);
}

pub fn mergeIncoreRecursive(opt: *Options, merge_bases: ?*cn.CommitList, side1: *cn.Commit, side2: *cn.Commit, result: *Result) void {
    mergeStart(opt, result);
    mergeOrtInternal(opt, merge_bases, side1, side2, result);
}

// ---------------------------------------------------------------------------
// subtree shifting (match-trees.c, simplified)

fn shiftTreeObject(one: Oid, two: Oid, shift: []const u8) Oid {
    const shifted = if (shift.len == 0) shiftTree(one, two) else shiftTreeBy(one, two, shift);
    return shifted;
}

/// shift_tree_by: one has `prefix` as a subdirectory containing two's content
/// or vice versa.
fn shiftTreeBy(one: Oid, two: Oid, prefix0: []const u8) Oid {
    var prefix = prefix0;
    while (prefix.len > 0 and prefix[prefix.len - 1] == '/') prefix = prefix[0 .. prefix.len - 1];
    const one_has = objects.treeLookup(one, prefix);
    const two_has = objects.treeLookup(two, prefix);
    const one_is = one_has != null and isDirMode(one_has.?.mode);
    const two_is = two_has != null and isDirMode(two_has.?.mode);
    if (one_is and !two_is) {
        // two is a subtree of one: put two at prefix within one
        return spliceTree(one, prefix, two);
    } else if (!one_is and two_is) {
        return two_has.?.oid;
    }
    return two;
}

fn spliceTree(base: Oid, prefix: []const u8, sub: Oid) Oid {
    const slash = std.mem.indexOfScalar(u8, prefix, '/');
    const first = if (slash) |s| prefix[0..s] else prefix;
    const ents = objects.readTree(base) orelse return base;
    var out: std.ArrayList(objects.TreeEntry) = .empty;
    for (ents) |e| {
        if (util.eql(e.name, first)) {
            var ne = e;
            ne.oid = if (slash) |s| spliceTree(e.oid, prefix[s + 1 ..], sub) else sub;
            appendT(objects.TreeEntry, &out, ne);
        } else appendT(objects.TreeEntry, &out, e);
    }
    return objects.writeTree(out.items);
}

fn scoreTrees(a: Oid, b: Oid) i32 {
    // score_trees(): count matching entries
    const ea = objects.readTree(a) orelse return 0;
    const eb = objects.readTree(b) orelse return 0;
    var score: i32 = 0;
    var i: usize = 0;
    var j: usize = 0;
    while (i < ea.len or j < eb.len) {
        if (i < ea.len and j < eb.len) {
            const c = objects.baseNameCompare(ea[i].name, ea[i].mode, eb[j].name, eb[j].mode);
            if (c == .lt) {
                score -= if (isDirMode(ea[i].mode)) 1 else 1;
                i += 1;
                continue;
            } else if (c == .gt) {
                score -= 1;
                j += 1;
                continue;
            }
            if (ea[i].mode == eb[j].mode) {
                score += if (hash.eql(ea[i].oid, eb[j].oid)) (if (isDirMode(ea[i].mode)) @as(i32, 1000) else 1000) else (if (isDirMode(ea[i].mode)) scoreTrees(ea[i].oid, eb[j].oid) else 500);
            } else {
                score += if (isDirMode(ea[i].mode) != isDirMode(eb[j].mode)) -100 else 100;
            }
            i += 1;
            j += 1;
        } else if (i < ea.len) {
            score -= 1;
            i += 1;
        } else {
            score -= 1;
            j += 1;
        }
    }
    return score;
}

fn matchTrees(hash1: Oid, hash2: Oid, best_score: *i32, best_match: *?[]const u8, base: []const u8, recurse_limit: i32) void {
    const ents = objects.readTree(hash2) orelse return;
    for (ents) |e| {
        if (!isDirMode(e.mode)) continue;
        const score = scoreTrees(e.oid, hash1);
        const path = if (base.len == 0) util.dupe(e.name) else util.concat(&.{ base, "/", e.name });
        if (best_score.* < score) {
            best_score.* = score;
            best_match.* = path;
        }
        if (recurse_limit > 0) matchTrees(hash1, e.oid, best_score, best_match, path, recurse_limit - 1);
    }
}

/// shift_tree(): guess how to shift `two` to match `one`.
fn shiftTree(one: Oid, two: Oid) Oid {
    var add_score = scoreTrees(one, two);
    var add_prefix: ?[]const u8 = null;
    matchTrees(one, two, &add_score, &add_prefix, "", 2);
    var del_score = scoreTrees(one, two);
    var del_prefix: ?[]const u8 = null;
    matchTrees(two, one, &del_score, &del_prefix, "", 2);
    if (add_score < del_score) {
        // two is a subtree of one: shift two down into del_prefix
        if (del_prefix) |p| return spliceTree(one, p, two);
        return two;
    }
    if (add_prefix) |p| {
        if (objects.treeLookup(two, p)) |e| return e.oid;
    }
    return two;
}

// ---------------------------------------------------------------------------
// Switch to result / display

fn checkout(opt: *Options, prev: Oid, next: Oid) bool {
    const idx = index_mod.get();
    var o = ut.Options{};
    o.head_idx = 0;
    o.src_index = idx;
    o.dst_index = idx;
    ut.setupPorcelain(&o, "merge");
    o.update = true;
    o.merge = true;
    o.quiet = false;
    o.verbose_update = opt.verbosity > 2;
    o.func = &ut.twowayMerge;
    o.preserve_ignored = false;
    return ut.unpackTrees(&.{ prev, next }, &o) != 0;
}

fn recordConflictedIndexEntries(opt: *Options) void {
    const priv = opt.priv.?;
    if (priv.conflicted.count() == 0) return;
    const idx = index_mod.get();
    var keep: std.ArrayList(index_mod.Entry) = .empty;
    for (idx.entries.items) |e| {
        if (e.stage() == 0) {
            if (priv.conflicted.contains(e.path)) continue;
        }
        appendT(index_mod.Entry, &keep, e);
    }
    var it = priv.conflicted.iterator();
    while (it.next()) |e| {
        const path = e.key_ptr.*;
        const ci = e.value_ptr.*;
        idx.invalidatePath(path);
        for (0..3) |i| {
            if (ci.filemask & (@as(u8, 1) << @intCast(i)) == 0) continue;
            var ne = index_mod.Entry{ .path = path, .mode = ci.stages[i].mode, .oid = ci.stages[i].oid };
            ne.setStage(@intCast(i + 1));
            appendT(index_mod.Entry, &keep, ne);
        }
    }
    std.mem.sort(index_mod.Entry, keep.items, {}, index_mod.entryLess);
    idx.entries = keep;
    idx.changed = true;
}

fn printSubmoduleConflictSuggestion() void {
    if (conflicted_submodules.items.len == 0) return;
    var subs: util.Buf = .empty;
    var tmp: util.Buf = .empty;
    for (conflicted_submodules.items, 0..) |item, i| {
        if (i > 0) util.bufByte(&subs, ' ');
        util.bufAppend(&subs, item.path);
        if (item.flag == .CONFLICT_SUBMODULE_NOT_INITIALIZED or item.flag == .CONFLICT_SUBMODULE_HISTORY_NOT_AVAILABLE) continue;
        util.bufPrint(&tmp, " - go to submodule ({s}), and either merge commit {s}\n   or update to an existing commit which has merged those changes\n", .{ item.path, item.abbrev orelse "" });
    }
    const msg = util.fmt("Recursive merging with submodules currently only supports trivial cases.\nPlease manually handle the merging of each conflicted submodule.\nThis can be accomplished with the following steps:\n{s} - come back to superproject and run:\n\n      git add {s}\n\n   to record the above merge or update\n - resolve any other conflicts in the superproject\n - commit the resulting index in the superproject", .{ tmp.items, subs.items });
    @import("advice.zig").adviseIfEnabled("submoduleMergeConflict", msg);
}

fn keyLess(_: void, a: []const u8, b: []const u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

pub fn displayUpdateMessages(opt: *Options, detailed: bool, result: *Result) void {
    _ = opt;
    const priv = result.priv orelse return;
    const keys = gpa.dupe([]const u8, priv.conflicts.keys()) catch oom();
    std.mem.sort([]const u8, keys, {}, keyLess);
    var b: util.Buf = .empty;
    for (keys) |k| {
        const list = priv.conflicts.get(k).?;
        for (list.items) |m| {
            if (result.clean < 0 and @intFromEnum(m.typ) < @intFromEnum(Ct.NB_REGULAR_CONFLICT_TYPES)) continue;
            if (detailed) {
                util.bufPrint(&b, "{d}\x00", .{m.paths.len});
                for (m.paths) |p| {
                    util.bufAppend(&b, p);
                    util.bufByte(&b, 0);
                }
                util.bufAppend(&b, shortDesc(m.typ));
                util.bufByte(&b, 0);
            }
            util.bufAppend(&b, m.text);
            util.bufByte(&b, '\n');
            if (detailed) util.bufByte(&b, 0);
        }
    }
    if (result.clean < 0) {
        util.flushStdout();
        util.ewrite(b.items);
    } else util.out(b.items);
    if (result.clean >= 0) {
        util.flushStdout();
        printSubmoduleConflictSuggestion();
    }
    warnRenameLimit("merge.renamelimit", priv.needed_limit);
}

pub fn warnRenameLimit(varname: []const u8, needed: i32) void {
    util.flushStdout();
    if (needed == 0) return;
    util.warn("exhaustive rename detection was skipped due to too many files.", .{});
    if (needed > 0) util.warn("you may want to set your {s} variable to at least {d} and retry the command.", .{ varname, needed });
}

pub const StageInfo = struct { path: []const u8, stage: u32, mode: u32, oid: Oid };

fn stageLess(_: void, a: StageInfo, b: StageInfo) bool {
    return std.mem.order(u8, a.path, b.path) == .lt;
}

pub fn getConflictedFiles(result: *Result) []StageInfo {
    var out: std.ArrayList(StageInfo) = .empty;
    const priv = result.priv orelse return out.items;
    var it = priv.conflicted.iterator();
    while (it.next()) |e| {
        const ci = e.value_ptr.*;
        for (0..3) |i| {
            if (ci.filemask & (@as(u8, 1) << @intCast(i)) == 0) continue;
            appendT(StageInfo, &out, .{ .path = e.key_ptr.*, .stage = @intCast(i + 1), .mode = ci.stages[i].mode, .oid = ci.stages[i].oid });
        }
    }
    std.mem.sort(StageInfo, out.items, {}, stageLess);
    return out.items;
}

/// Sorted list of conflicted paths (unique).
pub fn conflictedPaths(result: *Result) []const []const u8 {
    const priv = result.priv orelse return &.{};
    const keys = gpa.dupe([]const u8, priv.conflicted.keys()) catch oom();
    std.mem.sort([]const u8, keys, {}, keyLess);
    return keys;
}

pub fn mergeSwitchToResult(opt: *Options, head: Oid, result: *Result, update_worktree_and_index: bool, display_update_msgs: bool) void {
    if (result.clean >= 0 and update_worktree_and_index) {
        if (checkout(opt, head, result.tree)) {
            result.clean = -1;
            return;
        }
        opt.priv = result.priv;
        recordConflictedIndexEntries(opt);
        opt.priv = null;
        refs.update("AUTO_MERGE", result.tree, null, "", true) catch {
            result.clean = -1;
            return;
        };
    }
    if (display_update_msgs) displayUpdateMessages(opt, false, result);
}

// ---------------------------------------------------------------------------
// merge-ort-wrappers

/// repo_index_has_changes(): paths whose index entry differs from `tree`.
pub fn indexChangesAgainst(tree: Oid) []const u8 {
    const idx = index_mod.get();
    var flat: std.ArrayList(objects.FlatEntry) = .empty;
    objects.flattenTree(tree, "", &flat);
    var m: StrMap(objects.FlatEntry) = .empty;
    for (flat.items) |f| mput(objects.FlatEntry, &m, f.path, f);
    var changed: std.ArrayList([]const u8) = .empty;
    var seen: StrMap(void) = .empty;
    for (idx.entries.items) |e| {
        if (seen.contains(e.path)) continue;
        mput(void, &seen, e.path, {});
        const t = m.get(e.path);
        if (e.stage() != 0 or t == null or t.?.mode != e.mode or !hash.eql(t.?.oid, e.oid))
            appendT([]const u8, &changed, e.path);
    }
    for (flat.items) |f| {
        if (!seen.contains(f.path)) appendT([]const u8, &changed, f.path);
    }
    std.mem.sort([]const u8, changed.items, {}, keyLess);
    return joinList(changed.items, " ");
}

fn unclean(head: ?Oid) bool {
    const h = head orelse return false;
    const ch = indexChangesAgainst(h);
    if (ch.len > 0) {
        util.err("Your local changes to the following files would be overwritten by merge:\n  {s}", .{ch});
        return true;
    }
    return false;
}

pub fn mergeOrtNonrecursive(opt: *Options, head: Oid, merge: Oid, merge_base: Oid) i32 {
    if (unclean(head)) return -1;
    if (hash.eql(merge_base, merge)) {
        util.out("Already up to date.\n");
        return 1;
    }
    const show_msgs = opt.verbosity != 0;
    var result = Result{};
    mergeIncoreNonrecursive(opt, merge_base, head, merge, &result);
    mergeSwitchToResult(opt, head, &result, true, show_msgs);
    return result.clean;
}

pub fn mergeOrtRecursive(opt: *Options, side1: *cn.Commit, side2: *cn.Commit, merge_bases: ?*cn.CommitList) i32 {
    const head = commitTree(side1);
    if (unclean(head)) return -1;
    const show_msgs = opt.verbosity != 0;
    var tmp = Result{};
    mergeIncoreRecursive(opt, merge_bases, side1, side2, &tmp);
    mergeSwitchToResult(opt, head, &tmp, true, show_msgs);
    return tmp.clean;
}

// ---------------------------------------------------------------------------
// Options / config

pub fn parseAlgorithmValue(v: []const u8) ?xdiff.Algorithm {
    if (std.ascii.eqlIgnoreCase(v, "myers") or std.ascii.eqlIgnoreCase(v, "default")) return .myers;
    if (std.ascii.eqlIgnoreCase(v, "minimal")) return .minimal;
    if (std.ascii.eqlIgnoreCase(v, "patience")) return .patience;
    if (std.ascii.eqlIgnoreCase(v, "histogram")) return .histogram;
    return null;
}

fn cfgInt(key: []const u8) ?i32 {
    const v = repo_mod.cfg.getInt(key) orelse return null;
    return @intCast(std.math.clamp(v, std.math.minInt(i32), std.math.maxInt(i32)));
}

fn configRename(k: []const u8, v: ?[]const u8) i32 {
    const val = v orelse return 1;
    if (std.ascii.eqlIgnoreCase(val, "copies") or std.ascii.eqlIgnoreCase(val, "copy")) return 2;
    return if (config.configBool(k, val)) 1 else 0;
}

/// init_merge_options() + merge_recursive_config()
pub fn initMergeOptions(ui: bool) Options {
    var opt = Options{};
    const cfg = &repo_mod.cfg;
    if (cfgInt("merge.verbosity")) |v| opt.verbosity = v;
    if (cfgInt("diff.renamelimit")) |v| opt.rename_limit = v;
    if (cfgInt("merge.renamelimit")) |v| opt.rename_limit = v;
    if (cfg.getBool("merge.renormalize")) |b| opt.renormalize = b;
    if (cfg.getEntry("diff.renames")) |e| opt.detect_renames = configRename("diff.renames", e.value);
    if (cfg.getEntry("merge.renames")) |e| opt.detect_renames = configRename("merge.renames", e.value);
    if (cfg.getEntry("merge.directoryrenames")) |e| {
        const bv = config.parseMaybeBool(e.value);
        if (bv >= 0) {
            opt.detect_directory_renames = if (bv != 0) .true_ else .none;
        } else if (e.value != null and std.ascii.eqlIgnoreCase(e.value.?, "conflict")) {
            opt.detect_directory_renames = .conflict;
        }
    }
    if (ui) {
        if (cfg.get("diff.algorithm")) |v| {
            opt.xdl_flags.algorithm = parseAlgorithmValue(v) orelse util.die("unknown value for config '{s}': {s}", .{ "diff.algorithm", v });
        }
    }
    loadXmergeConfig();
    if (os.getenv("GIT_MERGE_VERBOSITY")) |v| {
        opt.verbosity = @intCast(std.fmt.parseInt(i64, v, 10) catch 0);
    }
    return opt;
}

/// parse_merge_opt(); returns false on error.
pub fn parseMergeOpt(opt: *Options, s: []const u8) bool {
    if (s.len == 0) return false;
    if (util.eql(s, "ours")) {
        opt.recursive_variant = .ours;
    } else if (util.eql(s, "theirs")) {
        opt.recursive_variant = .theirs;
    } else if (util.eql(s, "subtree")) {
        opt.subtree_shift = "";
    } else if (util.skipPrefix(s, "subtree=")) |a| {
        opt.subtree_shift = a;
    } else if (util.eql(s, "patience")) {
        opt.xdl_flags.algorithm = .patience;
    } else if (util.eql(s, "histogram")) {
        opt.xdl_flags.algorithm = .histogram;
    } else if (util.skipPrefix(s, "diff-algorithm=")) |a| {
        opt.xdl_flags.algorithm = parseAlgorithmValue(a) orelse return false;
    } else if (util.eql(s, "ignore-space-change")) {
        opt.xdl_flags.ignore_ws_change = true;
    } else if (util.eql(s, "ignore-all-space")) {
        opt.xdl_flags.ignore_ws = true;
    } else if (util.eql(s, "ignore-space-at-eol")) {
        opt.xdl_flags.ignore_ws_eol = true;
    } else if (util.eql(s, "ignore-cr-at-eol")) {
        opt.xdl_flags.ignore_cr_eol = true;
    } else if (util.eql(s, "renormalize")) {
        opt.renormalize = true;
    } else if (util.eql(s, "no-renormalize")) {
        opt.renormalize = false;
    } else if (util.eql(s, "no-renames")) {
        opt.detect_renames = 0;
    } else if (util.eql(s, "find-renames")) {
        opt.detect_renames = 1;
        opt.rename_score = 0;
    } else if (util.skipPrefix(s, "find-renames=") orelse util.skipPrefix(s, "rename-threshold=")) |a| {
        var rest: []const u8 = "";
        opt.rename_score = @intCast(@import("diff.zig").parseRenameScore(a, &rest));
        if (rest.len != 0) return false;
        opt.detect_renames = 1;
    } else return false;
    return true;
}
