//! git stash (builtin/stash.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const objects = @import("../objects.zig");
const commit_mod = @import("../commit.zig");
const pretty = @import("../pretty.zig");
const dir_mod = @import("../dir.zig");
const pathspec_mod = @import("../pathspec.zig");
const entry = @import("../entry.zig");
const ut = @import("../unpacktrees.zig");
const xdiff = @import("../xdiff.zig");
const merge_ort = @import("../merge_ort.zig");
const proc = @import("../proc.zig");
const add_patch = @import("../add_patch.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Index = index_mod.Index;
const Entry = index_mod.Entry;
const Pathspec = pathspec_mod.Pathspec;
const FlatEntry = objects.FlatEntry;
const FlatMap = std.StringHashMapUnmanaged(FlatEntry);

const list_usage_str = "git stash list [<log-options>]";
const show_usage_str = "git stash show [-u | --include-untracked | --only-untracked] [<diff-options>] [<stash>]";
const drop_usage_str = "git stash drop [-q | --quiet] [<stash>]";
const pop_usage_str = "git stash pop [--index] [-q | --quiet] [<stash>]";
const apply_usage_str = "git stash apply [--index] [-q | --quiet] [--label-ours=<label>] [--label-theirs=<label>] [--label-base=<label>] [<stash>]";
const branch_usage_str = "git stash branch <branchname> [<stash>]";
const store_usage_str = "git stash store [(-m | --message) <message>] [-q | --quiet] <commit>";
const push_usage_str = "git stash [push] [-p | --patch] [-S | --staged] [-k | --[no-]keep-index] [-q | --quiet]\n" ++
    "          [-u | --include-untracked] [-a | --all] [(-m | --message) <message>]\n" ++
    "          [--pathspec-from-file=<file> [--pathspec-file-nul]]\n" ++
    "          [--] [<pathspec>...]";
const save_usage_str = "git stash save [-p | --patch] [-S | --staged] [-k | --[no-]keep-index] [-q | --quiet]\n" ++
    "          [-u | --include-untracked] [-a | --all] [<message>]";
const create_usage_str = "git stash create [<message>]";
const export_usage_str = "git stash export (--print | --to-ref <ref>) [<stash>...]";
const import_usage_str = "git stash import <commit>";
const clear_usage_str = "git stash clear";

const stash_usage = [_][]const u8{
    list_usage_str,  show_usage_str,  drop_usage_str,   pop_usage_str,
    apply_usage_str, branch_usage_str, push_usage_str,  save_usage_str,
    clear_usage_str, create_usage_str, store_usage_str, export_usage_str,
    import_usage_str,
};

const ref_stash = "refs/stash";
const INCLUDE_ALL_FILES: i32 = 2;

var stash_index_path: []const u8 = "";
var show_stat = true;
var show_patch = false;
var show_include_untracked = false;
var use_index = false;

extern "c" fn getpid() c_int;

fn readConfig() void {
    const c = &repo_mod.cfg;
    if (c.getBool("stash.showstat")) |b| show_stat = b;
    if (c.getBool("stash.showpatch")) |b| show_patch = b;
    if (c.getBool("stash.showincludeuntracked")) |b| show_include_untracked = b;
    if (c.getBool("stash.index")) |b| use_index = b;
}

// ---------------- helpers ----------------

fn gitBin() []const u8 {
    return proc.gitBinary();
}

const RunOpts = struct {
    env: []const [2][]const u8 = &.{},
    stdin_data: ?[]const u8 = null,
    capture: bool = false,
    cwd: ?[]const u8 = null,
};

fn runGit(args: []const []const u8, o: RunOpts) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, gitBin()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return os.run(argv.items, .{ .env = o.env, .stdin_data = o.stdin_data, .capture_stdout = o.capture, .cwd = o.cwd });
}

fn flatten(tree: Oid) FlatMap {
    var list: std.ArrayList(FlatEntry) = .empty;
    objects.flattenTree(tree, "", &list);
    var m: FlatMap = .empty;
    for (list.items) |e| m.put(gpa, e.path, e) catch util.oom();
    return m;
}

fn sameFlat(a: ?FlatEntry, b: ?FlatEntry) bool {
    if (a == null and b == null) return true;
    if (a == null or b == null) return false;
    return a.?.mode == b.?.mode and hash.eql(a.?.oid, b.?.oid);
}

fn unionPaths(maps: []const *const FlatMap) [][]const u8 {
    var seen: std.StringHashMapUnmanaged(void) = .empty;
    var out: std.ArrayList([]const u8) = .empty;
    for (maps) |m| {
        var it = m.keyIterator();
        while (it.next()) |k| {
            const gop = seen.getOrPut(gpa, k.*) catch util.oom();
            if (!gop.found_existing) out.append(gpa, k.*) catch util.oom();
        }
    }
    util.sortStrings(out.items);
    return out.items;
}

fn commitTree(c: Oid) Oid {
    const cm = objects.readCommit(c) orelse util.die("could not parse commit {s}", .{&hash.hex(c)});
    return cm.tree;
}

fn emptyTreeOid() Oid {
    return hash.fromHex(hash.empty_tree_hex).?;
}

fn readBlobOrEmpty(o: ?FlatEntry) []const u8 {
    const e = o orelse return "";
    return entry.readBlob(e.oid) orelse "";
}

fn isBinary(data: []const u8) bool {
    const n = @min(data.len, 8000);
    return std.mem.indexOfScalar(u8, data[0..n], 0) != null;
}

fn writeBlob(data: []const u8) Oid {
    return repo_mod.repo().odb().write(.blob, data);
}

/// Write a file in the worktree from a (mode, oid) pair.
fn checkoutBlob(path: []const u8, mode: u32, oid: Oid) bool {
    var e = Entry{ .path = path, .mode = mode, .oid = oid };
    var st = entry.State{ .force = true, .quiet = true };
    return !entry.checkoutEntry(&e, &st, null);
}

fn treeFromEntries(entries: []const FlatEntry) ?Oid {
    var tmp = Index{};
    for (entries) |e| tmp.entries.append(gpa, .{ .path = e.path, .mode = e.mode, .oid = e.oid }) catch util.oom();
    std.mem.sort(Entry, tmp.entries.items, {}, index_mod.entryLess);
    return tmp.writeTree(false);
}

fn refreshAndWriteIndex() bool {
    const idx = index_mod.lockAndRead();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const Pathspec, null), null);
    if (idx.changed) idx.write() else idx.rollback();
    return true;
}

fn mergeStyle() xdiff.MergeStyle {
    if (repo_mod.cfg.get("merge.conflictstyle")) |v| {
        if (util.eql(v, "diff3")) return .diff3;
        if (util.eql(v, "zdiff3")) return .zdiff3;
    }
    return .merge;
}

fn psMatches(ps: *const Pathspec, path: []const u8) bool {
    if (ps.isEmpty()) return true;
    return ps.matches(path, false);
}

// ---------------- stash info ----------------

const StashInfo = struct {
    w_commit: Oid = hash.zero,
    b_commit: Oid = hash.zero,
    i_commit: Oid = hash.zero,
    u_commit: Oid = hash.zero,
    w_tree: Oid = hash.zero,
    b_tree: Oid = hash.zero,
    i_tree: Oid = hash.zero,
    u_tree: Oid = hash.zero,
    revision: []const u8 = "",
    is_stash_ref: bool = false,
    has_u: bool = false,
};

fn getOidf(comptime f: []const u8, args: anytype) ?Oid {
    return revparse.getOid(util.fmt(f, args));
}

fn assertStashLike(info: *StashInfo, rev: []const u8) void {
    info.b_commit = getOidf("{s}^1", .{rev}) orelse util.die("'{s}' is not a stash-like commit", .{rev});
    info.w_tree = getOidf("{s}:", .{rev}) orelse util.die("'{s}' is not a stash-like commit", .{rev});
    info.b_tree = getOidf("{s}^1:", .{rev}) orelse util.die("'{s}' is not a stash-like commit", .{rev});
    info.i_tree = getOidf("{s}^2:", .{rev}) orelse util.die("'{s}' is not a stash-like commit", .{rev});
}

fn allDigits(s: []const u8) bool {
    for (s) |ch| if (!std.ascii.isDigit(ch)) return false;
    return true;
}

fn parseStashRevision(commit: ?[]const u8, quiet: bool) ?[]const u8 {
    const c = commit orelse {
        if (!refs.exists(ref_stash)) {
            if (!quiet) util.eprint("No stash entries found.\n", .{});
            return null;
        }
        return ref_stash ++ "@{0}";
    };
    if (allDigits(c)) return util.fmt("{s}@{{{s}}}", .{ ref_stash, c });
    return c;
}

fn getStashInfo(info: *StashInfo, argv: []const []const u8) i32 {
    if (argv.len > 1) {
        var b: util.Buf = .empty;
        for (argv) |a| util.bufPrint(&b, " '{s}'", .{a});
        util.eprint("Too many revisions specified:{s}\n", .{b.items});
        return -1;
    }
    const commit: ?[]const u8 = if (argv.len == 1) argv[0] else null;
    const rev = parseStashRevision(commit, false) orelse return -1;
    info.revision = rev;
    info.w_commit = revparse.getOid(rev) orelse {
        util.err("{s} is not a valid reference", .{rev});
        return -1;
    };
    assertStashLike(info, rev);
    if (getOidf("{s}^3:", .{rev})) |u| {
        info.has_u = true;
        info.u_tree = u;
    }
    const end = std.mem.indexOfScalar(u8, rev, '@') orelse rev.len;
    const symbolic = rev[0..end];
    if (refs.dwimRef(symbolic)) |d| {
        if (d.count > 1) return 1;
        info.is_stash_ref = util.eql(d.name, ref_stash);
    } else {
        info.is_stash_ref = false;
    }
    return 0;
}

fn getStashInfoAssert(info: *StashInfo, argv: []const []const u8) i32 {
    const ret = getStashInfo(info, argv);
    if (ret < 0) return ret;
    if (!info.is_stash_ref) {
        util.err("'{s}' is not a stash reference", .{info.revision});
        return -1;
    }
    return 0;
}

// ---------------- clear / drop ----------------

fn doClearStash() i32 {
    const obj = revparse.getOid(ref_stash) orelse return 0;
    refs.deleteRef(ref_stash, obj, 0, null) catch return -1;
    return 0;
}

fn cmdClear(argv: []const []const u8) i32 {
    const usage = [_][]const u8{clear_usage_str};
    const rest = po.parse(argv, &.{}, &usage, .{ .stop_at_non_option = true });
    if (rest.len > 0) {
        util.err("git stash clear with arguments is unimplemented", .{});
        return -1;
    }
    return doClearStash();
}

/// reflog_delete(rev, EXPIRE_REFLOGS_REWRITE | EXPIRE_REFLOGS_UPDATE_REF)
fn reflogDelete(rev: []const u8) bool {
    const at = std.mem.indexOf(u8, rev, "@{") orelse return false;
    if (rev.len < at + 3 or rev[rev.len - 1] != '}') return false;
    const n = std.fmt.parseInt(usize, rev[at + 2 .. rev.len - 1], 10) catch return false;
    const d = refs.dwimRef(rev[0..at]) orelse return false;
    const full = d.name;
    if (!refs.reflogExists(full)) return false;
    const ents = refs.readReflog(full);
    if (n >= ents.len) return false;
    const del = ents.len - 1 - n;
    var kept: std.ArrayList(refs.ReflogEntry) = .empty;
    var last_kept: Oid = hash.zero;
    for (ents, 0..) |e, i| {
        if (i == del) continue;
        var ne = e;
        ne.old = last_kept;
        kept.append(gpa, ne) catch util.oom();
        last_kept = e.new;
    }
    if (!hash.isZero(last_kept)) refs.writeRef(full, last_kept) catch {};
    refs.writeReflog(full, kept.items);
    return true;
}

fn reflogIsEmpty(name: []const u8) bool {
    return refs.readReflog(name).len == 0;
}

fn doDropStash(info: *StashInfo, quiet: bool) i32 {
    if (reflogDelete(info.revision)) {
        if (!quiet) util.outf("Dropped {s} ({s})\n", .{ info.revision, hash.hex(info.w_commit) });
    } else {
        util.err("{s}: Could not drop stash entry", .{info.revision});
        return -1;
    }
    if (reflogIsEmpty(ref_stash)) _ = doClearStash();
    return 0;
}

fn cmdDrop(argv: []const []const u8) i32 {
    const usage = [_][]const u8{drop_usage_str};
    var quiet = false;
    const opts = [_]po.Opt{po.boolean('q', "quiet", &quiet, "be quiet, only report errors")};
    const rest = po.parse(argv, &opts, &usage, .{});
    var info = StashInfo{};
    if (getStashInfoAssert(&info, rest) != 0) return -1;
    return doDropStash(&info, quiet);
}

// ---------------- apply ----------------

const Conflict = struct {
    path: []const u8,
    stages: [3]?FlatEntry,
};

const MergeOut = struct {
    clean: bool,
    tree: Oid,
    conflicts: []Conflict,
    msgs: []const u8,
};

const Labels = struct {
    ours: []const u8,
    theirs: []const u8,
    base: []const u8,
};

/// A simple path-based (no rename detection) three-way tree merge in the
/// spirit of merge_incore_nonrecursive().
fn mergeTrees(base: Oid, ours: Oid, theirs: Oid, labels: Labels) MergeOut {
    const bm = flatten(base);
    const om = flatten(ours);
    const tm = flatten(theirs);
    var result: std.ArrayList(FlatEntry) = .empty;
    var conflicts: std.ArrayList(Conflict) = .empty;
    var msgs: util.Buf = .empty;
    var clean = true;
    for (unionPaths(&.{ &bm, &om, &tm })) |p| {
        const b = bm.get(p);
        const o = om.get(p);
        const t = tm.get(p);
        if (sameFlat(o, t)) {
            if (o) |x| result.append(gpa, x) catch util.oom();
            continue;
        }
        if (sameFlat(b, o)) {
            if (t) |x| result.append(gpa, x) catch util.oom();
            continue;
        }
        if (sameFlat(b, t)) {
            if (o) |x| result.append(gpa, x) catch util.oom();
            continue;
        }
        if (o != null and t != null) {
            const ov = o.?;
            const tv = t.?;
            var mode = ov.mode;
            var mode_clean = true;
            if (ov.mode != tv.mode) {
                if (b != null and b.?.mode == ov.mode) {
                    mode = tv.mode;
                } else if (b != null and b.?.mode == tv.mode) {
                    mode = ov.mode;
                } else mode_clean = false;
            }
            var merged_oid = ov.oid;
            var content_clean = true;
            if (hash.eql(ov.oid, tv.oid)) {
                merged_oid = ov.oid;
            } else if (b != null and hash.eql(b.?.oid, ov.oid)) {
                merged_oid = tv.oid;
            } else if (b != null and hash.eql(b.?.oid, tv.oid)) {
                merged_oid = ov.oid;
            } else if ((ov.mode & 0o170000) == 0o100000 and (tv.mode & 0o170000) == 0o100000) {
                const bd = readBlobOrEmpty(b);
                const od = readBlobOrEmpty(o);
                const td = readBlobOrEmpty(t);
                if (isBinary(bd) or isBinary(od) or isBinary(td)) {
                    util.bufPrint(&msgs, "warning: Cannot merge binary files: {s} ({s} vs. {s})\n", .{ p, labels.ours, labels.theirs });
                    content_clean = false;
                    merged_oid = ov.oid;
                } else {
                    var mo = xdiff.MergeOpts{};
                    mo.level = .zealous;
                    mo.style = mergeStyle();
                    mo.ancestor_name = labels.base;
                    mo.ours_name = labels.ours;
                    mo.theirs_name = labels.theirs;
                    const r = xdiff.merge(bd, od, td, mo) catch util.die("failed to execute internal merge", .{});
                    merged_oid = writeBlob(r.result);
                    content_clean = r.conflicts == 0;
                }
                util.bufPrint(&msgs, "Auto-merging {s}\n", .{p});
            } else {
                // symlinks / submodules: keep ours, conflict
                content_clean = false;
                merged_oid = ov.oid;
                util.bufPrint(&msgs, "Auto-merging {s}\n", .{p});
            }
            result.append(gpa, .{ .path = p, .mode = mode, .oid = merged_oid }) catch util.oom();
            if (!content_clean or !mode_clean) {
                clean = false;
                const reason = if (b == null) "add/add" else "content";
                if (!content_clean) util.bufPrint(&msgs, "CONFLICT ({s}): Merge conflict in {s}\n", .{ reason, p });
                conflicts.append(gpa, .{ .path = p, .stages = .{ b, o, t } }) catch util.oom();
            }
            continue;
        }
        // modify/delete
        clean = false;
        const side_ours = o != null;
        const kept = if (side_ours) o.? else t.?;
        result.append(gpa, kept) catch util.oom();
        const modify_branch = if (side_ours) labels.ours else labels.theirs;
        const delete_branch = if (side_ours) labels.theirs else labels.ours;
        util.bufPrint(&msgs, "CONFLICT (modify/delete): {s} deleted in {s} and modified in {s}.  Version {s} of {s} left in tree.\n", .{ p, delete_branch, modify_branch, modify_branch, p });
        conflicts.append(gpa, .{ .path = p, .stages = .{ b, o, t } }) catch util.oom();
    }
    const tree = treeFromEntries(result.items) orelse util.die("failed to write merged tree", .{});
    return .{ .clean = clean, .tree = tree, .conflicts = conflicts.items, .msgs = msgs.items };
}

/// Paths where the index differs from `tree` (repo_index_has_changes).
fn indexChangesAgainst(idx: *Index, tree: Oid) []const u8 {
    const m = flatten(tree);
    var b: util.Buf = .empty;
    var seen: std.StringHashMapUnmanaged(void) = .empty;
    for (idx.entries.items) |*e| {
        seen.put(gpa, e.path, {}) catch util.oom();
        const t = m.get(e.path);
        if (e.stage() != 0 or t == null or t.?.mode != e.mode or !hash.eql(t.?.oid, e.oid)) {
            if (b.items.len > 0 and util.endsWith(b.items, e.path)) continue;
            if (b.items.len > 0) util.bufByte(&b, ' ');
            util.bufAppend(&b, e.path);
        }
    }
    var it = m.keyIterator();
    var missing: std.ArrayList([]const u8) = .empty;
    while (it.next()) |k| if (!seen.contains(k.*)) missing.append(gpa, k.*) catch util.oom();
    util.sortStrings(missing.items);
    for (missing.items) |p| {
        if (b.items.len > 0) util.bufByte(&b, ' ');
        util.bufAppend(&b, p);
    }
    return b.items;
}

/// merge_ort_nonrecursive(): returns 1 if clean, 0 if conflicted, -1 on error.
fn mergeNonrecursive(head: Oid, merge: Oid, merge_base: Oid, labels: Labels, verbose: bool) i32 {
    const idx = index_mod.get();
    const changes = indexChangesAgainst(idx, head);
    if (changes.len > 0) {
        util.err("Your local changes to the following files would be overwritten by merge:\n  {s}", .{changes});
        return -1;
    }
    if (hash.eql(merge_base, merge)) {
        util.out("Already up to date.\n");
        return 1;
    }
    const res = mergeTrees(merge_base, head, merge, labels);

    var o = ut.Options{};
    o.head_idx = 0;
    o.src_index = idx;
    o.dst_index = idx;
    ut.setupPorcelain(&o, "merge");
    o.update = true;
    o.merge = true;
    o.func = &ut.twowayMerge;
    o.preserve_ignored = false;
    if (ut.unpackTrees(&.{ head, res.tree }, &o) != 0) return -1;

    const cur = index_mod.get();
    for (res.conflicts) |c| {
        _ = cur.removePath(c.path);
        for (c.stages, 0..) |s, i| {
            const fe = s orelse continue;
            var e = Entry{ .path = c.path, .mode = fe.mode, .oid = fe.oid };
            e.setStage(@intCast(i + 1));
            _ = cur.add(e, .{ .skip_df_check = true });
        }
        cur.changed = true;
    }
    refs.writeRef("AUTO_MERGE", res.tree) catch {};
    if (verbose) util.out(res.msgs);
    return if (res.clean) 1 else 0;
}

/// Compute the index tree for --index: apply the b_tree -> i_tree changes on top of c_tree.
fn applyIndexChanges(b_tree: Oid, i_tree: Oid, c_tree: Oid) ?Oid {
    const bm = flatten(b_tree);
    const im = flatten(i_tree);
    var cm = flatten(c_tree);
    var failed = false;
    for (unionPaths(&.{ &bm, &im })) |p| {
        const b = bm.get(p);
        const i = im.get(p);
        if (sameFlat(b, i)) continue;
        const c = cm.get(p);
        if (sameFlat(c, b)) {
            if (i) |x| cm.put(gpa, p, x) catch util.oom() else _ = cm.remove(p);
        } else if (sameFlat(c, i)) {
            continue;
        } else if (b != null and i != null and c != null) {
            const bd = readBlobOrEmpty(b);
            const cd = readBlobOrEmpty(c);
            const id = readBlobOrEmpty(i);
            var mo = xdiff.MergeOpts{};
            mo.level = .zealous;
            const r = xdiff.merge(bd, cd, id, mo) catch {
                failed = true;
                continue;
            };
            if (r.conflicts > 0 or isBinary(bd)) {
                util.err("{s}: patch does not apply", .{p});
                failed = true;
                continue;
            }
            cm.put(gpa, p, .{ .path = p, .mode = i.?.mode, .oid = writeBlob(r.result) }) catch util.oom();
        } else {
            if (c == null) {
                util.err("{s}: does not exist in index", .{p});
            } else util.err("{s}: already exists in index", .{p});
            failed = true;
        }
    }
    if (failed) return null;
    var list: std.ArrayList(FlatEntry) = .empty;
    var it = cm.valueIterator();
    while (it.next()) |v| list.append(gpa, v.*) catch util.oom();
    return treeFromEntries(list.items);
}

fn unstageChangesUnlessNew(orig_tree: Oid) void {
    const idx = index_mod.lockAndRead();
    const m = flatten(orig_tree);
    var seen: std.StringHashMapUnmanaged(void) = .empty;
    var changed = false;
    var i: usize = 0;
    while (i < idx.entries.items.len) : (i += 1) {
        const e = &idx.entries.items[i];
        seen.put(gpa, e.path, {}) catch util.oom();
        if (e.stage() != 0) continue;
        const t = m.get(e.path) orelse continue;
        if (t.mode == e.mode and hash.eql(t.oid, e.oid)) continue;
        if (e.skipWorktree()) {
            _ = checkoutBlob(e.path, e.mode, e.oid);
        }
        e.* = .{ .path = e.path, .mode = t.mode, .oid = t.oid };
        idx.invalidatePath(e.path);
        changed = true;
    }
    var it = m.valueIterator();
    var add: std.ArrayList(FlatEntry) = .empty;
    while (it.next()) |v| if (!seen.contains(v.path)) add.append(gpa, v.*) catch util.oom();
    for (add.items) |v| {
        _ = idx.add(.{ .path = v.path, .mode = v.mode, .oid = v.oid }, .{});
        changed = true;
    }
    if (changed) {
        idx.changed = true;
        idx.write();
    } else idx.rollback();
}

fn resetTreeIndexOnly(tree: Oid) i32 {
    const idx = index_mod.lockAndRead();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const Pathspec, null), null);
    index_mod.resetToTree(idx, tree);
    idx.write();
    return 0;
}

fn restoreUntracked(u_tree: Oid) i32 {
    const env = [_][2][]const u8{.{ "GIT_INDEX_FILE", stash_index_path }};
    if (runGit(&.{ "read-tree", &hash.hex(u_tree) }, .{ .env = &env }).status != 0) {
        _ = os.unlink(stash_index_path);
        return -1;
    }
    const r = runGit(&.{ "checkout-index", "--all" }, .{ .env = &env });
    _ = os.unlink(stash_index_path);
    return if (r.status != 0) -1 else 0;
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return p;
    return util.normalizePath(util.joinPath(os.getcwd(), p)) orelse p;
}

fn doApplyStash(info: *StashInfo, index_opt: bool, quiet: bool, label_ours: ?[]const u8, label_theirs: ?[]const u8, label_base: ?[]const u8) i32 {
    const r = repo_mod.repo();
    var has_index = index_opt;
    _ = refreshAndWriteIndex();
    var idx = index_mod.get();
    const c_tree = idx.writeTree(false) orelse {
        util.err("cannot apply a stash in the middle of a merge", .{});
        return -1;
    };
    var index_tree: Oid = hash.zero;
    if (index_opt) {
        if (hash.eql(info.b_tree, info.i_tree) or hash.eql(c_tree, info.i_tree)) {
            has_index = false;
        } else {
            index_tree = applyIndexChanges(info.b_tree, info.i_tree, c_tree) orelse {
                util.err("conflicts in index. Try without --index.", .{});
                return -1;
            };
            _ = runGit(&.{ "reset", "--quiet", "--refresh" }, .{});
            index_mod.discard();
            idx = index_mod.get();
        }
    }

    var labels = Labels{
        .ours = label_ours orelse "Updated upstream",
        .theirs = label_theirs orelse "Stashed changes",
        .base = label_base orelse "Stash base",
    };
    if (hash.eql(info.b_tree, c_tree)) labels.ours = "Version stash was based on";

    var mo = merge_ort.initMergeOptions(true);
    mo.branch1 = labels.ours;
    mo.branch2 = labels.theirs;
    mo.ancestor = labels.base;
    if (quiet) mo.verbosity = 0;
    if (mo.verbosity >= 3) util.outf("Merging {s} with {s}\n", .{ mo.branch1, mo.branch2 });
    _ = index_mod.lockAndRead();
    const clean = merge_ort.mergeOrtNonrecursive(&mo, c_tree, info.w_tree, info.b_tree);
    var ret: i32 = if (clean >= 0) @intFromBool(clean == 0) else clean;
    const cur = index_mod.get();
    if (ret < 0) {
        cur.rollback();
    } else {
        if (cur.changed or true) cur.write() else cur.rollback();
    }

    if (ret != 0) {
        if (index_opt) util.eprint("Index was not unstashed.\n", .{});
    } else {
        if (has_index) {
            if (resetTreeIndexOnly(index_tree) != 0) ret = -1;
        } else {
            unstageChangesUnlessNew(c_tree);
        }
    }

    if (info.has_u and restoreUntracked(info.u_tree) != 0) {
        util.err("could not restore untracked files from stash", .{});
        ret = -1;
    }

    if (!quiet) {
        util.flushStdout();
        const wt = r.work_tree orelse ".";
        const env = [_][2][]const u8{
            .{ "GIT_WORK_TREE", absPath(wt) },
            .{ "GIT_DIR", absPath(r.git_dir) },
        };
        const pfx = r.prefix;
        _ = runGit(&.{"status"}, .{ .env = &env, .cwd = if (pfx.len > 0) pfx else null });
    }
    return ret;
}

var label_ours_opt: ?[]const u8 = null;
var label_theirs_opt: ?[]const u8 = null;
var label_base_opt: ?[]const u8 = null;

fn cmdApply(argv: []const []const u8) i32 {
    const usage = [_][]const u8{apply_usage_str};
    var quiet = false;
    var index_opt = use_index;
    const opts = [_]po.Opt{
        po.boolean('q', "quiet", &quiet, "be quiet, only report errors"),
        po.boolean(0, "index", &index_opt, "attempt to recreate the index"),
        po.string(0, "label-ours", &label_ours_opt, "label", "label for the upstream side in conflict markers"),
        po.string(0, "label-theirs", &label_theirs_opt, "label", "label for the stashed side in conflict markers"),
        po.string(0, "label-base", &label_base_opt, "label", "label for the base in diff3 conflict markers"),
    };
    const rest = po.parse(argv, &opts, &usage, .{});
    var info = StashInfo{};
    if (getStashInfo(&info, rest) != 0) return -1;
    return doApplyStash(&info, index_opt, quiet, label_ours_opt, label_theirs_opt, label_base_opt);
}

fn cmdPop(argv: []const []const u8) i32 {
    const usage = [_][]const u8{pop_usage_str};
    var quiet = false;
    var index_opt = use_index;
    const opts = [_]po.Opt{
        po.boolean('q', "quiet", &quiet, "be quiet, only report errors"),
        po.boolean(0, "index", &index_opt, "attempt to recreate the index"),
    };
    const rest = po.parse(argv, &opts, &usage, .{});
    var info = StashInfo{};
    if (getStashInfoAssert(&info, rest) != 0) return -1;
    const ret = doApplyStash(&info, index_opt, quiet, null, null, null);
    if (ret != 0) {
        util.out("The stash entry is kept in case you need it again.\n");
        return ret;
    }
    return doDropStash(&info, quiet);
}

fn cmdBranch(argv: []const []const u8) i32 {
    const usage = [_][]const u8{branch_usage_str};
    const rest = po.parse(argv, &.{}, &usage, .{});
    if (rest.len == 0) {
        util.eprint("No branch name specified\n", .{});
        return -1;
    }
    const branch = rest[0];
    var info = StashInfo{};
    if (getStashInfo(&info, rest[1..]) != 0) return -1;
    var ret: i32 = @intCast(runGit(&.{ "checkout", "-b", branch, &hash.hex(info.b_commit) }, .{}).status);
    if (ret == 0) {
        index_mod.discard();
        ret = doApplyStash(&info, true, false, null, null, null);
    }
    if (ret == 0 and info.is_stash_ref) ret = doDropStash(&info, false);
    return ret;
}

// ---------------- list / show ----------------

fn cmdList(argv: []const []const u8) i32 {
    const usage = [_][]const u8{list_usage_str};
    const rest = po.parse(argv, &.{}, &usage, .{ .keep_unknown = true });
    if (!refs.exists(ref_stash)) return 0;
    var a: std.ArrayList([]const u8) = .empty;
    a.appendSlice(gpa, &.{ "log", "--format=%gd: %gs", "-g", "--first-parent" }) catch util.oom();
    a.appendSlice(gpa, rest) catch util.oom();
    a.appendSlice(gpa, &.{ ref_stash, "--" }) catch util.oom();
    util.flushStdout();
    return @intCast(runGit(a.items, .{}).status);
}

var show_untracked: i32 = 0;

fn cmdShow(argv: []const []const u8) i32 {
    const usage = [_][]const u8{show_usage_str};
    show_untracked = if (show_include_untracked) 1 else 0;
    var opts = [_]po.Opt{
        po.setInt('u', "include-untracked", &show_untracked, 1, "include untracked files in the stash"),
        po.setInt(0, "only-untracked", &show_untracked, 2, "only show untracked files in the stash"),
    };
    opts[1].noneg = true;
    const rest = po.parse(argv, &opts, &usage, .{ .keep_unknown = true, .keep_dashdash = true });
    var stash_args: std.ArrayList([]const u8) = .empty;
    var rev_args: std.ArrayList([]const u8) = .empty;
    for (rest) |a| {
        if (a.len > 0 and a[0] != '-') stash_args.append(gpa, a) catch util.oom() else rev_args.append(gpa, a) catch util.oom();
    }
    var info = StashInfo{};
    if (getStashInfo(&info, stash_args.items) != 0) return -1;

    var diff_args: std.ArrayList([]const u8) = .empty;
    diff_args.append(gpa, "diff") catch util.oom();
    if (rev_args.items.len == 0) {
        if (show_stat) diff_args.append(gpa, "--stat") catch util.oom();
        if (show_patch) diff_args.append(gpa, "--patch") catch util.oom();
        if (!show_stat and !show_patch) return 0;
    } else {
        diff_args.appendSlice(gpa, rev_args.items) catch util.oom();
    }
    var from: []const u8 = &hash.hex(info.b_commit);
    var to: []const u8 = &hash.hex(info.w_commit);
    switch (show_untracked) {
        0 => {},
        2 => {
            if (!info.has_u) return 0;
            from = hash.empty_tree_hex;
            to = &hash.hex(info.u_tree);
        },
        else => {
            if (info.has_u) {
                var list: std.ArrayList(FlatEntry) = .empty;
                objects.flattenTree(info.w_tree, "", &list);
                const wm = flatten(info.w_tree);
                var ul: std.ArrayList(FlatEntry) = .empty;
                objects.flattenTree(info.u_tree, "", &ul);
                for (ul.items) |u| {
                    if (wm.contains(u.path)) util.die("worktree and untracked commit have duplicate entries: {s}", .{u.path});
                    list.append(gpa, u) catch util.oom();
                }
                const t = treeFromEntries(list.items) orelse util.die("failed to unpack trees", .{});
                to = util.dupe(&hash.hex(t));
            }
        },
    }
    diff_args.append(gpa, util.dupe(from)) catch util.oom();
    diff_args.append(gpa, util.dupe(to)) catch util.oom();
    util.flushStdout();
    return @intCast(runGit(diff_args.items, .{}).status);
}

// ---------------- store ----------------

fn doStoreStash(w_commit: Oid, stash_msg: ?[]const u8, quiet: bool) i32 {
    var info = StashInfo{};
    assertStashLike(&info, util.dupe(&hash.hex(w_commit)));
    const msg = stash_msg orelse "Created via \"git stash store\".";
    refs.updateFlags(ref_stash, w_commit, null, msg, refs.F_FORCE_CREATE_REFLOG) catch {
        if (!quiet) {
            util.err("{s}", .{refs.last_error});
            util.eprint("Cannot update {s} with {s}\n", .{ ref_stash, hash.hex(w_commit) });
        }
        return -1;
    };
    return 0;
}

fn cmdStore(argv: []const []const u8) i32 {
    const usage = [_][]const u8{store_usage_str};
    var quiet = false;
    var msg: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.boolean('q', "quiet", &quiet, "be quiet"),
        po.string('m', "message", &msg, "message", "stash message"),
    };
    const rest = po.parse(argv, &opts, &usage, .{ .keep_unknown = true });
    if (rest.len != 1) {
        if (!quiet) util.eprint("\"git stash store\" requires one <commit> argument\n", .{});
        return -1;
    }
    const obj = revparse.getOid(rest[0]) orelse {
        if (!quiet) util.eprint("Cannot update {s} with {s}\n", .{ ref_stash, rest[0] });
        return -1;
    };
    return doStoreStash(obj, msg, quiet);
}

// ---------------- create ----------------

fn untrackedFiles(ps: *const Pathspec, include_untracked: i32) [][]const u8 {
    const res = dir_mod.untracked(.{
        .pathspec = if (ps.isEmpty()) null else ps,
        .standard_excludes = include_untracked != INCLUDE_ALL_FILES,
    });
    var out: std.ArrayList([]const u8) = .empty;
    for (res.entries) |e| out.append(gpa, e.name) catch util.oom();
    return out.items;
}

/// check_changes_tracked_files(): <0 error, 0 no changes, >0 changes.
fn checkChangesTrackedFiles(ps: *const Pathspec) i32 {
    const head = revparse.getCommit("HEAD") orelse return -1;
    const idx = index_mod.get();
    const hm = flatten(commitTree(head));
    var seen: std.StringHashMapUnmanaged(void) = .empty;
    for (idx.entries.items) |*e| {
        if (!psMatches(ps, e.path)) continue;
        seen.put(gpa, e.path, {}) catch util.oom();
        if (e.stage() != 0) return 1;
        if (e.mode == 0o160000) continue;
        const h = hm.get(e.path) orelse return 1;
        if (h.mode != e.mode or !hash.eql(h.oid, e.oid)) return 1;
        if (e.intentToAdd()) return 1;
    }
    var it = hm.keyIterator();
    while (it.next()) |k| {
        if (!psMatches(ps, k.*)) continue;
        if (!seen.contains(k.*)) return 1;
    }
    for (idx.entries.items) |*e| {
        if (!psMatches(ps, e.path)) continue;
        if (e.mode == 0o160000 or e.skipWorktree()) continue;
        const st = os.lstatPath(e.path) orelse return 1;
        if (e.uptodate) continue;
        if (idx.matchStat(e, st, false) != 0) return 1;
    }
    return 0;
}

fn checkChanges(ps: *const Pathspec, include_untracked: i32, untracked: *[][]const u8) bool {
    var ret = false;
    if (checkChangesTrackedFiles(ps) != 0) ret = true;
    if (include_untracked != 0) {
        untracked.* = untrackedFiles(ps, include_untracked);
        if (untracked.len > 0) ret = true;
    }
    return ret;
}

fn isPathADirectory(p: []const u8) bool {
    const st = os.lstatPath(p) orelse return false;
    return st.isDir();
}

fn addWorktreeFile(tmp: *Index, p: []const u8) void {
    const st = os.lstatPath(p) orelse {
        _ = tmp.removePath(p);
        return;
    };
    if (st.isDir() and index_mod.gitlinkHead(p) == null) {
        _ = tmp.removePath(p);
        return;
    }
    const old = tmp.get(p);
    const e = index_mod.entryFromFile(p, st, old, true) orelse return;
    _ = tmp.add(e, .{});
}

fn saveUntrackedFiles(info: *StashInfo, msg: []const u8, files: []const []const u8) bool {
    var tmp = Index{};
    for (files) |f0| {
        var f = f0;
        if (f.len > 1 and f[f.len - 1] == '/') f = f[0 .. f.len - 1];
        addWorktreeFile(&tmp, f);
    }
    info.u_tree = tmp.writeTree(false) orelse return false;
    info.u_commit = commit_mod.create(.{ .tree = info.u_tree, .message = util.fmt("untracked files on {s}\n", .{msg}) });
    return true;
}

fn stashWorkingTree(info: *StashInfo, ps: *const Pathspec) bool {
    const idx = index_mod.get();
    var tmp = Index{};
    index_mod.addTreeRecursive(&tmp, info.i_tree, "", 0);
    std.mem.sort(Entry, tmp.entries.items, {}, index_mod.entryLess);
    const bm = flatten(info.b_tree);
    var changed: std.ArrayList([]const u8) = .empty;
    var seen: std.StringHashMapUnmanaged(void) = .empty;
    for (idx.entries.items) |*e| {
        if (!psMatches(ps, e.path)) continue;
        const gop = seen.getOrPut(gpa, e.path) catch util.oom();
        if (gop.found_existing) continue;
        const b = bm.get(e.path);
        if (e.stage() != 0) {
            changed.append(gpa, e.path) catch util.oom();
            continue;
        }
        if (e.skipWorktree()) {
            if (b == null or b.?.mode != e.mode or !hash.eql(b.?.oid, e.oid)) changed.append(gpa, e.path) catch util.oom();
            continue;
        }
        const st = os.lstatPath(e.path) orelse {
            if (b != null) changed.append(gpa, e.path) catch util.oom();
            continue;
        };
        const dirty = !e.uptodate and idx.matchStat(e, st, false) != 0;
        if (dirty or b == null or b.?.mode != e.mode or !hash.eql(b.?.oid, e.oid))
            changed.append(gpa, e.path) catch util.oom();
    }
    var it = bm.keyIterator();
    var extra: std.ArrayList([]const u8) = .empty;
    while (it.next()) |k| {
        if (!psMatches(ps, k.*)) continue;
        if (!seen.contains(k.*)) extra.append(gpa, k.*) catch util.oom();
    }
    util.sortStrings(extra.items);
    changed.appendSlice(gpa, extra.items) catch util.oom();
    for (changed.items) |p| {
        if (isPathADirectory(p) and index_mod.gitlinkHead(p) == null) continue;
        addWorktreeFile(&tmp, p);
    }
    info.w_tree = tmp.writeTree(false) orelse return false;
    return true;
}

fn branchAndMsg(head: Oid) struct { branch: []const u8, msg: []const u8 } {
    var branch_name: []const u8 = "(no branch)";
    if (refs.readSymbolic("HEAD")) |target| {
        if (util.skipPrefix(target, "refs/heads/")) |b| branch_name = b;
    }
    const c = objects.readCommit(head) orelse util.die("could not parse HEAD commit", .{});
    var b: util.Buf = .empty;
    util.bufPrint(&b, "{s}: {s} ", .{ branch_name, revparse.abbrev(head, 0) });
    const pos = pretty.skipBlankLines(c.message, 0);
    _ = pretty.formatSubject(&b, c.message, pos, " ");
    return .{ .branch = branch_name, .msg = b.items };
}

const CreateResult = struct { ret: i32, patch_empty: bool = false };

fn doCreateStash(ps: *const Pathspec, stash_msg: *util.Buf, include_untracked: i32, only_staged: bool, info: *StashInfo, quiet: bool) i32 {
    _ = refreshAndWriteIndex();
    info.b_commit = revparse.getCommit("HEAD") orelse {
        if (!quiet) util.eprint("You do not have the initial commit yet\n", .{});
        return -1;
    };
    var untracked: [][]const u8 = &.{};
    if (!checkChanges(ps, include_untracked, &untracked)) return 1;

    const bm = branchAndMsg(info.b_commit);
    const idx = index_mod.get();
    info.i_tree = idx.writeTree(false) orelse {
        if (!quiet) util.eprint("Cannot save the current index state\n", .{});
        return -1;
    };
    info.i_commit = commit_mod.create(.{ .tree = info.i_tree, .parents = &.{info.b_commit}, .message = util.fmt("index on {s}\n", .{bm.msg}) });

    var has_u = false;
    if (include_untracked != 0) {
        if (!saveUntrackedFiles(info, bm.msg, untracked)) {
            if (!quiet) util.eprint("Cannot save the untracked files\n", .{});
            return -1;
        }
        has_u = true;
    }
    if (patch_mode_g) {
        const r = stashPatch(info, ps, quiet);
        if (r < 0) {
            if (!quiet) util.eprint("Cannot save the current worktree state\n", .{});
            return -1;
        } else if (r > 0) return r;
    } else if (only_staged) {
        info.w_tree = info.i_tree;
        if (hash.eql(info.w_tree, commitTree(info.b_commit))) {
            if (!quiet) util.eprint("No staged changes\n", .{});
            return 1;
        }
    } else {
        if (!stashWorkingTree(info, ps)) {
            if (!quiet) util.eprint("Cannot save the current worktree state\n", .{});
            return -1;
        }
    }
    if (stash_msg.items.len == 0) {
        util.bufPrint(stash_msg, "WIP on {s}", .{bm.msg});
    } else {
        const m = util.dupe(stash_msg.items);
        stash_msg.clearRetainingCapacity();
        util.bufPrint(stash_msg, "On {s}: {s}", .{ bm.branch, m });
    }
    var parents: std.ArrayList(Oid) = .empty;
    parents.append(gpa, info.b_commit) catch util.oom();
    parents.append(gpa, info.i_commit) catch util.oom();
    if (has_u) parents.append(gpa, info.u_commit) catch util.oom();
    info.w_commit = commit_mod.create(.{ .tree = info.w_tree, .parents = parents.items, .message = stash_msg.items });
    return 0;
}

fn cmdCreate(argv: []const []const u8) i32 {
    var msg: util.Buf = .empty;
    for (argv, 0..) |a, i| {
        if (i > 0) util.bufByte(&msg, ' ');
        util.bufAppend(&msg, a);
    }
    const ps = Pathspec{};
    if (checkChangesTrackedFiles(&ps) == 0) return 0;
    var info = StashInfo{};
    const ret = doCreateStash(&ps, &msg, 0, false, &info, false);
    if (ret == 0) util.outf("{s}\n", .{hash.hex(info.w_commit)});
    return ret;
}

// ---------------- push ----------------

/// Reverse-apply the HEAD -> index changes to the worktree (git apply -R of the staged diff).
fn revertStagedInWorktree(head_tree: Oid, i_tree: Oid, ps: *const Pathspec) bool {
    const hm = flatten(head_tree);
    const im = flatten(i_tree);
    const Action = struct { path: []const u8, mode: u32, oid: ?Oid };
    var actions: std.ArrayList(Action) = .empty;
    var ok = true;
    for (unionPaths(&.{ &hm, &im })) |p| {
        if (!psMatches(ps, p)) continue;
        const h = hm.get(p);
        const i = im.get(p);
        if (sameFlat(h, i)) continue;
        const st = os.lstatPath(p);
        if (i == null) {
            if (st != null) {
                util.err("{s}: already exists in working directory", .{p});
                ok = false;
                continue;
            }
            actions.append(gpa, .{ .path = p, .mode = h.?.mode, .oid = h.?.oid }) catch util.oom();
            continue;
        }
        if (st == null) {
            util.err("{s}: No such file or directory", .{p});
            ok = false;
            continue;
        }
        const wdata = (if (st.?.isLnk()) os.readLink(p) else os.readFile(p)) orelse "";
        const woid = @import("../odb.zig").hashObject(.blob, wdata);
        if (h == null) {
            if (!hash.eql(woid, i.?.oid)) {
                util.err("{s}: patch does not apply", .{p});
                ok = false;
                continue;
            }
            actions.append(gpa, .{ .path = p, .mode = 0, .oid = null }) catch util.oom();
            continue;
        }
        if (hash.eql(woid, i.?.oid)) {
            actions.append(gpa, .{ .path = p, .mode = h.?.mode, .oid = h.?.oid }) catch util.oom();
            continue;
        }
        var mo = xdiff.MergeOpts{};
        mo.level = .zealous;
        const r = xdiff.merge(readBlobOrEmpty(i), wdata, readBlobOrEmpty(h), mo) catch {
            ok = false;
            continue;
        };
        if (r.conflicts > 0) {
            util.err("patch failed: {s}", .{p});
            util.err("{s}: patch does not apply", .{p});
            ok = false;
            continue;
        }
        actions.append(gpa, .{ .path = p, .mode = h.?.mode, .oid = writeBlob(r.result) }) catch util.oom();
    }
    if (!ok) return false;
    for (actions.items) |a| {
        if (a.oid) |o| {
            _ = checkoutBlob(a.path, a.mode, o);
        } else {
            _ = os.unlink(a.path);
            removeEmptyParents(a.path);
        }
    }
    return true;
}

fn removeEmptyParents(path: []const u8) void {
    var p = path;
    while (std.mem.lastIndexOfScalar(u8, p, '/')) |i| {
        p = p[0..i];
        if (!os.rmdir(p)) break;
    }
}

/// Make index and worktree match `tree` for paths in ps; with no_overlay, remove
/// paths not in tree (git checkout --no-overlay <tree> -- <ps>).
fn checkoutTreePaths(tree: Oid, ps: *const Pathspec, no_overlay: bool) void {
    const idx = index_mod.lockAndRead();
    const tm = flatten(tree);
    var to_remove: std.ArrayList([]const u8) = .empty;
    for (idx.entries.items) |*e| {
        if (!psMatches(ps, e.path)) continue;
        if (!tm.contains(e.path) and no_overlay) to_remove.append(gpa, e.path) catch util.oom();
    }
    for (to_remove.items) |p| {
        const e = idx.get(p);
        if (e) |ee| entry.unlinkEntry(ee);
        while (idx.removePath(p)) {}
        idx.changed = true;
    }
    var st = entry.State{ .force = true, .quiet = true, .refresh_cache = true, .istate = idx };
    var paths: std.ArrayList([]const u8) = .empty;
    var it = tm.keyIterator();
    while (it.next()) |k| if (psMatches(ps, k.*)) paths.append(gpa, k.*) catch util.oom();
    util.sortStrings(paths.items);
    for (paths.items) |p| {
        const t = tm.get(p).?;
        if (idx.get(p)) |e| {
            if (e.stage() == 0 and e.mode == t.mode and hash.eql(e.oid, t.oid)) {
                _ = entry.checkoutEntry(e, &st, null);
                continue;
            }
        }
        while (idx.removePath(p)) {}
        _ = idx.add(.{ .path = p, .mode = t.mode, .oid = t.oid }, .{});
        idx.changed = true;
        if (idx.get(p)) |e| _ = entry.checkoutEntry(e, &st, null);
    }
    entry.removeScheduledDirs();
    idx.changed = true;
    idx.write();
}

fn pathspecArgs(ps: *const Pathspec, out: *std.ArrayList([]const u8)) void {
    for (ps.items) |it| out.append(gpa, it.original) catch util.oom();
}

fn doPushStash(ps: *const Pathspec, stash_msg: ?[]const u8, quiet: bool, keep_index0: i32, patch_mode: bool, include_untracked: i32, only_staged0: bool) i32 {
    var keep_index = keep_index0;
    var only_staged = only_staged0;
    if (patch_mode and keep_index == -1) keep_index = 1;
    if (patch_mode and include_untracked != 0) {
        util.eprint("Can't use --patch and --include-untracked or --all at the same time\n", .{});
        return -1;
    }
    if (patch_mode) only_staged = false;
    if (only_staged and include_untracked != 0) {
        util.eprint("Can't use --staged and --include-untracked or --all at the same time\n", .{});
        return -1;
    }
    patch_mode_g = patch_mode;

    {
        const idx = index_mod.get();
        if (include_untracked == 0 and !ps.isEmpty()) {
            const seen = ps.newSeen();
            ps.matchAgainstIndex(idx, seen, false);
            if (ps.reportPathError(seen) > 0) {
                util.eprint("Did you forget to 'git add'?\n", .{});
                return -1;
            }
        }
    }
    _ = refreshAndWriteIndex();

    var untracked: [][]const u8 = &.{};
    if (!checkChanges(ps, include_untracked, &untracked)) {
        if (!quiet) util.out("No local changes to save\n");
        return 0;
    }

    if (!refs.reflogExists(ref_stash) and doClearStash() != 0) {
        if (!quiet) util.eprint("Cannot initialize stash\n", .{});
        return -1;
    }

    var msg_buf: util.Buf = .empty;
    if (stash_msg) |m| util.bufAppend(&msg_buf, m);
    var info = StashInfo{};
    if (doCreateStash(ps, &msg_buf, include_untracked, only_staged, &info, quiet) != 0) return -1;

    if (doStoreStash(info.w_commit, msg_buf.items, true) != 0) {
        if (!quiet) util.eprint("Cannot save the current status\n", .{});
        return -1;
    }
    if (!quiet) util.outf("Saved working directory and index state {s}\n", .{msg_buf.items});
    util.flushStdout();

    const r = repo_mod.repo();
    if (!(patch_mode or only_staged)) {
        if (include_untracked != 0 and ps.isEmpty()) {
            var a: std.ArrayList([]const u8) = .empty;
            a.appendSlice(gpa, &.{ "clean", "--force", "--quiet", "-d", ":/" }) catch util.oom();
            if (include_untracked == INCLUDE_ALL_FILES) a.append(gpa, "-x") catch util.oom();
            var env: []const [2][]const u8 = &.{};
            var cwd: ?[]const u8 = null;
            if (repo_mod.original_cwd.len > 0) {
                const oc = repo_mod.original_cwd;
                if (r.work_tree) |wt| {
                    const e = gpa.alloc([2][]const u8, 1) catch util.oom();
                    e[0] = .{ "GIT_WORK_TREE", absPath(wt) };
                    env = e;
                    cwd = oc;
                }
            }
            if (runGit(a.items, .{ .env = env, .cwd = cwd }).status != 0) return -1;
        }
        index_mod.discard();
        if (!ps.isEmpty()) {
            var a: std.ArrayList([]const u8) = .empty;
            a.append(gpa, "add") catch util.oom();
            if (include_untracked == 0) a.append(gpa, "-u") catch util.oom();
            if (include_untracked == INCLUDE_ALL_FILES) a.append(gpa, "--force") catch util.oom();
            a.append(gpa, "--") catch util.oom();
            pathspecArgs(ps, &a);
            if (runGit(a.items, .{}).status != 0) return -1;
            index_mod.discard();
            checkoutTreePaths(commitTree(info.b_commit), ps, true);
        } else {
            if (runGit(&.{ "reset", "--hard", "-q", "--no-recurse-submodules" }, .{}).status != 0) return -1;
        }
        index_mod.discard();
        if (keep_index == 1 and !hash.isZero(info.i_tree) and !util.eql(&hash.hex(info.i_tree), hash.empty_tree_hex)) {
            checkoutTreePaths(info.i_tree, ps, true);
        }
        return 0;
    }
    if (patch_mode) {
        if (runGit(&.{ "apply", "-R" }, .{ .stdin_data = patch_out.items }).status != 0) {
            if (!quiet) util.eprint("Cannot remove worktree changes\n", .{});
            return -1;
        }
    } else if (!revertStagedInWorktree(commitTree(info.b_commit), info.i_tree, ps)) {
        if (!quiet) util.eprint("Cannot remove worktree changes\n", .{});
        return -1;
    }
    if (keep_index < 1) {
        var a: std.ArrayList([]const u8) = .empty;
        a.appendSlice(gpa, &.{ "reset", "-q", "--refresh", "--" }) catch util.oom();
        pathspecArgs(ps, &a);
        if (runGit(a.items, .{}).status != 0) return -1;
    }
    return 0;
}

var push_keep_index: i32 = -1;

fn keepIndexCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    push_keep_index = if (unset) 0 else 1;
}

fn pushStash(argv0: []const []const u8, push_assumed: bool) i32 {
    var only_staged = false;
    var patch_mode = false;
    var auto_advance = true;
    var ctx: i32 = -1;
    var ihc: i32 = -1;
    var include_u = false;
    var include_untracked: i32 = 0;
    var quiet = false;
    var pathspec_file_nul = false;
    var stash_msg: ?[]const u8 = null;
    var pathspec_from_file: ?[]const u8 = null;
    push_keep_index = -1;
    const opts = [_]po.Opt{
        .{ .short = 'k', .long = "keep-index", .kind = .callback, .cb = keepIndexCb, .noarg = true, .help = "keep index" },
        po.boolean('S', "staged", &only_staged, "stash staged changes only"),
        po.boolean('p', "patch", &patch_mode, "stash in patch mode"),
        po.boolean(0, "auto-advance", &auto_advance, "auto advance to the next file when selecting hunks interactively"),
        .{ .short = 'U', .long = "unified", .kind = .int, .i = &ctx, .argh = "n", .help = "generate diffs with <n> lines context", .noneg = true },
        .{ .short = 0, .long = "inter-hunk-context", .kind = .int, .i = &ihc, .argh = "n", .help = "show context between diff hunks up to the specified number of lines", .noneg = true },
        po.boolean('q', "quiet", &quiet, "quiet mode"),
        po.setInt('u', "include-untracked", &include_untracked, 1, "include untracked files in stash"),
        po.setInt('a', "all", &include_untracked, 2, "include ignore files"),
        po.string('m', "message", &stash_msg, "message", "stash message"),
        po.filename(0, "pathspec-from-file", &pathspec_from_file, "file", "read pathspec from file"),
        po.boolean(0, "pathspec-file-nul", &pathspec_file_nul, "with --pathspec-from-file, pathspec elements are separated with NUL character"),
    };
    _ = &include_u;
    var argv = argv0;
    var force_assume = false;
    if (argv.len > 0) {
        const usage_push = [_][]const u8{push_usage_str};
        argv = po.parse(argv, &opts, if (push_assumed) &stash_usage else &usage_push, .{ .keep_dashdash = true, .stop_at_non_option = push_assumed });
        force_assume = patch_mode;
    }
    if (argv.len > 0) {
        if (util.eql(argv[0], "--")) {
            argv = argv[1..];
        } else if (push_assumed and !force_assume) {
            util.die("subcommand wasn't specified; 'push' can't be assumed due to unexpected token '{s}'", .{argv[0]});
        }
    }
    const prefix = repo_mod.repo().prefix;
    var ps = pathspec_mod.parse(prefix, argv, .{ .prefer_full = true, .prefix_origin = true });
    if (pathspec_from_file) |f| {
        if (patch_mode) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "--patch" });
        if (only_staged) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "--staged" });
        if (!ps.isEmpty()) util.die("'{s}' and pathspec arguments cannot be used together", .{"--pathspec-from-file"});
        const items = pathspec_mod.readPathspecFile(f, pathspec_file_nul);
        ps = pathspec_mod.parse(prefix, items, .{ .prefer_full = true, .prefix_origin = true });
    } else if (pathspec_file_nul) {
        util.die("the option '{s}' requires '{s}'", .{ "--pathspec-file-nul", "--pathspec-from-file" });
    }
    checkInteractiveOpts(patch_mode, ctx, ihc, auto_advance);
    return doPushStash(&ps, stash_msg, quiet, push_keep_index, patch_mode, include_untracked, only_staged);
}

fn cmdSave(argv0: []const []const u8) i32 {
    const usage = [_][]const u8{save_usage_str};
    var only_staged = false;
    var patch_mode = false;
    var auto_advance = true;
    var ctx: i32 = -1;
    var ihc: i32 = -1;
    var include_untracked: i32 = 0;
    var quiet = false;
    var stash_msg: ?[]const u8 = null;
    push_keep_index = -1;
    const opts = [_]po.Opt{
        .{ .short = 'k', .long = "keep-index", .kind = .callback, .cb = keepIndexCb, .noarg = true, .help = "keep index" },
        po.boolean('S', "staged", &only_staged, "stash staged changes only"),
        po.boolean('p', "patch", &patch_mode, "stash in patch mode"),
        po.boolean(0, "auto-advance", &auto_advance, "auto advance to the next file when selecting hunks interactively"),
        .{ .short = 'U', .long = "unified", .kind = .int, .i = &ctx, .argh = "n", .help = "generate diffs with <n> lines context", .noneg = true },
        .{ .short = 0, .long = "inter-hunk-context", .kind = .int, .i = &ihc, .argh = "n", .help = "show context between diff hunks up to the specified number of lines", .noneg = true },
        po.boolean('q', "quiet", &quiet, "quiet mode"),
        po.setInt('u', "include-untracked", &include_untracked, 1, "include untracked files in stash"),
        po.setInt('a', "all", &include_untracked, 2, "include ignore files"),
        po.string('m', "message", &stash_msg, "message", "stash message"),
    };
    const argv = po.parse(argv0, &opts, &usage, .{ .keep_dashdash = true });
    if (argv.len > 0) {
        var b: util.Buf = .empty;
        for (argv, 0..) |a, i| {
            if (i > 0) util.bufByte(&b, ' ');
            util.bufAppend(&b, a);
        }
        stash_msg = b.items;
    }
    const ps = Pathspec{};
    checkInteractiveOpts(patch_mode, ctx, ihc, auto_advance);
    return doPushStash(&ps, stash_msg, quiet, push_keep_index, patch_mode, include_untracked, only_staged);
}

// ---------------- dispatch ----------------

pub fn cmdStash(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").stash);
    readConfig();
    stash_index_path = util.fmt("{s}.stash.{d}", .{ repo_mod.repo().indexPath(), getpid() });
    const argv = args[1..];
    if (argv.len == 0) return if (pushStash(&.{}, false) != 0) 1 else 0;
    const sub = argv[0];
    const rest = argv[1..];
    const Sub = struct { name: []const u8, f: *const fn ([]const []const u8) i32 };
    const subs = [_]Sub{
        .{ .name = "apply", .f = cmdApply },
        .{ .name = "clear", .f = cmdClear },
        .{ .name = "drop", .f = cmdDrop },
        .{ .name = "pop", .f = cmdPop },
        .{ .name = "branch", .f = cmdBranch },
        .{ .name = "list", .f = cmdList },
        .{ .name = "show", .f = cmdShow },
        .{ .name = "store", .f = cmdStore },
        .{ .name = "create", .f = cmdCreate },
        .{ .name = "push", .f = pushUnassumed },
        .{ .name = "save", .f = cmdSave },
        .{ .name = "export", .f = cmdExport },
        .{ .name = "import", .f = cmdImport },
    };
    for (subs) |s| {
        if (util.eql(sub, s.name)) {
            const ret = s.f(rest);
            if (ret < 0) return 255;
            return @intCast(ret);
        }
    }
    if (argv.len == 1 and util.eql(sub, "-h")) po.usageExit(&stash_usage, &.{}, false);
    var pargs: std.ArrayList([]const u8) = .empty;
    pargs.appendSlice(gpa, argv) catch util.oom();
    return if (pushStash(pargs.items, true) != 0) 1 else 0;
}

fn pushUnassumed(argv: []const []const u8) i32 {
    return pushStash(argv, false);
}

// ---------------- export / import ----------------

const export_ident = "git stash <git@stash> 1000684800 +0000";

fn checkStashTopology(stash: Oid) bool {
    const c = objects.readCommit(stash) orelse return false;
    if (c.parents.len != 2 and c.parents.len != 3) return false;
    const p1 = objects.readCommit(c.parents[0]) orelse return false;
    const p2 = objects.readCommit(c.parents[1]) orelse return false;
    if (c.parents.len == 3) {
        const p3 = objects.readCommit(c.parents[2]) orelse return false;
        if (p3.parents.len != 0) return false;
    }
    if (p2.parents.len != 1) return false;
    _ = objects.readCommit(p2.parents[0]) orelse return false;
    return hash.eql(p1.oid, p2.parents[0]);
}

fn commitBody(raw: []const u8) ?[]const u8 {
    const p = std.mem.indexOf(u8, raw, "\n\n") orelse return null;
    return raw[p + 2 ..];
}

fn headerValue(headers: []const u8, key: []const u8) ?[]const u8 {
    var it = std.mem.splitScalar(u8, headers, '\n');
    while (it.next()) |line| {
        if (line.len > key.len and std.mem.startsWith(u8, line, key) and line[key.len] == ' ') return line[key.len + 1 ..];
        if (line.len == 0) break;
    }
    return null;
}

fn writeCommitWithParents(oid: Oid, parents: []const Oid) ?Oid {
    const c = objects.readCommit(oid) orelse {
        util.err("cannot parse commit {s}", .{&hash.hex(oid)});
        return null;
    };
    const author = headerValue(c.raw, "author");
    const committer = headerValue(c.raw, "committer");
    if (author == null or committer == null) {
        util.err("cannot parse commit {s}", .{&hash.hex(oid)});
        return null;
    }
    var msg: util.Buf = .empty;
    util.bufAppend(&msg, "git stash: ");
    if (commitBody(c.raw)) |b| util.bufAppend(&msg, b);
    if (msg.items.len > 0 and msg.items[msg.items.len - 1] != '\n') util.bufByte(&msg, '\n');
    return commit_mod.create(.{ .tree = emptyTreeOid(), .parents = parents, .message = msg.items, .author = author, .committer = committer });
}

fn doExportStash(ref: ?[]const u8, argv: []const []const u8) i32 {
    const base = commit_mod.create(.{ .tree = emptyTreeOid(), .message = "", .author = export_ident, .committer = export_ident });
    var items: std.ArrayList(Oid) = .empty;
    if (argv.len > 0) {
        for (argv) |a| {
            const rev = parseStashRevision(a, true) orelse {
                util.err("unable to find stash entry {s}", .{a});
                return -1;
            };
            const oid = revparse.getOid(rev) orelse {
                util.err("unable to find stash entry {s}", .{a});
                return -1;
            };
            if (!checkStashTopology(oid)) {
                util.err("{s} does not look like a stash commit", .{rev});
                return -1;
            }
            items.append(gpa, oid) catch util.oom();
        }
    } else {
        const ents = refs.readReflog(ref_stash);
        var i = ents.len;
        while (i > 0) {
            i -= 1;
            const oid = ents[i].new;
            if (!checkStashTopology(oid)) {
                util.err("{s} does not look like a stash commit", .{&hash.hex(oid)});
                return 0;
            }
            items.append(gpa, oid) catch util.oom();
        }
    }
    std.mem.reverse(Oid, items.items);
    var prev = base;
    for (items.items) |s| {
        prev = writeCommitWithParents(s, &.{ prev, s }) orelse return -1;
    }
    if (ref) |r| {
        refs.updateFlags(r, prev, null, "", 0) catch util.die("{s}", .{refs.last_error});
    } else {
        util.outf("{s}\n", .{&hash.hex(prev)});
    }
    return 0;
}

fn cmdExport(argv: []const []const u8) i32 {
    const usage = [_][]const u8{export_usage_str};
    var print = false;
    var ref: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.noNeg(po.boolean(0, "print", &print, "print the object ID instead of writing it to a ref")),
        po.string(0, "to-ref", &ref, "ref", "save the data to the given ref"),
    };
    const rest = po.parse(argv, &opts, &usage, .{ .keep_dashdash = true });
    if ((!print and ref == null) or (print and ref != null)) {
        util.err("exactly one of --print and --to-ref is required", .{});
        return -1;
    }
    return doExportStash(ref, rest);
}

fn doImportStash(rev: []const u8) i32 {
    const chain = revparse.getOid(rev) orelse {
        util.err("not a valid revision: {s}", .{rev});
        return -1;
    };
    var this = objects.readCommit(chain) orelse {
        util.err("not a commit: {s}", .{rev});
        return -1;
    };
    var items: std.ArrayList(Oid) = .empty;
    while (true) {
        const h = &hash.hex(this.oid);
        if (!hash.eql(this.tree, emptyTreeOid()) or (this.parents.len != 0 and this.parents.len != 2)) {
            util.err("{s} is not a valid exported stash commit", .{h});
            return -1;
        }
        if (this.parents.len == 0) {
            const author = headerValue(this.raw, "author");
            const committer = headerValue(this.raw, "committer");
            if (author == null or committer == null) {
                util.err("cannot parse commit {s}", .{h});
                return 0;
            }
            if (!util.eql(author.?, export_ident) or !util.eql(committer.?, export_ident)) {
                util.err("found root commit {s} with invalid data", .{h});
                return -1;
            }
            break;
        }
        const body = commitBody(this.raw) orelse {
            util.err("cannot parse commit {s}", .{h});
            return -1;
        };
        if (!std.mem.startsWith(u8, body, "git stash: ")) {
            util.err("found stash commit {s} without expected prefix", .{h});
            return -1;
        }
        const stash = this.parents[1];
        const parent = objects.readCommit(this.parents[0]);
        if (parent == null or objects.readCommit(stash) == null) {
            util.err("cannot parse parents of commit: {s}", .{h});
            return -1;
        }
        if (!checkStashTopology(stash)) {
            util.err("{s} does not look like a stash commit", .{&hash.hex(stash)});
            return -1;
        }
        items.append(gpa, stash) catch util.oom();
        this = parent.?;
    }
    // items is newest-first; store oldest first
    var i = items.items.len;
    while (i > 0) {
        i -= 1;
        const oid = items.items[i];
        const c = objects.readCommit(oid) orelse {
            util.err("cannot read commit buffer for {s}", .{&hash.hex(oid)});
            return -1;
        };
        const msg = commitBody(c.raw) orelse {
            util.err("cannot parse commit {s}", .{&hash.hex(oid)});
            return -1;
        };
        if (doStoreStash(oid, msg, true) != 0) {
            util.err("cannot save the stash for {s}", .{&hash.hex(oid)});
            return -1;
        }
    }
    return 0;
}

fn cmdImport(argv: []const []const u8) i32 {
    const usage = [_][]const u8{import_usage_str};
    const opts = [_]po.Opt{};
    const rest = po.parse(argv, &opts, &usage, .{ .keep_dashdash = true });
    if (rest.len != 1) {
        util.eprint("fatal: a revision is required\n\n", .{});
        po.usageExit(&usage, &opts, true);
    }
    return doImportStash(rest[0]);
}

// ---------------- patch mode ----------------

var patch_mode_g = false;
var interactive_opts: add_patch.Options = .{};
var patch_out: util.Buf = .empty;

/// stash_patch(): let the user pick hunks into a temporary index based on HEAD.
fn stashPatch(info: *StashInfo, ps: *const Pathspec, quiet: bool) i32 {
    _ = os.unlink(stash_index_path);
    const env = [_][2][]const u8{.{ "GIT_INDEX_FILE", stash_index_path }};
    defer _ = os.unlink(stash_index_path);
    if (runGit(&.{ "read-tree", &hash.hex(commitTree(info.b_commit)) }, .{ .env = &env }).status != 0) return -1;
    var psargs: std.ArrayList([]const u8) = .empty;
    pathspecArgs(ps, &psargs);
    var ret: i32 = if (add_patch.run(.stash, interactive_opts, null, stash_index_path, psargs.items, 0) != 0) 1 else 0;
    const wt = runGit(&.{"write-tree"}, .{ .env = &env, .capture = true });
    if (wt.status != 0) return -1;
    info.w_tree = hash.fromHex(std.mem.trimEnd(u8, wt.stdout, "\n")) orelse return -1;
    const d = runGit(&.{ "diff-tree", "-p", "-U1", "HEAD", "--no-color", &hash.hex(info.w_tree), "--" }, .{ .capture = true });
    if (d.status != 0) return -1;
    patch_out = .empty;
    patch_out.appendSlice(gpa, d.stdout) catch util.oom();
    if (patch_out.items.len == 0) {
        if (!quiet) util.eprint("No changes selected\n", .{});
        ret = 1;
    }
    return ret;
}

fn checkInteractiveOpts(patch_mode: bool, ctx: i32, ihc: i32, auto_advance: bool) void {
    if (!patch_mode) {
        if (ctx != -1) util.die("the option '{s}' requires '{s}'", .{ "--unified", "--patch" });
        if (ihc != -1) util.die("the option '{s}' requires '{s}'", .{ "--inter-hunk-context", "--patch" });
        if (!auto_advance) util.die("the option '{s}' requires '{s}'", .{ "--no-auto-advance", "--patch" });
    }
    if (ctx < -1) util.die("'{s}' cannot be negative", .{"--unified"});
    if (ihc < -1) util.die("'{s}' cannot be negative", .{"--inter-hunk-context"});
    interactive_opts = .{ .context = ctx, .interhunkcontext = ihc, .auto_advance = auto_advance };
}
