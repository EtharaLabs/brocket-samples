//! Sparse index (sparse-index.c): "sdir" extension, sparse directory entries.
//!
//! A sparse directory entry is an index entry with mode 040000, a trailing
//! '/' in its path, the SKIP_WORKTREE flag and the oid of the tree it stands
//! for. convert_to_sparse() collapses fully skip-worktree directories outside
//! the cone into such entries (using the cache tree), ensure_full_index()
//! expands them again by reading their trees.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const objects = @import("objects.zig");
const sparse = @import("sparse.zig");
const trace2 = @import("trace2.zig");
const index_mod = @import("index.zig");
const gpa = util.gpa;

const Index = index_mod.Index;
const Entry = index_mod.Entry;
const CacheTree = index_mod.CacheTree;

const S_IFMT: u32 = 0o170000;
const S_IFDIR: u32 = 0o040000;
const S_IFGITLINK: u32 = 0o160000;

/// !command_requires_full_index: set by sparse-aware commands before reading.
pub var keep_sparse: bool = false;

/// Set once an index read from disk was sparse (and got expanded). Used by
/// commands that are sparse-aware in C (update-index) to report the
/// split-index incompatibility.
pub var read_sparse: bool = false;
/// set by convertToSparse(): the next ensureFull() undoes our own collapse
var just_converted = false;
/// give_advice_on_expansion
var give_advice_on_expansion = true;
const advice_msg =
    "The sparse index is expanding to a full index, a slow operation.\n" ++
    "Your working directory likely has contents that are outside of\n" ++
    "your sparse-checkout patterns. Use 'git sparse-checkout list' to\n" ++
    "see your sparse-checkout definition and compare it to your working\n" ++
    "directory contents. Cleaning up any merge conflicts or staged\n" ++
    "changes before running 'git sparse-checkout clean' or 'git\n" ++
    "sparse-checkout reapply' may assist in this cleanup.";

/// In-memory overrides used by `git sparse-checkout`, which changes these
/// settings before rewriting the index (repo->settings.sparse_index,
/// core_apply_sparse_checkout, core_sparse_checkout_cone and
/// istate->sparse_checkout_patterns in C).
pub var setting_override: ?bool = null;
pub var apply_override: ?bool = null;
pub var cone_override: ?bool = null;
pub var patterns_override: ?*sparse.Patterns = null;

pub fn isSparseDir(e: *const Entry) bool {
    return e.mode & S_IFMT == S_IFDIR;
}

fn envBoolOpt(name: []const u8) ?bool {
    const v = os.getenv(name) orelse return null;
    return @import("config.zig").parseBool(v) orelse
        util.die("bad boolean environment value '{s}' for '{s}'", .{ v, name });
}

/// set_sparse_index_config()'s in-memory part
pub fn setSetting(enable: bool) void {
    setting_override = enable;
}

fn currentPatterns() ?*sparse.Patterns {
    if (patterns_override) |p| return p;
    const cone = cone_override orelse sparse.configCone();
    return sparse.loadFile(sparse.sparseFilename(), cone);
}

/// is_sparse_index_allowed(istate, flags)
pub fn isAllowed(idx: *Index, memory_only: bool) bool {
    if (repo_mod.repo_ == null) return false;
    const apply = apply_override orelse sparse.configApply();
    const cone = cone_override orelse sparse.configCone();
    if (!apply or !cone) return false;
    if (!memory_only) {
        if (idx.split != null) return false;
        if (envBoolOpt("GIT_TEST_SPLIT_INDEX") orelse false) return false;
        if (envBoolOpt("GIT_TEST_SPARSE_INDEX")) |v| setSetting(v);
        const enabled = setting_override orelse (repo_mod.cfg.getBool("index.sparse") orelse false);
        if (!enabled) return false;
    }
    const pl = currentPatterns() orelse return false;
    if (!pl.use_cone) return false;
    return true;
}

fn cacheTreeFullyValid(t: ?*CacheTree) bool {
    const ct = t orelse return false;
    if (ct.entry_count < 0 or !repo_mod.repo().odb().has(ct.oid)) return false;
    for (ct.children.items) |c| {
        if (!cacheTreeFullyValid(c)) return false;
    }
    return true;
}

/// cache_tree_free() + cache_tree_update(); false on failure
fn rebuildCacheTree(idx: *Index, missing_ok: bool) bool {
    idx.cache_tree = null;
    if (idx.writeTree(missing_ok) != null) return true;
    idx.cache_tree = null;
    return false;
}

/// convert_to_sparse_rec(): returns the number of entries appended to `out`.
fn convertRec(
    pl: *sparse.Patterns,
    ents: []Entry,
    out: *std.ArrayList(Entry),
    start: usize,
    end: usize,
    ct_path: []const u8,
    ct: *CacheTree,
) usize {
    const start_len = out.items.len;
    var can_convert = !pl.pathIn(ct_path, @import("dir.zig").DT_REG);
    var i = start;
    while (can_convert and i < end) : (i += 1) {
        const e = &ents[i];
        if (e.stage() != 0 or e.mode & S_IFMT == S_IFGITLINK or !e.skipWorktree())
            can_convert = false;
    }
    if (can_convert) {
        out.append(gpa, .{
            .mode = S_IFDIR,
            .oid = ct.oid,
            .path = ct_path,
            .ext_flags = index_mod.CE_SKIP_WORKTREE,
        }) catch util.oom();
        return 1;
    }
    i = start;
    while (i < end) {
        const e = ents[i];
        const base = e.path[ct_path.len..];
        const sub: ?*CacheTree = if (std.mem.indexOfScalar(u8, base, '/')) |sl| ct.find(base[0..sl]) else null;
        if (sub == null or sub.?.entry_count < 0) {
            out.append(gpa, e) catch util.oom();
            i += 1;
            continue;
        }
        const sl = std.mem.indexOfScalar(u8, base, '/').?;
        const span: usize = @intCast(sub.?.entry_count);
        const child_path = e.path[0 .. ct_path.len + sl + 1];
        const stop = @min(i + span, end);
        _ = convertRec(pl, ents, out, i, stop, child_path, sub.?);
        i = stop;
    }
    return out.items.len - start_len;
}

/// convert_to_sparse(istate, 0)
pub fn convertToSparse(idx: *Index) void {
    _ = convertToSparseFlags(idx, false);
}

/// convert_to_sparse(istate, flags); returns false when the index stays full.
pub fn convertToSparseFlags(idx: *Index, memory_only: bool) bool {
    if (idx.sparse_index and !idx.sparse_partial) return true;
    if (idx.entries.items.len == 0) return false;
    if (!isAllowed(idx, memory_only)) return false;
    give_advice_on_expansion = false;
    for (idx.entries.items) |*e| {
        if (!e.removed and e.stage() != 0) return false;
    }
    const pl = currentPatterns() orelse return false;

    // drop entries scheduled for removal (they are not written anyway)
    var has_removed = false;
    for (idx.entries.items) |*e| {
        if (e.removed) has_removed = true;
    }
    if (has_removed) {
        var w: usize = 0;
        for (idx.entries.items) |e| {
            if (e.removed) continue;
            idx.entries.items[w] = e;
            w += 1;
        }
        idx.entries.items.len = w;
        idx.cache_tree = null;
    }

    if (!cacheTreeFullyValid(idx.cache_tree)) {
        if (!rebuildCacheTree(idx, true)) return false;
    }

    // remove_fsmonitor()
    idx.fsmonitor_last_update = null;
    idx.fsmonitor_dirty = null;
    idx.fsmonitor_has_run_once = false;

    trace2.regionEnter("index", "convert_to_sparse", true);
    var out: std.ArrayList(Entry) = .empty;
    out.ensureTotalCapacity(gpa, idx.entries.items.len) catch util.oom();
    _ = convertRec(pl, idx.entries.items, &out, 0, idx.entries.items.len, "", idx.cache_tree.?);
    idx.entries = out;
    _ = rebuildCacheTree(idx, false);
    idx.sparse_index = true;
    idx.sparse_partial = false;
    just_converted = true;
    trace2.regionLeave("index", "convert_to_sparse", true);
    return true;
}

fn addTree(out: *std.ArrayList(Entry), tree: hash.Oid, base: []const u8, pl: ?*sparse.Patterns) void {
    const ents = objects.readTree(tree) orelse return;
    for (ents) |te| {
        if (te.isDir()) {
            const sub = util.concat(&.{ base, te.name, "/" });
            if (pl) |p| {
                // add_path_to_index(): pad with "-" so the directory is
                // matched as if it contained a file.
                if (p.matches(util.concat(&.{ sub, "-" }), @import("dir.zig").DT_REG) == .not_matched) {
                    out.append(gpa, .{
                        .mode = S_IFDIR,
                        .oid = te.oid,
                        .path = sub,
                        .ext_flags = index_mod.CE_SKIP_WORKTREE,
                    }) catch util.oom();
                    continue;
                }
            }
            addTree(out, te.oid, sub, pl);
            continue;
        }
        out.append(gpa, .{
            .mode = te.mode,
            .oid = te.oid,
            .path = util.concat(&.{ base, te.name }),
            .ext_flags = index_mod.CE_SKIP_WORKTREE,
        }) catch util.oom();
    }
}

/// ensure_full_index() (expand_index(istate, NULL))
pub fn ensureFull(idx: *Index) void {
    expandIndex(idx, null);
}

/// expand_index(): expand the sparse directories matched by `pl` (all of
/// them when `pl` is null). With a pattern list the index may stay
/// partially sparse.
pub fn expandIndex(idx: *Index, pl0: ?*sparse.Patterns) void {
    if (!idx.sparse_index) return;
    var pl = pl0;
    if (pl) |p| {
        if (!p.use_cone) pl = null;
    }
    if (pl != null) {
        if (!rebuildCacheTree(idx, false)) pl = null;
    }
    if (pl == null) {
        if (!just_converted) read_sparse = true;
        just_converted = false;
        if (give_advice_on_expansion) {
            give_advice_on_expansion = false;
            @import("advice.zig").adviseIfEnabled("sparseIndexExpanded", advice_msg);
        }
    }
    const region: []const u8 = if (pl != null) "expand_index" else "ensure_full_index";
    trace2.regionEnter("index", region, true);
    var out: std.ArrayList(Entry) = .empty;
    out.ensureTotalCapacity(gpa, idx.entries.items.len) catch util.oom();
    for (idx.entries.items) |e| {
        if (!isSparseDir(&e)) {
            out.append(gpa, e) catch util.oom();
            continue;
        }
        if (pl) |p| {
            if (p.matches(e.path, @import("dir.zig").DT_DIR) == .not_matched) {
                out.append(gpa, e) catch util.oom();
                continue;
            }
        }
        if (!e.skipWorktree())
            util.warn("index entry is a directory, but not sparse ({x:0>8})", .{@as(u32, e.flags) | (@as(u32, e.ext_flags) << 16)});
        addTree(&out, e.oid, e.path, pl);
    }
    idx.entries = out;
    idx.sparse_index = pl != null;
    idx.sparse_partial = pl != null;
    idx.fsmonitor_has_run_once = false;
    idx.fsmonitor_dirty = null;
    idx.fsmonitor_last_update = null;
    _ = rebuildCacheTree(idx, false);
    trace2.regionLeave("index", region, true);
}

/// ensure_correct_sparsity()
pub fn ensureCorrectSparsity(idx: *Index) void {
    if (isAllowed(idx, false)) convertToSparse(idx) else ensureFull(idx);
}

/// Mark the running command as sparse-index aware
/// (`settings.command_requires_full_index = 0`). Call before reading the
/// index.
pub fn commandIsSparseAware() void {
    keep_sparse = true;
}

/// index_file_exists() without expansion: any stage, exact name.
fn entryExists(idx: *Index, path: []const u8, icase: bool) bool {
    if (icase) {
        for (idx.entries.items) |*e| {
            if (std.ascii.eqlIgnoreCase(e.path, path)) return true;
        }
        return false;
    }
    const i = idx.firstPosNoExpand(path);
    return i < idx.entries.items.len and util.eql(idx.entries.items[i].path, path);
}

var in_expand_to_path = false;

/// expand_to_path(): expand the index if `path` is not in it but some
/// parent directory of it is a sparse directory entry.
pub fn expandToPath(idx: *Index, path: []const u8, icase: bool) void {
    if (in_expand_to_path or !idx.sparse_index) return;
    in_expand_to_path = true;
    defer in_expand_to_path = false;
    if (entryExists(idx, path, icase)) return;
    var i: usize = 0;
    while (i < path.len) : (i += 1) {
        if (path[i] != '/') continue;
        if (entryExists(idx, path[0 .. i + 1], icase)) {
            ensureFull(idx);
            return;
        }
    }
}

/// index_name_pos_sparse(): position of `path` (stage 0) without expanding;
/// negative semantics as a union.
pub fn namePosSparse(idx: *Index, path: []const u8) index_mod.Pos {
    return idx.posNoExpand(path, 0);
}

// ---------------- clear_skip_worktree_from_present_files ----------------

const PathFound = struct {
    dir: util.Buf = .empty,
    lstat_count: i64 = 0,
};

fn maxCommonDirPrefix(a: []const u8, b: []const u8) usize {
    var common: usize = 0;
    var i: usize = 0;
    while (i < a.len and i < b.len) : (i += 1) {
        if (a[i] != b[i]) break;
        if (a[i] == '/') common = i + 1;
    }
    return common;
}

fn pathFound(path: []const u8, data: *PathFound) bool {
    if (data.dir.items.len > 0 and util.startsWith(path, data.dir.items)) return false;
    data.lstat_count += 1;
    if (os.lstatPath(path) != null) return true;
    const common = maxCommonDirPrefix(path, data.dir.items);
    data.dir.items.len = common;
    while (true) {
        const rest = path[data.dir.items.len..];
        const slash = std.mem.indexOfScalar(u8, rest, '/') orelse {
            util.bufAppend(&data.dir, rest);
            util.bufByte(&data.dir, '/');
            break;
        };
        util.bufAppend(&data.dir, rest[0 .. slash + 1]);
        data.lstat_count += 1;
        if (os.lstatPath(data.dir.items) == null) return false;
    }
    return false;
}

fn clearPresentSparse(idx: *Index) bool {
    var data = PathFound{};
    var path_count: i64 = 0;
    var restart = false;
    trace2.regionEnter("index", "clear_skip_worktree_from_present_files_sparse", true);
    for (idx.entries.items) |*e| {
        if (!e.skipWorktree()) continue;
        path_count += 1;
        if (pathFound(e.path, &data)) {
            if (isSparseDir(e)) {
                restart = true;
                break;
            }
            e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
        }
    }
    trace2.dataInt("index", true, "sparse_path_count", path_count);
    trace2.dataInt("index", true, "sparse_lstat_count", data.lstat_count);
    trace2.regionLeave("index", "clear_skip_worktree_from_present_files_sparse", true);
    return restart;
}

fn clearPresentFull(idx: *Index) void {
    var data = PathFound{};
    var path_count: i64 = 0;
    trace2.regionEnter("index", "clear_skip_worktree_from_present_files_full", true);
    for (idx.entries.items) |*e| {
        if (isSparseDir(e)) util.die("BUG: ensure-full-index did not fully flatten?", .{});
        if (!e.skipWorktree()) continue;
        path_count += 1;
        if (pathFound(e.path, &data)) e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
    }
    trace2.dataInt("index", true, "full_path_count", path_count);
    trace2.dataInt("index", true, "full_lstat_count", data.lstat_count);
    trace2.regionLeave("index", "clear_skip_worktree_from_present_files_full", true);
}

/// clear_skip_worktree_from_present_files(): unless
/// sparse.expectFilesOutsideOfPatterns, drop SKIP_WORKTREE from entries
/// whose file exists in the working tree.
pub fn clearSkipWorktreeFromPresentFiles(idx: *Index) void {
    if (repo_mod.repo_ == null or repo_mod.repo().work_tree == null) return;
    if (!sparse.configApply()) return;
    if (repo_mod.cfg.getBool("sparse.expectfilesoutsideofpatterns") orelse false) return;
    if (clearPresentSparse(idx)) {
        ensureFull(idx);
        clearPresentFull(idx);
    }
}
