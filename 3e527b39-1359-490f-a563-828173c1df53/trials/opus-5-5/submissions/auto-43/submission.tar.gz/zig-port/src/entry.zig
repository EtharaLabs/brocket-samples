//! Port of entry.c (checkout_entry, unlink_entry) and the bits of symlinks.c
//! (check_leading_path, has_dirs_only_path, scheduled directory removal) it needs.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const convert = @import("convert.zig");
const submodule = @import("submodule.zig");
const gpa = util.gpa;

const Entry = index_mod.Entry;
const Index = index_mod.Index;

pub const State = struct {
    base_dir: []const u8 = "",
    force: bool = false,
    quiet: bool = false,
    not_new: bool = false,
    refresh_cache: bool = false,
    clone: bool = false,
    istate: ?*Index = null,
    /// checkout metadata handed to process filters (blob is filled per entry)
    meta: convert.Meta = .{},
    /// delayed checkout queue (enableDelayedCheckout)
    dco: ?*convert.Dco = null,
    /// set by writeEntry() when the filter delayed the entry
    delayed: bool = false,
};

// ---------------- symlinks.c helpers ----------------

/// check_leading_path(): 0 if a leading component is missing, -1 if all
/// leading components are directories, else the length of the first leading
/// component that exists but is not a directory (or failed to lstat).
pub fn checkLeadingPath(name: []const u8, warn_on_err: bool) isize {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, name, i, '/')) |sl| {
        const comp = name[0..sl];
        if (os.lstatPath(comp)) |st| {
            if (!st.isDir()) return @intCast(sl);
        } else {
            const e = os.errno();
            if (e == os.ENOENT or e == os.ENOTDIR) return 0;
            if (warn_on_err) util.warn("failed to lstat '{s}': {s}", .{ comp, os.strErr(e) });
            return @intCast(sl);
        }
        i = sl + 1;
    }
    return -1;
}

/// has_dirs_only_path(): all components of name[0..len] are directories
/// (stat() is used for the first prefix_len bytes).
pub fn hasDirsOnlyPath(name: []const u8, prefix_len: usize) bool {
    if (name.len == 0) return true;
    var i: usize = 0;
    while (true) {
        const end = std.mem.indexOfScalarPos(u8, name, i, '/') orelse name.len;
        const comp = name[0..end];
        if (comp.len > 0) {
            const st = (if (end <= prefix_len) os.statPath(comp) else os.lstatPath(comp)) orelse return false;
            if (!st.isDir()) return false;
        }
        if (end >= name.len) return true;
        i = end + 1;
    }
}

var removal: util.Buf = .empty;

pub fn originalCwd() ?[]const u8 {
    const r = repo_mod.repo_ orelse return null;
    if (r.prefix.len == 0) return null;
    return r.prefix[0 .. r.prefix.len - 1];
}

fn doRemoveScheduledDirs(new_len: usize) void {
    const cwd = originalCwd();
    var len = removal.items.len;
    while (len > new_len) {
        const d = removal.items[0..len];
        if (cwd != null and util.eql(d, cwd.?)) break;
        if (!os.rmdir(d)) break;
        len -= 1;
        while (len > new_len and removal.items[len] != '/') len -= 1;
    }
    removal.items.len = new_len;
}

fn longestPathMatch(a: []const u8, b: []const u8) usize {
    const max = @min(a.len, b.len);
    var match: usize = 0;
    var i: usize = 0;
    while (i < max and a[i] == b[i]) : (i += 1) {
        if (a[i] == '/') match = i;
    }
    if (i >= max and ((a.len > b.len and a[b.len] == '/') or (a.len < b.len and b[a.len] == '/') or a.len == b.len)) match = i;
    return match;
}

pub fn scheduleDirForRemoval(name: []const u8) void {
    if (originalCwd()) |cwd| {
        if (util.eql(name, cwd)) return;
    }
    const match = longestPathMatch(name, removal.items);
    var last_slash = match;
    var i = match;
    while (i < name.len) : (i += 1) {
        if (name[i] == '/') last_slash = i;
    }
    if (match < last_slash and match < removal.items.len) doRemoveScheduledDirs(match);
    if (match < last_slash) util.bufAppend(&removal, name[match..last_slash]);
}

pub fn removeScheduledDirs() void {
    doRemoveScheduledDirs(0);
}

// ---------------- entry.c ----------------

fn createDirectories(path: []const u8, st: *const State) void {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, path, i, '/')) |sl| {
        const d = path[0..sl];
        i = sl + 1;
        if (d.len == 0) continue;
        if (hasDirsOnlyPath(d, st.base_dir.len)) continue;
        if (!os.mkdir(d, 0o777)) {
            if (os.errno() == os.EEXIST and st.force and os.unlink(d) and os.mkdir(d, 0o777)) continue;
            util.dieErrno("cannot create directory at '{s}'", .{d});
        }
    }
}

fn removeSubtree(path: []const u8) void {
    const ents = os.listDir(path) orelse util.dieErrno("cannot opendir '{s}'", .{path});
    for (ents) |de| {
        const p = util.concat(&.{ path, "/", de.name });
        const st = os.lstatPath(p) orelse util.dieErrno("cannot lstat '{s}'", .{p});
        if (st.isDir()) {
            removeSubtree(p);
        } else if (!os.unlink(p)) util.dieErrno("cannot unlink '{s}'", .{p});
    }
    if (!os.rmdir(path)) util.dieErrno("cannot rmdir '{s}'", .{path});
}

pub fn readBlob(oid: hash.Oid) ?[]const u8 {
    const obj = repo_mod.repo().odb().read(oid) orelse return null;
    if (obj.typ != .blob) return null;
    return obj.data;
}

fn hasSymlinks() bool {
    return repo_mod.cfg.getBool("core.symlinks") orelse true;
}

/// Open output file for an entry; to_tempfile creates .merge_file_XXXXXX in cwd.
fn openOutput(path: *[]const u8, e: *const Entry, to_tempfile: bool) c_int {
    const is_symlink = e.mode & os.S_IFMT != os.S_IFREG;
    if (to_tempfile) {
        const t = os.tmpFile(".", if (is_symlink) ".merge_link_" else ".merge_file_");
        // strip the leading "./"
        path.* = t.path[2..];
        return t.fd;
    }
    const mode: c_uint = if (!is_symlink and e.mode & 0o100 != 0) 0o777 else 0o666;
    return os.openFile(path.*, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode);
}

fn writeEntry(e: *Entry, path_in: []const u8, st: *State, to_tempfile: bool, nr_checkouts: ?*usize) ?[]const u8 {
    var path = path_in;
    st.delayed = false;
    const fmt = e.mode & os.S_IFMT;
    switch (fmt) {
        os.S_IFLNK, os.S_IFREG => {
            const retry = fmt == os.S_IFREG and st.dco != null and st.dco.?.state == .retry;
            const blob = if (retry) "" else readBlob(e.oid) orelse {
                util.err("unable to read sha1 file of {s} ({s})", .{ e.path, &hash.hex(e.oid) });
                return null;
            };
            var data: []const u8 = blob;
            if (fmt == os.S_IFLNK and hasSymlinks() and !to_tempfile) {
                if (!os.symlink(blob, path)) {
                    util.err("unable to create symlink {s}: {s}", .{ path, os.lastErr() });
                    return null;
                }
            } else {
                if (fmt == os.S_IFREG) {
                    var meta = st.meta;
                    meta.blob = e.oid;
                    if (st.dco != null and st.dco.?.state != .no_delay) {
                        const d = st.dco.?;
                        const ca = convert.convertAttrs(e.path);
                        data = convert.toWorktreeCaMeta(&ca, e.path, blob, &meta, d);
                        if (d.findPath(e.path)) |i| {
                            d.paths.items[i].marked = true;
                            d.paths.items[i].nr = nr_checkouts;
                            st.delayed = true;
                            return path;
                        }
                    } else data = convert.toWorktreeMeta(e.path, blob, &meta);
                }
                const fd = openOutput(&path, e, to_tempfile);
                if (fd < 0) {
                    util.err("unable to create file {s}: {s}", .{ path, os.lastErr() });
                    return null;
                }
                const ok = if (os.writeAll(fd, data)) true else |_| false;
                var fst: ?os.Stat = null;
                if (!to_tempfile and st.refresh_cache and st.base_dir.len == 0) fst = os.fstatFd(fd);
                os.close(fd);
                if (!ok) {
                    util.err("unable to write file {s}", .{path});
                    return null;
                }
                if (fst) |s| {
                    if (st.refresh_cache) {
                        e.fillStat(s);
                        e.uptodate = true;
                        e.fsmonitor_valid = false;
                        if (st.istate) |ix| ix.changed = true;
                    }
                    return path;
                }
            }
        },
        os.S_IFGITLINK => {
            if (to_tempfile) {
                util.err("cannot create temporary submodule {s}", .{e.path});
                return null;
            }
            if (!os.mkdir(path, 0o777)) {
                util.err("cannot create submodule directory {s}", .{path});
                return null;
            }
            if (submodule.fromCe(e) != null) {
                const hx = hash.hex(e.oid);
                if (submodule.moveHead(e.path, null, &hx, if (st.force) submodule.MOVE_HEAD_FORCE else 0) != 0) return null;
                return path;
            }
        },
        else => {
            util.err("unknown file mode for {s} in index", .{e.path});
            return null;
        },
    }
    if (st.refresh_cache) {
        const s = os.lstatPath(e.path) orelse {
            util.err("unable to stat just-written file {s}: {s}", .{ e.path, os.lastErr() });
            return null;
        };
        e.fillStat(s);
        if (s.isReg()) e.uptodate = true;
        e.fsmonitor_valid = false;
        if (st.istate) |ix| ix.changed = true;
    }
    return path;
}

/// ie_match_stat with CE_MATCH_IGNORE_VALID | CE_MATCH_IGNORE_SKIP_WORKTREE.
pub fn matchStatIgnoreValid(idx: ?*const Index, e: *const Entry, st: os.Stat) u32 {
    if (e.intentToAdd()) return index_mod.DATA_CHANGED | index_mod.TYPE_CHANGED | index_mod.MODE_CHANGED;
    var changed = index_mod.matchStatBasic(e, st);
    if (changed == 0) {
        if (idx) |ix| {
            if (ix.isRacy(e) and index_mod.contentChanged(e, st)) changed |= index_mod.DATA_CHANGED;
        }
    }
    return changed;
}

/// Last temp file name written by checkoutEntryTemp.
pub var last_temp_path: []const u8 = "";

/// checkout_entry(); returns true on error.
pub fn checkoutEntry(e: *Entry, st: *State, nr_checkouts: ?*usize) bool {
    const path = util.concat(&.{ st.base_dir, e.path });
    if (blk: {
        // check_path()
        const slash = std.mem.lastIndexOfScalar(u8, path, '/') orelse 0;
        if (!hasDirsOnlyPath(path[0..slash], st.base_dir.len)) break :blk null;
        break :blk os.lstatPath(path);
    }) |s| {
        const changed = matchStatIgnoreValid(st.istate, e, s);
        if (submodule.fromCe(e) != null) {
            const hx = hash.hex(e.oid);
            if (!submodule.isPopulatedGently(e.path, true)) {
                if (os.lstatPath(e.path) == null) util.die("could not stat file '{s}'", .{e.path});
                if (!s.isDir()) {
                    if (!os.unlink(e.path) and os.errno() != os.ENOENT) util.warn("unable to unlink '{s}': {s}", .{ e.path, os.lastErr() });
                }
                return submodule.moveHead(e.path, null, &hx, 0) != 0;
            }
            return submodule.moveHead(e.path, "HEAD", &hx, if (st.force) submodule.MOVE_HEAD_FORCE else 0) != 0;
        }
        if (changed == 0) return false;
        if (!st.force) {
            if (!st.quiet) util.eprint("{s} already exists, no checkout\n", .{path});
            return true;
        }
        if (s.isDir()) {
            if (e.mode & os.S_IFMT == os.S_IFGITLINK) return false;
            removeSubtree(path);
        } else if (!os.unlink(path)) {
            util.err("unable to unlink old '{s}': {s}", .{ path, os.lastErr() });
            return true;
        }
    } else if (st.not_new) return false;
    createDirectories(path, st);
    const pc = @import("parallel_checkout.zig");
    if (pc.accepting() and e.mode & os.S_IFMT == os.S_IFREG) {
        const ca = convert.convertAttrs(e.path);
        if (pc.enqueue(e, &ca, nr_checkouts)) return false;
    }
    if (writeEntry(e, path, st, false, nr_checkouts) == null) return true;
    if (st.delayed) return false;
    if (nr_checkouts) |n| n.* += 1;
    return false;
}

/// checkout_entry() with a topath: write to a temporary file; returns the
/// temp file name or null on error.
pub fn checkoutEntryTemp(e: *Entry, st: *State) ?[]const u8 {
    return writeEntry(e, "", st, true, null);
}

/// unlink_entry()
pub fn unlinkEntry(e: *const Entry) void {
    if (submodule.fromCe(e) != null) _ = submodule.moveHead(e.path, "HEAD", null, submodule.MOVE_HEAD_FORCE);
    if (checkLeadingPath(e.path, true) >= 0) return;
    if (e.mode & os.S_IFMT == os.S_IFGITLINK) {
        if (!os.rmdir(e.path)) {
            const er = os.errno();
            if (er != os.ENOENT) {
                util.warn("unable to rmdir '{s}': {s}", .{ e.path, os.strErr(er) });
                return;
            }
        }
    } else if (!os.unlink(e.path)) {
        const er = os.errno();
        if (er != os.ENOENT) {
            util.warn("unable to unlink '{s}': {s}", .{ e.path, os.strErr(er) });
            return;
        }
    }
    scheduleDirForRemoval(e.path);
}

/// enable_delayed_checkout()
pub fn enableDelayedCheckout(st: *State) void {
    if (st.dco != null) return;
    const d = gpa.create(convert.Dco) catch util.oom();
    d.* = .{};
    st.dco = d;
}

/// finish_delayed_checkout(); returns true on errors.
pub fn finishDelayedCheckout(st: *State, show_progress: bool) bool {
    const d = st.dco orelse return false;
    const cp = @import("convert_process.zig");
    const progress = @import("progress.zig");
    var errs = false;
    var processed: u64 = 0;
    var filtered_bytes: u64 = 0;
    d.state = .retry;
    var prog: ?*progress.Progress = null;
    if (show_progress) prog = progress.startDelayed("Filtering content", d.paths.items.len);
    while (d.filters.items.len > 0) {
        var fi: usize = 0;
        const filters = d.filters.items;
        var keep: std.ArrayList([]const u8) = .empty;
        while (fi < filters.len) : (fi += 1) {
            const filter = filters[fi];
            var available: std.ArrayList([]const u8) = .empty;
            if (!cp.queryAvailableBlobs(filter, &available)) {
                errs = true;
                continue;
            }
            if (available.items.len == 0) continue;
            // remove the available paths from dco.paths, remembering their util
            var marks = gpa.alloc(?convert.DelayedPath, available.items.len) catch util.oom();
            for (marks) |*m| m.* = null;
            var w: usize = 0;
            for (d.paths.items) |item| {
                var hit: ?usize = null;
                for (available.items, 0..) |a, ai| {
                    if (util.eql(a, item.path)) {
                        hit = ai;
                        break;
                    }
                }
                if (hit) |ai| {
                    marks[ai] = item;
                } else {
                    d.paths.items[w] = item;
                    w += 1;
                }
            }
            d.paths.items.len = w;
            var drop_filter = false;
            for (available.items, 0..) |a, ai| {
                const m = marks[ai];
                if (m == null or !m.?.marked) {
                    util.err("external filter '{s}' signaled that '{s}' is now available although it has not been delayed earlier", .{ filter, a });
                    errs = true;
                    drop_filter = true;
                    continue;
                }
                const ix = st.istate orelse index_mod.get();
                if (ix.get(a)) |ce| {
                    processed += 1;
                    progress.update(prog, processed);
                    if (checkoutEntry(ce, st, m.?.nr)) errs = true;
                    filtered_bytes += ce.size;
                } else errs = true;
            }
            if (!drop_filter) keep.append(gpa, filter) catch util.oom();
        }
        d.filters = keep;
    }
    progress.stop(&prog);
    _ = filtered_bytes;
    if (d.paths.items.len > 0) errs = true;
    for (d.paths.items) |item| util.err("'{s}' was not filtered properly", .{item.path});
    st.dco = null;
    return errs;
}
