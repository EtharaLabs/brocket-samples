//! git checkout / git switch / git restore (builtin/checkout.c)

const std = @import("std");
const add_patch = @import("../add_patch.zig");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const advice = @import("../advice.zig");
const cn = @import("../commitnode.zig");
const pretty = @import("../pretty.zig");
const revision = @import("../revision.zig");
const ut = @import("../unpacktrees.zig");
const entry = @import("../entry.zig");
const hook = @import("../hook.zig");
const xdiff = @import("../xdiff.zig");
const attr = @import("../attr.zig");
const wtstatus = @import("../wtstatus.zig");
const proc = @import("../proc.zig");
const tracking = @import("../tracking.zig");
const branchstate = @import("../branchstate.zig");
const bc = @import("../branchcreate.zig");
const submodule = @import("../submodule.zig");
const sparse_index_mod = @import("../sparse_index.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Entry = index_mod.Entry;
const Index = index_mod.Index;
const Commit = cn.Commit;
const Track = bc.Track;

/// in-core flag (uflags) marking entries selected by the pathspec
const CE_MATCHED: u32 = 1 << 20;

const Command = enum { checkout, @"switch", restore };

const Opts = struct {
    patch_mode: bool = false,
    patch_context: i32 = -1,
    patch_interhunk_context: i32 = -1,
    auto_advance: bool = true,
    quiet: i32 = 0,
    merge: i32 = -1,
    force: i32 = 0,
    force_detach: bool = false,
    implicit_detach: bool = false,
    writeout_stage: i32 = 0,
    overwrite_ignore: bool = true,
    ignore_skipworktree: bool = false,
    ignore_other_worktrees: bool = false,
    show_progress: i32 = -1,
    count_checkout_paths: bool = false,
    overlay_mode: i32 = -1,
    dwim_new_local_branch: bool = false,
    discard_changes: bool = false,
    accept_ref: bool = false,
    accept_pathspec: bool = false,
    switch_branch_doing_nothing_is_ok: bool = false,
    only_merge_on_switching_branches: bool = false,
    can_switch_when_in_progress: bool = false,
    orphan_from_empty_tree: bool = false,
    empty_pathspec_ok: bool = false,
    checkout_index: i32 = 0,
    checkout_worktree: i32 = 0,
    ignore_unmerged_opt: []const u8 = "",
    ignore_unmerged: bool = false,
    pathspec_file_nul: bool = false,
    pathspec_from_file: ?[]const u8 = null,

    new_branch: ?[]const u8 = null,
    new_branch_force: ?[]const u8 = null,
    new_orphan_branch: ?[]const u8 = null,
    new_branch_log: bool = false,
    track: Track = .unspecified,
    conflict_style: i32 = -1,

    branch_exists: bool = false,
    prefix: []const u8 = "",
    pathspec: pathspec_mod.Pathspec = .{},
    from_treeish: ?[]const u8 = null,
    source_tree: ?Oid = null,
};

var opts: Opts = .{};
var cb_option: u8 = 'b';

const BranchInfo = struct {
    name: ?[]const u8 = null,
    path: ?[]const u8 = null,
    commit: ?*Commit = null,
    refname: ?[]const u8 = null,
    oid: Oid = hash.zero,
};

const MERGE_WORKING_TREE_UNPACK_FAILED: i32 = -2;

fn quiet() bool {
    return opts.quiet > 0;
}

fn commitOid(c: ?*Commit) Oid {
    return if (c) |x| x.oid() else hash.zero;
}

fn emptyTree() Oid {
    return hash.fromHex(hash.empty_tree_hex).?;
}

fn postCheckoutHook(old: ?*Commit, new: ?*Commit, changed: bool) u8 {
    const a = hash.hex(commitOid(old));
    const b = hash.hex(commitOid(new));
    return hook.run("post-checkout", &.{ util.dupe(&a), util.dupe(&b), if (changed) "1" else "0" }, .{});
}

// ---------------------------------------------------------------------------
// checkout paths

fn removeMarked(idx: *Index) void {
    var i = idx.entries.items.len;
    while (i > 0) {
        i -= 1;
        if (idx.entries.items[i].uflags & ut.CE_REMOVE != 0) {
            idx.removeAt(i);
        }
    }
}

/// read_tree() walk for update_some(): directories go through
/// try_update_sparse_directory(), which does not descend into sparse
/// directory entries whose tree already matches (or, in no-overlay mode,
/// replaces their tree directly).
fn flattenTreeSome(idx: *Index, tree: Oid, prefix: []const u8, out: *std.ArrayList(objects.FlatEntry)) void {
    const entries = objects.readTree(tree) orelse return;
    for (entries) |e| {
        const p = if (prefix.len == 0) util.dupe(e.name) else util.concat(&.{ prefix, "/", e.name });
        if (!e.isDir()) {
            out.append(gpa, .{ .path = p, .mode = e.mode, .oid = e.oid }) catch util.oom();
            continue;
        }
        if (!opts.pathspec.couldMatchUnder(p)) continue;
        if (idx.sparse_index) {
            const dp = util.concat(&.{ p, "/" });
            switch (idx.posNoExpand(dp, 0)) {
                .found => |k| {
                    const old = &idx.entries.items[k];
                    // try_update_sparse_directory(): an identical tree needs no
                    // descent. C also swaps the oid in no-overlay mode, but that
                    // diverges from a full index (skip-worktree entries lose the
                    // bit there), so descend and let the add expand instead.
                    if (sparse_index_mod.isSparseDir(old) and hash.eql(old.oid, e.oid)) continue;
                },
                .missing => {},
            }
        }
        flattenTreeSome(idx, e.oid, p, out);
    }
}

/// read_tree_some() + update_some()
fn readTreeSome(idx: *Index, tree: Oid) void {
    var flat: std.ArrayList(objects.FlatEntry) = .empty;
    flattenTreeSome(idx, tree, "", &flat);
    for (flat.items) |fe| {
        if (!opts.pathspec.matches(fe.path, false)) continue;
        const mode = index_mod.canonMode(fe.mode);
        // expanding lookup: flattenTreeSome only descends into sparse
        // directories whose tree differs, which must be expanded anyway
        switch (idx.pos(fe.path, 0)) {
            .found => |i| {
                const old = &idx.entries.items[i];
                if (old.mode == mode and !old.intentToAdd() and hash.eql(old.oid, fe.oid)) {
                    old.uflags |= ut.CE_UPDATE;
                    continue;
                }
            },
            .missing => {},
        }
        var e = Entry{ .path = fe.path, .mode = mode, .oid = fe.oid };
        e.uflags = ut.CE_UPDATE;
        _ = idx.add(e, .{ .ok_to_add = true, .ok_to_replace = true });
    }
}

fn ceIsDir(e: *const Entry) bool {
    const t = e.mode & os.S_IFMT;
    return t == os.S_IFDIR or t == os.S_IFGITLINK;
}

fn markOverlay(e: *Entry, seen: []u8) void {
    e.uflags &= ~CE_MATCHED;
    if (!opts.ignore_skipworktree and e.skipWorktree()) return;
    if (opts.source_tree != null and e.uflags & ut.CE_UPDATE == 0) return;
    if (opts.pathspec.matchSeen(e.path, ceIsDir(e), seen) != 0) e.uflags |= CE_MATCHED;
}

fn markNoOverlay(e: *Entry, seen: []u8) void {
    e.uflags &= ~CE_MATCHED;
    if (!opts.ignore_skipworktree and e.skipWorktree()) return;
    if (opts.pathspec.matchSeen(e.path, ceIsDir(e), seen) != 0) {
        e.uflags |= CE_MATCHED;
        if (opts.source_tree != null and e.uflags & ut.CE_UPDATE == 0)
            e.uflags |= ut.CE_REMOVE | ut.CE_WT_REMOVE;
    }
}

fn skipSameName(idx: *Index, pos: usize) usize {
    var p = pos + 1;
    const name = idx.entries.items[pos].path;
    while (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, name)) p += 1;
    return p;
}

fn checkStage(idx: *Index, stage: i32, pos: usize, overlay: bool) bool {
    const name = idx.entries.items[pos].path;
    var p = pos;
    while (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, name)) : (p += 1) {
        if (idx.entries.items[p].stage() == @as(u32, @intCast(stage))) return false;
    }
    if (!overlay) return false;
    if (stage == 2) {
        util.err("path '{s}' does not have our version", .{name});
    } else util.err("path '{s}' does not have their version", .{name});
    return true;
}

fn checkStages(idx: *Index, stages: u32, pos: usize) bool {
    const name = idx.entries.items[pos].path;
    var seen: u32 = 0;
    var p = pos;
    while (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, name)) : (p += 1) {
        seen |= @as(u32, 1) << @intCast(idx.entries.items[p].stage());
    }
    if (stages & seen != stages) {
        util.err("path '{s}' does not have all necessary versions", .{name});
        return true;
    }
    return false;
}

/// checkout_entry() including the CE_WT_REMOVE case
fn checkoutOne(e: *Entry, st: *entry.State, n: ?*usize) bool {
    if (e.uflags & ut.CE_WT_REMOVE != 0) {
        entry.unlinkEntry(e);
        return false;
    }
    return entry.checkoutEntry(e, st, n);
}

fn checkoutStage(idx: *Index, stage: i32, pos: usize, st: *entry.State, n: *usize, overlay: bool) bool {
    const name = idx.entries.items[pos].path;
    var p = pos;
    while (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, name)) : (p += 1) {
        if (idx.entries.items[p].stage() == @as(u32, @intCast(stage)))
            return checkoutOne(&idx.entries.items[p], st, n);
    }
    if (!overlay) {
        entry.unlinkEntry(&idx.entries.items[pos]);
        return false;
    }
    if (stage == 2) {
        util.err("path '{s}' does not have our version", .{name});
    } else util.err("path '{s}' does not have their version", .{name});
    return true;
}

fn isBinary(data: []const u8) bool {
    const n = @min(data.len, 8000);
    return std.mem.indexOfScalar(u8, data[0..n], 0) != null;
}

fn parseConflictStyleName(s: []const u8) i32 {
    if (util.eql(s, "merge")) return 0;
    if (util.eql(s, "diff3")) return 1;
    if (util.eql(s, "zdiff3")) return 2;
    return -1;
}

fn configConflictStyle() i32 {
    const v = repo_mod.cfg.get("merge.conflictstyle") orelse return -1;
    const s = parseConflictStyleName(v);
    if (s < 0) util.die("unknown style '{s}' given for '{s}'", .{ v, "merge.conflictstyle" });
    return s;
}

fn readBlobOrEmpty(oid: Oid) []const u8 {
    if (hash.isZero(oid)) return "";
    return entry.readBlob(oid) orelse "";
}

/// checkout_merged(); returns true on error
fn checkoutMerged(idx: *Index, pos0: usize, st: *entry.State, n: *usize) bool {
    const path = idx.entries.items[pos0].path;
    var threeway: [3]Oid = .{ hash.zero, hash.zero, hash.zero };
    var mode: u32 = 0;
    var pos = pos0;
    while (pos < idx.entries.items.len) : (pos += 1) {
        const ce = &idx.entries.items[pos];
        const stage = ce.stage();
        if (stage == 0 or !util.eql(path, ce.path)) break;
        threeway[stage - 1] = ce.oid;
        if (stage == 2) mode = index_mod.canonMode(ce.mode);
    }
    if (hash.isZero(threeway[1]) or hash.isZero(threeway[2])) {
        util.err("path '{s}' does not have necessary versions", .{path});
        return true;
    }
    const ancestor = readBlobOrEmpty(threeway[0]);
    const ours = readBlobOrEmpty(threeway[1]);
    const theirs = readBlobOrEmpty(threeway[2]);

    // ll_merge(): pick the driver from the "merge" attribute
    const mattr = attr.get(path, "merge");
    var binary = attr.isUnset(mattr);
    var favor: xdiff.MergeFavor = .none;
    switch (mattr) {
        .value => |v| {
            if (util.eql(v, "binary")) binary = true else if (util.eql(v, "union")) favor = .union_;
        },
        else => {},
    }
    var result: []const u8 = undefined;
    if (binary or isBinary(ancestor) or isBinary(ours) or isBinary(theirs)) {
        util.warn("Cannot merge binary files: {s} ({s} vs. {s})", .{ path, "ours", "theirs" });
        result = ours;
    } else {
        var mo = xdiff.MergeOpts{};
        mo.level = .zealous;
        mo.favor = favor;
        const style: i32 = if (opts.conflict_style >= 0) opts.conflict_style else configConflictStyle();
        if (style >= 0) mo.style = @enumFromInt(@as(u2, @intCast(style)));
        const msz = attr.get(path, "conflict-marker-size");
        switch (msz) {
            .value => |v| {
                if (std.fmt.parseInt(isize, v, 10)) |x| {
                    if (x > 0) mo.marker_size = x;
                } else |_| {}
            },
            else => {},
        }
        mo.ancestor_name = "base";
        mo.ours_name = "ours";
        mo.theirs_name = "theirs";
        const r = xdiff.merge(ancestor, ours, theirs, mo) catch {
            util.err("path '{s}': cannot merge", .{path});
            return true;
        };
        result = r.result;
    }
    const oid = repo_mod.repo().odb().write(.blob, result);
    // heap-allocated: parallel checkout may queue it until checkoutWorktree() ends
    const ce = gpa.create(Entry) catch util.oom();
    ce.* = .{ .path = path, .mode = mode, .oid = oid };
    ce.setStage(2);
    return entry.checkoutEntry(ce, st, n);
}

fn plural(nr: usize, one: []const u8, many: []const u8) []const u8 {
    return if (nr == 1) one else many;
}

fn checkoutWorktree(idx: *Index) bool {
    var st = entry.State{ .force = true, .refresh_cache = true, .istate = idx };
    var nr_checkouts: usize = 0;
    var nr_unmerged: usize = 0;
    var errs = false;
    const pc = @import("../parallel_checkout.zig");
    const pc_cfg = pc.getConfigs();
    if (pc_cfg.workers > 1) pc.init();
    var pos: usize = 0;
    while (pos < idx.entries.items.len) : (pos += 1) {
        const ce = &idx.entries.items[pos];
        if (ce.uflags & CE_MATCHED == 0) continue;
        if (ce.stage() == 0) {
            if (checkoutOne(ce, &st, &nr_checkouts)) errs = true;
            continue;
        }
        if (opts.writeout_stage != 0) {
            if (checkoutStage(idx, opts.writeout_stage, pos, &st, &nr_checkouts, opts.overlay_mode != 0)) errs = true;
        } else if (opts.merge > 0) {
            if (checkoutMerged(idx, pos, &st, &nr_unmerged)) errs = true;
        }
        pos = skipSameName(idx, pos) - 1;
    }
    if (pc_cfg.workers > 1 and pc.run(&st, pc_cfg.workers, pc_cfg.threshold)) errs = true;
    removeMarked(idx);
    entry.removeScheduledDirs();

    if (opts.count_checkout_paths) {
        util.flushStdout();
        if (nr_unmerged > 0)
            util.eprint("Recreated {d} merge conflict{s}\n", .{ nr_unmerged, plural(nr_unmerged, "", "s") });
        if (opts.source_tree) |t| {
            util.eprint("Updated {d} path{s} from {s}\n", .{ nr_checkouts, plural(nr_checkouts, "", "s"), revparse.abbrev(t, revparse.defaultAbbrev()) });
        } else if (nr_unmerged == 0 or nr_checkouts > 0) {
            util.eprint("Updated {d} path{s} from the index\n", .{ nr_checkouts, plural(nr_checkouts, "", "s") });
        }
    }
    return errs;
}

fn unmergeIndex(idx: *Index) void {
    var paths: std.ArrayList([]const u8) = .empty;
    for (idx.reuc.items) |r| {
        if (opts.pathspec.matches(r.path, false)) paths.append(gpa, r.path) catch util.oom();
    }
    for (paths.items) |p| {
        _ = idx.unmergeEntry(p);
        var i = idx.firstPos(p);
        while (i < idx.entries.items.len and util.eql(idx.entries.items[i].path, p)) : (i += 1)
            idx.entries.items[i].uflags |= CE_MATCHED;
    }
}

fn checkoutPaths(new_info: *BranchInfo) u8 {
    if (opts.track != .unspecified) util.die("'{s}' cannot be used with updating paths", .{"--track"});
    if (opts.new_branch_log) util.die("'{s}' cannot be used with updating paths", .{"-l"});
    if (opts.ignore_unmerged and opts.patch_mode) util.die("'{s}' cannot be used with updating paths", .{opts.ignore_unmerged_opt});
    if (opts.force_detach) util.die("'{s}' cannot be used with updating paths", .{"--detach"});
    if (opts.merge > 0 and opts.patch_mode) util.die("options '{s}' and '{s}' cannot be used together", .{ "--merge", "--patch" });
    if (opts.ignore_unmerged and opts.merge > 0) util.die("options '{s}' and '{s}' cannot be used together", .{ opts.ignore_unmerged_opt, "-m" });
    if (opts.new_branch) |nb| util.die("Cannot update paths and switch to branch '{s}' at the same time.", .{nb});
    if (opts.checkout_worktree == 0 and opts.checkout_index == 0)
        util.die("neither '{s}' or '{s}' is specified", .{ "--staged", "--worktree" });
    if (opts.checkout_worktree == 0 and opts.from_treeish == null)
        util.die("'{s}' must be used when '{s}' is not specified", .{ "--worktree", "--source" });
    if (!opts.accept_ref and opts.checkout_index != 0) {
        if (opts.writeout_stage != 0) util.die("'{s}' or '{s}' cannot be used with {s}", .{ "--ours", "--theirs", "--staged" });
        if (opts.merge > 0) util.die("'{s}' or '{s}' cannot be used with {s}", .{ "--merge", "--conflict", "--staged" });
    }
    if ((opts.merge > 0 or opts.writeout_stage != 0) and opts.source_tree != null)
        util.die("'{s}', '{s}', or '{s}' cannot be used when checking out of a tree", .{ "--merge", "--ours", "--theirs" });
    if (opts.patch_mode) {
        var rev: ?[]const u8 = new_info.name;
        if (rev != null and new_info.commit != null and !util.eql(rev.?, "HEAD")) rev = hash.hexAlloc(new_info.commit.?.oid());
        const mode: add_patch.Mode = if (opts.checkout_index != 0 and opts.checkout_worktree != 0) .checkout else if (opts.checkout_index != 0) .reset else .worktree;
        const iopts = add_patch.Options{ .context = opts.patch_context, .interhunkcontext = opts.patch_interhunk_context, .auto_advance = opts.auto_advance };
        return if (add_patch.runPathspec(mode, iopts, rev, &opts.pathspec, 0) != 0) 1 else 0;
    }

    const idx = index_mod.lockAndRead();
    // matching skip-worktree entries themselves needs the files of
    // sparse directories
    if (opts.ignore_skipworktree) sparse_index_mod.ensureFull(idx);
    for (idx.entries.items) |*e| e.uflags = 0;
    if (opts.source_tree) |t| readTreeSome(idx, t);
    if (opts.merge > 0) unmergeIndex(idx);

    const seen = opts.pathspec.newSeen();
    for (idx.entries.items) |*e| {
        if (opts.overlay_mode != 0) markOverlay(e, seen) else markNoOverlay(e, seen);
    }
    if (opts.pathspec.reportPathError(seen) > 0) {
        idx.rollback();
        return 1;
    }

    var errs = false;
    var pos: usize = 0;
    while (pos < idx.entries.items.len) : (pos += 1) {
        const ce = &idx.entries.items[pos];
        if (ce.uflags & CE_MATCHED == 0) continue;
        if (ce.stage() == 0) continue;
        if (opts.ignore_unmerged) {
            if (!quiet()) util.warn("path '{s}' is unmerged", .{ce.path});
        } else if (opts.writeout_stage != 0) {
            if (checkStage(idx, opts.writeout_stage, pos, opts.overlay_mode != 0)) errs = true;
        } else if (opts.merge > 0) {
            if (checkStages(idx, (1 << 2) | (1 << 3), pos)) errs = true;
        } else {
            errs = true;
            util.err("path '{s}' is unmerged", .{ce.path});
        }
        pos = skipSameName(idx, pos) - 1;
    }
    if (errs) {
        idx.rollback();
        return 1;
    }

    if (opts.checkout_worktree != 0) {
        if (checkoutWorktree(idx)) errs = true;
    } else removeMarked(idx);

    const write_index = if (opts.checkout_worktree != 0 and opts.checkout_index == 0 and opts.source_tree == null)
        true
    else
        opts.checkout_index != 0;
    for (idx.entries.items) |*e| e.uflags = 0;
    if (write_index) {
        idx.writeToLock();
        const l = idx.lock.?;
        if (!l.commit()) util.die("unable to write new index file", .{});
        idx.lock = null;
    } else idx.rollback();

    const head: ?*Commit = if (refs.readOid("HEAD")) |h| cn.lookupCommitReference(h) else null;
    if (postCheckoutHook(head, head, false) != 0) errs = true;
    return if (errs) 1 else 0;
}

// ---------------------------------------------------------------------------
// switching branches

fn quoteOut(path: []const u8) []const u8 {
    return util.cquote(path);
}

/// show_local_changes(): diff-index --name-status <commit> (worktree side)
fn showLocalChanges(commit: *Commit) void {
    cn.parseOrDie(commit);
    const idx = index_mod.get();
    // sparse directories identical to the tree are skipped on both sides;
    // differing ones are compared file by file without expanding the index
    var flat: std.ArrayList(objects.FlatEntry) = .empty;
    sparse_index_mod.flattenTreeSparse(idx, commit.tree, "", &flat);
    var tmap = std.StringHashMap(objects.FlatEntry).init(gpa);
    for (flat.items) |fe| tmap.put(fe.path, fe) catch util.oom();
    const ents = sparse_index_mod.virtualEntries(idx, commit.tree);

    const Line = struct { path: []const u8, status: u8 };
    var lines: std.ArrayList(Line) = .empty;
    var i: usize = 0;
    while (i < ents.len) : (i += 1) {
        const e = &ents[i];
        if (e.stage() != 0) {
            lines.append(gpa, .{ .path = e.path, .status = 'U' }) catch util.oom();
            _ = tmap.remove(e.path);
            while (i + 1 < ents.len and util.eql(ents[i + 1].path, e.path)) i += 1;
            continue;
        }
        const te = tmap.get(e.path);
        if (te != null) _ = tmap.remove(e.path);
        if (e.skipWorktree()) {
            if (te) |t| {
                if (t.mode != e.mode or !hash.eql(t.oid, e.oid))
                    lines.append(gpa, .{ .path = e.path, .status = 'M' }) catch util.oom();
            } else lines.append(gpa, .{ .path = e.path, .status = 'A' }) catch util.oom();
            continue;
        }
        const st = os.lstatPath(e.path);
        if (te == null) {
            if (st != null) lines.append(gpa, .{ .path = e.path, .status = 'A' }) catch util.oom();
            continue;
        }
        const t = te.?;
        const s = st orelse {
            lines.append(gpa, .{ .path = e.path, .status = 'D' }) catch util.oom();
            continue;
        };
        var new_mode = e.mode;
        var changed = false;
        if (e.mode & os.S_IFMT == os.S_IFGITLINK) {
            changed = false;
        } else if (idx.modified(e, s)) {
            changed = true;
            new_mode = index_mod.ceModeFromStat(e, s);
        }
        if (!changed and t.mode == new_mode and hash.eql(t.oid, e.oid)) continue;
        const status: u8 = if (t.mode & os.S_IFMT != new_mode & os.S_IFMT) 'T' else 'M';
        lines.append(gpa, .{ .path = e.path, .status = status }) catch util.oom();
    }
    var it = tmap.iterator();
    while (it.next()) |kv| lines.append(gpa, .{ .path = kv.key_ptr.*, .status = 'D' }) catch util.oom();
    std.mem.sort(Line, lines.items, {}, struct {
        fn lt(_: void, a: Line, b: Line) bool {
            return std.mem.order(u8, a.path, b.path) == .lt;
        }
    }.lt);
    for (lines.items) |l| util.outf("{c}\t{s}\n", .{ l.status, quoteOut(l.path) });
}

fn describeDetachedHead(msg: []const u8, commit: *Commit) void {
    var sb: util.Buf = .empty;
    if (cn.parse(commit)) pretty.ppCommitEasy(.oneline, commit, &sb);
    const ab = revparse.abbrev(commit.oid(), revparse.defaultAbbrev());
    util.flushStdout();
    const ell = if (os.getenv("GIT_PRINT_SHA1_ELLIPSIS")) |v| std.ascii.eqlIgnoreCase(v, "yes") else false;
    if (ell) {
        util.eprint("{s} {s}... {s}\n", .{ msg, ab, sb.items });
    } else util.eprint("{s} {s} {s}\n", .{ msg, ab, sb.items });
}

/// reset_tree(); returns 0, or 128 on failure
fn resetTree(idx: *Index, tree: Oid, worktree: bool, writeout_error: *bool) i32 {
    var o = ut.Options{};
    o.head_idx = 0;
    o.update = worktree;
    o.skip_unmerged = !worktree;
    o.reset = if (opts.force > 0) .overwrite_untracked else .protect_untracked;
    o.preserve_ignored = opts.force == 0 and !opts.overwrite_ignore;
    o.merge = true;
    o.func = &ut.onewayMerge;
    o.verbose_update = opts.show_progress > 0;
    o.src_index = idx;
    o.dst_index = idx;
    switch (ut.unpackTrees(&.{tree}, &o)) {
        -2 => {
            writeout_error.* = true;
            return 0;
        },
        0 => return 0,
        else => return 128,
    }
}

fn setupBranchPath(b: *BranchInfo) void {
    const name = b.name.?;
    const expanded = revparse.interpretBranchName(name);
    if (refs.dwimRef(expanded)) |d| {
        b.oid = d.oid;
        b.refname = d.name;
    } else if (revparse.getOidCommittish(name)) |o| {
        b.oid = o;
    }
    // copy_branchname(INTERPRET_BRANCH_LOCAL)
    var local = expanded;
    if (!util.eql(local, name) and (util.startsWith(name, "@{-") or util.eql(name, "@"))) {
        // keep expansion
    } else local = name;
    if (util.eql(name, "@")) local = name;
    b.name = local;
    b.path = util.concat(&.{ "refs/heads/", local });
}

fn isIndexUnborn(idx: *Index) bool {
    return idx.entries.items.len == 0 and idx.timestamp_s == 0;
}

fn mergeWorkingTree(old: *BranchInfo, new: *BranchInfo, quiet_unpack: bool, writeout_error: *bool) i32 {
    const idx = index_mod.lockAndRead();
    for (idx.entries.items) |*e| e.uflags = 0;
    if (idx.reuc.items.len > 0) {
        idx.reuc.clearRetainingCapacity();
        idx.changed = true;
    }
    var new_tree: Oid = undefined;
    if (opts.new_orphan_branch != null and opts.orphan_from_empty_tree) {
        new_tree = emptyTree();
    } else {
        const c = new.commit.?;
        if (!cn.parse(c)) {
            idx.rollback();
            util.err("unable to read tree ({s})", .{&c.hex()});
            return 1;
        }
        new_tree = c.tree;
    }
    if (opts.discard_changes) {
        const ret = resetTree(idx, new_tree, true, writeout_error);
        if (ret != 0) {
            idx.rollback();
            return ret;
        }
    } else {
        _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
        if (idx.unmerged()) {
            idx.rollback();
            util.err("you need to resolve your current index first", .{});
            return 1;
        }
        var o = ut.Options{};
        o.head_idx = 0;
        o.src_index = idx;
        o.dst_index = idx;
        ut.setupPorcelain(&o, "checkout");
        o.initial_checkout = isIndexUnborn(idx);
        o.update = true;
        o.merge = true;
        o.quiet = quiet_unpack;
        o.verbose_update = opts.show_progress > 0;
        o.func = &ut.twowayMerge;
        o.preserve_ignored = !opts.overwrite_ignore;

        var old_tree = emptyTree();
        if (old.commit) |oc| {
            if (!cn.parse(oc)) util.die("unable to parse commit {s}", .{&oc.hex()});
            old_tree = oc.tree;
        }
        const ret = ut.unpackTrees(&.{ old_tree, new_tree }, &o);
        if (ret == -1) {
            idx.rollback();
            return MERGE_WORKING_TREE_UNPACK_FAILED;
        }
    }
    const cur = index_mod.get();
    _ = ut.cacheTreeUpdateRepair(cur);
    cur.writeToLock();
    const l = cur.lock.?;
    if (!l.commit()) util.die("unable to write new index file", .{});
    cur.lock = null;

    if (!opts.discard_changes and !quiet()) {
        if (new.commit) |c| showLocalChanges(c);
    }
    return 0;
}

// ---- tracking report (format_tracking_info, subset) ----

fn reportTracking(new: *BranchInfo) void {
    var name = new.name.?;
    if (util.eql(name, "HEAD")) {
        name = refs.currentBranch() orelse return;
    }
    var sb: util.Buf = .empty;
    if (!tracking.formatTrackingInfo(name, &sb, .full, true)) return;
    util.out(sb.items);
}

fn detachAdvice(new_name: []const u8) void {
    util.flushStdout();
    util.eprint("Note: switching to '{s}'.\n" ++
        "\n" ++
        "You are in 'detached HEAD' state. You can look around, make experimental\n" ++
        "changes and commit them, and you can discard any commits you make in this\n" ++
        "state without impacting any branches by switching back to a branch.\n" ++
        "\n" ++
        "If you want to create a new branch to retain commits you create, you may\n" ++
        "do so (now or later) by using -c with the switch command. Example:\n" ++
        "\n" ++
        "  git switch -c <new-branch-name>\n" ++
        "\n" ++
        "Or undo this operation with:\n" ++
        "\n" ++
        "  git switch -\n" ++
        "\n" ++
        "Turn off this advice by setting config variable advice.detachedHead to false\n\n", .{new_name});
}

fn updateRefsForSwitch(old: *BranchInfo, new: *BranchInfo) void {
    if (opts.new_branch) |nb| {
        if (opts.new_orphan_branch) |orphan| {
            const refname = util.concat(&.{ "refs/heads/", orphan });
            if (opts.new_branch_log and !refs.shouldAutocreateReflog(refname)) {
                if (refs.createReflog(refname)) |e| {
                    util.flushStdout();
                    util.eprint("Can not do reflog for '{s}': {s}\n", .{ orphan, e });
                    return;
                }
            }
        } else {
            const force = opts.new_branch_force != null;
            bc.createBranch(nb, new.name.?, force, force, opts.new_branch_log, quiet(), opts.track, false);
        }
        new.name = nb;
        new.refname = null;
        setupBranchPath(new);
    }

    var old_desc: ?[]const u8 = old.name;
    if (old_desc == null) {
        if (old.commit) |c| old_desc = util.dupe(&c.hex());
    }
    const msg = os.getenv("GIT_REFLOG_ACTION") orelse
        util.fmt("checkout: moving from {s} to {s}", .{ old_desc orelse "(invalid)", new.name.? });

    const new_name = new.name.?;
    if (util.eql(new_name, "HEAD") and new.path == null and !opts.force_detach) {
        // nothing to do
    } else if (opts.force_detach or new.path == null) {
        refs.updateOrDie(msg, "HEAD", new.commit.?.oid(), null, refs.F_NO_DEREF);
        if (!quiet()) {
            if (old.path != null and advice.enabled("detachedHead") and !opts.force_detach)
                detachAdvice(new_name);
            describeDetachedHead("HEAD is now at", new.commit.?);
        }
    } else if (new.path) |np| {
        refs.writeSymref("HEAD", np, msg) catch util.die("unable to update HEAD", .{});
        if (!quiet()) {
            util.flushStdout();
            if (old.path != null and util.eql(np, old.path.?)) {
                if (opts.new_branch_force != null) {
                    util.eprint("Reset branch '{s}'\n", .{new_name});
                } else util.eprint("Already on '{s}'\n", .{new_name});
            } else if (opts.new_branch != null) {
                if (opts.branch_exists) {
                    util.eprint("Switched to and reset branch '{s}'\n", .{new_name});
                } else util.eprint("Switched to a new branch '{s}'\n", .{new_name});
            } else {
                util.eprint("Switched to branch '{s}'\n", .{new_name});
            }
        }
        if (old.path != null and old.name != null) {
            if (!refs.exists(old.path.?) and refs.reflogExists(old.path.?))
                _ = refs.deleteReflog(old.path.?);
        }
    }
    branchstate.removeBranchState(!quiet());
    if (!quiet() and !opts.force_detach and (new.path != null or util.eql(new_name, "HEAD")))
        reportTracking(new);
}

const ORPHAN_CUTOFF = 4;

fn describeOneOrphan(sb: *util.Buf, c: *Commit) void {
    util.bufAppend(sb, "  ");
    util.bufAppend(sb, revparse.abbrev(c.oid(), revparse.defaultAbbrev()));
    util.bufByte(sb, ' ');
    if (cn.parse(c)) pretty.ppCommitEasy(.oneline, c, sb);
    util.bufByte(sb, '\n');
}

fn suggestReattach(commit: *Commit, revs: *revision.RevInfo) void {
    var sb: util.Buf = .empty;
    var lost: usize = 0;
    var last: ?*Commit = null;
    while (revision.getRevision(revs)) |c| {
        if (lost < ORPHAN_CUTOFF) describeOneOrphan(&sb, c);
        last = c;
        lost += 1;
    }
    if (ORPHAN_CUTOFF < lost) {
        const more = lost - ORPHAN_CUTOFF;
        if (more == 1) {
            describeOneOrphan(&sb, last.?);
        } else util.bufPrint(&sb, " ... and {d} more.\n", .{more});
    }
    util.flushStdout();
    util.eprint("Warning: you are leaving {d} commit{s} behind, not connected to\nany of your branches:\n\n{s}\n", .{ lost, plural(lost, "", "s"), sb.items });
    if (advice.enabled("detachedHead")) {
        util.eprint("If you want to keep {s} by creating a new branch, this may be a good time\nto do so with:\n\n git branch <new-branch-name> {s}\n\n", .{ plural(lost, "it", "them"), revparse.abbrev(commit.oid(), revparse.defaultAbbrev()) });
    }
}

fn orphanedCommitWarning(old: *Commit, new: ?*Commit) void {
    var revs = revision.RevInfo.init("");
    _ = revision.setupRevisions(&revs, &.{"checkout"}, .{});
    old.obj.flags &= ~cn.UNINTERESTING;
    revs.addPendingObject(&old.obj, util.dupe(&old.hex()));
    for (refs.iterate("refs/", .{})) |r| {
        revision.addPendingOid(&revs, r.name, r.oid, cn.UNINTERESTING);
    }
    if (new) |n| revision.addPendingOid(&revs, "HEAD", n.oid(), cn.UNINTERESTING);
    if (!revision.prepareRevisionWalk(&revs)) util.die("internal error in revision walk", .{});
    if (old.obj.flags & cn.UNINTERESTING == 0) {
        suggestReattach(old, &revs);
    } else describeDetachedHead("Previous HEAD position was", old);
    cn.clearAllObjectFlags(cn.ALL_REV_FLAGS);
}


// ---- autostash (sequencer.c create_autostash_ref / apply_autostash_ref) ----

const AutostashResult = enum { clean, conflict, failed };

fn runGitSub(args: []const []const u8, o: os.SpawnOpts) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    util.flushStdout();
    return os.run(argv.items, o);
}

/// reset_working_tree(HARD) onto HEAD
fn hardResetToHead() bool {
    const head = revparse.getOid("HEAD") orelse return false;
    const tree = objects.peelTo(head, .tree) orelse return false;
    const idx = index_mod.lockAndRead();
    _ = ut.readIndexUnmerged(idx);
    var o = ut.Options{};
    ut.setupPorcelain(&o, "reset");
    o.head_idx = 1;
    o.src_index = idx;
    o.dst_index = idx;
    o.func = &ut.onewayMerge;
    o.update = true;
    o.merge = true;
    o.skip_cache_tree_update = true;
    o.reset = .protect_untracked;
    if (ut.unpackTrees(&.{tree}, &o) != 0) {
        idx.rollback();
        return false;
    }
    index_mod.primeCacheTree(idx, tree);
    idx.writeToLock();
    const l = idx.lock.?;
    if (!l.commit()) return false;
    idx.lock = null;
    return true;
}

fn createAutostashRef(refname: []const u8, message: []const u8) void {
    {
        const idx = index_mod.lockAndRead();
        _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
        if (idx.changed) {
            idx.writeToLock();
            const l = idx.lock.?;
            _ = l.commit();
            idx.lock = null;
        } else idx.rollback();
    }
    index_mod.discard();
    if (!(wtstatus.hasUnstagedChanges(true) or wtstatus.hasUncommittedChanges(true))) return;
    const r = runGitSub(&.{ "stash", "create", message }, .{ .capture_stdout = true, .no_stdin = true });
    if (r.status != 0) util.die("Cannot autostash", .{});
    var out = r.stdout;
    while (out.len > 0 and out[out.len - 1] == '\n') out = out[0 .. out.len - 1];
    const oid = revparse.getOid(out) orelse util.die("Unexpected stash response: '{s}'", .{out});
    refs.updateOrDie("", refname, oid, hash.zero, 0);
    if (!hardResetToHead()) util.die("could not reset --hard", .{});
    index_mod.discard();
    _ = index_mod.get();
}

fn conflictStyleName(s: i32) []const u8 {
    return switch (s) {
        1 => "diff3",
        2 => "zdiff3",
        else => "merge",
    };
}

fn applyAutostashRef(refname: []const u8, label_ours: []const u8, label_theirs: []const u8, label_base: ?[]const u8, stash_msg: []const u8) AutostashResult {
    if (!refs.exists(refname)) return .clean;
    const oid = refs.readOid(refname) orelse return .failed;
    const hex = util.dupe(&hash.hex(oid));

    var env: std.ArrayList([2][]const u8) = .empty;
    if (opts.conflict_style >= 0) {
        const p = util.fmt("'merge.conflictStyle={s}'", .{conflictStyleName(opts.conflict_style)});
        const v = if (os.getenv("GIT_CONFIG_PARAMETERS")) |old| util.concat(&.{ old, " ", p }) else p;
        env.append(gpa, .{ "GIT_CONFIG_PARAMETERS", v }) catch util.oom();
    }
    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, &.{ "stash", "apply" }) catch util.oom();
    args.append(gpa, util.concat(&.{ "--label-ours=", label_ours })) catch util.oom();
    args.append(gpa, util.concat(&.{ "--label-theirs=", label_theirs })) catch util.oom();
    if (label_base) |b| args.append(gpa, util.concat(&.{ "--label-base=", b })) catch util.oom();
    args.append(gpa, hex) catch util.oom();
    const r = runGitSub(args.items, .{ .capture_stdout = true, .no_stderr = true, .env = env.items });
    var ret: AutostashResult = switch (r.status) {
        0 => .clean,
        1 => .conflict,
        else => .failed,
    };
    util.flushStdout();
    if (ret == .clean) {
        util.ewrite("Applied autostash.\n");
    } else {
        const s = runGitSub(&.{ "stash", "store", "-m", stash_msg, "-q", hex }, .{});
        if (s.status != 0) {
            util.err("cannot store {s}", .{hex});
            ret = .failed;
        } else if (ret == .conflict) {
            util.ewrite("Your local changes are stashed, however applying them\n" ++
                "resulted in conflicts.  You can either resolve the conflicts\n" ++
                "and then discard the stash with \"git stash drop\", or, if you\n" ++
                "do not want to resolve them now, run \"git reset --hard\" and\n" ++
                "apply the local changes later by running \"git stash pop\".\n");
        } else {
            util.err("could not apply autostash; your changes are safe in the stash", .{});
        }
    }
    refs.deleteRef(refname, oid, refs.F_NO_DEREF, "") catch {};
    return ret;
}

fn switchBranches(new: *BranchInfo) u8 {
    var old = BranchInfo{};
    var writeout_error = false;
    var do_merge = true;
    var created_autostash = false;
    var autostash_res: AutostashResult = .clean;
    var autostash_msg: []const u8 = "";

    const head = refs.resolveFull("HEAD", false);
    if (!head.broken) {
        old.path = head.name;
        if (!head.missing) old.commit = cn.lookupCommitReference(head.oid);
    }
    if (head.flags & refs.REF_ISSYMREF == 0) old.path = null;
    if (old.path) |p| {
        if (util.skipPrefix(p, "refs/heads/")) |n| old.name = n;
    }

    if (opts.new_orphan_branch != null and opts.orphan_from_empty_tree) {
        new.commit = null;
        new.name = "(empty)";
        do_merge = true;
    }

    if (new.name == null) {
        new.name = "HEAD";
        new.commit = old.commit;
        if (new.commit == null) util.die("You are on a branch yet to be born", .{});
        cn.parseOrDie(new.commit.?);
        if (opts.only_merge_on_switching_branches) do_merge = false;
    }

    if (do_merge) {
        var ret = mergeWorkingTree(&old, new, opts.merge > 0, &writeout_error);
        if (ret == MERGE_WORKING_TREE_UNPACK_FAILED and opts.merge > 0) {
            autostash_msg = util.fmt("autostash while switching to '{s}'", .{new.name.?});
            createAutostashRef("CHECKOUT_AUTOSTASH_HEAD", autostash_msg);
            created_autostash = true;
            ret = mergeWorkingTree(&old, new, false, &writeout_error);
        }
        if (created_autostash) {
            var label_base: ?[]const u8 = old.name;
            if (label_base == null) {
                if (old.commit) |oc| label_base = revparse.abbrev(oc.oid(), revparse.defaultAbbrev());
            }
            autostash_res = applyAutostashRef("CHECKOUT_AUTOSTASH_HEAD", new.name.?, "local", label_base, autostash_msg);
        }
        if (ret != 0) return if (ret < 0) 1 else @intCast(ret);
    }

    if (!quiet() and old.path == null and old.commit != null and new.commit != old.commit)
        orphanedCommitWarning(old.commit.?, new.commit);

    if (autostash_res == .conflict and !quiet()) {
        util.flushStdout();
        util.ewrite("\n");
    }
    updateRefsForSwitch(&old, new);

    if (created_autostash) {
        index_mod.discard();
        _ = index_mod.get();
        if (!quiet()) {
            if (new.commit) |c| {
                util.out("The following paths have local changes:\n");
                showLocalChanges(c);
            }
        }
    }

    const r = postCheckoutHook(old.commit, new.commit, true);
    return if (r != 0 or writeout_error) 1 else 0;
}

fn setupNewBranchInfoAndSourceTree(new: *BranchInfo, rev: *Oid, arg: []const u8) void {
    new.name = if (util.eql(arg, "@")) "HEAD" else arg;
    setupBranchPath(new);
    if (refs.checkRefnameFormat(new.path.?, 0) and refs.readOid(new.path.?) != null) {
        rev.* = refs.readOid(new.path.?).?;
    } else new.path = null;

    new.commit = cn.lookupCommitReference(rev.*);
    if (new.commit) |c| {
        cn.parseOrDie(c);
        opts.source_tree = c.tree;
    } else {
        opts.source_tree = objects.peelTo(rev.*, .tree) orelse
            util.die("unable to read tree ({s})", .{&hash.hex(rev.*)});
    }
}

fn adviseDisambiguatingRemotes(which: Command, branch: []const u8, names: []const []const u8) void {
    const cmdname = switch (which) {
        .checkout => "checkout",
        .@"switch" => "switch",
        else => unreachable,
    };
    advice.advise(util.fmt("Branch name '{s}' appears in multiple remotes:", .{branch}));
    for (names) |n| advice.advise(util.fmt("  {s}", .{n}));
    advice.advise(util.fmt("If you meant to check out a remote tracking branch on <remote>,\n" ++
        "you can do so by fully qualifying the name with the --track option:\n" ++
        "\n" ++
        "    git {s} --track <remote>/{s}\n" ++
        "\n" ++
        "If you'd like to always have checkouts of an ambiguous name prefer\n" ++
        "one remote, e.g. the 'origin' remote, consider setting\n" ++
        "checkout.defaultRemote=origin in your config.", .{ cmdname, branch }));
}

fn parseRemoteBranch(arg: []const u8, rev: *Oid, could_be_paths: bool, which: Command) ?[]const u8 {
    const t = bc.uniqueTrackingName(arg);
    if (t.dst != null) rev.* = t.oid;
    if (t.dst != null and could_be_paths)
        util.die("'{s}' could be both a local file and a tracking branch.\nPlease use -- (and optionally --no-guess) to disambiguate", .{arg});
    if (t.dst == null and t.num_matches > 1) {
        if (advice.enabled("checkoutAmbiguousRemoteBranchName"))
            adviseDisambiguatingRemotes(which, arg, t.remotes);
        util.die("'{s}' matched multiple ({d}) remote tracking branches", .{ arg, t.num_matches });
    }
    return t.dst;
}

fn parseBranchnameArg(argv: []const []const u8, dwim_ok: bool, which: Command, new: *BranchInfo, rev: *Oid) usize {
    var args = argv;
    var argcount: usize = 0;
    var has_dash_dash = false;
    if (args.len == 0) return 0;
    if (!opts.accept_pathspec) {
        if (args.len > 1) util.die("only one reference expected", .{});
        has_dash_dash = true;
    }
    var arg = args[0];
    var dash_dash_pos: ?usize = null;
    if (opts.accept_pathspec) {
        for (args, 0..) |a, i| {
            if (util.eql(a, "--")) {
                dash_dash_pos = i;
                break;
            }
        }
    }
    if (dash_dash_pos) |d| {
        if (d == 0) return 1;
        if (d == 1) has_dash_dash = true else util.die("only one reference expected, {d} given.", .{d});
    }
    opts.count_checkout_paths = !quiet() and !has_dash_dash;

    if (util.eql(arg, "-")) arg = "@{-1}";

    if (bc.getOidMb(arg)) |o| {
        rev.* = o;
    } else {
        var recover = dwim_ok;
        const could_be_paths = !has_dash_dash and revparse.checkFilename(opts.prefix, arg);
        if (!has_dash_dash and !pathspec_mod.noWildcard(arg)) recover = false;
        if (!(args.len == 1 and !has_dash_dash) and !(args.len == 2 and has_dash_dash) and opts.accept_pathspec)
            recover = false;
        if (recover) {
            if (parseRemoteBranch(arg, rev, could_be_paths, which)) |remote| {
                opts.new_branch = arg;
                arg = remote;
            } else recover = false;
        }
        if (!recover) {
            if (has_dash_dash) util.die("invalid reference: {s}", .{arg});
            return argcount;
        }
    }

    argcount += 1;
    args = args[1..];

    setupNewBranchInfoAndSourceTree(new, rev, arg);
    if (opts.source_tree == null) util.die("reference is not a tree: {s}", .{arg});

    if (!has_dash_dash) {
        if (args.len > 0) revparse.verifyNonFilename(opts.prefix, arg);
    } else if (opts.accept_pathspec) {
        argcount += 1;
    }
    return argcount;
}

fn switchUnbornToNewBranch() u8 {
    const nb = opts.new_branch orelse util.die("You are on a branch yet to be born", .{});
    const ref = util.concat(&.{ "refs/heads/", nb });
    var status: u8 = 0;
    refs.writeSymref("HEAD", ref, "checkout -b") catch {
        util.err("{s}", .{refs.last_error});
        status = 1;
    };
    if (!quiet()) {
        util.flushStdout();
        util.eprint("Switched to a new branch '{s}'\n", .{nb});
    }
    return status;
}

fn dieExpectingABranch(b: *BranchInfo) noreturn {
    const name = b.name.?;
    util.flushStdout();
    if (refs.dwimRef(revparse.interpretBranchName(name))) |d| {
        if (d.count == 1) {
            if (util.skipPrefix(d.name, "refs/tags/")) |r| {
                util.eprint("fatal: a branch is expected, got tag '{s}'\n", .{r});
            } else if (util.skipPrefix(d.name, "refs/remotes/")) |r| {
                util.eprint("fatal: a branch is expected, got remote branch '{s}'\n", .{r});
            } else util.eprint("fatal: a branch is expected, got '{s}'\n", .{d.name});
        } else if (b.commit != null) {
            util.eprint("fatal: a branch is expected, got commit '{s}'\n", .{name});
        } else util.eprint("fatal: a branch is expected, got '{s}'\n", .{name});
    } else if (b.commit != null) {
        util.eprint("fatal: a branch is expected, got commit '{s}'\n", .{name});
    } else util.eprint("fatal: a branch is expected, got '{s}'\n", .{name});
    if (advice.enabled("suggestDetachingHead"))
        advice.advise("If you want to detach HEAD at the commit, try again with the --detach option.");
    os.exit(128);
}

fn dieIfSomeOperationInProgress() void {
    const st = wtstatus.getState(false);
    if (st.merge_in_progress)
        util.die("cannot switch branch while merging\nConsider \"git merge --quit\" or \"git worktree add\".", .{});
    if (st.am_in_progress)
        util.die("cannot switch branch in the middle of an am session\nConsider \"git am --quit\" or \"git worktree add\".", .{});
    if (st.rebase_interactive_in_progress or st.rebase_in_progress)
        util.die("cannot switch branch while rebasing\nConsider \"git rebase --quit\" or \"git worktree add\".", .{});
    if (st.cherry_pick_in_progress)
        util.die("cannot switch branch while cherry-picking\nConsider \"git cherry-pick --quit\" or \"git worktree add\".", .{});
    if (st.revert_in_progress)
        util.die("cannot switch branch while reverting\nConsider \"git revert --quit\" or \"git worktree add\".", .{});
    if (st.bisect_in_progress) util.warn("you are switching branch while bisecting", .{});
}

fn dieIfSwitchingToABranchInUse(full_ref: []const u8) void {
    if (opts.ignore_other_worktrees) return;
    const head = refs.resolveFull("HEAD", false);
    if (head.broken) return;
    if (head.flags & refs.REF_ISSYMREF == 0 or !util.eql(head.name, full_ref)) {
        if (bc.branchCheckedOutElsewhere(full_ref)) |p| {
            util.die("'{s}' is already used by worktree at '{s}'", .{ util.skipPrefix(full_ref, "refs/heads/") orelse full_ref, p });
        }
    }
}

fn checkoutBranch(new: *BranchInfo) u8 {
    const noop_switch = new.name == null and opts.new_branch == null and !opts.force_detach;
    if (!opts.pathspec.isEmpty()) util.die("paths cannot be used with switching branches", .{});
    if (opts.patch_mode) util.die("'{s}' cannot be used with switching branches", .{"--patch"});
    if (opts.overlay_mode != -1) util.die("'{s}' cannot be used with switching branches", .{"--[no]-overlay"});
    if (opts.writeout_stage != 0) {
        if (noop_switch) util.die("'{s}' needs the paths to check out", .{"--ours/--theirs"});
        util.die("'{s}' cannot be used with switching branches", .{"--ours/--theirs"});
    }
    if (opts.force > 0 and opts.merge > 0) util.die("'{s}' cannot be used with '{s}'", .{ "-f", "-m" });
    if (opts.discard_changes and opts.merge > 0) util.die("'{s}' cannot be used with '{s}'", .{ "--discard-changes", "--merge" });
    if (opts.force_detach and opts.new_branch != null) util.die("'{s}' cannot be used with '{s}'", .{ "--detach", "-b/-B/--orphan" });

    if (opts.new_orphan_branch != null) {
        if (opts.track != .unspecified) util.die("'{s}' cannot be used with '{s}'", .{ "--orphan", "-t" });
        if (opts.orphan_from_empty_tree and new.name != null) util.die("'{s}' cannot take <start-point>", .{"--orphan"});
    } else if (opts.force_detach) {
        if (opts.track != .unspecified) util.die("'{s}' cannot be used with '{s}'", .{ "--detach", "-t" });
    } else if (opts.track == .unspecified) opts.track = bc.configBranchTrack();

    if (new.name != null and new.commit == null) util.die("Cannot switch branch to a non-commit '{s}'", .{new.name.?});
    if (noop_switch and !opts.switch_branch_doing_nothing_is_ok) util.die("missing branch or commit argument", .{});

    if (!opts.implicit_detach and !opts.force_detach and opts.new_branch == null and
        opts.new_branch_force == null and new.name != null and new.path == null)
        dieExpectingABranch(new);

    if (!opts.can_switch_when_in_progress) dieIfSomeOperationInProgress();

    if (new.path != null and !opts.force_detach and opts.new_branch == null)
        dieIfSwitchingToABranchInUse(new.path.?);
    if (opts.new_branch_force) |nbf| dieIfSwitchingToABranchInUse(util.concat(&.{ "refs/heads/", nbf }));

    if (new.commit == null and opts.new_branch != null) {
        const h = refs.resolveFull("HEAD", false);
        if (!h.broken and h.flags & refs.REF_ISSYMREF != 0 and hash.isZero(h.oid))
            return switchUnbornToNewBranch();
    }
    return switchBranches(new);
}

// ---------------------------------------------------------------------------
// option callbacks

fn cbMerge(_: ?[]const u8, unset: bool) void {
    opts.merge = if (unset) 0 else 1;
}
fn cbConflict(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        opts.conflict_style = -1;
        return;
    }
    opts.conflict_style = parseConflictStyleName(arg.?);
    if (opts.conflict_style < 0) {
        util.err("unknown conflict style '{s}'", .{arg.?});
        os.exit(129);
    }
    if (opts.merge == 0) opts.merge = -1;
}
fn cbProgress(_: ?[]const u8, unset: bool) void {
    opts.show_progress = if (unset) 0 else 1;
}
fn cbOverlay(_: ?[]const u8, unset: bool) void {
    opts.overlay_mode = if (unset) 0 else 1;
}
fn cbStaged(_: ?[]const u8, unset: bool) void {
    opts.checkout_index = if (unset) 0 else 1;
}
fn cbWorktree(_: ?[]const u8, unset: bool) void {
    opts.checkout_worktree = if (unset) 0 else 1;
}
fn cbTrack(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        opts.track = .never;
    } else if (arg == null or util.eql(arg.?, "direct")) {
        opts.track = .explicit;
    } else if (util.eql(arg.?, "inherit")) {
        opts.track = .inherit;
    } else {
        util.err("option `{s}' expects \"{s}\" or \"{s}\"", .{ "track", "direct", "inherit" });
        os.exit(129);
    }
}
fn cbOurs(_: ?[]const u8, _: bool) void {
    opts.writeout_stage = 2;
}
fn cbTheirs(_: ?[]const u8, _: bool) void {
    opts.writeout_stage = 3;
}
fn cbRecurse(arg: ?[]const u8, unset: bool) void {
    submodule.optWorktreeUpdater(arg, unset);
}

var o_force: i32 = 0;

fn commonOptions(l: *std.ArrayList(po.Opt)) void {
    const add = struct {
        fn f(list: *std.ArrayList(po.Opt), o: po.Opt) void {
            list.append(gpa, o) catch util.oom();
        }
    }.f;
    add(l, po.counter('q', "quiet", &opts.quiet, "suppress progress reporting"));
    add(l, .{ .long = "recurse-submodules", .kind = .callback, .cb = cbRecurse, .argh = "checkout", .help = "control recursive updating of submodules", .optarg = true });
    add(l, po.callbackNoArg(0, "progress", cbProgress, "force progress reporting"));
    add(l, po.callbackNoArg('m', "merge", cbMerge, "perform a 3-way merge with the new branch"));
    add(l, po.callback(0, "conflict", cbConflict, "style", "conflict style (merge, diff3, or zdiff3)"));
}

fn switchBranchOptions(l: *std.ArrayList(po.Opt)) void {
    l.append(gpa, po.boolean('d', "detach", &opts.force_detach, "detach HEAD at named commit")) catch util.oom();
    l.append(gpa, .{ .short = 't', .long = "track", .kind = .callback, .cb = cbTrack, .argh = "(direct|inherit)", .literal_argh = true, .optarg = true, .help = "set branch tracking configuration" }) catch util.oom();
    l.append(gpa, po.noComplete(po.counter('f', "force", &opts.force, "force checkout (throw away local modifications)"))) catch util.oom();
    l.append(gpa, po.string(0, "orphan", &opts.new_orphan_branch, "new-branch", "new unborn branch")) catch util.oom();
    l.append(gpa, po.noComplete(po.boolean(0, "overwrite-ignore", &opts.overwrite_ignore, "update ignored files (default)"))) catch util.oom();
    l.append(gpa, po.boolean(0, "ignore-other-worktrees", &opts.ignore_other_worktrees, "do not check if another worktree is using this branch")) catch util.oom();
}

fn pathOptions(l: *std.ArrayList(po.Opt)) void {
    l.append(gpa, .{ .short = '2', .long = "ours", .kind = .callback, .cb = cbOurs, .noarg = true, .noneg = true, .help = "checkout our version for unmerged files" }) catch util.oom();
    l.append(gpa, .{ .short = '3', .long = "theirs", .kind = .callback, .cb = cbTheirs, .noarg = true, .noneg = true, .help = "checkout their version for unmerged files" }) catch util.oom();
    l.append(gpa, po.boolean('p', "patch", &opts.patch_mode, "select hunks interactively")) catch util.oom();
    l.append(gpa, .{ .short = 'U', .long = "unified", .kind = .int, .i = &opts.patch_context, .argh = "n", .noneg = true, .help = "generate diffs with <n> lines context" }) catch util.oom();
    l.append(gpa, .{ .long = "inter-hunk-context", .kind = .int, .i = &opts.patch_interhunk_context, .argh = "n", .noneg = true, .help = "show context between diff hunks up to the specified number of lines" }) catch util.oom();
    l.append(gpa, po.boolean(0, "ignore-skip-worktree-bits", &opts.ignore_skipworktree, "do not limit pathspecs to sparse entries only")) catch util.oom();
    l.append(gpa, po.filename(0, "pathspec-from-file", &opts.pathspec_from_file, "file", "read pathspec from file")) catch util.oom();
    l.append(gpa, po.boolean(0, "pathspec-file-nul", &opts.pathspec_file_nul, "with --pathspec-from-file, pathspec elements are separated with NUL character")) catch util.oom();
}

// ---------------------------------------------------------------------------

fn checkoutMain(args: []const []const u8, options: []const po.Opt, usage: []const []const u8, which: Command) u8 {
    var new_info = BranchInfo{};
    const r = repo_mod.repo();
    sparse_index_mod.commandIsSparseAware();
    opts.overwrite_ignore = true;
    opts.prefix = r.prefix;
    opts.show_progress = -1;
    if (repo_mod.cfg.getBool("checkout.guess")) |g| opts.dwim_new_local_branch = g;
    submodule.loadRecurseConfig();
    opts.track = .unspecified;

    var argv = po.parse(args[1..], options, usage, .{ .keep_dashdash = opts.accept_pathspec and opts.accept_ref });

    if (opts.patch_context < -1) util.die("'{s}' cannot be negative", .{"--unified"});
    if (opts.patch_interhunk_context < -1) util.die("'{s}' cannot be negative", .{"--inter-hunk-context"});
    if (!opts.patch_mode) {
        if (opts.patch_context != -1) util.die("the option '{s}' requires '{s}'", .{ "--unified", "--patch" });
        if (opts.patch_interhunk_context != -1) util.die("the option '{s}' requires '{s}'", .{ "--inter-hunk-context", "--patch" });
        if (!opts.auto_advance) util.die("the option '{s}' requires '{s}'", .{ "--no-auto-advance", "--patch" });
    }
    if (opts.show_progress < 0) {
        opts.show_progress = if (quiet()) 0 else @intFromBool(os.isatty(2));
    }
    if (opts.merge == -1) opts.merge = @intFromBool(opts.conflict_style >= 0);
    if (opts.force > 0) {
        opts.discard_changes = true;
        opts.ignore_unmerged_opt = "--force";
        opts.ignore_unmerged = true;
    }
    const nsel = @as(u32, @intFromBool(opts.new_branch != null)) + @intFromBool(opts.new_branch_force != null) + @intFromBool(opts.new_orphan_branch != null);
    if (nsel > 1)
        util.die("options '-{c}', '-{c}', and '{s}' cannot be used together", .{ cb_option, std.ascii.toUpper(cb_option), "--orphan" });
    if (opts.overlay_mode == 1 and opts.patch_mode)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "-p", "--overlay" });

    if (opts.checkout_index >= 0 or opts.checkout_worktree >= 0) {
        if (opts.checkout_index < 0) opts.checkout_index = 0;
        if (opts.checkout_worktree < 0) opts.checkout_worktree = 0;
    } else {
        if (opts.checkout_index < 0) opts.checkout_index = -opts.checkout_index - 1;
        if (opts.checkout_worktree < 0) opts.checkout_worktree = -opts.checkout_worktree - 1;
    }
    if (opts.from_treeish == null and opts.checkout_index != 0) opts.from_treeish = "HEAD";

    if (opts.new_branch_force) |b| opts.new_branch = b;
    if (opts.new_orphan_branch) |b| opts.new_branch = b;

    if (opts.track != .unspecified and opts.new_branch == null) {
        if (argv.len == 0 or util.eql(argv[0], "--")) util.die("--track needs a branch name", .{});
        var a0 = argv[0];
        if (util.skipPrefix(a0, "refs/")) |x| a0 = x;
        if (util.skipPrefix(a0, "remotes/")) |x| a0 = x;
        const sl = std.mem.indexOfScalar(u8, a0, '/');
        if (sl == null or sl.? + 1 >= a0.len) util.die("missing branch name; try -{c}", .{cb_option});
        opts.new_branch = a0[sl.? + 1 ..];
    }

    if (argv.len > 0 and opts.accept_ref) {
        var rev: Oid = hash.zero;
        const dwim_ok = !opts.patch_mode and opts.dwim_new_local_branch and opts.track == .unspecified and opts.new_branch == null;
        const n = parseBranchnameArg(argv, dwim_ok, which, &new_info, &rev);
        argv = argv[n..];
    } else if (!opts.accept_ref and opts.from_treeish != null) {
        var rev = bc.getOidMb(opts.from_treeish.?) orelse util.die("could not resolve '{s}'", .{opts.from_treeish.?});
        setupNewBranchInfoAndSourceTree(&new_info, &rev, opts.from_treeish.?);
        if (opts.source_tree == null) util.die("reference is not a tree: {s}", .{opts.from_treeish.?});
    }

    if (argv.len > 0) {
        opts.pathspec = pathspec_mod.parse(opts.prefix, argv, .{ .prefix_origin = opts.patch_mode });
        if (opts.pathspec.isEmpty()) util.die("invalid path specification", .{});
        if (opts.new_branch != null and argv.len == 1 and new_info.commit == null)
            util.die("'{s}' is not a commit and a branch '{s}' cannot be created from it", .{ argv[0], opts.new_branch.? });
        if (opts.force_detach)
            util.die("git checkout: --detach does not take a path argument '{s}'", .{argv[0]});
    }

    if (opts.pathspec_from_file) |f| {
        if (!opts.pathspec.isEmpty()) util.die("'{s}' and pathspec arguments cannot be used together", .{"--pathspec-from-file"});
        if (opts.force_detach) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "--detach" });
        if (opts.patch_mode) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "--patch" });
        const items = pathspec_mod.readPathspecFile(f, opts.pathspec_file_nul);
        opts.pathspec = pathspec_mod.parse(opts.prefix, items, .{ .prefix_origin = opts.patch_mode });
    } else if (opts.pathspec_file_nul) {
        util.die("the option '{s}' requires '{s}'", .{ "--pathspec-file-nul", "--pathspec-from-file" });
    }
    opts.pathspec.recursive = true;

    if (!opts.pathspec.isEmpty()) {
        const n = @as(u32, @intFromBool(opts.writeout_stage != 0)) + @intFromBool(opts.force > 0) + @intFromBool(opts.merge > 0);
        if (n > 1) util.die("git checkout: --ours/--theirs, --force and --merge are incompatible when\nchecking out of the index.", .{});
    } else {
        if (opts.accept_pathspec and !opts.empty_pathspec_ok and !opts.patch_mode)
            util.die("you must specify path(s) to restore", .{});
    }

    if (opts.new_branch) |nb| {
        var buf: []const u8 = "";
        if (opts.new_branch_force != null) {
            opts.branch_exists = bc.validateBranchname(nb, &buf);
        } else {
            opts.branch_exists = bc.validateNewBranchname(nb, &buf, false);
        }
    }

    if (opts.patch_mode or !opts.pathspec.isEmpty()) return checkoutPaths(&new_info);
    return checkoutBranch(&new_info);
}

pub fn runCheckout(args: []const []const u8) u8 {
    opts = .{};
    opts.dwim_new_local_branch = true;
    opts.switch_branch_doing_nothing_is_ok = true;
    opts.only_merge_on_switching_branches = false;
    opts.accept_ref = true;
    opts.accept_pathspec = true;
    opts.implicit_detach = true;
    opts.can_switch_when_in_progress = true;
    opts.orphan_from_empty_tree = false;
    opts.empty_pathspec_ok = true;
    opts.overlay_mode = -1;
    opts.checkout_index = -2;
    opts.checkout_worktree = -2;
    cb_option = 'b';
    if (args.len == 3 and util.eql(args[1], "-b")) {
        opts.switch_branch_doing_nothing_is_ok = false;
        opts.only_merge_on_switching_branches = true;
    }
    var l: std.ArrayList(po.Opt) = .empty;
    l.append(gpa, po.string('b', "", &opts.new_branch, "branch", "create and checkout a new branch")) catch util.oom();
    l.append(gpa, po.string('B', "", &opts.new_branch_force, "branch", "create/reset and checkout a branch")) catch util.oom();
    l.append(gpa, po.boolean('l', "", &opts.new_branch_log, "create reflog for new branch")) catch util.oom();
    l.append(gpa, po.boolean(0, "guess", &opts.dwim_new_local_branch, "second guess 'git checkout <no-such-branch>' (default)")) catch util.oom();
    l.append(gpa, po.callbackNoArg(0, "overlay", cbOverlay, "use overlay mode (default)")) catch util.oom();
    l.append(gpa, po.boolean(0, "auto-advance", &opts.auto_advance, "auto advance to the next file when selecting hunks interactively")) catch util.oom();
    commonOptions(&l);
    switchBranchOptions(&l);
    pathOptions(&l);
    const usage = [_][]const u8{
        "git checkout [<options>] <branch>",
        "git checkout [<options>] [<branch>] -- <file>...",
    };
    return checkoutMain(args, l.items, &usage, .checkout);
}

pub fn runSwitch(args: []const []const u8) u8 {
    opts = .{};
    opts.dwim_new_local_branch = true;
    opts.accept_ref = true;
    opts.accept_pathspec = false;
    opts.switch_branch_doing_nothing_is_ok = false;
    opts.only_merge_on_switching_branches = true;
    opts.implicit_detach = false;
    opts.can_switch_when_in_progress = false;
    opts.orphan_from_empty_tree = true;
    opts.overlay_mode = -1;
    cb_option = 'c';
    var l: std.ArrayList(po.Opt) = .empty;
    l.append(gpa, po.string('c', "create", &opts.new_branch, "branch", "create and switch to a new branch")) catch util.oom();
    l.append(gpa, po.string('C', "force-create", &opts.new_branch_force, "branch", "create/reset and switch to a branch")) catch util.oom();
    l.append(gpa, po.boolean(0, "guess", &opts.dwim_new_local_branch, "second guess 'git switch <no-such-branch>'")) catch util.oom();
    l.append(gpa, po.boolean(0, "discard-changes", &opts.discard_changes, "throw away local modifications")) catch util.oom();
    commonOptions(&l);
    switchBranchOptions(&l);
    const usage = [_][]const u8{"git switch [<options>] [<branch>]"};
    return checkoutMain(args, l.items, &usage, .@"switch");
}

pub fn runRestore(args: []const []const u8) u8 {
    opts = .{};
    opts.accept_ref = false;
    opts.accept_pathspec = true;
    opts.empty_pathspec_ok = false;
    opts.overlay_mode = 0;
    opts.checkout_index = -1;
    opts.checkout_worktree = -2;
    opts.ignore_unmerged_opt = "--ignore-unmerged";
    var l: std.ArrayList(po.Opt) = .empty;
    l.append(gpa, po.string('s', "source", &opts.from_treeish, "tree-ish", "which tree-ish to checkout from")) catch util.oom();
    l.append(gpa, po.callbackNoArg('S', "staged", cbStaged, "restore the index")) catch util.oom();
    l.append(gpa, po.callbackNoArg('W', "worktree", cbWorktree, "restore the working tree (default)")) catch util.oom();
    l.append(gpa, po.boolean(0, "ignore-unmerged", &opts.ignore_unmerged, "ignore unmerged entries")) catch util.oom();
    l.append(gpa, po.callbackNoArg(0, "overlay", cbOverlay, "use overlay mode")) catch util.oom();
    commonOptions(&l);
    pathOptions(&l);
    const usage = [_][]const u8{"git restore [<options>] [--source=<branch>] <file>..."};
    return checkoutMain(args, l.items, &usage, .restore);
}
