//! git index-pack, unpack-objects, verify-pack, show-index.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const odb_mod = @import("../odb.zig");
const pack = @import("../pack.zig");
const progress = @import("../progress.zig");
const proc = @import("../proc.zig");
const zlib = @import("../zlib.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

const index_pack_usage = "git index-pack [-v] [-o <index-file>] [--keep | --keep=<msg>] [--[no-]rev-index] [--verify] [--strict[=<msg-id>=<severity>...]] [--fsck-objects[=<msg-id>=<severity>...]] (<pack-file> | --stdin [--fix-thin] [<pack-file>])";

fn usageDie(u: []const u8) noreturn {
    util.eprint("usage: {s}\n", .{u});
    os.exit(129);
}

fn showUsageIfAsked(args: []const []const u8, u: []const u8) void {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.outf("usage: {s}\n", .{u});
        util.flushStdout();
        os.exit(0);
    }
}

fn deriveFilename(name: []const u8, strip: []const u8, suffix: []const u8) []const u8 {
    // derive_filename: name must end in ".<strip>"
    const dot_strip = util.concat(&.{ ".", strip });
    if (!util.endsWith(name, dot_strip)) util.die("packfile name '{s}' does not end with '.{s}'", .{ name, strip });
    return util.concat(&.{ name[0 .. name.len - strip.len], suffix });
}

fn optArg(arg: []const u8, name: []const u8) ?[]const u8 {
    // skip_to_optional_arg: "--name" -> "", "--name=x" -> "x"
    if (!util.startsWith(arg, name)) return null;
    const rest = arg[name.len..];
    if (rest.len == 0) return "";
    if (rest[0] == '=') return rest[1..];
    return null;
}

fn haveRepo() bool {
    return repo_mod.repo_ != null;
}

pub fn cmdIndexPack(args: []const []const u8) u8 {
    showUsageIfAsked(args, index_pack_usage);
    var from_stdin = false;
    var fix_thin = false;
    var verify = false;
    var show_stat = false;
    var stat_only = false;
    var strict = false;
    var verbose = false;
    var keep_msg: ?[]const u8 = null;
    var promisor_msg: ?[]const u8 = null;
    var progress_title: ?[]const u8 = null;
    var report_eoi = false;
    var show_resolving = false;
    var index_name: ?[]const u8 = null;
    var pack_name: ?[]const u8 = null;
    var opts = pack.IdxOpts{};
    var rev_index = true;
    if (repo_mod.repo_ != null) {
        if (repo_mod.cfg.getInt("pack.indexversion")) |v| {
            if (v > 2) util.die("bad pack.indexVersion={d}", .{v});
            opts.version = @intCast(v);
        }
        if (repo_mod.cfg.getBool("pack.writereverseindex")) |b| rev_index = b;
    }
    if (os.getenv("GIT_TEST_NO_WRITE_REV_INDEX")) |v| {
        if (util.eql(v, "1") or util.eql(v, "true")) rev_index = false;
    }
    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (arg.len > 0 and arg[0] == '-') {
            if (util.eql(arg, "--stdin")) {
                from_stdin = true;
            } else if (util.eql(arg, "--fix-thin")) {
                fix_thin = true;
            } else if (optArg(arg, "--strict")) |_| {
                strict = true;
            } else if (util.eql(arg, "--check-self-contained-and-connected")) {
                strict = true;
            } else if (optArg(arg, "--fsck-objects")) |_| {} else if (util.eql(arg, "--verify")) {
                verify = true;
            } else if (util.eql(arg, "--verify-stat")) {
                verify = true;
                show_stat = true;
            } else if (util.eql(arg, "--verify-stat-only")) {
                verify = true;
                show_stat = true;
                stat_only = true;
            } else if (optArg(arg, "--keep")) |m| {
                keep_msg = m;
            } else if (optArg(arg, "--promisor")) |m| {
                promisor_msg = m;
            } else if (util.startsWith(arg, "--threads=")) {
                _ = std.fmt.parseInt(u32, arg[10..], 0) catch usageDie(index_pack_usage);
            } else if (util.startsWith(arg, "--pack_header=")) {
                util.die("bad --pack_header: {s}", .{arg[14..]});
            } else if (util.eql(arg, "-v")) {
                verbose = true;
            } else if (util.eql(arg, "--progress-title")) {
                if (progress_title != null or i + 1 >= args.len) usageDie(index_pack_usage);
                i += 1;
                progress_title = args[i];
            } else if (util.eql(arg, "--show-resolving-progress")) {
                show_resolving = true;
            } else if (util.eql(arg, "--report-end-of-input")) {
                report_eoi = true;
            } else if (util.eql(arg, "-o")) {
                if (index_name != null or i + 1 >= args.len) usageDie(index_pack_usage);
                i += 1;
                index_name = args[i];
            } else if (util.startsWith(arg, "--index-version=")) {
                const v = arg[16..];
                var it = std.mem.splitScalar(u8, v, ',');
                const ver = it.next().?;
                opts.version = std.fmt.parseInt(u32, ver, 10) catch util.die("bad {s}", .{arg});
                if (opts.version > 2) util.die("bad {s}", .{arg});
                if (it.next()) |o| {
                    opts.off32_limit = std.fmt.parseInt(u64, o, 0) catch util.die("bad {s}", .{arg});
                }
                if (opts.off32_limit & 0x80000000 != 0) util.die("bad {s}", .{arg});
            } else if (util.startsWith(arg, "--max-input-size=")) {} else if (util.startsWith(arg, "--object-format=")) {
                const f = arg[16..];
                if (!util.eql(f, "sha1")) util.die("unknown hash algorithm '{s}'", .{f});
            } else if (util.eql(arg, "--rev-index")) {
                rev_index = true;
            } else if (util.eql(arg, "--no-rev-index")) {
                rev_index = false;
            } else usageDie(index_pack_usage);
            continue;
        }
        if (pack_name != null) usageDie(index_pack_usage);
        pack_name = arg;
    }
    if (pack_name == null and !from_stdin) usageDie(index_pack_usage);
    if (fix_thin and !from_stdin) util.die("the option '{s}' requires '{s}'", .{ "--fix-thin", "--stdin" });
    if (promisor_msg != null and pack_name != null) util.die("--promisor cannot be used with a pack name", .{});
    if (from_stdin and !haveRepo()) util.die("--stdin requires a git repository", .{});
    // relative paths are relative to the original cwd (prefix)
    if (repo_mod.repo_) |r| {
        if (r.prefix.len > 0) {
            if (pack_name) |p| {
                if (p[0] != '/') pack_name = util.concat(&.{ r.prefix, p });
            }
            if (index_name) |p| {
                if (p[0] != '/') index_name = util.concat(&.{ r.prefix, p });
            }
        }
    }
    if (index_name == null and pack_name != null) index_name = deriveFilename(pack_name.?, "pack", "idx");
    var rev_index_name: ?[]const u8 = null;
    if (rev_index and index_name != null) rev_index_name = deriveFilename(index_name.?, "idx", "rev");

    var existing_idx: ?[]u8 = null;
    if (verify) {
        if (index_name == null) util.die("--verify with no packfile name given", .{});
        existing_idx = os.readFile(index_name.?);
        if (existing_idx) |d| {
            if (d.len >= 8 and std.mem.eql(u8, d[0..4], "\xfftOc")) {
                opts.version = std.mem.readInt(u32, d[4..8], .big);
            } else opts.version = 1;
        }
        opts.strict = true;
    }
    if (strict) opts.strict = true;

    // ---- read the pack
    var in: pack.Input = undefined;
    var out_fd: c_int = -1;
    var curr_pack: []const u8 = "";
    if (from_stdin) {
        in = .{ .fd = 0 };
        if (pack_name) |p| {
            out_fd = os.openFile(p, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600);
            if (out_fd < 0) util.dieErrno("could not open '{s}'", .{p});
            curr_pack = p;
        } else {
            const odb = repo_mod.repo().odb();
            const pdir = util.concat(&.{ odb.objects_dir, "/pack" });
            _ = os.mkdirAll(pdir);
            const t = os.tmpFile(pdir, "tmp_pack_");
            if (t.fd < 0) util.dieErrno("unable to create temporary file", .{});
            out_fd = t.fd;
            curr_pack = t.path;
        }
    } else {
        const d = os.readFile(pack_name.?) orelse util.dieErrno("could not open '{s}'", .{pack_name.?});
        in = pack.Input.fromBytes(d);
        curr_pack = pack_name.?;
    }
    const hdr = pack.readHeader(&in);
    var prog: ?*progress.Progress = null;
    if (verbose) prog = progress.start(progress_title orelse if (from_stdin) "Receiving objects" else "Indexing objects", hdr.nr);
    var res = pack.Resolver{};
    var nr_ofs: u32 = 0;
    var nr_ref: u32 = 0;
    var n: u32 = 0;
    while (n < hdr.nr) : (n += 1) {
        const e = pack.readEntry(&in);
        if (e.typ == .ofs_delta) nr_ofs += 1;
        if (e.typ == .ref_delta) nr_ref += 1;
        res.add(e);
        progress.update(prog, n + 1);
    }
    const end_of_objects = in.pos;
    var pack_sha = pack.readTrailer(&in);
    if (prog) |p| p.stop();
    prog = null;
    if (!from_stdin and in.pos != in.data.items.len) util.die("pack has junk at the end", .{});
    if (report_eoi) util.ewrite("\x00");
    const pack_bytes_len = in.pos;

    // ---- resolve deltas
    const nr_deltas = nr_ofs + nr_ref;
    if (nr_deltas > 0 and (verbose or show_resolving)) prog = progress.start("Resolving deltas", nr_deltas);
    var unresolved = res.resolveAll();
    var appended: std.ArrayList(u32) = .empty;
    if (unresolved > 0 and fix_thin) {
        var tried: hash.OidSet = .empty;
        const odb = repo_mod.repo().odb();
        while (unresolved > 0) {
            const base = res.firstMissingBase(&tried) orelse break;
            tried.put(gpa, base, {}) catch util.oom();
            const o = odb.read(base) orelse continue;
            if (!hash.eql(odb_mod.hashObject(o.typ, o.data), base)) util.die("local object {s} is corrupt", .{hash.hex(base)});
            const idx = res.addExternal(o.typ, @constCast(o.data));
            appended.append(gpa, idx) catch util.oom();
            unresolved = res.resolveAll();
        }
    }
    if (prog) |p| {
        progress.update(p, nr_deltas - unresolved);
        if (appended.items.len > 0) {
            p.stopMsg(util.fmt("completed with {d} local object{s}", .{ appended.items.len, if (appended.items.len == 1) "" else "s" }));
        } else p.stop();
    }
    if (unresolved > 0) util.die("pack has {d} unresolved delta{s}", .{ unresolved, if (unresolved == 1) "" else "s" });

    const total: usize = res.entries.items.len;
    // offsets/crcs of appended objects; build final pack bytes for stdin
    if (from_stdin) {
        var final_pack: util.Buf = .empty;
        if (appended.items.len > 0) {
            util.bufAppend(&final_pack, in.data.items[0..end_of_objects]);
            std.mem.writeInt(u32, final_pack.items[8..12], @intCast(total), .big);
            const level = pack.packCompressionLevel();
            for (appended.items) |ai| {
                const e = &res.entries.items[ai];
                const bytes = pack.encodeFullEntry(e.typ, e.data, level);
                e.offset = final_pack.items.len;
                e.crc = zlib.crc(0, bytes);
                util.bufAppend(&final_pack, bytes);
                e.end = final_pack.items.len;
            }
            pack_sha = hash.hashData(final_pack.items);
            util.bufAppend(&final_pack, &pack_sha);
        } else {
            util.bufAppend(&final_pack, in.data.items[0..pack_bytes_len]);
        }
        os.writeAll(out_fd, final_pack.items) catch util.dieErrno("write error", .{});
    }

    // ---- collision check against existing objects
    if (repo_mod.repo_ != null) {
        const odb = repo_mod.repo().odb();
        for (res.entries.items, 0..) |_, k| {
            if (std.mem.indexOfScalar(u32, appended.items, @intCast(k)) != null) continue;
            const oid = res.oids.items[k];
            if (!odb.has(oid)) continue;
            const data = res.get(@intCast(k)) orelse continue;
            const o = odb.read(oid) orelse util.die("cannot read existing object {s}", .{hash.hex(oid)});
            if (o.typ != res.types.items[k] or !std.mem.eql(u8, o.data, data))
                util.die("SHA1 COLLISION FOUND WITH {s} !", .{hash.hex(oid)});
        }
    }

    if (show_stat) showPackInfo(&res, stat_only, nr_deltas);

    // ---- index
    var ient = gpa.alloc(pack.IdxEntry, total) catch util.oom();
    for (res.entries.items, 0..) |e, k| ient[k] = .{ .oid = res.oids.items[k], .offset = e.offset, .crc = e.crc };
    const idx_data = pack.buildIdx(ient, pack_sha, opts);
    const rev_data: ?[]u8 = if (rev_index) pack.buildRev(ient, pack_sha) else null;

    if (verify) {
        if (existing_idx == null or !std.mem.eql(u8, existing_idx.?, idx_data))
            util.die("sha1 file '{s}' validation error", .{index_name.?});
        return 0;
    }

    if (from_stdin) os.close(out_fd);
    const hex = hash.hex(pack_sha);
    var report: []const u8 = "pack";
    const odb_pack_dir: []const u8 = if (repo_mod.repo_) |r| util.concat(&.{ r.odb().objects_dir, "/pack/pack-", &hex, "." }) else "";
    if (keep_msg) |m| {
        const kname = if (pack_name) |p| deriveFilename(p, "pack", "keep") else util.concat(&.{ odb_pack_dir, "keep" });
        if (writeSpecial(kname, m)) report = "keep";
    }
    if (promisor_msg) |m| {
        const pname = util.concat(&.{ odb_pack_dir, "promisor" });
        _ = writeSpecial(pname, m);
    }
    // pack
    if (pack_name == null) {
        const final = util.concat(&.{ odb_pack_dir, "pack" });
        finalizeFile(curr_pack, final, "pack");
    } else if (from_stdin) {
        _ = os.chmod(pack_name.?, 0o444);
    }
    if (rev_data) |rd| {
        const final = rev_index_name orelse util.concat(&.{ odb_pack_dir, "rev" });
        writeIdxLike(final, rd);
    }
    {
        const final = index_name orelse util.concat(&.{ odb_pack_dir, "idx" });
        writeIdxLike(final, idx_data);
    }
    if (!from_stdin) {
        util.outf("{s}\n", .{hex});
    } else {
        util.outf("{s}\t{s}\n", .{ report, hex });
        util.flushStdout();
        os.writeAll(1, in.data.items[in.pos..]) catch {};
    }
    return 0;
}

fn writeIdxLike(path: []const u8, data: []const u8) void {
    _ = os.unlink(path);
    pack.writeNewFile(path, data, 0o444);
}

fn finalizeFile(tmp: []const u8, final: []const u8, ext: []const u8) void {
    _ = os.chmod(tmp, 0o444);
    if (os.exists(final)) {
        // finalize_object_file: existing file is kept
        _ = os.unlink(tmp);
        return;
    }
    if (!os.link(tmp, final)) {
        if (!os.rename(tmp, final)) util.die("unable to rename temporary '*.{s}' file to '{s}'", .{ ext, final });
        return;
    }
    _ = os.unlink(tmp);
}

fn writeSpecial(path: []const u8, msg: []const u8) bool {
    _ = os.mkdirLeading(path);
    const fd = os.openFile(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666);
    if (fd < 0) {
        if (os.errno() != os.EEXIST) util.dieErrno("cannot write {s} file '{s}'", .{ util.basename(path), path });
        return false;
    }
    if (msg.len > 0) {
        os.writeAll(fd, msg) catch {};
        os.writeAll(fd, "\n") catch {};
    }
    os.close(fd);
    return true;
}

fn showPackInfo(res: *pack.Resolver, stat_only: bool, nr_deltas: u32) void {
    const total = res.entries.items.len;
    var deepest: u32 = 0;
    for (res.entries.items, 0..) |e, k| {
        if (pack.isDelta(e.typ)) deepest = @max(deepest, res.depth.items[k]);
    }
    const hist = gpa.alloc(u64, deepest + 1) catch util.oom();
    @memset(hist, 0);
    for (res.entries.items, 0..) |e, k| {
        if (pack.isDelta(e.typ)) hist[res.depth.items[k] - 1] += 1;
        if (stat_only) continue;
        const sz_in_pack = e.end - e.offset;
        util.outf("{s} {s: <6} {d} {d} {d}", .{ hash.hex(res.oids.items[k]), res.types.items[k].name(), e.size, sz_in_pack, e.offset });
        if (pack.isDelta(e.typ)) {
            util.outf(" {d} {s}", .{ res.depth.items[k], hash.hex(res.oids.items[res.base_idx.items[k]]) });
        }
        util.outf("\n", .{});
    }
    const base_objects = total - nr_deltas;
    if (base_objects > 0) util.outf("non delta: {d} object{s}\n", .{ base_objects, if (base_objects == 1) "" else "s" });
    var d: u32 = 0;
    while (d < deepest) : (d += 1) {
        if (hist[d] == 0) continue;
        util.outf("chain length = {d}: {d} object{s}\n", .{ d + 1, hist[d], if (hist[d] == 1) "" else "s" });
    }
}

// ---------------------------------------------------------------- verify-pack

const verify_pack_usage = [_][]const u8{"git verify-pack [-v | --verbose] [-s | --stat-only] [--] <pack>.idx..."};

pub fn cmdVerifyPack(args: []const []const u8) u8 {
    var verbose = false;
    var stat_only = false;
    var object_format: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.boolean('v', "verbose", &verbose, "verbose"),
        po.boolean('s', "stat-only", &stat_only, "show statistics only"),
        po.string(0, "object-format", &object_format, "hash", "specify the hash algorithm to use"),
    };
    const rest = po.parse(args[1..], &options, &verify_pack_usage, .{});
    if (rest.len < 1) po.usageWithOptions(&verify_pack_usage, &options);
    var err: u8 = 0;
    for (rest) |path| {
        var a = path;
        if (util.endsWith(a, ".idx")) {
            a = util.concat(&.{ a[0 .. a.len - 4], ".pack" });
        } else if (!util.endsWith(a, ".pack")) a = util.concat(&.{ a, ".pack" });
        var argv: std.ArrayList([]const u8) = .empty;
        argv.appendSlice(gpa, &.{ proc.gitBinary(), "index-pack" }) catch util.oom();
        argv.append(gpa, if (stat_only) "--verify-stat-only" else if (verbose) "--verify-stat" else "--verify") catch util.oom();
        if (object_format) |f| argv.append(gpa, util.concat(&.{ "--object-format=", f })) catch util.oom();
        argv.append(gpa, a) catch util.oom();
        const r = os.run(argv.items, .{});
        const failed = r.signaled or r.status != 0;
        if (verbose or stat_only) {
            if (failed) {
                util.outf("{s}: bad\n", .{a});
            } else if (!stat_only) util.outf("{s}: ok\n", .{a});
        }
        if (failed) err = 1;
    }
    return err;
}

// ---------------------------------------------------------------- show-index

const show_index_usage = [_][]const u8{"git show-index [--object-format=<hash-algorithm>] < <pack-idx-file>"};

pub fn cmdShowIndex(args: []const []const u8) u8 {
    var object_format: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.string(0, "object-format", &object_format, "hash-algorithm", "specify the hash algorithm to use"),
    };
    _ = po.parse(args[1..], &options, &show_index_usage, .{});
    if (object_format) |f| {
        if (!util.eql(f, "sha1")) util.die("Unknown hash algorithm", .{});
    } else if (repo_mod.repo_ == null) {
        util.warn("assuming SHA-1; use --object-format to override", .{});
    }
    const data = os.readAllFd(0) catch util.die("unable to read header", .{});
    var pos: usize = 0;
    if (data.len < 8) util.die("unable to read header", .{});
    var version: u32 = 1;
    var fan: [256]u32 = undefined;
    if (std.mem.eql(u8, data[0..4], "\xfftOc")) {
        version = std.mem.readInt(u32, data[4..8], .big);
        if (version != 2) util.die("unknown index version", .{});
        pos = 8;
    }
    if (data.len < pos + 1024) util.die("unable to read index", .{});
    for (&fan, 0..) |*f, k| f.* = std.mem.readInt(u32, data[pos + 4 * k ..][0..4], .big);
    pos += 1024;
    var nr: u32 = 0;
    for (fan) |f| {
        if (f < nr) util.die("corrupt index file", .{});
        nr = f;
    }
    if (version == 1) {
        var k: u32 = 0;
        while (k < nr) : (k += 1) {
            if (data.len < pos + 24) util.die("unable to read entry {d}/{d}", .{ k, nr });
            const off = std.mem.readInt(u32, data[pos..][0..4], .big);
            util.outf("{d} {s}\n", .{ off, hash.hex(data[pos + 4 ..][0..20].*) });
            pos += 24;
        }
        return 0;
    }
    const oids_at = pos;
    if (data.len < pos + 20 * @as(usize, nr)) util.die("unable to read sha1 {d}/{d}", .{ (data.len - pos) / 20, nr });
    pos += 20 * @as(usize, nr);
    const crc_at = pos;
    if (data.len < pos + 4 * @as(usize, nr)) util.die("unable to read crc {d}/{d}", .{ (data.len - pos) / 4, nr });
    pos += 4 * @as(usize, nr);
    const off_at = pos;
    if (data.len < pos + 4 * @as(usize, nr)) util.die("unable to read 32b offset {d}/{d}", .{ (data.len - pos) / 4, nr });
    pos += 4 * @as(usize, nr);
    var off64_nr: u32 = 0;
    var k: usize = 0;
    while (k < nr) : (k += 1) {
        const off = std.mem.readInt(u32, data[off_at + 4 * k ..][0..4], .big);
        var offset: u64 = off;
        if (off & 0x80000000 != 0) {
            if ((off & 0x7fffffff) != off64_nr) util.die("inconsistent 64b offset index", .{});
            if (data.len < pos + 8) util.die("unable to read 64b offset {d}", .{off64_nr});
            offset = std.mem.readInt(u64, data[pos..][0..8], .big);
            pos += 8;
            off64_nr += 1;
        }
        const crc = std.mem.readInt(u32, data[crc_at + 4 * k ..][0..4], .big);
        util.outf("{d} {s} ({x:0>8})\n", .{ offset, hash.hex(data[oids_at + 20 * k ..][0..20].*), crc });
    }
    return 0;
}

// ---------------------------------------------------------------- unpack-objects

const unpack_usage = "git unpack-objects [-n] [-q] [-r] [--strict]";

pub fn cmdUnpackObjects(args: []const []const u8) u8 {
    var dry_run = false;
    var quiet = !os.isatty(2);
    showUsageIfAsked(args, unpack_usage);
    for (args[1..]) |arg| {
        if (arg.len > 0 and arg[0] == '-') {
            if (util.eql(arg, "-n")) {
                dry_run = true;
                continue;
            }
            if (util.eql(arg, "-q")) {
                quiet = true;
                continue;
            }
            if (util.eql(arg, "-r")) continue;
            if (util.eql(arg, "--strict") or util.startsWith(arg, "--strict=")) continue;
            if (util.startsWith(arg, "--pack_header=")) util.die("bad --pack_header: {s}", .{arg[14..]});
            if (util.startsWith(arg, "--max-input-size=")) continue;
            usageDie(unpack_usage);
        }
        usageDie(unpack_usage);
    }
    const odb = repo_mod.repo().odb();
    var in = pack.Input{ .fd = 0 };
    in.fill(12);
    const h = in.data.items[0..12];
    if (!std.mem.eql(u8, h[0..4], "PACK")) util.die("bad pack file", .{});
    const ver = std.mem.readInt(u32, h[4..8], .big);
    if (ver != 2 and ver != 3) util.die("unknown pack file version {d}", .{ver});
    const nr = std.mem.readInt(u32, h[8..12], .big);
    in.pos = 12;
    var prog: ?*progress.Progress = null;
    if (!quiet) prog = progress.start("Unpacking objects", nr);
    var res = pack.Resolver{};
    var k: u32 = 0;
    while (k < nr) : (k += 1) {
        const e = pack.readEntry(&in);
        res.add(e);
        progress.update(prog, k + 1);
    }
    const sum = hash.hashData(in.data.items[0..in.pos]);
    var unresolved = res.resolveAll();
    var ext: std.ArrayList(u32) = .empty;
    var tried: hash.OidSet = .empty;
    while (unresolved > 0) {
        const base = res.firstMissingBase(&tried) orelse break;
        tried.put(gpa, base, {}) catch util.oom();
        const o = odb.read(base) orelse continue;
        ext.append(gpa, res.addExternal(o.typ, @constCast(o.data))) catch util.oom();
        unresolved = res.resolveAll();
    }
    if (!dry_run) {
        for (res.entries.items, 0..) |_, j| {
            if (j >= nr) break;
            if (!res.done.items[j]) continue;
            const data = res.get(@intCast(j)) orelse continue;
            _ = odb.write(res.types.items[j], data);
        }
    }
    if (prog) |p| p.stop();
    if (unresolved > 0) util.die("unresolved deltas left after unpacking", .{});
    in.fill(20);
    if (!std.mem.eql(u8, in.data.items[in.pos..][0..20], &sum)) util.die("final sha1 did not match", .{});
    in.pos += 20;
    os.writeAll(1, in.data.items[in.pos..]) catch {};
    return 0;
}
