//! Multi-pack-index reading and writing (midx.c, midx-write.c).
//! Bitmap (.bitmap) files are never written.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const progress = @import("progress.zig");
const lockfile = @import("lockfile.zig");
const proc = @import("proc.zig");
const config = @import("config.zig");
const cg = @import("commitgraph.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

const SIGNATURE: u32 = 0x4d494458;
const HEADER_SIZE = 12;
const RAWSZ = 20;
const HEXSZ = 40;
const CHUNK_ALIGNMENT = 4;
const ID_PACKNAMES: u32 = 0x504e414d;
const ID_OIDFANOUT: u32 = 0x4f494446;
const ID_OIDLOOKUP: u32 = 0x4f49444c;
const ID_OBJECTOFFSETS: u32 = 0x4f4f4646;
const ID_LARGEOFFSETS: u32 = 0x4c4f4646;
const ID_REVINDEX: u32 = 0x52494458;
const ID_BITMAPPEDPACKS: u32 = 0x42544d50;
const LARGE_OFFSET_NEEDED: u32 = 0x80000000;
const PACK_EXPIRED: u32 = 0xffffffff;
const NO_PREFERRED: u32 = 0xffffffff;
const BITMAP_POS_UNKNOWN: u32 = 0xffffffff;

pub const PROGRESS: u32 = 1 << 0;
pub const WRITE_REV_INDEX: u32 = 1 << 1;
pub const WRITE_BITMAP: u32 = 1 << 2;
pub const WRITE_BITMAP_HASH_CACHE: u32 = 1 << 3;
pub const WRITE_BITMAP_LOOKUP_TABLE: u32 = 1 << 4;
pub const WRITE_INCREMENTAL: u32 = 1 << 5;
pub const WRITE_COMPACT: u32 = 1 << 6;
pub const WRITE_NO_CHAIN: u32 = 1 << 7;

fn be32(b: []const u8, off: usize) u32 {
    return std.mem.readInt(u32, b[off..][0..4], .big);
}
fn be64(b: []const u8, off: usize) u64 {
    return std.mem.readInt(u64, b[off..][0..8], .big);
}
fn put32(b: *util.Buf, v: u32) void {
    var t: [4]u8 = undefined;
    std.mem.writeInt(u32, &t, v, .big);
    b.appendSlice(gpa, &t) catch util.oom();
}
fn put64(b: *util.Buf, v: u64) void {
    var t: [8]u8 = undefined;
    std.mem.writeInt(u64, &t, v, .big);
    b.appendSlice(gpa, &t) catch util.oom();
}

fn envBool(name: []const u8, def: bool) bool {
    const v = os.getenv(name) orelse return def;
    return config.configBool(name, v);
}

// ---------------------------------------------------------------- packs

/// A pack as seen by the MIDX code (struct packed_git subset).
pub const PackGit = struct {
    idx_path: []const u8,
    pack_path: []const u8,
    mtime: i64,
    size: u64,
    keep: bool,
    cruft: bool,
    idx: ?*odb_mod.Pack = null,
    idx_failed: bool = false,
    valid: ?bool = null,

    pub fn openIndex(self: *PackGit) bool {
        if (self.idx != null) return true;
        if (self.idx_failed) return false;
        if (!checkIdx(self.idx_path)) {
            self.idx_failed = true;
            return false;
        }
        self.idx = odb_mod.openIdx(self.idx_path, self.pack_path);
        if (self.idx == null) self.idx_failed = true;
        return self.idx != null;
    }

    pub fn numObjects(self: *const PackGit) u32 {
        return if (self.idx) |p| p.num else 0;
    }

    fn fanout(self: *const PackGit, i: usize) u32 {
        const p = self.idx.?;
        return be32(p.idx, p.fanout_off + i * 4);
    }

    /// is_pack_valid(): the pack file must open and match its index.
    fn isValid(self: *PackGit) bool {
        if (self.valid) |v| return v;
        self.valid = self.checkPack();
        return self.valid.?;
    }

    fn checkPack(self: *PackGit) bool {
        if (!self.openIndex()) {
            util.err("packfile {s} index unavailable", .{self.pack_path});
            return false;
        }
        const data = os.readFile(self.pack_path) orelse return false;
        if (data.len < 12 + RAWSZ) {
            util.err("file {s} is far too short to be a packfile", .{self.pack_path});
            return false;
        }
        if (!std.mem.eql(u8, data[0..4], "PACK")) {
            util.err("file {s} is not a GIT packfile", .{self.pack_path});
            return false;
        }
        const ver = be32(data, 4);
        if (ver != 2 and ver != 3) {
            util.err("packfile {s} is version {d} and not supported (try upgrading GIT to a newer version)", .{ self.pack_path, ver });
            return false;
        }
        const p = self.idx.?;
        const n = be32(data, 8);
        if (n != p.num) {
            util.err("packfile {s} claims to have {d} objects while index indicates {d} objects", .{ self.pack_path, n, p.num });
            return false;
        }
        const ih = p.idx[p.idx.len - 2 * RAWSZ ..][0..RAWSZ];
        if (!std.mem.eql(u8, data[data.len - RAWSZ ..], ih)) {
            util.err("packfile {s} does not match index", .{self.pack_path});
            return false;
        }
        return true;
    }
};

/// load_idx() validation (prints the same errors as git).
fn checkIdx(path: []const u8) bool {
    const d = os.readFile(path) orelse return false;
    if (d.len < 4 * 256 + 2 * RAWSZ) {
        util.err("index file {s} is too small", .{path});
        return false;
    }
    var version: u32 = 1;
    var off: usize = 0;
    if (std.mem.eql(u8, d[0..4], "\xfftOc")) {
        version = be32(d, 4);
        if (version != 2) {
            util.err("index file {s} is version {d} and is not supported by this binary (try upgrading GIT to a newer version)", .{ path, version });
            return false;
        }
        off = 8;
    }
    var nr: u32 = 0;
    var i: usize = 0;
    while (i < 256) : (i += 1) {
        const n = be32(d, off + i * 4);
        if (n < nr) {
            util.err("non-monotonic index {s}", .{path});
            return false;
        }
        nr = n;
    }
    if (version == 1) {
        if (d.len != 4 * 256 + 2 * RAWSZ + @as(usize, nr) * (RAWSZ + 4)) {
            util.err("wrong index v1 file size in {s}", .{path});
            return false;
        }
    } else {
        const min = 8 + 4 * 256 + 2 * RAWSZ + @as(usize, nr) * (RAWSZ + 8);
        var max = min;
        if (nr > 0) max += (@as(usize, nr) - 1) * 8;
        if (d.len < min or d.len > max) {
            util.err("wrong index v2 file size in {s}", .{path});
            return false;
        }
    }
    return true;
}

/// add_packed_git(): null when the .pack is missing.
fn addPackedGit(idx_path: []const u8) ?*PackGit {
    if (!util.endsWith(idx_path, ".idx")) return null;
    const base = idx_path[0 .. idx_path.len - 4];
    const pack_path = util.concat(&.{ base, ".pack" });
    const st = os.statPath(pack_path) orelse return null;
    if (st.isDir()) return null;
    const p = gpa.create(PackGit) catch util.oom();
    p.* = .{
        .idx_path = idx_path,
        .pack_path = pack_path,
        .mtime = st.mtime,
        .size = @intCast(st.size),
        .keep = os.exists(util.concat(&.{ base, ".keep" })),
        .cruft = os.exists(util.concat(&.{ base, ".mtimes" })),
    };
    return p;
}

/// find_pack_entry_one(): offset of oid in pack, 0 if absent.
fn packOffsetOf(p: *PackGit, oid: Oid) u64 {
    const ix = p.idx orelse return 0;
    const i = ix.find(oid) orelse return 0;
    return ix.offsetAt(i);
}

/// Match "foo.idx" against either "foo.pack" or "foo.idx".
pub fn cmpIdxOrPackName(idx_or_pack_name: []const u8, idx_name: []const u8) std.math.Order {
    var i: usize = 0;
    while (i < idx_name.len and i < idx_or_pack_name.len and idx_name[i] == idx_or_pack_name[i]) i += 1;
    const a = idx_or_pack_name[i..];
    const b = idx_name[i..];
    if (util.eql(b, "idx") and util.eql(a, "pack")) return .eq;
    return std.mem.order(u8, a, b);
}

// ---------------------------------------------------------------- reading

pub const Midx = struct {
    data: []const u8,
    source: []const u8,
    version: u8,
    num_packs: u32,
    num_objects: u32 = 0,
    fanout_off: usize = 0,
    oidl_off: usize = 0,
    ooff_off: usize = 0,
    loff: ?cg.Chunk = null,
    ridx: ?cg.Chunk = null,
    btmp: ?cg.Chunk = null,
    pack_names: [][]const u8 = &.{},
    sorted: ?[]u32 = null,
    packs: []?*PackGit = &.{},
    pack_err: []bool = &.{},
    base: ?*Midx = null,
    num_packs_in_base: u32 = 0,
    num_objects_in_base: u32 = 0,
    has_chain: bool = false,

    pub fn checksum(self: *const Midx) Oid {
        return self.data[self.data.len - RAWSZ ..][0..RAWSZ].*;
    }

    pub fn checksumHex(self: *const Midx) []u8 {
        return hash.hexAlloc(self.checksum());
    }

    pub fn checksumValid(self: *const Midx) bool {
        var h = hash.Hasher.init(.{});
        h.update(self.data[0 .. self.data.len - RAWSZ]);
        var d: Oid = undefined;
        h.final(&d);
        return hash.eql(d, self.checksum());
    }

    fn totalObjects(self: *const Midx) u32 {
        return self.num_objects + self.num_objects_in_base;
    }

    fn totalPacks(self: *const Midx) u32 {
        return self.num_packs + self.num_packs_in_base;
    }

    fn fanout(self: *const Midx, i: usize) u32 {
        return be32(self.data, self.fanout_off + i * 4);
    }

    fn localOid(self: *const Midx, n: u32) Oid {
        return self.data[self.oidl_off + @as(usize, n) * RAWSZ ..][0..RAWSZ].*;
    }
};

fn forObject(m0: *Midx, pos: u32) struct { m: *Midx, n: u32 } {
    var m: ?*Midx = m0;
    while (m) |x| {
        if (pos >= x.num_objects_in_base) break;
        m = x.base;
    }
    const x = m orelse util.die("BUG: NULL multi-pack-index for object position: {d}", .{pos});
    if (pos >= x.totalObjects()) util.die("invalid MIDX object position, MIDX is likely corrupt", .{});
    return .{ .m = x, .n = pos - x.num_objects_in_base };
}

fn forPack(m0: *Midx, id: u32) struct { m: *Midx, n: u32 } {
    var m: ?*Midx = m0;
    while (m) |x| {
        if (id >= x.num_packs_in_base) break;
        m = x.base;
    }
    const x = m orelse util.die("BUG: NULL multi-pack-index for pack ID: {d}", .{id});
    if (id >= x.totalPacks()) util.die("bad pack-int-id: {d} ({d} total packs)", .{ id, x.totalPacks() });
    return .{ .m = x, .n = id - x.num_packs_in_base };
}

pub fn nthOid(m: *Midx, pos: u32) Oid {
    const r = forObject(m, pos);
    return r.m.localOid(r.n);
}

pub fn nthOffset(m: *Midx, pos: u32) u64 {
    const r = forObject(m, pos);
    const off32 = be32(r.m.data, r.m.ooff_off + @as(usize, r.n) * 8 + 4);
    if (r.m.loff) |lo| {
        if (off32 & LARGE_OFFSET_NEEDED != 0) {
            const k = off32 ^ LARGE_OFFSET_NEEDED;
            if (k >= lo.size / 8) util.die("multi-pack-index large offset out of bounds", .{});
            return be64(r.m.data, lo.start + @as(usize, k) * 8);
        }
    }
    return off32;
}

pub fn nthPackIntId(m: *Midx, pos: u32) u32 {
    const r = forObject(m, pos);
    return r.m.num_packs_in_base + be32(r.m.data, r.m.ooff_off + @as(usize, r.n) * 8);
}

/// prepare_midx_pack(): true on success.
pub fn preparePack(m0: *Midx, id: u32) bool {
    const r = forPack(m0, id);
    const m = r.m;
    if (m.pack_err[r.n]) return false;
    if (m.packs[r.n] != null) return true;
    const path = util.concat(&.{ m.source, "/pack/", m.pack_names[r.n] });
    const p = addPackedGit(path) orelse {
        m.pack_err[r.n] = true;
        return false;
    };
    m.packs[r.n] = p;
    return true;
}

pub fn packAt(m0: *Midx, id: u32) *PackGit {
    const r = forPack(m0, id);
    return r.m.packs[r.n].?;
}

fn packNameAt(m0: *Midx, id: u32) []const u8 {
    const r = forPack(m0, id);
    return r.m.pack_names[r.n];
}

fn bsearchOne(m: *Midx, oid: Oid) ?u32 {
    var lo: u32 = if (oid[0] == 0) 0 else m.fanout(oid[0] - 1);
    var hi: u32 = m.fanout(oid[0]);
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        switch (hash.order(oid, m.localOid(mid))) {
            .eq => return mid + m.num_objects_in_base,
            .lt => hi = mid,
            .gt => lo = mid + 1,
        }
    }
    return null;
}

pub fn bsearch(m0: *Midx, oid: Oid) ?u32 {
    var m: ?*Midx = m0;
    while (m) |x| : (m = x.base) {
        if (bsearchOne(x, oid)) |p| return p;
    }
    return null;
}

fn layerContainsPack(m: *Midx, name: []const u8) bool {
    if (m.version == 2 and m.sorted == null) {
        const s = gpa.alloc(u32, m.num_packs) catch util.oom();
        for (s, 0..) |*v, i| v.* = @intCast(i);
        std.mem.sort(u32, s, m, struct {
            fn lt(mm: *Midx, a: u32, b: u32) bool {
                return std.mem.order(u8, mm.pack_names[a], mm.pack_names[b]) == .lt;
            }
        }.lt);
        m.sorted = s;
    }
    var first: u32 = 0;
    var last: u32 = m.num_packs;
    while (first < last) {
        const mid = first + (last - first) / 2;
        const cur = if (m.sorted) |s| m.pack_names[s[mid]] else m.pack_names[mid];
        switch (cmpIdxOrPackName(name, cur)) {
            .eq => return true,
            .gt => first = mid + 1,
            .lt => last = mid,
        }
    }
    return false;
}

pub fn containsPack(m0: *Midx, name: []const u8) bool {
    var m: ?*Midx = m0;
    while (m) |x| : (m = x.base) {
        if (layerContainsPack(x, name)) return true;
    }
    return false;
}

pub fn midxFilename(source: []const u8) []u8 {
    return util.concat(&.{ source, "/pack/multi-pack-index" });
}
fn midxFilenameExt(source: []const u8, hx: []const u8, ext: []const u8) []u8 {
    return util.concat(&.{ source, "/pack/multi-pack-index-", hx, ".", ext });
}
pub fn chainDirname(source: []const u8) []u8 {
    return util.concat(&.{ source, "/pack/multi-pack-index.d" });
}
pub fn chainFilename(source: []const u8) []u8 {
    return util.concat(&.{ source, "/pack/multi-pack-index.d/multi-pack-index-chain" });
}
fn splitFilenameExt(source: []const u8, hx: []const u8, ext: []const u8) []u8 {
    return util.concat(&.{ source, "/pack/multi-pack-index.d/multi-pack-index-", hx, ".", ext });
}

fn loadOne(source: []const u8, path: []const u8) ?*Midx {
    const st = os.statPath(path) orelse return null;
    if (st.isDir()) return null;
    const data = os.readFile(path) orelse return null;
    if (data.len < HEADER_SIZE + RAWSZ) {
        util.err("multi-pack-index file {s} is too small", .{path});
        return null;
    }
    const sig = be32(data, 0);
    if (sig != SIGNATURE)
        util.die("multi-pack-index signature 0x{x:0>8} does not match signature 0x{x:0>8}", .{ sig, SIGNATURE });
    const version = data[4];
    if (version != 1 and version != 2) util.die("multi-pack-index version {d} not recognized", .{version});
    const hv = data[5];
    if (hv != 1) {
        util.err("multi-pack-index hash version {d} does not match version {d}", .{ hv, 1 });
        return null;
    }
    const m = gpa.create(Midx) catch util.oom();
    m.* = .{ .data = data, .source = source, .version = version, .num_packs = be32(data, 8) };
    const num_chunks = data[6];
    var chunks: std.ArrayList(cg.Chunk) = .empty;
    if (!cg.readTocAligned(data, HEADER_SIZE, num_chunks, CHUNK_ALIGNMENT, &chunks)) return null;

    const pn = cg.findChunk(chunks.items, ID_PACKNAMES) orelse
        util.die("multi-pack-index required pack-name chunk missing or corrupted", .{});
    const fo = cg.findChunk(chunks.items, ID_OIDFANOUT) orelse
        util.die("multi-pack-index required OID fanout chunk missing or corrupted", .{});
    if (fo.size != 4 * 256) {
        util.err("multi-pack-index OID fanout is of the wrong size", .{});
        util.die("multi-pack-index required OID fanout chunk missing or corrupted", .{});
    }
    m.fanout_off = fo.start;
    var i: usize = 0;
    while (i < 255) : (i += 1) {
        const a = m.fanout(i);
        const b = m.fanout(i + 1);
        if (a > b) {
            util.err("oid fanout out of order: fanout[{d}] = {x} > {x} = fanout[{d}]", .{ i, a, b, i + 1 });
            util.die("multi-pack-index required OID fanout chunk missing or corrupted", .{});
        }
    }
    m.num_objects = m.fanout(255);
    const ol = cg.findChunk(chunks.items, ID_OIDLOOKUP) orelse
        util.die("multi-pack-index required OID lookup chunk missing or corrupted", .{});
    if (ol.size != @as(usize, m.num_objects) * RAWSZ) {
        util.err("multi-pack-index OID lookup chunk is the wrong size", .{});
        util.die("multi-pack-index required OID lookup chunk missing or corrupted", .{});
    }
    m.oidl_off = ol.start;
    const oo = cg.findChunk(chunks.items, ID_OBJECTOFFSETS) orelse
        util.die("multi-pack-index required object offsets chunk missing or corrupted", .{});
    if (oo.size != @as(usize, m.num_objects) * 8) {
        util.err("multi-pack-index object offset chunk is the wrong size", .{});
        util.die("multi-pack-index required object offsets chunk missing or corrupted", .{});
    }
    m.ooff_off = oo.start;
    m.loff = cg.findChunk(chunks.items, ID_LARGEOFFSETS);
    if (envBool("GIT_TEST_MIDX_READ_BTMP", true)) m.btmp = cg.findChunk(chunks.items, ID_BITMAPPEDPACKS);
    if (envBool("GIT_TEST_MIDX_READ_RIDX", true)) m.ridx = cg.findChunk(chunks.items, ID_REVINDEX);

    m.pack_names = gpa.alloc([]const u8, m.num_packs) catch util.oom();
    m.packs = gpa.alloc(?*PackGit, m.num_packs) catch util.oom();
    m.pack_err = gpa.alloc(bool, m.num_packs) catch util.oom();
    @memset(m.packs, null);
    @memset(m.pack_err, false);
    var cur: usize = pn.start;
    const end = pn.start + pn.size;
    var k: usize = 0;
    while (k < m.num_packs) : (k += 1) {
        const nul = std.mem.indexOfScalarPos(u8, data[0..end], cur, 0) orelse
            util.die("multi-pack-index pack-name chunk is too short", .{});
        m.pack_names[k] = data[cur..nul];
        cur = nul + 1;
        if (m.version == 1 and k > 0 and std.mem.order(u8, m.pack_names[k], m.pack_names[k - 1]) != .gt)
            util.die("multi-pack-index pack names out of order: '{s}' before '{s}'", .{ m.pack_names[k - 1], m.pack_names[k] });
    }
    return m;
}

fn loadChain(source: []const u8) ?*Midx {
    const path = chainFilename(source);
    const st = os.statPath(path) orelse return null;
    const data = os.readFile(path) orelse return null;
    if (st.size < HEXSZ) {
        if (st.size != 0) util.warn("multi-pack-index chain file too small", .{});
        return null;
    }
    const count: usize = @intCast(@divTrunc(st.size, HEXSZ + 1));
    var chain: ?*Midx = null;
    var it = std.mem.splitScalar(u8, data, '\n');
    var i: usize = 0;
    while (i < count) : (i += 1) {
        const line = it.next() orelse break;
        if (line.len == 0 and it.peek() == null) break;
        const layer = hash.fromHex(line) orelse {
            util.warn("invalid multi-pack-index chain: line '{s}' not a hash", .{line});
            break;
        };
        const m = loadOne(source, splitFilenameExt(source, &hash.hex(layer), "midx")) orelse {
            util.warn("unable to find all multi-pack index files", .{});
            break;
        };
        if (chain) |c| {
            m.num_packs_in_base = c.num_packs + c.num_packs_in_base;
            m.num_objects_in_base = c.num_objects + c.num_objects_in_base;
        }
        m.base = chain;
        m.has_chain = true;
        chain = m;
    }
    return chain;
}

/// load_multi_pack_index(): the single file, else the chain.
pub fn load(source: []const u8) ?*Midx {
    return loadOne(source, midxFilename(source)) orelse loadChain(source);
}

var cache_source: ?[]const u8 = null;
var cache_midx: ?*Midx = null;

/// get_multi_pack_index(): honours core.multiPackIndex, cached per source.
pub fn get(source: []const u8) ?*Midx {
    var enabled = repo_mod.cfg.getBool("core.multipackindex") orelse true;
    if (envBool("GIT_TEST_MULTI_PACK_INDEX", false)) enabled = true;
    if (!enabled) return null;
    if (cache_source) |s| {
        if (util.eql(s, source)) return cache_midx;
    }
    cache_source = source;
    cache_midx = load(source);
    return cache_midx;
}

fn closeCache() void {
    cache_source = null;
    cache_midx = null;
}

/// load_midx_revindex(): RIDX chunk or a .rev file.
fn hasRevindex(m: *Midx) bool {
    if (m.ridx != null) return true;
    const hx = m.checksumHex();
    const path = if (m.has_chain) splitFilenameExt(m.source, hx, "rev") else midxFilenameExt(m.source, hx, "rev");
    return os.exists(path);
}

/// pack_pos_to_midx(m, pos) for the first object of layer m.
fn firstPackPosToMidx(m: *Midx) ?u32 {
    if (m.ridx) |r| {
        if (r.size < 4) return null;
        return be32(m.data, r.start);
    }
    const hx = m.checksumHex();
    const path = if (m.has_chain) splitFilenameExt(m.source, hx, "rev") else midxFilenameExt(m.source, hx, "rev");
    const d = os.readFile(path) orelse return null;
    if (d.len < 16) return null;
    return be32(d, 12) + m.num_objects_in_base;
}

fn preferredPack(m: *Midx) ?u32 {
    const pos = firstPackPosToMidx(m) orelse return null;
    if (pos >= m.totalObjects()) return null;
    return nthPackIntId(m, pos);
}

// ---------------------------------------------------------------- clearing

fn clearExtIn(dir: []const u8, ext: []const u8, keep: []const []const u8) void {
    const ents = os.listDir(dir) orelse return;
    for (ents) |e| {
        if (!util.startsWith(e.name, "multi-pack-index-") or !util.endsWith(e.name, ext)) continue;
        var kept = false;
        for (keep) |k| {
            if (util.eql(k, e.name)) kept = true;
        }
        if (kept) continue;
        const full = util.concat(&.{ dir, "/", e.name });
        if (!os.unlink(full)) util.dieErrno("failed to remove {s}", .{full});
    }
}

/// clear_midx_files_ext()
pub fn clearMidxFilesExt(source: []const u8, ext: []const u8, keep_hash: ?[]const u8) void {
    var keep: std.ArrayList([]const u8) = .empty;
    if (keep_hash) |h| keep.append(gpa, util.concat(&.{ "multi-pack-index-", h, ".", ext })) catch util.oom();
    clearExtIn(util.concat(&.{ source, "/pack" }), ext, keep.items);
}

fn clearIncrementalExt(source: []const u8, ext: []const u8, hashes: []const []const u8) void {
    var keep: std.ArrayList([]const u8) = .empty;
    for (hashes) |h| keep.append(gpa, util.concat(&.{ "multi-pack-index-", h, ".", ext })) catch util.oom();
    clearExtIn(chainDirname(source), ext, keep.items);
}

fn clearMidxFiles(source: []const u8, hashes: []const []const u8, incremental: bool) void {
    for ([_][]const u8{ "bitmap", "rev", "midx" }) |ext| {
        clearIncrementalExt(source, ext, hashes);
        for (hashes) |h| clearMidxFilesExt(source, ext, h);
    }
    const path = if (incremental) midxFilename(source) else chainFilename(source);
    if (!os.unlink(path) and os.errno() != 2)
        util.dieErrno("failed to clear multi-pack-index at {s}", .{path});
}

// ---------------------------------------------------------------- writing

const PackInfo = struct {
    orig_id: u32,
    name: []const u8,
    p: *PackGit,
    expired: bool = false,
    bitmap_pos: u32 = BITMAP_POS_UNKNOWN,
    bitmap_nr: u32 = 0,
};

const Entry = struct {
    oid: Oid,
    pack_int_id: u32,
    mtime: i64,
    offset: u64,
    preferred: bool,
};

fn entryLess(_: void, a: Entry, b: Entry) bool {
    switch (hash.order(a.oid, b.oid)) {
        .lt => return true,
        .gt => return false,
        .eq => {},
    }
    if (a.preferred != b.preferred) return a.preferred;
    if (a.mtime != b.mtime) return a.mtime > b.mtime;
    return a.pack_int_id < b.pack_int_id;
}

pub const WriteOpts = struct {
    source: []const u8,
    packs_to_include: ?[]const []const u8 = null,
    packs_to_drop: ?[]const []const u8 = null,
    compact_from: ?*Midx = null,
    compact_to: ?*Midx = null,
    preferred_pack_name: ?[]const u8 = null,
    refs_snapshot: ?[]const u8 = null,
    incremental_base: ?[]const u8 = null,
    flags: u32 = 0,
};

const Ctx = struct {
    o: *const WriteOpts,
    version: i64,
    incremental: bool,
    compact: bool,
    m: ?*Midx = null,
    base: ?*Midx = null,
    info: std.ArrayList(PackInfo) = .empty,
    entries: std.ArrayList(Entry) = .empty,
    preferred: u32 = NO_PREFERRED,
    pack_perm: []u32 = &.{},

    fn perm(self: *const Ctx, orig: u32) u32 {
        var id = orig;
        if (self.compact) id -= self.o.compact_from.?.num_packs_in_base;
        return self.pack_perm[id];
    }

    fn fillPackFromMidx(self: *Ctx, m: *Midx, id: u32) bool {
        if (!preparePack(m, id)) {
            util.err("could not load pack {d}", .{id});
            return false;
        }
        self.info.append(gpa, .{ .orig_id = id, .name = packNameAt(m, id), .p = packAt(m, id) }) catch util.oom();
        return true;
    }

    fn fillPacksFromMidx(self: *Ctx) bool {
        var m = self.m;
        while (m) |x| : (m = x.base) {
            var i = x.num_packs_in_base;
            while (i < x.totalPacks()) : (i += 1) {
                if (!self.fillPackFromMidx(x, i)) return false;
            }
        }
        return true;
    }

    fn fillPacksFromMidxRange(self: *Ctx, bitmap_order: bool) bool {
        const from = self.o.compact_from.?;
        const to = self.o.compact_to.?;
        const nr = to.totalPacks() - from.num_packs_in_base;
        const slots = gpa.alloc(?PackInfo, nr) catch util.oom();
        @memset(slots, null);
        var m: ?*Midx = to;
        while (m) |x| {
            if (x == from.base) break;
            var pref: u32 = x.num_packs_in_base;
            if (bitmap_order) pref = preferredPack(x) orelse util.die("could not determine preferred pack", .{});
            var slot = x.num_packs_in_base - from.num_packs_in_base;
            if (!preparePack(x, pref)) {
                util.err("could not load pack {d}", .{pref});
                return false;
            }
            slots[slot] = .{ .orig_id = pref, .name = packNameAt(x, pref), .p = packAt(x, pref) };
            slot += 1;
            var i = x.num_packs_in_base;
            while (i < x.totalPacks()) : (i += 1) {
                if (i == pref) continue;
                if (!preparePack(x, i)) {
                    util.err("could not load pack {d}", .{i});
                    return false;
                }
                slots[slot] = .{ .orig_id = i, .name = packNameAt(x, i), .p = packAt(x, i) };
                slot += 1;
            }
            m = x.base;
        }
        for (slots) |s| self.info.append(gpa, s.?) catch util.oom();
        return true;
    }

    fn shouldInclude(self: *Ctx, name: []const u8) bool {
        if (self.m) |m| {
            if (containsPack(m, name)) return false;
        }
        if (self.base) |b| {
            if (containsPack(b, name)) return false;
        }
        if (self.o.packs_to_include) |list| {
            var found = false;
            for (list) |s| {
                if (util.eql(s, name)) {
                    found = true;
                    break;
                }
            }
            if (!found) return false;
        }
        return true;
    }

    fn addPacksFromDir(self: *Ctx, prog: ?*progress.Progress) void {
        const dir = util.concat(&.{ self.o.source, "/pack" });
        const ents = os.listDir(dir) orelse return;
        var checked: u64 = 0;
        for (ents) |e| {
            if (!util.endsWith(e.name, ".idx")) continue;
            checked += 1;
            progress.update(prog, checked);
            if (!self.shouldInclude(e.name)) continue;
            const full = util.concat(&.{ dir, "/", e.name });
            const p = addPackedGit(full) orelse {
                util.warn("failed to add packfile '{s}'", .{full});
                continue;
            };
            if (!p.openIndex()) {
                util.warn("failed to open pack-index '{s}'", .{full});
                continue;
            }
            self.info.append(gpa, .{ .orig_id = @intCast(self.info.items.len), .name = e.name, .p = p }) catch util.oom();
        }
    }

    fn needsUpdate(self: *Ctx, midx: *Midx) bool {
        if (!midx.checksumValid()) return true;
        if (midx.version != self.version) return true;
        if (self.incremental or self.compact) return true;
        if (self.info.items.len != midx.totalPacks()) return true;
        var set: std.StringHashMapUnmanaged(void) = .empty;
        for (self.info.items) |pi| {
            const b = util.basename(pi.p.pack_path);
            const s = if (util.endsWith(b, ".pack")) b[0 .. b.len - 5] else b;
            set.put(gpa, s, {}) catch util.oom();
        }
        var m: ?*Midx = midx;
        while (m) |x| : (m = x.base) {
            for (x.pack_names) |n| {
                const s = if (util.endsWith(n, ".idx")) n[0 .. n.len - 4] else n;
                if (!set.remove(s)) return true;
            }
        }
        return set.count() != 0;
    }

    fn addMidxFanout1(self: *Ctx, list: *std.ArrayList(Entry), m: *Midx, bucket: usize, pref: u32) void {
        var start = m.num_objects_in_base;
        if (bucket > 0) start += m.fanout(bucket - 1);
        const end = m.num_objects_in_base + m.fanout(bucket);
        _ = self;
        var cur = start;
        while (cur < end) : (cur += 1) {
            const pid = nthPackIntId(m, cur);
            if (pref != NO_PREFERRED and pref == pid) continue;
            list.append(gpa, .{ .oid = nthOid(m, cur), .pack_int_id = pid, .offset = nthOffset(m, cur), .mtime = 0, .preferred = false }) catch util.oom();
        }
    }

    fn addMidxFanout(self: *Ctx, list: *std.ArrayList(Entry), m: *Midx, bucket: usize, pref: u32) void {
        if (m.base) |b| self.addMidxFanout(list, b, bucket, pref);
        self.addMidxFanout1(list, m, bucket, pref);
    }

    fn addPackFanout(self: *Ctx, list: *std.ArrayList(Entry), cur_pack: u32, preferred: bool, bucket: usize) void {
        const p = self.info.items[cur_pack].p;
        if (!p.openIndex()) return;
        const start: u32 = if (bucket > 0) p.fanout(bucket - 1) else 0;
        const end = p.fanout(bucket);
        const ix = p.idx.?;
        var cur = start;
        while (cur < end) : (cur += 1) {
            list.append(gpa, .{ .oid = ix.oidAt(cur), .pack_int_id = cur_pack, .mtime = p.mtime, .offset = ix.offsetAt(cur), .preferred = preferred }) catch util.oom();
        }
    }

    fn computeSortedEntries(self: *Ctx, start_pack: u32) void {
        var list: std.ArrayList(Entry) = .empty;
        var bucket: usize = 0;
        while (bucket < 256) : (bucket += 1) {
            list.clearRetainingCapacity();
            if (self.compact) {
                var m: ?*Midx = self.o.compact_to;
                while (m) |x| {
                    if (x == self.o.compact_from.?.base) break;
                    self.addMidxFanout1(&list, x, bucket, NO_PREFERRED);
                    m = x.base;
                }
            } else {
                if (self.m != null and !self.incremental) self.addMidxFanout(&list, self.m.?, bucket, self.preferred);
                var cur = start_pack;
                while (cur < self.info.items.len) : (cur += 1) {
                    self.addPackFanout(&list, cur, cur == self.preferred, bucket);
                }
                if (self.preferred != NO_PREFERRED and self.preferred < start_pack)
                    self.addPackFanout(&list, self.preferred, true, bucket);
            }
            std.mem.sort(Entry, list.items, {}, entryLess);
            for (list.items, 0..) |e, k| {
                if (k > 0 and hash.eql(list.items[k - 1].oid, e.oid)) continue;
                if (self.incremental) {
                    if (self.base) |b| {
                        if (bsearch(b, e.oid) != null) continue;
                    }
                }
                self.entries.append(gpa, e) catch util.oom();
            }
        }
    }
};

fn infoLess(_: void, a: PackInfo, b: PackInfo) bool {
    return std.mem.order(u8, a.name, b.name) == .lt;
}

const OrderData = struct { nr: u32, pack: u32, offset: u64 };

fn orderLess(_: void, a: OrderData, b: OrderData) bool {
    if (a.pack != b.pack) return a.pack < b.pack;
    return a.offset < b.offset;
}

/// write_midx_internal(): 0 on success, -1 on error.
pub fn writeInternal(o: *const WriteOpts) i32 {
    var flags = o.flags;
    var ctx = Ctx{
        .o = o,
        .version = if (flags & WRITE_COMPACT != 0) 2 else 1,
        .incremental = flags & WRITE_INCREMENTAL != 0,
        .compact = flags & WRITE_COMPACT != 0,
    };
    if (repo_mod.cfg.getInt("midx.version")) |v| ctx.version = v;
    if (ctx.version != 1 and ctx.version != 2) util.die("unknown MIDX version: {d}", .{ctx.version});
    if (ctx.compact and ctx.version != 2) util.die("cannot perform MIDX compaction with v1 format", .{});

    const source = o.source;
    const midx_name = if (ctx.incremental)
        util.concat(&.{ source, "/pack/multi-pack-index.d/tmp_midx_XXXXXX" })
    else
        midxFilename(source);
    if (!os.mkdirLeading(midx_name)) util.dieErrno("unable to create leading directories of {s}", .{midx_name});

    if (o.packs_to_include == null or ctx.incremental) {
        var m = get(source);
        if (m) |mm| {
            if (!mm.checksumValid()) {
                util.warn("ignoring existing multi-pack-index; checksum mismatch", .{});
                m = null;
            }
        }
        if (m) |mm| {
            if (ctx.incremental) ctx.base = mm;
            if (o.packs_to_include == null) ctx.m = mm;
        }
    }
    if (ctx.compact) ctx.base = o.compact_from.?.base;

    if (o.incremental_base) |ib| {
        if (util.eql(ib, "none")) {
            ctx.base = null;
        } else {
            while (ctx.base) |b| {
                if (util.eql(ib, b.checksumHex())) break;
                ctx.base = b.base;
            }
            if (ctx.base == null) {
                util.err("could not find base MIDX '{s}'", .{ib});
                return -1;
            }
        }
    }

    if (ctx.incremental) {
        var m = ctx.base;
        while (m) |x| : (m = x.base) {
            if (flags & WRITE_BITMAP != 0 and !hasRevindex(x)) {
                util.err("could not load reverse index for MIDX {s}", .{x.checksumHex()});
                return -1;
            }
        }
    } else if (ctx.m != null and !ctx.compact) {
        if (!ctx.fillPacksFromMidx()) return -1;
    }

    const start_pack: u32 = @intCast(ctx.info.items.len);
    var prog: ?*progress.Progress = null;
    if (flags & PROGRESS != 0) prog = progress.startDelayed("Adding packfiles to multi-pack-index", 0);
    if (ctx.compact) {
        const bitmap_order = o.preferred_pack_name != null or flags & (WRITE_REV_INDEX | WRITE_BITMAP) != 0;
        if (!ctx.fillPacksFromMidxRange(bitmap_order)) return -1;
    } else {
        ctx.addPacksFromDir(prog);
    }
    progress.stop(&prog);

    if (o.packs_to_drop == null) {
        const midx = ctx.m orelse load(source);
        if (midx) |mx| {
            if (!ctx.needsUpdate(mx)) {
                const want_bitmap = flags & WRITE_BITMAP != 0;
                const hx = mx.checksumHex();
                const bpath = if (mx.has_chain) splitFilenameExt(source, hx, "bitmap") else midxFilenameExt(source, hx, "bitmap");
                const bitmap_exists = os.exists(bpath);
                if (bitmap_exists or !want_bitmap) {
                    if (!want_bitmap) clearMidxFilesExt(source, "bitmap", null);
                    return 0;
                }
            }
        }
    }

    if (ctx.incremental and ctx.info.items.len == 0) return 0;

    const info = &ctx.info;
    if (o.preferred_pack_name) |pn| {
        for (info.items, 0..) |pi, i| {
            if (cmpIdxOrPackName(pn, pi.name) == .eq) {
                ctx.preferred = @intCast(i);
                break;
            }
        }
        if (ctx.preferred == NO_PREFERRED) util.warn("unknown preferred pack: '{s}'", .{pn});
    } else if (info.items.len > 0 and flags & (WRITE_REV_INDEX | WRITE_BITMAP) != 0) {
        var oldest = info.items[0].p;
        ctx.preferred = 0;
        _ = oldest.openIndex();
        var i: usize = 1;
        while (i < info.items.len) : (i += 1) {
            const p = info.items[i].p;
            if (oldest.numObjects() == 0 or p.mtime < oldest.mtime) {
                oldest = p;
                _ = oldest.openIndex();
                ctx.preferred = @intCast(i);
            }
        }
        if (oldest.numObjects() == 0) ctx.preferred = NO_PREFERRED;
    }
    if (ctx.preferred != NO_PREFERRED) {
        const pi = info.items[ctx.preferred];
        if (!pi.p.openIndex()) util.die("failed to open preferred pack {s}", .{pi.name});
        if (pi.p.numObjects() == 0) {
            util.err("cannot select preferred pack {s} with no objects", .{pi.p.pack_path});
            return -1;
        }
    }

    ctx.computeSortedEntries(start_pack);
    const entries = ctx.entries.items;

    var num_large: u32 = 0;
    var large_needed = false;
    for (entries) |e| {
        if (e.offset > 0x7fffffff) num_large += 1;
        if (e.offset > 0xffffffff) large_needed = true;
    }

    if (!ctx.compact) std.mem.sort(PackInfo, info.items, {}, infoLess);

    if (o.packs_to_drop) |drops| {
        if (drops.len > 0) {
            var di: usize = 0;
            var missing: usize = 0;
            var i: usize = 0;
            while (i < info.items.len and di < drops.len) {
                const c = std.mem.order(u8, info.items[i].name, drops[di]);
                if (c == .eq) {
                    di += 1;
                    info.items[i].expired = true;
                    i += 1;
                } else if (c == .gt) {
                    util.err("did not see pack-file {s} to drop", .{drops[di]});
                    di += 1;
                    missing += 1;
                } else {
                    info.items[i].expired = false;
                    i += 1;
                }
            }
            if (missing > 0) return -1;
        }
    }

    ctx.pack_perm = gpa.alloc(u32, info.items.len) catch util.oom();
    @memset(ctx.pack_perm, PACK_EXPIRED);
    var dropped: u32 = 0;
    for (info.items, 0..) |pi, i| {
        var from = pi.orig_id;
        var to: u32 = undefined;
        if (pi.expired) {
            to = PACK_EXPIRED;
            dropped += 1;
        } else to = @as(u32, @intCast(i)) - dropped;
        if (ctx.compact) from -= o.compact_from.?.num_packs_in_base;
        if (from < ctx.pack_perm.len) ctx.pack_perm[from] = to;
    }

    var names_len: usize = 0;
    for (info.items) |pi| {
        if (pi.expired) continue;
        names_len += pi.name.len + 1;
    }

    if (o.preferred_pack_name) |pn| {
        for (info.items) |pi| {
            if (cmpIdxOrPackName(pn, pi.name) == .eq) {
                if (ctx.perm(pi.orig_id) == PACK_EXPIRED) util.warn("preferred pack '{s}' is expired", .{pn});
                break;
            }
        }
    }
    if (names_len % CHUNK_ALIGNMENT != 0) names_len += CHUNK_ALIGNMENT - names_len % CHUNK_ALIGNMENT;

    if (info.items.len - dropped == 0) {
        util.err("no pack files to index.", .{});
        return -1;
    }
    if (entries.len == 0) {
        if (flags & WRITE_BITMAP != 0) util.warn("refusing to write multi-pack .bitmap without any objects", .{});
        flags &= ~(WRITE_REV_INDEX | WRITE_BITMAP);
    }

    // locks / temp files
    var lk: ?*lockfile.Lock = null;
    var tmp_path: []const u8 = "";
    var tmp_fd: c_int = -1;
    if (ctx.incremental) {
        if (flags & WRITE_NO_CHAIN == 0) lk = lockfile.lockOrDie(chainFilename(source));
        const t = os.tmpFile(chainDirname(source), "tmp_midx_");
        if (t.fd < 0) {
            util.err("unable to create temporary MIDX layer", .{});
            if (lk) |l| l.rollback();
            return -1;
        }
        tmp_path = t.path;
        tmp_fd = t.fd;
        _ = os.chmod(tmp_path, 0o444);
    } else {
        lk = lockfile.lockOrDie(midx_name);
    }

    // chunks
    const ChunkOut = struct { id: u32, data: util.Buf };
    var chunks: std.ArrayList(ChunkOut) = .empty;
    {
        var b: util.Buf = .empty;
        for (info.items) |pi| {
            if (pi.expired) continue;
            b.appendSlice(gpa, pi.name) catch util.oom();
            b.append(gpa, 0) catch util.oom();
        }
        while (b.items.len < names_len) b.append(gpa, 0) catch util.oom();
        chunks.append(gpa, .{ .id = ID_PACKNAMES, .data = b }) catch util.oom();
    }
    {
        var b: util.Buf = .empty;
        var count: u32 = 0;
        var idx: usize = 0;
        var i: usize = 0;
        while (i < 256) : (i += 1) {
            while (idx < entries.len and entries[idx].oid[0] == i) {
                count += 1;
                idx += 1;
            }
            put32(&b, count);
        }
        chunks.append(gpa, .{ .id = ID_OIDFANOUT, .data = b }) catch util.oom();
    }
    {
        var b: util.Buf = .empty;
        for (entries) |e| b.appendSlice(gpa, &e.oid) catch util.oom();
        chunks.append(gpa, .{ .id = ID_OIDLOOKUP, .data = b }) catch util.oom();
    }
    {
        var b: util.Buf = .empty;
        var nl: u32 = 0;
        for (entries) |e| {
            put32(&b, ctx.perm(e.pack_int_id));
            if (large_needed and e.offset >> 31 != 0) {
                put32(&b, LARGE_OFFSET_NEEDED | nl);
                nl += 1;
            } else put32(&b, @truncate(e.offset));
        }
        chunks.append(gpa, .{ .id = ID_OBJECTOFFSETS, .data = b }) catch util.oom();
    }
    if (large_needed) {
        var b: util.Buf = .empty;
        for (entries) |e| {
            if (e.offset >> 31 != 0) put64(&b, e.offset);
        }
        chunks.append(gpa, .{ .id = ID_LARGEOFFSETS, .data = b }) catch util.oom();
    }
    var pack_order: []u32 = &.{};
    if (flags & (WRITE_REV_INDEX | WRITE_BITMAP) != 0) {
        var base_objects: u32 = 0;
        if (ctx.incremental) {
            if (ctx.base) |b| base_objects = b.totalObjects();
        }
        const data = gpa.alloc(OrderData, entries.len) catch util.oom();
        for (entries, 0..) |e, i| {
            var pk = ctx.perm(e.pack_int_id);
            if (!e.preferred or ctx.compact) pk |= 1 << 31;
            data[i] = .{ .nr = @intCast(i), .pack = pk, .offset = e.offset };
        }
        std.mem.sort(OrderData, data, {}, orderLess);
        pack_order = gpa.alloc(u32, entries.len) catch util.oom();
        for (data, 0..) |d, i| {
            const e = entries[d.nr];
            const pidx = ctx.perm(e.pack_int_id);
            if (pidx < info.items.len) {
                const pi = &info.items[pidx];
                if (pi.bitmap_pos == BITMAP_POS_UNKNOWN) pi.bitmap_pos = @as(u32, @intCast(i)) + base_objects;
                pi.bitmap_nr += 1;
            }
            pack_order[i] = d.nr;
        }
        for (info.items) |*pi| {
            if (pi.bitmap_pos == BITMAP_POS_UNKNOWN) pi.bitmap_pos = 0;
        }
        var b: util.Buf = .empty;
        for (pack_order) |v| put32(&b, v + base_objects);
        chunks.append(gpa, .{ .id = ID_REVINDEX, .data = b }) catch util.oom();
        var bb: util.Buf = .empty;
        for (info.items) |pi| {
            if (pi.expired) continue;
            put32(&bb, pi.bitmap_pos);
            put32(&bb, pi.bitmap_nr);
        }
        chunks.append(gpa, .{ .id = ID_BITMAPPEDPACKS, .data = bb }) catch util.oom();
    }

    var out: util.Buf = .empty;
    put32(&out, SIGNATURE);
    out.append(gpa, @intCast(ctx.version)) catch util.oom();
    out.append(gpa, 1) catch util.oom();
    out.append(gpa, @intCast(chunks.items.len)) catch util.oom();
    out.append(gpa, 0) catch util.oom();
    put32(&out, @as(u32, @intCast(info.items.len)) - dropped);
    var off: u64 = HEADER_SIZE + (chunks.items.len + 1) * 12;
    for (chunks.items) |c| {
        put32(&out, c.id);
        put64(&out, off);
        off += c.data.items.len;
    }
    put32(&out, 0);
    put64(&out, off);
    for (chunks.items) |c| out.appendSlice(gpa, c.data.items) catch util.oom();
    var h = hash.Hasher.init(.{});
    h.update(out.items);
    var midx_hash: Oid = undefined;
    h.final(&midx_hash);
    out.appendSlice(gpa, &midx_hash) catch util.oom();
    const hx = hash.hexAlloc(midx_hash);

    if (ctx.incremental) {
        os.writeAll(tmp_fd, out.items) catch util.dieErrno("unable to write {s}", .{tmp_path});
        os.close(tmp_fd);
    } else {
        lk.?.write(out.items);
    }

    if (flags & WRITE_REV_INDEX != 0 and envBool("GIT_TEST_MIDX_WRITE_REV", false)) {
        const dest = if (ctx.incremental) splitFilenameExt(source, hx, "rev") else midxFilenameExt(source, hx, "rev");
        var rb: util.Buf = .empty;
        put32(&rb, ID_REVINDEX);
        put32(&rb, 1);
        put32(&rb, 1);
        for (pack_order) |v| put32(&rb, v);
        rb.appendSlice(gpa, &midx_hash) catch util.oom();
        var rh = hash.Hasher.init(.{});
        rh.update(rb.items);
        var rd: Oid = undefined;
        rh.final(&rd);
        rb.appendSlice(gpa, &rd) catch util.oom();
        if (!os.exists(dest)) {
            const t = os.tmpFile(util.concat(&.{ source, "/pack" }), "tmp_rev_");
            if (t.fd < 0) util.die("cannot store reverse index file", .{});
            os.writeAll(t.fd, rb.items) catch util.die("cannot store reverse index file", .{});
            os.close(t.fd);
            _ = os.chmod(t.path, 0o444);
            if (!os.rename(t.path, dest)) util.die("cannot store reverse index file", .{});
        }
    }

    if (lk == null) {
        util.out(hx);
        util.out("\n");
    }

    var keep: std.ArrayList([]const u8) = .empty;
    if (ctx.incremental) {
        if (ctx.base) |b| {
            if (!b.has_chain) {
                const bhx = b.checksumHex();
                const pairs = [_][2][]const u8{
                    .{ midxFilename(source), splitFilenameExt(source, bhx, "midx") },
                    .{ midxFilenameExt(source, bhx, "bitmap"), splitFilenameExt(source, bhx, "bitmap") },
                    .{ midxFilenameExt(source, bhx, "rev"), splitFilenameExt(source, bhx, "rev") },
                };
                for (pairs) |pr| {
                    if (!os.link(pr[0], pr[1]) and os.errno() != 2) {
                        util.err("unable to link '{s}' to '{s}': {s}", .{ pr[0], pr[1], os.lastErr() });
                        if (lk) |l| l.rollback();
                        _ = os.unlink(tmp_path);
                        return -1;
                    }
                }
            }
        }
        const final_name = splitFilenameExt(source, hx, "midx");
        if (!os.rename(tmp_path, final_name)) {
            util.err("unable to rename new multi-pack-index layer: {s}", .{os.lastErr()});
            if (lk) |l| l.rollback();
            _ = os.unlink(tmp_path);
            return -1;
        }
        var layers: std.ArrayList(*Midx) = .empty;
        var m = ctx.base;
        while (m) |x| : (m = x.base) layers.append(gpa, x) catch util.oom();
        var i = layers.items.len;
        while (i > 0) {
            i -= 1;
            keep.append(gpa, layers.items[i].checksumHex()) catch util.oom();
        }
        keep.append(gpa, hx) catch util.oom();
        if (ctx.compact) {
            layers.clearRetainingCapacity();
            var mm = ctx.m;
            while (mm) |x| : (mm = x.base) {
                if (x == o.compact_to.?) break;
                layers.append(gpa, x) catch util.oom();
            }
            i = layers.items.len;
            while (i > 0) {
                i -= 1;
                keep.append(gpa, layers.items[i].checksumHex()) catch util.oom();
            }
        }
        if (lk) |l| {
            var cb: util.Buf = .empty;
            for (keep.items) |k| {
                cb.appendSlice(gpa, k) catch util.oom();
                cb.append(gpa, '\n') catch util.oom();
            }
            l.write(cb.items);
        }
    } else {
        keep.append(gpa, hx) catch util.oom();
    }

    if (ctx.m != null or ctx.base != null) closeCache();

    if (lk) |l| {
        if (!l.commit()) util.dieErrno("could not write multi-pack-index", .{});
        clearMidxFiles(source, keep.items, ctx.incremental);
    }
    return 0;
}

// ---------------------------------------------------------------- expire / repack

fn unlinkPackPath(pack_path: []const u8) void {
    const base = if (util.endsWith(pack_path, ".pack")) pack_path[0 .. pack_path.len - 5] else pack_path;
    if (os.exists(util.concat(&.{ base, ".keep" }))) return;
    for ([_][]const u8{ ".idx", ".pack", ".rev", ".keep", ".bitmap", ".promisor", ".mtimes" }) |ext| {
        _ = os.unlink(util.concat(&.{ base, ext }));
    }
}

pub fn expire(source: []const u8, flags: u32) i32 {
    const m = get(source) orelse return 0;
    if (m.base != null) util.die("cannot expire packs from an incremental multi-pack-index", .{});
    const count = gpa.alloc(u32, m.num_packs) catch util.oom();
    @memset(count, 0);
    var prog: ?*progress.Progress = null;
    if (flags & PROGRESS != 0) prog = progress.startDelayed("Counting referenced objects", m.num_objects);
    var i: u32 = 0;
    while (i < m.num_objects) : (i += 1) {
        count[nthPackIntId(m, i)] += 1;
        progress.update(prog, i + 1);
    }
    progress.stop(&prog);

    if (flags & PROGRESS != 0) prog = progress.startDelayed("Finding and deleting unreferenced packfiles", m.num_packs);
    var drops: std.ArrayList([]const u8) = .empty;
    i = 0;
    while (i < m.num_packs) : (i += 1) {
        progress.update(prog, i + 1);
        if (count[i] != 0) continue;
        if (!preparePack(m, i)) continue;
        const p = m.packs[i].?;
        if (p.keep or p.cruft) continue;
        // keep the index in memory: the rewrite below still reads it
        _ = p.openIndex();
        drops.append(gpa, m.pack_names[i]) catch util.oom();
        unlinkPackPath(p.pack_path);
    }
    progress.stop(&prog);
    if (drops.items.len == 0) return 0;
    util.sortStrings(drops.items);
    const o = WriteOpts{ .source = source, .packs_to_drop = drops.items, .flags = flags & PROGRESS };
    return writeInternal(&o);
}

fn wantIncludedPack(m: *Midx, pack_kept: bool, id: u32) bool {
    if (!preparePack(m, id)) return false;
    const p = m.packs[id].?;
    if (!pack_kept and p.keep) return false;
    if (p.cruft) return false;
    if (!p.openIndex() or p.numObjects() == 0) return false;
    return true;
}

const RepackInfo = struct { mtime: i64, referenced: u32, id: u32 };

pub fn repack(source: []const u8, batch_size: u64, flags: u32) i32 {
    const m = get(source) orelse return 0;
    if (m.base != null) util.die("cannot repack an incremental multi-pack-index", .{});
    const include = gpa.alloc(bool, m.num_packs) catch util.oom();
    @memset(include, false);
    const pack_kept = repo_mod.cfg.getBool("repack.packkeptobjects") orelse false;
    if (batch_size > 0) {
        const infos = gpa.alloc(RepackInfo, m.num_packs) catch util.oom();
        var i: u32 = 0;
        while (i < m.num_packs) : (i += 1) {
            infos[i] = .{ .mtime = 0, .referenced = 0, .id = i };
            if (!preparePack(m, i)) continue;
            infos[i].mtime = m.packs[i].?.mtime;
        }
        i = 0;
        while (i < m.num_objects) : (i += 1) infos[nthPackIntId(m, i)].referenced += 1;
        std.mem.sort(RepackInfo, infos, {}, struct {
            fn lt(_: void, a: RepackInfo, b: RepackInfo) bool {
                return a.mtime < b.mtime;
            }
        }.lt);
        var total: u64 = 0;
        var k: usize = 0;
        while (total < batch_size and k < m.num_packs) : (k += 1) {
            const id = infos[k].id;
            if (!wantIncludedPack(m, pack_kept, id)) continue;
            const p = m.packs[id].?;
            var expected: u64 = @as(u64, infos[k].referenced) << 14;
            expected /= p.numObjects();
            expected = std.math.mul(u64, expected, p.size) catch std.math.maxInt(u64);
            expected = (std.math.add(u64, expected, 1 << 13) catch std.math.maxInt(u64)) >> 14;
            if (expected >= batch_size) continue;
            total = std.math.add(u64, total, expected) catch std.math.maxInt(u64);
            include[id] = true;
        }
    } else {
        var i: u32 = 0;
        while (i < m.num_packs) : (i += 1) {
            if (wantIncludedPack(m, pack_kept, i)) include[i] = true;
        }
    }
    var n: usize = 0;
    for (include) |b| {
        if (b) n += 1;
    }
    if (n <= 1) return 0;

    const dbo = repo_mod.cfg.getBool("repack.usedeltabaseoffset") orelse true;
    const islands = repo_mod.cfg.getBool("repack.usedeltaislands") orelse false;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.append(gpa, "pack-objects") catch util.oom();
    argv.append(gpa, util.concat(&.{ source, "/pack/pack" })) catch util.oom();
    if (dbo) argv.append(gpa, "--delta-base-offset") catch util.oom();
    if (islands) argv.append(gpa, "--delta-islands") catch util.oom();
    argv.append(gpa, if (flags & PROGRESS != 0) "--progress" else "-q") catch util.oom();
    var input: util.Buf = .empty;
    var i: u32 = 0;
    while (i < m.num_objects) : (i += 1) {
        if (!include[nthPackIntId(m, i)]) continue;
        input.appendSlice(gpa, &hash.hex(nthOid(m, i))) catch util.oom();
        input.append(gpa, '\n') catch util.oom();
    }
    const r = os.run(argv.items, .{ .stdin_data = input.items, .capture_stdout = true });
    if (r.status != 0) {
        util.err("could not finish pack-objects", .{});
        return 1;
    }
    const o = WriteOpts{ .source = source, .flags = flags };
    return writeInternal(&o);
}

// ---------------------------------------------------------------- verify

var verify_error = false;

fn report(comptime f: []const u8, args: anytype) void {
    verify_error = true;
    util.eprint(f ++ "\n", args);
}

const PairPosId = struct { pos: u32, id: u32 };

pub fn verify(source: []const u8, flags: u32) u8 {
    verify_error = false;
    const m = load(source) orelse {
        if (os.statPath(midxFilename(source)) != null) {
            util.err("multi-pack-index file exists, but failed to parse", .{});
            return 1;
        }
        return 0;
    };
    if (!m.checksumValid()) report("incorrect checksum", .{});

    var prog: ?*progress.Progress = null;
    if (flags & PROGRESS != 0) prog = progress.startDelayed("Looking for referenced packfiles", m.totalPacks());
    var i: u32 = 0;
    while (i < m.totalPacks()) : (i += 1) {
        if (!preparePack(m, i)) report("failed to load pack in position {d}", .{i});
        progress.update(prog, i + 1);
    }
    progress.stop(&prog);

    if (m.num_objects == 0) {
        report("the midx contains no oid", .{});
        return @intFromBool(verify_error);
    }

    if (flags & PROGRESS != 0) prog = progress.startSparse("Verifying OID order in multi-pack-index", m.num_objects - 1);
    var curr: ?*Midx = m;
    while (curr) |cx| : (curr = cx.base) {
        i = 0;
        while (i < m.num_objects - 1) : (i += 1) {
            const a = nthOid(m, m.num_objects_in_base + i);
            const b = nthOid(m, m.num_objects_in_base + i + 1);
            if (hash.order(a, b) != .lt)
                report("oid lookup out of order: oid[{d}] = {s} >= {s} = oid[{d}]", .{ i, &hash.hex(a), &hash.hex(b), i + 1 });
            if ((i + 1) & ((1 << 12) - 1) == 0) progress.update(prog, i + 1);
        }
    }
    progress.stop(&prog);

    const total = m.totalObjects();
    const pairs = gpa.alloc(PairPosId, total) catch util.oom();
    i = 0;
    while (i < total) : (i += 1) pairs[i] = .{ .pos = i, .id = nthPackIntId(m, i) };
    if (flags & PROGRESS != 0) prog = progress.startSparse("Sorting objects by packfile", m.num_objects);
    progress.update(prog, 0);
    std.mem.sort(PairPosId, pairs[0..m.num_objects], {}, struct {
        fn lt(_: void, a: PairPosId, b: PairPosId) bool {
            return a.id > b.id;
        }
    }.lt);
    progress.stop(&prog);

    if (flags & PROGRESS != 0) prog = progress.startSparse("Verifying object offsets", m.num_objects);
    i = 0;
    while (i < total) : (i += 1) {
        const oid = nthOid(m, pairs[i].pos);
        // midx_fill_entry()
        const pos = bsearch(m, oid);
        var p: ?*PackGit = null;
        if (pos) |ps| {
            const pid = nthPackIntId(m, ps);
            if (preparePack(m, pid)) {
                const pk = packAt(m, pid);
                if (pk.isValid()) p = pk;
            }
        }
        const pk = p orelse {
            report("failed to load pack entry for oid[{d}] = {s}", .{ pairs[i].pos, &hash.hex(oid) });
            continue;
        };
        if (!pk.openIndex()) {
            report("failed to load pack-index for packfile {s}", .{pk.pack_path});
            break;
        }
        const m_off = nthOffset(m, pos.?);
        const p_off = packOffsetOf(pk, oid);
        if (m_off != p_off)
            report("incorrect object offset for oid[{d}] = {s}: {x} != {x}", .{ pairs[i].pos, &hash.hex(oid), m_off, p_off });
        if ((i + 1) & ((1 << 12) - 1) == 0) progress.update(prog, i + 1);
    }
    progress.stop(&prog);
    return @intFromBool(verify_error);
}
