//! git fetch-pack (builtin/fetch-pack.c), local transports only.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const pkt = @import("../pktline.zig");
const tp = @import("../transport.zig");
const fetchpack = @import("../fetchpack.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Ref = tp.Ref;

const fetch_pack_usage = "git fetch-pack [--all] [--stdin] [--quiet | -q] [--keep | -k] [--thin] " ++
    "[--include-tag] [--upload-pack=<git-upload-pack>] [--depth=<n>] " ++
    "[--no-progress] [--diag-url] [-v] [<host>:]<directory> [<refs>...]";

fn usage() noreturn {
    util.usageDie("usage: {s}", .{fetch_pack_usage});
}

const Match = enum { not_matched, matched, unadvertised_not_allowed };

const Sought = struct {
    ref: *Ref,
    status: Match = .not_matched,
};

fn addSought(list: *std.ArrayList(Sought), name_in: []const u8) void {
    var name = name_in;
    var oid = hash.zero;
    if (name.len >= 40) {
        if (hash.fromHex(name[0..40])) |o| {
            if (name.len > 40 and name[40] == ' ') {
                oid = o;
                name = name[41..];
            } else if (name.len == 40) {
                oid = o;
            }
        }
    }
    const r = tp.allocRef(name);
    r.old_oid = oid;
    list.append(gpa, .{ .ref = r }) catch util.oom();
}

fn lessRef(_: void, a: *Ref, b: *Ref) bool {
    return std.mem.order(u8, a.name, b.name) == .lt;
}

fn lessSought(_: void, a: Sought, b: Sought) bool {
    return std.mem.order(u8, a.ref.name, b.ref.name) == .lt;
}

fn isUnmatched(s: *const Sought) bool {
    if (s.status != .not_matched) return false;
    if (s.ref.name.len != 40) return false;
    const o = hash.fromHex(s.ref.name) orelse return false;
    return hash.eql(o, s.ref.old_oid);
}

// ---------------- --diag-url (connect.c parse_connect_url) ----------------

const Scheme = enum { local, file, ssh, git };

fn schemeName(s: Scheme) []const u8 {
    return switch (s) {
        .local, .file => "file",
        .ssh => "ssh",
        .git => "git",
    };
}

fn isUrlschemechar(first: bool, ch: u8) bool {
    const alnum = std.ascii.isAlphanumeric(ch);
    const special = ch == '+' or ch == '-' or ch == '.';
    return alnum or (!first and special);
}

fn isUrl(url: []const u8) bool {
    if (url.len == 0 or !isUrlschemechar(true, url[0])) return false;
    var i: usize = 1;
    while (i < url.len and url[i] != ':') : (i += 1) {
        if (!isUrlschemechar(false, url[i])) return false;
    }
    return i + 2 < url.len and url[i + 1] == '/' and url[i + 2] == '/';
}

fn urlDecode(url: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    if (std.mem.indexOfScalar(u8, url, ':')) |c| {
        if (c > 0) {
            util.bufAppend(&b, url[0..c]);
            i = c;
        }
    }
    while (i < url.len) {
        const ch = url[i];
        if (ch == '%' and i + 2 < url.len) {
            if (std.fmt.parseInt(u8, url[i + 1 .. i + 3], 16)) |v| {
                if (v > 0) {
                    util.bufByte(&b, v);
                    i += 3;
                    continue;
                }
            } else |_| {}
        }
        util.bufByte(&b, ch);
        i += 1;
    }
    return b.items;
}

/// host_end(): index of the end of a (possibly bracketed) host in s.
fn hostEnd(s: []const u8) usize {
    var start: usize = 0;
    if (std.mem.indexOf(u8, s, "@[")) |p| start = p + 1;
    if (start < s.len and s[start] == '[') {
        if (std.mem.indexOfScalarPos(u8, s, start + 1, ']')) |e| return e;
    }
    return 0;
}

fn parsePort(s: []const u8) bool {
    if (s.len == 0) return false;
    const n = std.fmt.parseInt(i64, s, 10) catch return false;
    return n >= 0 and n < 65536;
}

fn diagUrl(url: []const u8) void {
    const u = if (isUrl(url)) urlDecode(url) else url;
    var scheme: Scheme = .local;
    var host: []const u8 = u;
    var sep: u8 = '/';
    if (std.mem.indexOf(u8, u, "://")) |i| {
        const name = u[0..i];
        if (util.eql(name, "ssh") or util.eql(name, "git+ssh") or util.eql(name, "ssh+git")) {
            scheme = .ssh;
        } else if (util.eql(name, "git")) {
            scheme = .git;
        } else if (util.eql(name, "file")) {
            scheme = .file;
        } else util.die("protocol '{s}' is not supported", .{name});
        host = u[i + 3 ..];
    } else {
        const colon = std.mem.indexOfScalar(u8, u, ':');
        const slash = std.mem.indexOfScalar(u8, u, '/');
        const local = colon == null or (slash != null and slash.? < colon.?);
        if (!local) {
            scheme = .ssh;
            sep = ':';
        }
    }
    const end = hostEnd(host);
    var path_start: ?usize = null;
    if (scheme == .local) {
        path_start = end;
    } else {
        path_start = if (std.mem.indexOfScalarPos(u8, host, end, sep)) |p| p else null;
    }
    const ps = path_start orelse util.die("no path specified; see 'git help pull' for valid url syntax", .{});
    if (ps >= host.len) util.die("no path specified; see 'git help pull' for valid url syntax", .{});
    var path = host[ps..];
    if (sep == ':') path = path[1..];
    if (scheme == .git or scheme == .ssh) {
        if (path.len > 1 and path[1] == '~') path = path[1..];
    }
    var hostpart = host[0..ps];
    if (scheme != .ssh) {
        util.stdout.print("Diag: url={s}\n", .{url});
        util.stdout.print("Diag: protocol={s}\n", .{schemeName(scheme)});
        util.stdout.print("Diag: hostandport={s}\n", .{hostpart});
        util.stdout.print("Diag: path={s}\n", .{path});
        return;
    }
    if (path.len > 0 and path[0] == '-') util.die("strange pathname '{s}' blocked", .{path});
    // get_host_and_port with bracket removal
    var hb: util.Buf = .empty;
    {
        var start: usize = 0;
        if (std.mem.indexOf(u8, hostpart, "@[")) |p| start = p + 1;
        var port: ?[]const u8 = null;
        var rest: []const u8 = hostpart;
        var bracketed = false;
        if (start < hostpart.len and hostpart[start] == '[') {
            if (std.mem.indexOfScalarPos(u8, hostpart, start + 1, ']')) |e| {
                util.bufAppend(&hb, hostpart[0..start]);
                util.bufAppend(&hb, hostpart[start + 1 .. e]);
                rest = hostpart[e + 1 ..];
                bracketed = true;
            }
        }
        if (std.mem.indexOfScalar(u8, rest, ':')) |c| {
            if (parsePort(rest[c + 1 ..])) {
                port = rest[c + 1 ..];
                if (!bracketed) hostpart = rest[0..c];
            } else if (c + 1 == rest.len) {
                if (!bracketed) hostpart = rest[0..c];
            }
        }
        if (bracketed) hostpart = hb.items;
        if (port == null) {
            if (std.mem.indexOfScalar(u8, hostpart, ':')) |c| {
                if (parsePort(hostpart[c + 1 ..])) {
                    port = hostpart[c + 1 ..];
                    hostpart = hostpart[0..c];
                }
            }
        }
        util.stdout.print("Diag: url={s}\n", .{url});
        util.stdout.print("Diag: protocol={s}\n", .{schemeName(scheme)});
        util.stdout.print("Diag: userandhost={s}\n", .{hostpart});
        util.stdout.print("Diag: port={s}\n", .{port orelse "NONE"});
        util.stdout.print("Diag: path={s}\n", .{path});
    }
}

// ---------------- the command ----------------

pub fn cmdFetchPack(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.stdout.print("usage: {s}\n", .{fetch_pack_usage});
        util.flushStdout();
        os.exit(0);
    }
    var uploadpack: ?[]const u8 = null;
    var quiet = false;
    var keep_pack = false;
    var thin = false;
    var include_tag = false;
    var fetch_all = false;
    var stdin_refs = false;
    var diag = false;
    var depth: i32 = 0;
    var deepen_since: ?[]const u8 = null;
    var deepen_not: std.ArrayList([]const u8) = .empty;
    var deepen_relative = false;
    var no_progress = false;
    var cloning = false;
    var update_shallow = false;
    var i: usize = 1;
    while (i < args.len and args[i].len > 0 and args[i][0] == '-') : (i += 1) {
        const arg = args[i];
        if (util.skipPrefix(arg, "--upload-pack=")) |v| {
            uploadpack = v;
        } else if (util.skipPrefix(arg, "--exec=")) |v| {
            uploadpack = v;
        } else if (util.eql(arg, "--quiet") or util.eql(arg, "-q")) {
            quiet = true;
        } else if (util.eql(arg, "--keep") or util.eql(arg, "-k")) {
            keep_pack = true;
        } else if (util.eql(arg, "--thin")) {
            thin = true;
        } else if (util.eql(arg, "--include-tag")) {
            include_tag = true;
        } else if (util.eql(arg, "--all")) {
            fetch_all = true;
        } else if (util.eql(arg, "--stdin")) {
            stdin_refs = true;
        } else if (util.eql(arg, "--diag-url")) {
            diag = true;
        } else if (util.eql(arg, "-v")) {} else if (util.skipPrefix(arg, "--depth=")) |v| {
            depth = parseCLong(v);
        } else if (util.skipPrefix(arg, "--shallow-since=")) |v| {
            deepen_since = v;
        } else if (util.skipPrefix(arg, "--shallow-exclude=")) |v| {
            deepen_not.append(gpa, v) catch util.oom();
        } else if (util.eql(arg, "--deepen-relative")) {
            deepen_relative = true;
        } else if (util.eql(arg, "--no-progress")) {
            no_progress = true;
        } else if (util.eql(arg, "--stateless-rpc") or util.eql(arg, "--lock-pack") or
            util.eql(arg, "--check-self-contained-and-connected") or util.eql(arg, "--from-promisor") or
            util.eql(arg, "--refetch") or util.eql(arg, "--no-filter") or util.startsWith(arg, "--filter="))
        {} else if (util.eql(arg, "--cloning")) {
            cloning = true;
        } else if (util.eql(arg, "--update-shallow")) {
            update_shallow = true;
        } else usage();
    }
    if (i >= args.len) usage();
    const dest = args[i];
    i += 1;
    var sought: std.ArrayList(Sought) = .empty;
    while (i < args.len) : (i += 1) addSought(&sought, args[i]);
    if (stdin_refs) {
        const data = os.readAllFd(0) catch "";
        var it = std.mem.splitScalar(u8, data, '\n');
        var lines: std.ArrayList([]const u8) = .empty;
        while (it.next()) |l| lines.append(gpa, l) catch util.oom();
        if (lines.items.len > 0 and lines.items[lines.items.len - 1].len == 0) _ = lines.pop();
        for (lines.items) |l| addSought(&sought, l);
    }
    if (diag) {
        diagUrl(dest);
        return 0;
    }

    const remote = gpa.create(tp.Remote) catch util.oom();
    remote.* = .{ .name = dest };
    remote.urls.append(gpa, dest) catch util.oom();
    const t = tp.transportGet(remote, dest);
    t.uploadpack = uploadpack;
    t.depth = depth;
    t.deepen_since = deepen_since;
    t.deepen_not = deepen_not.items;
    t.deepen_relative = deepen_relative;
    t.update_shallow = update_shallow;
    t.cloning = cloning;
    tp.connect(t, false);
    const remote_refs = tp.getRemoteRefs(t, &.{});
    if (t.version != 2 and remote_refs.len == 0) {
        pkt.flush(t.fd_out);
        util.die("no matching remote head", .{});
    }
    const deepen = depth > 0 or deepen_since != null or deepen_not.items.len > 0;

    // remove duplicates (by name), then sort
    var uniq: std.ArrayList(Sought) = .empty;
    {
        var seen = std.StringHashMap(void).init(gpa);
        for (sought.items) |s| {
            if (seen.contains(s.ref.name)) continue;
            seen.put(s.ref.name, {}) catch util.oom();
            uniq.append(gpa, s) catch util.oom();
        }
    }
    std.mem.sort(Sought, uniq.items, {}, lessSought);
    const sorted = gpa.dupe(*Ref, remote_refs) catch util.oom();
    std.mem.sort(*Ref, sorted, {}, lessRef);

    // filter_refs
    var newlist: std.ArrayList(*Ref) = .empty;
    var unmatched: std.ArrayList(*Ref) = .empty;
    var si: usize = 0;
    for (sorted) |r| {
        if (util.startsWith(r.name, "refs/") and !refs.checkRefnameFormat(r.name, 0)) continue;
        var keep = false;
        while (si < uniq.items.len) {
            const ord = std.mem.order(u8, r.name, uniq.items[si].ref.name);
            if (ord == .lt) break;
            if (ord == .eq) {
                keep = true;
                uniq.items[si].status = .matched;
            }
            si += 1;
        }
        if (!keep and fetch_all and (!deepen or !util.startsWith(r.name, "refs/tags/"))) keep = true;
        if (keep) {
            newlist.append(gpa, r) catch util.oom();
        } else unmatched.append(gpa, r) catch util.oom();
    }
    const strict = t.version != 2 and !t.serverSupportsV0("allow-tip-sha1-in-want") and !t.serverSupportsV0("allow-reachable-sha1-in-want");
    for (uniq.items) |*s| {
        if (!isUnmatched(s)) continue;
        var ok = !strict;
        if (!ok) {
            for (newlist.items) |r| {
                if (hash.eql(r.old_oid, s.ref.old_oid)) ok = true;
            }
            for (unmatched.items) |r| {
                if (hash.eql(r.old_oid, s.ref.old_oid)) ok = true;
            }
        }
        if (ok) {
            s.status = .matched;
            newlist.append(gpa, tp.copyRef(s.ref)) catch util.oom();
        } else s.status = .unadvertised_not_allowed;
    }

    fetchpack.fetchPack(t, newlist.items, .{
        .quiet = quiet,
        .no_progress = no_progress,
        .thin = thin,
        .include_tag = include_tag,
        .keep_pack = keep_pack,
    });
    var ret: u8 = 0;
    if (t.child != null) {
        if (tp.disconnect(t) != 0) return 1;
    }
    if (newlist.items.len == 0) ret = 1;
    for (uniq.items) |s| {
        switch (s.status) {
            .matched => continue,
            .not_matched => util.err("no such remote ref {s}", .{s.ref.name}),
            .unadvertised_not_allowed => util.err("Server does not allow request for unadvertised object {s}", .{s.ref.name}),
        }
        ret = 1;
    }
    for (newlist.items) |r| util.stdout.print("{s} {s}\n", .{ hash.hex(r.old_oid), r.name });
    return ret;
}

/// strtol(arg, NULL, 0) clamped to i32.
fn parseCLong(s: []const u8) i32 {
    var p = std.mem.trimStart(u8, s, " \t\n\r\x0b\x0c");
    var neg = false;
    if (p.len > 0 and (p[0] == '-' or p[0] == '+')) {
        neg = p[0] == '-';
        p = p[1..];
    }
    var base: u8 = 10;
    if (p.len >= 2 and p[0] == '0' and (p[1] == 'x' or p[1] == 'X')) {
        base = 16;
        p = p[2..];
    } else if (p.len >= 1 and p[0] == '0') base = 8;
    var v: i64 = 0;
    for (p) |ch| {
        const d = std.fmt.charToDigit(ch, base) catch break;
        v = v * base + d;
        if (v > 0x7fffffff) v = 0x7fffffff + 1;
    }
    if (neg) v = -v;
    return @intCast(std.math.clamp(v, std.math.minInt(i32), std.math.maxInt(i32)));
}
