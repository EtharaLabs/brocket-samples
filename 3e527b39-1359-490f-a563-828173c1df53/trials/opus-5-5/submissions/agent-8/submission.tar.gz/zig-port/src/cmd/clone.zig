//! git clone (port of builtin/clone.c; local paths and local transports)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const tp = @import("../transport.zig");
const fetchpack = @import("../fetchpack.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const objects = @import("../objects.zig");
const config = @import("../config.zig");
const branchcreate = @import("../branchcreate.zig");
const advice = @import("../advice.zig");
const proc = @import("../proc.zig");
const init_cmd = @import("init.zig");
const index_mod = @import("../index.zig");
const ut = @import("../unpacktrees.zig");
const hook = @import("../hook.zig");
const dir_mod = @import("../dir.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Ref = tp.Ref;
const RefList = std.ArrayList(*Ref);

const TAG_REFSPEC = "refs/tags/*:refs/tags/*";

const usage = [_][]const u8{"git clone [<options>] [--] <repo> [<dir>]"};

var option_no_checkout = false;
var option_bare = false;
var option_mirror = false;
var option_single_branch: i32 = -1;
var option_local: i32 = -1;
var option_no_hardlinks = false;
var option_shared = false;
var option_tags = true;
var option_shallow_submodules = false;
var config_reject_shallow: i32 = -1;
var remote_name: ?[]const u8 = null;
var option_branch: ?[]const u8 = null;
var option_verbosity: i32 = 0;
var option_required_reference: std.ArrayList([]const u8) = .empty;
var option_optional_reference: std.ArrayList([]const u8) = .empty;
var max_jobs: i32 = -1;
var option_recurse_submodules: std.ArrayList([]const u8) = .empty;
var option_remote_submodules = false;
var option_progress: i32 = -1;
var option_reject_shallow: i32 = -1;
var option_template: ?[]const u8 = null;
var option_dissociate = false;
var option_origin: ?[]const u8 = null;
var option_rev: ?[]const u8 = null;
var option_upload_pack: ?[]const u8 = null;
var option_depth: ?[]const u8 = null;
var option_since: ?[]const u8 = null;
var option_not: std.ArrayList([]const u8) = .empty;
var real_git_dir: ?[]const u8 = null;
var ref_format: ?[]const u8 = null;
var option_config: std.ArrayList([]const u8) = .empty;
var server_options: std.ArrayList([]const u8) = .empty;
var ipv4 = false;
var ipv6 = false;
var filter: ?[]const u8 = null;
var option_filter_submodules: i32 = -1;
var option_sparse_checkout = false;
var bundle_uri: ?[]const u8 = null;

var wants_head = true;
var detach = false;

fn cbVerbose(_: ?[]const u8, unset: bool) void {
    if (unset) {
        option_verbosity = 0;
    } else if (option_verbosity >= 0) {
        option_verbosity += 1;
    } else option_verbosity = 1;
}

fn cbQuiet(_: ?[]const u8, unset: bool) void {
    if (unset) {
        option_verbosity = 0;
    } else if (option_verbosity <= 0) {
        option_verbosity -= 1;
    } else option_verbosity = -1;
}

fn cbRecurse(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        option_recurse_submodules.clearRetainingCapacity();
    } else option_recurse_submodules.append(gpa, arg orelse ".") catch util.oom();
}

fn cbConfig(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        option_config.clearRetainingCapacity();
    } else option_config.append(gpa, arg orelse "") catch util.oom();
}

var bool_progress = false;
var bool_reject_shallow = false;
var bool_local = false;
var bool_single = false;
var bool_filter_sub = false;

fn cbProgress(_: ?[]const u8, unset: bool) void {
    option_progress = if (unset) 0 else 1;
}
fn cbRejectShallow(_: ?[]const u8, unset: bool) void {
    option_reject_shallow = if (unset) 0 else 1;
}
fn cbLocal(_: ?[]const u8, unset: bool) void {
    option_local = if (unset) 0 else 1;
}
fn cbSingle(_: ?[]const u8, unset: bool) void {
    option_single_branch = if (unset) 0 else 1;
}
fn cbFilterSub(_: ?[]const u8, unset: bool) void {
    option_filter_submodules = if (unset) 0 else 1;
}

const options = [_]po.Opt{
    po.callbackNoArg('v', "verbose", cbVerbose, "be more verbose"),
    po.callbackNoArg('q', "quiet", cbQuiet, "be more quiet"),
    po.callbackNoArg(0, "progress", cbProgress, "force progress reporting"),
    po.callbackNoArg(0, "reject-shallow", cbRejectShallow, "don't clone shallow repository"),
    po.boolean('n', "no-checkout", &option_no_checkout, "don't create a checkout"),
    po.boolean(0, "bare", &option_bare, "create a bare repository"),
    .{ .long = "naked", .kind = .boolean, .b = &option_bare, .help = "create a bare repository", .hidden = true },
    po.boolean(0, "mirror", &option_mirror, "create a mirror repository (implies --bare)"),
    po.callbackNoArg('l', "local", cbLocal, "to clone from a local repository"),
    po.boolean(0, "no-hardlinks", &option_no_hardlinks, "don't use local hardlinks, always copy"),
    po.boolean('s', "shared", &option_shared, "setup as shared repository"),
    .{ .long = "recurse-submodules", .kind = .callback, .cb = cbRecurse, .optarg = true, .argh = "pathspec", .help = "initialize submodules in the clone" },
    .{ .long = "recursive", .kind = .callback, .cb = cbRecurse, .optarg = true, .argh = "pathspec", .help = "alias of --recurse-submodules", .hidden = true },
    po.integer('j', "jobs", &max_jobs, "n", "number of submodules cloned in parallel"),
    po.string(0, "template", &option_template, "template-directory", "directory from which templates will be used"),
    po.list(0, "reference", &option_required_reference, "repo", "reference repository"),
    po.list(0, "reference-if-able", &option_optional_reference, "repo", "reference repository"),
    po.boolean(0, "dissociate", &option_dissociate, "use --reference only while cloning"),
    po.string('o', "origin", &option_origin, "name", "use <name> instead of 'origin' to track upstream"),
    po.string('b', "branch", &option_branch, "branch", "checkout <branch> instead of the remote's HEAD"),
    po.string(0, "revision", &option_rev, "rev", "clone single revision <rev> and check out"),
    po.string('u', "upload-pack", &option_upload_pack, "path", "path to git-upload-pack on the remote"),
    po.string(0, "depth", &option_depth, "depth", "create a shallow clone of that depth"),
    po.string(0, "shallow-since", &option_since, "time", "create a shallow clone since a specific time"),
    po.list(0, "shallow-exclude", &option_not, "ref", "deepen history of shallow clone, excluding ref"),
    po.callbackNoArg(0, "single-branch", cbSingle, "clone only one branch, HEAD or --branch"),
    po.boolean(0, "tags", &option_tags, "clone tags, and make later fetches not to follow them"),
    po.boolean(0, "shallow-submodules", &option_shallow_submodules, "any cloned submodules will be shallow"),
    po.string(0, "separate-git-dir", &real_git_dir, "gitdir", "separate git dir from working tree"),
    po.string(0, "ref-format", &ref_format, "format", "specify the reference format to use"),
    .{ .short = 'c', .long = "config", .kind = .callback, .cb = cbConfig, .argh = "key=value", .help = "set config inside the new repository" },
    po.list(0, "server-option", &server_options, "server-specific", "option to transmit"),
    po.boolean('4', "ipv4", &ipv4, "use IPv4 addresses only"),
    po.boolean('6', "ipv6", &ipv6, "use IPv6 addresses only"),
    po.string(0, "filter", &filter, "args", "object filtering"),
    po.callbackNoArg(0, "also-filter-submodules", cbFilterSub, "apply partial clone filters to submodules"),
    po.boolean(0, "remote-submodules", &option_remote_submodules, "any cloned submodules will use their remote-tracking branch"),
    po.boolean(0, "sparse", &option_sparse_checkout, "initialize sparse-checkout file to include only files at root"),
    po.string(0, "bundle-uri", &bundle_uri, "uri", "a URI for downloading bundles before fetching from origin remote"),
};

// ---------------- helpers ----------------

fn absolutePathdup(path: []const u8) []const u8 {
    if (path.len == 0) util.die("The empty string is not a valid path", .{});
    if (path[0] == '/') return util.dupe(path);
    const cwd = os.getcwd();
    var base: []const u8 = cwd;
    if (os.getenv("PWD")) |pwd| {
        if (!util.eql(pwd, cwd)) {
            if (os.statPath(cwd)) |cs| {
                if (os.statPath(pwd)) |ps| {
                    if ((cs.dev != 0 or cs.ino != 0) and cs.dev == ps.dev and cs.ino == ps.ino) base = pwd;
                }
            }
        }
    }
    if (base.len > 0 and base[base.len - 1] != '/') return util.concat(&.{ base, "/", path });
    return util.concat(&.{ base, path });
}

const RepoPath = struct { path: []const u8, is_bundle: bool };

fn getRepoPath1(base: []const u8) ?RepoPath {
    const suffixes = [_][]const u8{ "/.git", "", ".git/.git", ".git" };
    for (suffixes) |s| {
        const p = util.concat(&.{ base, s });
        const st = os.statPath(p) orelse continue;
        if (st.isDir() and repo_mod.isGitDirectory(p)) return .{ .path = p, .is_bundle = false };
        if (st.isReg() and st.size > 8) {
            const data = os.readFile(p) orelse continue;
            if (data.len < 8 or !std.mem.eql(u8, data[0..8], "gitdir: ")) continue;
            if (repo_mod.readGitfile(p)) |dst| return .{ .path = dst, .is_bundle = false };
        }
    }
    const bsuf = [_][]const u8{ ".bundle", "" };
    for (bsuf) |s| {
        const p = util.concat(&.{ base, s });
        if (os.statPath(p)) |st| {
            if (st.isReg()) return .{ .path = p, .is_bundle = true };
        }
    }
    return null;
}

fn getRepoPath(repo: []const u8) ?RepoPath {
    const r = getRepoPath1(repo) orelse return null;
    return .{ .path = absolutePathdup(r.path), .is_bundle = r.is_bundle };
}

fn isDirSep(ch: u8) bool {
    return ch == '/';
}

fn urlBasename(repo: []const u8, is_bundle: bool, is_bare: bool) []const u8 {
    var start: usize = 0;
    var end: usize = repo.len;
    if (std.mem.indexOf(u8, repo, "://")) |i| start = i + 3;
    var p = start;
    while (p < end and !isDirSep(repo[p])) : (p += 1) {
        if (repo[p] == '@') start = p + 1;
    }
    while (start < end and (isDirSep(repo[end - 1]) or std.ascii.isWhitespace(repo[end - 1]))) end -= 1;
    if (end - start > 5 and isDirSep(repo[end - 5]) and std.mem.eql(u8, repo[end - 4 .. end], ".git")) {
        end -= 5;
        while (start < end and isDirSep(repo[end - 1])) end -= 1;
    }
    const seg = repo[start..end];
    if (std.mem.indexOfScalar(u8, seg, '/') == null and std.mem.indexOfScalar(u8, seg, ':') != null) {
        var q = end;
        while (start < q and std.ascii.isDigit(repo[q - 1]) and repo[q - 1] != ':') q -= 1;
        if (start < q and repo[q - 1] == ':') end = q - 1;
    }
    var q = end;
    while (start < q and !isDirSep(repo[q - 1]) and repo[q - 1] != ':') q -= 1;
    start = q;
    var name = repo[start..end];
    const sfx: []const u8 = if (is_bundle) ".bundle" else ".git";
    if (util.endsWith(name, sfx)) name = name[0 .. name.len - sfx.len];
    if (name.len == 0 or (name.len == 1 and name[0] == '/'))
        util.die("No directory name could be guessed.\nPlease specify a directory on the command line", .{});
    const d = if (is_bare) util.concat(&.{ name, ".git" }) else util.dupe(name);
    // collapse control chars / whitespace
    var out: util.Buf = .empty;
    var prev_space = true;
    for (d) |ch| {
        if (std.ascii.isWhitespace(ch) or ch < 0x20) {
            if (!prev_space) {
                util.bufByte(&out, ' ');
                prev_space = true;
            }
        } else {
            util.bufByte(&out, ch);
            prev_space = false;
        }
    }
    var res = out.items;
    if (res.len > 0 and res[res.len - 1] == ' ') res = res[0 .. res.len - 1];
    return res;
}

fn stripDirTrailingSlashes(d: []const u8) []const u8 {
    var end = d.len;
    while (end > 1 and d[end - 1] == '/') end -= 1;
    return d[0..end];
}

// ---------------- junk removal ----------------

const JunkMode = enum { none, leave_repo, leave_all };
var junk_mode: JunkMode = .none;
var junk_work_tree: ?[]const u8 = null;
var junk_work_tree_keep_top = false;
var junk_git_dir: ?[]const u8 = null;
var junk_git_dir_keep_top = false;

fn removeDir(path: []const u8, keep_top: bool) void {
    if (keep_top) {
        if (os.listDir(path)) |ents| {
            for (ents) |e| os.removeTree(util.joinPath(path, e.name));
        }
    } else os.removeTree(path);
}

fn removeJunk(_: []const u8) void {
    switch (junk_mode) {
        .leave_repo => {
            util.warn("{s}", .{"Clone succeeded, but checkout failed.\n" ++
                "You can inspect what was checked out with 'git status'\n" ++
                "and retry with 'git restore --source=HEAD :/'\n"});
            return;
        },
        .leave_all => return,
        .none => {},
    }
    // run from the original directory
    _ = os.chdir(orig_cwd);
    if (junk_git_dir) |g| removeDir(g, junk_git_dir_keep_top);
    if (junk_work_tree) |w| removeDir(w, junk_work_tree_keep_top);
}

var orig_cwd: []const u8 = "";

// ---------------- local copy ----------------

fn mkdirIfMissing(path: []const u8) void {
    if (os.mkdir(path, 0o777)) return;
    if (os.errno() != os.EEXIST) util.dieErrno("failed to create directory '{s}'", .{path});
    const st = os.statPath(path) orelse util.dieErrno("failed to stat '{s}'", .{path});
    if (!st.isDir()) util.die("{s} exists and is not a directory", .{path});
}

extern "c" fn utimes(path: [*:0]const u8, times: *const [2]Timeval) c_int;
const Timeval = extern struct { sec: i64, usec: i64 };

fn copyFileWithTime(dst: []const u8, src: []const u8) bool {
    const st = os.statPath(src) orelse return false;
    const data = os.readFile(src) orelse return false;
    const mode: c_uint = if (st.mode & 0o111 != 0) 0o777 else 0o666;
    os.writeFile(dst, data, mode) catch return false;
    const tv = [2]Timeval{ .{ .sec = st.atime, .usec = @divTrunc(st.atime_ns, 1000) }, .{ .sec = st.mtime, .usec = @divTrunc(st.mtime_ns, 1000) } };
    _ = utimes(os.z(dst), &tv);
    return true;
}

fn addToAlternates(objdir: []const u8, entry: []const u8) void {
    const path = util.concat(&.{ objdir, "/info/alternates" });
    _ = os.mkdirLeading(path);
    if (os.readFile(path)) |data| {
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |l| {
            if (util.eql(l, entry)) return;
        }
    }
    os.appendFile(path, util.concat(&.{ entry, "\n" })) catch {};
}

fn copyAlternates(src_file: []const u8, src_repo: []const u8, dest_objdir: []const u8) void {
    const data = os.readFile(src_file) orelse util.dieErrno("could not open '{s}' for reading", .{src_file});
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line| {
        if (line.len == 0 or line[0] == '#') continue;
        if (line[0] == '/') {
            addToAlternates(dest_objdir, line);
            continue;
        }
        const abs = util.fmt("{s}/objects/{s}", .{ src_repo, line });
        if (util.normalizePath(abs)) |n| {
            addToAlternates(dest_objdir, n);
        } else util.warn("skipping invalid relative alternate: {s}/{s}", .{ src_repo, line });
    }
}

fn copyOrLinkDirectory(src: []const u8, dest: []const u8, rel: []const u8, src_repo: []const u8, dest_objdir: []const u8) void {
    mkdirIfMissing(dest);
    const ents = os.listDir(src) orelse {
        if (os.lstatPath(src)) |st| {
            if (st.isLnk()) util.die("'{s}' is a symlink, refusing to clone with --local", .{src});
        }
        util.dieErrno("failed to start iterator over '{s}'", .{src});
    };
    std.mem.sort(os.DirEntry, ents, {}, struct {
        fn lt(_: void, a: os.DirEntry, b: os.DirEntry) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    for (ents) |e| {
        const s = util.concat(&.{ src, "/", e.name });
        const d = util.concat(&.{ dest, "/", e.name });
        const r = if (rel.len == 0) util.dupe(e.name) else util.concat(&.{ rel, "/", e.name });
        const st = os.lstatPath(s) orelse continue;
        if (st.isLnk()) util.die("symlink '{s}' exists, refusing to clone with --local", .{r});
        if (st.isDir()) {
            copyOrLinkDirectory(s, d, r, src_repo, dest_objdir);
            continue;
        }
        if (util.eql(r, "info/alternates")) {
            copyAlternates(s, src_repo, dest_objdir);
            continue;
        }
        if (!os.unlink(d) and os.errno() != os.ENOENT) util.dieErrno("failed to unlink '{s}'", .{d});
        if (!option_no_hardlinks) {
            if (os.link(s, d)) {
                const st2 = os.lstatPath(d) orelse util.die("hardlink cannot be checked at '{s}'", .{d});
                if (st2.mode != st.mode or st2.ino != st.ino or st2.dev != st.dev or st2.size != st.size or st2.uid != st.uid or st2.gid != st.gid)
                    util.die("hardlink different from source at '{s}'", .{d});
                continue;
            }
            if (option_local > 0) util.dieErrno("failed to create link '{s}'", .{d});
            option_no_hardlinks = true;
        }
        if (!copyFileWithTime(d, s)) util.dieErrno("failed to copy file to '{s}'", .{d});
    }
}

fn commonDirOf(gitdir: []const u8) []const u8 {
    const cd = util.concat(&.{ gitdir, "/commondir" });
    if (os.readFile(cd)) |data| {
        const v = std.mem.trimEnd(u8, data, "\n\r");
        if (v.len > 0 and v[0] == '/') return v;
        return util.concat(&.{ gitdir, "/", v });
    }
    return gitdir;
}

fn cloneLocal(src_repo: []const u8, dest_repo: []const u8) void {
    const dest_obj = util.concat(&.{ commonDirOf(dest_repo), "/objects" });
    if (option_shared) {
        addToAlternates(dest_obj, util.concat(&.{ commonDirOf(src_repo), "/objects" }));
    } else {
        const src_obj = util.concat(&.{ commonDirOf(src_repo), "/objects" });
        copyOrLinkDirectory(src_obj, dest_obj, "", src_repo, dest_obj);
    }
    repo_mod.repo().odb().reloadPacks();
    if (option_verbosity >= 0) util.ewrite("done.\n");
}

// ---------------- refs ----------------

fn findRemoteBranch(list: []const *Ref, branch: []const u8) ?*Ref {
    if (tp.findRefByName(list, util.concat(&.{ "refs/heads/", branch }))) |r| return r;
    return tp.findRefByName(list, util.concat(&.{ "refs/tags/", branch }));
}

fn wantedPeerRefs(remote_refs: []*Ref, rs: *const tp.Refspec) []*Ref {
    var local: RefList = .empty;
    var list: []const *Ref = remote_refs;
    if (wants_head) {
        if (tp.findRefByName(remote_refs, "HEAD")) |h| {
            const head = tp.copyRef(h);
            local.append(gpa, head) catch util.oom();
            if (option_single_branch > 0) list = tp.guessRemoteHead(head, remote_refs, false);
        } else if (option_single_branch > 0) list = &.{};
    } else if (option_single_branch > 0) {
        local.clearRetainingCapacity();
        if (findRemoteBranch(remote_refs, option_branch.?)) |r| {
            const one = gpa.alloc(*Ref, 1) catch util.oom();
            one[0] = tp.copyRef(r);
            one[0].peer_ref = null;
            list = one;
        } else list = &.{};
    }
    for (rs.items.items) |it| tp.getFetchMap(list, it, &local, false);
    return local.items;
}

fn writeRemoteRefs(local_refs: []const *Ref) void {
    var entries: std.ArrayList(refs.PackedRef) = .empty;
    for (local_refs) |r| {
        const p = r.peer_ref orelse continue;
        if (!refs.checkRefnameFormat(p.name, 0)) util.die("refusing to update ref with bad name '{s}'", .{p.name});
        var peeled: ?Oid = null;
        if (repo_mod.repo().odb().readType(r.old_oid)) |t| {
            if (t == .tag) {
                if (objects.peel(r.old_oid)) |pe| peeled = pe.oid;
            }
        }
        entries.append(gpa, .{ .name = p.name, .oid = r.old_oid, .peeled = peeled }) catch util.oom();
    }
    std.mem.sort(refs.PackedRef, entries.items, {}, struct {
        fn lt(_: void, a: refs.PackedRef, b: refs.PackedRef) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    var i: usize = 1;
    while (i < entries.items.len) : (i += 1) {
        if (util.eql(entries.items[i - 1].name, entries.items[i].name))
            util.die("cannot lock ref '{s}': reference already exists", .{entries.items[i].name});
    }
    if (entries.items.len > 0) refs.writePacked(entries.items);
}

fn writeFollowtags(remote_refs: []const *Ref, msg: []const u8) void {
    for (remote_refs) |r| {
        if (!util.startsWith(r.name, "refs/tags/")) continue;
        if (util.endsWith(r.name, "^{}")) continue;
        if (!repo_mod.repo().odb().has(r.old_oid)) continue;
        refs.updateOrDie(msg, r.name, r.old_oid, null, 0);
    }
}

fn updateRemoteRefs(remote_refs: ?[]const *Ref, mapped: []const *Ref, rhpa: ?*Ref, branch_top: []const u8, msg: []const u8, check_connectivity: bool) void {
    if (check_connectivity) {
        for (mapped) |r| {
            if (r.peer_ref == null) continue;
            if (!repo_mod.repo().odb().has(r.old_oid)) util.die("remote did not send all necessary objects", .{});
        }
    }
    if (remote_refs) |rr| {
        writeRemoteRefs(mapped);
        if (option_single_branch > 0 and option_tags) writeFollowtags(rr, msg);
    }
    if (rhpa) |h| {
        if (h.peer_ref) |p| {
            if (!option_bare) {
                const head_ref = util.concat(&.{ branch_top, "HEAD" });
                refs.writeSymref(head_ref, p.name, msg) catch util.die("unable to update {s}", .{head_ref});
            }
        }
    }
}

fn updateHead(our: ?*const Ref, remote: ?*const Ref, unborn: ?[]const u8, msg: []const u8) void {
    if (our) |o| {
        if (!detach) {
            if (util.skipPrefix(o.name, "refs/heads/")) |head| {
                refs.writeSymref("HEAD", o.name, null) catch util.die("unable to update HEAD", .{});
                if (!option_bare) {
                    refs.updateOrDie(msg, "HEAD", o.old_oid, null, 0);
                    _ = branchcreate.installBranchConfig(false, head, remote_name, o.name);
                }
                return;
            }
        }
        const c = objects.peelTo(o.old_oid, .commit) orelse util.die("could not parse object '{s}'", .{o.name});
        refs.updateOrDie(msg, "HEAD", c, null, refs.F_NO_DEREF);
    } else if (remote) |r| {
        refs.updateOrDie(msg, "HEAD", r.old_oid, null, refs.F_NO_DEREF);
    } else if (unborn) |u| {
        if (util.skipPrefix(u, "refs/heads/")) |head| {
            refs.writeSymref("HEAD", u, null) catch util.die("unable to update HEAD", .{});
            if (!option_bare) _ = branchcreate.installBranchConfig(false, head, remote_name, u);
        }
    }
}

fn detachAdvice(hex: []const u8) void {
    util.flushStdout();
    util.eprint("Note: switching to '{s}'.\n" ++
        "\n" ++
        "You are in 'detached HEAD' state. You can look around, make experimental\n" ++
        "changes and commit them, and you can discard any commits you make in this\n" ++
        "state without impacting any branches by switching back to a branch.\n" ++
        "\n" ++
        "If you want to create a new branch to retain commits you create, you may\n" ++
        "do so (now or later) by using -c with the switch command. Example:\n" ++
        "\n" ++
        "  git switch -c <new-branch-name>\n" ++
        "\n" ++
        "Or undo this operation with:\n" ++
        "\n" ++
        "  git switch -\n" ++
        "\n" ++
        "Turn off this advice by setting config variable advice.detachedHead to false\n\n", .{hex});
}

fn checkout(work_tree: ?[]const u8) u8 {
    if (option_no_checkout) return 0;
    var oid: Oid = undefined;
    var head_name: []const u8 = undefined;
    const rr = refs.resolve("HEAD") orelse {
        util.warn("remote HEAD refers to nonexistent ref, unable to checkout", .{});
        return 0;
    };
    oid = rr.oid;
    head_name = rr.name;
    if (util.eql(head_name, "HEAD")) {
        if (advice.enabled("detachedHead")) detachAdvice(&hash.hex(oid));
    } else if (!util.startsWith(head_name, "refs/heads/")) util.die("HEAD not found below refs/heads!", .{});

    if (work_tree) |wt| {
        if (!os.chdir(wt)) util.dieErrno("cannot chdir to '{s}'", .{wt});
    }
    const idx = index_mod.lockAndRead();
    var o = ut.Options{};
    o.update = true;
    o.merge = true;
    o.clone = true;
    o.preserve_ignored = false;
    o.func = &ut.onewayMerge;
    o.verbose_update = option_verbosity >= 0;
    o.src_index = idx;
    o.dst_index = idx;
    const tree = objects.peelTo(oid, .tree) orelse util.die("unable to parse commit {s}", .{&hash.hex(oid)});
    if (ut.unpackTrees(&.{tree}, &o) < 0) util.die("unable to checkout working tree", .{});
    idx.write();
    var err: u8 = 0;
    const zero = hash.hex(hash.zero);
    err |= hook.run("post-checkout", &.{ &zero, &hash.hex(oid), "1" }, .{});
    if (err == 0 and option_recurse_submodules.items.len > 0) err = updateSubmodulesAfterClone();
    return err;
}

/// `git submodule update --require-init --recursive` (end of clone.c checkout())
fn updateSubmodulesAfterClone() u8 {
    var a: std.ArrayList([]const u8) = .empty;
    a.appendSlice(gpa, &.{ proc.gitBinary(), "submodule", "update", "--require-init", "--recursive" }) catch util.oom();
    if (option_shallow_submodules) a.append(gpa, "--depth=1") catch util.oom();
    if (max_jobs != -1) a.append(gpa, util.fmt("--jobs={d}", .{max_jobs})) catch util.oom();
    if (option_progress > 0 and option_verbosity >= 0) a.append(gpa, "--progress") catch util.oom();
    if (option_verbosity < 0) a.append(gpa, "--quiet") catch util.oom();
    if (option_remote_submodules) a.appendSlice(gpa, &.{ "--remote", "--no-fetch" }) catch util.oom();
    if (ref_format) |f| a.append(gpa, util.concat(&.{ "--ref-format=", f })) catch util.oom();
    const filter_subs = if (option_filter_submodules >= 0) option_filter_submodules > 0 else (repo_mod.cfg.getBool("clone.filtersubmodules") orelse false);
    if (filter_subs) {
        if (filter) |f| a.append(gpa, util.concat(&.{ "--filter=", f })) catch util.oom();
    }
    if (option_single_branch >= 0) a.append(gpa, if (option_single_branch > 0) "--single-branch" else "--no-single-branch") catch util.oom();
    const r = os.run(a.items, .{});
    if (r.signaled) return 128;
    return r.status;
}

fn writeOneConfig(cfg_path: []const u8, kv: []const u8) void {
    var key: []const u8 = kv;
    var value: ?[]const u8 = null;
    if (std.mem.indexOfScalar(u8, kv, '=')) |eq| {
        key = kv[0..eq];
        value = kv[eq + 1 ..];
    }
    key = std.mem.trim(u8, key, " \t");
    if (key.len == 0) util.die("bogus config parameter: {s}", .{kv});
    const ck = config.canonicalKey(key) orelse util.die("unable to write parameters to config file", .{});
    if (util.eql(ck, "clone.defaultremotename")) {
        if (value) |v| remote_name = v;
    }
    if (config.setMultivarInFile(cfg_path, key, value orelse "true", .none, null, .{}) < 0)
        util.die("unable to write parameters to config file", .{});
}

fn readCloneConfig() void {
    if (repo_mod.cfg.getEntry("clone.defaultremotename")) |e| {
        if (e.value) |v| {
            remote_name = v;
        } else util.die("missing value for '{s}'", .{"clone.defaultremotename"});
    }
    if (repo_mod.cfg.getBool("clone.rejectshallow")) |b| config_reject_shallow = @intFromBool(b);
}

fn cfgSet(cfg_path: []const u8, key: []const u8, value: []const u8) void {
    _ = config.setInFileGently(cfg_path, key, null, value);
}

fn writeRefspecConfig(cfg_path: []const u8, src_ref_prefix: []const u8, our: ?*const Ref, rhpa: ?*const Ref, branch_top: []const u8) void {
    if (!(option_mirror or !option_bare)) return;
    var value: []const u8 = "";
    if (option_single_branch > 0 and !option_mirror) {
        if (option_branch) |b| {
            if (util.startsWith(our.?.name, "refs/tags/")) {
                value = util.fmt("+{s}:{s}", .{ our.?.name, our.?.name });
            } else value = util.fmt("+{s}:{s}{s}", .{ our.?.name, branch_top, b });
        } else if (rhpa) |h| {
            const head = util.skipPrefix(h.name, "refs/heads/") orelse util.die("BUG: remote HEAD points at non-head?", .{});
            value = util.fmt("+{s}:{s}{s}", .{ h.name, branch_top, head });
        }
    } else {
        value = util.fmt("+{s}*:{s}*", .{ src_ref_prefix, branch_top });
    }
    if (value.len > 0) {
        _ = config.setMultivarInFile(cfg_path, util.fmt("remote.{s}.fetch", .{remote_name.?}), value, .{ .pattern = "^$" }, null, .{});
        if (option_mirror) cfgSet(cfg_path, util.fmt("remote.{s}.mirror", .{remote_name.?}), "true");
    }
}

fn addOneReference(item: []const u8, required: bool, objdir: []const u8) void {
    var ref_git: ?[]const u8 = null;
    var errmsg: []const u8 = "";
    const abs = os.realPath(item) orelse absolutePathdup(item);
    const cand1 = util.concat(&.{ abs, "/.git/objects" });
    const cand2 = util.concat(&.{ abs, "/objects" });
    if (os.isDir(cand1)) {
        ref_git = util.concat(&.{ abs, "/.git" });
    } else if (os.isDir(cand2)) {
        ref_git = abs;
    } else errmsg = util.fmt("reference repository '{s}' is not a local repository.", .{item});
    if (ref_git) |rg| {
        if (os.exists(util.concat(&.{ rg, "/shallow" }))) {
            ref_git = null;
            errmsg = util.fmt("reference repository '{s}' is shallow", .{item});
        }
    }
    if (ref_git) |rg| {
        addToAlternates(objdir, util.concat(&.{ rg, "/objects" }));
    } else if (required) {
        util.die("{s}", .{errmsg});
    } else util.ewrite(util.fmt("info: Could not add alternate for '{s}': {s}\n", .{ item, errmsg }));
}

pub fn cmdClone(args: []const []const u8) u8 {
    orig_cwd = os.getcwd();
    repo_mod.loadConfig();
    readCloneConfig();
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len > 2) usageMsgOpt("Too many arguments.");
    if (rest.len == 0) usageMsgOpt("You must specify a repository to clone.");

    var deepen = false;
    if (option_depth != null or option_since != null or option_not.items.len > 0) deepen = true;
    if (option_single_branch == -1) option_single_branch = if (deepen) 1 else 0;
    if (ref_format) |f| {
        if (!util.eql(f, "files") and !util.eql(f, "reftable")) util.die("unknown ref storage format '{s}'", .{f});
    }
    if (option_mirror) {
        option_bare = true;
        option_tags = false;
    }
    if (option_bare) {
        if (real_git_dir != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--bare", "--separate-git-dir" });
        option_no_checkout = true;
    }
    if (bundle_uri != null and deepen)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--bundle-uri", "--depth/--shallow-since/--shallow-exclude" });

    const repo_name = rest[0];
    var repo: []const u8 = undefined;
    var display_repo: ?[]const u8 = null;
    var is_bundle = false;
    if (getRepoPath(repo_name)) |rp| {
        is_bundle = rp.is_bundle;
        repo = absolutePathdup(repo_name);
    } else if (std.mem.indexOfScalar(u8, repo_name, ':') != null) {
        repo = repo_name;
        display_repo = tp.anonymizeUrl(repo);
    } else util.die("repository '{s}' does not exist", .{repo_name});

    if (option_depth) |d| {
        const n = std.fmt.parseInt(i64, d, 10) catch 0;
        if (n < 1) util.die("depth {s} is not a positive number", .{d});
    }

    var dir: []const u8 = if (rest.len == 2) rest[1] else urlBasename(repo_name, is_bundle, option_bare);
    dir = stripDirTrailingSlashes(dir);

    const dest_exists = os.exists(dir);
    if (dest_exists and !dir_mod.isEmptyDir(dir))
        util.die("destination path '{s}' already exists and is not an empty directory.", .{dir});
    var real_dest_exists = false;
    if (real_git_dir) |rg| {
        real_dest_exists = os.exists(rg);
        if (real_dest_exists and !dir_mod.isEmptyDir(rg))
            util.die("repository path '{s}' already exists and is not an empty directory.", .{rg});
    }

    const reflog_msg = util.fmt("clone: from {s}", .{display_repo orelse repo});

    var work_tree: ?[]const u8 = null;
    if (!option_bare) {
        work_tree = os.getenv("GIT_WORK_TREE");
        if (work_tree) |wt| {
            if (os.exists(wt)) util.die("working tree '{s}' already exists.", .{wt});
        }
    }
    var git_dir: []const u8 = undefined;
    if (option_bare or work_tree != null) {
        git_dir = dir;
    } else {
        work_tree = dir;
        git_dir = util.concat(&.{ dir, "/.git" });
    }

    util.die_hook = removeJunk;

    if (!option_bare) {
        const wt = work_tree.?;
        if (!os.mkdirLeading(wt)) util.dieErrno("could not create leading directories of '{s}'", .{wt});
        if (dest_exists) {
            junk_work_tree_keep_top = true;
        } else if (!os.mkdir(wt, 0o777)) util.dieErrno("could not create work tree dir '{s}'", .{wt});
        junk_work_tree = absolutePathdup(wt);
    }
    if (real_git_dir) |rg| {
        if (real_dest_exists) junk_git_dir_keep_top = true;
        junk_git_dir = absolutePathdup(rg);
    } else {
        if (dest_exists) junk_git_dir_keep_top = true;
        junk_git_dir = absolutePathdup(git_dir);
    }
    if (!os.mkdirLeading(git_dir)) util.die("could not create leading directories of '{s}'", .{git_dir});

    if (option_verbosity >= 0) {
        if (option_bare) {
            util.ewrite(util.fmt("Cloning into bare repository '{s}'...\n", .{dir}));
        } else util.ewrite(util.fmt("Cloning into '{s}'...\n", .{dir}));
    }

    if (option_recurse_submodules.items.len > 0) {
        util.sortStrings(option_recurse_submodules.items);
        var prev: ?[]const u8 = null;
        for (option_recurse_submodules.items) |it| {
            if (prev != null and util.eql(prev.?, it)) continue;
            prev = it;
            option_config.append(gpa, util.fmt("submodule.active={s}", .{it})) catch util.oom();
        }
        if (repo_mod.cfg.getBool("submodule.stickyrecursiveclone") orelse false)
            option_config.append(gpa, "submodule.recurse=true") catch util.oom();
    }

    const abs_wt: ?[]const u8 = if (work_tree) |wt| (os.realPath(wt) orelse absolutePathdup(wt)) else null;
    const abs_git_dir = init_cmd.initDb(.{
        .git_dir = git_dir,
        .real_git_dir = real_git_dir,
        .work_tree = abs_wt,
        .template = option_template,
        .quiet = true,
        .bare = option_bare,
        .ref_format = ref_format,
        .skip_refdb = false,
    });
    const r = repo_mod.repo();
    r.git_dir = abs_git_dir;
    r.common_dir = abs_git_dir;
    r.work_tree = abs_wt;
    r.bare = option_bare;
    os.setEnv("GIT_DIR", abs_git_dir);
    if (abs_wt) |wt| os.setEnv("GIT_WORK_TREE", wt);
    const cfg_path = util.concat(&.{ abs_git_dir, "/config" });

    for (option_config.items) |kv| writeOneConfig(cfg_path, kv);
    repo_mod.loadConfig();
    readCloneConfig();

    if (config_reject_shallow != -1) {}
    var reject_shallow = false;
    if (config_reject_shallow != -1) reject_shallow = config_reject_shallow != 0;
    if (option_reject_shallow != -1) reject_shallow = option_reject_shallow != 0;

    if (option_filter_submodules > 0 and filter == null)
        util.die("the option '{s}' requires '{s}'", .{ "--also-filter-submodules", "--filter" });
    if (option_filter_submodules > 0 and option_recurse_submodules.items.len == 0)
        util.die("the option '{s}' requires '{s}'", .{ "--also-filter-submodules", "--recurse-submodules" });

    if (option_origin) |o| remote_name = o;
    if (remote_name == null) remote_name = "origin";
    if (!tp.validRemoteName(remote_name.?)) util.die("'{s}' is not a valid remote name", .{remote_name.?});

    var src_ref_prefix: []const u8 = "refs/heads/";
    var branch_top: []const u8 = "";
    if (option_bare) {
        if (option_mirror) src_ref_prefix = "refs/";
        branch_top = src_ref_prefix;
        cfgSet(cfg_path, "core.bare", "true");
    } else if (option_rev == null) {
        branch_top = util.fmt("refs/remotes/{s}/", .{remote_name.?});
    }
    cfgSet(cfg_path, util.fmt("remote.{s}.url", .{remote_name.?}), repo);
    if (!option_tags) cfgSet(cfg_path, util.fmt("remote.{s}.tagOpt", .{remote_name.?}), "--no-tags");

    const objdir = util.concat(&.{ abs_git_dir, "/objects" });
    for (option_required_reference.items) |it| addOneReference(it, true, objdir);
    for (option_optional_reference.items) |it| addOneReference(it, false, objdir);

    repo_mod.loadConfig();
    tp.invalidate();
    const remote = tp.remoteGet(remote_name.?) orelse util.die("unable to get remote '{s}'", .{remote_name.?});
    if (option_rev == null) remote.fetch.append(util.fmt("+{s}*:{s}*", .{ src_ref_prefix, branch_top }));

    const rpath = getRepoPath(remote.urls.items[0]);
    var path: ?[]const u8 = null;
    if (rpath) |p| {
        path = p.path;
        is_bundle = p.is_bundle;
    }
    var is_local = option_local != 0 and path != null and !is_bundle;
    if (is_local) {
        if (option_depth != null) util.warn("--depth is ignored in local clones; use file:// instead.", .{});
        if (option_since != null) util.warn("--shallow-since is ignored in local clones; use file:// instead.", .{});
        if (option_not.items.len > 0) util.warn("--shallow-exclude is ignored in local clones; use file:// instead.", .{});
        if (filter != null) util.warn("--filter is ignored in local clones; use file:// instead.", .{});
        if (os.exists(util.concat(&.{ path.?, "/shallow" }))) {
            if (reject_shallow) util.die("source repository is shallow, reject to clone.", .{});
            if (option_local > 0) util.warn("source repository is shallow, ignoring --local", .{});
            is_local = false;
        }
    }
    if (option_local > 0 and !is_local) util.warn("--local is ignored", .{});
    if (is_bundle) util.die("cloning from a bundle is not supported", .{});

    const t = tp.transportGet(remote, path orelse remote.urls.items[0]);
    t.verbose = if (option_verbosity <= 1) option_verbosity else 1;
    t.quiet = option_verbosity < 0;
    t.progress = if (option_progress >= 0) option_progress != 0 else (option_verbosity >= 0 and os.isatty(2));
    t.cloning = true;
    t.keep = true;
    if (option_depth) |d| t.depth = @intCast(@min(std.fmt.parseInt(i64, d, 10) catch 0, 0x7fffffff));
    t.deepen_since = option_since;
    t.deepen_not = option_not.items;
    t.reject_shallow = reject_shallow;

    if (option_rev != null and option_branch != null)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--revision", "--branch" });
    if (option_rev != null and option_mirror)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--revision", "--mirror" });

    var follow_tags = false;
    if (option_single_branch > 0) {
        follow_tags = true;
        if (option_branch != null) wants_head = false;
    }
    if (option_upload_pack) |u| t.uploadpack = u;
    if (server_options.items.len > 0) t.server_options = server_options.items;

    if (option_rev) |rv| {
        option_tags = false;
        option_single_branch = 0;
        wants_head = false;
        detach = true;
        remote.fetch.append(rv);
    }
    if (option_tags or option_branch != null) remote.fetch.append(TAG_REFSPEC);

    var prefixes: std.ArrayList([]const u8) = .empty;
    remote.fetch.refPrefixes(&prefixes);
    if (option_branch) |b| {
        // expand_ref_prefix
        const rules = [_][]const u8{ "{s}", "refs/{s}", "refs/tags/{s}", "refs/heads/{s}", "refs/remotes/{s}", "refs/remotes/{s}/HEAD" };
        inline for (rules) |rule| prefixes.append(gpa, util.fmt(rule, .{b})) catch util.oom();
    }
    if (wants_head or prefixes.items.len == 0) prefixes.append(gpa, "HEAD") catch util.oom();

    const remote_refs = tp.getRemoteRefs(t, prefixes.items);

    var mapped_refs: []*Ref = &.{};
    if (remote_refs.len > 0) mapped_refs = wantedPeerRefs(remote_refs, &remote.fetch);

    var complete_refs_before_fetch = true;
    if (mapped_refs.len > 0) {
        for (remote_refs) |rr| {
            if (hash.isZero(rr.old_oid)) {
                complete_refs_before_fetch = false;
                break;
            }
        }
        if (!is_local and !complete_refs_before_fetch) fetchRefs(t, mapped_refs, follow_tags);
    }

    const remote_head = tp.findRefByName(remote_refs, "HEAD");
    const guessed = tp.guessRemoteHead(remote_head, mapped_refs, false);
    const remote_head_points_at: ?*Ref = if (guessed.len > 0) guessed[0] else null;
    var our_head_points_at: ?*Ref = null;
    var unborn_head: ?[]const u8 = null;

    if (option_branch) |b| {
        our_head_points_at = findRemoteBranch(mapped_refs, b) orelse
            util.die("Remote branch {s} not found in upstream {s}", .{ b, remote_name.? });
    } else if (option_rev) |rv| {
        if (mapped_refs.len == 0) util.die("Remote revision {s} not found in upstream {s}", .{ rv, remote_name.? });
        our_head_points_at = mapped_refs[0];
    } else if (remote_head_points_at) |h| {
        our_head_points_at = h;
    } else if (remote_head != null) {
        our_head_points_at = null;
    } else {
        if (mapped_refs.len == 0) {
            util.warn("You appear to have cloned an empty repository.", .{});
            option_no_checkout = true;
        }
        var branch: []const u8 = undefined;
        if (t.unborn_head_target) |u| {
            if (refs.checkRefnameFormat(u, 0) and util.startsWith(u, "refs/heads/")) {
                unborn_head = u;
                branch = u["refs/heads/".len..];
            } else {
                branch = init_cmd.defaultBranchName(false);
                unborn_head = util.concat(&.{ "refs/heads/", branch });
            }
        } else {
            branch = init_cmd.defaultBranchName(false);
            unborn_head = util.concat(&.{ "refs/heads/", branch });
        }
        our_head_points_at = findRemoteBranch(mapped_refs, branch);
    }

    if (option_rev == null) writeRefspecConfig(cfg_path, src_ref_prefix, our_head_points_at, remote_head_points_at, branch_top);
    repo_mod.loadConfig();
    tp.invalidate();

    if (is_local) {
        cloneLocal(path.?, abs_git_dir);
    } else if (mapped_refs.len > 0 and complete_refs_before_fetch) {
        fetchRefs(t, mapped_refs, follow_tags);
    }

    updateRemoteRefs(remote_refs, mapped_refs, remote_head_points_at, branch_top, reflog_msg, !is_local);
    updateHead(our_head_points_at, remote_head, unborn_head, reflog_msg);

    _ = tp.disconnect(t);

    if (option_dissociate) {
        const alternates = util.concat(&.{ abs_git_dir, "/objects/info/alternates" });
        if (os.exists(alternates)) {
            const ch = proc.spawnGit(&.{ "repack", "-a", "-d" }, .{});
            if (proc.wait(ch.pid) != 0) util.die("cannot repack to clean up", .{});
            if (!os.unlink(alternates) and os.errno() != os.ENOENT) util.dieErrno("cannot unlink temporary alternates file", .{});
        }
    }

    if (option_sparse_checkout) {
        const ch = proc.spawnGit(&.{ "-C", dir, "sparse-checkout", "set" }, .{});
        if (proc.wait(ch.pid) != 0) return 1;
    }

    junk_mode = .leave_repo;
    const err = checkout(abs_wt);
    junk_mode = .leave_all;
    util.die_hook = null;
    return err;
}

fn fetchRefs(t: *tp.Transport, mapped: []const *Ref, follow_tags: bool) void {
    fetchpack.fetchPack(t, mapped, .{
        .quiet = t.quiet,
        .no_progress = !t.progress,
        .include_tag = follow_tags,
        .keep_pack = true,
    });
    repo_mod.repo().odb().reloadPacks();
}

fn usageMsgOpt(msg: []const u8) noreturn {
    util.ewrite(util.fmt("fatal: {s}\n\n", .{msg}));
    po.usageExit(&usage, &options, true);
}
