//! Plumbing: hash-object, cat-file, write-tree, commit-tree, mktree.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const odb_mod = @import("../odb.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const index_mod = @import("../index.zig");
const commit_mod = @import("../commit.zig");
const convert = @import("../convert.zig");
const fsck = @import("../fsck.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

// ---------------- hash-object ----------------

fn readStdin() []u8 {
    return os.readAllFd(0) catch util.die("could not read from stdin", .{});
}

/// Light fsck check of object contents (like index_mem with HASH_FORMAT_CHECK).
pub fn checkObjectFormat(typ: ObjType, data: []const u8) ?[]const u8 {
    switch (typ) {
        .commit => {
            if (!util.startsWith(data, "tree ")) return "corrupt commit";
            if (data.len < 46 or hash.fromHex(data[5..45]) == null or data[45] != '\n') return "corrupt commit";
            var p: usize = 46;
            while (util.startsWith(data[p..], "parent ")) {
                if (data.len < p + 48 or hash.fromHex(data[p + 7 .. p + 47]) == null or data[p + 47] != '\n') return "corrupt commit";
                p += 48;
            }
            if (!util.startsWith(data[p..], "author ")) return "corrupt commit";
            const nl = std.mem.indexOfScalarPos(u8, data, p, '\n') orelse return "corrupt commit";
            p = nl + 1;
            if (!util.startsWith(data[p..], "committer ")) return "corrupt commit";
            return null;
        },
        .tree => {
            var it = objects.TreeIter{ .data = data };
            var prev: ?objects.TreeEntry = null;
            var consumed: usize = 0;
            while (it.next()) |e| {
                if (e.name.len == 0 or std.mem.indexOfScalar(u8, e.name, '/') != null) return "corrupt tree file";
                if (prev) |pv| {
                    if (objects.baseNameCompare(pv.name, pv.mode, e.name, e.mode) != .lt) return "corrupt tree file";
                }
                prev = e;
                consumed = it.pos;
            }
            if (consumed != data.len) return "corrupt tree file";
            return null;
        },
        .tag => {
            if (!util.startsWith(data, "object ")) return "corrupt tag";
            if (data.len < 48 or hash.fromHex(data[7..47]) == null) return "corrupt tag";
            if (!util.startsWith(data[48..], "type ")) return "corrupt tag";
            return null;
        },
        else => return null,
    }
}

fn hashFormatCheckReport(o: *fsck.Options, oid: ?Oid, typ: ObjType, mt: fsck.MsgType, id: fsck.MsgId, msg: []const u8) i32 {
    _ = o;
    _ = oid;
    _ = typ;
    _ = mt;
    _ = id;
    util.err("object fails fsck: {s}", .{msg});
    return 1;
}

/// index_mem() with INDEX_FORMAT_CHECK: run a strict fsck on the buffer.
fn formatCheck(typ: ObjType, data: []const u8) void {
    var o: fsck.Options = .{ .strict = true, .error_func = hashFormatCheckReport };
    if (fsck.fsckBuffer(hash.zero, typ, data, &o) != 0)
        util.die("refusing to create malformed object", .{});
    _ = fsck.fsckFinish(&o);
}

/// xopen() of a directory succeeds in C, but reading it then fails in index_fd().
fn hashOpenFail(path: []const u8, write: bool) noreturn {
    if (os.errno() == os.EISDIR) {
        if (write) util.die("Unable to add {s} to database", .{path});
        util.die("Unable to hash {s}", .{path});
    }
    util.dieErrno("could not open '{s}' for reading", .{path});
}

fn hashOne(data_in: []const u8, typ: ObjType, write: bool, path: ?[]const u8, literally: bool) Oid {
    var data = data_in;
    if (path) |p| {
        if (typ == .blob) data = convert.toGitChecked(p, data, write);
    }
    if (!literally) formatCheck(typ, data);
    if (write) return repo_mod.repo().odb().write(typ, data);
    return odb_mod.hashObject(typ, data);
}

pub fn cmdHashObject(args: []const []const u8) u8 {
    var typ_s: ?[]const u8 = null;
    var write = false;
    var stdin_count: i32 = 0;
    var stdin_paths = false;
    var no_filters = false;
    var literally = false;
    var path: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.string('t', "", &typ_s, "type", "object type"),
        po.boolean('w', "", &write, "write the object into the object database"),
        po.counter(0, "stdin", &stdin_count, "read the object from stdin"),
        po.boolean(0, "stdin-paths", &stdin_paths, "read file names from stdin"),
        po.boolean(0, "no-filters", &no_filters, "store file as is without filters"),
        po.boolean(0, "literally", &literally, "just hash any random garbage to create corrupt objects for debugging Git"),
        po.string(0, "path", &path, "file", "process file as it were from this path"),
    };
    const usage = [_][]const u8{
        "git hash-object [-t <type>] [-w] [--path=<file> | --no-filters]\n                [--stdin [--literally]] [--] <file>...",
        "git hash-object [-t <type>] [-w] --stdin-paths [--no-filters]",
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (write) {
        repo_mod.setup(false);
    } else {
        repo_mod.setup(true);
    }
    const prefix = if (repo_mod.repo_) |r| r.prefix else "";
    if (path) |p| {
        if (prefix.len > 0 and !(p.len > 0 and p[0] == '/')) path = util.concat(&.{ prefix, p });
    }
    const stdin = stdin_count > 0;
    var errstr: ?[]const u8 = null;
    if (stdin_paths) {
        if (stdin) {
            errstr = "Can't use --stdin-paths with --stdin";
        } else if (rest.len > 0) {
            errstr = "Can't specify files with --stdin-paths";
        } else if (path != null) errstr = "Can't use --stdin-paths with --path";
    } else {
        if (stdin_count > 1) errstr = "Multiple --stdin arguments are not supported";
        if (path != null and no_filters) errstr = "Can't use --path with --no-filters";
    }
    if (errstr) |e| {
        util.err("{s}", .{e});
        po.usageWithOptions(&usage, &opts);
    }
    var typ: ObjType = .blob;
    if (typ_s) |t| {
        typ = ObjType.fromName(t) orelse util.die("invalid object type \"{s}\"", .{t});
    }
    const use_filters = !no_filters and repo_mod.repo_ != null;
    if (stdin) {
        const data = readStdin();
        const p: ?[]const u8 = if (use_filters) path else null;
        const oid = hashOne(data, typ, write, p, literally);
        util.outf("{s}\n", .{hash.hex(oid)});
    }
    for (rest) |f| {
        const full = if (f.len > 0 and f[0] == '/') f else util.concat(&.{ prefix, f });
        const data = os.readFile(full) orelse hashOpenFail(full, write);
        const p: ?[]const u8 = if (use_filters) (path orelse full) else null;
        const oid = hashOne(data, typ, write, p, literally);
        util.outf("{s}\n", .{hash.hex(oid)});
    }
    if (stdin_paths) {
        const input = readStdin();
        var it = std.mem.splitScalar(u8, input, '\n');
        while (it.next()) |line0| {
            if (line0.len == 0 and it.index == null) break;
            var line = line0;
            if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
            if (line.len > 0 and line[0] == '"') {
                if (util.cunquote(line)) |u| line = u.value else util.die("line is badly quoted", .{});
            }
            const data = os.readFile(line) orelse hashOpenFail(line, write);
            const p: ?[]const u8 = if (use_filters) line else null;
            const oid = hashOne(data, typ, write, p, literally);
            util.outf("{s}\n", .{hash.hex(oid)});
        }
    }
    return 0;
}

// ---------------- cat-file ----------------

fn printTreePretty(data: []const u8) void {
    var it = objects.TreeIter{ .data = data };
    while (it.next()) |e| {
        const t = if (e.mode == 0o40000) "tree" else if (e.mode == 0o160000) "commit" else "blob";
        util.outf("{o:0>6} {s} {s}\t", .{ e.mode, t, hash.hex(e.oid) });
        util.out(util.cquote(e.name));
        util.out("\n");
    }
}

const mailmap_mod = @import("../mailmap.zig");
const commitnode = @import("../commitnode.zig");
const diff_mod = @import("../diff.zig");

const BatchMode = enum { contents, info, command };

const FilterChoice = enum { disabled, blob_none, blob_limit, object_type, tree, sparse_oid, combine };

const BatchOpts = struct {
    enabled: bool = false,
    mode: BatchMode = .contents,
    format: ?[]const u8 = null,
    all_objects: bool = false,
    unordered: bool = false,
    buffer: bool = false,
    follow_symlinks: bool = false,
    in_delim: u8 = '\n',
    out_delim: u8 = '\n',
    transform: u8 = 0,
    filter: FilterChoice = .disabled,
    blob_limit: u64 = 0,
    filter_type: ObjType = .none,
};

var cf_batch: BatchOpts = .{};
var cf_opt: u8 = 0;
var cf_opt_name: []const u8 = "";
var cf_use_mailmap = false;
var cf_mailmap: ?*mailmap_mod.Map = null;
var cf_filter_spec: ?[]const u8 = null;

const mailmap_headers = [_][]const u8{ "author ", "committer ", "tagger " };

fn cfLoadMailmap() void {
    if (cf_mailmap == null) cf_mailmap = mailmap_mod.readMailmap();
}

fn cfApplyMailmap(data: []const u8) []const u8 {
    cfLoadMailmap();
    return mailmap_mod.applyToHeader(data, &mailmap_headers, cf_mailmap.?);
}

fn cfOptName(o: *const po.Opt) []const u8 {
    if (o.long.len > 0) return util.concat(&.{ "--", o.long });
    return util.fmt("-{c}", .{o.short});
}

fn cfCmdmodeCb(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    const v: u8 = @intCast(o.val);
    if (cf_opt != 0 and cf_opt != v) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ cfOptName(o), cf_opt_name });
        os.exit(129);
    }
    cf_opt = v;
    cf_opt_name = cfOptName(o);
}

fn cfBatchCb(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = unset;
    if (cf_batch.enabled) {
        util.err("only one batch option may be specified", .{});
        os.exit(129);
    }
    cf_batch.enabled = true;
    cf_batch.mode = if (util.eql(o.long, "batch")) .contents else if (util.eql(o.long, "batch-check")) .info else .command;
    cf_batch.format = arg;
}

fn cfFilterCb(arg: ?[]const u8, unset: bool) void {
    if (unset or arg == null) {
        cf_batch.filter = .disabled;
        cf_filter_spec = null;
        return;
    }
    const a = arg.?;
    if (cf_batch.filter != .disabled) {
        cf_batch.filter = .combine;
        return;
    }
    if (util.eql(a, "auto")) util.die("'auto' filter not supported by this command", .{});
    if (util.eql(a, "blob:none")) {
        cf_batch.filter = .blob_none;
    } else if (util.skipPrefix(a, "blob:limit=")) |v| {
        const n = @import("../config.zig").parseInt(v) orelse util.die("invalid filter-spec '{s}'", .{a});
        if (n < 0) util.die("invalid filter-spec '{s}'", .{a});
        cf_batch.filter = .blob_limit;
        cf_batch.blob_limit = @intCast(n);
    } else if (util.skipPrefix(a, "tree:")) |v| {
        const n = @import("../config.zig").parseInt(v) orelse util.die("expected 'tree:<depth>'", .{});
        if (n < 0) util.die("expected 'tree:<depth>'", .{});
        cf_batch.filter = .tree;
    } else if (util.skipPrefix(a, "sparse:oid=")) |_| {
        cf_batch.filter = .sparse_oid;
    } else if (util.skipPrefix(a, "sparse:path=")) |_| {
        util.die("sparse:path filters support has been dropped", .{});
    } else if (util.skipPrefix(a, "object:type=")) |v| {
        const t = ObjType.fromName(v) orelse util.die("'{s}' for 'object:type=<type>' is not a valid object type", .{v});
        cf_batch.filter = .object_type;
        cf_batch.filter_type = t;
    } else if (util.skipPrefix(a, "combine:")) |_| {
        cf_batch.filter = .combine;
    } else util.die("invalid filter-spec '{s}'", .{a});
    cf_filter_spec = a;
}

fn cmdmodeOpt(short: u8, long: []const u8, v: u8, help: []const u8) po.Opt {
    return .{ .short = short, .long = long, .kind = .callback, .cbx = cfCmdmodeCb, .noarg = true, .noneg = true, .val = v, .help = help };
}

fn batchOpt(long: []const u8, help: []const u8) po.Opt {
    return .{ .long = long, .kind = .callback, .cbx = cfBatchCb, .optarg = true, .noneg = true, .argh = "format", .help = help };
}

fn usageMsgOpt(usage: []const []const u8, opts: []const po.Opt, comptime f: []const u8, args: anytype) noreturn {
    util.flushStdout();
    util.eprint("fatal: " ++ f ++ "\n\n", args);
    po.usageWithOptions(usage, opts);
}

/// tree-walk.c get_tree_entry_follow_symlinks()
const FollowResult = enum { found, missing, dangling, loop, notdir };

const DirState = struct { data: []const u8, oid: Oid };

fn findTreeEntry(data: []const u8, name: []const u8, oid: *Oid, mode: *u32) bool {
    var it = objects.TreeIter{ .data = data };
    while (it.next()) |e| {
        if (util.eql(e.name, name)) {
            oid.* = e.oid;
            mode.* = e.mode;
            return true;
        }
    }
    return false;
}

fn followSymlinks(tree_oid: Oid, name: []const u8, result: *Oid, result_path: *util.Buf, mode: *u32) FollowResult {
    var retval: FollowResult = .missing;
    var parents: std.ArrayList(DirState) = .empty;
    var namebuf: util.Buf = .empty;
    util.bufAppend(&namebuf, name);
    var cur: Oid = tree_oid;
    var t: ?[]const u8 = null;
    var follows_remaining: i32 = 40;
    const odb = repo_mod.repo().odb();
    while (true) {
        if (t == null) {
            const root = objects.peelTo(cur, .tree) orelse return retval;
            const obj = odb.read(root) orelse return retval;
            parents.append(gpa, .{ .data = obj.data, .oid = root }) catch util.oom();
            if (namebuf.items.len == 0) {
                result.* = root;
                return .found;
            }
            if (obj.data.len == 0) return retval;
            t = obj.data;
        }
        while (namebuf.items.len > 0 and namebuf.items[0] == '/') _ = namebuf.orderedRemove(0);
        const nb = namebuf.items;
        const slash = std.mem.indexOfScalar(u8, nb, '/');
        const first = if (slash) |s| nb[0..s] else nb;
        if (util.eql(first, "..")) {
            if (parents.items.len == 1) {
                util.bufAppend(result_path, nb);
                mode.* = 0;
                return .found;
            }
            _ = parents.pop();
            t = parents.items[parents.items.len - 1].data;
            const rm: usize = if (slash != null) 3 else 2;
            const rest = util.dupe(nb[rm..]);
            namebuf = .empty;
            util.bufAppend(&namebuf, rest);
            continue;
        }
        if (first.len == 0) {
            result.* = parents.items[parents.items.len - 1].oid;
            return .found;
        }
        if (!findTreeEntry(t.?, first, &cur, mode)) return retval;
        const m = mode.* & 0o170000;
        if (m == 0o040000) {
            if (slash == null) {
                result.* = cur;
                return .found;
            }
            t = null;
            const rest = util.dupe(nb[slash.? + 1 ..]);
            namebuf = .empty;
            util.bufAppend(&namebuf, rest);
        } else if (m == 0o120000) {
            if (follows_remaining == 0) return .loop;
            follows_remaining -= 1;
            retval = .dangling;
            const obj = odb.read(cur) orelse return retval;
            var contents = obj.data;
            if (std.mem.indexOfScalar(u8, contents, 0)) |z| contents = contents[0..z];
            if (contents.len > 0 and contents[0] == '/') {
                util.bufAppend(result_path, contents);
                mode.* = 0;
                return .found;
            }
            t = parents.items[parents.items.len - 1].data;
            var nn: util.Buf = .empty;
            util.bufAppend(&nn, obj.data);
            if (slash) |s| util.bufAppend(&nn, nb[s..]);
            namebuf = nn;
        } else {
            if (slash == null) {
                result.* = cur;
                return .found;
            }
            if (m == 0o100000) return .notdir;
            result.* = cur;
            return .found;
        }
    }
}

const Lookup = struct {
    status: enum { found, missing, ambiguous, dangling, loop, notdir, symlink } = .found,
    oid: Oid = hash.zero,
    /// null == S_IFINVALID
    mode: ?u32 = null,
    symlink_path: []const u8 = "",
};

fn splitTreePath(name: []const u8) ?usize {
    if (name.len == 0 or name[0] == ':') return null;
    var depth: usize = 0;
    for (name, 0..) |ch, i| {
        if (ch == '{') depth += 1 else if (ch == '}' and depth > 0) depth -= 1 else if (ch == ':' and depth == 0) return i;
    }
    return null;
}

fn lookupName(name: []const u8, follow: bool) Lookup {
    if (follow) {
        if (splitTreePath(name)) |i| {
            const tr = revparse.resolve(name[0..i], .{ .want = .treeish, .quiet = true }) orelse
                return .{ .status = if (revparse.last_ambiguous) .ambiguous else .missing };
            var res: Oid = hash.zero;
            var path_buf: util.Buf = .empty;
            var mode: u32 = 0xffffffff;
            const r = followSymlinks(tr.oid, name[i + 1 ..], &res, &path_buf, &mode);
            switch (r) {
                .found => {},
                .missing => return .{ .status = .missing },
                .dangling => return .{ .status = .dangling },
                .loop => return .{ .status = .loop },
                .notdir => return .{ .status = .notdir },
            }
            if (mode == 0) return .{ .status = .symlink, .symlink_path = path_buf.items };
            return .{ .oid = res, .mode = if (mode == 0xffffffff) null else mode };
        }
    }
    const r = revparse.resolve(name, .{ .quiet = true }) orelse
        return .{ .status = if (revparse.last_ambiguous) .ambiguous else .missing };
    var mode: ?u32 = null;
    if (r.path) |p| {
        if (p.len > 0 or name[0] == ':') mode = r.mode;
    }
    return .{ .oid = r.oid, .mode = mode };
}

fn batchWrite(data: []const u8) void {
    util.out(data);
}

fn reportStatus(bo: *const BatchOpts, obj_name: ?[]const u8, oid: Oid, status: []const u8) void {
    util.outf("{s} {s}", .{ obj_name orelse &hash.hex(oid), status });
    util.out(&.{bo.out_delim});
    util.flushStdout();
}

const ExpandData = struct {
    oid: Oid = hash.zero,
    typ: ObjType = .none,
    size: usize = 0,
    mode: ?u32 = null,
    rest: ?[]const u8 = null,
};

fn expandBatchFormat(b: *util.Buf, f: []const u8, d: *const ExpandData) void {
    var i: usize = 0;
    while (i < f.len) {
        if (f[i] != '%') {
            util.bufByte(b, f[i]);
            i += 1;
            continue;
        }
        if (i + 1 < f.len and f[i + 1] == '%') {
            util.bufByte(b, '%');
            i += 2;
            continue;
        }
        if (i + 1 >= f.len or f[i + 1] != '(') {
            util.bufByte(b, '%');
            i += 1;
            continue;
        }
        const close = std.mem.indexOfScalarPos(u8, f, i + 2, ')') orelse badFormat(f[i + 1 ..]);
        const atom = f[i + 2 .. close];
        if (util.eql(atom, "objectname")) {
            util.bufAppend(b, &hash.hex(d.oid));
        } else if (util.eql(atom, "objecttype")) {
            if (d.typ != .none) util.bufAppend(b, d.typ.name());
        } else if (util.eql(atom, "objectsize")) {
            util.bufPrint(b, "{d}", .{d.size});
        } else if (util.eql(atom, "objectsize:disk")) {
            util.bufPrint(b, "{d}", .{commitnode.objectDiskSize(d.oid) orelse 0});
        } else if (util.eql(atom, "deltabase")) {
            util.bufAppend(b, &hash.hex(commitnode.objectDeltaBase(d.oid)));
        } else if (util.eql(atom, "rest")) {
            if (d.rest) |r| util.bufAppend(b, r);
        } else if (util.eql(atom, "objectmode")) {
            if (d.mode) |m| util.bufPrint(b, "{o:0>6}", .{m});
        } else badFormat(f[i + 1 ..]);
        i = close + 1;
    }
}

fn badFormat(start: []const u8) noreturn {
    // strbuf_expand_bad_format()
    if (start.len == 0 or start[0] != '(') util.die("bad {s} format: element '{s}' does not start with '('", .{ "cat-file", start });
    const close = std.mem.indexOfScalar(u8, start, ')') orelse util.die("bad {s} format: element '{s}' does not end in ')'", .{ "cat-file", start });
    util.die("bad {s} format: %{s}", .{ "cat-file", start[0 .. close + 1] });
}

fn validateFormat(f: []const u8) void {
    var d = ExpandData{};
    var b: util.Buf = .empty;
    d.rest = null;
    expandBatchFormat(&b, f, &d);
}

fn formatNeedsInfo(f: ?[]const u8) bool {
    const s = f orelse return true;
    return std.mem.indexOf(u8, s, "%(objecttype)") != null or std.mem.indexOf(u8, s, "%(objectsize") != null or
        std.mem.indexOf(u8, s, "%(deltabase)") != null;
}

fn printObjectOrDie(bo: *const BatchOpts, d: *const ExpandData) void {
    const odb = repo_mod.repo().odb();
    const obj = odb.read(d.oid) orelse util.die("object {s} disappeared", .{hash.hex(d.oid)});
    if (obj.typ == .blob) {
        if (bo.transform != 0) {
            const p = d.rest orelse util.die("missing path for '{s}'", .{hash.hex(d.oid)});
            if (bo.transform == 'w') {
                batchWrite(convert.toWorktree(p, obj.data));
            } else {
                batchWrite(textconvObject(p, 0o100644, d.oid) orelse obj.data);
            }
        } else batchWrite(obj.data);
    } else {
        var data = obj.data;
        if (cf_use_mailmap) data = cfApplyMailmap(data);
        if (obj.typ != d.typ) util.die("object {s} changed type!?", .{hash.hex(d.oid)});
        batchWrite(data);
    }
}

/// textconv_object(): null if no textconv driver applies.
fn textconvObject(path: []const u8, mode: u32, oid: Oid) ?[]const u8 {
    const df = diff_mod.allocFilespec(path, oid, true, mode);
    const tc = diff_mod.getTextconv(df) orelse return null;
    return diff_mod.fillTextconv(tc, df);
}

fn batchObjectWrite(obj_name: ?[]const u8, bo: *const BatchOpts, d: *ExpandData, skip_info: bool) void {
    if (!skip_info) {
        const odb = repo_mod.repo().odb();
        const obj = odb.read(d.oid) orelse {
            if (d.mode != null and d.mode.? == 0o160000)
                reportStatus(bo, null, d.oid, "submodule")
            else
                reportStatus(bo, obj_name, d.oid, "missing");
            return;
        };
        d.typ = obj.typ;
        d.size = obj.data.len;
        const excluded = switch (bo.filter) {
            .blob_none => d.typ == .blob,
            .blob_limit => d.typ == .blob and d.size >= bo.blob_limit,
            .object_type => d.typ != bo.filter_type,
            else => false,
        };
        if (excluded) {
            if (!bo.all_objects) reportStatus(bo, obj_name, d.oid, "excluded");
            return;
        }
        if (cf_use_mailmap and (d.typ == .commit or d.typ == .tag)) {
            d.size = cfApplyMailmap(obj.data).len;
        }
    }
    var b: util.Buf = .empty;
    if (bo.format) |f| {
        expandBatchFormat(&b, f, d);
    } else {
        util.bufPrint(&b, "{s} {s} {d}", .{ hash.hex(d.oid), d.typ.name(), d.size });
    }
    util.bufByte(&b, bo.out_delim);
    batchWrite(b.items);
    if (bo.mode == .contents) {
        printObjectOrDie(bo, d);
        batchWrite(&.{bo.out_delim});
    }
}

fn batchOneObject(obj_name: []const u8, bo: *const BatchOpts, d: *ExpandData) void {
    const l = lookupName(obj_name, bo.follow_symlinks);
    const delim = bo.out_delim;
    switch (l.status) {
        .found => {},
        .missing => return reportStatus(bo, obj_name, l.oid, "missing"),
        .ambiguous => return reportStatus(bo, obj_name, l.oid, "ambiguous"),
        .dangling, .loop, .notdir => {
            const w: []const u8 = switch (l.status) {
                .dangling => "dangling",
                .loop => "loop",
                else => "notdir",
            };
            util.outf("{s} {d}", .{ w, obj_name.len });
            util.out(&.{delim});
            util.out(obj_name);
            util.out(&.{delim});
            util.flushStdout();
            return;
        },
        .symlink => {
            util.outf("symlink {d}", .{l.symlink_path.len});
            util.out(&.{delim});
            util.out(l.symlink_path);
            util.out(&.{delim});
            util.flushStdout();
            return;
        },
    }
    d.oid = l.oid;
    d.mode = l.mode;
    batchObjectWrite(obj_name, bo, d, false);
}

/// Incremental reader for stdin (so interactive --batch use works).
const LineReader = struct {
    buf: util.Buf = .empty,
    pos: usize = 0,
    eof: bool = false,

    fn next(self: *LineReader, delim: u8) ?[]const u8 {
        while (true) {
            if (std.mem.indexOfScalarPos(u8, self.buf.items, self.pos, delim)) |e| {
                var line = self.buf.items[self.pos..e];
                self.pos = e + 1;
                if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
                return util.dupe(line);
            }
            if (self.eof) {
                if (self.pos >= self.buf.items.len) return null;
                var line = self.buf.items[self.pos..];
                self.pos = self.buf.items.len;
                if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
                return util.dupe(line);
            }
            if (self.pos > 0) {
                const rest = util.dupe(self.buf.items[self.pos..]);
                self.buf = .empty;
                util.bufAppend(&self.buf, rest);
                self.pos = 0;
            }
            var tmp: [65536]u8 = undefined;
            const n = std.c.read(0, &tmp, tmp.len);
            if (n < 0) {
                if (os.errno() == 4) continue;
                util.die("could not read from stdin", .{});
            }
            if (n == 0) {
                self.eof = true;
                continue;
            }
            util.bufAppend(&self.buf, tmp[0..@intCast(n)]);
        }
    }
};

const QueuedCmd = struct { fn_: u8, line: []const u8 };

fn runQueued(bo: *BatchOpts, q: QueuedCmd, d: *ExpandData) void {
    switch (q.fn_) {
        'c' => {
            bo.mode = .contents;
            batchOneObject(q.line, bo, d);
            bo.mode = .command;
        },
        'i' => {
            bo.mode = .info;
            batchOneObject(q.line, bo, d);
            bo.mode = .command;
        },
        'm' => {
            const v = @import("../config.zig").parseBool(q.line) orelse util.die("mailmap: invalid boolean '{s}'", .{q.line});
            cf_use_mailmap = v;
            if (v) cfLoadMailmap();
        },
        'r' => util.die("failed to get object info from the remote: {s}", .{q.line}),
        else => unreachable,
    }
}

fn batchObjectsCommand(bo: *BatchOpts, d: *ExpandData) void {
    var rd = LineReader{};
    var queued: std.ArrayList(QueuedCmd) = .empty;
    const cmds = [_]struct { name: []const u8, f: u8, args: bool }{
        .{ .name = "contents", .f = 'c', .args = true },
        .{ .name = "flush", .f = 'f', .args = false },
        .{ .name = "info", .f = 'i', .args = true },
        .{ .name = "mailmap", .f = 'm', .args = true },
        .{ .name = "remote-object-info", .f = 'r', .args = true },
    };
    while (rd.next(bo.in_delim)) |line| {
        if (line.len == 0) util.die("empty command in input", .{});
        if (std.ascii.isWhitespace(line[0])) util.die("whitespace before command: '{s}'", .{line});
        var found: ?u8 = null;
        var arg: []const u8 = "";
        for (cmds) |cm| {
            const rest = util.skipPrefix(line, cm.name) orelse continue;
            if (cm.args) {
                if (rest.len == 0 or rest[0] != ' ') util.die("{s} requires arguments", .{cm.name});
                arg = rest[1..];
            } else if (rest.len > 0) util.die("{s} takes no arguments", .{cm.name});
            found = cm.f;
            break;
        }
        const f = found orelse util.die("unknown command: '{s}'", .{line});
        if (f == 'f') {
            if (!bo.buffer) util.die("flush is only for --buffer mode", .{});
            for (queued.items) |q| runQueued(bo, q, d);
            queued.clearRetainingCapacity();
            util.flushStdout();
        } else if (!bo.buffer) {
            runQueued(bo, .{ .fn_ = f, .line = arg }, d);
            util.flushStdout();
        } else {
            queued.append(gpa, .{ .fn_ = f, .line = arg }) catch util.oom();
        }
    }
    if (bo.buffer and queued.items.len > 0 and !(@import("../config.zig").parseBool(os.getenv("GIT_TEST_CAT_FILE_NO_FLUSH_ON_EXIT") orelse "0") orelse false)) {
        for (queued.items) |q| runQueued(bo, q, d);
    }
}

const default_format = "%(objectname) %(objecttype) %(objectsize)";

fn batchObjects(bo: *BatchOpts) u8 {
    var d = ExpandData{};
    const fmt_s = bo.format orelse default_format;
    validateFormat(fmt_s);
    const split_ws = std.mem.indexOf(u8, fmt_s, "%(rest)") != null or bo.transform != 0;
    if (bo.format) |f| {
        if (util.eql(f, default_format)) bo.format = null;
    }
    if (bo.all_objects) {
        const skip_info = !formatNeedsInfo(bo.format) and bo.mode != .contents and bo.filter == .disabled;
        const all = repo_mod.repo().odb().allObjects(true);
        std.mem.sort(Oid, all, {}, hash.lessThan);
        var prev: ?Oid = null;
        for (all) |o| {
            if (prev != null and hash.eql(prev.?, o)) continue;
            prev = o;
            d = .{ .oid = o };
            batchObjectWrite(null, bo, &d, skip_info);
            if (!bo.buffer) util.flushStdout();
        }
        return 0;
    }
    if (bo.mode == .command) {
        batchObjectsCommand(bo, &d);
        return 0;
    }
    var rd = LineReader{};
    while (rd.next(bo.in_delim)) |line| {
        var name = line;
        d.rest = null;
        if (split_ws) {
            if (std.mem.indexOfAny(u8, line, " \t")) |sp| {
                name = line[0..sp];
                var r = sp;
                while (r < line.len and (line[r] == ' ' or line[r] == '\t')) r += 1;
                d.rest = line[r..];
            }
        }
        batchOneObject(name, bo, &d);
        if (!bo.buffer) util.flushStdout();
    }
    return 0;
}

pub fn cmdCatFile(args: []const []const u8) u8 {
    var allow_unknown = false;
    var input_nul = false;
    var nul_term = false;
    var buffer_set = false;
    var path: ?[]const u8 = null;
    cf_batch = .{};
    cf_opt = 0;
    const opts = [_]po.Opt{
        po.group("Check object existence or emit object contents"),
        cmdmodeOpt('e', "", 'e', "check if <object> exists"),
        cmdmodeOpt('p', "", 'p', "pretty-print <object> content"),
        po.group("Emit [broken] object attributes"),
        cmdmodeOpt('t', "", 't', "show object type (one of 'blob', 'tree', 'commit', 'tag', ...)"),
        cmdmodeOpt('s', "", 's', "show object size"),
        .{ .long = "allow-unknown-type", .kind = .boolean, .b = &allow_unknown, .help = "historical option -- no-op", .hidden = true },
        po.boolean(0, "use-mailmap", &cf_use_mailmap, "use mail map file"),
        .{ .long = "mailmap", .kind = .boolean, .b = &cf_use_mailmap, .help = "alias of --use-mailmap" },
        po.group("Batch objects requested on stdin (or --batch-all-objects)"),
        batchOpt("batch", "show full <object> or <rev> contents"),
        batchOpt("batch-check", "like --batch, but don't emit <contents>"),
        .{ .short = 'z', .kind = .boolean, .b = &input_nul, .help = "stdin is NUL-terminated", .hidden = true },
        po.boolean('Z', "", &nul_term, "stdin and stdout is NUL-terminated"),
        batchOpt("batch-command", "read commands from stdin"),
        cmdmodeOpt(0, "batch-all-objects", 'b', "with --batch[-check]: ignores stdin, batches all known objects"),
        po.group("Change or optimize batch output"),
        po.boolean(0, "buffer", &buffer_set, "buffer --batch output"),
        po.boolean(0, "follow-symlinks", &cf_batch.follow_symlinks, "follow in-tree symlinks"),
        po.boolean(0, "unordered", &cf_batch.unordered, "do not order objects before emitting them"),
        po.group("Emit object (blob or tree) with conversion or filter (stand-alone, or with batch)"),
        cmdmodeOpt(0, "textconv", 'c', "run textconv on object's content"),
        cmdmodeOpt(0, "filters", 'w', "run filters on object's content"),
        po.string(0, "path", &path, "blob|tree", "use a <path> for (--textconv | --filters); Not with 'batch'"),
        po.callback(0, "filter", cfFilterCb, "args", "object filtering"),
    };
    const usage = [_][]const u8{
        "git cat-file <type> <object>",
        "git cat-file (-e | -p | -t | -s) <object>",
        "git cat-file (--textconv | --filters)\n             [<rev>:<path|tree-ish> | --path=<path|tree-ish> <rev>]",
        "git cat-file (--batch | --batch-check | --batch-command) [--batch-all-objects]\n             [--buffer] [--follow-symlinks] [--unordered]\n             [--textconv | --filters] [-Z]",
    };
    // detect whether --buffer / --no-buffer was given at all
    var buffer_given = false;
    for (args[1..]) |a| {
        if (util.eql(a, "--")) break;
        if (util.eql(a, "--buffer") or util.eql(a, "--no-buffer")) buffer_given = true;
    }
    const rest = po.parse(args[1..], &opts, &usage, .{});
    repo_mod.setup(false);
    const opt = cf_opt;
    const opt_cw = opt == 'c' or opt == 'w';
    const opt_epts = opt == 'e' or opt == 'p' or opt == 't' or opt == 's';
    if (cf_use_mailmap) cfLoadMailmap();
    var bo = &cf_batch;
    switch (bo.filter) {
        .disabled => {},
        .blob_none, .blob_limit, .object_type => {
            if (!bo.enabled) util.usageDie("usage: objects filter only supported in batch mode", .{});
        },
        .tree => util.usageDie("usage: objects filter not supported: '{s}'", .{"tree"}),
        .sparse_oid => util.usageDie("usage: objects filter not supported: '{s}'", .{"sparse:oid"}),
        .combine => util.usageDie("usage: objects filter not supported: '{s}'", .{"combine"}),
    }
    if (opt == 'b') bo.all_objects = true;
    if (path != null and !opt_cw)
        usageMsgOpt(&usage, &opts, "'{s}=<{s}>' needs '{s}' or '{s}'", .{ "--path", "path|tree-ish", "--filters", "--textconv" });
    if (!bo.enabled) {
        if (bo.follow_symlinks) usageMsgOpt(&usage, &opts, "'{s}' requires a batch mode", .{"--follow-symlinks"});
        if (buffer_given) usageMsgOpt(&usage, &opts, "'{s}' requires a batch mode", .{"--buffer"});
        if (bo.all_objects) usageMsgOpt(&usage, &opts, "'{s}' requires a batch mode", .{"--batch-all-objects"});
        if (input_nul) usageMsgOpt(&usage, &opts, "'{s}' requires a batch mode", .{"-z"});
        if (nul_term) usageMsgOpt(&usage, &opts, "'{s}' requires a batch mode", .{"-Z"});
    }
    if (input_nul) bo.in_delim = 0;
    if (nul_term) {
        bo.in_delim = 0;
        bo.out_delim = 0;
    }
    bo.buffer = if (buffer_given) buffer_set else bo.all_objects;
    if (bo.enabled) {
        if (opt_cw) {
            bo.transform = opt;
        } else if (opt != 0 and opt != 'b') {
            usageMsgOpt(&usage, &opts, "'-{c}' is incompatible with batch mode", .{opt});
        } else if (rest.len > 0) {
            usageMsgOpt(&usage, &opts, "batch modes take no arguments", .{});
        }
        return batchObjects(bo);
    }
    var exp_type: ?[]const u8 = null;
    var obj_name: []const u8 = undefined;
    if (opt != 0) {
        if (rest.len == 0 and opt == 'c') {
            usageMsgOpt(&usage, &opts, "<rev> required with '{s}'", .{"--textconv"});
        } else if (rest.len == 0 and opt == 'w') {
            usageMsgOpt(&usage, &opts, "<rev> required with '{s}'", .{"--filters"});
        } else if (rest.len == 0 and opt_epts) {
            usageMsgOpt(&usage, &opts, "<object> required with '-{c}'", .{opt});
        } else if (rest.len == 1) {
            obj_name = rest[0];
        } else usageMsgOpt(&usage, &opts, "too many arguments", .{});
    } else if (rest.len == 0) {
        po.usageWithOptions(&usage, &opts);
    } else if (rest.len != 2) {
        usageMsgOpt(&usage, &opts, "only two arguments allowed in <type> <object> mode, not {d}", .{rest.len});
    } else {
        exp_type = rest[0];
        obj_name = rest[1];
    }
    return catOneFile(opt, exp_type, obj_name, path);
}

fn catOneFile(opt: u8, exp_type: ?[]const u8, obj_name: []const u8, force_path: ?[]const u8) u8 {
    const opt_cw = opt == 'c' or opt == 'w';
    const res = revparse.resolve(obj_name, .{ .die_on_error = true }) orelse util.die("Not a valid object name {s}", .{obj_name});
    if (force_path == null and opt_cw and res.path == null)
        util.die("<object>:<path> required, only <object> '{s}' given", .{obj_name});
    const oid = res.oid;
    const path = force_path orelse res.path;
    var mode: u32 = 0o100644;
    if (res.path) |p| {
        if (p.len > 0 or obj_name[0] == ':') mode = res.mode;
    }
    const odb = repo_mod.repo().odb();
    switch (opt) {
        't' => {
            const obj = odb.read(oid) orelse util.die("git cat-file: could not get object info", .{});
            util.outf("{s}\n", .{obj.typ.name()});
            return 0;
        },
        's' => {
            const obj = odb.read(oid) orelse util.die("git cat-file: could not get object info", .{});
            var size = obj.data.len;
            if (cf_use_mailmap and (obj.typ == .commit or obj.typ == .tag)) size = cfApplyMailmap(obj.data).len;
            util.outf("{d}\n", .{size});
            return 0;
        },
        'e' => return if (odb.has(oid)) 0 else 1,
        'w' => {
            const obj = odb.read(oid) orelse {
                util.err("cannot read object {s} '{s}'", .{ hash.hex(oid), path orelse "" });
                return 255;
            };
            if (obj.typ == .blob and mode & 0o170000 == 0o100000) {
                util.out(convert.toWorktree(path.?, obj.data));
            } else util.out(obj.data);
            return 0;
        },
        'c', 'p' => {
            if (opt == 'c') {
                if (textconvObject(path.?, mode, oid)) |out| {
                    util.out(out);
                    return 0;
                }
            }
            const obj = odb.read(oid) orelse util.die("Not a valid object name {s}", .{obj_name});
            if (obj.typ == .tree) {
                printTreePretty(obj.data);
                return 0;
            }
            if (obj.typ == .blob) {
                util.out(obj.data);
                return 0;
            }
            var data = obj.data;
            if (cf_use_mailmap) data = cfApplyMailmap(data);
            util.out(data);
            return 0;
        },
        0 => {
            const tn = exp_type.?;
            const want = ObjType.fromName(tn);
            if (want != null and want.? == .blob) {
                var blob_oid = oid;
                if (odb.read(oid)) |o| {
                    if (o.typ == .tag) {
                        const target = util.skipPrefix(o.data, "object ") orelse util.die("{s} not a valid tag", .{hash.hex(oid)});
                        blob_oid = (if (target.len >= 40) hash.fromHex(target[0..40]) else null) orelse util.die("{s} not a valid tag", .{hash.hex(oid)});
                    }
                }
                if (odb.read(blob_oid)) |b| {
                    if (b.typ == .blob) {
                        util.out(b.data);
                        return 0;
                    }
                }
            }
            const w = want orelse util.die("invalid object type \"{s}\"", .{tn});
            const p = (if (objects.typeOf(oid) == w) oid else objects.peelTo(oid, w)) orelse util.die("git cat-file {s}: bad file", .{obj_name});
            const o2 = odb.read(p) orelse util.die("git cat-file {s}: bad file", .{obj_name});
            var data = o2.data;
            if (cf_use_mailmap) data = cfApplyMailmap(data);
            util.out(data);
            return 0;
        },
        else => util.die("git cat-file: unknown option: {s}", .{exp_type orelse ""}),
    }
}



// ---------------- write-tree ----------------

pub fn cmdWriteTree(args: []const []const u8) u8 {
    var missing_ok = false;
    var prefix: ?[]const u8 = null;
    var ignore_cache_tree = false;
    const opts = [_]po.Opt{
        po.boolean(0, "missing-ok", &missing_ok, "allow missing objects"),
        po.string(0, "prefix", &prefix, "<prefix>/", "write tree object for a subdirectory <prefix>"),
        po.boolean(0, "ignore-cache-tree", &ignore_cache_tree, "only useful for debugging"),
    };
    const usage = [_][]const u8{"git write-tree [--missing-ok] [--prefix=<prefix>/]"};
    _ = po.parse(args[1..], &opts, &usage, .{});
    const idx = index_mod.get();
    {
        // verify_cache(): the index must be fully merged, and must not
        // contain both "path" and "path/file".
        var funny: usize = 0;
        for (idx.entries.items) |e| {
            if (e.stage() == 0) continue;
            funny += 1;
            if (funny > 10) {
                util.eprint("...\n", .{});
                break;
            }
            util.eprint("{s}: unmerged ({s})\n", .{ e.path, hash.hex(e.oid) });
        }
        if (funny == 0) {
            const items = idx.entries.items;
            var i: usize = 0;
            while (i + 1 < items.len) : (i += 1) {
                const a = items[i].path;
                const b = items[i + 1].path;
                if (a.len < b.len and b[a.len] == '/' and util.startsWith(b, a)) {
                    funny += 1;
                    if (funny > 10) {
                        util.eprint("...\n", .{});
                        break;
                    }
                    util.eprint("You have both {s} and {s}\n", .{ a, b });
                }
            }
        }
        if (funny > 0) util.die("git-write-tree: error building trees", .{});
    }
    const had_tree = idx.cache_tree != null and idx.cache_tree.?.entry_count >= 0;
    if (ignore_cache_tree) idx.cache_tree = null;
    const root = idx.writeTree(missing_ok) orelse util.die("git-write-tree: error building trees", .{});
    // update the index's cache tree on disk (git does this when it can lock)
    if (!had_tree) {
        switch (@import("../lockfile.zig").tryLock(idx.path)) {
            .ok => |l| {
                idx.lock = l;
                idx.write();
            },
            .err => {},
        }
    }
    var out_oid = root;
    if (prefix) |p0| {
        var p = p0;
        while (p.len > 0 and p[p.len - 1] == '/') p = p[0 .. p.len - 1];
        const ent = objects.treeLookup(root, p) orelse util.die("git-write-tree: prefix {s} not found", .{p0});
        if (!ent.isDir()) util.die("git-write-tree: prefix {s} not found", .{p0});
        out_oid = ent.oid;
    }
    util.outf("{s}\n", .{hash.hex(out_oid)});
    return 0;
}

// ---------------- commit-tree ----------------

var ct_parents: std.ArrayList(Oid) = .empty;
var ct_msg: util.Buf = .empty;
var ct_have_msg = false;

fn ctParent(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg.?;
    const o = revparse.getCommit(a) orelse util.die("not a valid object name {s}", .{a});
    for (ct_parents.items) |p| {
        if (hash.eql(p, o)) {
            util.err("duplicate parent {s} ignored", .{hash.hex(o)});
            return;
        }
    }
    ct_parents.append(gpa, o) catch util.oom();
}

fn ctMessage(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    if (ct_msg.items.len > 0) util.bufByte(&ct_msg, '\n');
    util.bufAppend(&ct_msg, arg.?);
    // strbuf_complete_line
    if (ct_msg.items.len > 0 and ct_msg.items[ct_msg.items.len - 1] != '\n') util.bufByte(&ct_msg, '\n');
    ct_have_msg = true;
}

fn ctFile(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg.?;
    if (ct_msg.items.len > 0) util.bufByte(&ct_msg, '\n');
    const data = if (util.eql(a, "-")) readStdin() else (os.readFile(util.concat(&.{ po.prefix, a })) orelse util.dieErrno("could not read log file '{s}'", .{a}));
    util.bufAppend(&ct_msg, data);
    if (ct_msg.items.len > 0 and ct_msg.items[ct_msg.items.len - 1] != '\n') util.bufByte(&ct_msg, '\n');
    ct_have_msg = true;
}

pub fn cmdCommitTree(args: []const []const u8) u8 {
    var sign: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.callback('p', "", ctParent, "parent", "id of a parent commit object"),
        po.callback('m', "", ctMessage, "message", "commit message"),
        po.callback('F', "", ctFile, "file", "read commit log message from file"),
        po.optString('S', "gpg-sign", &sign, "", "key-id", "GPG sign commit"),
    };
    const usage = [_][]const u8{"git commit-tree <tree> [(-p <parent>)...]\n                [(-m <message>)...] [(-F <file>)...] <tree>"};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len != 1) {
        if (rest.len == 0) util.die("must give exactly one tree", .{});
        util.die("must give exactly one tree", .{});
    }
    const tree = revparse.getTreeish(rest[0]) orelse util.die("not a valid object name {s}", .{rest[0]});
    if (!ct_have_msg) {
        const data = readStdin();
        util.bufAppend(&ct_msg, data);
    }
    const oid = commit_mod.create(.{ .tree = tree, .parents = ct_parents.items, .message = ct_msg.items });
    util.outf("{s}\n", .{hash.hex(oid)});
    return 0;
}

// ---------------- mktree ----------------

pub fn cmdMktree(args: []const []const u8) u8 {
    var nul = false;
    var missing = false;
    var batch = false;
    const opts = [_]po.Opt{
        po.boolean('z', "", &nul, "input is NUL terminated"),
        po.boolean(0, "missing", &missing, "allow missing objects"),
        po.boolean(0, "batch", &batch, "allow creation of more than one tree"),
    };
    const usage = [_][]const u8{"git mktree [-z] [--missing] [--batch]"};
    _ = po.parse(args[1..], &opts, &usage, .{});
    const input = readStdin();
    const sep: u8 = if (nul) 0 else '\n';
    var entries: std.ArrayList(objects.TreeEntry) = .empty;
    var it = std.mem.splitScalar(u8, input, sep);
    var got_eof = false;
    while (!got_eof) {
        while (true) {
            const line_opt = it.next();
            if (line_opt == null or (line_opt.?.len == 0 and it.index == null)) {
                got_eof = true;
                break;
            }
            const line = line_opt.?;
            if (line.len == 0) {
                if (batch) break;
                util.die("input format error: (blank line only valid in batch mode)", .{});
            }
            mktreeLine(&entries, line, nul, missing);
        }
        if (!(batch and got_eof and entries.items.len < 1)) {
            objects.sortTreeEntries(entries.items);
            const oid = repo_mod.repo().odb().write(.tree, objects.formatTree(entries.items));
            util.outf("{s}\n", .{hash.hex(oid)});
            util.flushStdout();
        }
        entries.clearRetainingCapacity();
    }
    return 0;
}

fn mktreeLine(entries: *std.ArrayList(objects.TreeEntry), line: []const u8, nul: bool, missing_in: bool) void {
    var allow_missing = missing_in;
    // "mode SP type SP sha TAB path" (strtoul-style mode parse)
    var p: usize = 0;
    while (p < line.len and (line[p] == ' ' or line[p] == '\t')) p += 1;
    const ds = p;
    var mode: u32 = 0;
    while (p < line.len and line[p] >= '0' and line[p] <= '7') : (p += 1) mode = mode *% 8 +% (line[p] - '0');
    if (p == ds or p >= line.len or line[p] != ' ') util.die("input format error: {s}", .{line});
    const ts = p + 1;
    const sp2 = std.mem.indexOfScalarPos(u8, line, ts, ' ') orelse util.die("input format error: {s}", .{line});
    if (line.len < sp2 + 1 + 40) util.die("input format error: {s}", .{line});
    const oid = hash.fromHex(line[sp2 + 1 .. sp2 + 41]) orelse util.die("input format error: {s}", .{line});
    if (line.len <= sp2 + 41 or line[sp2 + 41] != '\t') util.die("input format error: {s}", .{line});
    if (mode & 0o170000 == 0o160000) allow_missing = true;
    const typ_s = line[ts..sp2];
    var path: []const u8 = line[sp2 + 42 ..];
    if (!nul and path.len > 0 and path[0] == '"') {
        path = (util.cunquote(path) orelse util.die("invalid quoting", .{})).value;
    }
    const mode_type: ObjType = if (mode & 0o170000 == 0o040000) .tree else if (mode & 0o170000 == 0o160000) .commit else .blob;
    const given = ObjType.fromName(typ_s) orelse util.die("invalid object type \"{s}\"", .{typ_s});
    if (given != mode_type) util.die("entry '{s}' object type ({s}) doesn't match mode type ({s})", .{ path, typ_s, mode_type.name() });
    if (repo_mod.repo().odb().readType(oid)) |t| {
        if (t != mode_type)
            util.die("entry '{s}' object {s} is a {s} but specified type was ({s})", .{ path, hash.hex(oid), t.name(), mode_type.name() });
    } else if (!allow_missing) {
        util.die("entry '{s}' object {s} is unavailable", .{ path, hash.hex(oid) });
    }
    if (std.mem.indexOfScalar(u8, path, '/') != null) util.die("path {s} contains slash", .{path});
    entries.append(gpa, .{ .mode = mode, .name = util.dupe(path), .oid = oid }) catch util.oom();
}
