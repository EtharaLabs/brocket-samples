//! git read-tree (builtin/read-tree.c)

const std = @import("std");
const util = @import("../util.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const ut = @import("../unpacktrees.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git read-tree [(-m [--trivial] [--aggressive] | --reset | --prefix=<prefix>)\n" ++
        "              [-u | -i]] [--index-output=<file>] [--no-sparse-checkout]\n" ++
        "              (--empty | <tree-ish1> [<tree-ish2> [<tree-ish3>]])",
};

var index_output: ?[]const u8 = null;
var read_empty = false;
var verbose = false;
var merge = false;
var trivial = false;
var aggressive = false;
var reset = false;
var prefix: ?[]const u8 = null;
var update = false;
var index_only = false;
var dry_run = false;
var no_sparse = false;
var debug_unpack = false;
var quiet = false;
var super_prefix: ?[]const u8 = null;
fn excludeCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    if (!update) util.die("--exclude-per-directory is meaningless unless -u", .{});
    if (!util.eql(arg.?, ".gitignore")) util.die("--exclude-per-directory argument must be .gitignore", .{});
}
var recurse_submodules: ?[]const u8 = null;

const options = [_]po.Opt{
    .{ .long = "super-prefix", .kind = .string, .s = &super_prefix, .argh = "path", .help = "prepended to all paths", .hidden = true },
    .{ .long = "index-output", .kind = .string, .s = &index_output, .argh = "file", .help = "write resulting index to <file>", .noneg = true },
    po.boolean(0, "empty", &read_empty, "only empty the index"),
    po.boolean('v', "verbose", &verbose, "be verbose"),
    po.group("Merging"),
    po.boolean('m', "", &merge, "perform a merge in addition to a read"),
    po.boolean(0, "trivial", &trivial, "3-way merge if no file level merging required"),
    po.boolean(0, "aggressive", &aggressive, "3-way merge in presence of adds and removes"),
    po.boolean(0, "reset", &reset, "same as -m, but discard unmerged entries"),
    .{ .long = "prefix", .kind = .string, .s = &prefix, .argh = "<subdirectory>/", .literal_argh = true, .help = "read the tree into the index under <subdirectory>/", .noneg = true },
    po.boolean('u', "", &update, "update working tree with merge result"),
    .{ .long = "exclude-per-directory", .kind = .callback, .cb = excludeCb, .argh = "gitignore", .help = "allow explicitly ignored files to be overwritten", .noneg = true },
    po.boolean('i', "", &index_only, "don't check the working tree after merging"),
    po.boolean('n', "dry-run", &dry_run, "don't update the index or the work tree"),
    po.boolean(0, "no-sparse-checkout", &no_sparse, "skip applying sparse checkout filter"),
    po.boolean(0, "debug-unpack", &debug_unpack, "debug unpack-trees"),
    .{ .long = "recurse-submodules", .kind = .string, .s = &recurse_submodules, .argh = "checkout", .help = "control recursive updating of submodules", .optarg = true, .def = "1" },
    po.boolean('q', "quiet", &quiet, "suppress feedback messages"),
};

fn debugStage(label: []const u8, ce: ?*const index_mod.Entry) void {
    util.outf("{s} ", .{label});
    if (ce == null) {
        util.out("(missing)\n");
    } else if (ut.isDf(ce)) {
        util.out("(conflict)\n");
    } else {
        const e = ce.?;
        util.outf("{o:0>6} #{d} {s} {s}\n", .{ e.mode, e.stage(), e.path, hash.hex(e.oid)[0..8] });
    }
}

fn debugMerge(stages: []const ?*const index_mod.Entry, o: *ut.Options) i32 {
    util.outf("* {d}-way merge\n", .{o.merge_size});
    debugStage("index", stages[0]);
    var i: usize = 1;
    while (i <= o.merge_size) : (i += 1) {
        debugStage(util.fmt("ent#{d}", .{i}), stages[i]);
    }
    return 0;
}

pub fn run(args: []const []const u8) u8 {
    const rest = po.parse(args[1..], &options, &usage, .{});
    var o = ut.Options{};
    o.merge = merge;
    o.trivial_merges_only = trivial;
    o.aggressive = aggressive;
    o.prefix = prefix;
    o.update = update;
    o.index_only = index_only;
    o.dry_run = dry_run;
    o.quiet = quiet;
    o.verbose_update = verbose;
    o.super_prefix = super_prefix;
    o.skip_sparse_checkout = no_sparse;

    const nsel = @as(u32, @intFromBool(merge)) + @intFromBool(reset) + @intFromBool(prefix != null);
    if (nsel > 1) util.die("Which one? -m, --reset, or --prefix?", .{});
    if (prefix) |p| {
        if (p.len > 0 and p[0] == '/') util.die("Invalid prefix, prefix cannot start with '/'", .{});
    }
    if (reset) o.reset = .overwrite_untracked;

    // C reads the index only for -m, --reset and --prefix
    const idx = if (reset or merge or prefix != null) index_mod.lockAndRead() else index_mod.lockFresh();
    o.src_index = idx;
    o.dst_index = idx;

    var stage: usize = 0;
    if (reset or merge or prefix != null) {
        if (ut.readIndexUnmerged(idx) and (prefix != null or merge))
            util.die("You need to resolve your current index first", .{});
        stage = 1;
        o.merge = true;
    }
    idx.reuc.clearRetainingCapacity();

    var trees: std.ArrayList(hash.Oid) = .empty;
    for (rest) |arg| {
        const oid = revparse.getOid(arg) orelse util.die("Not a valid object name {s}", .{arg});
        if (trees.items.len >= ut.MAX_UNPACK_TREES) util.die("I cannot read more than {d} trees", .{ut.MAX_UNPACK_TREES});
        const t = objects.peelTo(oid, .tree) orelse util.die("failed to unpack tree object {s}", .{arg});
        trees.append(gpa, t) catch util.oom();
        stage += 1;
    }
    if (trees.items.len == 0 and !read_empty and !o.merge) {
        util.warn("read-tree: emptying the index with no arguments is deprecated; use --empty", .{});
    } else if (trees.items.len > 0 and read_empty) {
        util.die("passing trees as arguments contradicts --empty", .{});
    }
    if (update and index_only) util.die("-u and -i at the same time makes no sense", .{});
    if ((update or index_only) and !o.merge)
        util.die("{s} is meaningless without -m, --reset, or --prefix", .{if (update) "-u" else "-i"});
    if (o.merge and !index_only and repo_mod.repo().work_tree == null)
        util.die("this operation must be run in a work tree", .{});

    if (o.merge) {
        switch (stage - 1) {
            0 => util.die("you must specify at least one tree to merge", .{}),
            1 => o.func = if (prefix != null) &ut.bindMerge else &ut.onewayMerge,
            2 => {
                o.func = &ut.twowayMerge;
                o.initial_checkout = idx.entries.items.len == 0 and idx.timestamp_s == 0;
            },
            else => o.func = &ut.threewayMerge,
        }
        o.head_idx = if (stage - 1 >= 3) stage - 2 else 1;
    }
    if (debug_unpack) o.func = &debugMerge;

    if (trees.items.len == 1 and prefix == null) o.skip_cache_tree_update = true;
    idx.cache_tree = null;

    if (ut.unpackTrees(trees.items, &o) != 0) return 128;
    if (debug_unpack or dry_run) return 0;

    if (trees.items.len == 1 and prefix == null) index_mod.primeCacheTree(idx, trees.items[0]);

    idx.writeToLock();
    const l = idx.lock.?;
    if (index_output) |io| l.path = io;
    if (!l.commit()) util.die("unable to write new index file", .{});
    idx.lock = null;
    return 0;
}
