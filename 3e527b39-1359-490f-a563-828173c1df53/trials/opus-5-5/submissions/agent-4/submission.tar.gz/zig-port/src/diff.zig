//! Port of git's diff machinery (diff.c, ws.c, diff-lib.c, parts of diffcore).
//!
//! Stable API (used by other commands):
//!
//!   var o = diff.DiffOptions.init();       // porcelain defaults (diff.* UI config, renames)
//!   var o = diff.DiffOptions.initBasic();  // plumbing defaults (basic config only)
//!   o.output_format = diff.FMT_PATCH | diff.FMT_DIFFSTAT ...;  (FMT_RAW, FMT_DIFFSTAT,
//!       FMT_NUMSTAT, FMT_SUMMARY, FMT_PATCH, FMT_SHORTSTAT, FMT_DIRSTAT, FMT_NAME,
//!       FMT_NAME_STATUS, FMT_CHECKDIFF, FMT_NO_OUTPUT)
//!   o.detect_rename = diff.DETECT_RENAME / DETECT_COPY; o.pathspec = ...;
//!   o.flags.recursive / .reverse / .quick / .exit_with_status ...
//!   o.file: ?*util.Out (default &util.stdout; null = no output)
//!   const n = o.parseOpt(args, i);   // consume diff options at args[i] (0 = not a diff option)
//!   o.setupDone();                    // diff_setup_done
//!
//!   diff.diffTree(&o, old_tree_or_null, new_tree_or_null, base)  // queue tree changes
//!   diff.runDiffIndex(&o, tree_oid, cached)                      // queue tree vs index/worktree
//!   diff.runDiffFiles(&o)                                        // queue index vs worktree
//!   diff.flush(&o)            // diffcore_std + diff_flush (prints and clears the queue)
//!   diff.diffcoreStd(&o) then inspect diff.queue.items (*FilePair{status, score,
//!       one/two: *Filespec{path, oid, mode, oid_valid}}) then diff.clearQueue()
//!   diff.hasChanges(&o) / diff.resultCode(&o)
//!   diff.treesSame(old, new, &pathspec) bool
//!   diff.diffCombined(&o, commit_oid, parents, dense)
//!   diff.printStatSummary(out, files, ins, del)
//!   diff.setupRevDiff(revs) / diff.revResultCode(revs): install diff hooks for log & co.
//!   ws.c: parseWhitespaceRule, whitespaceRule, wsErrorString, wsCheck, wsCheckEmit,
//!       wsBlankLine, wsFixCopy (WS_* constants).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const color = @import("color.zig");
const attr = @import("attr.zig");
const pathspec_mod = @import("pathspec.zig");
const xdiff = @import("xdiff.zig");
const regex = @import("regex.zig");
const userdiff = @import("userdiff.zig");
const index_mod = @import("index.zig");
const objects = @import("objects.zig");
const convert = @import("convert.zig");
const revparse = @import("revparse.zig");
const pretty = @import("pretty.zig");
const odb_mod = @import("odb.zig");
const revision = @import("revision.zig");
const graph_mod = @import("graph.zig");
const cn = @import("commitnode.zig");
pub const diffcore = @import("diffcore.zig");
pub const treediff = @import("treediff.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Buf = util.Buf;

// ---------------------------------------------------------------------------
// constants (diff.h, ws.h, diffcore.h)

pub const FMT_RAW: u32 = 0x0001;
pub const FMT_DIFFSTAT: u32 = 0x0002;
pub const FMT_NUMSTAT: u32 = 0x0004;
pub const FMT_SUMMARY: u32 = 0x0008;
pub const FMT_PATCH: u32 = 0x0010;
pub const FMT_SHORTSTAT: u32 = 0x0020;
pub const FMT_DIRSTAT: u32 = 0x0040;
pub const FMT_NAME: u32 = 0x0100;
pub const FMT_NAME_STATUS: u32 = 0x0200;
pub const FMT_CHECKDIFF: u32 = 0x0400;
pub const FMT_NO_OUTPUT: u32 = 0x0800;
pub const FMT_CALLBACK: u32 = 0x1000;

pub const DETECT_RENAME: u8 = 1;
pub const DETECT_COPY: u8 = 2;

pub const MAX_SCORE: u32 = 60000;
pub const DEFAULT_RENAME_SCORE: u32 = 30000;
pub const DEFAULT_BREAK_SCORE: u32 = 30000;
pub const DEFAULT_MERGE_SCORE: u32 = 36000;
pub const MINIMUM_BREAK_SIZE: usize = 400;

pub const PICKAXE_ALL: u32 = 1;
pub const PICKAXE_REGEX: u32 = 2;
pub const PICKAXE_KIND_S: u32 = 4;
pub const PICKAXE_KIND_G: u32 = 8;
pub const PICKAXE_KIND_OBJFIND: u32 = 16;
pub const PICKAXE_KINDS_MASK: u32 = PICKAXE_KIND_S | PICKAXE_KIND_G | PICKAXE_KIND_OBJFIND;
pub const PICKAXE_IGNORE_CASE: u32 = 32;

pub const WS_BLANK_AT_EOL: u32 = 1 << 6;
pub const WS_SPACE_BEFORE_TAB: u32 = 1 << 7;
pub const WS_INDENT_WITH_NON_TAB: u32 = 1 << 8;
pub const WS_CR_AT_EOL: u32 = 1 << 9;
pub const WS_BLANK_AT_EOF: u32 = 1 << 10;
pub const WS_TAB_IN_INDENT: u32 = 1 << 11;
pub const WS_INCOMPLETE_LINE: u32 = 1 << 12;
pub const WS_TRAILING_SPACE: u32 = WS_BLANK_AT_EOL | WS_BLANK_AT_EOF;
pub const WS_DEFAULT_RULE: u32 = WS_TRAILING_SPACE | WS_SPACE_BEFORE_TAB | 8;
pub const WS_TAB_WIDTH_MASK: u32 = (1 << 6) - 1;
pub const WS_RULE_MASK: u32 = (1 << 16) - 1;

pub const WSEH_NEW: u32 = 1 << 16;
pub const WSEH_CONTEXT: u32 = 1 << 17;
pub const WSEH_OLD: u32 = 1 << 18;
const SYM_BLANK_LINE_EOF: u32 = 1 << 19;
const SYM_MOVED_LINE: u32 = 1 << 20;
const SYM_MOVED_LINE_ALT: u32 = 1 << 21;
const SYM_MOVED_LINE_UNINTERESTING: u32 = 1 << 22;
const SYM_CONTENT_WS_MASK: u32 = WSEH_NEW | WSEH_OLD | WSEH_CONTEXT | WS_RULE_MASK;

pub const STATUS_ADDED: u8 = 'A';
pub const STATUS_COPIED: u8 = 'C';
pub const STATUS_DELETED: u8 = 'D';
pub const STATUS_MODIFIED: u8 = 'M';
pub const STATUS_RENAMED: u8 = 'R';
pub const STATUS_TYPE_CHANGED: u8 = 'T';
pub const STATUS_UNKNOWN: u8 = 'X';
pub const STATUS_UNMERGED: u8 = 'U';
pub const STATUS_FILTER_AON: u8 = '*';
pub const STATUS_FILTER_BROKEN: u8 = 'B';

const status_letters = "ACDMRTXU*B";

pub fn filterBit(status: u8) u32 {
    for (status_letters, 0..) |c, i| {
        if (c == status) return @as(u32, 1) << @intCast(i);
    }
    return 0;
}

pub const WordDiff = enum { none, porcelain, plain, color };

pub const ColorMoved = enum(u8) { no = 0, plain = 1, blocks = 2, zebra = 3, zebra_dim = 4 };
pub const COLOR_MOVED_DEFAULT = ColorMoved.zebra;
pub const COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE: u32 = 1 << 5;
pub const COLOR_MOVED_WS_ERROR: u32 = 1 << 0;

pub const SubmoduleFormat = enum { short, log, inline_diff };

const OUTPUT_INDICATOR_NEW = 0;
const OUTPUT_INDICATOR_OLD = 1;
const OUTPUT_INDICATOR_CONTEXT = 2;

pub fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r';
}
fn isDigit(c: u8) bool {
    return c >= '0' and c <= '9';
}

fn sIsDir(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFDIR;
}
fn sIsReg(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFREG;
}
fn sIsLnk(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFLNK;
}
fn sIsGitlink(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFGITLINK;
}

// ---------------------------------------------------------------------------
// ws.c

pub var whitespace_rule_cfg: u32 = WS_DEFAULT_RULE;
var whitespace_cfg_loaded = false;

const WsRuleName = struct { name: []const u8, bits: u32, loosens_error: bool = false, exclude_default: bool = false };
const whitespace_rule_names = [_]WsRuleName{
    .{ .name = "trailing-space", .bits = WS_TRAILING_SPACE },
    .{ .name = "space-before-tab", .bits = WS_SPACE_BEFORE_TAB },
    .{ .name = "indent-with-non-tab", .bits = WS_INDENT_WITH_NON_TAB },
    .{ .name = "cr-at-eol", .bits = WS_CR_AT_EOL, .loosens_error = true },
    .{ .name = "blank-at-eol", .bits = WS_BLANK_AT_EOL },
    .{ .name = "blank-at-eof", .bits = WS_BLANK_AT_EOF },
    .{ .name = "tab-in-indent", .bits = WS_TAB_IN_INDENT, .exclude_default = true },
    .{ .name = "incomplete-line", .bits = WS_INCOMPLETE_LINE },
};

pub fn wsTabWidth(rule: u32) u32 {
    return rule & WS_TAB_WIDTH_MASK;
}

/// parse_whitespace_rule()
pub fn parseWhitespaceRule(string0: []const u8) u32 {
    var rule: u32 = WS_DEFAULT_RULE;
    var s = string0;
    while (true) {
        var k: usize = 0;
        while (k < s.len and (s[k] == ',' or s[k] == ' ' or s[k] == '\t' or s[k] == '\n' or s[k] == '\r')) k += 1;
        s = s[k..];
        const ep = std.mem.indexOfScalar(u8, s, ',') orelse s.len;
        var item = s[0..ep];
        var negated = false;
        if (item.len > 0 and item[0] == '-') {
            negated = true;
            item = item[1..];
        }
        if (item.len == 0) break;
        for (whitespace_rule_names) |r| {
            if (!std.mem.startsWith(u8, r.name, item)) continue;
            if (negated) rule &= ~r.bits else rule |= r.bits;
            break;
        }
        if (util.skipPrefix(s, "tabwidth=")) |arg| {
            var n: u32 = 0;
            var j: usize = 0;
            while (j < arg.len and isDigit(arg[j])) : (j += 1) n = n *| 10 +| (arg[j] - '0');
            if (0 < n and n < 0o100) {
                rule &= ~WS_TAB_WIDTH_MASK;
                rule |= n;
            } else {
                const arg_end = std.mem.indexOfScalar(u8, arg, ',') orelse arg.len;
                util.warn("tabwidth {s} out of range", .{arg[0..arg_end]});
            }
        }
        if (ep >= s.len) break;
        s = s[ep..];
    }
    if (rule & WS_TAB_IN_INDENT != 0 and rule & WS_INDENT_WITH_NON_TAB != 0)
        util.die("cannot enforce both tab-in-indent and indent-with-non-tab", .{});
    return rule;
}

fn loadWhitespaceCfg() void {
    if (whitespace_cfg_loaded) return;
    whitespace_cfg_loaded = true;
    if (repo_mod.cfg.getEntry("core.whitespace")) |e| {
        const v = e.value orelse util.die("missing value for '{s}'", .{e.key});
        whitespace_rule_cfg = parseWhitespaceRule(v);
    }
}

/// whitespace_rule(): rule for a path (attribute "whitespace" + core.whitespace)
pub fn whitespaceRule(path: []const u8) u32 {
    loadWhitespaceCfg();
    const v: attr.Value = if (repo_mod.repo_ != null) attr.get(path, "whitespace") else .unspecified;
    switch (v) {
        .set => {
            var all_rule = wsTabWidth(whitespace_rule_cfg);
            for (whitespace_rule_names) |r| {
                if (!r.loosens_error and !r.exclude_default) all_rule |= r.bits;
            }
            return all_rule;
        },
        .unset => return wsTabWidth(whitespace_rule_cfg),
        .unspecified => return whitespace_rule_cfg,
        .value => |s| return parseWhitespaceRule(s),
    }
}

/// whitespace_error_string()
pub fn wsErrorString(ws: u32) []const u8 {
    var err: Buf = .empty;
    if (ws & WS_TRAILING_SPACE == WS_TRAILING_SPACE) {
        util.bufAppend(&err, "trailing whitespace");
    } else {
        if (ws & WS_BLANK_AT_EOL != 0) util.bufAppend(&err, "trailing whitespace");
        if (ws & WS_BLANK_AT_EOF != 0) {
            if (err.items.len > 0) util.bufAppend(&err, ", ");
            util.bufAppend(&err, "new blank line at EOF");
        }
    }
    if (ws & WS_SPACE_BEFORE_TAB != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "space before tab in indent");
    }
    if (ws & WS_INDENT_WITH_NON_TAB != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "indent with spaces");
    }
    if (ws & WS_TAB_IN_INDENT != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "tab in indent");
    }
    if (ws & WS_INCOMPLETE_LINE != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "no newline at the end of file");
    }
    return err.items;
}

fn wsCheckEmit1(line: []const u8, ws_rule: u32, stream: ?*Buf, set: []const u8, reset: []const u8, ws: []const u8) u32 {
    var result: u32 = 0;
    var written: usize = 0;
    var trailing_whitespace: ?usize = null;
    var trailing_newline = false;
    var trailing_cr = false;
    var len = line.len;
    if (len > 0 and line[len - 1] == '\n') {
        trailing_newline = true;
        len -= 1;
    }
    if (ws_rule & WS_CR_AT_EOL != 0 and len > 0 and line[len - 1] == '\r') {
        trailing_cr = true;
        len -= 1;
    }
    if (ws_rule & WS_BLANK_AT_EOL != 0) {
        var i: usize = len;
        while (i > 0) {
            i -= 1;
            if (isSpace(line[i])) {
                trailing_whitespace = i;
                result |= WS_BLANK_AT_EOL;
            } else break;
        }
    }
    const tw = trailing_whitespace orelse len;
    if (!trailing_newline and ws_rule & WS_INCOMPLETE_LINE != 0) result |= WS_INCOMPLETE_LINE;

    var i: usize = 0;
    while (i < tw) : (i += 1) {
        if (line[i] == ' ') continue;
        if (line[i] != '\t') break;
        if (ws_rule & WS_SPACE_BEFORE_TAB != 0 and written < i) {
            result |= WS_SPACE_BEFORE_TAB;
            if (stream) |st| {
                util.bufAppend(st, ws);
                util.bufAppend(st, line[written..i]);
                util.bufAppend(st, reset);
                util.bufAppend(st, line[i .. i + 1]);
            }
        } else if (ws_rule & WS_TAB_IN_INDENT != 0) {
            result |= WS_TAB_IN_INDENT;
            if (stream) |st| {
                util.bufAppend(st, line[written..i]);
                util.bufAppend(st, ws);
                util.bufAppend(st, line[i .. i + 1]);
                util.bufAppend(st, reset);
            }
        } else if (stream) |st| {
            util.bufAppend(st, line[written .. i + 1]);
        }
        written = i + 1;
    }
    if (ws_rule & WS_INDENT_WITH_NON_TAB != 0 and i >= written and i - written >= wsTabWidth(ws_rule)) {
        result |= WS_INDENT_WITH_NON_TAB;
        if (stream) |st| {
            util.bufAppend(st, ws);
            util.bufAppend(st, line[written..i]);
            util.bufAppend(st, reset);
        }
        written = i;
    }
    if (stream) |st| {
        if (tw > written) {
            util.bufAppend(st, set);
            util.bufAppend(st, line[written..tw]);
            util.bufAppend(st, reset);
        }
        if (tw != len) {
            util.bufAppend(st, ws);
            util.bufAppend(st, line[tw..len]);
            util.bufAppend(st, reset);
        }
        if (trailing_cr) util.bufByte(st, '\r');
        if (trailing_newline) util.bufByte(st, '\n');
    }
    return result;
}

/// ws_check_emit(): append the line with whitespace errors highlighted to `stream`.
pub fn wsCheckEmit(line: []const u8, ws_rule: u32, stream: *Buf, set: []const u8, reset: []const u8, ws: []const u8) void {
    _ = wsCheckEmit1(line, ws_rule, stream, set, reset, ws);
}

/// ws_check()
pub fn wsCheck(line: []const u8, ws_rule: u32) u32 {
    return wsCheckEmit1(line, ws_rule, null, "", "", "");
}

/// ws_blank_line()
pub fn wsBlankLine(line: []const u8) bool {
    for (line) |c| {
        if (!isSpace(c)) return false;
    }
    return true;
}

/// ws_fix_copy(): append src to dst fixing whitespace errors per ws_rule.
pub fn wsFixCopy(dst: *Buf, src0: []const u8, ws_rule: u32, error_count: ?*usize) void {
    var src = src0;
    var len = src.len;
    var add_nl_to_tail = false;
    var add_cr_to_tail = false;
    var fixed = false;
    var last_tab_in_indent: isize = -1;
    var last_space_in_indent: isize = -1;
    var need_fix_leading_space = false;
    const tabw: isize = @intCast(wsTabWidth(ws_rule));

    if (ws_rule & WS_INCOMPLETE_LINE != 0) {
        if (0 < len and src[len - 1] != '\n') {
            fixed = true;
            add_nl_to_tail = true;
        }
    }
    if (ws_rule & WS_BLANK_AT_EOL != 0) {
        if (0 < len and src[len - 1] == '\n') {
            add_nl_to_tail = true;
            len -= 1;
            if (0 < len and src[len - 1] == '\r') {
                add_cr_to_tail = ws_rule & WS_CR_AT_EOL != 0;
                len -= 1;
            }
        }
        if (0 < len and isSpace(src[len - 1])) {
            while (0 < len and isSpace(src[len - 1])) len -= 1;
            fixed = true;
        }
    }
    var i: usize = 0;
    while (i < len) : (i += 1) {
        const ch = src[i];
        const ii: isize = @intCast(i);
        if (ch == '\t') {
            last_tab_in_indent = ii;
            if (ws_rule & WS_SPACE_BEFORE_TAB != 0 and 0 <= last_space_in_indent)
                need_fix_leading_space = true;
        } else if (ch == ' ') {
            last_space_in_indent = ii;
            if (ws_rule & WS_INDENT_WITH_NON_TAB != 0 and tabw <= ii - last_tab_in_indent)
                need_fix_leading_space = true;
        } else break;
    }
    if (need_fix_leading_space) {
        var consecutive_spaces: isize = 0;
        var last: usize = @intCast(last_tab_in_indent + 1);
        if (ws_rule & WS_INDENT_WITH_NON_TAB != 0) {
            if (last_tab_in_indent < last_space_in_indent)
                last = @intCast(last_space_in_indent + 1)
            else
                last = @intCast(last_tab_in_indent + 1);
        }
        i = 0;
        while (i < last) : (i += 1) {
            const ch = src[i];
            if (ch != ' ') {
                consecutive_spaces = 0;
                util.bufByte(dst, ch);
            } else {
                consecutive_spaces += 1;
                if (consecutive_spaces == tabw) {
                    util.bufByte(dst, '\t');
                    consecutive_spaces = 0;
                }
            }
        }
        while (consecutive_spaces > 0) : (consecutive_spaces -= 1) util.bufByte(dst, ' ');
        len -= last;
        src = src[last..];
        fixed = true;
    } else if (ws_rule & WS_TAB_IN_INDENT != 0 and last_tab_in_indent >= 0) {
        const start = dst.items.len;
        const last: usize = @intCast(last_tab_in_indent + 1);
        i = 0;
        while (i < last) : (i += 1) {
            if (src[i] == '\t') {
                while (true) {
                    util.bufByte(dst, ' ');
                    if ((dst.items.len - start) % @as(usize, @intCast(tabw)) == 0) break;
                }
            } else util.bufByte(dst, src[i]);
        }
        len -= last;
        src = src[last..];
        fixed = true;
    }
    util.bufAppend(dst, src[0..len]);
    if (add_cr_to_tail) util.bufByte(dst, '\r');
    if (add_nl_to_tail) util.bufByte(dst, '\n');
    if (fixed) {
        if (error_count) |ec| ec.* += 1;
    }
}

// ---------------------------------------------------------------------------
// colors

pub const Slot = enum(u8) {
    reset = 0,
    context,
    metainfo,
    fraginfo,
    old,
    new,
    commit,
    whitespace,
    funcinfo,
    old_moved,
    old_moved_alt,
    old_moved_dim,
    old_moved_alt_dim,
    new_moved,
    new_moved_alt,
    new_moved_dim,
    new_moved_alt_dim,
    context_dim,
    old_dim,
    new_dim,
    context_bold,
    old_bold,
    new_bold,
};

var diff_colors = [_][]const u8{
    color.RESET,
    "", // CONTEXT
    color.BOLD, // METAINFO
    color.CYAN, // FRAGINFO
    color.RED, // OLD
    color.GREEN, // NEW
    color.YELLOW, // COMMIT
    "\x1b[41m", // WHITESPACE
    "", // FUNCINFO
    color.BOLD_MAGENTA,
    color.BOLD_BLUE,
    color.FAINT,
    "\x1b[2;3m",
    color.BOLD_CYAN,
    color.BOLD_YELLOW,
    color.FAINT,
    "\x1b[2;3m",
    color.FAINT,
    "\x1b[2;31m",
    "\x1b[2;32m",
    color.BOLD,
    color.BOLD_RED,
    color.BOLD_GREEN,
};

const color_slot_names = [_][]const u8{
    "",                    "context",                   "meta",           "frag",
    "old",                 "new",                       "commit",         "whitespace",
    "func",                "oldMoved",                  "oldMovedAlternative", "oldMovedDimmed",
    "oldMovedAlternativeDimmed", "newMoved",            "newMovedAlternative", "newMovedDimmed",
    "newMovedAlternativeDimmed", "contextDimmed",       "oldDimmed",      "newDimmed",
    "contextBold",         "oldBold",                   "newBold",
};

fn parseDiffColorSlot(name: []const u8) ?usize {
    if (std.ascii.eqlIgnoreCase(name, "plain")) return @intFromEnum(Slot.context);
    for (color_slot_names, 0..) |n, i| {
        if (i == 0) continue;
        if (std.ascii.eqlIgnoreCase(n, name)) return i;
    }
    return null;
}

/// Slot lookup by name as used by log-tree's get_color hook ("commit", "reset", ...).
pub fn slotByName(name: []const u8) ?Slot {
    if (util.eql(name, "reset")) return .reset;
    const i = parseDiffColorSlot(name) orelse return null;
    return @enumFromInt(i);
}

var stdout_tty: ?bool = null;
pub fn wantColor(cb: color.ColorBool) bool {
    var v = cb;
    if (v == .unknown) v = git_use_color_default;
    if (v == .auto) {
        if (stdout_tty == null) stdout_tty = color.wantColorBool(.auto, null);
        return stdout_tty.?;
    }
    return v == .always;
}

pub fn getColor(o: *const DiffOptions, slot: Slot) []const u8 {
    if (wantColor(o.use_color)) return diff_colors[@intFromEnum(slot)];
    return "";
}

fn getColorCb(cb: color.ColorBool, slot: Slot) []const u8 {
    if (wantColor(cb)) return diff_colors[@intFromEnum(slot)];
    return "";
}

// ---------------------------------------------------------------------------
// configuration (git_diff_basic_config / git_diff_ui_config)

var basic_loaded = false;
var ui_loaded = false;

var diff_use_color_default: color.ColorBool = .unknown;
var git_use_color_default: color.ColorBool = .auto;
var diff_color_moved_default: ColorMoved = .no;
var diff_color_moved_ws_default: u32 = 0;
var diff_context_default: i32 = 3;
var diff_interhunk_context_default: i32 = 0;
var diff_word_regex_cfg: ?[]const u8 = null;
var external_diff_cfg: ?[]const u8 = null;
var external_diff_trust_cfg = false;
var diff_order_file_cfg: ?[]const u8 = null;
pub var diff_auto_refresh_index = true;
var diff_mnemonic_prefix = false;
var diff_no_prefix = false;
var diff_src_prefix: ?[]const u8 = null;
var diff_dst_prefix: ?[]const u8 = null;
var diff_relative = false;
var diff_stat_name_width: i32 = 0;
var diff_stat_graph_width: i32 = 0;
var diff_dirstat_permille_default: i32 = 30;
var diff_dirstat_flags_default: DirstatFlags = .{};
var diff_algorithm: u64 = 0;
var ws_error_highlight_default: u32 = WSEH_NEW;
var diff_detect_rename_default: u8 = 0;
var diff_rename_limit_default: i32 = 1000;
var diff_suppress_blank_empty = false;
var diff_indent_heuristic = true;
var diff_submodule_format_default: SubmoduleFormat = .short;
var diff_ignore_submodules_default: ?[]const u8 = null;

const DirstatFlags = struct { by_line: bool = false, by_file: bool = false, cumulative: bool = false };

fn cfgInt(e: config.Entry) i32 {
    const kv = e.kvi();
    return config.configInt(e.key, e.value, &kv);
}

/// config_error_nonbool + die (git dies on config callback errors)
fn cfgNonbool(e: config.Entry) []const u8 {
    return e.value orelse {
        util.err("missing value for '{s}'", .{e.key});
        badConfigDie(e);
    };
}

fn badConfigDie(e: config.Entry) noreturn {
    if (e.origin_type == .cmdline or e.origin.len == 0)
        util.die("unable to parse '{s}' from command-line config", .{e.key});
    util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
}

fn parseAlgorithmValue(value: ?[]const u8) ?u64 {
    const v = value orelse return null;
    if (std.ascii.eqlIgnoreCase(v, "myers") or std.ascii.eqlIgnoreCase(v, "default")) return 0;
    if (std.ascii.eqlIgnoreCase(v, "minimal")) return xdiff.XDF_NEED_MINIMAL;
    if (std.ascii.eqlIgnoreCase(v, "patience")) return xdiff.XDF_PATIENCE_DIFF;
    if (std.ascii.eqlIgnoreCase(v, "histogram")) return xdiff.XDF_HISTOGRAM_DIFF;
    return null;
}

/// git_config_rename()
fn configRename(key: []const u8, value: ?[]const u8) u8 {
    const v = value orelse return DETECT_RENAME;
    if (std.ascii.eqlIgnoreCase(v, "copies") or std.ascii.eqlIgnoreCase(v, "copy")) return DETECT_COPY;
    return if (config.configBool(key, v)) DETECT_RENAME else 0;
}

fn parseOneToken(arg: *[]const u8, token: []const u8) bool {
    if (util.skipPrefix(arg.*, token)) |rest| {
        if (rest.len == 0 or rest[0] == ',') {
            arg.* = rest;
            return true;
        }
    }
    return false;
}

/// parse_ws_error_highlight(): value, or error offset (-1 - offset)
fn parseWsErrorHighlight(arg0: []const u8) i64 {
    var arg = arg0;
    var val: u32 = 0;
    while (arg.len > 0) {
        if (parseOneToken(&arg, "none")) {
            val = 0;
        } else if (parseOneToken(&arg, "default")) {
            val = WSEH_NEW;
        } else if (parseOneToken(&arg, "all")) {
            val = WSEH_NEW | WSEH_OLD | WSEH_CONTEXT;
        } else if (parseOneToken(&arg, "new")) {
            val |= WSEH_NEW;
        } else if (parseOneToken(&arg, "old")) {
            val |= WSEH_OLD;
        } else if (parseOneToken(&arg, "context")) {
            val |= WSEH_CONTEXT;
        } else {
            return -1 - @as(i64, @intCast(arg0.len - arg.len));
        }
        if (arg.len > 0) arg = arg[1..];
    }
    return val;
}

fn parseColorMoved(arg: ?[]const u8) ?ColorMoved {
    switch (config.parseMaybeBool(arg)) {
        0 => return .no,
        1 => return COLOR_MOVED_DEFAULT,
        else => {},
    }
    const a = arg orelse return null;
    if (util.eql(a, "no")) return .no;
    if (util.eql(a, "plain")) return .plain;
    if (util.eql(a, "blocks")) return .blocks;
    if (util.eql(a, "zebra")) return .zebra;
    if (util.eql(a, "default")) return COLOR_MOVED_DEFAULT;
    if (util.eql(a, "dimmed-zebra") or util.eql(a, "dimmed_zebra")) return .zebra_dim;
    util.err("color moved setting must be one of 'no', 'default', 'blocks', 'zebra', 'dimmed-zebra', 'plain'", .{});
    return null;
}

fn parseColorMovedWs(arg: []const u8) u32 {
    var ret: u32 = 0;
    var it = std.mem.splitScalar(u8, arg, ',');
    while (it.next()) |raw| {
        const s = util.trim(raw);
        if (util.eql(s, "no")) {
            ret = 0;
        } else if (util.eql(s, "ignore-space-change")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE_CHANGE);
        } else if (util.eql(s, "ignore-space-at-eol")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE_AT_EOL);
        } else if (util.eql(s, "ignore-all-space")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE);
        } else if (util.eql(s, "allow-indentation-change")) {
            ret |= COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE;
        } else {
            ret |= COLOR_MOVED_WS_ERROR;
            util.err("unknown color-moved-ws mode '{s}', possible values are 'ignore-space-change', 'ignore-space-at-eol', 'ignore-all-space', 'allow-indentation-change'", .{s});
        }
    }
    if (ret & COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE != 0 and ret & @as(u32, @intCast(xdiff.XDF_WHITESPACE_FLAGS)) != 0) {
        util.err("color-moved-ws: allow-indentation-change cannot be combined with other whitespace modes", .{});
        ret |= COLOR_MOVED_WS_ERROR;
    }
    return ret;
}

/// parse_dirstat_params(): returns error text (empty if ok)
fn parseDirstatParams(o: *DiffOptions, params: []const u8) []const u8 {
    var errmsg: Buf = .empty;
    if (params.len == 0) return "";
    var it = std.mem.splitScalar(u8, params, ',');
    while (it.next()) |p| {
        if (util.eql(p, "changes")) {
            o.flags.dirstat_by_line = false;
            o.flags.dirstat_by_file = false;
        } else if (util.eql(p, "lines")) {
            o.flags.dirstat_by_line = true;
            o.flags.dirstat_by_file = false;
        } else if (util.eql(p, "files")) {
            o.flags.dirstat_by_line = false;
            o.flags.dirstat_by_file = true;
        } else if (util.eql(p, "noncumulative")) {
            o.flags.dirstat_cumulative = false;
        } else if (util.eql(p, "cumulative")) {
            o.flags.dirstat_cumulative = true;
        } else if (p.len > 0 and isDigit(p[0])) {
            var j: usize = 0;
            var n: i32 = 0;
            while (j < p.len and isDigit(p[j])) : (j += 1) n = n *% 10 +% @as(i32, p[j] - '0');
            var permille = n *% 10;
            if (j < p.len and p[j] == '.' and j + 1 < p.len and isDigit(p[j + 1])) {
                j += 1;
                permille += p[j] - '0';
                j += 1;
                while (j < p.len and isDigit(p[j])) j += 1;
            } else if (j < p.len and p[j] == '.') {
                j += 1;
            }
            if (j == p.len) {
                o.dirstat_permille = permille;
            } else {
                util.bufPrint(&errmsg, "  Failed to parse dirstat cut-off percentage '{s}'\n", .{p});
            }
        } else {
            util.bufPrint(&errmsg, "  Unknown dirstat parameter '{s}'\n", .{p});
        }
    }
    return errmsg.items;
}

fn loadBasicConfig() void {
    if (basic_loaded) return;
    basic_loaded = true;
    loadWhitespaceCfg();
    userdiff.loadConfig();
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        if (util.eql(k, "diff.renamelimit")) {
            diff_rename_limit_default = cfgInt(e);
        } else if (util.skipPrefix(k, "diff.color.") orelse util.skipPrefix(k, "color.diff.")) |name| {
            const slot = parseDiffColorSlot(name) orelse continue;
            const v = cfgNonbool(e);
            diff_colors[slot] = color.parseColor(v) orelse {
                util.err("invalid color value: {s}", .{v});
                badConfigDie(e);
            };
        } else if (util.eql(k, "diff.wserrorhighlight")) {
            const v = cfgNonbool(e);
            const val = parseWsErrorHighlight(v);
            if (val < 0) {
                util.err("unknown value for config '{s}': {s}", .{ k, v });
                badConfigDie(e);
            }
            ws_error_highlight_default = @intCast(val);
        } else if (util.eql(k, "diff.suppressblankempty") or util.eql(k, "diff.suppress-blank-empty")) {
            diff_suppress_blank_empty = config.configBool(k, e.value);
        } else if (util.eql(k, "diff.dirstat")) {
            const v = cfgNonbool(e);
            var tmp = DiffOptions.zero();
            tmp.dirstat_permille = diff_dirstat_permille_default;
            tmp.flags.dirstat_by_line = diff_dirstat_flags_default.by_line;
            tmp.flags.dirstat_by_file = diff_dirstat_flags_default.by_file;
            tmp.flags.dirstat_cumulative = diff_dirstat_flags_default.cumulative;
            const em = parseDirstatParams(&tmp, v);
            if (em.len > 0) util.warn("Found errors in 'diff.dirstat' config variable:\n{s}", .{em});
            diff_dirstat_permille_default = tmp.dirstat_permille;
            diff_dirstat_flags_default = .{ .by_line = tmp.flags.dirstat_by_line, .by_file = tmp.flags.dirstat_by_file, .cumulative = tmp.flags.dirstat_cumulative };
        } else if (util.eql(k, "diff.indentheuristic")) {
            diff_indent_heuristic = config.configBool(k, e.value);
        }
    }
}

fn loadUiConfig() void {
    loadBasicConfig();
    if (ui_loaded) return;
    ui_loaded = true;
    diff_detect_rename_default = DETECT_RENAME;
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        const v = e.value;
        if (util.eql(k, "diff.color") or util.eql(k, "color.diff")) {
            diff_use_color_default = color.configColorBool(k, v);
        } else if (util.eql(k, "color.ui")) {
            git_use_color_default = color.configColorBool(k, v);
        } else if (util.eql(k, "diff.colormoved")) {
            diff_color_moved_default = parseColorMoved(v) orelse badConfigDie(e);
        } else if (util.eql(k, "diff.colormovedws")) {
            const s = cfgNonbool(e);
            const cm = parseColorMovedWs(s);
            if (cm & COLOR_MOVED_WS_ERROR != 0) badConfigDie(e);
            diff_color_moved_ws_default = cm;
        } else if (util.eql(k, "diff.context")) {
            const val = cfgInt(e);
            if (val < 0) badConfigDie(e);
            diff_context_default = val;
        } else if (util.eql(k, "diff.interhunkcontext")) {
            const val = cfgInt(e);
            if (val < 0) badConfigDie(e);
            diff_interhunk_context_default = val;
        } else if (util.eql(k, "diff.renames")) {
            diff_detect_rename_default = configRename(k, v);
        } else if (util.eql(k, "diff.autorefreshindex")) {
            diff_auto_refresh_index = config.configBool(k, v);
        } else if (util.eql(k, "diff.mnemonicprefix")) {
            diff_mnemonic_prefix = config.configBool(k, v);
        } else if (util.eql(k, "diff.noprefix")) {
            diff_no_prefix = config.configBool(k, v);
        } else if (util.eql(k, "diff.srcprefix")) {
            diff_src_prefix = cfgNonbool(e);
        } else if (util.eql(k, "diff.dstprefix")) {
            diff_dst_prefix = cfgNonbool(e);
        } else if (util.eql(k, "diff.relative")) {
            diff_relative = config.configBool(k, v);
        } else if (util.eql(k, "diff.statnamewidth")) {
            diff_stat_name_width = cfgInt(e);
        } else if (util.eql(k, "diff.statgraphwidth")) {
            diff_stat_graph_width = cfgInt(e);
        } else if (util.eql(k, "diff.external")) {
            external_diff_cfg = cfgNonbool(e);
        } else if (util.eql(k, "diff.trustexitcode")) {
            external_diff_trust_cfg = config.configBool(k, v);
        } else if (util.eql(k, "diff.wordregex")) {
            diff_word_regex_cfg = cfgNonbool(e);
        } else if (util.eql(k, "diff.orderfile")) {
            _ = cfgNonbool(e);
            diff_order_file_cfg = repo_mod.cfg.getPath(k);
        } else if (util.eql(k, "diff.ignoresubmodules")) {
            diff_ignore_submodules_default = cfgNonbool(e);
        } else if (util.eql(k, "diff.submodule")) {
            const s = cfgNonbool(e);
            if (util.eql(s, "log")) {
                diff_submodule_format_default = .log;
            } else if (util.eql(s, "short")) {
                diff_submodule_format_default = .short;
            } else if (util.eql(s, "diff")) {
                diff_submodule_format_default = .inline_diff;
            } else util.warn("Unknown value for 'diff.submodule' config variable: '{s}'", .{s});
        } else if (util.eql(k, "diff.algorithm")) {
            const s = cfgNonbool(e);
            diff_algorithm = parseAlgorithmValue(s) orelse {
                util.err("unknown value for config '{s}': {s}", .{ k, s });
                badConfigDie(e);
            };
        }
    }
}

/// Make the porcelain ("UI") diff configuration effective (git_diff_ui_config).
pub fn useUiConfig() void {
    loadUiConfig();
}

/// external_diff(): GIT_EXTERNAL_DIFF or diff.external
fn externalDiff() ?[]const u8 {
    if (os.getenv("GIT_EXTERNAL_DIFF")) |e| return e;
    return external_diff_cfg;
}
