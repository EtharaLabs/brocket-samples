//! git blame / git annotate (port of blame.c and builtin/blame.c)

const std = @import("std");
const util = @import("../util.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const refs = @import("../refs.zig");
const cn = @import("../commitnode.zig");
const revision = @import("../revision.zig");
const po = @import("../parseopt.zig");
const xdiff = @import("../xdiff.zig");
const linerange = @import("../linerange.zig");
const date = @import("../date.zig");
const mailmap = @import("../mailmap.zig");
const pretty = @import("../pretty.zig");
const index_mod = @import("../index.zig");
const os = @import("../os.zig");
const convert = @import("../convert.zig");
const color = @import("../color.zig");
const odb_mod = @import("../odb.zig");
const diff_mod = @import("../diff.zig");
const config_mod = @import("../config.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Commit = cn.Commit;
const Buf = util.Buf;

const METAINFO_SHOWN: u32 = 1 << 12;
const MORE_THAN_ONE_PATH: u32 = 1 << 13;
const INT_MAX: i32 = std.math.maxInt(i32);

const S_IFMT: u32 = 0o170000;
const S_IFREG: u32 = 0o100000;

// ---------------------------------------------------------------------------
// scoreboard data structures

const Origin = struct {
    refcnt: i32 = 1,
    previous: ?*Origin = null,
    next: ?*Origin = null,
    commit: *Commit,
    suspects: ?*Entry = null,
    file: ?[]const u8 = null,
    blob_oid: Oid = hash.zero,
    mode: u32 = 0,
    guilty: bool = false,
    path: []const u8,
    fingerprints: ?[]Fingerprint = null,
    num_lines: i32 = 0,
};

const Entry = struct {
    next: ?*Entry = null,
    lno: i32 = 0,
    num_lines: i32 = 0,
    suspect: ?*Origin = null,
    s_lno: i32 = 0,
    score: u32 = 0,
    ignored: bool = false,
    unblamable: bool = false,
};

var suspects_slab = cn.Slab(?*Origin).init(null);

fn getSuspects(c: *Commit) ?*Origin {
    const p = suspects_slab.peek(c) orelse return null;
    return p.*;
}
fn setSuspects(c: *Commit, o: ?*Origin) void {
    suspects_slab.at(c).* = o;
}

fn incref(o: ?*Origin) ?*Origin {
    if (o) |x| x.refcnt += 1;
    return o;
}

fn decref(o0: ?*Origin) void {
    const o = o0 orelse return;
    o.refcnt -= 1;
    if (o.refcnt > 0) return;
    if (o.previous) |p| decref(p);
    o.file = null;
    var l: ?*Origin = null;
    var p = getSuspects(o.commit);
    while (p) |x| : ({
        l = x;
        p = x.next;
    }) {
        if (x == o) {
            if (l) |ll| ll.next = x.next else setSuspects(o.commit, x.next);
            return;
        }
    }
    util.die("internal error in blame_origin_decref", .{});
}

fn makeOrigin(commit: *Commit, path: []const u8) *Origin {
    const o = gpa.create(Origin) catch util.oom();
    o.* = .{ .commit = commit, .path = util.dupe(path) };
    o.next = getSuspects(commit);
    setSuspects(commit, o);
    return o;
}

fn getOrigin(commit: *Commit, path: []const u8) *Origin {
    var l: ?*Origin = null;
    var p = getSuspects(commit);
    while (p) |o| : ({
        l = o;
        p = o.next;
    }) {
        if (util.eql(o.path, path)) {
            if (l) |ll| {
                ll.next = o.next;
                o.next = getSuspects(commit);
                setSuspects(commit, o);
            }
            return incref(o).?;
        }
    }
    return makeOrigin(commit, path);
}

// scoreboard state
var sb_revs: *revision.RevInfo = undefined;
var sb_reverse = false;
var sb_show_root = false;
var sb_no_whole_file_rename = false;
var sb_xflags: xdiff.Flags = .{};
var sb_commits: cn.PrioQueue = .{ .compare = cn.compareByCommitDate };
var sb_ent: ?*Entry = null;
var sb_final_buf: []const u8 = "";
var sb_lineno: []usize = &.{};
var sb_num_lines: i32 = 0;
var sb_path: []const u8 = "";
var sb_num_read_blob: i32 = 0;
var sb_num_get_patch: i32 = 0;
var sb_num_commits: i32 = 0;

fn compareReverseCommitDate(a: *Commit, b: *Commit, d: ?*anyopaque) i32 {
    return -cn.compareByCommitDate(a, b, d);
}

fn fillOriginBlob(o: *Origin) []const u8 {
    if (o.file) |f| return f;
    sb_num_read_blob += 1;
    if (hash.isZero(o.blob_oid)) {
        o.file = "";
        return "";
    }
    if (blame_textconv) {
        if (diff_mod.textconvObject(o.path, o.mode, o.blob_oid)) |out| {
            o.file = out;
            return out;
        }
    }
    const obj = repo_mod.repo().odb().read(o.blob_oid) orelse
        util.die("unable to read {s}", .{hash.hex(o.blob_oid)});
    o.file = obj.data;
    return obj.data;
}

/// revs.diffopt.flags.allow_textconv (on by default; --no-textconv)
var blame_textconv = true;

// ---------------------------------------------------------------------------
// line fingerprints (multisets of lower-cased byte pairs) for --ignore-rev

const FpEnt = struct { key: u16, count: i32 };
const Fingerprint = []FpEnt;

fn getFingerprint(line: []const u8) Fingerprint {
    var keys: std.ArrayList(u16) = .empty;
    defer keys.deinit(gpa);
    var c0: u16 = 0;
    var p: usize = 0;
    while (p <= line.len) : (p += 1) {
        const c1: u16 = if (p == line.len or std.ascii.isWhitespace(line[p])) 0 else std.ascii.toLower(line[p]);
        const h = c0 | (c1 << 8);
        c0 = c1;
        if (h == 0) continue;
        keys.append(gpa, h) catch util.oom();
    }
    std.mem.sort(u16, keys.items, {}, std.sort.asc(u16));
    var out: std.ArrayList(FpEnt) = .empty;
    for (keys.items) |k| {
        if (out.items.len > 0 and out.items[out.items.len - 1].key == k) {
            out.items[out.items.len - 1].count += 1;
        } else out.append(gpa, .{ .key = k, .count = 1 }) catch util.oom();
    }
    return out.items;
}

fn fingerprintSimilarity(a: Fingerprint, b: Fingerprint) i32 {
    var i: usize = 0;
    var j: usize = 0;
    var n: i32 = 0;
    while (i < a.len and j < b.len) {
        if (a[i].key < b[j].key) {
            i += 1;
        } else if (a[i].key > b[j].key) {
            j += 1;
        } else {
            n += @min(a[i].count, b[j].count);
            i += 1;
            j += 1;
        }
    }
    return n;
}

/// Subtract the byte pairs in b from a (a removed pair keeps count 0).
fn fingerprintSubtract(a: Fingerprint, b: Fingerprint) void {
    var i: usize = 0;
    var j: usize = 0;
    while (i < a.len and j < b.len) {
        if (a[i].key < b[j].key) {
            i += 1;
        } else if (a[i].key > b[j].key) {
            j += 1;
        } else {
            if (a[i].count <= b[j].count) a[i].count = 0 else a[i].count -= b[j].count;
            i += 1;
            j += 1;
        }
    }
}

fn fillOriginFingerprints(o: *Origin) void {
    if (o.fingerprints != null) return;
    const file = fillOriginBlob(o);
    const starts = linerange.findLineStarts(file);
    const n = starts.len - 1;
    const fps = gpa.alloc(Fingerprint, n) catch util.oom();
    for (0..n) |i| fps[i] = getFingerprint(file[starts[i]..starts[i + 1]]);
    o.fingerprints = fps;
    o.num_lines = @intCast(n);
}

fn dropOriginFingerprints(o: *Origin) void {
    o.fingerprints = null;
    o.num_lines = 0;
}

const LineMap = struct { dst_start: i32, dst_len: i32, src_start: i32, src_len: i32 };

fn mapLineNumber(line: i32, m: LineMap) i32 {
    return @divTrunc(((line - m.src_start) * 2 + 1) * m.dst_len, m.src_len * 2) + m.dst_start;
}

const CERTAIN_NOTHING_MATCHES: i32 = -2;
const CERTAINTY_NOT_CALCULATED: i32 = -1;

/// State for fuzzy_find_matching_lines(); all per-B-line arrays are indexed
/// by (line_b - b0), fingerprints by absolute line numbers.
const Fuzzy = struct {
    pfp: []Fingerprint,
    tfp: []Fingerprint,
    sims: []i32,
    cert: []i32,
    second: []i32,
    result: []i32,
    b0: i32,
    maxa: i32,
    maxb: i32,
    map: LineMap,

    fn simIdx(z: *const Fuzzy, line_a: i32, row: i32, closest_a: i32) usize {
        return @intCast(line_a - closest_a + z.maxa + row * (z.maxa * 2 + 1));
    }

    fn findBest(z: *Fuzzy, start_a: i32, length_a: i32, start_b: i32, lb: i32) void {
        const row = start_b - z.b0 + lb;
        const r: usize = @intCast(row);
        if (z.cert[r] != CERTAINTY_NOT_CALCULATED) return;
        const closest = mapLineNumber(lb + start_b, z.map) - start_a;
        const ss = @max(closest - z.maxa, 0);
        const se = @min(closest + z.maxa + 1, length_a);
        var best: i32 = 0;
        var second: i32 = 0;
        var best_i: i32 = 0;
        var second_i: i32 = 0;
        var i = ss;
        while (i < se) : (i += 1) {
            const s = &z.sims[z.simIdx(i, row, closest)];
            if (s.* == -1) {
                const dist: i32 = @intCast(@abs(i - closest));
                s.* = fingerprintSimilarity(z.tfp[@intCast(start_b + lb)], z.pfp[@intCast(start_a + i)]) * (1000 - dist);
            }
            if (s.* > best) {
                second = best;
                second_i = best_i;
                best = s.*;
                best_i = i;
            } else if (s.* > second) {
                second = s.*;
                second_i = i;
            }
        }
        if (best == 0) {
            z.cert[r] = CERTAIN_NOTHING_MATCHES;
            z.result[r] = -1;
        } else {
            z.cert[r] = best * 2 - second;
            z.result[r] = start_a + best_i;
            z.second[r] = start_a + second_i;
        }
    }

    fn recurse(z: *Fuzzy, start_a: i32, start_b: i32, length_a: i32, length_b: i32) void {
        var mclb: i32 = -1;
        var mcc: i32 = -1;
        var i: i32 = 0;
        while (i < length_b) : (i += 1) {
            z.findBest(start_a, length_a, start_b, i);
            const c = z.cert[@intCast(start_b - z.b0 + i)];
            if (c > mcc) {
                mcc = c;
                mclb = i;
            }
        }
        if (mclb == -1) return;
        const mcla = z.result[@intCast(start_b - z.b0 + mclb)];
        fingerprintSubtract(z.pfp[@intCast(mcla)], z.tfp[@intCast(start_b + mclb)]);
        const inv_min = @max(mclb - z.maxb, 0);
        const inv_max = @min(mclb + z.maxb + 1, length_b);
        i = inv_min;
        while (i < inv_max) : (i += 1) {
            const closest = mapLineNumber(i + start_b, z.map) - start_a;
            if (@abs(mcla - start_a - closest) > z.maxa) continue;
            z.sims[z.simIdx(mcla - start_a, start_b - z.b0 + i, closest)] = -1;
        }
        i = mclb - 1;
        while (i >= inv_min) : (i -= 1) {
            const r: usize = @intCast(start_b - z.b0 + i);
            if (z.cert[r] >= 0 and (z.result[r] >= mcla or z.second[r] >= mcla))
                z.cert[r] = CERTAINTY_NOT_CALCULATED;
        }
        i = mclb + 1;
        while (i < inv_max) : (i += 1) {
            const r: usize = @intCast(start_b - z.b0 + i);
            if (z.cert[r] >= 0 and (z.result[r] <= mcla or z.second[r] <= mcla))
                z.cert[r] = CERTAINTY_NOT_CALCULATED;
        }
        if (mclb > 0) z.recurse(start_a, start_b, mcla + 1 - start_a, mclb);
        if (mclb + 1 < length_b) {
            const sa2 = mcla;
            const sb2 = start_b + mclb + 1;
            z.recurse(sa2, sb2, length_a + start_a - sa2, length_b + start_b - sb2);
        }
    }
};

fn fuzzyFindMatchingLines(parent: *Origin, target: *Origin, tlno: i32, parent_slno: i32, same: i32, parent_len: i32) ?[]i32 {
    const start_a = parent_slno;
    const length_a = parent_len;
    const start_b = tlno;
    const length_b = same - tlno;
    if (length_a <= 0) return null;
    var maxa: i32 = 10;
    if (maxa >= length_a) maxa = length_a - 1;
    const maxb = @divTrunc((2 * maxa + 1) * length_b - 1, length_a);
    const lb: usize = @intCast(length_b);
    var z = Fuzzy{
        .pfp = parent.fingerprints.?,
        .tfp = target.fingerprints.?,
        .sims = gpa.alloc(i32, lb * @as(usize, @intCast(maxa * 2 + 1))) catch util.oom(),
        .cert = gpa.alloc(i32, lb) catch util.oom(),
        .second = gpa.alloc(i32, lb) catch util.oom(),
        .result = gpa.alloc(i32, lb) catch util.oom(),
        .b0 = start_b,
        .maxa = maxa,
        .maxb = maxb,
        .map = .{ .dst_start = start_a, .dst_len = length_a, .src_start = start_b, .src_len = length_b },
    };
    defer {
        gpa.free(z.sims);
        gpa.free(z.cert);
        gpa.free(z.second);
    }
    @memset(z.sims, -1);
    @memset(z.cert, CERTAINTY_NOT_CALCULATED);
    @memset(z.second, -1);
    @memset(z.result, -1);
    z.recurse(start_a, start_b, length_a, length_b);
    return z.result;
}

const LineTracker = struct { is_parent: bool = false, s_lno: i32 = 0 };

fn scanParentRange(p_fps: []Fingerprint, t_fps: []Fingerprint, t_idx: i32, from: i32, nr_lines: i32) i32 {
    var best_val: i32 = 10; // FINGERPRINT_FILE_THRESHOLD
    var best_idx: i32 = -1;
    var p = from;
    while (p < from + nr_lines) : (p += 1) {
        const sim = fingerprintSimilarity(t_fps[@intCast(t_idx)], p_fps[@intCast(p)]);
        if (sim < best_val) continue;
        if (sim == best_val and best_idx != -1 and @abs(best_idx - t_idx) < @abs(p - t_idx)) continue;
        best_val = sim;
        best_idx = p;
    }
    return best_idx;
}

fn guessLineBlames(parent: *Origin, target: *Origin, tlno: i32, offset: i32, same: i32, parent_len: i32, line_blames: []LineTracker) void {
    const fuzzy = fuzzyFindMatchingLines(parent, target, tlno, tlno + offset, same, parent_len);
    defer if (fuzzy) |f| gpa.free(f);
    var i: i32 = 0;
    while (i < same - tlno) : (i += 1) {
        const target_idx = tlno + i;
        const ui: usize = @intCast(i);
        const best_idx = if (fuzzy != null and fuzzy.?[ui] >= 0)
            fuzzy.?[ui]
        else
            scanParentRange(parent.fingerprints.?, target.fingerprints.?, target_idx, 0, parent.num_lines);
        if (best_idx >= 0) {
            line_blames[ui] = .{ .is_parent = true, .s_lno = best_idx };
        } else {
            line_blames[ui] = .{ .is_parent = false, .s_lno = target_idx };
        }
    }
}

fn ignoreBlameEntry(e0: *Entry, parent: *Origin, diffp: *?*Entry, ignoredp: *?*Entry, line_blames: []const LineTracker) void {
    var e: ?*Entry = e0;
    var entry_len: i32 = 1;
    const nr_lines: usize = @intCast(e0.num_lines);
    for (0..nr_lines) |i| {
        var next: ?*Entry = null;
        const ee = e.?;
        if (i + 1 < nr_lines) {
            const a = line_blames[i];
            const b = line_blames[i + 1];
            if (a.is_parent == b.is_parent and a.s_lno + 1 == b.s_lno) {
                entry_len += 1;
                continue;
            }
            next = splitBlameAt(ee, entry_len, incref(ee.suspect));
        }
        if (line_blames[i].is_parent) {
            ee.ignored = true;
            decref(ee.suspect);
            ee.suspect = incref(parent);
            ee.s_lno = line_blames[i + 1 - @as(usize, @intCast(entry_len))].s_lno;
            ee.next = ignoredp.*;
            ignoredp.* = ee;
        } else {
            ee.unblamable = true;
            ee.next = diffp.*;
            diffp.* = ee;
        }
        e = next;
        entry_len = 1;
    }
}

// ---------------------------------------------------------------------------
// entry list helpers

fn blameMerge(list1: ?*Entry, list2: ?*Entry) ?*Entry {
    var p1 = list1 orelse return list2;
    var p2 = list2 orelse return list1;
    var head: ?*Entry = list1;
    var tail: *?*Entry = &head;
    if (p1.s_lno <= p2.s_lno) {
        while (true) {
            tail = &p1.next;
            p1 = tail.* orelse {
                tail.* = p2;
                return head;
            };
            if (!(p1.s_lno <= p2.s_lno)) break;
        }
    }
    while (true) {
        tail.* = p2;
        while (true) {
            tail = &p2.next;
            p2 = tail.* orelse {
                tail.* = p1;
                return head;
            };
            if (!(p1.s_lno > p2.s_lno)) break;
        }
        tail.* = p1;
        while (true) {
            tail = &p1.next;
            p1 = tail.* orelse {
                tail.* = p2;
                return head;
            };
            if (!(p1.s_lno <= p2.s_lno)) break;
        }
    }
}

fn sortEntries(head: *?*Entry, comptime lessFn: fn (void, *Entry, *Entry) bool) void {
    var arr: std.ArrayList(*Entry) = .empty;
    var e = head.*;
    while (e) |x| : (e = x.next) arr.append(gpa, x) catch util.oom();
    std.mem.sort(*Entry, arr.items, {}, lessFn);
    var tail: *?*Entry = head;
    for (arr.items) |x| {
        tail.* = x;
        tail = &x.next;
    }
    tail.* = null;
}

fn lessFinal(_: void, a: *Entry, b: *Entry) bool {
    return a.lno < b.lno;
}

fn lessSuspect(_: void, a: *Entry, b: *Entry) bool {
    const pa = @intFromPtr(a.suspect);
    const pb = @intFromPtr(b.suspect);
    if (pa != pb) return pa < pb;
    return a.s_lno < b.s_lno;
}

fn reverseBlame(head0: ?*Entry, tail0: ?*Entry) ?*Entry {
    var head = head0;
    var tail = tail0;
    while (head) |h| {
        const next = h.next;
        h.next = tail;
        tail = h;
        head = next;
    }
    return tail;
}

fn splitBlameAt(e: *Entry, len: i32, new_suspect: ?*Origin) *Entry {
    const n = gpa.create(Entry) catch util.oom();
    n.* = .{
        .suspect = new_suspect,
        .ignored = e.ignored,
        .unblamable = e.unblamable,
        .lno = e.lno + len,
        .s_lno = e.s_lno + len,
        .num_lines = e.num_lines - len,
    };
    e.num_lines = len;
    e.score = 0;
    return n;
}

fn queueBlames(porigin: *Origin, sorted: ?*Entry) void {
    if (porigin.suspects != null) {
        porigin.suspects = blameMerge(porigin.suspects, sorted);
    } else {
        var o = getSuspects(porigin.commit);
        while (o) |x| : (o = x.next) {
            if (x.suspects != null) {
                porigin.suspects = sorted;
                return;
            }
        }
        porigin.suspects = sorted;
        sb_commits.put(porigin.commit);
    }
}

fn blameCoalesce() void {
    var ent = sb_ent;
    while (ent) |e| {
        const next = e.next orelse break;
        if (e.suspect == next.suspect and
            e.s_lno + e.num_lines == next.s_lno and
            e.lno + e.num_lines == next.lno and
            e.ignored == next.ignored and
            e.unblamable == next.unblamable)
        {
            e.num_lines += next.num_lines;
            e.next = next.next;
            decref(next.suspect);
            e.score = 0;
            continue;
        }
        ent = next;
    }
}

// ---------------------------------------------------------------------------
// finding origins in parents

const ChildFile = struct { oid: Oid, mode: u32 };

/// The (blob, mode) of origin.path on the "child" side (commit tree or the
/// fake index for the working tree commit).
fn fillBlobOidAndMode(o: *Origin) bool {
    if (!hash.isZero(o.blob_oid)) return true;
    if (!cn.parse(o.commit)) return false;
    const te = objects.treeLookup(o.commit.tree, o.path) orelse return false;
    if (cn.objType(te.oid) != .blob) return false;
    o.blob_oid = te.oid;
    o.mode = te.mode;
    return true;
}

fn findOrigin(parent: *Commit, origin: *Origin) ?*Origin {
    var it = getSuspects(parent);
    while (it) |p| : (it = p.next) {
        if (util.eql(p.path, origin.path)) return incref(p);
    }
    const pe = objects.treeLookup(parent.tree, origin.path) orelse return null;
    if (pe.mode == 0o040000) return null; // added (directory in parent)
    if (hash.eql(pe.oid, origin.blob_oid) and pe.mode == origin.mode) {
        const porigin = getOrigin(parent, origin.path);
        porigin.blob_oid = origin.blob_oid;
        porigin.mode = origin.mode;
        return porigin;
    }
    if (pe.mode & S_IFMT != origin.mode & S_IFMT) return null; // type change
    const porigin = getOrigin(parent, origin.path);
    porigin.blob_oid = pe.oid;
    porigin.mode = pe.mode;
    return porigin;
}

// --- rename detection (diffcore-rename / diffcore-delta subset) ---

const MAX_SCORE: u64 = 60000;
const MIN_SCORE: u64 = 30000;
const HASHBASE: u32 = 107927;

fn hashChars(buf: []const u8) std.AutoHashMap(u32, u32) {
    var m = std.AutoHashMap(u32, u32).init(gpa);
    const check = buf[0..@min(buf.len, 8000)];
    const is_text = std.mem.indexOfScalar(u8, check, 0) == null;
    var n: u32 = 0;
    var accum1: u32 = 0;
    var accum2: u32 = 0;
    var i: usize = 0;
    while (i < buf.len) {
        const c: u32 = buf[i];
        i += 1;
        const old_1 = accum1;
        if (is_text and c == '\r' and i < buf.len and buf[i] == '\n') continue;
        accum1 = (accum1 << 7) ^ (accum2 >> 25);
        accum2 = (accum2 << 7) ^ (old_1 >> 25);
        accum1 +%= c;
        n += 1;
        if (n < 64 and c != '\n') continue;
        const hv = (accum1 +% accum2 *% 0x61) % HASHBASE;
        const gop = m.getOrPut(hv) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = 0;
        gop.value_ptr.* += n;
        n = 0;
        accum1 = 0;
        accum2 = 0;
    }
    if (n > 0) {
        const hv = (accum1 +% accum2 *% 0x61) % HASHBASE;
        const gop = m.getOrPut(hv) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = 0;
        gop.value_ptr.* += n;
    }
    return m;
}

fn estimateSimilarity(src: []const u8, src_mode: u32, dst: []const u8, dst_mode: u32, minimum_score: u64) u64 {
    if (src_mode & S_IFMT != S_IFREG or dst_mode & S_IFMT != S_IFREG) return 0;
    const max_size: u64 = @max(src.len, dst.len);
    const base_size: u64 = @min(src.len, dst.len);
    const delta_size = max_size - base_size;
    if (max_size * (MAX_SCORE - minimum_score) < delta_size * MAX_SCORE) return 0;
    var sm = hashChars(src);
    defer sm.deinit();
    var dm = hashChars(dst);
    defer dm.deinit();
    var sc: u64 = 0;
    var itr = sm.iterator();
    while (itr.next()) |kv| {
        const dc = dm.get(kv.key_ptr.*) orelse 0;
        sc += @min(kv.value_ptr.*, dc);
    }
    if (dst.len == 0) return 0;
    return sc * MAX_SCORE / max_size;
}

fn basenameOf(p: []const u8) []const u8 {
    if (std.mem.lastIndexOfScalar(u8, p, '/')) |i| return p[i + 1 ..];
    return p;
}

fn basenameSame(a: []const u8, b: []const u8) bool {
    return util.eql(basenameOf(a), basenameOf(b));
}

var fake_index: ?*index_mod.Index = null;
var fake_entry_path: []const u8 = "";

/// List of (path -> blob) on the child side of the diff for `origin`.
fn childFiles(origin: *Origin) std.StringHashMap(ChildFile) {
    var m = std.StringHashMap(ChildFile).init(gpa);
    if (hash.isZero(origin.commit.obj.oid)) {
        if (fake_index) |idx| {
            for (@import("../sparse_index.zig").virtualEntries(idx, null)) |e| m.put(e.path, .{ .oid = e.oid, .mode = e.mode }) catch util.oom();
        }
        m.put(origin.path, .{ .oid = origin.blob_oid, .mode = origin.mode }) catch util.oom();
    } else {
        var l: std.ArrayList(objects.FlatEntry) = .empty;
        objects.flattenTree(origin.commit.tree, "", &l);
        for (l.items) |e| m.put(e.path, .{ .oid = e.oid, .mode = e.mode }) catch util.oom();
    }
    return m;
}

fn readBlobData(oid: Oid) []const u8 {
    const obj = repo_mod.repo().odb().read(oid) orelse return "";
    return obj.data;
}

fn findRename(parent: *Commit, origin: *Origin) ?*Origin {
    // the destination must be an addition
    if (objects.treeLookup(parent.tree, origin.path)) |pe| {
        if (pe.mode != 0o040000) return null;
    }
    var child = childFiles(origin);
    defer child.deinit();
    var plist: std.ArrayList(objects.FlatEntry) = .empty;
    objects.flattenTree(parent.tree, "", &plist);
    // sources: deleted files
    var srcs: std.ArrayList(objects.FlatEntry) = .empty;
    for (plist.items) |e| {
        if (child.get(e.path) == null) srcs.append(gpa, e) catch util.oom();
    }
    if (srcs.items.len == 0) return null;

    var chosen: ?objects.FlatEntry = null;
    // exact renames
    {
        var best_score: i32 = -1;
        for (srcs.items) |s| {
            if (!hash.eql(s.oid, origin.blob_oid)) continue;
            if (s.mode & S_IFMT != S_IFREG or origin.mode & S_IFMT != S_IFREG) {
                if (s.mode != origin.mode) continue;
            }
            const score: i32 = 1 + @as(i32, @intFromBool(basenameSame(s.path, origin.path)));
            if (score > best_score) {
                chosen = s;
                best_score = score;
                if (score == 2) break;
            }
        }
    }
    if (chosen == null) {
        const dst = fillOriginBlob(origin);
        // basename-guided matching
        const base = basenameOf(origin.path);
        var nbase: usize = 0;
        var bsrc: ?objects.FlatEntry = null;
        for (srcs.items) |s| {
            if (util.eql(basenameOf(s.path), base)) {
                nbase += 1;
                bsrc = s;
            }
        }
        if (nbase == 1) {
            const min_basename_score = MIN_SCORE + (MAX_SCORE - MIN_SCORE) / 2;
            const s = bsrc.?;
            const score = estimateSimilarity(readBlobData(s.oid), s.mode, dst, origin.mode, min_basename_score);
            if (score >= min_basename_score) chosen = s;
        }
        if (chosen == null) {
            var best: u64 = 0;
            var best_name = false;
            for (srcs.items) |s| {
                if (s.mode & S_IFMT != S_IFREG) continue;
                const score = estimateSimilarity(readBlobData(s.oid), s.mode, dst, origin.mode, MIN_SCORE);
                if (score < MIN_SCORE) continue;
                const ns = basenameSame(s.path, origin.path);
                if (chosen == null or score > best or (score == best and ns and !best_name)) {
                    chosen = s;
                    best = score;
                    best_name = ns;
                }
            }
        }
    }
    const c = chosen orelse return null;
    const porigin = getOrigin(parent, c.path);
    porigin.blob_oid = c.oid;
    porigin.mode = c.mode;
    return porigin;
}

// ---------------------------------------------------------------------------
// passing blame

fn blameChunk(dstq: **?*Entry, srcq: **?*Entry, tlno: i32, offset: i32, same: i32, parent_len: i32, parent: *Origin, target: *Origin, ignore_diffs: bool) void {
    var e = srcq.*.*;
    var samep: ?*Entry = null;
    var diffp: ?*Entry = null;
    var ignoredp: ?*Entry = null;
    while (e) |ee| {
        if (ee.s_lno >= tlno) break;
        const next = ee.next;
        if (ee.s_lno + ee.num_lines > tlno) {
            const n = splitBlameAt(ee, tlno - ee.s_lno, ee.suspect);
            n.next = diffp;
            diffp = n;
        } else decref(ee.suspect);
        ee.suspect = incref(parent);
        ee.s_lno += offset;
        ee.next = samep;
        samep = ee;
        e = next;
    }
    if (samep) |sp| {
        dstq.*.* = reverseBlame(sp, dstq.*.*);
        dstq.* = &sp.next;
    }
    e = reverseBlame(diffp, e);
    samep = null;
    diffp = null;
    var line_blames: []LineTracker = &.{};
    defer if (line_blames.len > 0) gpa.free(line_blames);
    if (ignore_diffs and same - tlno > 0) {
        line_blames = gpa.alloc(LineTracker, @intCast(same - tlno)) catch util.oom();
        @memset(line_blames, .{});
        guessLineBlames(parent, target, tlno, offset, same, parent_len, line_blames);
    }
    while (e) |ee| {
        if (ee.s_lno >= same) break;
        const next = ee.next;
        if (ee.s_lno + ee.num_lines > same) {
            const n = splitBlameAt(ee, same - ee.s_lno, incref(ee.suspect));
            n.next = samep;
            samep = n;
        }
        if (ignore_diffs) {
            ignoreBlameEntry(ee, parent, &diffp, &ignoredp, line_blames[@intCast(ee.s_lno - tlno)..]);
        } else {
            ee.next = diffp;
            diffp = ee;
        }
        e = next;
    }
    if (ignoredp) |ip| {
        dstq.*.* = reverseBlame(ip, dstq.*.*);
        dstq.* = &ip.next;
    }
    srcq.*.* = reverseBlame(diffp, reverseBlame(samep, e));
    if (diffp) |dp| srcq.* = &dp.next;
}

const ChunkCtx = struct {
    parent: *Origin,
    target: *Origin,
    offset: i32 = 0,
    ignore_diffs: bool = false,
    dstq: *?*Entry,
    srcq: *?*Entry,
};

fn blameChunkCb(ctx: ?*anyopaque, start_a: isize, count_a: isize, start_b: isize, count_b: isize) void {
    const d: *ChunkCtx = @ptrCast(@alignCast(ctx.?));
    const sa: i32 = @intCast(start_a);
    const ca: i32 = @intCast(count_a);
    const sbb: i32 = @intCast(start_b);
    const cb: i32 = @intCast(count_b);
    if (sa - sbb != d.offset) util.die("internal error in blame::blame_chunk_cb", .{});
    blameChunk(&d.dstq, &d.srcq, sbb, sa - sbb, sbb + cb, ca, d.parent, d.target, d.ignore_diffs);
    d.offset = sa + ca - (sbb + cb);
}

fn diffHunks(a: []const u8, b: []const u8, ctx: ?*anyopaque, func: *const fn (ctx: ?*anyopaque, start_a: isize, count_a: isize, start_b: isize, count_b: isize) void) bool {
    const t = xdiff.trimCommonTail(a, b);
    var df = xdiff.diff(t.a, t.b, sb_xflags) catch return false;
    defer df.deinit();
    xdiff.forEachHunkRange(&df, .{ .context = 0 }, ctx, func);
    return true;
}

fn passBlameToParent(target: *Origin, parent: *Origin, ignore_diffs: bool) void {
    if (target.suspects == null) return;
    var newdest: ?*Entry = null;
    var d = ChunkCtx{ .parent = parent, .target = target, .ignore_diffs = ignore_diffs, .dstq = &newdest, .srcq = &target.suspects };
    const fp = fillOriginBlob(parent);
    const fo = fillOriginBlob(target);
    if (ignore_diffs) {
        fillOriginFingerprints(parent);
        fillOriginFingerprints(target);
    }
    sb_num_get_patch += 1;
    if (!diffHunks(fp, fo, &d, blameChunkCb))
        util.die("unable to generate diff ({s} -> {s})", .{ hash.hex(parent.commit.obj.oid), hash.hex(target.commit.obj.oid) });
    blameChunk(&d.dstq, &d.srcq, INT_MAX, d.offset, INT_MAX, 0, parent, target, false);
    d.dstq.* = null;
    if (ignore_diffs) sortEntries(&newdest, lessSuspect);
    queueBlames(parent, newdest);
}

// --- -M / -C: line movement and copy detection ---

const PICKAXE_BLAME_MOVE: u32 = 0o1;
const PICKAXE_BLAME_COPY: u32 = 0o2;
const PICKAXE_BLAME_COPY_HARDER: u32 = 0o4;
const PICKAXE_BLAME_COPY_HARDEST: u32 = 0o10;
const BLAME_DEFAULT_MOVE_SCORE: u32 = 20;
const BLAME_DEFAULT_COPY_SCORE: u32 = 40;

var sb_move_score: u32 = BLAME_DEFAULT_MOVE_SCORE;
var sb_copy_score: u32 = BLAME_DEFAULT_COPY_SCORE;
var sb_ignore_list: hash.OidSet = .empty;

const Split = [3]Entry;

fn addBlameEntry(queue: **?*Entry, src: *const Entry) void {
    const e = gpa.create(Entry) catch util.oom();
    e.* = src.*;
    _ = incref(e.suspect);
    e.next = queue.*.*;
    queue.*.* = e;
    queue.* = &e.next;
}

fn dupEntry(queue: **?*Entry, dst: *Entry, src: *const Entry) void {
    _ = incref(src.suspect);
    decref(dst.suspect);
    dst.* = src.*;
    dst.next = queue.*.*;
    queue.*.* = dst;
    queue.* = &dst.next;
}

fn splitOverlap(split: *Split, e: *const Entry, tlno: i32, plno: i32, same: i32, parent: *Origin) void {
    split.* = .{ .{}, .{}, .{} };
    for (split) |*s| {
        s.ignored = e.ignored;
        s.unblamable = e.unblamable;
    }
    if (e.s_lno < tlno) {
        split[0].suspect = incref(e.suspect);
        split[0].lno = e.lno;
        split[0].s_lno = e.s_lno;
        split[0].num_lines = tlno - e.s_lno;
        split[1].lno = e.lno + tlno - e.s_lno;
        split[1].s_lno = plno;
    } else {
        split[1].lno = e.lno;
        split[1].s_lno = plno + (e.s_lno - tlno);
    }
    var chunk_end_lno: i32 = undefined;
    if (same < e.s_lno + e.num_lines) {
        split[2].suspect = incref(e.suspect);
        split[2].lno = e.lno + (same - e.s_lno);
        split[2].s_lno = e.s_lno + (same - e.s_lno);
        split[2].num_lines = e.s_lno + e.num_lines - same;
        chunk_end_lno = split[2].lno;
    } else chunk_end_lno = e.lno + e.num_lines;
    split[1].num_lines = chunk_end_lno - split[1].lno;
    if (split[1].num_lines < 1) return;
    split[1].suspect = incref(parent);
}

fn splitBlame(blamed: **?*Entry, unblamed: **?*Entry, split: *const Split, e: *Entry) void {
    if (split[0].suspect != null and split[2].suspect != null) {
        dupEntry(unblamed, e, &split[0]);
        addBlameEntry(unblamed, &split[2]);
        addBlameEntry(blamed, &split[1]);
    } else if (split[0].suspect == null and split[2].suspect == null) {
        dupEntry(blamed, e, &split[1]);
    } else if (split[0].suspect != null) {
        dupEntry(unblamed, e, &split[0]);
        addBlameEntry(blamed, &split[1]);
    } else {
        dupEntry(blamed, e, &split[1]);
        addBlameEntry(unblamed, &split[2]);
    }
}

fn decrefSplit(split: *const Split) void {
    for (split) |s| decref(s.suspect);
}

fn copySplitIfBetter(best: *Split, potential: *Split) void {
    if (potential[1].suspect == null) return;
    if (best[1].suspect != null) {
        if (entryScore(&potential[1]) < entryScore(&best[1])) return;
    }
    for (potential) |s| _ = incref(s.suspect);
    decrefSplit(best);
    best.* = potential.*;
}

fn handleSplit(ent: *Entry, tlno: i32, plno: i32, same: i32, parent: *Origin, split: *Split) void {
    if (ent.num_lines <= tlno) return;
    if (tlno < same) {
        var potential: Split = undefined;
        splitOverlap(&potential, ent, tlno + ent.s_lno, plno, same + ent.s_lno, parent);
        copySplitIfBetter(split, &potential);
        decrefSplit(&potential);
    }
}

const SplitCtx = struct {
    ent: *Entry,
    parent: *Origin,
    split: *Split,
    plno: i32 = 0,
    tlno: i32 = 0,
};

fn handleSplitCb(ctx: ?*anyopaque, start_a: isize, count_a: isize, start_b: isize, count_b: isize) void {
    const d: *SplitCtx = @ptrCast(@alignCast(ctx.?));
    handleSplit(d.ent, d.tlno, d.plno, @intCast(start_b), d.parent, d.split);
    d.plno = @intCast(start_a + count_a);
    d.tlno = @intCast(start_b + count_b);
}

fn findCopyInBlob(ent: *Entry, parent: *Origin, split: *Split, file_p: []const u8) void {
    const cp = nthLine(ent.lno);
    const ep = nthLine(ent.lno + ent.num_lines);
    split.* = .{ .{}, .{}, .{} };
    var d = SplitCtx{ .ent = ent, .parent = parent, .split = split };
    if (!diffHunks(file_p, sb_final_buf[cp..ep], &d, handleSplitCb))
        util.die("unable to generate diff ({s})", .{hash.hex(parent.commit.obj.oid)});
    handleSplit(ent, d.tlno, d.plno, ent.num_lines, parent, split);
}

/// Move entries of *source whose score is <= score_min to the front of *small;
/// returns the link pointing to the old head of the small list.
fn filterSmall(small0: *?*Entry, source0: *?*Entry, score_min: u32) *?*Entry {
    var small = small0;
    var source = source0;
    var p = source.*;
    const oldsmall = small.*;
    while (p) |e| {
        if (entryScore(e) <= score_min) {
            small.* = e;
            small = &e.next;
            p = small.*;
        } else {
            source.* = e;
            source = &e.next;
            p = source.*;
        }
    }
    small.* = oldsmall;
    source.* = null;
    return small;
}

fn findMoveInParent(blamed: **?*Entry, toosmall0: *?*Entry, target: *Origin, parent: *Origin) void {
    var toosmall = toosmall0;
    var unblamed = target.suspects;
    if (unblamed == null) return;
    var leftover: ?*Entry = null;
    const file_p = fillOriginBlob(parent);
    while (true) {
        var unblamedtail: *?*Entry = &unblamed;
        var e = unblamed;
        while (e) |ee| {
            const next = ee.next;
            var split: Split = undefined;
            findCopyInBlob(ee, parent, &split, file_p);
            if (split[1].suspect != null and sb_move_score < entryScore(&split[1])) {
                splitBlame(blamed, &unblamedtail, &split, ee);
            } else {
                ee.next = leftover;
                leftover = ee;
            }
            decrefSplit(&split);
            e = next;
        }
        unblamedtail.* = null;
        toosmall = filterSmall(toosmall, &unblamed, sb_move_score);
        if (unblamed == null) break;
    }
    target.suspects = reverseBlame(leftover, null);
}

const BlameList = struct { ent: *Entry, split: Split };

fn findCopyInParent(blamed: **?*Entry, toosmall0: *?*Entry, target: *Origin, parent: *Commit, porigin: ?*Origin, opt: u32) void {
    var toosmall = toosmall0;
    var unblamed = target.suspects;
    if (unblamed == null) return;
    var leftover: ?*Entry = null;
    const harder = (opt & PICKAXE_BLAME_COPY_HARDEST != 0) or
        ((opt & PICKAXE_BLAME_COPY_HARDER != 0) and (porigin == null or !util.eql(target.path, porigin.?.path)));

    // the parent side of the tree diff: files changed (or, when finding
    // copies harder, all files) in the parent
    var cands: std.ArrayList(objects.FlatEntry) = .empty;
    {
        var plist: std.ArrayList(objects.FlatEntry) = .empty;
        if (cn.parse(parent)) objects.flattenTree(parent.tree, "", &plist);
        var child = childFiles(target);
        defer child.deinit();
        for (plist.items) |pe| {
            if (pe.mode & S_IFMT == 0o160000) continue;
            if (porigin) |po_| {
                if (util.eql(pe.path, po_.path)) continue;
            }
            if (!harder) {
                if (child.get(pe.path)) |c| {
                    if (hash.eql(c.oid, pe.oid) and c.mode == pe.mode) continue;
                }
            }
            cands.append(gpa, pe) catch util.oom();
        }
    }

    while (true) {
        var unblamedtail: *?*Entry = &unblamed;
        var bl: std.ArrayList(BlameList) = .empty;
        defer bl.deinit(gpa);
        var e = unblamed;
        while (e) |ee| : (e = ee.next) bl.append(gpa, .{ .ent = ee, .split = .{ .{}, .{}, .{} } }) catch util.oom();

        for (cands.items) |c| {
            const norigin = getOrigin(parent, c.path);
            norigin.blob_oid = c.oid;
            norigin.mode = c.mode;
            const file_p = fillOriginBlob(norigin);
            for (bl.items) |*b| {
                var potential: Split = undefined;
                findCopyInBlob(b.ent, norigin, &potential, file_p);
                copySplitIfBetter(&b.split, &potential);
                decrefSplit(&potential);
            }
            decref(norigin);
        }
        for (bl.items) |*b| {
            if (b.split[1].suspect != null and sb_copy_score < entryScore(&b.split[1])) {
                splitBlame(blamed, &unblamedtail, &b.split, b.ent);
            } else {
                b.ent.next = leftover;
                leftover = b.ent;
            }
            decrefSplit(&b.split);
        }
        unblamedtail.* = null;
        toosmall = filterSmall(toosmall, &unblamed, sb_copy_score);
        if (unblamed == null) break;
    }
    target.suspects = reverseBlame(leftover, null);
}

fn passWholeBlame(origin: *Origin, porigin: *Origin) void {
    if (porigin.file == null and origin.file != null) {
        porigin.file = origin.file;
        origin.file = null;
    }
    const suspects = origin.suspects;
    origin.suspects = null;
    var e = suspects;
    while (e) |x| : (e = x.next) {
        _ = incref(porigin);
        decref(x.suspect);
        x.suspect = porigin;
    }
    queueBlames(porigin, suspects);
}

fn firstScapegoat(commit: *Commit) ?*cn.CommitList {
    if (!sb_reverse) {
        if (sb_revs.first_parent_only) {
            if (commit.parents) |p| p.next = null;
        }
        return commit.parents;
    }
    return revision.getChildren(sb_revs, commit);
}

fn distributeBlame(blamed0: ?*Entry) void {
    var blamed = blamed0;
    sortEntries(&blamed, lessSuspect);
    while (blamed) |first| {
        const porigin = first.suspect.?;
        var suspects: ?*Entry = null;
        while (blamed) |b| {
            if (b.suspect != porigin) break;
            const next = b.next;
            b.next = suspects;
            suspects = b;
            blamed = next;
        }
        queueBlames(porigin, reverseBlame(suspects, null));
    }
}

fn passBlame(origin: *Origin, opt: u32) void {
    var toosmall: ?*Entry = null;
    var blames: ?*Entry = null;
    var blametail: *?*Entry = &blames;
    const num_sg = cn.listCount(firstScapegoat(origin.commit));
    const sg_origin = gpa.alloc(?*Origin, num_sg) catch util.oom();
    defer gpa.free(sg_origin);
    @memset(sg_origin, null);
    if (num_sg != 0) passBlameInner(origin, opt, sg_origin, &blametail, &toosmall);
    // finish:
    blametail.* = null;
    distributeBlame(blames);
    if (toosmall) |_| {
        var tail: *?*Entry = &toosmall;
        while (tail.*) |t| tail = &t.next;
        tail.* = origin.suspects;
        origin.suspects = toosmall;
    }
    for (sg_origin) |o| {
        if (o) |x| {
            if (x.suspects == null) dropOriginFingerprints(x);
            decref(x);
        }
    }
    dropOriginFingerprints(origin);
}

fn passBlameInner(origin: *Origin, opt: u32, sg_origin: []?*Origin, blametail: **?*Entry, toosmall: *?*Entry) void {
    const commit = origin.commit;
    const num_sg = sg_origin.len;
    const passes: usize = if (sb_no_whole_file_rename) 1 else 2;
    for (0..passes) |pass| {
        var i: usize = 0;
        var sg = firstScapegoat(commit);
        while (sg) |s| : ({
            sg = s.next;
            i += 1;
        }) {
            if (i >= num_sg) break;
            const p = s.item;
            if (sg_origin[i] != null) continue;
            if (!cn.parse(p)) continue;
            const porigin = (if (pass == 0) findOrigin(p, origin) else findRename(p, origin)) orelse continue;
            if (hash.eql(porigin.blob_oid, origin.blob_oid)) {
                passWholeBlame(origin, porigin);
                decref(porigin);
                return;
            }
            var same = false;
            for (0..i) |j| {
                if (sg_origin[j]) |o| {
                    if (hash.eql(o.blob_oid, porigin.blob_oid)) {
                        same = true;
                        break;
                    }
                }
            }
            if (!same) sg_origin[i] = porigin else decref(porigin);
        }
    }
    sb_num_commits += 1;
    for (sg_origin) |o| {
        const porigin = o orelse continue;
        if (origin.previous == null) {
            _ = incref(porigin);
            origin.previous = porigin;
        }
        passBlameToParent(origin, porigin, false);
        if (origin.suspects == null) return;
    }

    // pass remaining suspects for ignored commits to their parents
    if (sb_ignore_list.contains(commit.obj.oid)) {
        for (sg_origin) |o| {
            const porigin = o orelse continue;
            passBlameToParent(origin, porigin, true);
            // refresh the fingerprints if the parent is used again
            dropOriginFingerprints(porigin);
            if (origin.suspects == null) return;
        }
    }

    // optionally find moves in parents' files
    if (opt & PICKAXE_BLAME_MOVE != 0) {
        _ = filterSmall(toosmall, &origin.suspects, sb_move_score);
        if (origin.suspects != null) {
            for (sg_origin) |o| {
                const porigin = o orelse continue;
                findMoveInParent(blametail, toosmall, origin, porigin);
                if (origin.suspects == null) break;
            }
        }
    }

    // optionally find copies from parents' files
    if (opt & PICKAXE_BLAME_COPY != 0) {
        if (sb_copy_score > sb_move_score) {
            _ = filterSmall(toosmall, &origin.suspects, sb_copy_score);
        } else if (sb_copy_score < sb_move_score) {
            origin.suspects = blameMerge(origin.suspects, toosmall.*);
            toosmall.* = null;
            _ = filterSmall(toosmall, &origin.suspects, sb_copy_score);
        }
        if (origin.suspects == null) return;
        var i: usize = 0;
        var sg = firstScapegoat(commit);
        while (sg) |s| : ({
            sg = s.next;
            i += 1;
        }) {
            if (i >= num_sg) break;
            findCopyInParent(blametail, toosmall, origin, s.item, sg_origin[i], opt);
            if (origin.suspects == null) return;
        }
    }
}

fn assignBlame() void {
    var commit_opt = sb_commits.get();
    while (commit_opt) |commit| {
        var suspect = getSuspects(commit);
        while (suspect) |s| {
            if (s.suspects != null) break;
            suspect = s.next;
        }
        const sus = suspect orelse {
            commit_opt = sb_commits.get();
            continue;
        };
        _ = incref(sus);
        _ = cn.parse(commit);
        if (sb_reverse or (commit.obj.flags & cn.UNINTERESTING == 0 and
            !(sb_revs.max_age != revision.UNSET_TIME and commit.date < sb_revs.max_age)))
        {
            passBlame(sus, opt_pickaxe);
        } else {
            commit.obj.flags |= cn.UNINTERESTING;
            if (commit.obj.parsed) revision.markParentsUninteresting(sb_revs, commit);
        }
        if (commit.parents == null and !sb_show_root) commit.obj.flags |= cn.UNINTERESTING;

        if (sus.suspects) |first| {
            sus.guilty = true;
            var ent = first;
            while (true) {
                const next = ent.next;
                if (incremental) foundGuiltyEntry(ent);
                if (next) |n| {
                    ent = n;
                    continue;
                }
                ent.next = sb_ent;
                sb_ent = sus.suspects;
                sus.suspects = null;
                break;
            }
        }
        decref(sus);
    }
}

// ---------------------------------------------------------------------------
// setup

fn derefPending(e: revision.PendingEntry) ?*Commit {
    const o = cn.derefTag(e.item) orelse return null;
    if (o.typ != .commit) return null;
    return Commit.fromObj(o);
}

fn findSingleFinal(name_p: ?*?[]const u8) ?*Commit {
    var found: ?*Commit = null;
    var name: ?[]const u8 = null;
    for (sb_revs.pending.items) |e| {
        if (e.item.flags & cn.UNINTERESTING != 0) continue;
        const c = derefPending(e) orelse util.die("Non commit {s}?", .{e.name});
        if (found != null) util.die("More than one commit to dig from {s} and {s}?", .{ e.name, name.? });
        found = c;
        name = e.name;
    }
    if (name_p) |np| np.* = name;
    return found;
}

fn dwimReverseInitial(name_p: *?[]const u8) ?*Commit {
    if (sb_revs.pending.items.len != 1) return null;
    const e = sb_revs.pending.items[0];
    const o = cn.derefTag(e.item) orelse return null;
    if (o.typ != .commit) return null;
    const head = refs.readOid("HEAD") orelse return null;
    const head_commit = cn.lookupCommitReference(head) orelse return null;
    o.flags |= cn.UNINTERESTING;
    sb_revs.addPendingObject(&head_commit.obj, "HEAD");
    name_p.* = e.name;
    return Commit.fromObj(o);
}

fn findSingleInitial(name_p: *?[]const u8) ?*Commit {
    var found: ?*Commit = null;
    var name: ?[]const u8 = null;
    for (sb_revs.pending.items) |e| {
        if (e.item.flags & cn.UNINTERESTING == 0) continue;
        const c = derefPending(e) orelse util.die("Non commit {s}?", .{e.name});
        if (found != null) util.die("More than one commit to dig up from, {s} and {s}?", .{ e.name, name.? });
        found = c;
        name = e.name;
    }
    if (name == null) found = dwimReverseInitial(&name);
    if (name == null) util.die("No commit to dig up from?", .{});
    name_p.* = name;
    return found;
}

fn appendParent(tail: *?*cn.CommitList, oid: Oid) *?*cn.CommitList {
    const parent = cn.lookupCommitReference(oid) orelse util.die("no such commit {s}", .{hash.hex(oid)});
    return cn.listAppend(parent, tail);
}

fn fakeWorkingTreeCommit(path: []const u8, contents_from: ?[]const u8, oid: Oid) *Commit {
    const r = repo_mod.repo();
    const idx = index_mod.readFrom(r.indexPath());
    fake_index = idx;
    const now = os.now();
    const commit = cn.lookupCommit(hash.zero).?;
    commit.obj.parsed = true;
    commit.date = @intCast(now);
    commit.parents = null;
    var tail = appendParent(&commit.parents, oid);
    // MERGE_HEAD
    const mh_path = r.gitPath("MERGE_HEAD");
    if (os.readFile(mh_path)) |data| {
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line| {
            if (line.len == 0 and it.index == null) break;
            const o = (if (line.len >= 40) hash.fromHex(line[0..40]) else null) orelse
                util.die("unknown line in '{s}': {s}\n", .{ mh_path, line });
            tail = appendParent(tail, o);
        }
    }
    // verify_working_tree_path
    verify: {
        var p = commit.parents;
        while (p) |x| : (p = x.next) {
            if (!cn.parse(x.item)) continue;
            if (objects.treeLookup(x.item.tree, path)) |te| {
                if (cn.objType(te.oid) == .blob) break :verify;
            }
        }
        const pos = idx.firstPos(path);
        if (pos < idx.entries.items.len and util.eql(idx.entries.items[pos].path, path)) break :verify;
        util.die("no such path '{s}' in HEAD", .{path});
    }

    const origin = makeOrigin(commit, path);
    const ident = if (contents_from != null)
        util.fmt("External file (--contents) <external.file> {s}", .{date.datestamp()})
    else
        util.fmt("Not Committed Yet <not.committed.yet> {s}", .{date.datestamp()});
    var msg: Buf = .empty;
    util.bufAppend(&msg, "tree 0000000000000000000000000000000000000000\n");
    var p = commit.parents;
    while (p) |x| : (p = x.next) util.bufPrint(&msg, "parent {s}\n", .{hash.hex(x.item.obj.oid)});
    const from = if (contents_from) |cf| (if (util.eql(cf, "-")) "standard input" else cf) else path;
    util.bufPrint(&msg, "author {s}\ncommitter {s}\n\nVersion of {s} from {s}\n", .{ ident, ident, path, from });
    commit.buffer = msg.items;

    var mode: u32 = 0;
    var buf: []const u8 = "";
    if (contents_from == null or !util.eql(contents_from.?, "-")) {
        var read_from: []const u8 = undefined;
        var st: os.Stat = undefined;
        if (contents_from) |cf| {
            st = os.statPath(cf) orelse util.dieErrno("Cannot stat '{s}'", .{cf});
            read_from = cf;
        } else {
            st = os.lstatPath(path) orelse util.dieErrno("Cannot lstat '{s}'", .{path});
            read_from = path;
        }
        mode = index_mod.canonMode(st.mode);
        if (st.isReg()) {
            buf = (if (blame_textconv) diff_mod.textconvObject(read_from, mode, null) else null) orelse
                (os.readFile(read_from) orelse util.dieErrno("cannot open or read '{s}'", .{read_from}));
        } else if (st.isLnk()) {
            buf = os.readLink(read_from) orelse util.dieErrno("cannot readlink '{s}'", .{read_from});
        } else util.die("unsupported file type {s}", .{read_from});
    } else {
        buf = os.readAllFd(0) catch util.dieErrno("failed to read from stdin", .{});
    }
    buf = convert.toGit(path, buf);
    origin.file = buf;
    origin.blob_oid = odb_mod.hashObject(.blob, buf);
    if (mode == 0) {
        if (idx.findPos(path)) |pos| mode = idx.entries.items[pos].mode else mode = S_IFREG | 0o644;
    }
    origin.mode = mode;
    fake_entry_path = path;
    return commit;
}

// ---------------------------------------------------------------------------
// output

const OUTPUT_ANNOTATE_COMPAT: u32 = 1 << 0;
const OUTPUT_LONG_OBJECT_NAME: u32 = 1 << 1;
const OUTPUT_RAW_TIMESTAMP: u32 = 1 << 2;
const OUTPUT_PORCELAIN: u32 = 1 << 3;
const OUTPUT_SHOW_NAME: u32 = 1 << 4;
const OUTPUT_SHOW_NUMBER: u32 = 1 << 5;
const OUTPUT_SHOW_SCORE: u32 = 1 << 6;
const OUTPUT_NO_AUTHOR: u32 = 1 << 7;
const OUTPUT_SHOW_EMAIL: u32 = 1 << 8;
const OUTPUT_LINE_PORCELAIN: u32 = 1 << 9;
const OUTPUT_COLOR_LINE: u32 = 1 << 10;
const OUTPUT_SHOW_AGE_WITH_COLOR: u32 = 1 << 11;

var longest_file: usize = 0;
var longest_author: i64 = 0;
var max_orig_digits: usize = 0;
var max_digits: usize = 0;
var max_score_digits: usize = 0;
var blank_boundary = false;
var incremental = false;
var abbrev: i32 = -1;
var blame_date_mode: date.DateMode = date.DateMode.of(.iso8601);
var blame_date_width: usize = 0;
var mark_unblamable_lines = false;
var mark_ignored_lines = false;
var repeated_meta_color: []const u8 = "";
var the_mailmap: ?*mailmap.Map = null;

const ColorField = struct { hop: i64, col: []const u8 };
var colorfield: std.ArrayList(ColorField) = .empty;

const CommitInfo = struct {
    author: []const u8 = "",
    author_mail: []const u8 = "",
    author_time: u64 = 0,
    author_tz: []const u8 = "",
    committer: []const u8 = "",
    committer_mail: []const u8 = "",
    committer_time: u64 = 0,
    committer_tz: []const u8 = "",
    summary: []const u8 = "",
};

const AcLine = struct { name: []const u8, mail: []const u8, time: u64, tz: []const u8 };

fn isSpace(c: u8) bool {
    return c == ' ' or (c >= 9 and c <= 13);
}

fn getAcLine(inbuf: []const u8, what: []const u8) AcLine {
    const unknown = AcLine{ .name = "(unknown)", .mail = "(unknown)", .time = 0, .tz = "(unknown)" };
    const pos = std.mem.indexOf(u8, inbuf, what) orelse return unknown;
    const tmp = inbuf[pos + what.len ..];
    const len = std.mem.indexOfScalar(u8, tmp, '\n') orelse tmp.len;
    const line = tmp[0..len];
    // split_ident_line
    const lt = std.mem.indexOfScalar(u8, line, '<') orelse return unknown;
    const mail_begin = lt + 1;
    var name_end: usize = 0;
    {
        var cp: isize = @as(isize, @intCast(mail_begin)) - 2;
        while (cp >= 0) : (cp -= 1) {
            if (!isSpace(line[@intCast(cp)])) {
                name_end = @as(usize, @intCast(cp)) + 1;
                break;
            }
        }
    }
    const mail_end = std.mem.indexOfScalarPos(u8, line, mail_begin, '>') orelse return unknown;
    var time: u64 = 0;
    var tz: []const u8 = "(unknown)";
    person: {
        var cp = (std.mem.lastIndexOfScalar(u8, line, '>') orelse break :person) + 1;
        while (cp < line.len and isSpace(line[cp])) cp += 1;
        if (cp >= line.len) break :person;
        const db = cp;
        while (cp < line.len and std.ascii.isDigit(line[cp])) cp += 1;
        if (cp == db) break :person;
        const de = cp;
        while (cp < line.len and isSpace(line[cp])) cp += 1;
        if (cp >= line.len or (line[cp] != '+' and line[cp] != '-')) break :person;
        const tb = cp;
        cp += 1;
        while (cp < line.len and std.ascii.isDigit(line[cp])) cp += 1;
        if (cp == tb + 1) break :person;
        time = std.fmt.parseInt(u64, line[db..de], 10) catch std.math.maxInt(u64);
        tz = line[tb..cp];
    }
    var name = line[0..name_end];
    var mail = line[mail_begin..mail_end];
    if (the_mailmap) |m| {
        if (m.mapUser(name, mail)) |mapped| {
            name = mapped.name;
            mail = mapped.email;
        }
    }
    return .{ .name = name, .mail = util.fmt("<{s}>", .{mail}), .time = time, .tz = tz };
}

fn findCommitSubjectC(msg: []const u8) []const u8 {
    var p: usize = 0;
    while (p < msg.len and !(msg[p] == '\n' and p + 1 < msg.len and msg[p + 1] == '\n')) p += 1;
    if (p < msg.len) {
        p = pretty.skipBlankLines(msg, p + 2);
        const eol = std.mem.indexOfScalarPos(u8, msg, p, '\n') orelse msg.len;
        return msg[p..eol];
    }
    return "";
}

fn getCommitInfo(commit: *Commit) CommitInfo {
    const message = pretty.logmsgReencode(commit, pretty.logOutputEncoding()).msg;
    const a = getAcLine(message, "\nauthor ");
    const c = getAcLine(message, "\ncommitter ");
    const subj = findCommitSubjectC(message);
    return .{
        .author = a.name,
        .author_mail = a.mail,
        .author_time = a.time,
        .author_tz = a.tz,
        .committer = c.name,
        .committer_mail = c.mail,
        .committer_time = c.time,
        .committer_tz = c.tz,
        .summary = if (subj.len > 0) subj else util.fmt("({s})", .{hash.hex(commit.obj.oid)}),
    };
}

fn writeNameQuoted(b: *Buf, name: []const u8) void {
    util.bufAppend(b, util.cquote(name));
    util.bufByte(b, '\n');
}

fn writeFilenameInfo(b: *Buf, suspect: *Origin) void {
    if (suspect.previous) |prev| {
        util.bufPrint(b, "previous {s} ", .{hash.hex(prev.commit.obj.oid)});
        writeNameQuoted(b, prev.path);
    }
    util.bufAppend(b, "filename ");
    writeNameQuoted(b, suspect.path);
}

fn emitOneSuspectDetail(b: *Buf, suspect: *Origin, repeat: bool) bool {
    const c = suspect.commit;
    if (!repeat and c.obj.flags & METAINFO_SHOWN != 0) return false;
    c.obj.flags |= METAINFO_SHOWN;
    const ci = getCommitInfo(c);
    util.bufPrint(b, "author {s}\nauthor-mail {s}\nauthor-time {d}\nauthor-tz {s}\n", .{ ci.author, ci.author_mail, ci.author_time, ci.author_tz });
    util.bufPrint(b, "committer {s}\ncommitter-mail {s}\ncommitter-time {d}\ncommitter-tz {s}\n", .{ ci.committer, ci.committer_mail, ci.committer_time, ci.committer_tz });
    util.bufPrint(b, "summary {s}\n", .{ci.summary});
    if (c.obj.flags & cn.UNINTERESTING != 0) util.bufAppend(b, "boundary\n");
    return true;
}

fn foundGuiltyEntry(ent: *Entry) void {
    const suspect = ent.suspect.?;
    var b: Buf = .empty;
    util.bufPrint(&b, "{s} {d} {d} {d}\n", .{ hash.hex(suspect.commit.obj.oid), ent.s_lno + 1, ent.lno + 1, ent.num_lines });
    _ = emitOneSuspectDetail(&b, suspect, false);
    writeFilenameInfo(&b, suspect);
    util.out(b.items);
    util.flushStdout();
}

fn formatTime(time: u64, tz_str: []const u8, show_raw: bool) []const u8 {
    var b: Buf = .empty;
    if (show_raw) {
        util.bufPrint(&b, "{d} {s}", .{ time, tz_str });
    } else {
        const tz = atoi(tz_str);
        const s = date.showDate(@intCast(@min(time, @as(u64, std.math.maxInt(i64)))), tz, blame_date_mode);
        util.bufAppend(&b, s);
        var w: usize = @intCast(@max(pretty.utf8Strwidth(s), 0));
        while (w < blame_date_width) : (w += 1) util.bufByte(&b, ' ');
    }
    return b.items;
}

fn atoi(s: []const u8) i32 {
    var i: usize = 0;
    while (i < s.len and isSpace(s[i])) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    var v: i32 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) v = v *% 10 +% @as(i32, s[i] - '0');
    return if (neg) -v else v;
}

fn printMarks(b: ?*Buf, ent: *const Entry, opt: u32) usize {
    var len: usize = 0;
    if (ent.suspect.?.commit.obj.flags & cn.UNINTERESTING != 0 and !blank_boundary and opt & OUTPUT_ANNOTATE_COMPAT == 0) {
        if (b) |bb| util.bufByte(bb, '^');
        len += 1;
    }
    if (mark_unblamable_lines and ent.unblamable) {
        if (b) |bb| util.bufByte(bb, '*');
        len += 1;
    }
    if (mark_ignored_lines and ent.ignored) {
        if (b) |bb| util.bufByte(bb, '?');
        len += 1;
    }
    return len;
}

fn nthLine(lno: i32) usize {
    const n: usize = @intCast(lno);
    if (n >= sb_lineno.len) return sb_final_buf.len;
    return sb_lineno[n];
}

fn emitPorcelainDetails(b: *Buf, suspect: *Origin, repeat: bool) void {
    if (emitOneSuspectDetail(b, suspect, repeat) or suspect.commit.obj.flags & MORE_THAN_ONE_PATH != 0)
        writeFilenameInfo(b, suspect);
}

fn emitPorcelainPerLine(b: *Buf, ent: *const Entry) void {
    if (mark_unblamable_lines and ent.unblamable) util.bufAppend(b, "unblamable\n");
    if (mark_ignored_lines and ent.ignored) util.bufAppend(b, "ignored\n");
}

fn emitPorcelain(ent: *Entry, opt: u32) void {
    const repeat = opt & OUTPUT_LINE_PORCELAIN != 0;
    const suspect = ent.suspect.?;
    const hex = hash.hex(suspect.commit.obj.oid);
    var b: Buf = .empty;
    util.bufPrint(&b, "{s} {d} {d} {d}\n", .{ hex, ent.s_lno + 1, ent.lno + 1, ent.num_lines });
    emitPorcelainDetails(&b, suspect, repeat);
    emitPorcelainPerLine(&b, ent);
    var cp = nthLine(ent.lno);
    const buf = sb_final_buf;
    var cnt: i32 = 0;
    while (cnt < ent.num_lines) : (cnt += 1) {
        if (cnt != 0) {
            util.bufPrint(&b, "{s} {d} {d}\n", .{ hex, ent.s_lno + 1 + cnt, ent.lno + 1 + cnt });
            if (repeat) emitPorcelainDetails(&b, suspect, true);
            emitPorcelainPerLine(&b, ent);
        }
        util.bufByte(&b, '\t');
        cp = copyLine(&b, buf, cp);
    }
    if (buf.len > 0 and cp > 0 and buf[cp - 1] != '\n') util.bufByte(&b, '\n');
    util.out(b.items);
}

/// copy one line (including '\n') from buf at cp; returns the new position
fn copyLine(b: *Buf, buf: []const u8, cp0: usize) usize {
    var cp = cp0;
    while (true) {
        const ch: u8 = if (cp < buf.len) buf[cp] else 0;
        cp += 1;
        util.bufByte(b, ch);
        if (ch == '\n' or cp >= buf.len) break;
    }
    return cp;
}

fn determineLineHeat(ci: *const CommitInfo) []const u8 {
    var i: usize = 0;
    while (i + 1 < colorfield.items.len and @as(i64, @intCast(@min(ci.author_time, @as(u64, std.math.maxInt(i64))))) > colorfield.items[i].hop) i += 1;
    return colorfield.items[i].col;
}

fn emitOther(ent: *Entry, opt: u32, prev_ent: ?*Entry) void {
    const suspect = ent.suspect.?;
    const ci = getCommitInfo(suspect.commit);
    var hex = hash.hex(suspect.commit.obj.oid);
    const show_raw = opt & OUTPUT_RAW_TIMESTAMP != 0;
    var default_color: ?[]const u8 = null;
    var col: ?[]const u8 = null;
    var reset: ?[]const u8 = null;
    if (opt & OUTPUT_SHOW_AGE_WITH_COLOR != 0) {
        default_color = determineLineHeat(&ci);
        col = default_color;
        reset = color.RESET;
    }
    var b: Buf = .empty;
    var cp = nthLine(ent.lno);
    const buf = sb_final_buf;
    var cnt: i32 = 0;
    while (cnt < ent.num_lines) : (cnt += 1) {
        var length: usize = if (opt & OUTPUT_LONG_OBJECT_NAME != 0) 40 else @intCast(abbrev);
        if (opt & OUTPUT_COLOR_LINE != 0) {
            if (cnt > 0 or (prev_ent != null and hash.eql(suspect.commit.obj.oid, prev_ent.?.suspect.?.commit.obj.oid))) {
                col = repeated_meta_color;
                reset = color.RESET;
            } else {
                col = default_color;
                reset = if (default_color != null) color.RESET else null;
            }
        }
        if (col) |cc| util.bufAppend(&b, cc);
        if (suspect.commit.obj.flags & cn.UNINTERESTING != 0 and blank_boundary) @memset(&hex, ' ');
        length -|= printMarks(&b, ent, opt);
        util.bufAppend(&b, hex[0..@min(length, 40)]);
        if (opt & OUTPUT_ANNOTATE_COMPAT != 0) {
            const name = if (opt & OUTPUT_SHOW_EMAIL != 0) ci.author_mail else ci.author;
            util.bufByte(&b, '\t');
            util.bufByte(&b, '(');
            padLeft(&b, name, 10);
            util.bufByte(&b, '\t');
            padLeft(&b, formatTime(ci.author_time, ci.author_tz, show_raw), 10);
            util.bufPrint(&b, "\t{d})", .{ent.lno + 1 + cnt});
        } else {
            if (opt & OUTPUT_SHOW_SCORE != 0) {
                util.bufByte(&b, ' ');
                padLeft(&b, util.fmt("{d}", .{ent.score}), max_score_digits);
                util.bufPrint(&b, " {d:0>2}", .{@as(u32, @intCast(@max(suspect.refcnt, 0)))});
            }
            if (opt & OUTPUT_SHOW_NAME != 0) {
                util.bufByte(&b, ' ');
                const p = suspect.path[0..@min(suspect.path.len, longest_file)];
                util.bufAppend(&b, p);
                var k = p.len;
                while (k < longest_file) : (k += 1) util.bufByte(&b, ' ');
            }
            if (opt & OUTPUT_SHOW_NUMBER != 0) {
                util.bufByte(&b, ' ');
                padLeft(&b, util.fmt("{d}", .{ent.s_lno + 1 + cnt}), max_orig_digits);
            }
            if (opt & OUTPUT_NO_AUTHOR == 0) {
                const name = if (opt & OUTPUT_SHOW_EMAIL != 0) ci.author_mail else ci.author;
                const pad = longest_author - pretty.utf8Strwidth(name);
                util.bufAppend(&b, " (");
                util.bufAppend(&b, name);
                var k: i64 = 0;
                while (k < pad) : (k += 1) util.bufByte(&b, ' ');
                util.bufByte(&b, ' ');
                padLeft(&b, formatTime(ci.author_time, ci.author_tz, show_raw), 10);
            }
            util.bufByte(&b, ' ');
            padLeft(&b, util.fmt("{d}", .{ent.lno + 1 + cnt}), max_digits);
            util.bufAppend(&b, ") ");
        }
        if (reset) |rr| util.bufAppend(&b, rr);
        cp = copyLine(&b, buf, cp);
    }
    if (buf.len > 0 and cp > 0 and buf[cp - 1] != '\n') util.bufByte(&b, '\n');
    util.out(b.items);
}

fn padLeft(b: *Buf, s: []const u8, width: usize) void {
    var k = s.len;
    while (k < width) : (k += 1) util.bufByte(b, ' ');
    util.bufAppend(b, s);
}

fn output(option: u32) void {
    if (option & OUTPUT_PORCELAIN != 0) {
        var ent = sb_ent;
        while (ent) |e| : (ent = e.next) {
            const commit = e.suspect.?.commit;
            if (commit.obj.flags & MORE_THAN_ONE_PATH != 0) continue;
            var count: usize = 0;
            var s = getSuspects(commit);
            while (s) |x| : (s = x.next) {
                if (x.guilty) {
                    count += 1;
                    if (count > 1) {
                        commit.obj.flags |= MORE_THAN_ONE_PATH;
                        break;
                    }
                }
            }
        }
    }
    var prev: ?*Entry = null;
    var ent = sb_ent;
    while (ent) |e| : (ent = e.next) {
        if (option & OUTPUT_PORCELAIN != 0) {
            emitPorcelain(e, option);
        } else {
            emitOther(e, option, prev);
            prev = e;
        }
    }
}

fn decimalWidth(n0: i64) usize {
    var n = n0;
    var w: usize = 1;
    while (n >= 10) : (n = @divTrunc(n, 10)) w += 1;
    return w;
}

fn entryScore(e: *Entry) u32 {
    if (e.score != 0) return e.score;
    var score: u32 = 1;
    const a = nthLine(e.lno);
    const z = nthLine(e.lno + e.num_lines);
    for (sb_final_buf[a..z]) |ch| {
        if (std.ascii.isAlphanumeric(ch)) score += 1;
    }
    e.score = score;
    return score;
}

fn findAlignment(option: *u32) void {
    var longest_src_lines: i64 = 0;
    var longest_dst_lines: i64 = 0;
    var largest_score: u32 = 0;
    const compute_auto_abbrev = abbrev < 0;
    var auto_abbrev: usize = revparse.defaultAbbrev();
    var max_marks_count: usize = 0;
    var ent = sb_ent;
    while (ent) |e| : (ent = e.next) {
        const suspect = e.suspect.?;
        const marks = printMarks(null, e, option.*);
        if (max_marks_count < marks) max_marks_count = marks;
        if (compute_auto_abbrev) {
            const u = revparse.abbrev(suspect.commit.obj.oid, auto_abbrev).len;
            if (auto_abbrev < u) auto_abbrev = u;
        }
        if (!util.eql(suspect.path, sb_path)) option.* |= OUTPUT_SHOW_NAME;
        if (longest_file < suspect.path.len) longest_file = suspect.path.len;
        if (suspect.commit.obj.flags & METAINFO_SHOWN == 0) {
            suspect.commit.obj.flags |= METAINFO_SHOWN;
            const ci = getCommitInfo(suspect.commit);
            const num = if (option.* & OUTPUT_SHOW_EMAIL != 0) pretty.utf8Strwidth(ci.author_mail) else pretty.utf8Strwidth(ci.author);
            if (longest_author < num) longest_author = num;
        }
        const ns = e.s_lno + e.num_lines;
        if (longest_src_lines < ns) longest_src_lines = ns;
        const nd = e.lno + e.num_lines;
        if (longest_dst_lines < nd) longest_dst_lines = nd;
        const sc = entryScore(e);
        if (largest_score < sc) largest_score = sc;
    }
    max_orig_digits = decimalWidth(longest_src_lines);
    max_digits = decimalWidth(longest_dst_lines);
    max_score_digits = decimalWidth(largest_score);
    if (compute_auto_abbrev) abbrev = @intCast(auto_abbrev);
    if (abbrev < 40) {
        abbrev += @intCast(max_marks_count);
        if (abbrev > 40) abbrev = 40;
    }
}

// ---------------------------------------------------------------------------
// options

var xdl_minimal = false;
var algo: xdiff.Algorithm = .myers;
var opt_pickaxe: u32 = 0;
var blame_move_score: u32 = 0;
var blame_copy_score: u32 = 0;

fn parseScore(arg: []const u8) u32 {
    // strtoul(): leading whitespace and sign allowed; trailing garbage -> 0
    var s = std.mem.trimStart(u8, arg, " \t\n\r\x0b\x0c");
    if (s.len > 0 and s[0] == '+') s = s[1..];
    if (s.len == 0) return 0;
    return std.fmt.parseInt(u32, s, 10) catch 0;
}

fn cbCopy(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    // -C: copies from removed files; -C -C: from existing files when
    // blaming a new file; -C -C -C: from existing files for everybody
    if (opt_pickaxe & PICKAXE_BLAME_COPY_HARDER != 0) opt_pickaxe |= PICKAXE_BLAME_COPY_HARDEST;
    if (opt_pickaxe & PICKAXE_BLAME_COPY != 0) opt_pickaxe |= PICKAXE_BLAME_COPY_HARDER;
    opt_pickaxe |= PICKAXE_BLAME_COPY | PICKAXE_BLAME_MOVE;
    if (arg) |a| blame_copy_score = parseScore(a);
}

fn cbMove(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    opt_pickaxe |= PICKAXE_BLAME_MOVE;
    if (arg) |a| blame_move_score = parseScore(a);
}

fn cbDiffAlgorithm(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse return;
    if (parseAlgorithm(a)) |al| {
        algo = al;
    } else {
        util.err("option diff-algorithm accepts \"myers\", \"minimal\", \"patience\" and \"histogram\"", .{});
        os.exit(129);
    }
}

fn parseAlgorithm(a: []const u8) ?xdiff.Algorithm {
    if (std.ascii.eqlIgnoreCase(a, "myers") or std.ascii.eqlIgnoreCase(a, "default")) return .myers;
    if (std.ascii.eqlIgnoreCase(a, "minimal")) return .minimal;
    if (std.ascii.eqlIgnoreCase(a, "patience")) return .patience;
    if (std.ascii.eqlIgnoreCase(a, "histogram")) return .histogram;
    return null;
}

fn cbMinimal(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    algo = if (unset) .myers else .minimal;
}

fn cbAbbrev(arg: ?[]const u8, unset: bool) void {
    if (arg) |a| {
        if (a.len == 0) {
            util.err("option `abbrev' expects a numerical value", .{});
            os.exit(129);
        }
        var v = std.fmt.parseInt(i32, a, 10) catch {
            util.err("option `abbrev' expects a numerical value", .{});
            os.exit(129);
        };
        if (v != 0 and v < 4) v = 4 else if (v > 40) v = 40;
        abbrev = v;
    } else {
        abbrev = if (unset) 0 else -1;
    }
}

fn parseColorFields(s: []const u8) void {
    colorfield = .empty;
    var expect_color = true;
    var cur: ColorField = .{ .hop = 0, .col = "" };
    var it = std.mem.splitScalar(u8, s, ',');
    while (it.next()) |item| {
        if (expect_color) {
            cur.col = color.parseColor(item) orelse util.die("expecting a color: {s}", .{item});
            expect_color = false;
        } else {
            cur.hop = date.approxidate(item);
            colorfield.append(gpa, cur) catch util.oom();
            expect_color = true;
        }
    }
    if (expect_color) util.die("must end with a color", .{});
    cur.hop = std.math.maxInt(i64);
    colorfield.append(gpa, cur) catch util.oom();
}

fn insertSorted(list: *std.ArrayList([]const u8), s: []const u8) void {
    var pos: usize = 0;
    while (pos < list.items.len) : (pos += 1) {
        switch (std.mem.order(u8, list.items[pos], s)) {
            .lt => continue,
            .eq => return,
            .gt => break,
        }
    }
    list.insert(gpa, pos, s) catch util.oom();
}

/// peel_to_commit_oid()
fn peelToCommitOid(oid: Oid) ?Oid {
    return objects.peelTo(oid, .commit);
}

/// build_ignorelist()
fn buildIgnoreList(files: []const []const u8, revs_list: []const []const u8) void {
    sb_ignore_list = .empty;
    for (files) |f| {
        if (f.len == 0) {
            sb_ignore_list = .empty;
            continue;
        }
        // oidset_parse_file_carefully()
        const data = os.readFile(f) orelse util.die("could not open object name list: {s}", .{f});
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line0| {
            if (line0.len == 0 and it.index == null) break;
            var line = line0;
            if (std.mem.indexOfScalar(u8, line, '#')) |h| line = line[0..h];
            line = std.mem.trim(u8, line, " \t\r\n\x0b\x0c");
            if (line.len == 0) continue;
            const oid = (if (line.len == hash.HEXSZ) hash.fromHex(line) else null) orelse
                util.die("invalid object name: {s}", .{line});
            const c = peelToCommitOid(oid) orelse continue;
            sb_ignore_list.put(gpa, c, {}) catch util.oom();
        }
    }
    for (revs_list) |rv| {
        const oid = revparse.getOidCommittish(rv) orelse util.die("cannot find revision {s} to ignore", .{rv});
        const c = peelToCommitOid(oid) orelse util.die("cannot find revision {s} to ignore", .{rv});
        sb_ignore_list.put(gpa, c, {}) catch util.oom();
    }
}

/// read_ancestry(): phony grafts for -S ("commit parent1 parent2 ...").
fn readAncestry(path: []const u8) void {
    const data = os.readFile(path) orelse {
        util.warn("unable to access '{s}': {s}", .{ path, os.lastErr() });
        util.dieErrno("reading graft file '{s}' failed", .{path});
    };
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        const line = std.mem.trimEnd(u8, line0, " \t\r\n\x0b\x0c");
        if (line.len == 0 or line[0] == '#') continue;
        var toks = std.mem.tokenizeScalar(u8, line, ' ');
        const first = hash.fromHex(toks.next() orelse continue) orelse {
            util.err("bad graft data: {s}", .{line});
            continue;
        };
        var parents: ?*cn.CommitList = null;
        var tail: *?*cn.CommitList = &parents;
        var bad = false;
        while (toks.next()) |t| {
            const p = hash.fromHex(t) orelse {
                bad = true;
                break;
            };
            tail = cn.listAppend(cn.lookupCommit(p) orelse continue, tail);
        }
        if (bad) {
            util.err("bad graft data: {s}", .{line});
            continue;
        }
        const c = cn.lookupCommit(first) orelse continue;
        if (!cn.parse(c)) continue;
        c.parents = parents;
    }
}


const blame_usage_str = "git blame [<options>] [<rev-opts>] [<rev>] [--] <file>";
const annotate_usage_str = "git annotate [<options>] [<rev-opts>] [<rev>] [--] <file>";

fn isARev(name: []const u8) bool {
    const r = revparse.resolve(name, .{ .quiet = true }) orelse return false;
    return cn.objType(r.oid) != null;
}

pub fn cmdAnnotate(args: []const []const u8) u8 {
    // cmd_annotate() runs blame with "-c" prepended, so a lone helper
    // argument reaches diff_opt_parse() via parse_revision_opt().
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").diff_options);
    return cmdBlame(args);
}

pub fn cmdBlame(args: []const []const u8) u8 {
    const cmd_is_annotate = util.eql(args[0], "annotate");
    const usage: []const []const u8 = if (cmd_is_annotate)
        &.{ annotate_usage_str, "", "<rev-opts> are documented in git-rev-list(1)" }
    else
        &.{ blame_usage_str, "", "<rev-opts> are documented in git-rev-list(1)" };
    const str_usage = if (cmd_is_annotate) annotate_usage_str else blame_usage_str;
    const r = repo_mod.repo();
    @import("../sparse_index.zig").commandIsSparseAware();
    const cfg = &repo_mod.cfg;

    var output_option: i32 = 0;
    var show_root = false;
    var coloring_mode: u32 = 0;
    var ignore_ws = false;
    var indent_heuristic = true;

    // config
    parseColorFields("blue,12 month ago,white,1 month ago,red");
    if (cfg.getBool("blame.showroot")) |v| show_root = v;
    if (cfg.getBool("blame.blankboundary")) |v| blank_boundary = v;
    if (cfg.getBool("blame.showemail")) |v| {
        if (v) output_option |= @intCast(OUTPUT_SHOW_EMAIL) else output_option &= ~@as(i32, @intCast(OUTPUT_SHOW_EMAIL));
    }
    if (cfg.get("blame.date")) |v| {
        if (date.parseDateFormat(v)) |m| blame_date_mode = m;
    }
    if (cfg.getBool("blame.markunblamablelines")) |v| mark_unblamable_lines = v;
    if (cfg.getBool("blame.markignoredlines")) |v| mark_ignored_lines = v;
    if (cfg.get("color.blame.repeatedlines")) |v| {
        if (color.parseColor(v)) |c| repeated_meta_color = c else util.warn("invalid value for '{s}': '{s}'", .{ "color.blame.repeatedLines", v });
    }
    if (cfg.get("color.blame.highlightrecent")) |v| parseColorFields(v);
    for (cfg.getAll("blame.coloring")) |v| {
        if (util.eql(v, "repeatedLines")) {
            coloring_mode |= OUTPUT_COLOR_LINE;
        } else if (util.eql(v, "highlightRecent")) {
            coloring_mode |= OUTPUT_SHOW_AGE_WITH_COLOR;
        } else if (util.eql(v, "none")) {
            coloring_mode &= ~(OUTPUT_COLOR_LINE | OUTPUT_SHOW_AGE_WITH_COLOR);
        } else util.warn("invalid value for '{s}': '{s}'", .{ "blame.coloring", v });
    }
    if (cfg.get("diff.algorithm")) |v| {
        if (parseAlgorithm(v)) |a| algo = a else util.die("unknown value for config 'diff.algorithm': {s}", .{v});
    }
    if (cfg.getBool("diff.indentheuristic")) |v| indent_heuristic = v;

    var revs = revision.RevInfo.init(r.prefix);
    revs.date_mode = blame_date_mode;
    sb_revs = &revs;

    var incremental_b = false;
    var show_stats = false;
    var show_progress = false;
    var range_list: std.ArrayList([]const u8) = .empty;
    var ignore_rev_list: std.ArrayList([]const u8) = .empty;
    var ignore_revs_file_list: std.ArrayList([]const u8) = .empty;
    // blame.ignoreRevsFile (string_list_insert(): sorted, unique)
    for (cfg.entries.items) |ce| {
        if (!util.eql(ce.key, "blame.ignorerevsfile")) continue;
        switch (config_mod.configPathname(ce.key, ce.value)) {
            .ok => |p| if (p) |pth| insertSorted(&ignore_revs_file_list, pth),
            .err => @import("../fsck.zig").dieConfig(ce),
        }
    }
    var revs_file: ?[]const u8 = null;
    var contents_from: ?[]const u8 = null;
    var blank_b = blank_boundary;
    var ws_i: i32 = 0;

    const options = [_]po.Opt{
        po.boolean(0, "incremental", &incremental_b, "show blame entries as we find them, incrementally"),
        po.boolean('b', "", &blank_b, "do not show object names of boundary commits (Default: off)"),
        po.boolean(0, "root", &show_root, "do not treat root commits as boundaries (Default: off)"),
        po.boolean(0, "show-stats", &show_stats, "show work cost statistics"),
        po.boolean(0, "progress", &show_progress, "force progress reporting"),
        po.bit(0, "score-debug", &output_option, OUTPUT_SHOW_SCORE, "show output score for blame entries"),
        po.bit('f', "show-name", &output_option, OUTPUT_SHOW_NAME, "show original filename (Default: auto)"),
        po.bit('n', "show-number", &output_option, OUTPUT_SHOW_NUMBER, "show original linenumber (Default: off)"),
        po.bit('p', "porcelain", &output_option, OUTPUT_PORCELAIN, "show in a format designed for machine consumption"),
        po.bit(0, "line-porcelain", &output_option, OUTPUT_PORCELAIN | OUTPUT_LINE_PORCELAIN, "show porcelain format with per-line commit information"),
        po.bit('c', "", &output_option, OUTPUT_ANNOTATE_COMPAT, "use the same output mode as git-annotate (Default: off)"),
        po.bit('t', "", &output_option, OUTPUT_RAW_TIMESTAMP, "show raw timestamp (Default: off)"),
        po.bit('l', "", &output_option, OUTPUT_LONG_OBJECT_NAME, "show long commit SHA1 (Default: off)"),
        po.bit('s', "", &output_option, OUTPUT_NO_AUTHOR, "suppress author name and timestamp (Default: off)"),
        po.bit('e', "show-email", &output_option, OUTPUT_SHOW_EMAIL, "show author email instead of name (Default: off)"),
        po.bit('w', "", &ws_i, 1, "ignore whitespace differences"),
        .{ .long = "diff-algorithm", .kind = .callback, .cb = cbDiffAlgorithm, .argh = "algorithm", .noneg = true, .help = "choose a diff algorithm" },
        po.list(0, "ignore-rev", &ignore_rev_list, "rev", "ignore <rev> when blaming"),
        po.list(0, "ignore-revs-file", &ignore_revs_file_list, "file", "ignore revisions from <file>"),
        po.bit(0, "color-lines", &output_option, OUTPUT_COLOR_LINE, "color redundant metadata from previous line differently"),
        po.bit(0, "color-by-age", &output_option, OUTPUT_SHOW_AGE_WITH_COLOR, "color lines by age"),
        .{ .long = "minimal", .kind = .callback, .cb = cbMinimal, .noarg = true, .hidden = true, .help = "spend extra cycles to find a better match" },
        po.string('S', "", &revs_file, "file", "use revisions from <file> instead of calling git-rev-list"),
        po.string(0, "contents", &contents_from, "file", "use <file>'s contents as the final image"),
        .{ .short = 'C', .kind = .callback, .cb = cbCopy, .optarg = true, .noneg = true, .argh = "score", .help = "find line copies within and across files" },
        .{ .short = 'M', .kind = .callback, .cb = cbMove, .optarg = true, .noneg = true, .argh = "score", .help = "find line movements within and across files" },
        po.list('L', "", &range_list, "range", "process only line range <start>,<end> or function :<funcname>"),
        .{ .long = "abbrev", .kind = .callback, .cb = cbAbbrev, .optarg = true, .argh = "n", .help = "use <n> digits to display object names" },
    };

    const rest = po.parse(args[1..], &options, usage, .{ .keep_unknown = true, .keep_dashdash = true });
    blank_boundary = blank_b;
    incremental = incremental_b;
    ignore_ws = ws_i != 0;

    // walk the remaining arguments: revision options are consumed here,
    // pseudo-options and non-options kept.
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, args[0]) catch util.oom();
    var reverse = false;
    var dashdash_pos: usize = 0;
    // revs.diffopt: blame only looks at a few of the diff options
    var dopt = diff_mod.DiffOptions.initBasic();
    if (indent_heuristic) dopt.xdl_opts |= xdiff.XDF_INDENT_HEURISTIC else dopt.xdl_opts &= ~xdiff.XDF_INDENT_HEURISTIC;
    dopt.flags.allow_textconv = true;
    dopt.flags.follow_renames = true;
    {
        var i: usize = 0;
        while (i < rest.len) {
            var a = rest[i];
            if (util.eql(a, "--")) {
                dashdash_pos = argv.items.len;
                argv.appendSlice(gpa, rest[i..]) catch util.oom();
                break;
            }
            if (a.len < 2 or a[0] != '-') {
                argv.append(gpa, a) catch util.oom();
                i += 1;
                continue;
            }
            var sub: std.ArrayList([]const u8) = .empty;
            sub.appendSlice(gpa, rest[i..]) catch util.oom();
            if (util.eql(a, "--reverse")) {
                a = "--children";
                sub.items[0] = a;
                reverse = true;
            }
            var unk: std.ArrayList([]const u8) = .empty;
            var n = revision.handleRevisionOptUnk(&revs, sub.items, &unk);
            if (n < 0) os.exit(128);
            if (n == 0) n = @intCast(dopt.parseOpt(sub.items, 0));
            if (n == 0) {
                util.err("unknown option `{s}'", .{if (util.startsWith(a, "--")) a[2..] else a});
                po.usageWithOptions(usage, &options);
            }
            argv.appendSlice(gpa, unk.items) catch util.oom();
            i += @intCast(n);
        }
    }
    revision.revisionOptsFinish(&revs);
    blame_textconv = dopt.flags.allow_textconv;
    const no_whole_file_rename = !dopt.flags.follow_renames;
    indent_heuristic = dopt.xdl_opts & xdiff.XDF_INDENT_HEURISTIC != 0;
    if (dopt.flags.find_copies_harder)
        opt_pickaxe |= PICKAXE_BLAME_COPY | PICKAXE_BLAME_MOVE | PICKAXE_BLAME_COPY_HARDER;

    if (incremental or output_option & @as(i32, @intCast(OUTPUT_PORCELAIN)) != 0) {
        if (show_progress) util.die("--progress can't be used with --incremental or porcelain formats", .{});
    }
    if (abbrev == 0) abbrev = 40;
    if (revs_file) |rf| readAncestry(rf);

    if (cmd_is_annotate) {
        output_option |= @intCast(OUTPUT_ANNOTATE_COMPAT);
        blame_date_mode = date.DateMode.of(.iso8601);
    } else {
        blame_date_mode = revs.date_mode;
    }
    blame_date_width = switch (blame_date_mode.mode) {
        .rfc2822 => "Thu, 19 Oct 2006 16:00:04 -0700".len,
        .iso8601_strict => "2006-10-19T16:00:04-07:00".len,
        .iso8601 => "2006-10-19 16:00:04 -0700".len,
        .raw => "1161298804 -0700".len,
        .unix => "1161298804".len,
        .short => "2006-10-19".len,
        .relative => "4 years, 11 months ago".len,
        .human => "Thu Oct 19 16:00".len,
        .normal => "Thu Oct 19 16:00:04 2006 -0700".len,
        .strftime => date.showDate(0, 0, blame_date_mode).len,
    };

    // path / revision disambiguation
    var path: []const u8 = undefined;
    var argc = argv.items.len;
    const add_prefix = struct {
        fn f(p: []const u8) []const u8 {
            return repo_mod.prefixPath(p) orelse
                util.die("'{s}' is outside repository at '{s}'", .{ p, repo_mod.repo().work_tree orelse "" });
        }
    }.f;
    if (dashdash_pos != 0) {
        switch (argc - dashdash_pos - 1) {
            2 => {
                if (argc != 4) po.usageWithOptions(usage, &options);
                const a3 = argv.items[3];
                argv.items[3] = argv.items[2];
                argv.items[2] = "--";
                argv.items[1] = a3;
                argc -= 1;
                path = add_prefix(argv.items[argc]);
                argv.items.len = argc;
            },
            1 => {
                argc -= 1;
                path = add_prefix(argv.items[argc]);
                argv.items.len = argc;
            },
            else => po.usageWithOptions(usage, &options),
        }
    } else {
        if (argc < 2) po.usageWithOptions(usage, &options);
        if (argc == 3 and isARev(argv.items[argc - 1])) {
            path = add_prefix(argv.items[1]);
            argv.items[1] = argv.items[2];
        } else {
            if (argc == 2 and isARev(argv.items[1]) and r.work_tree == null)
                util.die("missing <path> to blame", .{});
            path = add_prefix(argv.items[argc - 1]);
        }
        argv.items[argc - 1] = "--";
    }

    revs.disable_stdin = true;
    _ = revision.setupRevisions(&revs, argv.items, .{});
    if (revs.pending.items.len == 0 and r.bare) {
        const head = refs.readOid("HEAD") orelse util.die("no such ref: HEAD", .{});
        const hc = cn.lookupCommitReference(head) orelse util.die("no such ref: HEAD", .{});
        revs.addPendingObject(&hc.obj, "HEAD");
    }

    sb_reverse = reverse;
    sb_path = path;
    buildIgnoreList(ignore_revs_file_list.items, ignore_rev_list.items);

    // setup_scoreboard
    if (reverse and contents_from != null) util.die("--contents and --reverse do not blend well.", .{});
    var final_commit_name: ?[]const u8 = null;
    var final: ?*Commit = null;
    if (!reverse) {
        final = findSingleFinal(&final_commit_name);
        sb_commits.compare = cn.compareByCommitDate;
    } else {
        final = findSingleInitial(&final_commit_name);
        sb_commits.compare = compareReverseCommitDate;
    }
    const fp_reverse = reverse and revs.first_parent_only;
    if (fp_reverse) revs.children_enabled = false;

    if (contents_from != null or final == null) {
        var parent_oid: Oid = undefined;
        if (final) |f| {
            parent_oid = f.obj.oid;
        } else {
            parent_oid = refs.readOid("HEAD") orelse util.die("no such ref: HEAD", .{});
        }
        if (contents_from == null) _ = repo_mod.requireWorkTree("blame");
        final = fakeWorkingTreeCommit(path, contents_from, parent_oid);
        revs.addPendingObject(&final.?.obj, ":");
    }
    var fp_final: ?*Commit = null;
    if (fp_reverse) {
        fp_final = findSingleFinal(null) orelse
            util.die("--reverse and --first-parent together require specified latest commit", .{});
    }
    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    if (fp_reverse) {
        revs.children = cn.Slab(?*cn.CommitList).init(null);
        revs.children_enabled = true;
        var c = fp_final.?;
        while (true) {
            _ = cn.parse(c);
            const pl = c.parents orelse break;
            if (hash.eql(c.obj.oid, final.?.obj.oid)) break;
            revs.children.at(pl.item).* = cn.newNode(c, null);
            c = pl.item;
        }
        if (!hash.eql(c.obj.oid, final.?.obj.oid))
            util.die("--reverse --first-parent together require range along first-parent chain", .{});
    }

    const fc = final.?;
    var o: *Origin = undefined;
    if (hash.isZero(fc.obj.oid)) {
        o = getSuspects(fc).?;
        sb_final_buf = o.file.?;
    } else {
        o = getOrigin(fc, path);
        if (!fillBlobOidAndMode(o)) util.die("no such path {s} in {s}", .{ path, final_commit_name orelse "" });
        const tc = if (blame_textconv) diff_mod.textconvObject(path, o.mode, o.blob_oid) else null;
        if (tc) |out| {
            sb_final_buf = out;
            o.file = out;
        } else {
            const obj = r.odb().read(o.blob_oid) orelse
                util.die("cannot read blob {s} for path {s}", .{ hash.hex(o.blob_oid), path });
            sb_final_buf = obj.data;
            o.file = obj.data;
        }
    }
    sb_num_read_blob += 1;
    sb_lineno = linerange.findLineStarts(sb_final_buf);
    const lno: i64 = @as(i64, @intCast(sb_lineno.len)) - 1;
    sb_num_lines = @intCast(lno);

    if (lno != 0 and range_list.items.len == 0) range_list.append(gpa, "1") catch util.oom();
    var anchor: i64 = 1;
    var ranges: std.ArrayList(linerange.RangeSpan) = .empty;
    const lines = linerange.Lines{ .buf = sb_final_buf, .starts = sb_lineno };
    for (range_list.items) |spec| {
        const rg = linerange.parseRangeArg(spec, lines, anchor, path) orelse {
            util.eprint("usage: {s}\n", .{str_usage});
            os.exit(129);
        };
        var bottom = rg.begin;
        var top = rg.end;
        if ((lno == 0 and (top != 0 or bottom != 0)) or lno < bottom)
            util.die("file {s} has only {d} line{s}", .{ path, lno, if (lno == 1) "" else "s" });
        if (bottom < 1) bottom = 1;
        if (top < 1 or lno < top) top = lno;
        bottom -= 1;
        ranges.append(gpa, .{ .start = bottom, .end = top }) catch util.oom();
        anchor = top + 1;
    }
    linerange.sortAndMerge(&ranges);
    var ent: ?*Entry = null;
    var ri = ranges.items.len;
    while (ri > 0) {
        ri -= 1;
        const rr = ranges.items[ri];
        const e = gpa.create(Entry) catch util.oom();
        e.* = .{ .lno = @intCast(rr.start), .num_lines = @intCast(rr.end - rr.start), .suspect = o, .s_lno = @intCast(rr.start), .next = ent };
        _ = incref(o);
        ent = e;
    }
    o.suspects = ent;
    sb_commits.put(o.commit);
    decref(o);
    sb_ent = null;

    sb_show_root = show_root;
    sb_no_whole_file_rename = no_whole_file_rename;
    if (blame_move_score != 0) sb_move_score = blame_move_score;
    if (blame_copy_score != 0) sb_copy_score = blame_copy_score;
    sb_xflags = .{ .algorithm = algo, .ignore_ws = ignore_ws, .indent_heuristic = indent_heuristic };
    the_mailmap = mailmap.readMailmap();

    assignBlame();

    if (incremental) {
        util.flushStdout();
        return 0;
    }
    if (@import("../main.zig").use_pager orelse (cfg.getBool("pager.blame") orelse true))
        @import("../commands.zig").setupPager();

    sortEntries(&sb_ent, lessFinal);
    blameCoalesce();

    var oopt: u32 = @intCast(output_option);
    if (oopt & (OUTPUT_COLOR_LINE | OUTPUT_SHOW_AGE_WITH_COLOR) == 0) oopt |= coloring_mode;
    if (oopt & OUTPUT_PORCELAIN == 0) {
        findAlignment(&oopt);
        if (repeated_meta_color.len == 0 and oopt & OUTPUT_COLOR_LINE != 0) repeated_meta_color = color.CYAN;
    }
    if (oopt & OUTPUT_ANNOTATE_COMPAT != 0) oopt &= ~(OUTPUT_COLOR_LINE | OUTPUT_SHOW_AGE_WITH_COLOR);
    output(oopt);
    if (show_stats) {
        util.outf("num read blob: {d}\n", .{sb_num_read_blob});
        util.outf("num get patch: {d}\n", .{sb_num_get_patch});
        util.outf("num commits: {d}\n", .{sb_num_commits});
    }
    return 0;
}
