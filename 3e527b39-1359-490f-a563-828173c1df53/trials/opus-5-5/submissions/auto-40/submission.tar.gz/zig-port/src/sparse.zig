//! Sparse-checkout pattern handling (dir.c cone/hashset parts,
//! path_in_sparse_checkout) and update_sparsity() from unpack-trees.c.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const dir_mod = @import("dir.zig");
const entry_mod = @import("entry.zig");
const pathspec_mod = @import("pathspec.zig");
const gpa = util.gpa;

const Index = index_mod.Index;
const Entry = index_mod.Entry;
const Pattern = dir_mod.Pattern;

pub const Match = enum(i8) { undecided = -1, not_matched = 0, matched = 1, matched_recursive = 2 };

const Set = std.StringHashMapUnmanaged(void);

pub const Patterns = struct {
    pl: dir_mod.PatternList = .{},
    use_cone: bool = false,
    full_cone: bool = false,
    recursive: Set = .empty,
    parent: Set = .empty,

    pub fn init(cone: bool) *Patterns {
        const p = gpa.create(Patterns) catch util.oom();
        p.* = .{ .use_cone = cone };
        return p;
    }

    /// add_pattern()
    pub fn add(self: *Patterns, string: []const u8) void {
        dir_mod.addPatternToList(&self.pl, string, "", 0);
        self.addToHashsets(self.pl.patterns.items[self.pl.patterns.items.len - 1]);
    }

    /// add_patterns_from_buffer() semantics
    pub fn addBuffer(self: *Patterns, buf: []const u8) void {
        const start = self.pl.patterns.items.len;
        dir_mod.addPatternsFromBuffer(&self.pl, buf, "");
        for (self.pl.patterns.items[start..]) |p| self.addToHashsets(p);
    }

    fn clearHashmaps(self: *Patterns) void {
        util.warn("disabling cone pattern matching", .{});
        self.recursive = .empty;
        self.parent = .empty;
        self.use_cone = false;
    }

    fn unrecognized(self: *Patterns, pat: []const u8) void {
        util.warn("unrecognized pattern: '{s}'", .{pat});
        self.clearHashmaps();
    }

    fn addToHashsets(self: *Patterns, given: *Pattern) void {
        if (!self.use_cone) return;
        const pat = given.pattern;
        const neg = given.flags & dir_mod.PATTERN_FLAG_NEGATIVE != 0;
        const mustbedir = given.flags & dir_mod.PATTERN_FLAG_MUSTBEDIR != 0;
        if (neg and mustbedir and util.eql(pat, "/*")) {
            self.full_cone = false;
            return;
        }
        if (given.flags == 0 and util.eql(pat, "/*")) {
            self.full_cone = true;
            return;
        }
        if (pat.len < 2 or pat[0] != '/' or std.mem.indexOf(u8, pat, "**") != null)
            return self.unrecognized(pat);
        if (!mustbedir and !util.eql(pat, "/*")) return self.unrecognized(pat);

        var i: usize = 1;
        while (i < pat.len) : (i += 1) {
            const prev = pat[i - 1];
            const cur = pat[i];
            const next: u8 = if (i + 1 < pat.len) pat[i + 1] else 0;
            if (!isGlobSpecial(cur)) continue;
            if (prev == '\\') continue;
            if (cur == '\\' and isGlobSpecial(next)) continue;
            if (prev == '/' and cur == '*' and next == 0) continue;
            return self.unrecognized(pat);
        }

        if (pat.len > 2 and util.endsWith(pat, "/*")) {
            if (!neg) return self.unrecognized(pat);
            const truncated = dupAndFilter(pat);
            if (!self.recursive.contains(truncated)) {
                util.warn("unrecognized negative pattern: '{s}'", .{pat});
                return self.clearHashmaps();
            }
            self.parent.put(gpa, truncated, {}) catch util.oom();
            _ = self.recursive.remove(truncated);
            return;
        }
        if (neg) {
            util.warn("unrecognized negative pattern: '{s}'", .{pat});
            return self.clearHashmaps();
        }
        const translated = dupAndFilter(pat);
        self.recursive.put(gpa, translated, {}) catch util.oom();
        if (self.parent.contains(translated)) {
            util.warn("your sparse-checkout file may have issues: pattern '{s}' is repeated", .{pat});
            return self.clearHashmaps();
        }
    }

    /// insert_recursive_pattern(): path starts with '/'
    pub fn insertRecursive(self: *Patterns, path: []const u8) void {
        self.recursive.put(gpa, util.dupe(path), {}) catch util.oom();
        var p = path;
        while (p.len > 0) {
            const slash = std.mem.lastIndexOfScalar(u8, p, '/') orelse break;
            if (slash == 0) break;
            p = p[0..slash];
            if (!self.parent.contains(p)) self.parent.put(gpa, util.dupe(p), {}) catch util.oom();
        }
    }

    /// path_matches_pattern_list()
    pub fn matches(self: *Patterns, pathname: []const u8, dtype: u8) Match {
        if (!self.use_cone) {
            const bpos = if (std.mem.lastIndexOfScalar(u8, pathname, '/')) |s| s + 1 else 0;
            const p = lastMatching(&self.pl, pathname, pathname[bpos..], dtype) orelse return .undecided;
            return if (p.flags & dir_mod.PATTERN_FLAG_NEGATIVE != 0) .not_matched else .matched;
        }
        if (self.full_cone) return .matched;
        var buf: util.Buf = .empty;
        util.bufByte(&buf, '/');
        util.bufAppend(&buf, pathname);
        var slash_pos: usize = 0;
        if (buf.items[buf.items.len - 1] == '/') {
            slash_pos = buf.items.len - 1;
            util.bufByte(&buf, '-');
        } else {
            slash_pos = std.mem.lastIndexOfScalar(u8, buf.items, '/') orelse 0;
        }
        if (self.recursive.contains(buf.items)) return .matched_recursive;
        if (slash_pos == 0) return .matched;
        if (self.parent.contains(buf.items[0..slash_pos])) return .matched;
        if (containsParent(&self.recursive, pathname)) return .matched_recursive;
        return .not_matched;
    }

    /// path_in_sparse_checkout_1() with these patterns.
    pub fn pathIn(self: *Patterns, path: []const u8, dtype0: u8) bool {
        if (path.len == 0) return true;
        var dtype = dtype0;
        var match: Match = .undecided;
        var end = path.len;
        while (end > 0 and match == .undecided) {
            var slash = end - 1;
            while (slash > 0 and path[slash] != '/') slash -= 1;
            match = self.matches(path[0..end], dtype);
            dtype = dir_mod.DT_DIR;
            end = slash;
        }
        return @intFromEnum(match) > 0;
    }
};

fn isGlobSpecial(ch: u8) bool {
    return ch == '*' or ch == '?' or ch == '[' or ch == '\\';
}

/// dup_and_filter_pattern()
fn dupAndFilter(pat: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (i < pat.len) : (i += 1) {
        if (pat[i] == '\\') {
            i += 1;
            if (i >= pat.len) break;
        }
        util.bufByte(&b, pat[i]);
    }
    if (b.items.len > 2 and util.endsWith(b.items, "/*")) b.items.len -= 2;
    return b.items;
}

/// hashmap_contains_parent()
pub fn containsParent(map: *const Set, path: []const u8) bool {
    var buf: []const u8 = if (path.len > 0 and path[0] == '/') path else util.concat(&.{ "/", path });
    while (std.mem.lastIndexOfScalar(u8, buf, '/')) |s| {
        if (s == 0) break;
        buf = buf[0..s];
        if (map.contains(buf)) return true;
    }
    return false;
}

fn lastMatching(pl: *dir_mod.PatternList, pathname: []const u8, basename: []const u8, dtype: u8) ?*Pattern {
    var i = pl.patterns.items.len;
    while (i > 0) {
        i -= 1;
        const p = pl.patterns.items[i];
        if (p.flags & dir_mod.PATTERN_FLAG_MUSTBEDIR != 0 and dtype != dir_mod.DT_DIR) continue;
        if (p.flags & dir_mod.PATTERN_FLAG_NODIR != 0) {
            if (dir_mod.matchBasename(basename, p.pattern, p.nowildcardlen, p.flags)) return p;
            continue;
        }
        if (dir_mod.matchPathname(pathname, p.base, 0, p.pattern, p.nowildcardlen)) return p;
    }
    return null;
}

// ---------------------------------------------------------------------------
// configuration / file

pub fn sparseFilename() []const u8 {
    return repo_mod.repo().gitPath("info/sparse-checkout");
}

pub fn configApply() bool {
    return repo_mod.cfg.getBool("core.sparsecheckout") orelse false;
}

pub fn configCone() bool {
    return repo_mod.cfg.getBool("core.sparsecheckoutcone") orelse false;
}

/// add_patterns_from_file_to_list(); null if the file can't be read.
pub fn loadFile(path: []const u8, cone: bool) ?*Patterns {
    const data = os.readFile(path) orelse return null;
    const p = Patterns.init(cone);
    p.addBuffer(data);
    return p;
}

var cached: ?*Patterns = null;
var cached_loaded = false;

/// The repository's sparse-checkout patterns (null when sparse checkout is
/// disabled or the file is missing).
pub fn current() ?*Patterns {
    if (!cached_loaded) {
        cached_loaded = true;
        if (configApply()) cached = loadFile(sparseFilename(), configCone());
    }
    return cached;
}

/// path_in_sparse_checkout(): true if sparse checkout is off.
pub fn pathInSparseCheckout(path: []const u8) bool {
    const p = current() orelse return true;
    return p.pathIn(path, dir_mod.DT_REG);
}

fn ceDtype(e: *const Entry) u8 {
    const m = e.mode & os.S_IFMT;
    if (m == os.S_IFGITLINK or m == os.S_IFDIR) return dir_mod.DT_DIR;
    if (m == os.S_IFLNK) return dir_mod.DT_LNK;
    return dir_mod.DT_REG;
}

// ---------------------------------------------------------------------------
// update_sparsity()

pub const Result = enum(i32) { success = 0, warnings = 1, index_failures = -1, worktree_failures = -2 };

const Action = enum(u8) { none, remove, update };

fn verifyUptodate(idx: *Index, e: *const Entry) bool {
    if (os.lstatPath(e.path)) |st| {
        const changed = entry_mod.matchStatIgnoreValid(idx, e, st);
        if (changed == 0) return true;
        if (e.mode & os.S_IFMT == os.S_IFGITLINK) return true;
        return false;
    }
    return os.errno() == os.ENOENT;
}

fn verifyAbsent(e: *const Entry) bool {
    const len = entry_mod.checkLeadingPath(e.path, false);
    if (len == 0) return true;
    if (len > 0) return false;
    const st = os.lstatPath(e.path) orelse return true;
    if (st.isDir()) {
        if (e.mode & os.S_IFMT == os.S_IFGITLINK) return true;
        return dir_mod.isEmptyDir(e.path);
    }
    return false;
}

fn showWarning(msg: []const u8, paths: []const []const u8) bool {
    if (paths.len == 0) return false;
    var b: util.Buf = .empty;
    for (paths) |p| util.bufPrint(&b, "\t{s}\n", .{p});
    util.warn("{s}\n{s}", .{ msg, b.items });
    return true;
}

/// update_sparsity(): set skip-worktree bits according to `pl` and update
/// the working tree. The caller writes/rolls back the index.
pub fn updateSparsity(idx: *Index, pl: *Patterns) Result {
    var ret: Result = .success;
    // expand sparse directories as needed (only those now inside the cone)
    @import("sparse_index.zig").expandIndex(idx, pl);
    const ents = idx.entries.items;
    const actions = gpa.alloc(Action, ents.len) catch util.oom();
    @memset(actions, .none);
    var not_uptodate: std.ArrayList([]const u8) = .empty;
    var unmerged: std.ArrayList([]const u8) = .empty;
    var orphaned: std.ArrayList([]const u8) = .empty;

    var i: usize = 0;
    while (i < ents.len) : (i += 1) {
        const e = &ents[i];
        if (e.removed) continue;
        if (e.stage() != 0) {
            unmerged.append(gpa, e.path) catch util.oom();
            while (i + 1 < ents.len and util.eql(ents[i + 1].path, e.path)) i += 1;
            ret = .warnings;
            continue;
        }
        const new_skip = !pl.pathIn(e.path, ceDtype(e));
        const was = e.skipWorktree();
        if (new_skip) e.ext_flags |= index_mod.CE_SKIP_WORKTREE else e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
        if (was != new_skip) idx.changed = true;
        if (!was and new_skip) {
            if (!verifyUptodate(idx, e)) {
                not_uptodate.append(gpa, e.path) catch util.oom();
                e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
                ret = .warnings;
                continue;
            }
            actions[i] = .remove;
        } else if (was and !new_skip) {
            if (!verifyAbsent(e)) {
                orphaned.append(gpa, e.path) catch util.oom();
                ret = .warnings;
                continue;
            }
            actions[i] = .update;
        }
    }

    // check_updates()
    var errs = false;
    for (ents, 0..) |*e, k| {
        if (actions[k] == .remove) entry_mod.unlinkEntry(e);
    }
    entry_mod.removeScheduledDirs();
    var state = entry_mod.State{ .force = true, .refresh_cache = true, .istate = idx };
    for (ents, 0..) |*e, k| {
        if (actions[k] != .update) continue;
        if (entry_mod.checkoutEntry(e, &state, null)) errs = true;
    }
    if (errs) ret = .worktree_failures;

    var shown = false;
    shown = showWarning("The following paths are not up to date and were left despite sparse patterns:", not_uptodate.items) or shown;
    shown = showWarning("The following paths are unmerged and were left despite sparse patterns:", unmerged.items) or shown;
    shown = showWarning("The following paths were already present and thus not updated despite sparse patterns:", orphaned.items) or shown;
    if (shown) util.eprint("After fixing the above paths, you may want to run `git sparse-checkout reapply`.\n", .{});
    return ret;
}

/// Directories that a sparse index would collapse (cone mode only): maximal
/// directories outside the cone whose entries are all merged, non-gitlink
/// and skip-worktree. Returned with a trailing '/'. Null if the index has
/// unmerged entries.
pub fn sparseDirectories(idx: *Index, pl: *Patterns) ?[]const []const u8 {
    if (!pl.use_cone) return null;
    for (idx.entries.items) |*e| {
        if (!e.removed and e.stage() != 0) return null;
    }
    var out: std.ArrayList([]const u8) = .empty;
    collapse(idx.entries.items, 0, idx.entries.items.len, "", pl, &out);
    return out.items;
}

fn collapse(ents: []Entry, start: usize, end: usize, prefix: []const u8, pl: *Patterns, out: *std.ArrayList([]const u8)) void {
    if (prefix.len > 0 and !pl.pathIn(prefix, dir_mod.DT_DIR)) {
        var ok = true;
        for (ents[start..end]) |*e| {
            if (e.removed) continue;
            if (e.stage() != 0 or e.mode & os.S_IFMT == os.S_IFGITLINK or !e.skipWorktree()) {
                ok = false;
                break;
            }
        }
        if (ok) {
            out.append(gpa, prefix) catch util.oom();
            return;
        }
    }
    var i = start;
    while (i < end) {
        const rest = ents[i].path[prefix.len..];
        const slash = std.mem.indexOfScalar(u8, rest, '/') orelse {
            i += 1;
            continue;
        };
        const sub = ents[i].path[0 .. prefix.len + slash + 1];
        var j = i + 1;
        while (j < end and util.startsWith(ents[j].path, sub)) j += 1;
        collapse(ents, i, j, sub, pl, out);
        i = j;
    }
}

/// clean_tracked_sparse_directories()
pub fn cleanTrackedSparseDirectories(idx: *Index, pl: *Patterns) void {
    const dirs = sparseDirectories(idx, pl) orelse return;
    for (dirs) |d| {
        if (os.lstatPath(d) == null) continue;
        const ps = pathspec_mod.parse("", &.{d}, .{});
        const res = dir_mod.untracked(.{ .pathspec = &ps, .show_ignored_too = true, .index = idx });
        if (res.entries.len > 0) {
            util.warn("directory '{s}' contains untracked files, but is not in the sparse-checkout cone", .{d});
        } else {
            os.removeTree(d[0 .. d.len - 1]);
            if (os.lstatPath(d) != null) util.warn("failed to remove directory '{s}'", .{d});
        }
    }
}
