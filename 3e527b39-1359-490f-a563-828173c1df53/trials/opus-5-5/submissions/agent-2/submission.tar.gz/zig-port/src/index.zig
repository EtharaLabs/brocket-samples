//! The index (dircache): reading/writing .git/index, cache-tree, stat matching.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const objects = @import("objects.zig");
const lockfile = @import("lockfile.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const CE_NAMEMASK: u16 = 0x0fff;
pub const CE_STAGEMASK: u16 = 0x3000;
pub const CE_STAGESHIFT = 12;
pub const CE_EXTENDED: u16 = 0x4000;
pub const CE_VALID: u16 = 0x8000;
// extended flags (stored in ext_flags)
pub const CE_INTENT_TO_ADD: u16 = 0x2000;
pub const CE_SKIP_WORKTREE: u16 = 0x4000;

pub const Entry = struct {
    ctime_s: u32 = 0,
    ctime_ns: u32 = 0,
    mtime_s: u32 = 0,
    mtime_ns: u32 = 0,
    dev: u32 = 0,
    ino: u32 = 0,
    mode: u32 = 0,
    uid: u32 = 0,
    gid: u32 = 0,
    size: u32 = 0,
    oid: Oid = hash.zero,
    flags: u16 = 0, // assume-valid, stage (namelen recomputed on write)
    ext_flags: u16 = 0,
    path: []const u8,
    // in-core only
    removed: bool = false,
    uptodate: bool = false,

    pub fn stage(self: *const Entry) u32 {
        return (self.flags & CE_STAGEMASK) >> CE_STAGESHIFT;
    }
    pub fn setStage(self: *Entry, s: u32) void {
        self.flags = (self.flags & ~CE_STAGEMASK) | @as(u16, @intCast(s << CE_STAGESHIFT));
    }
    pub fn intentToAdd(self: *const Entry) bool {
        return self.ext_flags & CE_INTENT_TO_ADD != 0;
    }
    pub fn skipWorktree(self: *const Entry) bool {
        return self.ext_flags & CE_SKIP_WORKTREE != 0;
    }
    pub fn assumeValid(self: *const Entry) bool {
        return self.flags & CE_VALID != 0;
    }
    pub fn fillStat(self: *Entry, st: os.Stat) void {
        self.ctime_s = @truncate(@as(u64, @bitCast(st.ctime)));
        self.ctime_ns = @truncate(@as(u64, @bitCast(st.ctime_ns)));
        self.mtime_s = @truncate(@as(u64, @bitCast(st.mtime)));
        self.mtime_ns = @truncate(@as(u64, @bitCast(st.mtime_ns)));
        self.dev = @truncate(st.dev);
        self.ino = @truncate(st.ino);
        self.uid = st.uid;
        self.gid = st.gid;
        self.size = @truncate(@as(u64, @bitCast(st.size)));
    }
};

pub fn compareName(a: []const u8, sa: u32, b: []const u8, sb: u32) std.math.Order {
    const o = std.mem.order(u8, a, b);
    if (o != .eq) return o;
    return std.math.order(sa, sb);
}

pub fn entryLess(_: void, a: Entry, b: Entry) bool {
    return compareName(a.path, a.stage(), b.path, b.stage()) == .lt;
}

/// mode for a file on disk
pub fn modeFromStat(st: os.Stat) u32 {
    if (st.isLnk()) return 0o120000;
    if (st.isDir()) return 0o160000;
    return if (st.mode & 0o100 != 0) 0o100755 else 0o100644;
}

/// canonicalize mode as in create_ce_mode / ce_mode_from_stat
pub fn ceModeFromStat(old: ?*const Entry, st: os.Stat) u32 {
    const trust_exec = repo_mod.cfg.getBool("core.filemode") orelse true;
    const has_symlinks = repo_mod.cfg.getBool("core.symlinks") orelse true;
    if (st.isReg()) {
        if (!has_symlinks) {
            if (old) |o| {
                if (o.mode == 0o120000) return o.mode;
            }
        }
        if (!trust_exec) {
            if (old) |o| {
                if (o.mode & 0o170000 == 0o100000) return o.mode;
            }
            return 0o100644;
        }
    }
    if (old) |o| {
        if (st.isDir() and o.mode == 0o160000) return 0o160000;
    }
    return modeFromStat(st);
}

pub fn canonMode(mode: u32) u32 {
    if (mode & 0o170000 == 0o100000) return if (mode & 0o100 != 0) 0o100755 else 0o100644;
    if (mode & 0o170000 == 0o120000) return 0o120000;
    if (mode & 0o170000 == 0o040000) return 0o040000;
    return 0o160000;
}

// ---------------- cache tree ----------------

pub const CacheTree = struct {
    name: []const u8 = "",
    entry_count: i32 = -1,
    oid: Oid = hash.zero,
    children: std.ArrayList(*CacheTree) = .empty,

    pub fn find(self: *CacheTree, name: []const u8) ?*CacheTree {
        for (self.children.items) |c| {
            if (util.eql(c.name, name)) return c;
        }
        return null;
    }

    pub fn findOrCreate(self: *CacheTree, name: []const u8) *CacheTree {
        if (self.find(name)) |c| return c;
        const c = gpa.create(CacheTree) catch util.oom();
        c.* = .{ .name = util.dupe(name) };
        // keep sorted by (len, name) as git's subtree_name_cmp
        var pos: usize = 0;
        while (pos < self.children.items.len) : (pos += 1) {
            const o = self.children.items[pos];
            if (subtreeLess(name, o.name)) break;
        }
        self.children.insert(gpa, pos, c) catch util.oom();
        return c;
    }

    pub fn invalidate(self: *CacheTree, path: []const u8) void {
        self.entry_count = -1;
        if (std.mem.indexOfScalar(u8, path, '/')) |sl| {
            if (self.find(path[0..sl])) |c| c.invalidate(path[sl + 1 ..]);
        }
    }
};

fn subtreeLess(a: []const u8, b: []const u8) bool {
    if (a.len != b.len) return a.len < b.len;
    return std.mem.order(u8, a, b) == .lt;
}

fn parseCacheTree(data: []const u8, pos: *usize) ?*CacheTree {
    const nul = std.mem.indexOfScalarPos(u8, data, pos.*, 0) orelse return null;
    const t = gpa.create(CacheTree) catch util.oom();
    t.* = .{ .name = data[pos.*..nul] };
    var p = nul + 1;
    const sp = std.mem.indexOfScalarPos(u8, data, p, ' ') orelse return null;
    t.entry_count = std.fmt.parseInt(i32, data[p..sp], 10) catch return null;
    p = sp + 1;
    const nl = std.mem.indexOfScalarPos(u8, data, p, '\n') orelse return null;
    const subtrees = std.fmt.parseInt(usize, data[p..nl], 10) catch return null;
    p = nl + 1;
    if (t.entry_count >= 0) {
        if (p + 20 > data.len) return null;
        t.oid = data[p..][0..20].*;
        p += 20;
    }
    pos.* = p;
    var i: usize = 0;
    while (i < subtrees) : (i += 1) {
        const c = parseCacheTree(data, pos) orelse return null;
        t.children.append(gpa, c) catch util.oom();
    }
    return t;
}

fn writeCacheTree(b: *util.Buf, t: *CacheTree) void {
    util.bufAppend(b, t.name);
    util.bufByte(b, 0);
    util.bufPrint(b, "{d} {d}\n", .{ t.entry_count, t.children.items.len });
    if (t.entry_count >= 0) util.bufAppend(b, &t.oid);
    for (t.children.items) |c| writeCacheTree(b, c);
}

// ---------------- resolve-undo ----------------

pub const Reuc = struct {
    path: []const u8,
    modes: [3]u32 = .{ 0, 0, 0 },
    oids: [3]Oid = .{ hash.zero, hash.zero, hash.zero },
};

// ---------------- index ----------------

pub const Index = struct {
    entries: std.ArrayList(Entry) = .empty,
    version: u32 = 2,
    cache_tree: ?*CacheTree = null,
    reuc: std.ArrayList(Reuc) = .empty,
    /// mtime of index file when read (racy-git detection)
    timestamp_s: u32 = 0,
    timestamp_ns: u32 = 0,
    path: []const u8 = "",
    lock: ?*lockfile.Lock = null,
    loaded_from_disk: bool = false,
    /// other extensions preserved verbatim (e.g. "link", "UNTR"): dropped for simplicity
    changed: bool = false,
    has_split: bool = false,

    // ---- lookup ----

    /// Binary search for path at stage. Returns index or -(insert_pos)-1 semantics via union.
    pub fn pos(self: *const Index, path: []const u8, stg: u32) union(enum) { found: usize, missing: usize } {
        var lo: usize = 0;
        var hi: usize = self.entries.items.len;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            const e = &self.entries.items[mid];
            switch (compareName(path, stg, e.path, e.stage())) {
                .eq => return .{ .found = mid },
                .lt => hi = mid,
                .gt => lo = mid + 1,
            }
        }
        return .{ .missing = lo };
    }

    pub fn findPos(self: *const Index, path: []const u8) ?usize {
        return switch (self.pos(path, 0)) {
            .found => |i| i,
            .missing => null,
        };
    }

    pub fn get(self: *Index, path: []const u8) ?*Entry {
        const i = self.findPos(path) orelse return null;
        return &self.entries.items[i];
    }

    /// First position with entry.path >= path (any stage)
    pub fn firstPos(self: *const Index, path: []const u8) usize {
        return switch (self.pos(path, 0)) {
            .found => |i| i,
            .missing => |i| i,
        };
    }

    /// Does any entry (any stage) have this exact path?
    pub fn hasPath(self: *const Index, path: []const u8) bool {
        const i = self.firstPos(path);
        return i < self.entries.items.len and util.eql(self.entries.items[i].path, path);
    }

    pub fn unmerged(self: *const Index) bool {
        for (self.entries.items) |e| {
            if (e.stage() != 0) return true;
        }
        return false;
    }

    pub fn invalidatePath(self: *Index, path: []const u8) void {
        if (self.cache_tree) |t| t.invalidate(path);
        self.changed = true;
    }

    pub fn removeAt(self: *Index, i: usize) void {
        self.invalidatePath(self.entries.items[i].path);
        _ = self.entries.orderedRemove(i);
        self.changed = true;
    }

    /// Remove all stages of path. Returns true if anything was removed.
    pub fn removePath(self: *Index, path: []const u8) bool {
        var i = self.firstPos(path);
        var any = false;
        while (i < self.entries.items.len and util.eql(self.entries.items[i].path, path)) {
            self.removeAt(i);
            any = true;
        }
        return any;
    }

    pub const AddOpts = struct {
        ok_to_add: bool = true,
        ok_to_replace: bool = true,
        skip_df_check: bool = false,
    };

    /// Add or replace an entry. Handles D/F conflicts when ok_to_replace. Returns false on error.
    pub fn add(self: *Index, e: Entry, opts: AddOpts) bool {
        self.invalidatePath(e.path);
        const stg = e.stage();
        switch (self.pos(e.path, stg)) {
            .found => |i| {
                self.entries.items[i] = e;
                return true;
            },
            .missing => |ins| {
                var at = ins;
                // adding stage 0 removes higher stages of the same path
                if (stg == 0) {
                    while (at < self.entries.items.len and util.eql(self.entries.items[at].path, e.path)) {
                        _ = self.entries.orderedRemove(at);
                    }
                }
                if (!opts.ok_to_add) return false;
                if (!opts.skip_df_check) {
                    if (!self.checkDF(e, opts.ok_to_replace)) return false;
                    at = switch (self.pos(e.path, stg)) {
                        .found => |i| i,
                        .missing => |i| i,
                    };
                }
                self.entries.insert(gpa, at, e) catch util.oom();
                return true;
            },
        }
    }

    /// Check directory/file conflicts. If replace, remove conflicting entries.
    fn checkDF(self: *Index, e: Entry, replace: bool) bool {
        const stg = e.stage();
        var conflict = false;
        // 1. a parent dir of e.path exists as a file
        var p: usize = 0;
        while (std.mem.indexOfScalarPos(u8, e.path, p, '/')) |sl| {
            const parent = e.path[0..sl];
            switch (self.pos(parent, stg)) {
                .found => |i| {
                    if (!replace) return false;
                    self.removeAt(i);
                    conflict = true;
                },
                .missing => {},
            }
            p = sl + 1;
        }
        // 2. e.path exists as a directory (entries under path/)
        const pref = util.concat(&.{ e.path, "/" });
        var i = self.firstPos(pref);
        while (i < self.entries.items.len and util.startsWith(self.entries.items[i].path, pref)) {
            if (self.entries.items[i].stage() != stg) {
                i += 1;
                continue;
            }
            if (!replace) return false;
            self.removeAt(i);
            conflict = true;
        }
        _ = conflict;
        return true;
    }

    // ---- reading ----

    pub fn readFile(self: *Index, path: []const u8) void {
        self.path = path;
        const data = os.readFile(path) orelse return;
        if (os.statPath(path)) |st| {
            self.timestamp_s = @truncate(@as(u64, @bitCast(st.mtime)));
            self.timestamp_ns = @truncate(@as(u64, @bitCast(st.mtime_ns)));
        }
        self.loaded_from_disk = true;
        self.parse(data, path);
    }

    fn parse(self: *Index, data: []const u8, path: []const u8) void {
        if (data.len < 12 + 20) util.die("index file smaller than expected", .{});
        if (!std.mem.eql(u8, data[0..4], "DIRC")) util.die("bad signature 0x{x:0>8}", .{std.mem.readInt(u32, data[0..4], .big)});
        const ver = std.mem.readInt(u32, data[4..8], .big);
        if (ver < 2 or ver > 4) util.die("bad index version {d}", .{ver});
        self.version = ver;
        const body = data[0 .. data.len - 20];
        var h = hash.Hasher.init(.{});
        h.update(body);
        var sum: Oid = undefined;
        h.final(&sum);
        if (!std.mem.eql(u8, &sum, data[data.len - 20 ..])) {
            if (!hash.isZero(data[data.len - 20 ..][0..20].*)) util.die("index file corrupt", .{});
        }
        const n = std.mem.readInt(u32, data[8..12], .big);
        var p: usize = 12;
        var prev_name: []const u8 = "";
        self.entries.ensureTotalCapacity(gpa, n) catch util.oom();
        var k: u32 = 0;
        while (k < n) : (k += 1) {
            if (p + 62 > body.len) util.die("index file corrupt", .{});
            var e = Entry{ .path = "" };
            const rd = struct {
                fn r(d: []const u8, o: usize) u32 {
                    return std.mem.readInt(u32, d[o..][0..4], .big);
                }
            }.r;
            e.ctime_s = rd(data, p);
            e.ctime_ns = rd(data, p + 4);
            e.mtime_s = rd(data, p + 8);
            e.mtime_ns = rd(data, p + 12);
            e.dev = rd(data, p + 16);
            e.ino = rd(data, p + 20);
            e.mode = rd(data, p + 24);
            e.uid = rd(data, p + 28);
            e.gid = rd(data, p + 32);
            e.size = rd(data, p + 36);
            e.oid = data[p + 40 ..][0..20].*;
            const flags = std.mem.readInt(u16, data[p + 60 ..][0..2], .big);
            e.flags = flags & ~CE_NAMEMASK;
            var q = p + 62;
            if (flags & CE_EXTENDED != 0) {
                if (ver < 3) util.die("index file corrupt", .{});
                e.ext_flags = std.mem.readInt(u16, data[q..][0..2], .big);
                q += 2;
            }
            e.flags &= ~CE_EXTENDED;
            if (ver == 4) {
                // varint strip length
                var strip: usize = 0;
                var c = data[q];
                q += 1;
                strip = c & 0x7f;
                while (c & 0x80 != 0) {
                    strip += 1;
                    c = data[q];
                    q += 1;
                    strip = (strip << 7) + (c & 0x7f);
                }
                const nul = std.mem.indexOfScalarPos(u8, data, q, 0) orelse util.die("index file corrupt", .{});
                if (strip > prev_name.len) util.die("malformed name field in the index, near path '{s}'", .{prev_name});
                const name = util.concat(&.{ prev_name[0 .. prev_name.len - strip], data[q..nul] });
                e.path = name;
                q = nul + 1;
                p = q;
            } else {
                const namelen = flags & CE_NAMEMASK;
                var nul: usize = undefined;
                if (namelen < CE_NAMEMASK) {
                    nul = q + namelen;
                } else {
                    nul = std.mem.indexOfScalarPos(u8, data, q, 0) orelse util.die("index file corrupt", .{});
                }
                e.path = data[q..nul];
                const entsize = ((q - p) + (nul - q) + 8) & ~@as(usize, 7);
                p += entsize;
            }
            prev_name = e.path;
            self.entries.appendAssumeCapacity(e);
        }
        // extensions
        while (p + 8 <= body.len) {
            const sig = data[p..][0..4];
            const sz = std.mem.readInt(u32, data[p + 4 ..][0..4], .big);
            const ext = data[p + 8 .. @min(body.len, p + 8 + sz)];
            if (std.mem.eql(u8, sig, "TREE")) {
                var tp: usize = 0;
                self.cache_tree = parseCacheTree(ext, &tp);
            } else if (std.mem.eql(u8, sig, "REUC")) {
                self.parseReuc(ext);
            } else if (std.mem.eql(u8, sig, "link")) {
                self.has_split = true;
                util.die("split index not supported in {s}", .{path});
            } else if (sig[0] >= 'A' and sig[0] <= 'Z') {
                // optional extension: ignore
            } else {
                util.die("index uses {s} extension, which we do not understand", .{sig});
            }
            p += 8 + sz;
        }
    }

    fn parseReuc(self: *Index, d: []const u8) void {
        var p: usize = 0;
        while (p < d.len) {
            const nul = std.mem.indexOfScalarPos(u8, d, p, 0) orelse return;
            var r = Reuc{ .path = d[p..nul] };
            p = nul + 1;
            var i: usize = 0;
            while (i < 3) : (i += 1) {
                const n2 = std.mem.indexOfScalarPos(u8, d, p, 0) orelse return;
                r.modes[i] = std.fmt.parseInt(u32, d[p..n2], 8) catch return;
                p = n2 + 1;
            }
            i = 0;
            while (i < 3) : (i += 1) {
                if (r.modes[i] != 0) {
                    r.oids[i] = d[p..][0..20].*;
                    p += 20;
                }
            }
            self.reuc.append(gpa, r) catch util.oom();
        }
    }

    // ---- writing ----

    fn serialize(self: *Index) []u8 {
        var b: util.Buf = .empty;
        var ver = self.version;
        var need_ext = false;
        var count: u32 = 0;
        for (self.entries.items) |e| {
            if (e.removed) continue;
            count += 1;
            if (e.ext_flags != 0) need_ext = true;
        }
        if (need_ext and ver < 3) ver = 3;
        if (!need_ext and ver == 3) ver = 2;
        self.version = ver;
        util.bufAppend(&b, "DIRC");
        var tmp: [4]u8 = undefined;
        std.mem.writeInt(u32, &tmp, ver, .big);
        util.bufAppend(&b, &tmp);
        std.mem.writeInt(u32, &tmp, count, .big);
        util.bufAppend(&b, &tmp);
        var prev: []const u8 = "";
        for (self.entries.items) |*e| {
            if (e.removed) continue;
            const start = b.items.len;
            for ([_]u32{ e.ctime_s, e.ctime_ns, e.mtime_s, e.mtime_ns, e.dev, e.ino, e.mode, e.uid, e.gid, e.size }) |v| {
                std.mem.writeInt(u32, &tmp, v, .big);
                util.bufAppend(&b, &tmp);
            }
            util.bufAppend(&b, &e.oid);
            var flags: u16 = e.flags & ~(CE_NAMEMASK | CE_EXTENDED);
            flags |= @intCast(@min(e.path.len, CE_NAMEMASK));
            if (e.ext_flags != 0) flags |= CE_EXTENDED;
            var t2: [2]u8 = undefined;
            std.mem.writeInt(u16, &t2, flags, .big);
            util.bufAppend(&b, &t2);
            if (e.ext_flags != 0) {
                std.mem.writeInt(u16, &t2, e.ext_flags, .big);
                util.bufAppend(&b, &t2);
            }
            if (ver == 4) {
                var common: usize = 0;
                while (common < prev.len and common < e.path.len and prev[common] == e.path[common]) common += 1;
                const strip = prev.len - common;
                writeVarint(&b, strip);
                util.bufAppend(&b, e.path[common..]);
                util.bufByte(&b, 0);
                prev = e.path;
            } else {
                util.bufAppend(&b, e.path);
                const len = b.items.len - start;
                const padded = (len + 8) & ~@as(usize, 7);
                b.appendNTimes(gpa, 0, padded - len) catch util.oom();
            }
        }
        if (self.cache_tree) |t| {
            var tb: util.Buf = .empty;
            writeCacheTree(&tb, t);
            util.bufAppend(&b, "TREE");
            std.mem.writeInt(u32, &tmp, @intCast(tb.items.len), .big);
            util.bufAppend(&b, &tmp);
            util.bufAppend(&b, tb.items);
        }
        if (self.reuc.items.len > 0) {
            var rb: util.Buf = .empty;
            for (self.reuc.items) |r| {
                util.bufAppend(&rb, r.path);
                util.bufByte(&rb, 0);
                for (r.modes) |m| util.bufPrint(&rb, "{o}\x00", .{m});
                for (r.modes, 0..) |m, i| {
                    if (m != 0) util.bufAppend(&rb, &r.oids[i]);
                }
            }
            util.bufAppend(&b, "REUC");
            std.mem.writeInt(u32, &tmp, @intCast(rb.items.len), .big);
            util.bufAppend(&b, &tmp);
            util.bufAppend(&b, rb.items);
        }
        var h = hash.Hasher.init(.{});
        h.update(b.items);
        var sum: Oid = undefined;
        h.final(&sum);
        util.bufAppend(&b, &sum);
        return b.items;
    }

    /// Smudge racily clean entries before writing (ce_smudge_racily_clean_entry).
    fn smudgeRacy(self: *Index, now_s: u32) void {
        for (self.entries.items) |*e| {
            if (e.removed or e.stage() != 0) continue;
            if (e.mtime_s < now_s) continue;
            if (e.size == 0) continue;
            const wt = repo_mod.repo().work_tree orelse return;
            _ = wt;
            const st = os.lstatPath(e.path) orelse continue;
            if (matchStatBasic(e, st) != 0) continue;
            if (contentChanged(e, st)) e.size = 0;
        }
    }

    pub fn lockIndex(self: *Index) void {
        if (self.lock != null) return;
        self.lock = lockfile.lockOrDie(self.path);
    }

    /// Write index to its lock file and commit.
    pub fn write(self: *Index) void {
        if (self.lock == null) self.lockIndex();
        const l = self.lock.?;
        // determine index version
        if (!self.loaded_from_disk) {
            self.version = defaultVersion();
        }
        // racy check: timestamp of the new index file ~ now
        const now: u32 = @intCast(os.now());
        if (repo_mod.repo().work_tree != null) self.smudgeRacy(now);
        const data = self.serialize();
        l.write(data);
        if (!l.commit()) util.dieErrno("unable to write new index file", .{});
        self.lock = null;
        if (os.statPath(self.path)) |st| {
            self.timestamp_s = @truncate(@as(u64, @bitCast(st.mtime)));
            self.timestamp_ns = @truncate(@as(u64, @bitCast(st.mtime_ns)));
        }
    }

    pub fn rollback(self: *Index) void {
        if (self.lock) |l| l.rollback();
        self.lock = null;
    }

    pub fn isRacy(self: *const Index, e: *const Entry) bool {
        return self.timestamp_s != 0 and self.timestamp_s <= e.mtime_s;
    }

    /// ie_match_stat: returns 0 if entry matches the stat info (and contents for racy entries).
    pub fn matchStat(self: *const Index, e: *const Entry, st: os.Stat, racy_is_dirty: bool) u32 {
        if (e.skipWorktree()) return 0;
        if (e.assumeValid()) return 0;
        if (e.intentToAdd()) return DATA_CHANGED | TYPE_CHANGED | MODE_CHANGED;
        var changed = matchStatBasic(e, st);
        if (changed == 0 and self.isRacy(e)) {
            if (racy_is_dirty) {
                changed |= DATA_CHANGED;
            } else if (contentChanged(e, st)) changed |= DATA_CHANGED;
        }
        return changed;
    }

    /// Like ie_modified: stat check then content check if stat differs only in metadata.
    pub fn modified(self: *const Index, e: *const Entry, st: os.Stat) bool {
        const changed = self.matchStat(e, st, false);
        if (changed == 0) return false;
        if (changed & (MODE_CHANGED | TYPE_CHANGED) != 0) return true;
        // racily-smudged entries (size 0) need content check too
        if (changed & DATA_CHANGED != 0 and e.size != 0) return true;
        return contentChanged(e, st);
    }

    /// Recompute tree objects for the whole index (write-tree). Returns root oid.
    pub fn writeTree(self: *Index, missing_ok: bool) ?Oid {
        if (self.unmerged()) return null;
        if (self.cache_tree == null) {
            const t = gpa.create(CacheTree) catch util.oom();
            t.* = .{};
            self.cache_tree = t;
        }
        var i: usize = 0;
        const r = self.updateTree(self.cache_tree.?, "", &i, missing_ok) orelse return null;
        return r;
    }

    fn updateTree(self: *Index, t: *CacheTree, base: []const u8, i: *usize, missing_ok: bool) ?Oid {
        const start = i.*;
        // find range of entries under base
        var end = start;
        while (end < self.entries.items.len and util.startsWith(self.entries.items[end].path, base)) end += 1;
        if (t.entry_count >= 0 and odbHas(t.oid)) {
            // still valid; but make sure count matches
            if (@as(usize, @intCast(t.entry_count)) == countNonRemoved(self.entries.items[start..end])) {
                i.* = end;
                return t.oid;
            }
        }
        var tes: std.ArrayList(objects.TreeEntry) = .empty;
        var seen_children: std.ArrayList(*CacheTree) = .empty;
        var k = start;
        var count: usize = 0;
        while (k < end) {
            const e = &self.entries.items[k];
            if (e.removed) {
                k += 1;
                continue;
            }
            const rel = e.path[base.len..];
            if (std.mem.indexOfScalar(u8, rel, '/')) |sl| {
                const dname = rel[0..sl];
                const sub = t.findOrCreate(dname);
                seen_children.append(gpa, sub) catch util.oom();
                var kk = k;
                const sub_base = util.concat(&.{ base, dname, "/" });
                const before = kk;
                const oid = self.updateTree(sub, sub_base, &kk, missing_ok) orelse return null;
                _ = before;
                count += @intCast(@max(sub.entry_count, 0));
                // an empty subtree (only intent-to-add entries) is omitted
                if (!(sub.entry_count == 0 and hash.eql(oid, emptyTreeOid()) and allItaUnder(self.entries.items[k..kk]))) {
                    tes.append(gpa, .{ .mode = 0o40000, .name = dname, .oid = oid }) catch util.oom();
                }
                k = kk;
            } else {
                count += 1;
                if (e.intentToAdd()) {
                    k += 1;
                    continue;
                }
                if (!missing_ok and e.mode != 0o160000 and !odbHas(e.oid)) {
                    util.err("invalid object {o} {s} for '{s}'", .{ e.mode, &hash.hex(e.oid), e.path });
                    return null;
                }
                tes.append(gpa, .{ .mode = e.mode, .name = rel, .oid = e.oid }) catch util.oom();
                k += 1;
            }
        }
        // drop stale children
        var ci: usize = 0;
        while (ci < t.children.items.len) {
            var found = false;
            for (seen_children.items) |s| {
                if (s == t.children.items[ci]) found = true;
            }
            if (!found) {
                _ = t.children.orderedRemove(ci);
            } else ci += 1;
        }
        const data = objects.formatTree(tes.items);
        const oid = repo_mod.repo().odb().write(.tree, data);
        t.oid = oid;
        t.entry_count = @intCast(count);
        i.* = end;
        return oid;
    }
};

fn allItaUnder(es: []const Entry) bool {
    for (es) |e| {
        if (!e.intentToAdd()) return false;
    }
    return true;
}

fn countNonRemoved(es: []const Entry) usize {
    var n: usize = 0;
    for (es) |e| {
        if (!e.removed) n += 1;
    }
    return n;
}

var empty_tree_cache: ?Oid = null;
fn emptyTreeOid() Oid {
    if (empty_tree_cache == null) empty_tree_cache = hash.fromHex(hash.empty_tree_hex).?;
    return empty_tree_cache.?;
}

fn odbHas(oid: Oid) bool {
    return repo_mod.repo().odb().has(oid);
}

fn writeVarint(b: *util.Buf, value0: usize) void {
    var varint: [16]u8 = undefined;
    var value = value0;
    var p: usize = varint.len - 1;
    varint[p] = @intCast(value & 127);
    while (true) {
        value >>= 7;
        if (value == 0) break;
        value -= 1;
        p -= 1;
        varint[p] = @intCast(128 | (value & 127));
    }
    util.bufAppend(b, varint[p..]);
}

pub const MTIME_CHANGED: u32 = 0x0001;
pub const CTIME_CHANGED: u32 = 0x0002;
pub const OWNER_CHANGED: u32 = 0x0004;
pub const MODE_CHANGED: u32 = 0x0008;
pub const INODE_CHANGED: u32 = 0x0010;
pub const DATA_CHANGED: u32 = 0x0020;
pub const TYPE_CHANGED: u32 = 0x0040;

pub fn matchStatBasic(e: *const Entry, st: os.Stat) u32 {
    var changed: u32 = 0;
    const trust_exec = repo_mod.cfg.getBool("core.filemode") orelse true;
    const has_symlinks = repo_mod.cfg.getBool("core.symlinks") orelse true;
    switch (e.mode & 0o170000) {
        0o100000 => {
            if (!st.isReg()) changed |= TYPE_CHANGED;
            if (trust_exec and (0o100 & (e.mode ^ st.mode)) != 0) changed |= MODE_CHANGED;
        },
        0o120000 => {
            if (!st.isLnk() and (has_symlinks or !st.isReg())) changed |= TYPE_CHANGED;
        },
        0o160000 => {
            if (!st.isDir()) changed |= TYPE_CHANGED;
            return changed;
        },
        else => return TYPE_CHANGED,
    }
    changed |= matchStatData(e, st);
    if (e.size == 0) {
        if (!util.eql(&hash.hex(e.oid), hash.empty_blob_hex)) changed |= DATA_CHANGED;
    }
    return changed;
}

pub fn matchStatData(e: *const Entry, st: os.Stat) u32 {
    var changed: u32 = 0;
    const trust_ctime = repo_mod.cfg.getBool("core.trustctime") orelse true;
    const check_stat_s = repo_mod.cfg.get("core.checkstat") orelse "default";
    const check_stat = !util.eql(check_stat_s, "minimal");
    if (e.mtime_s != @as(u32, @truncate(@as(u64, @bitCast(st.mtime))))) changed |= MTIME_CHANGED;
    if (trust_ctime and check_stat and e.ctime_s != @as(u32, @truncate(@as(u64, @bitCast(st.ctime))))) changed |= CTIME_CHANGED;
    if (check_stat) {
        if (e.uid != st.uid or e.gid != st.gid) changed |= OWNER_CHANGED;
        if (e.ino != @as(u32, @truncate(st.ino))) changed |= INODE_CHANGED;
    }
    if (e.size != @as(u32, @truncate(@as(u64, @bitCast(st.size))))) changed |= DATA_CHANGED;
    return changed;
}

/// Compare file content against entry's blob.
pub fn contentChanged(e: *const Entry, st: os.Stat) bool {
    switch (e.mode & 0o170000) {
        0o100000 => {
            if (!st.isReg()) return true;
            const oid = hashWorktreeFile(e.path, st, e.mode) orelse return true;
            return !hash.eql(oid, e.oid);
        },
        0o120000 => {
            if (st.isLnk()) {
                const t = os.readLink(e.path) orelse return true;
                return !hash.eql(odb_mod.hashObject(.blob, t), e.oid);
            }
            const data = os.readFile(e.path) orelse return true;
            return !hash.eql(odb_mod.hashObject(.blob, data), e.oid);
        },
        0o160000 => {
            if (!st.isDir()) return true;
            const head = gitlinkHead(e.path) orelse return false;
            return !hash.eql(head, e.oid);
        },
        else => return true,
    }
}

/// HEAD commit of a submodule checkout (for gitlink comparison)
pub fn gitlinkHead(path: []const u8) ?Oid {
    const dotgit = util.concat(&.{ path, "/.git" });
    var gd: []const u8 = dotgit;
    if (os.isFile(dotgit)) {
        const data = os.readFile(dotgit) orelse return null;
        const rest = util.skipPrefix(data, "gitdir: ") orelse return null;
        const p = util.trimRight(rest);
        gd = if (p.len > 0 and p[0] == '/') p else util.concat(&.{ path, "/", p });
    } else if (!os.isDir(dotgit)) return null;
    var name: []const u8 = "HEAD";
    var depth: usize = 0;
    while (depth < 10) : (depth += 1) {
        const data = os.readFile(util.concat(&.{ gd, "/", name })) orelse {
            // packed?
            const pk = os.readFile(util.concat(&.{ gd, "/packed-refs" })) orelse return null;
            var it = std.mem.splitScalar(u8, pk, '\n');
            while (it.next()) |line| {
                if (line.len > 41 and util.eql(line[41..], name)) return hash.fromHex(line[0..40]);
            }
            return null;
        };
        const t = util.trimRight(data);
        if (util.skipPrefix(t, "ref: ")) |r| {
            name = r;
            continue;
        }
        return hash.fromHex(t);
    }
    return null;
}

/// Hash a worktree file as a blob applying conversion (crlf/filters).
pub fn hashWorktreeFile(path: []const u8, st: os.Stat, mode: u32) ?Oid {
    _ = mode;
    if (st.isLnk()) {
        const t = os.readLink(path) orelse return null;
        return odb_mod.hashObject(.blob, t);
    }
    const data = os.readFile(path) orelse return null;
    const conv = @import("convert.zig");
    const converted = conv.toGit(path, data);
    return odb_mod.hashObject(.blob, converted);
}

pub fn defaultVersion() u32 {
    if (os.getenv("GIT_INDEX_VERSION")) |v| {
        const n = std.fmt.parseInt(u32, v, 10) catch 0;
        if (n >= 2 and n <= 4) return n;
        util.warn("GIT_INDEX_VERSION set, but the value is invalid.\nUsing version {d}", .{@as(u32, 2)});
        return 2;
    }
    if (repo_mod.cfg.getInt("index.version")) |v| {
        if (v >= 2 and v <= 4) return @intCast(v);
        util.warn("index.version set, but the value is invalid.\nUsing version {d}", .{@as(u32, 2)});
        return 2;
    }
    if (repo_mod.cfg.getBool("feature.manyfiles") orelse false) return 4;
    return 2;
}

// ---------------- global index ----------------

var the_index: ?*Index = null;

/// Read the repository index (cached).
pub fn get() *Index {
    if (the_index) |i| return i;
    const idx = gpa.create(Index) catch util.oom();
    idx.* = .{};
    idx.readFile(repo_mod.repo().indexPath());
    if (!idx.loaded_from_disk) idx.version = defaultVersion();
    the_index = idx;
    return idx;
}

/// Lock and read the index fresh (for modifications).
pub fn lockAndRead() *Index {
    const path = repo_mod.repo().indexPath();
    const l = lockfile.lockOrDie(path);
    const idx = gpa.create(Index) catch util.oom();
    idx.* = .{};
    idx.readFile(path);
    if (!idx.loaded_from_disk) idx.version = defaultVersion();
    idx.lock = l;
    the_index = idx;
    return idx;
}

pub fn readFrom(path: []const u8) *Index {
    const idx = gpa.create(Index) catch util.oom();
    idx.* = .{};
    idx.readFile(path);
    return idx;
}

pub fn discard() void {
    the_index = null;
}

/// Build an Entry for a worktree path from lstat; returns null if missing.
pub fn entryFromFile(path: []const u8, st: os.Stat, old: ?*const Entry, write_object: bool) ?Entry {
    var e = Entry{ .path = path };
    e.fillStat(st);
    e.mode = ceModeFromStat(old, st);
    if (st.isDir()) {
        e.oid = gitlinkHead(path) orelse return null;
        return e;
    }
    if (st.isLnk()) {
        const t = os.readLink(path) orelse return null;
        e.oid = if (write_object) repo_mod.repo().odb().write(.blob, t) else odb_mod.hashObject(.blob, t);
        return e;
    }
    const data = os.readFile(path) orelse return null;
    const conv = @import("convert.zig");
    const converted = conv.toGitChecked(path, data, write_object);
    e.oid = if (write_object) repo_mod.repo().odb().write(.blob, converted) else odb_mod.hashObject(.blob, converted);
    return e;
}

/// Read a tree into an index (stage 0), like read_tree.
pub fn addTreeRecursive(idx: *Index, tree: Oid, base: []const u8, stage: u32) void {
    const entries = objects.readTree(tree) orelse return;
    for (entries) |te| {
        const p = util.concat(&.{ base, te.name });
        if (te.isDir()) {
            addTreeRecursive(idx, te.oid, util.concat(&.{ p, "/" }), stage);
        } else {
            var e = Entry{ .path = p, .mode = te.mode, .oid = te.oid };
            e.setStage(stage);
            idx.entries.append(gpa, e) catch util.oom();
        }
    }
}

/// Replace index contents with the given tree (read-tree <tree>), keeping stat info where unchanged.
pub fn resetToTree(idx: *Index, tree: ?Oid) void {
    var old = idx.entries;
    idx.entries = .empty;
    if (tree) |t| addTreeRecursive(idx, t, "", 0);
    std.mem.sort(Entry, idx.entries.items, {}, entryLess);
    // carry over stat data
    var j: usize = 0;
    for (idx.entries.items) |*e| {
        while (j < old.items.len and compareName(old.items[j].path, old.items[j].stage(), e.path, 0) == .lt) j += 1;
        if (j < old.items.len and util.eql(old.items[j].path, e.path) and old.items[j].stage() == 0) {
            const o = old.items[j];
            if (hash.eql(o.oid, e.oid) and o.mode == e.mode) {
                var n = o;
                n.path = e.path;
                n.ext_flags &= ~CE_INTENT_TO_ADD;
                e.* = n;
            }
        }
    }
    old.deinit(gpa);
    idx.cache_tree = null;
    if (tree) |t| primeCacheTree(idx, t);
    idx.changed = true;
}

/// Fill cache tree from a tree object (prime_cache_tree).
pub fn primeCacheTree(idx: *Index, tree: Oid) void {
    const t = gpa.create(CacheTree) catch util.oom();
    t.* = .{};
    primeRec(t, tree);
    idx.cache_tree = t;
}

fn primeRec(t: *CacheTree, tree: Oid) void {
    t.oid = tree;
    const entries = objects.readTree(tree) orelse return;
    var cnt: i32 = 0;
    for (entries) |te| {
        if (te.isDir()) {
            const sub = t.findOrCreate(te.name);
            primeRec(sub, te.oid);
            cnt += sub.entry_count;
        } else cnt += 1;
    }
    t.entry_count = cnt;
}
