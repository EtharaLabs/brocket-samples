//! Lock files: path.lock created with O_EXCL, committed by rename.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");

pub const Lock = struct {
    path: []const u8,
    lock_path: []const u8,
    fd: c_int,
    active: bool = true,

    pub fn write(self: *Lock, data: []const u8) void {
        os.writeAll(self.fd, data) catch util.dieErrno("could not write to '{s}'", .{self.lock_path});
    }

    pub fn commit(self: *Lock) bool {
        if (!self.active) return false;
        if (self.fd >= 0) os.close(self.fd);
        self.fd = -1;
        self.active = false;
        unregister(self);
        return os.rename(self.lock_path, self.path);
    }

    pub fn rollback(self: *Lock) void {
        if (!self.active) return;
        if (self.fd >= 0) os.close(self.fd);
        self.fd = -1;
        _ = os.unlink(self.lock_path);
        self.active = false;
        unregister(self);
    }
};

var active_locks: std.ArrayList(*Lock) = .empty;

fn unregister(l: *Lock) void {
    for (active_locks.items, 0..) |x, i| {
        if (x == l) {
            _ = active_locks.swapRemove(i);
            return;
        }
    }
}

/// Remove all active lock files (called at exit/die).
pub fn cleanupAll() void {
    for (active_locks.items) |l| {
        if (l.active) {
            if (l.fd >= 0) os.close(l.fd);
            _ = os.unlink(l.lock_path);
            l.active = false;
        }
    }
    active_locks.clearRetainingCapacity();
}

fn absolutePath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return p;
    return util.normalizePath(util.joinPath(os.getcwd(), p)) orelse p;
}

pub fn lockMessage(path: []const u8, e: c_int) []const u8 {
    const abs = absolutePath(path);
    if (e == os.EEXIST) {
        return util.fmt("Unable to create '{s}.lock': {s}.\n\nAnother git process seems to be running in this repository, or the lock file may be stale", .{ abs, os.strErr(e) });
    }
    return util.fmt("Unable to create '{s}.lock': {s}", .{ abs, os.strErr(e) });
}

/// Try to acquire a lock. Returns null on failure (errno preserved in .err).
pub fn tryLock(path: []const u8) union(enum) { ok: *Lock, err: c_int } {
    const lp = util.concat(&.{ path, ".lock" });
    const fd = os.openFile(lp, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o666);
    if (fd < 0) return .{ .err = os.errno() };
    const l = util.gpa.create(Lock) catch util.oom();
    l.* = .{ .path = path, .lock_path = lp, .fd = fd };
    active_locks.append(util.gpa, l) catch util.oom();
    return .{ .ok = l };
}

pub fn lockOrDie(path: []const u8) *Lock {
    switch (tryLock(path)) {
        .ok => |l| return l,
        .err => |e| util.die("{s}", .{lockMessage(path, e)}),
    }
}
