//! Builtin command table and dispatch (port of git.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const main = @import("main.zig");
const gpa = util.gpa;

pub const Fn = *const fn (args: []const []const u8) u8;

pub const RUN_SETUP: u8 = 1;
pub const RUN_SETUP_GENTLY: u8 = 2;
pub const USE_PAGER: u8 = 4;
pub const NEED_WORK_TREE: u8 = 8;
pub const NO_PARSEOPT: u8 = 16;

pub const Cmd = struct { name: []const u8, f: Fn, flags: u8 };

const c_init = @import("cmd/init.zig");
const c_misc = @import("cmd/misc.zig");

pub const table = [_]Cmd{
    .{ .name = "init", .f = c_init.cmdInit, .flags = 0 },
    .{ .name = "init-db", .f = c_init.cmdInit, .flags = 0 },
    .{ .name = "version", .f = c_misc.cmdVersion, .flags = RUN_SETUP_GENTLY },
    .{ .name = "help", .f = c_misc.cmdHelp, .flags = 0 },
};

pub fn find(name: []const u8) ?*const Cmd {
    for (&table) |*c| {
        if (util.eql(c.name, name)) return c;
    }
    return null;
}

pub fn listCommands() void {
    for (table) |c| util.outf("{s}\n", .{c.name});
}

pub fn dispatchName(name: []const u8, args: []const []const u8) u8 {
    var l: std.ArrayList([]const u8) = .empty;
    l.append(gpa, name) catch util.oom();
    l.appendSlice(gpa, args) catch util.oom();
    return dispatch(l.items);
}

fn runBuiltin(c: *const Cmd, args: []const []const u8) u8 {
    const help = args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"));
    if (c.flags & RUN_SETUP != 0 and !help) {
        repo_mod.setup(false);
    } else if (c.flags & (RUN_SETUP | RUN_SETUP_GENTLY) != 0) {
        repo_mod.setup(true);
    } else {
        // commands not needing setup still read config lazily
        repo_mod.loadConfig();
    }
    if (c.flags & NEED_WORK_TREE != 0 and !help) {
        _ = repo_mod.requireWorkTree(c.name);
    }
    if (repo_mod.repo_) |r| {
        @import("parseopt.zig").prefix = r.prefix;
    }
    const pager_on = main.use_pager orelse false;
    if (pager_on) setupPager();
    return c.f(args);
}

pub fn setupPager() void {
    if (!os.isatty(1)) return;
    const pager = os.getenv("GIT_PAGER") orelse repo_mod.cfg.get("core.pager") orelse os.getenv("PAGER") orelse "less";
    if (pager.len == 0 or util.eql(pager, "cat")) return;
    util.flushStdout();
    os.startPager(pager);
}

fn splitCmdline(s: []const u8) ?[][]const u8 {
    var res: std.ArrayList([]const u8) = .empty;
    var cur: util.Buf = .empty;
    var in_word = false;
    var quote: u8 = 0;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        const ch = s[i];
        if (quote != 0) {
            if (ch == quote) {
                quote = 0;
            } else if (ch == '\\' and quote == '"' and i + 1 < s.len) {
                i += 1;
                util.bufByte(&cur, s[i]);
            } else util.bufByte(&cur, ch);
            continue;
        }
        if (std.ascii.isWhitespace(ch)) {
            if (in_word) {
                res.append(gpa, util.dupe(cur.items)) catch util.oom();
                cur = .empty;
                in_word = false;
            }
            continue;
        }
        in_word = true;
        if (ch == '"' or ch == '\'') {
            quote = ch;
        } else if (ch == '\\' and i + 1 < s.len) {
            i += 1;
            util.bufByte(&cur, s[i]);
        } else util.bufByte(&cur, ch);
    }
    if (quote != 0) return null;
    if (in_word) res.append(gpa, cur.items) catch util.oom();
    return res.items;
}

fn findExternal(name: []const u8) ?[]const u8 {
    const exe = util.concat(&.{ "git-", name });
    if (main.exec_path.len > 0) {
        const p = util.concat(&.{ main.exec_path, "/", exe });
        if (os.access(p, 1) and !os.isDir(p)) {
            // avoid finding ourselves for builtins
            return p;
        }
    }
    const path = os.getenv("PATH") orelse return null;
    var it = std.mem.splitScalar(u8, path, ':');
    while (it.next()) |d| {
        const dir = if (d.len == 0) "." else d;
        const p = util.concat(&.{ dir, "/", exe });
        if (os.access(p, 1) and !os.isDir(p)) return p;
    }
    return null;
}

pub fn dispatch(args_in: []const []const u8) u8 {
    var args = args_in;
    var seen: std.ArrayList([]const u8) = .empty;
    while (true) {
        const name = args[0];
        if (find(name)) |c| return runBuiltin(c, args);
        // external command?
        if (findExternal(name)) |p| {
            // make sure PATH includes exec_path
            var a: std.ArrayList([]const u8) = .empty;
            a.append(gpa, p) catch util.oom();
            a.appendSlice(gpa, args[1..]) catch util.oom();
            util.flushStdout();
            const r = os.run(a.items, .{});
            if (r.signaled) return 128 + @as(u8, @intCast(r.status & 0x7f));
            return @intCast(r.status & 0xff);
        }
        // alias?
        repo_mod.setup(true);
        const alias = repo_mod.cfg.get(util.concat(&.{ "alias.", name })) orelse aliasSubsection(name);
        if (alias) |a| {
            for (seen.items) |s| {
                if (util.eql(s, name)) {
                    var b: util.Buf = .empty;
                    for (seen.items) |s2| util.bufPrint(&b, "\n  {s}", .{s2});
                    util.bufPrint(&b, "\n  {s} <==", .{name});
                    util.die("recursive alias: {s}{s}", .{ seen.items[0], "" });
                }
            }
            seen.append(gpa, name) catch util.oom();
            if (a.len > 0 and a[0] == '!') {
                // shell alias
                var argv: std.ArrayList([]const u8) = .empty;
                argv.append(gpa, a[1..]) catch util.oom();
                argv.appendSlice(gpa, args[1..]) catch util.oom();
                util.flushStdout();
                // run relative to the top of the worktree
                if (repo_mod.repo_) |r| {
                    if (r.work_tree != null and r.prefix.len > 0) {
                        // setup chdir'ed to top already
                    }
                }
                const r = os.run(argv.items, .{ .use_shell = true });
                if (r.signaled) return 128 + @as(u8, @intCast(r.status & 0x7f));
                return @intCast(r.status & 0xff);
            }
            const words = splitCmdline(a) orelse util.die("bad alias.{s} string: unclosed quote", .{name});
            if (words.len == 0) util.die("empty alias for {s}", .{name});
            var na: std.ArrayList([]const u8) = .empty;
            na.appendSlice(gpa, words) catch util.oom();
            na.appendSlice(gpa, args[1..]) catch util.oom();
            args = na.items;
            continue;
        }
        util.eprint("git: '{s}' is not a git command. See 'git --help'.\n", .{name});
        return 1;
    }
}

fn aliasSubsection(name: []const u8) ?[]const u8 {
    return repo_mod.cfg.get(util.concat(&.{ "alias.", name, ".command" }));
}
