//! References: files backend with packed-refs and reflogs.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const ident = @import("ident.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const Ref = struct {
    name: []const u8,
    oid: Oid,
    symref: ?[]const u8 = null, // target if symbolic
    peeled: ?Oid = null,
};

fn isPerWorktree(name: []const u8) bool {
    if (std.mem.indexOfScalar(u8, name, '/') == null) return true; // HEAD, ORIG_HEAD etc
    return util.startsWith(name, "refs/bisect/") or util.startsWith(name, "refs/worktree/") or util.startsWith(name, "refs/rewritten/");
}

pub fn refPath(name: []const u8) []u8 {
    const r = repo_mod.repo();
    if (util.skipPrefix(name, "main-worktree/")) |rest| return r.commonPath(rest);
    if (util.startsWith(name, "worktrees/")) {
        const rest = name["worktrees/".len..];
        if (std.mem.indexOfScalar(u8, rest, '/')) |sl| {
            return util.concat(&.{ r.common_dir, "/worktrees/", rest[0..sl], "/", rest[sl + 1 ..] });
        }
    }
    if (isPerWorktree(name)) return r.gitPath(name);
    return r.commonPath(name);
}

fn logPath(name: []const u8) []u8 {
    const r = repo_mod.repo();
    if (isPerWorktree(name)) return r.gitPath(util.concat(&.{ "logs/", name }));
    return r.commonPath(util.concat(&.{ "logs/", name }));
}

// ---------------- refname validation ----------------

pub const ALLOW_ONELEVEL: u32 = 1;
pub const REFSPEC_PATTERN: u32 = 2;

fn disposition(ch: u8) u8 {
    if (ch == '/' or ch == 0) return 1;
    if (ch == '.') return 2;
    if (ch == '{') return 3;
    if (ch < 0x20 or ch == 0x7f or ch == ' ' or ch == '~' or ch == '^' or ch == ':' or ch == '?' or ch == '[' or ch == '\\') return 4;
    if (ch == '*') return 5;
    return 0;
}

pub fn checkRefnameFormat(name: []const u8, flags0: u32) bool {
    var flags = flags0;
    if (util.eql(name, "@")) return false;
    if (name.len == 0) return false;
    var count: usize = 0;
    var i: usize = 0;
    var last_comp_end: usize = 0;
    while (true) {
        // component starting at i
        const start = i;
        var last: u8 = 0;
        while (i < name.len and name[i] != '/') : (i += 1) {
            const ch = name[i];
            switch (disposition(ch)) {
                2 => if (last == '.') return false,
                3 => if (last == '@') return false,
                4 => return false,
                5 => {
                    if (flags & REFSPEC_PATTERN == 0) return false;
                    flags &= ~REFSPEC_PATTERN;
                },
                else => {},
            }
            last = ch;
        }
        const comp = name[start..i];
        if (comp.len == 0) return false;
        if (comp[0] == '.') return false;
        if (util.endsWith(comp, ".lock")) return false;
        count += 1;
        last_comp_end = i;
        if (i >= name.len) break;
        i += 1;
        if (i >= name.len) return false; // trailing slash
    }
    if (name[last_comp_end - 1] == '.') return false;
    if (flags & ALLOW_ONELEVEL == 0 and count < 2) return false;
    return true;
}

// ---------------- reading ----------------

pub const PackedRef = struct { name: []const u8, oid: Oid, peeled: ?Oid };

var packed_cache: ?[]PackedRef = null;

pub fn invalidatePacked() void {
    packed_cache = null;
}

pub fn packedRefs() []PackedRef {
    if (packed_cache) |p| return p;
    var plist: std.ArrayList(PackedRef) = .empty;
    const r = repo_mod.repo();
    if (os.readFile(r.commonPath("packed-refs"))) |data| {
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line| {
            if (line.len == 0 or line[0] == '#') continue;
            if (line[0] == '^') {
                if (plist.items.len > 0) plist.items[plist.items.len - 1].peeled = hash.fromHex(line[1..]);
                continue;
            }
            if (line.len < 42) continue;
            const oid = hash.fromHex(line[0..40]) orelse continue;
            plist.append(gpa, .{ .name = line[41..], .oid = oid, .peeled = null }) catch util.oom();
        }
    }
    std.mem.sort(PackedRef, plist.items, {}, struct {
        fn lt(_: void, a: PackedRef, b: PackedRef) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    packed_cache = plist.items;
    return plist.items;
}

fn findPacked(name: []const u8) ?PackedRef {
    for (packedRefs()) |p| {
        if (util.eql(p.name, name)) return p;
    }
    return null;
}

pub const RawRef = union(enum) {
    oid: Oid,
    symref: []const u8,
};

/// Read a single ref without following symrefs.
pub fn readRaw(name: []const u8) ?RawRef {
    const path = refPath(name);
    if (os.lstatPath(path)) |st| {
        if (st.isLnk()) {
            if (os.readLink(path)) |t| {
                if (util.startsWith(t, "refs/")) return .{ .symref = t };
            }
        }
        if (st.isDir()) {
            // a directory: not a ref; fall through to packed
        } else if (os.readFile(path)) |data| {
            if (util.skipPrefix(data, "ref:")) |rest| {
                return .{ .symref = util.trim(rest) };
            }
            if (data.len >= 40) {
                if (hash.fromHex(data[0..40])) |o| {
                    if (data.len == 40 or std.ascii.isWhitespace(data[40])) return .{ .oid = o };
                }
            }
            return null;
        }
    }
    if (isPerWorktree(name) and !util.startsWith(name, "refs/")) return null;
    if (findPacked(name)) |p| return .{ .oid = p.oid };
    return null;
}

pub const Resolved = struct {
    oid: Oid,
    name: []const u8, // final ref name
    symbolic: bool,
};

/// Resolve following symbolic refs. If the final ref doesn't exist, returns null
/// (use resolveTarget for dangling symrefs).
pub fn resolve(name: []const u8) ?Resolved {
    var cur = name;
    var depth: u32 = 0;
    var sym = false;
    while (depth < 6) : (depth += 1) {
        const raw = readRaw(cur) orelse return null;
        switch (raw) {
            .oid => |o| return .{ .oid = o, .name = cur, .symbolic = sym },
            .symref => |t| {
                cur = t;
                sym = true;
            },
        }
    }
    return null;
}

/// Follow symbolic refs to the final ref name, even if it doesn't exist.
pub fn resolveTarget(name: []const u8) []const u8 {
    var cur = name;
    var depth: u32 = 0;
    while (depth < 6) : (depth += 1) {
        const raw = readRaw(cur) orelse return cur;
        switch (raw) {
            .oid => return cur,
            .symref => |t| cur = t,
        }
    }
    return cur;
}

pub fn readOid(name: []const u8) ?Oid {
    const r = resolve(name) orelse return null;
    return r.oid;
}

pub fn exists(name: []const u8) bool {
    return resolve(name) != null;
}

/// Head's symbolic target ("refs/heads/master") or null if detached.
pub fn headSymref() ?[]const u8 {
    const raw = readRaw("HEAD") orelse return null;
    return switch (raw) {
        .symref => |t| t,
        .oid => null,
    };
}

/// Current branch short name or null if detached.
pub fn currentBranch() ?[]const u8 {
    const t = headSymref() orelse return null;
    return util.skipPrefix(t, "refs/heads/") orelse t;
}

/// DWIM ref: expand short name per rev-parse rules. Returns full name and oid.
pub fn dwimRef(short: []const u8) ?struct { name: []const u8, oid: Oid, count: usize } {
    const rules = [_][]const u8{ "{s}", "refs/{s}", "refs/tags/{s}", "refs/heads/{s}", "refs/remotes/{s}", "refs/remotes/{s}/HEAD" };
    var found: ?Resolved = null;
    var found_name: []const u8 = "";
    var count: usize = 0;
    inline for (rules, 0..) |rule, ri| {
        const full = util.fmt(rule, .{short});
        const ok = if (ri == 0) (isAllCapsOrHead(short) or util.startsWith(short, "refs/")) else true;
        if (ok) {
            if (resolve(full)) |r| {
                if (found == null) {
                    found = r;
                    found_name = full;
                }
                count += 1;
            }
        }
    }
    if (found) |f| return .{ .name = found_name, .oid = f.oid, .count = count };
    return null;
}

fn isAllCapsOrHead(s: []const u8) bool {
    // git checks for a valid pseudoref name: all caps / underscores, or something under refs/
    for (s) |ch| {
        if (!(std.ascii.isUpper(ch) or ch == '_' or ch == '-')) return std.mem.indexOfScalar(u8, s, '/') != null;
    }
    return true;
}

fn collectLoose(dir: []const u8, prefix: []const u8, out: *std.ArrayList([]const u8)) void {
    const ents = os.listDir(dir) orelse return;
    for (ents) |e| {
        const full = util.concat(&.{ dir, "/", e.name });
        const name = util.concat(&.{ prefix, e.name });
        const st = os.lstatPath(full) orelse continue;
        if (st.isDir()) {
            collectLoose(full, util.concat(&.{ name, "/" }), out);
        } else {
            if (util.endsWith(e.name, ".lock")) continue;
            out.append(gpa, name) catch util.oom();
        }
    }
}

/// List all refs under prefix (e.g. "refs/heads/"), sorted by name. Symrefs are resolved.
pub fn list(prefix: []const u8) []Ref {
    const r = repo_mod.repo();
    var names: std.ArrayList([]const u8) = .empty;
    // loose refs from common dir
    var base = "refs/";
    if (!util.startsWith(prefix, "refs/")) base = "refs/";
    collectLoose(r.commonPath("refs"), "refs/", &names);
    if (!util.eql(r.git_dir, r.common_dir)) {
        // per-worktree refs
        for ([_][]const u8{ "refs/bisect", "refs/worktree", "refs/rewritten" }) |d| {
            var tmp: std.ArrayList([]const u8) = .empty;
            collectLoose(r.gitPath(d), util.concat(&.{ d, "/" }), &tmp);
            names.appendSlice(gpa, tmp.items) catch util.oom();
        }
    }
    var map = std.StringHashMap(void).init(gpa);
    var result: std.ArrayList(Ref) = .empty;
    for (names.items) |n| {
        if (!util.startsWith(n, prefix)) continue;
        if (map.contains(n)) continue;
        map.put(n, {}) catch util.oom();
        const raw = readRaw(n) orelse continue;
        switch (raw) {
            .oid => |o| result.append(gpa, .{ .name = n, .oid = o }) catch util.oom(),
            .symref => |t| {
                if (resolve(t)) |res| result.append(gpa, .{ .name = n, .oid = res.oid, .symref = t }) catch util.oom();
            },
        }
    }
    for (packedRefs()) |p| {
        if (!util.startsWith(p.name, prefix)) continue;
        if (map.contains(p.name)) continue;
        result.append(gpa, .{ .name = p.name, .oid = p.oid, .peeled = p.peeled }) catch util.oom();
    }
    std.mem.sort(Ref, result.items, {}, struct {
        fn lt(_: void, a: Ref, b: Ref) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    _ = &base;
    return result.items;
}

// ---------------- writing ----------------

pub fn shouldAutocreateReflog(name: []const u8) bool {
    const r = repo_mod.repo();
    const v = repo_mod.cfg.get("core.logallrefupdates");
    if (v) |val| {
        if (std.ascii.eqlIgnoreCase(val, "always")) return true;
        const b = @import("config.zig").parseBool(val) orelse false;
        if (!b) return false;
    } else if (r.bare) return false;
    return util.startsWith(name, "refs/heads/") or util.startsWith(name, "refs/remotes/") or util.startsWith(name, "refs/notes/") or util.eql(name, "HEAD");
}

pub fn appendReflog(name: []const u8, old: Oid, new: Oid, msg: []const u8, force_create: bool) void {
    const path = logPath(name);
    if (!os.exists(path)) {
        if (!force_create and !shouldAutocreateReflog(name)) return;
        if (!os.mkdirLeading(path)) return;
    }
    const id = ident.committer();
    var b: util.Buf = .empty;
    util.bufPrint(&b, "{s} {s} {s}", .{ hash.hex(old), hash.hex(new), id });
    if (msg.len > 0) {
        util.bufByte(&b, '\t');
        // collapse newlines like git's copy_reflog_msg
        var last_space = false;
        const m = util.trimRight(msg);
        for (m) |ch| {
            if (ch == '\n') {
                if (!last_space) util.bufByte(&b, ' ');
                last_space = true;
                continue;
            }
            util.bufByte(&b, ch);
            last_space = false;
        }
    }
    util.bufByte(&b, '\n');
    os.appendFile(path, b.items) catch {};
}

pub const UpdateError = error{ LockFailed, Mismatch, WriteFailed, BadName, DirConflict };

fn lockRef(path: []const u8) !c_int {
    if (!os.mkdirLeading(path)) {
        // maybe a file in the way: a ref "refs/heads/a" while creating "refs/heads/a/b"
        return error.DirConflict;
    }
    const lock = util.concat(&.{ path, ".lock" });
    const fd = os.openFile(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666);
    if (fd < 0) {
        if (os.errno() == os.EISDIR) return error.DirConflict;
        return error.LockFailed;
    }
    return fd;
}

pub var last_error: []const u8 = "";

/// Update a ref (following symrefs unless no_deref). old: null = don't check;
/// zero = must not exist.
pub fn update(name: []const u8, new: Oid, old: ?Oid, msg: []const u8, no_deref: bool) UpdateError!void {
    const target = if (no_deref) name else resolveTarget(name);
    const cur = readOidNoDeref(target);
    if (old) |o| {
        if (hash.isZero(o)) {
            if (cur != null) {
                last_error = util.fmt("cannot lock ref '{s}': reference already exists", .{name});
                return error.Mismatch;
            }
        } else if (cur == null or !hash.eql(cur.?, o)) {
            if (cur == null) {
                last_error = util.fmt("cannot lock ref '{s}': unable to resolve reference '{s}'", .{ name, target });
            } else {
                last_error = util.fmt("cannot lock ref '{s}': is at {s} but expected {s}", .{ name, hash.hex(cur.?), hash.hex(o) });
            }
            return error.Mismatch;
        }
    }
    try writeRef(target, new);
    const old_val = cur orelse hash.zero;
    appendReflog(target, old_val, new, msg, false);
    // log on HEAD too if HEAD points to target
    if (!util.eql(target, "HEAD")) {
        if (headSymref()) |h| {
            if (util.eql(h, target) or (util.eql(name, "HEAD") and !no_deref)) appendReflog("HEAD", old_val, new, msg, false);
        }
    }
}

fn readOidNoDeref(name: []const u8) ?Oid {
    const raw = readRaw(name) orelse return null;
    return switch (raw) {
        .oid => |o| o,
        .symref => |t| readOid(t),
    };
}

pub fn writeRef(name: []const u8, new: Oid) UpdateError!void {
    const path = refPath(name);
    // if a directory exists in place (empty), remove it
    if (os.lstatPath(path)) |st| {
        if (st.isDir()) {
            if (!os.rmdir(path)) {
                last_error = util.fmt("cannot lock ref '{s}': there is a non-empty directory '{s}' blocking reference '{s}'", .{ name, path, name });
                return error.DirConflict;
            }
        }
    }
    // check D/F conflicts against existing refs
    if (checkDirConflict(name)) |other| {
        last_error = util.fmt("cannot lock ref '{s}': '{s}' exists; cannot create '{s}'", .{ name, other, name });
        return error.DirConflict;
    }
    const fd = lockRef(path) catch |e| {
        if (e == error.DirConflict) {
            last_error = util.fmt("cannot lock ref '{s}': unable to create directory for {s}", .{ name, path });
        } else {
            last_error = util.fmt("cannot lock ref '{s}': Unable to create '{s}.lock': File exists.\n\nAnother git process seems to be running in this repository, e.g.\nan editor opened by 'git commit'. Please make sure all processes\nare terminated then try again. If it still fails, a git process\nmay have crashed in this repository earlier:\nremove the file manually to continue.", .{ name, os.realPath(util.dirname(path)) orelse path });
            last_error = util.fmt("cannot lock ref '{s}': Unable to create '{s}.lock': File exists.\n\nAnother git process seems to be running in this repository, e.g.\nan editor opened by 'git commit'. Please make sure all processes\nare terminated then try again. If it still fails, a git process\nmay have crashed in this repository earlier:\nremove the file manually to continue.", .{ name, absPath(path) });
        }
        return e;
    };
    const content = util.concat(&.{ &hash.hex(new), "\n" });
    os.writeAll(fd, content) catch return error.WriteFailed;
    os.close(fd);
    if (!os.rename(util.concat(&.{ path, ".lock" }), path)) return error.WriteFailed;
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return p;
    return util.normalizePath(util.joinPath(os.getcwd(), p)) orelse p;
}

/// Check whether creating `name` conflicts with an existing ref (prefix or child).
pub fn checkDirConflict(name: []const u8) ?[]const u8 {
    // existing ref that is a prefix of name
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, name, i, '/')) |sl| {
        const pre = name[0..sl];
        if (util.startsWith(pre, "refs/") and pre.len > 5) {
            if (readRaw(pre) != null) {
                // loose file exists?
                return pre;
            }
        }
        i = sl + 1;
    }
    // existing ref under name/
    const pre = util.concat(&.{ name, "/" });
    for (packedRefs()) |p| {
        if (util.startsWith(p.name, pre)) return p.name;
    }
    const path = refPath(name);
    if (os.lstatPath(path)) |st| {
        if (st.isDir()) {
            var names: std.ArrayList([]const u8) = .empty;
            collectLoose(path, pre, &names);
            if (names.items.len > 0) return names.items[0];
        }
    }
    return null;
}

pub fn writeSymref(name: []const u8, target: []const u8, msg: ?[]const u8) !void {
    const path = refPath(name);
    const old = readOid(name);
    const fd = lockRef(path) catch return error.LockFailed;
    os.writeAll(fd, util.concat(&.{ "ref: ", target, "\n" })) catch return error.WriteFailed;
    os.close(fd);
    if (!os.rename(util.concat(&.{ path, ".lock" }), path)) return error.WriteFailed;
    if (msg) |m| {
        const new = readOid(target);
        if (new) |n| {
            appendReflog(name, old orelse hash.zero, n, m, false);
        }
    }
}

/// Delete a ref. old: optional expected value.
pub fn delete(name: []const u8, old: ?Oid, no_deref: bool) UpdateError!void {
    const target = if (no_deref) name else resolveTarget(name);
    if (old) |o| {
        const cur = readOidNoDeref(target);
        if (!hash.isZero(o) and (cur == null or !hash.eql(cur.?, o))) {
            if (cur == null) {
                last_error = util.fmt("cannot lock ref '{s}': unable to resolve reference '{s}'", .{ name, target });
            } else last_error = util.fmt("cannot lock ref '{s}': is at {s} but expected {s}", .{ name, hash.hex(cur.?), hash.hex(o) });
            return error.Mismatch;
        }
    }
    const path = refPath(target);
    if (os.lstatPath(path)) |st| {
        if (!st.isDir()) {
            _ = os.unlink(path);
            const r = repo_mod.repo();
            const base = if (isPerWorktree(target)) r.git_dir else r.common_dir;
            os.removeEmptyParents(path, base.len + 5);
        }
    }
    // remove from packed-refs
    if (findPacked(target) != null) {
        rewritePacked(target);
    }
    // delete reflog
    const lp = logPath(target);
    if (os.exists(lp)) {
        _ = os.unlink(lp);
        const r = repo_mod.repo();
        const base = if (isPerWorktree(target)) r.git_dir else r.common_dir;
        os.removeEmptyParents(lp, base.len + 10);
    }
}

fn rewritePacked(remove: []const u8) void {
    const r = repo_mod.repo();
    const path = r.commonPath("packed-refs");
    var b: util.Buf = .empty;
    util.bufAppend(&b, "# pack-refs with: peeled fully-peeled sorted \n");
    for (packedRefs()) |p| {
        if (util.eql(p.name, remove)) continue;
        util.bufPrint(&b, "{s} {s}\n", .{ hash.hex(p.oid), p.name });
        if (p.peeled) |pe| util.bufPrint(&b, "^{s}\n", .{hash.hex(pe)});
    }
    writePackedFile(path, b.items);
}

pub fn writePackedFile(path: []const u8, data: []const u8) void {
    const lock = util.concat(&.{ path, ".lock" });
    os.writeFile(lock, data, 0o666) catch return;
    _ = os.rename(lock, path);
    invalidatePacked();
}

/// Write all refs to packed-refs, entries given explicitly.
pub fn writePacked(entries: []const PackedRef) void {
    const r = repo_mod.repo();
    var b: util.Buf = .empty;
    util.bufAppend(&b, "# pack-refs with: peeled fully-peeled sorted \n");
    for (entries) |p| {
        util.bufPrint(&b, "{s} {s}\n", .{ hash.hex(p.oid), p.name });
        if (p.peeled) |pe| util.bufPrint(&b, "^{s}\n", .{hash.hex(pe)});
    }
    writePackedFile(r.commonPath("packed-refs"), b.items);
}

// ---------------- reflog reading ----------------

pub const ReflogEntry = struct {
    old: Oid,
    new: Oid,
    ident: []const u8, // "Name <email> time tz"
    msg: []const u8,
};

pub fn readReflog(name: []const u8) []ReflogEntry {
    var out: std.ArrayList(ReflogEntry) = .empty;
    const data = os.readFile(logPath(name)) orelse return out.items;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line| {
        if (line.len < 83) continue;
        const old = hash.fromHex(line[0..40]) orelse continue;
        const new = hash.fromHex(line[41..81]) orelse continue;
        const rest = line[82..];
        var id = rest;
        var msg: []const u8 = "";
        if (std.mem.indexOfScalar(u8, rest, '\t')) |t| {
            id = rest[0..t];
            msg = rest[t + 1 ..];
        }
        out.append(gpa, .{ .old = old, .new = new, .ident = id, .msg = msg }) catch util.oom();
    }
    return out.items;
}

pub fn reflogExists(name: []const u8) bool {
    return os.isFile(logPath(name));
}

pub fn reflogPath(name: []const u8) []u8 {
    return logPath(name);
}

pub fn writeReflog(name: []const u8, entries: []const ReflogEntry) void {
    var b: util.Buf = .empty;
    for (entries) |e| {
        util.bufPrint(&b, "{s} {s} {s}", .{ hash.hex(e.old), hash.hex(e.new), e.ident });
        if (e.msg.len > 0) {
            util.bufByte(&b, '\t');
            util.bufAppend(&b, e.msg);
        }
        util.bufByte(&b, '\n');
    }
    os.writeFile(logPath(name), b.items, 0o666) catch {};
}

pub fn renameReflog(old: []const u8, new: []const u8) void {
    const op = logPath(old);
    if (!os.exists(op)) return;
    const np = logPath(new);
    _ = os.mkdirLeading(np);
    _ = os.rename(op, np);
}

/// Shorten a ref name for display (refs/heads/x -> x), like shorten_unambiguous_ref.
pub fn shorten(name: []const u8) []const u8 {
    if (util.skipPrefix(name, "refs/heads/")) |s| return s;
    if (util.skipPrefix(name, "refs/tags/")) |s| return s;
    if (util.skipPrefix(name, "refs/remotes/")) |s| {
        if (util.endsWith(s, "/HEAD")) return s[0 .. s.len - 5];
        return s;
    }
    if (util.skipPrefix(name, "refs/")) |s| return s;
    return name;
}

/// shorten_unambiguous_ref with strict checking: try rules in reverse order.
pub fn shortenUnambiguous(name: []const u8) []const u8 {
    const rules = [_][2][]const u8{
        .{ "", "" },
        .{ "refs/", "" },
        .{ "refs/tags/", "" },
        .{ "refs/heads/", "" },
        .{ "refs/remotes/", "" },
        .{ "refs/remotes/", "/HEAD" },
    };
    var i: usize = rules.len;
    while (i > 1) {
        i -= 1;
        const pre = rules[i][0];
        const suf = rules[i][1];
        if (!util.startsWith(name, pre) or !util.endsWith(name, suf)) continue;
        if (name.len <= pre.len + suf.len) continue;
        const short = name[pre.len .. name.len - suf.len];
        // check that no rule before i (higher priority) resolves short to something else
        var ambiguous = false;
        var j: usize = 0;
        while (j < rules.len) : (j += 1) {
            if (j == i) continue;
            // only rules that would be checked by dwim before ours matter, plus all for strict
            if (j > i) continue;
            const cand = util.concat(&.{ rules[j][0], short, rules[j][1] });
            if (j == 0 and !(isAllCapsOrHead(short))) continue;
            if (readRaw(cand) != null) {
                ambiguous = true;
                break;
            }
        }
        if (!ambiguous) return short;
    }
    return name;
}
