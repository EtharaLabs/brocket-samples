//! Port of advice.c

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");

fn globallyEnabled() bool {
    if (os.getenv("GIT_ADVICE")) |v| return config.parseBool(v) orelse true;
    return true;
}

/// Is advice `key` (e.g. "defaultBranchName") enabled?
pub fn enabled(key: []const u8) bool {
    if (!globallyEnabled()) return false;
    const v = repo_mod.cfg.getBool(util.lower(util.concat(&.{ "advice.", key })));
    return v orelse true;
}

/// Print a hint block to stderr.
pub fn advise(msg: []const u8) void {
    var b: util.Buf = .empty;
    var it = std.mem.splitScalar(u8, msg, '\n');
    while (it.next()) |line| {
        if (line.len == 0) util.bufAppend(&b, "hint:\n") else util.bufPrint(&b, "hint: {s}\n", .{line});
    }
    util.ewrite(b.items);
}

pub fn adviseIfEnabled(key: []const u8, msg: []const u8) void {
    if (!enabled(key)) return;
    const configured = repo_mod.cfg.getBool(util.lower(util.concat(&.{ "advice.", key }))) != null;
    if (configured) {
        advise(msg);
    } else {
        advise(util.concat(&.{ msg, "\nDisable this message with \"git config set advice.", key, " false\"" }));
    }
}
