//! Log output of a single commit (port of log-tree.c).

const std = @import("std");
const util = @import("util.zig");
const cn = @import("commitnode.zig");
const revision = @import("revision.zig");

pub const DecorationOptions = struct {
    prefix: ?[]const u8 = null,
    suffix: ?[]const u8 = null,
    separator: ?[]const u8 = null,
    pointer: ?[]const u8 = null,
    tag: ?[]const u8 = null,
};

/// format_decorations: append " (HEAD -> main, tag: v1)" style decorations for commit.
pub fn formatDecorations(b: *util.Buf, commit: *const cn.Commit, use_color: bool, opts: ?*const DecorationOptions) void {
    _ = b;
    _ = commit;
    _ = use_color;
    _ = opts;
}

/// load_ref_decorations with default filter (used by %d/%D when decorations not loaded yet).
pub fn loadRefDecorationsDefault() void {}
