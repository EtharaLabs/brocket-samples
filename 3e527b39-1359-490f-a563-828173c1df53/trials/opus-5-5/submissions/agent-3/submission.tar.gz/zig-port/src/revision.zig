//! Revision walking (port of revision.c).

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const cn = @import("commitnode.zig");
const date = @import("date.zig");
const graph_mod = @import("graph.zig");
const reflogwalk = @import("reflogwalk.zig");
const Oid = hash.Oid;
const Commit = cn.Commit;
const CommitList = cn.CommitList;
const Obj = cn.Obj;
const gpa = util.gpa;

pub const CmitFmt = enum { raw, medium, short, full, fuller, oneline, email, mboxrd, userformat, unspecified };

pub const CommitAction = enum { ignore, show, error_ };

pub const RevInfo = struct {
    // --- work queue ---
    commits: ?*CommitList = null,
    // --- basic ---
    prefix: []const u8 = "",
    def: ?[]const u8 = null,

    sort_order: cn.SortOrder = .graph,

    // traversal flags
    dense: bool = true,
    prune: bool = false,
    no_walk: bool = false,
    unsorted_input: bool = false,
    remove_empty_trees: bool = false,
    simplify_history: bool = true,
    show_pulls: bool = false,
    topo_order: bool = false,
    simplify_merges: bool = false,
    simplify_by_decoration: bool = false,
    tag_objects: bool = false,
    tree_objects: bool = false,
    blob_objects: bool = false,
    edge_hint: bool = false,
    limited: bool = false,
    /// 0, 1 or 2 (boundary:2 bitfield in C)
    boundary: u2 = 0,
    count: bool = false,
    left_right: bool = false,
    left_only: bool = false,
    right_only: bool = false,
    rewrite_parents: bool = false,
    print_parents: bool = false,
    show_decorations: bool = false,
    reverse: bool = false,
    reverse_output_stage: bool = false,
    cherry_pick: bool = false,
    cherry_mark: bool = false,
    bisect: bool = false,
    ancestry_path: bool = false,
    first_parent_only: bool = false,
    exclude_first_parent_only: bool = false,
    line_level_traverse: bool = false,

    // diff flags
    diff: bool = false,
    full_diff: bool = false,
    show_root_diff: bool = false,
    no_commit_id: bool = false,
    verbose_header: bool = false,
    always_show_header: bool = false,

    // format info
    shown_one: bool = false,
    shown_dashes: bool = false,
    show_merge: bool = false,
    pretty_given: bool = false,
    abbrev_commit: bool = false,
    abbrev_commit_given: bool = false,
    zero_commit: bool = false,
    use_terminator: bool = false,
    missing_newline: bool = false,
    date_mode_explicit: bool = false,
    preserve_subject: bool = false,
    force_in_body_from: bool = false,
    encode_email_headers: bool = false,
    show_notes: bool = false,
    show_signature: bool = false,
    track_linear: bool = false,
    track_first_time: bool = false,
    linear: bool = false,

    date_mode: date.DateMode = .{},
    /// unset if negative
    expand_tabs_in_log: i32 = -1,
    expand_tabs_in_log_default: i32 = 8,
    /// 0 = full hex
    abbrev: usize = 0,
    commit_format: CmitFmt = .medium,
    /// user format string for .userformat (set by pretty.getCommitFormat)
    user_format: []const u8 = "",
    nr: i32 = 0,
    total: i32 = 0,
    subject_prefix: ?[]const u8 = null,
    show_log_size: bool = false,
    /// colors enabled for this output
    use_color: bool = false,
    /// mailmap enabled (--use-mailmap / log.mailmap)
    use_mailmap: bool = false,

    // graph
    graph: ?*graph_mod.Graph = null,
    graph_max_lanes: i32 = 0,
    no_graph_indent: bool = false,
    graph_indent_set: bool = false,

    // limits
    skip_count: i32 = -1,
    max_count: i32 = -1,
    max_age: u64 = std.math.maxInt(u64),
    max_age_as_filter: u64 = std.math.maxInt(u64),
    min_age: u64 = std.math.maxInt(u64),
    min_parents: i32 = 0,
    max_parents: i32 = -1,

    /// --source: map commit index -> source name
    sources: ?*cn.Slab(?[]const u8) = null,

    /// reflog walk state (set for -g)
    reflog_info: ?*reflogwalk.Info = null,

    count_left: i32 = 0,
    count_right: i32 = 0,
    count_same: i32 = 0,
};

/// get_commit_action
pub fn getCommitAction(revs: *RevInfo, commit: *Commit) CommitAction {
    _ = revs;
    _ = commit;
    return .show;
}

/// get_revision_mark: "<", ">", "-", "=", "+" or "" / "*" for graph.
pub fn getRevisionMark(revs: ?*const RevInfo, commit: *const Commit) []const u8 {
    const f = commit.obj.flags;
    if (f & cn.BOUNDARY != 0) return "-";
    if (f & cn.UNINTERESTING != 0) return "^";
    if (f & cn.PATCHSAME != 0) return "=";
    if (revs == null or revs.?.left_right) {
        if (f & cn.SYMMETRIC_LEFT != 0) return "<";
        return ">";
    }
    if (revs.?.graph != null) return "*";
    if (revs.?.cherry_mark) return "+";
    return "";
}
