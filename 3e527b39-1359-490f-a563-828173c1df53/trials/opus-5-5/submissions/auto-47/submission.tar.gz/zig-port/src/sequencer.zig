//! Port of sequencer.c (cherry-pick / revert machinery; rebase -i support
//! is added on top of the same structures).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const refs = @import("refs.zig");
const revparse = @import("revparse.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const objects = @import("objects.zig");
const cn = @import("commitnode.zig");
const index_mod = @import("index.zig");
const pathspec_mod = @import("pathspec.zig");
const ut = @import("unpacktrees.zig");
const mo = @import("merge_ort.zig");
const advice = @import("advice.zig");
const hook = @import("hook.zig");
const commit_mod = @import("commit.zig");
const wtstatus = @import("wtstatus.zig");
const trailer = @import("pretty_trailer.zig");
const pretty = @import("pretty.zig");
const revision = @import("revision.zig");
const summary = @import("summary.zig");
const proc = @import("proc.zig");
const lockfile = @import("lockfile.zig");
const date_mod = @import("date.zig");
const branchstate = @import("branchstate.zig");
const creach = @import("commitreach.zig");
const c_commit = @import("cmd/commit.zig");
const Oid = hash.Oid;
const Commit = cn.Commit;
const gpa = util.gpa;

pub const Cleanup = c_commit.Cleanup;

pub const Action = enum { revert, pick, rebase_i };

pub const RERERE_AUTOUPDATE: i32 = 1;
pub const RERERE_NOAUTOUPDATE: i32 = 2;

pub const Opts = struct {
    action: Action = .pick,
    edit: i32 = -1,
    record_origin: bool = false,
    no_commit: bool = false,
    signoff: bool = false,
    allow_ff: bool = false,
    allow_rerere_auto: i32 = 0,
    allow_empty: bool = false,
    allow_empty_message: bool = false,
    drop_redundant_commits: bool = false,
    keep_redundant_commits: bool = false,
    verbose: bool = false,
    quiet: bool = false,
    reschedule_failed_exec: bool = false,
    committer_date_is_author_date: bool = false,
    ignore_date: bool = false,
    commit_use_reference: bool = false,
    trailer_args: std.ArrayList([]const u8) = .empty,
    mainline: i32 = 0,
    gpg_sign: ?[]const u8 = null,
    default_msg_cleanup: Cleanup = .none,
    explicit_cleanup: bool = false,
    default_strategy: ?[]const u8 = null,
    strategy: ?[]const u8 = null,
    xopts: std.ArrayList([]const u8) = .empty,
    reflog_action: ?[]const u8 = null,
    squash_onto: Oid = hash.zero,
    have_squash_onto: bool = false,
    revs: ?*revision.RevInfo = null,
    // replay_ctx
    message: util.Buf = .empty,
    current_fixups: util.Buf = .empty,
    current_fixup_count: i32 = 0,
    have_message: bool = false,
};

// ---------------------------------------------------------------------------
// paths

fn gitPath(name: []const u8) []const u8 {
    return repo_mod.repo().gitPath(name);
}
fn seqDir() []const u8 {
    return gitPath("sequencer");
}
fn todoFile() []const u8 {
    return gitPath("sequencer/todo");
}
fn optsFile() []const u8 {
    return gitPath("sequencer/opts");
}
fn headFile() []const u8 {
    return gitPath("sequencer/head");
}
fn abortSafetyFile() []const u8 {
    return gitPath("sequencer/abort-safety");
}
pub fn rebasePath(name: []const u8) []const u8 {
    if (name.len == 0) return gitPath("rebase-merge");
    return gitPath(util.concat(&.{ "rebase-merge/", name }));
}
fn mergeMsgPath() []const u8 {
    return gitPath("MERGE_MSG");
}

fn isRebaseI(opts: *const Opts) bool {
    return opts.action == .rebase_i;
}
fn getDir(opts: *const Opts) []const u8 {
    return if (isRebaseI(opts)) rebasePath("") else seqDir();
}
fn getTodoPath(opts: *const Opts) []const u8 {
    return if (isRebaseI(opts)) rebasePath("git-rebase-todo") else todoFile();
}

// ---------------------------------------------------------------------------
// config

fn cleanupFromConfig(opts: *Opts, v: []const u8) void {
    if (util.eql(v, "verbatim")) {
        opts.default_msg_cleanup = .none;
        opts.explicit_cleanup = true;
    } else if (util.eql(v, "whitespace")) {
        opts.default_msg_cleanup = .space;
        opts.explicit_cleanup = true;
    } else if (util.eql(v, "strip")) {
        opts.default_msg_cleanup = .all;
        opts.explicit_cleanup = true;
    } else if (util.eql(v, "scissors")) {
        opts.default_msg_cleanup = .scissors;
        opts.explicit_cleanup = true;
    } else {
        util.warn("invalid commit message cleanup mode '{s}'", .{v});
    }
}

/// sequencer_init_config()
pub fn initConfig(opts: *Opts) void {
    opts.default_msg_cleanup = .none;
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        if (util.eql(k, "commit.cleanup")) {
            const v = e.value orelse util.die("missing value for '{s}'", .{k});
            cleanupFromConfig(opts, v);
        } else if (util.eql(k, "commit.gpgsign")) {
            opts.gpg_sign = if (config.configBool(k, e.value)) "" else null;
        } else if (opts.default_strategy == null and util.eql(k, "pull.twohead")) {
            const v = e.value orelse util.die("missing value for '{s}'", .{k});
            opts.default_strategy = if (std.mem.indexOfScalar(u8, v, ' ')) |sp| v[0..sp] else v;
        } else if (opts.action == .revert and util.eql(k, "revert.reference")) {
            opts.commit_use_reference = config.configBool(k, e.value);
        }
    }
}

fn describeCleanupMode(m: Cleanup) []const u8 {
    return switch (m) {
        .space => "whitespace",
        .none => "verbatim",
        .scissors => "scissors",
        .all => "strip",
    };
}

// ---------------------------------------------------------------------------
// small helpers

pub fn actionName(opts: *const Opts) []const u8 {
    return switch (opts.action) {
        .revert => "revert",
        .pick => "cherry-pick",
        .rebase_i => "rebase",
    };
}

fn shortCommitName(c: *Commit) []const u8 {
    return revparse.abbrev(c.oid(), revparse.defaultAbbrev());
}

fn commitOutputEncoding() []const u8 {
    return commit_mod.commitEncoding() orelse "UTF-8";
}

/// find_commit_subject(): returns the message from the subject on, and the
/// length of the subject line.
pub fn findCommitSubject(buf: []const u8) struct { rest: []const u8, len: usize } {
    var p: usize = 0;
    while (p < buf.len and (buf[p] != '\n' or p + 1 >= buf.len or buf[p + 1] != '\n')) {
        if (buf[p] == '\n' and p + 1 >= buf.len) {
            p += 1;
            break;
        }
        p += 1;
    }
    if (p < buf.len) {
        p = skipBlankLines(buf, p + 2);
        const eol = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse buf.len;
        return .{ .rest = buf[p..], .len = eol - p };
    }
    return .{ .rest = buf[buf.len..], .len = 0 };
}

fn skipBlankLines(buf: []const u8, start: usize) usize {
    var p = start;
    while (p < buf.len) {
        var q = p;
        while (q < buf.len and buf[q] != '\n' and std.ascii.isWhitespace(buf[q])) q += 1;
        if (q < buf.len and buf[q] == '\n') {
            p = q + 1;
            continue;
        }
        if (q >= buf.len) return q;
        break;
    }
    return p;
}

/// commit_subject_length()
pub fn commitSubjectLength(body: []const u8) usize {
    var p: usize = 0;
    while (p < body.len) {
        const next = skipBlankLines(body, p);
        if (next != p) break;
        p = std.mem.indexOfScalarPos(u8, body, p, '\n') orelse body.len;
        if (p < body.len) p += 1;
    }
    return p;
}

const CommitMessage = struct {
    parent_label: []const u8,
    label: []const u8,
    subject: []const u8,
    message: []const u8,
};

fn getMessage(commit: *Commit) CommitMessage {
    const msg = pretty.logmsgReencode(commit, commitOutputEncoding()).msg;
    const abbrev = shortCommitName(commit);
    const s = findCommitSubject(msg);
    const subject = s.rest[0..s.len];
    const label = util.fmt("{s} ({s})", .{ abbrev, subject });
    return .{
        .message = msg,
        .subject = subject,
        .label = label,
        .parent_label = util.fmt("parent of {s}", .{label}),
    };
}

pub const rebase_resolvemsg =
    "Resolve all conflicts manually, mark them as resolved with\n" ++
    "\"git add/rm <conflicted_files>\", then run \"git rebase --continue\".\n" ++
    "You can instead skip this commit: run \"git rebase --skip\".\n" ++
    "To abort and get back to the state before \"git rebase\", run " ++
    "\"git rebase --abort\".";

fn printAdvice(show_hint: bool, opts: *Opts) void {
    const msg: ?[]const u8 = if (isRebaseI(opts)) rebase_resolvemsg else os.getenv("GIT_CHERRY_PICK_HELP");
    if (msg) |m| {
        advice.adviseIfEnabled("mergeConflict", m);
        refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "") catch {};
        return;
    }
    if (show_hint) {
        if (opts.no_commit) {
            advice.adviseIfEnabled("mergeConflict", "after resolving the conflicts, mark the corrected paths\nwith 'git add <paths>' or 'git rm <paths>'");
        } else if (opts.action == .pick) {
            advice.adviseIfEnabled("mergeConflict", "After resolving the conflicts, mark them with\n" ++
                "\"git add/rm <pathspec>\", then run\n" ++
                "\"git cherry-pick --continue\".\n" ++
                "You can instead skip this commit with \"git cherry-pick --skip\".\n" ++
                "To abort and get back to the state before \"git cherry-pick\",\n" ++
                "run \"git cherry-pick --abort\".");
        } else if (opts.action == .revert) {
            advice.adviseIfEnabled("mergeConflict", "After resolving the conflicts, mark them with\n" ++
                "\"git add/rm <pathspec>\", then run\n" ++
                "\"git revert --continue\".\n" ++
                "You can instead skip this commit with \"git revert --skip\".\n" ++
                "To abort and get back to the state before \"git revert\",\n" ++
                "run \"git revert --abort\".");
        }
    }
}

/// write_message(): returns 0 or -1 (error printed).
pub fn writeMessage(buf: []const u8, filename: []const u8, append_eol: bool) i32 {
    const l = switch (lockfile.tryLock(filename)) {
        .ok => |l| l,
        .err => {
            util.err("could not lock '{s}': {s}", .{ filename, os.lastErr() });
            return -1;
        },
    };
    l.write(buf);
    if (append_eol) l.write("\n");
    if (!l.commit()) {
        util.err("failed to finalize '{s}'", .{filename});
        return -1;
    }
    return 0;
}

/// write_file(): writes `data` (dies on error).
fn writeFile(path: []const u8, data: []const u8) void {
    os.writeFile(path, data, 0o666) catch util.dieErrno("could not open '{s}' for writing", .{path});
}

/// read_oneliner()
pub fn readOneliner(path: []const u8, warn_missing: bool, skip_if_empty: bool) ?[]const u8 {
    const data = os.readFile(path) orelse {
        const e = os.errno();
        if (warn_missing or (e != os.ENOENT and e != os.ENOTDIR))
            util.warn("could not read '{s}': {s}", .{ path, os.strErr(e) });
        return null;
    };
    var s: []const u8 = data;
    if (s.len > 0 and s[s.len - 1] == '\n') {
        s = s[0 .. s.len - 1];
        if (s.len > 0 and s[s.len - 1] == '\r') s = s[0 .. s.len - 1];
    }
    if (skip_if_empty and s.len == 0) return null;
    return s;
}

fn errorDirtyIndex(opts: *Opts) i32 {
    if (ut.readIndexUnmerged(index_mod.get())) {
        advice.errorResolveConflict(actionName(opts));
        return -1;
    }
    util.err("your local changes would be overwritten by {s}.", .{actionName(opts)});
    if (advice.enabled("commitBeforeMerge")) advice.advise("commit your changes or stash them to proceed.");
    return -1;
}

fn updateAbortSafetyFile() void {
    if (!os.exists(seqDir())) return;
    if (revparse.getOid("HEAD")) |h| {
        writeFile(abortSafetyFile(), util.concat(&.{ &hash.hex(h), "\n" }));
    } else writeFile(abortSafetyFile(), "");
}

/// checkout_fast_forward() (merge.c), overwrite_ignore = 1
pub fn checkoutFastForward(head: Oid, remote: Oid) bool {
    const idx = index_mod.lockAndRead();
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
    const t1 = objects.peelTo(head, .tree) orelse {
        idx.rollback();
        return false;
    };
    const t2 = objects.peelTo(remote, .tree) orelse {
        idx.rollback();
        return false;
    };
    var o = ut.Options{};
    o.preserve_ignored = false;
    o.head_idx = 1;
    o.src_index = idx;
    o.dst_index = idx;
    o.update = true;
    o.verbose_update = true;
    o.merge = true;
    o.func = &ut.twowayMerge;
    ut.setupPorcelain(&o, "merge");
    if (ut.unpackTrees(&.{ t1, t2 }, &o) != 0) {
        index_mod.get().rollback();
        idx.rollback();
        return false;
    }
    index_mod.get().write();
    return true;
}

fn fastForwardTo(to: Oid, from: Oid, unborn: bool, opts: *Opts) i32 {
    index_mod.discard();
    if (!checkoutFastForward(from, to)) return -1;
    const msg = util.fmt("{s}: fast-forward", .{actionName(opts)});
    const old: Oid = if (unborn and !isRebaseI(opts)) hash.zero else from;
    refs.update("HEAD", to, old, msg, false) catch {
        util.err("{s}", .{refs.last_error});
        return -1;
    };
    updateAbortSafetyFile();
    return 0;
}

fn commentedAdd(buf: *util.Buf, text: []const u8) void {
    const incomplete = buf.items.len > 0 and buf.items[buf.items.len - 1] != '\n';
    wtstatus.addCommentedLines(buf, trailer.commentLineStr(), text);
    if (incomplete) buf.items.len -= 1;
}

/// append_conflicts_hint()
pub fn appendConflictsHint(msgbuf: *util.Buf, mode: Cleanup) void {
    const cs = trailer.commentLineStr();
    if (mode == .scissors) {
        util.bufByte(msgbuf, '\n');
        wtstatus.appendCutLine(msgbuf);
        util.bufAppend(msgbuf, cs);
    }
    util.bufByte(msgbuf, '\n');
    commentedAdd(msgbuf, "Conflicts:\n");
    const ents = index_mod.get().entries.items;
    var i: usize = 0;
    while (i < ents.len) {
        const ce = ents[i];
        i += 1;
        if (ce.stage() != 0) {
            commentedAdd(msgbuf, util.fmt("\t{s}\n", .{ce.path}));
            while (i < ents.len and util.eql(ce.path, ents[i].path)) i += 1;
        }
    }
}

fn commitTreeOid(c: ?*Commit) Oid {
    const cc = c orelse return hash.fromHex(hash.empty_tree_hex).?;
    _ = cn.parse(cc);
    return cc.tree;
}

fn doRecursiveMerge(base: ?*Commit, next: ?*Commit, base_label: []const u8, next_label: []const u8, head: Oid, msgbuf: *util.Buf, opts: *Opts) i32 {
    const idx = index_mod.lockAndRead();
    _ = idx;
    var o = mo.initMergeOptions(true);
    o.ancestor = if (base != null) base_label else "(empty tree)";
    o.branch1 = "HEAD";
    o.branch2 = if (next != null) next_label else "(empty tree)";
    o.show_rename_progress = true;
    const head_tree = objects.peelTo(head, .tree) orelse {
        index_mod.get().rollback();
        util.err("unable to read tree ({s})", .{hash.hex(head)});
        return -1;
    };
    const next_tree = commitTreeOid(next);
    const base_tree = commitTreeOid(base);
    for (opts.xopts.items) |x| _ = mo.parseMergeOpt(&o, x);
    var result = mo.Result{};
    mo.mergeIncoreNonrecursive(&o, base_tree, head_tree, next_tree, &result);
    const show_output = !isRebaseI(opts) or result.clean == 0;
    mo.mergeSwitchToResult(&o, head_tree, &result, true, show_output);
    const clean = result.clean;
    if (clean < 0) {
        index_mod.get().rollback();
        return clean;
    }
    index_mod.get().write();
    if (clean == 0) appendConflictsHint(msgbuf, opts.default_msg_cleanup);
    return if (clean == 0) 1 else 0;
}

/// is_index_unchanged(): 1 if the index tree equals HEAD's tree, 0 if not, -1 on error.
fn isIndexUnchanged() i32 {
    var head_tree: Oid = undefined;
    if (refs.readOid("HEAD")) |h| {
        const c = cn.lookupCommit(h) orelse return -1;
        if (!cn.parse(c)) return -1;
        head_tree = c.tree;
    } else {
        const sym = refs.readSymbolic("HEAD");
        if (sym == null or !util.startsWith(sym.?, "refs/heads/")) {
            util.err("could not resolve HEAD commit", .{});
            return -1;
        }
        head_tree = hash.fromHex(hash.empty_tree_hex).?;
    }
    const t = index_mod.get().writeTree(false) orelse {
        util.err("unable to update cache tree", .{});
        return -1;
    };
    return if (hash.eql(t, head_tree)) 1 else 0;
}

// ---------------------------------------------------------------------------
// author-script

fn writeAuthorScript(message: []const u8) i32 {
    var m = message;
    while (true) {
        if (m.len == 0 or m[0] == '\n') {
            _ = os.unlink(rebasePath("author-script"));
            return 0;
        } else if (util.skipPrefix(m, "author ")) |rest| {
            m = rest;
            break;
        } else if (std.mem.indexOfScalar(u8, m, '\n')) |eol| {
            m = m[eol + 1 ..];
        } else {
            _ = os.unlink(rebasePath("author-script"));
            return 0;
        }
    }
    var b: util.Buf = .empty;
    var i: usize = 0;
    util.bufAppend(&b, "GIT_AUTHOR_NAME='");
    while (i < m.len and m[i] != '\n' and m[i] != '\r') {
        if (util.startsWith(m[i..], " <")) {
            i += 2;
            break;
        } else if (m[i] != '\'') {
            util.bufByte(&b, m[i]);
            i += 1;
        } else {
            util.bufPrint(&b, "'\\{c}'", .{m[i]});
            i += 1;
        }
    }
    util.bufAppend(&b, "'\nGIT_AUTHOR_EMAIL='");
    while (i < m.len and m[i] != '\n' and m[i] != '\r') {
        if (util.startsWith(m[i..], "> ")) {
            i += 2;
            break;
        } else if (m[i] != '\'') {
            util.bufByte(&b, m[i]);
            i += 1;
        } else {
            util.bufPrint(&b, "'\\{c}'", .{m[i]});
            i += 1;
        }
    }
    util.bufAppend(&b, "'\nGIT_AUTHOR_DATE='@");
    while (i < m.len and m[i] != '\n' and m[i] != '\r') {
        if (m[i] != '\'') {
            util.bufByte(&b, m[i]);
        } else {
            util.bufPrint(&b, "'\\{c}'", .{m[i]});
        }
        i += 1;
    }
    util.bufByte(&b, '\'');
    return writeMessage(b.items, rebasePath("author-script"), true);
}

/// sq_dequote()
fn sqDequote(s: []const u8) ?[]const u8 {
    if (s.len == 0 or s[0] != '\'') return null;
    var b: util.Buf = .empty;
    var i: usize = 1;
    while (true) {
        if (i >= s.len) return null;
        const c = s[i];
        i += 1;
        if (c != '\'') {
            util.bufByte(&b, c);
            continue;
        }
        // closing quote
        if (i >= s.len) return b.items;
        if (s[i] == '\\' and i + 2 < s.len and s[i + 2] == '\'') {
            const ch = s[i + 1];
            if (ch == '\'' or ch == '!') {
                util.bufByte(&b, ch);
                i += 3;
                continue;
            }
        }
        return null;
    }
}

pub const AuthorScript = struct { name: []const u8, email: []const u8, date: []const u8 };

/// read_author_script(); null on error (messages printed). If allow_missing and
/// the file does not exist, returns an empty struct with missing=true.
pub fn readAuthorScript(path: []const u8, allow_missing: bool) union(enum) { ok: AuthorScript, missing, err } {
    const data = os.readFile(path) orelse {
        if (os.errno() == os.ENOENT and allow_missing) return .missing;
        util.err("could not open '{s}' for reading: {s}", .{ path, os.lastErr() });
        return .err;
    };
    if (data.len == 0) {
        util.err("could not open '{s}' for reading: {s}", .{ path, "Success" });
        return .err;
    }
    var name: ?[]const u8 = null;
    var email: ?[]const u8 = null;
    var date: ?[]const u8 = null;
    var bad = false;
    var p: []const u8 = data;
    while (p.len > 0) {
        const eq = std.mem.indexOfScalar(u8, p, '=') orelse {
            const np = std.mem.indexOfScalar(u8, p, '\n') orelse p.len;
            util.err("no key present in '{s}'", .{p[0..np]});
            return .err;
        };
        const key = p[0..eq];
        const np = std.mem.indexOfScalarPos(u8, p, eq, '\n') orelse p.len;
        const val = sqDequote(p[eq + 1 .. np]) orelse {
            util.err("unable to dequote value of '{s}'", .{key});
            return .err;
        };
        p = if (np < p.len) p[np + 1 ..] else p[p.len..];
        if (util.eql(key, "GIT_AUTHOR_NAME")) {
            if (name != null) {
                util.err("'GIT_AUTHOR_NAME' already given", .{});
                bad = true;
            } else name = val;
        } else if (util.eql(key, "GIT_AUTHOR_EMAIL")) {
            if (email != null) {
                util.err("'GIT_AUTHOR_EMAIL' already given", .{});
                bad = true;
            } else email = val;
        } else if (util.eql(key, "GIT_AUTHOR_DATE")) {
            if (date != null) {
                util.err("'GIT_AUTHOR_DATE' already given", .{});
                bad = true;
            } else date = val;
        } else {
            util.err("unknown variable '{s}'", .{key});
            bad = true;
        }
    }
    if (name == null) util.err("missing 'GIT_AUTHOR_NAME'", .{});
    if (email == null) util.err("missing 'GIT_AUTHOR_EMAIL'", .{});
    if (date == null) util.err("missing 'GIT_AUTHOR_DATE'", .{});
    if (name == null or email == null or date == null or bad) return .err;
    return .{ .ok = .{ .name = name.?, .email = email.?, .date = date.? } };
}

fn getAuthor(message: []const u8) ?[]const u8 {
    return cn.findHeader(message, "author");
}

// ---------------------------------------------------------------------------
// committing

pub const ALLOW_EMPTY: u32 = 1 << 0;
pub const EDIT_MSG: u32 = 1 << 1;
pub const AMEND_MSG: u32 = 1 << 2;
pub const CLEANUP_MSG: u32 = 1 << 3;
pub const VERIFY_MSG: u32 = 1 << 4;
pub const CREATE_ROOT_COMMIT: u32 = 1 << 5;

const staged_changes_advice =
    "you have staged changes in your working tree\n" ++
    "If these changes are meant to be squashed into the previous commit, run:\n" ++
    "\n" ++
    "  git commit --amend {s}\n" ++
    "\n" ++
    "If they are meant to go into a new commit, run:\n" ++
    "\n" ++
    "  git commit {s}\n" ++
    "\n" ++
    "In both cases, once you're done, continue with:\n" ++
    "\n" ++
    "  git rebase --continue\n";

fn gpgSignOptQuoted(opts: *const Opts) []const u8 {
    var b: util.Buf = .empty;
    if (opts.gpg_sign) |g| util.sqQuote(&b, util.concat(&.{ "-S", g }));
    return b.items;
}

fn runGitCommit(defmsg: ?[]const u8, reflog_action: []const u8, opts: *Opts, flags: u32) i32 {
    var env: std.ArrayList([2][]const u8) = .empty;
    if (isRebaseI(opts) and ((opts.committer_date_is_author_date and !opts.ignore_date) or
        !(defmsg == null and flags & AMEND_MSG != 0)))
    {
        switch (readAuthorScript(rebasePath("author-script"), false)) {
            .ok => |a| {
                env.append(gpa, .{ "GIT_AUTHOR_NAME", a.name }) catch util.oom();
                env.append(gpa, .{ "GIT_AUTHOR_EMAIL", a.email }) catch util.oom();
                env.append(gpa, .{ "GIT_AUTHOR_DATE", a.date }) catch util.oom();
            },
            else => {
                const g = gpgSignOptQuoted(opts);
                util.err(staged_changes_advice, .{ g, g });
                return -1;
            },
        }
    }
    env.append(gpa, .{ "GIT_REFLOG_ACTION", reflog_action }) catch util.oom();
    if (opts.committer_date_is_author_date) {
        var d: []const u8 = "";
        if (!opts.ignore_date) {
            for (env.items) |e| {
                if (util.eql(e[0], "GIT_AUTHOR_DATE")) d = e[1];
            }
        }
        env.append(gpa, .{ "GIT_COMMITTER_DATE", d }) catch util.oom();
    }
    if (opts.ignore_date) env.append(gpa, .{ "GIT_AUTHOR_DATE", "" }) catch util.oom();

    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.append(gpa, "commit") catch util.oom();
    if (flags & VERIFY_MSG == 0) argv.append(gpa, "-n") catch util.oom();
    if (flags & AMEND_MSG != 0) argv.append(gpa, "--amend") catch util.oom();
    if (opts.gpg_sign) |g| argv.append(gpa, util.concat(&.{ "-S", g })) catch util.oom() else argv.append(gpa, "--no-gpg-sign") catch util.oom();
    if (defmsg) |d| {
        argv.append(gpa, "-F") catch util.oom();
        argv.append(gpa, d) catch util.oom();
    } else if (flags & EDIT_MSG == 0) {
        argv.append(gpa, "-C") catch util.oom();
        argv.append(gpa, "HEAD") catch util.oom();
    }
    if (flags & CLEANUP_MSG != 0) argv.append(gpa, "--cleanup=strip") catch util.oom();
    if (flags & EDIT_MSG != 0) {
        argv.append(gpa, "-e") catch util.oom();
    } else if (flags & CLEANUP_MSG == 0 and !opts.signoff and !opts.record_origin and !opts.explicit_cleanup) {
        argv.append(gpa, "--cleanup=verbatim") catch util.oom();
    }
    if (flags & ALLOW_EMPTY != 0) argv.append(gpa, "--allow-empty") catch util.oom();
    if (flags & EDIT_MSG == 0) argv.append(gpa, "--allow-empty-message") catch util.oom();

    index_mod.discard();
    if (isRebaseI(opts) and flags & EDIT_MSG == 0) {
        // run_command_silent_on_success
        const r = os.run(argv.items, .{ .env = env.items, .capture_stdout = true, .stdout_to_stderr = false });
        index_mod.discard();
        if (r.status != 0 or r.signaled) {
            util.ewrite(r.stdout);
            return if (r.signaled) -1 else @intCast(r.status);
        }
        return 0;
    }
    const r = os.run(argv.items, .{ .env = env.items });
    index_mod.discard();
    if (r.signaled) return -1;
    return @intCast(r.status);
}

/// update_head_with_reflog()
pub fn updateHeadWithReflog(old_head: ?*Commit, new_head: Oid, action: ?[]const u8, msg: []const u8) bool {
    var sb: util.Buf = .empty;
    if (action) |a| {
        util.bufAppend(&sb, a);
        util.bufAppend(&sb, ": ");
    }
    if (std.mem.indexOfScalar(u8, msg, '\n')) |nl| {
        util.bufAppend(&sb, msg[0 .. nl + 1]);
    } else {
        util.bufAppend(&sb, msg);
        util.bufByte(&sb, '\n');
    }
    const old: Oid = if (old_head) |h| h.oid() else hash.zero;
    refs.update("HEAD", new_head, old, sb.items, false) catch {
        util.err("{s}", .{refs.last_error});
        return false;
    };
    return true;
}

fn runRewriteHook(oldoid: Oid, newoid: Oid) void {
    const data = util.fmt("{s} {s}\n", .{ hash.hex(oldoid), hash.hex(newoid) });
    _ = hook.run("post-rewrite", &.{"amend"}, .{ .stdin_data = data });
}

fn runPrepareCommitMsgHook(msg: []const u8, commit: ?[]const u8) i32 {
    const name = gitPath("COMMIT_EDITMSG");
    if (writeMessage(msg, name, false) != 0) return -1;
    const r = repo_mod.repo();
    const rc = if (commit) |c|
        hook.runCommitHook(false, r.indexPath(), null, "prepare-commit-msg", &.{ name, "commit", c })
    else
        hook.runCommitHook(false, r.indexPath(), null, "prepare-commit-msg", &.{ name, "message" });
    if (rc != 0) {
        util.err("'prepare-commit-msg' hook failed", .{});
        return -1;
    }
    return 0;
}

fn parseHead(head: *?*Commit) i32 {
    const oid = revparse.getOid("HEAD") orelse {
        head.* = null;
        return 0;
    };
    const c = cn.lookupCommitReference(oid) orelse {
        util.err("could not parse HEAD", .{});
        return -1;
    };
    if (!hash.eql(oid, c.oid())) util.warn("HEAD {s} is not a commit!", .{hash.hex(oid)});
    if (!cn.parse(c)) {
        util.err("could not parse HEAD commit", .{});
        return -1;
    }
    head.* = c;
    return 0;
}

/// read_commit_extra_headers() excluding gpgsig
fn readExtraHeaders(c: *Commit) []const u8 {
    _ = cn.parse(c);
    const buf = c.buffer;
    var b: util.Buf = .empty;
    var pos: usize = 0;
    var keep = false;
    while (pos < buf.len) {
        const eol = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse buf.len;
        const line = buf[pos..eol];
        if (line.len == 0) break;
        if (line[0] == ' ') {
            if (keep) {
                util.bufAppend(&b, line);
                util.bufByte(&b, '\n');
            }
        } else {
            const sp = std.mem.indexOfScalar(u8, line, ' ') orelse line.len;
            const key = line[0..sp];
            keep = !(util.eql(key, "tree") or util.eql(key, "parent") or util.eql(key, "author") or
                util.eql(key, "committer") or util.eql(key, "encoding") or util.eql(key, "gpgsig") or
                util.eql(key, "gpgsig-sha256"));
            if (keep) {
                util.bufAppend(&b, line);
                util.bufByte(&b, '\n');
            }
        }
        pos = eol + 1;
    }
    return b.items;
}

/// Split "Name <email> date tz" into parts.
fn splitIdent(id: []const u8) ?struct { name: []const u8, email: []const u8, date: []const u8 } {
    const lt = std.mem.indexOfScalar(u8, id, '<') orelse return null;
    const gt = std.mem.indexOfScalarPos(u8, id, lt, '>') orelse return null;
    const name = util.trim(id[0..lt]);
    const email = id[lt + 1 .. gt];
    const date = util.trim(id[gt + 1 ..]);
    return .{ .name = name, .email = email, .date = date };
}

/// try_to_commit(): -1 error, 0 success, 1 run 'git commit'
fn tryToCommit(msg_in: ?[]const u8, author_in: ?[]const u8, reflog_action: []const u8, opts: *Opts, flags: u32, oid_out: *Oid) i32 {
    const ident = @import("ident.zig");
    var current_head: ?*Commit = null;
    var msg: []const u8 = msg_in orelse "";
    var author = author_in;
    var parents: std.ArrayList(Oid) = .empty;
    var extra: []const u8 = "";
    var hook_commit: ?[]const u8 = null;
    var committer: ?[]const u8 = null;

    if (parseHead(&current_head) != 0) return -1;

    if (flags & AMEND_MSG != 0) {
        const ch = current_head.?;
        const message = pretty.logmsgReencode(ch, commitOutputEncoding()).msg;
        if (msg_in == null) {
            msg = findCommitSubject(message).rest;
            hook_commit = "HEAD";
        }
        author = getAuthor(message);
        if (author == null) {
            util.err("unable to parse commit author", .{});
            return -1;
        }
        var p = ch.parents;
        while (p) |n| : (p = n.next) parents.append(gpa, n.item.oid()) catch util.oom();
        extra = readExtraHeaders(ch);
    } else if (current_head != null and (flags & CREATE_ROOT_COMMIT == 0 or flags & AMEND_MSG != 0)) {
        parents.append(gpa, current_head.?.oid()) catch util.oom();
    }

    const tree = index_mod.get().writeTree(false) orelse {
        util.err("git write-tree failed to write a tree", .{});
        return -1;
    };

    if (flags & ALLOW_EMPTY == 0) {
        var first_parent = current_head;
        if (flags & AMEND_MSG != 0) {
            if (current_head.?.parents) |pl| {
                first_parent = pl.item;
                if (!cn.parse(pl.item)) {
                    util.err("could not parse HEAD commit", .{});
                    return -1;
                }
            } else first_parent = null;
        }
        if (hash.eql(commitTreeOid(first_parent), tree)) return 1;
    }

    if (hook.find("prepare-commit-msg") != null) {
        if (runPrepareCommitMsgHook(msg, hook_commit) != 0) return -1;
        msg = os.readFile(gitPath("COMMIT_EDITMSG")) orelse {
            util.err("unable to read commit message from '{s}': {s}", .{ gitPath("COMMIT_EDITMSG"), os.lastErr() });
            return -1;
        };
    }

    var cleanup: Cleanup = undefined;
    if (flags & CLEANUP_MSG != 0) {
        cleanup = .all;
    } else if ((opts.signoff or opts.record_origin) and !opts.explicit_cleanup) {
        cleanup = .space;
    } else cleanup = opts.default_msg_cleanup;

    if (cleanup != .none) msg = util.stripspace(msg, if (cleanup == .all) trailer.commentLineStr() else null);
    if (flags & EDIT_MSG != 0 and messageIsEmpty(msg, cleanup)) return 1;

    if (opts.committer_date_is_author_date) {
        var d: ?[]const u8 = null;
        if (!opts.ignore_date) {
            const sp = splitIdent(author.?) orelse {
                util.err("invalid author identity '{s}'", .{author.?});
                return -1;
            };
            if (sp.date.len == 0) {
                util.err("corrupt author: missing date information", .{});
                return -1;
            }
            d = util.concat(&.{ "@", sp.date });
        }
        const ne = ident.nameEmail(.committer, true);
        if (d) |dd| {
            const parsed = date_mod.parseDateString(dd) orelse dd;
            committer = util.fmt("{s} {s}", .{ ne, parsed });
        } else {
            committer = util.fmt("{s} {s}", .{ ne, nowDate() });
        }
    }

    if (opts.ignore_date) {
        const sp = splitIdent(author.?) orelse {
            util.err("invalid author identity '{s}'", .{author.?});
            return -1;
        };
        author = util.fmt("{s} <{s}> {s}", .{ sp.name, sp.email, nowDate() });
    }

    const oid = commit_mod.tryCreate(.{
        .tree = tree,
        .parents = parents.items,
        .message = msg,
        .author = author,
        .committer = committer,
        .extra_headers = extra,
        .sign = opts.gpg_sign,
    }) orelse {
        util.err("failed to write commit object", .{});
        return -1;
    };
    oid_out.* = oid;

    if (!updateHeadWithReflog(current_head, oid, reflog_action, msg)) return -1;

    _ = hook.runCommitHook(false, repo_mod.repo().indexPath(), null, "post-commit", &.{});
    if (flags & AMEND_MSG != 0) runRewriteHook(current_head.?.oid(), oid);
    return 0;
}

fn nowDate() []const u8 {
    return date_mod.datestamp();
}

fn restIsEmpty(sb: []const u8, start: usize) bool {
    const sign_off_header = "Signed-off-by: ";
    var i = start;
    while (i < sb.len) : (i += 1) {
        const eol = std.mem.indexOfScalarPos(u8, sb, i, '\n') orelse sb.len;
        if (sign_off_header.len <= eol - i and util.startsWith(sb[i..], sign_off_header)) {
            i = eol;
            continue;
        }
        while (i < eol) {
            if (!std.ascii.isWhitespace(sb[i])) return false;
            i += 1;
        }
    }
    return true;
}

fn messageIsEmpty(sb: []const u8, mode: Cleanup) bool {
    if (mode == .none and sb.len > 0) return false;
    return restIsEmpty(sb, 0);
}

fn writeRebaseHead(oid: Oid) i32 {
    refs.update("REBASE_HEAD", oid, null, "rebase", true) catch {
        util.err("{s}", .{refs.last_error});
        util.err("could not update {s}", .{"REBASE_HEAD"});
        return -1;
    };
    return 0;
}

fn doCommit(msg_file: ?[]const u8, author: ?[]const u8, reflog_action: []const u8, opts: *Opts, flags: u32, oid: ?Oid) i32 {
    var res: i32 = 1;
    if (flags & EDIT_MSG == 0 and flags & VERIFY_MSG == 0) {
        var new_oid: Oid = undefined;
        var sb: ?[]const u8 = null;
        if (msg_file) |f| {
            sb = os.readFile(f) orelse {
                util.err("unable to read commit message from '{s}': {s}", .{ f, os.lastErr() });
                return -1;
            };
        }
        res = tryToCommit(sb, author, reflog_action, opts, flags, &new_oid);
        if (res == 0) {
            refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "") catch {};
            _ = os.unlink(mergeMsgPath());
            if (!isRebaseI(opts)) summary.printCommitSummary(new_oid, summary.SUMMARY_SHOW_AUTHOR_DATE);
            return res;
        }
    }
    if (res == 1) {
        if (isRebaseI(opts)) {
            if (oid) |o| if (writeRebaseHead(o) != 0) return -1;
        }
        return runGitCommit(msg_file, reflog_action, opts, flags);
    }
    return res;
}

fn isOriginalCommitEmpty(commit: *Commit) i32 {
    if (!cn.parse(commit)) {
        util.err("could not parse commit {s}", .{hash.hex(commit.oid())});
        return -1;
    }
    var ptree: Oid = undefined;
    if (commit.parents) |p| {
        if (!cn.parse(p.item)) {
            util.err("could not parse parent commit {s}", .{hash.hex(p.item.oid())});
            return -1;
        }
        ptree = p.item.tree;
    } else ptree = hash.fromHex(hash.empty_tree_hex).?;
    return if (hash.eql(ptree, commit.tree)) 1 else 0;
}

fn allowEmpty(opts: *Opts, commit: *Commit) i32 {
    const index_unchanged = isIndexUnchanged();
    if (index_unchanged < 0) return index_unchanged;
    if (index_unchanged == 0) return 0;
    const originally_empty = isOriginalCommitEmpty(commit);
    if (originally_empty < 0) return originally_empty;
    if (originally_empty != 0) return if (opts.allow_empty) 1 else 0;
    if (opts.keep_redundant_commits) return 1;
    if (opts.drop_redundant_commits) return 2;
    return 0;
}

// ---------------------------------------------------------------------------
// todo list

pub const Command = enum(u8) {
    pick = 0,
    revert,
    edit,
    reword,
    fixup,
    squash,
    exec,
    break_,
    label,
    reset,
    merge,
    update_ref,
    noop,
    drop,
    comment,
    invalid,
};

const CmdInfo = struct { c: u8, str: []const u8 };
const todo_command_info = [_]CmdInfo{
    .{ .c = 'p', .str = "pick" },
    .{ .c = 0, .str = "revert" },
    .{ .c = 'e', .str = "edit" },
    .{ .c = 'r', .str = "reword" },
    .{ .c = 'f', .str = "fixup" },
    .{ .c = 's', .str = "squash" },
    .{ .c = 'x', .str = "exec" },
    .{ .c = 'b', .str = "break" },
    .{ .c = 'l', .str = "label" },
    .{ .c = 't', .str = "reset" },
    .{ .c = 'm', .str = "merge" },
    .{ .c = 'u', .str = "update-ref" },
    .{ .c = 0, .str = "noop" },
    .{ .c = 'd', .str = "drop" },
};

pub fn commandToString(c: Command) []const u8 {
    const i = @intFromEnum(c);
    if (i < @intFromEnum(Command.comment)) return todo_command_info[i].str;
    if (c == .comment) return trailer.commentLineStr();
    util.die("unknown command: {d}", .{i});
}

pub fn commandToChar(c: Command) u8 {
    const i = @intFromEnum(c);
    if (i < @intFromEnum(Command.comment)) return todo_command_info[i].c;
    return 0;
}

pub fn isNoop(c: Command) bool {
    return @intFromEnum(c) >= @intFromEnum(Command.noop);
}
pub fn isFixup(c: Command) bool {
    return c == .fixup or c == .squash;
}
fn isPickOrSimilar(c: Command) bool {
    return switch (c) {
        .pick, .revert, .edit, .reword, .fixup, .squash => true,
        else => false,
    };
}

pub const TODO_EDIT_MERGE_MSG: u32 = 1 << 0;
pub const TODO_REPLACE_FIXUP_MSG: u32 = 1 << 1;
pub const TODO_EDIT_FIXUP_MSG: u32 = 1 << 2;

pub const Item = struct {
    command: Command,
    commit: ?*Commit = null,
    flags: u32 = 0,
    arg_len: usize = 0,
    offset_in_buf: usize = 0,
    arg_offset: usize = 0,
};

pub const TodoList = struct {
    buf: util.Buf = .empty,
    items: std.ArrayList(Item) = .empty,
    current: usize = 0,
    done_nr: i32 = 0,
    total_nr: i32 = 0,

    pub fn getArg(self: *const TodoList, item: *const Item) []const u8 {
        return self.buf.items[item.arg_offset .. item.arg_offset + item.arg_len];
    }
    fn lineOffset(self: *const TodoList, index: usize) usize {
        return if (index < self.items.items.len) self.items.items[index].offset_in_buf else self.buf.items.len;
    }
    pub fn line(self: *const TodoList, index: usize) []const u8 {
        return self.buf.items[self.lineOffset(index)..self.lineOffset(index + 1)];
    }
};

/// is_command(): returns the rest after the command if bol starts with it.
fn isCommand(cmd: Command, bol: []const u8) ?[]const u8 {
    const info = todo_command_info[@intFromEnum(cmd)];
    var p: []const u8 = undefined;
    if (util.skipPrefix(bol, info.str)) |r| {
        p = r;
    } else if (info.c != 0 and bol.len > 0 and bol[0] == info.c) {
        p = bol[1..];
    } else if (info.c != 0 and bol.len > 0) {
        return null;
    } else return null;
    if (p.len == 0 or p[0] == ' ' or p[0] == '\t' or p[0] == '\n' or p[0] == '\r') return p;
    return null;
}

/// sequencer_parse_todo_command()
pub fn parseTodoCommand(p: []const u8) ?struct { cmd: Command, rest: []const u8 } {
    var i: u8 = 0;
    while (i < @intFromEnum(Command.comment)) : (i += 1) {
        const c: Command = @enumFromInt(i);
        if (isCommand(c, p)) |r| return .{ .cmd = c, .rest = r };
    }
    if (util.startsWith(p, trailer.commentLineStr())) return .{ .cmd = .comment, .rest = p };
    if (p.len == 0 or p[0] == '\n' or (p[0] == '\r' and p.len > 1 and p[1] == '\n')) return .{ .cmd = .comment, .rest = p };
    return null;
}

fn spanSpaces(s: []const u8) usize {
    var i: usize = 0;
    while (i < s.len and (s[i] == ' ' or s[i] == '\t')) i += 1;
    return i;
}

fn checkLabelOrRefArg(cmd: Command, arg: []const u8) i32 {
    switch (cmd) {
        .label => {
            if (util.eql(arg, "#") or !refs.checkRefnameFormat(arg, refs.ALLOW_ONELEVEL)) {
                util.err("'{s}' is not a valid label", .{arg});
                return -1;
            }
        },
        .update_ref => {
            if (!refs.checkRefnameFormat(arg, refs.ALLOW_ONELEVEL)) {
                util.err("'{s}' is not a valid refname", .{arg});
                return -1;
            }
            if (!refs.checkRefnameFormat(arg, 0)) {
                util.err("update-ref requires a fully qualified refname e.g. refs/heads/{s}", .{arg});
                return -1;
            }
        },
        else => {},
    }
    return 0;
}

fn checkMergeCommitInsn(cmd: Command) i32 {
    switch (cmd) {
        .pick => {
            util.err("'{s}' does not accept merge commits", .{"pick"});
            advice.adviseIfEnabled("rebaseTodoError", "'pick' does not take a merge commit. If you wanted to\nreplay the merge, use 'merge -C' on the commit.");
            return -1;
        },
        .reword => {
            util.err("'{s}' does not accept merge commits", .{"reword"});
            advice.adviseIfEnabled("rebaseTodoError", "'reword' does not take a merge commit. If you wanted to\nreplay the merge and reword the commit message, use\n'merge -c' on the commit");
            return -1;
        },
        .edit => {
            util.err("'{s}' does not accept merge commits", .{"edit"});
            advice.adviseIfEnabled("rebaseTodoError", "'edit' does not take a merge commit. If you wanted to\nreplay the merge, use 'merge -C' on the commit, and then\n'break' to give the control back to you so that you can\ndo 'git commit --amend && git rebase --continue'.");
            return -1;
        },
        .fixup, .squash => {
            util.err("cannot squash merge commit into another commit", .{});
            return -1;
        },
        else => return 0,
    }
}

/// parse_insn_line(); `bol`/`eol` are offsets into buf.
fn parseInsnLine(opts: *const Opts, item: *Item, buf: []const u8, bol0: usize, eol: usize) i32 {
    item.flags = 0;
    var bol = bol0 + spanSpaces(buf[bol0..eol]);
    const pr = parseTodoCommand(buf[bol..]) orelse {
        var e = bol;
        while (e < buf.len and buf[e] != ' ' and buf[e] != '\t' and buf[e] != '\r' and buf[e] != '\n') e += 1;
        util.err("invalid command '{s}'", .{buf[bol..e]});
        return -1;
    };
    item.command = pr.cmd;
    bol = buf.len - pr.rest.len;
    if (item.command == .comment) {
        item.commit = null;
        item.arg_offset = bol;
        item.arg_len = eol - bol;
        return 0;
    }
    const padding = spanSpaces(buf[bol..eol]);
    bol += padding;
    if (item.command == .noop or item.command == .break_) {
        if (bol != eol) {
            util.err("{s} does not accept arguments: '{s}'", .{ commandToString(item.command), buf[bol..eol] });
            return -1;
        }
        item.commit = null;
        item.arg_offset = bol;
        item.arg_len = 0;
        return 0;
    }
    if (padding == 0) {
        util.err("missing arguments for {s}", .{commandToString(item.command)});
        return -1;
    }
    if (item.command == .exec or item.command == .label or item.command == .reset or item.command == .update_ref) {
        item.commit = null;
        item.arg_offset = bol;
        item.arg_len = eol - bol;
        if (item.command == .label or item.command == .update_ref)
            return checkLabelOrRefArg(item.command, buf[bol..eol]);
        return 0;
    }
    if (item.command == .fixup) {
        if (util.startsWith(buf[bol..eol], "-C")) {
            bol += 2;
            bol += spanSpaces(buf[bol..eol]);
            item.flags |= TODO_REPLACE_FIXUP_MSG;
        } else if (util.startsWith(buf[bol..eol], "-c")) {
            bol += 2;
            bol += spanSpaces(buf[bol..eol]);
            item.flags |= TODO_EDIT_FIXUP_MSG;
        }
    }
    if (item.command == .merge) {
        if (util.startsWith(buf[bol..eol], "-C")) {
            bol += 2;
            bol += spanSpaces(buf[bol..eol]);
        } else if (util.startsWith(buf[bol..eol], "-c")) {
            bol += 2;
            bol += spanSpaces(buf[bol..eol]);
            item.flags |= TODO_EDIT_MERGE_MSG;
        } else {
            item.flags |= TODO_EDIT_MERGE_MSG;
            item.commit = null;
            item.arg_offset = bol;
            item.arg_len = eol - bol;
            return 0;
        }
    }
    var end = bol;
    while (end < buf.len and buf[end] != ' ' and buf[end] != '\t' and buf[end] != '\n') end += 1;
    const name = buf[bol..end];
    const oid = revparse.getOid(name);
    if (oid == null) util.err("could not parse '{s}'", .{name});
    bol = end + spanSpaces(buf[end..@max(end, eol)]);
    item.arg_offset = bol;
    item.arg_len = if (eol > bol) eol - bol else 0;
    if (oid == null) return -1;
    item.commit = cn.lookupCommitReference(oid.?);
    if (item.commit == null) return -1;
    if (isRebaseI(opts)) {
        _ = cn.parse(item.commit.?);
        if (item.commit.?.parents) |p| if (p.next != null) return checkMergeCommitInsn(item.command);
    }
    return 0;
}

pub const LastAction = enum { pick, revert };

/// sequencer_get_last_command()
pub fn getLastCommand() ?LastAction {
    const data = os.readFile(todoFile()) orelse return null;
    var i: usize = 0;
    while (i < data.len and (data[i] == ' ' or data[i] == '\t' or data[i] == '\r' or data[i] == '\n')) i += 1;
    const bol = data[i..];
    if (isCommand(.pick, bol)) |r| {
        if (r.len > 0 and (r[0] == ' ' or r[0] == '\t')) return .pick;
        return null;
    }
    if (isCommand(.revert, bol)) |r| {
        if (r.len > 0 and (r[0] == ' ' or r[0] == '\t')) return .revert;
    }
    return null;
}

/// todo_list_parse_insn_buffer(); returns 0 or -1.
pub fn parseInsnBuffer(opts: *const Opts, todo: *TodoList) i32 {
    const buf = todo.buf.items;
    var res: i32 = 0;
    var fixup_okay = os.exists(rebasePath("done"));
    todo.current = 0;
    todo.items = .empty;
    todo.total_nr = 0;
    var p: usize = 0;
    var lineno: usize = 1;
    while (p < buf.len) : (lineno += 1) {
        var eol = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse buf.len;
        const next_p = if (eol < buf.len) eol + 1 else eol;
        if (p != eol and buf[eol - 1] == '\r') eol -= 1;
        var item = Item{ .command = .comment, .offset_in_buf = p };
        if (parseInsnLine(opts, &item, buf, p, eol) != 0) {
            util.err("invalid line {d}: {s}", .{ lineno, buf[p..eol] });
            res = -1;
            item.command = .invalid;
            item.arg_offset = p;
            item.arg_len = eol - p;
            item.commit = null;
        }
        if (item.command != .comment) todo.total_nr += 1;
        if (fixup_okay) {} else if (isFixup(item.command)) {
            util.err("cannot '{s}' without a previous commit", .{commandToString(item.command)});
            res = -1;
        } else if (!isNoop(item.command)) fixup_okay = true;
        todo.items.append(gpa, item) catch util.oom();
        p = next_p;
    }
    return res;
}

fn countCommands(todo: *const TodoList) i32 {
    var n: i32 = 0;
    for (todo.items.items) |it| {
        if (it.command != .comment) n += 1;
    }
    return n;
}

fn readPopulateTodo(todo: *TodoList, opts: *Opts) i32 {
    const todo_file = getTodoPath(opts);
    todo.buf = .empty;
    const data = os.readFile(todo_file) orelse {
        util.err("could not open '{s}': {s}", .{ todo_file, os.lastErr() });
        return -1;
    };
    todo.buf.appendSlice(gpa, data) catch util.oom();
    if (parseInsnBuffer(opts, todo) != 0) {
        if (isRebaseI(opts)) {
            util.err("please fix this using 'git rebase --edit-todo'.", .{});
            return -1;
        }
        util.err("unusable instruction sheet: '{s}'", .{todo_file});
        return -1;
    }
    if (todo.items.items.len == 0 and (!isRebaseI(opts) or !os.exists(rebasePath("done")))) {
        util.err("no commits parsed.", .{});
        return -1;
    }
    if (!isRebaseI(opts)) {
        const valid: Command = if (opts.action == .pick) .pick else .revert;
        for (todo.items.items) |it| {
            if (it.command == valid) continue;
            if (valid == .pick) {
                util.err("cannot cherry-pick during a revert.", .{});
            } else util.err("cannot revert during a cherry-pick.", .{});
            return -1;
        }
    }
    if (isRebaseI(opts)) {
        var done = TodoList{};
        if (os.readFile(rebasePath("done"))) |d| {
            if (d.len > 0) {
                done.buf.appendSlice(gpa, d) catch util.oom();
                todo.done_nr = if (parseInsnBuffer(opts, &done) == 0) countCommands(&done) else 0;
            } else todo.done_nr = 0;
        } else todo.done_nr = 0;
        todo.total_nr = todo.done_nr + countCommands(todo);
        writeFile(rebasePath("end"), util.fmt("{d}\n", .{todo.total_nr}));
    }
    return 0;
}

// ---------------------------------------------------------------------------
// options sheet

const PopulateCtx = struct { opts: *Opts };

fn populateOptsCb(ctxp: *anyopaque, key: []const u8, value: ?[]const u8, kvi: *const config.KvInfo) i32 {
    const ctx: *PopulateCtx = @ptrCast(@alignCast(ctxp));
    const opts = ctx.opts;
    var is_bool = false;
    var error_flag = true;
    const v = value orelse {
        util.err("invalid value for '{s}': '{s}'", .{ key, "" });
        return -1;
    };
    _ = &is_bool;
    if (util.eql(key, "options.no-commit")) {
        opts.no_commit = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.edit")) {
        opts.edit = if (boolOrInt(key, v, kvi, &error_flag)) 1 else 0;
    } else if (util.eql(key, "options.allow-empty")) {
        opts.allow_empty = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.allow-empty-message")) {
        opts.allow_empty_message = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.drop-redundant-commits")) {
        opts.drop_redundant_commits = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.keep-redundant-commits")) {
        opts.keep_redundant_commits = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.signoff")) {
        opts.signoff = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.record-origin")) {
        opts.record_origin = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.allow-ff")) {
        opts.allow_ff = boolOrInt(key, v, kvi, &error_flag);
    } else if (util.eql(key, "options.mainline")) {
        opts.mainline = config.configInt(key, v, kvi);
    } else if (util.eql(key, "options.strategy")) {
        opts.strategy = util.dupe(v);
    } else if (util.eql(key, "options.gpg-sign")) {
        opts.gpg_sign = util.dupe(v);
    } else if (util.eql(key, "options.strategy-option")) {
        opts.xopts.append(gpa, util.dupe(v)) catch util.oom();
    } else if (util.eql(key, "options.allow-rerere-auto")) {
        opts.allow_rerere_auto = if (boolOrInt(key, v, kvi, &error_flag)) RERERE_AUTOUPDATE else RERERE_NOAUTOUPDATE;
    } else if (util.eql(key, "options.default-msg-cleanup")) {
        opts.explicit_cleanup = true;
        opts.default_msg_cleanup = c_commit.getCleanupMode(v, true);
    } else {
        util.err("invalid key: {s}", .{key});
        return -1;
    }
    if (!error_flag) {
        util.err("invalid value for '{s}': '{s}'", .{ key, v });
        return -1;
    }
    return 0;
}

fn boolOrInt(key: []const u8, v: []const u8, kvi: *const config.KvInfo, ok: *bool) bool {
    var is_bool = false;
    const r = config.configBoolOrInt(key, v, kvi, &is_bool);
    ok.* = true;
    return r != 0;
}

fn parseStrategyOpts(opts: *Opts, raw: []const u8) void {
    var s = raw;
    if (s.len > 0 and s[0] == ' ') s = s[1..];
    const argv = @import("commands.zig").splitCmdline(s) orelse util.die("could not split '{s}'", .{s});
    for (argv) |a| {
        const arg = util.skipPrefix(a, "--") orelse a;
        opts.xopts.append(gpa, arg) catch util.oom();
    }
}

fn readStrategyOpts(opts: *Opts) void {
    const s = readOneliner(rebasePath("strategy"), false, false) orelse return;
    opts.strategy = s;
    const o = readOneliner(rebasePath("strategy_opts"), false, false) orelse return;
    parseStrategyOpts(opts, o);
}

fn readTrailers(opts: *Opts) i32 {
    const data = os.readFile(rebasePath("trailer")) orelse {
        if (os.errno() != os.ENOENT) {
            util.err("cannot read trailers files", .{});
            return -1;
        }
        return 0;
    };
    if (data.len == 0) {
        util.err("trailers file is empty", .{});
        return -1;
    }
    var p: []const u8 = data;
    while (std.mem.indexOfScalar(u8, p, '\n')) |nl| {
        if (nl == 0) {
            util.err("trailers file contains empty line", .{});
            return -1;
        }
        opts.trailer_args.append(gpa, p[0..nl]) catch util.oom();
        p = p[nl + 1 ..];
    }
    return 0;
}

pub fn readPopulateOpts(opts: *Opts) i32 {
    if (isRebaseI(opts)) {
        if (readOneliner(rebasePath("gpg_sign_opt"), false, true)) |b| {
            if (util.startsWith(b, "-S")) opts.gpg_sign = b[2..];
        }
        if (readOneliner(rebasePath("allow_rerere_autoupdate"), false, true)) |b| {
            if (util.eql(b, "--rerere-autoupdate")) {
                opts.allow_rerere_auto = RERERE_AUTOUPDATE;
            } else if (util.eql(b, "--no-rerere-autoupdate")) opts.allow_rerere_auto = RERERE_NOAUTOUPDATE;
        }
        if (os.exists(rebasePath("verbose"))) opts.verbose = true;
        if (os.exists(rebasePath("quiet"))) opts.quiet = true;
        if (os.exists(rebasePath("signoff"))) {
            opts.allow_ff = false;
            opts.signoff = true;
        }
        if (os.exists(rebasePath("cdate_is_adate"))) {
            opts.allow_ff = false;
            opts.committer_date_is_author_date = true;
        }
        if (os.exists(rebasePath("ignore_date"))) {
            opts.allow_ff = false;
            opts.ignore_date = true;
        }
        if (os.exists(rebasePath("reschedule-failed-exec"))) {
            opts.reschedule_failed_exec = true;
        } else if (os.exists(rebasePath("no-reschedule-failed-exec"))) opts.reschedule_failed_exec = false;
        if (os.exists(rebasePath("drop_redundant_commits"))) opts.drop_redundant_commits = true;
        if (os.exists(rebasePath("keep_redundant_commits"))) opts.keep_redundant_commits = true;
        readStrategyOpts(opts);
        if (readTrailers(opts) != 0) return -1;
        if (readOneliner(rebasePath("current-fixups"), false, true)) |cf| {
            opts.current_fixups = .empty;
            opts.current_fixups.appendSlice(gpa, cf) catch util.oom();
            opts.current_fixup_count = 1;
            var i: usize = 0;
            while (std.mem.indexOfScalarPos(u8, cf, i, '\n')) |nl| {
                if (nl + 1 < cf.len and cf[nl + 1] != '\n') opts.current_fixup_count += 1;
                i = nl + 1;
            }
        }
        if (readOneliner(rebasePath("squash-onto"), false, false)) |so| {
            opts.squash_onto = revparse.getOidCommittish(so) orelse {
                util.err("unusable squash-onto", .{});
                return -1;
            };
            opts.have_squash_onto = true;
        }
        return 0;
    }
    if (!os.exists(optsFile())) return 0;
    var ctx = PopulateCtx{ .opts = opts };
    if (config.fromFile(.{ .f = populateOptsCb, .ctx = &ctx }, optsFile(), .local, null, null) < 0) {
        util.err("malformed options sheet: '{s}'", .{optsFile()});
        return -1;
    }
    return 0;
}

fn saveOpts(opts: *Opts) i32 {
    const f = optsFile();
    var res: i32 = 0;
    if (opts.no_commit) res |= config.setInFileGently(f, "options.no-commit", null, "true");
    if (opts.edit >= 0) res |= config.setInFileGently(f, "options.edit", null, if (opts.edit != 0) "true" else "false");
    if (opts.allow_empty) res |= config.setInFileGently(f, "options.allow-empty", null, "true");
    if (opts.allow_empty_message) res |= config.setInFileGently(f, "options.allow-empty-message", null, "true");
    if (opts.drop_redundant_commits) res |= config.setInFileGently(f, "options.drop-redundant-commits", null, "true");
    if (opts.keep_redundant_commits) res |= config.setInFileGently(f, "options.keep-redundant-commits", null, "true");
    if (opts.signoff) res |= config.setInFileGently(f, "options.signoff", null, "true");
    if (opts.record_origin) res |= config.setInFileGently(f, "options.record-origin", null, "true");
    if (opts.allow_ff) res |= config.setInFileGently(f, "options.allow-ff", null, "true");
    if (opts.mainline != 0) res |= config.setInFileGently(f, "options.mainline", null, util.fmt("{d}", .{opts.mainline}));
    if (opts.strategy) |s| res |= config.setInFileGently(f, "options.strategy", null, s);
    if (opts.gpg_sign) |g| res |= config.setInFileGently(f, "options.gpg-sign", null, g);
    for (opts.xopts.items) |x| res |= config.setMultivarInFile(f, "options.strategy-option", x, .{ .pattern = "^$" }, null, .{});
    if (opts.allow_rerere_auto != 0) res |= config.setInFileGently(f, "options.allow-rerere-auto", null, if (opts.allow_rerere_auto == RERERE_AUTOUPDATE) "true" else "false");
    if (opts.explicit_cleanup) res |= config.setInFileGently(f, "options.default-msg-cleanup", null, describeCleanupMode(opts.default_msg_cleanup));
    return res;
}

// ---------------------------------------------------------------------------
// state

fn removeTree(path: []const u8) bool {
    const st = os.lstatPath(path) orelse return true;
    if (st.isDir()) {
        if (os.listDir(path)) |ents| {
            for (ents) |de| _ = removeTree(util.concat(&.{ path, "/", de.name }));
        }
        return os.rmdir(path);
    }
    return os.unlink(path);
}

/// sequencer_remove_state()
pub fn removeState(opts: *Opts) i32 {
    var ret: i32 = 0;
    if (isRebaseI(opts)) {
        if (os.readFile(rebasePath("refs-to-delete"))) |data| {
            var it = std.mem.splitScalar(u8, data, '\n');
            while (it.next()) |p| {
                if (p.len == 0) continue;
                refs.deleteRef(p, null, 0, "(rebase) cleanup") catch {
                    util.warn("could not delete '{s}'", .{p});
                    ret = -1;
                };
            }
        }
    }
    const dir = getDir(opts);
    if (os.exists(dir) and !removeTree(dir)) {
        util.err("could not remove '{s}'", .{dir});
        ret = -1;
    }
    return ret;
}

fn walkRevsPopulateTodo(todo: *TodoList, opts: *Opts) i32 {
    const command: Command = if (opts.action == .pick) .pick else .revert;
    const command_string = todo_command_info[@intFromEnum(command)].str;
    const revs = opts.revs.?;
    if (opts.action == .pick and !revs.no_walk) revs.reverse = !revs.reverse;
    if (!revision.prepareRevisionWalk(revs)) {
        util.err("revision walk setup failed", .{});
        return -1;
    }
    const encoding = pretty.logOutputEncoding();
    while (revision.getRevision(revs)) |commit| {
        const buf = pretty.logmsgReencode(commit, encoding).msg;
        const s = findCommitSubject(buf);
        const item = Item{ .command = command, .commit = commit, .offset_in_buf = todo.buf.items.len };
        util.bufPrint(&todo.buf, "{s} {s} {s}\n", .{ command_string, shortCommitName(commit), s.rest[0..s.len] });
        todo.items.append(gpa, item) catch util.oom();
    }
    if (todo.items.items.len == 0) {
        util.err("empty commit set passed", .{});
        return -1;
    }
    return 0;
}

fn createSeqDir() i32 {
    const advise_skip = refs.exists("REVERT_HEAD") or refs.exists("CHERRY_PICK_HEAD");
    const skip_s: []const u8 = if (advise_skip) "--skip | " else "";
    if (getLastCommand()) |action| {
        switch (action) {
            .revert => {
                util.err("revert is already in progress", .{});
                if (advice.enabled("sequencerInUse")) advice.advise(util.fmt("try \"git revert (--continue | {s}--abort | --quit)\"", .{skip_s}));
            },
            .pick => {
                util.err("cherry-pick is already in progress", .{});
                if (advice.enabled("sequencerInUse")) advice.advise(util.fmt("try \"git cherry-pick (--continue | {s}--abort | --quit)\"", .{skip_s}));
            },
        }
        return -1;
    }
    if (!os.mkdir(seqDir(), 0o777)) {
        util.err("could not create sequencer directory '{s}': {s}", .{ seqDir(), os.lastErr() });
        return -1;
    }
    return 0;
}

fn saveHead(head: []const u8) i32 {
    return writeMessage(head, headFile(), true);
}

fn rollbackIsSafe() bool {
    var expected: Oid = hash.zero;
    if (os.readFile(abortSafetyFile())) |data| {
        const t = util.trim(data);
        expected = hash.fromHex(t) orelse blk: {
            if (t.len == 0) util.die("could not parse {s}", .{abortSafetyFile()});
            util.die("could not parse {s}", .{abortSafetyFile()});
            break :blk hash.zero;
        };
    } else if (os.errno() != os.ENOENT) {
        util.dieErrno("could not read '{s}'", .{abortSafetyFile()});
    }
    const actual = revparse.getOid("HEAD") orelse hash.zero;
    return hash.eql(actual, expected);
}

fn resetMerge(oid: Oid) i32 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "reset", "--merge" }) catch util.oom();
    if (!hash.isZero(oid)) argv.append(gpa, hash.hexAlloc(oid)) catch util.oom();
    index_mod.discard();
    const r = os.run(argv.items, .{});
    index_mod.discard();
    return if (r.status != 0 or r.signaled) 1 else 0;
}

fn rollbackSinglePick() i32 {
    if (!refs.exists("CHERRY_PICK_HEAD") and !refs.exists("REVERT_HEAD")) {
        util.err("no cherry-pick or revert in progress", .{});
        return -1;
    }
    const head = refs.readOid("HEAD") orelse {
        if (refs.readSymbolic("HEAD") != null) {
            util.err("cannot abort from a branch yet to be born", .{});
            return -1;
        }
        util.err("cannot resolve HEAD", .{});
        return -1;
    };
    return resetMerge(head);
}

fn skipSinglePick() i32 {
    const head = refs.readOid("HEAD") orelse {
        util.err("cannot resolve HEAD", .{});
        return -1;
    };
    return resetMerge(head);
}

/// sequencer_rollback()
pub fn rollback(opts: *Opts) i32 {
    const data = os.readFile(headFile()) orelse {
        if (os.errno() == os.ENOENT) return rollbackSinglePick();
        util.err("cannot open '{s}': {s}", .{ headFile(), os.lastErr() });
        return -1;
    };
    if (data.len == 0) {
        util.err("cannot read '{s}': {s}", .{ headFile(), "unexpected end of file" });
        return -1;
    }
    const line = if (std.mem.indexOfScalar(u8, data, '\n')) |nl| data[0..nl] else data;
    const oid = (if (line.len == 40) hash.fromHex(line) else null) orelse {
        util.err("stored pre-cherry-pick HEAD file '{s}' is corrupt", .{headFile()});
        return -1;
    };
    if (hash.isZero(oid)) {
        util.err("cannot abort from a branch yet to be born", .{});
        return -1;
    }
    if (!rollbackIsSafe()) {
        util.warn("You seem to have moved HEAD. Not rewinding, check your HEAD!", .{});
    } else if (resetMerge(oid) != 0) return -1;
    return removeState(opts);
}

/// sequencer_skip()
pub fn skip(opts: *Opts) i32 {
    const action = getLastCommand();
    var give_advice = false;
    switch (opts.action) {
        .revert => {
            if (!refs.exists("REVERT_HEAD")) {
                if (action != .revert) {
                    util.err("no revert in progress", .{});
                    return -1;
                }
                if (!rollbackIsSafe()) give_advice = true;
            }
        },
        .pick => {
            if (!refs.exists("CHERRY_PICK_HEAD")) {
                if (action != .pick) {
                    util.err("no cherry-pick in progress", .{});
                    return -1;
                }
                if (!rollbackIsSafe()) give_advice = true;
            }
        },
        else => unreachable,
    }
    if (give_advice) {
        util.err("there is nothing to skip", .{});
        if (advice.enabled("resolveConflict")) {
            advice.advise(util.fmt("have you committed already?\ntry \"git {s} --continue\"", .{if (action == .revert) "revert" else "cherry-pick"}));
        }
        return -1;
    }
    if (skipSinglePick() != 0) {
        util.err("failed to skip the commit", .{});
        return -1;
    }
    if (!os.isDir(seqDir())) return 0;
    return sequencerContinue(opts);
}

fn saveTodo(todo: *TodoList, opts: *Opts, reschedule: bool) i32 {
    const todo_path = getTodoPath(opts);
    var next = todo.current;
    if (isRebaseI(opts) and !reschedule) next += 1;
    const l = switch (lockfile.tryLock(todo_path)) {
        .ok => |l| l,
        .err => {
            util.err("could not lock '{s}': {s}", .{ todo_path, os.lastErr() });
            return -1;
        },
    };
    const offset = todo.lineOffset(next);
    l.write(todo.buf.items[offset..]);
    if (!l.commit()) {
        util.err("failed to finalize '{s}'", .{todo_path});
        return -1;
    }
    if (isRebaseI(opts) and !reschedule and next > 0) {
        const done = rebasePath("done");
        const prev = os.readFile(done) orelse "";
        os.writeFile(done, util.concat(&.{ prev, todo.line(next - 1) }), 0o666) catch {
            util.err("could not write to '{s}'", .{done});
            return -1;
        };
    }
    return 0;
}

// ---------------------------------------------------------------------------
// picking

fn shouldEdit(opts: *const Opts) bool {
    if (opts.edit < 0) return opts.action == .revert and os.isatty(0);
    return opts.edit != 0;
}

fn referToCommit(msgbuf: *util.Buf, commit: *Commit, use_ref: bool) void {
    if (use_ref) {
        const ctx = pretty.Context{ .abbrev = revparse.defaultAbbrev(), .date_mode = date_mod.DateMode.of(.short) };
        pretty.formatCommitMessage(commit, "%h (%s, %ad)", msgbuf, &ctx);
    } else {
        util.bufAppend(msgbuf, &hash.hex(commit.oid()));
    }
}

pub fn reflogAction(opts: *Opts) []const u8 {
    if (opts.reflog_action == null) {
        opts.reflog_action = os.getenv("GIT_REFLOG_ACTION") orelse actionName(opts);
    }
    return opts.reflog_action.?;
}

pub fn reflogMessage(opts: *Opts, sub_action: ?[]const u8, msg: ?[]const u8) []const u8 {
    var b: util.Buf = .empty;
    util.bufAppend(&b, reflogAction(opts));
    if (sub_action) |s| util.bufPrint(&b, " ({s})", .{s});
    if (msg) |m| {
        util.bufAppend(&b, ": ");
        util.bufAppend(&b, m);
    }
    return b.items;
}

/// sequencer_format_revert_message()
pub fn formatRevertMessage(subject: []const u8, commit: *Commit, parent: ?*Commit, use_ref: bool, message: *util.Buf) void {
    if (use_ref) {
        commentedAdd(message, "*** SAY WHY WE ARE REVERTING ON THE TITLE LINE ***");
        if (message.items.len == 0 or message.items[message.items.len - 1] != '\n') util.bufByte(message, '\n');
    } else if (util.skipPrefix(subject, "Revert \"")) |orig| {
        if (!util.startsWith(orig, "Revert \"")) {
            util.bufAppend(message, "Reapply \"");
            util.bufAppend(message, orig);
            util.bufAppend(message, "\n");
        } else {
            util.bufAppend(message, "Revert \"");
            util.bufAppend(message, subject);
            util.bufAppend(message, "\"\n");
        }
    } else {
        util.bufAppend(message, "Revert \"");
        util.bufAppend(message, subject);
        util.bufAppend(message, "\"\n");
    }
    util.bufAppend(message, "\nThis reverts commit ");
    referToCommit(message, commit, use_ref);
    if (commit.parents) |p| {
        if (p.next != null) {
            util.bufAppend(message, ", reversing\nchanges made to ");
            referToCommit(message, parent.?, use_ref);
        }
    }
    util.bufAppend(message, ".\n");
}

const cherry_picked_prefix = "(cherry picked from commit ";

pub const PickResult = enum { err, ok, conflicts, dropped };

fn tryMergeCommand(strategy: []const u8, xopts: []const []const u8, base: ?*Commit, head: Oid, remote: ?*Commit) i32 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.append(gpa, util.concat(&.{ "merge-", strategy })) catch util.oom();
    for (xopts) |x| argv.append(gpa, util.concat(&.{ "--", x })) catch util.oom();
    argv.append(gpa, if (base) |b| hash.hexAlloc(b.oid()) else hash.empty_tree_hex) catch util.oom();
    argv.append(gpa, "--") catch util.oom();
    argv.append(gpa, hash.hexAlloc(head)) catch util.oom();
    argv.append(gpa, if (remote) |r| hash.hexAlloc(r.oid()) else hash.empty_tree_hex) catch util.oom();
    index_mod.discard();
    const r = os.run(argv.items, .{});
    index_mod.discard();
    if (r.signaled) return -1;
    return @intCast(r.status);
}


fn doPickCommit(item: *Item, opts: *Opts, final_fixup: bool, check_todo: *bool) PickResult {
    var flags: u32 = if (shouldEdit(opts)) EDIT_MSG else 0;
    var msg_file: ?[]const u8 = if (shouldEdit(opts)) null else mergeMsgPath();
    var head: Oid = undefined;
    var unborn = false;
    var reword = false;
    var drop_commit = false;
    var author: ?[]const u8 = null;
    const command = item.command;
    const commit = item.commit.?;
    var res: i32 = 0;

    const reflog_action = if (isRebaseI(opts)) reflogMessage(opts, commandToString(command), null) else reflogAction(opts);

    if (opts.no_commit) {
        head = index_mod.get().writeTree(false) orelse {
            util.err("your index file is unmerged.", .{});
            return .err;
        };
    } else {
        const h = revparse.getOid("HEAD");
        unborn = h == null;
        if (h) |hh| head = hh;
        if (isPickOrSimilar(command) and opts.have_squash_onto and h != null and hash.eql(head, opts.squash_onto)) {
            if (isFixup(command)) {
                util.err("cannot fixup root commit", .{});
                return .err;
            }
            flags |= CREATE_ROOT_COMMIT;
            unborn = true;
        } else if (unborn) head = hash.fromHex(hash.empty_tree_hex).?;
        const cmp_tree = objects.peelTo(head, .tree) orelse head;
        if (mo.indexChangesAgainst(cmp_tree).len > 0) {
            if (errorDirtyIndex(opts) < 0) return .err;
        }
    }
    index_mod.discard();

    _ = cn.parse(commit);
    var parent: ?*Commit = null;
    if (commit.parents == null) {
        parent = null;
    } else if (commit.parents.?.next != null) {
        if (opts.mainline == 0) {
            util.err("commit {s} is a merge but no -m option was given.", .{hash.hex(commit.oid())});
            return .err;
        }
        var cnt: i32 = 1;
        var p = commit.parents;
        while (cnt != opts.mainline and p != null) : (cnt += 1) p = p.?.next;
        if (cnt != opts.mainline or p == null) {
            util.err("commit {s} does not have parent {d}", .{ hash.hex(commit.oid()), opts.mainline });
            return .err;
        }
        parent = p.?.item;
    } else if (1 < opts.mainline) {
        util.err("commit {s} does not have parent {d}", .{ hash.hex(commit.oid()), opts.mainline });
        return .err;
    } else parent = commit.parents.?.item;

    const msg = getMessage(commit);

    leave: {
        if (opts.allow_ff and !isFixup(command) and
            ((parent != null and hash.eql(parent.?.oid(), head)) or (parent == null and unborn)))
        {
            if (isRebaseI(opts)) _ = writeAuthorScript(msg.message);
            res = fastForwardTo(commit.oid(), head, unborn, opts);
            if (res != 0 or command != .reword) break :leave;
            reword = true;
            msg_file = null;
            // fast_forward_edit
            flags = EDIT_MSG | VERIFY_MSG | AMEND_MSG | ALLOW_EMPTY;
            res = runGitCommit(null, reflog_action, opts, flags);
            check_todo.* = true;
            res = if (res != 0) 1 else 0;
            if (res == 0 and final_fixup) finalFixupCleanup(opts);
            break :leave;
        }
        if (parent) |p| {
            if (!cn.parse(p)) {
                util.err("{s}: cannot parse parent commit {s}", .{ commandToString(command), hash.hex(p.oid()) });
                return .err;
            }
        }

        var base: ?*Commit = undefined;
        var next: ?*Commit = undefined;
        var base_label: []const u8 = undefined;
        var next_label: []const u8 = undefined;
        if (command == .revert) {
            base = commit;
            base_label = msg.label;
            next = parent;
            next_label = msg.parent_label;
            formatRevertMessage(msg.subject, commit, parent, opts.commit_use_reference, &opts.message);
        } else {
            base = parent;
            base_label = msg.parent_label;
            next = commit;
            next_label = msg.label;
            const s = findCommitSubject(msg.message);
            util.bufAppend(&opts.message, s.rest);
            if (opts.record_origin) {
                if (opts.message.items.len > 0 and opts.message.items[opts.message.items.len - 1] != '\n') util.bufByte(&opts.message, '\n');
                if (c_commit.hasConformingFooter(opts.message.items, "\x00", 0) == 0) util.bufByte(&opts.message, '\n');
                util.bufAppend(&opts.message, cherry_picked_prefix);
                util.bufAppend(&opts.message, &hash.hex(commit.oid()));
                util.bufAppend(&opts.message, ")\n");
            }
            if (!isFixup(command)) author = getAuthor(msg.message);
        }
        opts.have_message = true;

        if (command == .reword) {
            reword = true;
        } else if (isFixup(command)) {
            if (updateSquashMessages(command, commit, opts, item.flags) != 0) {
                res = -1;
                break :leave;
            }
            flags |= AMEND_MSG;
            if (!final_fixup) {
                msg_file = rebasePath("message-squash");
            } else if (os.exists(rebasePath("message-fixup"))) {
                msg_file = rebasePath("message-fixup");
            } else {
                const dest = gitPath("SQUASH_MSG");
                _ = os.unlink(dest);
                const data = os.readFile(rebasePath("message-squash")) orelse {
                    util.err("could not copy '{s}' to '{s}'", .{ rebasePath("message-squash"), dest });
                    res = -1;
                    break :leave;
                };
                os.writeFile(dest, data, 0o666) catch {
                    util.err("could not copy '{s}' to '{s}'", .{ rebasePath("message-squash"), dest });
                    res = -1;
                    break :leave;
                };
                _ = os.unlink(mergeMsgPath());
                msg_file = dest;
                flags |= EDIT_MSG;
            }
        }

        if (opts.signoff and !isFixup(command)) c_commit.appendSignoff(&opts.message, 0, false);
        if (opts.trailer_args.items.len > 0 and !isFixup(command)) amendWithTrailers(&opts.message, opts.trailer_args.items);

        if (isRebaseI(opts) and writeAuthorScript(msg.message) < 0) {
            res = -1;
        } else if (opts.strategy == null or util.eql(opts.strategy.?, "recursive") or util.eql(opts.strategy.?, "ort") or command == .revert) {
            res = doRecursiveMerge(base, next, base_label, next_label, head, &opts.message, opts);
            if (res < 0) break :leave;
            res |= writeMessage(opts.message.items, mergeMsgPath(), false);
        } else {
            if (writeMessage(opts.message.items, mergeMsgPath(), false) != 0) {
                res = -1;
                break :leave;
            }
            res = tryMergeCommand(opts.strategy.?, opts.xopts.items, base, head, next);
            if (res != 0 and res != 1) res = -1;
        }

        if ((command == .pick or command == .reword or command == .edit) and !opts.no_commit and (res == 0 or res == 1)) {
            refs.update("CHERRY_PICK_HEAD", commit.oid(), null, "", true) catch {
                util.err("{s}", .{refs.last_error});
                res = -1;
            };
        }
        if (command == .revert and ((opts.no_commit and res == 0) or res == 1)) {
            refs.update("REVERT_HEAD", commit.oid(), null, "", true) catch {
                util.err("{s}", .{refs.last_error});
                res = -1;
            };
        }

        if (res != 0) {
            if (command == .revert) {
                util.err("could not revert {s}... {s}", .{ shortCommitName(commit), msg.subject });
            } else util.err("could not apply {s}... {s}", .{ shortCommitName(commit), msg.subject });
            printAdvice(res == 1, opts);
            _ = @import("rerere.zig").rerere(@intCast(opts.allow_rerere_auto));
            break :leave;
        }

        const allow = allowEmpty(opts, commit);
        if (allow < 0) {
            res = allow;
            break :leave;
        } else if (allow == 1) {
            flags |= ALLOW_EMPTY;
        } else if (allow == 2) {
            drop_commit = true;
            refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "") catch {};
            _ = os.unlink(mergeMsgPath());
            refs.deleteRef("AUTO_MERGE", null, refs.F_NO_DEREF, "") catch {};
            util.eprint("dropping {s} {s} -- patch contents already upstream\n", .{ hash.hex(commit.oid()), msg.subject });
        }
        if (!opts.no_commit and !drop_commit) {
            if (author != null or command == .revert or flags & AMEND_MSG != 0) {
                res = doCommit(msg_file, author, reflog_action, opts, flags, commit.oid());
            } else {
                util.err("unable to parse commit author", .{});
                res = -1;
            }
            check_todo.* = flags & EDIT_MSG != 0;
            if (res == 0 and reword) {
                flags = EDIT_MSG | VERIFY_MSG | AMEND_MSG | ALLOW_EMPTY;
                res = runGitCommit(null, reflog_action, opts, flags);
                check_todo.* = true;
            }
            res = if (res != 0) 1 else 0;
        }
        if (res == 0 and final_fixup) finalFixupCleanup(opts);
    }

    updateAbortSafetyFile();
    if (res < 0) return .err;
    if (res > 0) return .conflicts;
    if (drop_commit) return .dropped;
    return .ok;
}

fn finalFixupCleanup(opts: *Opts) void {
    _ = os.unlink(rebasePath("message-fixup"));
    _ = os.unlink(rebasePath("message-squash"));
    _ = os.unlink(rebasePath("current-fixups"));
    opts.current_fixups = .empty;
    opts.current_fixup_count = 0;
}

/// amend_strbuf_with_trailers(): run interpret-trailers over the message.
pub fn amendWithTrailers(buf: *util.Buf, args: []const []const u8) void {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "interpret-trailers" }) catch util.oom();
    for (args) |a| argv.append(gpa, util.concat(&.{ "--trailer=", a })) catch util.oom();
    const r = os.run(argv.items, .{ .stdin_data = buf.items, .capture_stdout = true });
    if (r.status != 0 or r.signaled) util.die("failed to add trailers", .{});
    buf.* = .empty;
    buf.appendSlice(gpa, r.stdout) catch util.oom();
}

fn readAndRefreshCache(opts: *Opts) i32 {
    index_mod.discard();
    const idx = switch (lockfile.tryLock(repo_mod.repo().indexPath())) {
        .ok => |l| blk: {
            l.rollback();
            break :blk index_mod.lockAndRead();
        },
        .err => index_mod.get(),
    };
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET | index_mod.REFRESH_UNMERGED, @as(?*const pathspec_mod.Pathspec, null), null);
    if (idx.lock != null) {
        if (idx.changed) idx.write() else idx.rollback();
    }
    // merge strategies other than "ort" need the full index
    if (opts.strategy) |s| {
        if (!util.eql(s, "ort")) @import("sparse_index.zig").ensureFull(index_mod.get());
    }
    return 0;
}

fn pickCommits(todo: *TodoList, opts: *Opts) i32 {
    if (isRebaseI(opts)) return pickCommitsRebase(todo, opts);
    if (readAndRefreshCache(opts) != 0) return -1;
    while (todo.current < todo.items.items.len) {
        const item = &todo.items.items[todo.current];
        var check_todo = false;
        if (saveTodo(todo, opts, false) != 0) return -1;
        opts.message = .empty;
        opts.have_message = false;
        if (@intFromEnum(item.command) <= @intFromEnum(Command.squash)) {
            const r = doPickCommit(item, opts, false, &check_todo);
            switch (r) {
                .err => return -1,
                .conflicts => return 1,
                else => {},
            }
        } else if (!isNoop(item.command)) {
            util.err("unknown command {d}", .{@intFromEnum(item.command)});
            return -1;
        }
        todo.current += 1;
    }
    return removeState(opts);
}

fn continueSinglePick(opts: *Opts) i32 {
    if (!refs.exists("CHERRY_PICK_HEAD") and !refs.exists("REVERT_HEAD")) {
        util.err("no cherry-pick or revert in progress", .{});
        return -1;
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "commit" }) catch util.oom();
    if (opts.edit == 0 or (opts.edit < 0 and !os.isatty(0)))
        argv.appendSlice(gpa, &.{ "--no-edit", "--cleanup=strip" }) catch util.oom();
    index_mod.discard();
    const r = os.run(argv.items, .{});
    index_mod.discard();
    if (r.signaled) return -1;
    return @intCast(r.status);
}


/// sequencer_continue()
pub fn sequencerContinue(opts: *Opts) i32 {
    if (readAndRefreshCache(opts) != 0) return -1;
    if (readPopulateOpts(opts) != 0) return -1;
    var todo = TodoList{};
    if (isRebaseI(opts)) {
        if (readPopulateTodo(&todo, opts) != 0) return -1;
        {
            const r = continueRebase(&todo, opts);
            if (r != 0) return if (r > 0) r else -1;
        }
    } else if (!os.exists(getTodoPath(opts))) {
        return continueSinglePick(opts);
    } else if (readPopulateTodo(&todo, opts) != 0) {
        return -1;
    }
    if (!isRebaseI(opts)) {
        if (refs.exists("CHERRY_PICK_HEAD") or refs.exists("REVERT_HEAD")) {
            const r = continueSinglePick(opts);
            if (r != 0) return r;
        }
        index_mod.discard();
        const ht = objects.peelTo(revparse.getOid("HEAD") orelse hash.zero, .tree) orelse hash.fromHex(hash.empty_tree_hex).?;
        if (mo.indexChangesAgainst(ht).len > 0) return errorDirtyIndex(opts);
        todo.current += 1;
    }
    return pickCommits(&todo, opts);
}

fn singlePick(cmit: *Commit, opts: *Opts) i32 {
    var check_todo = false;
    var item = Item{ .command = if (opts.action == .pick) .pick else .revert, .commit = cmit };
    return switch (doPickCommit(&item, opts, false, &check_todo)) {
        .err => -1,
        .conflicts => 1,
        else => 0,
    };
}

/// sequencer_pick_revisions()
pub fn pickRevisions(opts: *Opts) i32 {
    const revs = opts.revs.?;
    if (readAndRefreshCache(opts) != 0) return -1;
    for (revs.pending.items) |pe| {
        const name = pe.name;
        if (name.len == 0) continue;
        if (revparse.getOid(name)) |oid| {
            if (cn.lookupCommitReference(oid) == null) {
                const t = objects.typeOf(oid);
                util.err("{s}: can't cherry-pick a {s}", .{ name, if (t) |tt| @tagName(tt) else "bad object" });
                return -1;
            }
        } else {
            util.err("{s}: bad revision", .{name});
            return -1;
        }
    }
    if (revs.cmdline.items.len == 1 and revs.cmdline.items[0].whence == .rev and revs.no_walk and revs.cmdline.items[0].flags == 0) {
        if (!revision.prepareRevisionWalk(revs)) {
            util.err("revision walk setup failed", .{});
            return -1;
        }
        const cmit = revision.getRevision(revs) orelse {
            util.err("empty commit set passed", .{});
            return -1;
        };
        return singlePick(cmit, opts);
    }
    var todo = TodoList{};
    if (walkRevsPopulateTodo(&todo, opts) != 0 or createSeqDir() < 0) return -1;
    const head = revparse.getOid("HEAD");
    if (head == null and opts.action == .revert) {
        util.err("can't revert as initial commit", .{});
        return -1;
    }
    if (saveHead(&hash.hex(head orelse hash.zero)) != 0) return -1;
    if (saveOpts(opts) != 0) return -1;
    updateAbortSafetyFile();
    return pickCommits(&todo, opts);
}

/// sequencer_post_commit_cleanup()
pub fn postCommitCleanup(verbose: bool) void {
    branchstate.sequencerPostCommitCleanup(verbose);
}

// ===========================================================================
// rebase -i support

fn cstr() []const u8 {
    return trailer.commentLineStr();
}

/// strbuf_add_commented_lines() exactly as in strbuf.c (add_lines).
fn addCommentedC(buf: *util.Buf, text: []const u8) void {
    var s = text;
    while (s.len > 0) {
        const n = if (std.mem.indexOfScalar(u8, s, '\n')) |i| i + 1 else s.len;
        util.bufAppend(buf, cstr());
        if (s[0] != '\n' and s[0] != '\t') util.bufByte(buf, ' ');
        util.bufAppend(buf, s[0..n]);
        s = s[n..];
    }
    if (buf.items.len > 0 and buf.items[buf.items.len - 1] != '\n') util.bufByte(buf, '\n');
}

/// add_commented_lines(): avoids double commenting of subjects.
fn addCommentedLinesSq(buf: *util.Buf, text: []const u8) void {
    var s = text;
    while (util.startsWith(s, cstr())) {
        const n = if (std.mem.indexOfScalar(u8, s, '\n')) |i| i + 1 else s.len;
        util.bufAppend(buf, s[0..n]);
        s = s[n..];
    }
    addCommentedC(buf, s);
}

pub fn termClearLine() void {
    if (!os.isatty(2)) return;
    const term = os.getenv("TERM");
    if (term == null or util.eql(term.?, "dumb")) {
        const cols: usize = @intCast(@max(pretty.termColumns(), 1));
        var b: util.Buf = .empty;
        util.bufByte(&b, '\r');
        b.appendNTimes(gpa, ' ', cols) catch util.oom();
        util.bufByte(&b, '\r');
        util.ewrite(b.items);
    } else util.ewrite("\r\x1b[K");
}

const first_commit_msg_str = "This is the 1st commit message:";
const skip_first_commit_msg_str = "The 1st commit message will be skipped:";

fn isFixupFlag(command: Command, flag: u32) bool {
    return command == .fixup and (flag & TODO_REPLACE_FIXUP_MSG != 0 or flag & TODO_EDIT_FIXUP_MSG != 0);
}

fn seenSquash(opts: *const Opts) bool {
    const b = opts.current_fixups.items;
    return util.startsWith(b, "squash") or std.mem.indexOf(u8, b, "\nsquash") != null;
}

fn seenFixupEditMsg(opts: *const Opts) bool {
    const b = opts.current_fixups.items;
    return util.startsWith(b, "fixup -c") or std.mem.indexOf(u8, b, "\nfixup -c") != null;
}

fn copyLinesWith(commented: bool, msg: *util.Buf, text: []const u8) void {
    if (commented) addCommentedLinesSq(msg, text) else util.bufAppend(msg, text);
}

/// update_squash_message_for_fixup()
fn updateSquashMessageForFixup(msg: *util.Buf) void {
    var commented = false;
    var buf1: util.Buf = .empty;
    var buf2: util.Buf = .empty;
    addCommentedC(&buf1, first_commit_msg_str);
    addCommentedC(&buf2, skip_first_commit_msg_str);
    const orig = gpa.dupe(u8, msg.items) catch util.oom();
    msg.* = .empty;
    var i: i32 = 1;
    var start: usize = 0;
    var s: ?usize = 0;
    while (s) |sp| {
        if (util.startsWith(orig[sp..], buf1.items)) {
            var next = sp + buf1.items.len;
            const off: usize = if (sp > start + 1 and orig[sp - 2] == '\n') 1 else 0;
            copyLinesWith(commented, msg, orig[start .. sp - off]);
            if (off != 0) util.bufByte(msg, '\n');
            util.bufAppend(msg, buf2.items);
            if (next < orig.len and orig[next] == '\n') {
                util.bufByte(msg, '\n');
                next += 1;
            }
            start = next;
            s = next;
            commented = true;
            i += 1;
            updateCommentBufs(&buf1, &buf2, i);
        } else if (util.startsWith(orig[sp..], buf2.items)) {
            const next = sp + buf2.items.len;
            const off: usize = if (sp > start + 1 and orig[sp - 2] == '\n') 1 else 0;
            copyLinesWith(commented, msg, orig[start .. sp - off]);
            start = sp - off;
            s = next;
            commented = false;
            i += 1;
            updateCommentBufs(&buf1, &buf2, i);
        } else {
            s = if (std.mem.indexOfScalarPos(u8, orig, sp, '\n')) |nl| nl + 1 else null;
        }
    }
    copyLinesWith(commented, msg, orig[start..]);
}

fn updateCommentBufs(buf1: *util.Buf, buf2: *util.Buf, n: i32) void {
    buf1.items.len = cstr().len + 1;
    util.bufPrint(buf1, "This is the commit message #{d}:\n", .{n});
    buf2.items.len = cstr().len + 1;
    util.bufPrint(buf2, "The commit message #{d} will be skipped:\n", .{n});
}

/// append_squash_message()
fn appendSquashMessage(buf: *util.Buf, body: []const u8, command: Command, opts: *Opts, flag: u32) i32 {
    var commented_len: usize = 0;
    if (util.startsWith(body, "amend!") or
        ((command == .squash or seenSquash(opts)) and (util.startsWith(body, "squash!") or util.startsWith(body, "fixup!"))))
        commented_len = commitSubjectLength(body);
    util.bufPrint(buf, "\n{s} ", .{cstr()});
    opts.current_fixup_count += 1;
    util.bufPrint(buf, "This is the commit message #{d}:", .{opts.current_fixup_count + 1});
    util.bufAppend(buf, "\n\n");
    addCommentedC(buf, body[0..commented_len]);
    const fixup_off = buf.items.len;
    util.bufAppend(buf, body[commented_len..]);

    if (isFixupFlag(command, flag) and !seenSquash(opts)) {
        if (opts.signoff) c_commit.appendSignoff(buf, 0, false);
        if (opts.trailer_args.items.len > 0) amendWithTrailers(buf, opts.trailer_args.items);
        if (command == .fixup and flag & TODO_REPLACE_FIXUP_MSG != 0 and
            (os.exists(rebasePath("message-fixup")) or !os.exists(rebasePath("message-squash"))))
        {
            const off = @min(fixup_off, buf.items.len);
            const fixup_msg = buf.items[skipBlankLines(buf.items, off)..];
            if (writeMessage(fixup_msg, rebasePath("message-fixup"), false) < 0) {
                util.err("cannot write '{s}'", .{rebasePath("message-fixup")});
                return -1;
            }
        } else _ = os.unlink(rebasePath("message-fixup"));
    } else _ = os.unlink(rebasePath("message-fixup"));
    return 0;
}

/// update_squash_messages()
fn updateSquashMessages(command: Command, commit: *Commit, opts: *Opts, flag: u32) i32 {
    var buf: util.Buf = .empty;
    var res: i32 = 0;
    const encoding = commitOutputEncoding();
    if (opts.current_fixup_count > 0) {
        const data = os.readFile(rebasePath("message-squash")) orelse "";
        if (data.len == 0) {
            util.err("could not read '{s}'", .{rebasePath("message-squash")});
            return -1;
        }
        const eol: usize = if (!util.startsWith(data, cstr())) 0 else (std.mem.indexOfScalar(u8, data, '\n') orelse data.len);
        util.bufPrint(&buf, "{s} ", .{cstr()});
        util.bufPrint(&buf, "This is a combination of {d} commits.", .{opts.current_fixup_count + 2});
        util.bufAppend(&buf, data[eol..]);
        if (isFixupFlag(command, flag) and !seenSquash(opts)) updateSquashMessageForFixup(&buf);
    } else {
        const head = revparse.getOid("HEAD") orelse {
            util.err("need a HEAD to fixup", .{});
            return -1;
        };
        const head_commit = cn.lookupCommitReference(head) orelse {
            util.err("could not read HEAD", .{});
            return -1;
        };
        const head_message = pretty.logmsgReencode(head_commit, encoding).msg;
        const body = findCommitSubject(head_message).rest;
        if (command == .fixup and flag == 0 and writeMessage(body, rebasePath("message-fixup"), false) < 0) {
            util.err("cannot write '{s}'", .{rebasePath("message-fixup")});
            return -1;
        }
        util.bufPrint(&buf, "{s} ", .{cstr()});
        util.bufPrint(&buf, "This is a combination of {d} commits.", .{2});
        util.bufPrint(&buf, "\n{s} ", .{cstr()});
        util.bufAppend(&buf, if (isFixupFlag(command, flag)) skip_first_commit_msg_str else first_commit_msg_str);
        util.bufAppend(&buf, "\n\n");
        if (isFixupFlag(command, flag)) addCommentedC(&buf, body) else util.bufAppend(&buf, body);
    }
    const message = pretty.logmsgReencode(commit, encoding).msg;
    const body = findCommitSubject(message).rest;
    if (command == .squash or isFixupFlag(command, flag)) {
        res = appendSquashMessage(&buf, body, command, opts, flag);
    } else if (command == .fixup) {
        util.bufPrint(&buf, "\n{s} ", .{cstr()});
        opts.current_fixup_count += 1;
        util.bufPrint(&buf, "The commit message #{d} will be skipped:", .{opts.current_fixup_count + 1});
        util.bufAppend(&buf, "\n\n");
        addCommentedC(&buf, body);
    }
    if (res == 0) res = writeMessage(buf.items, rebasePath("message-squash"), false);
    if (res == 0) {
        const fixup_flag: []const u8 = if (isFixupFlag(command, flag) and flag & TODO_EDIT_FIXUP_MSG != 0) " -c" else "";
        util.bufPrint(&opts.current_fixups, "{s}{s}{s} {s}", .{
            if (opts.current_fixups.items.len > 0) "\n" else "",
            commandToString(command),
            fixup_flag,
            hash.hex(commit.oid()),
        });
        res = writeMessage(opts.current_fixups.items, rebasePath("current-fixups"), false);
    }
    return res;
}

/// flush_rewritten_pending()
fn flushRewrittenPending() void {
    const data = os.readFile(rebasePath("rewritten-pending")) orelse return;
    if (data.len == 0) return;
    const newoid = revparse.getOid("HEAD") orelse return;
    var out: util.Buf = .empty;
    var bol: usize = 0;
    while (bol < data.len) {
        const eol = std.mem.indexOfScalarPos(u8, data, bol, '\n') orelse data.len;
        util.bufPrint(&out, "{s} {s}\n", .{ data[bol..eol], hash.hex(newoid) });
        if (eol >= data.len) break;
        bol = eol + 1;
    }
    os.appendFile(rebasePath("rewritten-list"), out.items) catch {
        util.warn("could not open '{s}' for writing: {s}", .{ rebasePath("rewritten-list"), os.lastErr() });
        return;
    };
    _ = os.unlink(rebasePath("rewritten-pending"));
}

/// record_in_rewritten()
fn recordInRewritten(oid: Oid, next_command: ?Command) void {
    os.appendFile(rebasePath("rewritten-pending"), util.fmt("{s}\n", .{hash.hex(oid)})) catch {
        util.warn("could not open '{s}' for writing: {s}", .{ rebasePath("rewritten-pending"), os.lastErr() });
        return;
    };
    if (next_command == null or !isFixup(next_command.?)) flushRewrittenPending();
}

fn isFinalFixup(todo: *const TodoList) bool {
    var i = todo.current;
    const items = todo.items.items;
    if (!isFixup(items[i].command)) return false;
    i += 1;
    while (i < items.len) : (i += 1) {
        if (isFixup(items[i].command)) return false;
        if (!isNoop(items[i].command)) break;
    }
    return true;
}

fn peekCommand(todo: *const TodoList, offset: usize) ?Command {
    var i = todo.current + offset;
    while (i < todo.items.items.len) : (i += 1) {
        if (!isNoop(todo.items.items[i].command)) return todo.items.items[i].command;
    }
    return null;
}

/// write_basic_state()
pub fn writeBasicState(opts: *Opts, head_name: ?[]const u8, onto: ?Oid, orig_head: ?Oid) void {
    if (head_name) |h| writeFile(rebasePath("head-name"), util.fmt("{s}\n", .{h}));
    if (onto) |o| writeFile(rebasePath("onto"), util.fmt("{s}\n", .{hash.hex(o)}));
    if (orig_head) |o| writeFile(rebasePath("orig-head"), util.fmt("{s}\n", .{hash.hex(o)}));
    if (opts.quiet) writeFile(rebasePath("quiet"), "");
    if (opts.verbose) writeFile(rebasePath("verbose"), "");
    if (opts.strategy) |s| writeFile(rebasePath("strategy"), util.fmt("{s}\n", .{s}));
    if (opts.xopts.items.len > 0) {
        var b: util.Buf = .empty;
        for (opts.xopts.items, 0..) |x, i| {
            if (i > 0) util.bufByte(&b, ' ');
            quoteCmdlineArg(&b, x);
        }
        writeFile(rebasePath("strategy_opts"), util.fmt("{s}\n", .{b.items}));
    }
    if (opts.allow_rerere_auto == RERERE_AUTOUPDATE) {
        writeFile(rebasePath("allow_rerere_autoupdate"), "--rerere-autoupdate\n");
    } else if (opts.allow_rerere_auto == RERERE_NOAUTOUPDATE) writeFile(rebasePath("allow_rerere_autoupdate"), "--no-rerere-autoupdate\n");
    if (opts.gpg_sign) |g| writeFile(rebasePath("gpg_sign_opt"), util.fmt("-S{s}\n", .{g}));
    if (opts.signoff) writeFile(rebasePath("signoff"), "--signoff\n");
    if (opts.drop_redundant_commits) writeFile(rebasePath("drop_redundant_commits"), "");
    if (opts.keep_redundant_commits) writeFile(rebasePath("keep_redundant_commits"), "");
    if (opts.committer_date_is_author_date) writeFile(rebasePath("cdate_is_adate"), "");
    if (opts.ignore_date) writeFile(rebasePath("ignore_date"), "");
    if (opts.reschedule_failed_exec) {
        writeFile(rebasePath("reschedule-failed-exec"), "");
    } else writeFile(rebasePath("no-reschedule-failed-exec"), "");
    if (opts.trailer_args.items.len > 0) {
        var b: util.Buf = .empty;
        for (opts.trailer_args.items) |t| util.bufPrint(&b, "{s}\n", .{t});
        writeFile(rebasePath("trailer"), b.items);
    }
}

/// quote_cmdline() for one argument (quote.c)
fn quoteCmdlineArg(b: *util.Buf, arg: []const u8) void {
    util.bufByte(b, '"');
    for (arg) |ch| {
        if (ch == '"' or ch == '\\') util.bufByte(b, '\\');
        util.bufByte(b, ch);
    }
    util.bufByte(b, '"');
}

// ---------------------------------------------------------------------------
// patches / stopping

/// make_patch()
fn makePatch(commit: *Commit, opts: *Opts) i32 {
    _ = opts;
    var res: i32 = 0;
    const hex = hash.hex(commit.oid());
    if (writeMessage(&hex, rebasePath("stopped-sha"), true) < 0) return -1;
    res |= writeRebaseHead(commit.oid());
    const r = os.run(&.{ proc.gitBinary(), "diff-tree", "-p", "--no-commit-id", "--no-color", &hex }, .{ .capture_stdout = true, .no_stdin = true });
    os.writeFile(rebasePath("patch"), r.stdout, 0o666) catch {
        util.err("could not open '{s}': {s}", .{ rebasePath("patch"), os.lastErr() });
        res |= -1;
    };
    if (!os.exists(rebasePath("message"))) {
        const buf = pretty.logmsgReencode(commit, commitOutputEncoding()).msg;
        const subject = findCommitSubject(buf).rest;
        res |= writeMessage(subject, rebasePath("message"), true);
    }
    return res;
}

fn intendToAmend() i32 {
    const head = revparse.getOid("HEAD") orelse {
        util.err("cannot read HEAD", .{});
        return -1;
    };
    return writeMessage(&hash.hex(head), rebasePath("amend"), true);
}

/// error_with_patch()
fn errorWithPatch(commit: ?*Commit, subject: []const u8, opts: *Opts, exit_code: i32, to_amend: bool) i32 {
    if (opts.have_message and !os.exists(rebasePath("message")) and
        writeMessage(opts.message.items, rebasePath("message"), false) != 0)
    {
        util.err("could not write commit message file", .{});
        return -1;
    }
    if (commit) |c| {
        if (makePatch(c, opts) != 0) return -1;
    }
    if (to_amend) {
        if (intendToAmend() != 0) return -1;
        util.eprint("You can amend the commit now, with\n" ++
            "\n" ++
            "  git commit --amend {s}\n" ++
            "\n" ++
            "Once you are satisfied with your changes, run\n" ++
            "\n" ++
            "  git rebase --continue\n", .{gpgSignOptQuoted(opts)});
    } else if (exit_code != 0) {
        if (commit) |c| {
            util.eprint("Could not apply {s}... {s}\n", .{ shortCommitName(c), subject });
        } else util.eprint("Could not merge {s}\n", .{subject});
    }
    return exit_code;
}

fn copyFile(dst: []const u8, src: []const u8) bool {
    const data = os.readFile(src) orelse return false;
    os.writeFile(dst, data, 0o666) catch return false;
    return true;
}

/// error_failed_squash()
fn errorFailedSquash(commit: *Commit, opts: *Opts, subject: []const u8) i32 {
    if (!copyFile(rebasePath("message"), rebasePath("message-squash"))) {
        util.err("could not copy '{s}' to '{s}'", .{ rebasePath("message-squash"), rebasePath("message") });
        return -1;
    }
    _ = os.unlink(mergeMsgPath());
    if (!copyFile(mergeMsgPath(), rebasePath("message"))) {
        util.err("could not copy '{s}' to '{s}'", .{ rebasePath("message"), mergeMsgPath() });
        return -1;
    }
    return errorWithPatch(commit, subject, opts, 1, true);
}

/// do_exec()
fn doExec(command_line: []const u8, quiet: bool) i32 {
    if (!quiet) util.eprint("Executing: {s}\n", .{command_line});
    const r = os.run(&.{command_line}, .{ .use_shell = true, .unset_env = &.{"GIT_CHERRY_PICK_HELP"} });
    var status: i32 = if (r.signaled) 128 + @as(i32, @intCast(r.status)) else @intCast(r.status);
    index_mod.discard();
    const dirty = wtstatus.requireCleanWorkTree("rebase", null, true, true);
    if (status != 0) {
        util.warn("execution failed: {s}\n{s}" ++
            "You can fix the problem, and then run\n" ++
            "\n" ++
            "  git rebase --continue\n" ++
            "\n", .{ command_line, if (dirty) "and made changes to the index and/or the working tree.\n" else "" });
        if (status == 127) status = 1;
    } else if (dirty) {
        util.warn("execution succeeded: {s}\nbut " ++
            "left changes to the index and/or the working tree.\n" ++
            "Commit or stash your changes, and then run\n" ++
            "\n" ++
            "  git rebase --continue\n" ++
            "\n", .{command_line});
        status = 1;
    }
    return status;
}

/// safe_append()
fn safeAppend(filename: []const u8, text: []const u8) i32 {
    const l = switch (lockfile.tryLock(filename)) {
        .ok => |l| l,
        .err => {
            util.err("could not lock '{s}': {s}", .{ filename, os.lastErr() });
            return -1;
        },
    };
    var buf: util.Buf = .empty;
    if (os.readFile(filename)) |d| util.bufAppend(&buf, d);
    if (buf.items.len > 0 and buf.items[buf.items.len - 1] != '\n') util.bufByte(&buf, '\n');
    util.bufAppend(&buf, text);
    l.write(buf.items);
    if (!l.commit()) {
        util.err("failed to finalize '{s}'", .{filename});
        return -1;
    }
    return 0;
}

/// do_label()
fn doLabel(name: []const u8) i32 {
    if (util.eql(name, "#")) {
        util.err("illegal label name: '{s}'", .{name});
        return -1;
    }
    const ref_name = util.concat(&.{ "refs/rewritten/", name });
    const msg = util.fmt("rebase (label) '{s}'", .{name});
    const head = revparse.getOid("HEAD") orelse {
        util.err("could not read HEAD", .{});
        return -1;
    };
    refs.update(ref_name, head, null, msg, false) catch {
        util.err("{s}", .{refs.last_error});
        return -1;
    };
    return safeAppend(rebasePath("refs-to-delete"), util.fmt("{s}\n", .{ref_name}));
}

fn lookupCommitByName(name: []const u8) ?*Commit {
    const oid = revparse.getOid(name) orelse return null;
    const c = cn.lookupCommitReference(oid) orelse return null;
    if (!cn.parse(c)) return null;
    return c;
}

/// lookup_label(); `name_out` receives the ref name used (like `buf` in C).
fn lookupLabel(label: []const u8, name_out: *[]const u8) ?*Commit {
    var buf: []const u8 = util.concat(&.{ "refs/rewritten/", label });
    var commit: ?*Commit = null;
    if (refs.readOid(buf)) |oid| {
        commit = cn.lookupCommit(oid);
        if (commit) |c| _ = cn.parse(c);
    } else {
        buf = label;
        commit = lookupCommitByName(buf);
    }
    name_out.* = buf;
    if (commit == null) util.err("could not resolve '{s}'", .{buf});
    return commit;
}

/// do_reset()
fn doReset(name_in: []const u8, opts: *Opts) i32 {
    var name = name_in;
    var oid: Oid = undefined;
    if (util.eql(name, "[new root]")) {
        if (!opts.have_squash_onto) {
            opts.squash_onto = commit_mod.create(.{ .tree = hash.fromHex(hash.empty_tree_hex).?, .message = "" });
            opts.have_squash_onto = true;
            if (writeMessage(&hash.hex(opts.squash_onto), rebasePath("squash-onto"), false) != 0) {
                util.err("writing squash-onto", .{});
                return -1;
            }
        }
        oid = opts.squash_onto;
    } else {
        var i: usize = 0;
        while (i < name.len and !std.ascii.isWhitespace(name[i])) i += 1;
        name = name[0..i];
        var ref_name: []const u8 = "";
        const commit = lookupLabel(name, &ref_name) orelse return -1;
        oid = commit.oid();
    }
    index_mod.discard();
    const idx = index_mod.lockAndRead();
    var o = ut.Options{};
    ut.setupPorcelain(&o, "reset");
    o.head_idx = 1;
    o.src_index = idx;
    o.dst_index = idx;
    o.func = &ut.onewayMerge;
    o.meta = .{ .refname = name, .treeish = oid };
    o.merge = true;
    o.update = true;
    o.preserve_ignored = false;
    o.skip_cache_tree_update = true;
    if (ut.readIndexUnmerged(idx)) {
        idx.rollback();
        advice.errorResolveConflict(actionName(opts));
        return -1;
    }
    const tree = objects.peelTo(oid, .tree) orelse {
        idx.rollback();
        util.err("failed to find tree of {s}", .{hash.hex(oid)});
        return -1;
    };
    if (ut.unpackTrees(&.{tree}, &o) != 0) {
        idx.rollback();
        return -1;
    }
    index_mod.primeCacheTree(idx, tree);
    idx.write();
    refs.update("HEAD", oid, null, reflogMessage(opts, "reset", util.fmt("'{s}'", .{name})), false) catch {
        util.err("{s}", .{refs.last_error});
        return -1;
    };
    return 0;
}

/// do_merge()
fn doMerge(commit: ?*Commit, arg: []const u8, flags: u32, check_todo: *bool, opts: *Opts) i32 {
    var run_commit_flags: u32 = 0;
    var ref_name: []const u8 = "";
    const strategy: ?[]const u8 = if (opts.xopts.items.len == 0 and (opts.strategy == null or
        util.eql(opts.strategy.?, "recursive") or util.eql(opts.strategy.?, "ort"))) null else opts.strategy;
    const reflog_action = reflogMessage(opts, "merge", null);

    const head_commit = lookupCommitByName("HEAD") orelse {
        util.err("cannot merge without a current revision", .{});
        return -1;
    };

    var to_merge: std.ArrayList(*Commit) = .empty;
    var merge_arg_len = arg.len;
    var oneline_offset = arg.len;
    var p: usize = 0;
    while (p < arg.len) {
        if (arg[p] == '#' and (p + 1 >= arg.len or std.ascii.isWhitespace(arg[p + 1]))) {
            p += 1;
            while (p < arg.len and (arg[p] == ' ' or arg[p] == '\t' or arg[p] == '\n')) p += 1;
            oneline_offset = p;
            break;
        }
        var k: usize = 0;
        while (p + k < arg.len and arg[p + k] != ' ' and arg[p + k] != '\t' and arg[p + k] != '\n') k += 1;
        if (k > 0) {
            const mc = lookupLabel(arg[p .. p + k], &ref_name) orelse {
                util.err("unable to parse '{s}'", .{arg[p .. p + k]});
                return -1;
            };
            to_merge.append(gpa, mc) catch util.oom();
            p += k;
            merge_arg_len = p;
        }
        while (p < arg.len and (arg[p] == ' ' or arg[p] == '\t' or arg[p] == '\n')) p += 1;
    }
    if (to_merge.items.len == 0) {
        util.err("nothing to merge: '{s}'", .{arg});
        return -1;
    }

    if (opts.have_squash_onto and hash.eql(head_commit.oid(), opts.squash_onto)) {
        if (to_merge.items.len > 1) {
            util.err("octopus merge cannot be executed on top of a [new root]", .{});
            return -1;
        }
        return fastForwardTo(to_merge.items[0].oid(), head_commit.oid(), false, opts);
    }

    var can_fast_forward = opts.allow_ff and commit != null and commit.?.parents != null and
        hash.eql(commit.?.parents.?.item.oid(), head_commit.oid());
    if (can_fast_forward) {
        var pp = commit.?.parents.?.next;
        var j: usize = 0;
        while (j < to_merge.items.len and pp != null) : ({
            j += 1;
            pp = pp.?.next;
        }) {
            if (!hash.eql(to_merge.items[j].oid(), pp.?.item.oid())) {
                can_fast_forward = false;
                break;
            }
        }
        if (can_fast_forward and (j < to_merge.items.len or pp != null)) can_fast_forward = false;
    }

    var ret: i32 = 0;
    ff: {
        if (can_fast_forward) {
            ret = fastForwardTo(commit.?.oid(), head_commit.oid(), false, opts);
            if (flags & TODO_EDIT_MERGE_MSG != 0) break :ff;
            return ret;
        }

        if (commit) |c| {
            const message = pretty.logmsgReencode(c, commitOutputEncoding()).msg;
            _ = writeAuthorScript(message);
            util.bufAppend(&opts.message, findCommitSubject(message).rest);
        } else {
            _ = writeAuthorScript(util.concat(&.{ "author ", @import("ident.zig").author() }));
            if (oneline_offset < arg.len) {
                util.bufAppend(&opts.message, arg[oneline_offset..]);
            } else {
                util.bufPrint(&opts.message, "Merge {s} '{s}'", .{ if (to_merge.items.len > 1) "branches" else "branch", arg[0..merge_arg_len] });
            }
        }
        opts.have_message = true;
        if (writeMessage(opts.message.items, mergeMsgPath(), false) != 0) {
            util.err("could not write '{s}': {s}", .{ mergeMsgPath(), os.lastErr() });
            return -1;
        }

        if (strategy != null or to_merge.items.len > 1) {
            var env: std.ArrayList([2][]const u8) = .empty;
            var adate: []const u8 = "";
            switch (readAuthorScript(rebasePath("author-script"), false)) {
                .ok => |a| {
                    env.append(gpa, .{ "GIT_AUTHOR_NAME", a.name }) catch util.oom();
                    env.append(gpa, .{ "GIT_AUTHOR_EMAIL", a.email }) catch util.oom();
                    env.append(gpa, .{ "GIT_AUTHOR_DATE", a.date }) catch util.oom();
                    adate = a.date;
                },
                else => {
                    const g = gpgSignOptQuoted(opts);
                    util.err(staged_changes_advice, .{ g, g });
                    return -1;
                },
            }
            if (opts.committer_date_is_author_date)
                env.append(gpa, .{ "GIT_COMMITTER_DATE", if (opts.ignore_date) "" else adate }) catch util.oom();
            if (opts.ignore_date) env.append(gpa, .{ "GIT_AUTHOR_DATE", "" }) catch util.oom();
            var argv: std.ArrayList([]const u8) = .empty;
            argv.appendSlice(gpa, &.{ proc.gitBinary(), "merge", "-s" }) catch util.oom();
            if (strategy) |s| {
                argv.append(gpa, s) catch util.oom();
                for (opts.xopts.items) |x| argv.append(gpa, util.concat(&.{ "-X", x })) catch util.oom();
            } else argv.append(gpa, "octopus") catch util.oom();
            argv.append(gpa, if (flags & TODO_EDIT_MERGE_MSG == 0) "--no-edit" else "--edit") catch util.oom();
            argv.appendSlice(gpa, &.{ "--no-ff", "--no-log", "--no-stat", "-F", mergeMsgPath() }) catch util.oom();
            if (opts.gpg_sign) |g| argv.append(gpa, util.concat(&.{ "-S", g })) catch util.oom() else argv.append(gpa, "--no-gpg-sign") catch util.oom();
            for (to_merge.items) |m| argv.append(gpa, hash.hexAlloc(m.oid())) catch util.oom();
            refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "") catch {};
            index_mod.discard();
            const r = os.run(argv.items, .{ .env = env.items });
            index_mod.discard();
            return if (r.signaled) -1 else @intCast(r.status);
        }

        const merge_commit = to_merge.items[0];
        const bases = creach.getMergeBases(head_commit, merge_commit);
        if (bases != null and hash.eql(merge_commit.oid(), bases.?.item.oid())) return 0;

        _ = writeMessage(&hash.hex(merge_commit.oid()), gitPath("MERGE_HEAD"), false);
        _ = writeMessage("no-ff", gitPath("MERGE_MODE"), false);

        var reversed: ?*cn.CommitList = null;
        var bb = bases;
        while (bb) |n| : (bb = n.next) _ = cn.listInsert(n.item, &reversed);

        index_mod.discard();
        const idx = index_mod.lockAndRead();
        var o = mo.initMergeOptions(true);
        o.branch1 = "HEAD";
        o.branch2 = ref_name;
        var clean: i32 = undefined;
        const head_tree = commitTreeOid(head_commit);
        const changes = mo.indexChangesAgainst(head_tree);
        if (changes.len > 0) {
            util.err("Your local changes to the following files would be overwritten by merge:\n  {s}", .{changes});
            clean = -1;
        } else {
            var result = mo.Result{};
            mo.mergeIncoreRecursive(&o, reversed, head_commit, merge_commit, &result);
            mo.mergeSwitchToResult(&o, head_tree, &result, true, result.clean <= 0);
            clean = result.clean;
        }
        if (clean < 0) {
            idx.rollback();
            util.err("could not even attempt to merge '{s}'", .{arg[0..merge_arg_len]});
            _ = os.unlink(mergeMsgPath());
            return clean;
        }
        ret = if (clean == 0) 1 else 0;
        const cur = index_mod.get();
        if (cur.lock != null) {
            if (cur.changed) cur.write() else cur.rollback();
        }
        if (ret != 0) {
            _ = @import("rerere.zig").rerere(@intCast(opts.allow_rerere_auto));
        } else {
            ret = if (runGitCommit(mergeMsgPath(), reflog_action, opts, run_commit_flags) != 0) 1 else 0;
        }
        if (!(ret == 0 and flags & TODO_EDIT_MERGE_MSG != 0)) return ret;
    }
    // fast_forward_edit
    check_todo.* = true;
    run_commit_flags |= AMEND_MSG | EDIT_MSG | VERIFY_MSG;
    return if (runGitCommit(null, reflog_action, opts, run_commit_flags) != 0) 1 else 0;
}

// ---------------------------------------------------------------------------
// update-refs state

const UpdateRefRec = struct { ref: []const u8, before: Oid, after: Oid };

fn updateRefsPath() []const u8 {
    return rebasePath("update-refs");
}

/// sequencer_get_update_refs_state(); returns null on parse error.
fn getUpdateRefsState(list: *std.ArrayList(UpdateRefRec)) bool {
    const data = os.readFile(updateRefsPath()) orelse return true;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |ref| {
        if (ref.len == 0 and it.peek() == null) break;
        const b = it.next();
        const a = if (b != null) it.next() else null;
        const bo = if (b) |x| (if (x.len >= 40) hash.fromHex(x[0..40]) else null) else null;
        const ao = if (a) |x| (if (x.len >= 40) hash.fromHex(x[0..40]) else null) else null;
        if (bo == null or ao == null) {
            util.warn("update-refs file at '{s}' is invalid", .{updateRefsPath()});
            return false;
        }
        insertUpdateRef(list, .{ .ref = ref, .before = bo.?, .after = ao.? });
    }
    return true;
}

fn insertUpdateRef(list: *std.ArrayList(UpdateRefRec), rec: UpdateRefRec) void {
    var i: usize = 0;
    while (i < list.items.len) : (i += 1) {
        const c = std.mem.order(u8, list.items[i].ref, rec.ref);
        if (c == .eq) return;
        if (c == .gt) break;
    }
    list.insert(gpa, i, rec) catch util.oom();
}

fn initUpdateRefRecord(ref: []const u8) UpdateRefRec {
    return .{ .ref = util.dupe(ref), .before = refs.readOid(ref) orelse hash.zero, .after = hash.zero };
}

fn writeUpdateRefsState(list: []const UpdateRefRec) i32 {
    const path = updateRefsPath();
    if (list.len == 0) {
        _ = os.unlink(path);
        return 0;
    }
    _ = os.mkdirLeading(path);
    const l = switch (lockfile.tryLock(path)) {
        .ok => |l| l,
        .err => {
            util.err("another 'rebase' process appears to be running; '{s}.lock' already exists", .{path});
            return -1;
        },
    };
    var b: util.Buf = .empty;
    for (list) |r| util.bufPrint(&b, "{s}\n{s}\n{s}\n", .{ r.ref, hash.hex(r.before), hash.hex(r.after) });
    l.write(b.items);
    return if (l.commit()) 0 else -1;
}

/// todo_list_filter_update_refs()
pub fn filterUpdateRefs(todo: *const TodoList) void {
    var list: std.ArrayList(UpdateRefRec) = .empty;
    _ = getUpdateRefsState(&list);
    var updated = false;
    var i: usize = 0;
    while (i < list.items.len) {
        const rec = list.items[i];
        var found = !hash.isZero(rec.after);
        if (!found) {
            for (todo.items.items) |*it| {
                if (it.command == .update_ref and util.eql(todo.getArg(it), rec.ref)) {
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            _ = list.orderedRemove(i);
            updated = true;
        } else i += 1;
    }
    for (todo.items.items) |*it| {
        if (it.command != .update_ref) continue;
        const arg = todo.getArg(it);
        var found = false;
        for (list.items) |r| {
            if (util.eql(r.ref, arg)) {
                found = true;
                break;
            }
        }
        if (!found) {
            insertUpdateRef(&list, initUpdateRefRecord(arg));
            updated = true;
        }
    }
    if (updated) _ = writeUpdateRefsState(list.items);
}

fn doUpdateRef(refname: []const u8) i32 {
    var list: std.ArrayList(UpdateRefRec) = .empty;
    if (!getUpdateRefsState(&list)) return -1;
    for (list.items) |*r| {
        if (util.eql(r.ref, refname)) {
            r.after = refs.readOid("HEAD") orelse return -1;
            break;
        }
    }
    _ = writeUpdateRefsState(list.items);
    return 0;
}

fn doUpdateRefs(quiet: bool) i32 {
    var list: std.ArrayList(UpdateRefRec) = .empty;
    if (!getUpdateRefsState(&list)) return -1;
    var res: i32 = 0;
    var upd: util.Buf = .empty;
    var errb: util.Buf = .empty;
    for (list.items) |r| {
        var loop_res: i32 = 0;
        refs.update(r.ref, r.after, r.before, "rewritten during rebase", false) catch {
            util.err("{s}", .{refs.last_error});
            loop_res = -1;
        };
        res |= loop_res;
        if (quiet) continue;
        if (loop_res != 0) util.bufPrint(&errb, "\t{s}\n", .{r.ref}) else util.bufPrint(&upd, "\t{s}\n", .{r.ref});
    }
    if (!quiet and (upd.items.len > 0 or errb.items.len > 0)) {
        util.eprint("Updated the following refs with {s}:\n{s}", .{ "--update-refs", upd.items });
        if (res != 0) util.eprint("Failed to update the following refs with {s}:\n{s}", .{ "--update-refs", errb.items });
    }
    return res;
}

// ---------------------------------------------------------------------------
// autostash

fn runGit(args: []const []const u8, o: os.SpawnOpts) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    util.flushStdout();
    index_mod.discard();
    const r = os.run(argv.items, o);
    index_mod.discard();
    return r;
}

/// create_autostash()
pub fn createAutostash(path: []const u8) void {
    {
        index_mod.discard();
        switch (lockfile.tryLock(repo_mod.repo().indexPath())) {
            .ok => |l| {
                l.rollback();
                const idx = index_mod.lockAndRead();
                _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
                if (idx.changed) idx.write() else idx.rollback();
            },
            .err => {},
        }
        index_mod.discard();
    }
    if (!(wtstatus.hasUnstagedChanges(true) or wtstatus.hasUncommittedChanges(true))) return;
    const r = runGit(&.{ "stash", "create", "autostash" }, .{ .capture_stdout = true, .no_stdin = true });
    if (r.status != 0 or r.signaled) util.die("Cannot autostash", .{});
    const line = util.trim(r.stdout);
    const oid = revparse.getOid(line) orelse util.die("Unexpected stash response: '{s}'", .{line});
    if (!os.mkdirLeading(path)) util.die("Could not create directory for '{s}'", .{path});
    os.writeFile(path, util.concat(&.{ &hash.hex(oid), "\n" }), 0o666) catch util.die("could not write '{s}'", .{path});
    util.outf("Created autostash: {s}\n", .{revparse.abbrev(oid, revparse.defaultAbbrev())});
    util.flushStdout();
    if (resetWorkingTree(.{ .flags = RESET_HARD | RESET_UPDATE_HEAD }) < 0)
        util.die("could not reset --hard", .{});
    index_mod.discard();
}

fn applySaveAutostashOid(stash_oid: []const u8, attempt_apply: bool) i32 {
    var ret: i32 = 0;
    if (attempt_apply) {
        const r = os.run(&.{ "/bin/sh", "-c", "exec \"$0\" stash apply \"$1\" >/dev/null 2>&1", proc.gitBinary(), stash_oid }, .{ .no_stdin = true });
        index_mod.discard();
        ret = if (r.signaled) -1 else switch (r.status) {
            0 => 0,
            1 => 1,
            else => -1,
        };
        // git stash apply returns 1 for both conflicts and errors; treat as conflict
        // when the index has unmerged entries.
        if (ret == 1) {
            const idx = index_mod.get();
            if (!idx.unmerged()) ret = -1;
        }
    }
    if (attempt_apply and ret == 0) {
        util.eprint("Applied autostash.\n", .{});
    } else {
        const r = runGit(&.{ "stash", "store", "-m", "autostash", "-q", stash_oid }, .{ .no_stdin = true });
        if (r.status != 0 or r.signaled) {
            util.err("cannot store {s}", .{stash_oid});
            return -1;
        }
        if (attempt_apply) {
            if (ret == 1) {
                util.eprint("Your local changes are stashed, however applying them\n" ++
                    "resulted in conflicts.  You can either resolve the conflicts\n" ++
                    "and then discard the stash with \"git stash drop\", or, if you\n" ++
                    "do not want to resolve them now, run \"git reset --hard\" and\n" ++
                    "apply the local changes later by running \"git stash pop\".\n", .{});
            } else {
                util.err("could not apply autostash; your changes are safe in the stash", .{});
            }
            ret = 0;
        } else {
            util.eprint("Autostash exists; creating a new stash entry.\n" ++
                "Your changes are safe in the stash.\n" ++
                "You can run \"git stash pop\" or \"git stash drop\" at any time.\n", .{});
        }
    }
    return ret;
}

fn applySaveAutostash(path: []const u8, attempt_apply: bool) i32 {
    const s = readOneliner(path, false, true) orelse {
        _ = os.unlink(path);
        return 0;
    };
    const ret = applySaveAutostashOid(s, attempt_apply);
    _ = os.unlink(path);
    return ret;
}

pub fn saveAutostash(path: []const u8) i32 {
    return applySaveAutostash(path, false);
}
pub fn applyAutostash(path: []const u8) i32 {
    return applySaveAutostash(path, true);
}
pub fn applyAutostashOid(oid: []const u8) i32 {
    return applySaveAutostashOid(oid, true);
}

// ---------------------------------------------------------------------------
// reset.c

pub const RESET_DETACH: u32 = 1;
pub const RESET_HARD: u32 = 2;
pub const RESET_RUN_POST_CHECKOUT_HOOK: u32 = 4;
pub const RESET_REFS_ONLY: u32 = 8;
pub const RESET_UPDATE_HEAD: u32 = 16;
pub const RESET_UPDATE_ORIG_HEAD: u32 = 32;

pub const ResetOpts = struct {
    oid: ?Oid = null,
    branch: ?[]const u8 = null,
    flags: u32 = 0,
    branch_msg: ?[]const u8 = null,
    head_msg: ?[]const u8 = null,
    orig_head_msg: ?[]const u8 = null,
    orig_head: ?Oid = null,
    default_reflog_action: ?[]const u8 = null,
};

fn resetUpdateRefs(o: ResetOpts, oid: Oid, head: ?Oid) i32 {
    var prefix: []const u8 = "";
    const update_orig = o.flags & RESET_UPDATE_ORIG_HEAD != 0;
    if ((update_orig and o.orig_head_msg == null) or o.head_msg == null) {
        prefix = util.fmt("{s}: ", .{os.getenv("GIT_REFLOG_ACTION") orelse (o.default_reflog_action orelse "rebase")});
    }
    if (update_orig) {
        const old_orig = revparse.getOid("ORIG_HEAD");
        if (head) |h| {
            const m = o.orig_head_msg orelse util.concat(&.{ prefix, "updating ORIG_HEAD" });
            refs.update("ORIG_HEAD", o.orig_head orelse h, old_orig, m, false) catch util.err("{s}", .{refs.last_error});
        } else if (old_orig) |oo| {
            refs.deleteRef("ORIG_HEAD", oo, 0, null) catch {};
        }
    }
    const reflog_head = o.head_msg orelse util.concat(&.{ prefix, "updating HEAD" });
    var ok = true;
    if (o.branch) |br| {
        refs.update(br, oid, null, o.branch_msg orelse reflog_head, false) catch {
            util.err("{s}", .{refs.last_error});
            ok = false;
        };
        if (ok) refs.writeSymref("HEAD", br, reflog_head) catch {
            ok = false;
        };
    } else {
        refs.update("HEAD", oid, head orelse hash.zero, reflog_head, o.flags & RESET_DETACH != 0) catch {
            util.err("{s}", .{refs.last_error});
            ok = false;
        };
    }
    if (ok and o.flags & RESET_RUN_POST_CHECKOUT_HOOK != 0) {
        _ = hook.run("post-checkout", &.{ &hash.hex(head orelse hash.zero), &hash.hex(oid), "1" }, .{});
    }
    return if (ok) 0 else -1;
}

/// reset_working_tree()
pub fn resetWorkingTree(o: ResetOpts) i32 {
    const hard = o.flags & RESET_HARD != 0;
    const head = revparse.getOid("HEAD");
    if (head == null and (o.oid == null or !hard)) {
        util.err("could not determine HEAD revision", .{});
        return -1;
    }
    const oid = o.oid orelse head.?;
    if (o.flags & RESET_REFS_ONLY != 0) {
        if (o.flags & RESET_UPDATE_HEAD != 0) return resetUpdateRefs(o, oid, head);
        return 0;
    }
    index_mod.discard();
    const idx = switch (lockfile.tryLock(repo_mod.repo().indexPath())) {
        .ok => |l| blk: {
            l.rollback();
            break :blk index_mod.lockAndRead();
        },
        .err => {
            util.err("Unable to create '{s}.lock': {s}", .{ repo_mod.repo().indexPath(), os.lastErr() });
            return -1;
        },
    };
    _ = ut.readIndexUnmerged(idx);
    var uo = ut.Options{};
    ut.setupPorcelain(&uo, if (hard) "reset" else "checkout");
    uo.head_idx = 1;
    uo.src_index = idx;
    uo.dst_index = idx;
    uo.func = if (hard) &ut.onewayMerge else &ut.twowayMerge;
    uo.meta = .{ .refname = o.branch, .treeish = oid };
    uo.update = true;
    uo.merge = true;
    uo.preserve_ignored = false;
    if (hard) {
        uo.skip_cache_tree_update = true;
        uo.reset = .protect_untracked;
    }
    const tree = objects.peelTo(oid, .tree) orelse {
        idx.rollback();
        util.err("failed to find tree of {s}", .{hash.hex(oid)});
        return -1;
    };
    var r: i32 = undefined;
    if (hard) {
        r = ut.unpackTrees(&.{tree}, &uo);
    } else {
        const htree = objects.peelTo(head.?, .tree) orelse {
            idx.rollback();
            util.err("failed to find tree of {s}", .{hash.hex(head.?)});
            return -1;
        };
        r = ut.unpackTrees(&.{ htree, tree }, &uo);
    }
    if (r != 0) {
        index_mod.get().rollback();
        return -1;
    }
    const cur = index_mod.get();
    if (hard) index_mod.primeCacheTree(cur, tree);
    cur.write();
    if (o.flags & RESET_UPDATE_HEAD != 0 and (o.oid != null or o.flags & RESET_UPDATE_ORIG_HEAD != 0 or o.branch != null))
        return resetUpdateRefs(o, oid, head);
    return 0;
}

/// checkout_onto()
fn checkoutOnto(opts: *Opts, onto_name: []const u8, onto: Oid, orig_head: Oid) i32 {
    const ro = ResetOpts{
        .oid = onto,
        .orig_head = orig_head,
        .flags = RESET_DETACH | RESET_UPDATE_ORIG_HEAD | RESET_UPDATE_HEAD | RESET_RUN_POST_CHECKOUT_HOOK,
        .head_msg = reflogMessage(opts, "start", util.fmt("checkout {s}", .{onto_name})),
        .default_reflog_action = reflogAction(opts),
    };
    if (resetWorkingTree(ro) != 0) {
        _ = applyAutostash(rebasePath("autostash"));
        _ = removeState(opts);
        util.err("could not detach HEAD", .{});
        return -1;
    }
    return 0;
}

fn stoppedAtHead() i32 {
    const head = revparse.getOid("HEAD");
    const c = if (head) |h| cn.lookupCommit(h) else null;
    if (c == null or !cn.parse(c.?)) {
        util.eprint("Stopped at HEAD\n", .{});
    } else {
        util.eprint("Stopped at {s}\n", .{getMessage(c.?).label});
    }
    return 0;
}

/// returns: 0 unchanged, 1 reread (current must restart at 0), -1 error
fn rereadTodoIfChanged(todo: *TodoList, opts: *Opts) i32 {
    const path = getTodoPath(opts);
    const buf = os.readFile(path) orelse {
        util.err("could not read '{s}'.", .{path});
        return -1;
    };
    const offset = todo.lineOffset(todo.current + 1);
    if (!util.eql(buf, todo.buf.items[offset..])) {
        todo.* = .{};
        if (readPopulateTodo(todo, opts) != 0) return -1;
        return 1;
    }
    return 0;
}

const rescheduled_advice_fmt = "Could not execute the todo command\n" ++
    "\n" ++
    "    {s}" ++
    "\n" ++
    "It has been rescheduled; To edit the command before continuing, please\n" ++
    "edit the todo list first:\n" ++
    "\n" ++
    "    git rebase --edit-todo\n" ++
    "    git rebase --continue\n";

fn pickOneCommit(todo: *TodoList, opts: *Opts, check_todo: *bool, reschedule: *bool) i32 {
    const item = &todo.items.items[todo.current];
    const arg = todo.getArg(item);
    const pick_res = doPickCommit(item, opts, isFinalFixup(todo), check_todo);
    if (!isRebaseI(opts)) return switch (pick_res) {
        .err => -1,
        .conflicts => 1,
        else => 0,
    };
    switch (pick_res) {
        .err => {
            reschedule.* = true;
            return -1;
        },
        else => {},
    }
    if (item.command == .edit) {
        const commit = item.commit.?;
        const res: i32 = if (pick_res == .conflicts) 1 else 0;
        const to_amend = pick_res != .conflicts and pick_res != .dropped;
        if (pick_res == .ok or pick_res == .dropped) {
            if (!opts.verbose) termClearLine();
            util.eprint("Stopped at {s}...  {s}\n", .{ shortCommitName(commit), arg });
        }
        return errorWithPatch(commit, arg, opts, res, to_amend);
    }
    switch (pick_res) {
        .ok => {
            recordInRewritten(item.commit.?.oid(), peekCommand(todo, 1));
            return 0;
        },
        .dropped => {
            if (isFinalFixup(todo)) flushRewrittenPending();
            return 0;
        },
        .conflicts => {
            if (isFixup(item.command)) return errorFailedSquash(item.commit.?, opts, arg);
            var to_amend = false;
            if (item.command == .reword) {
                if (revparse.getOid("HEAD")) |h| {
                    if (hash.eql(item.commit.?.oid(), h) or (opts.have_squash_onto and hash.eql(opts.squash_onto, h))) to_amend = true;
                }
            }
            return errorWithPatch(item.commit.?, arg, opts, 1, to_amend);
        },
        .err => unreachable,
    }
}

/// pick_commits() for rebase -i
fn pickCommitsRebase(todo: *TodoList, opts: *Opts) i32 {
    var res: i32 = 0;
    var reschedule = false;
    if (readAndRefreshCache(opts) != 0) return -1;
    _ = os.unlink(rebasePath("message"));
    _ = os.unlink(rebasePath("stopped-sha"));
    _ = os.unlink(rebasePath("amend"));
    _ = os.unlink(rebasePath("patch"));

    while (todo.current < todo.items.items.len) {
        const item = todo.items.items[todo.current];
        const arg = todo.getArg(&todo.items.items[todo.current]);
        var check_todo = false;
        if (saveTodo(todo, opts, reschedule) != 0) return -1;
        if (item.command != .comment) {
            todo.done_nr += 1;
            os.writeFile(rebasePath("msgnum"), util.fmt("{d}\n", .{todo.done_nr}), 0o666) catch {};
            if (!opts.quiet) util.eprint("Rebasing ({d}/{d}){s}", .{ todo.done_nr, todo.total_nr, if (opts.verbose) "\n" else "\r" });
        }
        _ = os.unlink(rebasePath("author-script"));
        _ = os.unlink(gitPath("MERGE_HEAD"));
        refs.deleteRef("AUTO_MERGE", null, refs.F_NO_DEREF, "") catch {};
        refs.deleteRef("REBASE_HEAD", null, refs.F_NO_DEREF, "") catch {};
        if (item.command == .break_) {
            if (!opts.verbose) termClearLine();
            return stoppedAtHead();
        }
        opts.message = .empty;
        opts.have_message = false;
        if (@intFromEnum(item.command) <= @intFromEnum(Command.squash)) {
            res = pickOneCommit(todo, opts, &check_todo, &reschedule);
            if (res == 0 and item.command == .edit) return 0;
        } else if (item.command == .exec) {
            if (!opts.verbose) termClearLine();
            res = doExec(arg, opts.quiet);
            if (res != 0 and opts.reschedule_failed_exec) reschedule = true;
            check_todo = true;
        } else if (item.command == .label) {
            res = doLabel(arg);
            if (res != 0) reschedule = true;
        } else if (item.command == .reset) {
            res = doReset(arg, opts);
            if (res != 0) reschedule = true;
        } else if (item.command == .merge) {
            res = doMerge(item.commit, arg, item.flags, &check_todo, opts);
            if (res < 0) {
                reschedule = true;
            } else if (item.commit) |c| recordInRewritten(c.oid(), peekCommand(todo, 1));
            if (res > 0) return errorWithPatch(item.commit, arg, opts, res, false);
        } else if (item.command == .update_ref) {
            res = doUpdateRef(arg);
            if (res != 0) reschedule = true;
        } else if (!isNoop(item.command)) {
            util.err("unknown command {d}", .{@intFromEnum(item.command)});
            return -1;
        }

        var restart = false;
        if (reschedule) {
            advice.advise(util.fmt(rescheduled_advice_fmt, .{todo.line(todo.current)}));
            if (saveTodo(todo, opts, true) != 0) return -1;
            if (item.commit) |c| _ = writeRebaseHead(c.oid());
        } else if (check_todo and res == 0) {
            const rr = rereadTodoIfChanged(todo, opts);
            if (rr < 0) return -1;
            restart = rr == 1;
        }
        if (res != 0) return res;
        if (restart) todo.current = 0 else todo.current += 1;
    }

    const head_ref = readOneliner(rebasePath("head-name"), false, false) orelse "";
    if (util.startsWith(head_ref, "refs/")) {
        const head = revparse.getOid("HEAD") orelse {
            util.err("cannot read HEAD", .{});
            return -1;
        };
        const orig_s = readOneliner(rebasePath("orig-head"), false, false);
        const orig = if (orig_s) |s| (if (s.len >= 40) hash.fromHex(s[0..40]) else null) else null;
        if (orig == null) {
            util.err("could not read orig-head", .{});
            return -1;
        }
        const onto = readOneliner(rebasePath("onto"), false, false) orelse {
            util.err("could not read 'onto'", .{});
            return -1;
        };
        refs.update(head_ref, head, orig.?, reflogMessage(opts, "finish", util.fmt("{s} onto {s}", .{ head_ref, onto })), true) catch {
            util.err("{s}", .{refs.last_error});
            util.err("could not update {s}", .{head_ref});
            return -1;
        };
        refs.writeSymref("HEAD", head_ref, reflogMessage(opts, "finish", util.fmt("returning to {s}", .{head_ref}))) catch {
            util.err("could not update HEAD to {s}", .{head_ref});
            return -1;
        };
    }
    if (opts.verbose) {
        if (readOneliner(rebasePath("orig-head"), false, false)) |o| {
            if (revparse.getOid(o)) |orig| {
                if (revparse.getOid("HEAD")) |head| {
                    _ = runGit(&.{ "diff", "--stat", "--no-color", &hash.hex(orig), &hash.hex(head) }, .{ .no_stdin = true });
                }
            }
        }
    }
    flushRewrittenPending();
    if (os.readFile(rebasePath("rewritten-list"))) |rl| {
        if (rl.len > 0) {
            _ = runGit(&.{ "notes", "copy", "--for-rewrite=rebase" }, .{ .stdin_data = rl });
            _ = hook.run("post-rewrite", &.{"rebase"}, .{ .path_to_stdin = rebasePath("rewritten-list") });
        }
    }
    _ = applyAutostash(rebasePath("autostash"));
    if (!opts.quiet) {
        if (!opts.verbose) termClearLine();
        util.eprint("Successfully rebased and updated {s}.\n", .{head_ref});
    }
    if (doUpdateRefs(opts.quiet) != 0) return -1;
    return removeState(opts);
}

/// commit_staged_changes()
fn commitStagedChanges(opts: *Opts, todo: *TodoList) i32 {
    var flags: u32 = ALLOW_EMPTY | EDIT_MSG;
    var final_fixup = false;
    const reflog_action = reflogMessage(opts, "continue", null);
    index_mod.discard();
    if (wtstatus.hasUnstagedChanges(true)) {
        util.err("cannot rebase: You have unstaged changes.", .{});
        return -1;
    }
    const is_clean = !wtstatus.hasUncommittedChanges(false);
    if (!is_clean and !os.exists(rebasePath("message"))) {
        const g = gpgSignOptQuoted(opts);
        util.err(staged_changes_advice, .{ g, g });
        return -1;
    }
    if (os.exists(rebasePath("amend"))) {
        const head = revparse.getOid("HEAD") orelse {
            util.err("cannot amend non-existing commit", .{});
            return -1;
        };
        const rev = readOneliner(rebasePath("amend"), false, false) orelse {
            util.err("invalid file: '{s}'", .{rebasePath("amend")});
            return -1;
        };
        const to_amend = (if (rev.len >= 40) hash.fromHex(rev[0..40]) else null) orelse {
            util.err("invalid contents: '{s}'", .{rebasePath("amend")});
            return -1;
        };
        if (!is_clean and !hash.eql(head, to_amend)) {
            util.err("\nYou have uncommitted changes in your working tree. Please, commit them\n" ++
                "first and then run 'git rebase --continue' again.", .{});
            return -1;
        }
        const next = peekCommand(todo, 0);
        const next_is_fixup = next != null and isFixup(next.?);
        if (!is_clean or opts.current_fixup_count == 0) {
            // not the final fixup
        } else if (!hash.eql(head, to_amend) or !os.exists(rebasePath("stopped-sha"))) {
            if (!next_is_fixup) {
                _ = os.unlink(rebasePath("message-fixup"));
                _ = os.unlink(rebasePath("message-squash"));
                _ = os.unlink(rebasePath("current-fixups"));
                opts.current_fixups = .empty;
                opts.current_fixup_count = 0;
            }
        } else {
            opts.current_fixup_count -= 1;
            var len = opts.current_fixups.items.len;
            while (len > 0 and opts.current_fixups.items[len - 1] != '\n') len -= 1;
            if (len > 0) len -= 1;
            opts.current_fixups.items.len = len;
            if (writeMessage(opts.current_fixups.items, rebasePath("current-fixups"), false) < 0) {
                util.err("could not write file: '{s}'", .{rebasePath("current-fixups")});
                return -1;
            }
            if (opts.current_fixup_count > 0 and !next_is_fixup) {
                final_fixup = true;
                if (!seenSquash(opts) and !seenFixupEditMsg(opts)) flags = (flags & ~EDIT_MSG) | CLEANUP_MSG;
            } else if (next_is_fixup) {
                var commit: ?*Commit = null;
                if (parseHead(&commit) != 0) {
                    util.err("could not parse HEAD", .{});
                    return -1;
                }
                const p = pretty.logmsgReencode(commit.?, commitOutputEncoding()).msg;
                const msg = findCommitSubject(p).rest;
                if (writeMessage(msg, rebasePath("message-squash"), false) != 0) {
                    util.err("could not write file: '{s}'", .{rebasePath("message-squash")});
                    return -1;
                }
            }
        }
        flags |= AMEND_MSG;
    }
    if (is_clean) {
        if (refs.exists("CHERRY_PICK_HEAD")) {
            refs.deleteRef("CHERRY_PICK_HEAD", null, refs.F_NO_DEREF, "") catch {
                util.err("could not remove CHERRY_PICK_HEAD", .{});
                return -1;
            };
        }
        _ = os.unlink(mergeMsgPath());
        if (!final_fixup) return 0;
    }
    if (runGitCommit(if (final_fixup) null else rebasePath("message"), reflog_action, opts, flags) != 0) {
        util.err("could not commit staged changes.", .{});
        return -1;
    }
    _ = os.unlink(rebasePath("amend"));
    _ = os.unlink(gitPath("MERGE_HEAD"));
    refs.deleteRef("AUTO_MERGE", null, refs.F_NO_DEREF, "") catch {};
    if (final_fixup) {
        _ = os.unlink(rebasePath("message-fixup"));
        _ = os.unlink(rebasePath("message-squash"));
    }
    if (opts.current_fixup_count > 0) {
        _ = os.unlink(rebasePath("current-fixups"));
        opts.current_fixups = .empty;
        opts.current_fixup_count = 0;
    }
    return 0;
}

fn continueRebase(todo: *TodoList, opts: *Opts) i32 {
    if (os.exists(rebasePath("dropped"))) {
        const res = todoCheckAgainstBackup(opts, todo);
        if (res != 0) return res;
        _ = os.unlink(rebasePath("dropped"));
    }
    if (commitStagedChanges(opts, todo) != 0) return -1;
    if (os.exists(rebasePath("stopped-sha"))) {
        if (readOneliner(rebasePath("stopped-sha"), false, true)) |s| {
            if (s.len >= 40) {
                if (hash.fromHex(s[0..40])) |oid| recordInRewritten(oid, peekCommand(todo, 0));
            }
        }
    }
    return 0;
}

// ---------------------------------------------------------------------------
// todo list creation (sequencer_make_script etc.)

const logtree = @import("logtree.zig");

pub const TODO_LIST_KEEP_EMPTY: u32 = 1 << 0;
pub const TODO_LIST_SHORTEN_IDS: u32 = 1 << 1;
pub const TODO_LIST_ABBREVIATE_CMDS: u32 = 1 << 2;
pub const TODO_LIST_REBASE_MERGES: u32 = 1 << 3;
pub const TODO_LIST_REBASE_COUSINS: u32 = 1 << 4;
pub const TODO_LIST_APPEND_TODO_HELP: u32 = 1 << 5;
pub const TODO_LIST_ROOT_WITH_ONTO: u32 = 1 << 6;
pub const TODO_LIST_REAPPLY_CHERRY_PICKS: u32 = 1 << 7;
pub const TODO_LIST_WARN_SKIPPED_CHERRY_PICKS: u32 = 1 << 8;

const OidStrMap = std.AutoHashMap(Oid, []const u8);
const OidSet = std.AutoHashMap(Oid, void);

const LabelState = struct {
    commit2label: OidStrMap,
    labels: std.StringHashMap(void),
    max_label_length: usize = 255 - 5 - 16,
};

fn labelOid(oid: Oid, label_in: ?[]const u8, state: *LabelState) []const u8 {
    if (state.commit2label.get(oid)) |s| return s;
    var buf: util.Buf = .empty;
    if (label_in == null) {
        util.bufAppend(&buf, revparse.abbrev(oid, revparse.defaultAbbrev()));
        if (state.labels.contains(buf.items)) {
            const full = hash.hex(oid);
            var i: usize = buf.items.len + 1;
            while (i < 40) : (i += 1) {
                if (!state.labels.contains(full[0..i])) break;
            }
            buf = .empty;
            util.bufAppend(&buf, full[0..@min(i, 40)]);
        }
    } else {
        const label = label_in.?;
        var label_is_utf8 = true;
        const max_len = state.max_label_length;
        var k: usize = 0;
        while (k < label.len and buf.items.len + 1 < max_len) : (k += 1) {
            const ch = label[k];
            if (std.ascii.isAlphanumeric(ch) or (!label_is_utf8 and ch & 0x80 != 0)) {
                util.bufByte(&buf, ch);
            } else if (ch & 0x80 != 0) {
                const n = std.unicode.utf8ByteSequenceLength(ch) catch 0;
                if (n > 0 and k + n <= label.len and std.unicode.utf8ValidateSlice(label[k .. k + n])) {
                    if (buf.items.len + n > max_len) break;
                    util.bufAppend(&buf, label[k .. k + n]);
                    k += n - 1;
                } else {
                    label_is_utf8 = false;
                    util.bufByte(&buf, ch);
                }
            } else if (buf.items.len > 0 and buf.items[buf.items.len - 1] != '-') {
                util.bufByte(&buf, '-');
            }
        }
        if (buf.items.len == 0) {
            util.bufAppend(&buf, "rev-");
            util.bufAppend(&buf, revparse.abbrev(oid, revparse.defaultAbbrev()));
        }
        if ((buf.items.len == 40 and hash.fromHex(buf.items) != null) or
            (buf.items.len == 1 and buf.items[0] == '#') or state.labels.contains(buf.items))
        {
            const len = buf.items.len;
            var i: usize = 2;
            while (true) : (i += 1) {
                buf.items.len = len;
                util.bufPrint(&buf, "-{d}", .{i});
                if (!state.labels.contains(buf.items)) break;
            }
        }
    }
    const s = util.dupe(buf.items);
    state.labels.put(s, {}) catch util.oom();
    state.commit2label.put(oid, s) catch util.oom();
    return s;
}

fn ppCommit(commit: *Commit, format: []const u8, out: *util.Buf) void {
    const ctx = pretty.Context{ .fmt = .userformat, .fmt_string = format, .output_encoding = pretty.logOutputEncoding() };
    pretty.formatCommitMessage(commit, format, out, &ctx);
}

fn makeScriptWithMerges(format: []const u8, revs: *revision.RevInfo, out: *util.Buf, flags: u32) i32 {
    const keep_empty = flags & TODO_LIST_KEEP_EMPTY != 0;
    const rebase_cousins = flags & TODO_LIST_REBASE_COUSINS != 0;
    const root_with_onto = flags & TODO_LIST_ROOT_WITH_ONTO != 0;
    var skipped_commit = false;
    const abbr = flags & TODO_LIST_ABBREVIATE_CMDS != 0;
    const cmd_pick = if (abbr) "p" else "pick";
    const cmd_label = if (abbr) "l" else "label";
    const cmd_reset = if (abbr) "t" else "reset";
    const cmd_merge = if (abbr) "m" else "merge";

    var commits: std.ArrayList(*Commit) = .empty;
    var tips: std.ArrayList(*Commit) = .empty;
    var commit2todo = OidStrMap.init(gpa);
    var interesting = OidSet.init(gpa);
    var child_seen = OidSet.init(gpa);
    var shown = OidSet.init(gpa);
    var state = LabelState{ .commit2label = OidStrMap.init(gpa), .labels = std.StringHashMap(void).init(gpa) };
    if (repo_mod.cfg.getInt("rebase.maxlabellength")) |v| state.max_label_length = @intCast(@max(v, 0));
    logtree.loadBranchDecorations();

    if (revs.cmdline.items.len > 0 and revs.cmdline.items[0].item.flags & cn.BOTTOM != 0) {
        const oid = revs.cmdline.items[0].item.oid;
        state.commit2label.put(oid, "onto") catch util.oom();
        state.labels.put("onto", {}) catch util.oom();
    }

    var oneline: util.Buf = .empty;
    while (revision.getRevision(revs)) |commit| {
        commits.append(gpa, commit) catch util.oom();
        interesting.put(commit.oid(), {}) catch util.oom();
        const is_empty = isOriginalCommitEmpty(commit) == 1;
        if (!is_empty and commit.obj.flags & cn.PATCHSAME != 0) {
            if (flags & TODO_LIST_WARN_SKIPPED_CHERRY_PICKS != 0)
                util.warn("skipped previously applied commit {s}", .{shortCommitName(commit)});
            skipped_commit = true;
            continue;
        }
        if (is_empty and !keep_empty) continue;
        oneline = .empty;
        ppCommit(commit, format, &oneline);
        const to_merge0 = if (commit.parents) |p| p.next else null;
        if (to_merge0 == null) {
            var b: util.Buf = .empty;
            util.bufPrint(&b, "{s} {s} {s}", .{ cmd_pick, hash.hex(commit.oid()), oneline.items });
            if (is_empty) util.bufPrint(&b, " {s} empty", .{cstr()});
            commit2todo.put(commit.oid(), b.items) catch util.oom();
            continue;
        }
        var label_from_message: []const u8 = oneline.items;
        if (util.skipPrefix(oneline.items, "# Merge ")) |p1a| {
            if (std.mem.indexOfScalar(u8, p1a, '\'')) |q1| {
                const p1 = p1a[q1 + 1 ..];
                if (std.mem.indexOfScalar(u8, p1, '\'')) |q2| label_from_message = p1[0..q2];
            }
        }
        if (label_from_message.ptr == oneline.items.ptr) {
            if (util.skipPrefix(oneline.items, "# Merge pull request ")) |p1| {
                if (std.mem.indexOf(u8, p1, " from ")) |f| label_from_message = p1[f + 6 ..];
            }
        }
        label_from_message = util.dupe(label_from_message);
        var b: util.Buf = .empty;
        util.bufPrint(&b, "{s} -C {s}", .{ cmd_merge, hash.hex(commit.oid()) });
        var tm = to_merge0;
        while (tm) |n| : (tm = n.next) {
            var label = label_from_message;
            if (logtree.getNameDecoration(&n.item.obj)) |d| {
                if (util.skipPrefix(d.name, "refs/heads/")) |s| label = s else label = d.name;
            }
            const oid = n.item.oid();
            util.bufByte(&b, ' ');
            if (!interesting.contains(oid)) {
                util.bufAppend(&b, labelOid(oid, null, &state));
                continue;
            }
            tips.append(gpa, n.item) catch util.oom();
            util.bufAppend(&b, labelOid(oid, label, &state));
        }
        util.bufPrint(&b, " {s}", .{oneline.items});
        commit2todo.put(commit.oid(), b.items) catch util.oom();
    }
    if (skipped_commit) advice.adviseIfEnabled("skippedCherryPicks", "use --reapply-cherry-picks to include skipped commits");

    for (commits.items, 0..) |c, ci| {
        var p = c.parents;
        while (p) |n| : (p = n.next) {
            const oid = n.item.oid();
            if (!interesting.contains(oid)) continue;
            const gop = child_seen.getOrPut(oid) catch util.oom();
            if (gop.found_existing) _ = labelOid(oid, "branch-point", &state);
        }
        if (ci + 1 == commits.items.len) tips.append(gpa, c) catch util.oom();
    }

    util.bufPrint(out, "{s} onto\n", .{cmd_label});
    for (tips.items) |tip| {
        var commit: ?*Commit = tip;
        if (shown.contains(tip.oid())) continue;
        if (state.commit2label.get(tip.oid())) |e| {
            util.bufPrint(out, "\n{s} Branch {s}\n", .{ cstr(), e });
        } else util.bufByte(out, '\n');
        var list: std.ArrayList(*Commit) = .empty;
        while (commit != null and interesting.contains(commit.?.oid()) and !shown.contains(commit.?.oid())) {
            list.insert(gpa, 0, commit.?) catch util.oom();
            if (commit.?.parents == null) {
                commit = null;
                break;
            }
            commit = commit.?.parents.?.item;
        }
        if (commit == null) {
            util.bufPrint(out, "{s} {s}\n", .{ cmd_reset, if (rebase_cousins or root_with_onto) "onto" else "[new root]" });
        } else {
            var to: ?[]const u8 = null;
            if (state.commit2label.get(commit.?.oid())) |e| {
                to = e;
            } else if (!rebase_cousins) to = labelOid(commit.?.oid(), null, &state);
            if (to == null or util.eql(to.?, "onto")) {
                util.bufPrint(out, "{s} onto\n", .{cmd_reset});
            } else {
                oneline = .empty;
                _ = cn.parse(commit.?);
                ppCommit(commit.?, format, &oneline);
                util.bufPrint(out, "{s} {s} {s}\n", .{ cmd_reset, to.?, oneline.items });
            }
        }
        for (list.items) |c2| {
            const oid = c2.oid();
            if (commit2todo.get(oid)) |e| util.bufPrint(out, "{s}\n", .{e});
            if (state.commit2label.get(oid)) |e| util.bufPrint(out, "{s} {s}\n", .{ cmd_label, e });
            shown.put(oid, {}) catch util.oom();
        }
    }
    return 0;
}

fn seqPatchIdHook(revs: *revision.RevInfo, commit: *cn.Commit) ?hash.Oid {
    _ = revs;
    return @import("diff.zig").commitPatchId(commit);
}

/// sequencer_make_script()
pub fn makeScript(out: *util.Buf, args: []const []const u8, flags: u32) i32 {
    const keep_empty = flags & TODO_LIST_KEEP_EMPTY != 0;
    const insn = if (flags & TODO_LIST_ABBREVIATE_CMDS != 0) "p" else "pick";
    const rebase_merges = flags & TODO_LIST_REBASE_MERGES != 0;
    const reapply = flags & TODO_LIST_REAPPLY_CHERRY_PICKS != 0;
    var skipped_commit = false;

    const revs = gpa.create(revision.RevInfo) catch util.oom();
    revs.* = revision.RevInfo.init("");
    revs.verbose_header = true;
    if (!rebase_merges) revs.max_parents = 1;
    revs.cherry_mark = !reapply;
    revs.patch_id_hook = seqPatchIdHook;
    revs.limited = true;
    revs.reverse = true;
    revs.right_only = true;
    revs.sort_order = .graph;
    revs.topo_order = true;

    var format: []const u8 = repo_mod.cfg.get("rebase.instructionFormat") orelse "";
    if (format.len == 0) format = "# %s";
    if (format[0] != '#') format = util.concat(&.{ "# ", format });

    const left = revision.setupRevisions(revs, args, .{});
    if (left.len > 1) {
        util.err("make_script: unhandled options", .{});
        return -1;
    }
    if (!revision.prepareRevisionWalk(revs)) {
        util.err("make_script: error preparing revisions", .{});
        return -1;
    }
    if (rebase_merges) return makeScriptWithMerges(format, revs, out, flags);
    while (revision.getRevision(revs)) |commit| {
        const is_empty = isOriginalCommitEmpty(commit) == 1;
        if (!is_empty and commit.obj.flags & cn.PATCHSAME != 0) {
            if (flags & TODO_LIST_WARN_SKIPPED_CHERRY_PICKS != 0)
                util.warn("skipped previously applied commit {s}", .{shortCommitName(commit)});
            skipped_commit = true;
            continue;
        }
        if (is_empty and !keep_empty) continue;
        util.bufPrint(out, "{s} {s} ", .{ insn, hash.hex(commit.oid()) });
        ppCommit(commit, format, out);
        if (is_empty) util.bufPrint(out, " {s} empty", .{cstr()});
        util.bufByte(out, '\n');
    }
    if (skipped_commit) advice.adviseIfEnabled("skippedCherryPicks", "use --reapply-cherry-picks to include skipped commits");
    return 0;
}

fn appendItem(todo: *TodoList, item: Item) void {
    todo.items.append(gpa, item) catch util.oom();
}

/// todo_list_add_exec_commands()
pub fn addExecCommands(todo: *TodoList, commands: []const []const u8) void {
    var base_items: std.ArrayList(Item) = .empty;
    for (commands) |c| {
        const off = todo.buf.items.len;
        util.bufAppend(&todo.buf, c);
        util.bufByte(&todo.buf, '\n');
        base_items.append(gpa, .{ .command = .exec, .offset_in_buf = off, .arg_offset = off, .arg_len = c.len }) catch util.oom();
    }
    var items: std.ArrayList(Item) = .empty;
    var insert = false;
    for (todo.items.items) |it| {
        if (insert and !isFixup(it.command)) {
            items.appendSlice(gpa, base_items.items) catch util.oom();
            insert = false;
        }
        items.append(gpa, it) catch util.oom();
        if (it.command == .pick or it.command == .merge) insert = true;
    }
    if (insert) items.appendSlice(gpa, base_items.items) catch util.oom();
    todo.items = items;
}

fn todoToBuf(todo: *const TodoList, buf: *util.Buf, num: i32, flags: u32) void {
    var max = todo.items.items.len;
    if (num > 0 and @as(usize, @intCast(num)) < max) max = @intCast(num);
    for (todo.items.items[0..max]) |*item| {
        if (@intFromEnum(item.command) >= @intFromEnum(Command.comment)) {
            util.bufPrint(buf, "{s}\n", .{todo.getArg(item)});
            continue;
        }
        const c = commandToChar(item.command);
        if (flags & TODO_LIST_ABBREVIATE_CMDS != 0 and c != 0) util.bufByte(buf, c) else util.bufAppend(buf, commandToString(item.command));
        if (item.commit) |cm| {
            const id: []const u8 = if (flags & TODO_LIST_SHORTEN_IDS != 0) shortCommitName(cm) else hash.hexAlloc(cm.oid());
            if (item.command == .fixup) {
                if (item.flags & TODO_EDIT_FIXUP_MSG != 0) util.bufAppend(buf, " -c") else if (item.flags & TODO_REPLACE_FIXUP_MSG != 0) util.bufAppend(buf, " -C");
            }
            if (item.command == .merge) util.bufAppend(buf, if (item.flags & TODO_EDIT_MERGE_MSG != 0) " -c" else " -C");
            util.bufPrint(buf, " {s}", .{id});
        }
        if (item.arg_len == 0) util.bufByte(buf, '\n') else util.bufPrint(buf, " {s}\n", .{todo.getArg(item)});
    }
}

fn missingCommitCheckLevel() u8 {
    const v = repo_mod.cfg.get("rebase.missingcommitscheck") orelse return 0;
    if (std.ascii.eqlIgnoreCase(v, "ignore")) return 0;
    if (std.ascii.eqlIgnoreCase(v, "warn")) return 1;
    if (std.ascii.eqlIgnoreCase(v, "error")) return 2;
    util.warn("unrecognized setting {s} for option rebase.missingCommitsCheck. Ignoring.", .{v});
    return 0;
}

/// append_todo_help()
pub fn appendTodoHelp(command_count: i32, shortrevisions: ?[]const u8, shortonto: ?[]const u8, buf: *util.Buf) void {
    const msg = "\nCommands:\n" ++
        "p, pick <commit> = use commit\n" ++
        "r, reword <commit> = use commit, but edit the commit message\n" ++
        "e, edit <commit> = use commit, but stop for amending\n" ++
        "s, squash <commit> = use commit, but meld into previous commit\n" ++
        "f, fixup [-C | -c] <commit> = like \"squash\" but keep only the previous\n" ++
        "                   commit's log message, unless -C is used, in which case\n" ++
        "                   keep only this commit's message; -c is same as -C but\n" ++
        "                   opens the editor\n" ++
        "x, exec <command> = run command (the rest of the line) using shell\n" ++
        "b, break = stop here (continue rebase later with 'git rebase --continue')\n" ++
        "d, drop <commit> = remove commit\n" ++
        "l, label <label> = label current HEAD with a name\n" ++
        "t, reset <label> = reset HEAD to a label\n" ++
        "m, merge [-C <commit> | -c <commit>] <label> [# <oneline>]\n" ++
        "        create a merge commit using the original merge commit's\n" ++
        "        message (or the oneline, if no original merge commit was\n" ++
        "        specified); use -c <commit> to reword the commit message\n" ++
        "u, update-ref <ref> = track a placeholder for the <ref> to be updated\n" ++
        "                      to this position in the new commits. The <ref> is\n" ++
        "                      updated at the end of the rebase\n" ++
        "\n" ++
        "These lines can be re-ordered; they are executed from top to bottom.\n";
    const edit_todo = !(shortrevisions != null and shortonto != null);
    if (!edit_todo) {
        util.bufByte(buf, '\n');
        addCommentedC(buf, util.fmt("Rebase {s} onto {s} ({d} {s})", .{ shortrevisions.?, shortonto.?, command_count, if (command_count == 1) "command" else "commands" }));
    }
    addCommentedC(buf, msg);
    if (missingCommitCheckLevel() == 2) {
        addCommentedC(buf, "\nDo not remove any line. Use 'drop' explicitly to remove a commit.\n");
    } else addCommentedC(buf, "\nIf you remove a line here THAT COMMIT WILL BE LOST.\n");
    if (edit_todo) {
        addCommentedC(buf, "\nYou are editing the todo file of an ongoing interactive rebase.\nTo continue rebase after editing, run:\n    git rebase --continue\n\n");
    } else addCommentedC(buf, "\nHowever, if you remove everything, the rebase will be aborted.\n\n");
}

/// todo_list_write_to_file()
pub fn todoWriteToFile(todo: *const TodoList, file: []const u8, shortrevisions: ?[]const u8, shortonto: ?[]const u8, num: i32, flags: u32) i32 {
    var buf: util.Buf = .empty;
    todoToBuf(todo, &buf, num, flags);
    if (flags & TODO_LIST_APPEND_TODO_HELP != 0) appendTodoHelp(countCommands(todo), shortrevisions, shortonto, &buf);
    return writeMessage(buf.items, file, false);
}

const edit_todo_list_advice = "You can fix this with 'git rebase --edit-todo' and then run 'git rebase --continue'.\n" ++
    "Or you can abort the rebase with 'git rebase --abort'.\n";

/// todo_list_check()
fn todoCheck(old: *const TodoList, new: *const TodoList) i32 {
    const level = missingCommitCheckLevel();
    if (level == 0) return 0;
    var seen = OidSet.init(gpa);
    for (new.items.items) |it| {
        if (it.commit) |c| seen.put(c.oid(), {}) catch util.oom();
    }
    var missing: util.Buf = .empty;
    var i = old.items.items.len;
    while (i > 0) {
        i -= 1;
        const it = &old.items.items[i];
        if (it.commit) |c| {
            if (!seen.contains(c.oid())) {
                util.bufPrint(&missing, " - {s} {s}\n", .{ revparse.abbrev(c.oid(), revparse.defaultAbbrev()), old.getArg(it) });
                seen.put(c.oid(), {}) catch util.oom();
            }
        }
    }
    if (missing.items.len == 0) return 0;
    util.eprint("Warning: some commits may have been dropped accidentally.\nDropped commits (newer to older):\n", .{});
    util.ewrite(missing.items);
    util.eprint("To avoid this message, use \"drop\" to explicitly remove a commit.\n\n" ++
        "Use 'git config rebase.missingCommitsCheck' to change the level of warnings.\n" ++
        "The possible behaviours are: ignore, warn, error.\n\n", .{});
    util.ewrite(edit_todo_list_advice);
    return if (level == 2) 1 else 0;
}

pub fn todoCheckAgainstBackup(opts: *Opts, todo: *const TodoList) i32 {
    var backup = TodoList{};
    const data = os.readFile(rebasePath("git-rebase-todo.backup")) orelse return 0;
    if (data.len == 0) return 0;
    util.bufAppend(&backup.buf, data);
    _ = parseInsnBuffer(opts, &backup);
    return todoCheck(&backup, todo);
}

/// edit_todo_list(); returns 0, -1, -2 (editor failed), -3 (empty), -4 (bad).
pub fn editTodoList(opts: *Opts, todo: *TodoList, new_todo: *TodoList, shortrevisions: ?[]const u8, shortonto: ?[]const u8, flags: u32) i32 {
    const todo_file = rebasePath("git-rebase-todo");
    const todo_backup = rebasePath("git-rebase-todo.backup");
    const initial = shortrevisions != null and shortonto != null;
    var incorrect: i32 = 0;
    if (!initial) {
        incorrect = (if (parseInsnBuffer(opts, todo) != 0) @as(i32, -1) else 0) | @as(i32, if (os.exists(rebasePath("dropped"))) 1 else 0);
    }
    if (todoWriteToFile(todo, todo_file, shortrevisions, shortonto, -1, flags | TODO_LIST_SHORTEN_IDS | TODO_LIST_APPEND_TODO_HELP) != 0) {
        util.err("could not write '{s}'", .{todo_file});
        return -1;
    }
    if (incorrect == 0 and todoWriteToFile(todo, todo_backup, shortrevisions, shortonto, -1, (flags | TODO_LIST_APPEND_TODO_HELP) & ~TODO_LIST_SHORTEN_IDS) < 0) {
        util.err("could not write '{s}'.", .{todo_backup});
        return -1;
    }
    if (@import("editor.zig").launchSequence(todo_file, &.{})) return -2;
    new_todo.buf = .empty;
    util.bufAppend(&new_todo.buf, os.readFile(todo_file) orelse "");
    const stripped = util.stripspace(new_todo.buf.items, cstr());
    new_todo.buf = .empty;
    util.bufAppend(&new_todo.buf, stripped);
    if (initial and new_todo.buf.items.len == 0) return -3;
    if (parseInsnBuffer(opts, new_todo) != 0) {
        util.ewrite(edit_todo_list_advice);
        return -4;
    }
    if (incorrect != 0) {
        if (todoCheckAgainstBackup(opts, new_todo) != 0) {
            writeFile(rebasePath("dropped"), "");
            return -4;
        }
        if (incorrect > 0) _ = os.unlink(rebasePath("dropped"));
    } else if (todoCheck(todo, new_todo) != 0) {
        writeFile(rebasePath("dropped"), "");
        return -4;
    }
    filterUpdateRefs(new_todo);
    return 0;
}

/// skip_unnecessary_picks()
fn skipUnnecessaryPicks(todo: *TodoList, base_oid: *Oid) i32 {
    var i: usize = 0;
    while (i < todo.items.items.len) : (i += 1) {
        const item = &todo.items.items[i];
        if (@intFromEnum(item.command) >= @intFromEnum(Command.noop)) continue;
        if (item.command != .pick) break;
        const c = item.commit.?;
        if (!cn.parse(c)) {
            util.err("could not parse commit '{s}'", .{hash.hex(c.oid())});
            return -1;
        }
        const p = c.parents orelse break;
        if (p.next != null) break;
        if (!hash.eql(p.item.oid(), base_oid.*)) break;
        base_oid.* = c.oid();
    }
    if (i > 0) {
        if (todoWriteToFile(todo, rebasePath("done"), null, null, @intCast(i), 0) != 0) {
            util.err("could not write to '{s}': {s}", .{ rebasePath("done"), os.lastErr() });
            return -1;
        }
        const rest = todo.items.items[i..];
        std.mem.copyForwards(Item, todo.items.items[0..rest.len], rest);
        todo.items.items.len = rest.len;
        todo.current = 0;
        todo.done_nr += @intCast(i);
        if (peekCommand(todo, 0)) |pc| {
            if (isFixup(pc)) recordInRewritten(base_oid.*, pc);
        }
    }
    return 0;
}

/// todo_list_add_update_ref_commands()
fn addUpdateRefCommands(todo: *TodoList) i32 {
    var items: std.ArrayList(Item) = .empty;
    var recs: std.ArrayList(UpdateRefRec) = .empty;
    logtree.loadBranchDecorations();
    const head_ref = refs.readSymbolic("HEAD");
    const bc = @import("branchcreate.zig");
    const orig_items = todo.items.items;
    for (orig_items) |it| {
        items.append(gpa, it) catch util.oom();
        const c = it.commit orelse continue;
        var d = logtree.getNameDecoration(&c.obj);
        while (d) |dec| : (d = dec.next) {
            if ((head_ref != null and util.eql(head_ref.?, dec.name)) or dec.typ != .ref_local) continue;
            const base = todo.buf.items.len;
            var item = Item{ .command = .comment };
            if (bc.branchCheckedOut(dec.name)) |path| {
                addCommentedC(&todo.buf, util.fmt("Ref {s} checked out at '{s}'\n", .{ dec.name, path }));
            } else {
                item.command = .update_ref;
                util.bufPrint(&todo.buf, "{s}\n", .{dec.name});
                insertUpdateRef(&recs, initUpdateRefRecord(dec.name));
            }
            item.offset_in_buf = base;
            item.arg_offset = base;
            item.arg_len = todo.buf.items.len - base;
            items.append(gpa, item) catch util.oom();
        }
    }
    if (writeUpdateRefsState(recs.items) != 0) return -1;
    todo.items = items;
    return 0;
}

fn skipFixupish(subject: []const u8) ?[]const u8 {
    return util.skipPrefix(subject, "fixup! ") orelse util.skipPrefix(subject, "amend! ") orelse util.skipPrefix(subject, "squash! ");
}

/// todo_list_rearrange_squash()
pub fn rearrangeSquash(todo: *TodoList) i32 {
    const n = todo.items.items.len;
    var subject2item = std.StringHashMap(usize).init(gpa);
    var commit_todo = std.AutoHashMap(Oid, usize).init(gpa);
    const next = gpa.alloc(isize, n) catch util.oom();
    const tail = gpa.alloc(isize, n) catch util.oom();
    const subjects = gpa.alloc(?[]const u8, n) catch util.oom();
    var rearranged = false;
    for (0..n) |i| {
        const item = &todo.items.items[i];
        next[i] = -1;
        tail[i] = -1;
        subjects[i] = null;
        if (item.commit == null or item.command == .drop) continue;
        if (isFixup(item.command)) {
            util.err("the script was already rearranged.", .{});
            return -1;
        }
        _ = cn.parse(item.commit.?);
        const cb = pretty.logmsgReencode(item.commit.?, "UTF-8").msg;
        const subj_start = findCommitSubject(cb).rest;
        var sb: util.Buf = .empty;
        _ = pretty.formatSubject(&sb, subj_start, 0, " ");
        const subject = sb.items;
        subjects[i] = subject;
        var idx2: isize = -1;
        if (skipFixupish(subject)) |p0| {
            var p = p0;
            while (true) {
                while (p.len > 0 and std.ascii.isWhitespace(p[0])) p = p[1..];
                p = skipFixupish(p) orelse break;
            }
            if (subject2item.get(p)) |e| {
                idx2 = @intCast(e);
            } else if (std.mem.indexOfScalar(u8, p, ' ') == null and lookupCommitByNameQuiet(p) != null and
                commit_todo.contains(lookupCommitByNameQuiet(p).?.oid()))
            {
                idx2 = @intCast(commit_todo.get(lookupCommitByNameQuiet(p).?.oid()).?);
            } else {
                var k: usize = 0;
                while (k < i) : (k += 1) {
                    if (subjects[k]) |s| {
                        if (util.startsWith(s, p)) break;
                    }
                }
                idx2 = if (k == i) -1 else @intCast(k);
            }
        }
        if (idx2 >= 0) {
            const j: usize = @intCast(idx2);
            rearranged = true;
            if (util.startsWith(subject, "fixup!")) {
                todo.items.items[i].command = .fixup;
            } else if (util.startsWith(subject, "amend!")) {
                todo.items.items[i].command = .fixup;
                todo.items.items[i].flags = TODO_REPLACE_FIXUP_MSG;
            } else todo.items.items[i].command = .squash;
            if (tail[j] < 0) {
                next[i] = next[j];
                next[j] = @intCast(i);
            } else {
                const t: usize = @intCast(tail[j]);
                next[i] = next[t];
                next[t] = @intCast(i);
            }
            tail[j] = @intCast(i);
        } else if (!subject2item.contains(subject)) {
            subject2item.put(subject, i) catch util.oom();
        }
        commit_todo.put(item.commit.?.oid(), i) catch util.oom();
    }
    if (rearranged) {
        var items: std.ArrayList(Item) = .empty;
        for (0..n) |i| {
            if (isFixup(todo.items.items[i].command)) continue;
            var cur: isize = @intCast(i);
            while (cur >= 0) {
                items.append(gpa, todo.items.items[@intCast(cur)]) catch util.oom();
                cur = next[@intCast(cur)];
            }
        }
        todo.items = items;
    }
    return 0;
}

fn lookupCommitByNameQuiet(name: []const u8) ?*Commit {
    return lookupCommitByName(name);
}

/// complete_action()
pub fn completeAction(opts: *Opts, flags: u32, shortrevisions: []const u8, onto_name: []const u8, onto: *Commit, orig_head: Oid, commands: []const []const u8, autosquash: bool, update_refs: bool, todo: *TodoList) i32 {
    const shortonto = revparse.abbrev(onto.oid(), revparse.defaultAbbrev());
    var oid = onto.oid();
    if (todo.buf.items.len == 0) appendItem(todo, .{ .command = .noop });
    if (update_refs and addUpdateRefCommands(todo) != 0) return -1;
    if (autosquash and rearrangeSquash(todo) != 0) return -1;
    if (commands.len > 0) addExecCommands(todo, commands);
    if (countCommands(todo) == 0) {
        _ = applyAutostash(rebasePath("autostash"));
        _ = removeState(opts);
        util.err("nothing to do", .{});
        return -1;
    }
    var new_todo = TodoList{};
    const res = editTodoList(opts, todo, &new_todo, shortrevisions, shortonto, flags);
    switch (res) {
        -1 => return -1,
        -2 => {
            _ = applyAutostash(rebasePath("autostash"));
            _ = removeState(opts);
            return -1;
        },
        -3 => {
            _ = applyAutostash(rebasePath("autostash"));
            _ = removeState(opts);
            util.err("nothing to do", .{});
            return -1;
        },
        -4 => {
            _ = checkoutOnto(opts, onto_name, onto.oid(), orig_head);
            return -1;
        },
        else => {},
    }
    var buf2: util.Buf = .empty;
    todoToBuf(&new_todo, &buf2, -1, 0);
    new_todo.buf = buf2;
    new_todo.total_nr = 0;
    if (parseInsnBuffer(opts, &new_todo) < 0) util.die("BUG: invalid todo list after expanding IDs:\n{s}", .{new_todo.buf.items});
    if (opts.allow_ff and skipUnnecessaryPicks(&new_todo, &oid) != 0) {
        util.err("could not skip unnecessary pick commands", .{});
        return -1;
    }
    if (todoWriteToFile(&new_todo, rebasePath("git-rebase-todo"), null, null, -1, flags & ~TODO_LIST_SHORTEN_IDS) != 0) {
        util.err("could not write '{s}': {s}", .{ rebasePath("git-rebase-todo"), os.lastErr() });
        return -1;
    }
    if (checkoutOnto(opts, onto_name, oid, orig_head) != 0) return -1;
    index_mod.discard();
    if (wtstatus.requireCleanWorkTree("rebase", null, true, true)) return -1;
    writeFile(rebasePath("end"), util.fmt("{d}\n", .{new_todo.total_nr}));
    return pickCommits(&new_todo, opts);
}

/// builtin/rebase.c edit_todo_file()
pub fn editTodoFile(flags: u32, opts: *Opts) i32 {
    var todo = TodoList{};
    var new_todo = TodoList{};
    const todo_file = rebasePath("git-rebase-todo");
    const data = os.readFile(todo_file) orelse {
        util.err("could not read '{s}'.: {s}", .{ todo_file, os.lastErr() });
        return -1;
    };
    util.bufAppend(&todo.buf, util.stripspace(data, cstr()));
    var res = editTodoList(opts, &todo, &new_todo, null, null, flags);
    if (res == 0 and todoWriteToFile(&new_todo, todo_file, null, null, -1, flags & ~TODO_LIST_SHORTEN_IDS) != 0) {
        util.err("could not write '{s}': {s}", .{ todo_file, os.lastErr() });
        res = -1;
    }
    return res;
}
