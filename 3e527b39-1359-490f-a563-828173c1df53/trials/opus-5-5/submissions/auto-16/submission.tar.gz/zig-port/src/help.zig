//! Port of help.c (command lists, unknown-command suggestions,
//! help.autocorrect), builtin/help.c (git help) and a minimal
//! git-web--browse.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const config = @import("config.zig");
const repo_mod = @import("repo.zig");
const column = @import("column.zig");
const po = @import("parseopt.zig");
const cl = @import("command_list.zig");
const gpa = util.gpa;

pub const git_usage_string =
    "git [-v | --version] [-h | --help] [-C <path>] [-c <name>=<value>]\n" ++
    "           [--exec-path[=<path>]] [--html-path] [--man-path] [--info-path]\n" ++
    "           [-p | --paginate | -P | --no-pager] [--no-replace-objects] [--no-lazy-fetch]\n" ++
    "           [--no-optional-locks] [--no-advice] [--bare] [--git-dir=<path>]\n" ++
    "           [--work-tree=<path>] [--namespace=<name>] [--config-env=<name>=<envvar>]\n" ++
    "           <command> [<args>]";

pub const git_more_info_string =
    "'git help -a' and 'git help -g' list available subcommands and some\n" ++
    "concept guides. See 'git help <command>' or 'git help <concept>'\n" ++
    "to read about a specific subcommand or concept.\n" ++
    "See 'git help git' for an overview of the system.";

/// Builtins that git marks NO_PARSEOPT (for --list-cmds=parseopt).
const no_parseopt = [_][]const u8{
    "check-ref-format", "credential",             "diff",                 "diff-files",    "diff-index",
    "diff-pairs",       "diff-tree",              "fast-import",          "fetch-pack",    "get-tar-commit-id",
    "index-pack",       "mailsplit",              "merge-index",          "merge-ours",    "merge-recursive",
    "merge-recursive-ours", "merge-recursive-theirs", "merge-subtree",    "pack-redundant", "patch-id",
    "remote-ext",       "remote-fd",              "rev-list",             "rev-parse",     "unpack-file",
    "unpack-objects",   "upload-archive",         "upload-archive--writer", "var",
};

/// Builtins that git marks DEPRECATED.
pub const deprecated_cmds = [_][]const u8{ "pack-redundant", "whatchanged" };

pub fn isDeprecated(name: []const u8) bool {
    for (deprecated_cmds) |d| if (util.eql(d, name)) return @import("commands.zig").find(name) != null;
    return false;
}

// ---------------------------------------------------------------------------
// early config (read_early_config)

var early_cfg: ?config.Config = null;

/// Config as read_early_config() would see it: if setup already ran, the
/// repository config; else discover the repository without side effects.
pub fn earlyConfig() *const config.Config {
    if (repo_mod.repo_ != null and repo_mod.have_repository) {
        if (repo_mod.cfg.entries.items.len == 0) repo_mod.loadConfig();
        return &repo_mod.cfg;
    }
    if (early_cfg) |*c| return c;
    var c: config.Config = .{};
    var o = config.Options{};
    if (repo_mod.discoverGitDirectory()) |d| {
        o.git_dir = d.gitdir;
        o.common_dir = d.commondir;
        c.git_dir = d.gitdir;
    }
    config.loadSequenceInto(&c, &o);
    early_cfg = c;
    return &early_cfg.?;
}

pub fn invalidateEarlyConfig() void {
    early_cfg = null;
}

pub const Alias = struct { name: []const u8, value: []const u8 };

fn aliasKey(key: []const u8) ?struct { name: []const u8, subsection: bool } {
    const pk = config.parseConfigKey(key, "alias") orelse return null;
    if (pk.sub) |sub| {
        if (sub.len == 0) return .{ .name = pk.key, .subsection = false };
        if (util.eql(pk.key, "command")) return .{ .name = sub, .subsection = true };
        return .{ .name = key["alias.".len..], .subsection = false };
    }
    return .{ .name = pk.key, .subsection = false };
}

/// alias_lookup()
pub fn aliasLookup(name: []const u8) ?[]const u8 {
    const c = earlyConfig();
    var res: ?[]const u8 = null;
    for (c.entries.items) |e| {
        const a = aliasKey(e.key) orelse continue;
        const match = if (a.subsection) util.eql(a.name, name) else std.ascii.eqlIgnoreCase(a.name, name);
        if (!match) continue;
        if (e.value == null) {
            _ = config.errorNonbool(e.key);
            util.die("bad config line {d} in file {s}", .{ e.line, e.origin });
        }
        res = e.value;
    }
    return res;
}

/// list_aliases()
pub fn listAliases() []Alias {
    const c = earlyConfig();
    var l: std.ArrayList(Alias) = .empty;
    for (c.entries.items) |e| {
        const a = aliasKey(e.key) orelse continue;
        const v = e.value orelse {
            _ = config.errorNonbool(e.key);
            util.die("bad config line {d} in file {s}", .{ e.line, e.origin });
        };
        l.append(gpa, .{ .name = a.name, .value = v }) catch util.oom();
    }
    return l.items;
}

// ---------------------------------------------------------------------------
// command lists

const Named = struct { name: []const u8, help: []const u8, category: u32 };

fn dropPrefix(name: []const u8, category: u32) []const u8 {
    const prefix: []const u8 = if (category & (cl.CAT_guide | cl.CAT_userinterfaces | cl.CAT_developerinterfaces) != 0) "git" else "git-";
    return util.skipPrefix(name, prefix) orelse name;
}

fn extractCmds(mask: u32) []Named {
    var l: std.ArrayList(Named) = .empty;
    for (cl.command_list) |c| {
        if (c.category & mask == 0) continue;
        l.append(gpa, .{ .name = dropPrefix(c.name, c.category), .help = c.help, .category = c.category }) catch util.oom();
    }
    return l.items;
}

fn putPad(o: *util.Buf, n: usize) void {
    var i: usize = 0;
    while (i < n) : (i += 1) util.bufByte(o, ' ');
}

fn printCommandList(o: *util.Buf, cmds: []const Named, mask: u32, longest: usize) void {
    for (cmds) |c| {
        if (c.category & mask == 0) continue;
        const len = column.strWidth(c.name);
        util.bufPrint(o, "   {s}   ", .{c.name});
        if (longest > len) putPad(o, longest - len);
        util.bufAppend(o, c.help);
        util.bufByte(o, '\n');
    }
}

const CatDesc = struct { cat: u32, desc: []const u8 };

const common_categories = [_]CatDesc{
    .{ .cat = cl.CAT_init, .desc = "start a working area (see also: git help tutorial)" },
    .{ .cat = cl.CAT_worktree, .desc = "work on the current change (see also: git help everyday)" },
    .{ .cat = cl.CAT_info, .desc = "examine the history and state (see also: git help revisions)" },
    .{ .cat = cl.CAT_history, .desc = "grow, mark and tweak your common history" },
    .{ .cat = cl.CAT_remote, .desc = "collaborate (see also: git help workflows)" },
};
const common_mask = cl.CAT_init | cl.CAT_worktree | cl.CAT_info | cl.CAT_history | cl.CAT_remote;

const main_categories = [_]CatDesc{
    .{ .cat = cl.CAT_mainporcelain, .desc = "Main Porcelain Commands" },
    .{ .cat = cl.CAT_ancillarymanipulators, .desc = "Ancillary Commands / Manipulators" },
    .{ .cat = cl.CAT_ancillaryinterrogators, .desc = "Ancillary Commands / Interrogators" },
    .{ .cat = cl.CAT_foreignscminterface, .desc = "Interacting with Others" },
    .{ .cat = cl.CAT_plumbingmanipulators, .desc = "Low-level Commands / Manipulators" },
    .{ .cat = cl.CAT_plumbinginterrogators, .desc = "Low-level Commands / Interrogators" },
    .{ .cat = cl.CAT_synchingrepositories, .desc = "Low-level Commands / Syncing Repositories" },
    .{ .cat = cl.CAT_purehelpers, .desc = "Low-level Commands / Internal Helpers" },
    .{ .cat = cl.CAT_userinterfaces, .desc = "User-facing repository, command and file interfaces" },
    .{ .cat = cl.CAT_developerinterfaces, .desc = "Developer-facing file formats, protocols and other interfaces" },
};

fn namedLess(_: void, a: Named, b: Named) bool {
    return std.mem.order(u8, a.name, b.name) == .lt;
}

fn printCmdByCategory(o: *util.Buf, catdesc: []const CatDesc) usize {
    var mask: u32 = 0;
    for (catdesc) |c| mask |= c.cat;
    const cmds = extractCmds(mask);
    var longest: usize = 0;
    for (cmds) |c| longest = @max(longest, c.name.len);
    std.mem.sort(Named, cmds, {}, namedLess);
    for (catdesc, 0..) |c, i| {
        if (i > 0) util.bufByte(o, '\n');
        util.bufAppend(o, c.desc);
        util.bufByte(o, '\n');
        printCommandList(o, cmds, c.cat, longest);
    }
    return longest;
}

pub fn listCommonCmdsHelp(o: *util.Buf) void {
    util.bufAppend(o, "These are common Git commands used in various situations:\n\n");
    _ = printCmdByCategory(o, &common_categories);
}

fn uniqSorted(l: *std.ArrayList([]const u8)) void {
    util.sortStrings(l.items);
    if (l.items.len == 0) return;
    var j: usize = 1;
    var i: usize = 1;
    while (i < l.items.len) : (i += 1) {
        if (!util.eql(l.items[i], l.items[j - 1])) {
            l.items[j] = l.items[i];
            j += 1;
        }
    }
    l.shrinkRetainingCapacity(j);
}

fn isExecutable(path: []const u8) bool {
    const st = os.statPath(path) orelse return false;
    return st.isReg() and st.mode & 0o100 != 0;
}

fn listCommandsInDir(l: *std.ArrayList([]const u8), path: []const u8, prefix: []const u8) void {
    const ents = os.listDir(path) orelse return;
    for (ents) |e| {
        const ent = util.skipPrefix(e.name, prefix) orelse continue;
        if (!isExecutable(util.concat(&.{ path, "/", e.name }))) continue;
        const name = if (util.endsWith(ent, ".exe")) ent[0 .. ent.len - 4] else ent;
        l.append(gpa, util.dupe(name)) catch util.oom();
    }
}

pub fn execPath() []const u8 {
    return @import("main.zig").exec_path;
}

/// Builtin names, sorted (git's commands[] array is sorted).
pub fn builtinNames() [][]const u8 {
    const commands = @import("commands.zig");
    var l: std.ArrayList([]const u8) = .empty;
    for (commands.table) |c| l.append(gpa, c.name) catch util.oom();
    uniqSorted(&l);
    return l.items;
}

pub const CmdLists = struct { main: [][]const u8, other: [][]const u8 };

/// load_command_list("git-", ...)
pub fn loadCommandList() CmdLists {
    var main_l: std.ArrayList([]const u8) = .empty;
    var other_l: std.ArrayList([]const u8) = .empty;
    main_l.appendSlice(gpa, builtinNames()) catch util.oom();
    const ep = execPath();
    if (ep.len > 0) {
        listCommandsInDir(&main_l, ep, "git-");
        uniqSorted(&main_l);
    }
    if (os.getenv("PATH")) |p| {
        var it = std.mem.splitScalar(u8, p, ':');
        while (it.next()) |d| {
            if (ep.len == 0 or !util.eql(d, ep)) listCommandsInDir(&other_l, d, "git-");
        }
        uniqSorted(&other_l);
    }
    // exclude_cmds(other, main)
    var j: usize = 0;
    for (other_l.items) |o| {
        var found = false;
        for (main_l.items) |m| {
            if (util.eql(m, o)) {
                found = true;
                break;
            }
        }
        if (!found) {
            other_l.items[j] = o;
            j += 1;
        }
    }
    other_l.shrinkRetainingCapacity(j);
    return .{ .main = main_l.items, .other = other_l.items };
}

pub fn isGitCommand(s: []const u8) bool {
    if (@import("commands.zig").find(s) != null) return true;
    const l = loadCommandList();
    for (l.main) |m| if (util.eql(m, s)) return true;
    for (l.other) |m| if (util.eql(m, s)) return true;
    return false;
}

fn listCmdsByCategory(l: *std.ArrayList([]const u8), cat: []const u8) void {
    var cat_id: u32 = 0;
    for (cl.category_names, 0..) |n, i| {
        if (util.eql(n, cat)) {
            cat_id = @as(u32, 1) << @intCast(i);
            break;
        }
    }
    if (cat_id == 0) util.die("unsupported command listing type '{s}'", .{cat});
    for (cl.command_list) |c| {
        if (c.category & cat_id == 0) continue;
        l.append(gpa, dropPrefix(c.name, c.category)) catch util.oom();
    }
}

fn listCmdsByConfig(l: *std.ArrayList([]const u8)) void {
    const cmd_list = earlyConfigGet("completion.commands") orelse return;
    uniqSorted(l);
    var it = std.mem.tokenizeScalar(u8, cmd_list, ' ');
    while (it.next()) |w| {
        if (w[0] == '-') {
            var i: usize = 0;
            while (i < l.items.len) {
                if (util.eql(l.items[i], w[1..])) {
                    _ = l.orderedRemove(i);
                    break;
                }
                i += 1;
            }
        } else {
            var found = false;
            for (l.items) |x| if (util.eql(x, w)) {
                found = true;
            };
            if (!found) {
                l.append(gpa, w) catch util.oom();
                util.sortStrings(l.items);
            }
        }
    }
}

fn earlyConfigGet(key: []const u8) ?[]const u8 {
    return earlyConfig().get(key);
}

/// git --list-cmds=<spec>
pub fn listCmds(spec: []const u8) u8 {
    var l: std.ArrayList([]const u8) = .empty;
    if (util.eql(spec, "parseopt")) {
        for (builtinNames()) |n| {
            var skip = false;
            for (no_parseopt) |x| if (util.eql(x, n)) {
                skip = true;
            };
            if (!skip) util.outf("{s} ", .{n});
        }
        return 0;
    }
    repo_mod.setup(true);
    var it = std.mem.splitScalar(u8, spec, ',');
    while (it.next()) |tok| {
        if (util.eql(tok, "builtins")) {
            l.appendSlice(gpa, builtinNames()) catch util.oom();
        } else if (util.eql(tok, "main")) {
            l.appendSlice(gpa, loadCommandList().main) catch util.oom();
        } else if (util.eql(tok, "others")) {
            l.appendSlice(gpa, loadCommandList().other) catch util.oom();
        } else if (util.eql(tok, "nohelpers")) {
            var j: usize = 0;
            for (l.items) |x| {
                if (std.mem.indexOf(u8, x, "--") == null) {
                    l.items[j] = x;
                    j += 1;
                }
            }
            l.shrinkRetainingCapacity(j);
        } else if (util.eql(tok, "alias")) {
            for (listAliases()) |a| l.append(gpa, a.name) catch util.oom();
        } else if (util.eql(tok, "config")) {
            listCmdsByConfig(&l);
        } else if (util.eql(tok, "deprecated")) {
            for (builtinNames()) |n| {
                for (deprecated_cmds) |d| if (util.eql(d, n)) l.append(gpa, n) catch util.oom();
            }
        } else if (tok.len > 5 and util.startsWith(tok, "list-")) {
            listCmdsByCategory(&l, tok[5..]);
        } else if (tok.len == 0 and it.index == null) {
            break;
        } else {
            util.die("unsupported command listing type '{s}'", .{tok});
        }
    }
    for (l.items) |x| util.outf("{s}\n", .{x});
    return 0;
}

fn prettyPrintCmdnames(o: *util.Buf, names: []const []const u8, colopts0: u32) void {
    const colopts = (colopts0 & ~column.COL_ENABLE_MASK) | column.COL_ENABLED;
    util.out(o.items);
    o.clearRetainingCapacity();
    column.printColumns(names, colopts, .{ .indent = "  ", .padding = 2 });
}

fn listCommands(o: *util.Buf, lists: CmdLists) void {
    var colopts: u32 = 0;
    column.applyRepoConfig("help", &colopts);
    if (lists.main.len > 0) {
        util.bufPrint(o, "available git commands in '{s}'\n\n", .{execPath()});
        prettyPrintCmdnames(o, lists.main, colopts);
        util.bufByte(o, '\n');
    }
    if (lists.other.len > 0) {
        util.bufAppend(o, "git commands available from elsewhere on your $PATH\n\n");
        prettyPrintCmdnames(o, lists.other, colopts);
        util.bufByte(o, '\n');
    }
}

fn aliasLess(_: void, a: Alias, b: Alias) bool {
    return std.mem.order(u8, a.name, b.name) == .lt;
}

fn listAllCmdsHelp(o: *util.Buf, show_external: bool, show_aliases: bool) void {
    util.bufAppend(o, "See 'git help <command>' to read about a specific subcommand\n\n");
    var longest = printCmdByCategory(o, &main_categories);
    if (show_external) {
        const others = loadCommandList().other;
        if (others.len > 0) util.bufAppend(o, "\nExternal commands\n");
        for (others) |x| util.bufPrint(o, "   {s}\n", .{x});
    }
    if (show_aliases) {
        const al = listAliases();
        std.mem.sort(Alias, al, {}, aliasLess);
        for (al) |a| longest = @max(longest, column.strWidth(a.name));
        if (al.len > 0) {
            util.bufAppend(o, "\nCommand aliases\n");
            var named: std.ArrayList(Named) = .empty;
            for (al) |a| named.append(gpa, .{ .name = a.name, .help = a.value, .category = 1 }) catch util.oom();
            printCommandList(o, named.items, 1, longest);
        }
    }
}

fn listCategoryHelp(o: *util.Buf, cat: u32, desc: []const u8) void {
    _ = printCmdByCategory(o, &[_]CatDesc{.{ .cat = cat, .desc = desc }});
    util.bufByte(o, '\n');
}

// ---------------------------------------------------------------------------
// help_unknown_cmd

const AUTOCORRECT_SHOW: i32 = -4;
const AUTOCORRECT_PROMPT: i32 = -3;
const AUTOCORRECT_NEVER: i32 = -2;
const AUTOCORRECT_IMMEDIATELY: i32 = -1;

fn parseAutocorrect(value: ?[]const u8) i32 {
    switch (config.parseMaybeBoolText(value)) {
        1 => return AUTOCORRECT_IMMEDIATELY,
        0 => return AUTOCORRECT_SHOW,
        else => {},
    }
    const v = value.?;
    if (util.eql(v, "prompt")) return AUTOCORRECT_PROMPT;
    if (util.eql(v, "never")) return AUTOCORRECT_NEVER;
    if (util.eql(v, "immediate")) return AUTOCORRECT_IMMEDIATELY;
    if (util.eql(v, "show")) return AUTOCORRECT_SHOW;
    return 0;
}

/// levenshtein.c
pub fn levenshtein(s1: []const u8, s2: []const u8, w: i32, s: i32, a: i32, d: i32) i32 {
    const len2 = s2.len;
    var row0 = gpa.alloc(i32, len2 + 1) catch util.oom();
    var row1 = gpa.alloc(i32, len2 + 1) catch util.oom();
    var row2 = gpa.alloc(i32, len2 + 1) catch util.oom();
    @memset(row0, 0);
    for (0..len2 + 1) |j| row1[j] = @as(i32, @intCast(j)) * a;
    for (0..s1.len) |i| {
        row2[0] = @as(i32, @intCast(i + 1)) * d;
        for (0..len2) |j| {
            row2[j + 1] = row1[j] + s * @as(i32, @intFromBool(s1[i] != s2[j]));
            if (i > 0 and j > 0 and s1[i - 1] == s2[j] and s1[i] == s2[j - 1] and row2[j + 1] > row0[j - 1] + w)
                row2[j + 1] = row0[j - 1] + w;
            if (row2[j + 1] > row1[j + 1] + d) row2[j + 1] = row1[j + 1] + d;
            if (row2[j + 1] > row2[j] + a) row2[j + 1] = row2[j] + a;
        }
        const t = row0;
        row0 = row1;
        row1 = row2;
        row2 = t;
    }
    return row1[len2];
}

const Cand = struct { name: []const u8, len: i32 };

fn candLess(_: void, a: Cand, b: Cand) bool {
    if (a.len != b.len) return a.len < b.len;
    return std.mem.order(u8, a.name, b.name) == .lt;
}

extern "c" fn usleep(us: c_uint) c_int;

fn promptYesNo(msg: []const u8) bool {
    const fd = os.openFile("/dev/tty", os.O_RDWR, 0);
    if (fd < 0) return false;
    defer os.close(fd);
    os.writeAll(fd, msg) catch {};
    var b: util.Buf = .empty;
    var ch: [1]u8 = undefined;
    while (true) {
        const n = std.c.read(fd, &ch, 1);
        if (n <= 0 or ch[0] == '\n') break;
        util.bufByte(&b, ch[0]);
    }
    return b.items.len > 0 and (b.items[0] == 'y' or b.items[0] == 'Y');
}

/// help_unknown_cmd(): exits unless an autocorrected command is assumed.
pub fn helpUnknownCmd(cmd: []const u8) []const u8 {
    const c = earlyConfig();
    var autocorrect: i32 = 0;
    var aliases: std.ArrayList([]const u8) = .empty;
    for (c.entries.items) |e| {
        if (util.eql(e.key, "help.autocorrect")) {
            var v = parseAutocorrect(e.value);
            if (v == 0) {
                v = config.configInt(e.key, e.value, &e.kvi());
                if (v < 0 or v == 1) v = AUTOCORRECT_IMMEDIATELY;
            }
            autocorrect = v;
        }
        if (aliasKey(e.key)) |a| aliases.append(gpa, a.name) catch util.oom();
    }
    if (autocorrect == AUTOCORRECT_PROMPT and (!os.isatty(0) or !os.isatty(2))) autocorrect = AUTOCORRECT_NEVER;
    if (autocorrect == AUTOCORRECT_NEVER) {
        util.eprint("git: '{s}' is not a git command. See 'git --help'.\n", .{cmd});
        os.exit(1);
    }
    const lists = loadCommandList();
    var all: std.ArrayList([]const u8) = .empty;
    all.appendSlice(gpa, lists.main) catch util.oom();
    all.appendSlice(gpa, aliases.items) catch util.oom();
    all.appendSlice(gpa, lists.other) catch util.oom();
    uniqSorted(&all);

    const common = extractCmds(common_mask);
    var cands = gpa.alloc(Cand, all.items.len) catch util.oom();
    var n: usize = 0;
    for (all.items, 0..) |cand, i| {
        if (util.eql(cand, cmd)) util.die("'{s}' appears to be a git command, but we were not\nable to execute it. Maybe git-{s} is broken?", .{ cmd, cmd });
        var cmp: std.math.Order = .gt;
        while (n < common.len) {
            cmp = std.mem.order(u8, common[n].name, cand);
            if (cmp != .lt) break;
            n += 1;
        }
        cands[i] = .{ .name = cand, .len = 0 };
        if (n < common.len and cmp == .eq) {
            n += 1;
            if (util.startsWith(cand, cmd)) continue;
        }
        cands[i].len = levenshtein(cmd, cand, 0, 2, 1, 3) + 1;
    }
    std.mem.sort(Cand, cands, {}, candLess);
    if (cands.len == 0) util.die("Uh oh. Your system reports no Git commands at all.", .{});

    const SIMILARITY_FLOOR = 7;
    n = 0;
    while (n < cands.len and cands[n].len == 0) n += 1;
    var best: i32 = 0;
    if (cands.len <= n) {
        best = SIMILARITY_FLOOR + 1;
    } else {
        best = cands[n].len;
        n += 1;
        while (n < cands.len and best == cands[n].len) n += 1;
    }
    if (autocorrect != 0 and autocorrect != AUTOCORRECT_SHOW and n == 1 and best < SIMILARITY_FLOOR) {
        const assumed = cands[0].name;
        util.eprint("WARNING: You called a Git command named '{s}', which does not exist.\n", .{cmd});
        if (autocorrect == AUTOCORRECT_IMMEDIATELY) {
            util.eprint("Continuing under the assumption that you meant '{s}'.\n", .{assumed});
        } else if (autocorrect == AUTOCORRECT_PROMPT) {
            if (!promptYesNo(util.fmt("Run '{s}' instead [y/N]? ", .{assumed}))) os.exit(1);
        } else {
            const secs: f64 = @as(f64, @floatFromInt(autocorrect)) / 10.0;
            util.eprint("Continuing in {d:.1} seconds, assuming that you meant '{s}'.\n", .{ secs, assumed });
            _ = usleep(@intCast(@as(i64, autocorrect) * 100 * 1000));
        }
        return assumed;
    }
    util.eprint("git: '{s}' is not a git command. See 'git --help'.\n", .{cmd});
    if (best < SIMILARITY_FLOOR) {
        util.eprint("{s}", .{if (n == 1) "\nThe most similar command is\n" else "\nThe most similar commands are\n"});
        for (cands[0..n]) |x| util.eprint("\t{s}\n", .{x.name});
    }
    os.exit(1);
}

// ---------------------------------------------------------------------------
// git help

const Mode = enum(i32) { none = 0, all = 1, guides, config, user_interfaces, developer_interfaces, config_for_completion, config_sections_for_completion, aliases_for_completion };
const Format = enum(i32) { none = 0, man, info, web };

var cmd_mode: i32 = 0;
var cmd_mode_opt: []const u8 = "";
var verbose: i32 = 1;
var help_format: i32 = 0;
var exclude_guides: bool = false;
var show_external: i32 = -1;
var show_aliases: i32 = -1;

const help_usage = [_][]const u8{
    "git help [-a|--all] [--[no-]verbose] [--[no-]external-commands] [--[no-]aliases]",
    "git help [[-i|--info] [-m|--man] [-w|--web]] [<command>|<doc>]",
    "git help [-g|--guides]",
    "git help [-c|--config]",
    "git help [--user-interfaces]",
    "git help [--developer-interfaces]",
};

fn optDisplayName(o: *const po.Opt) []const u8 {
    if (o.long.len > 0) return util.concat(&.{ "--", o.long });
    return util.fmt("-{c}", .{o.short});
}

fn cmdModeCb(o: *const po.Opt, _: ?[]const u8, _: bool) void {
    var name = optDisplayName(o);
    // short-only spellings are reported as given; prefer the short form
    // when the option has both (matches the common invocation)
    if (o.short != 0) name = util.fmt("-{c}", .{o.short});
    if (cmd_mode != 0 and cmd_mode != o.val) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ name, cmd_mode_opt });
        po.usageWithOptions(&help_usage, &help_opts);
    }
    cmd_mode = o.val;
    cmd_mode_opt = name;
}

fn extCb(_: ?[]const u8, unset: bool) void {
    show_external = if (unset) 0 else 1;
}
fn aliasesCb(_: ?[]const u8, unset: bool) void {
    show_aliases = if (unset) 0 else 1;
}

fn modeOpt(short: u8, long: []const u8, v: Mode, help: []const u8, hidden: bool) po.Opt {
    return .{ .short = short, .long = long, .kind = .callback, .cbx = cmdModeCb, .noarg = true, .noneg = true, .val = @intFromEnum(v), .help = help, .hidden = hidden };
}

const help_opts = [_]po.Opt{
    modeOpt('a', "all", .all, "print all available commands", false),
    .{ .long = "external-commands", .kind = .callback, .cb = extCb, .noarg = true, .help = "show external commands in --all" },
    .{ .long = "aliases", .kind = .callback, .cb = aliasesCb, .noarg = true, .help = "show aliases in --all" },
    .{ .long = "exclude-guides", .kind = .boolean, .b = &exclude_guides, .help = "exclude guides", .hidden = true },
    po.setInt('m', "man", &help_format, @intFromEnum(Format.man), "show man page"),
    po.setInt('w', "web", &help_format, @intFromEnum(Format.web), "show manual in web browser"),
    po.setInt('i', "info", &help_format, @intFromEnum(Format.info), "show info page"),
    po.verbose(&verbose),
    modeOpt('g', "guides", .guides, "print list of useful guides", false),
    modeOpt(0, "user-interfaces", .user_interfaces, "print list of user-facing repository, command and file interfaces", false),
    modeOpt(0, "developer-interfaces", .developer_interfaces, "print list of file formats, protocols and other developer interfaces", false),
    modeOpt('c', "config", .config, "print all configuration variable names", false),
    modeOpt(0, "config-for-completion", .config_for_completion, "", true),
    modeOpt(0, "config-sections-for-completion", .config_sections_for_completion, "", true),
    modeOpt(0, "aliases-for-completion", .aliases_for_completion, "", true),
};

fn usageMsgOpt(comptime f: []const u8, args: anytype) noreturn {
    util.eprint("fatal: " ++ f ++ "\n\n", args);
    po.usageWithOptions(&help_usage, &help_opts);
}

fn noHelpFormat(opt_mode: []const u8, fmt: i32) void {
    const opt_fmt: []const u8 = switch (@as(Format, @enumFromInt(fmt))) {
        .none => return,
        .man => "--man",
        .info => "--info",
        .web => "--web",
    };
    usageMsgOpt("options '{s}' and '{s}' cannot be used together", .{ opt_mode, opt_fmt });
}

fn optModeUsage(argc: usize, opt_mode: []const u8, fmt: i32) void {
    if (argc > 0) usageMsgOpt("the '{s}' option doesn't take any non-option arguments", .{opt_mode});
    noHelpFormat(opt_mode, fmt);
}

const ConfigShow = enum { human, vars, sections };

fn addSlots(keys: *std.ArrayList([]const u8), prefix: []const u8, slots: []const []const u8) void {
    for (slots) |s| keys.append(gpa, util.concat(&.{ prefix, ".", s })) catch util.oom();
}

fn listConfigHelp(o: *util.Buf, typ: ConfigShow) void {
    const Exp = struct { prefix: []const u8, placeholder: []const u8, slots: []const []const u8 };
    const exps = [_]Exp{
        .{ .prefix = "advice", .placeholder = "*", .slots = &cl.advice_keys },
        .{ .prefix = "color.branch", .placeholder = "<slot>", .slots = &cl.color_branch_slots },
        .{ .prefix = "color.decorate", .placeholder = "<slot>", .slots = &cl.color_decorate_slots },
        .{ .prefix = "color.diff", .placeholder = "<slot>", .slots = &cl.color_diff_slots },
        .{ .prefix = "color.grep", .placeholder = "<slot>", .slots = &cl.color_grep_slots },
        .{ .prefix = "color.interactive", .placeholder = "<slot>", .slots = &cl.color_interactive_slots },
        .{ .prefix = "color.remote", .placeholder = "<slot>", .slots = &cl.sideband_keywords },
        .{ .prefix = "color.status", .placeholder = "<slot>", .slots = &cl.color_status_slots },
        .{ .prefix = "fsck", .placeholder = "<msg-id>", .slots = &cl.fsck_msg_ids },
        .{ .prefix = "receive.fsck", .placeholder = "<msg-id>", .slots = &cl.fsck_msg_ids },
    };
    var keys: std.ArrayList([]const u8) = .empty;
    outer: for (cl.config_name_list) |v| {
        for (exps) |e| {
            if (std.ascii.eqlIgnoreCase(v, util.concat(&.{ e.prefix, ".", e.placeholder }))) {
                addSlots(&keys, e.prefix, e.slots);
                continue :outer;
            }
        }
        keys.append(gpa, v) catch util.oom();
    }
    var uniq: std.ArrayList([]const u8) = .empty;
    for (keys.items) |k| {
        const r = switch (typ) {
            .human => k,
            .vars => cutVar(k),
            .sections => if (std.mem.indexOfScalar(u8, k, '.')) |d| k[0..d] else cutVar(k),
        };
        uniq.append(gpa, r) catch util.oom();
    }
    uniqSorted(&uniq);
    for (uniq.items) |k| {
        util.bufAppend(o, k);
        util.bufByte(o, '\n');
    }
}

fn cutVar(s: []const u8) []const u8 {
    const w = std.mem.indexOfScalar(u8, s, '*');
    const t = std.mem.indexOfScalar(u8, s, '<');
    if (w != null and t != null) return s[0..@min(w.?, t.?)];
    if (w) |x| return s[0..x];
    if (t) |x| return s[0..x];
    return s;
}

fn parseHelpFormat(f: []const u8) i32 {
    if (util.eql(f, "man")) return @intFromEnum(Format.man);
    if (util.eql(f, "info")) return @intFromEnum(Format.info);
    if (util.eql(f, "web") or util.eql(f, "html")) return @intFromEnum(Format.web);
    util.die("unrecognized help format '{s}'", .{f});
}

const Viewer = struct { name: []const u8, info: []const u8 };
var man_viewers: std.ArrayList([]const u8) = .empty;
var viewer_info: std.ArrayList(Viewer) = .empty;
var html_path: ?[]const u8 = null;

fn supportedManViewer(name: []const u8) bool {
    // strncasecmp(known, name, len): name must be a prefix of a known viewer
    for ([_][]const u8{ "man", "woman", "konqueror" }) |k| {
        if (name.len <= k.len and std.ascii.eqlIgnoreCase(k[0..name.len], name)) return true;
    }
    return false;
}

fn readHelpConfig() void {
    for (repo_mod.cfg.entries.items) |e| {
        if (util.eql(e.key, "help.format")) {
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                continue;
            };
            help_format = parseHelpFormat(v);
        } else if (util.eql(e.key, "help.htmlpath")) {
            html_path = e.value orelse {
                _ = config.errorNonbool(e.key);
                continue;
            };
        } else if (util.eql(e.key, "man.viewer")) {
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                continue;
            };
            man_viewers.append(gpa, v) catch util.oom();
        } else if (config.parseConfigKey(e.key, "man")) |pk| {
            const name = pk.sub orelse continue;
            if (!util.eql(pk.key, "path") and !util.eql(pk.key, "cmd")) continue;
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                continue;
            };
            if (util.eql(pk.key, "path")) {
                if (supportedManViewer(name)) {
                    viewer_info.insert(gpa, 0, .{ .name = name, .info = v }) catch util.oom();
                } else util.warn("'{s}': path for unsupported man viewer.\nPlease consider using 'man.<tool>.cmd' instead.", .{name});
            } else {
                if (supportedManViewer(name)) {
                    util.warn("'{s}': cmd for supported man viewer.\nPlease consider using 'man.<tool>.path' instead.", .{name});
                } else viewer_info.insert(gpa, 0, .{ .name = name, .info = v }) catch util.oom();
            }
        }
    }
}

fn getViewerInfo(name: []const u8) ?[]const u8 {
    for (viewer_info.items) |v| if (std.ascii.eqlIgnoreCase(v.name, name)) return v.info;
    return null;
}

/// Locate a program like execvp would; null if not found.
pub fn locateInPath(prog: []const u8) ?[]const u8 {
    if (std.mem.indexOfScalar(u8, prog, '/') != null) return if (os.access(prog, 1)) prog else null;
    const p = os.getenv("PATH") orelse return null;
    var it = std.mem.splitScalar(u8, p, ':');
    while (it.next()) |d0| {
        const d = if (d0.len == 0) "." else d0;
        const full = util.concat(&.{ d, "/", prog });
        if (isExecutable(full)) return full;
    }
    return null;
}

/// "exec" a program: run it and exit with its status; returns if it
/// cannot be started.
fn execProgram(argv: []const []const u8) void {
    if (locateInPath(argv[0]) == null) return;
    util.flushStdout();
    const r = os.run(argv, .{});
    os.exit(@intCast(r.status & 0xff));
}

fn execViewer(name: []const u8, page: []const u8) void {
    const info = getViewerInfo(name);
    if (std.ascii.eqlIgnoreCase(name, "man")) {
        const path = info orelse "man";
        execProgram(&.{ path, page });
        util.warn("failed to exec '{s}': No such file or directory", .{path});
    } else if (std.ascii.eqlIgnoreCase(name, "woman")) {
        const path = info orelse "emacsclient";
        if (locateInPath(path) == null) {
            util.err("Failed to start emacsclient.", .{});
            return;
        }
        execProgram(&.{ path, "-e", util.fmt("(woman \"{s}\")", .{page}) });
    } else if (std.ascii.eqlIgnoreCase(name, "konqueror")) {
        const display = os.getenv("DISPLAY") orelse "";
        if (display.len == 0) return;
        var path: []const u8 = "kfmclient";
        if (info) |p| path = if (util.endsWith(p, "/konqueror")) util.concat(&.{ p[0 .. p.len - "/konqueror".len], "/kfmclient" }) else p;
        execProgram(&.{ path, "newTab", util.fmt("man:{s}(1)", .{page}) });
        util.warn("failed to exec '{s}': No such file or directory", .{path});
    } else if (info) |cmd| {
        util.flushStdout();
        const r = os.run(&.{ "/bin/sh", "-c", util.fmt("{s} {s}", .{ cmd, page }) }, .{});
        os.exit(@intCast(r.status & 0xff));
    } else {
        util.warn("'{s}': unknown man viewer.", .{name});
    }
}

fn showManPage(page: []const u8) noreturn {
    const fallback = os.getenv("GIT_MAN_VIEWER");
    var mp: util.Buf = .empty;
    util.bufAppend(&mp, manPath());
    util.bufByte(&mp, ':');
    if (os.getenv("MANPATH")) |old| util.bufAppend(&mp, old);
    os.setEnv("MANPATH", mp.items);
    for (man_viewers.items) |v| execViewer(v, page);
    if (fallback) |f| execViewer(f, page);
    execViewer("man", page);
    util.die("no man viewer handled the request", .{});
}

pub fn htmlPath() []const u8 {
    return util.concat(&.{ config.systemPrefix(), "/share/doc/git-doc" });
}
pub fn manPath() []const u8 {
    return util.concat(&.{ config.systemPrefix(), "/share/man" });
}
pub fn infoPath() []const u8 {
    return util.concat(&.{ config.systemPrefix(), "/share/info" });
}

fn showInfoPage(page: []const u8) noreturn {
    os.setEnv("INFOPATH", infoPath());
    execProgram(&.{ "info", "gitman", page });
    util.die("no info viewer handled the request", .{});
}

fn showHtmlPage(page: []const u8) noreturn {
    const path = html_path orelse htmlPath();
    if (std.mem.indexOf(u8, path, "://") == null) {
        const f = util.fmt("{s}/{s}.html", .{ path, page });
        const st = os.statPath(f);
        if (st == null or !st.?.isReg()) util.die("'{s}/{s}.html': documentation file not found.", .{ path, page });
    }
    const url = util.fmt("{s}/{s}.html", .{ path, page });
    os.exit(webBrowse(null, "help.browser", &.{url}));
}

fn cmdToPage(git_cmd: []const u8) []const u8 {
    if (util.startsWith(git_cmd, "git")) return git_cmd;
    if (isGitCommand(git_cmd)) return util.concat(&.{ "git-", git_cmd });
    if (util.eql(git_cmd, "scalar")) return git_cmd;
    return util.concat(&.{ "git", git_cmd });
}

fn checkGitCmd(cmd: []const u8) []const u8 {
    if (isGitCommand(cmd)) return cmd;
    if (aliasLookup(cmd)) |alias| {
        if (!exclude_guides or (alias.len > 0 and alias[0] == '!')) {
            util.outf("'{s}' is aliased to '{s}'\n", .{ cmd, alias });
            util.flushStdout();
            os.exit(0);
        }
        util.eprint("'{s}' is aliased to '{s}'\n", .{ cmd, alias });
        const words = @import("commands.zig").splitCmdline(alias) orelse util.die("bad alias.{s} string: unclosed quote", .{cmd});
        return if (words.len > 0) words[0] else "";
    }
    if (exclude_guides) return helpUnknownCmd(cmd);
    return cmd;
}

pub fn cmdHelp(args: []const []const u8) u8 {
    const rest = po.parse(args[1..], &help_opts, &help_usage, .{});
    const parsed_format = help_format;
    if (cmd_mode != @intFromEnum(Mode.all) and (show_external >= 0 or show_aliases >= 0))
        usageMsgOpt("the '--no-[external-commands|aliases]' options can only be used with '--all'", .{});

    var o: util.Buf = .empty;
    switch (@as(Mode, @enumFromInt(cmd_mode))) {
        .all => {
            optModeUsage(rest.len, "--all", help_format);
            if (verbose != 0) {
                @import("commands.zig").setupPager();
                listAllCmdsHelp(&o, show_external != 0, show_aliases != 0);
                util.out(o.items);
                return 0;
            }
            util.bufPrint(&o, "usage: {s}\n\n", .{git_usage_string});
            listCommands(&o, loadCommandList());
            util.bufPrint(&o, "{s}\n", .{git_more_info_string});
            util.out(o.items);
            return 0;
        },
        .guides => {
            optModeUsage(rest.len, "--guides", help_format);
            listCategoryHelp(&o, cl.CAT_guide, "The Git concept guides are:");
            util.bufPrint(&o, "{s}\n", .{git_more_info_string});
            util.out(o.items);
            return 0;
        },
        .config_for_completion => {
            optModeUsage(rest.len, "--config-for-completion", help_format);
            listConfigHelp(&o, .vars);
            util.out(o.items);
            return 0;
        },
        .user_interfaces => {
            optModeUsage(rest.len, "--user-interfaces", help_format);
            listCategoryHelp(&o, cl.CAT_userinterfaces, "User-facing repository, command and file interfaces:");
            util.out(o.items);
            return 0;
        },
        .developer_interfaces => {
            optModeUsage(rest.len, "--developer-interfaces", help_format);
            listCategoryHelp(&o, cl.CAT_developerinterfaces, "File formats, protocols and other developer interfaces:");
            util.out(o.items);
            return 0;
        },
        .config_sections_for_completion => {
            optModeUsage(rest.len, "--config-sections-for-completion", help_format);
            listConfigHelp(&o, .sections);
            util.out(o.items);
            return 0;
        },
        .aliases_for_completion => {
            optModeUsage(rest.len, "--aliases-for-completion", help_format);
            for (listAliases()) |a| {
                util.bufPrint(&o, "{s}\n{s}", .{ a.name, a.value });
                util.bufByte(&o, 0);
            }
            util.out(o.items);
            return 0;
        },
        .config => {
            optModeUsage(rest.len, "--config", help_format);
            @import("commands.zig").setupPager();
            listConfigHelp(&o, .human);
            util.bufAppend(&o, "\n'git help config' for more information\n");
            util.out(o.items);
            return 0;
        },
        .none => {},
    }

    if (rest.len == 0) {
        util.bufPrint(&o, "usage: {s}\n\n", .{git_usage_string});
        listCommonCmdsHelp(&o);
        util.bufPrint(&o, "\n{s}\n", .{git_more_info_string});
        util.out(o.items);
        return 0;
    }

    repo_mod.setup(true);
    readHelpConfig();
    if (parsed_format != 0) help_format = parsed_format;
    if (help_format == 0) help_format = @intFromEnum(Format.man);

    const command = checkGitCmd(rest[0]);
    const page = cmdToPage(command);
    switch (@as(Format, @enumFromInt(help_format))) {
        .none, .man => showManPage(page),
        .info => showInfoPage(page),
        .web => showHtmlPage(page),
    }
}

/// Output for `git` with no command (exit 1) and `git help` (exit 0).
pub fn printMainUsage() void {
    var o: util.Buf = .empty;
    util.bufPrint(&o, "usage: {s}\n\n", .{git_usage_string});
    listCommonCmdsHelp(&o);
    util.bufPrint(&o, "\n{s}\n", .{git_more_info_string});
    util.out(o.items);
}

// ---------------------------------------------------------------------------
// git web--browse (port of git-web--browse.sh)

const known_browsers = [_][]const u8{
    "firefox",  "iceweasel", "seamonkey", "iceape", "chrome", "google-chrome", "chromium", "chromium-browser",
    "konqueror", "opera",    "w3m",       "elinks", "links",  "lynx",          "dillo",    "open",
    "start",    "cygstart",  "xdg-open",
};

fn isKnownBrowser(b: []const u8) bool {
    for (known_browsers) |k| if (util.eql(k, b)) return true;
    return false;
}

fn cfgNonEmpty(key: []const u8) ?[]const u8 {
    const v = repo_mod.cfg.get(key) orelse return null;
    return if (v.len == 0) null else v;
}

fn browserPath(b: []const u8) []const u8 {
    if (cfgNonEmpty(util.concat(&.{ "browser.", b, ".path" }))) |p| return p;
    if (util.eql(b, "chromium") and locateInPath("chromium-browser") != null) return "chromium-browser";
    return b;
}

fn webBrowse(browser0: ?[]const u8, conf: ?[]const u8, urls: []const []const u8) u8 {
    var browser = browser0;
    if (browser == null) {
        var opt: []const u8 = "";
        for ([_]?[]const u8{ conf, "web.browser" }) |o| {
            const k = o orelse continue;
            if (k.len == 0) continue;
            opt = k;
            browser = cfgNonEmpty(k);
            if (browser != null) break;
        }
        if (browser) |b| {
            if (!isKnownBrowser(b) and cfgNonEmpty(util.concat(&.{ "browser.", b, ".cmd" })) == null) {
                util.eprint("git config option {s} set to unknown browser: {s}\nResetting to default...\n", .{ opt, b });
                browser = null;
            }
        }
    }
    var custom_cmd: ?[]const u8 = null;
    var path: []const u8 = "";
    if (browser == null) {
        const display = (os.getenv("DISPLAY") orelse "").len > 0;
        var cands: std.ArrayList([]const u8) = .empty;
        if (isExecutable("/usr/bin/cygstart")) cands.append(gpa, "cygstart") catch util.oom();
        if (isExecutable("/bin/start")) cands.append(gpa, "start") catch util.oom();
        if (os.getenv("SECURITYSESSIONID") != null or os.getenv("TERM_PROGRAM") != null) cands.append(gpa, "open") catch util.oom();
        if (display) {
            if (util.eql(os.getenv("KDE_FULL_SESSION") orelse "", "true")) cands.append(gpa, "konqueror") catch util.oom();
            for ([_][]const u8{ "firefox", "iceweasel", "google-chrome", "chrome", "chromium", "chromium-browser", "konqueror", "opera", "seamonkey", "iceape", "w3m", "elinks", "links", "lynx", "dillo", "xdg-open" }) |x| cands.append(gpa, x) catch util.oom();
        } else {
            for ([_][]const u8{ "w3m", "elinks", "links", "lynx" }) |x| cands.append(gpa, x) catch util.oom();
        }
        for (cands.items) |cnd| {
            const p = browserPath(cnd);
            if (locateInPath(p) != null) {
                browser = cnd;
                path = p;
                break;
            }
        }
        if (browser == null) util.die("No known browser available.", .{});
    } else {
        const b = browser.?;
        custom_cmd = cfgNonEmpty(util.concat(&.{ "browser.", b, ".cmd" }));
        if (!isKnownBrowser(b) and custom_cmd == null) util.die("Unknown browser '{s}'.", .{b});
        path = browserPath(b);
        if (custom_cmd == null and locateInPath(path) == null) util.die("The browser {s} is not available as '{s}'.", .{ b, path });
    }
    const b = browser.?;
    var argv: std.ArrayList([]const u8) = .empty;
    if (isKnownBrowser(b)) {
        argv.append(gpa, path) catch util.oom();
        if (util.eql(b, "konqueror") and util.eql(util.basename(path), "kfmclient")) argv.append(gpa, "newTab") catch util.oom();
        if (util.eql(b, "start")) argv.append(gpa, "\"web-browse\"") catch util.oom();
        argv.appendSlice(gpa, urls) catch util.oom();
        _ = os.run(argv.items, .{});
        return 0;
    }
    if (custom_cmd) |c| {
        argv.append(gpa, "/bin/sh") catch util.oom();
        argv.append(gpa, "-c") catch util.oom();
        argv.append(gpa, util.concat(&.{ c, " \"$@\"" })) catch util.oom();
        argv.append(gpa, c) catch util.oom();
        argv.appendSlice(gpa, urls) catch util.oom();
        const r = os.run(argv.items, .{});
        return @intCast(r.status & 0xff);
    }
    return 0;
}

pub fn cmdWebBrowse(args: []const []const u8) u8 {
    const usage = "usage: git web--browse [--browser=browser|--tool=browser] [--config=conf.var] url/file ...";
    var browser: ?[]const u8 = null;
    var conf: ?[]const u8 = null;
    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (util.eql(a, "-b") or util.startsWith(a, "--browser") or util.eql(a, "-t") or util.startsWith(a, "--tool")) {
            if (std.mem.indexOfScalar(u8, a, '=')) |eq| {
                browser = a[eq + 1 ..];
            } else {
                if (i + 1 >= args.len) util.usageDie("{s}", .{usage});
                i += 1;
                browser = args[i];
            }
        } else if (util.eql(a, "-c") or util.startsWith(a, "--config")) {
            if (std.mem.indexOfScalar(u8, a, '=')) |eq| {
                conf = a[eq + 1 ..];
            } else {
                if (i + 1 >= args.len) util.usageDie("{s}", .{usage});
                i += 1;
                conf = args[i];
            }
        } else if (util.eql(a, "--")) {
            i += 1;
            break;
        } else if (a.len > 0 and a[0] == '-') {
            util.usageDie("{s}", .{usage});
        } else break;
    }
    if (i >= args.len) util.usageDie("{s}", .{usage});
    return webBrowse(browser, conf, args[i..]);
}
