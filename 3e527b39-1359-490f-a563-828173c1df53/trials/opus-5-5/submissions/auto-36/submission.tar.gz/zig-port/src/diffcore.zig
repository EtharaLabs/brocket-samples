//! diffcore: rename/copy detection, break, pickaxe, order, rotate
//! (port of diffcore-delta.c, diffcore-rename.c, diffcore-break.c,
//! diffcore-pickaxe.c, diffcore-order.c, diffcore-rotate.c)
const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const regex = @import("regex.zig");
const odb_mod = @import("odb.zig");
const wildmatch = @import("wildmatch.zig");
const xdiff = @import("xdiff.zig");
const diff = @import("diff.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Filespec = diff.Filespec;
const FilePair = diff.FilePair;
const Queue = diff.Queue;
const MAX_SCORE = diff.MAX_SCORE;

fn sIsReg(mode: u32) bool {
    return mode & 0o170000 == 0o100000;
}

// ---------------------------------------------------------------------------
// diffcore-delta.c

const HASHBASE: u32 = 107927;

const Span = struct { hashval: u32, cnt: u32 };
const SpanData = struct { spans: []Span };

fn hashChars(s: *Filespec) []Span {
    const buf = s.data orelse "";
    const is_text = !diff.isBinary(s);
    var map = std.AutoHashMap(u32, u32).init(gpa);
    var n: u32 = 0;
    var accum1: u32 = 0;
    var accum2: u32 = 0;
    var i: usize = 0;
    while (i < buf.len) {
        const c: u32 = buf[i];
        const old_1 = accum1;
        i += 1;
        if (is_text and c == '\r' and i < buf.len and buf[i] == '\n') continue;
        accum1 = (accum1 << 7) ^ (accum2 >> 25);
        accum2 = (accum2 << 7) ^ (old_1 >> 25);
        accum1 +%= c;
        n += 1;
        if (n < 64 and c != '\n') continue;
        const hv = (accum1 +% accum2 *% 0x61) % HASHBASE;
        const gop = map.getOrPut(hv) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = 0;
        gop.value_ptr.* += n;
        n = 0;
        accum1 = 0;
        accum2 = 0;
    }
    if (n > 0) {
        const hv = (accum1 +% accum2 *% 0x61) % HASHBASE;
        const gop = map.getOrPut(hv) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = 0;
        gop.value_ptr.* += n;
    }
    const spans = gpa.alloc(Span, map.count()) catch util.oom();
    var it = map.iterator();
    var k: usize = 0;
    while (it.next()) |e| : (k += 1) spans[k] = .{ .hashval = e.key_ptr.*, .cnt = e.value_ptr.* };
    std.mem.sort(Span, spans, {}, struct {
        fn lt(_: void, a: Span, b: Span) bool {
            return a.hashval < b.hashval;
        }
    }.lt);
    return spans;
}

fn spansOf(s: *Filespec) []Span {
    if (s.cnt_data) |p| {
        const sd: *SpanData = @ptrCast(@alignCast(p));
        return sd.spans;
    }
    const sd = gpa.create(SpanData) catch util.oom();
    sd.* = .{ .spans = hashChars(s) };
    s.cnt_data = sd;
    return sd.spans;
}

pub const Changes = struct { src_copied: u64, literal_added: u64 };

/// diffcore_count_changes(): both filespecs must be populated
pub fn countChanges(one: *Filespec, two: *Filespec) Changes {
    const src = spansOf(one);
    const dst = spansOf(two);
    var sc: u64 = 0;
    var la: u64 = 0;
    var d: usize = 0;
    for (src) |s| {
        while (d < dst.len and dst[d].hashval < s.hashval) : (d += 1) la += dst[d].cnt;
        var dst_cnt: u64 = 0;
        if (d < dst.len and dst[d].hashval == s.hashval) {
            dst_cnt = dst[d].cnt;
            d += 1;
        }
        const src_cnt: u64 = s.cnt;
        if (src_cnt < dst_cnt) {
            la += dst_cnt - src_cnt;
            sc += src_cnt;
        } else sc += dst_cnt;
    }
    while (d < dst.len) : (d += 1) la += dst[d].cnt;
    return .{ .src_copied = sc, .literal_added = la };
}

// ---------------------------------------------------------------------------
// diffcore-break.c

fn shouldBreak(src: *Filespec, dst: *Filespec, break_score: u32, merge_score_p: *u32) bool {
    merge_score_p.* = 0;
    if (sIsReg(src.mode) != sIsReg(dst.mode)) {
        merge_score_p.* = MAX_SCORE;
        return true;
    }
    if (src.oid_valid and dst.oid_valid and hash.eql(src.oid, dst.oid)) return false;
    if (diff.populateFilespec(src, false) != 0 or diff.populateFilespec(dst, false) != 0) return false;
    const max_size: u64 = @max(src.size, dst.size);
    if (max_size < diff.MINIMUM_BREAK_SIZE) return false;
    if (src.size == 0) return false;
    const r = countChanges(src, dst);
    var src_copied = r.src_copied;
    var literal_added = r.literal_added;
    if (src.size < src_copied) src_copied = src.size;
    if (dst.size < literal_added + src_copied) {
        literal_added = if (src_copied < dst.size) dst.size - src_copied else 0;
    }
    const src_removed: u64 = src.size - src_copied;
    merge_score_p.* = @intCast(src_removed * MAX_SCORE / src.size);
    if (merge_score_p.* > break_score) return true;
    const delta_size = src_removed + literal_added;
    if (delta_size * MAX_SCORE / max_size < break_score) return false;
    if ((src.size * break_score < src_removed * MAX_SCORE) and
        (literal_added * 20 < src_removed) and (literal_added * 20 < src_copied)) return false;
    return true;
}

fn isBlobMode(mode: u32) bool {
    const t = mode & 0o170000;
    return t == 0o100000 or t == 0o120000;
}

/// diffcore_break()
pub fn breakPairs(o: *diff.DiffOptions, score_opt: i32) void {
    _ = o;
    const bits: u32 = @bitCast(score_opt);
    var merge_score: u32 = (bits >> 16) & 0xFFFF;
    var break_score: u32 = bits & 0xFFFF;
    if (break_score == 0) break_score = diff.DEFAULT_BREAK_SCORE;
    if (merge_score == 0) merge_score = diff.DEFAULT_MERGE_SCORE;
    var outq: Queue = .empty;
    for (diff.queue.items) |p| {
        if (diff.fileValid(p.one) and diff.fileValid(p.two) and isBlobMode(p.one.mode) and
            isBlobMode(p.two.mode) and util.eql(p.one.path, p.two.path))
        {
            var score: u32 = 0;
            if (shouldBreak(p.one, p.two, break_score, &score)) {
                if (p.one.size < diff.MINIMUM_BREAK_SIZE or p.two.size < diff.MINIMUM_BREAK_SIZE or score < merge_score)
                    score = 0;
                const null_one = diff.allocEmptyFilespec(p.one.path);
                const dp = diff.queuePairTo(&outq, p.one, null_one);
                dp.score = score;
                dp.broken_pair = true;
                const null_two = diff.allocEmptyFilespec(p.two.path);
                const cp = diff.queuePairTo(&outq, null_two, p.two);
                cp.score = score;
                cp.broken_pair = true;
                continue;
            }
        }
        outq.append(gpa, p) catch util.oom();
    }
    diff.queue = outq;
}

/// diffcore_merge_broken()
pub fn mergeBroken() void {
    const q = diff.queue.items;
    var outq: Queue = .empty;
    var merged = gpa.alloc(bool, q.len) catch util.oom();
    @memset(merged, false);
    outer: for (q, 0..) |p, i| {
        if (merged[i]) continue;
        if (p.broken_pair and util.eql(p.one.path, p.two.path)) {
            var j = i + 1;
            while (j < q.len) : (j += 1) {
                if (merged[j]) continue;
                const pp = q[j];
                if (pp.broken_pair and util.eql(pp.one.path, pp.two.path) and util.eql(p.one.path, pp.two.path)) {
                    var c = p;
                    var d = pp;
                    if (diff.fileValid(p.one)) {
                        d = p;
                        c = pp;
                    }
                    if (!diff.fileValid(d.one)) util.die("internal error in merge #1", .{});
                    if (diff.fileValid(d.two)) util.die("internal error in merge #2", .{});
                    if (diff.fileValid(c.one)) util.die("internal error in merge #3", .{});
                    if (!diff.fileValid(c.two)) util.die("internal error in merge #4", .{});
                    const dp = diff.queuePairTo(&outq, d.one, c.two);
                    dp.score = p.score;
                    d.one.rename_used += 1;
                    merged[j] = true;
                    continue :outer;
                }
            }
            outq.append(gpa, p) catch util.oom();
        } else outq.append(gpa, p) catch util.oom();
    }
    diff.queue = outq;
}

// ---------------------------------------------------------------------------
// diffcore-rename.c

const RenameDst = struct { p: *FilePair, is_rename: bool = false };
const RenameSrc = struct { p: *FilePair, score: u32 };

var rename_dst: std.ArrayList(RenameDst) = .empty;
var rename_src: std.ArrayList(RenameSrc) = .empty;
var break_idx: ?std.StringHashMap(usize) = null;

fn basenameSame(src: *const Filespec, dst: *const Filespec) bool {
    var sl = src.path.len;
    var dl = dst.path.len;
    while (sl > 0 and dl > 0) {
        sl -= 1;
        dl -= 1;
        const c1 = src.path[sl];
        const c2 = dst.path[dl];
        if (c1 != c2) return false;
        if (c1 == '/') return true;
    }
    return (sl == 0 or src.path[sl - 1] == '/') and (dl == 0 or dst.path[dl - 1] == '/');
}

fn getBasename(p: []const u8) []const u8 {
    return if (std.mem.lastIndexOfScalar(u8, p, '/')) |k| p[k + 1 ..] else p;
}

fn recordRenamePair(dst_index: usize, src_index: usize, score: u32) void {
    const src = rename_src.items[src_index].p;
    const dst = rename_dst.items[dst_index].p;
    if (rename_dst.items[dst_index].is_rename) util.die("BUG: dst already renamed!", .{});
    src.one.rename_used += 1;
    src.one.count += 1;
    rename_dst.items[dst_index].is_rename = true;
    dst.one = src.one;
    dst.renamed_pair = true;
    dst.score = if (util.eql(dst.one.path, dst.two.path)) rename_src.items[src_index].score else score;
}

fn registerRenameSrc(p: *FilePair) void {
    if (p.broken_pair) {
        if (break_idx == null) break_idx = std.StringHashMap(usize).init(gpa);
        break_idx.?.put(p.one.path, rename_dst.items.len) catch util.oom();
    }
    rename_src.append(gpa, .{ .p = p, .score = p.score }) catch util.oom();
}

fn addRenameDst(p: *FilePair) bool {
    const n = rename_dst.items.len;
    if (n > 0 and util.eql(rename_dst.items[n - 1].p.two.path, p.two.path)) return false;
    rename_dst.append(gpa, .{ .p = p }) catch util.oom();
    return true;
}

fn locateRenameDst(p: *FilePair) ?*RenameDst {
    const bi = break_idx orelse return null;
    const idx = bi.get(p.one.path) orelse return null;
    if (idx >= rename_dst.items.len) return null;
    return &rename_dst.items[idx];
}

/// hash_filespec(): make sure the oid is known
fn hashFilespec(s: *Filespec) Oid {
    if (!s.oid_valid) {
        if (diff.populateFilespec(s, false) != 0) return s.oid;
        s.oid = odb_mod.hashObject(.blob, s.data orelse "");
    }
    return s.oid;
}

fn findExactRenames(o: *diff.DiffOptions) usize {
    var table = hash.OidMap(std.ArrayList(usize)).empty;
    for (rename_src.items, 0..) |rs, i| {
        const oid = hashFilespec(rs.p.one);
        const gop = table.getOrPut(gpa, oid) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = .empty;
        gop.value_ptr.append(gpa, i) catch util.oom();
    }
    var renames: usize = 0;
    for (rename_dst.items, 0..) |rd, di| {
        const target = rd.p.two;
        const oid = hashFilespec(target);
        const list = table.get(oid) orelse continue;
        var best: ?usize = null;
        var best_score: i32 = -1;
        var budget: usize = 100;
        for (list.items) |si| {
            const source = rename_src.items[si].p.one;
            if (!sIsReg(source.mode) or !sIsReg(target.mode)) {
                if (source.mode != target.mode) continue;
            }
            var score: i32 = if (source.rename_used == 0) 1 else 0;
            if (source.rename_used != 0 and o.detect_rename != diff.DETECT_COPY) continue;
            if (basenameSame(source, target)) score += 1;
            if (score > best_score) {
                best = si;
                best_score = score;
                if (score == 2) break;
            }
            budget -= 1;
            if (budget == 0) break;
        }
        if (best) |b| {
            recordRenamePair(di, b, MAX_SCORE);
            renames += 1;
        }
    }
    return renames;
}

fn removeUnneededPathsFromSrc(detecting_copies: bool) void {
    if (detecting_copies) return;
    if (break_idx != null) return;
    var n: usize = 0;
    for (rename_src.items) |rs| {
        if (rs.p.one.rename_used != 0) continue;
        rename_src.items[n] = rs;
        n += 1;
    }
    rename_src.shrinkRetainingCapacity(n);
}

fn estimateSimilarity(src: *Filespec, dst: *Filespec, minimum_score: u32) u32 {
    if (!sIsReg(src.mode) or !sIsReg(dst.mode)) return 0;
    if (src.cnt_data == null and diff.populateFilespec(src, true) != 0) return 0;
    if (dst.cnt_data == null and diff.populateFilespec(dst, true) != 0) return 0;
    const max_size: u64 = @max(src.size, dst.size);
    const base_size: u64 = @min(src.size, dst.size);
    const delta_size = max_size - base_size;
    if (max_size * (MAX_SCORE - minimum_score) < delta_size * MAX_SCORE) return 0;
    if (src.cnt_data == null and diff.populateFilespec(src, false) != 0) return 0;
    if (dst.cnt_data == null and diff.populateFilespec(dst, false) != 0) return 0;
    const r = countChanges(src, dst);
    if (dst.size == 0) return 0;
    return @intCast(r.src_copied * MAX_SCORE / max_size);
}

fn findBasenameMatches(minimum_score: u32) usize {
    var sources = std.StringHashMap(i64).init(gpa);
    var dests = std.StringHashMap(i64).init(gpa);
    for (rename_src.items, 0..) |rs, i| {
        const base = getBasename(rs.p.one.path);
        const gop = sources.getOrPut(base) catch util.oom();
        gop.value_ptr.* = if (gop.found_existing) -1 else @intCast(i);
    }
    for (rename_dst.items, 0..) |rd, i| {
        if (rd.is_rename) continue;
        const base = getBasename(rd.p.two.path);
        const gop = dests.getOrPut(base) catch util.oom();
        gop.value_ptr.* = if (gop.found_existing) -1 else @intCast(i);
    }
    var renames: usize = 0;
    for (rename_src.items, 0..) |rs, i| {
        const base = getBasename(rs.p.one.path);
        const src_index = sources.get(base) orelse -1;
        const dst_index = dests.get(base) orelse continue;
        // without dir-rename info, idx_possible_rename() gives -1
        if (src_index == -1 or dst_index == -1) continue;
        const di: usize = @intCast(dst_index);
        if (rename_dst.items[di].is_rename) continue;
        const one = rs.p.one;
        const two = rename_dst.items[di].p.two;
        const score = estimateSimilarity(one, two, minimum_score);
        if (score < minimum_score) continue;
        recordRenamePair(di, i, score);
        renames += 1;
    }
    return renames;
}

/// returns 0 = ok, 1 = give up, 2 = only modified sources (-C -C degraded)
fn tooManyRenameCandidates(num_destinations: usize, num_sources: usize, o: *diff.DiffOptions) u8 {
    const rename_limit = o.rename_limit;
    o.needed_rename_limit = 0;
    if (rename_limit <= 0) return 0;
    const lim: u64 = @intCast(rename_limit);
    if (@as(u64, num_destinations) * num_sources <= lim * lim) return 0;
    o.needed_rename_limit = @intCast(@max(num_sources, num_destinations));
    if (!o.flags.find_copies_harder) return 1;
    var limited: u64 = 0;
    for (rename_src.items[0..num_sources]) |rs| {
        if (diff.unmodifiedPair(rs.p)) continue;
        limited += 1;
    }
    if (@as(u64, num_destinations) * limited <= lim * lim) return 2;
    return 1;
}

const NUM_CANDIDATE_PER_DST = 4;
const DiffScore = struct { src: i32 = -1, dst: i32 = -1, score: i32 = 0, name_score: i32 = 0 };

fn scoreCompare(a: DiffScore, b: DiffScore) i32 {
    if (a.dst < 0) return if (0 <= b.dst) 1 else 0;
    if (b.dst < 0) return -1;
    if (a.score == b.score) return b.name_score - a.name_score;
    return b.score - a.score;
}

fn recordIfBetter(m: []DiffScore, o: DiffScore) void {
    var worst: usize = 0;
    var i: usize = 1;
    while (i < NUM_CANDIDATE_PER_DST) : (i += 1) {
        if (scoreCompare(m[i], m[worst]) > 0) worst = i;
    }
    if (scoreCompare(m[worst], o) > 0) m[worst] = o;
}

fn findRenames(mx: []const DiffScore, minimum_score: u32, copies: bool) usize {
    var count: usize = 0;
    for (mx) |m| {
        if (m.dst < 0 or m.score < @as(i32, @intCast(minimum_score))) break;
        const dst = &rename_dst.items[@intCast(m.dst)];
        if (dst.is_rename) continue;
        if (!copies and rename_src.items[@intCast(m.src)].p.one.rename_used != 0) continue;
        recordRenamePair(@intCast(m.dst), @intCast(m.src), @intCast(m.score));
        count += 1;
    }
    return count;
}

/// diffcore_rename()
pub fn rename(o: *diff.DiffOptions) void {
    const want_copies = o.detect_rename == diff.DETECT_COPY;
    var minimum_score = o.rename_score;
    if (minimum_score == 0) minimum_score = diff.DEFAULT_RENAME_SCORE;
    rename_dst = .empty;
    rename_src = .empty;
    break_idx = null;
    const q = diff.queue.items;
    const empty_blob = hash.fromHex(hash.empty_blob_hex).?;

    setup: {
        for (q) |p| {
            if (!diff.fileValid(p.one)) {
                if (!diff.fileValid(p.two)) continue;
                if (o.single_follow) |sf| {
                    if (!util.eql(sf, p.two.path)) continue;
                }
                if (!o.flags.rename_empty and hash.eql(p.two.oid, empty_blob)) continue;
                if (!addRenameDst(p)) {
                    util.warn("skipping rename detection, detected duplicate destination '{s}'", .{p.two.path});
                    break :setup;
                }
            } else if (!o.flags.rename_empty and hash.eql(p.one.oid, empty_blob)) {
                continue;
            } else if (!p.is_unmerged and !diff.fileValid(p.two)) {
                if (p.broken_pair and p.score == 0) p.one.rename_used += 1;
                registerRenameSrc(p);
            } else if (want_copies) {
                p.one.rename_used += 1;
                registerRenameSrc(p);
            }
        }
        if (rename_dst.items.len == 0 or rename_src.items.len == 0) break :setup;

        var rename_count = findExactRenames(o);
        if (minimum_score == MAX_SCORE) break :setup;

        if (want_copies or break_idx != null) {
            removeUnneededPathsFromSrc(want_copies);
        } else {
            var factor: f64 = 0.5;
            if (os.getenv("GIT_BASENAME_FACTOR")) |bf| {
                const v = std.fmt.parseInt(i64, bf, 10) catch 0;
                factor = @as(f64, @floatFromInt(v)) / 100.0;
            }
            const min_basename_score: u32 = minimum_score +
                @as(u32, @intFromFloat(factor * @as(f64, @floatFromInt(MAX_SCORE - minimum_score))));
            removeUnneededPathsFromSrc(want_copies);
            rename_count += findBasenameMatches(min_basename_score);
            removeUnneededPathsFromSrc(want_copies);
        }

        const num_destinations = rename_dst.items.len - rename_count;
        const num_sources = rename_src.items.len;
        if (num_destinations == 0 or num_sources == 0) break :setup;

        var skip_unmodified = false;
        switch (tooManyRenameCandidates(num_destinations, num_sources, o)) {
            1 => break :setup,
            2 => {
                o.degraded_cc_to_c = true;
                skip_unmodified = true;
            },
            else => {},
        }

        const mx = gpa.alloc(DiffScore, NUM_CANDIDATE_PER_DST * num_destinations) catch util.oom();
        var dst_cnt: usize = 0;
        for (rename_dst.items, 0..) |rd, i| {
            if (rd.is_rename) continue;
            const two = rd.p.two;
            const m = mx[dst_cnt * NUM_CANDIDATE_PER_DST ..][0..NUM_CANDIDATE_PER_DST];
            for (m) |*e| e.* = .{};
            for (rename_src.items, 0..) |rs, j| {
                if (skip_unmodified and diff.unmodifiedPair(rs.p)) continue;
                const one = rs.p.one;
                const this_src = DiffScore{
                    .score = @intCast(estimateSimilarity(one, two, minimum_score)),
                    .name_score = if (basenameSame(one, two)) 1 else 0,
                    .dst = @intCast(i),
                    .src = @intCast(j),
                };
                recordIfBetter(m, this_src);
            }
            dst_cnt += 1;
        }
        const used = mx[0 .. dst_cnt * NUM_CANDIDATE_PER_DST];
        std.mem.sort(DiffScore, used, {}, struct {
            fn lt(_: void, a: DiffScore, b: DiffScore) bool {
                return scoreCompare(a, b) < 0;
            }
        }.lt);
        rename_count += findRenames(used, minimum_score, false);
        if (want_copies) rename_count += findRenames(used, minimum_score, true);
    }

    // write back to queue
    var outq: Queue = .empty;
    for (q) |p| {
        var keep = true;
        if (p.is_unmerged) {
            keep = true;
        } else if (!diff.fileValid(p.one) and diff.fileValid(p.two)) {
            keep = true;
        } else if (diff.fileValid(p.one) and !diff.fileValid(p.two)) {
            if (diff.pairBroken(p)) {
                var dst = locateRenameDst(p);
                if (o.single_follow != null and dst != null and !util.eql(dst.?.p.two.path, p.two.path)) dst = null;
                if (dst) |d| {
                    if (d.is_rename) keep = false;
                }
            } else if (p.one.rename_used != 0) keep = false;
        } else if (diff.unmodifiedPair(p)) {
            keep = false;
        }
        if (keep) outq.append(gpa, p) catch util.oom();
    }
    diff.queue = outq;
    rename_dst = .empty;
    rename_src = .empty;
    break_idx = null;
}

// ---------------------------------------------------------------------------
// diffcore-pickaxe.c

const Matcher = union(enum) {
    re: regex.Regex,
    kw: struct { needle: []const u8, icase: bool },
};

fn kwFind(hay: []const u8, needle: []const u8, icase: bool) ?usize {
    if (!icase) return std.mem.indexOf(u8, hay, needle);
    if (needle.len > hay.len) return null;
    var i: usize = 0;
    while (i + needle.len <= hay.len) : (i += 1) {
        if (std.ascii.eqlIgnoreCase(hay[i .. i + needle.len], needle)) return i;
    }
    return null;
}

fn contains(data0: []const u8, m: *const Matcher, limit: u32) u32 {
    var cnt: u32 = 0;
    var data = data0;
    switch (m.*) {
        .re => |re| {
            var notbol = false;
            while (data.len > 0) {
                const mt = re.find(data, notbol) orelse break;
                notbol = true;
                const so: usize = @intCast(mt.so);
                const eo: usize = @intCast(mt.eo);
                data = data[eo..];
                if (data.len > 0 and so == eo) data = data[1..];
                cnt += 1;
                if (limit != 0 and cnt == limit) return cnt;
            }
        },
        .kw => |kw| {
            if (kw.needle.len == 0) return 0;
            while (data.len > 0) {
                const off = kwFind(data, kw.needle, kw.icase) orelse break;
                data = data[off + kw.needle.len ..];
                cnt += 1;
                if (limit != 0 and cnt == limit) return cnt;
            }
        },
    }
    return cnt;
}

const GrepCtx = struct { re: regex.Regex, hit: bool = false };

fn grepLine(c: *anyopaque, line: []const u8) void {
    const g: *GrepCtx = @ptrCast(@alignCast(c));
    if (g.hit) return;
    if (line.len == 0 or (line[0] != '+' and line[0] != '-')) return;
    if (g.re.find(line[1..], false) != null) g.hit = true;
}

fn diffGrep(a: []const u8, b: []const u8, o: *diff.DiffOptions, re: regex.Regex) bool {
    var g = GrepCtx{ .re = re };
    _ = diff.xdiDiffOutf(a, b, .{}, .{ .context = @intCast(@max(o.context, 0)), .interhunk = @intCast(@max(o.interhunkcontext, 0)) }, &g, grepLine);
    return g.hit;
}

const PickKind = enum { grep, has_changes, objfind };

fn pickaxeMatch(p: *FilePair, o: *diff.DiffOptions, m: ?*const Matcher, kind: PickKind) bool {
    if (!diff.fileValid(p.one) and !diff.fileValid(p.two)) return false;
    if (kind == .objfind) {
        const set = o.objfind orelse return false;
        return (diff.fileValid(p.one) and set.contains(p.one.oid)) or
            (diff.fileValid(p.two) and set.contains(p.two.oid));
    }
    var tc1: ?*@import("userdiff.zig").Driver = null;
    var tc2: ?*@import("userdiff.zig").Driver = null;
    if (o.flags.allow_textconv) {
        tc1 = diff.getTextconv(p.one);
        tc2 = diff.getTextconv(p.two);
    }
    if (tc1 == tc2 and diff.unmodifiedPair(p)) return false;
    if (o.pickaxe_opts & diff.PICKAXE_KIND_G != 0 and !o.flags.text and
        ((tc1 == null and diff.fileValid(p.one) and diff.isBinary(p.one)) or
            (tc2 == null and diff.fileValid(p.two) and diff.isBinary(p.two)))) return false;
    const a = if (diff.fileValid(p.one)) diff.fillTextconv(tc1, p.one) else "";
    const b = if (diff.fileValid(p.two)) diff.fillTextconv(tc2, p.two) else "";
    switch (kind) {
        .grep => return diffGrep(a, b, o, m.?.re),
        .has_changes => {
            const c1 = if (diff.fileValid(p.one)) contains(a, m.?, 0) else 0;
            const c2 = if (diff.fileValid(p.two)) contains(b, m.?, c1 + 1) else 0;
            return c1 != c2;
        },
        .objfind => unreachable,
    }
}

fn hasNonAscii(s: []const u8) bool {
    for (s) |c| if (c >= 0x80) return true;
    return false;
}

fn basicRegexQuote(s: []const u8) []const u8 {
    var b: util.Buf = .empty;
    for (s) |c| {
        if (std.mem.indexOfScalar(u8, "\\[]*.^$", c) != null) util.bufByte(&b, '\\');
        util.bufByte(&b, c);
    }
    return b.items;
}

fn compileOrDie(pat: []const u8, opts: regex.Opts) regex.Regex {
    return switch (regex.Regex.compile(pat, opts)) {
        .ok => |r| r,
        .err => |e| util.die("invalid regex: {s}", .{e}),
    };
}

/// diffcore_pickaxe()
pub fn pickaxe(o: *diff.DiffOptions) void {
    const opts = o.pickaxe_opts;
    const needle = o.pickaxe orelse "";
    const icase = opts & diff.PICKAXE_IGNORE_CASE != 0;
    var matcher: Matcher = undefined;
    var kind: PickKind = undefined;
    if (opts & (diff.PICKAXE_REGEX | diff.PICKAXE_KIND_G) != 0) {
        matcher = .{ .re = compileOrDie(needle, .{ .extended = true, .newline = true, .icase = icase }) };
        kind = if (opts & diff.PICKAXE_KIND_G != 0) .grep else .has_changes;
    } else if (opts & diff.PICKAXE_KIND_S != 0) {
        if (icase and hasNonAscii(needle)) {
            matcher = .{ .re = compileOrDie(basicRegexQuote(needle), .{ .newline = true, .icase = true }) };
        } else {
            matcher = .{ .kw = .{ .needle = needle, .icase = icase } };
        }
        kind = .has_changes;
    } else {
        kind = .objfind;
    }
    const mp: ?*const Matcher = if (kind == .objfind) null else &matcher;
    const q = diff.queue.items;
    if (opts & diff.PICKAXE_ALL != 0) {
        for (q) |p| {
            if (pickaxeMatch(p, o, mp, kind)) return;
        }
        diff.queue = .empty;
    } else {
        var outq: Queue = .empty;
        for (q) |p| {
            if (pickaxeMatch(p, o, mp, kind)) outq.append(gpa, p) catch util.oom();
        }
        diff.queue = outq;
    }
}

// ---------------------------------------------------------------------------
// diffcore-order.c

var order_patterns: ?[][]const u8 = null;

fn prepareOrder(orderfile: []const u8) [][]const u8 {
    if (order_patterns) |op| return op;
    const data = os.readFile(orderfile) orelse util.dieErrno("failed to read orderfile '{s}'", .{orderfile});
    var list: std.ArrayList([]const u8) = .empty;
    var cp: usize = 0;
    while (cp < data.len) {
        var ep = cp;
        while (ep < data.len and data[ep] != '\n') ep += 1;
        if (!(data[cp] == '\n' or data[cp] == '#')) list.append(gpa, data[cp..ep]) catch util.oom();
        if (ep < data.len) ep += 1;
        cp = ep;
    }
    order_patterns = list.items;
    return list.items;
}

fn matchOrder(pats: []const []const u8, path: []const u8) usize {
    for (pats, 0..) |pat, i| {
        var p = path;
        while (p.len > 0) {
            if (wildmatch.match(pat, p, 0)) return i;
            const k = std.mem.lastIndexOfScalar(u8, p, '/') orelse break;
            p = p[0..k];
        }
    }
    return pats.len;
}

const OrderItem = struct { idx: usize, order: usize };

fn orderIndices(of: []const u8, n: usize, ctx: anytype, comptime pathOf: fn (@TypeOf(ctx), usize) []const u8) []OrderItem {
    const pats = prepareOrder(of);
    const items = gpa.alloc(OrderItem, n) catch util.oom();
    for (items, 0..) |*it, i| it.* = .{ .idx = i, .order = matchOrder(pats, pathOf(ctx, i)) };
    std.mem.sort(OrderItem, items, {}, struct {
        fn lt(_: void, a: OrderItem, b: OrderItem) bool {
            if (a.order != b.order) return a.order < b.order;
            return a.idx < b.idx;
        }
    }.lt);
    return items;
}

fn pairPath(q: []*FilePair, i: usize) []const u8 {
    return q[i].two.path;
}

/// diffcore_order()
pub fn order(of: []const u8) void {
    const q = diff.queue.items;
    if (q.len == 0) return;
    const items = orderIndices(of, q.len, q, pairPath);
    var outq: Queue = .empty;
    for (items) |it| outq.append(gpa, q[it.idx]) catch util.oom();
    diff.queue = outq;
}

fn combPath(paths: []*diff.treediff.CombinePath, i: usize) []const u8 {
    return paths[i].path;
}

/// order_objects() for combined paths
pub fn orderPaths(of: []const u8, paths: []*diff.treediff.CombinePath) []*diff.treediff.CombinePath {
    if (paths.len == 0) return paths;
    const items = orderIndices(of, paths.len, paths, combPath);
    const out = gpa.alloc(*diff.treediff.CombinePath, paths.len) catch util.oom();
    for (items, 0..) |it, i| out[i] = paths[it.idx];
    return out;
}

// ---------------------------------------------------------------------------
// diffcore-rotate.c

/// diffcore_rotate()
pub fn rotate(o: *diff.DiffOptions) void {
    const q = diff.queue.items;
    if (q.len == 0) return;
    const target = o.rotate_to.?;
    var i: usize = 0;
    while (i < q.len) : (i += 1) {
        const cmp = std.mem.order(u8, target, q[i].two.path);
        if (cmp != .gt) break;
    }
    if (i >= q.len) {
        if (o.rotate_to_strict) util.die("No such path '{s}' in the diff", .{target});
        return;
    }
    var outq: Queue = .empty;
    outq.appendSlice(gpa, q[i..]) catch util.oom();
    if (!o.skip_instead_of_rotate) outq.appendSlice(gpa, q[0..i]) catch util.oom();
    diff.queue = outq;
}
