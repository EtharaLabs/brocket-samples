//! git remote-ext / git remote-fd (builtin/remote-ext.c, builtin/remote-fd.c)
//! plus the bidirectional transfer loop from transport-helper.c.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const pkt = @import("../pktline.zig");
const gpa = util.gpa;

const PollFd = extern struct { fd: c_int, events: c_short, revents: c_short };
extern "c" fn poll(fds: [*]PollFd, n: c_ulong, timeout: c_int) c_int;
extern "c" fn read(fd: c_int, buf: [*]u8, n: usize) isize;
extern "c" fn write(fd: c_int, buf: [*]const u8, n: usize) isize;
extern "c" fn shutdown(fd: c_int, how: c_int) c_int;
extern "c" fn close(fd: c_int) c_int;

/// bidirectional_transfer_loop(input, output): copy stdin -> output and
/// input -> stdout until both directions have seen EOF.
pub fn bidirectionalTransferLoop(input: c_int, output: c_int) i32 {
    proc.ignoreSigpipe();
    // direction 0: fd 0 -> output; direction 1: input -> fd 1
    var src = [2]c_int{ 0, input };
    var dst = [2]c_int{ output, 1 };
    var done = [2]bool{ false, false };
    var buf: [65536]u8 = undefined;
    while (!done[0] or !done[1]) {
        var fds: [2]PollFd = undefined;
        var map: [2]usize = undefined;
        var n: usize = 0;
        for (0..2) |d| {
            if (done[d]) continue;
            fds[n] = .{ .fd = src[d], .events = 1, .revents = 0 };
            map[n] = d;
            n += 1;
        }
        const r = poll(&fds, n, -1);
        if (r < 0) {
            if (os.errno() == 4) continue;
            util.err("poll failed: {s}", .{os.lastErr()});
            return -1;
        }
        for (0..n) |k| {
            if (fds[k].revents == 0) continue;
            const d = map[k];
            const got = read(src[d], &buf, buf.len);
            if (got < 0) {
                const e = os.errno();
                if (e == 4 or e == 11) continue;
                util.err("read(2) failed: {s}", .{os.lastErr()});
                return -1;
            }
            if (got == 0) {
                done[d] = true;
                // the destination shares its fd with the other source (remote-fd)
                if (dst[d] == src[1 - d]) {
                    _ = shutdown(dst[d], 1);
                } else {
                    _ = close(dst[d]);
                }
                continue;
            }
            os.writeAll(dst[d], buf[0..@intCast(got)]) catch {
                util.err("write(2) failed: {s}", .{os.lastErr()});
                return -1;
            };
        }
    }
    _ = &src;
    _ = &dst;
    return 0;
}

/// fgets()-like line read from fd 0, one byte at a time so nothing past
/// the newline is consumed.
fn readLine() ?[]const u8 {
    var b: util.Buf = .empty;
    var ch: [1]u8 = undefined;
    while (b.items.len < 4094) {
        const r = read(0, &ch, 1);
        if (r < 0) {
            if (os.errno() == 4) continue;
            return if (b.items.len > 0) b.items else null;
        }
        if (r == 0) return if (b.items.len > 0) b.items else null;
        util.bufByte(&b, ch[0]);
        if (ch[0] == '\n') break;
    }
    var s: []const u8 = b.items;
    while (s.len > 0 and std.ascii.isWhitespace(s[s.len - 1])) s = s[0 .. s.len - 1];
    return s;
}

// ---------------- remote-ext ----------------

var git_req: ?[]const u8 = null;
var git_req_vhost: ?[]const u8 = null;

fn stripEscapes(str: []const u8, service: []const u8, next: *[]const u8) ?[]const u8 {
    const noprefix = util.skipPrefix(service, "git-") orelse service;
    os.setEnv("GIT_EXT_SERVICE", service);
    os.setEnv("GIT_EXT_SERVICE_NOPREFIX", noprefix);
    var rpos: usize = 0;
    var escape = false;
    var special: u8 = 0;
    while (rpos < str.len and (escape or str[rpos] != ' ')) : (rpos += 1) {
        if (escape) {
            switch (str[rpos]) {
                ' ', '%', 's', 'S' => {},
                'G', 'V' => {
                    special = str[rpos];
                    if (rpos != 1) util.die("Bad remote-ext placeholder '%{c}'.", .{str[rpos]});
                },
                else => util.die("Bad remote-ext placeholder '%{c}'.", .{str[rpos]}),
            }
            escape = false;
        } else escape = str[rpos] == '%';
    }
    if (escape and rpos >= str.len) util.die("remote-ext command has incomplete placeholder", .{});
    next.* = str[rpos..];
    if (next.len > 0 and next.*[0] == ' ') next.* = next.*[1..];

    var ret: util.Buf = .empty;
    rpos = if (special != 0) 2 else 0;
    escape = false;
    while (rpos < str.len and (escape or str[rpos] != ' ')) : (rpos += 1) {
        if (escape) {
            switch (str[rpos]) {
                ' ', '%' => util.bufByte(&ret, str[rpos]),
                's' => util.bufAppend(&ret, noprefix),
                'S' => util.bufAppend(&ret, service),
                else => {},
            }
            escape = false;
        } else if (str[rpos] == '%') {
            escape = true;
        } else util.bufByte(&ret, str[rpos]);
    }
    switch (special) {
        'G' => {
            git_req = ret.items;
            return null;
        },
        'V' => {
            git_req_vhost = ret.items;
            return null;
        },
        else => return ret.items,
    }
}

fn runChild(arg_in: []const u8, service: []const u8) u8 {
    var args: std.ArrayList([]const u8) = .empty;
    var arg = arg_in;
    while (arg.len > 0) {
        if (stripEscapes(arg, service, &arg)) |e| args.append(gpa, e) catch util.oom();
    }
    if (args.items.len == 0) util.die("Can't run specified command", .{});
    if (std.mem.indexOfScalar(u8, args.items[0], '/') == null) {
        const path = os.getenv("PATH") orelse "/usr/local/bin:/usr/bin:/bin";
        var found = false;
        var it = std.mem.splitScalar(u8, path, ':');
        while (it.next()) |d| {
            const p = util.concat(&.{ if (d.len == 0) "." else d, "/", args.items[0] });
            if (os.access(p, 1) and !os.isDir(p)) {
                found = true;
                break;
            }
        }
        if (!found) {
            util.err("cannot run {s}: No such file or directory", .{args.items[0]});
            util.die("Can't run specified command", .{});
        }
    }
    const ch = proc.spawn(args.items, .{ .pipe_in = true, .pipe_out = true });
    if (git_req) |req| {
        if (git_req_vhost) |vh| {
            pkt.writeFmt(ch.in, "{s} {s}\x00host={s}\x00", .{ service, req, vh });
        } else pkt.writeFmt(ch.in, "{s} {s}\x00", .{ service, req });
    }
    const r = bidirectionalTransferLoop(ch.out, ch.in);
    const st = proc.wait(ch.pid);
    if (r != 0) return 255;
    return st;
}

const ext_usage = "git remote-ext <remote> <url>";

pub fn cmdRemoteExt(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.stdout.print("usage: {s}\n", .{ext_usage});
        util.flushStdout();
        os.exit(0);
    }
    if (args.len != 3) util.usageDie("usage: {s}", .{ext_usage});
    const child = args[2];
    while (true) {
        const line = readLine() orelse os.exit(0);
        if (util.eql(line, "capabilities")) {
            os.writeAll(1, "*connect\n\n") catch {};
        } else if (util.skipPrefix(line, "connect ")) |svc| {
            os.writeAll(1, "\n") catch {};
            return runChild(child, svc);
        } else {
            util.eprint("Bad command", .{});
            return 1;
        }
    }
}

// ---------------- remote-fd ----------------

const fd_usage = "git remote-fd <remote> <url>";

fn strtoul(s: []const u8, end: *usize) c_int {
    var i: usize = 0;
    var v: u64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) v = v *% 10 +% (s[i] - '0');
    end.* = i;
    return @truncate(@as(i64, @bitCast(v)));
}

pub fn cmdRemoteFd(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.stdout.print("usage: {s}\n", .{fd_usage});
        util.flushStdout();
        os.exit(0);
    }
    if (args.len != 3) util.usageDie("usage: {s}", .{fd_usage});
    const a = args[2];
    var end: usize = 0;
    const input_fd = strtoul(a, &end);
    if (end == 0 or (end < a.len and a[end] != ',' and a[end] != '/')) util.die("Bad URL syntax", .{});
    var output_fd = input_fd;
    if (end < a.len and a[end] == ',') {
        const rest = a[end + 1 ..];
        var e2: usize = 0;
        output_fd = strtoul(rest, &e2);
        if (e2 == 0 or (e2 < rest.len and rest[e2] != '/')) util.die("Bad URL syntax", .{});
    }
    while (true) {
        const line = readLine() orelse return 0;
        if (util.eql(line, "capabilities")) {
            os.writeAll(1, "*connect\n\n") catch {};
        } else if (util.startsWith(line, "connect ")) {
            os.writeAll(1, "\n") catch {};
            if (bidirectionalTransferLoop(input_fd, output_fd) != 0)
                util.die("Copying data between file descriptors failed", .{});
            return 0;
        } else util.die("Bad command: {s}", .{line});
    }
}
