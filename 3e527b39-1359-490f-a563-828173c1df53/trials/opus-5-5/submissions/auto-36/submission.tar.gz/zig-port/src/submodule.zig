//! Worktree-updater side of submodule.c: submodule.recurse /
//! --recurse-submodules handling, submodule_from_ce() and
//! submodule_move_head(), used by unpack-trees and entry.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const config = @import("config.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const h = @import("cmd/submodule.zig");

pub const Submodule = h.Submodule;

pub const MOVE_HEAD_DRY_RUN: u32 = 1 << 0;
pub const MOVE_HEAD_FORCE: u32 = 1 << 1;

/// config_update_recurse_submodules == RECURSE_SUBMODULES_ON
pub var recurse: bool = false;

/// Process-wide super prefix (read-tree --super-prefix), used when
/// recursing into nested submodules.
pub var super_prefix: ?[]const u8 = null;

pub fn shouldUpdate() bool {
    return recurse;
}

/// git_default_submodule_config(): submodule.recurse
pub fn loadRecurseConfig() void {
    if (repo_mod.cfg.getEntry("submodule.recurse")) |e| {
        recurse = config.configBool(e.key, e.value);
    }
}

/// parse_update_recurse_submodules_arg()
pub fn parseUpdateRecurseArg(opt: []const u8, arg: []const u8) bool {
    return switch (config.parseMaybeBool(arg)) {
        1 => true,
        0 => false,
        else => util.die("bad {s} argument: {s}", .{ opt, arg }),
    };
}

/// option_parse_recurse_submodules_worktree_updater()
pub fn optWorktreeUpdater(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        recurse = false;
        return;
    }
    if (arg) |a| {
        recurse = parseUpdateRecurseArg("recurse-submodules", a);
    } else recurse = true;
}

fn isGitlink(mode: u32) bool {
    return mode & 0o170000 == 0o160000;
}

/// submodule_from_ce()
pub fn fromCe(e: *const index_mod.Entry) ?*Submodule {
    if (!isGitlink(e.mode)) return null;
    if (!shouldUpdate()) return null;
    return h.submoduleFromPath(e.path);
}

/// Drop cached .gitmodules information (repo_read_gitmodules() reload).
pub fn reloadGitmodules() void {
    h.resetCache();
}

/// is_submodule_populated_gently(); with `gentle` false, a broken gitfile dies.
pub fn isPopulatedGently(path: []const u8, gentle: bool) bool {
    const gd = util.concat(&.{ path, "/.git" });
    if (repo_mod.isGitDirectory(gd)) return true;
    if (gentle) {
        var e: repo_mod.GitfileErr = .none;
        return repo_mod.readGitfileGently(gd, &e) != null;
    }
    return repo_mod.readGitfileGently(gd, null) != null;
}

/// submodule_uses_gitfile()
fn usesGitfile(path: []const u8) bool {
    h.validatePathOrExit(path);
    const dotgit = util.concat(&.{ path, "/.git" });
    if (repo_mod.readGitfile(dotgit) == null) return false;
    const r = h.git(&.{ "submodule", "foreach", "--quiet", "--recursive", "test -f .git" }, .{
        .cwd = path,
        .no_stdin = true,
        .no_stderr = true,
        .capture = true,
    });
    return h.ok(r);
}

/// submodule_has_dirty_index()
fn hasDirtyIndex(sub: *const Submodule) bool {
    const p = sub.path orelse "";
    h.validatePathOrExit(p);
    const r = h.git(&.{ "diff-index", "--quiet", "--cached", "HEAD" }, .{ .cwd = p, .no_stdin = true, .capture = true });
    return !h.ok(r);
}

fn superPrefixArg(path: []const u8) []const u8 {
    return util.concat(&.{ "--super-prefix=", super_prefix orelse "", path, "/" });
}

/// submodule_reset_index()
fn resetIndex(path: []const u8) void {
    h.validatePathOrExit(path);
    const r = h.git(&.{ "read-tree", "-u", "--reset", superPrefixArg(path), hash.empty_tree_hex }, .{ .cwd = path, .no_stdin = true });
    if (!h.ok(r)) util.die("could not reset submodule index", .{});
}

/// submodule_unset_core_worktree()
fn unsetCoreWorktree(sub: *const Submodule) void {
    const p = sub.path orelse "";
    h.validatePathOrExit(p);
    const cfg = util.concat(&.{ h.nameToGitdir(sub.name), "/config" });
    if (h.setConfigInFile(cfg, "core.worktree", null) < 0)
        util.warn("Could not unset core.worktree setting in submodule '{s}'", .{p});
}

/// submodule_move_head(): move the submodule at `path` from old_head to
/// new_head (null for appearing/disappearing submodules).
pub fn moveHead(path: []const u8, old_head: ?[]const u8, new_head: ?[]const u8, flags: u32) i32 {
    if (!h.isSubmoduleActive(path)) return 0;
    const force = flags & MOVE_HEAD_FORCE != 0;
    const dry = flags & MOVE_HEAD_DRY_RUN != 0;
    if (old_head != null and !isPopulatedGently(path, force)) return 0;
    const sub = h.submoduleFromPath(path) orelse util.die("BUG: could not get submodule information for '{s}'", .{path});

    if (old_head != null and !force) {
        if (hasDirtyIndex(sub)) {
            util.err("submodule '{s}' has dirty index", .{path});
            return -1;
        }
    }

    if (!dry) {
        if (old_head != null) {
            if (!usesGitfile(path)) {
                h.absorbGitDir(path, super_prefix);
            } else {
                const gd = repo_mod.readGitfile(util.concat(&.{ path, "/.git" })) orelse "";
                if (!h.validateGitdir(gd, sub.name))
                    util.die("refusing to create/use '{s}' in another submodule's git dir. Enabling extensions.submodulePathConfig should fix this.", .{gd});
            }
        } else {
            const gd = h.nameToGitdir(sub.name);
            h.connectWorkTreeAndGitDir(path, gd);
            resetIndex(path);
        }
        if (old_head != null and force) {
            h.connectWorkTreeAndGitDir(path, h.nameToGitdir(sub.name));
        }
    }

    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(util.gpa, &.{ "read-tree", "--recurse-submodules", superPrefixArg(path) }) catch util.oom();
    argv.append(util.gpa, if (dry) "-n" else "-u") catch util.oom();
    argv.append(util.gpa, if (force) "--reset" else "-m") catch util.oom();
    if (!force) argv.append(util.gpa, old_head orelse hash.empty_tree_hex) catch util.oom();
    argv.append(util.gpa, new_head orelse hash.empty_tree_hex) catch util.oom();
    if (!h.ok(h.git(argv.items, .{ .cwd = path, .no_stdin = true }))) {
        util.err("Submodule '{s}' could not be updated.", .{path});
        return -1;
    }

    if (!dry) {
        if (new_head) |nh| {
            if (!h.ok(h.git(&.{ "update-ref", "HEAD", "--no-deref", nh }, .{ .cwd = path, .no_stdin = true }))) return -1;
        } else {
            const dotgit = util.concat(&.{ path, "/.git" });
            if (!os.unlink(dotgit)) {
                const e = os.errno();
                if (e != os.ENOENT) util.warn("unable to unlink '{s}': {s}", .{ dotgit, os.strErr(e) });
            }
            if (h.isEmptyDir(path)) {
                if (!os.rmdir(path)) {
                    const e = os.errno();
                    if (e != os.ENOENT) util.warn("unable to rmdir '{s}': {s}", .{ path, os.strErr(e) });
                }
            }
            unsetCoreWorktree(sub);
        }
    }
    return 0;
}
