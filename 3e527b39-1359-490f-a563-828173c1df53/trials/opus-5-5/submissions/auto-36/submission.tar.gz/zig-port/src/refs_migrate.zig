//! repo_migrate_ref_storage_format() (refs.c): convert the main ref store
//! between the "files" and "reftable" formats.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const rt = @import("reftable.zig");
const rtb = @import("reftable_backend.zig");
const config = @import("config.zig");
const Oid = hash.Oid;

extern "c" fn mkdtemp(template: [*:0]u8) ?[*:0]u8;

const Item = struct { name: []const u8, oid: Oid, symref: ?[]const u8 };
const Log = struct { name: []const u8, e: refs.ReflogEntry };

pub const MigrateFlags = struct { dry_run: bool = false, skip_reflog: bool = false };

/// Returns null on success, or the error message (printed by the caller as
/// "error: %s").
pub fn migrate(format: []const u8, flags: MigrateFlags) ?[]const u8 {
    const r = repo_mod.repo();
    if (util.eql(r.ref_storage, format)) return "current and new ref storage format are equal";
    if (hasWorktrees()) return "migrating repositories with worktrees is not supported yet";

    // collect everything from the old store first
    var items: std.ArrayList(Item) = .empty;
    for (refs.listRootRefs()) |x| collect(&items, x);
    for (refs.iterate("refs/", .{ .include_broken = true, .check_objects = false })) |x| collect(&items, x);
    var logs: std.ArrayList(Log) = .empty;
    if (!flags.skip_reflog) {
        const names = refs.listReflogs();
        util.sortStrings(names);
        for (names) |n| {
            for (refs.readReflog(n)) |e| util.append(Log, &logs, .{ .name = n, .e = e });
        }
    }

    const gitdir = r.git_dir;
    const tmpl = util.concat(&.{ gitdir, "/ref_migration.XXXXXX\x00" });
    const tmpz: [*:0]u8 = @ptrCast(@constCast(tmpl.ptr));
    if (mkdtemp(tmpz) == null) return util.fmt("cannot create migration directory: {s}", .{os.lastErr()});
    const tmp = tmpl[0 .. tmpl.len - 1];

    const ok = if (util.eql(format, "reftable")) writeReftable(tmp, items.items, logs.items) else writeFiles(tmp, items.items, logs.items);
    if (ok) |msg| return msg;

    if (flags.dry_run) {
        util.outf("Finished dry-run migration of refs, the result can be found at '{s}'\n", .{tmp});
        return null;
    }

    // destructive part
    const removed = if (refs.isReftable()) rtb.removeOnDisk(gitdir) else removeFilesOnDisk(gitdir);
    if (!removed) return migratedAt(tmp, "could not remove old ref storage");
    if (moveFiles(tmp, gitdir)) |msg| return migratedAt(tmp, msg);
    if (!os.rmdir(tmp)) util.warn("could not remove temporary migration directory '{s}': {s}", .{ tmp, os.lastErr() });

    setVersion(format);
    r.ref_storage = util.dupe(format);
    rtb.reset();
    refs.invalidatePacked();
    return null;
}

fn migratedAt(tmp: []const u8, msg: []const u8) []const u8 {
    return util.fmt("{s}\nmigrated refs can be found at '{s}'", .{ msg, tmp });
}

fn hasWorktrees() bool {
    const ents = os.listDir(util.concat(&.{ repo_mod.repo().common_dir, "/worktrees" })) orelse return false;
    for (ents) |e| {
        if (!util.eql(e.name, ".") and !util.eql(e.name, "..")) return true;
    }
    return false;
}

fn collect(items: *std.ArrayList(Item), x: refs.Ref) void {
    if (x.flags & refs.REF_ISSYMREF != 0) {
        const t = x.symref orelse refs.readSymbolic(x.name) orelse return;
        util.append(Item, items, .{ .name = x.name, .oid = hash.zero, .symref = t });
        return;
    }
    if (hash.isZero(x.oid)) return;
    util.append(Item, items, .{ .name = x.name, .oid = x.oid, .symref = null });
}

fn writeReftable(tmp: []const u8, items: []const Item, logs: []const Log) ?[]const u8 {
    rtb.createOnDisk(tmp);
    var recs: std.ArrayList(rt.RefRecord) = .empty;
    for (items) |it| {
        const val: rt.RefValue = if (it.symref) |t|
            .{ .symref = t }
        else if (refs.peeledOf(it.oid)) |p|
            .{ .val2 = .{ .oid = it.oid, .peeled = p } }
        else
            .{ .val1 = it.oid };
        util.append(rt.RefRecord, &recs, .{ .name = it.name, .update_index = 1, .value = val });
    }
    var lrecs: std.ArrayList(rt.LogRecord) = .empty;
    for (logs, 0..) |l, i| {
        var u = rtb.logFromIdent(l.e.ident);
        u.old = l.e.old;
        u.new = l.e.new;
        u.message = refs.normalizeReflogMsg(l.e.msg);
        util.append(rt.LogRecord, &lrecs, .{ .name = l.name, .update_index = 1 + @as(u64, @intCast(i)), .value = .{ .update = u } });
    }
    const max: u64 = if (logs.len > 0) logs.len else 1;
    rtb.writeRecordsAt(util.concat(&.{ tmp, "/reftable" }), 1, max, recs.items, lrecs.items) catch |e|
        return migratedAt(tmp, rt.errStr(e));
    return null;
}

fn writeFiles(tmp: []const u8, items: []const Item, logs: []const Log) ?[]const u8 {
    // files_ref_store_create_on_disk()
    _ = os.mkdir(util.concat(&.{ tmp, "/refs" }), 0o777);
    _ = os.mkdir(util.concat(&.{ tmp, "/refs/heads" }), 0o777);
    _ = os.mkdir(util.concat(&.{ tmp, "/refs/tags" }), 0o777);
    var packed_list: std.ArrayList(refs.PackedRef) = .empty;
    for (items) |it| {
        if (it.symref != null or refs.isRootRef(it.name)) {
            const path = util.concat(&.{ tmp, "/", it.name });
            _ = os.mkdirLeading(path);
            const data = if (it.symref) |t| util.concat(&.{ "ref: ", t, "\n" }) else util.concat(&.{ &hash.hex(it.oid), "\n" });
            os.writeFile(path, data, 0o666) catch return util.fmt("unable to write '{s}': {s}", .{ path, os.lastErr() });
            continue;
        }
        util.append(refs.PackedRef, &packed_list, .{ .name = it.name, .oid = it.oid, .peeled = refs.peeledOf(it.oid) });
    }
    std.mem.sort(refs.PackedRef, packed_list.items, {}, struct {
        fn lt(_: void, a: refs.PackedRef, b: refs.PackedRef) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    const ppath = util.concat(&.{ tmp, "/packed-refs" });
    os.writeFile(ppath, refs.formatPacked(packed_list.items), 0o666) catch
        return util.fmt("unable to write '{s}': {s}", .{ ppath, os.lastErr() });
    var i: usize = 0;
    while (i < logs.len) {
        var j = i;
        var entries: std.ArrayList(refs.ReflogEntry) = .empty;
        while (j < logs.len and util.eql(logs[j].name, logs[i].name)) : (j += 1) {
            var e = logs[j].e;
            e.msg = refs.normalizeReflogMsg(e.msg);
            util.append(refs.ReflogEntry, &entries, e);
        }
        const lp = util.concat(&.{ tmp, "/logs/", logs[i].name });
        _ = os.mkdirLeading(lp);
        os.writeFile(lp, refs.formatReflog(entries.items), 0o666) catch
            return util.fmt("unable to write '{s}': {s}", .{ lp, os.lastErr() });
        i = j;
    }
    return null;
}

/// files_ref_store_remove_on_disk()
fn removeFilesOnDisk(gitdir: []const u8) bool {
    var ok = true;
    const rd = util.concat(&.{ gitdir, "/refs" });
    os.removeTree(rd);
    if (os.exists(rd)) {
        util.err("could not delete refs: {s}", .{os.lastErr()});
        ok = false;
    }
    const ld = util.concat(&.{ gitdir, "/logs" });
    os.removeTree(ld);
    if (os.exists(ld)) {
        util.err("could not delete logs: {s}", .{os.lastErr()});
        ok = false;
    }
    if (os.listDir(gitdir)) |ents| {
        for (ents) |e| {
            if (!refs.isRootRef(e.name)) continue;
            const p = util.concat(&.{ gitdir, "/", e.name });
            if (os.isDir(p)) continue;
            if (!os.unlink(p)) {
                util.err("could not delete root ref '{s}': {s}", .{ e.name, os.lastErr() });
                ok = false;
            }
        }
    }
    const pp = util.concat(&.{ gitdir, "/packed-refs" });
    if (os.exists(pp) and !os.unlink(pp)) {
        util.err("could not delete packed-refs: {s}", .{os.lastErr()});
        ok = false;
    }
    return ok;
}

fn moveFiles(from: []const u8, to: []const u8) ?[]const u8 {
    const ents = os.listDir(from) orelse return util.fmt("could not open source directory '{s}': {s}", .{ from, os.lastErr() });
    for (ents) |e| {
        if (util.eql(e.name, ".") or util.eql(e.name, "..")) continue;
        const a = util.concat(&.{ from, "/", e.name });
        const b = util.concat(&.{ to, "/", e.name });
        if (!os.rename(a, b)) return util.fmt("could not link file '{s}' to '{s}': {s}", .{ a, b, os.lastErr() });
    }
    return null;
}

/// initialize_repository_version(repo, hash, format, reinit=1)
fn setVersion(format: []const u8) void {
    const r = repo_mod.repo();
    const cfg_path = util.concat(&.{ r.common_dir, "/config" });
    const is_reftable = util.eql(format, "reftable");
    if (is_reftable) {
        _ = config.setInFile(cfg_path, "extensions.refstorage", format, .{}, false, false, null);
    } else {
        _ = config.setInFileGently(cfg_path, "extensions.refstorage", null, null);
    }
    var version: []const u8 = if (is_reftable) "1" else "0";
    var local: config.Config = .{};
    _ = config.readFileInto(&local, cfg_path, .local);
    for (local.entries.items) |e| {
        const ext = util.skipPrefix(e.key, "extensions.") orelse continue;
        if (std.ascii.eqlIgnoreCase(ext, "noop") or std.ascii.eqlIgnoreCase(ext, "partialclone") or
            std.ascii.eqlIgnoreCase(ext, "preciousobjects") or std.ascii.eqlIgnoreCase(ext, "worktreeconfig")) continue;
        version = "1";
    }
    if (repo_mod.cfg.getBool("init.defaultsubmodulepathconfig") orelse false) {
        version = "1";
        _ = config.setInFile(cfg_path, "extensions.submodulepathconfig", "true", .{}, false, false, null);
    }
    _ = config.setInFile(cfg_path, "core.repositoryformatversion", version, .{}, false, false, null);
}
