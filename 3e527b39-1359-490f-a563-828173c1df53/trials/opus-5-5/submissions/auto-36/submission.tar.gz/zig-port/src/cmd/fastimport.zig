//! git fast-import (port of builtin/fast-import.c).
//!
//! Objects are written loose as they are imported; when more objects than
//! fastimport.unpackLimit were imported into one "pack", they are bundled into
//! a real packfile at checkpoint/end time (git writes a pack and loosens small
//! ones, so the resulting repository state is equivalent).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const odb_mod = @import("../odb.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const date = @import("../date.zig");
const index_mod = @import("../index.zig");
const pack = @import("../pack.zig");
const lockfile = @import("../lockfile.zig");
const commitnode = @import("../commitnode.zig");
const commitreach = @import("../commitreach.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

const S_IFMT: u32 = 0o170000;
const S_IFDIR: u32 = 0o040000;
const S_IFREG: u32 = 0o100000;
const S_IFLNK: u32 = 0o120000;
const S_IFGITLINK: u32 = 0o160000;
const NO_DELTA: u32 = 0o4000;
const MAX_PACK_ID: u32 = 0xffff;
const MAX_DEPTH: u64 = (1 << 13) - 1;

fn isDirMode(m: u32) bool {
    return m & S_IFMT == S_IFDIR;
}
fn isGitlink(m: u32) bool {
    return m & S_IFMT == S_IFGITLINK;
}

// ------------------------------------------------------------------ state

const ObjEntry = struct {
    oid: Oid,
    typ: ObjType = .none,
    pack_id: u32 = MAX_PACK_ID,
    offset: u64 = 0,
};

const Version = struct { mode: u32 = 0, oid: Oid = hash.zero };

const TEntry = struct {
    tree: ?*TContent = null,
    name: []const u8 = "",
    versions: [2]Version = .{ .{}, .{} },
};

const TContent = struct {
    entries: std.ArrayList(*TEntry) = .empty,
};

const Branch = struct {
    table_next: ?*Branch = null,
    active_next: ?*Branch = null,
    name: []const u8,
    branch_tree: TEntry = .{ .versions = .{ .{ .mode = S_IFDIR }, .{ .mode = S_IFDIR } } },
    last_commit: u64 = 0,
    num_notes: u64 = 0,
    active: bool = false,
    delete: bool = false,
    pack_id: u32 = MAX_PACK_ID,
    oid: Oid = hash.zero,
};

const Tag = struct {
    next: ?*Tag = null,
    name: []const u8,
    pack_id: u32 = MAX_PACK_ID,
    oid: Oid = hash.zero,
};

const SignMode = enum { abort, verbatim, warn_verbatim, warn_strip, strip, abort_if_invalid, strip_if_invalid, sign_if_invalid };
const WhenSpec = enum { raw, raw_permissive, rfc2822, now };

var max_depth: u64 = 50;
var unpack_limit: i64 = 100;
var force_update = false;
var show_stats = true;
var quiet_flag = false;
var failure = false;
var signed_tag_mode: SignMode = .verbatim;
var signed_commit_mode: SignMode = .verbatim;

var object_table: hash.OidMap(*ObjEntry) = .empty;
var marks: std.AutoHashMapUnmanaged(u64, *ObjEntry) = .empty;
var max_mark_seen: u64 = 0;
var marks_set_count: u64 = 0;
var object_count_by_type: [8]u64 = @splat(0);
var duplicate_count_by_type: [8]u64 = @splat(0);
var object_count: u64 = 0;
var alloc_count: u64 = 0;
var branch_count: u64 = 0;
var branch_load_count: u64 = 0;
var atoms: std.StringHashMapUnmanaged(void) = .empty;

var pack_id: u32 = 0;
var pending: std.ArrayList(*ObjEntry) = .empty;
var pack_edges_fd: c_int = -1;

var export_marks_file: ?[]const u8 = null;
var import_marks_file: ?[]const u8 = null;
var import_marks_file_from_stream = false;
var import_marks_file_ignore_missing = false;
var import_marks_file_done = false;
var relative_marks_paths = false;

var max_active_branches: u64 = 5;
var cur_active_branches: u64 = 0;
const branch_table_sz = 1039;
var branch_table: [branch_table_sz]?*Branch = @splat(null);
var active_branches: ?*Branch = null;

var first_tag: ?*Tag = null;
var last_tag: ?*Tag = null;

var whenspec: WhenSpec = .raw;
var command_buf: []const u8 = "";
var unread_command_buf = false;
var next_mark: u64 = 0;
var require_explicit_termination = false;
var cat_blob_fd: c_int = 1;
var seen_data_command = false;
var allow_unsafe_features = false;
var cmd_args: []const []const u8 = &.{};

var cmd_hist: std.ArrayList([]const u8) = .empty;
const cmd_save = 100;

var sub_marks_from: std.ArrayList(SubMarks) = .empty;
var sub_marks_to: std.ArrayList(SubMarks) = .empty;
var sub_oid_map: hash.OidMap(Oid) = .empty;
const SubMarks = struct { name: []const u8, map: std.AutoHashMapUnmanaged(u64, Oid) };

// ------------------------------------------------------------------ input

const Input = struct {
    buf: []u8 = &.{},
    start: usize = 0,
    end: usize = 0,
    eof: bool = false,

    fn fill(self: *Input) bool {
        if (self.start < self.end) return true;
        if (self.eof) return false;
        if (self.buf.len == 0) self.buf = gpa.alloc(u8, 1 << 16) catch util.oom();
        while (true) {
            const n = std.c.read(0, self.buf.ptr, self.buf.len);
            if (n < 0) {
                if (os.errno() == 4) continue;
                self.eof = true;
                return false;
            }
            if (n == 0) {
                self.eof = true;
                return false;
            }
            self.start = 0;
            self.end = @intCast(n);
            return true;
        }
    }

    /// strbuf_getline_lf(): null on EOF with nothing read.
    fn getline(self: *Input) ?[]u8 {
        var out: util.Buf = .empty;
        var got = false;
        while (self.fill()) {
            got = true;
            const slice = self.buf[self.start..self.end];
            if (std.mem.indexOfScalar(u8, slice, '\n')) |i| {
                util.bufAppend(&out, slice[0..i]);
                self.start += i + 1;
                return out.items;
            }
            util.bufAppend(&out, slice);
            self.start = self.end;
        }
        if (!got) return null;
        return out.items;
    }

    fn readInto(self: *Input, out: *util.Buf, n: usize) usize {
        if (!self.fill()) return 0;
        const avail = @min(n, self.end - self.start);
        util.bufAppend(out, self.buf[self.start .. self.start + avail]);
        self.start += avail;
        return avail;
    }

    fn getc(self: *Input) ?u8 {
        if (!self.fill()) return null;
        const ch = self.buf[self.start];
        self.start += 1;
        return ch;
    }
    fn ungetc(self: *Input) void {
        self.start -= 1;
    }
};

var input: Input = .{};

// ------------------------------------------------------------------ objects & marks

fn findObject(oid: Oid) ?*ObjEntry {
    return object_table.get(oid);
}

fn insertObject(oid: Oid) *ObjEntry {
    if (object_table.get(oid)) |e| return e;
    const e = gpa.create(ObjEntry) catch util.oom();
    e.* = .{ .oid = oid };
    alloc_count += 1;
    object_table.put(gpa, oid, e) catch util.oom();
    return e;
}

fn insertMark(idnum: u64, oe: *ObjEntry) void {
    const r = marks.getOrPut(gpa, idnum) catch util.oom();
    if (!r.found_existing) marks_set_count += 1;
    r.value_ptr.* = oe;
    if (idnum > max_mark_seen) max_mark_seen = idnum;
}

fn findMark(idnum: u64) *ObjEntry {
    return marks.get(idnum) orelse util.die("mark :{d} not declared", .{idnum});
}

fn sortedMarks() []u64 {
    var l: std.ArrayList(u64) = .empty;
    var it = marks.keyIterator();
    while (it.next()) |k| l.append(gpa, k.*) catch util.oom();
    std.mem.sort(u64, l.items, {}, std.sort.asc(u64));
    return l.items;
}

fn odb() *odb_mod.Odb {
    return repo_mod.repo().odb();
}

fn typeIdx(t: ObjType) usize {
    return @intFromEnum(t);
}

/// store_object(): returns true if the object was a duplicate.
fn storeObject(typ: ObjType, data: []const u8, oidout: ?*Oid, mark: u64) bool {
    const oid = odb_mod.hashObject(typ, data);
    if (oidout) |o| o.* = oid;
    const e = insertObject(oid);
    if (mark != 0) insertMark(mark, e);
    if (e.offset != 0) {
        duplicate_count_by_type[typeIdx(typ)] += 1;
        return true;
    }
    if (odb().findPacked(oid) != null) {
        e.typ = typ;
        e.pack_id = MAX_PACK_ID;
        e.offset = 1;
        duplicate_count_by_type[typeIdx(typ)] += 1;
        return true;
    }
    e.typ = typ;
    e.pack_id = pack_id;
    object_count += 1;
    e.offset = object_count + 11;
    object_count_by_type[typeIdx(typ)] += 1;
    _ = odb().write(typ, data);
    pending.append(gpa, e) catch util.oom();
    return false;
}

fn readObject(oid: Oid) ?odb_mod.Object {
    return odb().read(oid);
}

fn objectType(oid: Oid) ?ObjType {
    if (findObject(oid)) |e| {
        if (e.typ != .none) return e.typ;
    }
    const o = readObject(oid) orelse return null;
    return o.typ;
}

/// Read an object, peeling tags until an object of type `want` is found.
/// Updates `oid` to the peeled object.
fn readPeeled(oid: *Oid, want: ObjType) ?[]const u8 {
    var depth: u32 = 0;
    while (depth < 100) : (depth += 1) {
        const o = readObject(oid.*) orelse return null;
        if (o.typ == want) return o.data;
        if (o.typ != .tag) return null;
        const d = o.data;
        if (d.len < 47 or !util.startsWith(d, "object ")) return null;
        oid.* = hash.fromHex(d[7..47]) orelse return null;
    }
    return null;
}

// ------------------------------------------------------------------ packing

fn endPackfile() void {
    defer pending.clearRetainingCapacity();
    if (pending.items.len == 0) return;
    if (@as(i64, @intCast(pending.items.len)) <= unpack_limit) {
        // small "packs" stay loose (git loosens them via unpack-objects)
        for (pending.items) |e| e.pack_id = MAX_PACK_ID;
        pack_id += 0;
        return;
    }
    const o = odb();
    const pdir = util.concat(&.{ o.objects_dir, "/pack" });
    _ = os.mkdirAll(pdir);
    const tmp = os.tmpFile(pdir, "tmp_pack_");
    if (tmp.fd < 0) util.dieErrno("unable to create temporary file", .{});
    var w = pack.Writer{ .fd = tmp.fd };
    w.header(@intCast(pending.items.len));
    var idx: std.ArrayList(pack.IdxEntry) = .empty;
    const level = pack.packCompressionLevel();
    for (pending.items) |e| {
        const obj = o.read(e.oid) orelse util.die("can't read object {s}", .{hash.hex(e.oid)});
        const off = w.beginEntry();
        w.write(pack.encodeFullEntry(obj.typ, obj.data, level));
        var ie: pack.IdxEntry = undefined;
        ie.oid = e.oid;
        ie.offset = off;
        ie.crc = w.crc;
        idx.append(gpa, ie) catch util.oom();
    }
    const sum = w.finish();
    os.close(tmp.fd);
    const hx = hash.hex(sum);
    const base = util.concat(&.{ pdir, "/pack-", &hx });
    const pack_path = util.concat(&.{ base, ".pack" });
    const idx_path = util.concat(&.{ base, ".idx" });
    _ = os.chmod(tmp.path, 0o444);
    if (!os.rename(tmp.path, pack_path)) util.die("cannot store pack file", .{});
    const idx_data = pack.buildIdx(idx.items, sum, .{});
    pack.writeNewFile(idx_path, idx_data, 0o444);
    // drop the loose copies now that they live in the pack
    for (pending.items) |e| {
        _ = os.unlink(o.looseObjectPath(o.objects_dir, e.oid));
    }
    o.reloadPacks();
    if (pack_edges_fd >= 0) {
        var b: util.Buf = .empty;
        util.bufPrint(&b, "{s}:", .{pack_path});
        for (branch_table) |head| {
            var bp = head;
            while (bp) |br| : (bp = br.table_next) {
                if (br.pack_id == pack_id) util.bufPrint(&b, " {s}", .{hash.hex(br.oid)});
            }
        }
        var tp = first_tag;
        while (tp) |t| : (tp = t.next) {
            if (t.pack_id == pack_id) util.bufPrint(&b, " {s}", .{hash.hex(t.oid)});
        }
        util.bufByte(&b, '\n');
        os.writeAll(pack_edges_fd, b.items) catch {};
    }
    pack_id += 1;
}

// ------------------------------------------------------------------ trees

fn toAtom(s: []const u8) []const u8 {
    const r = atoms.getOrPut(gpa, s) catch util.oom();
    if (!r.found_existing) r.key_ptr.* = util.dupe(s);
    return r.key_ptr.*;
}

fn newTreeContent() *TContent {
    const t = gpa.create(TContent) catch util.oom();
    t.* = .{};
    return t;
}

fn newTreeEntry() *TEntry {
    const e = gpa.create(TEntry) catch util.oom();
    e.* = .{};
    return e;
}

fn dupTreeContent(s: ?*TContent) ?*TContent {
    const src = s orelse return null;
    const d = newTreeContent();
    for (src.entries.items) |a| {
        const b = newTreeEntry();
        b.* = a.*;
        if (a.tree != null and hash.isZero(b.versions[1].oid)) {
            b.tree = dupTreeContent(a.tree);
        } else b.tree = null;
        d.entries.append(gpa, b) catch util.oom();
    }
    return d;
}

fn loadTree(root: *TEntry) void {
    const oid = root.versions[1].oid;
    const t = newTreeContent();
    root.tree = t;
    if (hash.isZero(oid)) return;
    if (findObject(oid)) |myoe| {
        if (myoe.typ != .none and myoe.typ != .tree) util.die("not a tree: {s}", .{hash.hex(oid)});
    }
    const obj = readObject(oid) orelse util.die("can't load tree {s}", .{hash.hex(oid)});
    if (obj.typ != .tree) util.die("can't load tree {s}", .{hash.hex(oid)});
    const buf = obj.data;
    var c: usize = 0;
    while (c < buf.len) {
        const e = newTreeEntry();
        t.entries.append(gpa, e) catch util.oom();
        var mode: u32 = 0;
        while (true) {
            if (c >= buf.len) util.die("corrupt mode in {s}", .{hash.hex(oid)});
            const ch = buf[c];
            c += 1;
            if (ch == ' ') break;
            if (ch < '0' or ch > '7') util.die("corrupt mode in {s}", .{hash.hex(oid)});
            mode = ((mode << 3) + (ch - '0')) & 0xffff;
        }
        const nul = std.mem.indexOfScalarPos(u8, buf, c, 0) orelse util.die("corrupt mode in {s}", .{hash.hex(oid)});
        e.versions[1].mode = mode;
        e.versions[0].mode = mode;
        e.name = toAtom(buf[c..nul]);
        c = nul + 1;
        if (c + 20 > buf.len) util.die("corrupt mode in {s}", .{hash.hex(oid)});
        e.versions[0].oid = buf[c..][0..20].*;
        e.versions[1].oid = buf[c..][0..20].*;
        c += 20;
    }
}

fn baseNameCompare(n1: []const u8, mode1: u32, n2: []const u8, mode2: u32) std.math.Order {
    const len = @min(n1.len, n2.len);
    const o = std.mem.order(u8, n1[0..len], n2[0..len]);
    if (o != .eq) return o;
    const c1: u8 = if (n1.len > len) n1[len] else if (isDirMode(mode1)) '/' else 0;
    const c2: u8 = if (n2.len > len) n2[len] else if (isDirMode(mode2)) '/' else 0;
    return std.math.order(c1, c2);
}

fn mktree(t: *TContent, v: usize) []u8 {
    const Ctx = struct {
        v: usize,
        fn lt(ctx: @This(), a: *TEntry, b: *TEntry) bool {
            return baseNameCompare(a.name, a.versions[ctx.v].mode, b.name, b.versions[ctx.v].mode) == .lt;
        }
    };
    std.mem.sort(*TEntry, t.entries.items, Ctx{ .v = v }, Ctx.lt);
    var b: util.Buf = .empty;
    for (t.entries.items) |e| {
        if (e.versions[v].mode == 0) continue;
        util.bufPrint(&b, "{o} {s}\x00", .{ e.versions[v].mode & ~NO_DELTA, e.name });
        util.bufAppend(&b, &e.versions[v].oid);
    }
    return b.items;
}

fn storeTree(root: *TEntry) void {
    if (!hash.isZero(root.versions[1].oid)) return;
    if (root.tree == null) loadTree(root);
    const t = root.tree.?;
    for (t.entries.items) |e| {
        if (e.tree != null) storeTree(e);
    }
    const data = mktree(t, 1);
    _ = storeObject(.tree, data, &root.versions[1].oid, 0);
    var j: usize = 0;
    for (t.entries.items) |e| {
        if (e.versions[1].mode != 0) {
            e.versions[0] = e.versions[1];
            t.entries.items[j] = e;
            j += 1;
        }
    }
    t.entries.shrinkRetainingCapacity(j);
}

fn treeContentReplace(root: *TEntry, oid: Oid, mode: u32, newtree: ?*TContent) void {
    if (!isDirMode(mode)) util.die("root cannot be a non-directory", .{});
    root.versions[0].oid = hash.zero;
    root.versions[1].oid = oid;
    root.tree = newtree;
}

fn treeContentSet(root: *TEntry, p: []const u8, oid: Oid, mode: u32, subtree: ?*TContent) bool {
    const slash = std.mem.indexOfScalar(u8, p, '/');
    const n = slash orelse p.len;
    if (n == 0) util.die("empty path component found in input", .{});
    if (slash == null and !isDirMode(mode) and subtree != null) util.die("non-directories cannot have subtrees", .{});
    if (root.tree == null) loadTree(root);
    const comp = p[0..n];
    var i: usize = 0;
    while (i < root.tree.?.entries.items.len) : (i += 1) {
        const e = root.tree.?.entries.items[i];
        if (util.eql(e.name, comp)) {
            if (slash == null) {
                if (!isDirMode(mode) and e.versions[1].mode == mode and hash.eql(e.versions[1].oid, oid)) return false;
                e.versions[1].mode = mode;
                e.versions[1].oid = oid;
                e.tree = subtree;
                if (isDirMode(e.versions[0].mode)) e.versions[0].mode |= NO_DELTA;
                root.versions[1].oid = hash.zero;
                return true;
            }
            if (!isDirMode(e.versions[1].mode)) {
                e.tree = newTreeContent();
                e.versions[1].mode = S_IFDIR;
            }
            if (e.tree == null) loadTree(e);
            if (treeContentSet(e, p[n + 1 ..], oid, mode, subtree)) {
                root.versions[1].oid = hash.zero;
                return true;
            }
            return false;
        }
    }
    const e = newTreeEntry();
    e.name = toAtom(comp);
    e.versions[0].mode = 0;
    e.versions[0].oid = hash.zero;
    root.tree.?.entries.append(gpa, e) catch util.oom();
    if (slash != null) {
        e.tree = newTreeContent();
        e.versions[1].mode = S_IFDIR;
        _ = treeContentSet(e, p[n + 1 ..], oid, mode, subtree);
    } else {
        e.tree = subtree;
        e.versions[1].mode = mode;
        e.versions[1].oid = oid;
    }
    root.versions[1].oid = hash.zero;
    return true;
}

fn treeContentRemove(root: *TEntry, p: []const u8, backup_leaf0: ?*TEntry, allow_root: bool) bool {
    var backup_leaf = backup_leaf0;
    const slash = std.mem.indexOfScalar(u8, p, '/');
    const n = slash orelse p.len;
    if (root.tree == null) loadTree(root);
    var target: *TEntry = undefined;
    found: {
        if (p.len == 0 and allow_root) {
            target = root;
            break :found;
        }
        const comp = p[0..n];
        for (root.tree.?.entries.items) |e| {
            if (util.eql(e.name, comp)) {
                if (slash != null and !isDirMode(e.versions[1].mode)) return true;
                if (slash == null or !isDirMode(e.versions[1].mode)) {
                    target = e;
                    break :found;
                }
                if (e.tree == null) loadTree(e);
                if (treeContentRemove(e, p[n + 1 ..], backup_leaf, false)) {
                    for (e.tree.?.entries.items) |x| {
                        if (x.versions[1].mode != 0) {
                            root.versions[1].oid = hash.zero;
                            return true;
                        }
                    }
                    backup_leaf = null;
                    target = e;
                    break :found;
                }
                return false;
            }
        }
        return false;
    }
    const e = target;
    if (backup_leaf) |bl| bl.* = e.*;
    e.tree = null;
    e.versions[1].mode = 0;
    e.versions[1].oid = hash.zero;
    root.versions[1].oid = hash.zero;
    return true;
}

fn treeContentGet(root: *TEntry, p: []const u8, leaf: *TEntry, allow_root: bool) bool {
    const slash = std.mem.indexOfScalar(u8, p, '/');
    const n = slash orelse p.len;
    if (n == 0 and !allow_root) util.die("empty path component found in input", .{});
    if (root.tree == null) loadTree(root);
    var e: *TEntry = root;
    if (n != 0) {
        const comp = p[0..n];
        var hit: ?*TEntry = null;
        for (root.tree.?.entries.items) |x| {
            if (util.eql(x.name, comp)) {
                hit = x;
                break;
            }
        }
        const x = hit orelse return false;
        if (slash != null) {
            if (!isDirMode(x.versions[1].mode)) return false;
            if (x.tree == null) loadTree(x);
            return treeContentGet(x, p[n + 1 ..], leaf, false);
        }
        e = x;
    }
    leaf.* = e.*;
    if (e.tree != null and hash.isZero(e.versions[1].oid)) {
        leaf.tree = dupTreeContent(e.tree);
    } else leaf.tree = null;
    return true;
}

// ------------------------------------------------------------------ branches

fn hcStr(s: []const u8) u32 {
    var r: u32 = 0;
    for (s) |ch| r = r *% 31 +% @as(u32, @bitCast(@as(i32, @as(i8, @bitCast(ch)))));
    return r;
}

fn lookupBranch(name: []const u8) ?*Branch {
    var bp = branch_table[hcStr(name) % branch_table_sz];
    while (bp) |b| : (bp = b.table_next) {
        if (util.eql(b.name, name)) return b;
    }
    return null;
}

fn newBranch(name: []const u8) *Branch {
    const hc = hcStr(name) % branch_table_sz;
    if (lookupBranch(name) != null) util.die("invalid attempt to create duplicate branch: {s}", .{name});
    if (!refs.checkRefnameFormat(name, refs.ALLOW_ONELEVEL)) util.die("branch name doesn't conform to Git standards: {s}", .{name});
    const b = gpa.create(Branch) catch util.oom();
    b.* = .{ .name = util.dupe(name) };
    b.table_next = branch_table[hc];
    branch_table[hc] = b;
    branch_count += 1;
    return b;
}

fn unloadOneBranch() void {
    while (cur_active_branches > 0 and cur_active_branches >= max_active_branches) {
        var min_commit: u64 = std.math.maxInt(u64);
        var l: ?*Branch = null;
        var p: ?*Branch = null;
        var ep = active_branches;
        while (ep) |e| : (ep = e.active_next) {
            if (e.last_commit < min_commit) {
                p = l;
                min_commit = e.last_commit;
            }
            l = e;
        }
        var e: *Branch = undefined;
        if (p) |pp| {
            e = pp.active_next.?;
            pp.active_next = e.active_next;
        } else {
            e = active_branches.?;
            active_branches = e.active_next;
        }
        e.active = false;
        e.active_next = null;
        e.branch_tree.tree = null;
        cur_active_branches -= 1;
    }
}

fn loadBranch(b: *Branch) void {
    loadTree(&b.branch_tree);
    if (!b.active) {
        b.active = true;
        b.active_next = active_branches;
        active_branches = b;
        cur_active_branches += 1;
        branch_load_count += 1;
    }
}

fn updateBranch(b: *Branch) bool {
    const msg = "fast-import";
    if (util.skipPrefix(b.name, "refs/replace/")) |rest| {
        if (util.eql(rest, &hash.hex(b.oid))) {
            if (!quiet_flag) util.warn("dropping {s} since it would point to itself (i.e. to {s})", .{ b.name, hash.hex(b.oid) });
            refs.deleteRef(b.name, null, 0, null) catch {};
            return true;
        }
    }
    if (hash.isZero(b.oid)) {
        if (b.delete) refs.deleteRef(b.name, null, 0, null) catch {};
        return true;
    }
    const old_oid = refs.readOid(b.name) orelse hash.zero;
    if (!force_update and !hash.isZero(old_oid)) {
        const old_c = commitnode.lookupCommitReference(old_oid);
        const new_c = commitnode.lookupCommitReference(b.oid);
        if (old_c == null or new_c == null) {
            util.err("branch {s} is missing commits.", .{b.name});
            return false;
        }
        if (!commitreach.inMergeBases(old_c.?, new_c.?)) {
            util.warn("not updating {s} (new tip {s} does not contain {s})", .{ b.name, hash.hex(b.oid), hash.hex(old_oid) });
            return false;
        }
    }
    refs.update(b.name, b.oid, old_oid, msg, false) catch {
        util.err("{s}", .{refs.last_error});
        return false;
    };
    return true;
}

fn dumpBranches() void {
    for (branch_table) |head| {
        var bp = head;
        while (bp) |b| : (bp = b.table_next) {
            if (!updateBranch(b)) failure = true;
        }
    }
}

fn dumpTags() void {
    const t = refs.Transaction.init();
    var tp = first_tag;
    while (tp) |tg| : (tp = tg.next) {
        const ref_name = util.concat(&.{ "refs/tags/", tg.name });
        const e = t.update(ref_name, tg.oid, null, null, null, 0, "fast-import");
        if (e != .ok) {
            util.err("{s}", .{t.err.items});
            failure = true;
            t.abort();
            return;
        }
    }
    if (t.commit() != .ok) {
        util.err("{s}", .{t.err.items});
        failure = true;
    }
}

fn dumpMarks() void {
    const path = export_marks_file orelse return;
    if (import_marks_file != null and !import_marks_file_done) return;
    if (!os.mkdirLeading(path)) {
        util.err("unable to create leading directories of {s}: {s}", .{ path, os.lastErr() });
        failure = true;
        return;
    }
    const lk = switch (lockfile.tryLock(path)) {
        .ok => |l| l,
        .err => |e| {
            util.err("unable to write marks file {s}: {s}", .{ path, os.strErr(e) });
            failure = true;
            return;
        },
    };
    var b: util.Buf = .empty;
    for (sortedMarks()) |m| {
        const e = marks.get(m).?;
        util.bufPrint(&b, ":{d} {s}\n", .{ m, hash.hex(e.oid) });
    }
    lk.write(b.items);
    if (!lk.commit()) {
        util.err("unable to write file {s}: {s}", .{ path, os.lastErr() });
        failure = true;
    }
}

fn readMarkFile(data: []const u8, comptime inserter: fn (Oid, u64, ?*SubMarks) void, sm: ?*SubMarks) void {
    var pos: usize = 0;
    while (pos < data.len) {
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n');
        const line = data[pos .. nl orelse data.len];
        pos = if (nl) |x| x + 1 else data.len;
        if (line.len == 0 or line[0] != ':' or nl == null) util.die("corrupt mark line: {s}", .{line});
        var i: usize = 1;
        var mark: u64 = 0;
        while (i < line.len and std.ascii.isDigit(line[i])) : (i += 1) mark = mark *% 10 +% (line[i] - '0');
        if (mark == 0 or i == 1 or i >= line.len or line[i] != ' ' or line.len < i + 1 + 40)
            util.die("corrupt mark line: {s}", .{line});
        const oid = hash.fromHex(line[i + 1 .. i + 41]) orelse util.die("corrupt mark line: {s}", .{line});
        inserter(oid, mark, sm);
    }
}

fn insertObjectEntry(oid: Oid, mark: u64, _: ?*SubMarks) void {
    var e = findObject(oid);
    if (e == null) {
        const t = objectType(oid) orelse util.die("object not found: {s}", .{hash.hex(oid)});
        e = insertObject(oid);
        e.?.typ = t;
        e.?.pack_id = MAX_PACK_ID;
        e.?.offset = 1;
    }
    insertMark(mark, e.?);
}

fn insertOidEntry(oid: Oid, mark: u64, sm: ?*SubMarks) void {
    sm.?.map.put(gpa, mark, oid) catch util.oom();
}

fn readMarks() void {
    const path = import_marks_file.?;
    if (os.readFile(path)) |data| {
        readMarkFile(data, insertObjectEntry, null);
    } else {
        if (!(import_marks_file_ignore_missing and os.errno() == os.ENOENT))
            util.dieErrno("cannot read '{s}'", .{path});
    }
    import_marks_file_done = true;
}

// ------------------------------------------------------------------ command reading

var stdin_eof = false;

fn readNextCommand() bool {
    if (stdin_eof) {
        unread_command_buf = false;
        return false;
    }
    while (true) {
        if (unread_command_buf) {
            unread_command_buf = false;
        } else {
            const line = input.getline() orelse {
                unread_command_buf = false;
                command_buf = "";
                stdin_eof = true;
                return false;
            };
            command_buf = line;
            if (!seen_data_command and !util.startsWith(command_buf, "feature ") and !util.startsWith(command_buf, "option ")) {
                parseArgv();
            }
            if (cmd_hist.items.len >= cmd_save) _ = cmd_hist.orderedRemove(0);
            cmd_hist.append(gpa, command_buf) catch util.oom();
        }
        if (command_buf.len > 0 and command_buf[0] == '#') continue;
        return true;
    }
}

fn skipOptionalLf() void {
    if (input.getc()) |ch| {
        if (ch != '\n') input.ungetc();
    }
}

fn parseMark() void {
    if (util.skipPrefix(command_buf, "mark :")) |v| {
        next_mark = strtoumax(v).val;
        _ = readNextCommand();
    } else next_mark = 0;
}

fn parseOriginalIdentifier() void {
    if (util.startsWith(command_buf, "original-oid ")) _ = readNextCommand();
}

const NumRes = struct { val: u64, end: usize, overflow: bool = false };

/// strtoumax/strtoul with base 10 (leading whitespace and sign accepted).
fn strtoumax(s: []const u8) NumRes {
    var i: usize = 0;
    while (i < s.len and (s[i] == ' ' or (s[i] >= 9 and s[i] <= 13))) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    const ds = i;
    var v: u64 = 0;
    var of = false;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) {
        const m = @mulWithOverflow(v, 10);
        const a = @addWithOverflow(m[0], s[i] - '0');
        if (m[1] != 0 or a[1] != 0) of = true;
        v = a[0];
    }
    if (i == ds) return .{ .val = 0, .end = 0 };
    if (of) v = std.math.maxInt(u64);
    if (neg) v = 0 -% v;
    return .{ .val = v, .end = i, .overflow = of };
}

fn parseData(limit: u64) []u8 {
    _ = limit;
    var sb: util.Buf = .empty;
    const data = util.skipPrefix(command_buf, "data ") orelse
        util.die("expected 'data n' command, found: {s}", .{command_buf});
    if (util.skipPrefix(data, "<<")) |term| {
        const t = util.dupe(term);
        while (true) {
            const line = input.getline() orelse util.die("EOF in data (terminator '{s}' not found)", .{t});
            command_buf = line;
            if (util.eql(line, t)) break;
            util.bufAppend(&sb, line);
            util.bufByte(&sb, '\n');
        }
    } else {
        const length: usize = @intCast(strtoumax(data).val);
        var n: usize = 0;
        sb.ensureTotalCapacity(gpa, length) catch util.oom();
        while (n < length) {
            const s = input.readInto(&sb, length - n);
            if (s == 0 and input.eof) util.die("EOF in data ({d} bytes remaining)", .{length - n});
            n += s;
        }
    }
    skipOptionalLf();
    return sb.items;
}

fn validateRawDate(src: []const u8, strict: bool) bool {
    const a = strtoumax(src);
    if (a.end == 0 or a.overflow or a.end >= src.len or src[a.end] != ' ') return false;
    const rest = src[a.end + 1 ..];
    if (rest.len == 0 or (rest[0] != '-' and rest[0] != '+')) return false;
    const b = strtoumax(rest[1..]);
    if (b.end == 0 or b.overflow or b.end != rest.len - 1) return false;
    if (strict and b.val > 1400) return false;
    return true;
}

/// parse_ident(): `line` is the full command; `start` the offset after "author " etc.
fn parseIdent(line: []const u8, start0: usize) []const u8 {
    var start = start0;
    if (start < line.len and line[start] == '<') start -= 1;
    const buf = line[start..];
    var lt = std.mem.indexOfAny(u8, buf, "<>") orelse buf.len;
    if (lt >= buf.len or buf[lt] != '<') util.die("missing < in ident string: {s}", .{buf});
    if (lt != 0 and buf[lt - 1] != ' ') util.die("missing space before < in ident string: {s}", .{buf});
    lt = lt + 1 + (std.mem.indexOfAny(u8, buf[lt + 1 ..], "<>") orelse buf.len - lt - 1);
    if (lt >= buf.len or buf[lt] != '>') util.die("missing > in ident string: {s}", .{buf});
    lt += 1;
    if (lt >= buf.len or buf[lt] != ' ') util.die("missing space after > in ident string: {s}", .{buf});
    lt += 1;
    const when = buf[lt..];
    var ident: util.Buf = .empty;
    util.bufAppend(&ident, buf[0..lt]);
    switch (whenspec) {
        .raw, .raw_permissive => {
            if (!validateRawDate(when, whenspec == .raw)) util.die("invalid raw date \"{s}\" in ident: {s}", .{ when, buf });
            util.bufAppend(&ident, when);
        },
        .rfc2822 => {
            const d = date.parseDateString(when) orelse util.die("invalid rfc2822 date \"{s}\" in ident: {s}", .{ when, buf });
            util.bufAppend(&ident, d);
        },
        .now => {
            if (!util.eql(when, "now")) util.die("date in ident must be 'now': {s}", .{buf});
            util.bufAppend(&ident, date.datestamp());
        },
    }
    return ident.items;
}

fn parseAndStoreBlob(oidout: ?*Oid, mark: u64) void {
    const data = parseData(0);
    _ = storeObject(.blob, data, oidout, mark);
    gpa.free(data);
}

fn parseNewBlob() void {
    _ = readNextCommand();
    parseMark();
    parseOriginalIdentifier();
    parseAndStoreBlob(null, next_mark);
}

// ------------------------------------------------------------------ notes fanout

fn convertNumNotesToFanout(num0: u64) u8 {
    var num = num0;
    var fanout: u8 = 0;
    while (true) {
        num >>= 8;
        if (num == 0) break;
        fanout += 1;
    }
    return fanout;
}

fn constructPathWithFanout(hex_sha1: []const u8, fanout0: u8) []u8 {
    var fanout = fanout0;
    if (fanout >= 20) util.die("too large fanout ({d})", .{fanout});
    var b: util.Buf = .empty;
    var j: usize = 0;
    while (fanout > 0) : (fanout -= 1) {
        util.bufAppend(&b, hex_sha1[j .. j + 2]);
        util.bufByte(&b, '/');
        j += 2;
    }
    util.bufAppend(&b, hex_sha1[j..40]);
    return b.items;
}

fn doChangeNoteFanout(orig_root: *TEntry, root: *TEntry, hex_oid: []const u8, fullpath: []const u8, fanout: u8) u64 {
    if (root.tree == null) loadTree(root);
    var num_notes: u64 = 0;
    var i: usize = 0;
    while (root.tree != null and i < root.tree.?.entries.items.len) : (i += 1) {
        const e = root.tree.?.entries.items[i];
        const tmp_len = hex_oid.len + e.name.len;
        if (e.versions[1].mode == 0 or tmp_len > 40 or e.name.len % 2 != 0) continue;
        const new_hex = util.concat(&.{ hex_oid, e.name });
        const new_full = if (fullpath.len > 0) util.concat(&.{ fullpath, "/", e.name }) else util.dupe(e.name);
        if (tmp_len == 40 and hash.fromHex(new_hex) != null) {
            if (fanout == 0xff) {
                num_notes += 1;
                continue;
            }
            const realpath = constructPathWithFanout(new_hex, fanout);
            if (util.eql(new_full, realpath)) {
                num_notes += 1;
                continue;
            }
            var leaf: TEntry = .{};
            if (!treeContentRemove(orig_root, new_full, &leaf, false)) util.die("failed to remove path {s}", .{new_full});
            _ = treeContentSet(orig_root, realpath, leaf.versions[1].oid, leaf.versions[1].mode, leaf.tree);
        } else if (isDirMode(e.versions[1].mode)) {
            num_notes += doChangeNoteFanout(orig_root, e, new_hex, new_full, fanout);
        }
    }
    return num_notes;
}

fn changeNoteFanout(root: *TEntry, fanout: u8) u64 {
    return doChangeNoteFanout(root, root, "", "", fanout);
}

// ------------------------------------------------------------------ refs to objects

fn parseMappedOidHex(p: []const u8, oid: *Oid) ?usize {
    if (p.len < 40) return null;
    const o = hash.fromHex(p[0..40]) orelse return null;
    if (p.len > 40 and std.ascii.isHex(p[40])) {
        // maybe a longer (sha256) id; not supported
        if (p.len >= 64 and util.isHex(p[0..64])) return null;
    }
    oid.* = sub_oid_map.get(o) orelse o;
    return 40;
}

fn parseMarkRef(p: []const u8) struct { mark: u64, end: usize } {
    std.debug.assert(p[0] == ':');
    var i: usize = 1;
    var v: u64 = 0;
    while (i < p.len and std.ascii.isDigit(p[i])) : (i += 1) v = v *% 10 +% (p[i] - '0');
    if (i == 1) util.die("no value after ':' in mark: {s}", .{command_buf});
    return .{ .mark = v, .end = i };
}

fn parseMarkRefEol(p: []const u8) u64 {
    const r = parseMarkRef(p);
    if (r.end != p.len) util.die("garbage after mark: {s}", .{command_buf});
    return r.mark;
}

fn parseMarkRefSpace(p: *[]const u8) u64 {
    const r = parseMarkRef(p.*);
    if (r.end >= p.len or p.*[r.end] != ' ') util.die("missing space after mark: {s}", .{command_buf});
    p.* = p.*[r.end + 1 ..];
    return r.mark;
}

fn parsePath(p: []const u8, endp: *usize, is_last_field: bool, field: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '"') {
        const r = util.cunquote(p) orelse util.die("invalid {s}: {s}", .{ field, command_buf });
        if (std.mem.indexOfScalar(u8, r.value, 0) != null) util.die("NUL in {s}: {s}", .{ field, command_buf });
        endp.* = p.len - r.rest.len;
        return r.value;
    }
    endp.* = if (is_last_field) p.len else (std.mem.indexOfScalar(u8, p, ' ') orelse p.len);
    return p[0..endp.*];
}

fn parsePathEol(p: []const u8, field: []const u8) []const u8 {
    var end: usize = 0;
    const r = parsePath(p, &end, true, field);
    if (end != p.len) util.die("garbage after {s}: {s}", .{ field, command_buf });
    return r;
}

fn parsePathSpace(p: *[]const u8, field: []const u8) []const u8 {
    var end: usize = 0;
    const r = parsePath(p.*, &end, false, field);
    if (end >= p.len or p.*[end] != ' ') util.die("missing space after {s}: {s}", .{ field, command_buf });
    p.* = p.*[end + 1 ..];
    return r;
}

fn parseModeStr(p: *[]const u8) ?u32 {
    var mode: u32 = 0;
    var i: usize = 0;
    while (true) {
        if (i >= p.len) return null;
        const ch = p.*[i];
        i += 1;
        if (ch == ' ') break;
        if (ch < '0' or ch > '7') return null;
        mode = ((mode << 3) + (ch - '0')) & 0xffff;
    }
    p.* = p.*[i..];
    return mode;
}

fn fileChangeM(p0: []const u8, b: *Branch) void {
    var p = p0;
    var mode = parseModeStr(&p) orelse util.die("corrupt mode: {s}", .{command_buf});
    switch (mode) {
        0o644, 0o755 => mode |= S_IFREG,
        S_IFREG | 0o644, S_IFREG | 0o755, S_IFLNK, S_IFDIR, S_IFGITLINK => {},
        else => util.die("corrupt mode: {s}", .{command_buf}),
    }
    var oid: Oid = hash.zero;
    var oe: ?*ObjEntry = null;
    var inline_data = false;
    if (p.len > 0 and p[0] == ':') {
        oe = findMark(parseMarkRefSpace(&p));
        oid = oe.?.oid;
    } else if (util.skipPrefix(p, "inline ")) |rest| {
        inline_data = true;
        p = rest;
    } else {
        const n = parseMappedOidHex(p, &oid) orelse util.die("invalid dataref: {s}", .{command_buf});
        p = p[n..];
        oe = findObject(oid);
        if (p.len == 0 or p[0] != ' ') util.die("missing space after SHA1: {s}", .{command_buf});
        p = p[1..];
    }
    const path = parsePathEol(p, "path");

    if (isDirMode(mode) and util.eql(&hash.hex(oid), hash.empty_tree_hex) and path.len > 0) {
        _ = treeContentRemove(&b.branch_tree, path, null, false);
        return;
    }

    if (isGitlink(mode)) {
        if (inline_data) {
            util.die("Git links cannot be specified 'inline': {s}", .{command_buf});
        } else if (oe) |e| {
            if (e.typ != .commit) util.die("not a commit (actually a {s}): {s}", .{ e.typ.name(), command_buf });
        }
    } else if (inline_data) {
        if (isDirMode(mode)) util.die("directories cannot be specified 'inline': {s}", .{command_buf});
        const saved = command_buf;
        _ = saved;
        while (readNextCommand()) {
            if (util.skipPrefix(command_buf, "cat-blob ")) |v| {
                parseCatBlob(v);
            } else {
                parseAndStoreBlob(&oid, 0);
                break;
            }
        }
    } else {
        const expected: ObjType = if (isDirMode(mode)) .tree else .blob;
        const t: ?ObjType = if (oe) |e| e.typ else objectType(oid);
        if (t == null) util.die("{s} not found: {s}", .{ if (isDirMode(mode)) "tree" else "blob", command_buf });
        if (t.? != expected) util.die("not a {s} (actually a {s}): {s}", .{ expected.name(), t.?.name(), command_buf });
    }

    if (path.len == 0) {
        treeContentReplace(&b.branch_tree, oid, mode, null);
        return;
    }
    if (!index_mod.verifyPath(path, mode)) util.die("invalid path '{s}'", .{path});
    _ = treeContentSet(&b.branch_tree, path, oid, mode, null);
}

fn fileChangeD(p: []const u8, b: *Branch) void {
    const path = parsePathEol(p, "path");
    _ = treeContentRemove(&b.branch_tree, path, null, true);
}

fn fileChangeCr(p0: []const u8, b: *Branch, rename: bool) void {
    var p = p0;
    const source = parsePathSpace(&p, "source");
    const dest = parsePathEol(p, "dest");
    var leaf: TEntry = .{};
    if (rename) {
        _ = treeContentRemove(&b.branch_tree, source, &leaf, true);
    } else {
        _ = treeContentGet(&b.branch_tree, source, &leaf, true);
    }
    if (leaf.versions[1].mode == 0) util.die("path {s} not in branch", .{source});
    if (dest.len == 0) {
        treeContentReplace(&b.branch_tree, leaf.versions[1].oid, leaf.versions[1].mode, leaf.tree);
        return;
    }
    if (!index_mod.verifyPath(dest, leaf.versions[1].mode)) util.die("invalid path '{s}'", .{dest});
    _ = treeContentSet(&b.branch_tree, dest, leaf.versions[1].oid, leaf.versions[1].mode, leaf.tree);
}

fn noteChangeN(p0: []const u8, b: *Branch, old_fanout: *u8) void {
    var p = p0;
    if (b.num_notes == 0 and old_fanout.* == 0) {
        b.num_notes = changeNoteFanout(&b.branch_tree, 0xff);
        old_fanout.* = convertNumNotesToFanout(b.num_notes);
    }
    var oid: Oid = hash.zero;
    var oe: ?*ObjEntry = null;
    var inline_data = false;
    if (p.len > 0 and p[0] == ':') {
        oe = findMark(parseMarkRefSpace(&p));
        oid = oe.?.oid;
    } else if (util.skipPrefix(p, "inline ")) |rest| {
        inline_data = true;
        p = rest;
    } else {
        const n = parseMappedOidHex(p, &oid) orelse util.die("invalid dataref: {s}", .{command_buf});
        p = p[n..];
        oe = findObject(oid);
        if (p.len == 0 or p[0] != ' ') util.die("missing space after SHA1: {s}", .{command_buf});
        p = p[1..];
    }
    var commit_oid: Oid = hash.zero;
    if (lookupBranch(p)) |s| {
        if (hash.isZero(s.oid)) util.die("can't add a note on empty branch.", .{});
        commit_oid = s.oid;
    } else if (p.len > 0 and p[0] == ':') {
        const commit_mark = parseMarkRefEol(p);
        const coe = findMark(commit_mark);
        if (coe.typ != .commit) util.die("mark :{d} not a commit", .{commit_mark});
        commit_oid = coe.oid;
    } else if (revparse.getOid(p)) |o| {
        commit_oid = o;
        const buf = readPeeled(&commit_oid, .commit);
        if (buf == null or buf.?.len < 46) util.die("not a valid commit: {s}", .{p});
    } else util.die("invalid ref name or SHA1 expression: {s}", .{p});

    if (inline_data) {
        _ = readNextCommand();
        parseAndStoreBlob(&oid, 0);
    } else if (oe) |e| {
        if (e.typ != .blob) util.die("not a blob (actually a {s}): {s}", .{ e.typ.name(), command_buf });
    } else if (!hash.isZero(oid)) {
        const t = objectType(oid) orelse util.die("blob not found: {s}", .{command_buf});
        if (t != .blob) util.die("not a blob (actually a {s}): {s}", .{ t.name(), command_buf });
    }
    const chex = hash.hex(commit_oid);
    const path = constructPathWithFanout(&chex, old_fanout.*);
    if (treeContentRemove(&b.branch_tree, path, null, false)) b.num_notes -%= 1;
    if (hash.isZero(oid)) return;
    b.num_notes += 1;
    const new_fanout = convertNumNotesToFanout(b.num_notes);
    const path2 = constructPathWithFanout(&chex, new_fanout);
    _ = treeContentSet(&b.branch_tree, path2, oid, S_IFREG | 0o644, null);
}

fn fileChangeDeleteall(b: *Branch) void {
    b.branch_tree.tree = null;
    b.branch_tree.versions[0].oid = hash.zero;
    b.branch_tree.versions[1].oid = hash.zero;
    loadTree(&b.branch_tree);
    b.num_notes = 0;
}

fn parseFromCommit(b: *Branch, buf: ?[]const u8) void {
    const d = buf orelse util.die("not a valid commit: {s}", .{hash.hex(b.oid)});
    if (d.len < 46) util.die("not a valid commit: {s}", .{hash.hex(b.oid)});
    if (!util.startsWith(d, "tree ")) util.die("the commit {s} is corrupt", .{hash.hex(b.oid)});
    const t = hash.fromHex(d[5..45]) orelse util.die("the commit {s} is corrupt", .{hash.hex(b.oid)});
    b.branch_tree.versions[1].oid = t;
    b.branch_tree.versions[0].oid = t;
}

fn parseFromExisting(b: *Branch) void {
    if (hash.isZero(b.oid)) {
        b.branch_tree.versions[0].oid = hash.zero;
        b.branch_tree.versions[1].oid = hash.zero;
    } else {
        const buf = readPeeled(&b.oid, .commit);
        parseFromCommit(b, buf);
    }
}

fn parseObjectish(b: *Branch, objectish: []const u8) void {
    const oid = b.branch_tree.versions[1].oid;
    const s = lookupBranch(objectish);
    if (s != null and s.? == b) {
        util.die("can't create a branch from itself: {s}", .{b.name});
    } else if (s) |src| {
        const t = src.branch_tree.versions[1].oid;
        b.oid = src.oid;
        b.branch_tree.versions[0].oid = t;
        b.branch_tree.versions[1].oid = t;
    } else if (objectish.len > 0 and objectish[0] == ':') {
        const idnum = parseMarkRefEol(objectish);
        const oe = findMark(idnum);
        if (oe.typ != .commit) util.die("mark :{d} not a commit", .{idnum});
        if (!hash.eql(b.oid, oe.oid)) {
            b.oid = oe.oid;
            parseFromExisting(b);
        }
    } else if (revparse.getOid(objectish)) |o| {
        b.oid = o;
        parseFromExisting(b);
        if (hash.isZero(b.oid)) b.delete = true;
    } else util.die("invalid ref name or SHA1 expression: {s}", .{objectish});

    if (b.branch_tree.tree != null and !hash.eql(oid, b.branch_tree.versions[1].oid)) {
        b.branch_tree.tree = null;
    }
    _ = readNextCommand();
}

fn parseFrom(b: *Branch) bool {
    const from = util.skipPrefix(command_buf, "from ") orelse return false;
    parseObjectish(b, from);
    return true;
}

fn parseMerge() []Oid {
    var list: std.ArrayList(Oid) = .empty;
    while (util.skipPrefix(command_buf, "merge ")) |from| {
        var oid: Oid = hash.zero;
        if (lookupBranch(from)) |s| {
            oid = s.oid;
        } else if (from.len > 0 and from[0] == ':') {
            const idnum = parseMarkRefEol(from);
            const oe = findMark(idnum);
            if (oe.typ != .commit) util.die("mark :{d} not a commit", .{idnum});
            oid = oe.oid;
        } else if (revparse.getOid(from)) |o| {
            oid = o;
            const buf = readPeeled(&oid, .commit);
            if (buf == null or buf.?.len < 46) util.die("not a valid commit: {s}", .{from});
        } else util.die("invalid ref name or SHA1 expression: {s}", .{from});
        list.append(gpa, oid) catch util.oom();
        _ = readNextCommand();
    }
    return list.items;
}

// ------------------------------------------------------------------ signatures

const SigData = struct { hash_algo: ?[]const u8 = null, sig_format: []const u8 = "", data: []const u8 = "" };

fn validSignatureFormat(f: []const u8) bool {
    return util.eql(f, "openpgp") or util.eql(f, "x509") or util.eql(f, "ssh") or util.eql(f, "unknown");
}

fn parseOneSignature(v: []const u8) SigData {
    const sp = std.mem.indexOfScalar(u8, v, ' ') orelse
        util.die("expected gpgsig format: 'gpgsig <hash-algo> <signature-format>', got 'gpgsig {s}'", .{v});
    var sig = SigData{ .hash_algo = util.dupe(v[0..sp]), .sig_format = util.dupe(v[sp + 1 ..]) };
    if (!util.eql(sig.hash_algo.?, "sha1") and !util.eql(sig.hash_algo.?, "sha256"))
        util.die("unknown git hash algorithm in gpgsig: '{s}'", .{sig.hash_algo.?});
    if (!validSignatureFormat(sig.sig_format)) util.die("invalid signature format in gpgsig: '{s}'", .{sig.sig_format});
    if (util.eql(sig.sig_format, "unknown")) util.warn("'unknown' signature format in gpgsig", .{});
    _ = readNextCommand();
    sig.data = parseData(0);
    return sig;
}

fn addGpgsigToCommit(b: *util.Buf, header: []const u8, sig: *const SigData) void {
    if (sig.hash_algo == null) return;
    util.bufAppend(b, header);
    var it = std.mem.splitScalar(u8, sig.data, '\n');
    var first = true;
    while (it.next()) |l| {
        if (!first) util.bufAppend(b, "\n ");
        first = false;
        util.bufAppend(b, l);
    }
    util.bufByte(b, '\n');
}

fn finalizeCommitBuffer(b: *util.Buf, s1: ?*const SigData, s256: ?*const SigData, msg: []const u8) void {
    if (s1) |s| addGpgsigToCommit(b, "gpgsig ", s);
    if (s256) |s| addGpgsigToCommit(b, "gpgsig-sha256 ", s);
    util.bufByte(b, '\n');
    util.bufAppend(b, msg);
}

fn findCommitSubject(msg: []const u8) []const u8 {
    // msg is the commit message (no headers); subject is the first paragraph
    var p: usize = 0;
    while (p < msg.len and msg[p] == '\n') p += 1;
    var e = p;
    while (e < msg.len) {
        const nl = std.mem.indexOfScalarPos(u8, msg, e, '\n') orelse {
            e = msg.len;
            break;
        };
        if (nl + 1 >= msg.len or msg[nl + 1] == '\n') {
            e = nl;
            break;
        }
        e = nl + 1;
    }
    var s = msg[p..e];
    while (s.len > 0 and s[s.len - 1] == '\n') s = s[0 .. s.len - 1];
    return s;
}

fn warnInvalidSignature(msg: []const u8, mode: SignMode) void {
    const subject = findCommitSubject(msg);
    const verb = if (mode == .strip_if_invalid) "stripping" else "replacing";
    if (subject.len > 100) {
        util.warn("{s} invalid signature for commit '{s}...'\n  allegedly by unknown", .{ verb, subject[0..100] });
    } else if (subject.len > 0) {
        util.warn("{s} invalid signature for commit '{s}'\n  allegedly by unknown", .{ verb, subject });
    } else {
        util.warn("{s} invalid signature for commit\n  allegedly by unknown", .{verb});
    }
}

fn sigFormatPrefix(line: []const u8) bool {
    return util.startsWith(line, "-----BEGIN PGP SIGNATURE-----") or
        util.startsWith(line, "-----BEGIN PGP MESSAGE-----") or
        util.startsWith(line, "-----BEGIN SIGNED MESSAGE-----") or
        util.startsWith(line, "-----BEGIN SSH SIGNATURE-----");
}

fn parseSignedBuffer(buf: []const u8) usize {
    var len: usize = 0;
    var match: usize = buf.len;
    while (len < buf.len) {
        if (sigFormatPrefix(buf[len..])) match = len;
        const eol = std.mem.indexOfScalarPos(u8, buf, len, '\n');
        len = if (eol) |x| x + 1 else buf.len;
    }
    return match;
}

// ------------------------------------------------------------------ commit / tag / reset

fn parseNewCommit(arg: []const u8) void {
    const b = lookupBranch(arg) orelse newBranch(arg);
    _ = readNextCommand();
    parseMark();
    parseOriginalIdentifier();
    var author: ?[]const u8 = null;
    var committer: ?[]const u8 = null;
    var encoding: ?[]const u8 = null;
    if (util.startsWith(command_buf, "author ")) {
        author = parseIdent(command_buf, 7);
        _ = readNextCommand();
    }
    if (util.startsWith(command_buf, "committer ")) {
        committer = parseIdent(command_buf, 10);
        _ = readNextCommand();
    }
    if (committer == null) util.die("expected committer but didn't get one", .{});

    var sig1: SigData = .{};
    var sig256: SigData = .{};
    while (util.skipPrefix(command_buf, "gpgsig ")) |v| {
        switch (signed_commit_mode) {
            .abort => util.die("encountered signed commit; use --signed-commits=<mode> to handle it", .{}),
            .warn_strip, .strip => {
                if (signed_commit_mode == .warn_strip) util.warn("stripping a commit signature", .{});
                _ = readNextCommand();
                _ = parseData(0);
            },
            else => {
                if (signed_commit_mode == .warn_verbatim) util.warn("importing a commit signature verbatim", .{});
                const sig = parseOneSignature(v);
                if (util.eql(sig.hash_algo.?, "sha1")) {
                    if (sig1.hash_algo != null) util.warn("multiple {s} signatures found, ignoring additional signature", .{"SHA-1"}) else sig1 = sig;
                } else {
                    if (sig256.hash_algo != null) util.warn("multiple {s} signatures found, ignoring additional signature", .{"SHA-256"}) else sig256 = sig;
                }
            },
        }
        _ = readNextCommand();
    }

    if (util.skipPrefix(command_buf, "encoding ")) |v| {
        encoding = util.dupe(v);
        _ = readNextCommand();
    }
    const msg = parseData(0);
    _ = readNextCommand();
    _ = parseFrom(b);
    const merge_list = parseMerge();

    if (b.branch_tree.tree == null or max_active_branches == 0) {
        unloadOneBranch();
        loadBranch(b);
    }

    var prev_fanout = convertNumNotesToFanout(b.num_notes);

    while (command_buf.len > 0) {
        if (util.skipPrefix(command_buf, "M ")) |v| {
            fileChangeM(v, b);
        } else if (util.skipPrefix(command_buf, "D ")) |v| {
            fileChangeD(v, b);
        } else if (util.skipPrefix(command_buf, "R ")) |v| {
            fileChangeCr(v, b, true);
        } else if (util.skipPrefix(command_buf, "C ")) |v| {
            fileChangeCr(v, b, false);
        } else if (util.skipPrefix(command_buf, "N ")) |v| {
            noteChangeN(v, b, &prev_fanout);
        } else if (util.eql(command_buf, "deleteall")) {
            fileChangeDeleteall(b);
        } else if (util.skipPrefix(command_buf, "ls ")) |v| {
            parseLs(v, b);
        } else if (util.skipPrefix(command_buf, "cat-blob ")) |v| {
            parseCatBlob(v);
        } else {
            unread_command_buf = true;
            break;
        }
        if (!readNextCommand()) break;
    }

    const new_fanout = convertNumNotesToFanout(b.num_notes);
    if (new_fanout != prev_fanout) b.num_notes = changeNoteFanout(&b.branch_tree, new_fanout);

    storeTree(&b.branch_tree);
    b.branch_tree.versions[0].oid = b.branch_tree.versions[1].oid;

    var nd: util.Buf = .empty;
    util.bufPrint(&nd, "tree {s}\n", .{hash.hex(b.branch_tree.versions[1].oid)});
    if (!hash.isZero(b.oid)) util.bufPrint(&nd, "parent {s}\n", .{hash.hex(b.oid)});
    for (merge_list) |m| util.bufPrint(&nd, "parent {s}\n", .{hash.hex(m)});
    util.bufPrint(&nd, "author {s}\ncommitter {s}\n", .{ author orelse committer.?, committer.? });
    if (encoding) |e| util.bufPrint(&nd, "encoding {s}\n", .{e});

    const check_modes = signed_commit_mode == .strip_if_invalid or signed_commit_mode == .sign_if_invalid or signed_commit_mode == .abort_if_invalid;
    if (check_modes and (sig1.hash_algo != null or sig256.hash_algo != null)) {
        // No signature verification backend is available: treat as invalid.
        if (signed_commit_mode == .abort_if_invalid) util.die("aborting due to invalid signature", .{});
        warnInvalidSignature(msg, signed_commit_mode);
        if (signed_commit_mode == .sign_if_invalid) util.die("failed to sign commit object", .{});
        finalizeCommitBuffer(&nd, null, null, msg);
    } else {
        finalizeCommitBuffer(&nd, &sig1, &sig256, msg);
    }

    if (!storeObject(.commit, nd.items, &b.oid, next_mark)) b.pack_id = pack_id;
    b.last_commit = object_count_by_type[typeIdx(.commit)];
}

fn handleTagSignature(msg: *[]const u8, name: []const u8) void {
    const off = parseSignedBuffer(msg.*);
    if (off >= msg.len) return;
    switch (signed_tag_mode) {
        .warn_verbatim => util.warn("importing a tag signature verbatim for tag '{s}'", .{name}),
        .verbatim => {},
        .warn_strip, .strip => {
            if (signed_tag_mode == .warn_strip) util.warn("stripping a tag signature for tag '{s}'", .{name});
            msg.* = msg.*[0..off];
        },
        .abort_if_invalid => util.die("aborting due to invalid signature", .{}),
        .sign_if_invalid => util.die("failed to sign tag object", .{}),
        .strip_if_invalid => msg.* = msg.*[0..off],
        .abort => util.die("encountered signed tag; use --signed-tags=<mode> to handle it", .{}),
    }
}

fn parseNewTag(arg: []const u8) void {
    const t = gpa.create(Tag) catch util.oom();
    t.* = .{ .name = util.dupe(arg) };
    if (last_tag) |lt| lt.next = t else first_tag = t;
    last_tag = t;
    _ = readNextCommand();
    parseMark();

    const from = util.skipPrefix(command_buf, "from ") orelse util.die("expected 'from' command, got '{s}'", .{command_buf});
    var oid: Oid = hash.zero;
    var typ: ObjType = .commit;
    if (lookupBranch(from)) |s| {
        if (hash.isZero(s.oid)) util.die("can't tag an empty branch.", .{});
        oid = s.oid;
        typ = .commit;
    } else if (from.len > 0 and from[0] == ':') {
        const from_mark = parseMarkRefEol(from);
        const oe = findMark(from_mark);
        typ = oe.typ;
        oid = oe.oid;
    } else if (revparse.getOid(from)) |o| {
        oid = o;
        if (findObject(oid)) |oe| {
            typ = oe.typ;
        } else {
            typ = objectType(oid) orelse util.die("not a valid object: {s}", .{from});
        }
    } else util.die("invalid ref name or SHA1 expression: {s}", .{from});
    _ = readNextCommand();

    parseOriginalIdentifier();

    var tagger: ?[]const u8 = null;
    if (util.startsWith(command_buf, "tagger ")) {
        tagger = parseIdent(command_buf, 7);
        _ = readNextCommand();
    }

    var msg: []const u8 = parseData(0);
    var nd: util.Buf = .empty;
    util.bufPrint(&nd, "object {s}\ntype {s}\ntag {s}\n", .{ hash.hex(oid), typ.name(), t.name });
    if (tagger) |tg| util.bufPrint(&nd, "tagger {s}\n", .{tg});
    handleTagSignature(&msg, t.name);
    util.bufByte(&nd, '\n');
    util.bufAppend(&nd, msg);

    if (storeObject(.tag, nd.items, &t.oid, next_mark)) {
        t.pack_id = MAX_PACK_ID;
    } else t.pack_id = pack_id;
}

fn parseResetBranch(arg: []const u8) void {
    var b: *Branch = undefined;
    if (lookupBranch(arg)) |x| {
        b = x;
        b.oid = hash.zero;
        b.branch_tree.versions[0].oid = hash.zero;
        b.branch_tree.versions[1].oid = hash.zero;
        b.branch_tree.tree = null;
    } else b = newBranch(arg);
    _ = readNextCommand();
    _ = parseFrom(b);
    if (b.delete) {
        if (util.skipPrefix(b.name, "refs/tags/")) |tag_name| {
            var prev: ?*Tag = null;
            var tp = first_tag;
            while (tp) |t| : (tp = t.next) {
                if (util.eql(t.name, tag_name)) break;
                prev = t;
            }
            if (tp) |t| {
                if (prev) |pv| pv.next = t.next else first_tag = t.next;
                if (t.next == null) last_tag = prev;
            }
        }
    }
    if (command_buf.len > 0) unread_command_buf = true;
}

// ------------------------------------------------------------------ cat-blob / ls / get-mark

fn catBlobWrite(data: []const u8) void {
    if (cat_blob_fd == 1) {
        util.out(data);
        util.flushStdout();
        if (util.stdout.broken) util.dieErrno("write to frontend failed", .{});
        return;
    }
    os.writeAll(cat_blob_fd, data) catch util.dieErrno("write to frontend failed", .{});
}

fn catBlob(oid: Oid) void {
    const obj = readObject(oid) orelse {
        catBlobWrite(util.fmt("{s} missing\n", .{hash.hex(oid)}));
        return;
    };
    if (obj.typ != .blob) util.die("object {s} is a {s} but a blob was expected.", .{ hash.hex(oid), obj.typ.name() });
    var b: util.Buf = .empty;
    util.bufPrint(&b, "{s} {s} {d}\n", .{ hash.hex(oid), obj.typ.name(), obj.data.len });
    util.bufAppend(&b, obj.data);
    util.bufByte(&b, '\n');
    catBlobWrite(b.items);
}

fn parseGetMark(p: []const u8) void {
    if (p.len == 0 or p[0] != ':') util.die("not a mark: {s}", .{p});
    const oe = findMark(parseMarkRefEol(p));
    catBlobWrite(util.fmt("{s}\n", .{hash.hex(oe.oid)}));
}

fn parseCatBlob(p0: []const u8) void {
    var oid: Oid = hash.zero;
    if (p0.len > 0 and p0[0] == ':') {
        const oe = findMark(parseMarkRefEol(p0));
        oid = oe.oid;
    } else {
        const n = parseMappedOidHex(p0, &oid) orelse util.die("invalid dataref: {s}", .{command_buf});
        if (n != p0.len) util.die("garbage after SHA1: {s}", .{command_buf});
    }
    catBlob(oid);
}

fn dereference(oe0: ?*ObjEntry, oid: *Oid) ?*ObjEntry {
    var oe = oe0;
    if (oe == null) {
        const t = objectType(oid.*) orelse util.die("object not found: {s}", .{hash.hex(oid.*)});
        const e = insertObject(oid.*);
        e.typ = t;
        e.pack_id = MAX_PACK_ID;
        e.offset = 1;
        oe = e;
    }
    const e = oe.?;
    switch (e.typ) {
        .tree => return e,
        .commit, .tag => {},
        else => util.die("not a tree-ish: {s}", .{command_buf}),
    }
    const obj = readObject(oid.*) orelse util.die("can't load object {s}", .{hash.hex(oid.*)});
    const buf = obj.data;
    if (e.typ == .tag) {
        if (buf.len < 47 or !util.startsWith(buf, "object ")) util.die("invalid SHA1 in tag: {s}", .{command_buf});
        oid.* = hash.fromHex(buf[7..47]) orelse util.die("invalid SHA1 in tag: {s}", .{command_buf});
    } else {
        if (buf.len < 45 or !util.startsWith(buf, "tree ")) util.die("invalid SHA1 in commit: {s}", .{command_buf});
        oid.* = hash.fromHex(buf[5..45]) orelse util.die("invalid SHA1 in commit: {s}", .{command_buf});
    }
    return findObject(oid.*);
}

fn parseTreeishDataref(p: *[]const u8) *ObjEntry {
    var oid: Oid = hash.zero;
    var e: ?*ObjEntry = null;
    if (p.len > 0 and p.*[0] == ':') {
        e = findMark(parseMarkRefSpace(p));
        oid = e.?.oid;
    } else {
        const n = parseMappedOidHex(p.*, &oid) orelse util.die("invalid dataref: {s}", .{command_buf});
        e = findObject(oid);
        if (n >= p.len or p.*[n] != ' ') util.die("missing space after tree-ish: {s}", .{command_buf});
        p.* = p.*[n + 1 ..];
    }
    while (e == null or e.?.typ != .tree) e = dereference(e, &oid);
    return e.?;
}

fn printLs(mode: u32, oid: Oid, path: []const u8) void {
    var line: util.Buf = .empty;
    if (mode == 0) {
        util.bufAppend(&line, "missing ");
        util.bufAppend(&line, util.cquote(path));
        util.bufByte(&line, '\n');
    } else {
        const typ = if (isGitlink(mode)) "commit" else if (isDirMode(mode)) "tree" else "blob";
        util.bufPrint(&line, "{o:0>6} {s} {s}\t", .{ mode & ~NO_DELTA, typ, hash.hex(oid) });
        util.bufAppend(&line, util.cquote(path));
        util.bufByte(&line, '\n');
    }
    catBlobWrite(line.items);
}

fn parseLs(p0: []const u8, b: ?*Branch) void {
    var p = p0;
    var root: *TEntry = undefined;
    if (p.len > 0 and p[0] == '"') {
        const br = b orelse util.die("not in a commit: {s}", .{command_buf});
        root = &br.branch_tree;
    } else {
        const e = parseTreeishDataref(&p);
        root = newTreeEntry();
        root.versions[1].oid = e.oid;
        if (!hash.isZero(e.oid)) root.versions[1].mode = S_IFDIR;
        loadTree(root);
    }
    const path = parsePathEol(p, "path");
    var leaf: TEntry = .{};
    _ = treeContentGet(root, path, &leaf, true);
    if (isDirMode(leaf.versions[1].mode)) storeTree(&leaf);
    printLs(leaf.versions[1].mode, leaf.versions[1].oid, path);
}

// ------------------------------------------------------------------ misc commands

fn checkpoint() void {
    if (object_count > 0 or pending.items.len > 0) endPackfile();
    dumpBranches();
    dumpTags();
    dumpMarks();
}

fn parseProgress() void {
    util.out(command_buf);
    util.out("\n");
    util.flushStdout();
    skipOptionalLf();
}

fn parseAlias() void {
    skipOptionalLf();
    _ = readNextCommand();
    parseMark();
    if (next_mark == 0) util.die("expected 'mark' command, got {s}", .{command_buf});
    var b = Branch{ .name = "" };
    b.branch_tree.versions = .{ .{}, .{} };
    const v = util.skipPrefix(command_buf, "to ") orelse util.die("expected 'to' command, got {s}", .{command_buf});
    parseObjectish(&b, v);
    var e = findObject(b.oid);
    if (e == null) {
        const t = objectType(b.oid) orelse util.die("object not found: {s}", .{hash.hex(b.oid)});
        e = insertObject(b.oid);
        e.?.typ = t;
        e.?.offset = 1;
    }
    insertMark(next_mark, e.?);
}

fn makeFastImportPath(path: []const u8) []const u8 {
    if (!relative_marks_paths or (path.len > 0 and path[0] == '/')) {
        if (path.len > 0 and path[0] == '/') return util.dupe(path);
        return util.concat(&.{ repo_mod.repo().prefix, path });
    }
    return repo_mod.repo().gitPath(util.concat(&.{ "info/fast-import/", path }));
}

fn optionImportMarks(m: []const u8, from_stream: bool, ignore_missing: bool) void {
    if (import_marks_file != null) {
        if (from_stream) util.die("only one import-marks command allowed per stream", .{});
        if (!import_marks_file_from_stream) readMarks();
    }
    import_marks_file = makeFastImportPath(m);
    import_marks_file_from_stream = from_stream;
    import_marks_file_ignore_missing = ignore_missing;
}

fn optionDateFormat(f: []const u8) void {
    if (util.eql(f, "raw")) {
        whenspec = .raw;
    } else if (util.eql(f, "raw-permissive")) {
        whenspec = .raw_permissive;
    } else if (util.eql(f, "rfc2822")) {
        whenspec = .rfc2822;
    } else if (util.eql(f, "now")) {
        whenspec = .now;
    } else util.die("unknown --date-format argument {s}", .{f});
}

fn ulongArg(option: []const u8, arg: []const u8) u64 {
    const r = strtoumax(arg);
    if (std.mem.indexOfScalar(u8, arg, '-') != null or r.end == 0 or r.end != arg.len)
        util.die("{s}: argument must be a non-negative integer", .{option});
    return r.val;
}

fn optionDepth(d: []const u8) void {
    max_depth = ulongArg("--depth", d);
    if (max_depth > MAX_DEPTH) util.die("--depth cannot exceed {d}", .{MAX_DEPTH});
}

fn optionActiveBranches(b: []const u8) void {
    max_active_branches = ulongArg("--active-branches", b);
}

fn optionExportMarks(m: []const u8) void {
    export_marks_file = makeFastImportPath(m);
}

fn optionCatBlobFd(fd: []const u8) void {
    const n = ulongArg("--cat-blob-fd", fd);
    if (n > std.math.maxInt(c_int)) util.die("--cat-blob-fd cannot exceed {d}", .{std.math.maxInt(c_int)});
    cat_blob_fd = @intCast(n);
}

fn optionExportPackEdges(edges: []const u8) void {
    const f = if (edges.len > 0 and edges[0] == '/') edges else util.concat(&.{ repo_mod.repo().prefix, edges });
    if (pack_edges_fd >= 0) os.close(pack_edges_fd);
    pack_edges_fd = os.openFile(f, os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_CLOEXEC, 0o666);
    if (pack_edges_fd < 0) util.dieErrno("could not open '{s}'", .{f});
}

fn optionRewriteSubmodules(arg: []const u8, to: bool) void {
    const colon = std.mem.indexOfScalar(u8, arg, ':') orelse util.die("expected format name:filename for submodule rewrite option", .{});
    const name = util.dupe(arg[0..colon]);
    var f = arg[colon + 1 ..];
    if (!(f.len > 0 and f[0] == '/')) f = util.concat(&.{ repo_mod.repo().prefix, f });
    const data = os.readFile(f) orelse util.dieErrno("cannot read '{s}'", .{f});
    var sm = SubMarks{ .name = name, .map = .empty };
    readMarkFile(data, insertOidEntry, &sm);
    const list = if (to) &sub_marks_to else &sub_marks_from;
    for (list.items) |*x| {
        if (util.eql(x.name, name)) {
            x.* = sm;
            return;
        }
    }
    list.append(gpa, sm) catch util.oom();
}

fn optionMaxPackSize(arg: []const u8) void {
    _ = po.parseIntArg(arg) orelse util.die("--max-pack-size: argument must be a non-negative integer", .{});
}

fn optionBigFileThreshold(arg: []const u8) void {
    _ = po.parseIntArg(arg) orelse util.die("--big-file-threshold: argument must be a non-negative integer", .{});
}

fn parseSignMode(arg: []const u8) ?SignMode {
    if (util.eql(arg, "abort")) return .abort;
    if (util.eql(arg, "verbatim") or util.eql(arg, "ignore")) return .verbatim;
    if (util.eql(arg, "warn-verbatim") or util.eql(arg, "warn")) return .warn_verbatim;
    if (util.eql(arg, "warn-strip")) return .warn_strip;
    if (util.eql(arg, "strip")) return .strip;
    if (util.eql(arg, "abort-if-invalid")) return .abort_if_invalid;
    if (util.eql(arg, "strip-if-invalid")) return .strip_if_invalid;
    if (util.eql(arg, "sign-if-invalid") or util.startsWith(arg, "sign-if-invalid=")) return .sign_if_invalid;
    return null;
}

fn optionSignedCommits(arg: []const u8) void {
    signed_commit_mode = parseSignMode(arg) orelse util.usageDie("usage: unknown --signed-commits mode '{s}'", .{arg});
}

fn optionSignedTags(arg: []const u8) void {
    signed_tag_mode = parseSignMode(arg) orelse util.usageDie("usage: unknown --signed-tags mode '{s}'", .{arg});
}

fn optionQuiet() void {
    show_stats = false;
    quiet_flag = true;
}

fn parseOneOption(option: []const u8) bool {
    if (util.skipPrefix(option, "max-pack-size=")) |v| {
        optionMaxPackSize(v);
    } else if (util.skipPrefix(option, "big-file-threshold=")) |v| {
        optionBigFileThreshold(v);
    } else if (util.skipPrefix(option, "depth=")) |v| {
        optionDepth(v);
    } else if (util.skipPrefix(option, "active-branches=")) |v| {
        optionActiveBranches(v);
    } else if (util.skipPrefix(option, "export-pack-edges=")) |v| {
        if (!allow_unsafe_features) util.die("option '{s}' forbidden in input without --allow-unsafe-features", .{"export-pack-edges"});
        optionExportPackEdges(v);
    } else if (util.skipPrefix(option, "signed-commits=")) |v| {
        optionSignedCommits(v);
    } else if (util.skipPrefix(option, "signed-tags=")) |v| {
        optionSignedTags(v);
    } else if (util.eql(option, "quiet")) {
        optionQuiet();
    } else if (util.eql(option, "stats")) {
        show_stats = true;
    } else if (util.eql(option, "allow-unsafe-features")) {
        // handled during early option parsing
    } else return false;
    return true;
}

fn checkUnsafeFeature(feature: []const u8) void {
    if (!allow_unsafe_features) util.die("feature '{s}' forbidden in input without --allow-unsafe-features", .{feature});
}

fn parseOneFeature(feature: []const u8) bool {
    if (util.skipPrefix(feature, "date-format=")) |a| {
        optionDateFormat(a);
    } else if (util.skipPrefix(feature, "import-marks=")) |a| {
        checkUnsafeFeature("import-marks");
        optionImportMarks(a, true, false);
    } else if (util.skipPrefix(feature, "import-marks-if-exists=")) |a| {
        checkUnsafeFeature("import-marks-if-exists");
        optionImportMarks(a, true, true);
    } else if (util.skipPrefix(feature, "export-marks=")) |a| {
        checkUnsafeFeature(feature);
        optionExportMarks(a);
    } else if (util.eql(feature, "alias")) {
        // supported
    } else if (util.skipPrefix(feature, "rewrite-submodules-to=")) |a| {
        checkUnsafeFeature("rewrite-submodules-to");
        optionRewriteSubmodules(a, true);
    } else if (util.skipPrefix(feature, "rewrite-submodules-from=")) |a| {
        checkUnsafeFeature("rewrite-submodules-from");
        optionRewriteSubmodules(a, false);
    } else if (util.eql(feature, "get-mark") or util.eql(feature, "cat-blob")) {
        // supported
    } else if (util.eql(feature, "relative-marks")) {
        relative_marks_paths = true;
    } else if (util.eql(feature, "no-relative-marks")) {
        relative_marks_paths = false;
    } else if (util.eql(feature, "done")) {
        require_explicit_termination = true;
    } else if (util.eql(feature, "force")) {
        force_update = true;
    } else if (util.eql(feature, "notes") or util.eql(feature, "ls")) {
        // supported
    } else return false;
    return true;
}

fn parseFeature(feature: []const u8) void {
    if (seen_data_command) util.die("got feature command '{s}' after data command", .{feature});
    if (parseOneFeature(feature)) return;
    util.die("this version of fast-import does not support feature {s}.", .{feature});
}

fn parseOption(option: []const u8) void {
    if (seen_data_command) util.die("got option command '{s}' after data command", .{option});
    if (parseOneOption(option)) return;
    util.die("this version of fast-import does not support option: {s}", .{option});
}

fn gitPackConfig() void {
    const cfg = &repo_mod.cfg;
    if (cfg.getInt("pack.depth")) |d| {
        max_depth = if (d < 0) MAX_DEPTH else @min(@as(u64, @intCast(d)), MAX_DEPTH);
    }
    if (cfg.getInt("pack.indexversion")) |v| {
        if (v > 2) util.die("bad pack.indexVersion={d}", .{v});
    }
    if (cfg.getInt("fastimport.unpacklimit")) |l| {
        unpack_limit = l;
    } else if (cfg.getInt("transfer.unpacklimit")) |l| {
        unpack_limit = l;
    }
}

// ------------------------------------------------------------------ argv

const usage_str = [_][]const u8{"git fast-import [<options>]"};

var opt_stats = true;
var opt_force = false;
var opt_done = false;
var opt_relative = false;
var opt_unsafe = false;

fn cbDateFormat(a: ?[]const u8, _: bool) void {
    optionDateFormat(a.?);
}
fn cbQuiet(_: ?[]const u8, _: bool) void {
    optionQuiet();
    opt_stats = false;
}
fn cbMaxPackSize(a: ?[]const u8, _: bool) void {
    optionMaxPackSize(a.?);
}
fn cbBigFile(a: ?[]const u8, _: bool) void {
    optionBigFileThreshold(a.?);
}
fn cbDepth(a: ?[]const u8, _: bool) void {
    optionDepth(a.?);
}
fn cbActive(a: ?[]const u8, _: bool) void {
    optionActiveBranches(a.?);
}
fn cbImportMarks(a: ?[]const u8, _: bool) void {
    relative_marks_paths = opt_relative;
    optionImportMarks(a.?, false, false);
}
fn cbImportMarksIfExists(a: ?[]const u8, _: bool) void {
    relative_marks_paths = opt_relative;
    optionImportMarks(a.?, false, true);
}
fn cbExportMarks(a: ?[]const u8, _: bool) void {
    relative_marks_paths = opt_relative;
    optionExportMarks(a.?);
}
fn cbSubFrom(a: ?[]const u8, _: bool) void {
    optionRewriteSubmodules(a.?, false);
}
fn cbSubTo(a: ?[]const u8, _: bool) void {
    optionRewriteSubmodules(a.?, true);
}
fn cbSignedCommits(a: ?[]const u8, _: bool) void {
    optionSignedCommits(a.?);
}
fn cbSignedTags(a: ?[]const u8, _: bool) void {
    optionSignedTags(a.?);
}
fn cbPackEdges(a: ?[]const u8, _: bool) void {
    optionExportPackEdges(a.?);
}
fn cbCatBlobFd(a: ?[]const u8, _: bool) void {
    optionCatBlobFd(a.?);
}

const options = [_]po.Opt{
    po.group("Common"),
    .{ .long = "date-format", .kind = .callback, .cb = cbDateFormat, .argh = "fmt", .help = "format of the commit/tag dates", .noneg = true },
    .{ .long = "stats", .kind = .boolean, .b = &opt_stats, .help = "display some basic statistics (objects, packfiles and memory)", .noneg = true },
    .{ .long = "quiet", .kind = .callback, .cb = cbQuiet, .noarg = true, .help = "disable the output shown by --stats", .noneg = true },
    .{ .long = "force", .kind = .boolean, .b = &opt_force, .help = "force updating modified existing branches", .noneg = true },
    .{ .long = "done", .kind = .boolean, .b = &opt_done, .help = "require a terminating 'done' command", .noneg = true },
    .{ .long = "max-pack-size", .kind = .callback, .cb = cbMaxPackSize, .argh = "n", .help = "maximum size of each output pack file", .noneg = true },
    .{ .long = "big-file-threshold", .kind = .callback, .cb = cbBigFile, .argh = "n", .help = "maximum size of a blob that will be deltified", .noneg = true },
    .{ .long = "depth", .kind = .callback, .cb = cbDepth, .argh = "n", .help = "maximum delta depth", .noneg = true },
    .{ .long = "active-branches", .kind = .callback, .cb = cbActive, .argh = "n", .help = "maximum number of branches to maintain active", .noneg = true },
    po.group("Marks"),
    .{ .long = "import-marks", .kind = .callback, .cb = cbImportMarks, .argh = "file", .help = "import marks from <file>", .noneg = true },
    .{ .long = "import-marks-if-exists", .kind = .callback, .cb = cbImportMarksIfExists, .argh = "file", .help = "import marks from <file> if it exists", .noneg = true },
    .{ .long = "export-marks", .kind = .callback, .cb = cbExportMarks, .argh = "file", .help = "dump marks to <file>", .noneg = true },
    po.boolean(0, "relative-marks", &opt_relative, "are --(import|export)-marks= paths relative to '.git/info/fast-import'?"),
    po.group("Submodule rewrite"),
    .{ .long = "rewrite-submodules-from", .kind = .callback, .cb = cbSubFrom, .argh = "name:filename", .help = "rewrite object IDs for submodule <name> from <filename>", .noneg = true },
    .{ .long = "rewrite-submodules-to", .kind = .callback, .cb = cbSubTo, .argh = "name:filename", .help = "rewrite object IDs for submodule <name> to <filename>", .noneg = true },
    po.group("Signing"),
    .{ .long = "signed-commits", .kind = .callback, .cb = cbSignedCommits, .argh = "mode", .help = "how to handle signed commits", .noneg = true },
    .{ .long = "signed-tags", .kind = .callback, .cb = cbSignedTags, .argh = "mode", .help = "how to handle signed tags", .noneg = true },
    .{ .long = "allow-unsafe-features", .kind = .boolean, .b = &opt_unsafe, .help = "allow unsafe mark commands from the stream", .hidden = true, .noneg = true },
    .{ .long = "export-pack-edges", .kind = .callback, .cb = cbPackEdges, .argh = "file", .help = "dump edge commits to <file>", .hidden = true, .noneg = true },
    .{ .long = "cat-blob-fd", .kind = .callback, .cb = cbCatBlobFd, .argh = "fd", .help = "write some responses to <fd> instead of stdout", .hidden = true, .noneg = true },
};

fn parseArgv() void {
    opt_stats = show_stats;
    opt_force = force_update;
    opt_done = require_explicit_termination;
    opt_relative = relative_marks_paths;
    const rest = po.parse(cmd_args, &options, &usage_str, .{});
    if (rest.len > 0) po.usageWithOptions(&usage_str, &options);
    show_stats = opt_stats;
    force_update = opt_force;
    require_explicit_termination = opt_done;
    relative_marks_paths = opt_relative;
    seen_data_command = true;
    if (import_marks_file != null) readMarks();
    buildMarkMap();
}

fn buildMarkMap() void {
    sub_oid_map = .empty;
    for (sub_marks_from.items) |*from| {
        var to: ?*SubMarks = null;
        for (sub_marks_to.items) |*t| {
            if (util.eql(t.name, from.name)) to = t;
        }
        const tm = to orelse util.die("missing to marks for submodule '{s}'", .{from.name});
        var it = from.map.iterator();
        while (it.next()) |kv| {
            const too = tm.map.get(kv.key_ptr.*) orelse util.die("mark :{d} not declared", .{kv.key_ptr.*});
            const r = sub_oid_map.getOrPut(gpa, kv.value_ptr.*) catch util.oom();
            if (!r.found_existing) r.value_ptr.* = too;
        }
    }
}

// ------------------------------------------------------------------ crash report

fn writeCrashReport(msg: []const u8) void {
    const pid = std.c.getpid();
    const loc = repo_mod.repo().gitPath(util.fmt("fast_import_crash_{d}", .{pid}));
    var b: util.Buf = .empty;
    util.bufAppend(&b, "fast-import crash report:\n");
    util.bufPrint(&b, "    fast-import process: {d}\n", .{pid});
    util.bufPrint(&b, "    parent process     : {d}\n", .{std.c.getppid()});
    util.bufPrint(&b, "    at {s}\n", .{date.showDate(os.now(), 0, date.DateMode.of(.iso8601))});
    util.bufAppend(&b, "\n");
    util.bufPrint(&b, "fatal: {s}\n", .{msg});
    util.bufAppend(&b, "\nMost Recent Commands Before Crash\n---------------------------------\n");
    for (cmd_hist.items, 0..) |c, i| {
        util.bufAppend(&b, if (i + 1 == cmd_hist.items.len) "* " else "  ");
        util.bufAppend(&b, c);
        util.bufByte(&b, '\n');
    }
    util.bufAppend(&b, "\nActive Branch LRU\n-----------------\n");
    util.bufPrint(&b, "    active_branches = {d} cur, {d} max\n\n", .{ cur_active_branches, max_active_branches });
    util.bufAppend(&b, "  pos  clock name\n  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    var lu: u64 = 0;
    var ap = active_branches;
    while (ap) |br| : (ap = br.active_next) {
        lu += 1;
        util.bufPrint(&b, "  {d:>2}) {d:>6} {s}\n", .{ lu, br.last_commit, br.name });
    }
    util.bufAppend(&b, "\nInactive Branches\n-----------------\n");
    for (branch_table) |head| {
        var bp = head;
        while (bp) |br| : (bp = br.table_next) {
            util.bufPrint(&b, "{s}:\n  status      :", .{br.name});
            if (br.active) util.bufAppend(&b, " active");
            if (br.branch_tree.tree != null) util.bufAppend(&b, " loaded");
            if (hash.isZero(br.branch_tree.versions[1].oid)) util.bufAppend(&b, " dirty");
            util.bufByte(&b, '\n');
            util.bufPrint(&b, "  tip commit  : {s}\n", .{hash.hex(br.oid)});
            util.bufPrint(&b, "  old tree    : {s}\n", .{hash.hex(br.branch_tree.versions[0].oid)});
            util.bufPrint(&b, "  cur tree    : {s}\n", .{hash.hex(br.branch_tree.versions[1].oid)});
            util.bufPrint(&b, "  commit clock: {d}\n", .{br.last_commit});
            util.bufAppend(&b, "  last pack   : ");
            if (br.pack_id < MAX_PACK_ID) util.bufPrint(&b, "{d}", .{br.pack_id});
            util.bufAppend(&b, "\n\n");
        }
    }
    if (first_tag != null) {
        util.bufAppend(&b, "\nAnnotated Tags\n--------------\n");
        var tp = first_tag;
        while (tp) |t| : (tp = t.next) util.bufPrint(&b, "{s} {s}\n", .{ hash.hex(t.oid), t.name });
    }
    util.bufAppend(&b, "\nMarks\n-----\n");
    if (export_marks_file) |f| {
        util.bufPrint(&b, "  exported to {s}\n", .{f});
    } else {
        for (sortedMarks()) |m| util.bufPrint(&b, ":{d} {s}\n", .{ m, hash.hex(marks.get(m).?.oid) });
    }
    util.bufAppend(&b, "\n-------------------\nEND OF CRASH REPORT\n");
    os.writeFile(loc, b.items, 0o666) catch {
        util.err("can't write crash report {s}: {s}", .{ loc, os.lastErr() });
        return;
    };
    util.eprint("fast-import: dumping crash report to {s}\n", .{loc});
}

fn dieNicely(msg: []const u8) void {
    writeCrashReport(msg);
    endPackfile();
    dumpMarks();
}

// ------------------------------------------------------------------ main

pub fn cmdFastImport(args: []const []const u8) u8 {
    if (args.len == 2 and util.eql(args[1], "-h")) po.usageExit(&usage_str, &options, false);
    cmd_args = args[1..];
    gitPackConfig();
    for (cmd_args) |a| {
        if (a.len == 0 or a[0] != '-' or util.eql(a, "--")) break;
        if (util.eql(a, "--allow-unsafe-features")) allow_unsafe_features = true;
    }
    util.die_hook = dieNicely;

    while (readNextCommand()) {
        const cb = command_buf;
        if (util.eql(cb, "blob")) {
            parseNewBlob();
        } else if (util.skipPrefix(cb, "commit ")) |v| {
            parseNewCommit(v);
        } else if (util.skipPrefix(cb, "tag ")) |v| {
            parseNewTag(v);
        } else if (util.skipPrefix(cb, "reset ")) |v| {
            parseResetBranch(v);
        } else if (util.skipPrefix(cb, "ls ")) |v| {
            parseLs(v, null);
        } else if (util.skipPrefix(cb, "cat-blob ")) |v| {
            parseCatBlob(v);
        } else if (util.skipPrefix(cb, "get-mark ")) |v| {
            parseGetMark(v);
        } else if (util.eql(cb, "checkpoint")) {
            skipOptionalLf();
            checkpoint();
        } else if (util.eql(cb, "done")) {
            break;
        } else if (util.eql(cb, "alias")) {
            parseAlias();
        } else if (util.startsWith(cb, "progress ")) {
            parseProgress();
        } else if (util.skipPrefix(cb, "feature ")) |v| {
            parseFeature(v);
        } else if (util.skipPrefix(cb, "option git ")) |v| {
            parseOption(v);
        } else if (util.startsWith(cb, "option ")) {
            // ignore non-git options
        } else {
            util.die("unsupported command: {s}", .{cb});
        }
    }

    if (!seen_data_command) parseArgv();

    if (require_explicit_termination and input.eof) util.die("stream ends early", .{});

    util.die_hook = null;
    endPackfile();
    dumpBranches();
    dumpTags();
    dumpMarks();
    if (pack_edges_fd >= 0) os.close(pack_edges_fd);

    if (show_stats) printStats();
    return if (failure) 1 else 0;
}

fn printStats() void {
    var total: u64 = 0;
    var dups: u64 = 0;
    for (object_count_by_type) |c| total += c;
    for (duplicate_count_by_type) |c| dups += c;
    var shift: u6 = 0;
    while ((max_mark_seen >> shift) >= 1024) shift += 10;
    const marks_cap: u64 = (@as(u64, 1) << shift) * 1024;
    const B = struct { t: ObjType, n: []const u8 };
    const rows = [_]B{ .{ .t = .blob, .n = "blobs  " }, .{ .t = .tree, .n = "trees  " }, .{ .t = .commit, .n = "commits" }, .{ .t = .tag, .n = "tags   " } };
    var b: util.Buf = .empty;
    util.bufAppend(&b, "fast-import statistics:\n");
    util.bufAppend(&b, "---------------------------------------------------------------------\n");
    const alloc_shown = (alloc_count / 5000 + 1) * 5000;
    util.bufPrint(&b, "Alloc'd objects: {d:>10}\n", .{alloc_shown});
    util.bufPrint(&b, "Total objects:   {d:>10} ({d:>10} duplicates                  )\n", .{ total, dups });
    for (rows) |r| {
        const i = typeIdx(r.t);
        util.bufPrint(&b, "      {s}:   {d:>10} ({d:>10} duplicates {d:>10} deltas of {d:>10} attempts)\n", .{ r.n, object_count_by_type[i], duplicate_count_by_type[i], @as(u64, 0), @as(u64, 0) });
    }
    util.bufPrint(&b, "Total branches:  {d:>10} ({d:>10} loads     )\n", .{ branch_count, branch_load_count });
    util.bufPrint(&b, "      marks:     {d:>10} ({d:>10} unique    )\n", .{ marks_cap, marks_set_count });
    util.bufPrint(&b, "      atoms:     {d:>10}\n", .{atoms.count()});
    const objkb = alloc_shown * 32 / 1024;
    util.bufPrint(&b, "Memory total:    {d:>10} KiB\n", .{objkb + 2048});
    util.bufPrint(&b, "       pools:    {d:>10} KiB\n", .{@as(u64, 2048)});
    util.bufPrint(&b, "     objects:    {d:>10} KiB\n", .{objkb});
    util.bufAppend(&b, "---------------------------------------------------------------------\n");
    util.bufPrint(&b, "pack_report: getpagesize()            = {d:>10}\n", .{@as(u64, 4096)});
    util.bufPrint(&b, "pack_report: core.packedGitWindowSize = {d:>10}\n", .{@as(u64, 1024 * 1024 * 1024)});
    util.bufPrint(&b, "pack_report: core.packedGitLimit      = {d:>10}\n", .{@as(u64, 32 * 1024 * 1024 * 1024)});
    util.bufPrint(&b, "pack_report: pack_used_ctr            = {d:>10}\n", .{@as(u64, 0)});
    util.bufPrint(&b, "pack_report: pack_mmap_calls          = {d:>10}\n", .{@as(u64, 0)});
    util.bufPrint(&b, "pack_report: pack_open_windows        = {d:>10} / {d:>10}\n", .{ @as(u64, 0), @as(u64, 0) });
    util.bufPrint(&b, "pack_report: pack_mapped              = {d:>10} / {d:>10}\n", .{ @as(u64, 0), @as(u64, 0) });
    util.bufAppend(&b, "---------------------------------------------------------------------\n\n");
    util.ewrite(b.items);
}
