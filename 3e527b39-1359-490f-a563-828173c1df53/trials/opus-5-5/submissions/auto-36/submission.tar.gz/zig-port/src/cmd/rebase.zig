//! builtin/rebase.c: git rebase (merge backend via the sequencer, apply
//! backend via `git am`).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const cn = @import("../commitnode.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const seq = @import("../sequencer.zig");
const hook = @import("../hook.zig");
const wtstatus = @import("../wtstatus.zig");
const creach = @import("../commitreach.zig");
const commit_mod = @import("../commit.zig");
const branchstate = @import("../branchstate.zig");
const branchcreate = @import("../branchcreate.zig");
const worktree = @import("../worktree.zig");
const transport = @import("../transport.zig");
const tracking = @import("../tracking.zig");
const trailer = @import("../trailer.zig");
const proc = @import("../proc.zig");
const Oid = hash.Oid;
const Commit = cn.Commit;
const gpa = util.gpa;

const usage = [_][]const u8{
    "git rebase [-i] [options] [--exec <cmd>] [--onto <newbase> | --keep-base] [<upstream> [<branch>]]",
    "git rebase [-i] [options] [--exec <cmd>] [--onto <newbase>] --root [<branch>]",
    "git rebase --continue | --abort | --skip | --edit-todo",
};

const RebaseType = enum { unspecified, apply, merge };
const EmptyType = enum { unspecified, drop, keep, stop };
const Action = enum { none, @"continue", skip, abort, quit, edit_todo, show_current_patch };

const NO_QUIET: i32 = 1 << 0;
const VERBOSE: i32 = 1 << 1;
const DIFFSTAT: i32 = 1 << 2;
const FORCE: i32 = 1 << 3;
const INTERACTIVE_EXPLICIT: i32 = 1 << 4;

const Options = struct {
    typ: RebaseType = .unspecified,
    empty: EmptyType = .unspecified,
    default_backend: []const u8 = "merge",
    state_dir: []const u8 = "",
    upstream: ?*Commit = null,
    upstream_name: ?[]const u8 = null,
    upstream_arg: []const u8 = "",
    head_name: ?[]const u8 = null,
    orig_head: ?*Commit = null,
    onto: ?*Commit = null,
    onto_name: ?[]const u8 = null,
    revisions: []const u8 = "",
    switch_to: ?[]const u8 = null,
    root: bool = false,
    root_with_onto: bool = false,
    squash_onto: ?Oid = null,
    restrict_revision: ?*Commit = null,
    dont_finish_rebase: bool = false,
    flags: i32 = NO_QUIET,
    git_am_opts: std.ArrayList([]const u8) = .empty,
    action: Action = .none,
    action_name: []const u8 = "",
    reflog_action: []const u8 = "rebase",
    signoff: bool = false,
    trailer_args: std.ArrayList([]const u8) = .empty,
    allow_rerere_autoupdate: i32 = 0,
    keep_empty: bool = false,
    autosquash: i32 = -1,
    gpg_sign_opt: ?[]const u8 = null,
    autostash: bool = false,
    committer_date_is_author_date: bool = false,
    ignore_date: bool = false,
    exec: std.ArrayList([]const u8) = .empty,
    allow_empty_message: bool = true,
    rebase_merges: i32 = -1,
    rebase_cousins: i32 = 0,
    strategy: ?[]const u8 = null,
    strategy_opts: std.ArrayList([]const u8) = .empty,
    git_format_patch_opt: std.ArrayList([]const u8) = .empty,
    reschedule_failed_exec: bool = false,
    reapply_cherry_picks: i32 = -1,
    fork_point: i32 = -1,
    update_refs: i32 = -1,
    config_autosquash: bool = false,
    config_rebase_merges: i32 = -1,
    config_update_refs: i32 = -1,
};

var options: Options = .{};

fn gitPath(name: []const u8) []const u8 {
    return repo_mod.repo().gitPath(name);
}
fn applyDir() []const u8 {
    return gitPath("rebase-apply");
}
fn mergeDir() []const u8 {
    return gitPath("rebase-merge");
}
fn statePath(name: []const u8) []const u8 {
    return util.concat(&.{ options.state_dir, "/", name });
}

fn hexOf(c: *Commit) []const u8 {
    return util.dupe(&c.hex());
}

fn lookupCommitReferenceByName(name: []const u8) ?*Commit {
    const oid = revparse.getOid(name) orelse return null;
    const c = cn.lookupCommitReference(oid) orelse return null;
    if (!cn.parse(c)) return null;
    return c;
}

// ---------------------------------------------------------------------------
// replay opts

fn getReplayOpts() seq.Opts {
    var r: seq.Opts = .{ .action = .rebase_i };
    seq.initConfig(&r);
    r.signoff = options.signoff;
    r.trailer_args.appendSlice(gpa, options.trailer_args.items) catch util.oom();
    r.allow_ff = options.flags & FORCE == 0;
    if (options.allow_rerere_autoupdate != 0) r.allow_rerere_auto = options.allow_rerere_autoupdate;
    r.allow_empty = true;
    r.allow_empty_message = options.allow_empty_message;
    r.drop_redundant_commits = options.empty == .drop;
    r.keep_redundant_commits = options.empty == .keep;
    r.quiet = options.flags & NO_QUIET == 0;
    r.verbose = options.flags & VERBOSE != 0;
    r.reschedule_failed_exec = options.reschedule_failed_exec;
    r.committer_date_is_author_date = options.committer_date_is_author_date;
    r.ignore_date = options.ignore_date;
    r.gpg_sign = options.gpg_sign_opt;
    r.reflog_action = options.reflog_action;
    r.strategy = null;
    if (options.strategy) |s| {
        r.strategy = s;
    } else if (r.default_strategy) |d| {
        r.strategy = d;
        r.default_strategy = null;
    }
    r.xopts.appendSlice(gpa, options.strategy_opts.items) catch util.oom();
    if (options.squash_onto) |s| {
        r.squash_onto = s;
        r.have_squash_onto = true;
    }
    return r;
}

fn editTodoFile(flags: u32, r: *seq.Opts) i32 {
    return seq.editTodoFile(flags, r);
}

fn initBasicState(r: *seq.Opts, head_name: []const u8, onto: *Commit, orig_head: Oid) i32 {
    const md = mergeDir();
    if (!os.isDir(md)) {
        if (!os.mkdirAll(md)) {
            util.err("could not create temporary {s}", .{md});
            return -1;
        }
    }
    _ = refs.deleteReflog("REBASE_HEAD");
    os.writeFile(seq.rebasePath("interactive"), "", 0o666) catch {
        util.err("could not mark as interactive", .{});
        return -1;
    };
    seq.writeBasicState(r, head_name, onto.oid(), orig_head);
    return 0;
}

fn doInteractiveRebase(flags: u32) i32 {
    var replay = getReplayOpts();
    const orig = options.orig_head.?;
    const base_rev = options.upstream orelse options.onto.?;
    const revisions = util.fmt("{s}...{s}", .{ hexOf(base_rev), hexOf(orig) });
    const shorthead = revparse.abbrev(orig.oid(), revparse.defaultAbbrev());
    const shortrevisions = if (options.upstream != null)
        util.fmt("{s}..{s}", .{ revparse.abbrev(base_rev.oid(), revparse.defaultAbbrev()), shorthead })
    else
        util.dupe(shorthead);

    var args: std.ArrayList([]const u8) = .empty;
    args.append(gpa, "") catch util.oom();
    args.append(gpa, revisions) catch util.oom();
    if (options.restrict_revision) |rr| args.append(gpa, util.fmt("^{s}", .{hexOf(rr)})) catch util.oom();

    var todo: seq.TodoList = .{};
    if (seq.makeScript(&todo.buf, args.items, flags) != 0) {
        util.err("could not generate todo list", .{});
        return -1;
    }
    if (initBasicState(&replay, options.head_name orelse "detached HEAD", options.onto.?, orig.oid()) != 0)
        return -1;
    if (options.upstream == null) {
        if (options.squash_onto) |s| {
            os.writeFile(seq.rebasePath("squash-onto"), util.fmt("{s}\n", .{hash.hex(s)}), 0o666) catch {};
        }
    }
    index_mod.discard();
    if (seq.parseInsnBuffer(&replay, &todo) != 0) util.die("BUG: unusable todo list", .{});
    return seq.completeAction(&replay, flags, shortrevisions, options.onto_name.?, options.onto.?, orig.oid(), options.exec.items, options.autosquash > 0, options.update_refs > 0, &todo);
}

fn runSequencerRebase() i32 {
    var flags: u32 = 0;
    var abbreviate_commands = false;
    if (repo_mod.cfg.get("rebase.abbreviatecommands")) |v| abbreviate_commands = config.configBool("rebase.abbreviatecommands", v);
    if (options.keep_empty) flags |= seq.TODO_LIST_KEEP_EMPTY;
    if (abbreviate_commands) flags |= seq.TODO_LIST_ABBREVIATE_CMDS;
    if (options.rebase_merges > 0) flags |= seq.TODO_LIST_REBASE_MERGES;
    if (options.rebase_cousins > 0) flags |= seq.TODO_LIST_REBASE_COUSINS;
    if (options.root_with_onto) flags |= seq.TODO_LIST_ROOT_WITH_ONTO;
    if (options.reapply_cherry_picks > 0) flags |= seq.TODO_LIST_REAPPLY_CHERRY_PICKS;
    if (options.flags & NO_QUIET != 0) flags |= seq.TODO_LIST_WARN_SKIPPED_CHERRY_PICKS;

    switch (options.action) {
        .none => {
            if (options.onto == null and options.upstream == null)
                util.die("a base commit must be provided with --upstream or --onto", .{});
            return doInteractiveRebase(flags);
        },
        .skip, .@"continue" => {
            if (options.action == .skip) @import("../rerere.zig").clear();
            var r = getReplayOpts();
            return seq.sequencerContinue(&r);
        },
        .edit_todo => {
            var r = getReplayOpts();
            return editTodoFile(flags, &r);
        },
        .show_current_patch => {
            const res = runGit(&.{ "show", "REBASE_HEAD", "--" }, .{});
            return @intCast(res.status);
        },
        else => util.die("BUG: invalid command", .{}),
    }
}

fn runGit(args: []const []const u8, o: os.SpawnOpts) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    util.flushStdout();
    index_mod.discard();
    const r = os.run(argv.items, o);
    index_mod.discard();
    return r;
}

fn isMerge() bool {
    return options.typ == .merge;
}

fn implyMerge(option: []const u8) void {
    switch (options.typ) {
        .apply => util.die("{s} requires the merge backend", .{option}),
        .merge => {},
        .unspecified => options.typ = .merge,
    }
}

// ---------------------------------------------------------------------------
// state

fn readOneliner(path: []const u8) ?[]const u8 {
    return seq.readOneliner(path, true, false);
}

fn readBasicState() i32 {
    const head_name = readOneliner(statePath("head-name")) orelse return -1;
    const onto_s = readOneliner(statePath("onto")) orelse return -1;
    options.head_name = if (util.startsWith(head_name, "refs/")) head_name else null;
    const onto_oid = hash.fromHex(onto_s);
    options.onto = if (onto_oid) |o| cn.lookupCommit(o) else null;
    if (options.onto == null) {
        util.err("invalid onto: '{s}'", .{onto_s});
        return -1;
    }
    var buf: []const u8 = undefined;
    if (os.exists(statePath("orig-head"))) {
        buf = readOneliner(statePath("orig-head")) orelse return -1;
    } else {
        buf = readOneliner(statePath("head")) orelse return -1;
    }
    const oh = hash.fromHex(buf);
    options.orig_head = if (oh) |o| cn.lookupCommit(o) else null;
    if (options.orig_head == null) {
        util.err("invalid orig-head: '{s}'", .{buf});
        return -1;
    }
    if (os.exists(statePath("quiet"))) options.flags &= ~NO_QUIET else options.flags |= NO_QUIET;
    if (os.exists(statePath("verbose"))) options.flags |= VERBOSE;
    if (os.exists(statePath("signoff"))) {
        options.signoff = true;
        options.flags |= FORCE;
    }
    if (os.exists(statePath("allow_rerere_autoupdate"))) {
        const v = readOneliner(statePath("allow_rerere_autoupdate")) orelse return -1;
        if (util.eql(v, "--rerere-autoupdate")) {
            options.allow_rerere_autoupdate = seq.RERERE_AUTOUPDATE;
        } else if (util.eql(v, "--no-rerere-autoupdate")) {
            options.allow_rerere_autoupdate = seq.RERERE_NOAUTOUPDATE;
        } else util.warn("ignoring invalid allow_rerere_autoupdate: '{s}'", .{v});
    }
    if (os.exists(statePath("gpg_sign_opt"))) {
        options.gpg_sign_opt = readOneliner(statePath("gpg_sign_opt")) orelse return -1;
    }
    return 0;
}

fn wfile(path: []const u8, data: []const u8) void {
    os.writeFile(path, util.concat(&.{ data, "\n" }), 0o666) catch util.die("could not write '{s}'", .{path});
}

fn rebaseWriteBasicState() void {
    wfile(statePath("head-name"), options.head_name orelse "detached HEAD");
    wfile(statePath("onto"), if (options.onto) |o| hexOf(o) else "");
    wfile(statePath("orig-head"), hexOf(options.orig_head.?));
    if (options.flags & NO_QUIET == 0) wfile(statePath("quiet"), "");
    if (options.flags & VERBOSE != 0) wfile(statePath("verbose"), "");
    if (options.allow_rerere_autoupdate > 0)
        wfile(statePath("allow_rerere_autoupdate"), if (options.allow_rerere_autoupdate == seq.RERERE_AUTOUPDATE) "--rerere-autoupdate" else "--no-rerere-autoupdate");
    if (options.gpg_sign_opt) |g| wfile(statePath("gpg_sign_opt"), g);
    if (options.signoff) wfile(statePath("signoff"), "--signoff");
}

fn cleanupAutostash() i32 {
    const path = statePath("autostash");
    if (!os.exists(path)) return 0;
    const ret = seq.applyAutostash(path);
    os.removeTree(options.state_dir);
    return ret;
}

fn finishRebase() i32 {
    refs.deleteRef("REBASE_HEAD", null, refs.F_NO_DEREF, null) catch {};
    refs.deleteRef("AUTO_MERGE", null, refs.F_NO_DEREF, null) catch {};
    _ = seq.applyAutostash(statePath("autostash"));
    if (options.typ == .merge) {
        var r: seq.Opts = .{ .action = .rebase_i };
        return seq.removeState(&r);
    }
    os.removeTree(options.state_dir);
    if (os.exists(options.state_dir)) {
        util.err("could not remove '{s}'", .{options.state_dir});
        return -1;
    }
    return 0;
}

fn moveToOriginalBranch() i32 {
    const hn = options.head_name orelse return 0;
    const onto = options.onto orelse util.die("BUG: move_to_original_branch without onto", .{});
    return seq.resetWorkingTree(.{
        .branch = hn,
        .flags = seq.RESET_REFS_ONLY | seq.RESET_UPDATE_HEAD,
        .branch_msg = util.fmt("{s} (finish): {s} onto {s}", .{ options.reflog_action, hn, hexOf(onto) }),
        .head_msg = util.fmt("{s} (finish): returning to {s}", .{ options.reflog_action, hn }),
    });
}

fn runAm() i32 {
    const env = [_][2][]const u8{.{ "GIT_REFLOG_ACTION", util.fmt("{s} (pick)", .{options.reflog_action}) }};
    var am: std.ArrayList([]const u8) = .empty;
    am.append(gpa, "am") catch util.oom();
    const resolvemsg = util.concat(&.{ "--resolvemsg=", seq.rebase_resolvemsg });
    switch (options.action) {
        .@"continue", .skip => {
            am.append(gpa, if (options.action == .skip) "--skip" else "--resolved") catch util.oom();
            am.append(gpa, resolvemsg) catch util.oom();
            if (options.action == .@"continue") {
                if (options.gpg_sign_opt) |g| am.append(gpa, g) catch util.oom();
            }
            const r = runGit(am.items, .{ .env = &env });
            if (r.status != 0) return @intCast(r.status);
            return moveToOriginalBranch();
        },
        .show_current_patch => {
            am.append(gpa, "--show-current-patch") catch util.oom();
            const r = runGit(am.items, .{ .env = &env });
            return @intCast(r.status);
        },
        else => {},
    }

    const rebased_patches = gitPath("rebased-patches");
    var fp: std.ArrayList([]const u8) = .empty;
    fp.appendSlice(gpa, &.{ "format-patch", "-k", "--stdout", "--full-index", "--cherry-pick", "--right-only", "--default-prefix", "--no-renames", "--no-cover-letter", "--pretty=mboxrd", "--topo-order", "--no-base" }) catch util.oom();
    fp.appendSlice(gpa, options.git_format_patch_opt.items) catch util.oom();
    const base = if (options.root) options.onto.? else options.upstream.?;
    fp.append(gpa, util.fmt("{s}...{s}", .{ hexOf(base), hexOf(options.orig_head.?) })) catch util.oom();
    if (options.restrict_revision) |rr| fp.append(gpa, util.fmt("^{s}", .{hexOf(rr)})) catch util.oom();
    const fr = runGit(fp.items, .{ .capture_stdout = true, .no_stdin = true });
    if (fr.status != 0) {
        _ = os.unlink(rebased_patches);
        _ = seq.resetWorkingTree(.{
            .oid = options.orig_head.?.oid(),
            .branch = options.head_name,
            .default_reflog_action = options.reflog_action,
            .flags = seq.RESET_UPDATE_HEAD,
        });
        util.err("\ngit encountered an error while preparing the patches to replay\nthese revisions:\n\n    {s}\n\nAs a result, git cannot rebase them.", .{options.revisions});
        return @intCast(fr.status);
    }
    os.writeFile(rebased_patches, fr.stdout, 0o666) catch {
        util.err("could not open '{s}' for writing", .{rebased_patches});
        return -1;
    };

    am.appendSlice(gpa, options.git_am_opts.items) catch util.oom();
    am.append(gpa, "--rebasing") catch util.oom();
    am.append(gpa, resolvemsg) catch util.oom();
    am.append(gpa, "--patch-format=mboxrd") catch util.oom();
    if (options.allow_rerere_autoupdate == seq.RERERE_AUTOUPDATE) {
        am.append(gpa, "--rerere-autoupdate") catch util.oom();
    } else if (options.allow_rerere_autoupdate == seq.RERERE_NOAUTOUPDATE) am.append(gpa, "--no-rerere-autoupdate") catch util.oom();
    if (options.gpg_sign_opt) |g| am.append(gpa, g) catch util.oom();
    const r = runGit(am.items, .{ .env = &env, .stdin_data = fr.stdout });
    _ = os.unlink(rebased_patches);
    if (r.status == 0) return moveToOriginalBranch();
    if (os.isDir(options.state_dir)) rebaseWriteBasicState();
    return @intCast(r.status);
}

fn runSpecificRebase() i32 {
    var status: i32 = 0;
    if (options.typ == .merge) {
        if (options.flags & INTERACTIVE_EXPLICIT == 0) os.setEnv("GIT_SEQUENCE_EDITOR", ":");
        if (options.gpg_sign_opt) |g| options.gpg_sign_opt = if (g.len >= 2) g[2..] else "";
        status = runSequencerRebase();
    } else {
        status = runAm();
    }
    if (options.dont_finish_rebase) {
        // nothing
    } else if (options.typ == .merge) {
        // merge backend cleans up after itself
    } else if (status == 0) {
        if (!os.exists(statePath("stopped-sha"))) _ = finishRebase();
    } else if (status == 2) {
        _ = seq.applyAutostash(statePath("autostash"));
        os.removeTree(options.state_dir);
        util.die("Nothing to do", .{});
    }
    return if (status != 0) -1 else 0;
}

fn parseRebaseMergesValue(v: []const u8) void {
    if (util.eql(v, "no-rebase-cousins")) {
        options.rebase_cousins = 0;
    } else if (util.eql(v, "rebase-cousins")) {
        options.rebase_cousins = 1;
    } else util.die("Unknown rebase-merges mode: {s}", .{v});
}

fn rebaseConfig() void {
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        const v = e.value;
        if (util.eql(k, "rebase.stat")) {
            if (config.configBool(k, v)) options.flags |= DIFFSTAT else options.flags &= ~DIFFSTAT;
        } else if (util.eql(k, "rebase.autosquash")) {
            options.config_autosquash = config.configBool(k, v);
        } else if (util.eql(k, "commit.gpgsign")) {
            options.gpg_sign_opt = if (config.configBool(k, v)) "-S" else null;
        } else if (util.eql(k, "rebase.autostash")) {
            options.autostash = config.configBool(k, v);
        } else if (util.eql(k, "rebase.rebasemerges")) {
            options.config_rebase_merges = config.parseMaybeBool(v);
            if (options.config_rebase_merges < 0) {
                options.config_rebase_merges = 1;
                parseRebaseMergesValue(v orelse "");
            } else options.rebase_cousins = 0;
        } else if (util.eql(k, "rebase.updaterefs")) {
            options.config_update_refs = if (config.configBool(k, v)) 1 else 0;
        } else if (util.eql(k, "rebase.reschedulefailedexec")) {
            options.reschedule_failed_exec = config.configBool(k, v);
        } else if (util.eql(k, "rebase.forkpoint")) {
            options.fork_point = if (config.configBool(k, v)) -1 else 0;
        } else if (util.eql(k, "rebase.backend")) {
            options.default_backend = v orelse util.die("missing value for '{s}'", .{k});
        }
    }
}

fn checkoutUpToDate() i32 {
    var flags: u32 = seq.RESET_RUN_POST_CHECKOUT_HOOK | seq.RESET_UPDATE_HEAD;
    if (options.head_name == null) flags |= seq.RESET_DETACH;
    if (seq.resetWorkingTree(.{
        .oid = options.orig_head.?.oid(),
        .branch = options.head_name,
        .flags = flags,
        .head_msg = util.fmt("{s}: checkout {s}", .{ options.reflog_action, options.switch_to.? }),
    }) < 0) {
        util.err("could not switch to {s}", .{options.switch_to.?});
        return -1;
    }
    return 0;
}

fn isLinearHistory(from: *Commit, to_in: *Commit) bool {
    var to: ?*Commit = to_in;
    while (to) |t| {
        if (t == from) break;
        _ = cn.parse(t);
        const p = t.parents orelse return true;
        if (p.next != null) return false;
        to = p.item;
    }
    return true;
}

fn canFastForward(onto: *Commit, upstream: ?*Commit, restrict: ?*Commit, head: *Commit, branch_base: Oid) bool {
    if (hash.isZero(branch_base)) return false;
    if (!hash.eql(branch_base, onto.oid())) return false;
    if (restrict) |r| if (!hash.eql(r.oid(), branch_base)) return false;
    const up = upstream orelse return false;
    const mb = creach.getMergeBases(up, head) orelse return false;
    if (mb.next != null) return false;
    if (!hash.eql(onto.oid(), mb.item.oid())) return false;
    return isLinearHistory(onto, head);
}

fn fillBranchBase() Oid {
    const mb = creach.getMergeBases(options.onto.?, options.orig_head.?) orelse return hash.zero;
    if (mb.next != null) return hash.zero;
    return mb.item.oid();
}

// ---------------------------------------------------------------------------
// option callbacks

var keep_base = false;
var ok_to_skip_pre_rebase = false;
var ignore_whitespace = false;
var gpg_sign: ?[]const u8 = null;
var reschedule_failed_exec: i32 = -1;
var preserve_merges_selected: i32 = 0;
var strategy_opt: ?[]const u8 = null;
var autosquash_i: i32 = -1;

fn setAction(a: Action, name: []const u8) void {
    if (options.action != .none and options.action != a) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ name, options.action_name });
        os.exit(129);
    }
    options.action = a;
    options.action_name = name;
}
fn cbContinue(_: ?[]const u8, _: bool) void {
    setAction(.@"continue", "--continue");
}
fn cbSkip(_: ?[]const u8, _: bool) void {
    setAction(.skip, "--skip");
}
fn cbAbort(_: ?[]const u8, _: bool) void {
    setAction(.abort, "--abort");
}
fn cbQuit(_: ?[]const u8, _: bool) void {
    setAction(.quit, "--quit");
}
fn cbEditTodo(_: ?[]const u8, _: bool) void {
    setAction(.edit_todo, "--edit-todo");
}
fn cbShowCurrentPatch(_: ?[]const u8, _: bool) void {
    setAction(.show_current_patch, "--show-current-patch");
}
fn cbApply(_: ?[]const u8, _: bool) void {
    if (options.typ != .unspecified and options.typ != .apply) util.die("apply options and merge options cannot be used together", .{});
    options.typ = .apply;
}
fn cbMerge(_: ?[]const u8, _: bool) void {
    if (options.typ != .unspecified and options.typ != .merge) util.die("apply options and merge options cannot be used together", .{});
    options.typ = .merge;
}
fn cbInteractive(_: ?[]const u8, _: bool) void {
    if (options.typ != .unspecified and options.typ != .merge) util.die("apply options and merge options cannot be used together", .{});
    options.typ = .merge;
    options.flags |= INTERACTIVE_EXPLICIT;
}
fn cbRerere(_: ?[]const u8, unset: bool) void {
    options.allow_rerere_autoupdate = if (unset) seq.RERERE_NOAUTOUPDATE else seq.RERERE_AUTOUPDATE;
}
fn cbEmpty(arg: ?[]const u8, _: bool) void {
    const v = arg.?;
    if (std.ascii.eqlIgnoreCase(v, "drop")) {
        options.empty = .drop;
    } else if (std.ascii.eqlIgnoreCase(v, "keep")) {
        options.empty = .keep;
    } else if (std.ascii.eqlIgnoreCase(v, "stop")) {
        options.empty = .stop;
    } else if (std.ascii.eqlIgnoreCase(v, "ask")) {
        util.warn("--empty=ask is deprecated; use '--empty=stop' instead.", .{});
        options.empty = .stop;
    } else util.die("unrecognized empty type '{s}'; valid values are \"drop\", \"keep\", and \"stop\".", .{v});
}
fn cbKeepEmpty(_: ?[]const u8, unset: bool) void {
    implyMerge(if (unset) "--no-keep-empty" else "--keep-empty");
    options.keep_empty = !unset;
}
fn cbRebaseMerges(arg: ?[]const u8, unset: bool) void {
    options.rebase_merges = if (unset) 0 else 1;
    options.rebase_cousins = 0;
    if (arg) |a| {
        if (a.len == 0) {
            util.warn("--rebase-merges with an empty string argument is deprecated and will stop working in a future version of Git. Use --rebase-merges without an argument instead, which does the same thing.", .{});
            return;
        }
        parseRebaseMergesValue(a);
    }
}
fn cbC(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        options.git_am_opts.append(gpa, "--no-C") catch util.oom();
        return;
    }
    options.git_am_opts.append(gpa, util.concat(&.{ "-C", arg.? })) catch util.oom();
}
fn cbWhitespace(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        options.git_am_opts.append(gpa, "--no-whitespace") catch util.oom();
        return;
    }
    options.git_am_opts.append(gpa, util.concat(&.{ "--whitespace=", arg.? })) catch util.oom();
}
fn cbNoStat(_: ?[]const u8, unset: bool) void {
    if (unset) options.flags |= DIFFSTAT else options.flags &= ~DIFFSTAT;
}

const all_quiet_bits: i32 = NO_QUIET | VERBOSE | DIFFSTAT;

const rebase_options = [_]po.Opt{
    po.string(0, "onto", &options.onto_name, "revision", "rebase onto given branch instead of upstream"),
    po.boolean(0, "keep-base", &keep_base, "use the merge-base of upstream and branch as the current base"),
    po.boolean(0, "no-verify", &ok_to_skip_pre_rebase, "allow pre-rebase hook to run"),
    .{ .short = 'q', .long = "quiet", .kind = .negbit, .i = &options.flags, .val = all_quiet_bits, .help = "be quiet. implies --no-stat" },
    .{ .short = 'v', .long = "verbose", .kind = .bit, .i = &options.flags, .val = all_quiet_bits, .help = "display a diffstat of what changed upstream" },
    .{ .short = 'n', .long = "no-stat", .kind = .callback, .cb = cbNoStat, .noarg = true, .help = "do not show diffstat of what changed upstream" },
    po.list(0, "trailer", &options.trailer_args, "trailer", "add custom trailer(s)"),
    po.boolean(0, "signoff", &options.signoff, "add a Signed-off-by trailer to each commit"),
    po.boolean(0, "committer-date-is-author-date", &options.committer_date_is_author_date, "make committer date match author date"),
    po.boolean(0, "reset-author-date", &options.ignore_date, "ignore author date and use current date"),
    .{ .long = "ignore-date", .kind = .boolean, .b = &options.ignore_date, .hidden = true, .help = "synonym of --reset-author-date" },
    .{ .short = 'C', .kind = .callback, .cb = cbC, .argh = "n", .help = "passed to 'git apply'" },
    po.boolean(0, "ignore-whitespace", &ignore_whitespace, "ignore changes in whitespace"),
    .{ .long = "whitespace", .kind = .callback, .cb = cbWhitespace, .argh = "action", .help = "passed to 'git apply'" },
    po.bit('f', "force-rebase", &options.flags, FORCE, "cherry-pick all commits, even if unchanged"),
    po.bit(0, "no-ff", &options.flags, FORCE, "cherry-pick all commits, even if unchanged"),
    .{ .long = "continue", .kind = .callback, .cb = cbContinue, .noarg = true, .noneg = true, .help = "continue" },
    .{ .long = "skip", .kind = .callback, .cb = cbSkip, .noarg = true, .noneg = true, .help = "skip current patch and continue" },
    .{ .long = "abort", .kind = .callback, .cb = cbAbort, .noarg = true, .noneg = true, .help = "abort and check out the original branch" },
    .{ .long = "quit", .kind = .callback, .cb = cbQuit, .noarg = true, .noneg = true, .help = "abort but keep HEAD where it is" },
    .{ .long = "edit-todo", .kind = .callback, .cb = cbEditTodo, .noarg = true, .noneg = true, .help = "edit the todo list during an interactive rebase" },
    .{ .long = "show-current-patch", .kind = .callback, .cb = cbShowCurrentPatch, .noarg = true, .noneg = true, .help = "show the patch file being applied or merged" },
    .{ .long = "apply", .kind = .callback, .cb = cbApply, .noarg = true, .noneg = true, .help = "use apply strategies to rebase" },
    .{ .short = 'm', .long = "merge", .kind = .callback, .cb = cbMerge, .noarg = true, .noneg = true, .help = "use merging strategies to rebase" },
    .{ .short = 'i', .long = "interactive", .kind = .callback, .cb = cbInteractive, .noarg = true, .noneg = true, .help = "let the user edit the list of commits to rebase" },
    .{ .short = 'p', .long = "preserve-merges", .kind = .set_int, .i = &preserve_merges_selected, .val = 1, .hidden = true, .help = "(REMOVED) was: try to recreate merges instead of ignoring them" },
    .{ .long = "rerere-autoupdate", .kind = .callback, .cb = cbRerere, .noarg = true, .help = "update the index with reused conflict resolution if possible" },
    .{ .long = "empty", .kind = .callback, .cb = cbEmpty, .argh = "(drop|keep|stop)", .literal_argh = true, .noneg = true, .help = "how to handle commits that become empty" },
    .{ .short = 'k', .long = "keep-empty", .kind = .callback, .cb = cbKeepEmpty, .noarg = true, .hidden = true, .help = "keep commits which start empty" },
    po.setInt(0, "autosquash", &autosquash_i, 1, "move commits that begin with squash!/fixup! under -i"),
    po.setInt(0, "update-refs", &options.update_refs, 1, "update branches that point to commits that are being rebased"),
    po.optString('S', "gpg-sign", &gpg_sign, "", "key-id", "GPG-sign commits"),
    po.boolean(0, "autostash", &options.autostash, "automatically stash/stash pop before and after"),
    po.list('x', "exec", &options.exec, "exec", "add exec lines after each commit of the editable list"),
    .{ .long = "allow-empty-message", .kind = .boolean, .b = &options.allow_empty_message, .hidden = true, .help = "allow rebasing commits with empty messages" },
    .{ .short = 'r', .long = "rebase-merges", .kind = .callback, .cb = cbRebaseMerges, .optarg = true, .argh = "mode", .help = "try to rebase merges instead of skipping them" },
    po.setInt(0, "fork-point", &options.fork_point, 1, "use 'merge-base --fork-point' to refine upstream"),
    po.string('s', "strategy", &strategy_opt, "strategy", "use the given merge strategy"),
    po.list('X', "strategy-option", &options.strategy_opts, "option", "pass the argument through to the merge strategy"),
    po.boolean(0, "root", &options.root, "rebase all reachable commits up to the root(s)"),
    po.setInt(0, "reschedule-failed-exec", &reschedule_failed_exec, 1, "automatically re-schedule any `exec` that fails"),
    po.setInt(0, "reapply-cherry-picks", &options.reapply_cherry_picks, 1, "apply all changes, even those already present upstream"),
};

fn checkExecCmd(cmd: []const u8) bool {
    if (std.mem.indexOfScalar(u8, cmd, '\n') != null) {
        util.err("exec commands cannot contain newlines", .{});
        return true;
    }
    for (cmd) |ch| {
        if (!(ch == ' ' or ch == '\t' or ch == '\r' or ch == 0x0c or ch == 0x0b)) return false;
    }
    util.err("empty exec command", .{});
    return true;
}

fn errorOnMissingDefaultUpstream() noreturn {
    const cur = transport.branchGet(null);
    util.outf("{s}\nPlease specify which branch you want to rebase against.\nSee git-rebase(1) for details.\n\n    git rebase '<branch>'\n\n", .{if (cur != null) "There is no tracking information for the current branch." else "You are not currently on a branch."});
    if (cur) |b| {
        util.outf("If you wish to set tracking information for this branch you can do so with:\n\n    git branch --set-upstream-to={s}/<branch> {s}\n\n", .{ b.remote_name orelse "<remote>", b.name });
    }
    util.flushStdout();
    os.exit(1);
}

fn finish(ret: i32) u8 {
    util.flushStdout();
    return if (ret != 0) 1 else 0;
}

pub fn cmdRebase(args: []const []const u8) u8 {
    options = .{};
    rebaseConfig();
    gpg_sign = if (options.gpg_sign_opt != null) "" else null;
    options.gpg_sign_opt = null;
    autosquash_i = -1;

    if (os.exists(util.concat(&.{ applyDir(), "/applying" })))
        util.die("It looks like 'git am' is in progress. Cannot rebase.", .{});

    if (os.isDir(applyDir())) {
        options.typ = .apply;
        options.state_dir = applyDir();
    } else if (os.isDir(mergeDir())) {
        options.typ = .merge;
        options.state_dir = mergeDir();
    }
    const in_progress = options.typ != .unspecified;
    const saw_rewritten = options.typ == .merge and os.isDir(util.concat(&.{ mergeDir(), "/rewritten" }));
    const had_interactive = options.typ == .merge and os.exists(util.concat(&.{ mergeDir(), "/interactive" }));

    const total_argc = args.len;
    var rest = po.parse(args[1..], &rebase_options, &usage, .{});
    options.autosquash = autosquash_i;

    if (in_progress and options.typ == .merge) {
        if (options.action != .abort and saw_rewritten)
            util.die("`rebase --preserve-merges` (-p) is no longer supported.\nUse `git rebase --abort` to terminate current rebase.\nOr downgrade to v2.33, or earlier, to complete the rebase.", .{});
        if (had_interactive) options.flags |= INTERACTIVE_EXPLICIT;
    }

    if (options.trailer_args.items.len > 0) {
        if (trailer.validateArgs(options.trailer_args.items)) os.exit(128);
        options.flags |= FORCE;
    }
    if (preserve_merges_selected != 0)
        util.die("--preserve-merges was replaced by --rebase-merges\nNote: Your `pull.rebase` configuration may also be set to 'preserve',\nwhich is no longer supported; use 'merges' instead", .{});

    if (options.action != .none and total_argc != 2) po.usageWithOptions(&usage, &rebase_options);
    if (rest.len > 2) po.usageWithOptions(&usage, &rebase_options);

    if (keep_base) {
        if (options.onto_name != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--keep-base", "--onto" });
        if (options.root) util.die("options '{s}' and '{s}' cannot be used together", .{ "--keep-base", "--root" });
        if (options.fork_point < 0) options.fork_point = 0;
    }
    if (options.root and options.fork_point > 0)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--root", "--fork-point" });
    if (options.action != .none and !in_progress) util.die("no rebase in progress", .{});
    if (options.action == .edit_todo and !isMerge())
        util.die("The --edit-todo action can only be used during interactive rebase.", .{});

    options.reflog_action = os.getenv("GIT_REFLOG_ACTION") orelse "rebase";

    switch (options.action) {
        .@"continue" => {
            if (revparse.getOid("HEAD") == null) util.die("Cannot read HEAD", .{});
            index_mod.discard();
            switch (@import("../lockfile.zig").tryLock(repo_mod.repo().indexPath())) {
                .ok => |l| {
                    l.rollback();
                    const idx = index_mod.lockAndRead();
                    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
                    if (idx.changed) idx.write() else idx.rollback();
                },
                .err => {
                    const idx = index_mod.get();
                    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
                },
            }
            if (wtstatus.hasUnstagedChanges(true)) {
                util.outf("You must edit all merge conflicts and then\nmark them as resolved using git add\n", .{});
                util.flushStdout();
                os.exit(1);
            }
            if (readBasicState() != 0) os.exit(1);
            return finish(runSpecificRebase());
        },
        .skip => {
            @import("../rerere.zig").clear();
            if (seq.resetWorkingTree(.{ .flags = seq.RESET_HARD | seq.RESET_UPDATE_HEAD }) < 0)
                util.die("could not discard worktree changes", .{});
            branchstate.removeBranchState(false);
            if (readBasicState() != 0) os.exit(1);
            return finish(runSpecificRebase());
        },
        .abort => {
            @import("../rerere.zig").clear();
            if (readBasicState() != 0) os.exit(1);
            const oh = options.orig_head.?;
            if (seq.resetWorkingTree(.{
                .oid = oh.oid(),
                .head_msg = util.fmt("{s} (abort): returning to {s}", .{ options.reflog_action, options.head_name orelse hexOf(oh) }),
                .branch = options.head_name,
                .flags = seq.RESET_HARD | seq.RESET_UPDATE_HEAD,
            }) < 0) util.die("could not move back to {s}", .{hexOf(oh)});
            branchstate.removeBranchState(false);
            return finish(finishRebase());
        },
        .quit => {
            _ = seq.saveAutostash(statePath("autostash"));
            var ret: i32 = 0;
            if (options.typ == .merge) {
                var r: seq.Opts = .{ .action = .rebase_i };
                ret = seq.removeState(&r);
            } else {
                os.removeTree(options.state_dir);
                if (os.exists(options.state_dir)) {
                    util.err("could not remove '{s}'", .{options.state_dir});
                    ret = -1;
                }
            }
            return finish(ret);
        },
        .edit_todo, .show_current_patch => {
            options.dont_finish_rebase = true;
            return finish(runSpecificRebase());
        },
        .none => {},
    }

    if (in_progress) {
        const sd = options.state_dir;
        const base = if (std.mem.lastIndexOfScalar(u8, sd, '/')) |p| sd[p + 1 ..] else sd;
        util.die("It seems that there is already a {s} directory, and\nI wonder if you are in the middle of another rebase.  If that is the\ncase, please try\n\t{s}\nIf that is not the case, please\n\t{s}\nand run me again.  I am stopping in case you still have something\nvaluable there.\n", .{ base, "git rebase (--continue | --abort | --skip)", util.fmt("rm -fr \"{s}\"", .{sd}) });
    }

    var allow_preemptive_ff = true;
    if (options.flags & INTERACTIVE_EXPLICIT != 0 or options.exec.items.len > 0 or options.autosquash == 1)
        allow_preemptive_ff = false;
    if (options.committer_date_is_author_date or options.ignore_date) options.flags |= FORCE;

    for (options.git_am_opts.items) |option| {
        if (util.eql(option, "--whitespace=fix") or util.eql(option, "--whitespace=strip")) {
            allow_preemptive_ff = false;
        } else if (util.skipPrefix(option, "-C")) |p| {
            for (p) |ch| if (!std.ascii.isDigit(ch)) util.die("switch `C' expects a numerical value", .{});
        } else if (util.skipPrefix(option, "--whitespace=")) |p| {
            if (p.len > 0 and !util.eql(p, "warn") and !util.eql(p, "nowarn") and !util.eql(p, "error") and !util.eql(p, "error-all"))
                util.die("Invalid whitespace option: '{s}'", .{p});
        }
    }
    for (options.exec.items) |e| if (checkExecCmd(e)) os.exit(1);

    if (options.flags & NO_QUIET == 0) options.git_am_opts.append(gpa, "-q") catch util.oom();
    if (options.empty != .unspecified) implyMerge("--empty");

    if (options.reapply_cherry_picks < 0) {
        options.reapply_cherry_picks = if (keep_base) 1 else 0;
    } else if (!keep_base) {
        implyMerge(if (options.reapply_cherry_picks > 0) "--reapply-cherry-picks" else "--no-reapply-cherry-picks");
    }

    if (gpg_sign) |g| options.gpg_sign_opt = util.concat(&.{ "-S", g });
    if (options.exec.items.len > 0) implyMerge("--exec");

    if (options.typ == .apply) {
        if (ignore_whitespace) options.git_am_opts.append(gpa, "--ignore-whitespace") catch util.oom();
        if (options.committer_date_is_author_date) options.git_am_opts.append(gpa, "--committer-date-is-author-date") catch util.oom();
        if (options.ignore_date) options.git_am_opts.append(gpa, "--ignore-date") catch util.oom();
    } else {
        if (ignore_whitespace) options.strategy_opts.append(gpa, "ignore-space-change") catch util.oom();
    }

    if (strategy_opt) |s| {
        options.strategy = s;
    } else if (options.strategy_opts.items.len > 0 and options.strategy == null) options.strategy = "ort";
    if (options.strategy != null) implyMerge("--strategy");
    if (options.root and options.onto_name == null) implyMerge("--root without --onto");
    if (options.trailer_args.items.len > 0) implyMerge("--trailer");

    if (os.isatty(2) and options.flags & NO_QUIET != 0) options.git_format_patch_opt.append(gpa, "--progress") catch util.oom();

    if (options.git_am_opts.items.len > 0 or options.typ == .apply) {
        var non_q = false;
        for (options.git_am_opts.items) |o| {
            if (!util.eql(o, "-q")) non_q = true;
        }
        if (non_q or options.typ == .apply) {
            if (isMerge()) {
                util.die("apply options and merge options cannot be used together", .{});
            } else if (options.rebase_merges == -1 and options.config_rebase_merges == 1) {
                util.die("apply options are incompatible with rebase.rebaseMerges.  Consider adding --no-rebase-merges", .{});
            } else if (options.update_refs == -1 and options.config_update_refs == 1) {
                util.die("apply options are incompatible with rebase.updateRefs.  Consider adding --no-update-refs", .{});
            } else options.typ = .apply;
        }
    }

    if (options.update_refs == 1) implyMerge("--update-refs");
    if (options.update_refs < 0) options.update_refs = if (options.config_update_refs >= 0) options.config_update_refs else 0;
    if (options.rebase_merges == 1) implyMerge("--rebase-merges");
    if (options.rebase_merges < 0) options.rebase_merges = if (options.config_rebase_merges >= 0) options.config_rebase_merges else 0;

    if (options.autosquash == 1) {
        implyMerge("--autosquash");
    } else if (options.autosquash == -1) {
        options.autosquash = if (options.config_autosquash and options.flags & INTERACTIVE_EXPLICIT != 0) 1 else 0;
    }

    if (options.typ == .unspecified) {
        if (util.eql(options.default_backend, "merge")) {
            options.typ = .merge;
        } else if (util.eql(options.default_backend, "apply")) {
            options.typ = .apply;
        } else util.die("Unknown rebase backend: {s}", .{options.default_backend});
    }
    options.state_dir = if (options.typ == .merge) mergeDir() else applyDir();

    if (options.empty == .unspecified) {
        if (options.flags & INTERACTIVE_EXPLICIT != 0) {
            options.empty = .stop;
        } else if (options.exec.items.len > 0) {
            options.empty = .keep;
        } else options.empty = .drop;
    }
    if (reschedule_failed_exec > 0 and !isMerge())
        util.die("--reschedule-failed-exec requires --exec or --interactive", .{});
    if (reschedule_failed_exec >= 0) options.reschedule_failed_exec = reschedule_failed_exec > 0;

    if (options.signoff) {
        options.git_am_opts.append(gpa, "--signoff") catch util.oom();
        options.flags |= FORCE;
    }

    if (!options.root) {
        if (rest.len < 1) {
            const cur = transport.branchGet(null);
            const up = if (cur) |b| tracking.branchGetUpstream(b.name) else null;
            options.upstream_name = up orelse errorOnMissingDefaultUpstream();
            if (options.fork_point < 0) options.fork_point = 1;
        } else {
            options.upstream_name = rest[0];
            rest = rest[1..];
            if (util.eql(options.upstream_name.?, "-")) options.upstream_name = "@{-1}";
        }
        options.upstream = lookupCommitReferenceByName(options.upstream_name.?) orelse
            util.die("invalid upstream '{s}'", .{options.upstream_name.?});
        options.upstream_arg = options.upstream_name.?;
    } else {
        if (options.onto_name == null) {
            const so = commit_mod.create(.{ .tree = hash.fromHex(hash.empty_tree_hex).?, .message = "" });
            options.squash_onto = so;
            options.onto_name = util.dupe(&hash.hex(so));
        } else options.root_with_onto = true;
        options.upstream_name = null;
        options.upstream = null;
        if (rest.len > 1) po.usageWithOptions(&usage, &rebase_options);
        options.upstream_arg = "--root";
    }

    var branch_name: []const u8 = "HEAD";
    if (rest.len == 1) {
        branch_name = rest[0];
        options.switch_to = rest[0];
        const full = util.concat(&.{ "refs/heads/", branch_name });
        if (refs.readOid(full)) |boid| {
            worktree.dieIfCheckedOut(full, true);
            options.head_name = full;
            options.orig_head = cn.lookupCommit(boid);
            if (options.orig_head) |c| _ = cn.parse(c);
        } else {
            options.orig_head = lookupCommitReferenceByName(branch_name);
            options.head_name = null;
        }
        if (options.orig_head == null) util.die("no such branch/commit '{s}'", .{branch_name});
    } else if (rest.len == 0) {
        const r = refs.resolve("HEAD") orelse util.die("No such ref: {s}", .{"HEAD"});
        if (r.symbolic) {
            options.head_name = r.name;
            branch_name = util.skipPrefix(r.name, "refs/heads/") orelse r.name;
        } else {
            options.head_name = null;
            branch_name = "HEAD";
        }
        options.orig_head = lookupCommitReferenceByName("HEAD") orelse util.die("Could not resolve HEAD to a commit", .{});
    } else util.die("BUG: unexpected number of arguments left to parse", .{});

    var branch_base: Oid = hash.zero;
    if (keep_base) {
        options.onto_name = util.concat(&.{ options.upstream_name.?, "...", branch_name });
    } else if (options.onto_name == null) options.onto_name = options.upstream_name;
    const onto_name = options.onto_name.?;
    if (std.mem.indexOf(u8, onto_name, "...") != null) {
        branch_base = branchcreate.getOidMb(onto_name) orelse {
            if (keep_base) util.die("'{s}': need exactly one merge base with branch", .{options.upstream_name.?});
            util.die("'{s}': need exactly one merge base", .{onto_name});
        };
        options.onto = cn.lookupCommitReference(branch_base) orelse util.die("could not parse commit {s}", .{onto_name});
        _ = cn.parse(options.onto.?);
    } else {
        options.onto = lookupCommitReferenceByName(onto_name) orelse
            util.die("Does not point to a valid commit '{s}'", .{onto_name});
        branch_base = fillBranchBase();
    }

    if (keep_base and options.reapply_cherry_picks > 0) options.upstream = options.onto;
    if (options.fork_point > 0) options.restrict_revision = creach.forkPoint(options.upstream_name.?, options.orig_head);

    index_mod.discard();
    _ = index_mod.get();

    if (options.autostash) seq.createAutostash(statePath("autostash"));

    if (wtstatus.requireCleanWorkTree("rebase", "Please commit or stash them.", true, true)) {
        return finish(-1 | cleanupAutostash());
    }

    if (allow_preemptive_ff and canFastForward(options.onto.?, options.upstream, options.restrict_revision, options.orig_head.?, branch_base)) {
        if (options.flags & FORCE == 0) {
            if (options.switch_to != null) {
                if (checkoutUpToDate() != 0) return finish(-1 | cleanupAutostash());
            }
            if (options.flags & NO_QUIET == 0) {
                // quiet
            } else if (util.eql(branch_name, "HEAD") and refs.resolve("HEAD") != null) {
                util.outf("HEAD is up to date.\n", .{});
            } else util.outf("Current branch {s} is up to date.\n", .{branch_name});
            return finish(finishRebase());
        } else if (options.flags & NO_QUIET == 0) {
            // quiet
        } else if (util.eql(branch_name, "HEAD") and refs.resolve("HEAD") != null) {
            util.outf("HEAD is up to date, rebase forced.\n", .{});
        } else util.outf("Current branch {s} is up to date, rebase forced.\n", .{branch_name});
    }

    if (!ok_to_skip_pre_rebase) {
        var hargs: std.ArrayList([]const u8) = .empty;
        hargs.append(gpa, options.upstream_arg) catch util.oom();
        if (rest.len > 0) hargs.append(gpa, rest[0]) catch util.oom();
        util.flushStdout();
        if (hook.run("pre-rebase", hargs.items, .{}) != 0) {
            util.err("The pre-rebase hook refused to rebase.", .{});
            return finish(-1 | cleanupAutostash());
        }
    }

    if (options.flags & DIFFSTAT != 0) {
        const onto_hex = hexOf(options.onto.?);
        if (options.flags & VERBOSE != 0) {
            if (hash.isZero(branch_base)) {
                util.outf("Changes to {s}:\n", .{onto_hex});
            } else util.outf("Changes from {s} to {s}:\n", .{ hash.hex(branch_base), onto_hex });
        }
        const from = if (hash.isZero(branch_base)) hash.empty_tree_hex else util.dupe(&hash.hex(branch_base));
        _ = runGit(&.{ "--no-pager", "diff", "--stat", "--summary", "-M", from, onto_hex }, .{ .no_stdin = true });
    }

    if (isMerge()) {
        return finish(runSpecificRebase());
    }

    if (options.flags & NO_QUIET != 0) util.outf("First, rewinding head to replay your work on top of it...\n", .{});
    if (seq.resetWorkingTree(.{
        .oid = options.onto.?.oid(),
        .orig_head = options.orig_head.?.oid(),
        .flags = seq.RESET_DETACH | seq.RESET_UPDATE_HEAD | seq.RESET_UPDATE_ORIG_HEAD | seq.RESET_RUN_POST_CHECKOUT_HOOK,
        .head_msg = util.fmt("{s} (start): checkout {s}", .{ options.reflog_action, onto_name }),
        .default_reflog_action = options.reflog_action,
    }) != 0) {
        util.err("Could not detach HEAD", .{});
        return finish(-1 | cleanupAutostash());
    }

    if (hash.eql(branch_base, options.orig_head.?.oid())) {
        util.outf("Fast-forwarded {s} to {s}.\n", .{ branch_name, onto_name });
        _ = moveToOriginalBranch();
        return finish(finishRebase());
    }

    const rev_base = if (options.root) options.onto.? else (options.restrict_revision orelse options.upstream.?);
    options.revisions = util.fmt("{s}..{s}", .{ hexOf(rev_base), hexOf(options.orig_head.?) });
    return finish(runSpecificRebase());
}
