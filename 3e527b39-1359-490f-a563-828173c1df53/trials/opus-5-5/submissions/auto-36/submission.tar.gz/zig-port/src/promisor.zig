//! Promisor remotes and lazy fetching (port of promisor-remote.c,
//! partial_clone_register() and is_promisor_object()).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const config = @import("config.zig");
const repo_mod = @import("repo.zig");
const objfilter = @import("objfilter.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

/// repo->fetch_if_missing: commands that must not lazily fetch clear it.
pub var fetch_if_missing = true;

/// Set in the environment of our own lazy-fetch child so that it never
/// recurses into another lazy fetch.
const internal_env = "GIT_INTERNAL_LAZY_FETCH_CHILD";

var remotes_cache: ?[][]const u8 = null;

/// Names of the promisor remotes, extensions.partialclone first.
pub fn remotes() [][]const u8 {
    if (remotes_cache) |r| return r;
    var list: std.ArrayList([]const u8) = .empty;
    const cfg = &repo_mod.cfg;
    const S = struct {
        fn addName(l: *std.ArrayList([]const u8), name: []const u8) void {
            if (name.len == 0) return;
            for (l.items) |x| if (util.eql(x, name)) return;
            if (name[0] == '/') {
                util.warn("promisor remote name cannot begin with '/': {s}", .{name});
                return;
            }
            l.append(gpa, util.dupe(name)) catch util.oom();
        }
    };
    if (cfg.get("extensions.partialclone")) |pc| S.addName(&list, pc);
    for (cfg.entries.items) |e| {
        const k = e.key;
        if (!util.startsWith(k, "remote.")) continue;
        const dot = std.mem.lastIndexOfScalar(u8, k, '.') orelse continue;
        if (dot <= "remote.".len) continue;
        const sub = k[dot + 1 ..];
        const name = k["remote.".len..dot];
        if (util.eql(sub, "promisor")) {
            const v = e.value orelse "true";
            if (config.parseBool(v) orelse false) S.addName(&list, name);
        } else if (util.eql(sub, "partialclonefilter")) {
            S.addName(&list, name);
        }
    }
    remotes_cache = list.items;
    return list.items;
}

pub fn invalidate() void {
    remotes_cache = null;
}

pub fn hasRemote() bool {
    return remotes().len > 0;
}

pub fn isPromisorRemote(name: []const u8) bool {
    for (remotes()) |r| if (util.eql(r, name)) return true;
    return false;
}

/// remote.<name>.partialclonefilter
pub fn partialCloneFilter(name: []const u8) ?[]const u8 {
    return repo_mod.cfg.get(util.fmt("remote.{s}.partialclonefilter", .{name}));
}

fn setConfig(key: []const u8, value: []const u8) void {
    const path = repo_mod.repo().commonPath("config");
    if (config.setInFileGently(path, key, null, value) != 0)
        util.die("could not set '{s}' to '{s}'", .{ key, value });
    config.addCmdline(&repo_mod.cfg, util.fmt("{s}={s}", .{ key, value }));
}

/// partial_clone_register()
pub fn register(remote: []const u8, filter_spec: []const u8) void {
    if (isPromisorRemote(remote)) {
        if (partialCloneFilter(remote) != null) return;
    } else {
        const ver = repo_mod.cfg.getInt("core.repositoryformatversion") orelse 0;
        if (ver == 0) setConfig("core.repositoryformatversion", "1");
        setConfig(util.fmt("remote.{s}.promisor", .{remote}), "true");
    }
    setConfig(util.fmt("remote.{s}.partialclonefilter", .{remote}), filter_spec);
    invalidate();
}

/// Expanded form of a user-given filter spec (dies on a bad spec).
pub fn expandSpec(spec: []const u8) []const u8 {
    const f = objfilter.parse(spec);
    return objfilter.expandSpec(f);
}

pub fn lazyFetchDisabled() bool {
    if (!fetch_if_missing) return true;
    if (os.getenv(internal_env) != null) return true;
    if (envBool("GIT_NO_LAZY_FETCH")) return true;
    return false;
}

var warned_disabled = false;

/// fetch_objects(): returns true when the fetch subprocess succeeded.
fn fetchObjects(remote: []const u8, oids: []const Oid) bool {
    if (envBool("GIT_NO_LAZY_FETCH")) {
        if (!warned_disabled) {
            warned_disabled = true;
            util.warn("lazy fetching disabled; some objects may not be available", .{});
        }
        return false;
    }
    var input: util.Buf = .empty;
    for (oids) |o| {
        util.bufAppend(&input, &hash.hex(o));
        util.bufByte(&input, '\n');
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{
        @import("proc.zig").gitBinary(), "-c",                      "fetch.negotiationAlgorithm=noop",
        "fetch",                         remote,                    "--no-tags",
        "--no-write-fetch-head",         "--recurse-submodules=no", "--filter=blob:none",
        "--stdin",
    }) catch util.oom();
    if (repo_mod.cfg.getBool("promisor.quiet") orelse false) argv.append(gpa, "--quiet") catch util.oom();
    util.flushStdout();
    const r = os.run(argv.items, .{ .stdin_data = input.items, .stdout_to_stderr = true, .env = &.{.{ internal_env, "1" }} });
    return r.status == 0 and !r.signaled;
}

fn envBool(name: []const u8) bool {
    const v = os.getenv(name) orelse return false;
    return config.parseBool(v) orelse false;
}

/// promisor_remote_get_direct(): try each promisor remote in turn.
pub fn getDirect(oids: []const Oid) void {
    if (oids.len == 0) return;
    const odb = repo_mod.repo().odb();
    var remaining: std.ArrayList(Oid) = .empty;
    remaining.appendSlice(gpa, oids) catch util.oom();
    for (remotes()) |r| {
        const ok = fetchObjects(r, remaining.items);
        odb.reloadPacks();
        if (ok) return;
        if (remaining.items.len == 1) continue;
        var j: usize = 0;
        for (remaining.items) |o| {
            if (!odb.has(o)) {
                remaining.items[j] = o;
                j += 1;
            }
        }
        remaining.items.len = j;
        if (j == 0) return;
    }
    for (remaining.items) |o| {
        if (isPromisorObject(o)) util.die("could not fetch {s} from promisor remote", .{hash.hex(o)});
    }
}

/// Hook used by the object database when an object is missing: lazily
/// fetch it. Returns true if a fetch was attempted.
pub fn lazyFetchOne(oid: Oid) bool {
    if (lazyFetchDisabled()) return false;
    if (repo_mod.repo_ == null) return false;
    if (!hasRemote()) return false;
    if (hash.eql(oid, hash.zero)) return false;
    getDirect(&.{oid});
    return true;
}

/// Prefetch a batch of objects that are not present locally.
pub fn prefetchMissing(oids: []const Oid) void {
    if (os.getenv(internal_env) != null or repo_mod.repo_ == null or !hasRemote()) return;
    const odb = repo_mod.repo().odb();
    var missing: std.ArrayList(Oid) = .empty;
    var seen: hash.OidMap(void) = .empty;
    for (oids) |o| {
        if (odb.has(o)) continue;
        const gop = seen.getOrPut(gpa, o) catch util.oom();
        if (gop.found_existing) continue;
        missing.append(gpa, o) catch util.oom();
    }
    getDirect(missing.items);
}

// ---------------- is_promisor_object ----------------

var promisor_set: ?hash.OidMap(void) = null;

fn addOid(set: *hash.OidMap(void), oid: Oid) void {
    set.put(gpa, oid, {}) catch util.oom();
}

pub fn isPromisorPack(pack_path: []const u8) bool {
    if (!util.endsWith(pack_path, ".pack")) return false;
    return os.exists(util.concat(&.{ pack_path[0 .. pack_path.len - 5], ".promisor" }));
}

/// is_promisor_object(): the object is in a promisor pack, or is
/// referenced by an object in a promisor pack.
pub fn isPromisorObject(oid: Oid) bool {
    if (promisor_set == null) {
        var set: hash.OidMap(void) = .empty;
        const odb = repo_mod.repo().odb();
        odb.loadPacks();
        const saved = fetch_if_missing;
        fetch_if_missing = false;
        defer fetch_if_missing = saved;
        const objects = @import("objects.zig");
        for (odb.packs.items) |p| {
            if (!isPromisorPack(p.pack_path)) continue;
            var i: u32 = 0;
            while (i < p.num) : (i += 1) {
                const o = p.oidAt(i);
                addOid(&set, o);
                const obj = odb.readNoReplace(o) orelse continue;
                switch (obj.typ) {
                    .commit => {
                        const c = objects.parseCommit(o, obj.data) orelse continue;
                        addOid(&set, c.tree);
                        for (c.parents) |par| addOid(&set, par);
                    },
                    .tree => {
                        var it = objects.TreeIter{ .data = obj.data };
                        while (it.next()) |e| {
                            if (e.mode == 0o160000) continue;
                            addOid(&set, e.oid);
                        }
                    },
                    .tag => {
                        const t = objects.parseTag(obj.data) orelse continue;
                        addOid(&set, t.object);
                    },
                    else => {},
                }
            }
        }
        promisor_set = set;
    }
    return promisor_set.?.contains(oid);
}
