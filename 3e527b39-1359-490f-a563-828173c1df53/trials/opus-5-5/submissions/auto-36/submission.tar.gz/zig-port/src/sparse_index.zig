//! Sparse index (sparse-index.c): "sdir" extension, sparse directory entries.
//!
//! A sparse directory entry is an index entry with mode 040000, a trailing
//! '/' in its path, the SKIP_WORKTREE flag and the oid of the tree it stands
//! for. convert_to_sparse() collapses fully skip-worktree directories outside
//! the cone into such entries (using the cache tree), ensure_full_index()
//! expands them again by reading their trees.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const objects = @import("objects.zig");
const sparse = @import("sparse.zig");
const trace2 = @import("trace2.zig");
const index_mod = @import("index.zig");
const gpa = util.gpa;

const Index = index_mod.Index;
const Entry = index_mod.Entry;
const CacheTree = index_mod.CacheTree;

const S_IFMT: u32 = 0o170000;
const S_IFDIR: u32 = 0o040000;
const S_IFGITLINK: u32 = 0o160000;

/// !command_requires_full_index: set by sparse-aware commands before reading.
pub var keep_sparse: bool = false;

/// Set once an index read from disk was sparse (and got expanded). Used by
/// commands that are sparse-aware in C (update-index) to report the
/// split-index incompatibility.
pub var read_sparse: bool = false;
/// set by convertToSparse(): the next ensureFull() undoes our own collapse
var just_converted = false;

/// In-memory overrides used by `git sparse-checkout`, which changes these
/// settings before rewriting the index (repo->settings.sparse_index,
/// core_apply_sparse_checkout, core_sparse_checkout_cone and
/// istate->sparse_checkout_patterns in C).
pub var setting_override: ?bool = null;
pub var apply_override: ?bool = null;
pub var cone_override: ?bool = null;
pub var patterns_override: ?*sparse.Patterns = null;

pub fn isSparseDir(e: *const Entry) bool {
    return e.mode & S_IFMT == S_IFDIR;
}

fn envBoolOpt(name: []const u8) ?bool {
    const v = os.getenv(name) orelse return null;
    return @import("config.zig").parseBool(v) orelse
        util.die("bad boolean environment value '{s}' for '{s}'", .{ v, name });
}

/// set_sparse_index_config()'s in-memory part
pub fn setSetting(enable: bool) void {
    setting_override = enable;
}

fn currentPatterns() ?*sparse.Patterns {
    if (patterns_override) |p| return p;
    const cone = cone_override orelse sparse.configCone();
    return sparse.loadFile(sparse.sparseFilename(), cone);
}

/// is_sparse_index_allowed(istate, flags)
pub fn isAllowed(idx: *Index, memory_only: bool) bool {
    if (repo_mod.repo_ == null) return false;
    const apply = apply_override orelse sparse.configApply();
    const cone = cone_override orelse sparse.configCone();
    if (!apply or !cone) return false;
    if (!memory_only) {
        if (idx.split != null) return false;
        if (envBoolOpt("GIT_TEST_SPLIT_INDEX") orelse false) return false;
        if (envBoolOpt("GIT_TEST_SPARSE_INDEX")) |v| setSetting(v);
        const enabled = setting_override orelse (repo_mod.cfg.getBool("index.sparse") orelse false);
        if (!enabled) return false;
    }
    const pl = currentPatterns() orelse return false;
    if (!pl.use_cone) return false;
    return true;
}

fn cacheTreeFullyValid(t: ?*CacheTree) bool {
    const ct = t orelse return false;
    if (ct.entry_count < 0 or !repo_mod.repo().odb().has(ct.oid)) return false;
    for (ct.children.items) |c| {
        if (!cacheTreeFullyValid(c)) return false;
    }
    return true;
}

/// cache_tree_free() + cache_tree_update(); false on failure
fn rebuildCacheTree(idx: *Index, missing_ok: bool) bool {
    idx.cache_tree = null;
    if (idx.writeTree(missing_ok) != null) return true;
    idx.cache_tree = null;
    return false;
}

/// convert_to_sparse_rec(): returns the number of entries appended to `out`.
fn convertRec(
    pl: *sparse.Patterns,
    ents: []Entry,
    out: *std.ArrayList(Entry),
    start: usize,
    end: usize,
    ct_path: []const u8,
    ct: *CacheTree,
) usize {
    const start_len = out.items.len;
    var can_convert = !pl.pathIn(ct_path, @import("dir.zig").DT_REG);
    var i = start;
    while (can_convert and i < end) : (i += 1) {
        const e = &ents[i];
        if (e.stage() != 0 or e.mode & S_IFMT == S_IFGITLINK or !e.skipWorktree())
            can_convert = false;
    }
    if (can_convert) {
        out.append(gpa, .{
            .mode = S_IFDIR,
            .oid = ct.oid,
            .path = ct_path,
            .ext_flags = index_mod.CE_SKIP_WORKTREE,
        }) catch util.oom();
        return 1;
    }
    i = start;
    while (i < end) {
        const e = ents[i];
        const base = e.path[ct_path.len..];
        const sub: ?*CacheTree = if (std.mem.indexOfScalar(u8, base, '/')) |sl| ct.find(base[0..sl]) else null;
        if (sub == null or sub.?.entry_count < 0) {
            out.append(gpa, e) catch util.oom();
            i += 1;
            continue;
        }
        const sl = std.mem.indexOfScalar(u8, base, '/').?;
        const span: usize = @intCast(sub.?.entry_count);
        const child_path = e.path[0 .. ct_path.len + sl + 1];
        const stop = @min(i + span, end);
        _ = convertRec(pl, ents, out, i, stop, child_path, sub.?);
        i = stop;
    }
    return out.items.len - start_len;
}

/// convert_to_sparse(istate, 0)
pub fn convertToSparse(idx: *Index) void {
    _ = convertToSparseFlags(idx, false);
}

/// convert_to_sparse(istate, flags); returns false when the index stays full.
pub fn convertToSparseFlags(idx: *Index, memory_only: bool) bool {
    if (idx.sparse_index) return true;
    if (idx.entries.items.len == 0) return false;
    if (!isAllowed(idx, memory_only)) return false;
    for (idx.entries.items) |*e| {
        if (!e.removed and e.stage() != 0) return false;
    }
    const pl = currentPatterns() orelse return false;

    // drop entries scheduled for removal (they are not written anyway)
    var has_removed = false;
    for (idx.entries.items) |*e| {
        if (e.removed) has_removed = true;
    }
    if (has_removed) {
        var w: usize = 0;
        for (idx.entries.items) |e| {
            if (e.removed) continue;
            idx.entries.items[w] = e;
            w += 1;
        }
        idx.entries.items.len = w;
        idx.cache_tree = null;
    }

    if (!cacheTreeFullyValid(idx.cache_tree)) {
        if (!rebuildCacheTree(idx, true)) return false;
    }

    // remove_fsmonitor()
    idx.fsmonitor_last_update = null;
    idx.fsmonitor_dirty = null;
    idx.fsmonitor_has_run_once = false;

    trace2.regionEnter("index", "convert_to_sparse", true);
    var out: std.ArrayList(Entry) = .empty;
    out.ensureTotalCapacity(gpa, idx.entries.items.len) catch util.oom();
    _ = convertRec(pl, idx.entries.items, &out, 0, idx.entries.items.len, "", idx.cache_tree.?);
    idx.entries = out;
    _ = rebuildCacheTree(idx, false);
    idx.sparse_index = true;
    just_converted = true;
    trace2.regionLeave("index", "convert_to_sparse", true);
    return true;
}

fn addTree(out: *std.ArrayList(Entry), tree: hash.Oid, base: []const u8) void {
    const ents = objects.readTree(tree) orelse return;
    for (ents) |te| {
        if (te.isDir()) {
            addTree(out, te.oid, util.concat(&.{ base, te.name, "/" }));
            continue;
        }
        out.append(gpa, .{
            .mode = te.mode,
            .oid = te.oid,
            .path = util.concat(&.{ base, te.name }),
            .ext_flags = index_mod.CE_SKIP_WORKTREE,
        }) catch util.oom();
    }
}

/// ensure_full_index() (expand_index(istate, NULL))
pub fn ensureFull(idx: *Index) void {
    if (!idx.sparse_index) return;
    if (!just_converted) read_sparse = true;
    just_converted = false;
    trace2.regionEnter("index", "ensure_full_index", true);
    var out: std.ArrayList(Entry) = .empty;
    out.ensureTotalCapacity(gpa, idx.entries.items.len) catch util.oom();
    for (idx.entries.items) |e| {
        if (!isSparseDir(&e)) {
            out.append(gpa, e) catch util.oom();
            continue;
        }
        if (!e.skipWorktree())
            util.warn("index entry is a directory, but not sparse ({x:0>8})", .{@as(u32, e.flags) | (@as(u32, e.ext_flags) << 16)});
        addTree(&out, e.oid, e.path);
    }
    idx.entries = out;
    idx.sparse_index = false;
    idx.fsmonitor_has_run_once = false;
    idx.fsmonitor_dirty = null;
    idx.fsmonitor_last_update = null;
    _ = rebuildCacheTree(idx, false);
    trace2.regionLeave("index", "ensure_full_index", true);
}

/// ensure_correct_sparsity()
pub fn ensureCorrectSparsity(idx: *Index) void {
    if (isAllowed(idx, false)) convertToSparse(idx) else ensureFull(idx);
}
