//! git bundle (port of bundle.c and builtin/bundle.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const repo_mod = @import("../repo.zig");
const po = @import("../parseopt.zig");
const revision = @import("../revision.zig");
const cn = @import("../commitnode.zig");
const pretty = @import("../pretty.zig");
const proc = @import("../proc.zig");
const lockfile = @import("../lockfile.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

const create_usage = "git bundle create [-q | --quiet | --progress]\n                  [--version=<version>] <file> <git-rev-list-args>";
const verify_usage = "git bundle verify [-q | --quiet] <file>";
const list_heads_usage = "git bundle list-heads <file> [<refname>...]";
const unbundle_usage = "git bundle unbundle [--progress] <file> [<refname>...]";
const all_usage = [_][]const u8{ create_usage, verify_usage, list_heads_usage, unbundle_usage };

pub const RefEntry = struct { name: []const u8, oid: Oid };

pub const Header = struct {
    version: u32 = 0,
    prerequisites: std.ArrayList(RefEntry) = .empty,
    references: std.ArrayList(RefEntry) = .empty,
    filter: ?[]const u8 = null,
    filter_obj: ?*@import("../objfilter.zig").Filter = null,
    /// Everything after the header (the packfile).
    pack: []const u8 = "",
};

fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r' or c == 0x0b or c == 0x0c;
}

/// read_bundle_header_fd on in-memory data. Returns null on error (after
/// reporting if report_path is set).
pub fn parseHeader(data: []const u8, header: *Header, report_path: ?[]const u8) ?void {
    var pos: usize = 0;
    const first_end = if (std.mem.indexOfScalar(u8, data, '\n')) |n| n + 1 else data.len;
    const first = data[0..first_end];
    if (util.eql(first, "# v2 git bundle\n")) {
        header.version = 2;
    } else if (util.eql(first, "# v3 git bundle\n")) {
        header.version = 3;
    } else {
        if (report_path) |p| util.err("'{s}' does not look like a v2 or v3 bundle file", .{p});
        return null;
    }
    pos = first_end;
    while (pos < data.len) {
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n');
        const end = if (nl) |n| n + 1 else data.len;
        var line = data[pos..end];
        pos = end;
        if (line.len == 0 or line[0] == '\n') break;
        while (line.len > 0 and isSpace(line[line.len - 1])) line = line[0 .. line.len - 1];
        if (header.version == 3 and line.len > 0 and line[0] == '@') {
            const cap = line[1..];
            if (util.startsWith(cap, "object-format=")) {
                const a = cap["object-format=".len..];
                if (!util.eql(a, "sha1")) {
                    util.err("unrecognized bundle hash algorithm: {s}", .{a});
                    return null;
                }
                continue;
            }
            if (util.startsWith(cap, "filter=")) {
                header.filter_obj = @import("../objfilter.zig").add(header.filter_obj, cap["filter=".len..]);
                header.filter = header.filter_obj.?.spec;
                continue;
            }
            util.err("unknown capability '{s}'", .{cap});
            return null;
        }
        var is_prereq = false;
        if (line.len > 0 and line[0] == '-') {
            is_prereq = true;
            line = line[1..];
        }
        const ok = blk: {
            if (line.len < 40) break :blk false;
            if (hash.fromHex(line[0..40]) == null) break :blk false;
            const rest = line[40..];
            if (rest.len > 0 and !isSpace(rest[0])) break :blk false;
            if (!is_prereq and rest.len == 0) break :blk false;
            break :blk true;
        };
        if (!ok) {
            if (report_path != null) util.err("unrecognized header: {s}{s} ({d})", .{ if (is_prereq) "-" else "", line, line.len });
            return null;
        }
        const oid = hash.fromHex(line[0..40]).?;
        if (is_prereq) {
            header.prerequisites.append(gpa, .{ .name = "", .oid = oid }) catch util.oom();
        } else {
            header.references.append(gpa, .{ .name = line[41..], .oid = oid }) catch util.oom();
        }
    }
    header.pack = data[pos..];
}

/// Read and parse a bundle file ("-" = stdin). Returns null on error.
pub fn readBundle(path: []const u8, header: *Header) ?void {
    if (util.eql(path, "-")) {
        const data = os.readAllFd(0) catch "";
        return parseHeader(data, header, "<stdin>");
    }
    return readBundleHeader(path, header);
}

/// read_bundle_header(): no special meaning for "-".
pub fn readBundleHeader(path: []const u8, header: *Header) ?void {
    const data = os.readFile(path) orelse {
        util.err("could not open '{s}'", .{path});
        return null;
    };
    return parseHeader(data, header, path);
}

pub fn isBundle(path: []const u8, quiet: bool) bool {
    const data = os.readFile(path) orelse return false;
    var h: Header = .{};
    return parseHeader(data, &h, if (quiet) null else path) != null;
}

fn listRefs(r: []const RefEntry, filter: []const []const u8) void {
    for (r) |e| {
        if (filter.len > 0) {
            var found = false;
            for (filter) |f| {
                if (util.eql(e.name, f)) found = true;
            }
            if (!found) continue;
        }
        util.outf("{s} {s}\n", .{ hash.hex(e.oid), e.name });
    }
}

pub const VerifyMode = enum { quiet, verbose, normal };

pub fn verifyBundle(header: *const Header, mode: VerifyMode) i32 {
    if (repo_mod.repo_ == null) {
        util.err("need a repository to verify a bundle", .{});
        return -1;
    }
    var ret: i32 = 0;
    const odb = repo_mod.repo().odb();
    for (header.prerequisites.items) |p| {
        if (odb.has(p.oid) and cn.parseObject(p.oid) != null) continue;
        ret += 1;
        if (mode == .quiet) continue;
        if (ret == 1) util.err("Repository lacks these prerequisite commits:", .{});
        util.err("{s} {s}", .{ hash.hex(p.oid), p.name });
    }
    if (ret != 0) return ret;

    if (header.prerequisites.items.len > 0) {
        var in: util.Buf = .empty;
        for (header.prerequisites.items) |p| util.bufPrint(&in, "{s}\n", .{hash.hex(p.oid)});
        // check_connected()
        var argv: std.ArrayList([]const u8) = .empty;
        argv.appendSlice(gpa, &.{ proc.gitBinary(), "rev-list", "--objects", "--stdin" }) catch util.oom();
        if (@import("../promisor.zig").hasRemote()) argv.append(gpa, "--exclude-promisor-objects") catch util.oom();
        argv.appendSlice(gpa, &.{ "--not", "--all", "--quiet", "--alternate-refs" }) catch util.oom();
        const res = os.run(argv.items, .{ .stdin_data = in.items, .capture_stdout = true, .no_stderr = true });
        if (res.status != 0) {
            ret = 1;
            util.err("some prerequisite commits exist in the object store, but are not connected to the repository's history", .{});
        }
    }

    if (mode == .verbose) {
        const r = header.references.items;
        if (r.len == 1) util.out("The bundle contains this ref:\n") else util.outf("The bundle contains these {d} refs:\n", .{r.len});
        listRefs(r, &.{});
        const p = header.prerequisites.items;
        if (p.len == 0) {
            util.out("The bundle records a complete history.\n");
        } else {
            if (p.len == 1) util.out("The bundle requires this ref:\n") else util.outf("The bundle requires these {d} refs:\n", .{p.len});
            listRefs(p, &.{});
        }
        util.out("The bundle uses this hash algorithm: sha1\n");
        if (header.filter) |f| util.outf("The bundle uses this filter: {s}\n", .{f});
    }
    return ret;
}

fn dwimRef(name: []const u8) ?struct { full: []const u8, count: usize } {
    const rules = [_][]const u8{ "{s}", "refs/{s}", "refs/tags/{s}", "refs/heads/{s}", "refs/remotes/{s}", "refs/remotes/{s}/HEAD" };
    var found: ?[]const u8 = null;
    var count: usize = 0;
    inline for (rules, 0..) |rule, ri| {
        const full = util.fmt(rule, .{name});
        var ok = true;
        if (ri == 0 and !util.startsWith(full, "refs/")) {
            for (full) |ch| {
                if (!std.ascii.isUpper(ch) and ch != '_') ok = false;
            }
        }
        if (ok) {
            if (refs.resolve(full)) |r| {
                if (found == null) found = r.name;
                count += 1;
            }
        }
    }
    const f = found orelse return null;
    return .{ .full = f, .count = count };
}

fn tagInDateRange(oid: Oid, revs: *revision.RevInfo) bool {
    if (revs.max_age == revision.UNSET_TIME and revs.min_age == revision.UNSET_TIME) return true;
    const o = repo_mod.repo().odb().read(oid) orelse return true;
    const data = o.data;
    const idx = std.mem.indexOf(u8, data, "\ntagger ") orelse return true;
    const line_start = idx + 1;
    const lineend = std.mem.indexOfScalarPos(u8, data, line_start, '\n') orelse data.len;
    const gt = std.mem.indexOfScalarPos(u8, data[0..lineend], line_start, '>') orelse return true;
    var p = gt + 1;
    while (p < data.len and data[p] == ' ') p += 1;
    var e = p;
    while (e < data.len and std.ascii.isDigit(data[e])) e += 1;
    const date = std.fmt.parseInt(u64, data[p..e], 10) catch 0;
    return (revs.max_age == revision.UNSET_TIME or revs.max_age < date) and
        (revs.min_age == revision.UNSET_TIME or revs.min_age > date);
}

const Pending = struct { item: *cn.Obj, name: []const u8 };

fn createBundle(path: []const u8, args: []const []const u8, version_in: i32, progress: bool) i32 {
    var revs = revision.RevInfo.init(repo_mod.repo().prefix);
    const left = revision.setupRevisions(&revs, args, .{});
    if (left.len > 1) {
        util.err("unrecognized argument: {s}", .{left[1]});
        return -1;
    }
    const filt = revs.obj_filter;
    const min_version: i32 = if (filt != null) 3 else 2;
    const to_stdout = util.eql(path, "-");
    var lock: ?*lockfile.Lock = null;
    if (!to_stdout) lock = lockfile.lockOrDie(path);
    var out: util.Buf = .empty;

    const version = if (version_in == -1) min_version else version_in;
    if (version < 2 or version > 3) {
        util.die("unsupported bundle version {d}", .{version});
    } else if (version < min_version) {
        util.die("cannot write bundle version {d} with algorithm {s}", .{ version, "sha1" });
    } else if (version == 2) {
        util.bufAppend(&out, "# v2 git bundle\n");
    } else {
        util.bufAppend(&out, "# v3 git bundle\n@object-format=sha1\n");
        if (filt) |f| util.bufPrint(&out, "@filter={s}\n", .{@import("../objfilter.zig").expandSpec(f)});
    }

    var pending: std.ArrayList(Pending) = .empty;
    for (revs.pending.items) |e| pending.append(gpa, .{ .item = e.item, .name = e.name }) catch util.oom();

    revs.boundary = 1;
    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    while (revision.getRevision(&revs)) |commit| {
        if (commit.obj.flags & cn.BOUNDARY == 0) continue;
        util.bufPrint(&out, "-{s} ", .{hash.hex(commit.obj.oid)});
        var sb: util.Buf = .empty;
        var ctx = pretty.Context{ .fmt = .oneline, .output_encoding = pretty.logOutputEncoding() };
        pretty.prettyPrintCommit(&ctx, commit, &sb);
        const subj = std.mem.trim(u8, sb.items, " \t\n\r");
        commit.obj.flags |= cn.UNINTERESTING;
        pending.append(gpa, .{ .item = &commit.obj, .name = subj }) catch util.oom();
        util.bufAppend(&out, subj);
        util.bufByte(&out, '\n');
    }

    // write bundle refs
    var ref_count: usize = 0;
    var seen = std.StringHashMap(void).init(gpa);
    for (pending.items) |e| {
        if (e.item.flags & cn.UNINTERESTING != 0) continue;
        const d = dwimRef(e.name) orelse continue;
        if (d.count != 1) continue;
        const rr = refs.resolveFull(e.name, true);
        const display = if (!rr.broken and rr.flags & refs.REF_ISSYMREF != 0) e.name else d.full;
        if (seen.contains(display)) continue;
        if (e.item.typ == .tag and !tagInDateRange(e.item.oid, &revs)) {
            e.item.flags |= cn.UNINTERESTING;
            continue;
        }
        if (e.item.flags & cn.SHOWN == 0 and e.item.typ == .commit) {
            util.warn("ref '{s}' is excluded by the rev-list options", .{e.name});
            continue;
        }
        ref_count += 1;
        seen.put(display, {}) catch util.oom();
        util.bufPrint(&out, "{s} {s}\n", .{ hash.hex(e.item.oid), display });
    }
    util.bufByte(&out, '\n');
    if (ref_count == 0) util.die("Refusing to create empty bundle.", .{});

    // write pack
    var in: util.Buf = .empty;
    for (pending.items) |e| {
        if (e.item.flags & cn.UNINTERESTING == 0) util.bufPrint(&in, "{s}\n", .{hash.hex(e.item.oid)});
    }
    util.bufAppend(&in, "--not\n");
    for (pending.items) |e| {
        if (e.item.flags & cn.UNINTERESTING != 0) util.bufPrint(&in, "{s}\n", .{hash.hex(e.item.oid)});
    }
    util.bufByte(&in, '\n');
    var pargv: std.ArrayList([]const u8) = .empty;
    pargv.appendSlice(gpa, &.{ proc.gitBinary(), "pack-objects", "--revs", "--stdout", "--thin", "--delta-base-offset", if (progress) "--all-progress" else "--quiet" }) catch util.oom();
    if (filt) |f| pargv.append(gpa, util.concat(&.{ "--filter=", f.spec })) catch util.oom();
    const res = os.run(pargv.items, .{ .stdin_data = in.items, .capture_stdout = true });
    if (res.status != 0) {
        if (res.signaled) util.err("pack-objects died of signal {d}", .{res.status - 128});
        util.err("pack-objects died", .{});
        if (lock) |l| l.rollback();
        return -1;
    }
    util.bufAppend(&out, res.stdout);
    if (lock) |l| {
        l.write(out.items);
        if (!l.commit()) util.dieErrno("cannot create '{s}'", .{path});
    } else {
        util.flushStdout();
        os.writeAll(1, out.items) catch {};
    }
    return 0;
}

pub fn unbundle(header: *const Header, extra: []const []const u8, mode: VerifyMode) i32 {
    return unbundleOpts(header, extra, mode, null);
}

/// unbundle() with unbundle_opts; fsck_msg_types non-null = VERIFY_BUNDLE_FSCK.
pub fn unbundleOpts(header: *const Header, extra: []const []const u8, mode: VerifyMode, fsck_msg_types: ?[]const u8) i32 {
    if (verifyBundle(header, mode) != 0) return -1;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "index-pack", "--fix-thin", "--stdin" }) catch util.oom();
    if (header.filter != null) argv.append(gpa, "--promisor=from-bundle") catch util.oom();
    if (fsck_msg_types) |m| argv.append(gpa, util.concat(&.{ "--fsck-objects", m })) catch util.oom();
    argv.appendSlice(gpa, extra) catch util.oom();
    const res = os.run(argv.items, .{ .stdin_data = header.pack, .capture_stdout = true });
    if (res.status != 0) {
        util.err("index-pack died", .{});
        return -1;
    }
    return 0;
}

fn fileArg(prefix: []const u8, a: []const u8) []const u8 {
    if (util.eql(a, "-") or (a.len > 0 and a[0] == '/') or prefix.len == 0) return a;
    return util.concat(&.{ prefix, a });
}

fn needFile(rest: []const []const u8, usage: []const []const u8, opts: []const po.Opt) void {
    if (rest.len == 0) {
        util.eprint("fatal: need a <file> argument\n\n", .{});
        po.usageWithOptions(usage, opts);
    }
}

fn curPrefix() []const u8 {
    if (repo_mod.repo_) |r| return r.prefix;
    return "";
}

fn cmdCreate(args: []const []const u8) u8 {
    var progress: i32 = if (os.isatty(2)) 1 else 0;
    var version: i32 = -1;
    var noop = false;
    const opts = [_]po.Opt{
        .{ .short = 'q', .long = "quiet", .kind = .negbit, .i = &progress, .val = 1, .help = "do not show progress meter" },
        po.bit(0, "progress", &progress, 1, "show progress meter"),
        .{ .long = "all-progress", .kind = .bit, .i = &progress, .val = 1, .help = "historical; same as --progress", .hidden = true },
        .{ .long = "all-progress-implied", .kind = .boolean, .b = &noop, .help = "(no-op)", .noneg = true },
        po.integer(0, "version", &version, "n", "specify bundle format version"),
    };
    const usage = [_][]const u8{create_usage};
    const rest = po.parse(args[1..], &opts, &usage, .{ .stop_at_non_option = true });
    needFile(rest, &usage, &opts);
    const file = fileArg(curPrefix(), rest[0]);
    if (repo_mod.repo_ == null) util.die("Need a repository to create a bundle.", .{});
    return if (createBundle(file, rest, version, progress != 0) != 0) 1 else 0;
}

fn cmdVerify(args: []const []const u8) u8 {
    var quiet = false;
    const opts = [_]po.Opt{po.boolean('q', "quiet", &quiet, "do not show bundle details")};
    const usage = [_][]const u8{verify_usage};
    const rest = po.parse(args[1..], &opts, &usage, .{ .stop_at_non_option = true });
    needFile(rest, &usage, &opts);
    const file = fileArg(curPrefix(), rest[0]);
    if (repo_mod.repo_ == null) {
        util.err("need a repository to verify a bundle", .{});
        return 1;
    }
    var h: Header = .{};
    readBundle(file, &h) orelse return 1;
    if (verifyBundle(&h, if (quiet) .quiet else .verbose) != 0) return 1;
    util.flushStdout();
    util.eprint("{s} is okay\n", .{if (util.eql(file, "-")) "<stdin>" else file});
    return 0;
}

fn cmdListHeads(args: []const []const u8) u8 {
    const opts = [_]po.Opt{};
    const usage = [_][]const u8{list_heads_usage};
    const rest = po.parse(args[1..], &opts, &usage, .{ .stop_at_non_option = true });
    needFile(rest, &usage, &opts);
    const file = fileArg(curPrefix(), rest[0]);
    var h: Header = .{};
    readBundle(file, &h) orelse return 1;
    listRefs(h.references.items, rest[1..]);
    return 0;
}

fn cmdUnbundle(args: []const []const u8) u8 {
    var progress = os.isatty(2);
    const opts = [_]po.Opt{po.boolean(0, "progress", &progress, "show progress meter")};
    const usage = [_][]const u8{unbundle_usage};
    const rest = po.parse(args[1..], &opts, &usage, .{ .stop_at_non_option = true });
    needFile(rest, &usage, &opts);
    const file = fileArg(curPrefix(), rest[0]);
    if (repo_mod.repo_ == null) util.die("Need a repository to unbundle.", .{});
    var h: Header = .{};
    readBundle(file, &h) orelse return 1;
    const extra: []const []const u8 = if (progress) &.{ "-v", "--progress-title", "Unbundling objects" } else &.{};
    if (unbundle(&h, extra, .normal) != 0) return 1;
    listRefs(h.references.items, rest[1..]);
    return 0;
}

pub fn cmdBundle(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").bundle);
    const opts = [_]po.Opt{};
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&all_usage, &opts);
    }
    const sub = args[1];
    if (util.eql(sub, "-h")) po.usageExit(&all_usage, &opts, false);
    if (util.eql(sub, "create")) return cmdCreate(args[1..]);
    if (util.eql(sub, "verify")) return cmdVerify(args[1..]);
    if (util.eql(sub, "list-heads")) return cmdListHeads(args[1..]);
    if (util.eql(sub, "unbundle")) return cmdUnbundle(args[1..]);
    if (sub.len > 0 and sub[0] == '-') {
        util.err("unknown option `{s}'", .{std.mem.trimStart(u8, sub, "-")});
    } else util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&all_usage, &opts);
}
