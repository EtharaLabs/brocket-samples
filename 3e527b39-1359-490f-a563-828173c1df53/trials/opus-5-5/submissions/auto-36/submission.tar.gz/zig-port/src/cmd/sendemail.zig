//! git send-email (port of git-send-email.perl).
//!
//! Supports sending through a sendmail-like program (--sendmail-cmd or an
//! absolute --smtp-server path) and --dry-run.  Real SMTP/TLS/IMAP
//! networking is not implemented; trying to use it dies with a message.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const main_mod = @import("../main.zig");
const gpa = util.gpa;
const Buf = util.Buf;
const Str = []const u8;
const List = std.ArrayList(Str);

extern "c" fn sleep(s: c_uint) c_uint;
extern "c" fn read(fd: c_int, buf: [*]u8, n: usize) isize;
extern "c" fn getservbyname(name: [*:0]const u8, proto: ?[*:0]const u8) ?*anyopaque;
extern "c" fn mkdtemp(template: [*:0]u8) ?[*:0]u8;

// ---------------------------------------------------------------- basics

fn push(l: *List, s: Str) void {
    l.append(gpa, s) catch util.oom();
}
fn eql(a: Str, b: Str) bool {
    return std.mem.eql(u8, a, b);
}
fn startsWith(a: Str, b: Str) bool {
    return std.mem.startsWith(u8, a, b);
}
fn isWs(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r' or c == 0x0c or c == 0x0b;
}
fn trimWs(s: Str) Str {
    var a: usize = 0;
    var b: usize = s.len;
    while (a < b and isWs(s[a])) a += 1;
    while (b > a and isWs(s[b - 1])) b -= 1;
    return s[a..b];
}
fn trimEndWs(s: Str) Str {
    var b: usize = s.len;
    while (b > 0 and isWs(s[b - 1])) b -= 1;
    return s[0..b];
}
fn trimStartWs(s: Str) Str {
    var a: usize = 0;
    while (a < s.len and isWs(s[a])) a += 1;
    return s[a..];
}
fn hasNonAscii(s: Str) bool {
    for (s) |c| if (c >= 0x80) return true;
    return false;
}
fn chomp(s: Str) Str {
    if (s.len > 0 and s[s.len - 1] == '\n') return s[0 .. s.len - 1];
    return s;
}
fn truthy(s: ?Str) bool {
    const v = s orelse return false;
    return !(v.len == 0 or eql(v, "0"));
}
fn lower(s: Str) []u8 {
    const r = gpa.alloc(u8, s.len) catch util.oom();
    for (s, 0..) |c, i| r[i] = std.ascii.toLower(c);
    return r;
}
fn startsWithI(s: Str, p: Str) bool {
    return s.len >= p.len and std.ascii.eqlIgnoreCase(s[0..p.len], p);
}
fn firstLower(s: ?Str) u8 {
    const v = s orelse return 0;
    if (v.len == 0) return 0;
    return std.ascii.toLower(v[0]);
}
/// Perl numeric conversion of a string (leading integer).
fn perlNum(s: Str) i64 {
    const t = trimStartWs(s);
    var i: usize = 0;
    var neg = false;
    if (i < t.len and (t[i] == '-' or t[i] == '+')) {
        neg = t[i] == '-';
        i += 1;
    }
    var v: i64 = 0;
    while (i < t.len and t[i] >= '0' and t[i] <= '9') : (i += 1) v = v *% 10 +% (t[i] - '0');
    return if (neg) -v else v;
}
fn isIntStr(s: Str) bool {
    var i: usize = 0;
    if (i < s.len and (s[i] == '-' or s[i] == '+')) i += 1;
    if (i >= s.len) return false;
    while (i < s.len) : (i += 1) if (s[i] < '0' or s[i] > '9') return false;
    return true;
}

/// Split into lines, each keeping its trailing "\n" (Perl <$fh> semantics).
fn linesKeep(data: Str) List {
    var l: List = .empty;
    var i: usize = 0;
    while (i < data.len) {
        const e = std.mem.indexOfScalarPos(u8, data, i, '\n');
        const end = if (e) |x| x + 1 else data.len;
        push(&l, data[i..end]);
        i = end;
    }
    return l;
}

fn readFileOrDie(path: Str) Str {
    return os.readFile(path) orelse pdief("unable to open {s}: {s}\n", .{ path, os.lastErr() });
}

// ---------------------------------------------------------------- dying

var fp_tmpdir: ?Str = null;
var header_tmp_files: List = .empty;

fn cleanupTemps() void {
    if (fp_tmpdir) |d| os.removeTree(d);
    fp_tmpdir = null;
    for (header_tmp_files.items) |f| _ = os.unlink(f);
    header_tmp_files.items.len = 0;
}

fn finish(code: u8) noreturn {
    cleanupTemps();
    os.exit(code);
}

/// Perl-style die: message to stderr, exit 255.
fn pdie(msg: Str) noreturn {
    util.ewrite(msg);
    if (msg.len == 0 or msg[msg.len - 1] != '\n') util.ewrite("\n");
    finish(255);
}
fn pdief(comptime f: []const u8, args: anytype) noreturn {
    pdie(util.fmt(f, args));
}

// ---------------------------------------------------------------- repository / git

var have_repo = false;
var repo_path: Str = ""; // absolute git dir
var wc_path: ?Str = null;

fn detectRepo() void {
    const r = os.run(&.{ proc.gitBinary(), "rev-parse", "--is-bare-repository", "--absolute-git-dir" }, .{ .capture_stdout = true, .no_stderr = true });
    if (r.status != 0) return;
    var it = std.mem.splitScalar(u8, r.stdout, '\n');
    const bare = it.next() orelse return;
    const dir = it.next() orelse return;
    if (dir.len == 0) return;
    have_repo = true;
    repo_path = util.dupe(dir);
    if (!eql(bare, "true")) {
        const t = os.run(&.{ proc.gitBinary(), "rev-parse", "--show-toplevel" }, .{ .capture_stdout = true, .no_stderr = true });
        const top = chomp(t.stdout);
        if (t.status == 0 and top.len > 0) wc_path = util.dupe(top) else wc_path = os.getcwd();
    }
}

fn gitArgv(args: []const Str) List {
    var argv: List = .empty;
    push(&argv, proc.gitBinary());
    for (args) |a| push(&argv, a);
    return argv;
}

/// Run git; when in_repo and we have a repository, run it like Git.pm's
/// $repo->command (in the work tree, with GIT_DIR set).
fn gitRun(args: []const Str, in_repo: bool, capture: bool) os.ChildResult {
    const argv = gitArgv(args);
    if (in_repo and have_repo) {
        const env = gpa.alloc([2]Str, 1) catch util.oom();
        env[0] = .{ "GIT_DIR", repo_path };
        return os.run(argv.items, .{ .capture_stdout = capture, .cwd = wc_path orelse repo_path, .env = env });
    }
    return os.run(argv.items, .{ .capture_stdout = capture });
}

fn gitFail(args: []const Str, status: u8) noreturn {
    var b: Buf = .empty;
    for (args, 0..) |a, i| {
        if (i > 0) util.bufAppend(&b, " ");
        util.bufAppend(&b, a);
    }
    util.ewrite(util.fmt("{s}: command returned error: {d}\n", .{ b.items, status }));
    finish(if (status == 0) 255 else status);
}

fn gitOut(args: []const Str, in_repo: bool) Str {
    const r = gitRun(args, in_repo, true);
    if (r.status != 0) gitFail(args, r.status);
    return r.stdout;
}

fn gitLines(args: []const Str, in_repo: bool) List {
    const out = gitOut(args, in_repo);
    var l: List = .empty;
    var it = std.mem.splitScalar(u8, out, '\n');
    while (it.next()) |x| push(&l, x);
    if (l.items.len > 0 and l.items[l.items.len - 1].len == 0) l.items.len -= 1;
    return l;
}

fn gitOneline(args: []const Str, in_repo: bool) Str {
    const out = gitOut(args, in_repo);
    const e = std.mem.indexOfScalar(u8, out, '\n') orelse out.len;
    return out[0..e];
}

/// Git::config-style lookup: returns null when the key is missing (exit 1).
fn gitConfigQuery(args: []const Str) ?Str {
    const r = gitRun(args, true, true);
    if (r.status == 1) return null;
    if (r.status != 0) gitFail(args, r.status);
    return chomp(r.stdout);
}

var ident_cache: [2]?Str = .{ null, null };
fn identPerson(which: usize) Str {
    if (ident_cache[which]) |v| return v;
    const name: Str = if (which == 0) "GIT_AUTHOR_IDENT" else "GIT_COMMITTER_IDENT";
    const line = gitOneline(&.{ "var", name }, true);
    // ^(.*) <(.*)> (\d+ [+-]\d{4})$
    var res: Str = " <>";
    if (std.mem.lastIndexOf(u8, line, "> ")) |gt| {
        if (std.mem.lastIndexOf(u8, line[0..gt], " <")) |lt| {
            res = util.concat(&.{ line[0..lt], " <", line[lt + 2 .. gt], ">" });
        }
    }
    ident_cache[which] = res;
    return res;
}
fn repoAuthor() Str {
    return identPerson(0);
}
fn repoCommitter() Str {
    return identPerson(1);
}

// ---------------------------------------------------------------- settings

var thread = true;
var chain_reply_to = false;
var suppress_from: ?bool = null;
var signed_off_by_cc: ?bool = null;
var cover_cc: ?bool = null;
var cover_to: ?bool = null;
var validate = true;
var multiedit: ?bool = null;
var annotate: ?bool = null;
var use_xmailer = true;
var forbid_sendmail_variables = true;
var mailmap = false;
var use_imap_only = false;

var smtp_encryption: ?Str = null;
var smtp_server: ?Str = null;
var smtp_server_port: ?Str = null;
var smtp_server_options: List = .empty;
var smtp_authuser: ?Str = null;
var smtp_authpass: ?Str = null;
var smtp_domain: ?Str = null;
var smtp_auth: ?Str = null;
var batch_size: ?Str = null;
var relogin_delay: ?Str = null;
var imap_sent_folder: ?Str = null;
var config_to: List = .empty;
var to_cmd: ?Str = null;
var config_cc: List = .empty;
var cc_cmd: ?Str = null;
var header_cmd: ?Str = null;
var aliasfiletype: ?Str = null;
var config_bcc: List = .empty;
var suppress_cc_list: List = .empty;
var envelope_sender: ?Str = null;
var confirm: ?Str = null;
var sender: ?Str = null;
var auto_8bit_encoding: ?Str = null;
var compose_encoding: ?Str = null;
var target_xfer_encoding: Str = "auto";
var sendmail_cmd: ?Str = null;

var alias_files: List = .empty;
var smtp_ssl_cert_path: ?Str = null;
var smtp_ssl_client_cert: ?Str = null;
var smtp_ssl_client_key: ?Str = null;
var mailmap_file: ?Str = null;
var mailmap_blob: ?Str = null;

// command line only
var identity: ?Str = null;
var no_identity = false;
var no_to = false;
var no_cc = false;
var no_bcc = false;
var no_header_cmd = false;
var getopt_to: List = .empty;
var getopt_cc: List = .empty;
var getopt_bcc: List = .empty;
var initial_in_reply_to: ?Str = null;
var reply_to: ?Str = null;
var initial_subject: ?Str = null;
var compose: i32 = 0;
var quiet = false;
var dry_run = false;
var format_patch: ?bool = null;
var force = false;
var dump_aliases = false;
var translate_aliases = false;
var help = false;
var completion_helper = false;
var reroll_count: ?Str = null;

// ---------------------------------------------------------------- config reading

const ValList = std.ArrayList(?Str);
var known_keys: std.StringHashMapUnmanaged(ValList) = .empty;
var known_key_order: List = .empty;

fn loadKnownKeys() void {
    const args = [_]Str{ "config", "--null", "--get-regexp", "^sende?mail[.]" };
    const r = gitRun(&args, true, true);
    if (r.status == 1) return;
    if (r.status != 0) gitFail(&args, r.status);
    var it = std.mem.splitScalar(u8, r.stdout, 0);
    while (it.next()) |rec| {
        if (rec.len == 0) continue;
        var k: Str = rec;
        var v: ?Str = null;
        if (std.mem.indexOfScalar(u8, rec, '\n')) |nl| {
            k = rec[0..nl];
            v = rec[nl + 1 ..];
        }
        const gop = known_keys.getOrPut(gpa, k) catch util.oom();
        if (!gop.found_existing) {
            gop.value_ptr.* = .empty;
            push(&known_key_order, k);
        }
        gop.value_ptr.append(gpa, v) catch util.oom();
    }
}

const bool_settings = [_]Str{ "thread", "chainreplyto", "suppressfrom", "signedoffcc", "signedoffbycc", "cccover", "tocover", "validate", "multiedit", "annotate", "xmailer", "forbidsendmailvariables", "mailmap", "useimaponly" };

fn setBoolSetting(s: Str, v: bool) void {
    if (eql(s, "thread")) thread = v else if (eql(s, "chainreplyto")) chain_reply_to = v else if (eql(s, "suppressfrom")) suppress_from = v else if (eql(s, "signedoffcc") or eql(s, "signedoffbycc")) signed_off_by_cc = v else if (eql(s, "cccover")) cover_cc = v else if (eql(s, "tocover")) cover_to = v else if (eql(s, "validate")) validate = v else if (eql(s, "multiedit")) multiedit = v else if (eql(s, "annotate")) annotate = v else if (eql(s, "xmailer")) use_xmailer = v else if (eql(s, "forbidsendmailvariables")) forbid_sendmail_variables = v else if (eql(s, "mailmap")) mailmap = v else if (eql(s, "useimaponly")) use_imap_only = v;
}

const scalar_settings = [_]Str{ "smtpencryption", "smtpserver", "smtpserverport", "smtpuser", "smtppass", "smtpdomain", "smtpauth", "smtpbatchsize", "smtprelogindelay", "imapsentfolder", "tocmd", "cccmd", "headercmd", "aliasfiletype", "envelopesender", "confirm", "from", "assume8bitencoding", "composeencoding", "transferencoding", "sendmailcmd" };

fn scalarSettingPtr(s: Str) *?Str {
    if (eql(s, "smtpencryption")) return &smtp_encryption;
    if (eql(s, "smtpserver")) return &smtp_server;
    if (eql(s, "smtpserverport")) return &smtp_server_port;
    if (eql(s, "smtpuser")) return &smtp_authuser;
    if (eql(s, "smtppass")) return &smtp_authpass;
    if (eql(s, "smtpdomain")) return &smtp_domain;
    if (eql(s, "smtpauth")) return &smtp_auth;
    if (eql(s, "smtpbatchsize")) return &batch_size;
    if (eql(s, "smtprelogindelay")) return &relogin_delay;
    if (eql(s, "imapsentfolder")) return &imap_sent_folder;
    if (eql(s, "tocmd")) return &to_cmd;
    if (eql(s, "cccmd")) return &cc_cmd;
    if (eql(s, "headercmd")) return &header_cmd;
    if (eql(s, "aliasfiletype")) return &aliasfiletype;
    if (eql(s, "envelopesender")) return &envelope_sender;
    if (eql(s, "confirm")) return &confirm;
    if (eql(s, "from")) return &sender;
    if (eql(s, "assume8bitencoding")) return &auto_8bit_encoding;
    if (eql(s, "composeencoding")) return &compose_encoding;
    return &sendmail_cmd;
}

const list_settings = [_]Str{ "smtpserveroption", "to", "cc", "bcc", "suppresscc" };
fn listSettingPtr(s: Str) *List {
    if (eql(s, "smtpserveroption")) return &smtp_server_options;
    if (eql(s, "to")) return &config_to;
    if (eql(s, "cc")) return &config_cc;
    if (eql(s, "bcc")) return &config_bcc;
    return &suppress_cc_list;
}

const path_scalar_settings = [_]Str{ "smtpsslcertpath", "smtpsslclientcert", "smtpsslclientkey", "mailmap.file", "mailmap.blob" };
fn pathSettingPtr(s: Str) *?Str {
    if (eql(s, "smtpsslcertpath")) return &smtp_ssl_cert_path;
    if (eql(s, "smtpsslclientcert")) return &smtp_ssl_client_cert;
    if (eql(s, "smtpsslclientkey")) return &smtp_ssl_client_key;
    if (eql(s, "mailmap.file")) return &mailmap_file;
    return &mailmap_blob;
}

var configured: std.StringHashMapUnmanaged(void) = .empty;
fn markConfigured(setting: Str) bool {
    const gop = configured.getOrPut(gpa, setting) catch util.oom();
    return gop.found_existing;
}

fn readConfig(prefix: Str) void {
    for (bool_settings) |setting| {
        const key = util.concat(&.{ prefix, ".", setting });
        const vals = known_keys.get(key) orelse continue;
        var v: ?bool = null;
        if (vals.items.len == 1 and vals.items[0] != null and (eql(vals.items[0].?, "true") or eql(vals.items[0].?, "false"))) {
            v = eql(vals.items[0].?, "true");
        } else {
            if (gitConfigQuery(&.{ "config", "--bool", "--get", key })) |s| v = eql(s, "true");
        }
        const bv = v orelse continue;
        if (markConfigured(setting)) continue;
        setBoolSetting(setting, bv);
    }
    {
        const setting = "aliasesfile";
        const key = util.concat(&.{ prefix, ".", setting });
        if (known_keys.get(key) != null) {
            const args = [_]Str{ "config", "--path", "--get-all", key };
            const r = gitRun(&args, true, true);
            if (r.status != 0 and r.status != 1) gitFail(&args, r.status);
            var vals: List = .empty;
            if (r.status == 0) {
                var it = std.mem.splitScalar(u8, r.stdout, '\n');
                while (it.next()) |x| push(&vals, x);
                if (vals.items.len > 0 and vals.items[vals.items.len - 1].len == 0) vals.items.len -= 1;
            }
            if (vals.items.len > 0 and !markConfigured(setting)) alias_files = vals;
        }
    }
    for (path_scalar_settings) |setting| {
        const key = util.concat(&.{ prefix, ".", setting });
        if (known_keys.get(key) == null) continue;
        const v = gitConfigQuery(&.{ "config", "--path", "--get", key }) orelse continue;
        if (markConfigured(setting)) continue;
        pathSettingPtr(setting).* = v;
    }
    for (list_settings) |setting| {
        const key = util.concat(&.{ prefix, ".", setting });
        const vals = known_keys.get(key) orelse continue;
        if (markConfigured(setting)) continue;
        var l: List = .empty;
        for (vals.items) |x| if (x) |s| push(&l, s);
        listSettingPtr(setting).* = l;
    }
    for (scalar_settings) |setting| {
        const key = util.concat(&.{ prefix, ".", setting });
        const vals = known_keys.get(key) orelse continue;
        const v = vals.items[vals.items.len - 1] orelse continue;
        if (markConfigured(setting)) continue;
        if (eql(setting, "transferencoding")) target_xfer_encoding = v else scalarSettingPtr(setting).* = v;
    }
}

// ---------------------------------------------------------------- Getopt::Long emulation

const Kind = enum { flag, neg, req_s, opt_s, req_i, opt_i };
const Spec = struct { names: []const Str, kind: Kind, id: Opt };

const Opt = enum {
    identity,
    no_identity,
    h,
    dump_aliases,
    translate_aliases,
    from,
    in_reply_to,
    reply_to,
    subject,
    to,
    to_cmd,
    no_to,
    cc,
    no_cc,
    bcc,
    no_bcc,
    chain_reply_to,
    sendmail_cmd,
    smtp_server,
    smtp_server_option,
    smtp_server_port,
    smtp_user,
    smtp_pass,
    smtp_ssl,
    smtp_encryption,
    smtp_ssl_cert_path,
    smtp_ssl_client_cert,
    smtp_ssl_client_key,
    smtp_debug,
    smtp_domain,
    smtp_auth,
    no_smtp_auth,
    imap_sent_folder,
    use_imap_only,
    annotate,
    compose,
    quiet,
    cc_cmd,
    header_cmd,
    no_header_cmd,
    suppress_from,
    suppress_cc,
    signed_off_cc,
    cc_cover,
    to_cover,
    confirm,
    dry_run,
    envelope_sender,
    thread,
    validate,
    transfer_encoding,
    mailmap,
    format_patch,
    eightbit_encoding,
    compose_encoding,
    force,
    xmailer,
    batch_size,
    relogin_delay,
    git_completion_helper,
    v,
    outlook_id_fix,
};

const identity_specs = [_]Spec{
    .{ .names = &.{"identity"}, .kind = .req_s, .id = .identity },
    .{ .names = &.{"no-identity"}, .kind = .flag, .id = .no_identity },
};
const dump_specs = [_]Spec{
    .{ .names = &.{"h"}, .kind = .flag, .id = .h },
    .{ .names = &.{"dump-aliases"}, .kind = .flag, .id = .dump_aliases },
    .{ .names = &.{"translate-aliases"}, .kind = .flag, .id = .translate_aliases },
};
const main_specs = [_]Spec{
    .{ .names = &.{ "sender", "from" }, .kind = .req_s, .id = .from },
    .{ .names = &.{"in-reply-to"}, .kind = .req_s, .id = .in_reply_to },
    .{ .names = &.{"reply-to"}, .kind = .req_s, .id = .reply_to },
    .{ .names = &.{"subject"}, .kind = .req_s, .id = .subject },
    .{ .names = &.{"to"}, .kind = .req_s, .id = .to },
    .{ .names = &.{"to-cmd"}, .kind = .req_s, .id = .to_cmd },
    .{ .names = &.{"no-to"}, .kind = .flag, .id = .no_to },
    .{ .names = &.{"cc"}, .kind = .req_s, .id = .cc },
    .{ .names = &.{"no-cc"}, .kind = .flag, .id = .no_cc },
    .{ .names = &.{"bcc"}, .kind = .req_s, .id = .bcc },
    .{ .names = &.{"no-bcc"}, .kind = .flag, .id = .no_bcc },
    .{ .names = &.{"chain-reply-to"}, .kind = .neg, .id = .chain_reply_to },
    .{ .names = &.{"sendmail-cmd"}, .kind = .req_s, .id = .sendmail_cmd },
    .{ .names = &.{"smtp-server"}, .kind = .req_s, .id = .smtp_server },
    .{ .names = &.{"smtp-server-option"}, .kind = .req_s, .id = .smtp_server_option },
    .{ .names = &.{"smtp-server-port"}, .kind = .req_s, .id = .smtp_server_port },
    .{ .names = &.{"smtp-user"}, .kind = .req_s, .id = .smtp_user },
    .{ .names = &.{"smtp-pass"}, .kind = .opt_s, .id = .smtp_pass },
    .{ .names = &.{"smtp-ssl"}, .kind = .flag, .id = .smtp_ssl },
    .{ .names = &.{"smtp-encryption"}, .kind = .req_s, .id = .smtp_encryption },
    .{ .names = &.{"smtp-ssl-cert-path"}, .kind = .req_s, .id = .smtp_ssl_cert_path },
    .{ .names = &.{"smtp-ssl-client-cert"}, .kind = .req_s, .id = .smtp_ssl_client_cert },
    .{ .names = &.{"smtp-ssl-client-key"}, .kind = .req_s, .id = .smtp_ssl_client_key },
    .{ .names = &.{"smtp-debug"}, .kind = .opt_i, .id = .smtp_debug },
    .{ .names = &.{"smtp-domain"}, .kind = .opt_s, .id = .smtp_domain },
    .{ .names = &.{"smtp-auth"}, .kind = .req_s, .id = .smtp_auth },
    .{ .names = &.{"no-smtp-auth"}, .kind = .flag, .id = .no_smtp_auth },
    .{ .names = &.{"imap-sent-folder"}, .kind = .req_s, .id = .imap_sent_folder },
    .{ .names = &.{"use-imap-only"}, .kind = .neg, .id = .use_imap_only },
    .{ .names = &.{"annotate"}, .kind = .neg, .id = .annotate },
    .{ .names = &.{"compose"}, .kind = .flag, .id = .compose },
    .{ .names = &.{"quiet"}, .kind = .flag, .id = .quiet },
    .{ .names = &.{"cc-cmd"}, .kind = .req_s, .id = .cc_cmd },
    .{ .names = &.{"header-cmd"}, .kind = .req_s, .id = .header_cmd },
    .{ .names = &.{"no-header-cmd"}, .kind = .flag, .id = .no_header_cmd },
    .{ .names = &.{"suppress-from"}, .kind = .neg, .id = .suppress_from },
    .{ .names = &.{"suppress-cc"}, .kind = .req_s, .id = .suppress_cc },
    .{ .names = &.{ "signed-off-cc", "signed-off-by-cc" }, .kind = .neg, .id = .signed_off_cc },
    .{ .names = &.{"cc-cover"}, .kind = .neg, .id = .cc_cover },
    .{ .names = &.{"to-cover"}, .kind = .neg, .id = .to_cover },
    .{ .names = &.{"confirm"}, .kind = .req_s, .id = .confirm },
    .{ .names = &.{"dry-run"}, .kind = .flag, .id = .dry_run },
    .{ .names = &.{"envelope-sender"}, .kind = .req_s, .id = .envelope_sender },
    .{ .names = &.{"thread"}, .kind = .neg, .id = .thread },
    .{ .names = &.{"validate"}, .kind = .neg, .id = .validate },
    .{ .names = &.{"transfer-encoding"}, .kind = .req_s, .id = .transfer_encoding },
    .{ .names = &.{"mailmap"}, .kind = .neg, .id = .mailmap },
    .{ .names = &.{"use-mailmap"}, .kind = .neg, .id = .mailmap },
    .{ .names = &.{"format-patch"}, .kind = .neg, .id = .format_patch },
    .{ .names = &.{"8bit-encoding"}, .kind = .req_s, .id = .eightbit_encoding },
    .{ .names = &.{"compose-encoding"}, .kind = .req_s, .id = .compose_encoding },
    .{ .names = &.{"force"}, .kind = .flag, .id = .force },
    .{ .names = &.{"xmailer"}, .kind = .neg, .id = .xmailer },
    .{ .names = &.{"batch-size"}, .kind = .req_i, .id = .batch_size },
    .{ .names = &.{"relogin-delay"}, .kind = .req_i, .id = .relogin_delay },
    .{ .names = &.{"git-completion-helper"}, .kind = .flag, .id = .git_completion_helper },
    .{ .names = &.{"v"}, .kind = .req_s, .id = .v },
    .{ .names = &.{"outlook-id-fix"}, .kind = .neg, .id = .outlook_id_fix },
};

fn applyOpt(id: Opt, neg: bool, val: Str) void {
    const b = !neg;
    switch (id) {
        .identity => identity = val,
        .no_identity => no_identity = true,
        .h => help = true,
        .dump_aliases => dump_aliases = true,
        .translate_aliases => translate_aliases = true,
        .from => sender = val,
        .in_reply_to => initial_in_reply_to = val,
        .reply_to => reply_to = val,
        .subject => initial_subject = val,
        .to => push(&getopt_to, val),
        .to_cmd => to_cmd = val,
        .no_to => no_to = true,
        .cc => push(&getopt_cc, val),
        .no_cc => no_cc = true,
        .bcc => push(&getopt_bcc, val),
        .no_bcc => no_bcc = true,
        .chain_reply_to => chain_reply_to = b,
        .sendmail_cmd => sendmail_cmd = val,
        .smtp_server => smtp_server = val,
        .smtp_server_option => push(&smtp_server_options, val),
        .smtp_server_port => smtp_server_port = val,
        .smtp_user => smtp_authuser = val,
        .smtp_pass => smtp_authpass = val,
        .smtp_ssl => smtp_encryption = "ssl",
        .smtp_encryption => smtp_encryption = val,
        .smtp_ssl_cert_path => smtp_ssl_cert_path = val,
        .smtp_ssl_client_cert => smtp_ssl_client_cert = val,
        .smtp_ssl_client_key => smtp_ssl_client_key = val,
        .smtp_debug => {},
        .smtp_domain => smtp_domain = val,
        .smtp_auth => smtp_auth = val,
        .no_smtp_auth => smtp_auth = "none",
        .imap_sent_folder => imap_sent_folder = val,
        .use_imap_only => use_imap_only = b,
        .annotate => annotate = b,
        .compose => compose = 1,
        .quiet => quiet = true,
        .cc_cmd => cc_cmd = val,
        .header_cmd => header_cmd = val,
        .no_header_cmd => no_header_cmd = true,
        .suppress_from => suppress_from = b,
        .suppress_cc => push(&suppress_cc_list, val),
        .signed_off_cc => signed_off_by_cc = b,
        .cc_cover => cover_cc = b,
        .to_cover => cover_to = b,
        .confirm => confirm = val,
        .dry_run => dry_run = true,
        .envelope_sender => envelope_sender = val,
        .thread => thread = b,
        .validate => validate = b,
        .transfer_encoding => target_xfer_encoding = val,
        .mailmap => mailmap = b,
        .format_patch => format_patch = b,
        .eightbit_encoding => auto_8bit_encoding = val,
        .compose_encoding => compose_encoding = val,
        .force => force = true,
        .xmailer => use_xmailer = b,
        .batch_size => batch_size = val,
        .relogin_delay => relogin_delay = val,
        .git_completion_helper => completion_helper = true,
        .v => reroll_count = val,
        .outlook_id_fix => {},
    }
}

const Hit = struct { si: usize, neg: bool };

fn findOpt(specs: []const Spec, lname: Str) ?Hit {
    var hits: std.ArrayList(Hit) = .empty;
    // exact match first
    for (specs, 0..) |sp, si| {
        for (sp.names) |n| {
            if (eql(n, lname)) return .{ .si = si, .neg = false };
            if (sp.kind == .neg) {
                if (eql(util.concat(&.{ "no-", n }), lname) or eql(util.concat(&.{ "no", n }), lname)) return .{ .si = si, .neg = true };
            }
        }
    }
    if (lname.len == 0) return null;
    for (specs, 0..) |sp, si| {
        for (sp.names) |n| {
            if (startsWith(n, lname)) hits.append(gpa, .{ .si = si, .neg = false }) catch util.oom();
            if (sp.kind == .neg) {
                if (startsWith(util.concat(&.{ "no-", n }), lname) or startsWith(util.concat(&.{ "no", n }), lname))
                    hits.append(gpa, .{ .si = si, .neg = true }) catch util.oom();
            }
        }
    }
    if (hits.items.len == 0) return null;
    const first = hits.items[0];
    for (hits.items) |h| {
        if (h.si != first.si or h.neg != first.neg) return null;
    }
    return first;
}

fn getopt(args: []const Str, specs: []const Spec) List {
    var rest: List = .empty;
    var i: usize = 0;
    while (i < args.len) {
        const a = args[i];
        i += 1;
        if (eql(a, "--")) {
            push(&rest, a);
            while (i < args.len) : (i += 1) push(&rest, args[i]);
            break;
        }
        if (a.len < 2 or a[0] != '-') {
            push(&rest, a);
            continue;
        }
        const body = if (startsWith(a, "--")) a[2..] else a[1..];
        var name = body;
        var inline_val: ?Str = null;
        if (std.mem.indexOfScalar(u8, body, '=')) |eq| {
            name = body[0..eq];
            inline_val = body[eq + 1 ..];
        }
        const hit = findOpt(specs, lower(name)) orelse {
            push(&rest, a);
            continue;
        };
        const sp = specs[hit.si];
        switch (sp.kind) {
            .flag, .neg => {
                if (inline_val != null) {
                    push(&rest, a);
                    continue;
                }
                applyOpt(sp.id, hit.neg, "1");
            },
            .req_s => {
                if (inline_val) |v| {
                    if (v.len == 0) {
                        push(&rest, a);
                        continue;
                    }
                    applyOpt(sp.id, false, v);
                } else if (i < args.len) {
                    applyOpt(sp.id, false, args[i]);
                    i += 1;
                } else {
                    push(&rest, a);
                }
            },
            .opt_s => {
                if (inline_val) |v| {
                    applyOpt(sp.id, false, v);
                } else if (i < args.len and !(eql(args[i], "--") or (args[i].len > 1 and args[i][0] == '-'))) {
                    applyOpt(sp.id, false, args[i]);
                    i += 1;
                } else applyOpt(sp.id, false, "");
            },
            .req_i => {
                if (inline_val) |v| {
                    if (!isIntStr(v)) {
                        push(&rest, a);
                        continue;
                    }
                    applyOpt(sp.id, false, v);
                } else if (i < args.len and isIntStr(args[i])) {
                    applyOpt(sp.id, false, args[i]);
                    i += 1;
                } else push(&rest, a);
            },
            .opt_i => {
                if (inline_val) |v| {
                    if (!isIntStr(v)) {
                        push(&rest, a);
                        continue;
                    }
                    applyOpt(sp.id, false, v);
                } else if (i < args.len and isIntStr(args[i])) {
                    applyOpt(sp.id, false, args[i]);
                    i += 1;
                } else applyOpt(sp.id, false, "0");
            },
        }
    }
    return rest;
}

// ---------------------------------------------------------------- usage

const usage_text =
    \\git send-email [<options>] <file|directory>
    \\git send-email [<options>] <format-patch options>
    \\git send-email --dump-aliases
    \\git send-email --translate-aliases
    \\
    \\  Composing:
    \\    --from                  <str>  * Email From:
    \\    --[no-]to               <str>  * Email To:
    \\    --[no-]cc               <str>  * Email Cc:
    \\    --[no-]bcc              <str>  * Email Bcc:
    \\    --subject               <str>  * Email "Subject:"
    \\    --reply-to              <str>  * Email "Reply-To:"
    \\    --in-reply-to           <str>  * Email "In-Reply-To:"
    \\    --[no-]outlook-id-fix          * The SMTP host is an Outlook server that munges the
    \\                                     Message-ID. Retrieve it from the server.
    \\    --[no-]xmailer                 * Add "X-Mailer:" header (default).
    \\    --[no-]annotate                * Review each patch that will be sent in an editor.
    \\    --compose                      * Open an editor for introduction.
    \\    --compose-encoding      <str>  * Encoding to assume for introduction.
    \\    --8bit-encoding         <str>  * Encoding to assume 8bit mails if undeclared
    \\    --transfer-encoding     <str>  * Transfer encoding to use (quoted-printable, 8bit, base64)
    \\    --[no-]mailmap                 * Use mailmap file to map all email addresses to canonical
    \\                                     real names and email addresses.
    \\
    \\  Sending:
    \\    --envelope-sender       <str>  * Email envelope sender.
    \\    --sendmail-cmd          <str>  * Command to run to send email.
    \\    --smtp-server       <str:int>  * Outgoing SMTP server to use. The port
    \\                                     is optional. Default 'localhost'.
    \\    --smtp-server-option    <str>  * Outgoing SMTP server option to use.
    \\    --smtp-server-port      <int>  * Outgoing SMTP server port.
    \\    --smtp-user             <str>  * Username for SMTP-AUTH.
    \\    --smtp-pass             <str>  * Password for SMTP-AUTH; not necessary.
    \\    --smtp-encryption       <str>  * tls or ssl; anything else disables.
    \\    --smtp-ssl                     * Deprecated. Use `--smtp-encryption ssl`.
    \\    --smtp-ssl-cert-path    <str>  * Path to ca-certificates (either directory or file).
    \\                                     Pass an empty string to disable certificate
    \\                                     verification.
    \\    --smtp-ssl-client-cert  <str>  * Path to the client certificate file
    \\    --smtp-ssl-client-key   <str>  * Path to the private key file for the client certificate
    \\    --smtp-domain           <str>  * The domain name sent to HELO/EHLO handshake
    \\    --smtp-auth             <str>  * Space-separated list of allowed AUTH mechanisms, or
    \\                                     "none" to disable authentication.
    \\                                     This setting forces to use one of the listed mechanisms.
    \\    --no-smtp-auth                 * Disable SMTP authentication. Shorthand for
    \\                                     `--smtp-auth=none`
    \\    --smtp-debug            <0|1>  * Disable, enable Net::SMTP debug.
    \\    --imap-sent-folder      <str>  * IMAP folder where a copy of the emails should be sent.
    \\                                     Make sure `git imap-send` is set up to use this feature.
    \\    --[no-]use-imap-only           * Only copy emails to the IMAP folder specified by
    \\                                     `--imap-sent-folder` instead of actually sending them.
    \\
    \\    --batch-size            <int>  * send max <int> message per connection.
    \\    --relogin-delay         <int>  * delay <int> seconds between two successive login.
    \\                                     This option can only be used with --batch-size
    \\
    \\  Automating:
    \\    --identity              <str>  * Use the sendemail.<id> options.
    \\    --to-cmd                <str>  * Email To: via `<str> $patch_path`.
    \\    --cc-cmd                <str>  * Email Cc: via `<str> $patch_path`.
    \\    --header-cmd            <str>  * Add headers via `<str> $patch_path`.
    \\    --no-header-cmd                * Disable any header command in use.
    \\    --suppress-cc           <str>  * author, self, sob, cc, cccmd, body, bodycc, misc-by, all.
    \\    --[no-]cc-cover                * Email Cc: addresses in the cover letter.
    \\    --[no-]to-cover                * Email To: addresses in the cover letter.
    \\    --[no-]signed-off-by-cc        * Send to Signed-off-by: addresses. Default on.
    \\    --[no-]suppress-from           * Send to self. Default off.
    \\    --[no-]chain-reply-to          * Chain In-Reply-To: fields. Default off.
    \\    --[no-]thread                  * Use In-Reply-To: field. Default on.
    \\
    \\  Administering:
    \\    --confirm               <str>  * Confirm recipients before sending;
    \\                                     auto, cc, compose, always, or never.
    \\    --quiet                        * Output one line of info per email.
    \\    --dry-run                      * Don't actually send the emails.
    \\    --[no-]validate                * Perform patch sanity checks. Default on.
    \\    --[no-]format-patch            * understand any non optional arguments as
    \\                                     `git format-patch` ones.
    \\    --force                        * Send even if safety checks would prevent it.
    \\
    \\  Information:
    \\    --dump-aliases                 * Dump configured aliases and exit.
    \\    --translate-aliases            * Translate aliases read from standard
    \\                                     input according to the configured email
    \\                                     alias file(s), outputting the result to
    \\                                     standard output.
    \\
    \\
;

fn usage(code: u8) noreturn {
    util.out(usage_text);
    finish(code);
}

fn doCompletionHelper() noreturn {
    var opts: List = .empty;
    const groups = [_][]const Spec{ &main_specs, &dump_specs, &identity_specs };
    for (groups) |g| {
        for (g) |sp| {
            if (sp.id == .git_completion_helper or sp.id == .h) continue;
            for (sp.names) |n| {
                switch (sp.kind) {
                    .req_s, .opt_s, .req_i, .opt_i => push(&opts, util.concat(&.{ "--", n, "=" })),
                    .flag => push(&opts, util.concat(&.{ "--", n })),
                    .neg => {
                        push(&opts, util.concat(&.{ "--", n }));
                    },
                }
            }
            if (sp.kind == .neg) for (sp.names) |n| push(&opts, util.concat(&.{ "--no-", n }));
        }
    }
    const fp = gitOut(&.{ "format-patch", "--git-completion-helper" }, true);
    var it = std.mem.splitScalar(u8, fp, ' ');
    while (it.next()) |x| push(&opts, x);
    var seen: std.StringHashMapUnmanaged(void) = .empty;
    var first = true;
    for (opts.items) |o| {
        if (o.len == 0) continue;
        const gop = seen.getOrPut(gpa, o) catch util.oom();
        if (gop.found_existing) continue;
        if (!first) util.out(" ");
        first = false;
        util.out(o);
    }
    finish(0);
}

// ---------------------------------------------------------------- terminal prompts

var term_in: c_int = -2;
var term_out: c_int = -1;

fn termOpen() bool {
    if (term_in == -2) {
        if (truthy(os.getenv("GIT_SEND_EMAIL_NOTTY"))) {
            term_in = 0;
            term_out = 1;
        } else {
            const fd = os.openFile("/dev/tty", os.O_RDWR, 0);
            term_in = if (fd < 0) -1 else fd;
            term_out = term_in;
        }
    }
    return term_in >= 0;
}

fn termReadline(prompt: Str) ?Str {
    util.flushStdout();
    os.writeAll(term_out, prompt) catch {};
    var b: Buf = .empty;
    var got = false;
    while (true) {
        var c: [1]u8 = undefined;
        const n = read(term_in, &c, 1);
        if (n <= 0) break;
        got = true;
        if (c[0] == '\n') break;
        util.bufByte(&b, c[0]);
    }
    if (!got) return null;
    return b.items;
}

const Valid = enum { none, at_dot, nonspace, yn, qde, send };

fn validMatch(v: Valid, s: Str) bool {
    switch (v) {
        .none => return true,
        .at_dot => {
            const at = std.mem.indexOfScalar(u8, s, '@') orelse return false;
            return std.mem.indexOfScalarPos(u8, s, at + 1, '.') != null;
        },
        .nonspace => {
            if (s.len == 0) return false;
            for (s) |c| if (isWs(c)) return false;
            return true;
        },
        .yn => return firstLower(s) == 'y' or firstLower(s) == 'n',
        .qde => {
            const c = firstLower(s);
            return c == 'q' or c == 'd' or c == 'e';
        },
        .send => {
            const c = firstLower(s);
            return c == 'y' or c == 'n' or c == 'e' or c == 'q' or c == 'a';
        },
    }
}

fn ask(prompt: Str, valid: Valid, default: ?Str, confirm_only: bool) ?Str {
    if (!termOpen()) return default;
    var i: usize = 0;
    while (i < 10) : (i += 1) {
        const resp = termReadline(prompt) orelse {
            util.out("\n");
            return default;
        };
        if (resp.len == 0 and default != null) return default;
        if (validMatch(valid, resp)) return resp;
        if (confirm_only) {
            const yn = termReadline(util.fmt("Are you sure you want to use <{s}> [y/N]? ", .{resp}));
            if (yn) |y| {
                for (y) |c| if (c == 'y' or c == 'Y') return resp;
            }
        }
    }
    return null;
}

// ---------------------------------------------------------------- editor

var editor: ?Str = null;

fn doEdit(files: []const Str) void {
    if (editor == null) editor = gitOneline(&.{ "var", "GIT_EDITOR" }, true);
    const ed = editor.?;
    const script = util.concat(&.{ ed, " \"$@\"" });
    const die_msg = "the editor exited uncleanly, aborting everything";
    if (multiedit != null and !multiedit.?) {
        for (files) |f| {
            const r = os.run(&.{ "sh", "-c", script, ed, f }, .{});
            if (r.status != 0) pdie(die_msg);
        }
    } else {
        var argv: List = .empty;
        push(&argv, "sh");
        push(&argv, "-c");
        push(&argv, script);
        push(&argv, ed);
        for (files) |f| push(&argv, f);
        const r = os.run(argv.items, .{});
        if (r.status != 0) pdie(die_msg);
    }
}

// ---------------------------------------------------------------- RFC 2047

fn isTokenChar(c: u8) bool {
    if (c <= 0x20 or c >= 0x7f) return false;
    return std.mem.indexOfScalar(u8, "][()<>@,;:\\\"/?.=", c) == null;
}
fn isEncTextChar(c: u8) bool {
    if (c <= 0x20 or c >= 0x7f) return false;
    return c != '?';
}

const EncWord = struct { end: usize, charset: Str, enc: Str, text: Str };

fn matchEncodedWord(s: Str, p: usize) ?EncWord {
    if (p + 2 > s.len or s[p] != '=' or s[p + 1] != '?') return null;
    var i = p + 2;
    const cs = i;
    while (i < s.len and isTokenChar(s[i])) i += 1;
    if (i == cs or i >= s.len or s[i] != '?') return null;
    const charset = s[cs..i];
    i += 1;
    const es = i;
    while (i < s.len and isTokenChar(s[i])) i += 1;
    if (i == es or i >= s.len or s[i] != '?') return null;
    const enc = s[es..i];
    i += 1;
    const ts = i;
    while (i < s.len and isEncTextChar(s[i])) i += 1;
    if (i == ts or i + 1 >= s.len or s[i] != '?' or s[i + 1] != '=') return null;
    return .{ .end = i + 2, .charset = charset, .enc = enc, .text = s[ts..i] };
}

fn hexVal(c: u8) ?u8 {
    return switch (c) {
        '0'...'9' => c - '0',
        'a'...'f' => c - 'a' + 10,
        'A'...'F' => c - 'A' + 10,
        else => null,
    };
}

const Unquoted = struct { s: Str, charset: ?Str };

fn unquoteRfc2047(s: Str) Unquoted {
    var b: Buf = .empty;
    var charset: ?Str = null;
    var i: usize = 0;
    while (i < s.len) {
        const w = matchEncodedWord(s, i) orelse {
            util.bufByte(&b, s[i]);
            i += 1;
            continue;
        };
        var cur = w;
        var pos = i;
        while (true) {
            charset = cur.charset;
            if (eql(cur.enc, "q") or eql(cur.enc, "Q")) {
                var k: usize = 0;
                const t = cur.text;
                while (k < t.len) {
                    if (t[k] == '_') {
                        util.bufByte(&b, ' ');
                        k += 1;
                    } else if (t[k] == '=' and k + 2 < t.len + 0 + 1 and k + 2 <= t.len - 0 and k + 2 < t.len + 1 and hexVal(t[k + 1]) != null and hexVal(t[k + 2]) != null) {
                        util.bufByte(&b, hexVal(t[k + 1]).? * 16 + hexVal(t[k + 2]).?);
                        k += 3;
                    } else {
                        util.bufByte(&b, t[k]);
                        k += 1;
                    }
                }
            } else {
                util.bufAppend(&b, s[pos..cur.end]);
            }
            // look for [ \t]+ followed by another encoded word
            var j = cur.end;
            while (j < s.len and (s[j] == ' ' or s[j] == '\t')) j += 1;
            if (j == cur.end) {
                i = cur.end;
                break;
            }
            const nw = matchEncodedWord(s, j) orelse {
                i = cur.end;
                break;
            };
            pos = j;
            cur = nw;
        }
    }
    return .{ .s = b.items, .charset = charset };
}

fn quoteRfc2047(s: Str, encoding: ?Str) Str {
    const enc = if (truthy(encoding)) encoding.? else "UTF-8";
    var b: Buf = .empty;
    util.bufAppend(&b, "=?");
    util.bufAppend(&b, enc);
    util.bufAppend(&b, "?q?");
    for (s) |c| {
        if (std.ascii.isAlphanumeric(c) or c == '-' or c == '!' or c == '*' or c == '+' or c == '/') {
            util.bufByte(&b, c);
        } else util.bufPrint(&b, "={X:0>2}", .{c});
    }
    util.bufAppend(&b, "?=");
    return b.items;
}

fn isRfc2047Quoted(s: ?Str) bool {
    const v = s orelse return false;
    if (v.len > 75) return false;
    if (v.len >= 2 and v[0] == '"' and v[v.len - 1] == '"' and !hasNonAscii(v)) return true;
    const w = matchEncodedWord(v, 0) orelse return false;
    return w.end == v.len;
}

fn subjectNeedsQuoting(s: Str) bool {
    return hasNonAscii(s) or std.mem.indexOf(u8, s, "=?") != null;
}

fn quoteSubject(s: ?Str, encoding: ?Str) ?Str {
    const v = s orelse return null;
    if (subjectNeedsQuoting(v)) return quoteRfc2047(v, encoding);
    return v;
}

// ---------------------------------------------------------------- address helpers

fn sanitizeAddress(r_in: Str) Str {
    var r = r_in;
    // remove garbage after email address: s/(.*>).*$/$1/
    {
        const nl = std.mem.indexOfScalar(u8, r, '\n') orelse r.len;
        if (std.mem.lastIndexOfScalar(u8, r[0..nl], '>')) |gt| {
            r = util.concat(&.{ r[0 .. gt + 1], r[nl..] });
            if (r.len > gt + 1 and r[gt + 1] == '\n' and r.len == gt + 2) {} else if (r.len > gt + 1) r = r[0 .. gt + 1];
        }
    }
    const lt = std.mem.indexOfScalar(u8, r, '<') orelse return r;
    const name0 = trimEndWs(r[0..lt]);
    const addr = r[lt..];
    if (!truthy(name0)) return r;
    if (isRfc2047Quoted(name0)) return r;
    // remove non-escaped quotes
    var nb: Buf = .empty;
    var i: usize = 0;
    while (i < name0.len) {
        if (i == 0 and name0[0] == '"') {
            i = 1;
            continue;
        }
        if (name0[i] != '\\' and i + 1 < name0.len and name0[i + 1] == '"') {
            util.bufByte(&nb, name0[i]);
            i += 2;
            continue;
        }
        util.bufByte(&nb, name0[i]);
        i += 1;
    }
    var name: Str = nb.items;
    if (hasNonAscii(name)) {
        name = quoteRfc2047(name, null);
    } else {
        var special = false;
        for (name) |c| {
            if (c < 0x20 or c == 0x7f or std.mem.indexOfScalar(u8, "][()<>@,;:\\\".", c) != null) special = true;
        }
        if (special) {
            var q: Buf = .empty;
            util.bufByte(&q, '"');
            for (name) |c| {
                if (c == '\\' or c == '\r') util.bufByte(&q, '\\');
                util.bufByte(&q, c);
            }
            util.bufByte(&q, '"');
            name = q.items;
        }
    }
    return util.concat(&.{ name, " ", addr });
}

fn sanitizeList(l: []const Str) List {
    var r: List = .empty;
    for (l) |x| push(&r, sanitizeAddress(x));
    return r;
}

fn isLocalChar(c: u8) bool {
    return !(c == '<' or c == '>' or c == '"' or c == '@' or isWs(c));
}
fn isDomainChar(c: u8) bool {
    return isLocalChar(c) and c != '.';
}

fn extractValidAddress(addr_in: ?Str) ?Str {
    var a = addr_in orelse return null;
    {
        const t = chomp(a);
        if (t.len > 0) {
            var all = true;
            for (t) |c| if (!isLocalChar(c)) {
                all = false;
            };
            if (all) return a;
        }
    }
    // s/^\s*<(.*)>\s*$/$1/
    {
        const t = trimWs(a);
        if (t.len >= 2 and t[0] == '<' and t[t.len - 1] == '>' and std.mem.indexOfScalar(u8, t, '\n') == null) a = t[1 .. t.len - 1];
    }
    var i: usize = 0;
    while (i < a.len) {
        if (!isLocalChar(a[i])) {
            i += 1;
            continue;
        }
        const start = i;
        while (i < a.len and isLocalChar(a[i])) i += 1;
        if (i < a.len and a[i] == '@') {
            var j = i + 1;
            const ls = j;
            while (j < a.len and isDomainChar(a[j])) j += 1;
            if (j > ls) {
                var end: usize = j;
                var labels: usize = 0;
                while (j < a.len and a[j] == '.') {
                    var k = j + 1;
                    const ks = k;
                    while (k < a.len and isDomainChar(a[k])) k += 1;
                    if (k == ks) break;
                    labels += 1;
                    j = k;
                    end = k;
                }
                if (labels > 0) return a[start..end];
            }
        }
    }
    return null;
}

fn extractValidAddressOrDie(a: Str) Str {
    const v = extractValidAddress(a);
    if (!truthy(v)) pdief("error: unable to extract a valid address from: {s}\n", .{a});
    return v.?;
}

fn stripGarbageOneAddress(addr_in: Str) Str {
    const a = chomp(addr_in);
    if (a.len > 0 and a[0] == '"') {
        if (std.mem.indexOfScalarPos(u8, a, 1, '"')) |q| {
            var j = q + 1;
            while (j < a.len and a[j] == ' ') j += 1;
            if (j < a.len and a[j] == '<') {
                if (std.mem.indexOfScalarPos(u8, a, j + 1, '>')) |gt| return a[0 .. gt + 1];
            }
        }
    } else {
        var run: usize = 0;
        while (run < a.len and a[run] != '"' and a[run] != '<') run += 1;
        if (run < a.len and a[run] == '<') {
            if (std.mem.indexOfScalarPos(u8, a, run + 1, '>')) |gt| return a[0 .. gt + 1];
        }
    }
    var k: usize = 0;
    while (k < a.len and a[k] != '"' and a[k] != '#' and a[k] != ',' and !isWs(a[k])) k += 1;
    return a[0..k];
}

// ---- Mail::Address

fn isTokSpecial(c: u8) bool {
    return std.mem.indexOfScalar(u8, "()<>@,;:\\\".[]", c) != null;
}

fn scanParenInner(s: Str, k0: usize) usize {
    var k = k0;
    while (k < s.len) {
        const c = s[k];
        if (c == '(' or c == ')') break;
        if (c == '\\') {
            if (k + 1 < s.len) {
                k += 2;
                continue;
            }
            break;
        }
        k += 1;
    }
    return k;
}

fn tokenise(line_in: Str) List {
    // s/\A\s+//; s/[\r\n]+/ /g;
    const t0 = trimStartWs(line_in);
    var nb: Buf = .empty;
    {
        var i: usize = 0;
        while (i < t0.len) {
            if (t0[i] == '\r' or t0[i] == '\n') {
                while (i < t0.len and (t0[i] == '\r' or t0[i] == '\n')) i += 1;
                util.bufByte(&nb, ' ');
            } else {
                util.bufByte(&nb, t0[i]);
                i += 1;
            }
        }
    }
    const s = nb.items;
    var words: List = .empty;
    var pos: usize = 0;
    while (pos < s.len) {
        var j = pos;
        while (j < s.len and isWs(s[j])) j += 1;
        if (j < s.len and s[j] == '(') {
            pos = j;
            var field: Buf = .empty;
            var depth: usize = 0;
            outer: while (pos < s.len and s[pos] == '(') {
                const k = scanParenInner(s, pos + 1);
                util.bufAppend(&field, s[pos..k]);
                pos = k;
                depth += 1;
                while (true) {
                    const k2 = scanParenInner(s, pos);
                    if (k2 < s.len and s[k2] == ')') {
                        var e = k2 + 1;
                        while (e < s.len and isWs(s[e])) e += 1;
                        util.bufAppend(&field, s[pos..e]);
                        pos = e;
                        depth -= 1;
                        if (depth == 0) break :outer;
                        const k3 = scanParenInner(s, pos);
                        if (k3 > pos) {
                            util.bufAppend(&field, s[pos..k3]);
                            pos = k3;
                        }
                    } else break;
                }
            }
            push(&words, trimEndWs(field.items));
            continue;
        }
        const c = s[pos];
        var end: ?usize = null;
        if (c == '"' or c == '[') {
            const close: u8 = if (c == '"') '"' else ']';
            var k = pos + 1;
            while (k < s.len) {
                if (s[k] == '\\') {
                    if (k + 1 < s.len) {
                        k += 2;
                        continue;
                    }
                    break;
                }
                if (s[k] == close) {
                    end = k + 1;
                    break;
                }
                k += 1;
            }
        }
        if (end == null) {
            var k = pos;
            while (k < s.len and !isWs(s[k]) and !isTokSpecial(s[k])) k += 1;
            if (k > pos) end = k else if (isTokSpecial(c)) end = pos + 1;
        }
        if (end) |e| {
            push(&words, s[pos..e]);
            pos = e;
            while (pos < s.len and isWs(s[pos])) pos += 1;
        } else {
            pos += 1; // unrecognised (cannot really happen)
        }
    }
    push(&words, ",");
    return words;
}

fn isAtext(c: u8) bool {
    return std.ascii.isAlphanumeric(c) or c == '_' or std.mem.indexOfScalar(u8, "- !#$%&'*+/=?^`{|}~", c) != null;
}

fn formatAddr(phrase: Str, email: Str, comment_in: Str) ?Str {
    var parts: List = .empty;
    if (phrase.len > 0) {
        var all_atext = true;
        for (phrase) |c| if (!(isAtext(c) or isWs(c))) {
            all_atext = false;
        };
        var has_unesc_quote = false;
        for (phrase, 0..) |c, i| {
            if (c == '"' and (i == 0 or phrase[i - 1] != '\\')) has_unesc_quote = true;
        }
        if (all_atext or has_unesc_quote) push(&parts, phrase) else push(&parts, util.concat(&.{ "\"", phrase, "\"" }));
        if (email.len > 0) push(&parts, util.concat(&.{ "<", email, ">" }));
    } else if (email.len > 0) push(&parts, email);
    var comment = comment_in;
    var has_nonws = false;
    for (comment) |c| if (!isWs(c)) {
        has_nonws = true;
    };
    if (has_nonws) {
        var a = trimStartWs(comment);
        if (a.len > 0 and a[0] == '(') a = a[1..];
        var b = trimEndWs(a);
        if (b.len > 0 and b[b.len - 1] == ')') b = b[0 .. b.len - 1];
        comment = util.concat(&.{ "(", b, ")" });
    }
    if (comment.len > 0) push(&parts, comment);
    if (parts.items.len == 0) return null;
    return std.mem.join(gpa, " ", parts.items) catch util.oom();
}

fn findNext(tokens: []const Str, idx0: usize) Str {
    var idx = idx0;
    while (idx < tokens.len) : (idx += 1) {
        const c = tokens[idx];
        if (eql(c, ",") or eql(c, ";") or eql(c, "<")) return c;
    }
    return "";
}

fn completeAddr(objs: *List, phrase: *List, address: *List, comment: *List) void {
    if (phrase.items.len == 0 and address.items.len == 0 and comment.items.len == 0) return;
    const p = std.mem.join(gpa, " ", phrase.items) catch util.oom();
    const a = std.mem.join(gpa, "", address.items) catch util.oom();
    const c = std.mem.join(gpa, " ", comment.items) catch util.oom();
    if (formatAddr(p, a, c)) |f| push(objs, f);
    phrase.* = .empty;
    address.* = .empty;
    comment.* = .empty;
}

fn isAddrSep(t: Str) bool {
    return eql(t, ".") or eql(t, "@") or eql(t, ":") or eql(t, ";");
}

fn parseAddressLine(line: ?Str) List {
    var objs: List = .empty;
    const l = line orelse return objs;
    const tokens = tokenise(l).items;
    var phrase: List = .empty;
    var address: List = .empty;
    var comment: List = .empty;
    var depth: usize = 0;
    var next = findNext(tokens, 0);
    for (tokens, 0..) |t, idx| {
        if (t.len > 0 and t[0] == '(') {
            push(&comment, t);
        } else if (eql(t, "<")) {
            depth += 1;
        } else if (eql(t, ">")) {
            if (depth > 0) depth -= 1;
        } else if (eql(t, ",") or eql(t, ";")) {
            completeAddr(&objs, &phrase, &address, &comment);
            depth = 0;
            next = findNext(tokens, idx + 1);
        } else if (depth > 0) {
            push(&address, t);
        } else if (eql(next, "<")) {
            push(&phrase, t);
        } else if (isAddrSep(t) or address.items.len == 0 or isAddrSep(address.items[address.items.len - 1])) {
            push(&address, t);
        } else {
            completeAddr(&objs, &phrase, &address, &comment);
            depth = 0;
            push(&address, t);
        }
    }
    return objs;
}

// ---- Text::ParseWords

const Delim = enum { comma, space };

fn delimAt(s: Str, p: usize, d: Delim) usize {
    switch (d) {
        .space => {
            var k = p;
            while (k < s.len and isWs(s[k])) k += 1;
            return k - p;
        },
        .comma => {
            var k = p;
            while (k < s.len and isWs(s[k])) k += 1;
            if (k >= s.len or s[k] != ',') return 0;
            k += 1;
            while (k < s.len and isWs(s[k])) k += 1;
            return k - p;
        },
    }
}

fn unescapeBs(s: Str) Str {
    var b: Buf = .empty;
    var i: usize = 0;
    while (i < s.len) {
        if (s[i] == '\\' and i + 1 < s.len) {
            util.bufByte(&b, s[i + 1]);
            i += 2;
        } else {
            util.bufByte(&b, s[i]);
            i += 1;
        }
    }
    return b.items;
}

fn parseLine(d: Delim, keep: bool, line_in: Str) ?List {
    var pieces: List = .empty;
    var line = line_in;
    var word: ?Buf = null;
    while (line.len > 0) {
        var quote: ?u8 = null;
        var quoted: Str = "";
        var unquoted: Str = "";
        var delim_len: usize = 0;
        var consumed: usize = 0;
        if (line[0] == '"' or line[0] == '\'') {
            const q = line[0];
            var k: usize = 1;
            var found = false;
            while (k < line.len) {
                if (line[k] == '\\') {
                    if (k + 1 < line.len) {
                        k += 2;
                        continue;
                    }
                    break;
                }
                if (line[k] == q) {
                    found = true;
                    break;
                }
                k += 1;
            }
            if (found) {
                quote = q;
                quoted = line[1..k];
                consumed = k + 1;
            }
        }
        if (quote == null) {
            var p: usize = 0;
            var ok = false;
            while (true) {
                if (p == line.len) {
                    ok = true;
                    break;
                }
                const dl = delimAt(line, p, d);
                if (dl > 0) {
                    delim_len = dl;
                    ok = true;
                    break;
                }
                if (p > 0 and (line[p] == '"' or line[p] == '\'')) {
                    ok = true;
                    break;
                }
                if (line[p] == '\\' and p + 1 < line.len) {
                    p += 2;
                    continue;
                }
                if (line[p] == '"' or line[p] == '\'' or line[p] == '\\') break;
                p += 1;
            }
            if (!ok) return null;
            unquoted = line[0..p];
            consumed = p + delim_len;
        }
        line = line[consumed..];
        var piece: Str = undefined;
        if (quote) |q| {
            if (keep) {
                piece = util.concat(&.{ line_in[0..0], &[_]u8{q}, quoted, &[_]u8{q} });
            } else piece = if (q == '"') unescapeBs(quoted) else quoted;
        } else {
            piece = if (keep) unquoted else unescapeBs(unquoted);
        }
        if (word == null) word = .empty;
        util.bufAppend(&word.?, piece);
        if (delim_len > 0) {
            push(&pieces, if (word) |w| w.items else "");
            word = null;
        }
        if (line.len == 0) push(&pieces, if (word) |w| w.items else "");
    }
    return pieces;
}

fn quotewords(d: Delim, keep: bool, line: Str) List {
    const words = parseLine(d, keep, line) orelse return .empty;
    if (words.items.len == 0 and line.len > 0) return .empty;
    return words;
}

fn splitAddrs(s: Str) List {
    return quotewords(.comma, true, s);
}

// ---------------------------------------------------------------- aliases

var aliases: std.StringHashMapUnmanaged(List) = .empty;
var expanding: std.StringHashMapUnmanaged(void) = .empty;

fn setAlias(name: Str, addrs: List) void {
    aliases.put(gpa, name, addrs) catch util.oom();
}

fn expandOneAlias(out: *List, alias: Str) void {
    if (expanding.contains(alias)) pdief("fatal: alias '{s}' expands to itself\n", .{alias});
    if (aliases.get(alias)) |l| {
        expanding.put(gpa, alias, {}) catch util.oom();
        for (l.items) |x| expandOneAlias(out, x);
        _ = expanding.remove(alias);
    } else push(out, alias);
}

fn expandAliases(l: []const Str) List {
    var out: List = .empty;
    for (l) |x| expandOneAlias(&out, x);
    return out;
}

fn nextWord(s: Str, p0: usize) struct { start: usize, end: usize } {
    var p = p0;
    while (p < s.len and isWs(s[p])) p += 1;
    const st = p;
    while (p < s.len and !isWs(s[p])) p += 1;
    return .{ .start = st, .end = p };
}

fn parseMutt(data: Str) void {
    for (linesKeep(data).items) |raw| {
        // ^\s*alias\s+(?:-group\s+\S+\s+)*(\S+)\s+(.*)$
        const s = raw;
        var p: usize = 0;
        while (p < s.len and isWs(s[p])) p += 1;
        if (!startsWith(s[p..], "alias")) continue;
        p += 5;
        if (p >= s.len or !isWs(s[p])) continue;
        // collect words with positions
        var w = nextWord(s, p);
        // greedy -group handling
        while (eql(s[w.start..w.end], "-group")) {
            const g = nextWord(s, w.end);
            if (g.start == g.end) break;
            const n = nextWord(s, g.end);
            if (n.start == n.end or n.start == g.end) break;
            // need whitespace after the name word as well
            if (n.end >= s.len) break;
            w = n;
        }
        if (w.start == w.end) continue;
        if (w.end >= s.len or !isWs(s[w.end])) continue;
        const name = s[w.start..w.end];
        var q = w.end;
        while (q < s.len and isWs(s[q])) q += 1;
        var addr = chomp(s[q..]);
        if (std.mem.indexOfScalar(u8, addr, '#')) |h| addr = addr[0..h];
        const l = splitAddrs(addr);
        for (l.items) |*x| x.* = std.mem.replaceOwned(u8, gpa, x.*, "\\\"", "\"") catch util.oom();
        setAlias(name, l);
    }
}

fn parseMailrc(data: Str) void {
    for (linesKeep(data).items) |s| {
        if (!startsWith(s, "alias")) continue;
        var p: usize = 5;
        if (p >= s.len or !isWs(s[p])) continue;
        const w = nextWord(s, p);
        if (w.start == w.end or w.end >= s.len or !isWs(s[w.end])) continue;
        p = w.end;
        while (p < s.len and isWs(s[p])) p += 1;
        const rest = trimEndWs(s[p..]);
        setAlias(s[w.start..w.end], quotewords(.space, false, rest));
    }
}

fn parsePine(data: Str) void {
    const lines = linesKeep(data).items;
    var idx: usize = 0;
    var x: ?Str = "";
    while (x) |x0| {
        var cur: Buf = .empty;
        util.bufAppend(&cur, chomp(x0));
        var nextline: ?Str = null;
        while (idx < lines.len) {
            const l = lines[idx];
            idx += 1;
            const c = chomp(l);
            var sp: usize = 0;
            while (sp < c.len and c[sp] == ' ') sp += 1;
            if (sp > 0 and !(c.len != l.len and false)) {
                util.bufAppend(&cur, c[sp..]);
                continue;
            }
            nextline = l;
            break;
        }
        pineLine(cur.items);
        x = nextline;
    }
}

fn pineLine(x: Str) void {
    var fields: List = .empty;
    var it = std.mem.splitScalar(u8, x, '\t');
    while (it.next()) |f| push(&fields, f);
    const n = fields.items.len;
    if (n < 3 or n > 5) return;
    const name = fields.items[0];
    if (name.len == 0) return;
    for (name) |c| if (isWs(c)) return;
    var a = fields.items[2];
    if (a.len >= 2 and a[0] == '(') a = a[1..];
    if (n > 3 and a.len >= 2 and a[a.len - 1] == ':') a = a[0 .. a.len - 1];
    if (a.len >= 2 and a[a.len - 1] == ')') a = a[0 .. a.len - 1];
    if (a.len == 0) return;
    setAlias(name, splitAddrs(a));
}

fn parseElm(data: Str) void {
    for (linesKeep(data).items) |s| {
        // ^(\S+)\s+=\s+[^=]+=\s(\S+)
        var p: usize = 0;
        while (p < s.len and !isWs(s[p])) p += 1;
        if (p == 0) continue;
        const name = s[0..p];
        const ws0 = p;
        while (p < s.len and isWs(s[p])) p += 1;
        if (p == ws0 or p >= s.len or s[p] != '=') continue;
        p += 1;
        const e2 = std.mem.indexOfScalarPos(u8, s, p, '=') orelse continue;
        const seg = s[p..e2];
        if (seg.len < 2 or !isWs(seg[0])) continue;
        var q = e2 + 1;
        if (q >= s.len or !isWs(s[q])) continue;
        q += 1;
        const st = q;
        while (q < s.len and !isWs(s[q])) q += 1;
        if (q == st) continue;
        setAlias(name, splitAddrs(s[st..q]));
    }
}

fn parseGnus(data: Str) void {
    for (linesKeep(data).items) |s| {
        var from: usize = 0;
        while (std.mem.indexOfPos(u8, s, from, "(define-mail-alias")) |pos| {
            from = pos + 1;
            var p = pos + "(define-mail-alias".len;
            const w0 = p;
            while (p < s.len and isWs(s[p])) p += 1;
            if (p == w0 or p >= s.len or s[p] != '"') continue;
            p += 1;
            // name: \S+? followed by "\s+"(\S+?)"\)
            var k = p + 1;
            var found = false;
            while (k <= s.len) : (k += 1) {
                if (k > p and isWs(s[k - 1])) break;
                if (k < s.len and s[k] == '"' and k > p) {
                    var r = k + 1;
                    const r0 = r;
                    while (r < s.len and isWs(s[r])) r += 1;
                    if (r > r0 and r < s.len and s[r] == '"') {
                        const vs = r + 1;
                        var v = vs + 1;
                        while (v + 1 <= s.len) : (v += 1) {
                            if (isWs(s[v - 1])) break;
                            if (v + 1 < s.len and s[v] == '"' and s[v + 1] == ')') {
                                var l: List = .empty;
                                push(&l, s[vs..v]);
                                setAlias(s[p..k], l);
                                found = true;
                                break;
                            }
                        }
                        if (found) break;
                    }
                }
                if (k >= s.len) break;
            }
            if (found) break;
        }
    }
}

fn parseSendmailAlias(s: Str) void {
    if (std.mem.indexOfScalar(u8, s, '"') != null) {
        util.ewrite(util.fmt("warning: sendmail alias with quotes is not supported: {s}\n", .{s}));
    } else if (std.mem.indexOf(u8, s, ":include:") != null) {
        util.ewrite(util.fmt("warning: `:include:` not supported: {s}\n", .{s}));
    } else if (std.mem.indexOfAny(u8, s, "/|") != null) {
        util.ewrite(util.fmt("warning: `/file` or `|pipe` redirection not supported: {s}\n", .{s}));
    } else blk: {
        // ^(\S+?)\s*:\s*(.+)$
        const colon = std.mem.indexOfScalarPos(u8, s, 1, ':') orelse break :blk;
        const name = trimEndWs(s[0..colon]);
        if (name.len == 0) break :blk;
        for (name) |c| if (isWs(c)) break :blk;
        const raw = s[colon + 1 ..];
        var addr = trimStartWs(raw);
        if (addr.len == 0) {
            if (raw.len == 0) break :blk;
            addr = raw[raw.len - 1 ..];
        }
        setAlias(name, splitAddrs(addr));
        return;
    }
    if (std.mem.indexOfScalar(u8, s, '"') == null and std.mem.indexOf(u8, s, ":include:") == null and std.mem.indexOfAny(u8, s, "/|") == null)
        util.ewrite(util.fmt("warning: sendmail line is not recognized: {s}\n", .{s}));
}

fn parseSendmail(data: Str) void {
    var s: Buf = .empty;
    for (linesKeep(data).items) |raw| {
        const l = chomp(raw);
        const t = trimStartWs(l);
        if (t.len == 0 or t[0] == '#') continue;
        if (s.items.len > 0 and s.items[s.items.len - 1] == '\\') {
            s.items.len -= 1;
            util.bufAppend(&s, l);
            continue;
        }
        if (t.len != l.len) {
            util.bufAppend(&s, t);
            continue;
        }
        if (truthy(s.items)) parseSendmailAlias(util.dupe(s.items));
        s = .empty;
        util.bufAppend(&s, l);
    }
    if (s.items.len > 0 and s.items[s.items.len - 1] == '\\') s.items.len -= 1;
    if (truthy(s.items)) parseSendmailAlias(util.dupe(s.items));
}

fn loadAliases() void {
    if (alias_files.items.len == 0) return;
    const t = aliasfiletype orelse return;
    const known = [_]Str{ "mutt", "mailrc", "pine", "elm", "sendmail", "gnus" };
    var ok = false;
    for (known) |k| if (eql(k, t)) {
        ok = true;
    };
    if (!ok) return;
    for (alias_files.items) |f| {
        const data = os.readFile(f) orelse pdief("opening {s}: {s}\n", .{ f, os.lastErr() });
        if (eql(t, "mutt")) parseMutt(data) else if (eql(t, "mailrc")) parseMailrc(data) else if (eql(t, "pine")) parsePine(data) else if (eql(t, "elm")) parseElm(data) else if (eql(t, "sendmail")) parseSendmail(data) else parseGnus(data);
    }
}

// ---------------------------------------------------------------- address list processing

fn validateAddress(addr_in: Str) ?Str {
    var address: Str = addr_in;
    while (!truthy(extractValidAddress(address))) {
        util.ewrite(util.fmt("error: unable to extract a valid address from: {s}\n", .{address}));
        const r = ask("What to do with this address? ([q]uit|[d]rop|[e]dit): ", .qde, "q", false);
        const c = firstLower(r);
        if (c == 'd') return null;
        if (c == 'q') {
            cleanupComposeFiles();
            finish(0);
        }
        address = ask("To whom should the emails be sent (if anyone)? ", .at_dot, "", true) orelse "";
    }
    return address;
}

fn mailmapList(l: List) List {
    if (l.items.len == 0 or !mailmap) return l;
    var args: List = .empty;
    push(&args, "check-mailmap");
    if (truthy(mailmap_file)) push(&args, util.concat(&.{ "--mailmap-file=", mailmap_file.? }));
    if (truthy(mailmap_blob)) push(&args, util.concat(&.{ "--mailmap-blob=", mailmap_blob.? }));
    for (l.items) |x| push(&args, x);
    const out = gitLines(args.items, false);
    for (out.items) |*x| {
        if (x.len >= 2 and x.*[0] == '<' and x.*[x.len - 1] == '>') x.* = x.*[1 .. x.len - 1];
    }
    return out;
}

fn processAddressList(l: []const Str) List {
    var parsed: List = .empty;
    for (l) |x| {
        for (parseAddressLine(x).items) |a| push(&parsed, a);
    }
    const expanded = expandAliases(parsed.items);
    const san = sanitizeList(expanded.items);
    var valid: List = .empty;
    for (san.items) |a| if (validateAddress(a)) |v| push(&valid, v);
    return mailmapList(valid);
}

// ---------------------------------------------------------------- misc helpers

fn canonPath(p_in: Str) Str {
    var b: Buf = .empty;
    // collapse multiple slashes
    for (p_in, 0..) |c, i| {
        if (c == '/' and i > 0 and p_in[i - 1] == '/') continue;
        util.bufByte(&b, c);
    }
    var p: Str = b.items;
    // s{(?:/\.)+(?:/|\z)}{/}g
    {
        var o: Buf = .empty;
        var i: usize = 0;
        while (i < p.len) {
            if (p[i] == '/' and i + 1 < p.len and p[i + 1] == '.' and (i + 2 == p.len or p[i + 2] == '/')) {
                var j = i;
                while (j + 1 < p.len and p[j] == '/' and p[j + 1] == '.' and (j + 2 == p.len or p[j + 2] == '/')) j += 2;
                util.bufByte(&o, '/');
                i = if (j < p.len and p[j] == '/') j + 1 else j;
                continue;
            }
            util.bufByte(&o, p[i]);
            i += 1;
        }
        p = o.items;
    }
    if (!eql(p, "./")) {
        while (startsWith(p, "./")) p = p[2..];
    }
    if (startsWith(p, "/../")) {
        var q = p[1..];
        while (startsWith(q, "../")) q = q[3..];
        p = util.concat(&.{ "/", q });
    }
    if (eql(p, "/..")) p = "/";
    if (p.len > 1 and p[p.len - 1] == '/') p = p[0 .. p.len - 1];
    return p;
}

fn catFile(dir: Str, name: Str) Str {
    var d = canonPath(util.concat(&.{ dir, "/" }));
    if (d.len == 0 or d[d.len - 1] != '/') d = util.concat(&.{ d, "/" });
    return util.concat(&.{ d, canonPath(name) });
}

fn isFifo(path: Str) bool {
    const st = os.statPath(path) orelse return false;
    return st.mode & 0o170000 == 0o010000;
}
fn isRegFile(path: Str) bool {
    const st = os.statPath(path) orelse return false;
    return st.isReg();
}
fn isDirPath(path: Str) bool {
    const st = os.statPath(path) orelse return false;
    return st.isDir();
}

fn isFormatPatchArg(f: Str) bool {
    if (!have_repo) return false;
    const r = gitRun(&.{ "rev-parse", "--verify", "--quiet", f }, true, true);
    if (r.status != 0) return false;
    if (format_patch) |fp| return fp;
    pdief("File '{s}' exists but it could also be the range of commits\n" ++
        "to produce patches for.  Please disambiguate by...\n\n" ++
        "    * Saying \"./{s}\" if you mean a file; or\n" ++
        "    * Giving --format-patch option if you mean a range.\n", .{ f, f });
}

fn getPatchSubject(fn_: Str) Str {
    const data = os.readFile(fn_) orelse "";
    for (linesKeep(data).items) |l| {
        const c = chomp(l);
        if (startsWith(c, "Subject: ")) return util.concat(&.{ "GIT: ", c[9..], "\n" });
    }
    pdief("No 'Subject:' line in '{s}'\n", .{fn_});
}

fn fileDeclares8bitCte(fn_: Str) bool {
    const data = os.readFile(fn_) orelse return false;
    for (linesKeep(data).items) |l| {
        if (eql(l, "\n")) break;
        if (startsWith(l, "Content-Transfer-Encoding: ") and std.mem.indexOf(u8, chomp(l)[27..], "8bit") != null) return true;
    }
    return false;
}

fn bodyOrSubjectHasNonAscii(fn_: Str) bool {
    const data = readFileOrDie(fn_);
    const lines = linesKeep(data).items;
    var i: usize = 0;
    while (i < lines.len) : (i += 1) {
        const l = lines[i];
        if (l.len == 0 or eql(l, "\n")) {
            i += 1;
            break;
        }
        if (startsWith(l, "Subject") and hasNonAscii(chomp(l))) return true;
    }
    while (i < lines.len) : (i += 1) if (hasNonAscii(lines[i])) return true;
    return false;
}

fn findEncoding(e: Str) bool {
    const l = lower(e);
    const names = [_]Str{ "utf8", "utf-8", "utf-8-strict", "us-ascii", "ascii", "latin1", "latin-1", "iso-646-us", "koi8-r", "koi8-u", "koi8-f", "shift_jis", "sjis", "euc-jp", "euc-kr", "euc-cn", "big5", "big5-eten", "big5-hkscs", "gb2312", "gbk", "cp936", "gb18030", "iso-2022-jp", "iso-2022-jp-1", "iso-2022-kr", "utf-16", "utf-16le", "utf-16be", "utf-32", "utf-32le", "utf-32be", "ucs-2", "ucs-2be", "ucs-2le", "utf-7", "hz", "macroman", "viscii", "cp437", "cp850", "cp852", "cp866", "cp932", "cp949", "cp950" };
    for (names) |n| if (eql(l, n)) return true;
    const prefixes = [_]Str{ "iso-8859-", "iso8859-", "iso_8859-", "cp125", "windows-125", "latin" };
    for (prefixes) |p| {
        if (startsWith(l, p) and l.len > p.len) {
            var digits = true;
            for (l[p.len..]) |c| if (c < '0' or c > '9') {
                digits = false;
            };
            if (digits) return true;
        }
    }
    return false;
}

// ---------------------------------------------------------------- transfer encodings

fn qpPlain(c: u8) bool {
    return c == '\t' or (c >= ' ' and c <= '~' and c != '=');
}

fn qpEncode(s: Str) Str {
    const eol = "\n";
    const el = eol.len;
    var r: Buf = .empty;
    const n = s.len;
    var i: usize = 0;
    var ll: usize = 0;
    while (true) {
        var beg = i;
        var p = i;
        while (p < n and qpPlain(s[p])) p += 1;
        if (p == n or s[p] == '\n') {
            while (p > beg and (s[p - 1] == '\t' or s[p - 1] == ' ')) p -= 1;
        }
        var pl = p - beg;
        if (pl > 0) {
            while (pl > 75 - ll) {
                const len = 75 - ll;
                util.bufAppend(&r, s[beg .. beg + len]);
                beg += len;
                pl -= len;
                util.bufAppend(&r, "=" ++ eol);
                ll = 0;
            }
            if (pl > 0) {
                util.bufAppend(&r, s[beg .. beg + pl]);
                beg += pl;
                ll += pl;
            }
        }
        i = beg;
        if (p == n) break;
        if (s[p] == '\n') {
            if (ll == 1 and r.items.len > el + 1 and r.items[r.items.len - el - 2] == '=') {
                r.items[r.items.len - el - 2] = r.items[r.items.len - 1];
                r.items.len -= 1;
            } else util.bufAppend(&r, eol);
            i = p + 1;
            ll = 0;
        } else {
            if (ll > 72 and !(ll == 73 and p + 1 < n and s[p + 1] == '\n')) {
                util.bufAppend(&r, "=" ++ eol);
                ll = 0;
            }
            util.bufPrint(&r, "={X:0>2}", .{s[p]});
            i = p + 1;
            ll += 3;
        }
    }
    if (r.items.len > 0 and ll > 0) util.bufAppend(&r, "=" ++ eol);
    return r.items;
}

fn qpDecode(s0: Str) Str {
    const s1 = std.mem.replaceOwned(u8, gpa, s0, "\r\n", "\n") catch util.oom();
    // s/[ \t]+\n/\n/g
    var b: Buf = .empty;
    var i: usize = 0;
    while (i < s1.len) {
        if (s1[i] == ' ' or s1[i] == '\t') {
            var j = i;
            while (j < s1.len and (s1[j] == ' ' or s1[j] == '\t')) j += 1;
            if (j < s1.len and s1[j] == '\n') {
                i = j;
                continue;
            }
            util.bufAppend(&b, s1[i..j]);
            i = j;
            continue;
        }
        util.bufByte(&b, s1[i]);
        i += 1;
    }
    const s2 = std.mem.replaceOwned(u8, gpa, b.items, "=\n", "") catch util.oom();
    var o: Buf = .empty;
    i = 0;
    while (i < s2.len) {
        if (s2[i] == '=' and i + 2 < s2.len + 1 and i + 2 <= s2.len - 1 + 1 and i + 2 < s2.len + 1 and i + 2 <= s2.len and hexVal(s2[i + 1]) != null and hexVal(s2[i + 2]) != null) {
            util.bufByte(&o, hexVal(s2[i + 1]).? * 16 + hexVal(s2[i + 2]).?);
            i += 3;
        } else {
            util.bufByte(&o, s2[i]);
            i += 1;
        }
    }
    return o.items;
}

const b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

fn b64Encode(s: Str) Str {
    var r: Buf = .empty;
    var line: usize = 0;
    var i: usize = 0;
    while (i < s.len) : (i += 3) {
        const b0 = s[i];
        const b1: u8 = if (i + 1 < s.len) s[i + 1] else 0;
        const b2: u8 = if (i + 2 < s.len) s[i + 2] else 0;
        util.bufByte(&r, b64chars[b0 >> 2]);
        util.bufByte(&r, b64chars[((b0 & 3) << 4) | (b1 >> 4)]);
        util.bufByte(&r, if (i + 1 < s.len) b64chars[((b1 & 15) << 2) | (b2 >> 6)] else '=');
        util.bufByte(&r, if (i + 2 < s.len) b64chars[b2 & 63] else '=');
        line += 4;
        if (line == 76) {
            util.bufByte(&r, '\n');
            line = 0;
        }
    }
    if (line > 0) util.bufByte(&r, '\n');
    return r.items;
}

fn b64Decode(s: Str) Str {
    var r: Buf = .empty;
    var acc: u32 = 0;
    var bits: u5 = 0;
    for (s) |c| {
        if (c == '=') break;
        const v = std.mem.indexOfScalar(u8, b64chars, c) orelse continue;
        acc = (acc << 6) | @as(u32, @intCast(v));
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            util.bufByte(&r, @intCast((acc >> bits) & 0xff));
        }
    }
    return r.items;
}

const Encoded = struct { msg: Str, enc: Str };

fn applyTransferEncoding(msg_in: Str, from: Str, to_in: Str) Encoded {
    if (eql(from, to_in) and !eql(from, "7bit")) return .{ .msg = msg_in, .enc = to_in };
    var msg = msg_in;
    var to = to_in;
    if (eql(from, "quoted-printable")) msg = qpDecode(msg);
    if (eql(from, "base64")) msg = b64Decode(msg);
    if (eql(to, "auto")) {
        var long = false;
        var run: usize = 0;
        for (msg) |c| {
            if (c == '\r') long = true;
            if (c == '\n') run = 0 else {
                run += 1;
                if (run >= 999) long = true;
            }
        }
        to = if (long) "quoted-printable" else "8bit";
    }
    if (eql(to, "7bit") and hasNonAscii(msg)) pdie("cannot send message as 7bit");
    if (eql(to, "7bit") or eql(to, "8bit")) return .{ .msg = msg, .enc = to };
    if (eql(to, "quoted-printable")) return .{ .msg = qpEncode(msg), .enc = to };
    if (eql(to, "base64")) return .{ .msg = b64Encode(msg), .enc = to };
    pdie("invalid transfer encoding");
}

// ---------------------------------------------------------------- per-message state

var to_list: List = .empty;
var cc_list: List = .empty;
var xh: List = .empty;
var initial_to: List = .empty;
var initial_cc: List = .empty;
var initial_bcc: List = .empty;
var subject: ?Str = null;
var message: Str = "";
var message_id: ?Str = null;
var message_num: i64 = 0;
var in_reply_to: ?Str = null;
var references: Str = "";
var needs_confirm: enum { no, yes, inform } = .no;
var ask_default: ?Str = null;
var confirm_unconfigured = false;
var broken_encoding: std.StringHashMapUnmanaged(void) = .empty;
var time_val: i64 = 0;
var num_sent: i64 = 0;
var compose_filename: ?Str = null;

const Supp = struct {
    cccmd: ?bool = null,
    cc: ?bool = null,
    author: ?bool = null,
    self: ?bool = null,
    sob: ?bool = null,
    bodycc: ?bool = null,
    misc_by: ?bool = null,
    body: ?bool = null,
    all: ?bool = null,
};
var supp: Supp = .{};

fn sup(v: ?bool) bool {
    return v orelse false;
}

fn cleanupComposeFiles() void {
    if (compose != 0) {
        if (compose_filename) |f| {
            _ = os.unlink(f);
            _ = os.unlink(util.concat(&.{ f, ".final" }));
        }
    }
}

fn senderStr() Str {
    return sender orelse "";
}

fn executeCmd(prefix: Str, cmd: Str, file: Str) List {
    var b: Buf = .empty;
    util.bufAppend(&b, cmd);
    util.bufAppend(&b, " ");
    for (file) |c| {
        if (!(std.ascii.isAlphanumeric(c) or c == '_')) util.bufByte(&b, '\\');
        util.bufByte(&b, c);
    }
    const r = os.run(&.{ "/bin/sh", "-c", b.items }, .{ .capture_stdout = true });
    var lines: List = .empty;
    var seen_blank = false;
    for (linesKeep(r.stdout).items) |l| {
        if (seen_blank) pdief("({s}) Malformed output from '{s}'", .{ prefix, cmd });
        if (eql(l, "\n")) {
            seen_blank = true;
            continue;
        }
        push(&lines, l);
    }
    if (r.status != 0) pdief("({s}) failed to close pipe to '{s}'", .{ prefix, cmd });
    return lines;
}

fn unfoldHeaders(in: []const Str) List {
    var hs: List = .empty;
    for (in) |l| {
        if (trimWs(l).len == 0) break;
        if (l.len > 0 and isWs(l[0]) and trimWs(l).len > 0 and hs.items.len > 0) {
            const last = &hs.items[hs.items.len - 1];
            last.* = util.concat(&.{ chomp(last.*), " ", trimStartWs(l) });
        } else push(&hs, l);
    }
    return hs;
}

fn recipientsCmd(prefix: Str, what: Str, cmd: Str, file: Str, q: bool) List {
    var addrs: List = .empty;
    for (executeCmd(prefix, cmd, file).items) |l| {
        const a = sanitizeAddress(trimWs(l));
        if (eql(a, senderStr()) and sup(supp.self)) continue;
        push(&addrs, a);
        if (!q) util.outf("({s}) Adding {s}: {s} from: '{s}'\n", .{ prefix, what, a, cmd });
    }
    return addrs;
}

/// Match /^Name:\s+(.*)$/i on a chomped header line.
fn hdrVal(line: Str, name: Str) ?Str {
    if (!startsWithI(line, name)) return null;
    const rest = line[name.len..];
    if (rest.len == 0 or !isWs(rest[0])) return null;
    return trimStartWs(rest);
}
/// Match /^Name: (.*)/i (exactly one space).
fn hdrVal1(line: Str, name: Str) ?Str {
    if (!startsWithI(line, name) or line.len <= name.len or line[name.len] != ' ') return null;
    return line[name.len + 1 ..];
}

fn preProcessFile(t: Str, q: bool) void {
    const data = os.readFile(t) orelse pdief("can't open file {s}", .{t});
    const lines = linesKeep(data).items;
    var author: ?Str = null;
    var sauthor: ?Str = null;
    var author_encoding: ?Str = null;
    var has_content_type = false;
    var body_encoding: ?Str = null;
    var xfer_encoding: ?Str = null;
    var has_mime_version = false;
    to_list = .empty;
    cc_list = .empty;
    xh = .empty;
    var input_format: enum { none, mbox, lots } = .none;
    subject = initial_subject;
    message = "";
    message_num += 1;
    message_id = null;
    var header_lines: List = .empty;
    var li: usize = 0;
    while (li < lines.len) {
        const l = lines[li];
        li += 1;
        if (trimWs(l).len == 0) break;
        push(&header_lines, l);
    }
    var header = unfoldHeaders(header_lines.items);
    if (!no_header_cmd and truthy(header_cmd)) {
        const hl = executeCmd("header-cmd", header_cmd.?, t);
        for (unfoldHeaders(hl.items).items) |h| push(&header, h);
    }
    for (header.items) |hraw| {
        if (startsWith(hraw, "From ")) {
            input_format = .mbox;
            continue;
        }
        const h = chomp(hraw);
        if (input_format == .none) {
            var k: usize = 0;
            while (k < h.len and (std.ascii.isAlphabetic(h[k]) or h[k] == '-')) k += 1;
            if (k > 0 and k + 1 < h.len + 0 + 1 and k < h.len and h[k] == ':' and k + 1 < h.len and isWs(h[k + 1])) input_format = .mbox;
        }
        if (input_format == .mbox) {
            if (hdrVal(h, "Subject:")) |v| {
                subject = v;
            } else if (hdrVal(h, "From:")) |v| {
                const uq = unquoteRfc2047(v);
                author = uq.s;
                author_encoding = uq.charset;
                sauthor = sanitizeAddress(uq.s);
                if (sup(supp.author)) continue;
                if (sup(supp.self) and eql(sauthor.?, senderStr())) continue;
                if (!q) util.outf("(mbox) Adding cc: {s} from line '{s}'\n", .{ v, h });
                push(&cc_list, v);
            } else if (hdrVal(h, "To:")) |v| {
                for (parseAddressLine(v).items) |a| {
                    if (!q) util.outf("(mbox) Adding to: {s} from line '{s}'\n", .{ a, h });
                    push(&to_list, a);
                }
            } else if (hdrVal(h, "Cc:")) |v| {
                for (parseAddressLine(v).items) |a| {
                    const qa = unquoteRfc2047(a).s;
                    const sa = sanitizeAddress(qa);
                    if (eql(sa, senderStr())) {
                        if (sup(supp.self)) continue;
                    } else {
                        if (sup(supp.cc)) continue;
                    }
                    if (!q) util.outf("(mbox) Adding cc: {s} from line '{s}'\n", .{ a, h });
                    push(&cc_list, a);
                }
            } else if (startsWithI(h, "Content-type:")) {
                has_content_type = true;
                if (std.mem.indexOf(u8, h, "charset=")) |ci| {
                    var p = ci + 8;
                    if (p < h.len and h[p] == '"') p += 1;
                    const st = p;
                    while (p < h.len and h[p] != ' ' and h[p] != '"') p += 1;
                    if (p > st) body_encoding = h[st..p];
                }
                push(&xh, h);
            } else if (startsWithI(h, "MIME-Version")) {
                has_mime_version = true;
                push(&xh, h);
            } else if (hdrVal1(h, "Message-ID:")) |v| {
                message_id = v;
            } else if (hdrVal1(h, "Content-Transfer-Encoding:")) |v| {
                if (xfer_encoding == null) xfer_encoding = v;
            } else if (hdrVal1(h, "In-Reply-To:")) |v| {
                if (!truthy(initial_in_reply_to) or thread) in_reply_to = v;
            } else if (hdrVal1(h, "Reply-To:")) |v| {
                reply_to = v;
            } else if (hdrVal1(h, "References:")) |v| {
                if (!truthy(initial_in_reply_to) or thread) references = v;
            } else if (!(startsWithI(h, "Date:") and h.len > 5 and isWs(h[5]))) {
                var k: usize = 0;
                while (k < h.len and (std.ascii.isAlphabetic(h[k]) or h[k] == '-')) k += 1;
                if (k > 0 and k < h.len and h[k] == ':') {
                    var m = k + 1;
                    const m0 = m;
                    while (m < h.len and isWs(h[m])) m += 1;
                    if (m > m0 and m < h.len) push(&xh, h);
                }
            }
        } else {
            input_format = .lots;
            if (cc_list.items.len == 0 and !sup(supp.cc)) {
                if (!q) util.outf("(non-mbox) Adding cc: {s} from line '{s}'\n", .{ h, h });
                push(&cc_list, h);
            } else if (subject == null) {
                subject = h;
            }
        }
    }
    var msg: Buf = .empty;
    while (li < lines.len) : (li += 1) {
        const l = lines[li];
        util.bufAppend(&msg, l);
        // /^([a-z][a-z-]*-by|Cc): (.*)/i
        const ci = std.mem.indexOf(u8, l, ": ") orelse continue;
        const what = l[0..ci];
        var okw = false;
        if (std.ascii.eqlIgnoreCase(what, "Cc")) okw = true else if (what.len >= 4 and std.ascii.isAlphabetic(what[0]) and std.ascii.endsWithIgnoreCase(what, "-by")) {
            okw = true;
            for (what) |c| if (!(std.ascii.isAlphabetic(c) or c == '-')) {
                okw = false;
            };
        }
        if (!okw) continue;
        const lc = chomp(l);
        const rest = blk: {
            const r0 = l[ci + 2 ..];
            const e = std.mem.indexOfScalar(u8, r0, '\n') orelse r0.len;
            break :blk r0[0..e];
        };
        const c = stripGarbageOneAddress(rest);
        const sc = sanitizeAddress(c);
        if (eql(sc, senderStr())) {
            if (sup(supp.self)) continue;
        } else {
            if (std.ascii.eqlIgnoreCase(what, "Signed-off-by")) {
                if (sup(supp.sob)) continue;
            } else if (std.ascii.endsWithIgnoreCase(what, "-by")) {
                if (sup(supp.misc_by)) continue;
            } else {
                if (sup(supp.bodycc)) continue;
            }
        }
        // $c !~ /.+@.+|<.+>/
        var valid_c = false;
        if (c.len >= 3) {
            for (c[1 .. c.len - 1]) |ch| if (ch == '@') {
                valid_c = true;
            };
        }
        if (!valid_c) {
            if (std.mem.indexOfScalar(u8, c, '<')) |lt| {
                if (std.mem.lastIndexOfScalar(u8, c, '>')) |gt| {
                    if (gt > lt + 1) valid_c = true;
                }
            }
        }
        if (!valid_c) {
            if (!q) util.outf("(body) Ignoring {s} from line '{s}'\n", .{ what, lc });
            continue;
        }
        push(&cc_list, sc);
        if (!q) util.outf("(body) Adding cc: {s} from line '{s}'\n", .{ sc, lc });
    }
    message = msg.items;

    if (to_cmd) |cmd| {
        for (recipientsCmd("to-cmd", "to", cmd, t, q).items) |a| push(&to_list, a);
    }
    if (cc_cmd) |cmd| {
        if (!sup(supp.cccmd)) {
            for (recipientsCmd("cc-cmd", "cc", cmd, t, q).items) |a| push(&cc_list, a);
        }
    }

    const broken = broken_encoding.contains(t);
    if (broken and !has_content_type) {
        if (xfer_encoding == null) xfer_encoding = "8bit";
        has_content_type = true;
        push(&xh, util.concat(&.{ "Content-Type: text/plain; charset=", auto_8bit_encoding orelse "" }));
        body_encoding = auto_8bit_encoding;
    }
    if (broken and !isRfc2047Quoted(subject)) subject = quoteSubject(subject, auto_8bit_encoding);

    if (sauthor) |sa| {
        if (!eql(sa, senderStr())) {
            message = util.concat(&.{ "From: ", author.?, "\n\n", message });
            if (author_encoding) |ae| {
                if (!has_content_type) {
                    if (xfer_encoding == null) xfer_encoding = "8bit";
                    has_content_type = true;
                    push(&xh, util.concat(&.{ "Content-Type: text/plain; charset=", ae }));
                }
            }
        }
    }
    const enc = applyTransferEncoding(message, xfer_encoding orelse "8bit", target_xfer_encoding);
    message = enc.msg;
    push(&xh, util.concat(&.{ "Content-Transfer-Encoding: ", enc.enc }));
    if (!has_mime_version) xh.insert(gpa, 0, "MIME-Version: 1.0") catch util.oom();

    const cf = confirm orelse "auto";
    const nc = eql(cf, "always") or
        ((eql(cf, "auto") or eql(cf, "cc")) and cc_list.items.len > 0) or
        ((eql(cf, "auto") or eql(cf, "compose")) and compose != 0 and message_num == 1);
    needs_confirm = if (nc) .yes else .no;
    if (nc and confirm_unconfigured and cc_list.items.len > 0) needs_confirm = .inform;

    const pto = processAddressList(to_list.items);
    const pcc = processAddressList(cc_list.items);
    to_list = .empty;
    for (initial_to.items) |x| push(&to_list, x);
    for (pto.items) |x| push(&to_list, x);
    cc_list = .empty;
    for (initial_cc.items) |x| push(&cc_list, x);
    for (pcc.items) |x| push(&cc_list, x);

    if (message_num == 1) {
        if (cover_cc orelse false) initial_cc = cc_list.clone(gpa) catch util.oom();
        if (cover_to orelse false) initial_to = to_list.clone(gpa) catch util.oom();
    }
}

// ---------------------------------------------------------------- headers / sending

fn uniqueEmailList(l: []const Str) List {
    var seen: std.StringHashMapUnmanaged(void) = .empty;
    var out: List = .empty;
    for (l) |e| {
        const clean = extractValidAddressOrDie(e);
        const gop = seen.getOrPut(gpa, clean) catch util.oom();
        if (gop.found_existing) continue;
        push(&out, e);
    }
    return out;
}

const day_names = [_]Str{ "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
const mon_names = [_]Str{ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

fn format2822Time(t: i64) Str {
    const lt = os.localtime(t);
    const gt = os.gmtime(t);
    var localmin: i64 = lt.min + @as(i64, lt.hour) * 60;
    const gmtmin: i64 = gt.min + @as(i64, gt.hour) * 60;
    if (lt.sec != gt.sec) pdie("local zone differs from GMT by a non-minute interval\n");
    if (@mod(gt.wday + 1, 7) == lt.wday) {
        localmin += 1440;
    } else if (@mod(gt.wday - 1, 7) == lt.wday) {
        localmin -= 1440;
    } else if (gt.wday != lt.wday) pdie("local time offset greater than or equal to 24 hours\n");
    const offset = localmin - gmtmin;
    const aoff: u64 = @abs(offset);
    if (aoff / 60 >= 24) pdie("local time offset greater than or equal to 24 hours\n");
    const sign: u8 = if (offset >= 0) '+' else '-';
    return util.fmt("{s}, {d:>2} {s} {d} {d:0>2}:{d:0>2}:{d:0>2} {c}{d:0>2}{d:0>2}", .{
        day_names[@intCast(lt.wday)], @as(u32, @intCast(lt.mday)), mon_names[@intCast(lt.mon)], lt.year + 1900,
        @as(u32, @intCast(lt.hour)),  @as(u32, @intCast(lt.min)),  @as(u32, @intCast(lt.sec)),  sign,
        aoff / 60,                    aoff % 60,
    });
}

var message_id_stamp: ?Str = null;
var message_id_serial: u64 = 0;

fn makeMessageId() void {
    if (message_id_stamp == null) {
        const g = os.gmtime(os.now());
        message_id_stamp = util.fmt("{d:0>4}{d:0>2}{d:0>2}{d:0>2}{d:0>2}{d:0>2}.{d}", .{
            @as(u32, @intCast(g.year + 1900)), @as(u32, @intCast(g.mon + 1)), @as(u32, @intCast(g.mday)),
            @as(u32, @intCast(g.hour)),        @as(u32, @intCast(g.min)),     @as(u32, @intCast(g.sec)),
            proc.getPid(),
        });
        message_id_serial = 0;
    }
    message_id_serial += 1;
    const uniq = util.fmt("{s}-{d}", .{ message_id_stamp.?, message_id_serial });
    const cands = [_]Str{ senderStr(), repoCommitter(), repoAuthor() };
    var du: ?Str = null;
    for (cands) |c| {
        du = extractValidAddress(sanitizeAddress(c));
        if (du != null and du.?.len > 0) break;
    }
    if (du == null or du.?.len == 0) du = util.concat(&.{ "user@", proc.hostname() });
    message_id = util.fmt("<{s}-{s}>", .{ uniq, du.? });
}

const Header = struct { recipients: List, header: Str };

fn genHeader() Header {
    var recipients = uniqueEmailList(to_list.items);
    var ncc: List = .empty;
    for (cc_list.items) |e| {
        const c = extractValidAddressOrDie(e);
        const pat = util.concat(&.{ "<", c, ">" });
        var dup = false;
        for (recipients.items) |r| {
            if (eql(c, r) or std.mem.endsWith(u8, r, pat)) dup = true;
        }
        if (!dup) push(&ncc, e);
    }
    cc_list = ncc;
    const to = std.mem.join(gpa, ",\n\t", recipients.items) catch util.oom();
    var all: List = .empty;
    for (recipients.items) |x| push(&all, x);
    for (cc_list.items) |x| push(&all, x);
    for (initial_bcc.items) |x| push(&all, x);
    recipients = uniqueEmailList(all.items);
    for (recipients.items) |*x| x.* = extractValidAddressOrDie(x.*);
    const date = format2822Time(time_val);
    time_val += 1;
    const cc = std.mem.join(gpa, ",\n\t", uniqueEmailList(cc_list.items).items) catch util.oom();
    if (message_id == null) makeMessageId();
    var h: Buf = .empty;
    util.bufAppend(&h, "From: ");
    util.bufAppend(&h, senderStr());
    util.bufAppend(&h, "\nTo: ");
    util.bufAppend(&h, to);
    if (cc.len > 0) {
        util.bufAppend(&h, "\nCc: ");
        util.bufAppend(&h, cc);
    }
    util.bufAppend(&h, "\nSubject: ");
    util.bufAppend(&h, subject orelse "");
    util.bufAppend(&h, "\nDate: ");
    util.bufAppend(&h, date);
    util.bufAppend(&h, "\nMessage-ID: ");
    util.bufAppend(&h, message_id.?);
    util.bufAppend(&h, "\n");
    if (use_xmailer) util.bufAppend(&h, "X-Mailer: git-send-email " ++ main_mod.version ++ "\n");
    if (truthy(in_reply_to)) {
        util.bufAppend(&h, util.fmt("In-Reply-To: {s}\nReferences: {s}\n", .{ in_reply_to.?, references }));
    }
    if (truthy(reply_to)) util.bufAppend(&h, util.fmt("Reply-To: {s}\n", .{reply_to.?}));
    if (xh.items.len > 0) {
        util.bufAppend(&h, std.mem.join(gpa, "\n", xh.items) catch util.oom());
        util.bufAppend(&h, "\n");
    }
    return .{ .recipients = recipients, .header = h.items };
}

fn isAbsolute(p: ?Str) bool {
    const v = p orelse return false;
    return v.len > 0 and v[0] == '/';
}

const inform_text =
    \\    The Cc list above has been expanded by additional
    \\    addresses found in the patch commit message. By default
    \\    send-email prompts before sending whenever this occurs.
    \\    This behavior is controlled by the sendemail.confirm
    \\    configuration setting.
    \\
    \\    For additional information, run 'git send-email --help'.
    \\    To retain the current behavior, but squelch this message,
    \\    run 'git config --global sendemail.confirm auto'.
    \\
    \\
;

fn sendMessage() i32 {
    const gh = genHeader();
    const header = gh.header;
    var params: List = .empty;
    push(&params, "-i");
    for (gh.recipients.items) |r| push(&params, r);
    var raw_from: ?Str = senderStr();
    if (envelope_sender) |es| {
        if (!eql(es, "auto")) raw_from = es;
    }
    raw_from = extractValidAddress(raw_from);
    if (envelope_sender != null) {
        params.insert(gpa, 0, raw_from orelse "") catch util.oom();
        params.insert(gpa, 0, "-f") catch util.oom();
    }

    if (needs_confirm != .no and !dry_run) {
        util.outf("\n{s}\n", .{header});
        if (needs_confirm == .inform) {
            confirm_unconfigured = false;
            ask_default = "y";
            util.out(inform_text);
        }
        const r = ask("Send this email? ([y]es|[n]o|[e]dit|[q]uit|[a]ll): ", .send, ask_default, false) orelse
            pdie("Send this email reply required");
        switch (firstLower(r)) {
            'n' => {
                message_num -= 1;
                return 0;
            },
            'e' => {
                message_num -= 1;
                return -1;
            },
            'q' => {
                cleanupComposeFiles();
                finish(0);
            },
            'a' => confirm = "never",
            else => {},
        }
    }

    var full: List = .empty;
    for (smtp_server_options.items) |o| push(&full, o);
    for (params.items) |p| push(&full, p);
    params = full;

    const use_sendmail = sendmail_cmd != null or isAbsolute(smtp_server);
    if (dry_run) {
        // nothing
    } else if (use_imap_only) {
        if (imap_sent_folder == null) pdie("The destination IMAP folder is not properly defined.");
    } else if (use_sendmail) {
        var argv: List = .empty;
        if (sendmail_cmd) |sc| {
            push(&argv, "sh");
            push(&argv, "-c");
            push(&argv, util.concat(&.{ sc, " \"$@\"" }));
            push(&argv, "-");
        } else push(&argv, smtp_server.?);
        for (params.items) |p| push(&argv, p);
        const data = util.concat(&.{ header, "\n", message });
        const r = os.run(argv.items, .{ .stdin_data = data });
        if (r.status != 0) pdie("Died");
    } else {
        if (smtp_server == null) pdie("The required SMTP server is not properly defined.");
        var b: Buf = .empty;
        util.bufAppend(&b, "Unable to initialize SMTP properly. Check config and use --smtp-debug.");
        util.bufAppend(&b, util.fmt(" VALUES: server={s} encryption={s} hello={s}", .{ smtp_server.?, smtp_encryption orelse "", if (truthy(smtp_domain)) smtp_domain.? else "localhost.localdomain" }));
        if (smtp_server_port) |p| util.bufAppend(&b, util.fmt(" port={s}", .{p}));
        pdie(b.items);
    }
    if (quiet) {
        util.outf("{s} {s}\n", .{ if (dry_run) "Dry-Sent" else "Sent", subject orelse "" });
    } else {
        util.out(if (dry_run) "Dry-OK. Log says:\n" else "OK. Log says:\n");
        if (!use_sendmail) {
            util.outf("Server: {s}\n", .{smtp_server orelse ""});
            util.outf("MAIL FROM:<{s}>\n", .{raw_from orelse ""});
            for (gh.recipients.items) |r| util.outf("RCPT TO:<{s}>\n", .{r});
        } else {
            const sm = sendmail_cmd orelse smtp_server.?;
            util.outf("Sendmail: {s} ", .{sm});
            util.out(std.mem.join(gpa, " ", params.items) catch util.oom());
            util.out("\n");
        }
        util.out(header);
        util.out("\n");
        util.out("Result: OK\n");
    }
    return 1;
}

fn processFile(t: Str) bool {
    preProcessFile(t, quiet);
    const sent = sendMessage();
    if (sent == -1) {
        doEdit(&.{t});
        return false;
    }
    if (thread) {
        if (sent != 0 and (chain_reply_to or in_reply_to == null or in_reply_to.?.len == 0 or message_num == 1)) {
            in_reply_to = message_id;
            if (references.len > 0) {
                references = util.concat(&.{ references, "\n ", message_id orelse "" });
            } else references = message_id orelse "";
        }
    } else if (initial_in_reply_to == null) {
        in_reply_to = null;
        references = "";
    }
    message_id = null;
    num_sent += 1;
    if (batch_size) |bs| {
        if (num_sent == perlNum(bs)) {
            num_sent = 0;
            if (relogin_delay) |d| {
                util.flushStdout();
                const n = perlNum(d);
                if (n > 0) _ = sleep(@intCast(n));
            }
        }
    }
    return true;
}

fn initLoopVars() void {
    in_reply_to = initial_in_reply_to;
    references = if (truthy(initial_in_reply_to)) initial_in_reply_to.? else "";
    message_num = 0;
}

fn validatePatch(fn_: Str, xfer: Str) void {
    if (have_repo) {
        const hooks_path = gitOneline(&.{ "rev-parse", "--git-path", "hooks" }, true);
        const hook = util.concat(&.{ hooks_path, "/sendemail-validate" });
        if (os.access(hook, 1) and isRegFile(hook)) {
            const target = os.realPath(fn_) orelse util.dupe(fn_);
            const cwd_save = os.getcwd();
            if (!os.chdir(wc_path orelse repo_path)) pdief("chdir: {s}", .{os.lastErr()});
            const old_git_dir = os.getenv("GIT_DIR");
            const old_copy: ?Str = if (old_git_dir) |g| util.dupe(g) else null;
            os.setEnv("GIT_DIR", repo_path);
            const gh = genHeader();
            const tf = os.tmpFile(repo_path, ".gitsendemail.header.");
            if (tf.fd < 0) pdief("Error in tempfile(): {s}", .{os.lastErr()});
            os.writeAll(tf.fd, gh.header) catch {};
            os.close(tf.fd);
            push(&header_tmp_files, tf.path);
            const r = os.run(&.{ "git", "hook", "run", "--ignore-missing", "sendemail-validate", "--", target, tf.path }, .{});
            if (old_copy) |g| os.setEnv("GIT_DIR", g) else os.unsetEnv("GIT_DIR");
            if (!os.chdir(cwd_save)) pdief("chdir: {s}", .{os.lastErr()});
            if (r.status != 0) {
                pdief("fatal: {s}: rejected by sendemail-validate hook\n" ++
                    "fatal: command 'git hook run --ignore-missing sendemail-validate -- <patch> <header>' died with exit code {d}\n" ++
                    "warning: no patches were sent\n", .{ fn_, r.status });
            }
        }
    }
    if (!(eql(xfer, "auto") or eql(xfer, "quoted-printable") or eql(xfer, "base64"))) {
        const data = readFileOrDie(fn_);
        for (linesKeep(data).items, 1..) |l, n| {
            if (l.len > 998) pdief("fatal: {s}:{d} is longer than 998 characters\nwarning: no patches were sent\n", .{ fn_, n });
        }
    }
}

fn handleBackupFiles(files: []const Str) List {
    var result: List = .empty;
    var last: ?Str = null;
    var known_suffix: ?Str = null;
    for (files) |file| {
        var skip = false;
        if (last) |l| {
            if (l.len < file.len and startsWith(file, l)) {
                const suffix = file[l.len..];
                if (!std.ascii.isAlphanumeric(suffix[0])) {
                    if (known_suffix != null and eql(suffix, known_suffix.?)) {
                        util.outf("Skipping {s} with backup suffix '{s}'.\n", .{ file, known_suffix.? });
                        skip = true;
                    } else {
                        const ans = ask(util.fmt("Do you really want to send {s}? [y|N]: ", .{file}), .yn, "n", false);
                        skip = !eql(ans orelse "", "y");
                        if (skip) known_suffix = suffix;
                    }
                }
            }
        }
        if (!skip) push(&result, file);
        last = file;
    }
    return result;
}

fn makeTempDir() Str {
    const base = os.getenv("TMPDIR") orelse "/tmp";
    const tmpl = util.concat(&.{ if (base.len > 0) base else "/tmp", "/se_XXXXXX" });
    const buf = gpa.allocSentinel(u8, tmpl.len, 0) catch util.oom();
    @memcpy(buf[0..tmpl.len], tmpl);
    if (mkdtemp(buf.ptr) == null) pdief("Error in tempdir() using {s}: {s}", .{ tmpl, os.lastErr() });
    return buf[0..tmpl.len];
}

// ---------------------------------------------------------------- compose

fn doCompose(files: []const Str) void {
    const dir = if (have_repo) repo_path else ".";
    const tf = os.tmpFile(dir, ".gitsendemail.msg.");
    if (tf.fd < 0) pdief("Error in tempfile() using template {s}/.gitsendemail.msg.XXXXXX: {s}", .{ dir, os.lastErr() });
    os.close(tf.fd);
    const cfn: Str = tf.path;
    compose_filename = cfn;

    const tpl_sender = if (truthy(sender)) sender.? else if (truthy(repoAuthor())) repoAuthor() else if (truthy(repoCommitter())) repoCommitter() else "";
    const tpl_subject = if (truthy(initial_subject)) initial_subject.? else "";
    const tpl_irt = if (truthy(initial_in_reply_to)) initial_in_reply_to.? else "";
    const tpl_reply_to = if (truthy(reply_to)) reply_to.? else "";
    var c: Buf = .empty;
    util.bufAppend(&c, util.fmt("From {s} # This line is ignored.\n", .{tpl_sender}));
    util.bufAppend(&c, "GIT: Lines beginning in \"GIT:\" will be removed.\n" ++
        "GIT: Consider including an overall diffstat or table of contents\n" ++
        "GIT: for the patch you are writing.\n" ++
        "GIT: \n" ++
        "GIT: Clear the body content if you don't wish to send a summary.\n");
    util.bufAppend(&c, util.fmt("From: {s}\nTo: {s}\nCc: {s}\nBcc: {s}\nReply-To: {s}\nSubject: {s}\nIn-Reply-To: {s}\n\n", .{
        tpl_sender,
        std.mem.join(gpa, ",", initial_to.items) catch util.oom(),
        std.mem.join(gpa, ",", initial_cc.items) catch util.oom(),
        std.mem.join(gpa, ", ", initial_bcc.items) catch util.oom(),
        tpl_reply_to,
        tpl_subject,
        tpl_irt,
    }));
    for (files) |f| util.bufAppend(&c, getPatchSubject(f));
    os.writeFile(cfn, c.items, 0o600) catch pdief("Failed to open for writing {s}: {s}", .{ cfn, os.lastErr() });

    if (annotate orelse false) {
        var l: List = .empty;
        push(&l, cfn);
        for (files) |f| push(&l, f);
        doEdit(l.items);
    } else doEdit(&.{cfn});

    const data = os.readFile(cfn) orelse pdief("Failed to open {s}: {s}", .{ cfn, os.lastErr() });
    var need_8bit_cte = hasNonAscii(data);
    var in_body = false;
    var summary_empty = true;
    if (compose_encoding == null) compose_encoding = "UTF-8";
    var o: Buf = .empty;
    for (linesKeep(data).items) |l| {
        if (startsWith(l, "GIT:")) continue;
        if (in_body) {
            if (!eql(l, "\n")) summary_empty = false;
        } else if (eql(l, "\n")) {
            in_body = true;
            if (need_8bit_cte) {
                util.bufAppend(&o, util.fmt("MIME-Version: 1.0\nContent-Type: text/plain; charset={s}\nContent-Transfer-Encoding: 8bit\n", .{compose_encoding.?}));
            }
        } else if (startsWithI(l, "MIME-Version:")) {
            need_8bit_cte = false;
        } else if (composeHdr(l, "Subject:")) |v| {
            initial_subject = v;
            util.bufAppend(&o, util.concat(&.{ "Subject: ", quoteSubject(v, compose_encoding).?, "\n" }));
            continue;
        } else if (composeHdr(l, "In-Reply-To:")) |v| {
            initial_in_reply_to = v;
            continue;
        } else if (composeHdr(l, "Reply-To:")) |v| {
            reply_to = v;
        } else if (composeHdr(l, "From:")) |v| {
            sender = v;
            continue;
        } else if (composeHdr(l, "To:")) |v| {
            initial_to = parseAddressLine(v);
            continue;
        } else if (composeHdr(l, "Cc:")) |v| {
            initial_cc = parseAddressLine(v);
            continue;
        } else if (startsWithI(l, "Bcc:")) {
            initial_bcc = .empty;
            continue;
        }
        util.bufAppend(&o, l);
    }
    os.writeFile(util.concat(&.{ cfn, ".final" }), o.items, 0o666) catch pdief("Failed to open {s}.final: {s}", .{ cfn, os.lastErr() });
    if (summary_empty) {
        util.out("Summary email is empty, skipping it\n");
        compose = -1;
    }
}

/// /^Name:\s*(.+)\s*$/i on a line (with its newline).
fn composeHdr(l: Str, name: Str) ?Str {
    if (!startsWithI(l, name)) return null;
    const rest = chomp(l[name.len..]);
    if (std.mem.indexOfScalar(u8, rest, '\n') != null) return null;
    if (rest.len == 0) return null;
    const t = trimStartWs(rest);
    if (t.len == 0) return rest[rest.len - 1 ..];
    return t;
}

// ---------------------------------------------------------------- main

pub fn cmdSendEmail(args_in: []const []const u8) u8 {
    detectRepo();
    loadKnownKeys();

    if (known_keys.get("sendemail.identity") != null) {
        identity = gitConfigQuery(&.{ "config", "--get", "sendemail.identity" });
    }
    var argv = getopt(args_in[1..], &identity_specs);
    if (no_identity) identity = null;
    if (identity) |id| readConfig(util.concat(&.{ "sendemail.", id }));
    readConfig("sendemail");

    argv = getopt(argv.items, &dump_specs);
    if (!help and (dump_aliases or translate_aliases) and argv.items.len > 0)
        pdie("--dump-aliases incompatible with other options\n");
    if (!help and dump_aliases and translate_aliases)
        pdie("--dump-aliases and --translate-aliases are mutually exclusive\n");
    argv = getopt(argv.items, &main_specs);

    initial_to = if (getopt_to.items.len > 0) getopt_to else if (no_to) .empty else config_to;
    initial_cc = if (getopt_cc.items.len > 0) getopt_cc else if (no_cc) .empty else config_cc;
    initial_bcc = if (getopt_bcc.items.len > 0) getopt_bcc else if (no_bcc) .empty else config_bcc;

    if (help) usage(0);
    if (completion_helper) doCompletionHelper();

    if (forbid_sendmail_variables) {
        for (known_key_order.items) |k| {
            if (startsWith(k, "sendmail")) pdie("fatal: found configuration options for 'sendmail'\n" ++
                "git-send-email is configured with the sendemail.* options - note the 'e'.\n" ++
                "Set sendemail.forbidSendmailVariables to false to disable this check.\n");
        }
    }
    if ((format_patch orelse false) and !have_repo) pdie("Cannot run git format-patch from outside a repository\n");
    if (relogin_delay != null and batch_size == null)
        pdie("`batch-size` and `relogin` must be specified together (via command-line or configuration option)\n");
    if (smtp_encryption == null) smtp_encryption = "";

    var any_supp = false;
    for (suppress_cc_list.items) |e| {
        if (eql(e, "all")) supp.all = true else if (eql(e, "cccmd")) supp.cccmd = true else if (eql(e, "cc")) supp.cc = true else if (eql(e, "author")) supp.author = true else if (eql(e, "self")) supp.self = true else if (eql(e, "sob")) supp.sob = true else if (eql(e, "body")) supp.body = true else if (eql(e, "bodycc")) supp.bodycc = true else if (eql(e, "misc-by")) supp.misc_by = true else pdief("Unknown --suppress-cc field: '{s}'\n", .{e});
        any_supp = true;
    }
    if (sup(supp.all)) {
        supp.cccmd = true;
        supp.cc = true;
        supp.author = true;
        supp.self = true;
        supp.sob = true;
        supp.body = true;
        supp.bodycc = true;
        supp.misc_by = true;
        supp.all = null;
    }
    if (suppress_from) |v| {
        supp.self = v;
        any_supp = true;
    }
    if (signed_off_by_cc) |v| {
        supp.sob = !v;
        any_supp = true;
    }
    if (sup(supp.body)) {
        supp.sob = true;
        supp.bodycc = true;
        supp.misc_by = true;
    }
    supp.body = null;
    {
        // "scalar %suppress_cc": any key still present
        const s = supp;
        any_supp = s.cccmd != null or s.cc != null or s.author != null or s.self != null or s.sob != null or s.bodycc != null or s.misc_by != null;
    }

    confirm_unconfigured = confirm == null;
    if (confirm_unconfigured) confirm = if (any_supp) "compose" else "auto";
    {
        const cf = confirm.?;
        const ok = startsWith(cf, "auto") or startsWith(cf, "cc") or startsWith(cf, "compose") or startsWith(cf, "always") or startsWith(cf, "never");
        if (!ok) pdief("Unknown --confirm setting: '{s}'\n", .{cf});
    }

    loadAliases();

    if (dump_aliases) {
        var keys: List = .empty;
        var it = aliases.keyIterator();
        while (it.next()) |k| push(&keys, k.*);
        util.sortStrings(keys.items);
        for (keys.items) |k| util.outf("{s}\n", .{k});
        finish(0);
    }
    if (translate_aliases) {
        var input: Buf = .empty;
        var rb: [4096]u8 = undefined;
        while (true) {
            const n = read(0, &rb, rb.len);
            if (n <= 0) break;
            util.bufAppend(&input, rb[0..@intCast(n)]);
        }
        for (linesKeep(input.items).items) |l| {
            const parsed = parseAddressLine(l);
            const ex = expandAliases(parsed.items);
            for (sanitizeList(ex.items).items) |a| util.outf("{s}\n", .{a});
        }
        finish(0);
    }

    // collect files
    var files: List = .empty;
    var rev_list_opts: List = .empty;
    {
        var i: usize = 0;
        const a = argv.items;
        while (i < a.len) : (i += 1) {
            const f = a[i];
            if (eql(f, "--")) {
                push(&rev_list_opts, "--");
                i += 1;
                while (i < a.len) : (i += 1) push(&rev_list_opts, a[i]);
                break;
            } else if (isDirPath(f) and !isFormatPatchArg(f)) {
                const ents = os.listDir(f) orelse pdief("Failed to opendir {s}: {s}", .{ f, os.lastErr() });
                var names: List = .empty;
                for (ents) |e| push(&names, e.name);
                util.sortStrings(names.items);
                for (names.items) |n| {
                    const p = catFile(f, n);
                    if (isRegFile(p)) push(&files, p);
                }
            } else if ((isRegFile(f) or isFifo(f)) and !isFormatPatchArg(f)) {
                push(&files, f);
            } else push(&rev_list_opts, f);
        }
    }
    if (rev_list_opts.items.len > 0) {
        if (!have_repo) pdie("Cannot run git format-patch from outside a repository\n");
        const td = makeTempDir();
        fp_tmpdir = td;
        var fa: List = .empty;
        push(&fa, "format-patch");
        push(&fa, "-o");
        push(&fa, td);
        if (reroll_count) |v| {
            push(&fa, "-v");
            push(&fa, v);
        }
        for (rev_list_opts.items) |o| push(&fa, o);
        for (gitLines(fa.items, true).items) |l| push(&files, l);
    }

    if (sender) |s0| {
        const ex = expandAliases(&.{trimWs(s0)});
        sender = if (ex.items.len > 0) ex.items[0] else null;
    } else {
        sender = if (truthy(repoAuthor())) repoAuthor() else if (truthy(repoCommitter())) repoCommitter() else "";
    }
    sender = sanitizeAddress(senderStr());

    time_val = os.now() - (@as(i64, @intCast(files.items.len)) - 1);

    files = handleBackupFiles(files.items);
    if (files.items.len > 0) {
        if (!quiet) for (files.items) |f| util.outf("{s}\n", .{f});
    } else {
        util.ewrite("\nNo patch files specified!\n\n");
        usage(1);
    }

    if (compose != 0) {
        doCompose(files.items);
    } else if (annotate orelse false) {
        doEdit(files.items);
    }

    for (files.items) |f| {
        if (bodyOrSubjectHasNonAscii(f) and !fileDeclares8bitCte(f)) broken_encoding.put(gpa, f, {}) catch util.oom();
    }
    if (auto_8bit_encoding == null and broken_encoding.count() > 0) {
        util.out("The following files are 8bit, but do not declare a Content-Transfer-Encoding.\n");
        var keys: List = .empty;
        var it = broken_encoding.keyIterator();
        while (it.next()) |k| push(&keys, k.*);
        util.sortStrings(keys.items);
        for (keys.items) |k| util.outf("    {s}\n", .{k});
        while (true) {
            const e = ask("Declare which 8bit encoding to use [default: UTF-8]? ", .nonspace, "UTF-8", false) orelse continue;
            if (findEncoding(e)) {
                auto_8bit_encoding = e;
                break;
            }
            const yn = ask(util.fmt("'{s}' does not appear to be a valid charset name. Use it anyway [y/N]? ", .{e}), .yn, "n", false);
            if (firstLower(yn) == 'y') {
                auto_8bit_encoding = e;
                break;
            }
        }
    }

    if (!force) {
        for (files.items) |f| {
            if (std.mem.indexOf(u8, getPatchSubject(f), "*** SUBJECT HERE ***") != null) {
                pdief("Refusing to send because the patch\n\t{s}\nhas the template subject '*** SUBJECT HERE ***'. Pass --force if you really want to send.\n", .{f});
            }
        }
    }

    var prompting = false;
    if (initial_to.items.len == 0 and to_cmd == null) {
        const to = ask("To whom should the emails be sent (if anyone)? ", .at_dot, "", true);
        if (to) |t| {
            for (parseAddressLine(t).items) |x| push(&initial_to, x);
        }
        prompting = true;
    }

    initial_to = processAddressList(initial_to.items);
    initial_cc = processAddressList(initial_cc.items);
    initial_bcc = processAddressList(initial_bcc.items);

    if (thread and initial_in_reply_to == null and prompting) {
        initial_in_reply_to = ask("Message-ID to be used as In-Reply-To for the first email (if any)? ", .at_dot, "", true);
    }
    if (initial_in_reply_to) |irt0| {
        var irt = trimStartWs(irt0);
        if (irt.len > 0 and irt[0] == '<') irt = irt[1..];
        irt = trimEndWs(irt);
        if (irt.len > 0 and irt[irt.len - 1] == '>') irt = irt[0 .. irt.len - 1];
        initial_in_reply_to = if (irt.len > 0) util.concat(&.{ "<", irt, ">" }) else "";
    }
    if (reply_to) |rt| {
        const ex = expandAliases(&.{trimWs(rt)});
        reply_to = sanitizeAddress(if (ex.items.len > 0) ex.items[0] else "");
    }

    if (sendmail_cmd == null and smtp_server == null) {
        var paths: List = .empty;
        push(&paths, "/usr/sbin/sendmail");
        push(&paths, "/usr/lib/sendmail");
        var it = std.mem.splitScalar(u8, os.getenv("PATH") orelse "", ':');
        while (it.next()) |p| push(&paths, util.concat(&.{ p, "/sendmail" }));
        for (paths.items) |p| {
            if (os.access(p, 1)) {
                sendmail_cmd = p;
                break;
            }
        }
        if (sendmail_cmd == null) smtp_server = "localhost";
    }

    if (compose > 0) {
        files.insert(gpa, 0, util.concat(&.{ compose_filename.?, ".final" })) catch util.oom();
    }

    if (validate) {
        var real_files: List = .empty;
        for (files.items) |f| if (!isFifo(f)) push(&real_files, f);
        if (smtp_server_port) |port| {
            var ok = false;
            if (port.len > 0) {
                var digits = true;
                for (port) |ch| if (ch < '0' or ch > '9') {
                    digits = false;
                };
                if (digits) {
                    const v = std.fmt.parseInt(u64, port, 10) catch 0;
                    ok = v > 0 and v <= 65535;
                }
            }
            if (!ok) {
                const pz = gpa.allocSentinel(u8, port.len, 0) catch util.oom();
                @memcpy(pz[0..port.len], port);
                ok = getservbyname(pz.ptr, null) != null;
            }
            if (!ok) pdief("error: invalid SMTP port '{s}'\n", .{port});
        }
        os.setEnv("GIT_SENDEMAIL_FILE_TOTAL", util.fmt("{d}", .{real_files.items.len}));
        initLoopVars();
        for (real_files.items, 1..) |r, num| {
            os.setEnv("GIT_SENDEMAIL_FILE_COUNTER", util.fmt("{d}", .{num}));
            preProcessFile(r, true);
            validatePatch(r, target_xfer_encoding);
        }
        os.unsetEnv("GIT_SENDEMAIL_FILE_COUNTER");
        os.unsetEnv("GIT_SENDEMAIL_FILE_TOTAL");
    }

    initLoopVars();
    for (files.items) |t| {
        while (!processFile(t)) {}
    }

    cleanupComposeFiles();
    finish(0);
}
