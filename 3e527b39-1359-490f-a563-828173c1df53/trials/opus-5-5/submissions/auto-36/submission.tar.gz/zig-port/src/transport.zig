//! Remotes, refspecs and the git:// style transport over local subprocesses
//! (port of remote.c, refspec.c, connect.c and parts of transport.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const hash = @import("hash.zig");
const pkt = @import("pktline.zig");
const proc = @import("proc.zig");
const config = @import("config.zig");
const conn = @import("connect.zig");
const th = @import("transport_helper.zig");
const bundle = @import("cmd/bundle.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

// ---------------- refspecs ----------------

pub const RefspecItem = struct {
    force: bool = false,
    pattern: bool = false,
    matching: bool = false,
    exact_sha1: bool = false,
    negative: bool = false,
    src: ?[]const u8 = null,
    dst: ?[]const u8 = null,
    raw: []const u8 = "",
};

fn checkRef(name: []const u8, flags: u32) bool {
    return refs.checkRefnameFormat(name, flags);
}

pub fn parseRefspec(spec: []const u8, fetch: bool) ?RefspecItem {
    var item = RefspecItem{ .raw = spec };
    var lhs = spec;
    if (lhs.len > 0 and lhs[0] == '+') {
        item.force = true;
        lhs = lhs[1..];
    } else if (lhs.len > 0 and lhs[0] == '^') {
        item.negative = true;
        lhs = lhs[1..];
    }
    const colon = std.mem.lastIndexOfScalar(u8, lhs, ':');
    if (item.negative and colon != null) return null;
    if (!fetch and colon != null and colon.? == 0 and lhs.len == 1) {
        item.matching = true;
        return item;
    }
    var is_glob = false;
    if (colon) |ci| {
        const rhs = lhs[ci + 1 ..];
        is_glob = rhs.len >= 1 and std.mem.indexOfScalar(u8, rhs, '*') != null;
        item.dst = rhs;
    }
    const l = if (colon) |ci| lhs[0..ci] else lhs;
    if (l.len >= 1 and std.mem.indexOfScalar(u8, l, '*') != null) {
        if ((colon != null and !is_glob) or (colon == null and !item.negative and fetch)) return null;
        is_glob = true;
    } else if (colon != null and is_glob) {
        return null;
    }
    item.pattern = is_glob;
    item.src = if (l.len == 1 and l[0] == '@') "HEAD" else l;
    const flags: u32 = refs.ALLOW_ONELEVEL | (if (is_glob) refs.REFSPEC_PATTERN else 0);
    const src = item.src.?;
    if (item.negative) {
        if (src.len == 0) return null;
        if (src.len == 40 and hash.fromHex(src) != null) return null;
        if (!checkRef(src, flags)) return null;
        return item;
    }
    if (fetch) {
        if (src.len == 0) {} else if (src.len == 40 and hash.fromHex(src) != null) {
            item.exact_sha1 = true;
        } else if (!checkRef(src, flags)) return null;
        if (item.dst) |d| {
            if (d.len > 0 and !checkRef(d, flags)) return null;
        }
    } else {
        if (src.len > 0 and is_glob) {
            if (!checkRef(src, flags)) return null;
        }
        if (item.dst) |d| {
            if (d.len == 0) return null;
            if (!checkRef(d, flags)) return null;
        } else {
            if (!checkRef(src, flags)) return null;
        }
    }
    return item;
}

pub const Refspec = struct {
    items: std.ArrayList(RefspecItem) = .empty,
    fetch: bool,

    pub fn append(self: *Refspec, s: []const u8) void {
        const it = parseRefspec(util.dupe(s), self.fetch) orelse util.die("invalid refspec '{s}'", .{s});
        self.items.append(gpa, it) catch util.oom();
    }

    pub fn findMatch(self: *const Refspec, query_src: ?[]const u8, query_dst: ?[]const u8) ?struct { value: []const u8, force: bool } {
        const find_src = query_src == null;
        const needle = if (find_src) query_dst.? else query_src.?;
        if (self.findNegativeMatch(needle, find_src)) return null;
        for (self.items.items) |r| {
            if (r.dst == null or r.negative) continue;
            const key = (if (find_src) r.dst else r.src) orelse continue;
            const value = (if (find_src) r.src else r.dst) orelse continue;
            if (r.pattern) {
                if (matchRefnameWithPattern(key, needle, value)) |res| return .{ .value = res, .force = r.force };
            } else if (util.eql(needle, key)) {
                return .{ .value = value, .force = r.force };
            }
        }
        return null;
    }

    pub fn findAllMatches(self: *const Refspec, query_src: ?[]const u8, query_dst: ?[]const u8, results: *std.ArrayList([]const u8)) void {
        const find_src = query_src == null;
        const needle = if (find_src) query_dst.? else query_src.?;
        if (self.findNegativeMatch(needle, find_src)) return;
        for (self.items.items) |r| {
            if (r.dst == null or r.negative) continue;
            const key = (if (find_src) r.dst else r.src) orelse continue;
            const value = (if (find_src) r.src else r.dst) orelse continue;
            if (r.pattern) {
                if (matchRefnameWithPattern(key, needle, value)) |res| results.append(gpa, res) catch util.oom();
            } else if (util.eql(needle, key)) {
                results.append(gpa, value) catch util.oom();
            }
        }
    }

    fn findNegativeMatch(self: *const Refspec, needle: []const u8, find_src: bool) bool {
        _ = find_src;
        var reversed: std.ArrayList([]const u8) = .empty;
        for (self.items.items) |r| {
            if (r.negative) continue;
            if (r.pattern) {
                const key = r.dst orelse r.src.?;
                if (matchRefnameWithPattern(key, needle, r.src.?)) |e| reversed.append(gpa, e) catch util.oom();
            } else if (r.matching) {
                reversed.append(gpa, needle) catch util.oom();
            } else if (r.src) |s| {
                if (util.eql(needle, s)) reversed.append(gpa, s) catch util.oom();
            }
        }
        for (reversed.items) |n| {
            if (self.matchesNegative(n)) return true;
        }
        return false;
    }

    pub fn matchesNegative(self: *const Refspec, name: []const u8) bool {
        for (self.items.items) |r| {
            if (r.negative and refspecMatch(r, name)) return true;
        }
        return false;
    }

    pub fn applyRefspecs(self: *const Refspec, name: []const u8) ?[]const u8 {
        const m = self.findMatch(name, null) orelse return null;
        return m.value;
    }

    /// refspec_ref_prefixes
    pub fn refPrefixes(self: *const Refspec, out: *std.ArrayList([]const u8)) void {
        for (self.items.items) |item| {
            if (item.negative) continue;
            var prefix: ?[]const u8 = null;
            if (self.fetch) {
                if (item.exact_sha1) continue;
                prefix = item.src;
            } else {
                if (item.dst) |d| {
                    prefix = d;
                } else if (item.src != null and !item.exact_sha1) prefix = item.src;
            }
            const p = prefix orelse continue;
            if (item.pattern) {
                const star = std.mem.indexOfScalar(u8, p, '*').?;
                out.append(gpa, p[0..star]) catch util.oom();
            } else expandRefPrefix(out, p);
        }
    }
};

pub fn refspecMatch(r: RefspecItem, name: []const u8) bool {
    if (r.pattern) return matchRefnameWithPattern(r.src.?, name, null) != null;
    return util.eql(r.src.?, name);
}

/// Returns the replacement (or "" if replacement is null) when matched.
pub fn matchRefnameWithPattern(pattern: []const u8, refname: []const u8, replacement: ?[]const u8) ?[]const u8 {
    const kstar = std.mem.indexOfScalar(u8, pattern, '*') orelse util.die("pattern '{s}' has no '*'", .{pattern});
    const klen = kstar;
    const ksuffix = pattern[kstar + 1 ..];
    if (!util.startsWith(refname, pattern[0..klen])) return null;
    if (refname.len < klen + ksuffix.len) return null;
    if (!util.endsWith(refname, ksuffix)) return null;
    const repl = replacement orelse return "";
    const vstar = std.mem.indexOfScalar(u8, repl, '*') orelse util.die("replacement '{s}' has no '*'", .{repl});
    return util.concat(&.{ repl[0..vstar], refname[klen .. refname.len - ksuffix.len], repl[vstar + 1 ..] });
}

pub const rev_parse_rules = [_][2][]const u8{
    .{ "", "" },
    .{ "refs/", "" },
    .{ "refs/tags/", "" },
    .{ "refs/heads/", "" },
    .{ "refs/remotes/", "" },
    .{ "refs/remotes/", "/HEAD" },
};

pub fn expandRefPrefix(out: *std.ArrayList([]const u8), p: []const u8) void {
    for (rev_parse_rules) |r| out.append(gpa, util.concat(&.{ r[0], p, r[1] })) catch util.oom();
}

/// refname_match(): score of abbrev matching full name (0 = no match)
pub fn refnameMatch(abbrev: []const u8, full: []const u8) usize {
    for (rev_parse_rules, 0..) |r, i| {
        if (full.len == r[0].len + abbrev.len + r[1].len and util.startsWith(full, r[0]) and
            util.eql(full[r[0].len .. r[0].len + abbrev.len], abbrev) and util.endsWith(full, r[1]))
            return rev_parse_rules.len - i;
    }
    return 0;
}

// ---------------- remotes ----------------

pub const FollowHead = enum { unconfigured, never, create, warn, always };

pub const Remote = struct {
    name: []const u8,
    urls: std.ArrayList([]const u8) = .empty,
    pushurls: std.ArrayList([]const u8) = .empty,
    fetch: Refspec = .{ .fetch = true },
    push: Refspec = .{ .fetch = false },
    fetch_tags: i32 = 0,
    prune: ?bool = null,
    prune_tags: ?bool = null,
    mirror: bool = false,
    skip_default_update: bool = false,
    receivepack: ?[]const u8 = null,
    uploadpack: ?[]const u8 = null,
    configured: bool = false,
    configured_in_repo: bool = false,
    follow_remote_head: FollowHead = .unconfigured,
    no_warn_branch: ?[]const u8 = null,
    from_config: bool = false,
    negotiation_restrict: std.ArrayList([]const u8) = .empty,
    negotiation_include: std.ArrayList([]const u8) = .empty,
};

pub const Branch = struct {
    name: []const u8,
    refname: []const u8,
    remote_name: ?[]const u8 = null,
    pushremote_name: ?[]const u8 = null,
    merge: std.ArrayList([]const u8) = .empty,
    /// tracking refs for merge entries (dst)
    merge_dst: std.ArrayList(?[]const u8) = .empty,
};

const Rewrite = struct { base: []const u8, instead_of: std.ArrayList([]const u8) = .empty };

var loaded = false;
var remotes_list: std.ArrayList(*Remote) = .empty;
var branches_list: std.ArrayList(*Branch) = .empty;
var rewrites: std.ArrayList(Rewrite) = .empty;
var rewrites_push: std.ArrayList(Rewrite) = .empty;
pub var pushremote_default: ?[]const u8 = null;

pub fn invalidate() void {
    loaded = false;
    remotes_list = .empty;
    branches_list = .empty;
    rewrites = .empty;
    rewrites_push = .empty;
    pushremote_default = null;
}

fn makeRemote(name: []const u8) *Remote {
    for (remotes_list.items) |r| {
        if (util.eql(r.name, name)) return r;
    }
    const r = gpa.create(Remote) catch util.oom();
    r.* = .{ .name = util.dupe(name) };
    remotes_list.append(gpa, r) catch util.oom();
    return r;
}

fn makeBranch(name: []const u8) *Branch {
    for (branches_list.items) |b| {
        if (util.eql(b.name, name)) return b;
    }
    const b = gpa.create(Branch) catch util.oom();
    b.* = .{ .name = util.dupe(name), .refname = util.concat(&.{ "refs/heads/", name }) };
    branches_list.append(gpa, b) catch util.oom();
    return b;
}

fn addRewrite(list: *std.ArrayList(Rewrite), base: []const u8, v: []const u8) void {
    for (list.items) |*rw| {
        if (util.eql(rw.base, base)) {
            rw.instead_of.append(gpa, v) catch util.oom();
            return;
        }
    }
    var rw = Rewrite{ .base = base };
    rw.instead_of.append(gpa, v) catch util.oom();
    list.append(gpa, rw) catch util.oom();
}

fn splitKey(key: []const u8, section: []const u8) ?struct { name: []const u8, sub: []const u8 } {
    const rest = util.skipPrefix(key, section) orelse return null;
    if (rest.len == 0 or rest[0] != '.') return null;
    const r2 = rest[1..];
    const dot = std.mem.lastIndexOfScalar(u8, r2, '.') orelse return null;
    return .{ .name = r2[0..dot], .sub = r2[dot + 1 ..] };
}

fn load() void {
    if (loaded) return;
    loaded = true;
    for (repo_mod.cfg.entries.items) |e| {
        const v = e.value;
        if (splitKey(e.key, "branch")) |k| {
            if (k.name.len == 0) continue;
            const b = makeBranch(k.name);
            if (util.eql(k.sub, "remote")) {
                b.remote_name = v;
            } else if (util.eql(k.sub, "pushremote")) {
                b.pushremote_name = v;
            } else if (util.eql(k.sub, "merge")) {
                if (v) |val| b.merge.append(gpa, val) catch util.oom();
            }
            continue;
        }
        if (splitKey(e.key, "url")) |k| {
            if (v) |val| {
                if (util.eql(k.sub, "insteadof")) addRewrite(&rewrites, k.name, val);
                if (util.eql(k.sub, "pushinsteadof")) addRewrite(&rewrites_push, k.name, val);
            }
            continue;
        }
        if (util.eql(e.key, "remote.pushdefault")) {
            pushremote_default = v;
            continue;
        }
        const k = splitKey(e.key, "remote") orelse continue;
        if (k.name.len > 0 and k.name[0] == '/') {
            util.warn("config remote shorthand cannot begin with '/': {s}", .{k.name});
            continue;
        }
        const r = makeRemote(k.name);
        r.from_config = true;
        if (e.scope == .local or e.scope == .worktree) r.configured_in_repo = true;
        const val = v orelse "";
        const s = k.sub;
        if (util.eql(s, "mirror")) {
            r.mirror = if (v) |x| (config.parseBool(x) orelse false) else true;
        } else if (util.eql(s, "skipdefaultupdate") or util.eql(s, "skipfetchall")) {
            r.skip_default_update = if (v) |x| (config.parseBool(x) orelse false) else true;
        } else if (util.eql(s, "prune")) {
            r.prune = if (v) |x| (config.parseBool(x) orelse false) else true;
        } else if (util.eql(s, "prunetags")) {
            r.prune_tags = if (v) |x| (config.parseBool(x) orelse false) else true;
        } else if (util.eql(s, "url")) {
            if (v == null) util.die("missing value for '{s}'", .{e.key});
            r.urls.append(gpa, val) catch util.oom();
        } else if (util.eql(s, "pushurl")) {
            if (v == null) util.die("missing value for '{s}'", .{e.key});
            r.pushurls.append(gpa, val) catch util.oom();
        } else if (util.eql(s, "push")) {
            r.push.append(val);
        } else if (util.eql(s, "fetch")) {
            r.fetch.append(val);
        } else if (util.eql(s, "receivepack")) {
            if (r.receivepack == null) r.receivepack = val else util.err("more than one receivepack given, using the first", .{});
        } else if (util.eql(s, "uploadpack")) {
            if (r.uploadpack == null) r.uploadpack = val else util.err("more than one uploadpack given, using the first", .{});
        } else if (util.eql(s, "tagopt")) {
            if (util.eql(val, "--no-tags")) r.fetch_tags = -1 else if (util.eql(val, "--tags")) r.fetch_tags = 2;
        } else if (util.eql(s, "negotiationrestrict") or util.eql(s, "negotiationinclude")) {
            if (v == null) util.die("missing value for '{s}'", .{e.key});
            const lst = if (s[11] == 'r') &r.negotiation_restrict else &r.negotiation_include;
            if (val.len == 0) lst.clearRetainingCapacity() else lst.append(gpa, val) catch util.oom();
        } else if (util.eql(s, "followremotehead")) {
            if (util.eql(val, "never")) {
                r.follow_remote_head = .never;
            } else if (util.eql(val, "create")) {
                r.follow_remote_head = .create;
            } else if (util.eql(val, "warn")) {
                r.follow_remote_head = .warn;
                r.no_warn_branch = null;
            } else if (util.skipPrefix(val, "warn-if-not-")) |nb| {
                r.follow_remote_head = .warn;
                r.no_warn_branch = nb;
            } else if (util.eql(val, "always")) {
                r.follow_remote_head = .always;
            } else util.warn("unrecognized followRemoteHEAD value '{s}' ignored", .{val});
        }
    }
    // alias urls
    for (remotes_list.items) |r| aliasRemoteUrls(r);
}

fn aliasUrl(url: []const u8, list: []const Rewrite) ?[]const u8 {
    var best: ?[]const u8 = null;
    var best_base: []const u8 = "";
    for (list) |rw| {
        for (rw.instead_of.items) |io| {
            if (util.startsWith(url, io) and (best == null or best.?.len < io.len)) {
                best = io;
                best_base = rw.base;
            }
        }
    }
    const b = best orelse return null;
    return util.concat(&.{ best_base, url[b.len..] });
}

fn aliasRemoteUrls(r: *Remote) void {
    for (r.pushurls.items) |*u| {
        if (aliasUrl(u.*, rewrites.items)) |a| u.* = a;
    }
    const add_push_aliases = r.pushurls.items.len == 0;
    for (r.urls.items) |*u| {
        if (add_push_aliases) {
            if (aliasUrl(u.*, rewrites_push.items)) |pa| r.pushurls.append(gpa, pa) catch util.oom();
        }
        if (aliasUrl(u.*, rewrites.items)) |a| u.* = a;
    }
}

fn validRemoteNick(name: []const u8) bool {
    if (name.len == 0 or util.eql(name, ".") or util.eql(name, "..")) return false;
    for (name) |ch| {
        if (ch == '/' or ch == '\\') return false;
    }
    return true;
}

pub fn currentBranch() ?*Branch {
    load();
    const head = refs.readSymbolic("HEAD") orelse return null;
    const short = util.skipPrefix(head, "refs/heads/") orelse return null;
    return makeBranch(short);
}

pub fn branchGet(name: ?[]const u8) ?*Branch {
    load();
    if (name == null or name.?.len == 0 or util.eql(name.?, "HEAD")) return currentBranch();
    return makeBranch(name.?);
}

pub fn remoteNames() [][]const u8 {
    load();
    var l: std.ArrayList([]const u8) = .empty;
    for (remotes_list.items) |r| {
        if (r.from_config) l.append(gpa, r.name) catch util.oom();
    }
    return l.items;
}

pub fn allRemotes() []*Remote {
    load();
    var l: std.ArrayList(*Remote) = .empty;
    for (remotes_list.items) |r| {
        if (r.from_config) l.append(gpa, r) catch util.oom();
    }
    return l.items;
}

fn defaultRemoteName(explicit: *bool) []const u8 {
    if (currentBranch()) |b| {
        if (b.remote_name) |n| {
            explicit.* = true;
            return n;
        }
    }
    explicit.* = false;
    var count: usize = 0;
    var only: []const u8 = "origin";
    for (remotes_list.items) |r| {
        if (r.from_config) {
            count += 1;
            only = r.name;
        }
    }
    if (count == 1) return only;
    return "origin";
}

fn readRemotesFile(r: *Remote) void {
    const rp = repo_mod.repo_ orelse return;
    const data = os.readFile(rp.commonPath(util.concat(&.{ "remotes/", r.name }))) orelse return;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        const line = util.trim(line0);
        if (util.skipPrefix(line, "URL:")) |v| {
            r.urls.append(gpa, util.trim(v)) catch util.oom();
        } else if (util.skipPrefix(line, "Push:")) |v| {
            r.push.append(util.trim(v));
        } else if (util.skipPrefix(line, "Pull:")) |v| {
            r.fetch.append(util.trim(v));
        }
    }
    r.configured = true;
}

fn readBranchesFile(r: *Remote) void {
    const rp = repo_mod.repo_ orelse return;
    const data = os.readFile(rp.commonPath(util.concat(&.{ "branches/", r.name }))) orelse return;
    const line = util.trim(if (std.mem.indexOfScalar(u8, data, '\n')) |i| data[0..i] else data);
    var url = line;
    var frag: []const u8 = "";
    if (std.mem.indexOfScalar(u8, line, '#')) |i| {
        url = line[0..i];
        frag = line[i + 1 ..];
    }
    if (frag.len == 0) frag = "master"; // remote HEAD
    r.urls.append(gpa, url) catch util.oom();
    r.fetch.append(util.fmt("refs/heads/{s}:refs/heads/{s}", .{ frag, r.name }));
    r.push.append(util.fmt("HEAD:refs/heads/{s}", .{frag}));
    r.configured = true;
}

fn remoteGet1(name_in: ?[]const u8, push: bool) ?*Remote {
    load();
    var name_given = name_in != null;
    var name: []const u8 = undefined;
    if (name_in) |n| {
        name = n;
    } else if (push) {
        var explicit = false;
        if (currentBranch()) |b| {
            if (b.pushremote_name) |p| {
                name = p;
                explicit = true;
            }
        }
        if (!explicit) {
            if (pushremote_default) |p| {
                name = p;
                explicit = true;
            }
        }
        if (!explicit) name = defaultRemoteName(&explicit);
        name_given = explicit;
    } else {
        name = defaultRemoteName(&name_given);
    }
    const r = makeRemote(name);
    if (validRemoteNick(name) and repo_mod.repo_ != null) {
        if (r.urls.items.len == 0) readRemotesFile(r);
        if (r.urls.items.len == 0) readBranchesFile(r);
    }
    if (name_given and r.urls.items.len == 0) {
        const u = aliasUrl(name, rewrites.items) orelse name;
        r.urls.append(gpa, u) catch util.oom();
        if (aliasUrl(name, rewrites_push.items)) |pa| r.pushurls.append(gpa, pa) catch util.oom();
    }
    if (r.urls.items.len == 0) return null;
    return r;
}

pub fn remoteGet(name: ?[]const u8) ?*Remote {
    return remoteGet1(name, false);
}

pub fn pushremoteGet(name: ?[]const u8) ?*Remote {
    return remoteGet1(name, true);
}

/// Does the named remote exist in configuration?
pub fn remoteIsConfigured(r: *const Remote, in_repo: bool) bool {
    if (in_repo) return r.configured_in_repo;
    return r.from_config or r.configured;
}

pub fn remoteFindTracking(r: *const Remote, src: []const u8) ?[]const u8 {
    return r.fetch.applyRefspecs(src);
}

/// Merge refs of a branch with their tracking counterparts (set_merge).
pub fn branchMergeDsts(b: *Branch) void {
    if (b.merge_dst.items.len == b.merge.items.len) return;
    b.merge_dst = .empty;
    const rname = b.remote_name orelse {
        for (b.merge.items) |_| b.merge_dst.append(gpa, null) catch util.oom();
        return;
    };
    const r = remoteGet(rname);
    for (b.merge.items) |m| {
        var dst: ?[]const u8 = null;
        if (r) |rr| dst = remoteFindTracking(rr, m);
        if (dst == null and util.eql(rname, ".")) {
            if (refs.dwimRef(m)) |d| {
                dst = if (d.count == 1) d.name else m;
            } else dst = m;
        }
        b.merge_dst.append(gpa, dst) catch util.oom();
    }
}

pub fn branchMergeMatches(b: ?*Branch, i: usize, refname: []const u8) bool {
    const br = b orelse return false;
    if (i >= br.merge.items.len) return false;
    return refnameMatch(br.merge.items[i], refname) != 0;
}

// ---------------- remote refs ----------------

pub const PushStatus = enum {
    none,
    ok,
    reject_nonfastforward,
    reject_already_exists,
    reject_nodelete,
    reject_fetch_first,
    reject_needs_force,
    reject_stale,
    reject_remote_updated,
    reject_shallow,
    uptodate,
    remote_reject,
    expecting_report,
    atomic_push_failed,
};

pub const Ref = struct {
    name: []const u8,
    old_oid: Oid = hash.zero,
    new_oid: Oid = hash.zero,
    old_oid_expect: Oid = hash.zero,
    symref: ?[]const u8 = null,
    peer_ref: ?*Ref = null,
    force: bool = false,
    exact_oid: bool = false,
    deletion: bool = false,
    forced_update: bool = false,
    expect_old_sha1: bool = false,
    check_old: bool = false,
    fetch_head_status: enum { merge, not_for_merge, ignore } = .not_for_merge,
    status: PushStatus = .none,
    remote_status: ?[]const u8 = null,
    matched: bool = false,
};

pub fn allocRef(name: []const u8) *Ref {
    const r = gpa.create(Ref) catch util.oom();
    r.* = .{ .name = util.dupe(name) };
    return r;
}

pub fn copyRef(r: *const Ref) *Ref {
    const n = gpa.create(Ref) catch util.oom();
    n.* = r.*;
    n.name = util.dupe(r.name);
    if (r.peer_ref) |p| n.peer_ref = copyRef(p);
    return n;
}

pub fn findRefByName(list: []const *Ref, name: []const u8) ?*Ref {
    for (list) |r| {
        if (util.eql(r.name, name)) return r;
    }
    return null;
}

pub fn findRefByNameAbbrev(list: []const *Ref, name: []const u8) ?*Ref {
    var best: ?*Ref = null;
    var best_score: usize = 0;
    for (list) |r| {
        const s = refnameMatch(name, r.name);
        if (best_score < s) {
            best = r;
            best_score = s;
        }
    }
    return best;
}

fn ignoreSymrefUpdate(name: []const u8) bool {
    return switch (refs.readRawFull(name)) {
        .symref => true,
        else => false,
    };
}

pub fn getLocalRef(name: ?[]const u8) ?*Ref {
    const n = name orelse return null;
    if (n.len == 0) return null;
    if (util.startsWith(n, "refs/")) return allocRef(n);
    if (util.startsWith(n, "heads/") or util.startsWith(n, "tags/") or util.startsWith(n, "remotes/"))
        return allocRef(util.concat(&.{ "refs/", n }));
    return allocRef(util.concat(&.{ "refs/heads/", n }));
}

/// get_fetch_map
pub fn getFetchMap(remote_refs: []const *Ref, spec: RefspecItem, out: *std.ArrayList(*Ref), missing_ok: bool) void {
    if (spec.negative) return;
    var got: std.ArrayList(*Ref) = .empty;
    if (spec.pattern) {
        for (remote_refs) |r| {
            if (std.mem.indexOfScalar(u8, r.name, '^') != null) continue;
            const expn = matchRefnameWithPattern(spec.src.?, r.name, spec.dst) orelse continue;
            if (ignoreSymrefUpdate(expn)) continue;
            const cpy = copyRef(r);
            cpy.peer_ref = allocRef(expn);
            if (spec.force) cpy.peer_ref.?.force = true;
            got.append(gpa, cpy) catch util.oom();
        }
    } else {
        const name = if (spec.src.?.len > 0) spec.src.? else "HEAD";
        var m: ?*Ref = null;
        if (spec.exact_sha1) {
            m = allocRef(name);
            m.?.old_oid = hash.fromHex(name).?;
            m.?.exact_oid = true;
        } else if (findRefByNameAbbrev(remote_refs, name)) |f| {
            m = copyRef(f);
        }
        if (m == null and !missing_ok) util.die("couldn't find remote ref {s}", .{name});
        if (m) |mm| {
            mm.peer_ref = getLocalRef(spec.dst);
            if (mm.peer_ref != null and spec.force) mm.peer_ref.?.force = true;
            got.append(gpa, mm) catch util.oom();
        }
    }
    for (got.items) |r| {
        if (r.peer_ref) |p| {
            if (!util.startsWith(p.name, "refs/") or !refs.checkRefnameFormat(p.name, 0)) {
                util.err("* Ignoring funny ref '{s}' locally", .{p.name});
                continue;
            }
        }
        out.append(gpa, r) catch util.oom();
    }
}

// ---------------- transport ----------------

pub const Transport = struct {
    remote: *Remote,
    url: []const u8,
    path: []const u8 = "",
    uploadpack: ?[]const u8 = null,
    receivepack: ?[]const u8 = null,
    child: ?proc.Child = null,
    rd: *pkt.Reader = undefined,
    fd_out: c_int = -1,
    version: u32 = 0,
    caps_v0: []const u8 = "",
    caps_v2: std.ArrayList([]const u8) = .empty,
    got_remote_heads: bool = false,
    remote_refs: []*Ref = &.{},
    unborn_head_target: ?[]const u8 = null,
    for_push: bool = false,
    helper: ?[]const u8 = null,
    family: u8 = 0,
    hd: ?*th.Helper = null,
    /// bundle transport (bundle_vtable): the parsed header once read
    is_bundle: bool = false,
    bundle_header: ?*bundle.Header = null,
    /// set when the vtable fetch_refs reported an error (bundle transport)
    fetch_failed: bool = false,
    /// transport->bundles / got_remote_bundle_uri (bundle-uri.c)
    bundles: ?*@import("bundle_uri.zig").List = null,
    got_remote_bundle_uri: bool = false,
    stateless_rpc: bool = false,
    refetch: bool = false,
    check_self_contained: bool = false,
    self_contained_and_connected: bool = false,
    // options
    verbose: i32 = 0,
    quiet: bool = false,
    progress: bool = false,
    thin: bool = true,
    keep: bool = false,
    follow_tags: bool = false,
    server_options: []const []const u8 = &.{},
    cloning: bool = false,
    /// smart_options->negotiation_restrict_tips / negotiation_include_tips
    negotiation_restrict: ?[]const Oid = null,
    negotiation_include: []const Oid = &.{},
    /// smart_options->acked_commits (fetch --negotiate-only)
    acked_commits: ?*std.ArrayList(Oid) = null,
    deepen: bool = false,
    depth: i32 = 0,
    deepen_since: ?[]const u8 = null,
    deepen_not: []const []const u8 = &.{},
    deepen_relative: bool = false,
    update_shallow: bool = false,
    reject_shallow: bool = false,
    remote_shallow: std.ArrayList(Oid) = .empty,
    pack_lockfiles: std.ArrayList([]const u8) = .empty,

    pub fn serverSupportsV0(self: *const Transport, cap: []const u8) bool {
        return capValue(self.caps_v0, cap) != null;
    }

    pub fn serverSupportsV2(self: *const Transport, cap: []const u8) bool {
        for (self.caps_v2.items) |c| {
            if (util.eql(c, cap)) return true;
            if (util.startsWith(c, cap) and c.len > cap.len and c[cap.len] == '=') return true;
        }
        return false;
    }

    pub fn serverSupportsFeature(self: *const Transport, cmd: []const u8, feature: []const u8) bool {
        for (self.caps_v2.items) |c| {
            const rest = util.skipPrefix(c, cmd) orelse continue;
            if (rest.len == 0 or rest[0] != '=') continue;
            var it = std.mem.tokenizeScalar(u8, rest[1..], ' ');
            while (it.next()) |w| {
                if (util.eql(w, feature)) return true;
            }
        }
        return false;
    }
};

pub fn capValue(caps: []const u8, name: []const u8) ?[]const u8 {
    var it = std.mem.tokenizeScalar(u8, caps, ' ');
    while (it.next()) |w| {
        if (util.eql(w, name)) return "";
        if (util.startsWith(w, name) and w.len > name.len and w[name.len] == '=') return w[name.len + 1 ..];
    }
    return null;
}

pub const local_repo_env = [_][]const u8{
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CONFIG",         "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG_COUNT",                 "GIT_OBJECT_DIRECTORY", "GIT_DIR",
    "GIT_WORK_TREE",                    "GIT_IMPLICIT_WORK_TREE", "GIT_GRAFT_FILE",
    "GIT_INDEX_FILE",                   "GIT_NO_REPLACE_OBJECTS", "GIT_REPLACE_REF_BASE",
    "GIT_PREFIX",                       "GIT_SHALLOW_FILE",   "GIT_COMMON_DIR",
};

pub fn protocolVersionConfig() u32 {
    if (os.getenv("GIT_TEST_PROTOCOL_VERSION")) |v| {
        if (util.parseInt(u32, v)) |n| return n;
    }
    if (repo_mod.cfg.get("protocol.version")) |v| {
        if (util.parseInt(u32, v)) |n| {
            if (n <= 2) return n;
        }
        util.die("unknown value for config 'protocol.version': {s}", .{v});
    }
    return 2;
}

fn sqQuoted(s: []const u8) []const u8 {
    var b: util.Buf = .empty;
    util.sqQuote(&b, s);
    return b.items;
}

/// Spawn the remote service and read its advertisement.
pub fn transportGet(remote: *Remote, url_in: ?[]const u8) *Transport {
    const t = gpa.create(Transport) catch util.oom();
    const url = url_in orelse remote.urls.items[0];
    t.* = .{ .remote = remote, .url = url };
    t.progress = os.isatty(2);
    t.uploadpack = remote.uploadpack;
    t.receivepack = remote.receivepack;
    var p: usize = 0;
    while (p < url.len and conn.isUrlschemechar(p == 0, url[p])) p += 1;
    if (util.startsWith(url[p..], "::")) {
        t.helper = url[0..p];
        conn.checkAllowed(url[0..p]);
    } else if (util.startsWith(url, "rsync:")) {
        util.die("git-over-rsync is no longer supported", .{});
    } else if (conn.urlIsLocalNotSsh(url) and os.isFile(url) and bundle.isBundle(url, true)) {
        conn.checkAllowed("file");
        t.is_bundle = true;
    } else if (!conn.isUrl(url) or util.startsWith(url, "file://") or util.startsWith(url, "git://") or
        util.startsWith(url, "ssh://") or util.startsWith(url, "git+ssh://") or util.startsWith(url, "ssh+git://"))
    {
        // builtin smart transport; allow checks happen at connect time
        if (!conn.isUrl(url) and conn.urlIsLocalNotSsh(url)) t.path = url;
    } else {
        const colon = std.mem.indexOfScalar(u8, url, ':').?;
        t.helper = url[0..colon];
        conn.checkAllowed(url[0..colon]);
    }
    return t;
}

pub const Service = enum {
    upload_pack,
    receive_pack,
    upload_archive,

    pub fn cmd(s: Service) []const u8 {
        return switch (s) {
            .upload_pack => "git-upload-pack",
            .receive_pack => "git-receive-pack",
            .upload_archive => "git-upload-archive",
        };
    }
};

/// git_connect(): start the remote service; sets t.child / t.fd_out / t.rd.
pub fn openService(t: *Transport, service: Service, prog_in: ?[]const u8) void {
    const prog = prog_in orelse service.cmd();
    var version = protocolVersionConfig();
    if (version == 2 and service != .upload_pack) version = 0;
    var ch: proc.Child = undefined;
    if (t.helper != null) {
        ch = th.connectHelper(t, service, prog);
    } else {
        const pu = conn.parseConnectUrl(t.url);
        t.path = pu.path;
        var env: std.ArrayList([2][]const u8) = .empty;
        if (pu.scheme == .git) {
            const target = os.getenv("GIT_OVERRIDE_VIRTUAL_HOST") orelse pu.host;
            conn.checkAllowed("git");
            if (std.mem.indexOfScalar(u8, target, '\n') != null or std.mem.indexOfScalar(u8, pu.path, '\n') != null)
                util.die("newline is forbidden in git:// hosts and repo paths", .{});
            if (conn.proxyCommand(pu.host)) |proxy| {
                const hp = conn.getHostAndPort(pu.host);
                const port = hp.port orelse "9418";
                if (conn.looksLikeOption(hp.host)) util.die("strange hostname '{s}' blocked", .{hp.host});
                if (conn.looksLikeOption(port)) util.die("strange port '{s}' blocked", .{port});
                conn.checkRunnable(proxy);
                ch = proc.spawn(&.{ proxy, hp.host, port }, .{ .pipe_in = true, .pipe_out = true });
            } else {
                const sock = conn.tcpConnect(pu.host, t.family, t.verbose > 0);
                ch = .{ .pid = -1, .in = conn.dupFd(sock), .out = sock };
            }
            var req: util.Buf = .empty;
            util.bufAppend(&req, util.fmt("{s} {s}\x00host={s}\x00", .{ prog, pu.path, target }));
            if (version > 0) util.bufAppend(&req, util.fmt("\x00version={d}\x00", .{version}));
            pkt.write(ch.in, req.items);
        } else {
            if (conn.looksLikeOption(pu.path)) util.die("strange pathname '{s}' blocked", .{pu.path});
            const cmdline = util.concat(&.{ prog, " ", sqQuoted(pu.path) });
            if (pu.scheme == .ssh) {
                conn.checkAllowed("ssh");
                var hp = conn.getHostAndPort(pu.host);
                conn.getPort(&hp);
                const sc = conn.sshCommand(hp.host, hp.port, version, t.family, cmdline);
                env.appendSlice(gpa, sc.env) catch util.oom();
                conn.checkRunnable(sc.argv[0]);
                ch = proc.spawn(sc.argv, .{ .pipe_in = true, .pipe_out = true, .env = env.items, .unset_env = &local_repo_env });
            } else {
                conn.checkAllowed("file");
                if (version > 0) env.append(gpa, .{ "GIT_PROTOCOL", util.fmt("version={d}", .{version}) }) catch util.oom();
                var argv: std.ArrayList([]const u8) = .empty;
                if (util.eql(prog, service.cmd())) {
                    // same as running "git-<service> '<path>'" through the shell
                    argv.appendSlice(gpa, &.{ proc.gitBinary(), service.cmd()[4..], pu.path }) catch util.oom();
                } else {
                    argv.appendSlice(gpa, conn.prepareShellCmd(&.{cmdline})) catch util.oom();
                }
                ch = proc.spawn(argv.items, .{ .pipe_in = true, .pipe_out = true, .env = env.items, .unset_env = &local_repo_env });
            }
        }
    }
    setChild(t, ch);
}

fn setChild(t: *Transport, ch: proc.Child) void {
    t.child = ch;
    t.fd_out = ch.in;
    t.rd = gpa.create(pkt.Reader) catch util.oom();
    t.rd.* = pkt.Reader.init(ch.out);
    t.rd.gentle_eof = true;
}

/// Spawn the remote service and read its advertisement.
pub fn connect(t: *Transport, for_push: bool) void {
    if (t.child != null) return;
    if (t.hd != null and t.got_remote_heads) return;
    t.for_push = for_push;
    if (t.is_bundle) {
        // get_refs_from_bundle(): nothing to push to; refs listed in reverse
        if (t.got_remote_heads) return;
        t.version = 0;
        t.got_remote_heads = true;
        if (for_push) return;
        const h = bundleHeader(t);
        var list: std.ArrayList(*Ref) = .empty;
        var i = h.references.items.len;
        while (i > 0) {
            i -= 1;
            const e = h.references.items[i];
            const r = allocRef(e.name);
            r.old_oid = e.oid;
            list.append(gpa, r) catch util.oom();
        }
        t.remote_refs = list.items;
        return;
    }
    if (t.helper != null) {
        if (th.processConnect(t, for_push)) |ch| {
            setChild(t, ch);
        } else {
            if (!t.got_remote_heads) {
                t.remote_refs = th.getRefsListUsingList(t, for_push);
                t.got_remote_heads = true;
            }
            t.version = 0;
            return;
        }
    } else openService(t, if (for_push) .receive_pack else .upload_pack, if (for_push) t.receivepack else t.uploadpack);
    // discover version
    const st = t.rd.read();
    switch (st) {
        .eof => dieInitialContact(false),
        .normal => {
            if (util.eql(t.rd.line, "version 2")) {
                t.version = 2;
            } else if (util.eql(t.rd.line, "version 1")) {
                t.version = 1;
            } else {
                t.version = 0;
                t.rd.unread();
            }
        },
        else => {
            t.version = 0;
            t.rd.unread();
        },
    }
    if (t.version == 2) {
        while (true) {
            const s2 = t.rd.read();
            if (s2 == .eof) dieInitialContact(true);
            if (s2 != .normal) break;
            t.caps_v2.append(gpa, util.dupe(t.rd.line)) catch util.oom();
        }
    } else {
        t.remote_refs = getRemoteHeads(t);
        t.got_remote_heads = true;
    }
}

/// get_refs_from_bundle_inner(): (re)read the bundle header.
pub fn bundleHeader(t: *Transport) *bundle.Header {
    const h = gpa.create(bundle.Header) catch util.oom();
    h.* = .{};
    bundle.readBundleHeader(t.url, h) orelse util.die("could not read bundle '{s}'", .{t.url});
    t.bundle_header = h;
    return h;
}

pub fn dieInitialContact(unexpected: bool) noreturn {
    if (unexpected) util.die("the remote end hung up upon initial contact", .{});
    util.die("Could not read from remote repository.\n\nPlease make sure you have the correct access rights\nand the repository exists.", .{});
}

fn getRemoteHeads(t: *Transport) []*Ref {
    var list: std.ArrayList(*Ref) = .empty;
    var first = true;
    var symrefs: std.ArrayList([2][]const u8) = .empty;
    while (true) {
        const st = t.rd.read();
        switch (st) {
            .eof => dieInitialContact(true),
            .flush => break,
            .delim, .response_end => util.die("invalid packet", .{}),
            .normal => {},
        }
        var line: []const u8 = t.rd.line;
        if (first) {
            first = false;
            if (std.mem.indexOfScalar(u8, line, 0)) |nul| {
                t.caps_v0 = util.dupe(line[nul + 1 ..]);
                line = line[0..nul];
                var it = std.mem.tokenizeScalar(u8, t.caps_v0, ' ');
                while (it.next()) |w| {
                    if (util.skipPrefix(w, "symref=")) |sv| {
                        if (std.mem.indexOfScalar(u8, sv, ':')) |ci| {
                            symrefs.append(gpa, .{ sv[0..ci], sv[ci + 1 ..] }) catch util.oom();
                        }
                    }
                }
            }
            if (line.len > 41 and util.eql(line[41..], "capabilities^{}")) continue;
        }
        if (util.skipPrefix(line, "shallow ")) |sh| {
            const so = hash.fromHex(sh) orelse util.die("protocol error: expected shallow sha-1, got '{s}'", .{sh});
            t.remote_shallow.append(gpa, so) catch util.oom();
            continue;
        }
        if (line.len < 42 or line[40] != ' ') util.die("protocol error: unexpected '{s}'", .{line});
        const oid = hash.fromHex(line[0..40]) orelse util.die("protocol error: unexpected '{s}'", .{line});
        const name = line[41..];
        if (util.eql(name, ".have")) continue;
        if (t.for_push and std.mem.indexOf(u8, name, "^{}") != null) continue;
        const r = allocRef(name);
        r.old_oid = oid;
        list.append(gpa, r) catch util.oom();
    }
    for (symrefs.items) |sr| {
        if (findRefByName(list.items, sr[0])) |r| r.symref = util.dupe(sr[1]);
    }
    return list.items;
}

fn sendCapabilitiesV2(t: *Transport) void {
    if (t.serverSupportsV2("agent")) pkt.writeFmt(t.fd_out, "agent={s}", .{@import("cmd/uploadpack.zig").agentSanitized()});
    if (t.serverSupportsV2("object-format")) pkt.write(t.fd_out, "object-format=sha1");
}

pub fn sendCommandV2(t: *Transport, cmd: []const u8) void {
    pkt.writeFmt(t.fd_out, "command={s}\n", .{cmd});
    sendCapabilitiesV2(t);
    for (t.server_options) |o| pkt.writeFmt(t.fd_out, "server-option={s}", .{o});
    pkt.delim(t.fd_out);
}

/// transport_get_remote_bundle_uri(); 0 on success
pub fn getRemoteBundleUri(t: *Transport) i32 {
    const bu = @import("bundle_uri.zig");
    if (t.got_remote_bundle_uri) return 0;
    t.got_remote_bundle_uri = true;
    if (!(repo_mod.cfg.getBool("transfer.bundleuri") orelse false)) return 0;
    if (t.bundles == null) {
        const l = gpa.create(bu.List) catch util.oom();
        l.* = .{};
        t.bundles = l;
    }
    const list = t.bundles.?;
    if (list.base_uri == null) list.base_uri = util.dupe(t.url);
    if (t.is_bundle) {
        util.err("bundle-uri operation not supported by protocol", .{});
        return -1;
    }
    if (getBundleUriVia(t, list) < 0) {
        util.err("could not retrieve server-advertised bundle-uri list", .{});
        return -1;
    }
    return 0;
}

/// get_bundle_uri() + get_remote_bundle_uri()
fn getBundleUriVia(t: *Transport, list: *@import("bundle_uri.zig").List) i32 {
    if (t.child == null) {
        connect(t, false);
        if (t.child == null) return -1; // helper without connect
    }
    if (t.version != 2 or !t.serverSupportsV2("bundle-uri")) return 0;
    sendCapabilitiesV2(t);
    pkt.write(t.fd_out, "command=bundle-uri\n");
    pkt.delim(t.fd_out);
    pkt.flush(t.fd_out);
    var line_nr: usize = 1;
    var err: i32 = 0;
    while (t.rd.read() == .normal) {
        line_nr += 1;
        if (err != 0) continue;
        if (@import("bundle_uri.zig").parseLine(list, t.rd.line) == 0) continue;
        util.err("error on bundle-uri response line {d}: {s}", .{ line_nr, t.rd.line });
        err = -1;
    }
    if (t.rd.status != .flush) {
        util.err("expected flush after bundle-uri listing", .{});
        return -1;
    }
    th.checkStatelessDelimiter(t, "expected response end packet after ref listing");
    return err;
}

/// transport_get_remote_refs
pub fn getRemoteRefs(t: *Transport, prefixes: []const []const u8) []*Ref {
    if (t.child == null) connect(t, false);
    if (t.version != 2) return t.remote_refs;
    if (t.got_remote_heads) return t.remote_refs;
    if (!t.serverSupportsV2("ls-refs")) util.die("server doesn't support '{s}'", .{"ls-refs"});
    sendCommandV2(t, "ls-refs");
    if (!t.for_push) pkt.write(t.fd_out, "peel\n");
    pkt.write(t.fd_out, "symrefs\n");
    if (t.serverSupportsFeature("ls-refs", "unborn")) pkt.write(t.fd_out, "unborn\n");
    for (prefixes) |p| pkt.writeFmt(t.fd_out, "ref-prefix {s}\n", .{p});
    pkt.flush(t.fd_out);
    var list: std.ArrayList(*Ref) = .empty;
    while (t.rd.read() == .normal) {
        if (!processRefV2(t, t.rd.line, &list)) util.die("invalid ls-refs response: {s}", .{t.rd.line});
    }
    if (t.rd.status != .flush) util.die("expected flush after ref listing", .{});
    th.checkStatelessDelimiter(t, "expected response end packet after ref listing");
    t.remote_refs = list.items;
    t.got_remote_heads = true;
    return t.remote_refs;
}

fn processRefV2(t: *Transport, line: []const u8, list: *std.ArrayList(*Ref)) bool {
    var parts: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, line, ' ');
    while (it.next()) |p| parts.append(gpa, p) catch util.oom();
    if (parts.items.len < 2) return false;
    var i: usize = 0;
    if (util.eql(parts.items[0], "unborn")) {
        i = 1;
        if (util.eql(parts.items[i], "HEAD")) {
            i += 1;
            while (i < parts.items.len) : (i += 1) {
                if (util.skipPrefix(parts.items[i], "symref-target:")) |tg| {
                    if (refs.checkRefnameFormat(tg, 0)) {
                        t.unborn_head_target = util.dupe(tg);
                    } else util.warn("remote advertised invalid symref-target '{s}', ignoring", .{tg});
                    break;
                }
            }
        }
        return true;
    }
    const oid = hash.fromHex(parts.items[0]) orelse return false;
    if (parts.items[0].len != 40) return false;
    const name = parts.items[1];
    if (!refs.checkRefnameFormat(name, refs.ALLOW_ONELEVEL)) {
        util.warn("remote advertised invalid ref name '{s}', ignoring", .{name});
        return true;
    }
    const r = allocRef(name);
    r.old_oid = oid;
    list.append(gpa, r) catch util.oom();
    i = 2;
    while (i < parts.items.len) : (i += 1) {
        const arg = parts.items[i];
        if (util.skipPrefix(arg, "symref-target:")) |tg| {
            if (refs.checkRefnameFormat(tg, 0)) {
                r.symref = util.dupe(tg);
            } else util.warn("remote advertised invalid symref-target '{s}', ignoring", .{tg});
        }
        if (util.skipPrefix(arg, "peeled:")) |ph| {
            const po_ = hash.fromHex(ph) orelse return false;
            if (ph.len != 40) return false;
            const pr = allocRef(util.concat(&.{ name, "^{}" }));
            pr.old_oid = po_;
            list.append(gpa, pr) catch util.oom();
        }
    }
    return true;
}

/// transport_disconnect; returns nonzero if the child failed.
pub fn disconnect(t: *Transport) u8 {
    var ret: u8 = 0;
    if (t.hd != null) return if (th.disconnect(t) != 0) 1 else 0;
    if (t.child) |*ch| {
        if (t.fd_out >= 0) {
            if ((t.got_remote_heads or t.version == 2) and !t.stateless_rpc) {
                pkt.packetTrace("0000", true);
                os.writeAll(t.fd_out, "0000") catch {};
            }
            proc.closeFd(&t.fd_out);
        }
        proc.closeFd(&ch.out);
        const st: u8 = if (ch.pid > 0) proc.wait(ch.pid) else 0;
        if (st != 0) ret = 1;
        t.child = null;
    }
    return ret;
}

/// Close our side of the connection without writing a flush (used after a
/// complete fetch/push exchange).
pub fn finish(t: *Transport) u8 {
    var ret: u8 = 0;
    if (t.child) |*ch| {
        proc.closeFd(&t.fd_out);
        proc.closeFd(&ch.out);
        const st: u8 = if (ch.pid > 0) proc.wait(ch.pid) else 0;
        if (st != 0) ret = 1;
        t.child = null;
    }
    return ret;
}

/// transport_anonymize_url: for local paths it's unchanged (strip user:pass@ from URLs)
pub fn anonymizeUrl(url: []const u8) []const u8 {
    const scheme_end = std.mem.indexOf(u8, url, "://") orelse return url;
    const rest = url[scheme_end + 3 ..];
    const slash = std.mem.indexOfScalar(u8, rest, '/') orelse rest.len;
    const at = std.mem.lastIndexOfScalar(u8, rest[0..slash], '@') orelse return url;
    return util.concat(&.{ url[0 .. scheme_end + 3], rest[at + 1 ..] });
}

/// guess_remote_head; returns list of candidate refs (copies).
pub fn guessRemoteHead(head: ?*const Ref, list: []const *Ref, all: bool) []*Ref {
    var out: std.ArrayList(*Ref) = .empty;
    const h = head orelse return out.items;
    if (h.symref) |s| {
        if (findRefByName(list, s)) |r| out.append(gpa, copyRef(r)) catch util.oom();
        return out.items;
    }
    if (!all) {
        const db = @import("cmd/init.zig").defaultBranchName(true);
        if (findRefByName(list, util.concat(&.{ "refs/heads/", db }))) |r| {
            if (hash.eql(r.old_oid, h.old_oid)) {
                out.append(gpa, copyRef(r)) catch util.oom();
                return out.items;
            }
        }
        if (findRefByName(list, "refs/heads/master")) |r| {
            if (hash.eql(r.old_oid, h.old_oid)) {
                out.append(gpa, copyRef(r)) catch util.oom();
                return out.items;
            }
        }
    }
    for (list) |r| {
        if (r != h and util.startsWith(r.name, "refs/heads/") and hash.eql(r.old_oid, h.old_oid)) {
            out.append(gpa, copyRef(r)) catch util.oom();
            if (!all) break;
        }
    }
    return out.items;
}

/// get_stale_heads: local refs matched by refspec dst whose source isn't in fetch_map.
pub fn getStaleHeads(rs: *const Refspec, fetch_map: []const *Ref) []*Ref {
    var names = std.StringHashMap(void).init(gpa);
    for (fetch_map) |r| names.put(r.name, {}) catch util.oom();
    var out: std.ArrayList(*Ref) = .empty;
    for (refs.iterate("", .{ .include_broken = true, .check_objects = false })) |lr| {
        var matches: std.ArrayList([]const u8) = .empty;
        rs.findAllMatches(null, lr.name, &matches);
        if (matches.items.len == 0) continue;
        if (lr.flags & refs.REF_ISSYMREF != 0) continue;
        var stale = true;
        for (matches.items) |m| {
            if (names.contains(m)) {
                stale = false;
                break;
            }
        }
        if (stale) {
            const r = allocRef(lr.name);
            r.new_oid = lr.oid;
            out.append(gpa, r) catch util.oom();
        }
    }
    return out.items;
}

pub fn pushUrls(r: *const Remote) []const []const u8 {
    return if (r.pushurls.items.len > 0) r.pushurls.items else r.urls.items;
}

pub fn validRemoteName(name: []const u8) bool {
    if (name.len == 0) return false;
    // valid_remote_name: check_refname_format("refs/remotes/<name>/test")
    return refs.checkRefnameFormat(util.concat(&.{ "refs/remotes/", name, "/test" }), 0);
}

// ---------------- push ref matching (remote.c) ----------------

pub const MATCH_REFS_ALL: u32 = 1;
pub const MATCH_REFS_MIRROR: u32 = 2;
pub const MATCH_REFS_PRUNE: u32 = 4;
pub const MATCH_REFS_FOLLOW_TAGS: u32 = 8;

/// get_local_heads
pub fn getLocalHeads() []*Ref {
    var out: std.ArrayList(*Ref) = .empty;
    for (refs.iterate("refs/", .{ .check_objects = false })) |lr| {
        if (!refs.checkRefnameFormat(lr.name[5..], 0)) continue;
        const r = allocRef(lr.name);
        r.new_oid = lr.oid;
        out.append(gpa, r) catch util.oom();
    }
    return out.items;
}

pub fn countRefspecMatch(pattern: []const u8, list: []const *Ref, matched: *?*Ref) usize {
    const patlen = pattern.len;
    var matched_weak: ?*Ref = null;
    var m: ?*Ref = null;
    var weak: usize = 0;
    var strong: usize = 0;
    for (list) |r| {
        if (refnameMatch(pattern, r.name) == 0) continue;
        const namelen = r.name.len;
        if (namelen != patlen and patlen + 5 != namelen and !util.startsWith(r.name, "refs/heads/") and !util.startsWith(r.name, "refs/tags/")) {
            matched_weak = r;
            weak += 1;
        } else {
            m = r;
            strong += 1;
        }
    }
    if (m == null) {
        matched.* = matched_weak;
        return weak;
    }
    matched.* = m;
    return strong;
}

fn tryExplicitObjectName(name: []const u8) ?*Ref {
    if (name.len == 0) return allocRef("(delete)");
    const oid = @import("revparse.zig").getOid(name) orelse return null;
    const r = allocRef(name);
    r.new_oid = oid;
    return r;
}

fn matchExplicitLhs(src: []const *Ref, rs: RefspecItem, match: ?*?*Ref) bool {
    var m: ?*Ref = null;
    switch (countRefspecMatch(rs.src.?, src, &m)) {
        1 => {
            if (match) |p| p.* = m;
            return true;
        },
        0 => {
            const r = tryExplicitObjectName(rs.src.?) orelse {
                util.err("src refspec {s} does not match any", .{rs.src.?});
                return false;
            };
            if (match) |p| p.* = r;
            return true;
        },
        else => {
            util.err("src refspec {s} matches more than one", .{rs.src.?});
            return false;
        },
    }
}

pub fn checkPushRefs(src: []const *Ref, rs: *const Refspec) bool {
    var ok = true;
    for (rs.items.items) |it| {
        if (it.pattern or it.matching or it.negative) continue;
        if (!matchExplicitLhs(src, it, null)) ok = false;
    }
    return ok;
}

fn guessRef(name: []const u8, peer: *const Ref) ?[]const u8 {
    const r = refs.resolve(peer.name) orelse return null;
    if (util.startsWith(r.name, "refs/heads/")) return util.concat(&.{ "refs/heads/", name });
    if (util.startsWith(r.name, "refs/tags/")) return util.concat(&.{ "refs/tags/", name });
    return null;
}

fn showPushUnqualifiedError(dst_value: []const u8, src_name: []const u8) void {
    util.err("The destination you provided is not a full refname (i.e.,\n" ++
        "starting with \"refs/\"). We tried to guess what you meant by:\n" ++
        "\n" ++
        "- Looking for a ref that matches '{s}' on the remote side.\n" ++
        "- Checking if the <src> being pushed ('{s}')\n" ++
        "  is a ref in \"refs/{{heads,tags}}/\". If so we add a corresponding\n" ++
        "  refs/{{heads,tags}}/ prefix on the remote side.\n" ++
        "\n" ++
        "Neither worked, so we gave up. You must fully qualify the ref.", .{ dst_value, src_name });
    const advice = @import("advice.zig");
    const oid = @import("revparse.zig").getOid(src_name) orelse return;
    const typ = @import("objects.zig").typeOf(oid);
    const msg = if (typ) |t| switch (t) {
        .commit => util.fmt("The <src> part of the refspec is a commit object.\nDid you mean to create a new branch by pushing to\n'{s}:refs/heads/{s}'?", .{ src_name, dst_value }),
        .tag => util.fmt("The <src> part of the refspec is a tag object.\nDid you mean to create a new tag by pushing to\n'{s}:refs/tags/{s}'?", .{ src_name, dst_value }),
        .tree => util.fmt("The <src> part of the refspec is a tree object.\nDid you mean to tag a new tree by pushing to\n'{s}:refs/tags/{s}'?", .{ src_name, dst_value }),
        .blob => util.fmt("The <src> part of the refspec is a blob object.\nDid you mean to tag a new blob by pushing to\n'{s}:refs/tags/{s}'?", .{ src_name, dst_value }),
        else => util.fmt("The <src> part of the refspec ('{s}') is an object ID that doesn't exist.\n", .{src_name}),
    } else util.fmt("The <src> part of the refspec ('{s}') is an object ID that doesn't exist.\n", .{src_name});
    advice.adviseIfEnabled("pushUnqualifiedRefName", msg);
}

fn matchExplicit(src: []const *Ref, dst: *std.ArrayList(*Ref), rs: RefspecItem) bool {
    if (rs.pattern or rs.matching or rs.negative) return true;
    var msrc: ?*Ref = null;
    if (!matchExplicitLhs(src, rs, &msrc)) return false;
    const matched_src = msrc.?;
    var dst_value: []const u8 = undefined;
    if (rs.dst) |d| {
        dst_value = d;
    } else {
        const res = refs.resolve(matched_src.name);
        if (res == null or (res.?.symbolic and !util.startsWith(res.?.name, "refs/heads/")))
            util.die("{s} cannot be resolved to branch", .{matched_src.name});
        dst_value = res.?.name;
    }
    var mdst: ?*Ref = null;
    switch (countRefspecMatch(dst_value, dst.items, &mdst)) {
        1 => {},
        0 => {
            if (util.startsWith(dst_value, "refs/")) {
                mdst = allocRef(dst_value);
                dst.append(gpa, mdst.?) catch util.oom();
            } else if (hash.isZero(matched_src.new_oid)) {
                util.err("unable to delete '{s}': remote ref does not exist", .{dst_value});
            } else if (guessRef(dst_value, matched_src)) |g| {
                mdst = allocRef(g);
                dst.append(gpa, mdst.?) catch util.oom();
            } else showPushUnqualifiedError(dst_value, matched_src.name);
        },
        else => {
            mdst = null;
            util.err("dst refspec {s} matches more than one", .{dst_value});
        },
    }
    const md = mdst orelse return false;
    if (md.peer_ref != null) {
        util.err("dst ref {s} receives from more than one src", .{md.name});
        return false;
    }
    md.peer_ref = copyRef(matched_src);
    md.force = rs.force;
    return true;
}

const Direction = enum { from_src, from_dst };

fn getRefMatch(rs: *const Refspec, ref: *const Ref, send_mirror: bool, dir: Direction, ret_pat: ?*?RefspecItem) ?[]const u8 {
    var matching: ?usize = null;
    var name: ?[]const u8 = null;
    for (rs.items.items, 0..) |item, i| {
        if (item.negative) continue;
        if (item.matching and (matching == null or item.force)) {
            matching = i;
            continue;
        }
        if (item.pattern) {
            const dst_side = item.dst orelse item.src.?;
            const m = if (dir == .from_src)
                matchRefnameWithPattern(item.src.?, ref.name, dst_side)
            else
                matchRefnameWithPattern(dst_side, ref.name, item.src.?);
            if (m) |mm| {
                name = mm;
                matching = i;
                break;
            }
        }
    }
    const mi = matching orelse return null;
    const pat = rs.items.items[mi];
    if (pat.matching) {
        if (!send_mirror and !util.startsWith(ref.name, "refs/heads/")) return null;
        name = ref.name;
    }
    if (ret_pat) |p| p.* = pat;
    return name;
}

fn addMissingTags(src: []const *Ref, dst: *std.ArrayList(*Ref)) void {
    const cr = @import("commitreach.zig");
    const objects = @import("objects.zig");
    var tips: std.ArrayList(Oid) = .empty;
    var dst_tags = std.StringHashMap(void).init(gpa);
    for (dst.items) |r| {
        const o = if (r.peer_ref != null and !hash.isZero(r.peer_ref.?.new_oid)) r.peer_ref.?.new_oid else r.old_oid;
        if (!hash.isZero(o)) {
            if (objects.peelTo(o, .commit)) |c| tips.append(gpa, c) catch util.oom();
        }
        if (util.startsWith(r.name, "refs/tags/")) dst_tags.put(r.name, {}) catch util.oom();
    }
    if (tips.items.len == 0) return;
    for (src) |r| {
        if (!util.startsWith(r.name, "refs/tags/")) continue;
        if (dst_tags.contains(r.name)) continue;
        if (objects.typeOf(r.new_oid) != .tag) continue;
        const c = objects.peelTo(r.new_oid, .commit) orelse continue;
        var reach = false;
        for (tips.items) |t| {
            if (hash.eql(t, c) or cr.refNewer(t, c)) {
                reach = true;
                break;
            }
        }
        if (!reach) continue;
        const d = allocRef(r.name);
        d.new_oid = r.new_oid;
        d.peer_ref = copyRef(r);
        dst.append(gpa, d) catch util.oom();
    }
}

/// match_push_refs; returns false on errors.
pub fn matchPushRefs(src: []const *Ref, dst: *std.ArrayList(*Ref), rs: *Refspec, flags: u32) bool {
    const send_all = flags & MATCH_REFS_ALL != 0;
    const send_mirror = flags & MATCH_REFS_MIRROR != 0;
    if (rs.items.items.len == 0) rs.append(":");
    var errs = false;
    for (rs.items.items) |it| {
        if (!matchExplicit(src, dst, it)) errs = true;
    }
    for (src) |r| {
        var pat: ?RefspecItem = null;
        const dst_name = getRefMatch(rs, r, send_mirror, .from_src, &pat) orelse continue;
        var dst_peer = findRefByName(dst.items, dst_name);
        if (dst_peer) |dp| {
            if (dp.peer_ref != null) continue;
        } else {
            if (pat.?.matching and !(send_all or send_mirror)) continue;
            const np = allocRef(dst_name);
            np.new_oid = r.new_oid;
            dst.append(gpa, np) catch util.oom();
            dst_peer = np;
        }
        dst_peer.?.peer_ref = copyRef(r);
        dst_peer.?.force = pat.?.force;
    }
    if (flags & MATCH_REFS_FOLLOW_TAGS != 0) addMissingTags(src, dst);
    if (flags & MATCH_REFS_PRUNE != 0) {
        for (dst.items) |r| {
            if (r.peer_ref != null) continue;
            const src_name = getRefMatch(rs, r, send_mirror, .from_dst, null) orelse continue;
            if (findRefByName(src, src_name) == null) r.peer_ref = allocRef("(delete)");
        }
    }
    // apply_negative_refspecs
    var w: usize = 0;
    for (dst.items) |r| {
        if (rs.matchesNegative(r.name)) continue;
        dst.items[w] = r;
        w += 1;
    }
    dst.items.len = w;
    return !errs;
}

/// set_ref_status_for_push
pub fn setRefStatusForPush(list: []const *Ref, send_mirror: bool, force_update: bool) void {
    const cr = @import("commitreach.zig");
    const objects = @import("objects.zig");
    const odbm = repo_mod.repo().odb();
    for (list) |r| {
        var force_ref_update = r.force or force_update;
        var reject: PushStatus = .none;
        if (r.peer_ref) |p| {
            r.new_oid = p.new_oid;
        } else if (!send_mirror) continue;
        r.deletion = hash.isZero(r.new_oid);
        if (!r.deletion and hash.eql(r.old_oid, r.new_oid)) {
            r.status = .uptodate;
            continue;
        }
        if (r.expect_old_sha1) {
            if (!hash.eql(r.old_oid, r.old_oid_expect)) {
                reject = .reject_stale;
            } else force_ref_update = true;
        }
        if (reject == .none and !r.deletion and !hash.isZero(r.old_oid)) {
            if (util.startsWith(r.name, "refs/tags/")) {
                reject = .reject_already_exists;
            } else if (!odbm.has(r.old_oid)) {
                reject = .reject_fetch_first;
            } else if (objects.peelTo(r.old_oid, .commit) == null or objects.peelTo(r.new_oid, .commit) == null) {
                reject = .reject_needs_force;
            } else if (!cr.refNewer(r.new_oid, r.old_oid)) {
                reject = .reject_nonfastforward;
            }
        }
        if (!force_ref_update) {
            r.status = reject;
        } else if (reject != .none) {
            r.forced_update = true;
        }
    }
}
