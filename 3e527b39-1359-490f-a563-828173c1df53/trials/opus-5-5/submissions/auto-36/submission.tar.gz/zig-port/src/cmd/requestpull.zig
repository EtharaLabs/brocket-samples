//! git request-pull (port of git-request-pull.sh)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const proc = @import("../proc.zig");
const gpa = util.gpa;

const usage = [_][]const u8{"git request-pull [options] start url [end]"};

const child_env = [_][2][]const u8{.{ "GIT_PAGER", "" }};

fn gitArgv(args: []const []const u8) []const []const u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return argv.items;
}

/// $(git ...): stdout with trailing newlines stripped.
fn capture(args: []const []const u8, quiet_err: bool) struct { out: []const u8, ok: bool } {
    const r = os.run(gitArgv(args), .{ .capture_stdout = true, .no_stderr = quiet_err, .env = &child_env });
    var s: []const u8 = r.stdout;
    while (s.len > 0 and s[s.len - 1] == '\n') s = s[0 .. s.len - 1];
    return .{ .out = s, .ok = r.status == 0 };
}

fn runGit(args: []const []const u8) bool {
    const r = os.run(gitArgv(args), .{ .env = &child_env });
    return r.status == 0;
}

fn shDie(comptime f: []const u8, a: anytype) noreturn {
    util.flushStdout();
    util.eprint(f ++ "\n", a);
    os.exit(1);
}

fn shUsage(opts: []const po.Opt) noreturn {
    po.printUsage(&usage, opts, false);
    util.flushStdout();
    os.exit(1);
}

fn ifsFields(line: []const u8) struct { a: []const u8, b: []const u8 } {
    const ws = " \t\n";
    const t = std.mem.trim(u8, line, ws);
    const i = std.mem.indexOfAny(u8, t, ws) orelse return .{ .a = t, .b = "" };
    return .{ .a = t[0..i], .b = std.mem.trim(u8, t[i..], ws) };
}

pub fn cmdRequestPull(args: []const []const u8) u8 {
    var patch = false;
    const options = [_]po.Opt{
        po.boolean('p', "", &patch, "show patch text as well"),
    };
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len < 2 or rest[0].len == 0 or rest[1].len == 0) shUsage(&options);
    const base = rest[0];
    var url = rest[1];
    const end: []const u8 = if (rest.len > 2) rest[2] else "";
    var status: u8 = 0;

    const baserev = capture(&.{ "rev-parse", "--verify", "--quiet", util.concat(&.{ base, "^0" }) }, false).out;
    if (baserev.len == 0) shDie("fatal: Not a valid revision: {s}", .{base});

    var local: []const u8 = if (std.mem.lastIndexOfScalar(u8, end, ':')) |i| end[0..i] else end;
    if (local.len == 0) local = "HEAD";
    const remote: []const u8 = if (std.mem.indexOfScalar(u8, end, ':')) |i| end[i + 1 ..] else end;
    var pretty_remote = remote;
    if (util.startsWith(pretty_remote, "refs/")) pretty_remote = pretty_remote[5..];
    if (util.startsWith(pretty_remote, "heads/")) pretty_remote = pretty_remote[6..];

    var head = capture(&.{ "symbolic-ref", "-q", local }, false).out;
    if (head.len == 0) {
        const sr = capture(&.{ "show-ref", "--heads", "--tags", local }, false).out;
        var buf: util.Buf = .empty;
        var it = std.mem.splitScalar(u8, sr, '\n');
        var first = true;
        while (it.next()) |line| {
            if (!first) util.bufByte(&buf, '\n');
            first = false;
            var f = std.mem.splitScalar(u8, line, ' ');
            _ = f.next();
            buf.appendSlice(gpa, f.next() orelse "") catch util.oom();
        }
        var s: []const u8 = buf.items;
        while (s.len > 0 and s[s.len - 1] == '\n') s = s[0 .. s.len - 1];
        head = s;
    }
    if (head.len == 0) head = capture(&.{ "rev-parse", "--quiet", "--verify", local }, false).out;
    if (head.len == 0) shDie("fatal: Not a valid revision: {s}", .{local});

    const headrev = capture(&.{ "rev-parse", "--verify", "--quiet", util.concat(&.{ head, "^0" }) }, false).out;
    if (headrev.len == 0) shDie("fatal: Ambiguous revision: {s}", .{local});
    const local_sha1 = capture(&.{ "rev-parse", "--verify", "--quiet", head }, false).out;

    var branch_name: []const u8 = if (util.startsWith(head, "refs/heads/")) head[11..] else head;
    if (branch_name.len == 0 or os.run(gitArgv(&.{ "config", util.concat(&.{ "branch.", branch_name, ".description" }) }), .{ .capture_stdout = true, .env = &child_env }).status != 0)
        branch_name = "";

    const mb = capture(&.{ "merge-base", baserev, headrev }, false);
    if (!mb.ok) shDie("fatal: No commits in common between {s} and {s}", .{ base, head });
    const merge_base = mb.out;

    // find_matching_ref over `git ls-remote $url`
    const want = if (remote.len > 0) remote else "HEAD";
    const ls = os.run(gitArgv(&.{ "ls-remote", url }), .{ .capture_stdout = true, .env = &child_env }).stdout;
    var remote_sha1: []const u8 = "";
    var ref: []const u8 = "";
    {
        var rsha: []const u8 = "";
        var it = std.mem.splitScalar(u8, ls, '\n');
        while (it.next()) |line| {
            if (line.len == 0 and it.index == null) break;
            const fl = ifsFields(line);
            const sha1 = fl.a;
            var r = fl.b;
            var deref = false;
            // case "*^?*": a caret followed by at least one character
            if (std.mem.indexOfScalar(u8, r, '^')) |ci| {
                if (ci + 1 < r.len) {
                    r = r[0..std.mem.lastIndexOfScalar(u8, r, '^').?];
                    deref = true;
                }
            }
            if (util.eql(sha1, want)) {
                remote_sha1 = sha1;
                ref = sha1;
                break;
            }
            if (util.eql(r, want) or (r.len > want.len and util.endsWith(r, want) and r[r.len - want.len - 1] == '/')) {
                if (!deref) rsha = sha1;
                if (util.eql(sha1, headrev)) {
                    remote_sha1 = if (rsha.len > 0) rsha else headrev;
                    ref = r;
                    break;
                }
            }
        }
    }

    if (ref.len == 0) {
        util.flushStdout();
        util.eprint("warn: No match for commit {s} found at {s}\n", .{ headrev, url });
        util.eprint("warn: Are you sure you pushed '{s}' there?\n", .{want});
        status = 1;
    } else if (!util.eql(local_sha1, remote_sha1)) {
        util.flushStdout();
        util.eprint("warn: {s} found at {s} but points to a different object\n", .{ head, url });
        util.eprint("warn: Are you sure you pushed '{s}' there?\n", .{want});
        status = 1;
    }

    if (util.eql(ref, util.concat(&.{ "refs/tags/", pretty_remote })))
        pretty_remote = util.concat(&.{ "tags/", pretty_remote });

    url = capture(&.{ "ls-remote", "--get-url", url }, false).out;

    chain: {
        if (!runGit(&.{ "show", "-s", "--format=The following changes since commit %H:\n\n  %s (%ci)\n\nare available in the Git repository at:\n", merge_base })) break :chain;
        util.outf("  {s} {s}\n", .{ url, pretty_remote });
        util.flushStdout();
        if (!runGit(&.{ "show", "-s", "--format=\nfor you to fetch changes up to %H:\n\n  %s (%ci)\n\n----------------------------------------------------------------", headrev })) break :chain;

        const ty = capture(&.{ "cat-file", "-t", head }, false).out;
        if (util.eql(ty, "tag")) {
            // sed -n -e '1,/^$/d' -e '/^-----BEGIN \(PGP\|SSH\|SIGNED\) /q' -e p
            const r = os.run(gitArgv(&.{ "cat-file", "tag", head }), .{ .capture_stdout = true, .env = &child_env });
            var it = std.mem.splitScalar(u8, r.stdout, '\n');
            var lineno: usize = 0;
            var in_header = true;
            while (it.next()) |line| {
                if (it.index == null and line.len == 0) break;
                lineno += 1;
                if (in_header) {
                    if (lineno > 1 and line.len == 0) in_header = false;
                    continue;
                }
                if (util.startsWith(line, "-----BEGIN PGP ") or util.startsWith(line, "-----BEGIN SSH ") or util.startsWith(line, "-----BEGIN SIGNED ")) break;
                util.outf("{s}\n", .{line});
            }
            util.out("\n----------------------------------------------------------------\n");
            util.flushStdout();
        }

        if (branch_name.len > 0) {
            util.outf("(from the branch description for {s} local branch)\n\n", .{branch_name});
            util.flushStdout();
            _ = runGit(&.{ "config", util.concat(&.{ "branch.", branch_name, ".description" }) });
            util.out("----------------------------------------------------------------\n");
            util.flushStdout();
        }

        if (!runGit(&.{ "shortlog", util.concat(&.{ "^", baserev }), headrev })) break :chain;
        const range = util.concat(&.{ merge_base, "..", headrev });
        const ok = if (patch)
            runGit(&.{ "diff", "-M", "--stat", "--summary", "-p", range })
        else
            runGit(&.{ "diff", "-M", "--stat", "--summary", range });
        if (!ok) break :chain;
        return status;
    }
    return 1;
}
