//! Port of worktree.c: enumerating, validating and repairing linked worktrees.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const refs = @import("refs.zig");
const hash = @import("hash.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

pub const Worktree = struct {
    path: []const u8,
    id: ?[]const u8 = null,
    head_ref: ?[]const u8 = null,
    head_oid: Oid = hash.zero,
    is_detached: bool = false,
    is_bare: bool = false,
    is_current: bool = false,
    lock_reason: ?[]const u8 = null,
    lock_reason_valid: bool = false,
    prune_reason: ?[]const u8 = null,
    prune_reason_valid: bool = false,

    pub fn isMain(self: *const Worktree) bool {
        return self.id == null;
    }

    /// get_worktree_git_dir()
    pub fn gitDir(self: *const Worktree) []const u8 {
        const r = repo_mod.repo();
        if (self.id) |id| return util.concat(&.{ r.common_dir, "/worktrees/", id });
        return r.common_dir;
    }

    pub fn gitPath(self: *const Worktree, name: []const u8) []const u8 {
        return util.concat(&.{ self.gitDir(), "/", name });
    }
};

// ---------------- path helpers ----------------

pub fn isAbs(p: []const u8) bool {
    return p.len > 0 and p[0] == '/';
}

pub fn absolutePath(p: []const u8) []const u8 {
    if (isAbs(p)) return util.normalizePath(p) orelse p;
    return util.normalizePath(util.joinPath(os.getcwd(), p)) orelse p;
}

fn stripSlash(p: []const u8) []const u8 {
    var s = p;
    while (s.len > 1 and s[s.len - 1] == '/') s = s[0 .. s.len - 1];
    return s;
}

/// strbuf_realpath(.., die_on_error=0): the last component may be missing.
pub fn realPathLastMissing(p0: []const u8) ?[]const u8 {
    const p = stripSlash(p0);
    if (os.realPath(p)) |r| return r;
    if (os.errno() != os.ENOENT) return null;
    const abs = absolutePath(p);
    const dir = util.dirname(abs);
    const base = util.basename(abs);
    const rd = os.realPath(if (dir.len == 0) "/" else dir) orelse return null;
    if (base.len == 0) return rd;
    if (util.eql(rd, "/")) return util.concat(&.{ "/", base });
    return util.concat(&.{ rd, "/", base });
}

/// strbuf_realpath_forgiving(): resolve as much as exists, keep the rest.
pub fn realPathForgiving(p0: []const u8) []const u8 {
    const abs = absolutePath(stripSlash(p0));
    if (os.realPath(abs)) |r| return r;
    var head: []const u8 = abs;
    var tail: []const u8 = "";
    while (true) {
        const d = util.dirname(head);
        const b = util.basename(head);
        tail = if (tail.len == 0) b else util.concat(&.{ b, "/", tail });
        if (d.len == 0) return util.concat(&.{ "/", tail });
        if (os.realPath(d)) |rd| {
            if (util.eql(rd, "/")) return util.concat(&.{ "/", tail });
            return util.concat(&.{ rd, "/", tail });
        }
        head = d;
    }
}

fn realOrAbs(p: []const u8) []const u8 {
    return os.realPath(p) orelse absolutePath(p);
}

fn stripSuffix(s: []const u8, suf: []const u8) []const u8 {
    if (util.endsWith(s, suf)) return s[0 .. s.len - suf.len];
    return s;
}

/// relative_path() from path.c (both paths absolute and normalized).
pub fn relativePath(in: []const u8, prefix: []const u8) []const u8 {
    var a: std.ArrayList([]const u8) = .empty;
    var b: std.ArrayList([]const u8) = .empty;
    var it = std.mem.tokenizeScalar(u8, in, '/');
    while (it.next()) |p| a.append(gpa, p) catch util.oom();
    var it2 = std.mem.tokenizeScalar(u8, prefix, '/');
    while (it2.next()) |p| b.append(gpa, p) catch util.oom();
    var common: usize = 0;
    while (common < a.items.len and common < b.items.len and util.eql(a.items[common], b.items[common])) common += 1;
    var out: util.Buf = .empty;
    var k = common;
    while (k < b.items.len) : (k += 1) util.bufAppend(&out, "../");
    for (a.items[common..], 0..) |p, i| {
        if (i > 0) util.bufByte(&out, '/');
        util.bufAppend(&out, p);
    }
    if (out.items.len == 0) return "./";
    return out.items;
}

// ---------------- enumeration ----------------

fn addHeadInfo(wt: *Worktree) void {
    const gd = wt.gitDir();
    const data = refs.headContentsAt(gd) orelse return;
    const t = util.trimRight(data);
    if (util.skipPrefix(t, "ref:")) |rest0| {
        const rest = util.trim(rest0);
        wt.head_ref = util.dupe(rest);
        if (refs.resolve(rest)) |res| wt.head_oid = res.oid;
    } else if (hash.fromHex(t)) |o| {
        wt.head_oid = o;
        wt.is_detached = true;
    }
}

fn isCurrent(wt: *const Worktree) bool {
    const r = repo_mod.repo();
    return util.eql(absolutePath(r.git_dir), absolutePath(wt.gitDir()));
}

fn mainWorktreeBareFromConfigWorktree() bool {
    const r = repo_mod.repo();
    var c: config.Config = .{};
    _ = config.readFileInto(&c, util.concat(&.{ r.common_dir, "/config.worktree" }), .worktree);
    return c.getBool("core.bare") orelse false;
}

pub fn getMain(skip_head: bool) *Worktree {
    const r = repo_mod.repo();
    const wt = gpa.create(Worktree) catch util.oom();
    const p = stripSuffix(realOrAbs(r.common_dir), "/.git");
    wt.* = .{ .path = p };
    wt.is_current = isCurrent(wt);
    const bare_cfg = repo_mod.cfg.getBool("core.bare") orelse false;
    wt.is_bare = bare_cfg or (wt.is_current and r.work_tree == null) or
        (!wt.is_current and mainWorktreeBareFromConfigWorktree());
    if (!skip_head) addHeadInfo(wt);
    return wt;
}

pub fn getLinked(id: []const u8, skip_head: bool) ?*Worktree {
    const r = repo_mod.repo();
    const gf = util.concat(&.{ r.common_dir, "/worktrees/", id, "/gitdir" });
    const data = os.readFile(gf) orelse return null;
    if (data.len == 0) return null;
    var p: []const u8 = util.trimRight(data);
    p = stripSuffix(p, "/.git");
    if (!isAbs(p)) {
        p = realPathForgiving(util.concat(&.{ r.common_dir, "/worktrees/", id, "/", p }));
    }
    const wt = gpa.create(Worktree) catch util.oom();
    wt.* = .{ .path = util.dupe(p), .id = util.dupe(id) };
    wt.is_current = isCurrent(wt);
    if (!skip_head) addHeadInfo(wt);
    return wt;
}

fn getInternal(skip_head: bool) []*Worktree {
    var l: std.ArrayList(*Worktree) = .empty;
    l.append(gpa, getMain(skip_head)) catch util.oom();
    const r = repo_mod.repo();
    if (os.listDir(util.concat(&.{ r.common_dir, "/worktrees" }))) |ents| {
        // readdir order is unspecified; keep it as is (git does too)
        for (ents) |e| {
            if (getLinked(e.name, skip_head)) |wt| l.append(gpa, wt) catch util.oom();
        }
    }
    return l.items;
}

pub fn getAll() []*Worktree {
    return getInternal(false);
}

pub fn getAllWithoutHead() []*Worktree {
    return getInternal(true);
}

pub fn findBySuffix(list: []*Worktree, suffix: []const u8) ?*Worktree {
    if (suffix.len == 0) return null;
    var found: ?*Worktree = null;
    var nr: usize = 0;
    for (list) |wt| {
        if (nr >= 2) break;
        const p = wt.path;
        if (p.len < suffix.len) continue;
        const start = p.len - suffix.len;
        if ((start == 0 or p[start - 1] == '/') and util.eql(suffix, p[start..])) {
            found = wt;
            nr += 1;
        }
    }
    return if (nr == 1) found else null;
}

pub fn findByPath(list: []*Worktree, p: []const u8) ?*Worktree {
    const path = realPathLastMissing(p) orelse return null;
    for (list) |wt| {
        const wp = realPathLastMissing(wt.path) orelse continue;
        if (util.eql(path, wp)) return wt;
    }
    return null;
}

pub fn prefixFilename(prefix: []const u8, arg: []const u8) []const u8 {
    if (isAbs(arg) or prefix.len == 0) return arg;
    return util.concat(&.{ prefix, arg });
}

pub fn find(list: []*Worktree, prefix: []const u8, arg: []const u8) ?*Worktree {
    if (findBySuffix(list, arg)) |wt| return wt;
    return findByPath(list, prefixFilename(prefix, arg));
}

pub fn lockReason(wt: *Worktree) ?[]const u8 {
    if (wt.isMain()) return null;
    if (!wt.lock_reason_valid) {
        const p = wt.gitPath("locked");
        if (os.exists(p)) {
            const d = os.readFile(p) orelse util.dieErrno("failed to read '{s}'", .{p});
            wt.lock_reason = util.trim(d);
        } else wt.lock_reason = null;
        wt.lock_reason_valid = true;
    }
    return wt.lock_reason;
}

/// should_prune_worktree(): returns reason when it should be pruned; sets wtpath.
pub fn shouldPrune(id: []const u8, wtpath: *?[]const u8, expire: i64) ?[]const u8 {
    wtpath.* = null;
    const r = repo_mod.repo();
    const repo_path = realPathLastMissing(util.concat(&.{ r.common_dir, "/worktrees/", id })) orelse
        util.concat(&.{ r.common_dir, "/worktrees/", id });
    if (!os.isDir(repo_path)) return "not a valid directory";
    if (os.exists(util.concat(&.{ repo_path, "/locked" }))) return null;
    const gitdir = util.concat(&.{ repo_path, "/gitdir" });
    if (os.statPath(gitdir) == null) return "gitdir file does not exist";
    const data = os.readFile(gitdir) orelse return util.fmt("unable to read gitdir file ({s})", .{os.lastErr()});
    var len = data.len;
    while (len > 0 and (data[len - 1] == '\n' or data[len - 1] == '\r')) len -= 1;
    if (len == 0) return "invalid gitdir file";
    const path = data[0..len];
    const dotgit = if (isAbs(path)) path else realPathForgiving(util.concat(&.{ repo_path, "/", path }));
    if (!os.exists(dotgit)) {
        const st = os.statPath(util.concat(&.{ repo_path, "/index" }));
        if (st == null or st.?.mtime <= expire) return "gitdir file points to non-existent location";
    }
    wtpath.* = dotgit;
    return null;
}

pub fn pruneReason(wt: *Worktree, expire: i64) ?[]const u8 {
    if (wt.isMain()) return null;
    if (wt.prune_reason_valid) return wt.prune_reason;
    var p: ?[]const u8 = null;
    wt.prune_reason = shouldPrune(wt.id.?, &p, expire);
    wt.prune_reason_valid = true;
    return wt.prune_reason;
}

/// read_gitfile_gently() error codes
pub const GitfileErr = enum { ok, stat_failed, not_a_file, open_failed, read_failed, invalid_format, no_path, not_a_repo, too_large, is_a_dir };

pub fn readGitfileGently(path: []const u8, err: *GitfileErr) ?[]const u8 {
    const raw = readGitfileRaw(path, err) orelse return null;
    var full: []const u8 = raw;
    if (!isAbs(raw)) {
        const d = util.dirname(path);
        full = if (d.len == 0) raw else util.concat(&.{ d, "/", raw });
    }
    if (!repo_mod.isGitDirectory(full)) {
        err.* = .not_a_repo;
        return null;
    }
    return realOrAbs(full);
}

/// read_gitfile_raw-ish: returns the path recorded in the gitfile.
pub fn readGitfileRaw(path: []const u8, err: *GitfileErr) ?[]const u8 {
    err.* = .ok;
    const st = os.statPath(path) orelse {
        err.* = .stat_failed;
        return null;
    };
    if (st.isDir()) {
        err.* = .is_a_dir;
        return null;
    }
    if (!st.isReg()) {
        err.* = .not_a_file;
        return null;
    }
    const data = os.readFile(path) orelse {
        err.* = .open_failed;
        return null;
    };
    const rest = util.skipPrefix(data, "gitdir: ") orelse {
        err.* = .invalid_format;
        return null;
    };
    const p = util.trimRight(rest);
    if (p.len == 0) {
        err.* = .no_path;
        return null;
    }
    return p;
}

pub fn gitfileErrCode(e: GitfileErr) i32 {
    return @intFromEnum(e);
}

/// validate_worktree(); returns error message or null when valid.
pub fn validate(wt: *const Worktree, missing_ok: bool) ?[]const u8 {
    const r = repo_mod.repo();
    const wt_path = util.concat(&.{ wt.path, "/.git" });
    if (wt.isMain()) {
        if (os.isDir(wt_path)) return null;
        return util.fmt("'{s}' at main working tree is not the repository directory", .{wt_path});
    }
    const id = wt.id.?;
    if (!isAbs(wt.path))
        return util.fmt("'{s}' file does not contain absolute path to the working tree location", .{util.concat(&.{ r.common_dir, "/worktrees/", id, "/gitdir" })});
    if (missing_ok and !os.exists(wt.path)) return null;
    if (!os.exists(wt_path)) return util.fmt("'{s}' does not exist", .{wt_path});
    var e: GitfileErr = .ok;
    const path = readGitfileGently(wt_path, &e) orelse
        return util.fmt("'{s}' is not a .git file, error code {d}", .{ wt_path, gitfileErrCode(e) });
    const rp = realOrAbs(util.concat(&.{ r.common_dir, "/worktrees/", id }));
    if (!util.eql(path, rp))
        return util.fmt("'{s}' does not point back to '{s}'", .{ wt.path, util.concat(&.{ r.common_dir, "/worktrees/", id }) });
    return null;
}

fn writeFileLn(path: []const u8, content: []const u8) void {
    const data = if (content.len > 0 and content[content.len - 1] == '\n') content else util.concat(&.{ content, "\n" });
    os.writeFile(path, data, 0o666) catch util.dieErrno("could not write to '{s}'", .{path});
}

pub fn writeFile(path: []const u8, content: []const u8) void {
    writeFileLn(path, content);
}

var relative_enabled_done = false;

fn enableRelativeWorktrees() void {
    if (relative_enabled_done) return;
    const r = repo_mod.repo();
    if (repo_mod.cfg.getBool("extensions.relativeworktrees") orelse false) {
        relative_enabled_done = true;
        return;
    }
    const cfgfile = util.concat(&.{ r.common_dir, "/config" });
    if ((repo_mod.cfg.getInt("core.repositoryformatversion") orelse 0) < 1) {
        if (config.setInFileGently(cfgfile, "core.repositoryformatversion", null, "1") != 0)
            util.die("unable to upgrade repository format to support relative worktrees", .{});
    }
    if (config.setInFileGently(cfgfile, "extensions.relativeWorktrees", null, "true") != 0)
        util.die("unable to set extensions.relativeWorktrees setting", .{});
    relative_enabled_done = true;
}

/// write_worktree_linking_files()
pub fn writeLinkingFiles(dotgit: []const u8, gitdir: []const u8, use_relative: bool) void {
    const path = realOrAbs(stripSuffix(dotgit, "/.git"));
    const repo_path = realOrAbs(stripSuffix(gitdir, "/gitdir"));
    if (use_relative) enableRelativeWorktrees();
    if (use_relative) {
        writeFileLn(gitdir, util.concat(&.{ relativePath(path, repo_path), "/.git" }));
        writeFileLn(dotgit, util.concat(&.{ "gitdir: ", relativePath(repo_path, path) }));
    } else {
        writeFileLn(gitdir, util.concat(&.{ path, "/.git" }));
        writeFileLn(dotgit, util.concat(&.{ "gitdir: ", repo_path }));
    }
}

/// update_worktree_location()
pub fn updateLocation(wt: *Worktree, path_: []const u8, use_relative: bool) void {
    const r = repo_mod.repo();
    const gitdir = realOrAbs(util.concat(&.{ r.common_dir, "/worktrees/", wt.id.?, "/gitdir" }));
    const path = realOrAbs(path_);
    const dotgit = util.concat(&.{ path, "/.git" });
    if (!util.eql(wt.path, path)) {
        writeLinkingFiles(dotgit, gitdir, use_relative);
        wt.path = path;
    }
}

// ---------------- shared symref detection ----------------

fn readTrim(p: []const u8) ?[]const u8 {
    const d = os.readFile(p) orelse return null;
    return util.trim(d);
}

fn beingRebased(wt: *const Worktree, target: []const u8) bool {
    const gd = wt.gitDir();
    const branch = readTrim(util.concat(&.{ gd, "/rebase-merge/head-name" })) orelse
        readTrim(util.concat(&.{ gd, "/rebase-apply/head-name" })) orelse return false;
    if (!os.isDir(util.concat(&.{ gd, "/rebase-merge" })) and !os.exists(util.concat(&.{ gd, "/rebase-apply/rebasing" }))) return false;
    const b = util.skipPrefix(branch, "refs/heads/") orelse branch;
    const t = util.skipPrefix(target, "refs/heads/") orelse return false;
    return util.eql(b, t);
}

fn beingBisected(wt: *const Worktree, target: []const u8) bool {
    const gd = wt.gitDir();
    const from = readTrim(util.concat(&.{ gd, "/BISECT_START" })) orelse return false;
    const t = util.skipPrefix(target, "refs/heads/") orelse return false;
    return util.eql(from, t);
}

/// is_shared_symref()
pub fn isSharedSymref(wt: *const Worktree, symref: []const u8, target: []const u8) bool {
    if (wt.is_bare) return false;
    if (wt.is_detached and util.eql(symref, "HEAD")) {
        if (beingRebased(wt, target)) return true;
        if (beingBisected(wt, target)) return true;
    }
    if (util.eql(symref, "HEAD")) {
        const data = refs.headContentsAt(wt.gitDir()) orelse return false;
        const t = util.trimRight(data);
        const rest = util.skipPrefix(t, "ref:") orelse return false;
        return util.eql(util.trim(rest), target);
    }
    const tgt = refs.readSymbolic(symref) orelse return false;
    return util.eql(tgt, target);
}

pub fn findSharedSymref(list: []*Worktree, symref: []const u8, target: []const u8) ?*Worktree {
    for (list) |wt| {
        if (isSharedSymref(wt, symref, target)) return wt;
    }
    return null;
}

/// die_if_checked_out() from branch.c
pub fn dieIfCheckedOut(branch: []const u8, ignore_current: bool) void {
    const list = getAll();
    for (list) |wt| {
        if (wt.is_current and ignore_current) continue;
        if (isSharedSymref(wt, "HEAD", branch)) {
            const b = util.skipPrefix(branch, "refs/heads/") orelse branch;
            util.die("'{s}' is already used by worktree at '{s}'", .{ b, wt.path });
        }
    }
}

// ---------------- repair ----------------

pub const RepairFn = *const fn (iserr: bool, path: []const u8, msg: []const u8, cb: ?*anyopaque) void;

fn repairGitfile(wt: *Worktree, f: RepairFn, cb: ?*anyopaque, use_relative: bool) void {
    const r = repo_mod.repo();
    if (!os.exists(wt.path)) return;
    if (!os.isDir(wt.path)) {
        f(true, wt.path, "not a directory", cb);
        return;
    }
    const repo_p = realOrAbs(util.concat(&.{ r.common_dir, "/worktrees/", wt.id.? }));
    const dotgit = util.concat(&.{ wt.path, "/.git" });
    const gitdir = util.concat(&.{ repo_p, "/gitdir" });
    var e: GitfileErr = .ok;
    const contents = readGitfileRaw(dotgit, &e);
    var backlink: []const u8 = "";
    if (contents) |c| {
        backlink = if (isAbs(c)) c else realPathForgiving(util.concat(&.{ wt.path, "/", c }));
    }
    var repair: ?[]const u8 = null;
    if (e == .not_a_file or e == .is_a_dir) {
        f(true, wt.path, ".git is not a file", cb);
    } else if (e != .ok or !repo_mod.isGitDirectory(backlink)) {
        repair = ".git file broken";
    } else if (!util.eql(backlink, repo_p)) {
        repair = ".git file incorrect";
    } else if (use_relative == isAbs(contents.?)) {
        repair = ".git file absolute/relative path mismatch";
    }
    if (repair) |m| {
        f(false, wt.path, m, cb);
        writeLinkingFiles(dotgit, gitdir, use_relative);
    }
}

pub fn repairAll(f: RepairFn, cb: ?*anyopaque, use_relative: bool) void {
    const list = getAllWithoutHead();
    for (list[1..]) |wt| repairGitfile(wt, f, cb, use_relative);
}

fn isMainWorktreePath(path: []const u8) bool {
    const r = repo_mod.repo();
    const target = stripSuffix(realOrAbs(path), "/.git");
    const maindir = stripSuffix(realOrAbs(r.common_dir), "/.git");
    return util.eql(maindir, target);
}

fn inferBacklink(gitfile: []const u8) ?[]const u8 {
    const r = repo_mod.repo();
    const actual = os.readFile(gitfile) orelse return null;
    if (!util.startsWith(actual, "gitdir:")) return null;
    const t = util.trim(actual);
    const slash = std.mem.lastIndexOfScalar(u8, t, '/') orelse return null;
    const id = t[slash + 1 ..];
    if (id.len == 0) return null;
    const inferred = util.concat(&.{ r.common_dir, "/worktrees/", id });
    if (!os.isDir(inferred)) return null;
    return inferred;
}

pub fn repairAtPath(path: []const u8, f: RepairFn, cb: ?*anyopaque, use_relative: bool) void {
    if (isMainWorktreePath(path)) return;
    const dotgit = realPathLastMissing(util.concat(&.{ path, "/.git" })) orelse {
        f(true, path, "not a valid path", cb);
        return;
    };
    var inferred: []const u8 = "";
    if (inferBacklink(dotgit)) |ib| inferred = realPathForgiving(ib);
    var e: GitfileErr = .ok;
    var backlink: []const u8 = "";
    if (readGitfileGently(dotgit, &e)) |c| {
        backlink = c;
    } else if (e == .not_a_file or e == .is_a_dir) {
        f(true, dotgit, "unable to locate repository; .git is not a file", cb);
        return;
    } else if (e == .not_a_repo) {
        if (inferred.len > 0) {
            backlink = inferred;
            inferred = "";
        } else {
            f(true, dotgit, "unable to locate repository; .git file does not reference a repository", cb);
            return;
        }
    } else {
        f(true, dotgit, "unable to locate repository; .git file broken", cb);
        return;
    }
    if (inferred.len > 0 and !util.eql(backlink, inferred)) backlink = inferred;
    const gitdir = util.concat(&.{ backlink, "/gitdir" });
    var repair: ?[]const u8 = null;
    if (os.readFile(gitdir)) |old| {
        if (use_relative == isAbs(old)) {
            repair = "gitdir absolute/relative path mismatch";
        } else {
            var o: []const u8 = util.trimRight(old);
            if (!isAbs(o)) o = realPathForgiving(util.concat(&.{ backlink, "/", o }));
            if (!util.eql(o, dotgit)) repair = "gitdir incorrect";
        }
    } else repair = "gitdir unreadable";
    if (repair) |m| {
        f(false, gitdir, m, cb);
        writeLinkingFiles(dotgit, gitdir, use_relative);
    }
}
