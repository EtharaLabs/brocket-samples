//! Object filters for partial traversal (list-objects-filter-options.c,
//! list-objects-filter.c): blob:none, blob:limit=<n>, tree:<depth>,
//! sparse:oid=<blob>, object:type=<type>, combine:<f>+<f>...

const std = @import("std");
const util = @import("util.zig");
const odb_mod = @import("odb.zig");
const config = @import("config.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const sparse = @import("sparse.zig");
const dir_mod = @import("dir.zig");
const gpa = util.gpa;

const ObjType = odb_mod.ObjType;
const Oid = hash.Oid;

pub const Kind = enum { blob_none, blob_limit, tree_depth, sparse_oid, object_type, combine };

pub const Filter = struct {
    kind: Kind,
    limit: u64 = 0,
    depth: u64 = 0,
    typ: ObjType = .none,
    sparse_name: []const u8 = "",
    sparse_pl: ?*sparse.Patterns = null,
    subs: []Filter = &.{},
    /// the spec as given (for --filter=<spec> pass-through)
    spec: []const u8 = "",
};

fn parseUlong(s: []const u8) ?u64 {
    const v = config.parseInt(s) orelse return null;
    if (v < 0) return null;
    return @intCast(v);
}

fn percentDecode(s: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        if (s[i] == '%' and i + 2 < s.len) {
            const v = std.fmt.parseInt(u8, s[i + 1 .. i + 3], 16) catch {
                b.append(gpa, s[i]) catch util.oom();
                continue;
            };
            b.append(gpa, v) catch util.oom();
            i += 2;
        } else b.append(gpa, s[i]) catch util.oom();
    }
    return b.items;
}

/// gently_parse_list_objects_filter(): returns an error message on failure.
pub fn parseGently(arg: []const u8, out: *Filter) ?[]const u8 {
    out.* = .{ .kind = .blob_none, .spec = arg };
    if (util.eql(arg, "auto")) return "'auto' filter not supported by this command";
    if (util.eql(arg, "blob:none")) return null;
    if (util.startsWith(arg, "blob:limit=")) {
        if (parseUlong(arg[11..])) |v| {
            out.kind = .blob_limit;
            out.limit = v;
            return null;
        }
    } else if (util.startsWith(arg, "tree:")) {
        const v = parseUlong(arg[5..]) orelse return "expected 'tree:<depth>'";
        out.kind = .tree_depth;
        out.depth = v;
        return null;
    } else if (util.startsWith(arg, "sparse:oid=")) {
        out.kind = .sparse_oid;
        out.sparse_name = arg[11..];
        return null;
    } else if (util.startsWith(arg, "sparse:path=")) {
        return "sparse:path filters support has been dropped";
    } else if (util.startsWith(arg, "object:type=")) {
        const t = ObjType.fromName(arg[12..]) orelse
            return util.fmt("'{s}' for 'object:type=<type>' is not a valid object type", .{arg[12..]});
        out.kind = .object_type;
        out.typ = t;
        return null;
    } else if (util.startsWith(arg, "combine:")) {
        const p = arg[8..];
        if (p.len == 0) return "expected something after combine:";
        var subs: std.ArrayList(Filter) = .empty;
        var it = std.mem.splitScalar(u8, p, '+');
        while (it.next()) |sub| {
            const reserved = "~`!@#$^&*()[]{}\\;'\",<>?";
            for (sub) |ch| {
                if (ch <= ' ' or std.mem.indexOfScalar(u8, reserved, ch) != null)
                    return util.fmt("must escape char in sub-filter-spec: '{c}'", .{ch});
            }
            var f: Filter = undefined;
            if (parseGently(percentDecode(sub), &f)) |e| return e;
            subs.append(gpa, f) catch util.oom();
        }
        out.kind = .combine;
        out.subs = subs.items;
        return null;
    }
    return util.fmt("invalid filter-spec '{s}'", .{arg});
}

/// parse_list_objects_filter(): dies on error.
pub fn parse(arg: []const u8) *Filter {
    const f = gpa.create(Filter) catch util.oom();
    if (parseGently(arg, f)) |e| util.die("{s}", .{e});
    return f;
}

/// Combine an additional --filter into an existing one (multiple --filter
/// options become combine:).
pub fn add(existing: ?*Filter, arg: []const u8) *Filter {
    const nf = parse(arg);
    const e = existing orelse return nf;
    if (e.kind == .combine) {
        var subs: std.ArrayList(Filter) = .empty;
        subs.appendSlice(gpa, e.subs) catch util.oom();
        subs.append(gpa, nf.*) catch util.oom();
        e.subs = subs.items;
        e.spec = util.concat(&.{ e.spec, "+", arg });
        return e;
    }
    const c = gpa.create(Filter) catch util.oom();
    const subs = gpa.alloc(Filter, 2) catch util.oom();
    subs[0] = e.*;
    subs[1] = nf.*;
    c.* = .{ .kind = .combine, .subs = subs, .spec = util.concat(&.{ "combine:", e.spec, "+", arg }) };
    return c;
}

/// Path depth in the traversal: root tree is 0, its entries are 1, ...
fn pathDepth(path: []const u8) u64 {
    if (path.len == 0) return 0;
    return std.mem.count(u8, path, "/") + 1;
}

fn sparsePatterns(f: *Filter) *sparse.Patterns {
    if (f.sparse_pl) |p| return p;
    const oid = @import("revparse.zig").getOid(f.sparse_name) orelse
        util.die("unable to access sparse blob in '{s}'", .{f.sparse_name});
    const o = repo_mod.repo().odb().read(oid) orelse util.die("unable to access sparse blob in '{s}'", .{f.sparse_name});
    if (o.typ != .blob) util.die("unable to access sparse blob in '{s}'", .{f.sparse_name});
    const p = sparse.Patterns.init(false);
    p.addBuffer(o.data);
    f.sparse_pl = p;
    return p;
}

pub const Decision = struct {
    show: bool,
    /// for trees: whether to descend
    recurse: bool = true,
};

/// Decide whether a commit is shown.
pub fn includeCommit(f: *Filter) bool {
    return switch (f.kind) {
        .object_type => f.typ == .commit,
        .combine => blk: {
            for (f.subs) |*s| {
                if (!includeCommit(s)) break :blk false;
            }
            break :blk true;
        },
        else => true,
    };
}

/// Decide whether an object reached during traversal at `path` is shown
/// (and, for trees, whether to descend into it).
pub fn check(f: *Filter, typ: ObjType, oid: Oid, path: []const u8) Decision {
    switch (f.kind) {
        .blob_none => return .{ .show = typ != .blob },
        .blob_limit => {
            if (typ != .blob) return .{ .show = true };
            const sz = blobSize(oid) orelse return .{ .show = true };
            return .{ .show = sz < f.limit };
        },
        .tree_depth => {
            if (typ == .tag) return .{ .show = true };
            const d = pathDepth(path);
            if (typ == .tree) {
                const inc = d < f.depth;
                return .{ .show = inc, .recurse = inc };
            }
            if (typ == .blob) return .{ .show = d < f.depth };
            return .{ .show = true };
        },
        .object_type => return .{ .show = typ == f.typ },
        .sparse_oid => {
            if (typ != .blob) return .{ .show = true };
            const p = sparsePatterns(f);
            return .{ .show = p.pathIn(path, dir_mod.DT_REG) };
        },
        .combine => {
            var d = Decision{ .show = true, .recurse = true };
            for (f.subs) |*s| {
                const x = check(s, typ, oid, path);
                if (!x.show) d.show = false;
                if (!x.recurse) d.recurse = false;
            }
            return d;
        },
    }
}

fn blobSize(oid: Oid) ?u64 {
    const o = repo_mod.repo().odb().read(oid) orelse return null;
    return o.data.len;
}

/// expand_list_objects_filter_spec(): canonical spec sent over the wire.
pub fn expandSpec(f: *const Filter) []const u8 {
    return switch (f.kind) {
        .blob_limit => util.fmt("blob:limit={d}", .{f.limit}),
        .tree_depth => util.fmt("tree:{d}", .{f.depth}),
        else => f.spec,
    };
}
