//! Builtin merge/diff tool definitions (contents of git's mergetools/ directory),
//! sourced by the generated shell snippet that runs a tool's diff_cmd/merge_cmd.

pub const Script = struct { name: []const u8, body: []const u8 };

pub const scripts = [_]Script{
    .{ .name = "araxis", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" -wait -2 \"$LOCAL\" \"$REMOTE\" >/dev/null 2>&1\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Araxis Merge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" -wait -merge -3 -a1 \\\n" ++
        "\t\t\t\"$BASE\" \"$LOCAL\" \"$REMOTE\" \"$MERGED\" >/dev/null 2>&1\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" -wait -2 \\\n" ++
        "\t\t\t\"$LOCAL\" \"$REMOTE\" \"$MERGED\" >/dev/null 2>&1\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Araxis Merge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path() {\n" ++
        "\techo compare\n" ++
        "}\n" ++
        "" },
    .{ .name = "bc", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Beyond Compare (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" \"$BASE\" \\\n" ++
        "\t\t\t-mergeoutput=\"$MERGED\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" \\\n" ++
        "\t\t\t-mergeoutput=\"$MERGED\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Beyond Compare (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path() {\n" ++
        "\tif type bcomp >/dev/null 2>/dev/null\n" ++
        "\tthen\n" ++
        "\t\techo bcomp\n" ++
        "\telse\n" ++
        "\t\techo bcompare\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "list_tool_variants () {\n" ++
        "\techo bc\n" ++
        "\techo bc3\n" ++
        "\techo bc4\n" ++
        "}\n" ++
        "" },
    .{ .name = "codecompare", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Code Compare (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" -MF=\"$LOCAL\" -TF=\"$REMOTE\" -BF=\"$BASE\" \\\n" ++
        "\t\t\t-RF=\"$MERGED\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" -MF=\"$LOCAL\" -TF=\"$REMOTE\" \\\n" ++
        "\t\t\t-RF=\"$MERGED\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Code Compare (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path() {\n" ++
        "\tif merge_mode\n" ++
        "\tthen\n" ++
        "\t\techo CodeMerge\n" ++
        "\telse\n" ++
        "\t\techo CodeCompare\n" ++
        "\tfi\n" ++
        "}\n" ++
        "" },
    .{ .name = "deltawalker", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" >/dev/null 2>&1\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use DeltaWalker (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\t# Adding $(pwd)/ in front of $MERGED should not be necessary.\n" ++
        "\t# However without it, DeltaWalker (at least v1.9.8 on Windows)\n" ++
        "\t# crashes with a JRE exception.  The DeltaWalker user manual,\n" ++
        "\t# shows $(pwd)/ whenever the '-merged' options is given.\n" ++
        "\t# Adding it here seems to work around the problem.\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" \"$BASE\" -merged=\"$(pwd)/$MERGED\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" -merged=\"$(pwd)/$MERGED\"\n" ++
        "\tfi >/dev/null 2>&1\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use DeltaWalker (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path () {\n" ++
        "\techo DeltaWalker\n" ++
        "}\n" ++
        "\n" ++
        "exit_code_trustable () {\n" ++
        "\ttrue\n" ++
        "}\n" ++
        "" },
    .{ .name = "diffmerge", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" >/dev/null 2>&1\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use DiffMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" --merge --result=\"$MERGED\" \\\n" ++
        "\t\t\t\"$LOCAL\" \"$BASE\" \"$REMOTE\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" --merge \\\n" ++
        "\t\t\t--result=\"$MERGED\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use DiffMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "exit_code_trustable () {\n" ++
        "\ttrue\n" ++
        "}\n" ++
        "" },
    .{ .name = "diffuse", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" | cat\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Diffuse (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" \\\n" ++
        "\t\t\t\"$LOCAL\" \"$MERGED\" \"$REMOTE\" \\\n" ++
        "\t\t\t\"$BASE\" | cat\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" \\\n" ++
        "\t\t\t\"$LOCAL\" \"$MERGED\" \"$REMOTE\" | cat\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Diffuse (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "ecmerge", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" --default --mode=diff2 \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use ECMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" \"$BASE\" \"$LOCAL\" \"$REMOTE\" \\\n" ++
        "\t\t\t--default --mode=merge3 --to=\"$MERGED\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" \\\n" ++
        "\t\t\t--default --mode=merge2 --to=\"$MERGED\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use ECMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "emerge", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" -f emerge-files-command \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Emacs' Emerge\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" \\\n" ++
        "\t\t\t-f emerge-files-with-ancestor-command \\\n" ++
        "\t\t\t\"$LOCAL\" \"$REMOTE\" \"$BASE\" \\\n" ++
        "\t\t\t\"$(basename \"$MERGED\")\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" \\\n" ++
        "\t\t\t-f emerge-files-command \\\n" ++
        "\t\t\t\"$LOCAL\" \"$REMOTE\" \\\n" ++
        "\t\t\t\"$(basename \"$MERGED\")\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Emacs' Emerge\"\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path() {\n" ++
        "\techo emacs\n" ++
        "}\n" ++
        "\n" ++
        "exit_code_trustable () {\n" ++
        "\ttrue\n" ++
        "}\n" ++
        "" },
    .{ .name = "examdiff", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" -nh\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use ExamDiff Pro (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" -merge \"$LOCAL\" \"$BASE\" \"$REMOTE\" -o:\"$MERGED\" -nh\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" -merge \"$LOCAL\" \"$REMOTE\" -o:\"$MERGED\" -nh\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use ExamDiff Pro (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path() {\n" ++
        "\tmergetool_find_win32_cmd \"ExamDiff.com\" \"ExamDiff Pro\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "guiffy", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Guiffy's Diff Tool (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" -s \"$LOCAL\" \\\n" ++
        "\t\t\"$REMOTE\" \"$BASE\" \"$MERGED\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" -m \"$LOCAL\" \\\n" ++
        "\t\t\"$REMOTE\" \"$MERGED\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Guiffy's Diff Tool (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "exit_code_trustable () {\n" ++
        "\ttrue\n" ++
        "}\n" ++
        "" },
    .{ .name = "kdiff3", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \\\n" ++
        "\t\t--L1 \"$MERGED (A)\" --L2 \"$MERGED (B)\" \\\n" ++
        "\t\t\"$LOCAL\" \"$REMOTE\" >/dev/null 2>&1\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use KDiff3 (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" --auto \\\n" ++
        "\t\t\t--L1 \"$MERGED (Base)\" \\\n" ++
        "\t\t\t--L2 \"$MERGED (Local)\" \\\n" ++
        "\t\t\t--L3 \"$MERGED (Remote)\" \\\n" ++
        "\t\t\t-o \"$MERGED\" \"$BASE\" \"$LOCAL\" \"$REMOTE\" \\\n" ++
        "\t\t>/dev/null 2>&1\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" --auto \\\n" ++
        "\t\t\t--L1 \"$MERGED (Local)\" \\\n" ++
        "\t\t\t--L2 \"$MERGED (Remote)\" \\\n" ++
        "\t\t\t-o \"$MERGED\" \"$LOCAL\" \"$REMOTE\" \\\n" ++
        "\t\t>/dev/null 2>&1\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use KDiff3 (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "exit_code_trustable () {\n" ++
        "\ttrue\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path() {\n" ++
        "\tif type kdiff3 >/dev/null 2>/dev/null\n" ++
        "\tthen\n" ++
        "\t\techo kdiff3\n" ++
        "\telse\n" ++
        "\t\tmergetool_find_win32_cmd \"kdiff3.exe\" \"Kdiff3\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "" },
    .{ .name = "kompare", .body = 
        "can_merge () {\n" ++
        "\treturn 1\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Kompare (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Kompare (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "exit_code_trustable () {\n" ++
        "\ttrue\n" ++
        "}\n" ++
        "" },
    .{ .name = "meld", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Meld (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tcheck_meld_for_features\n" ++
        "\n" ++
        "\toption_auto_merge=\n" ++
        "\tif test \"$meld_use_auto_merge_option\" = true\n" ++
        "\tthen\n" ++
        "\t\toption_auto_merge=\"--auto-merge\"\n" ++
        "\tfi\n" ++
        "\n" ++
        "\tif test \"$meld_has_output_option\" = true\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" $option_auto_merge --output=\"$MERGED\" \\\n" ++
        "\t\t\t\"$LOCAL\" \"$BASE\" \"$REMOTE\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" $option_auto_merge \"$LOCAL\" \"$MERGED\" \"$REMOTE\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Meld (requires a graphical session) with optional \\`auto merge\\` (see \\`git help mergetool\\`'s \\`CONFIGURATION\\` section)\"\n" ++
        "}\n" ++
        "\n" ++
        "# Get meld help message\n" ++
        "init_meld_help_msg () {\n" ++
        "\tif test -z \"$meld_help_msg\"\n" ++
        "\tthen\n" ++
        "\t\tmeld_path=\"$(git config mergetool.meld.path || echo meld)\"\n" ++
        "\t\tmeld_help_msg=$(\"$meld_path\" --help 2>&1)\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "# Check the features and set flags\n" ++
        "check_meld_for_features () {\n" ++
        "\t# Check whether we should use 'meld --output <file>'\n" ++
        "\tif test -z \"$meld_has_output_option\"\n" ++
        "\tthen\n" ++
        "\t\tmeld_has_output_option=$(git config --bool mergetool.meld.hasOutput)\n" ++
        "\t\tcase \"$meld_has_output_option\" in\n" ++
        "\t\ttrue | false)\n" ++
        "\t\t\t: use configured value\n" ++
        "\t\t\t;;\n" ++
        "\t\t*)\n" ++
        "\t\t\t: empty or invalid configured value, detecting \"--output\" automatically\n" ++
        "\t\t\tinit_meld_help_msg\n" ++
        "\n" ++
        "\t\t\tcase \"$meld_help_msg\" in\n" ++
        "\t\t\t*\"--output=\"* | *'[OPTION...]'*)\n" ++
        "\t\t\t\t# All version that has [OPTION...] supports --output\n" ++
        "\t\t\t\tmeld_has_output_option=true\n" ++
        "\t\t\t\t;;\n" ++
        "\t\t\t*)\n" ++
        "\t\t\t\tmeld_has_output_option=false\n" ++
        "\t\t\t\t;;\n" ++
        "\t\t\tesac\n" ++
        "\t\t\t;;\n" ++
        "\t\tesac\n" ++
        "\tfi\n" ++
        "\t# Check whether we should use 'meld --auto-merge ...'\n" ++
        "\tif test -z \"$meld_use_auto_merge_option\"\n" ++
        "\tthen\n" ++
        "\t\tmeld_use_auto_merge_option=$(\n" ++
        "\t\t\tgit config --bool-or-str mergetool.meld.useAutoMerge\n" ++
        "\t\t)\n" ++
        "\t\tcase \"$meld_use_auto_merge_option\" in\n" ++
        "\t\ttrue | false)\n" ++
        "\t\t\t: use well formatted boolean value\n" ++
        "\t\t\t;;\n" ++
        "\t\tauto)\n" ++
        "\t\t\t# testing the \"--auto-merge\" option only if config is \"auto\"\n" ++
        "\t\t\tinit_meld_help_msg\n" ++
        "\n" ++
        "\t\t\tcase \"$meld_help_msg\" in\n" ++
        "\t\t\t*\"--auto-merge\"* | *'[OPTION...]'*)\n" ++
        "\t\t\t\tmeld_use_auto_merge_option=true\n" ++
        "\t\t\t\t;;\n" ++
        "\t\t\t*)\n" ++
        "\t\t\t\tmeld_use_auto_merge_option=false\n" ++
        "\t\t\t\t;;\n" ++
        "\t\t\tesac\n" ++
        "\t\t\t;;\n" ++
        "\t\t\"\")\n" ++
        "\t\t\tmeld_use_auto_merge_option=false\n" ++
        "\t\t\t;;\n" ++
        "\t\t*)\n" ++
        "\t\t\tdie \"unknown mergetool.meld.useAutoMerge: $meld_use_auto_merge_option\"\n" ++
        "\t\t\t;;\n" ++
        "\t\tesac\n" ++
        "\tfi\n" ++
        "}\n" ++
        "" },
    .{ .name = "opendiff", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" | cat\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use FileMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" \\\n" ++
        "\t\t\t-ancestor \"$BASE\" -merge \"$MERGED\" | cat\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\" \\\n" ++
        "\t\t\t-merge \"$MERGED\" | cat\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use FileMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "p4merge", .body = 
        "diff_cmd () {\n" ++
        "\tempty_file=\n" ++
        "\n" ++
        "\t# p4merge does not like /dev/null\n" ++
        "\tif test \"/dev/null\" = \"$LOCAL\"\n" ++
        "\tthen\n" ++
        "\t\tLOCAL=\"$(create_empty_file)\"\n" ++
        "\tfi\n" ++
        "\tif test \"/dev/null\" = \"$REMOTE\"\n" ++
        "\tthen\n" ++
        "\t\tREMOTE=\"$(create_empty_file)\"\n" ++
        "\tfi\n" ++
        "\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "\n" ++
        "\tif test -n \"$empty_file\"\n" ++
        "\tthen\n" ++
        "\t\trm -f \"$empty_file\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use HelixCore P4Merge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif ! $base_present\n" ++
        "\tthen\n" ++
        "\t\tcp -- \"$LOCAL\" \"$BASE\"\n" ++
        "\t\tcreate_virtual_base \"$BASE\" \"$REMOTE\"\n" ++
        "\tfi\n" ++
        "\t\"$merge_tool_path\" \"$BASE\" \"$REMOTE\" \"$LOCAL\" \"$MERGED\"\n" ++
        "}\n" ++
        "\n" ++
        "create_empty_file () {\n" ++
        "\tempty_file=\"${TMPDIR:-/tmp}/git-difftool-p4merge-empty-file.$$\"\n" ++
        "\t>\"$empty_file\"\n" ++
        "\n" ++
        "\tprintf \"%s\" \"$empty_file\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use HelixCore P4Merge (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "smerge", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" mergetool \"$LOCAL\" \"$REMOTE\" -o \"$MERGED\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Sublime Merge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" mergetool \"$BASE\" \"$LOCAL\" \"$REMOTE\" -o \"$MERGED\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" mergetool \"$LOCAL\" \"$REMOTE\" -o \"$MERGED\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Sublime Merge (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "tkdiff", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use TkDiff (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" -a \"$BASE\" -o \"$MERGED\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" -o \"$MERGED\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "exit_code_trustable () {\n" ++
        "\ttrue\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use TkDiff (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "tortoisemerge", .body = 
        "can_diff () {\n" ++
        "\treturn 1\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use TortoiseMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\tbasename=\"$(basename \"$merge_tool_path\" .exe)\"\n" ++
        "\t\tif test \"$basename\" = \"tortoisegitmerge\"\n" ++
        "\t\tthen\n" ++
        "\t\t\t\"$merge_tool_path\" \\\n" ++
        "\t\t\t\t-base \"$BASE\" -mine \"$LOCAL\" \\\n" ++
        "\t\t\t\t-theirs \"$REMOTE\" -merged \"$MERGED\"\n" ++
        "\t\telse\n" ++
        "\t\t\t\"$merge_tool_path\" \\\n" ++
        "\t\t\t\t-base:\"$BASE\" -mine:\"$LOCAL\" \\\n" ++
        "\t\t\t\t-theirs:\"$REMOTE\" -merged:\"$MERGED\"\n" ++
        "\t\tfi\n" ++
        "\telse\n" ++
        "\t\techo \"$merge_tool_path cannot be used without a base\" 1>&2\n" ++
        "\t\treturn 1\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path() {\n" ++
        "\tif type tortoisegitmerge >/dev/null 2>/dev/null\n" ++
        "\tthen\n" ++
        "\t\techo tortoisegitmerge\n" ++
        "\telse\n" ++
        "\t\techo tortoisemerge\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use TortoiseMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "vimdiff", .body = 
        "# This script can be run in two different contexts:\n" ++
        "#\n" ++
        "#   - From git, when the user invokes the \"vimdiff\" merge tool. In this context\n" ++
        "#     this script expects the following environment variables (among others) to\n" ++
        "#     be defined (which is something \"git\" takes care of):\n" ++
        "#\n" ++
        "#       - $BASE\n" ++
        "#       - $LOCAL\n" ++
        "#       - $REMOTE\n" ++
        "#       - $MERGED\n" ++
        "#\n" ++
        "#     In this mode, all this script does is to run the next command:\n" ++
        "#\n" ++
        "#         vim -f -c ... $LOCAL $BASE $REMOTE $MERGED\n" ++
        "#\n" ++
        "#     ...where the \"...\" string depends on the value of the\n" ++
        "#     \"mergetool.vimdiff.layout\" configuration variable and is used to open vim\n" ++
        "#     with a certain layout of buffers, windows and tabs.\n" ++
        "#\n" ++
        "#   - From a script inside the unit tests framework folder (\"t\" folder) by\n" ++
        "#     sourcing this script and then manually calling \"run_unit_tests\", which\n" ++
        "#     will run a battery of unit tests to make sure nothing breaks.\n" ++
        "#     In this context this script does not expect any particular environment\n" ++
        "#     variable to be set.\n" ++
        "\n" ++
        "\n" ++
        "################################################################################\n" ++
        "## Internal functions (not meant to be used outside this script)\n" ++
        "################################################################################\n" ++
        "\n" ++
        "debug_print () {\n" ++
        "\t# Send message to stderr if global variable GIT_MERGETOOL_VIMDIFF_DEBUG\n" ++
        "\t# is set.\n" ++
        "\n" ++
        "\tif test -n \"$GIT_MERGETOOL_VIMDIFF_DEBUG\"\n" ++
        "\tthen\n" ++
        "\t\t>&2 echo \"$@\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "substring () {\n" ++
        "\t# Return a substring of $1 containing $3 characters starting at\n" ++
        "\t# zero-based offset $2.\n" ++
        "\t#\n" ++
        "\t# Examples:\n" ++
        "\t#\n" ++
        "\t#   substring \"Hello world\" 0 4  --> \"Hell\"\n" ++
        "\t#   substring \"Hello world\" 3 4  --> \"lo w\"\n" ++
        "\t#   substring \"Hello world\" 3 10 --> \"lo world\"\n" ++
        "\n" ++
        "\tSTRING=$1\n" ++
        "\tSTART=$2\n" ++
        "\tLEN=$3\n" ++
        "\n" ++
        "\techo \"$STRING\" | cut -c$(( START + 1 ))-$(( START + $LEN ))\n" ++
        "}\n" ++
        "\n" ++
        "gen_cmd_aux () {\n" ++
        "\t# Auxiliary function used from \"gen_cmd()\".\n" ++
        "\t# Read that other function documentation for more details.\n" ++
        "\n" ++
        "\tLAYOUT=$1\n" ++
        "\tCMD=$2  # This is a second (hidden) argument used for recursion\n" ++
        "\n" ++
        "\tdebug_print\n" ++
        "\tdebug_print \"LAYOUT    : $LAYOUT\"\n" ++
        "\tdebug_print \"CMD       : $CMD\"\n" ++
        "\n" ++
        "\tstart=0\n" ++
        "\tend=${#LAYOUT}\n" ++
        "\n" ++
        "\tnested=0\n" ++
        "\tnested_min=100\n" ++
        "\n" ++
        "\t# Step 1:\n" ++
        "\t#\n" ++
        "\t# Increase/decrease \"start\"/\"end\" indices respectively to get rid of\n" ++
        "\t# outer parenthesis.\n" ++
        "\t#\n" ++
        "\t# Example:\n" ++
        "\t#\n" ++
        "\t#   - BEFORE: (( LOCAL , BASE ) / MERGED )\n" ++
        "\t#   - AFTER :  ( LOCAL , BASE ) / MERGED\n" ++
        "\n" ++
        "\toldIFS=$IFS\n" ++
        "\tIFS=#\n" ++
        "\tfor c in $(echo \"$LAYOUT\" | sed 's:.:&#:g')\n" ++
        "\tdo\n" ++
        "\t\tif test -z \"$c\" || test \"$c\" = \" \"\n" ++
        "\t\tthen\n" ++
        "\t\t\tcontinue\n" ++
        "\t\tfi\n" ++
        "\n" ++
        "\t\tif test \"$c\" = \"(\"\n" ++
        "\t\tthen\n" ++
        "\t\t\tnested=$(( nested + 1 ))\n" ++
        "\t\t\tcontinue\n" ++
        "\t\tfi\n" ++
        "\n" ++
        "\t\tif test \"$c\" = \")\"\n" ++
        "\t\tthen\n" ++
        "\t\t\tnested=$(( nested - 1 ))\n" ++
        "\t\t\tcontinue\n" ++
        "\t\tfi\n" ++
        "\n" ++
        "\t\tif test \"$nested\" -lt \"$nested_min\"\n" ++
        "\t\tthen\n" ++
        "\t\t\tnested_min=$nested\n" ++
        "\t\tfi\n" ++
        "\tdone\n" ++
        "\tIFS=$oldIFS\n" ++
        "\n" ++
        "\tdebug_print \"NESTED MIN: $nested_min\"\n" ++
        "\n" ++
        "\twhile test \"$nested_min\" -gt \"0\"\n" ++
        "\tdo\n" ++
        "\t\tstart=$(( start + 1 ))\n" ++
        "\t\tend=$(( end - 1 ))\n" ++
        "\n" ++
        "\t\tstart_minus_one=$(( start - 1 ))\n" ++
        "\n" ++
        "\t\twhile ! test \"$(substring \"$LAYOUT\" \"$start_minus_one\" 1)\" = \"(\"\n" ++
        "\t\tdo\n" ++
        "\t\t\tstart=$(( start + 1 ))\n" ++
        "\t\t\tstart_minus_one=$(( start_minus_one + 1 ))\n" ++
        "\t\tdone\n" ++
        "\n" ++
        "\t\twhile ! test \"$(substring \"$LAYOUT\" \"$end\" 1)\" = \")\"\n" ++
        "\t\tdo\n" ++
        "\t\t\tend=$(( end - 1 ))\n" ++
        "\t\tdone\n" ++
        "\n" ++
        "\t\tnested_min=$(( nested_min - 1 ))\n" ++
        "\tdone\n" ++
        "\n" ++
        "\tdebug_print \"CLEAN     : $(substring \"$LAYOUT\" \"$start\" \"$(( end - start ))\")\"\n" ++
        "\n" ++
        "\n" ++
        "\t# Step 2:\n" ++
        "\t#\n" ++
        "\t# Search for all valid separators (\"/\" or \",\") which are *not*\n" ++
        "\t# inside parenthesis. Save the index at which each of them makes the\n" ++
        "\t# first appearance.\n" ++
        "\n" ++
        "\tindex_horizontal_split=\"\"\n" ++
        "\tindex_vertical_split=\"\"\n" ++
        "\n" ++
        "\tnested=0\n" ++
        "\ti=$(( start - 1 ))\n" ++
        "\n" ++
        "\toldIFS=$IFS\n" ++
        "\tIFS=#\n" ++
        "\tfor c in $(substring \"$LAYOUT\" \"$start\" \"$(( end - start ))\" | sed 's:.:&#:g');\n" ++
        "\tdo\n" ++
        "\t\ti=$(( i + 1 ))\n" ++
        "\n" ++
        "\t\tif test \"$c\" = \" \"\n" ++
        "\t\tthen\n" ++
        "\t\t\tcontinue\n" ++
        "\t\tfi\n" ++
        "\n" ++
        "\t\tif test \"$c\" = \"(\"\n" ++
        "\t\tthen\n" ++
        "\t\t\tnested=$(( nested + 1 ))\n" ++
        "\t\t\tcontinue\n" ++
        "\t\tfi\n" ++
        "\n" ++
        "\t\tif test \"$c\" = \")\"\n" ++
        "\t\tthen\n" ++
        "\t\t\tnested=$(( nested - 1 ))\n" ++
        "\t\t\tcontinue\n" ++
        "\t\tfi\n" ++
        "\n" ++
        "\t\tif test \"$nested\" = 0\n" ++
        "\t\tthen\n" ++
        "\t\t\tcurrent=$c\n" ++
        "\n" ++
        "\t\t\tif test \"$current\" = \"/\"\n" ++
        "\t\t\tthen\n" ++
        "\t\t\t\tif test -z \"$index_horizontal_split\"\n" ++
        "\t\t\t\tthen\n" ++
        "\t\t\t\t\tindex_horizontal_split=$i\n" ++
        "\t\t\t\tfi\n" ++
        "\n" ++
        "\t\t\telif test \"$current\" = \",\"\n" ++
        "\t\t\tthen\n" ++
        "\t\t\t\tif test -z \"$index_vertical_split\"\n" ++
        "\t\t\t\tthen\n" ++
        "\t\t\t\t\tindex_vertical_split=$i\n" ++
        "\t\t\t\tfi\n" ++
        "\t\t\tfi\n" ++
        "\t\tfi\n" ++
        "\tdone\n" ++
        "\tIFS=$oldIFS\n" ++
        "\n" ++
        "\n" ++
        "\t# Step 3:\n" ++
        "\t#\n" ++
        "\t# Process the separator with the highest order of precedence\n" ++
        "\t# (\";\" has the highest precedence and \"|\" the lowest one).\n" ++
        "\t#\n" ++
        "\t# By \"process\" I mean recursively call this function twice: the first\n" ++
        "\t# one with the substring at the left of the separator and the second one\n" ++
        "\t# with the one at its right.\n" ++
        "\n" ++
        "\tterminate=\"false\"\n" ++
        "\n" ++
        "\tif ! test -z \"$index_horizontal_split\"\n" ++
        "\tthen\n" ++
        "\t\tbefore=\"leftabove split\"\n" ++
        "\t\tafter=\"wincmd j\"\n" ++
        "\t\tindex=$index_horizontal_split\n" ++
        "\t\tterminate=\"true\"\n" ++
        "\n" ++
        "\telif ! test -z \"$index_vertical_split\"\n" ++
        "\tthen\n" ++
        "\t\tbefore=\"leftabove vertical split\"\n" ++
        "\t\tafter=\"wincmd l\"\n" ++
        "\t\tindex=$index_vertical_split\n" ++
        "\t\tterminate=\"true\"\n" ++
        "\tfi\n" ++
        "\n" ++
        "\tif  test \"$terminate\" = \"true\"\n" ++
        "\tthen\n" ++
        "\t\tCMD=\"$CMD | $before\"\n" ++
        "\t\tCMD=$(gen_cmd_aux \"$(substring \"$LAYOUT\" \"$start\" \"$(( index - start ))\")\" \"$CMD\")\n" ++
        "\t\tCMD=\"$CMD | $after\"\n" ++
        "\t\tCMD=$(gen_cmd_aux \"$(substring \"$LAYOUT\" \"$(( index + 1 ))\" \"$(( ${#LAYOUT} - index ))\")\" \"$CMD\")\n" ++
        "\t\techo \"$CMD\"\n" ++
        "\t\treturn\n" ++
        "\tfi\n" ++
        "\n" ++
        "\n" ++
        "\t# Step 4:\n" ++
        "\t#\n" ++
        "\t# If we reach this point, it means there are no separators and we just\n" ++
        "\t# need to print the command to display the specified buffer\n" ++
        "\n" ++
        "\ttarget=$(substring \"$LAYOUT\" \"$start\" \"$(( end - start ))\" | sed 's:[ @();|-]::g')\n" ++
        "\n" ++
        "\tif test \"$target\" = \"LOCAL\"\n" ++
        "\tthen\n" ++
        "\t\tCMD=\"$CMD | 1b\"\n" ++
        "\n" ++
        "\telif test \"$target\" = \"BASE\"\n" ++
        "\tthen\n" ++
        "\t\tCMD=\"$CMD | 2b\"\n" ++
        "\n" ++
        "\telif test \"$target\" = \"REMOTE\"\n" ++
        "\tthen\n" ++
        "\t\tCMD=\"$CMD | 3b\"\n" ++
        "\n" ++
        "\telif test \"$target\" = \"MERGED\"\n" ++
        "\tthen\n" ++
        "\t\tCMD=\"$CMD | 4b\"\n" ++
        "\n" ++
        "\telse\n" ++
        "\t\tCMD=\"$CMD | ERROR: >$target<\"\n" ++
        "\tfi\n" ++
        "\n" ++
        "\techo \"$CMD\"\n" ++
        "\treturn\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "gen_cmd () {\n" ++
        "\t# This function returns (in global variable FINAL_CMD) the string that\n" ++
        "\t# you can use when invoking \"vim\" (as shown next) to obtain a given\n" ++
        "\t# layout:\n" ++
        "\t#\n" ++
        "\t#   $ vim -f $FINAL_CMD \"$LOCAL\" \"$BASE\" \"$REMOTE\" \"$MERGED\"\n" ++
        "\t#\n" ++
        "\t# It takes one single argument: a string containing the desired layout\n" ++
        "\t# definition.\n" ++
        "\t#\n" ++
        "\t# The syntax of the \"layout definitions\" is explained in \"Documentation/\n" ++
        "\t# mergetools/vimdiff.adoc\" but you can already intuitively understand\n" ++
        "\t# how it works by knowing that...\n" ++
        "\t#\n" ++
        "\t#   * \"+\" means \"a new vim tab\"\n" ++
        "\t#   * \"/\" means \"a new vim horizontal split\"\n" ++
        "\t#   * \",\" means \"a new vim vertical split\"\n" ++
        "\t#\n" ++
        "\t# It also returns (in global variable FINAL_TARGET) the name (\"LOCAL\",\n" ++
        "\t# \"BASE\", \"REMOTE\" or \"MERGED\") of the file that is marked with an \"@\",\n" ++
        "\t# or \"MERGED\" if none of them is.\n" ++
        "\t#\n" ++
        "\t# Example:\n" ++
        "\t#\n" ++
        "\t#     gen_cmd \"@LOCAL , REMOTE\"\n" ++
        "\t#     |\n" ++
        "\t#     `-> FINAL_CMD    == \"-c \\\"echo | leftabove vertical split | 1b | wincmd l | 3b | tabdo windo diffthis\\\" -c \\\"tabfirst\\\"\"\n" ++
        "\t#         FINAL_TARGET == \"LOCAL\"\n" ++
        "\n" ++
        "\tLAYOUT=$1\n" ++
        "\n" ++
        "\n" ++
        "\t# Search for a \"@\" in one of the files identifiers (\"LOCAL\", \"BASE\",\n" ++
        "\t# \"REMOTE\", \"MERGED\"). If not found, use \"MERGE\" as the default file\n" ++
        "\t# where changes will be saved.\n" ++
        "\n" ++
        "\tif echo \"$LAYOUT\" | grep @LOCAL >/dev/null\n" ++
        "\tthen\n" ++
        "\t\tFINAL_TARGET=\"LOCAL\"\n" ++
        "\telif echo \"$LAYOUT\" | grep @BASE >/dev/null\n" ++
        "\tthen\n" ++
        "\t\tFINAL_TARGET=\"BASE\"\n" ++
        "\telif echo \"$LAYOUT\" | grep @REMOTE >/dev/null\n" ++
        "\tthen\n" ++
        "\t\tFINAL_TARGET=\"REMOTE\"\n" ++
        "\telse\n" ++
        "\t\tFINAL_TARGET=\"MERGED\"\n" ++
        "\tfi\n" ++
        "\n" ++
        "\n" ++
        "\t# Obtain the first part of vim \"-c\" option to obtain the desired layout\n" ++
        "\n" ++
        "\tCMD=\n" ++
        "\toldIFS=$IFS\n" ++
        "\tIFS=+\n" ++
        "\tfor tab in $LAYOUT\n" ++
        "\tdo\n" ++
        "\t\tif test -z \"$CMD\"\n" ++
        "\t\tthen\n" ++
        "\t\t\tCMD=\"echo\" # vim \"nop\" operator\n" ++
        "\t\telse\n" ++
        "\t\t\tCMD=\"$CMD | tabnew\"\n" ++
        "\t\tfi\n" ++
        "\n" ++
        "\t\t# If this is a single window diff with all the buffers\n" ++
        "\t\tif ! echo \"$tab\" | grep -E \",|/\" >/dev/null\n" ++
        "\t\tthen\n" ++
        "\t\t\tCMD=\"$CMD | silent execute 'bufdo diffthis'\"\n" ++
        "\t\tfi\n" ++
        "\n" ++
        "\t\tCMD=$(gen_cmd_aux \"$tab\" \"$CMD\")\n" ++
        "\tdone\n" ++
        "\tIFS=$oldIFS\n" ++
        "\n" ++
        "\tCMD=\"$CMD | execute 'tabdo windo diffthis'\"\n" ++
        "\n" ++
        "\tFINAL_CMD=\"-c \\\"set hidden diffopt-=hiddenoff | $CMD | tabfirst\\\"\"\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "################################################################################\n" ++
        "## API functions (called from \"git-mergetool--lib.sh\")\n" ++
        "################################################################################\n" ++
        "\n" ++
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" -R -f -d \\\n" ++
        "\t\t-c 'wincmd l' -c 'cd $GIT_PREFIX' \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\tTOOL=$1\n" ++
        "\n" ++
        "\tcase \"$TOOL\" in\n" ++
        "\tnvimdiff*)\n" ++
        "\t\tprintf \"Use Neovim\"\n" ++
        "\t\t;;\n" ++
        "\tgvimdiff*)\n" ++
        "\t\tprintf \"Use gVim (requires a graphical session)\"\n" ++
        "\t\t;;\n" ++
        "\tvimdiff*)\n" ++
        "\t\tprintf \"Use Vim\"\n" ++
        "\t\t;;\n" ++
        "\tesac\n" ++
        "\n" ++
        "\treturn 0\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tTOOL=$1\n" ++
        "\n" ++
        "\tlayout=$(git config \"mergetool.$TOOL.layout\")\n" ++
        "\n" ++
        "\t# backward compatibility:\n" ++
        "\tif test -z \"$layout\"\n" ++
        "\tthen\n" ++
        "\t\tlayout=$(git config mergetool.vimdiff.layout)\n" ++
        "\tfi\n" ++
        "\n" ++
        "\tcase \"$TOOL\" in\n" ++
        "\t*vimdiff)\n" ++
        "\t\tif test -z \"$layout\"\n" ++
        "\t\tthen\n" ++
        "\t\t\t# Default layout when none is specified\n" ++
        "\t\t\tlayout=\"(LOCAL,BASE,REMOTE)/MERGED\"\n" ++
        "\t\tfi\n" ++
        "\t\t;;\n" ++
        "\t*vimdiff1)\n" ++
        "\t\tlayout=\"@LOCAL,REMOTE\"\n" ++
        "\t\t;;\n" ++
        "\t*vimdiff2)\n" ++
        "\t\tlayout=\"LOCAL,MERGED,REMOTE\"\n" ++
        "\t\t;;\n" ++
        "\t*vimdiff3)\n" ++
        "\t\tlayout=\"MERGED\"\n" ++
        "\t\t;;\n" ++
        "\tesac\n" ++
        "\n" ++
        "\tgen_cmd \"$layout\"\n" ++
        "\n" ++
        "\tdebug_print \"\"\n" ++
        "\tdebug_print \"FINAL CMD : $FINAL_CMD\"\n" ++
        "\tdebug_print \"FINAL TAR : $FINAL_TARGET\"\n" ++
        "\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\teval '\"$merge_tool_path\"' \\\n" ++
        "\t\t\t-f \"$FINAL_CMD\" '\"$LOCAL\"' '\"$BASE\"' '\"$REMOTE\"' '\"$MERGED\"'\n" ++
        "\telse\n" ++
        "\t\t# If there is no BASE (example: a merge conflict in a new file\n" ++
        "\t\t# with the same name created in both branches which didn't exist\n" ++
        "\t\t# before), close all BASE windows using vim's \"quit\" command\n" ++
        "\n" ++
        "\t\tFINAL_CMD=$(echo \"$FINAL_CMD\" | \\\n" ++
        "\t\t\tsed -e 's:2b:quit:g' -e 's:3b:2b:g' -e 's:4b:3b:g')\n" ++
        "\n" ++
        "\t\teval '\"$merge_tool_path\"' \\\n" ++
        "\t\t\t-f \"$FINAL_CMD\" '\"$LOCAL\"' '\"$REMOTE\"' '\"$MERGED\"'\n" ++
        "\tfi\n" ++
        "\n" ++
        "\tret=\"$?\"\n" ++
        "\n" ++
        "\tif test \"$ret\" -eq 0\n" ++
        "\tthen\n" ++
        "\t\tcase \"$FINAL_TARGET\" in\n" ++
        "\t\tLOCAL)\n" ++
        "\t\t\tsource_path=\"$LOCAL\"\n" ++
        "\t\t\t;;\n" ++
        "\t\tREMOTE)\n" ++
        "\t\t\tsource_path=\"$REMOTE\"\n" ++
        "\t\t\t;;\n" ++
        "\t\tMERGED|*)\n" ++
        "\t\t\t# Do nothing\n" ++
        "\t\t\tsource_path=\n" ++
        "\t\t\t;;\n" ++
        "\t\tesac\n" ++
        "\n" ++
        "\t\tif test -n \"$source_path\"\n" ++
        "\t\tthen\n" ++
        "\t\t\tcp \"$source_path\" \"$MERGED\"\n" ++
        "\t\tfi\n" ++
        "\tfi\n" ++
        "\n" ++
        "\treturn \"$ret\"\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\tTOOL=$1\n" ++
        "\n" ++
        "\tcase \"$TOOL\" in\n" ++
        "\tnvimdiff*)\n" ++
        "\t\tprintf \"Use Neovim \"\n" ++
        "\t\t;;\n" ++
        "\tgvimdiff*)\n" ++
        "\t\tprintf \"Use gVim (requires a graphical session) \"\n" ++
        "\t\t;;\n" ++
        "\tvimdiff*)\n" ++
        "\t\tprintf \"Use Vim \"\n" ++
        "\t\t;;\n" ++
        "\tesac\n" ++
        "\n" ++
        "\tcase \"$TOOL\" in\n" ++
        "\t*1)\n" ++
        "\t\techo \"with a 2 panes layout (LOCAL and REMOTE)\"\n" ++
        "\t\t;;\n" ++
        "\t*2)\n" ++
        "\t\techo \"with a 3 panes layout (LOCAL, MERGED and REMOTE)\"\n" ++
        "\t\t;;\n" ++
        "\t*3)\n" ++
        "\t\techo \"where only the MERGED file is shown\"\n" ++
        "\t\t;;\n" ++
        "\t*)\n" ++
        "\t\techo \"with a custom layout (see \\`git help mergetool\\`'s \\`BACKEND SPECIFIC HINTS\\` section)\"\n" ++
        "\t\t;;\n" ++
        "\tesac\n" ++
        "\n" ++
        "\treturn 0\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "translate_merge_tool_path () {\n" ++
        "\tcase \"$1\" in\n" ++
        "\tnvimdiff*)\n" ++
        "\t\techo nvim\n" ++
        "\t\t;;\n" ++
        "\tgvimdiff*)\n" ++
        "\t\techo gvim\n" ++
        "\t\t;;\n" ++
        "\tvimdiff*)\n" ++
        "\t\techo vim\n" ++
        "\t\t;;\n" ++
        "\tesac\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "exit_code_trustable () {\n" ++
        "\ttrue\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "list_tool_variants () {\n" ++
        "\tif test \"$TOOL_MODE\" = \"diff\"\n" ++
        "\tthen\n" ++
        "\t\tfor prefix in '' g n\n" ++
        "\t\tdo\n" ++
        "\t\t\techo \"${prefix}vimdiff\"\n" ++
        "\t\tdone\n" ++
        "\telse\n" ++
        "\t\tfor prefix in '' g n\n" ++
        "\t\tdo\n" ++
        "\t\t\tfor suffix in '' 1 2 3\n" ++
        "\t\t\tdo\n" ++
        "\t\t\t\techo \"${prefix}vimdiff${suffix}\"\n" ++
        "\t\t\tdone\n" ++
        "\t\tdone\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "\n" ++
        "" },
    .{ .name = "vscode", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" --wait --diff \"$LOCAL\" \"$REMOTE\"\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use Visual Studio Code (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\t\"$merge_tool_path\" --wait --merge \"$REMOTE\" \"$LOCAL\" \"$BASE\" \"$MERGED\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use Visual Studio Code (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path () {\n" ++
        "\techo code\n" ++
        "}\n" ++
        "" },
    .{ .name = "winmerge", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" -u -e \"$LOCAL\" \"$REMOTE\"\n" ++
        "\treturn 0\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use WinMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\t# mergetool.winmerge.trustExitCode is implicitly false.\n" ++
        "\t# touch $BACKUP so that we can check_unchanged.\n" ++
        "\t\"$merge_tool_path\" -u -e -dl Local -dr Remote \\\n" ++
        "\t\t\"$LOCAL\" \"$REMOTE\" \"$MERGED\"\n" ++
        "}\n" ++
        "\n" ++
        "translate_merge_tool_path() {\n" ++
        "\tmergetool_find_win32_cmd \"WinMergeU.exe\" \"WinMerge\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use WinMerge (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
    .{ .name = "xxdiff", .body = 
        "diff_cmd () {\n" ++
        "\t\"$merge_tool_path\" \\\n" ++
        "\t\t-R 'Accel.Search: \"Ctrl+F\"' \\\n" ++
        "\t\t-R 'Accel.SearchForward: \"Ctrl+G\"' \\\n" ++
        "\t\t\"$LOCAL\" \"$REMOTE\"\n" ++
        "\n" ++
        "\t# xxdiff can segfault on binary files which are often uninteresting.\n" ++
        "\t# Do not allow segfaults to stop us from continuing on to the next file.\n" ++
        "\tif test $? = 128\n" ++
        "\tthen\n" ++
        "\t\treturn 1\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "diff_cmd_help () {\n" ++
        "\techo \"Use xxdiff (requires a graphical session)\"\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd () {\n" ++
        "\tif $base_present\n" ++
        "\tthen\n" ++
        "\t\t\"$merge_tool_path\" -X --show-merged-pane \\\n" ++
        "\t\t\t-R 'Accel.SaveAsMerged: \"Ctrl+S\"' \\\n" ++
        "\t\t\t-R 'Accel.Search: \"Ctrl+F\"' \\\n" ++
        "\t\t\t-R 'Accel.SearchForward: \"Ctrl+G\"' \\\n" ++
        "\t\t\t--merged-file \"$MERGED\" \"$LOCAL\" \"$BASE\" \"$REMOTE\"\n" ++
        "\telse\n" ++
        "\t\t\"$merge_tool_path\" -X $extra \\\n" ++
        "\t\t\t-R 'Accel.SaveAsMerged: \"Ctrl+S\"' \\\n" ++
        "\t\t\t-R 'Accel.Search: \"Ctrl+F\"' \\\n" ++
        "\t\t\t-R 'Accel.SearchForward: \"Ctrl+G\"' \\\n" ++
        "\t\t\t--merged-file \"$MERGED\" \"$LOCAL\" \"$REMOTE\"\n" ++
        "\tfi\n" ++
        "}\n" ++
        "\n" ++
        "merge_cmd_help () {\n" ++
        "\techo \"Use xxdiff (requires a graphical session)\"\n" ++
        "}\n" ++
        "" },
};
