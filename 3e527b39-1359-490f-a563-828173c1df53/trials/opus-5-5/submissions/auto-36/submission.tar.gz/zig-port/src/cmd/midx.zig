//! git multi-pack-index (builtin/multi-pack-index.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const odb_mod = @import("../odb.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const midx = @import("../midx.zig");
const gpa = util.gpa;

const write_usage_str = "git multi-pack-index [<options>] write [--preferred-pack=<pack>]\n" ++
    "  [--[no-]bitmap] [--[no-]incremental] [--[no-]stdin-packs]\n" ++
    "  [--refs-snapshot=<path>] [--[no-]write-chain-file]\n" ++
    "  [--base=<checksum>]";
const compact_usage_str = "git multi-pack-index [<options>] compact [--[no-]incremental]\n" ++
    "  [--[no-]bitmap] [--base=<checksum>] [--[no-]write-chain-file]\n" ++
    "  <from> <to>";
const verify_usage_str = "git multi-pack-index [<options>] verify";
const expire_usage_str = "git multi-pack-index [<options>] expire";
const repack_usage_str = "git multi-pack-index [<options>] repack [--batch-size=<size>]";

const main_usage = [_][]const u8{ write_usage_str, compact_usage_str, verify_usage_str, expire_usage_str, repack_usage_str };
const write_usage = [_][]const u8{write_usage_str};
const compact_usage = [_][]const u8{compact_usage_str};
const verify_usage = [_][]const u8{verify_usage_str};
const expire_usage = [_][]const u8{expire_usage_str};
const repack_usage = [_][]const u8{repack_usage_str};

var object_dir: ?[]const u8 = null;
var flags: i32 = 0;
var preferred_pack: ?[]const u8 = null;
var incremental_base: ?[]const u8 = null;
var refs_snapshot: ?[]const u8 = null;
var batch_size: i32 = 0;
var stdin_packs = false;

fn cbObjectDir(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        object_dir = repo_mod.repo().odb().allDirs()[0];
        return;
    }
    const a = arg orelse return;
    object_dir = os.realPath(a) orelse util.dieErrno("Invalid path '{s}'", .{a});
}

const common_opts = [_]po.Opt{
    po.callback(0, "object-dir", cbObjectDir, "directory", "object directory containing set of packfile and pack-index pairs"),
    po.bit(0, "progress", &flags, @intCast(midx.PROGRESS), "force progress reporting"),
};

fn withCommon(comptime extra: []const po.Opt) [extra.len + common_opts.len]po.Opt {
    var out: [extra.len + common_opts.len]po.Opt = undefined;
    for (common_opts, 0..) |o, i| out[i] = o;
    for (extra, 0..) |o, i| out[common_opts.len + i] = o;
    return out;
}

/// handle_object_dir_option(): match against the repository's sources.
fn findSource() []const u8 {
    const dirs = repo_mod.repo().odb().allDirs();
    const want = object_dir orelse return dirs[0];
    const rw = os.realPath(want) orelse want;
    for (dirs) |d| {
        if (util.eql(d, want)) return d;
        if (os.realPath(d)) |rd| {
            if (util.eql(rw, rd)) return d;
        }
    }
    util.die("object directory is not an alternate of the current repository: '{s}'", .{want});
}

fn uflags() u32 {
    return @bitCast(flags);
}

fn loadWriteConfig() void {
    if (repo_mod.cfg.get("pack.writebitmaphashcache")) |v| {
        if (config.configBool("pack.writebitmaphashcache", v)) flags |= @intCast(midx.WRITE_BITMAP_HASH_CACHE) else flags &= ~@as(i32, @intCast(midx.WRITE_BITMAP_HASH_CACHE));
    }
    if (repo_mod.cfg.get("pack.writebitmaplookuptable")) |v| {
        if (config.configBool("pack.writebitmaplookuptable", v)) flags |= @intCast(midx.WRITE_BITMAP_LOOKUP_TABLE) else flags &= ~@as(i32, @intCast(midx.WRITE_BITMAP_LOOKUP_TABLE));
    }
}

fn exitCode(r: i32) u8 {
    return @truncate(@as(u32, @bitCast(r)));
}

fn readPacksFromStdin() [][]const u8 {
    const data = os.readAllFd(0) catch return &.{};
    var out: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |l0| {
        var l = l0;
        if (it.peek() == null and l.len == 0) break;
        if (l.len > 0 and l[l.len - 1] == '\r') l = l[0 .. l.len - 1];
        out.append(gpa, l) catch util.oom();
    }
    util.sortStrings(out.items);
    return out.items;
}

fn cmdWrite(args: []const []const u8) u8 {
    const opts = comptime withCommon(&.{
        po.string(0, "preferred-pack", &preferred_pack, "preferred-pack", "pack for reuse when computing a multi-pack bitmap"),
        po.bit(0, "bitmap", &flags, @intCast(midx.WRITE_BITMAP | midx.WRITE_REV_INDEX), "write multi-pack bitmap"),
        po.string(0, "base", &incremental_base, "checksum", "base MIDX for incremental writes"),
        po.bit(0, "incremental", &flags, @intCast(midx.WRITE_INCREMENTAL), "write a new incremental MIDX"),
        .{ .long = "write-chain-file", .kind = .negbit, .i = &flags, .val = @intCast(midx.WRITE_NO_CHAIN), .help = "write the multi-pack-index chain file" },
        po.boolean(0, "stdin-packs", &stdin_packs, "write multi-pack index containing only given indexes"),
        po.filename(0, "refs-snapshot", &refs_snapshot, "file", "refs snapshot for selecting bitmap commits"),
    });
    flags |= @intCast(midx.WRITE_BITMAP_HASH_CACHE);
    loadWriteConfig();
    if (os.isatty(2)) flags |= @intCast(midx.PROGRESS);
    const rest = po.parse(args[1..], &opts, &write_usage, .{});
    if (rest.len > 0) po.usageWithOptions(&write_usage, &opts);
    const f = uflags();
    if (f & midx.WRITE_NO_CHAIN != 0 and f & midx.WRITE_INCREMENTAL == 0) {
        util.err("cannot use {s} without {s}", .{ "--no-write-chain-file", "--incremental" });
        po.usageWithOptions(&write_usage, &opts);
    }
    if (incremental_base != null and f & midx.WRITE_NO_CHAIN == 0) {
        util.err("cannot use --base without --no-write-chain-file", .{});
        po.usageWithOptions(&write_usage, &opts);
    }
    const source = findSource();
    var o = midx.WriteOpts{
        .source = source,
        .preferred_pack_name = preferred_pack,
        .refs_snapshot = refs_snapshot,
        .flags = f,
    };
    if (stdin_packs) {
        o.packs_to_include = readPacksFromStdin();
        o.incremental_base = incremental_base;
    }
    return exitCode(midx.writeInternal(&o));
}

fn cmdCompact(args: []const []const u8) u8 {
    const opts = comptime withCommon(&.{
        po.string(0, "base", &incremental_base, "checksum", "base MIDX for incremental writes"),
        po.bit(0, "bitmap", &flags, @intCast(midx.WRITE_BITMAP | midx.WRITE_REV_INDEX), "write multi-pack bitmap"),
        po.bit(0, "incremental", &flags, @intCast(midx.WRITE_INCREMENTAL), "write a new incremental MIDX"),
        .{ .long = "write-chain-file", .kind = .negbit, .i = &flags, .val = @intCast(midx.WRITE_NO_CHAIN), .help = "write the multi-pack-index chain file" },
    });
    loadWriteConfig();
    if (os.isatty(2)) flags |= @intCast(midx.PROGRESS);
    const rest = po.parse(args[1..], &opts, &compact_usage, .{});
    if (rest.len != 2) po.usageWithOptions(&compact_usage, &opts);
    const f = uflags();
    if (f & midx.WRITE_NO_CHAIN != 0 and f & midx.WRITE_INCREMENTAL == 0) {
        util.err("cannot use {s} without {s}", .{ "--no-write-chain-file", "--incremental" });
        po.usageWithOptions(&compact_usage, &opts);
    }
    const source = findSource();
    var from: ?*midx.Midx = null;
    var to: ?*midx.Midx = null;
    var cur = midx.get(source);
    while (cur) |c| : (cur = c.base) {
        if (from != null and to != null) break;
        const cs = c.checksumHex();
        if (from == null and util.eql(cs, rest[0])) from = c;
        if (to == null and util.eql(cs, rest[1])) to = c;
    }
    const fm = from orelse util.die("could not find MIDX: {s}", .{rest[0]});
    const tm = to orelse util.die("could not find MIDX: {s}", .{rest[1]});
    if (fm == tm) util.die("MIDX compaction endpoints must be unique", .{});
    var m: ?*midx.Midx = fm;
    while (m) |x| : (m = x.base) {
        if (x == tm) util.die("MIDX {s} must be an ancestor of {s}", .{ rest[0], rest[1] });
    }
    const o = midx.WriteOpts{
        .source = source,
        .compact_from = fm,
        .compact_to = tm,
        .incremental_base = incremental_base,
        .flags = f | midx.WRITE_COMPACT,
    };
    return exitCode(midx.writeInternal(&o));
}

fn cmdVerify(args: []const []const u8) u8 {
    const opts = comptime withCommon(&.{});
    if (os.isatty(2)) flags |= @intCast(midx.PROGRESS);
    const rest = po.parse(args[1..], &opts, &verify_usage, .{});
    if (rest.len > 0) po.usageWithOptions(&verify_usage, &opts);
    return midx.verify(findSource(), uflags());
}

fn cmdExpire(args: []const []const u8) u8 {
    const opts = comptime withCommon(&.{});
    if (os.isatty(2)) flags |= @intCast(midx.PROGRESS);
    const rest = po.parse(args[1..], &opts, &expire_usage, .{});
    if (rest.len > 0) po.usageWithOptions(&expire_usage, &opts);
    return exitCode(midx.expire(findSource(), uflags()));
}

fn cmdRepack(args: []const []const u8) u8 {
    const opts = comptime withCommon(&.{
        .{ .long = "batch-size", .kind = .uint, .i = &batch_size, .argh = "n", .help = "during repack, collect pack-files of smaller size into a batch that is larger than this size" },
    });
    if (os.isatty(2)) flags |= @intCast(midx.PROGRESS);
    const rest = po.parse(args[1..], &opts, &repack_usage, .{});
    if (rest.len > 0) po.usageWithOptions(&repack_usage, &opts);
    const bs: u64 = if (batch_size > 0) @intCast(batch_size) else 0;
    return exitCode(midx.repack(findSource(), bs, uflags()));
}

pub fn cmdMultiPackIndex(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").multi_pack_index);
    odb_mod.disableReplaceRefs();
    object_dir = repo_mod.repo().odb().allDirs()[0];
    const rest = po.parse(args[1..], &common_opts, &main_usage, .{ .stop_at_non_option = true });
    if (rest.len == 0) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&main_usage, &common_opts);
    }
    const sub = rest[0];
    if (util.eql(sub, "repack")) return cmdRepack(rest);
    if (util.eql(sub, "write")) return cmdWrite(rest);
    if (util.eql(sub, "compact")) return cmdCompact(rest);
    if (util.eql(sub, "verify")) return cmdVerify(rest);
    if (util.eql(sub, "expire")) return cmdExpire(rest);
    util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&main_usage, &common_opts);
}
