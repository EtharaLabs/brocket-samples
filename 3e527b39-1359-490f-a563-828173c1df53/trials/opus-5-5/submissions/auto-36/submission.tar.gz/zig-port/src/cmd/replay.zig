//! git replay (builtin/replay.c + replay.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const revision = @import("../revision.zig");
const cn = @import("../commitnode.zig");
const mo = @import("../merge_ort.zig");
const commit_mod = @import("../commit.zig");
const pretty = @import("../pretty.zig");
const seq = @import("../sequencer.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Commit = cn.Commit;

const RefMode = enum { update, print };

fn parseRefActionMode(v: []const u8, source: []const u8) RefMode {
    if (util.eql(v, "update")) return .update;
    if (util.eql(v, "print")) return .print;
    util.die("invalid {s} value: '{s}'", .{ source, v });
}

const usage = [_][]const u8{"(EXPERIMENTAL!) git replay ([--contained] --onto=<newbase> | --advance=<branch> | --revert=<branch>)\n" ++
    "[--ref=<ref>] [--ref-action=<mode>] [--linearize] <revision-range>"};

const Mode = enum { pick, revert };

pub const Update = struct { refname: []const u8, old: Oid, new: Oid };

fn incompatible(names: []const []const u8, set: []const bool) void {
    var on: std.ArrayList([]const u8) = .empty;
    for (names, set) |n, s| {
        if (s) on.append(gpa, n) catch util.oom();
    }
    if (on.items.len == 3) util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ on.items[0], on.items[1], on.items[2] });
    if (on.items.len == 2) util.die("options '{s}' and '{s}' cannot be used together", .{ on.items[0], on.items[1] });
}

fn shortName(c: *Commit) []const u8 {
    return revparse.abbrev(c.oid(), 0);
}

fn peelCommittish(name: []const u8, mode: []const u8) *Commit {
    const oid = revparse.getOid(name) orelse util.die("'{s}' is not a valid commit-ish for {s}", .{ name, mode });
    if (cn.parseObject(oid) == null) util.die("unable to parse object: {s}", .{name});
    const c = cn.lookupCommitReference(oid) orelse util.die("'{s}' does not point to a commit for {s}", .{ name, mode });
    _ = cn.parse(c);
    return c;
}

/// repo_dwim_ref() == 1: the full name if it uniquely resolves.
fn dwimUnique(name: []const u8) ?[]const u8 {
    const r = refs.dwimRef(name) orelse return null;
    if (r.count != 1) return null;
    if (refs.resolve(r.name)) |res| return res.name;
    return r.name;
}

fn contains(list: []const []const u8, s: []const u8) bool {
    for (list) |x| {
        if (util.eql(x, s)) return true;
    }
    return false;
}

fn treeOf(c: *Commit) Oid {
    _ = cn.parse(c);
    return c.tree;
}

fn extraHeaders(c: *Commit) []const u8 {
    _ = cn.parse(c);
    const buf = c.buffer;
    var b: util.Buf = .empty;
    var pos: usize = 0;
    var keep = false;
    while (pos < buf.len) {
        const eol = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse buf.len;
        const line = buf[pos..eol];
        if (line.len == 0) break;
        if (line[0] == ' ') {
            if (keep) {
                util.bufAppend(&b, line);
                util.bufByte(&b, '\n');
            }
        } else {
            const sp = std.mem.indexOfScalar(u8, line, ' ') orelse line.len;
            const key = line[0..sp];
            keep = !(util.eql(key, "tree") or util.eql(key, "parent") or util.eql(key, "author") or
                util.eql(key, "committer") or util.eql(key, "encoding") or util.eql(key, "gpgsig") or
                util.eql(key, "gpgsig-sha256"));
            if (keep) {
                util.bufAppend(&b, line);
                util.bufByte(&b, '\n');
            }
        }
        pos = eol + 1;
    }
    return b.items;
}

fn createCommit(tree: Oid, based_on: *Commit, parent: *Commit, mode: Mode) ?*Commit {
    const out_enc = commit_mod.commitEncoding() orelse "UTF-8";
    const message = pretty.logmsgReencode(based_on, out_enc).msg;
    var msg: util.Buf = .empty;
    var author: ?[]const u8 = null;
    switch (mode) {
        .revert => {
            const s = seq.findCommitSubject(message);
            const subject = s.rest[0..s.len];
            const p: ?*Commit = if (based_on.parents) |pl| pl.item else null;
            seq.formatRevertMessage(subject, based_on, p, false, &msg);
        },
        .pick => {
            util.bufAppend(&msg, seq.findCommitSubject(message).rest);
            author = cn.findHeader(message, "author");
        },
    }
    const oid = commit_mod.create(.{
        .tree = tree,
        .parents = &.{parent.oid()},
        .message = msg.items,
        .author = author,
        .extra_headers = extraHeaders(based_on),
    });
    const c = cn.lookupCommit(oid) orelse {
        util.err("failed to write commit object", .{});
        return null;
    };
    _ = cn.parse(c);
    return c;
}

const PickOut = struct { commit: ?*Commit, clean: i32 };

fn pickRegularCommit(pickme: *Commit, replayed_base: *Commit, mode: Mode, empty: Empty) PickOut {
    _ = cn.parse(pickme);
    const base_tree: Oid = if (pickme.parents) |p| treeOf(p.item) else hash.fromHex(hash.empty_tree_hex).?;
    const replayed_base_tree = treeOf(replayed_base);
    const pickme_tree = treeOf(pickme);
    var o = mo.initMergeOptions(false);
    o.show_rename_progress = false;
    var result = mo.Result{};
    switch (mode) {
        .pick => {
            o.branch1 = shortName(replayed_base);
            o.branch2 = shortName(pickme);
            o.ancestor = if (pickme.parents != null) util.fmt("parent of {s}", .{o.branch2}) else "empty tree";
            mo.mergeIncoreNonrecursive(&o, base_tree, replayed_base_tree, pickme_tree, &result);
        },
        .revert => {
            const pickme_name = shortName(pickme);
            o.branch1 = shortName(replayed_base);
            o.branch2 = util.fmt("parent of {s}", .{pickme_name});
            o.ancestor = pickme_name;
            mo.mergeIncoreNonrecursive(&o, pickme_tree, replayed_base_tree, base_tree, &result);
        },
    }
    if (result.clean < 0) {
        util.err("merge of {s} onto {s} failed", .{ hash.hex(pickme.oid()), hash.hex(replayed_base.oid()) });
        return .{ .commit = null, .clean = -1 };
    }
    if (result.clean == 0) return .{ .commit = null, .clean = 0 };
    // commits that become empty
    if (std.mem.eql(u8, &replayed_base_tree, &result.tree) and !std.mem.eql(u8, &pickme_tree, &base_tree)) {
        switch (empty) {
            .drop => return .{ .commit = replayed_base, .clean = 1 },
            .keep => {},
            .abort => {
                util.err("commit {s} became empty after replay", .{hash.hex(pickme.oid())});
                return .{ .commit = null, .clean = -1 };
            },
        }
    }
    const c = createCommit(result.tree, pickme, replayed_base, mode) orelse return .{ .commit = null, .clean = 1 };
    return .{ .commit = c, .clean = 1 };
}

pub const Empty = enum { drop, keep, abort };

pub const Opts = struct {
    empty: Empty = .drop,
    advance: ?[]const u8 = null,
    onto: ?[]const u8 = null,
    ref: ?[]const u8 = null,
    revert: ?[]const u8 = null,
    contained: bool = false,
    linearize: bool = false,
};

/// replay_revisions(): 0 on success, 1 on conflict, negative on error.
pub fn replayRevisions(revs: *revision.RevInfo, opts: *const Opts, out: *std.ArrayList(Update)) i32 {
    const mode: Mode = if (opts.revert != null) .revert else .pick;
    var advance = opts.advance;
    var revert = opts.revert;

    // set_up_replay_mode()
    const detached_head = switch (refs.readRawFull("HEAD")) {
        .symref => false,
        else => true,
    };
    var positive_refs: std.ArrayList([]const u8) = .empty;
    var positive_exprs: usize = 0;
    for (revs.cmdline.items) |e| {
        var expr = e.name;
        if (expr.len > 0 and expr[0] == '^') expr = expr[1..];
        const full = dwimUnique(expr);
        if (e.flags & cn.BOTTOM != 0) continue;
        if (full) |f| {
            if (!contains(positive_refs.items, f)) positive_refs.append(gpa, f) catch util.oom();
        }
        positive_exprs += 1;
    }
    if (positive_exprs == 0) util.die("need some commits to replay", .{});
    var onto: *Commit = undefined;
    var update_refs: ?[]const []const u8 = null;
    if (opts.onto) |on| {
        onto = peelCommittish(on, "--onto");
        if (positive_exprs < positive_refs.items.len) util.die("all positive revisions given must be references", .{});
        update_refs = positive_refs.items;
    } else {
        const opt_name = if (advance != null) "--advance" else "--revert";
        const bn = (advance orelse revert).?;
        const full = dwimUnique(bn) orelse util.die("argument to {s} must be a reference", .{opt_name});
        if (advance != null) advance = full else revert = full;
        onto = peelCommittish(full, opt_name);
        if (positive_exprs > 1)
            util.die("'{s}' cannot be used with multiple revision ranges because the ordering would be ill-defined", .{opt_name});
    }

    if (opts.linearize and update_refs != null and update_refs.?.len > 1) {
        util.err("'--linearize' cannot be used with multiple branches", .{});
        return -1;
    }

    var ref: ?[]const u8 = null;
    var old_oid: Oid = hash.zero;
    if (opts.ref) |r| {
        if (update_refs != null and update_refs.?.len > 1) {
            util.err("'--ref' cannot be used with multiple revision ranges", .{});
            return -1;
        }
        if (!refs.checkRefnameFormat(r, 0) or !util.startsWith(r, "refs/")) {
            util.err("'{s}' is not a valid refname", .{r});
            return -1;
        }
        ref = r;
        old_oid = refs.readOid(r) orelse hash.zero;
    } else {
        ref = advance orelse revert;
        old_oid = onto.oid();
    }

    if (!revision.prepareRevisionWalk(revs)) {
        util.err("error preparing revisions", .{});
        return -1;
    }

    // ref decorations: refs/heads/* (and HEAD when detached), in the
    // order get_name_decoration() reports them.
    var deco = std.AutoHashMap(Oid, std.ArrayList([]const u8)).init(gpa);
    if (ref == null) {
        const all = refs.iterate("refs/heads/", .{ .check_objects = false });
        var i = all.len;
        while (i > 0) {
            i -= 1;
            const gop = deco.getOrPut(all[i].oid) catch util.oom();
            if (!gop.found_existing) gop.value_ptr.* = .empty;
            gop.value_ptr.append(gpa, all[i].name) catch util.oom();
        }
        if (detached_head) {
            if (refs.readOid("HEAD")) |h| {
                const gop = deco.getOrPut(h) catch util.oom();
                if (!gop.found_existing) gop.value_ptr.* = .empty;
                gop.value_ptr.insert(gpa, 0, "HEAD") catch util.oom();
            }
        }
    }

    var last_commit: ?*Commit = onto;
    var replayed = std.AutoHashMap(Oid, *Commit).init(gpa);
    var clean: i32 = 1;
    while (revision.getRevision(revs)) |commit| {
        _ = cn.parse(commit);
        const is_merge = if (commit.parents) |p| p.next != null else false;
        if (is_merge) {
            if (!opts.linearize) util.die("replaying merge commits is not supported yet!", .{});
        } else {
            const parent: ?*Commit = if (commit.parents) |p| p.item else null;
            var base: *Commit = onto;
            if (parent) |p| {
                if (replayed.get(p.oid())) |m| base = m;
            }
            if (opts.linearize or mode == .revert) base = last_commit.?;
            const r = pickRegularCommit(commit, base, mode, opts.empty);
            clean = r.clean;
            last_commit = r.commit;
        }
        const lc = last_commit orelse break;
        const gop = replayed.getOrPut(commit.oid()) catch util.oom();
        if (gop.found_existing) util.die("BUG: Duplicate rewritten commit: {s}", .{hash.hex(commit.oid())});
        gop.value_ptr.* = lc;
        if (ref != null) continue;
        if (deco.get(commit.oid())) |names| {
            for (names.items) |n| {
                if (!opts.contained and !contains(update_refs orelse &.{}, n)) continue;
                out.append(gpa, .{ .refname = n, .old = commit.oid(), .new = lc.oid() }) catch util.oom();
            }
        }
    }
    if (clean < 0) return -1;
    if (clean == 0) return 1;
    if (last_commit == null) return -1;
    if (ref) |r| out.append(gpa, .{ .refname = r, .old = old_oid, .new = last_commit.?.oid() }) catch util.oom();
    return 0;
}

const forced_warning = "some rev walking options will be overridden as '{s}' bit in 'struct rev_info' will be forced";

pub fn cmdReplay(args: []const []const u8) u8 {
    var opts = Opts{};
    var ref_action: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.boolean(0, "contained", &opts.contained, "update all branches that point at commits in <revision-range>"),
        .{ .long = "onto", .kind = .string, .s = &opts.onto, .argh = "revision", .noneg = true, .help = "replay onto given commit" },
        .{ .long = "advance", .kind = .string, .s = &opts.advance, .argh = "branch", .noneg = true, .help = "make replay advance given branch" },
        .{ .long = "revert", .kind = .string, .s = &opts.revert, .argh = "branch", .noneg = true, .help = "revert commits onto given branch" },
        .{ .long = "ref", .kind = .string, .s = &opts.ref, .argh = "branch", .noneg = true, .help = "reference to update with result" },
        .{ .long = "ref-action", .kind = .string, .s = &ref_action, .argh = "mode", .noneg = true, .help = "control ref update behavior (update|print)" },
        po.boolean(0, "linearize", &opts.linearize, "drop merge commits, replaying only non-merge commits"),
    };
    const rest = po.parse(args[1..], &options, &usage, .{ .keep_unknown = true });

    if (opts.onto == null and opts.advance == null and opts.revert == null) {
        util.err("exactly one of --onto, --advance, or --revert is required", .{});
        po.usageWithOptions(&usage, &options);
    }
    incompatible(&.{ "--onto", "--advance", "--revert" }, &.{ opts.onto != null, opts.advance != null, opts.revert != null });
    incompatible(&.{ "--advance", "--contained" }, &.{ opts.advance != null, opts.contained });
    incompatible(&.{ "--revert", "--contained" }, &.{ opts.revert != null, opts.contained });
    incompatible(&.{ "--ref", "--contained" }, &.{ opts.ref != null, opts.contained });
    incompatible(&.{ "--linearize", "--contained" }, &.{ opts.linearize, opts.contained });

    var ref_mode: RefMode = .update;
    if (ref_action) |ra| {
        ref_mode = parseRefActionMode(ra, "--ref-action");
    } else if (repo_mod.cfg.get("replay.refaction")) |v| {
        ref_mode = parseRefActionMode(v, "replay.refAction");
    }

    const desired_reverse = opts.revert == null;
    const revs = gpa.create(revision.RevInfo) catch util.oom();
    revs.* = revision.RevInfo.init(repo_mod.repo().prefix);
    revs.reverse = desired_reverse;
    revs.sort_order = .graph;
    revs.topo_order = true;
    revs.simplify_history = false;

    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "replay") catch util.oom();
    argv.appendSlice(gpa, rest) catch util.oom();
    const left = revision.setupRevisions(revs, argv.items, .{});
    if (left.len > 1) {
        util.err("unrecognized argument: {s}", .{left[1]});
        os.exit(128);
    }
    if (revs.reverse != desired_reverse) {
        util.warn(forced_warning, .{"reverse"});
        revs.reverse = desired_reverse;
    }
    if (revs.sort_order != .graph) {
        util.warn(forced_warning, .{"sort_order"});
        revs.sort_order = .graph;
    }
    if (!revs.topo_order) {
        util.warn(forced_warning, .{"topo_order"});
        revs.topo_order = true;
    }
    if (revs.simplify_history) {
        util.warn(forced_warning, .{"simplify_history"});
        revs.simplify_history = false;
    }

    var updates: std.ArrayList(Update) = .empty;
    const ret = replayRevisions(revs, &opts, &updates);
    if (ret < 0) os.exit(128);
    if (ret != 0) return @intCast(ret);

    var reflog_msg: []const u8 = undefined;
    if (opts.revert) |r| {
        reflog_msg = util.concat(&.{ "replay --revert ", r });
    } else if (opts.advance) |a| {
        reflog_msg = util.concat(&.{ "replay --advance ", a });
    } else {
        const oid = revparse.getOidCommittish(opts.onto.?) orelse util.die("BUG: --onto commit should have been resolved beforehand already", .{});
        reflog_msg = util.concat(&.{ "replay --onto ", &hash.hex(oid) });
    }

    switch (ref_mode) {
        .print => {
            for (updates.items) |u| util.outf("update {s} {s} {s}\n", .{ u.refname, hash.hex(u.new), hash.hex(u.old) });
        },
        .update => {
            const tx = refs.Transaction.init();
            for (updates.items) |u| {
                if (tx.update(u.refname, u.new, u.old, null, null, 0, reflog_msg) != .ok) {
                    util.err("failed to update ref '{s}': {s}", .{ u.refname, tx.errMsg() });
                    os.exit(128);
                }
            }
            if (tx.commit() != .ok) {
                util.err("failed to commit ref transaction: {s}", .{tx.errMsg()});
                os.exit(128);
            }
        },
    }
    return 0;
}
