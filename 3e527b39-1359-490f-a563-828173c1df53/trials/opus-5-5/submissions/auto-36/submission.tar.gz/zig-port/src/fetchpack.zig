//! Client side of the pack fetch protocol (subset of fetch-pack.c):
//! negotiate with upload-pack (v0 or v2) and store the received pack via
//! index-pack / unpack-objects subprocesses.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const hash = @import("hash.zig");
const pkt = @import("pktline.zig");
const proc = @import("proc.zig");
const objects = @import("objects.zig");
const transport = @import("transport.zig");
const fsck = @import("fsck.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Transport = transport.Transport;
const Ref = transport.Ref;

const cn = @import("commitnode.zig");
const negotiator = @import("negotiator.zig");
const t2 = @import("trace2.zig");

/// fetch_pack_fsck_objects()
fn fetchFsckObjects() bool {
    const cfg = repo_mod.cfg;
    if (cfg.getBool("fetch.fsckobjects")) |b| return b;
    if (cfg.getBool("transfer.fsckobjects")) |b| return b;
    return false;
}

/// fetch_pack_fsck_config(): fetch.fsck.* -> "=id=type,skiplist=path"
fn fetchFsckMsgTypes() []const u8 {
    const config = @import("config.zig");
    var out: util.Buf = .empty;
    for (repo_mod.cfg.entries.items) |e| {
        const sep: u8 = if (out.items.len > 0) ',' else '=';
        if (util.eql(e.key, "fetch.fsck.skiplist")) {
            switch (config.configPathname(e.key, e.value)) {
                .ok => |p| if (p) |path| util.bufPrint(&out, "{c}skiplist={s}", .{ sep, path }),
                .err => fsck.dieConfig(e),
            }
            continue;
        }
        if (util.skipPrefix(e.key, "fetch.fsck.")) |id| {
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                fsck.dieConfig(e);
            };
            if (fsck.parseMsgId(id) != null) {
                if (!util.eql(v, "error") and !util.eql(v, "warn") and !util.eql(v, "ignore"))
                    util.die("Unknown fsck message type: '{s}'", .{v});
                util.bufPrint(&out, "{c}{s}={s}", .{ sep, id, v });
            } else util.warn("Skipping unknown msg id '{s}'", .{id});
        }
    }
    return out.items;
}

fn printMissingGitmodules(o: *fsck.Options, oid: ?Oid, typ: @import("odb.zig").ObjType, mt: fsck.MsgType, id: fsck.MsgId, msg: []const u8) i32 {
    if (id == .gitmodules_missing) {
        if (oid) |x| util.outf("{s}\n", .{&hash.hex(x)});
        return 0;
    }
    return fsck.objectsErrorFunction(o, oid, typ, mt, id, msg);
}

fn unpackLimit() u32 {
    const cfg = repo_mod.cfg;
    if (cfg.get("fetch.unpacklimit")) |v| {
        if (util.parseInt(u32, v)) |n| return n;
    }
    if (cfg.get("transfer.unpacklimit")) |v| {
        if (util.parseInt(u32, v)) |n| return n;
    }
    return 100;
}

// ---------------- negotiation (fetch-pack.c) ----------------

/// fetch-pack.c COMPLETE (a private bit here so that leftover walk flags
/// from in-process revision walks cannot be mistaken for it)
const COMPLETE: u32 = 1 << 30;
/// bits used by the negotiators (negotiator/default.c, skipping.c)
const NEGOTIATOR_FLAGS: u32 = 0xf << 2;
const INITIAL_FLUSH: usize = 16;
const PIPESAFE_FLUSH: usize = 32;
const LARGE_FLUSH: usize = 16384;
const MAX_IN_VAIN: usize = 256;

fn nextFlush(stateless: bool, count: usize) usize {
    if (stateless) {
        if (count < LARGE_FLUSH) return count << 1;
        return count * 11 / 10;
    }
    if (count < PIPESAFE_FLUSH) return count << 1;
    return count + PIPESAFE_FLUSH;
}

var verbose_out = false;

fn printVerbose(comptime f: []const u8, args: anytype) void {
    if (!verbose_out) return;
    util.ewrite(util.fmt(f ++ "\n", args));
}

/// deref_without_lazy_fetch()
fn derefNoFetch(oid0: Oid, mark_tags_complete: bool) ?*cn.Commit {
    var oid = oid0;
    var depth: u32 = 0;
    while (true) : (depth += 1) {
        const typ = cn.objType(oid) orelse return null;
        if (typ == .tag) {
            if (depth > 1000) return null;
            if (mark_tags_complete) {
                if (cn.lookup(oid, .tag)) |o| o.flags |= COMPLETE;
            }
            const data = repo_mod.repo().odb().read(oid) orelse return null;
            const tg = objects.parseTag(data.data) orelse return null;
            oid = tg.object;
            continue;
        }
        if (typ != .commit) return null;
        const c = cn.lookupCommit(oid) orelse return null;
        if (!cn.parse(c)) return null;
        return c;
    }
}

var complete_queue: cn.PrioQueue = .{ .compare = cn.compareByCommitDate };

fn markComplete(oid: Oid) void {
    const c = derefNoFetch(oid, true) orelse return;
    if (c.obj.flags & COMPLETE != 0) return;
    c.obj.flags |= COMPLETE;
    complete_queue.put(c);
}

fn isCompleteObj(oid: Oid) bool {
    const o = cn.lookupAny(oid) orelse return false;
    return o.flags & COMPLETE != 0;
}

fn localRefs() []refs.Ref {
    return refs.iterate("refs/", .{ .include_broken = true, .check_objects = false });
}

/// mark_complete_and_common_ref()
fn markCompleteAndCommonRef(neg: *negotiator.Negotiator, t: *Transport, all_refs: []const *Ref) void {
    if (t.refetch) return;
    var cutoff: u64 = 0;
    const odb = repo_mod.repo().odb();
    t2.regionEnter("fetch-pack", "parse_remote_refs_and_find_cutoff", false);
    for (all_refs) |r| {
        if (!odb.has(r.old_oid)) continue;
        const o = cn.parseObject(r.old_oid) orelse continue;
        if (o.typ != .commit) continue;
        const c = cn.Commit.fromObj(o);
        if (cutoff == 0 or cutoff < c.date) cutoff = c.date;
    }
    t2.regionLeave("fetch-pack", "parse_remote_refs_and_find_cutoff", false);
    t2.regionEnter("fetch-pack", "mark_complete_local_refs", false);
    if (!t.deepen) {
        for (localRefs()) |r| {
            if (hash.isZero(r.oid)) continue;
            markComplete(r.oid);
        }
        if (cutoff != 0) {
            while (complete_queue.peek()) |item| {
                if (item.date < cutoff) break;
                printVerbose("Marking {s} as complete", .{hash.hex(item.obj.oid)});
                _ = cn.popMostRecentCommit(&complete_queue, COMPLETE);
            }
        }
    }
    t2.regionLeave("fetch-pack", "mark_complete_local_refs", false);
    t2.regionEnter("fetch-pack", "mark_common_remote_refs", false);
    for (all_refs) |r| {
        const c = derefNoFetch(r.old_oid, false) orelse continue;
        if (c.obj.flags & COMPLETE == 0) continue;
        neg.knownCommon(c);
    }
    t2.regionLeave("fetch-pack", "mark_common_remote_refs", false);
}

/// mark_tips()
fn markTips(neg: *negotiator.Negotiator, restrict: ?[]const Oid) void {
    if (restrict) |tips| {
        for (tips) |o| {
            if (derefNoFetch(o, false)) |c| neg.addTip(c);
        }
        return;
    }
    for (localRefs()) |r| {
        if (hash.isZero(r.oid)) continue;
        if (derefNoFetch(r.oid, false)) |c| neg.addTip(c);
    }
}

/// everything_local()
fn everythingLocal(wants: []const *Ref) bool {
    var ret = true;
    for (wants) |r| {
        if (!isCompleteObj(r.old_oid)) {
            ret = false;
            printVerbose("want {s} ({s})", .{ hash.hex(r.old_oid), r.name });
            continue;
        }
        printVerbose("already have {s} ({s})", .{ hash.hex(r.old_oid), r.name });
    }
    return ret;
}

fn isOidName(r: *const Ref) bool {
    if (r.name.len != 40) return false;
    const o = hash.fromHex(r.name) orelse return false;
    return hash.eql(o, r.old_oid);
}

/// The wanted refs as filter_refs() leaves them: named refs sorted by name
/// (one per name), then requests for exact object names.
fn wantedRefs(sought: []const *Ref) []*Ref {
    var named: std.ArrayList(*Ref) = .empty;
    var exact: std.ArrayList(*Ref) = .empty;
    for (sought) |r| {
        if (isOidName(r)) {
            exact.append(gpa, @constCast(r)) catch util.oom();
        } else named.append(gpa, @constCast(r)) catch util.oom();
    }
    std.mem.sort(*Ref, named.items, {}, struct {
        fn lt(_: void, a: *Ref, b: *Ref) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    var out: std.ArrayList(*Ref) = .empty;
    for (named.items, 0..) |r, i| {
        if (i > 0 and util.eql(named.items[i - 1].name, r.name)) continue;
        out.append(gpa, r) catch util.oom();
    }
    out.appendSlice(gpa, exact.items) catch util.oom();
    return out.items;
}

/// add_oids_to_set(): --negotiation-include tips, deduplicated
/// Iteration order of a C `struct oidset` (khash, oidhash = first 4 bytes)
/// after inserting `list` in order; duplicates are dropped.
pub fn oidsetOrder(list: []const Oid) []Oid {
    const Slot = struct { key: Oid = hash.zero, state: u8 = 0 }; // 0 empty, 1 used, 2 deleted
    var slots: []Slot = &.{};
    var n_buckets: u32 = 0;
    var size: u32 = 0;
    var upper: u32 = 0;
    const H = struct {
        fn h(o: Oid) u32 {
            return std.mem.readInt(u32, o[0..4], .little);
        }
    };
    for (list) |key| {
        if (size >= upper) {
            // kh_resize(h, n_buckets + 1)
            var nb: u32 = std.math.ceilPowerOfTwo(u32, n_buckets + 1) catch unreachable;
            if (nb < 4) nb = 4;
            const new_used = gpa.alloc(bool, nb) catch util.oom();
            @memset(new_used, false);
            const ns = gpa.alloc(Slot, nb) catch util.oom();
            for (ns, 0..) |*s, ix| s.* = if (ix < slots.len) slots[ix] else .{};
            var j: u32 = 0;
            while (j < n_buckets) : (j += 1) {
                if (ns[j].state != 1) continue;
                var k = ns[j].key;
                ns[j].state = 2;
                while (true) {
                    var step: u32 = 0;
                    var i = H.h(k) & (nb - 1);
                    while (new_used[i]) {
                        step += 1;
                        i = (i +% step) & (nb - 1);
                    }
                    new_used[i] = true;
                    if (i < n_buckets and ns[i].state == 1) {
                        const tmp = ns[i].key;
                        ns[i].key = k;
                        k = tmp;
                        ns[i].state = 2;
                    } else {
                        ns[i].key = k;
                        break;
                    }
                }
            }
            for (ns, new_used) |*s, u| s.state = if (u) 1 else 0;
            slots = ns;
            n_buckets = nb;
            upper = @intFromFloat(@as(f64, @floatFromInt(nb)) * 0.77 + 0.5);
        }
        const mask = n_buckets - 1;
        var i = H.h(key) & mask;
        var step: u32 = 0;
        while (slots[i].state != 0 and !hash.eql(slots[i].key, key)) {
            step += 1;
            i = (i +% step) & mask;
        }
        if (slots[i].state == 0) {
            slots[i] = .{ .key = key, .state = 1 };
            size += 1;
        }
    }
    var out: std.ArrayList(Oid) = .empty;
    for (slots) |s| if (s.state == 1) out.append(gpa, s.key) catch util.oom();
    return out.items;
}

fn includeOids(list: []const Oid) []Oid {
    const odb = repo_mod.repo().odb();
    for (list) |o| {
        if (!odb.has(o)) util.die("the object {s} does not exist", .{hash.hex(o)});
    }
    return oidsetOrder(list);
}

fn initNegotiator(t: *Transport) negotiator.Negotiator {
    cn.clearAllObjectFlags(COMPLETE);
    complete_queue.clear();
    if (t.refetch) return negotiator.Negotiator.init(.noop);
    return negotiator.Negotiator.init(negotiator.configuredAlgorithm());
}

const AckType = enum { nak, ack, ack_continue, ack_common, ack_ready };

/// get_ack()
fn getAck(rd: *pkt.Reader, result: *Oid) AckType {
    if (rd.read() != .normal) util.die("git fetch-pack: expected ACK/NAK, got a flush packet", .{});
    const line = rd.line;
    if (util.eql(line, "NAK")) return .nak;
    if (util.skipPrefix(line, "ACK ")) |arg| {
        if (arg.len >= 40) {
            if (hash.fromHex(arg[0..40])) |o| {
                result.* = o;
                const p = arg[40..];
                if (p.len < 1) return .ack;
                if (std.mem.indexOf(u8, p, "continue") != null) return .ack_continue;
                if (std.mem.indexOf(u8, p, "common") != null) return .ack_common;
                if (std.mem.indexOf(u8, p, "ready") != null) return .ack_ready;
                return .ack;
            }
        }
    }
    util.die("git fetch-pack: expected ACK/NAK, got '{s}'", .{line});
}

/// send_request()
fn sendRequest(t: *Transport, buf: []const u8) void {
    if (t.stateless_rpc) {
        var rest = buf;
        while (rest.len > 0) {
            const n = @min(rest.len, pkt.LARGE_PACKET_DATA_MAX);
            var hdr: [4]u8 = undefined;
            _ = std.fmt.bufPrint(&hdr, "{x:0>4}", .{n + 4}) catch unreachable;
            os.writeAll(t.fd_out, &hdr) catch util.die("unable to write to remote: {s}", .{os.lastErr()});
            os.writeAll(t.fd_out, rest[0..n]) catch util.die("unable to write to remote: {s}", .{os.lastErr()});
            rest = rest[n..];
        }
        pkt.flush(t.fd_out);
    } else os.writeAll(t.fd_out, buf) catch util.die("unable to write to remote: {s}", .{os.lastErr()});
}

/// consume_shallow_list()
fn consumeShallowList(t: *Transport) void {
    if (!(t.stateless_rpc and t.deepen)) return;
    while (t.rd.read() == .normal) {
        if (util.startsWith(t.rd.line, "shallow ")) continue;
        if (util.startsWith(t.rd.line, "unshallow ")) continue;
        util.die("git fetch-pack: expected shallow list", .{});
    }
    if (t.rd.status != .flush) util.die("git fetch-pack: expected a flush packet after shallow list", .{});
}

const V0Caps = struct {
    multi_ack: u8 = 0,
    no_done: bool = false,
    sideband: u8 = 0,
    thin: bool = false,
    no_progress: bool = false,
    include_tag: bool = false,
    ofs_delta: bool = false,
    deepen_since_ok: bool = false,
    deepen_not_ok: bool = false,
    agent: bool = false,
    filtering: bool = false,
};

/// find_common(): returns <0 if no common commit was found.
fn findCommon(neg: *negotiator.Negotiator, t: *Transport, o: Options, wants: []const *Ref, caps: *V0Caps) i32 {
    const stateless = t.stateless_rpc;
    var multi_ack = caps.multi_ack;
    if (stateless and multi_ack == 1) util.die("the option '{s}' requires '{s}'", .{ "--stateless-rpc", "multi_ack_detailed" });
    const advertise_sid = repo_mod.cfg.getBool("transfer.advertisesid") orelse false;
    markTips(neg, o.negotiation_restrict);
    var req: util.Buf = .empty;
    var fetching: usize = 0;
    for (wants) |r| {
        if (!t.refetch and isCompleteObj(r.old_oid)) continue;
        if (fetching == 0) {
            var c: util.Buf = .empty;
            if (multi_ack == 2) util.bufAppend(&c, " multi_ack_detailed");
            if (multi_ack == 1) util.bufAppend(&c, " multi_ack");
            if (caps.no_done) util.bufAppend(&c, " no-done");
            if (caps.sideband == 2) util.bufAppend(&c, " side-band-64k");
            if (caps.sideband == 1) util.bufAppend(&c, " side-band");
            if (t.deepen_relative) util.bufAppend(&c, " deepen-relative");
            if (caps.thin) util.bufAppend(&c, " thin-pack");
            if (caps.no_progress) util.bufAppend(&c, " no-progress");
            if (caps.include_tag) util.bufAppend(&c, " include-tag");
            if (caps.ofs_delta) util.bufAppend(&c, " ofs-delta");
            if (caps.deepen_since_ok) util.bufAppend(&c, " deepen-since");
            if (caps.deepen_not_ok) util.bufAppend(&c, " deepen-not");
            if (caps.agent) util.bufPrint(&c, " agent={s}", .{@import("cmd/uploadpack.zig").agentSanitized()});
            if (advertise_sid and t.serverSupportsV0("session-id")) util.bufPrint(&c, " session-id={s}", .{t2.sessionId()});
            if (o.filter != null) util.bufAppend(&c, " filter");
            pkt.bufFmt(&req, "want {s}{s}\n", .{ hash.hex(r.old_oid), c.items });
        } else pkt.bufFmt(&req, "want {s}\n", .{hash.hex(r.old_oid)});
        fetching += 1;
    }
    if (fetching == 0) {
        pkt.flush(t.fd_out);
        return 1;
    }
    addShallowRequests(&req, t, false);
    sendFilter(&req, o.filter, caps.filtering);
    pkt.bufFlush(&req);
    var state_len = req.items.len;
    if (t.deepen) {
        sendRequest(t, req.items);
        while (t.rd.read() == .normal) {
            const line = t.rd.line;
            if (handleShallowLine(line)) continue;
            util.die("expected shallow/unshallow, got {s}", .{line});
        }
    } else if (!stateless) sendRequest(t, req.items);
    if (!stateless) {
        req.clearRetainingCapacity();
        state_len = 0;
    }

    t2.regionEnter("fetch-pack", "negotiation_v0_v1", true);
    var count: usize = 0;
    var flushes: i64 = 0;
    var flush_at: usize = INITIAL_FLUSH;
    var retval: i32 = -1;
    var round: usize = 0;
    var haves: usize = 0;
    var in_vain: usize = 0;
    var got_continue = false;
    var got_ready = false;
    var result_oid: Oid = hash.zero;

    for (includeOids(o.negotiation_include)) |io| {
        pkt.bufFmt(&req, "have {s}\n", .{hash.hex(io)});
        printVerbose("have {s}", .{hash.hex(io)});
        count += 1;
        if (cn.lookupCommit(io)) |c| neg.haveSent(c);
    }
    outer: while (neg.next()) |oid| {
        pkt.bufFmt(&req, "have {s}\n", .{hash.hex(oid)});
        printVerbose("have {s}", .{hash.hex(oid)});
        in_vain += 1;
        haves += 1;
        count += 1;
        if (flush_at > count) continue;
        round += 1;
        var rbuf: [24]u8 = undefined;
        const round_s = std.fmt.bufPrint(&rbuf, "{d}", .{round}) catch unreachable;
        t2.regionEnterMsg("negotiation_v0_v1", "round", true, round_s);
        t2.dataInt("negotiation_v0_v1", true, "haves_added", @intCast(haves));
        t2.dataInt("negotiation_v0_v1", true, "in_vain", @intCast(in_vain));
        haves = 0;
        pkt.bufFlush(&req);
        sendRequest(t, req.items);
        req.shrinkRetainingCapacity(state_len);
        flushes += 1;
        flush_at = nextFlush(stateless, count);
        // keep one window "ahead" of the other side
        if (!stateless and count == INITIAL_FLUSH) continue;
        consumeShallowList(t);
        while (true) {
            const a = getAck(t.rd, &result_oid);
            if (a == .nak) break;
            printVerbose("got ack {d} {s}", .{ @intFromEnum(a), hash.hex(result_oid) });
            if (a == .ack) {
                t2.regionLeaveMsg("negotiation_v0_v1", "round", true, round_s);
                flushes = 0;
                multi_ack = 0;
                retval = 0;
                break :outer;
            }
            const commit = cn.lookupCommit(result_oid) orelse util.die("invalid commit {s}", .{hash.hex(result_oid)});
            const was_common = neg.ack(commit);
            if (stateless and a == .ack_common and !was_common) {
                // replay the have on the next RPC request
                pkt.bufFmt(&req, "have {s}\n", .{hash.hex(result_oid)});
                state_len = req.items.len;
                haves += 1;
                in_vain = 0;
            } else if (!stateless or a != .ack_common) in_vain = 0;
            retval = 0;
            got_continue = true;
            if (a == .ack_ready) got_ready = true;
        }
        flushes -= 1;
        t2.regionLeaveMsg("negotiation_v0_v1", "round", true, round_s);
        if (got_continue and MAX_IN_VAIN < in_vain) {
            printVerbose("giving up", .{});
            break;
        }
        if (got_ready) break;
    }
    t2.regionLeave("fetch-pack", "negotiation_v0_v1", true);
    t2.dataInt("negotiation_v0_v1", true, "total_rounds", @intCast(round));
    if (!got_ready or !caps.no_done) {
        pkt.bufWrite(&req, "done\n");
        sendRequest(t, req.items);
    }
    printVerbose("done", .{});
    if (retval != 0) {
        multi_ack = 0;
        flushes += 1;
    }
    if (!got_ready or !caps.no_done) consumeShallowList(t);
    while (flushes != 0 or multi_ack != 0) {
        const a = getAck(t.rd, &result_oid);
        if (a != .nak) {
            printVerbose("got ack ({d}) {s}", .{ @intFromEnum(a), hash.hex(result_oid) });
            if (a == .ack) return 0;
            multi_ack = 1;
            continue;
        }
        flushes -= 1;
    }
    return if (count > 0) retval else 0;
}

/// Pack data source: either sideband-demuxed or raw from the reader.
const PackSource = struct {
    rd: *pkt.Reader,
    sideband: bool,
    demux: pkt.Demux = .{},
    ended: bool = false,
    pending: []const u8 = &.{},
    pending_buf: util.Buf = .empty,

    /// Returns next chunk of pack data, or null at end.
    fn next(self: *PackSource) ?[]const u8 {
        if (self.ended) return null;
        if (!self.sideband) {
            var buf: [65536]u8 = undefined;
            const n = self.rd.readRaw(&buf);
            if (n == 0) {
                self.ended = true;
                return null;
            }
            self.pending_buf.clearRetainingCapacity();
            util.bufAppend(&self.pending_buf, buf[0..n]);
            return self.pending_buf.items;
        }
        pkt.in_async = true;
        defer pkt.in_async = false;
        while (true) {
            _ = self.rd.read();
            switch (self.demux.handle(self.rd, "fetch-pack")) {
                .data => |d| return d,
                .consumed => {},
                .end => {
                    self.ended = true;
                    return null;
                },
            }
        }
    }
};

pub const Options = struct {
    quiet: bool = false,
    no_progress: bool = true,
    thin: bool = true,
    include_tag: bool = false,
    keep_pack: bool = false,
    filter: ?[]const u8 = null,
    from_promisor: bool = false,
    verbose: bool = false,
    /// --negotiation-restrict tips (null: all local refs)
    negotiation_restrict: ?[]const Oid = null,
    /// --negotiation-include tips
    negotiation_include: []const Oid = &.{},
};

var cur_sought: []const *Ref = &.{};

/// create_promisor_file(): record the sought refs next to the new pack.
fn writePromisorFile(out: []const u8) void {
    if (out.len < 45) return;
    if (!util.startsWith(out, "pack\t") and !util.startsWith(out, "keep\t")) return;
    const odb = repo_mod.repo().odb();
    const path = util.fmt("{s}/pack/pack-{s}.promisor", .{ odb.objects_dir, out[5..45] });
    var b: util.Buf = .empty;
    for (cur_sought) |r| util.bufPrint(&b, "{s} {s}\n", .{ hash.hex(r.old_oid), r.name });
    os.writeFile(path, b.items, 0o666) catch util.die("could not write '{s}' promisor file", .{path});
}

fn receivePack(src: *PackSource, o: Options) void {
    // read the pack header (12 bytes)
    var head: util.Buf = .empty;
    while (head.items.len < 12) {
        const d = src.next() orelse util.die("protocol error: bad pack header", .{});
        util.bufAppend(&head, d);
    }
    if (!std.mem.eql(u8, head.items[0..4], "PACK")) util.die("protocol error: bad pack header", .{});
    const nr = std.mem.readInt(u32, head.items[8..12], .big);
    const limit = unpackLimit();
    var do_keep = o.keep_pack or o.from_promisor;
    if (!o.keep_pack and !o.from_promisor and limit != 0) do_keep = nr >= limit;
    var args: std.ArrayList([]const u8) = .empty;
    const fsck_objects = fetchFsckObjects();
    const use_index_pack = do_keep or fsck_objects;
    const cmd_name: []const u8 = if (use_index_pack) "index-pack" else "unpack-objects";
    if (use_index_pack) {
        args.appendSlice(gpa, &.{ "index-pack", "--stdin" }) catch util.oom();
        if (!o.quiet and !o.no_progress) args.append(gpa, "-v") catch util.oom();
        if (o.thin) args.append(gpa, "--fix-thin") catch util.oom();
        if (o.from_promisor) args.append(gpa, "--promisor") catch util.oom();
    } else {
        args.append(gpa, "unpack-objects") catch util.oom();
        if (o.quiet or o.no_progress) args.append(gpa, "-q") catch util.oom();
    }
    if (fsck_objects) {
        // --strict would also check links, which a promisor pack lacks
        if (o.from_promisor) {
            args.append(gpa, "--fsck-objects") catch util.oom();
        } else args.append(gpa, util.concat(&.{ "--strict", fetchFsckMsgTypes() })) catch util.oom();
    }
    proc.ignoreSigpipe();
    var ch = proc.spawnGit(args.items, .{ .pipe_in = true, .pipe_out = use_index_pack });
    var write_ok = true;
    os.writeAll(ch.in, head.items) catch {
        write_ok = false;
    };
    while (src.next()) |d| {
        if (write_ok) os.writeAll(ch.in, d) catch {
            write_ok = false;
        };
    }
    proc.closeFd(&ch.in);
    var gitmodules: std.ArrayList(Oid) = .empty;
    if (use_index_pack) {
        // "pack\t<hash>\n" (or keep), then missing .gitmodules oids
        var outb: util.Buf = .empty;
        var buf: [4096]u8 = undefined;
        while (true) {
            const n = std.c.read(ch.out, &buf, buf.len);
            if (n <= 0) break;
            util.bufAppend(&outb, buf[0..@intCast(n)]);
        }
        proc.closeFd(&ch.out);
        if (o.from_promisor) writePromisorFile(outb.items);
        if (fsck_objects) {
            if (outb.items.len < 46 or outb.items[45] != '\n') util.die("fetch-pack: invalid index-pack output", .{});
            var rest = outb.items[46..];
            while (rest.len > 0) {
                if (rest.len < 41) util.die("invalid length read {d}", .{rest.len});
                if (rest[40] != '\n') util.die("invalid hash", .{});
                const oid = hash.fromHex(rest[0..40]) orelse util.die("invalid hash", .{});
                gitmodules.append(gpa, oid) catch util.oom();
                rest = rest[41..];
            }
        }
    }
    const rc = proc.wait(ch.pid);
    if (rc != 0) util.die("{s} failed", .{cmd_name});
    repo_mod.repo().odb().reloadPacks();
    if (fsck_objects) {
        var fo = fsck.Options{ .strict = true, .error_func = printMissingGitmodules };
        for (gitmodules.items) |g| fo.gitmodules_found.insert(g);
        if (fsck.fsckFinish(&fo) != 0) util.die("fsck failed", .{});
    }
}

fn repoIsShallow() bool {
    return objects.shallowList().len > 0;
}

/// Shallow-related request lines (add_shallow_requests / find_common).
fn addShallowRequests(req: *util.Buf, t: *Transport, v2: bool) void {
    for (objects.shallowList()) |s| pkt.bufFmt(req, "shallow {s}\n", .{hash.hex(s)});
    if (t.depth > 0) pkt.bufFmt(req, "deepen {d}", .{t.depth});
    if (t.deepen_since) |s| pkt.bufFmt(req, "deepen-since {d}", .{@import("date.zig").approxidate(s)});
    for (t.deepen_not) |n| pkt.bufFmt(req, "deepen-not {s}", .{n});
    if (v2 and t.deepen_relative) pkt.bufWrite(req, "deepen-relative\n");
}

fn handleShallowLine(line: []const u8) bool {
    if (util.skipPrefix(line, "shallow ")) |a| {
        const o = hash.fromHex(a) orelse util.die("invalid shallow line: {s}", .{line});
        objects.registerShallow(o);
        return true;
    }
    if (util.skipPrefix(line, "unshallow ")) |a| {
        const o = hash.fromHex(a) orelse util.die("invalid unshallow line: {s}", .{line});
        if (!repo_mod.repo().odb().has(o)) util.die("object not found: {s}", .{line});
        if (!objects.unregisterShallow(o)) util.die("no shallow found: {s}", .{line});
        return true;
    }
    return false;
}

fn writeShallowFile(list: []const Oid) void {
    const path = repo_mod.repo().commonPath("shallow");
    if (list.len == 0) {
        _ = os.unlink(path);
    } else {
        var b: util.Buf = .empty;
        for (list) |s| util.bufPrint(&b, "{s}\n", .{hash.hex(s)});
        const lk = @import("lockfile.zig").lockOrDie(path);
        lk.write(b.items);
        if (!lk.commit()) util.die("unable to write shallow file", .{});
    }
    objects.resetCaches();
}

fn sortOids(l: []Oid) void {
    std.mem.sort(Oid, l, {}, struct {
        fn lt(_: void, a: Oid, b: Oid) bool {
            return std.mem.order(u8, &a, &b) == .lt;
        }
    }.lt);
}

/// update_shallow(): after the pack has been received.
fn updateShallow(t: *Transport, sought: []const *Ref, remote_shallow: []const Oid) void {
    if (t.deepen) {
        writeShallowFile(objects.shallowList());
        return;
    }
    if (remote_shallow.len == 0) return;
    const odb = repo_mod.repo().odb();
    if (t.cloning) {
        var extra: std.ArrayList(Oid) = .empty;
        for (remote_shallow) |s| {
            if (odb.has(s)) extra.append(gpa, s) catch util.oom();
        }
        if (extra.items.len > 0) {
            for (objects.shallowList()) |s| extra.append(gpa, s) catch util.oom();
            sortOids(extra.items);
            writeShallowFile(extra.items);
        }
        return;
    }
    // ours: present and not already shallow; theirs: now present
    var roots: hash.OidSet = .empty;
    for (remote_shallow) |s| {
        if (!odb.has(s)) continue;
        if (objects.isShallow(s)) continue;
        roots.put(gpa, s, {}) catch util.oom();
    }
    if (roots.count() == 0) return;
    // commits reachable from our existing refs
    var local: hash.OidSet = .empty;
    var stack: std.ArrayList(Oid) = .empty;
    for (refs.iterate("", .{ .check_objects = false })) |r| {
        const c_oid = objects.peelTo(r.oid, .commit) orelse continue;
        stack.append(gpa, c_oid) catch util.oom();
    }
    while (stack.pop()) |o| {
        if (local.contains(o)) continue;
        local.put(gpa, o, {}) catch util.oom();
        if (roots.contains(o)) continue;
        const cm = objects.readCommit(o) orelse continue;
        for (cm.parents) |p| stack.append(gpa, p) catch util.oom();
    }
    var used: hash.OidSet = .empty;
    var status: std.ArrayList(bool) = .empty;
    for (sought) |r| {
        var hit = false;
        const start = objects.peelTo(r.old_oid, .commit);
        var seen: hash.OidSet = .empty;
        if (start) |s0| stack.append(gpa, s0) catch util.oom();
        while (stack.pop()) |o| {
            if (seen.contains(o) or local.contains(o)) continue;
            seen.put(gpa, o, {}) catch util.oom();
            if (roots.contains(o)) {
                hit = true;
                used.put(gpa, o, {}) catch util.oom();
                continue;
            }
            const cm = objects.readCommit(o) orelse continue;
            for (cm.parents) |p| stack.append(gpa, p) catch util.oom();
        }
        status.append(gpa, hit) catch util.oom();
    }
    if (used.count() == 0) return;
    if (t.update_shallow) {
        var extra: std.ArrayList(Oid) = .empty;
        var it = used.keyIterator();
        while (it.next()) |k| extra.append(gpa, k.*) catch util.oom();
        for (objects.shallowList()) |s| extra.append(gpa, s) catch util.oom();
        sortOids(extra.items);
        writeShallowFile(extra.items);
        return;
    }
    for (sought, status.items) |r, st| {
        if (st) r.status = .reject_shallow;
    }
}

fn checkShallowCaps(t: *Transport) void {
    if (t.version == 2) return;
    if (!t.serverSupportsV0("shallow")) {
        if (t.depth > 0 or repoIsShallow()) util.die("Server does not support shallow clients", .{});
    }
    if (!t.serverSupportsV0("deepen-since") and t.deepen_since != null) util.die("Server does not support --shallow-since", .{});
    if (!t.serverSupportsV0("deepen-not") and t.deepen_not.len > 0) util.die("Server does not support --shallow-exclude", .{});
    if (!t.serverSupportsV0("deepen-relative") and t.deepen_relative) util.die("Server does not support --deepen", .{});
}

/// Fetch the objects for `sought` refs over the (already connected) transport.
pub fn fetchPack(t: *Transport, sought: []const *Ref, o0: Options) void {
    var o = o0;
    if (o.negotiation_restrict == null) o.negotiation_restrict = t.negotiation_restrict;
    if (o.negotiation_include.len == 0) o.negotiation_include = t.negotiation_include;
    cur_sought = sought;
    verbose_out = o.verbose;
    if (t.child == null) transport.connect(t, false);
    if (t.hd != null) {
        if (@import("transport_helper.zig").fetchRefs(t, sought, .{ .filter = o.filter }) != 0) util.die("remote transport reported error", .{});
        return;
    }
    if (t.is_bundle) {
        // fetch_refs_from_bundle()
        const h = t.bundle_header orelse transport.bundleHeader(t);
        const extra: []const []const u8 = if (t.progress) &.{"-v"} else &.{};
        const msg_types: ?[]const u8 = if (fetchFsckObjects()) fetchFsckMsgTypes() else null;
        if (@import("cmd/bundle.zig").unbundleOpts(h, extra, .normal, msg_types) != 0) t.fetch_failed = true;
        t.bundle_header = null;
        return;
    }
    t.deepen = t.depth > 0 or t.deepen_since != null or t.deepen_not.len > 0;
    checkShallowCaps(t);
    if (t.version == 2) return fetchV2(t, sought, o);
    return fetchV0(t, sought, o);
}

/// send_filter()
fn sendFilter(req: *util.Buf, filter: ?[]const u8, supported: bool) void {
    if (filter) |fs| {
        if (supported) {
            pkt.bufFmt(req, "filter {s}\n", .{fs});
            t2.dataString("fetch", true, "filter/effective", fs);
        } else {
            util.warn("filtering not recognized by server, ignoring", .{});
            t2.dataString("fetch", true, "filter/unsupported", fs);
        }
    } else t2.dataString("fetch", true, "filter/none", "");
}

fn allRemoteRefs(t: *Transport, sought: []const *Ref) []const *Ref {
    if (t.remote_refs.len > 0) return t.remote_refs;
    return sought;
}

fn fetchV0(t: *Transport, sought: []const *Ref, o: Options) void {
    const remote_shallow = t.remote_shallow.items;
    var neg = initNegotiator(t);
    const wants = wantedRefs(sought);
    var caps = V0Caps{};
    caps.agent = t.serverSupportsV0("agent");
    if (t.serverSupportsV0("multi_ack_detailed")) {
        caps.multi_ack = 2;
        if (t.serverSupportsV0("no-done") and t.stateless_rpc) caps.no_done = true;
    } else if (t.serverSupportsV0("multi_ack")) caps.multi_ack = 1;
    if (t.serverSupportsV0("side-band-64k")) {
        caps.sideband = 2;
    } else if (t.serverSupportsV0("side-band")) caps.sideband = 1;
    caps.thin = o.thin and t.serverSupportsV0("thin-pack");
    caps.no_progress = o.no_progress and t.serverSupportsV0("no-progress");
    caps.include_tag = o.include_tag and t.serverSupportsV0("include-tag");
    caps.ofs_delta = t.serverSupportsV0("ofs-delta");
    if (t.serverSupportsV0("filter")) {
        caps.filtering = true;
    } else if (o.filter != null) util.warn("filtering not recognized by server, ignoring", .{});
    caps.deepen_since_ok = t.serverSupportsV0("deepen-since");
    caps.deepen_not_ok = t.serverSupportsV0("deepen-not");

    markCompleteAndCommonRef(&neg, t, allRemoteRefs(t, sought));
    if (!t.refetch and everythingLocal(wants)) {
        _ = transport.disconnect(t);
        t.got_remote_heads = false;
        updateShallow(t, sought, remote_shallow);
        return;
    }
    const ret = findCommon(&neg, t, o, wants, &caps);
    if (ret == 1) {
        // nothing to want after all (find_common() already sent a flush)
        t.got_remote_heads = false;
        updateShallow(t, sought, remote_shallow);
        return;
    }
    if (ret < 0 and !o.keep_pack) util.warn("no common commits", .{});
    if (t.stateless_rpc) pkt.flush(t.fd_out);
    if (!t.deepen and remote_shallow.len > 0 and t.reject_shallow) {
        var any = false;
        for (remote_shallow) |s| {
            if (!objects.isShallow(s)) any = true;
        }
        if (any) util.die("source repository is shallow, reject to clone.", .{});
    }
    var src = PackSource{ .rd = t.rd, .sideband = caps.sideband != 0 };
    t.rd.chomp = false;
    receivePack(&src, o);
    t.rd.chomp = true;
    _ = transport.finish(t);
    t.got_remote_heads = false;
    updateShallow(t, sought, remote_shallow);
}

/// Ordered set of oids (oidset used for "common" in do_fetch_pack_v2()).
const OidList = struct {
    list: std.ArrayList(Oid) = .empty,
    set: hash.OidSet = .empty,
    fn add(self: *OidList, o: Oid) void {
        if (self.set.contains(o)) return;
        self.set.put(gpa, o, {}) catch util.oom();
        self.list.append(gpa, o) catch util.oom();
    }
};

/// send_fetch_request(); returns whether "done" was sent.
fn sendFetchRequest(neg: *negotiator.Negotiator, t: *Transport, o: Options, wants: []const *Ref, common: *const OidList, haves_to_send: *usize, in_vain: *usize, seen_ack: bool, include_oids: []const Oid) bool {
    transport.sendCommandV2(t, "fetch");
    var req: util.Buf = .empty;
    if (o.thin) pkt.bufWrite(&req, "thin-pack");
    if (o.no_progress) pkt.bufWrite(&req, "no-progress");
    if (o.include_tag) pkt.bufWrite(&req, "include-tag");
    pkt.bufWrite(&req, "ofs-delta");
    if (t.serverSupportsFeature("fetch", "shallow")) {
        addShallowRequests(&req, t, true);
    } else if (repoIsShallow() or t.deepen) util.die("Server does not support shallow requests", .{});
    sendFilter(&req, o.filter, t.serverSupportsFeature("fetch", "filter"));
    // add_wants()
    const ref_in_want = t.serverSupportsFeature("fetch", "ref-in-want");
    for (wants) |r| {
        if (isCompleteObj(r.old_oid)) continue;
        if (!ref_in_want or r.exact_oid or isOidName(r)) {
            pkt.bufFmt(&req, "want {s}\n", .{hash.hex(r.old_oid)});
        } else pkt.bufFmt(&req, "want-ref {s}\n", .{r.name});
    }
    // add_common()
    for (common.list.items) |c| pkt.bufFmt(&req, "have {s}\n", .{hash.hex(c)});
    // add_haves()
    var haves_added: usize = 0;
    for (include_oids) |io| {
        if (cn.lookupCommit(io)) |c| {
            pkt.bufFmt(&req, "have {s}\n", .{hash.hex(io)});
            neg.haveSent(c);
        }
    }
    while (neg.next()) |oid| {
        pkt.bufFmt(&req, "have {s}\n", .{hash.hex(oid)});
        haves_added += 1;
        if (haves_added >= haves_to_send.*) break;
    }
    haves_to_send.* = nextFlush(true, haves_to_send.*);
    in_vain.* += haves_added;
    t2.dataInt("negotiation_v2", true, "haves_added", @intCast(haves_added));
    t2.dataInt("negotiation_v2", true, "in_vain", @intCast(in_vain.*));
    var done_sent = false;
    if (haves_added == 0 or (seen_ack and in_vain.* >= MAX_IN_VAIN)) {
        pkt.bufWrite(&req, "done\n");
        done_sent = true;
    }
    pkt.bufFlush(&req);
    os.writeAll(t.fd_out, req.items) catch util.die("unable to write request to remote: {s}", .{os.lastErr()});
    return done_sent;
}

/// process_section_header(reader, section, 0)
fn expectSection(t: *Transport, section: []const u8) void {
    const st = t.rd.peek();
    if (st == .normal and util.eql(t.rd.line, section)) {
        _ = t.rd.read();
        return;
    }
    if (st == .normal) util.die("expected '{s}', received '{s}'", .{ section, t.rd.line });
    util.die("expected '{s}'", .{section});
}

/// process_ack(): returns true after each ACK line.
fn processAck(neg: *negotiator.Negotiator, t: *Transport, common_oid: *Oid, received_ready: *bool) bool {
    while (t.rd.read() == .normal) {
        const line = t.rd.line;
        if (util.eql(line, "NAK")) continue;
        if (util.skipPrefix(line, "ACK ")) |arg| {
            if (arg.len >= 40) {
                if (hash.fromHex(arg[0..40])) |oid| {
                    common_oid.* = oid;
                    if (cn.lookupCommit(oid)) |c| _ = neg.ack(c);
                }
            }
            return true;
        }
        if (util.eql(line, "ready")) {
            received_ready.* = true;
            continue;
        }
        util.die("unexpected acknowledgment line: '{s}'", .{line});
    }
    const st = t.rd.status;
    if (st != .flush and st != .delim) util.die("error processing acks: {d}", .{@intFromEnum(st)});
    if (received_ready.* and st != .delim) util.die("expected packfile to be sent after '{s}'", .{"ready"});
    if (!received_ready.* and st != .flush) util.die("expected no other sections to be sent after no '{s}'", .{"ready"});
    return false;
}

fn fetchV2(t: *Transport, sought: []const *Ref, o: Options) void {
    var neg = initNegotiator(t);
    const wants = wantedRefs(sought);
    // FETCH_CHECK_LOCAL
    markCompleteAndCommonRef(&neg, t, allRemoteRefs(t, sought));
    const all_local = !t.refetch and everythingLocal(wants);
    markTips(&neg, o.negotiation_restrict);
    const include_oids = includeOids(o.negotiation_include);
    if (all_local) return;
    if (!t.serverSupportsV2("fetch")) util.die("server doesn't support '{s}'", .{"fetch"});

    var common: OidList = .{};
    var haves_to_send: usize = INITIAL_FLUSH;
    var in_vain: usize = 0;
    var seen_ack = false;
    var received_ready = false;
    var round: usize = 0;
    var common_oid: Oid = hash.zero;
    t2.regionEnter("fetch-pack", "negotiation_v2", true);
    while (true) {
        // FETCH_SEND_REQUEST
        round += 1;
        var rbuf: [24]u8 = undefined;
        const round_s = std.fmt.bufPrint(&rbuf, "{d}", .{round}) catch unreachable;
        t2.regionEnterMsg("negotiation_v2", "round", true, round_s);
        if (sendFetchRequest(&neg, t, o, wants, &common, &haves_to_send, &in_vain, seen_ack, include_oids)) {
            t2.regionLeaveMsg("negotiation_v2", "round", true, round_s);
            break;
        }
        // FETCH_PROCESS_ACKS
        expectSection(t, "acknowledgments");
        while (processAck(&neg, t, &common_oid, &received_ready)) {
            in_vain = 0;
            seen_ack = true;
            common.add(common_oid);
        }
        t2.regionLeaveMsg("negotiation_v2", "round", true, round_s);
        if (received_ready) break;
        @import("transport_helper.zig").checkStatelessDelimiter(t, "git fetch-pack: expected response end packet");
    }
    // FETCH_GET_PACK
    t2.regionLeave("fetch-pack", "negotiation_v2", true);
    t2.dataInt("negotiation_v2", true, "total_rounds", @intCast(round));
    receiveV2Pack(t, sought, o);
}

fn receiveV2Pack(t: *Transport, sought: []const *Ref, o: Options) void {
    var remote_shallow: std.ArrayList(Oid) = .empty;
    // read sections until "packfile"
    while (true) {
        const st = t.rd.read();
        if (st == .eof) util.die("the remote end hung up unexpectedly", .{});
        if (st != .normal) util.die("error processing acks: {d}", .{@intFromEnum(st)});
        const sect = util.dupe(t.rd.line);
        if (util.eql(sect, "packfile")) break;
        if (util.eql(sect, "shallow-info")) {
            var unshallow_received = false;
            var shallows: std.ArrayList(Oid) = .empty;
            while (t.rd.read() == .normal) {
                const line = t.rd.line;
                if (util.skipPrefix(line, "shallow ")) |a| {
                    const so = hash.fromHex(a) orelse util.die("invalid shallow line: {s}", .{line});
                    shallows.append(gpa, so) catch util.oom();
                    continue;
                }
                if (util.startsWith(line, "unshallow ")) {
                    _ = handleShallowLine(line);
                    unshallow_received = true;
                    continue;
                }
                util.die("expected shallow/unshallow, got {s}", .{line});
            }
            if (t.rd.status != .delim) util.die("error processing shallow info: {d}", .{@intFromEnum(t.rd.status)});
            if (t.deepen or unshallow_received) {
                for (shallows.items) |so| objects.registerShallow(so);
                t.deepen = true;
            } else if (shallows.items.len > 0) {
                remote_shallow = shallows;
                if (t.reject_shallow) {
                    for (shallows.items) |so| {
                        if (!objects.isShallow(so)) util.die("source repository is shallow, reject to clone.", .{});
                    }
                }
            }
            continue;
        }
        // skip the section body
        while (true) {
            const s2 = t.rd.read();
            if (s2 == .delim) break;
            if (s2 == .normal) continue;
            if (s2 == .flush) return;
            util.die("the remote end hung up unexpectedly", .{});
        }
    }
    var src = PackSource{ .rd = t.rd, .sideband = true };
    t.rd.chomp = false;
    receivePack(&src, o);
    t.rd.chomp = true;
    @import("transport_helper.zig").checkStatelessDelimiter(t, "git fetch-pack: expected response end packet");
    updateShallow(t, sought, remote_shallow.items);
}

/// fetch_refs_via_pack() with smart_options->acked_commits set
/// (git fetch --negotiate-only): returns 0 on success, -1 on failure.
pub fn negotiateOnly(t: *Transport, acked: *std.ArrayList(Oid)) i32 {
    transport.connect(t, false);
    if (t.child == null or t.version < 2) {
        util.warn("--negotiate-only requires protocol v2", .{});
        return -1;
    }
    if (!t.serverSupportsFeature("fetch", "wait-for-done")) {
        util.warn("server does not support wait-for-done", .{});
        return -1;
    }
    negotiateUsingFetch(t, t.negotiation_restrict orelse &.{}, acked, t.negotiation_include);
    return 0;
}

/// negotiate_using_fetch()
fn negotiateUsingFetch(t: *Transport, restrict: []const Oid, acked: *std.ArrayList(Oid), include: []const Oid) void {
    const REACH_SCRATCH: u32 = 1 << 7;
    const commitreach = @import("commitreach.zig");
    var neg = negotiator.Negotiator.init(negotiator.configuredAlgorithm());
    markTips(&neg, restrict);
    const include_oids = includeOids(include);
    var nt: std.ArrayList(*cn.Obj) = .empty;
    for (restrict) |o| {
        if (cn.lookupAny(o)) |obj| nt.append(gpa, obj) catch util.oom();
    }
    var acked_set: hash.OidSet = .empty;
    var acked_list: std.ArrayList(Oid) = .empty;
    var haves_to_send: usize = INITIAL_FLUSH;
    var in_vain: usize = 0;
    var seen_ack = false;
    var last_iteration = false;
    var round: usize = 0;
    var min_generation: u64 = commitreach.GEN_INFINITY;
    t2.regionEnter("fetch-pack", "negotiate_using_fetch", true);
    while (!last_iteration) {
        round += 1;
        var rbuf: [24]u8 = undefined;
        const round_s = std.fmt.bufPrint(&rbuf, "{d}", .{round}) catch unreachable;
        t2.regionEnterMsg("negotiate_using_fetch", "round", true, round_s);
        transport.sendCommandV2(t, "fetch");
        var req: util.Buf = .empty;
        pkt.bufWrite(&req, "wait-for-done");
        // add_haves()
        var haves_added: usize = 0;
        for (include_oids) |io| {
            if (cn.lookupCommit(io)) |c| {
                pkt.bufFmt(&req, "have {s}\n", .{hash.hex(io)});
                neg.haveSent(c);
            }
        }
        while (neg.next()) |oid| {
            pkt.bufFmt(&req, "have {s}\n", .{hash.hex(oid)});
            haves_added += 1;
            if (haves_added >= haves_to_send) break;
        }
        haves_to_send = nextFlush(true, haves_to_send);
        in_vain += haves_added;
        if (haves_added == 0 or (seen_ack and in_vain >= MAX_IN_VAIN)) last_iteration = true;
        t2.dataInt("negotiate_using_fetch", true, "haves_added", @intCast(haves_added));
        t2.dataInt("negotiate_using_fetch", true, "in_vain", @intCast(in_vain));
        pkt.bufFlush(&req);
        os.writeAll(t.fd_out, req.items) catch util.die("unable to write request to remote: {s}", .{os.lastErr()});

        expectSection(t, "acknowledgments");
        var received_ready = false;
        var common_oid: Oid = hash.zero;
        while (processAck(&neg, t, &common_oid, &received_ready)) {
            if (cn.lookupCommit(common_oid)) |c| {
                if (!cn.parse(c)) util.die("could not parse commit {s}", .{hash.hex(common_oid)});
                c.obj.flags |= negotiator.COMMON;
                const g = commitreach.generation(c);
                if (g < min_generation) min_generation = g;
            }
            in_vain = 0;
            seen_ack = true;
            if (!acked_set.contains(common_oid)) {
                acked_set.put(gpa, common_oid, {}) catch util.oom();
                acked_list.append(gpa, common_oid) catch util.oom();
            }
        }
        if (received_ready) util.die("unexpected 'ready' from remote", .{});
        @import("transport_helper.zig").checkStatelessDelimiter(t, "git fetch-pack: expected response end packet");
        if (commitreach.canAllFromReachWithFlag(nt.items, negotiator.COMMON, REACH_SCRATCH, 0, min_generation))
            last_iteration = true;
        t2.regionLeaveMsg("negotiation", "round", true, round_s);
    }
    t2.regionLeave("fetch-pack", "negotiate_using_fetch", true);
    t2.dataInt("negotiate_using_fetch", true, "total_rounds", @intCast(round));
    // clear_common_flag()
    for (acked_list.items) |o| {
        if (cn.lookupAny(o)) |obj| obj.flags &= ~negotiator.COMMON;
    }
    acked.appendSlice(gpa, oidsetOrder(acked_list.items)) catch util.oom();
}
