//! Connection set-up for the builtin smart transports (connect.c):
//! URL parsing, ssh command construction, git:// sockets/proxies, and the
//! protocol allow policy (transport.c is_transport_allowed).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const gpa = util.gpa;

// ---------------- protocol allow policy ----------------

const Allow = enum { never, user_only, always };

fn parseProtocolConfig(key: []const u8, value: []const u8) Allow {
    if (std.ascii.eqlIgnoreCase(value, "always")) return .always;
    if (std.ascii.eqlIgnoreCase(value, "never")) return .never;
    if (std.ascii.eqlIgnoreCase(value, "user")) return .user_only;
    util.die("unknown value for config '{s}': {s}", .{ key, value });
}

fn cfgString(key: []const u8) ?[]const u8 {
    const e = repo_mod.cfg.getEntry(key) orelse return null;
    if (e.value) |v| return v;
    _ = config.errorNonbool(key);
    util.die("bad config variable '{s}'", .{key});
}

fn getProtocolConfig(t: []const u8) Allow {
    const key = util.fmt("protocol.{s}.allow", .{t});
    if (cfgString(key)) |v| return parseProtocolConfig(key, v);
    if (cfgString("protocol.allow")) |v| return parseProtocolConfig("protocol.allow", v);
    if (util.eql(t, "http") or util.eql(t, "https") or util.eql(t, "git") or util.eql(t, "ssh")) return .always;
    if (util.eql(t, "ext")) return .never;
    return .user_only;
}

/// is_transport_allowed(); from_user < 0 means "consult GIT_PROTOCOL_FROM_USER".
pub fn isTransportAllowed(t: []const u8, from_user: i8) bool {
    if (os.getenv("GIT_ALLOW_PROTOCOL")) |list| {
        var it = std.mem.splitScalar(u8, list, ':');
        while (it.next()) |p| {
            if (util.eql(p, t)) return true;
        }
        return false;
    }
    return switch (getProtocolConfig(t)) {
        .always => true,
        .never => false,
        .user_only => blk: {
            if (from_user >= 0) break :blk from_user != 0;
            const v = os.getenv("GIT_PROTOCOL_FROM_USER") orelse break :blk true;
            break :blk config.configBool("GIT_PROTOCOL_FROM_USER", v);
        },
    };
}

pub fn checkAllowed(t: []const u8) void {
    if (!isTransportAllowed(t, -1)) util.die("transport '{s}' not allowed", .{t});
}

// ---------------- URL parsing (parse_connect_url) ----------------

pub const Scheme = enum { local, file, ssh, git };

pub fn schemeName(s: Scheme) []const u8 {
    return switch (s) {
        .local, .file => "file",
        .ssh => "ssh",
        .git => "git",
    };
}

pub fn isUrlschemechar(first: bool, ch: u8) bool {
    const alnum = std.ascii.isAlphanumeric(ch);
    const special = ch == '+' or ch == '-' or ch == '.';
    return alnum or (!first and special);
}

pub fn isUrl(url: []const u8) bool {
    if (url.len == 0 or !isUrlschemechar(true, url[0])) return false;
    var i: usize = 1;
    while (i < url.len and url[i] != ':') : (i += 1) {
        if (!isUrlschemechar(false, url[i])) return false;
    }
    return i + 2 < url.len and url[i + 1] == '/' and url[i + 2] == '/';
}

/// url_is_local_not_ssh()
pub fn urlIsLocalNotSsh(url: []const u8) bool {
    const colon = std.mem.indexOfScalar(u8, url, ':') orelse return true;
    const slash = std.mem.indexOfScalar(u8, url, '/');
    if (slash) |s| {
        if (s < colon) return true;
    }
    return false;
}

/// url_decode(): decode %XX everywhere after the scheme.
pub fn urlDecode(url: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    if (std.mem.indexOfScalar(u8, url, ':')) |c| {
        if (c > 0) {
            util.bufAppend(&b, url[0..c]);
            i = c;
        }
    }
    while (i < url.len) {
        const ch = url[i];
        if (ch == '%' and i + 2 < url.len) {
            if (std.fmt.parseInt(u8, url[i + 1 .. i + 3], 16)) |v| {
                if (v > 0) {
                    util.bufByte(&b, v);
                    i += 3;
                    continue;
                }
            } else |_| {}
        }
        util.bufByte(&b, ch);
        i += 1;
    }
    return b.items;
}

/// host_end() without bracket removal: index of the end of a bracketed host.
fn hostEnd(s: []const u8) usize {
    var start: usize = 0;
    if (std.mem.indexOf(u8, s, "@[")) |p| start = p + 1;
    if (start < s.len and s[start] == '[') {
        if (std.mem.indexOfScalarPos(u8, s, start + 1, ']')) |e| return e;
    }
    return 0;
}

fn parsePort(s: []const u8) bool {
    if (s.len == 0) return false;
    // strtol semantics: optional sign, digits, no trailing garbage
    const n = std.fmt.parseInt(i64, s, 10) catch return false;
    return n >= 0 and n < 65536;
}

pub const Parsed = struct {
    scheme: Scheme,
    host: []const u8,
    path: []const u8,
};

pub fn parseConnectUrl(url: []const u8) Parsed {
    const u = if (isUrl(url)) urlDecode(url) else url;
    var scheme: Scheme = .local;
    var host: []const u8 = u;
    var sep: u8 = '/';
    if (std.mem.indexOf(u8, u, "://")) |i| {
        const name = u[0..i];
        if (util.eql(name, "ssh") or util.eql(name, "git+ssh") or util.eql(name, "ssh+git")) {
            scheme = .ssh;
        } else if (util.eql(name, "git")) {
            scheme = .git;
        } else if (util.eql(name, "file")) {
            scheme = .file;
        } else util.die("protocol '{s}' is not supported", .{name});
        host = u[i + 3 ..];
    } else {
        if (!urlIsLocalNotSsh(u)) {
            scheme = .ssh;
            sep = ':';
        }
    }
    const end = hostEnd(host);
    var ps: usize = undefined;
    if (scheme == .local) {
        ps = end;
    } else {
        ps = std.mem.indexOfScalarPos(u8, host, end, sep) orelse
            util.die("no path specified; see 'git help pull' for valid url syntax", .{});
    }
    if (ps >= host.len) util.die("no path specified; see 'git help pull' for valid url syntax", .{});
    var path = host[ps..];
    if (sep == ':') path = path[1..];
    if (scheme == .git or scheme == .ssh) {
        if (path.len > 1 and path[1] == '~') path = path[1..];
    }
    return .{ .scheme = scheme, .host = host[0..ps], .path = path };
}

pub const HostPort = struct { host: []const u8, port: ?[]const u8 };

/// get_host_and_port(): strips brackets and a valid (or empty) ":port".
pub fn getHostAndPort(hostport: []const u8) HostPort {
    var hb: util.Buf = .empty;
    var start: usize = 0;
    if (std.mem.indexOf(u8, hostport, "@[")) |p| start = p + 1;
    var host: []const u8 = hostport;
    var rest_off: usize = 0;
    if (start < hostport.len and hostport[start] == '[') {
        if (std.mem.indexOfScalarPos(u8, hostport, start + 1, ']')) |e| {
            util.bufAppend(&hb, hostport[0..start]);
            util.bufAppend(&hb, hostport[start + 1 .. e]);
            const after = hostport[e + 1 ..];
            if (std.mem.indexOfScalar(u8, after, ':')) |c| {
                if (parsePort(after[c + 1 ..])) return .{ .host = hb.items, .port = after[c + 1 ..] };
            }
            return .{ .host = hb.items, .port = null };
        }
    }
    _ = &rest_off;
    if (std.mem.indexOfScalar(u8, host, ':')) |c| {
        if (parsePort(host[c + 1 ..])) {
            return .{ .host = host[0..c], .port = host[c + 1 ..] };
        } else if (c + 1 == host.len) {
            host = host[0..c];
        }
    }
    return .{ .host = host, .port = null };
}

/// get_port(): a trailing ":port" on an already bracket-stripped host.
pub fn getPort(hp: *HostPort) void {
    if (hp.port != null) return;
    if (std.mem.indexOfScalar(u8, hp.host, ':')) |c| {
        if (parsePort(hp.host[c + 1 ..])) {
            hp.port = hp.host[c + 1 ..];
            hp.host = hp.host[0..c];
        }
    }
}

pub fn looksLikeOption(s: []const u8) bool {
    return s.len > 0 and s[0] == '-';
}

// ---------------- shell command preparation ----------------

/// prepare_shell_cmd(): wrap argv in "sh -c" when argv[0] has metacharacters.
pub fn prepareShellCmd(argv: []const []const u8) []const []const u8 {
    var out: std.ArrayList([]const u8) = .empty;
    const cmd = argv[0];
    if (std.mem.indexOfAny(u8, cmd, "|&;<>()$`\\\"' \t\n*?[#~=%") != null) {
        out.append(gpa, "/bin/sh") catch util.oom();
        out.append(gpa, "-c") catch util.oom();
        if (argv.len > 1) {
            out.append(gpa, util.concat(&.{ cmd, " \"$@\"" })) catch util.oom();
        } else {
            out.append(gpa, cmd) catch util.oom();
        }
    }
    out.appendSlice(gpa, argv) catch util.oom();
    return out.items;
}

// ---------------- ssh ----------------

pub const Variant = enum { auto, simple, ssh, plink, putty, tortoiseplink };

fn getSshCommand() ?[]const u8 {
    if (os.getenv("GIT_SSH_COMMAND")) |s| return s;
    if (repo_mod.cfg.getEntry("core.sshcommand")) |e| {
        if (e.value) |v| return v;
        _ = config.errorNonbool("core.sshcommand");
        util.die("bad config variable '{s}'", .{"core.sshcommand"});
    }
    return null;
}

fn overrideVariant(v: *Variant) void {
    const variant = os.getenv("GIT_SSH_VARIANT") orelse (cfgString("ssh.variant") orelse return);
    if (util.eql(variant, "auto")) {
        v.* = .auto;
    } else if (util.eql(variant, "plink")) {
        v.* = .plink;
    } else if (util.eql(variant, "putty")) {
        v.* = .putty;
    } else if (util.eql(variant, "tortoiseplink")) {
        v.* = .tortoiseplink;
    } else if (util.eql(variant, "simple")) {
        v.* = .simple;
    } else v.* = .ssh;
}

/// split_cmdline(): only the first word matters here.
fn firstWord(s: []const u8) ?[]const u8 {
    var cur: util.Buf = .empty;
    var quote: u8 = 0;
    var started = false;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        const ch = s[i];
        if (quote == 0 and std.ascii.isWhitespace(ch)) {
            if (started) return cur.items;
            continue;
        }
        started = true;
        if (quote == 0 and (ch == '"' or ch == '\'')) {
            quote = ch;
        } else if (quote != 0 and ch == quote) {
            quote = 0;
        } else if (ch == '\\' and quote != '\'' and i + 1 < s.len) {
            i += 1;
            util.bufByte(&cur, s[i]);
        } else util.bufByte(&cur, ch);
    }
    if (quote != 0) return null;
    if (!started) return null;
    return cur.items;
}

fn cBasename(p: []const u8) []const u8 {
    var s = p;
    while (s.len > 1 and s[s.len - 1] == '/') s = s[0 .. s.len - 1];
    if (std.mem.lastIndexOfScalar(u8, s, '/')) |i| {
        if (s.len > 1) return s[i + 1 ..];
    }
    return s;
}

fn determineVariant(ssh: []const u8, is_cmdline: bool) Variant {
    var v: Variant = .auto;
    overrideVariant(&v);
    if (v != .auto) return v;
    const name = if (!is_cmdline) cBasename(ssh) else cBasename(firstWord(ssh) orelse return v);
    if (std.ascii.eqlIgnoreCase(name, "ssh") or std.ascii.eqlIgnoreCase(name, "ssh.exe")) return .ssh;
    if (std.ascii.eqlIgnoreCase(name, "plink") or std.ascii.eqlIgnoreCase(name, "plink.exe")) return .plink;
    if (std.ascii.eqlIgnoreCase(name, "tortoiseplink") or std.ascii.eqlIgnoreCase(name, "tortoiseplink.exe")) return .tortoiseplink;
    return v;
}

pub const CONNECT_IPV4: u8 = 4;
pub const CONNECT_IPV6: u8 = 6;

const Env = std.ArrayList([2][]const u8);

fn pushSshOptions(args: *std.ArrayList([]const u8), env: *Env, variant: Variant, port: ?[]const u8, version: u32, family: u8) void {
    if (variant == .ssh and version > 0) {
        args.appendSlice(gpa, &.{ "-o", "SendEnv=GIT_PROTOCOL" }) catch util.oom();
        env.append(gpa, .{ "GIT_PROTOCOL", util.fmt("version={d}", .{version}) }) catch util.oom();
    }
    if (family == CONNECT_IPV4) {
        if (variant == .simple) util.die("ssh variant 'simple' does not support -4", .{});
        args.append(gpa, "-4") catch util.oom();
    } else if (family == CONNECT_IPV6) {
        if (variant == .simple) util.die("ssh variant 'simple' does not support -6", .{});
        args.append(gpa, "-6") catch util.oom();
    }
    if (variant == .tortoiseplink) args.append(gpa, "-batch") catch util.oom();
    if (port) |p| {
        switch (variant) {
            .simple => util.die("ssh variant 'simple' does not support setting port", .{}),
            .ssh, .auto => args.append(gpa, "-p") catch util.oom(),
            .plink, .putty, .tortoiseplink => args.append(gpa, "-P") catch util.oom(),
        }
        args.append(gpa, p) catch util.oom();
    }
}

pub const Command = struct {
    /// final argv to exec (already shell-wrapped when needed)
    argv: []const []const u8,
    env: []const [2][]const u8,
};

/// fill_ssh_args() + the trailing remote command; returns the argv to exec.
pub fn sshCommand(ssh_host: []const u8, port: ?[]const u8, version: u32, family: u8, remote_cmd: []const u8) Command {
    if (looksLikeOption(ssh_host)) util.die("strange hostname '{s}' blocked", .{ssh_host});
    var use_shell = true;
    var variant: Variant = undefined;
    var ssh: []const u8 = undefined;
    if (getSshCommand()) |s| {
        ssh = s;
        variant = determineVariant(s, true);
    } else {
        use_shell = false;
        ssh = os.getenv("GIT_SSH") orelse "ssh";
        variant = determineVariant(ssh, false);
    }
    if (variant == .auto) {
        var dargs: std.ArrayList([]const u8) = .empty;
        var denv: Env = .empty;
        dargs.appendSlice(gpa, &.{ ssh, "-G" }) catch util.oom();
        pushSshOptions(&dargs, &denv, .ssh, port, version, family);
        dargs.append(gpa, ssh_host) catch util.oom();
        if (!use_shell and !runnable(ssh)) util.err("cannot run {s}: No such file or directory", .{ssh});
        const r = os.run(dargs.items, .{ .use_shell = use_shell, .no_stdin = true, .capture_stdout = true, .no_stderr = true, .env = denv.items});
        variant = if (r.status != 0) .simple else .ssh;
    }
    var args: std.ArrayList([]const u8) = .empty;
    var env: Env = .empty;
    args.append(gpa, ssh) catch util.oom();
    pushSshOptions(&args, &env, variant, port, version, family);
    args.append(gpa, ssh_host) catch util.oom();
    args.append(gpa, remote_cmd) catch util.oom();
    return .{ .argv = if (use_shell) prepareShellCmd(args.items) else args.items, .env = env.items };
}

// ---------------- git:// ----------------

const AddrInfo = extern struct {
    ai_flags: c_int,
    ai_family: c_int,
    ai_socktype: c_int,
    ai_protocol: c_int,
    ai_addrlen: u32,
    ai_addr: ?*anyopaque,
    ai_canonname: ?[*:0]u8,
    ai_next: ?*AddrInfo,
};
extern "c" fn getaddrinfo(node: [*:0]const u8, service: [*:0]const u8, hints: *const AddrInfo, res: *?*AddrInfo) c_int;
extern "c" fn freeaddrinfo(ai: *AddrInfo) void;
extern "c" fn gai_strerror(e: c_int) [*:0]const u8;
extern "c" fn getnameinfo(sa: ?*anyopaque, salen: u32, host: [*]u8, hostlen: u32, serv: ?[*]u8, servlen: u32, flags: c_int) c_int;
extern "c" fn socket(domain: c_int, ty: c_int, protocol: c_int) c_int;
extern "c" fn connect(fd: c_int, addr: ?*anyopaque, len: u32) c_int;
extern "c" fn setsockopt(fd: c_int, level: c_int, name: c_int, val: *const anyopaque, len: u32) c_int;
extern "c" fn dup(fd: c_int) c_int;

fn aiName(ai: *const AddrInfo) []const u8 {
    var buf: [1025]u8 = undefined;
    if (getnameinfo(ai.ai_addr, ai.ai_addrlen, &buf, buf.len, null, 0, 1) != 0) return "(unknown)";
    const n = std.mem.indexOfScalar(u8, &buf, 0) orelse buf.len;
    return util.dupe(buf[0..n]);
}

/// git_tcp_connect_sock(): returns a connected socket or dies.
pub fn tcpConnect(hostport: []const u8, family: u8, verbose: bool) c_int {
    var hp = getHostAndPort(hostport);
    var port: []const u8 = hp.port orelse "9418";
    // an empty port after ':' was stripped by getHostAndPort
    if (port.len == 0) port = "<none>";
    _ = &hp;
    var hints = std.mem.zeroes(AddrInfo);
    if (family == CONNECT_IPV4) hints.ai_family = 2 else if (family == CONNECT_IPV6) hints.ai_family = 10;
    hints.ai_socktype = 1;
    hints.ai_protocol = 6;
    if (verbose) util.eprint("Looking up {s} ... ", .{hp.host});
    var res: ?*AddrInfo = null;
    const gai = getaddrinfo(os.z(hp.host), os.z(port), &hints, &res);
    if (gai != 0) util.die("unable to look up {s} (port {s}) ({s})", .{ hp.host, port, std.mem.span(gai_strerror(gai)) });
    if (verbose) util.eprint("done.\nConnecting to {s} (port {s}) ... ", .{ hp.host, port });
    var msg: util.Buf = .empty;
    var sock: c_int = -1;
    var cnt: usize = 0;
    var ai = res;
    while (ai) |a| : ({
        ai = a.ai_next;
        cnt += 1;
    }) {
        sock = socket(a.ai_family, a.ai_socktype, a.ai_protocol);
        if (sock < 0 or connect(sock, a.ai_addr, a.ai_addrlen) < 0) {
            util.bufAppend(&msg, util.fmt("{s}[{d}: {s}]: errno={s}\n", .{ hp.host, cnt, aiName(a), os.lastErr() }));
            if (sock >= 0) os.close(sock);
            sock = -1;
            continue;
        }
        if (verbose) util.eprint("{s} ", .{aiName(a)});
        break;
    }
    if (res) |r| freeaddrinfo(r);
    if (sock < 0) util.die("unable to connect to {s}:\n{s}", .{ hp.host, msg.items });
    const one: c_int = 1;
    if (setsockopt(sock, 1, 9, &one, @sizeOf(c_int)) < 0) util.err("unable to set SO_KEEPALIVE on socket: {s}", .{os.lastErr()});
    if (verbose) util.eprint("done.\n", .{});
    return sock;
}

pub fn dupFd(fd: c_int) c_int {
    return dup(fd);
}

/// git_use_proxy(): GIT_PROXY_COMMAND / core.gitproxy for this host.
pub fn proxyCommand(host: []const u8) ?[]const u8 {
    var cmd: ?[]const u8 = os.getenv("GIT_PROXY_COMMAND");
    if (cmd == null) {
        for (repo_mod.cfg.entries.items) |e| {
            if (!util.eql(e.key, "core.gitproxy")) continue;
            const value = e.value orelse {
                _ = config.errorNonbool(e.key);
                util.die("bad config variable '{s}'", .{e.key});
            };
            var matchlen: isize = -1;
            if (std.mem.indexOf(u8, value, " for ")) |fp| {
                const pat = value[fp + 5 ..];
                if (host.len >= pat.len and util.eql(host[host.len - pat.len ..], pat) and
                    (host.len == pat.len or host[host.len - pat.len - 1] == '.'))
                    matchlen = @intCast(fp);
            } else matchlen = @intCast(value.len);
            if (matchlen >= 0) {
                var ml: usize = @intCast(matchlen);
                if (ml == 4 and util.eql(value[0..4], "none")) ml = 0;
                cmd = value[0..ml];
                break;
            }
        }
    }
    const c = cmd orelse return null;
    if (c.len == 0) return null;
    return c;
}

/// The PATH lookup start_command() does before forking; dies like C when
/// the program cannot be found.
pub fn checkRunnable(argv0: []const u8) void {
    if (runnable(argv0)) return;
    util.err("cannot run {s}: No such file or directory", .{argv0});
    util.die("unable to fork", .{});
}

fn runnable(argv0: []const u8) bool {
    if (std.mem.indexOfScalar(u8, argv0, '/') != null) return os.exists(argv0);
    const path = os.getenv("PATH") orelse "/usr/local/bin:/usr/bin:/bin";
    var it = std.mem.splitScalar(u8, path, ':');
    while (it.next()) |d| {
        const dir = if (d.len == 0) "." else d;
        const p = util.concat(&.{ dir, "/", argv0 });
        if (os.access(p, 1) and !os.isDir(p)) return true;
    }
    return false;
}
