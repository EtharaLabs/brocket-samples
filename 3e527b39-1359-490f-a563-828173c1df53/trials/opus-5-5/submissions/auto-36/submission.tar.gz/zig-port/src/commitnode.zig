//! In-memory object graph used by revision walking (port of object.c/commit.c
//! lookup + parse bits, commit_list helpers and prio-queue.c).
//!
//! Every object (commit/tree/blob/tag) is interned once per process; `Obj.flags`
//! carries the walk flags (SEEN, UNINTERESTING, ...). A `Commit` embeds its `Obj`
//! as the first field `obj`; use `Commit.fromObj(o)` to go back.

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const objects = @import("objects.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const ObjType = odb_mod.ObjType;

// ---- object flags (revision.h) ----
pub const SEEN: u32 = 1 << 0;
pub const UNINTERESTING: u32 = 1 << 1;
pub const TREESAME: u32 = 1 << 2;
pub const SHOWN: u32 = 1 << 3;
pub const TMP_MARK: u32 = 1 << 4;
pub const BOUNDARY: u32 = 1 << 5;
pub const CHILD_SHOWN: u32 = 1 << 6;
pub const ADDED: u32 = 1 << 7;
pub const SYMMETRIC_LEFT: u32 = 1 << 8;
pub const PATCHSAME: u32 = 1 << 9;
pub const BOTTOM: u32 = 1 << 10;
pub const PULL_MERGE: u32 = 1 << 15;
// commit-reach.c
pub const PARENT1: u32 = 1 << 16;
pub const PARENT2: u32 = 1 << 17;
pub const STALE: u32 = 1 << 18;
pub const RESULT: u32 = 1 << 19;
pub const ENQUEUED: u32 = 1 << 20;
pub const TOPO_WALK_EXPLORED: u32 = 1 << 23;
pub const TOPO_WALK_INDEGREE: u32 = 1 << 24;
pub const NOT_USER_GIVEN: u32 = 1 << 25;
pub const TRACK_LINEAR: u32 = 1 << 26;
pub const ANCESTRY_PATH: u32 = 1 << 27;
pub const CHILD_VISITED: u32 = 1 << 28;
pub const ALL_REV_FLAGS: u32 = ((1 << 11) - 1) | NOT_USER_GIVEN | TRACK_LINEAR | PULL_MERGE | CHILD_VISITED;

pub const Obj = struct {
    oid: Oid,
    typ: ObjType,
    flags: u32 = 0,
    parsed: bool = false,
};

pub const CommitList = struct {
    item: *Commit,
    next: ?*CommitList = null,
};

pub const Commit = struct {
    obj: Obj,
    parents: ?*CommitList = null,
    /// committer date (timestamp_t semantics: unsigned)
    date: u64 = 0,
    tree: Oid = hash.zero,
    /// raw commit object contents (after parse)
    buffer: []const u8 = "",
    /// dense index for "slabs" (per-commit side tables)
    index: u32 = 0,
    /// parse failed
    corrupt: bool = false,

    pub fn fromObj(o: *Obj) *Commit {
        return @alignCast(@fieldParentPtr("obj", o));
    }
    pub fn oid(self: *const Commit) Oid {
        return self.obj.oid;
    }
    pub fn hex(self: *const Commit) [40]u8 {
        return hash.hex(self.obj.oid);
    }
    pub fn parentCount(self: *const Commit) usize {
        return listCount(self.parents);
    }
    /// Raw message (after the header block).
    pub fn message(self: *Commit) []const u8 {
        _ = parse(self);
        const b = self.buffer;
        if (std.mem.indexOf(u8, b, "\n\n")) |i| return b[i + 2 ..];
        return "";
    }
};

var objs: hash.OidMap(*Obj) = .empty;
var commit_count: u32 = 0;

/// All commits created so far (index -> commit)
pub var all_commits: std.ArrayList(*Commit) = .empty;

pub fn lookupAny(oid: Oid) ?*Obj {
    return objs.get(oid);
}

/// lookup_object of a given type; creates it if needed. Returns null if an
/// object with the same oid exists with a different (known) type.
pub fn lookup(oid: Oid, typ: ObjType) ?*Obj {
    if (objs.get(oid)) |o| {
        if (o.typ == typ) return o;
        if (o.typ == .none) {
            // unknown placeholder: upgrade (only commits need a different layout)
            if (typ != .commit) {
                o.typ = typ;
                return o;
            }
            return null;
        }
        return null;
    }
    if (typ == .commit) {
        const c = gpa.create(Commit) catch util.oom();
        c.* = .{ .obj = .{ .oid = oid, .typ = .commit }, .index = commit_count };
        commit_count += 1;
        all_commits.append(gpa, c) catch util.oom();
        objs.put(gpa, oid, &c.obj) catch util.oom();
        return &c.obj;
    }
    const o = gpa.create(Obj) catch util.oom();
    o.* = .{ .oid = oid, .typ = typ };
    objs.put(gpa, oid, o) catch util.oom();
    return o;
}

pub fn lookupCommit(oid: Oid) ?*Commit {
    const o = lookup(oid, .commit) orelse return null;
    return Commit.fromObj(o);
}

/// parse_object: read the object, determining its type. Returns null if missing.
pub fn parseObject(oid: Oid) ?*Obj {
    if (objs.get(oid)) |o| {
        if (o.typ == .commit) {
            if (!parse(Commit.fromObj(o))) return null;
            return o;
        }
        if (o.parsed) return o;
    }
    const t = repo_mod.repo().odb().readType(oid) orelse return null;
    const o = lookup(oid, t) orelse return null;
    if (t == .commit) {
        if (!parse(Commit.fromObj(o))) return null;
    } else o.parsed = true;
    return o;
}

/// Object type, reading the odb if necessary.
pub fn objType(oid: Oid) ?ObjType {
    if (objs.get(oid)) |o| if (o.typ != .none) return o.typ;
    return repo_mod.repo().odb().readType(oid);
}

/// Peel tags until reaching a non-tag object (deref_tag). Returns null on missing.
pub fn derefTag(o0: *Obj) ?*Obj {
    var o = o0;
    var depth: u32 = 0;
    while (o.typ == .tag and depth < 1000) : (depth += 1) {
        const data = repo_mod.repo().odb().read(o.oid) orelse return null;
        const t = objects.parseTag(data.data) orelse return null;
        o = parseObject(t.object) orelse return null;
    }
    return o;
}

/// lookup_commit_reference_gently: peel tags to a commit.
pub fn lookupCommitReference(oid: Oid) ?*Commit {
    const o = parseObject(oid) orelse return null;
    const p = derefTag(o) orelse return null;
    if (p.typ != .commit) return null;
    return Commit.fromObj(p);
}

/// parse_commit; returns false on failure (missing / corrupt).
pub fn parse(c: *Commit) bool {
    if (c.obj.parsed) return true;
    if (c.corrupt) return false;
    const raw = objects.readCommit(c.obj.oid) orelse {
        c.corrupt = true;
        return false;
    };
    c.buffer = raw.raw;
    c.tree = raw.tree;
    var tail: *?*CommitList = &c.parents;
    for (raw.parents) |p| {
        const pc = lookupCommit(p) orelse continue;
        const n = gpa.create(CommitList) catch util.oom();
        n.* = .{ .item = pc };
        tail.* = n;
        tail = &n.next;
    }
    c.date = parseCommitDate(raw.raw);
    c.obj.parsed = true;
    return true;
}

pub fn parseOrDie(c: *Commit) void {
    if (!parse(c)) util.die("unable to parse commit {s}", .{hash.hex(c.obj.oid)});
}

/// port of parse_commit_date()
fn parseCommitDate(buf: []const u8) u64 {
    // skip tree and parent lines
    var pos: usize = 0;
    while (pos < buf.len) {
        if (util.startsWith(buf[pos..], "tree ") or util.startsWith(buf[pos..], "parent ")) {
            const nl = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse return 0;
            pos = nl + 1;
        } else break;
    }
    const b = buf[pos..];
    if (b.len <= 6 or !util.startsWith(b, "author")) return 0;
    const nl1 = std.mem.indexOfScalar(u8, b, '\n') orelse return 0;
    const rest = b[nl1 + 1 ..];
    if (rest.len <= 9 or !util.startsWith(rest, "committer")) return 0;
    const eol = std.mem.indexOfScalar(u8, rest, '\n') orelse return 0;
    var d = eol;
    while (d > 0 and rest[d - 1] != '>') d -= 1;
    if (d == 0) return 0;
    while (d < eol and std.ascii.isWhitespace(rest[d])) d += 1;
    if (d >= rest.len) return 0;
    if (!std.ascii.isDigit(rest[d]) and rest[d] != '-') return 0;
    return parseTimestamp(rest[d..eol]);
}

/// strtoumax-like
pub fn parseTimestamp(s: []const u8) u64 {
    var i: usize = 0;
    while (i < s.len and std.ascii.isWhitespace(s[i])) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '-' or s[i] == '+')) {
        neg = s[i] == '-';
        i += 1;
    }
    var v: u64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) {
        const m = @mulWithOverflow(v, 10);
        const a = @addWithOverflow(m[0], s[i] - '0');
        if (m[1] != 0 or a[1] != 0) return std.math.maxInt(u64);
        v = a[0];
    }
    return if (neg) 0 -% v else v;
}

/// Find a header line value in a commit buffer ("author", "committer", "encoding"...).
pub fn findHeader(buf: []const u8, key: []const u8) ?[]const u8 {
    var pos: usize = 0;
    while (pos < buf.len) {
        const nl = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse buf.len;
        const line = buf[pos..nl];
        if (line.len == 0) return null;
        if (line.len > key.len and util.startsWith(line, key) and line[key.len] == ' ') return line[key.len + 1 ..];
        pos = nl + 1;
    }
    return null;
}

// ---------------- commit_list helpers ----------------

pub fn newNode(item: *Commit, next: ?*CommitList) *CommitList {
    const n = gpa.create(CommitList) catch util.oom();
    n.* = .{ .item = item, .next = next };
    return n;
}

/// commit_list_insert: push at front of *list_p, returns the new node.
pub fn listInsert(item: *Commit, list_p: *?*CommitList) *CommitList {
    const n = newNode(item, list_p.*);
    list_p.* = n;
    return n;
}

/// commit_list_append: append at *tail, return pointer to new tail's next.
pub fn listAppend(item: *Commit, tail: *?*CommitList) *?*CommitList {
    const n = newNode(item, null);
    tail.* = n;
    return &n.next;
}

pub fn listCount(l0: ?*CommitList) usize {
    var n: usize = 0;
    var l = l0;
    while (l) |x| : (l = x.next) n += 1;
    return n;
}

pub fn listContains(item: *Commit, l0: ?*CommitList) bool {
    var l = l0;
    while (l) |x| : (l = x.next) if (x.item == item) return true;
    return false;
}

pub fn listCopy(l0: ?*CommitList) ?*CommitList {
    var head: ?*CommitList = null;
    var tail = &head;
    var l = l0;
    while (l) |x| : (l = x.next) tail = listAppend(x.item, tail);
    return head;
}

pub fn listReverse(l0: ?*CommitList) ?*CommitList {
    var next: ?*CommitList = null;
    var cur = l0;
    while (cur) |c| {
        const backup = c.next;
        c.next = next;
        next = c;
        cur = backup;
    }
    return next;
}

pub fn popCommit(stack: *?*CommitList) ?*Commit {
    const top = stack.* orelse return null;
    stack.* = top.next;
    return top.item;
}

/// commit_list_insert_by_date
pub fn listInsertByDate(item: *Commit, list: *?*CommitList) *CommitList {
    var pp = list;
    while (pp.*) |p| {
        if (p.item.date < item.date) break;
        pp = &p.next;
    }
    return listInsert(item, pp);
}

/// Stable merge sort of a commit list by a "less" predicate (mirrors DEFINE_LIST_SORT).
pub fn listSort(list: *?*CommitList, ctx: anytype, comptime cmp: fn (@TypeOf(ctx), *Commit, *Commit) i32) void {
    var arr: std.ArrayList(*CommitList) = .empty;
    var l = list.*;
    while (l) |x| : (l = x.next) arr.append(gpa, x) catch util.oom();
    if (arr.items.len < 2) return;
    const Ctx = struct {
        c: @TypeOf(ctx),
        fn lt(self: @This(), a: *CommitList, b: *CommitList) bool {
            return cmp(self.c, a.item, b.item) < 0;
        }
    };
    std.sort.block(*CommitList, arr.items, Ctx{ .c = ctx }, Ctx.lt);
    for (arr.items, 0..) |n, i| n.next = if (i + 1 < arr.items.len) arr.items[i + 1] else null;
    list.* = arr.items[0];
}

fn cmpDateDesc(_: void, a: *Commit, b: *Commit) i32 {
    if (a.date < b.date) return 1;
    if (a.date > b.date) return -1;
    return 0;
}

pub fn listSortByDate(list: *?*CommitList) void {
    var arr: std.ArrayList(*CommitList) = .empty;
    var l = list.*;
    while (l) |x| : (l = x.next) arr.append(gpa, x) catch util.oom();
    if (arr.items.len < 2) return;
    std.sort.block(*CommitList, arr.items, {}, struct {
        fn lt(_: void, a: *CommitList, b: *CommitList) bool {
            return a.item.date > b.item.date;
        }
    }.lt);
    for (arr.items, 0..) |n, i| n.next = if (i + 1 < arr.items.len) arr.items[i + 1] else null;
    list.* = arr.items[0];
}

/// clear_commit_marks
pub fn clearCommitMarks(commit: *Commit, mark: u32) void {
    var list: ?*CommitList = null;
    clearMarks1(&list, commit, mark);
    while (popCommit(&list)) |c| clearMarks1(&list, c, mark);
}

fn clearMarks1(plist: *?*CommitList, commit0: *Commit, mark: u32) void {
    var commit: ?*Commit = commit0;
    while (commit) |c| {
        if (mark & c.obj.flags == 0) return;
        c.obj.flags &= ~mark;
        const parents = c.parents orelse return;
        var p = parents.next;
        while (p) |x| : (p = x.next) {
            if (x.item.obj.flags & mark != 0) _ = listInsert(x.item, plist);
        }
        commit = parents.item;
    }
}

pub fn clearCommitMarksMany(commits: []const *Commit, mark: u32) void {
    for (commits) |c| clearCommitMarks(c, mark);
}

/// Clear flags on every object we know of.
pub fn clearAllObjectFlags(mask: u32) void {
    var it = objs.valueIterator();
    while (it.next()) |o| o.*.flags &= ~mask;
}

// ---------------- prio queue ----------------

pub const CompareFn = *const fn (a: *Commit, b: *Commit, data: ?*anyopaque) i32;

pub fn compareByCommitDate(a: *Commit, b: *Commit, _: ?*anyopaque) i32 {
    if (a.date < b.date) return 1;
    if (a.date > b.date) return -1;
    return 0;
}

/// No commit-graph: generation is infinity for all, so same as commit date.
pub const compareByGenThenCommitDate = compareByCommitDate;

pub const PrioQueue = struct {
    const Item = struct { ctr: u64, data: *Commit };
    compare: ?CompareFn = null,
    cb_data: ?*anyopaque = null,
    array: std.ArrayList(Item) = .empty,
    insertion_ctr: u64 = 0,
    get_pending: bool = false,

    fn cmp(q: *PrioQueue, i: usize, j: usize) i32 {
        var c = q.compare.?(q.array.items[i].data, q.array.items[j].data, q.cb_data);
        if (c == 0) {
            const a = q.array.items[i].ctr;
            const b = q.array.items[j].ctr;
            c = @as(i32, @intFromBool(a > b)) - @as(i32, @intFromBool(a < b));
        }
        return c;
    }
    fn swap(q: *PrioQueue, i: usize, j: usize) void {
        std.mem.swap(Item, &q.array.items[i], &q.array.items[j]);
    }
    pub fn count(q: *const PrioQueue) usize {
        return q.array.items.len - @intFromBool(q.get_pending);
    }
    pub fn reverse(q: *PrioQueue) void {
        std.mem.reverse(Item, q.array.items);
    }
    pub fn clear(q: *PrioQueue) void {
        q.array.clearRetainingCapacity();
        q.insertion_ctr = 0;
        q.get_pending = false;
    }
    fn siftDownRoot(q: *PrioQueue) void {
        var ix: usize = 0;
        const n = q.array.items.len;
        while (ix * 2 + 1 < n) {
            var child = ix * 2 + 1;
            if (child + 1 < n and q.cmp(child, child + 1) >= 0) child += 1;
            if (q.cmp(ix, child) <= 0) break;
            q.swap(child, ix);
            ix = child;
        }
    }
    fn flushGet(q: *PrioQueue) void {
        if (!q.get_pending) return;
        q.get_pending = false;
        const last = q.array.pop().?;
        if (q.array.items.len > 0) {
            q.array.items[0] = last;
            q.siftDownRoot();
        }
    }
    pub fn put(q: *PrioQueue, thing: *Commit) void {
        if (q.get_pending) {
            q.get_pending = false;
            q.array.items[0] = .{ .ctr = q.insertion_ctr, .data = thing };
            q.insertion_ctr += 1;
            q.siftDownRoot();
            return;
        }
        q.array.append(gpa, .{ .ctr = q.insertion_ctr, .data = thing }) catch util.oom();
        q.insertion_ctr += 1;
        if (q.compare == null) return;
        var ix = q.array.items.len - 1;
        while (ix > 0) {
            const parent = (ix - 1) / 2;
            if (q.cmp(parent, ix) <= 0) break;
            q.swap(parent, ix);
            ix = parent;
        }
    }
    pub fn get(q: *PrioQueue) ?*Commit {
        const pending: usize = @intFromBool(q.get_pending);
        if (q.array.items.len <= pending) {
            q.array.clearRetainingCapacity();
            q.get_pending = false;
            return null;
        }
        if (q.compare == null) return q.array.pop().?.data;
        q.flushGet();
        q.get_pending = true;
        return q.array.items[0].data;
    }
    pub fn peek(q: *PrioQueue) ?*Commit {
        const pending: usize = @intFromBool(q.get_pending);
        if (q.array.items.len <= pending) {
            q.array.clearRetainingCapacity();
            q.get_pending = false;
            return null;
        }
        if (q.compare == null) return q.array.items[q.array.items.len - 1].data;
        q.flushGet();
        return q.array.items[0].data;
    }
    /// Items currently in the queue (unordered), skipping a pending-get root.
    pub fn items(q: *PrioQueue) []Item {
        q.flushGet();
        return q.array.items;
    }
};

/// pop_most_recent_commit
pub fn popMostRecentCommit(q: *PrioQueue, mark: u32) ?*Commit {
    const ret = q.get() orelse return null;
    var p = ret.parents;
    while (p) |x| : (p = x.next) {
        const c = x.item;
        if (parse(c) and c.obj.flags & mark == 0) {
            c.obj.flags |= mark;
            q.put(c);
        }
    }
    return ret;
}

// ---------------- topo sort ----------------

pub const SortOrder = enum { graph, commit_date, author_date };

/// author date of a commit (0 on failure)
pub fn authorDate(c: *Commit) u64 {
    _ = parse(c);
    const line = findHeader(c.buffer, "author") orelse return 0;
    const gt = std.mem.lastIndexOfScalar(u8, line, '>') orelse return 0;
    var r = line[gt + 1 ..];
    while (r.len > 0 and r[0] == ' ') r = r[1..];
    return parseTimestamp(r);
}

var author_dates: std.ArrayList(u64) = .empty;

pub fn compareByAuthorDate(a: *Commit, b: *Commit, _: ?*anyopaque) i32 {
    const ad = author_dates.items[a.index];
    const bd = author_dates.items[b.index];
    if (ad < bd) return 1;
    if (ad > bd) return -1;
    return 0;
}

pub fn recordAuthorDate(c: *Commit) void {
    while (author_dates.items.len <= c.index) author_dates.append(gpa, 0) catch util.oom();
    author_dates.items[c.index] = authorDate(c);
}

/// Slab of i32 indexed by commit.index.
pub fn Slab(comptime T: type) type {
    return struct {
        const Self = @This();
        data: std.ArrayList(T) = .empty,
        def: T,
        pub fn init(def: T) Self {
            return .{ .def = def };
        }
        pub fn at(self: *Self, c: *const Commit) *T {
            while (self.data.items.len <= c.index) self.data.append(gpa, self.def) catch util.oom();
            return &self.data.items[c.index];
        }
        pub fn peek(self: *const Self, c: *const Commit) ?*T {
            if (c.index >= self.data.items.len) return null;
            return &self.data.items[c.index];
        }
    };
}

/// sort_in_topological_order
pub fn sortInTopologicalOrder(list: *?*CommitList, order: SortOrder) void {
    const orig = list.* orelse return;
    list.* = null;
    var indegree = Slab(i32).init(0);
    var queue = PrioQueue{};
    switch (order) {
        .graph => queue.compare = null,
        .commit_date => queue.compare = compareByCommitDate,
        .author_date => queue.compare = compareByAuthorDate,
    }
    var next: ?*CommitList = orig;
    while (next) |n| : (next = n.next) {
        indegree.at(n.item).* = 1;
        if (order == .author_date) recordAuthorDate(n.item);
    }
    next = orig;
    while (next) |n| : (next = n.next) {
        var p = n.item.parents;
        while (p) |x| : (p = x.next) {
            const pi = indegree.at(x.item);
            if (pi.* != 0) pi.* += 1;
        }
    }
    next = orig;
    while (next) |n| : (next = n.next) {
        if (indegree.at(n.item).* == 1) queue.put(n.item);
    }
    if (order == .graph) queue.reverse();
    var tail = list;
    while (queue.get()) |commit| {
        var p = commit.parents;
        while (p) |x| : (p = x.next) {
            const pi = indegree.at(x.item);
            if (pi.* == 0) continue;
            pi.* -= 1;
            if (pi.* == 1) queue.put(x.item);
        }
        indegree.at(commit).* = 0;
        tail = listAppend(commit, tail);
    }
}

// ---------------------------------------------------------------------------
// on-disk object size (objectsize:disk / rev-list --disk-usage)

var pack_offsets: std.AutoHashMapUnmanaged(*odb_mod.Pack, []u64) = .empty;

fn sortedPackOffsets(p: *odb_mod.Pack) []u64 {
    if (pack_offsets.get(p)) |v| return v;
    const offs = gpa.alloc(u64, p.num + 1) catch util.oom();
    var i: u32 = 0;
    while (i < p.num) : (i += 1) offs[i] = p.offsetAt(i);
    const st = @import("os.zig").statPath(p.pack_path);
    const plen: u64 = if (st) |s| @intCast(s.size) else 0;
    offs[p.num] = if (plen >= 20) plen - 20 else plen;
    std.mem.sort(u64, offs, {}, std.sort.asc(u64));
    pack_offsets.put(gpa, p, offs) catch util.oom();
    return offs;
}

/// Size the object occupies on disk: packed entry length (pack checked
/// first, as odb_read_object_info_extended does) or loose file size.
pub fn objectDiskSize(oid: Oid) ?u64 {
    const odb = repo_mod.repo().odb();
    if (odb.findPacked(oid)) |loc| {
        const offs = sortedPackOffsets(loc.pack);
        const off = loc.pack.offsetAt(loc.idx);
        var lo: usize = 0;
        var hi: usize = offs.len;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            if (offs[mid] <= off) lo = mid + 1 else hi = mid;
        }
        if (lo < offs.len) return offs[lo] - off;
        return 0;
    }
    for (odb.allDirs()) |dir| {
        if (@import("os.zig").statPath(odb.looseObjectPath(dir, oid))) |st| return @intCast(st.size);
    }
    return null;
}

/// Delta base of a packed object (zero oid if not a delta or not packed).
pub fn objectDeltaBase(oid: Oid) Oid {
    const odb = repo_mod.repo().odb();
    const loc = odb.findPacked(oid) orelse return hash.zero;
    const p = loc.pack;
    if (p.pack == null) p.pack = @import("os.zig").readFile(p.pack_path);
    const data = p.pack orelse return hash.zero;
    const off = p.offsetAt(loc.idx);
    const hdr = odb_mod.parseEntryHeader(data, @intCast(off)) orelse return hash.zero;
    var pos: usize = @as(usize, @intCast(off)) + hdr.hdr_len;
    switch (@intFromEnum(hdr.typ)) {
        6 => {
            const rel = odb_mod.parseOfsDelta(data, &pos);
            const base_off = off - rel;
            var j: u32 = 0;
            while (j < p.num) : (j += 1) {
                if (p.offsetAt(j) == base_off) return p.oidAt(j);
            }
        },
        7 => {
            var b: Oid = hash.zero;
            if (pos + 20 <= data.len) @memcpy(&b, data[pos .. pos + 20]);
            return b;
        },
        else => {},
    }
    return hash.zero;
}
