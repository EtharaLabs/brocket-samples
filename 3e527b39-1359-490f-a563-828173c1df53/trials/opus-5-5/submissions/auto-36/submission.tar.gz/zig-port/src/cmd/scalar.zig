//! scalar: a front-end for managing large repositories (port of scalar.c).
//! Invoked when argv[0]'s basename is "scalar" (see main.zig).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const proc = @import("../proc.zig");
const trace2 = @import("../trace2.zig");
const gpa = util.gpa;

const main = @import("../main.zig");

/// run_git(): spawn `git <args...>`; returns the exit code.
fn runGit(args: []const []const u8) i32 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    const r = os.run(argv.items, .{});
    return r.status;
}

/// pipe_command() capturing stdout; null on failure.
fn captureGit(args: []const []const u8) ?[]const u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    const r = os.run(argv.items, .{ .capture_stdout = true });
    if (r.status != 0) return null;
    return r.stdout;
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return util.dupe(p);
    if (p.len == 0) util.die("The empty string is not a valid path", .{});
    var cwd: []const u8 = os.getcwd();
    if (os.getenv("PWD")) |pwd| {
        if (!util.eql(pwd, cwd)) {
            if (os.statPath(cwd)) |a| {
                if (os.statPath(pwd)) |b| {
                    if (a.dev == b.dev and a.ino == b.ino) cwd = pwd;
                }
            }
        }
    }
    if (cwd.len > 0 and cwd[cwd.len - 1] == '/') return util.concat(&.{ cwd, p });
    return util.concat(&.{ cwd, "/", p });
}

/// is_nonbare_repository_dir()
fn isNonbareRepositoryDir(path: []const u8) bool {
    const p = if (path.len > 0 and path[path.len - 1] == '/') util.concat(&.{ path, ".git" }) else util.concat(&.{ path, "/.git" });
    var e: repo_mod.GitfileErr = .none;
    if (repo_mod.readGitfileGently(p, &e) != null) return true;
    if (repo_mod.isGitDirectory(p)) return true;
    return e == .open_failed or e == .read_failed;
}

fn setupEnlistmentDirectory(args: []const []const u8, usage: []const []const u8, opts: []const po.Opt, want_root: bool) []const u8 {
    if (args.len > 1) po.usageWithOptions(usage, opts);
    var path: []const u8 = undefined;
    if (args.len == 1) {
        path = absPath(args[0]);
        if (!os.isDir(path)) util.die("'{s}' does not exist", .{path});
        if (!os.chdir(path)) util.dieErrno("could not switch to '{s}'", .{path});
    } else {
        path = os.getcwd();
    }
    while (path.len > 1 and path[path.len - 1] == '/') path = path[0 .. path.len - 1];

    var is_parent = false;
    const src = util.concat(&.{ path, "/src" });
    if (isNonbareRepositoryDir(src)) {
        is_parent = true;
        if (!os.chdir(src)) util.dieErrno("could not switch to '{s}'", .{src});
    }

    repo_mod.setup(false);
    const wt = repo_mod.repo().work_tree orelse util.die("Scalar enlistments require a worktree", .{});
    if (!want_root) return "";
    return if (is_parent) path else wt;
}

fn configPath() []const u8 {
    return repo_mod.repo().commonPath("config");
}

fn setScalarConfig(key: []const u8, value: []const u8) i32 {
    return config.setMultivarInFile(configPath(), key, value, .any, " # set by scalar", .{});
}

const ScalarConfig = struct {
    key: []const u8,
    value: []const u8,
    overwrite_on_reconfigure: bool = false,
};

fn configHasString(key: []const u8) bool {
    const e = repo_mod.cfg.getEntry(key) orelse return false;
    return e.value != null;
}

fn setConfigIfMissing(c: ScalarConfig, reconfigure: bool) i32 {
    if ((reconfigure and c.overwrite_on_reconfigure) or !configHasString(c.key)) {
        trace2.dataString("scalar", true, c.key, "created");
        return setScalarConfig(c.key, c.value);
    }
    trace2.dataString("scalar", true, c.key, "exists");
    return 0;
}

fn haveFsmonitorSupport() bool {
    // fsmonitor IPC is not supported on this platform
    return false;
}

const recommended = [_]ScalarConfig{
    .{ .key = "am.keepCR", .value = "true" },
    .{ .key = "commitGraph.changedPaths", .value = "true" },
    .{ .key = "commitGraph.generationVersion", .value = "1" },
    .{ .key = "core.autoCRLF", .value = "false" },
    .{ .key = "core.logAllRefUpdates", .value = "true" },
    .{ .key = "core.safeCRLF", .value = "false" },
    .{ .key = "credential.https://dev.azure.com.useHttpPath", .value = "true" },
    .{ .key = "feature.experimental", .value = "false" },
    .{ .key = "feature.manyFiles", .value = "false" },
    .{ .key = "fetch.showForcedUpdates", .value = "false" },
    .{ .key = "fetch.unpackLimit", .value = "1" },
    .{ .key = "fetch.writeCommitGraph", .value = "false" },
    .{ .key = "gc.auto", .value = "0" },
    .{ .key = "gui.GCWarning", .value = "false" },
    .{ .key = "index.skipHash", .value = "true", .overwrite_on_reconfigure = true },
    .{ .key = "index.threads", .value = "true" },
    .{ .key = "index.version", .value = "4" },
    .{ .key = "merge.renames", .value = "true" },
    .{ .key = "merge.stat", .value = "false" },
    .{ .key = "pack.useBitmaps", .value = "false" },
    .{ .key = "pack.usePathWalk", .value = "true" },
    .{ .key = "receive.autoGC", .value = "false" },
    .{ .key = "status.aheadBehind", .value = "false" },
    .{ .key = "core.untrackedCache", .value = "true" },
};

fn setRecommendedConfig(reconfigure: bool) i32 {
    repo_mod.loadConfig();
    for (recommended) |c| {
        if (setConfigIfMissing(c, reconfigure) != 0) {
            util.err("could not configure {s}={s}", .{ c.key, c.value });
            return -1;
        }
    }
    if (haveFsmonitorSupport()) {
        const f = ScalarConfig{ .key = "core.fsmonitor", .value = "true" };
        if (setConfigIfMissing(f, reconfigure) != 0) {
            util.err("could not configure {s}={s}", .{ f.key, f.value });
            return -1;
        }
    }
    if (!configHasString("log.excludeDecoration")) {
        trace2.dataString("scalar", true, "log.excludeDecoration", "created");
        if (setScalarConfig("log.excludeDecoration", "refs/prefetch/*") != 0) {
            util.err("could not configure log.excludeDecoration", .{});
            return -1;
        }
    } else {
        trace2.dataString("scalar", true, "log.excludeDecoration", "exists");
    }
    return 0;
}

fn toggleMaintenance(enable: bool) i32 {
    if (enable) return runGit(&.{ "maintenance", "start" });
    return runGit(&.{ "maintenance", "unregister", "--force" });
}

fn addOrRemoveEnlistment(add: bool) i32 {
    const wt = repo_mod.repo().work_tree orelse util.die("Scalar enlistments require a worktree", .{});
    const res = runGit(&.{ "config", "--global", "--get", "--fixed-value", "scalar.repo", wt });
    if ((add and res == 0) or (!add and res != 0)) return 0;
    return runGit(&.{ "config", "--global", if (add) "--add" else "--unset", if (add) "--no-fixed-value" else "--fixed-value", "scalar.repo", wt });
}

fn registerDir(maintenance: bool) i32 {
    if (addOrRemoveEnlistment(true) != 0) {
        util.err("could not add enlistment", .{});
        return -1;
    }
    if (setRecommendedConfig(false) != 0) {
        util.err("could not set recommended config", .{});
        return -1;
    }
    if (maintenance and toggleMaintenance(true) != 0)
        util.warn("could not toggle maintenance", .{});
    return 0;
}

fn unregisterDir() i32 {
    var res: i32 = 0;
    if (toggleMaintenance(false) != 0) {
        util.err("could not turn off maintenance", .{});
        res = -1;
    }
    if (addOrRemoveEnlistment(false) != 0) {
        util.err("could not remove enlistment", .{});
        res = -1;
    }
    return res;
}

/// set_config(): repo_config_set_gently() on the local config; null unsets.
fn setConfig(key: []const u8, value: ?[]const u8) i32 {
    return config.setMultivarInFile(configPath(), key, value, .any, null, .{});
}

fn remoteDefaultBranch(url: []const u8) ?[]const u8 {
    if (captureGit(&.{ "ls-remote", "--symref", url, "HEAD" })) |out| {
        var it = std.mem.splitScalar(u8, out, '\n');
        while (it.next()) |line0| {
            const p0 = util.skipPrefix(line0, "ref: ") orelse continue;
            if (!std.mem.endsWith(u8, p0, "\tHEAD")) continue;
            const p = p0[0 .. p0.len - 5];
            if (util.skipPrefix(p, "refs/heads/")) |b| return util.dupe(b);
            util.err("remote HEAD is not a branch: '{s}'", .{p});
            return null;
        }
    }
    util.warn("failed to get default branch name from remote; using local default", .{});
    if (captureGit(&.{ "symbolic-ref", "--short", "HEAD" })) |out| {
        return util.dupe(util.trim(out));
    }
    util.err("failed to get default branch name", .{});
    return null;
}

fn deleteEnlistment(enlistment: []const u8) i32 {
    if (unregisterDir() != 0) {
        util.err("failed to unregister repository", .{});
        return -1;
    }
    const offset: usize = if (enlistment.len > 0 and enlistment[0] == '/') 1 else 0;
    const parent = if (std.mem.lastIndexOfScalar(u8, enlistment[offset..], '/')) |i| enlistment[0 .. offset + i] else enlistment[0..offset];
    if (!os.chdir(parent)) {
        util.err("could not switch to '{s}': {s}", .{ parent, os.lastErr() });
        return -1;
    }
    os.removeTree(enlistment);
    if (os.lstatPath(enlistment) != null) {
        util.err("failed to delete enlistment directory", .{});
        return -1;
    }
    return 0;
}

const clone_usage = [_][]const u8{"scalar clone [--single-branch] [--branch <main-branch>] [--full-clone]\n" ++
    "\t[--[no-]src] [--[no-]tags] [--[no-]maintenance] <url> [<enlistment>]"};

fn cmdClone(args: []const []const u8) i32 {
    var branch: ?[]const u8 = null;
    var full_clone = false;
    var single_branch = false;
    const show_progress = os.isatty(2);
    var src = true;
    var tags = true;
    var maintenance = true;
    const opts = [_]po.Opt{
        po.string('b', "branch", &branch, "<branch>", "branch to checkout after clone"),
        po.boolean(0, "full-clone", &full_clone, "when cloning, create full working directory"),
        po.boolean(0, "single-branch", &single_branch, "only download metadata for the branch that will be checked out"),
        po.boolean(0, "src", &src, "create repository within 'src' directory"),
        po.boolean(0, "tags", &tags, "specify if tags should be fetched during clone"),
        po.boolean(0, "maintenance", &maintenance, "specify if background maintenance should be enabled"),
    };
    const rest = po.parse(args[1..], &opts, &clone_usage, .{});

    var url: []const u8 = undefined;
    var enlistment: []const u8 = undefined;
    if (rest.len == 2) {
        url = rest[0];
        enlistment = rest[1];
    } else if (rest.len == 1) {
        url = rest[0];
        var b = url;
        while (b.len > 0 and b[b.len - 1] == '/') b = b[0 .. b.len - 1];
        if (std.mem.endsWith(u8, b, ".git")) b = b[0 .. b.len - 4];
        const i = std.mem.lastIndexOfScalar(u8, b, '/') orelse util.die("cannot deduce worktree name from '{s}'", .{url});
        enlistment = util.dupe(b[i + 1 ..]);
    } else {
        util.flushStdout();
        util.eprint("fatal: You must specify a repository to clone.\n\n", .{});
        po.usageWithOptions(&clone_usage, &opts);
    }

    if (os.isDir(enlistment)) util.die("directory '{s}' exists already", .{enlistment});

    const dir = if (src) util.concat(&.{ enlistment, "/src" }) else enlistment;

    var defbranch: []const u8 = undefined;
    if (branch) |b| {
        defbranch = b;
    } else {
        repo_mod.loadConfig();
        defbranch = @import("init.zig").defaultBranchName(true);
    }
    var res = runGit(&.{ "-c", util.concat(&.{ "init.defaultBranch=", defbranch }), "init", "--", dir });
    if (res != 0) return res;

    if (!os.chdir(dir)) {
        util.err("could not switch to '{s}': {s}", .{ dir, os.lastErr() });
        return -1;
    }
    repo_mod.setup(false);

    if (branch == null) {
        branch = remoteDefaultBranch(url);
        if (branch == null) {
            util.err("failed to get default branch for '{s}'", .{url});
            return -1;
        }
    }
    const br = branch.?;
    const refspec_branch = if (single_branch) br else "*";

    if (setConfig("remote.origin.url", url) != 0 or
        setConfig("remote.origin.fetch", util.concat(&.{ "+refs/heads/", refspec_branch, ":refs/remotes/origin/", refspec_branch })) != 0 or
        setConfig("remote.origin.promisor", "true") != 0 or
        setConfig("remote.origin.partialCloneFilter", "blob:none") != 0)
    {
        util.err("could not configure remote in '{s}'", .{dir});
        return -1;
    }

    if (!tags and setConfig("remote.origin.tagOpt", "--no-tags") != 0) {
        util.err("could not disable tags in '{s}'", .{dir});
        return -1;
    }

    if (!full_clone) {
        res = runGit(&.{ "sparse-checkout", "init", "--cone" });
        if (res != 0) return res;
    }

    if (setRecommendedConfig(false) != 0) {
        util.err("could not configure '{s}'", .{dir});
        return -1;
    }

    const progress = if (show_progress) "--progress" else "--no-progress";
    res = if (tags)
        runGit(&.{ "fetch", "--quiet", progress, "origin" })
    else
        runGit(&.{ "fetch", "--quiet", progress, "origin", "--no-tags" });
    if (res != 0) {
        util.warn("partial clone failed; attempting full clone", .{});
        if (setConfig("remote.origin.promisor", null) != 0 or
            setConfig("remote.origin.partialCloneFilter", null) != 0)
        {
            util.err("could not configure for full clone", .{});
            return -1;
        }
        res = runGit(&.{ "fetch", "--quiet", progress, "origin" });
        if (res != 0) return res;
    }

    res = setConfig(util.concat(&.{ "branch.", br, ".remote" }), "origin");
    if (res != 0) return res;
    res = setConfig(util.concat(&.{ "branch.", br, ".merge" }), util.concat(&.{ "refs/heads/", br }));
    if (res != 0) return res;

    res = runGit(&.{ "checkout", "-f", "-t", util.concat(&.{ "origin/", br }) });
    if (res != 0) return res;

    return registerDir(maintenance);
}

fn cmdDiagnose(args: []const []const u8) i32 {
    const opts = [_]po.Opt{};
    const usage = [_][]const u8{"scalar diagnose [<enlistment>]"};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    const root = setupEnlistmentDirectory(rest, &usage, &opts, true);
    const out = util.concat(&.{ root, "/.scalarDiagnostics" });
    return runGit(&.{ "diagnose", "--mode=all", "-s", "%Y%m%d_%H%M%S", "-o", out });
}

fn cmdList(args: []const []const u8) i32 {
    if (args.len != 1) util.die("`scalar list` does not take arguments", .{});
    _ = runGit(&.{ "config", "--global", "--get-all", "scalar.repo" });
    return 0;
}

fn cmdRegister(args: []const []const u8) i32 {
    var maintenance = true;
    const opts = [_]po.Opt{
        po.boolean(0, "maintenance", &maintenance, "specify if background maintenance should be enabled"),
    };
    const usage = [_][]const u8{"scalar register [--[no-]maintenance] [<enlistment>]"};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    _ = setupEnlistmentDirectory(rest, &usage, &opts, false);
    return registerDir(maintenance);
}

fn removeDeletedEnlistment(path0: []const u8) i32 {
    var res: i32 = 0;
    const path = @import("../worktree.zig").realPathForgiving(path0);
    _ = runGit(&.{ "config", "--global", "--unset", "--fixed-value", "scalar.repo", path });
    _ = runGit(&.{ "config", "--global", "--unset", "--fixed-value", "maintenance.repo", path });
    res = 0;
    return res;
}

fn cmdReconfigure(args: []const []const u8) i32 {
    var all = false;
    var maintenance_str: ?[]const u8 = null;
    var maintenance: i32 = 1;
    const opts = [_]po.Opt{
        po.boolean('a', "all", &all, "reconfigure all registered enlistments"),
        po.string(0, "maintenance", &maintenance_str, "(enable|disable|keep)", "signal how to adjust background maintenance"),
    };
    const usage = [_][]const u8{"scalar reconfigure [--maintenance=(enable|disable|keep)] [--all | <enlistment>]"};
    const rest = po.parse(args[1..], &opts, &usage, .{});

    if (!all) {
        _ = setupEnlistmentDirectory(rest, &usage, &opts, false);
        return setRecommendedConfig(true);
    }

    if (rest.len > 0) {
        util.flushStdout();
        util.eprint("fatal: --all or <enlistment>, but not both\n\n", .{});
        po.usageWithOptions(&usage, &opts);
    }

    if (maintenance_str) |m| {
        if (util.eql(m, "enable")) {
            maintenance = 1;
        } else if (util.eql(m, "disable")) {
            maintenance = 0;
        } else if (util.eql(m, "keep")) {
            maintenance = -1;
        } else util.die("unknown mode for --maintenance option: {s}", .{m});
    }

    repo_mod.loadConfig();
    const repos = repo_mod.cfg.getAll("scalar.repo");
    var res: i32 = 0;
    for (repos) |dir| {
        var succeeded = false;
        loop: {
            if (!os.chdir(dir)) {
                const e = os.errno();
                if (e != os.ENOENT) {
                    util.warn("could not switch to '{s}': {s}", .{ dir, os.strErr(e) });
                    break :loop;
                }
                if (removeDeletedEnlistment(dir) != 0) {
                    util.err("could not remove stale scalar.repo '{s}'", .{dir});
                } else {
                    util.warn("removed stale scalar.repo '{s}'", .{dir});
                    succeeded = true;
                }
                break :loop;
            }
            const found = repo_mod.discoverGitDirectory();
            if (found == null) {
                util.warn("repository not found in '{s}'", .{dir});
                break :loop;
            }
            succeeded = true;
            const gd = repo_mod.realPathDup(found.?.gitdir, false) orelse break :loop;
            const cd = repo_mod.realPathDup(found.?.commondir, false) orelse break :loop;
            const f = repo_mod.readRepositoryFormat(util.concat(&.{ cd, "/config" }));
            const r = gpa.create(repo_mod.Repo) catch util.oom();
            r.* = .{
                .git_dir = gd,
                .common_dir = cd,
                .work_tree = null,
                .worktree_config = f.worktree_config,
                .object_format = f.object_format,
            };
            const old = repo_mod.repo_;
            repo_mod.repo_ = r;
            _ = setRecommendedConfig(true);
            repo_mod.repo_ = old;
            repo_mod.loadConfig();

            if (maintenance >= 0) _ = toggleMaintenance(maintenance == 1);
        }
        if (!succeeded) {
            res = -1;
            util.warn("to unregister this repository from Scalar, run\n\tgit config --global --unset --fixed-value scalar.repo \"{s}\"", .{dir});
        }
    }
    return res;
}

const run_tasks = [_][2]?[]const u8{
    .{ "config", null },
    .{ "commit-graph", "commit-graph" },
    .{ "fetch", "prefetch" },
    .{ "loose-objects", "loose-objects" },
    .{ "pack-files", "incremental-repack" },
};

fn cmdRun(args: []const []const u8) i32 {
    const opts = [_]po.Opt{};
    var b: util.Buf = .empty;
    util.bufAppend(&b, "scalar run <task> [<enlistment>]\nTasks:\n");
    for (run_tasks) |t| util.bufPrint(&b, "\t{s}\n", .{t[0].?});
    const usage = [_][]const u8{b.items};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len == 0) po.usageWithOptions(&usage, &opts);

    var idx: ?usize = null;
    if (!util.eql(rest[0], "all")) {
        for (run_tasks, 0..) |t, i| {
            if (util.eql(t[0].?, rest[0])) {
                idx = i;
                break;
            }
        }
        if (idx == null) {
            util.err("no such task: '{s}'", .{rest[0]});
            po.usageWithOptions(&usage, &opts);
        }
    }
    _ = setupEnlistmentDirectory(rest[1..], &usage, &opts, false);

    if (idx) |i| {
        if (i == 0) return registerDir(true);
        return runGit(&.{ "maintenance", "run", "--task", run_tasks[i][1].? });
    }
    if (registerDir(true) != 0) return -1;
    for (run_tasks[1..]) |t| {
        if (runGit(&.{ "maintenance", "run", "--task", t[1].? }) != 0) return -1;
    }
    return 0;
}

fn cmdUnregister(args: []const []const u8) i32 {
    const opts = [_]po.Opt{};
    const usage = [_][]const u8{"scalar unregister [<enlistment>]"};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len == 1) {
        const src_path = util.concat(&.{ rest[0], "/src" });
        const wd_path = rest[0];
        if (!os.isDir(util.concat(&.{ src_path, "/.git" })) and !os.isDir(util.concat(&.{ wd_path, "/.git" }))) {
            var res: bool = true;
            res = removeDeletedEnlistment(src_path) != 0 and res;
            res = removeDeletedEnlistment(wd_path) != 0 and res;
            return if (res) 1 else 0;
        }
    }
    _ = setupEnlistmentDirectory(rest, &usage, &opts, false);
    return unregisterDir();
}

fn cmdDelete(args: []const []const u8) i32 {
    const cwd = os.getcwd();
    const opts = [_]po.Opt{};
    const usage = [_][]const u8{"scalar delete <enlistment>"};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len != 1) po.usageWithOptions(&usage, &opts);
    const enlistment = setupEnlistmentDirectory(rest, &usage, &opts, true);
    if (repo_mod.dirInsideOf(cwd, enlistment) != null) {
        util.err("refusing to delete current working directory", .{});
        return -1;
    }
    return deleteEnlistment(enlistment);
}

fn cmdHelp(args: []const []const u8) i32 {
    const opts = [_]po.Opt{};
    const usage = [_][]const u8{"scalar help"};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len != 0) po.usageWithOptions(&usage, &opts);
    return runGit(&.{ "help", "scalar" });
}

fn cmdVersion(args: []const []const u8) i32 {
    var verbose: i32 = 0;
    var build_options = false;
    const opts = [_]po.Opt{
        po.verbose(&verbose),
        po.boolean(0, "build-options", &build_options, "include Git's build options"),
    };
    const usage = [_][]const u8{"scalar verbose [-v | --verbose] [--build-options]"};
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len != 0) po.usageWithOptions(&usage, &opts);
    var b: util.Buf = .empty;
    util.bufPrint(&b, "git version {s}\n", .{main.version});
    if (build_options) {
        util.bufAppend(&b, "cpu: x86_64\nbuilt from commit: (none)\nsizeof-long: 8\nsizeof-size_t: 8\nshell-path: /bin/sh\nzlib: 1.3.1\nSHA-1: SHA1_DC\nSHA-256: SHA256_BLK\ndefault-ref-format: files\ndefault-hash: sha1\n");
    }
    util.eprint("{s}\n", .{b.items});
    return 0;
}

const Builtin = struct { name: []const u8, f: *const fn ([]const []const u8) i32 };

const builtins = [_]Builtin{
    .{ .name = "clone", .f = cmdClone },
    .{ .name = "list", .f = cmdList },
    .{ .name = "register", .f = cmdRegister },
    .{ .name = "unregister", .f = cmdUnregister },
    .{ .name = "run", .f = cmdRun },
    .{ .name = "reconfigure", .f = cmdReconfigure },
    .{ .name = "delete", .f = cmdDelete },
    .{ .name = "help", .f = cmdHelp },
    .{ .name = "version", .f = cmdVersion },
    .{ .name = "diagnose", .f = cmdDiagnose },
};

/// Entry point when invoked as `scalar` (args[0] is the program name).
pub fn scalarMain(all: []const []const u8) u8 {
    var args = if (all.len > 0) all[1..] else all;
    while (args.len > 0 and args[0].len > 0 and args[0][0] == '-') {
        if (util.eql(args[0], "-C")) {
            if (args.len < 2) util.die("-C requires a <directory>", .{});
            if (!os.chdir(args[1])) util.dieErrno("could not change to '{s}'", .{args[1]});
            args = args[2..];
        } else if (util.eql(args[0], "-c")) {
            if (args.len < 2) util.die("-c requires a <key>=<value> argument", .{});
            repo_mod.addCmdlineConfig(args[1]);
            args = args[2..];
        } else break;
    }

    if (args.len > 0) {
        for (builtins) |b| {
            if (util.eql(b.name, args[0])) {
                return if (b.f(args) != 0) 1 else 0;
            }
        }
    }

    var u: util.Buf = .empty;
    util.bufAppend(&u, "scalar [-C <directory>] [-c <key>=<value>] <command> [<options>]\n\nCommands:\n");
    for (builtins) |b| util.bufPrint(&u, "\t{s}\n", .{b.name});
    util.flushStdout();
    util.eprint("usage: {s}\n", .{u.items});
    os.exit(129);
}
