//! Fetch negotiators (fetch-negotiator.c, negotiator/default.c,
//! negotiator/skipping.c, negotiator/noop.c): decide which "have" lines
//! fetch-pack sends.

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const cn = @import("commitnode.zig");
const refs = @import("refs.zig");
const repo_mod = @import("repo.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Commit = cn.Commit;

// object flags (shared by both algorithms; ADVERTISED == COMMON_REF)
pub const COMMON: u32 = 1 << 2;
const COMMON_REF: u32 = 1 << 3;
const ADVERTISED: u32 = 1 << 3;
const SEEN: u32 = 1 << 4;
const POPPED: u32 = 1 << 5;

pub const Algorithm = enum { consecutive, skipping, noop };

/// prepare_repo_settings(): feature.experimental + fetch.negotiationAlgorithm
pub fn configuredAlgorithm() Algorithm {
    const cfg = &repo_mod.cfg;
    var alg: Algorithm = .consecutive;
    if (cfg.getBool("feature.experimental") orelse false) alg = .skipping;
    if (cfg.get("fetch.negotiationalgorithm")) |v| {
        if (std.ascii.eqlIgnoreCase(v, "skipping")) {
            alg = .skipping;
        } else if (std.ascii.eqlIgnoreCase(v, "noop")) {
            alg = .noop;
        } else if (std.ascii.eqlIgnoreCase(v, "consecutive")) {
            alg = .consecutive;
        } else if (std.ascii.eqlIgnoreCase(v, "default")) {} else util.die("unknown fetch negotiation algorithm '{s}'", .{v});
    }
    return alg;
}

/// skipping.c queue entry
const Entry = struct {
    commit: *Commit,
    original_ttl: u16 = 0,
    ttl: u16 = 0,
    ctr: u64 = 0,
};

/// Minimal prio queue of entries ordered by commit date (newest first),
/// FIFO among equal dates (same total order as prio-queue.c).
const EntryQueue = struct {
    items: std.ArrayList(*Entry) = .empty,
    ctr: u64 = 0,

    fn less(a: *Entry, b: *Entry) bool {
        if (a.commit.date != b.commit.date) return a.commit.date > b.commit.date;
        return a.ctr < b.ctr;
    }
    fn put(q: *EntryQueue, e: *Entry) void {
        e.ctr = q.ctr;
        q.ctr += 1;
        q.items.append(gpa, e) catch util.oom();
        var ix = q.items.items.len - 1;
        while (ix > 0) {
            const parent = (ix - 1) / 2;
            if (!less(q.items.items[ix], q.items.items[parent])) break;
            std.mem.swap(*Entry, &q.items.items[ix], &q.items.items[parent]);
            ix = parent;
        }
    }
    fn get(q: *EntryQueue) ?*Entry {
        const arr = q.items.items;
        if (arr.len == 0) return null;
        const top = arr[0];
        const last = q.items.pop().?;
        if (q.items.items.len > 0) {
            const a = q.items.items;
            a[0] = last;
            var ix: usize = 0;
            while (ix * 2 + 1 < a.len) {
                var child = ix * 2 + 1;
                if (child + 1 < a.len and less(a[child + 1], a[child])) child += 1;
                if (!less(a[child], a[ix])) break;
                std.mem.swap(*Entry, &a[child], &a[ix]);
                ix = child;
            }
        }
        return top;
    }
};

var marked_default = false;
var marked_skipping = false;

fn clearMarks(mask: u32) void {
    for (refs.iterate("refs/", .{ .check_objects = false })) |r| {
        const o = cn.parseObject(r.oid) orelse continue;
        const d = cn.derefTag(o) orelse continue;
        if (d.typ == .commit) cn.clearCommitMarks(Commit.fromObj(d), mask);
    }
}

pub const Negotiator = struct {
    alg: Algorithm,
    rev_list: cn.PrioQueue = .{ .compare = cn.compareByCommitDate },
    entries: EntryQueue = .{},
    non_common_revs: i64 = 0,

    pub fn init(alg: Algorithm) Negotiator {
        switch (alg) {
            .consecutive => {
                if (marked_default) clearMarks(COMMON | COMMON_REF | SEEN | POPPED);
                marked_default = true;
            },
            .skipping => {
                if (marked_skipping) clearMarks(COMMON | ADVERTISED | SEEN | POPPED);
                marked_skipping = true;
            },
            .noop => {},
        }
        return .{ .alg = alg };
    }

    pub fn knownCommon(n: *Negotiator, c: *Commit) void {
        switch (n.alg) {
            .consecutive => if (c.obj.flags & SEEN == 0) {
                n.defPush(c, COMMON_REF | SEEN);
                n.defMarkCommon(c, true, true);
            },
            .skipping => if (c.obj.flags & SEEN == 0) {
                _ = n.skipPush(c, ADVERTISED);
            },
            .noop => {},
        }
    }

    pub fn addTip(n: *Negotiator, c: *Commit) void {
        switch (n.alg) {
            .consecutive => n.defPush(c, SEEN),
            .skipping => if (c.obj.flags & SEEN == 0) {
                _ = n.skipPush(c, 0);
            },
            .noop => {},
        }
    }

    pub fn next(n: *Negotiator) ?Oid {
        return switch (n.alg) {
            .consecutive => n.defGetRev(),
            .skipping => n.skipGetRev(),
            .noop => null,
        };
    }

    /// Returns whether the commit was already known to be common.
    pub fn ack(n: *Negotiator, c: *Commit) bool {
        switch (n.alg) {
            .consecutive => {
                const known = c.obj.flags & COMMON != 0;
                n.defMarkCommon(c, false, true);
                return known;
            },
            .skipping => {
                const known = c.obj.flags & COMMON != 0;
                if (c.obj.flags & SEEN == 0)
                    util.die("received ack for commit {s} not sent as 'have'", .{hash.hex(c.obj.oid)});
                n.skipMarkCommon(c);
                return known;
            },
            .noop => return false,
        }
    }

    pub fn haveSent(n: *Negotiator, c: *Commit) void {
        switch (n.alg) {
            .consecutive => {
                if (!cn.parse(c)) return;
                n.defMarkCommon(c, false, false);
            },
            .skipping => {
                if (!cn.parse(c)) return;
                n.skipMarkCommon(c);
            },
            .noop => {},
        }
    }

    // ---------------- default (consecutive) ----------------

    fn defPush(n: *Negotiator, c: *Commit, mark: u32) void {
        if (c.obj.flags & mark != 0) return;
        c.obj.flags |= mark;
        if (!cn.parse(c)) return;
        n.rev_list.put(c);
        if (c.obj.flags & COMMON == 0) n.non_common_revs += 1;
    }

    fn defMarkCommon(n: *Negotiator, commit0: *Commit, ancestors_only: bool, dont_parse: bool) void {
        if (commit0.obj.flags & COMMON != 0) return;
        var stack: std.ArrayList(*Commit) = .empty;
        defer stack.deinit(gpa);
        stack.append(gpa, commit0) catch util.oom();
        if (!ancestors_only) {
            commit0.obj.flags |= COMMON;
            if (commit0.obj.flags & SEEN != 0 and commit0.obj.flags & POPPED == 0) n.non_common_revs -= 1;
        }
        while (stack.pop()) |c| {
            if (c.obj.flags & SEEN == 0) {
                n.defPush(c, SEEN);
            } else {
                if (!c.obj.parsed and !dont_parse) {
                    if (!cn.parse(c)) continue;
                }
                var p = c.parents;
                while (p) |pl| : (p = pl.next) {
                    const pc = pl.item;
                    if (pc.obj.flags & COMMON != 0) continue;
                    pc.obj.flags |= COMMON;
                    if (pc.obj.flags & SEEN != 0 and pc.obj.flags & POPPED == 0) n.non_common_revs -= 1;
                    stack.append(gpa, pc) catch util.oom();
                }
            }
        }
    }

    fn defGetRev(n: *Negotiator) ?Oid {
        while (true) {
            if (n.non_common_revs == 0) return null;
            const c = n.rev_list.get() orelse return null;
            _ = cn.parse(c);
            c.obj.flags |= POPPED;
            if (c.obj.flags & COMMON == 0) n.non_common_revs -= 1;
            var send = true;
            var mark: u32 = SEEN;
            if (c.obj.flags & COMMON != 0) {
                send = false;
                mark = COMMON | SEEN;
            } else if (c.obj.flags & COMMON_REF != 0) {
                mark = COMMON | SEEN;
            }
            var p = c.parents;
            while (p) |pl| : (p = pl.next) {
                if (pl.item.obj.flags & SEEN == 0) n.defPush(pl.item, mark);
                if (mark & COMMON != 0) n.defMarkCommon(pl.item, true, false);
            }
            if (send) return c.obj.oid;
        }
    }

    // ---------------- skipping ----------------

    fn skipPush(n: *Negotiator, c: *Commit, mark: u32) *Entry {
        c.obj.flags |= mark | SEEN;
        const e = gpa.create(Entry) catch util.oom();
        e.* = .{ .commit = c };
        n.entries.put(e);
        if (mark & COMMON == 0) n.non_common_revs += 1;
        return e;
    }

    fn skipMarkCommon(n: *Negotiator, seen_commit: *Commit) void {
        if (seen_commit.obj.flags & COMMON != 0) return;
        var stack: std.ArrayList(*Commit) = .empty;
        defer stack.deinit(gpa);
        stack.append(gpa, seen_commit) catch util.oom();
        seen_commit.obj.flags |= COMMON;
        while (stack.pop()) |c| {
            if (c.obj.flags & POPPED == 0) n.non_common_revs -= 1;
            if (!c.obj.parsed) continue;
            var p = c.parents;
            while (p) |pl| : (p = pl.next) {
                const f = pl.item.obj.flags;
                if (f & SEEN == 0 or f & COMMON != 0) continue;
                pl.item.obj.flags |= COMMON;
                stack.append(gpa, pl.item) catch util.oom();
            }
        }
    }

    fn skipPushParent(n: *Negotiator, entry: *Entry, to_push: *Commit) bool {
        var parent_entry: *Entry = undefined;
        if (to_push.obj.flags & SEEN != 0) {
            if (to_push.obj.flags & POPPED != 0) return false;
            var found: ?*Entry = null;
            for (n.entries.items.items) |e| {
                if (e.commit == to_push) {
                    found = e;
                    break;
                }
            }
            parent_entry = found orelse util.die("BUG: missing parent in priority queue", .{});
        } else parent_entry = n.skipPush(to_push, 0);
        if (entry.commit.obj.flags & (COMMON | ADVERTISED) != 0) {
            n.skipMarkCommon(to_push);
        } else {
            const new_original_ttl: u16 = if (entry.ttl != 0) entry.original_ttl else @truncate(@as(u32, entry.original_ttl) * 3 / 2 + 1);
            const new_ttl: u16 = if (entry.ttl != 0) entry.ttl - 1 else new_original_ttl;
            if (parent_entry.original_ttl < new_original_ttl) {
                parent_entry.original_ttl = new_original_ttl;
                parent_entry.ttl = new_ttl;
            }
        }
        return true;
    }

    fn skipGetRev(n: *Negotiator) ?Oid {
        while (true) {
            if (n.non_common_revs == 0) return null;
            const entry = n.entries.get() orelse return null;
            const c = entry.commit;
            var to_send: ?*Commit = null;
            var parent_pushed = false;
            c.obj.flags |= POPPED;
            if (c.obj.flags & COMMON == 0) n.non_common_revs -= 1;
            if (c.obj.flags & COMMON == 0 and entry.ttl == 0) to_send = c;
            _ = cn.parse(c);
            var p = c.parents;
            while (p) |pl| : (p = pl.next) {
                if (n.skipPushParent(entry, pl.item)) parent_pushed = true;
            }
            if (c.obj.flags & COMMON == 0 and !parent_pushed) to_send = c;
            gpa.destroy(entry);
            if (to_send) |s| return s.obj.oid;
        }
    }
};
