//! git credential-cache / credential-cache--daemon
//! (builtin/credential-cache.c, builtin/credential-cache--daemon.c, unix-socket.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const config = @import("../config.zig");
const repo_mod = @import("../repo.zig");
const proc = @import("../proc.zig");
const cred = @import("../credential.zig");
const gpa = util.gpa;

const SockaddrUn = extern struct {
    family: u16,
    path: [108]u8,
};
const PollFd = extern struct {
    fd: c_int,
    events: i16,
    revents: i16,
};

extern "c" fn socket(domain: c_int, ty: c_int, protocol: c_int) c_int;
extern "c" fn connect(fd: c_int, addr: *const SockaddrUn, len: u32) c_int;
extern "c" fn bind(fd: c_int, addr: *const SockaddrUn, len: u32) c_int;
extern "c" fn listen(fd: c_int, backlog: c_int) c_int;
extern "c" fn accept(fd: c_int, addr: ?*anyopaque, len: ?*u32) c_int;
extern "c" fn shutdown(fd: c_int, how: c_int) c_int;
extern "c" fn poll(fds: *PollFd, n: c_ulong, timeout: c_int) c_int;
extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn raise(sig: c_int) c_int;
extern "c" fn dup2(a: c_int, b: c_int) c_int;
extern "c" fn _exit(code: c_int) noreturn;

const AF_UNIX = 1;
const SOCK_STREAM = 1;
const SHUT_WR = 1;
const POLLIN: i16 = 1;
const ENAMETOOLONG = 36;
const ECONNREFUSED = 111;
const ECONNRESET = 104;
const ECONNABORTED = 103;

// ---------------------------------------------------------------------------
// unix-socket.c

const SockCtx = struct { orig_dir: ?[]const u8 = null };

fn sockaddrInit(sa: *SockaddrUn, path_in: []const u8, ctx: *SockCtx) bool {
    var path = path_in;
    ctx.orig_dir = null;
    if (path.len + 1 > sa.path.len) {
        const slash = std.mem.lastIndexOfScalar(u8, path, '/') orelse {
            os.setErrno(ENAMETOOLONG);
            return false;
        };
        const dir = path[0..slash];
        path = path[slash + 1 ..];
        if (path.len + 1 > sa.path.len) {
            os.setErrno(ENAMETOOLONG);
            return false;
        }
        const cwd = os.getcwd();
        if (!os.chdir(dir)) return false;
        ctx.orig_dir = cwd;
    }
    sa.* = .{ .family = AF_UNIX, .path = @splat(0) };
    @memcpy(sa.path[0..path.len], path);
    return true;
}

fn sockaddrCleanup(ctx: *SockCtx) void {
    const d = ctx.orig_dir orelse return;
    if (!os.chdir(d)) util.die("unable to restore original working directory", .{});
    ctx.orig_dir = null;
}

fn unixStreamConnect(path: []const u8) c_int {
    var sa: SockaddrUn = undefined;
    var ctx = SockCtx{};
    if (!sockaddrInit(&sa, path, &ctx)) return -1;
    const fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0 or connect(fd, &sa, @sizeOf(SockaddrUn)) < 0) {
        const e = os.errno();
        if (fd >= 0) os.close(fd);
        sockaddrCleanup(&ctx);
        os.setErrno(e);
        return -1;
    }
    sockaddrCleanup(&ctx);
    return fd;
}

fn unixStreamListen(path: []const u8) c_int {
    _ = os.unlink(path);
    var sa: SockaddrUn = undefined;
    var ctx = SockCtx{};
    if (!sockaddrInit(&sa, path, &ctx)) return -1;
    const fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0 or bind(fd, &sa, @sizeOf(SockaddrUn)) < 0 or listen(fd, 5) < 0) {
        const e = os.errno();
        if (fd >= 0) os.close(fd);
        sockaddrCleanup(&ctx);
        os.setErrno(e);
        return -1;
    }
    sockaddrCleanup(&ctx);
    return fd;
}

// ---------------------------------------------------------------------------
// client

fn connectionClosed(e: c_int) bool {
    return e == ECONNRESET or e == ECONNABORTED;
}

fn connectionFatallyBroken(e: c_int) bool {
    return e != os.ENOENT and e != ECONNREFUSED;
}

/// Returns -1 if the connection could not be made, else whether data was received.
fn sendRequest(sock: []const u8, data: []const u8) i32 {
    var got_data: i32 = 0;
    const fd = unixStreamConnect(sock);
    if (fd < 0) return -1;
    os.writeAll(fd, data) catch util.dieErrno("unable to write to cache daemon", .{});
    _ = shutdown(fd, SHUT_WR);
    var buf: [1024]u8 = undefined;
    while (true) {
        const n = std.c.read(fd, &buf, buf.len);
        if (n < 0) {
            const e = os.errno();
            if (e == os.EINTR) continue;
            if (connectionClosed(e)) break;
            util.dieErrno("read error from cache daemon", .{});
        }
        if (n == 0) break;
        util.flushStdout();
        os.writeAll(1, buf[0..@intCast(n)]) catch util.dieErrno("write error", .{});
        got_data = 1;
    }
    os.close(fd);
    return got_data;
}

fn spawnDaemon(sock: []const u8) void {
    const ch = proc.spawnGit(&.{ "credential-cache--daemon", sock }, .{ .no_stdin = true, .pipe_out = true });
    var buf: [128]u8 = undefined;
    var r: usize = 0;
    while (r < buf.len) {
        const n = std.c.read(ch.out, buf[r..].ptr, buf.len - r);
        if (n < 0) {
            if (os.errno() == os.EINTR) continue;
            util.dieErrno("unable to read result code from cache daemon", .{});
        }
        if (n == 0) break;
        r += @intCast(n);
    }
    if (r != 3 or !std.mem.eql(u8, buf[0..3], "ok\n"))
        util.die("cache daemon did not start: {s}", .{buf[0..r]});
    os.close(ch.out);
}

const FLAG_SPAWN = 1;
const FLAG_RELAY = 2;

fn doCache(sock: []const u8, action: []const u8, timeout: i32, flags: u32) void {
    var b: util.Buf = .empty;
    util.bufPrint(&b, "action={s}\n", .{action});
    util.bufPrint(&b, "timeout={d}\n", .{timeout});
    if (flags & FLAG_RELAY != 0) {
        const data = os.readAllFd(0) catch util.dieErrno("unable to relay credential", .{});
        util.bufAppend(&b, data);
    }
    if (sendRequest(sock, b.items) < 0) {
        if (connectionFatallyBroken(os.errno())) util.dieErrno("unable to connect to cache daemon", .{});
        if (flags & FLAG_SPAWN != 0) {
            spawnDaemon(sock);
            if (sendRequest(sock, b.items) < 0) util.dieErrno("unable to connect to cache daemon", .{});
        }
    }
}

fn xdgCacheHome(file: []const u8) ?[]const u8 {
    if (os.getenv("XDG_CACHE_HOME")) |x| {
        if (x.len > 0) return util.concat(&.{ x, "/git/", file });
    }
    const home = os.getenv("HOME") orelse return null;
    return util.concat(&.{ home, "/.cache/git/", file });
}

fn getSocketPath() ?[]const u8 {
    if (config.interpolatePath("~/.git-credential-cache", false)) |old| {
        if (os.statPath(old)) |st| {
            if (st.isDir()) return util.concat(&.{ old, "/socket" });
        }
    }
    return xdgCacheHome("credential/socket");
}

const cache_usage = [_][]const u8{"git credential-cache [<options>] <action>"};

pub fn cmdCredentialCache(args: []const []const u8) u8 {
    var timeout: i32 = 900;
    var socket_arg: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.integer(0, "timeout", &timeout, "n", "number of seconds to cache credentials"),
        po.string(0, "socket", &socket_arg, "path", "path of cache-daemon socket"),
    };
    const rest = po.parse(args[1..], &opts, &cache_usage, .{});
    if (rest.len == 0) po.usageWithOptions(&cache_usage, &opts);
    const op = rest[0];
    const sock = socket_arg orelse getSocketPath() orelse
        util.die("unable to find a suitable socket path; use --socket", .{});

    if (util.eql(op, "exit")) {
        doCache(sock, op, timeout, 0);
    } else if (util.eql(op, "get") or util.eql(op, "erase")) {
        doCache(sock, op, timeout, FLAG_RELAY);
    } else if (util.eql(op, "store")) {
        doCache(sock, op, timeout, FLAG_RELAY | FLAG_SPAWN);
    } else if (util.eql(op, "capability")) {
        var c = cred.Credential{};
        c.capa_authtype.request_initial = true;
        var b: util.Buf = .empty;
        cred.announceCapabilities(&c, &b);
        util.out(b.items);
    }
    return 0;
}

// ---------------------------------------------------------------------------
// daemon

const Entry = struct {
    item: cred.Credential,
    expiration: u64,
};

var entries: std.ArrayList(Entry) = .empty;
var wait_for_entry_until: u64 = 0;
var socket_file: ?[*:0]const u8 = null;

fn nowU() u64 {
    const t = os.now();
    return if (t < 0) 0 else @intCast(t);
}

fn cleanupSocket() void {
    if (socket_file) |p| {
        _ = std.c.unlink(p);
        socket_file = null;
    }
}

fn onSignal(sig: c_int) callconv(.c) void {
    cleanupSocket();
    _ = signal(sig, 0);
    _ = raise(sig);
    _exit(128 + sig);
}

fn lookupEntry(c: *const cred.Credential) ?*Entry {
    for (entries.items) |*e| {
        if (cred.match(c, &e.item, false)) return e;
    }
    return null;
}

fn removeCredential(c: *const cred.Credential, match_password: bool) void {
    for (entries.items) |*e| {
        if (cred.match(c, &e.item, match_password)) e.expiration = 0;
    }
}

fn checkExpirations() u64 {
    const now = nowU();
    var next: u64 = cred.TIME_MAX;
    if (wait_for_entry_until == 0) wait_for_entry_until = now + 30;
    var i: usize = 0;
    while (i < entries.items.len) {
        if (entries.items[i].expiration <= now) {
            _ = entries.swapRemove(i);
            wait_for_entry_until = now + 30;
        } else {
            if (entries.items[i].expiration < next) next = entries.items[i].expiration;
            i += 1;
        }
    }
    if (entries.items.len == 0) {
        if (wait_for_entry_until <= now) return 0;
        next = wait_for_entry_until;
    }
    return next - now;
}

fn atoi(s: []const u8) i32 {
    var i: usize = 0;
    while (i < s.len and (s[i] == ' ' or (s[i] >= 9 and s[i] <= 13))) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    var n: i64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) {
        n = n * 10 + (s[i] - '0');
        if (n > std.math.maxInt(i32)) n = std.math.maxInt(i32);
    }
    const v: i32 = @intCast(n);
    return if (neg) -v else v;
}

fn serveOneClient(fd: c_int) void {
    var r = cred.Reader{ .fd = fd };
    var c = cred.Credential{};
    var timeout: i32 = -1;
    var out: util.Buf = .empty;
    defer os.writeAll(fd, out.items) catch {};

    const l1 = r.getlineLf() orelse "";
    const action = util.skipPrefix(l1, "action=") orelse {
        util.err("client sent bogus action line: {s}", .{l1});
        return;
    };
    const l2 = r.getlineLf() orelse "";
    const t = util.skipPrefix(l2, "timeout=") orelse {
        util.err("client sent bogus timeout line: {s}", .{l2});
        return;
    };
    timeout = atoi(t);
    c.setAllCapabilities(.initial);
    if (!cred.read(&c, &r, .helper)) return;

    if (util.eql(action, "get")) {
        if (lookupEntry(&c)) |e| {
            e.item.capa_authtype.request_initial = true;
            e.item.capa_authtype.request_helper = true;
            util.bufAppend(&out, "capability[]=authtype\n");
            if (e.item.username) |u| util.bufPrint(&out, "username={s}\n", .{u});
            if (e.item.password) |p| util.bufPrint(&out, "password={s}\n", .{p});
            if (c.capa_authtype.has(.response)) {
                if (e.item.authtype) |a| util.bufPrint(&out, "authtype={s}\n", .{a});
            }
            if (c.capa_authtype.has(.response)) {
                if (e.item.credential) |a| util.bufPrint(&out, "credential={s}\n", .{a});
            }
            if (e.item.password_expiry_utc != cred.TIME_MAX)
                util.bufPrint(&out, "password_expiry_utc={d}\n", .{e.item.password_expiry_utc});
            if (e.item.oauth_refresh_token) |o| util.bufPrint(&out, "oauth_refresh_token={s}\n", .{o});
        }
    } else if (util.eql(action, "exit")) {
        cleanupSocket();
        util.flushStdout();
        std.c.exit(0);
    } else if (util.eql(action, "erase")) {
        removeCredential(&c, true);
    } else if (util.eql(action, "store")) {
        if (timeout < 0) {
            util.warn("cache client didn't specify a timeout", .{});
        } else if ((c.username == null or c.password == null) and (c.authtype == null and c.credential == null)) {
            util.warn("cache client gave us a partial credential", .{});
        } else if (c.ephemeral) {
            util.warn("not storing ephemeral credential", .{});
        } else {
            removeCredential(&c, false);
            entries.append(gpa, .{ .item = c, .expiration = nowU() + @as(u64, @intCast(timeout)) }) catch util.oom();
        }
    } else {
        util.warn("cache client sent unknown action: {s}", .{action});
    }
}

fn serveCacheLoop(fd: c_int) bool {
    const wakeup = checkExpirations();
    if (wakeup == 0) return false;
    var pfd = PollFd{ .fd = fd, .events = POLLIN, .revents = 0 };
    const ms: u64 = @min(wakeup * 1000, @as(u64, std.math.maxInt(c_int)));
    if (poll(&pfd, 1, @intCast(ms)) < 0) {
        if (os.errno() != os.EINTR) util.dieErrno("poll failed", .{});
        return true;
    }
    if (pfd.revents & POLLIN != 0) {
        const client = accept(fd, null, null);
        if (client < 0) {
            util.warn("accept failed: {s}", .{os.lastErr()});
            return true;
        }
        serveOneClient(client);
        os.close(client);
    }
    return true;
}

fn serveCache(sock: []const u8, debug: bool) void {
    const fd = unixStreamListen(sock);
    if (fd < 0) util.dieErrno("unable to bind to '{s}'", .{sock});
    util.out("ok\n");
    util.flushStdout();
    os.close(1);
    util.stdout.broken = true;
    if (!debug) {
        const dn = os.openFile("/dev/null", os.O_WRONLY, 0);
        if (dn < 0) util.dieErrno("unable to point stderr to /dev/null", .{});
        _ = dup2(dn, 2);
        os.close(dn);
    }
    while (serveCacheLoop(fd)) {}
    os.close(fd);
}

fn initSocketDirectory(path: []const u8) void {
    const dir = util.dirname(path);
    const d = if (dir.len == 0) "/" else dir;
    if (os.statPath(d)) |st| {
        if (st.mode & 0o077 != 0)
            util.die("The permissions on your socket directory are too loose; other\n" ++
                "users may be able to read your cached credentials. Consider running:\n" ++
                "\n" ++
                "\tchmod 0700 {s}", .{d});
    } else {
        if (!os.mkdirLeading(d)) util.dieErrno("unable to create directories for '{s}'", .{d});
        if (!os.mkdir(d, 0o700)) util.dieErrno("unable to mkdir '{s}'", .{d});
    }
    _ = os.chdir(d);
}

const daemon_usage = [_][]const u8{"git credential-cache--daemon [--debug] <socket-path>"};

pub fn cmdCredentialCacheDaemon(args: []const []const u8) u8 {
    var debug = false;
    const ignore_sighup = repo_mod.cfg.getBool("credentialcache.ignoresighup") orelse false;
    const opts = [_]po.Opt{
        po.boolean(0, "debug", &debug, "print debugging messages to stderr"),
    };
    const rest = po.parse(args[1..], &opts, &daemon_usage, .{});
    if (rest.len == 0) po.usageWithOptions(&daemon_usage, &opts);
    const sock = rest[0];
    if (!(sock.len > 0 and sock[0] == '/')) util.die("socket directory must be an absolute path", .{});
    initSocketDirectory(sock);
    socket_file = os.z(sock);
    const handler = @intFromPtr(&onSignal);
    _ = signal(2, handler);
    _ = signal(3, handler);
    _ = signal(15, handler);
    _ = signal(13, handler);
    if (ignore_sighup) _ = signal(1, 1) else _ = signal(1, handler);
    serveCache(sock, debug);
    cleanupSocket();
    return 0;
}
