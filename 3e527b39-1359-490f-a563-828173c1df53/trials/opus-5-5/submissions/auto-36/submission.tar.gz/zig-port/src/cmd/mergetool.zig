//! git mergetool (port of git-mergetool.sh).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const repo_mod = @import("../repo.zig");
const proc = @import("../proc.zig");
const main_mod = @import("../main.zig");
const lib = @import("../mergetool_lib.zig");
const gpa = util.gpa;

extern "c" fn getpid() c_int;
extern "c" fn mkdtemp(template: [*:0]u8) ?[*:0]u8;

const usage_str = "usage: git mergetool [--tool=tool] [--tool-help] [-y|--no-prompt|--prompt] [-g|--gui|--no-gui] [-O<orderfile>] [file to merge] ...";

fn usage() noreturn {
    util.flushStdout();
    util.eprint("{s}\n", .{usage_str});
    os.exit(1);
}

/// Run our own git; returns the exit status.
fn git(args: []const []const u8, opts: os.SpawnOpts) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return os.run(argv.items, opts);
}

fn gitOut(args: []const []const u8) []const u8 {
    return git(args, .{ .capture_stdout = true }).stdout;
}

fn splitLines(s: []const u8) [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    var it = std.mem.tokenizeScalar(u8, s, '\n');
    while (it.next()) |x| l.append(gpa, x) catch util.oom();
    return l.items;
}

fn isFile(p: []const u8) bool {
    const st = os.statPath(p) orelse return false;
    return st.isReg();
}

fn rmF(p: []const u8) void {
    if (os.lstatPath(p)) |st| {
        if (!st.isDir()) _ = os.unlink(p);
    }
}

fn copyFile(dst: []const u8, src: []const u8) bool {
    const d = os.readFile(src) orelse return false;
    const st = os.statPath(src) orelse return false;
    _ = os.unlink(dst);
    os.writeFile(dst, d, @intCast(st.mode & 0o777)) catch return false;
    return true;
}

/// mv -- src dst
fn mv(src: []const u8, dst: []const u8) void {
    if (os.lstatPath(src) == null) {
        util.flushStdout();
        util.eprint("mv: cannot stat '{s}': No such file or directory\n", .{src});
        return;
    }
    if (os.rename(src, dst)) return;
    if (copyFile(dst, src)) _ = os.unlink(src);
}

fn askLine(prompt: []const u8) ?[]const u8 {
    util.out(prompt);
    return lib.readLine();
}

fn firstIs(ans: []const u8, chars: []const u8) bool {
    return ans.len > 0 and std.mem.indexOfScalar(u8, chars, ans[0]) != null;
}

const State = struct {
    tool: []const u8,
    guessed: bool,
    prompt: ?bool,
    keep_backup: bool,
    keep_temporaries: bool,
};

const File = struct {
    merged: []const u8,
    backup: []const u8 = "",
    local: []const u8 = "",
    remote: []const u8 = "",
    base: []const u8 = "",
    lconfl: []const u8 = "",
    rconfl: []const u8 = "",
    tmpdir: []const u8 = ".",
    base_mode: ?[]const u8 = null,
    local_mode: ?[]const u8 = null,
    remote_mode: ?[]const u8 = null,
    local_sha1: []const u8 = "",
    remote_sha1: []const u8 = "",

    fn cleanup(f: *const File, save_backup: bool) void {
        if (save_backup) {
            os.removeTree(util.concat(&.{ f.merged, ".orig" }));
            _ = os.unlink(util.concat(&.{ f.merged, ".orig" }));
            if (os.lstatPath(f.backup) != null) mv(f.backup, util.concat(&.{ f.merged, ".orig" }));
            rmF(f.local);
            rmF(f.remote);
            rmF(f.base);
        } else {
            rmF(f.local);
            rmF(f.remote);
            rmF(f.base);
            rmF(f.backup);
        }
        if (!util.eql(f.tmpdir, ".")) _ = os.rmdir(f.tmpdir);
    }
};

fn isSymlinkMode(m: ?[]const u8) bool {
    return if (m) |x| util.eql(x, "120000") else false;
}
fn isSubmoduleMode(m: ?[]const u8) bool {
    return if (m) |x| util.eql(x, "160000") else false;
}

fn describeFile(f: *const File, mode: ?[]const u8, branch: []const u8, file: []const u8) void {
    util.outf("  {{{s}}}: ", .{branch});
    if (mode == null) {
        util.out("deleted\n");
    } else if (isSymlinkMode(mode)) {
        const t = os.readFile(file) orelse "";
        util.outf("a symbolic link -> '{s}'\n", .{std.mem.trimEnd(u8, t, "\n")});
    } else if (isSubmoduleMode(mode)) {
        util.outf("submodule commit {s}\n", .{file});
    } else if (f.base_mode != null) {
        util.out("modified file\n");
    } else {
        util.out("created file\n");
    }
}

fn checkoutStagedFile(stage: u8, merged: []const u8, dst: []const u8) void {
    const res = git(&.{ "checkout-index", "--temp", util.fmt("--stage={d}", .{stage}), merged }, .{ .capture_stdout = true, .no_stderr = true });
    var tmpfile: []const u8 = res.stdout;
    if (std.mem.indexOfScalar(u8, tmpfile, '\t')) |i| tmpfile = tmpfile[0..i];
    tmpfile = std.mem.trimEnd(u8, tmpfile, "\n");
    if (tmpfile.len > 0) {
        mv(tmpfile, dst);
    } else {
        os.writeFile(dst, "", 0o666) catch {};
    }
}

fn hideResolved(f: *const File) void {
    const a = git(&.{ "merge-file", "--ours", "-q", "-p", f.local, f.base, f.remote }, .{ .capture_stdout = true });
    os.writeFile(f.lconfl, a.stdout, 0o666) catch {};
    const b = git(&.{ "merge-file", "--theirs", "-q", "-p", f.local, f.base, f.remote }, .{ .capture_stdout = true });
    os.writeFile(f.rconfl, b.stdout, 0o666) catch {};
    mv(f.lconfl, f.local);
    mv(f.rconfl, f.remote);
}

fn stageSubmodule(path: []const u8, sha1: []const u8) void {
    if (!os.mkdirAll(path)) util.die("fatal: unable to create directory for module at {s}", .{path});
    const rel = util.normalizePath(path) orelse path;
    if (git(&.{ "update-index", "--add", "--replace", "--cacheinfo", "160000", sha1, rel }, .{}).status != 0) os.exit(1);
}

fn checkoutStageAndAdd(stage: []const u8, merged: []const u8) void {
    _ = git(&.{ "checkout-index", "-f", stage, "--", merged }, .{});
    _ = git(&.{ "add", "--", merged }, .{});
}

fn takeSubdir(rev: []const u8, merged: []const u8) bool {
    if (gitOut(&.{ "ls-tree", rev, "--", merged }).len == 0) return false;
    const lt = gitOut(&.{ "ls-tree", "--full-name", "-r", rev, "--", merged });
    const st = git(&.{ "update-index", "--index-info" }, .{ .stdin_data = lt }).status;
    if (st != 0) os.exit(st);
    return true;
}

fn resolveSubmoduleMerge(f: *const File) bool {
    while (true) {
        const ans = askLine("Use (l)ocal or (r)emote, or (a)bort? ") orelse return false;
        if (firstIs(ans, "lL")) {
            if (f.local_mode == null) {
                if (!takeSubdir("HEAD", f.merged)) {
                    if (os.lstatPath(f.merged) != null) mv(f.merged, f.backup);
                    _ = git(&.{ "update-index", "--force-remove", f.merged }, .{});
                    f.cleanup(true);
                }
            } else if (isSubmoduleMode(f.local_mode)) {
                stageSubmodule(f.merged, f.local_sha1);
            } else {
                checkoutStageAndAdd("--stage=2", f.merged);
            }
            return true;
        } else if (firstIs(ans, "rR")) {
            if (f.remote_mode == null) {
                if (!takeSubdir("MERGE_HEAD", f.merged)) {
                    if (os.lstatPath(f.merged) != null) mv(f.merged, f.backup);
                    _ = git(&.{ "update-index", "--force-remove", f.merged }, .{});
                }
            } else if (isSubmoduleMode(f.remote_mode)) {
                if (!isSubmoduleMode(f.local_mode) and os.lstatPath(f.merged) != null) mv(f.merged, f.backup);
                stageSubmodule(f.merged, f.remote_sha1);
            } else {
                if (os.lstatPath(f.merged) != null) mv(f.merged, f.backup);
                checkoutStageAndAdd("--stage=3", f.merged);
            }
            f.cleanup(true);
            return true;
        } else if (firstIs(ans, "aA")) {
            return false;
        }
    }
}

fn resolveSymlinkMerge(f: *const File) bool {
    while (true) {
        const ans = askLine("Use (l)ocal or (r)emote, or (a)bort? ") orelse return false;
        if (firstIs(ans, "lL")) {
            checkoutStageAndAdd("--stage=2", f.merged);
            f.cleanup(true);
            return true;
        } else if (firstIs(ans, "rR")) {
            checkoutStageAndAdd("--stage=3", f.merged);
            f.cleanup(true);
            return true;
        } else if (firstIs(ans, "aA")) {
            return false;
        }
    }
}

fn resolveDeletedMerge(st: *const State, f: *const File) bool {
    while (true) {
        const q = if (f.base_mode != null) "Use (m)odified or (d)eleted file, or (a)bort? " else "Use (c)reated or (d)eleted file, or (a)bort? ";
        const ans = askLine(q) orelse return false;
        if (firstIs(ans, "mMcC")) {
            _ = git(&.{ "add", "--", f.merged }, .{});
            f.cleanup(st.keep_backup);
            return true;
        } else if (firstIs(ans, "dD")) {
            _ = git(&.{ "rm", "--", f.merged }, .{ .capture_stdout = true });
            f.cleanup(false);
            return true;
        } else if (firstIs(ans, "aA")) {
            if (!st.keep_temporaries) f.cleanup(false);
            return false;
        }
    }
}

fn rmdirP(dir: []const u8) void {
    var d = dir;
    while (d.len > 0) {
        if (!os.rmdir(d)) return;
        const i = std.mem.lastIndexOfScalar(u8, d, '/') orelse return;
        d = d[0..i];
    }
}

fn dirnameOf(p: []const u8) []const u8 {
    const t = std.mem.trimEnd(u8, p, "/");
    const i = std.mem.lastIndexOfScalar(u8, t, '/') orelse return ".";
    if (i == 0) return "/";
    return t[0..i];
}

fn mergeFile(st: *const State, merged: []const u8) bool {
    const u = gitOut(&.{ "ls-files", "-u", "--", merged });
    if (u.len == 0) {
        if (!isFile(merged)) {
            util.outf("{s}: file not found\n", .{merged});
        } else {
            util.outf("{s}: file does not need merging\n", .{merged});
        }
        return false;
    }
    var ext: []const u8 = "";
    var basename: []const u8 = merged;
    const last = if (std.mem.lastIndexOfScalar(u8, merged, '/')) |i| merged[i + 1 ..] else merged;
    if (std.mem.indexOfScalar(u8, last, '.') != null) {
        const d = std.mem.lastIndexOfScalar(u8, merged, '.').?;
        ext = merged[d..];
        basename = merged[0..d];
    }
    if (!lib.setupTool(st.tool, false)) return false;

    var f = File{ .merged = merged };
    if (lib.cfgBool("mergetool.writetotemp") orelse false) {
        var tmpdir: []const u8 = os.getenv("TMPDIR") orelse "/tmp";
        if (tmpdir.len == 0) tmpdir = "/tmp";
        const src = util.concat(&.{ std.mem.trimEnd(u8, tmpdir, "/"), "/git-mergetool-XXXXXX" });
        const tmpl = gpa.allocSentinel(u8, src.len, 0) catch util.oom();
        @memcpy(tmpl, src);
        if (mkdtemp(tmpl.ptr) == null) {
            util.flushStdout();
            util.eprint("error: mktemp is needed when 'mergetool.writeToTemp' is true\n", .{});
            os.exit(1);
        }
        f.tmpdir = tmpl;
        if (std.mem.lastIndexOfScalar(u8, basename, '/')) |i| basename = basename[i + 1 ..];
    }
    const pid = getpid();
    const td = f.tmpdir;
    f.backup = util.fmt("{s}/{s}_BACKUP_{d}{s}", .{ td, basename, pid, ext });
    f.local = util.fmt("{s}/{s}_LOCAL_{d}{s}", .{ td, basename, pid, ext });
    f.lconfl = util.fmt("{s}/{s}_LOCAL_LCONFL_{d}{s}", .{ td, basename, pid, ext });
    f.remote = util.fmt("{s}/{s}_REMOTE_{d}{s}", .{ td, basename, pid, ext });
    f.rconfl = util.fmt("{s}/{s}_REMOTE_RCONFL_{d}{s}", .{ td, basename, pid, ext });
    f.base = util.fmt("{s}/{s}_BASE_{d}{s}", .{ td, basename, pid, ext });

    for (splitLines(u)) |line| {
        // <mode> SP <sha1> SP <stage> TAB <path>
        var it = std.mem.splitScalar(u8, line, ' ');
        const mode = it.next() orelse continue;
        const sha1 = it.next() orelse continue;
        const rest = it.rest();
        if (rest.len < 2 or rest[1] != '\t') continue;
        switch (rest[0]) {
            '1' => f.base_mode = mode,
            '2' => {
                f.local_mode = mode;
                f.local_sha1 = sha1;
            },
            '3' => {
                f.remote_mode = mode;
                f.remote_sha1 = sha1;
            },
            else => {},
        }
    }

    if (isSubmoduleMode(f.local_mode) or isSubmoduleMode(f.remote_mode)) {
        util.outf("Submodule merge conflict for '{s}':\n", .{merged});
        describeFile(&f, f.local_mode, "local", f.local_sha1);
        describeFile(&f, f.remote_mode, "remote", f.remote_sha1);
        return resolveSubmoduleMerge(&f);
    }

    if (isFile(merged)) {
        mv(merged, f.backup);
        _ = copyFile(merged, f.backup);
    }
    _ = os.mkdirAll(dirnameOf(merged));

    checkoutStagedFile(1, merged, f.base);
    checkoutStagedFile(2, merged, f.local);
    checkoutStagedFile(3, merged, f.remote);

    const enabled = lib.cfgBool(util.concat(&.{ "mergetool.", st.tool, ".hideresolved" })) orelse
        (lib.cfgBool("mergetool.hideresolved") orelse false);
    if (enabled) hideResolved(&f);

    if (f.local_mode == null or f.remote_mode == null) {
        util.outf("Deleted merge conflict for '{s}':\n", .{merged});
        describeFile(&f, f.local_mode, "local", f.local);
        describeFile(&f, f.remote_mode, "remote", f.remote);
        const ok = resolveDeletedMerge(st, &f);
        rmdirP(dirnameOf(merged));
        return ok;
    }

    if (isSymlinkMode(f.local_mode) or isSymlinkMode(f.remote_mode)) {
        util.outf("Symbolic link merge conflict for '{s}':\n", .{merged});
        describeFile(&f, f.local_mode, "local", f.local);
        describeFile(&f, f.remote_mode, "remote", f.remote);
        return resolveSymlinkMerge(&f);
    }

    util.outf("Normal merge conflict for '{s}':\n", .{merged});
    describeFile(&f, f.local_mode, "local", f.local);
    describeFile(&f, f.remote_mode, "remote", f.remote);
    if (st.guessed or (st.prompt orelse false)) {
        util.outf("Hit return to start merge resolution tool ({s}): ", .{st.tool});
        _ = lib.readLine() orelse return false;
    }

    const v = lib.Vars{ .merged = merged, .local = f.local, .remote = f.remote, .base = f.base, .backup = f.backup };
    if (lib.runMergeTool(st.tool, v, f.base_mode != null) != 0) {
        util.flushStdout();
        util.eprint("merge of {s} failed\n", .{merged});
        mv(f.backup, merged);
        if (!st.keep_temporaries) f.cleanup(false);
        return false;
    }
    if (st.keep_backup) {
        mv(f.backup, util.concat(&.{ merged, ".orig" }));
    } else {
        rmF(f.backup);
    }
    _ = git(&.{ "add", "--", merged }, .{});
    f.cleanup(false);
    return true;
}

fn promptAfterFailedMerge() bool {
    while (true) {
        const ans = askLine("Continue merging other unresolved paths [y/n]? ") orelse return false;
        if (firstIs(ans, "yY")) return true;
        if (firstIs(ans, "nN")) return false;
    }
}

fn noop() u8 {
    util.out("No files need merging\n");
    return 0;
}

pub fn cmdMergetool(args: []const []const u8) u8 {
    lib.mode = .merge;
    // git-mergetool is a script run without setup: GIT_PREFIX is not exported.
    os.unsetEnv("GIT_PREFIX");
    if (args.len > 1 and util.eql(args[1], "-h")) {
        util.outf("{s}\n", .{usage_str});
        return 0;
    }
    var prompt = lib.cfgBool("mergetool.prompt");
    var tool: []const u8 = "";
    var orderfile: []const u8 = "";
    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const a = args[i];
        if (util.startsWith(a, "--tool-help=")) {
            const m = a["--tool-help=".len..];
            lib.mode = if (util.eql(m, "diff")) .diff else .merge;
            lib.showToolHelp();
        } else if (util.eql(a, "--tool-help")) {
            lib.showToolHelp();
        } else if (util.eql(a, "-t") or util.startsWith(a, "--tool")) {
            if (std.mem.indexOfScalar(u8, a, '=')) |e| {
                tool = a[e + 1 ..];
            } else if (i + 1 >= args.len) {
                usage();
            } else {
                i += 1;
                tool = args[i];
            }
        } else if (util.eql(a, "--no-gui")) {
            lib.gui = false;
        } else if (util.eql(a, "-g") or util.eql(a, "--gui")) {
            lib.gui = true;
        } else if (util.eql(a, "-y") or util.eql(a, "--no-prompt")) {
            prompt = false;
        } else if (util.eql(a, "--prompt")) {
            prompt = true;
        } else if (util.startsWith(a, "-O")) {
            orderfile = a[2..];
        } else if (util.eql(a, "--")) {
            i += 1;
            break;
        } else if (a.len > 0 and a[0] == '-') {
            usage();
        } else break;
    }
    const paths = args[i..];

    const r = repo_mod.repo();
    if (r.work_tree == null) {
        util.flushStdout();
        util.eprint("fatal: {s}/git-mergetool cannot be used without a working tree.\n", .{main_mod.exec_path});
        return 1;
    }

    var guessed = false;
    if (tool.len == 0) {
        const sel = lib.getMergeTool();
        tool = sel.tool;
        guessed = sel.guessed;
    }
    const st = State{
        .tool = tool,
        .guessed = guessed,
        .prompt = prompt,
        .keep_backup = lib.cfgBool("mergetool.keepbackup") orelse true,
        .keep_temporaries = lib.cfgBool("mergetool.keeptemporaries") orelse false,
    };
    const prefix = r.prefix;

    if (orderfile.len > 0) {
        const o = splitLines(gitOut(&.{ "rev-parse", "--prefix", prefix, "--", orderfile }));
        orderfile = if (o.len > 1) o[1] else "";
    }

    var targets: std.ArrayList([]const u8) = .empty;
    const rr = r.gitPath("MERGE_RR");
    if (paths.len == 0 and os.lstatPath(rr) != null) {
        const rem = splitLines(gitOut(&.{ "rerere", "remaining" }));
        if (rem.len == 0) return noop();
        targets.appendSlice(gpa, rem) catch util.oom();
    } else if (paths.len > 0) {
        var a: std.ArrayList([]const u8) = .empty;
        a.appendSlice(gpa, &.{ "rev-parse", "--prefix", prefix, "--" }) catch util.oom();
        a.appendSlice(gpa, paths) catch util.oom();
        const res = git(a.items, .{ .capture_stdout = true });
        if (res.status != 0) return 1;
        const o = splitLines(res.stdout);
        if (o.len > 1) targets.appendSlice(gpa, o[1..]) catch util.oom();
    }

    var dargs: std.ArrayList([]const u8) = .empty;
    dargs.appendSlice(gpa, &.{ "-c", "core.quotePath=false", "diff", "--name-only", "--diff-filter=U" }) catch util.oom();
    if (orderfile.len > 0) dargs.append(gpa, util.concat(&.{ "-O", orderfile })) catch util.oom();
    dargs.append(gpa, "--") catch util.oom();
    dargs.appendSlice(gpa, targets.items) catch util.oom();
    const files = splitLines(gitOut(dargs.items));
    if (files.len == 0) return noop();

    util.out("Merging:\n");
    for (files) |f| util.outf("{s}\n", .{f});

    var rc: u8 = 0;
    for (files, 0..) |f, n| {
        util.out("\n");
        if (!mergeFile(&st, f)) {
            rc = 1;
            if (n + 1 == files.len or !promptAfterFailedMerge()) return 1;
        }
    }
    return rc;
}
