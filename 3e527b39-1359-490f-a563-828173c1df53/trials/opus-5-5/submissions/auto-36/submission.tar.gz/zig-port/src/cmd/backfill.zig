//! git backfill (port of builtin/backfill.c)
//!
//! Missing blobs reachable from the given revisions are discovered with
//! `rev-list --objects --missing=print` and downloaded in batches from the
//! promisor remote(s) via `git fetch --stdin`.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const proc = @import("../proc.zig");
const revision = @import("../revision.zig");
const diff = @import("../diff.zig");
const repo_mod = @import("../repo.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git backfill [--min-batch-size=<n>] [--[no-]sparse] [--[no-]include-edges] [<revision-range>]",
};

fn cannot(what: []const u8) noreturn {
    util.die("'{s}' cannot be used with 'git backfill'", .{what});
}

fn checkFilter(spec: []const u8) void {
    if (util.skipPrefix(spec, "blob:limit=")) |v| {
        var n: u64 = 0;
        var digits: usize = 0;
        for (v) |ch| {
            if (ch < '0' or ch > '9') break;
            n = n *% 10 +% (ch - '0');
            digits += 1;
        }
        const suf = v[digits..];
        if (n != 0 and suf.len <= 1) util.die("cannot backfill with blob size limits", .{});
        return;
    }
    if (util.skipPrefix(spec, "tree:")) |v| {
        if (!util.eql(v, "0")) {
            util.err("tree:{s} filter not supported by the path-walk API", .{v});
            util.die("cannot backfill with these filter options", .{});
        }
        return;
    }
    if (util.eql(spec, "blob:none") or util.startsWith(spec, "object:type=")) return;
    if (util.startsWith(spec, "combine:")) return;
    util.die("cannot backfill with these filter options", .{});
}

fn promisorRemotes() [][]const u8 {
    var list: std.ArrayList([]const u8) = .empty;
    const cfg = &repo_mod.cfg;
    if (cfg.get("extensions.partialclone")) |pc| list.append(gpa, pc) catch util.oom();
    for (cfg.entries.items) |e| {
        const k = e.key;
        if (!util.startsWith(k, "remote.") or !util.endsWith(k, ".promisor")) continue;
        const name = k["remote.".len .. k.len - ".promisor".len];
        if (name.len == 0) continue;
        if (!(cfg.getBool(k) orelse false)) continue;
        var dup = false;
        for (list.items) |x| if (util.eql(x, name)) {
            dup = true;
        };
        if (!dup) list.append(gpa, name) catch util.oom();
    }
    return list.items;
}

fn downloadBatch(batch: *std.ArrayList([]const u8)) void {
    if (batch.items.len == 0) return;
    var input: util.Buf = .empty;
    for (batch.items) |o| {
        util.bufAppend(&input, o);
        util.bufByte(&input, '\n');
    }
    for (promisorRemotes()) |remote| {
        const r = os.run(&.{
            proc.gitBinary(),                 "-c",                         "fetch.negotiationAlgorithm=noop",
            "fetch",                          remote,                       "--no-tags",
            "--no-write-fetch-head",          "--recurse-submodules=no",    "--filter=blob:none",
            "--stdin",
        }, .{ .stdin_data = input.items });
        if (r.status == 0) break;
    }
    batch.clearRetainingCapacity();
}

pub fn cmdBackfill(args: []const []const u8) u8 {
    var min_batch: i32 = 50000;
    var sparse = false;
    var sparse_set = false;
    var include_edges = true;
    _ = &sparse_set;
    const options = [_]po.Opt{
        .{ .long = "min-batch-size", .kind = .uint, .i = &min_batch, .argh = "n", .help = "Minimum number of objects to request at a time" },
        po.boolean(0, "sparse", &sparse, "Restrict the missing objects to the current sparse-checkout"),
        po.boolean(0, "include-edges", &include_edges, "Include blobs from boundary commits in the backfill"),
    };
    const rest = po.parse(args[1..], &options, &usage, .{ .keep_unknown = true, .keep_dashdash = true });

    const revs = gpa.create(revision.RevInfo) catch util.oom();
    revs.* = revision.RevInfo.init(repo_mod.repo().prefix);
    const o = gpa.create(diff.DiffOptions) catch util.oom();
    o.* = diff.DiffOptions.initBasic();
    diff.setupRevDiffWith(revs, o);

    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "backfill") catch util.oom();
    argv.appendSlice(gpa, rest) catch util.oom();
    const left = revision.setupRevisions(revs, argv.items, .{});
    if (left.len > 1) util.die("unrecognized argument: {s}", .{left[1]});

    if (o.pickaxe != null)
        cannot(if (o.pickaxe_opts & diff.PICKAXE_REGEX != 0) "-G" else "-S");
    if (o.filter != 0 or o.filter_not != 0) cannot("--diff-filter");
    if (o.flags.follow_renames) cannot("--follow");
    if (revs.line_level_traverse) cannot("-L");
    if (revs.explicit_diff_merges) cannot("--diff-merges");
    var filter_spec: ?[]const u8 = null;
    for (rest) |a| {
        if (util.eql(a, "--")) break;
        if (util.skipPrefix(a, "--filter=")) |v| filter_spec = v;
        if (util.eql(a, "--no-filter")) filter_spec = null;
    }
    if (filter_spec) |f| checkFilter(f);

    // Walk from HEAD if otherwise unspecified.
    var rl: std.ArrayList([]const u8) = .empty;
    rl.appendSlice(gpa, &.{ proc.gitBinary(), "rev-list", "--objects", "--missing=print" }) catch util.oom();
    var have_rev = revs.pending.items.len > 0;
    for (rest) |a| {
        if (util.eql(a, "--")) break;
        if (util.startsWith(a, "--filter=") or util.eql(a, "--no-filter")) continue;
        rl.append(gpa, a) catch util.oom();
    }
    if (!have_rev) {
        rl.append(gpa, "HEAD") catch util.oom();
        have_rev = true;
    }
    const r = os.run(rl.items, .{ .capture_stdout = true });
    if (r.status != 0) return 1;

    var batch: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, r.stdout, '\n');
    while (it.next()) |line| {
        if (line.len < 2 or line[0] != '?') continue;
        batch.append(gpa, line[1..]) catch util.oom();
        if (batch.items.len >= @as(usize, @intCast(@max(min_batch, 1)))) downloadBatch(&batch);
    }
    downloadBatch(&batch);
    return 0;
}
