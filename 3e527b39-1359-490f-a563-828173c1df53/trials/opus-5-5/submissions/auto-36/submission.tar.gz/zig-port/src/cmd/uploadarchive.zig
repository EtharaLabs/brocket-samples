//! git upload-archive / upload-archive--writer (port of builtin/upload-archive.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const pkt = @import("../pktline.zig");
const up = @import("uploadpack.zig");
const gpa = util.gpa;

const usage_str = "git upload-archive <repository>";
const MAX_ARGS = 64;

fn showUsageIfAsked(args: []const []const u8) void {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.out("usage: " ++ usage_str ++ "\n");
        util.flushStdout();
        os.exit(0);
    }
}

fn usage() noreturn {
    util.eprint("usage: " ++ usage_str ++ "\n", .{});
    os.exit(129);
}

pub fn cmdUploadArchiveWriter(args: []const []const u8) u8 {
    showUsageIfAsked(args);
    if (args.len != 2) usage();
    if (!up.enterRepo(args[1], false)) util.die("'{s}' does not appear to be a git repository", .{args[1]});

    var sent: std.ArrayList([]const u8) = .empty;
    sent.appendSlice(gpa, &.{ "archive", "--internal-upload-archive" }) catch util.oom();
    var nargs: usize = 1;
    var r = pkt.Reader.init(0);
    while (r.readLine()) |line| {
        if (nargs > MAX_ARGS) util.die("Too many options (>{d})", .{MAX_ARGS - 1});
        const a = util.skipPrefix(line, "argument ") orelse util.die("'argument' token or flush expected", .{});
        if (util.eql(a, "--remote") or util.startsWith(a, "--remote=")) util.die("Unexpected option --remote", .{});
        if (util.eql(a, "--exec") or util.startsWith(a, "--exec=")) util.die("the option '{s}' requires '{s}'", .{ "--exec", "--remote" });
        sent.append(gpa, util.dupe(a)) catch util.oom();
        nargs += 1;
    }
    const child = proc.spawnGit(sent.items, .{ .no_stdin = true });
    return proc.wait(child.pid);
}

extern "c" fn sleep(s: c_uint) c_uint;
extern "c" fn poll(fds: [*]PollFd, n: c_ulong, timeout: c_int) c_int;
const PollFd = extern struct { fd: c_int, events: i16, revents: i16 };
const POLLIN: i16 = 1;

fn errorClnt(msg: []const u8) noreturn {
    pkt.sendSideband(1, 3, msg, pkt.LARGE_PACKET_MAX);
    util.die("sent error to the client: {s}", .{msg});
}

pub fn cmdUploadArchive(args: []const []const u8) u8 {
    showUsageIfAsked(args);
    proc.ignoreSigpipe();
    var wargs: std.ArrayList([]const u8) = .empty;
    wargs.append(gpa, "upload-archive--writer") catch util.oom();
    wargs.appendSlice(gpa, args[1..]) catch util.oom();
    var child = proc.spawnGit(wargs.items, .{ .pipe_out = true, .pipe_err = true });

    pkt.write(1, "ACK\n");
    pkt.flush(1);

    var buf: [16384]u8 = undefined;
    var fds = [2]PollFd{
        .{ .fd = child.out, .events = POLLIN, .revents = 0 },
        .{ .fd = child.err, .events = POLLIN, .revents = 0 },
    };
    while (fds[0].fd >= 0 or fds[1].fd >= 0) {
        if (poll(&fds, 2, -1) < 0) {
            if (os.errno() != 4) {
                util.err("poll failed resuming: {s}", .{os.lastErr()});
                _ = sleep(1);
            }
            continue;
        }
        // status stream first, as upstream does
        const order = [_]usize{ 1, 0 };
        for (order) |i| {
            if (fds[i].fd < 0 or fds[i].revents == 0) continue;
            const n = std.c.read(fds[i].fd, &buf, buf.len);
            if (n < 0) {
                const e = os.errno();
                if (e == 11 or e == 4) continue;
                errorClnt(util.fmt("read error: {s}\n", .{os.lastErr()}));
            }
            if (n == 0) {
                _ = std.c.close(fds[i].fd);
                fds[i].fd = -1;
                continue;
            }
            const band: u8 = if (i == 1) 2 else 1;
            pkt.sendSideband(1, band, buf[0..@intCast(n)], pkt.LARGE_PACKET_MAX);
        }
    }
    child.out = -1;
    child.err = -1;
    if (proc.wait(child.pid) != 0) errorClnt("git upload-archive: archiver died with error");
    pkt.flush(1);
    return 0;
}
