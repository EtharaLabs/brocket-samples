//! git fmt-merge-msg (port of builtin/fmt-merge-msg.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const fmm = @import("../fmt_merge_msg.zig");

const usage = [_][]const u8{"git fmt-merge-msg [-m <message>] [--log[=<n>] | --no-log] [--file <file>]"};

pub fn cmdFmtMergeMsg(args: []const []const u8) u8 {
    var inpath: ?[]const u8 = null;
    var message: ?[]const u8 = null;
    var into_name: ?[]const u8 = null;
    var shortlog_len: i32 = -1;
    const merge_log_config = fmm.loadConfig();
    const opts = [_]po.Opt{
        .{ .long = "log", .kind = .int, .i = &shortlog_len, .optarg = true, .val = fmm.DEFAULT_MERGE_LOG_LEN, .argh = "n", .help = "populate log with at most <n> entries from shortlog" },
        .{ .long = "summary", .kind = .int, .i = &shortlog_len, .optarg = true, .hidden = true, .val = fmm.DEFAULT_MERGE_LOG_LEN, .argh = "n", .help = "alias for --log (deprecated)" },
        po.string('m', "message", &message, "text", "use <text> as start of message"),
        po.string(0, "into-name", &into_name, "name", "use <name> instead of the real target branch"),
        po.filename('F', "file", &inpath, "file", "file to read from"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len > 0) po.usageWithOptions(&usage, &opts);
    if (shortlog_len < 0) shortlog_len = if (merge_log_config > 0) merge_log_config else 0;
    var input: []const u8 = undefined;
    if (inpath != null and !util.eql(inpath.?, "-")) {
        input = os.readFile(inpath.?) orelse util.dieErrno("cannot open '{s}'", .{inpath.?});
    } else {
        input = os.readAllFd(0) catch util.dieErrno("could not read input file", .{});
    }
    var out: util.Buf = .empty;
    if (message) |m| util.bufAppend(&out, m);
    const o = fmm.Opts{ .add_title = message == null, .credit_people = true, .shortlog_len = shortlog_len, .into_name = into_name };
    fmm.fmtMergeMsg(input, &out, &o);
    util.out(out.items);
    return 0;
}
