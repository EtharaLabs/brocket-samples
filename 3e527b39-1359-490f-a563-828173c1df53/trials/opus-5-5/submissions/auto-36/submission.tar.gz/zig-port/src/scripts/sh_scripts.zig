//! Shell libraries installed next to the git binary (git-sh-setup, git-sh-i18n).
//! Tabs are written as @T@ (Zig multiline strings cannot hold tabs); build.zig
//! expands them via `expand()`.

pub const sh_setup =
    \\# This shell scriplet is meant to be included by other shell scripts
    \\# to set up some variables pointing at the normal git directories and
    \\# a few helper shell functions.
    \\
    \\# Having this variable in your environment would break scripts because
    \\# you would cause "cd" to be taken to unexpected places.  If you
    \\# like CDPATH, define it for your interactive shell sessions without
    \\# exporting it.
    \\# But we protect ourselves from such a user mistake nevertheless.
    \\unset CDPATH
    \\
    \\# Similarly for IFS, but some shells (e.g. FreeBSD 7.2) are buggy and
    \\# do not equate an unset IFS with IFS with the default, so here is
    \\# an explicit SP HT LF.
    \\IFS=' @T@
    \\'
    \\
    \\git_broken_path_fix () {
    \\@T@case ":$PATH:" in
    \\@T@*:$1:*) : ok ;;
    \\@T@*)
    \\@T@@T@PATH=$(
    \\@T@@T@@T@SANE_TOOL_PATH="$1"
    \\@T@@T@@T@IFS=: path= sep=
    \\@T@@T@@T@set x $PATH
    \\@T@@T@@T@shift
    \\@T@@T@@T@for elem
    \\@T@@T@@T@do
    \\@T@@T@@T@@T@case "$SANE_TOOL_PATH:$elem" in
    \\@T@@T@@T@@T@(?*:/bin | ?*:/usr/bin)
    \\@T@@T@@T@@T@@T@path="$path$sep$SANE_TOOL_PATH"
    \\@T@@T@@T@@T@@T@sep=:
    \\@T@@T@@T@@T@@T@SANE_TOOL_PATH=
    \\@T@@T@@T@@T@esac
    \\@T@@T@@T@@T@path="$path$sep$elem"
    \\@T@@T@@T@@T@sep=:
    \\@T@@T@@T@done
    \\@T@@T@@T@echo "$path"
    \\@T@@T@)
    \\@T@@T@;;
    \\@T@esac
    \\}
    \\
    \\# @BROKEN_PATH_FIX@
    \\
    \\# Source git-sh-i18n for gettext support.
    \\. "$(git --exec-path)/git-sh-i18n"
    \\
    \\die () {
    \\@T@die_with_status 1 "$@"
    \\}
    \\
    \\die_with_status () {
    \\@T@status=$1
    \\@T@shift
    \\@T@printf >&2 '%s\n' "$*"
    \\@T@exit "$status"
    \\}
    \\
    \\if test -n "$OPTIONS_SPEC"; then
    \\@T@usage() {
    \\@T@@T@"$0" -h
    \\@T@@T@exit 1
    \\@T@}
    \\
    \\@T@parseopt_extra=
    \\@T@[ -n "$OPTIONS_KEEPDASHDASH" ] &&
    \\@T@@T@parseopt_extra="--keep-dashdash"
    \\@T@[ -n "$OPTIONS_STUCKLONG" ] &&
    \\@T@@T@parseopt_extra="$parseopt_extra --stuck-long"
    \\
    \\@T@eval "$(
    \\@T@@T@echo "$OPTIONS_SPEC" |
    \\@T@@T@@T@git rev-parse --parseopt $parseopt_extra -- "$@" ||
    \\@T@@T@echo exit $?
    \\@T@)"
    \\else
    \\@T@dashless=$(basename -- "$0" | sed -e 's/-/ /')
    \\@T@usage() {
    \\@T@@T@die "$(eval_gettext "usage: \$dashless \$USAGE")"
    \\@T@}
    \\
    \\@T@if [ -z "$LONG_USAGE" ]
    \\@T@then
    \\@T@@T@LONG_USAGE="$(eval_gettext "usage: \$dashless \$USAGE")"
    \\@T@else
    \\@T@@T@LONG_USAGE="$(eval_gettext "usage: \$dashless \$USAGE
    \\
    \\$LONG_USAGE")"
    \\@T@fi
    \\
    \\@T@case "$1" in
    \\@T@@T@-h)
    \\@T@@T@echo "$LONG_USAGE"
    \\@T@@T@exit
    \\@T@esac
    \\fi
    \\
    \\# Set the name of the end-user facing command in the reflog when the
    \\# script may update refs.  When GIT_REFLOG_ACTION is already set, this
    \\# will not overwrite it, so that a scripted Porcelain (e.g. "git
    \\# rebase") can set it to its own name (e.g. "rebase") and then call
    \\# another scripted Porcelain (e.g. "git am") and a call to this
    \\# function in the latter will keep the name of the end-user facing
    \\# program (e.g. "rebase") in GIT_REFLOG_ACTION, ensuring whatever it
    \\# does will be record as actions done as part of the end-user facing
    \\# operation (e.g. "rebase").
    \\#
    \\# NOTE NOTE NOTE: consequently, after assigning a specific message to
    \\# GIT_REFLOG_ACTION when calling a "git" command to record a custom
    \\# reflog message, do not leave that custom value in GIT_REFLOG_ACTION,
    \\# after you are done.  Other callers of "git" commands that rely on
    \\# writing the default "program name" in reflog expect the variable to
    \\# contain the value set by this function.
    \\#
    \\# To use a custom reflog message, do either one of these three:
    \\#
    \\# (a) use a single-shot export form:
    \\#     GIT_REFLOG_ACTION="$GIT_REFLOG_ACTION: preparing frotz" \
    \\#         git command-that-updates-a-ref
    \\#
    \\# (b) save the original away and restore:
    \\#     SAVED_ACTION=$GIT_REFLOG_ACTION
    \\#     GIT_REFLOG_ACTION="$GIT_REFLOG_ACTION: preparing frotz"
    \\#     git command-that-updates-a-ref
    \\#     GIT_REFLOG_ACITON=$SAVED_ACTION
    \\#
    \\# (c) assign the variable in a subshell:
    \\#     (
    \\#         GIT_REFLOG_ACTION="$GIT_REFLOG_ACTION: preparing frotz"
    \\#         git command-that-updates-a-ref
    \\#     )
    \\set_reflog_action() {
    \\@T@if [ -z "${GIT_REFLOG_ACTION:+set}" ]
    \\@T@then
    \\@T@@T@GIT_REFLOG_ACTION="$*"
    \\@T@@T@export GIT_REFLOG_ACTION
    \\@T@fi
    \\}
    \\
    \\git_editor() {
    \\@T@if test -z "${GIT_EDITOR:+set}"
    \\@T@then
    \\@T@@T@GIT_EDITOR="$(git var GIT_EDITOR)" || return $?
    \\@T@fi
    \\
    \\@T@eval "$GIT_EDITOR" '"$@"'
    \\}
    \\
    \\git_pager() {
    \\@T@if test -t 1
    \\@T@then
    \\@T@@T@GIT_PAGER=$(git var GIT_PAGER)
    \\@T@else
    \\@T@@T@GIT_PAGER=cat
    \\@T@fi
    \\@T@for vardef in LESS=FRX LV=-c
    \\@T@do
    \\@T@@T@var=${vardef%%=*}
    \\@T@@T@eval ": \"\${$vardef}\" && export $var"
    \\@T@done
    \\
    \\@T@eval "$GIT_PAGER" '"$@"'
    \\}
    \\
    \\is_bare_repository () {
    \\@T@git rev-parse --is-bare-repository
    \\}
    \\
    \\cd_to_toplevel () {
    \\@T@cdup=$(git rev-parse --show-toplevel) &&
    \\@T@cd "$cdup" || {
    \\@T@@T@gettextln "Cannot chdir to \$cdup, the toplevel of the working tree" >&2
    \\@T@@T@exit 1
    \\@T@}
    \\}
    \\
    \\require_work_tree_exists () {
    \\@T@if test "z$(git rev-parse --is-bare-repository)" != zfalse
    \\@T@then
    \\@T@@T@program_name=$0
    \\@T@@T@die "$(eval_gettext "fatal: \$program_name cannot be used without a working tree.")"
    \\@T@fi
    \\}
    \\
    \\require_work_tree () {
    \\@T@test "$(git rev-parse --is-inside-work-tree 2>/dev/null)" = true || {
    \\@T@@T@program_name=$0
    \\@T@@T@die "$(eval_gettext "fatal: \$program_name cannot be used without a working tree.")"
    \\@T@}
    \\}
    \\
    \\require_clean_work_tree () {
    \\@T@git rev-parse --verify HEAD >/dev/null || exit 1
    \\@T@git update-index -q --ignore-submodules --refresh
    \\@T@err=0
    \\
    \\@T@if ! git diff-files --quiet --ignore-submodules
    \\@T@then
    \\@T@@T@action=$1
    \\@T@@T@case "$action" in
    \\@T@@T@"rewrite branches")
    \\@T@@T@@T@gettextln "Cannot rewrite branches: You have unstaged changes." >&2
    \\@T@@T@@T@;;
    \\@T@@T@*)
    \\@T@@T@@T@eval_gettextln "Cannot \$action: You have unstaged changes." >&2
    \\@T@@T@@T@;;
    \\@T@@T@esac
    \\@T@@T@err=1
    \\@T@fi
    \\
    \\@T@if ! git diff-index --cached --quiet --ignore-submodules HEAD --
    \\@T@then
    \\@T@@T@if test $err = 0
    \\@T@@T@then
    \\@T@@T@@T@action=$1
    \\@T@@T@@T@eval_gettextln "Cannot \$action: Your index contains uncommitted changes." >&2
    \\@T@@T@else
    \\@T@@T@    gettextln "Additionally, your index contains uncommitted changes." >&2
    \\@T@@T@fi
    \\@T@@T@err=1
    \\@T@fi
    \\
    \\@T@if test $err = 1
    \\@T@then
    \\@T@@T@test -n "$2" && echo "$2" >&2
    \\@T@@T@exit 1
    \\@T@fi
    \\}
    \\
    \\# Generate a sed script to parse identities from a commit.
    \\#
    \\# Reads the commit from stdin, which should be in raw format (e.g., from
    \\# cat-file or "--pretty=raw").
    \\#
    \\# The first argument specifies the ident line to parse (e.g., "author"), and
    \\# the second specifies the environment variable to put it in (e.g., "AUTHOR"
    \\# for "GIT_AUTHOR_*"). Multiple pairs can be given to parse author and
    \\# committer.
    \\pick_ident_script () {
    \\@T@while test $# -gt 0
    \\@T@do
    \\@T@@T@lid=$1; shift
    \\@T@@T@uid=$1; shift
    \\@T@@T@printf '%s' "
    \\@T@@T@/^$lid /{
    \\@T@@T@@T@s/'/'\\\\''/g
    \\@T@@T@@T@h
    \\@T@@T@@T@s/^$lid "'\([^<]*\) <[^>]*> .*$/\1/'"
    \\@T@@T@@T@s/.*/GIT_${uid}_NAME='&'/p
    \\
    \\@T@@T@@T@g
    \\@T@@T@@T@s/^$lid "'[^<]* <\([^>]*\)> .*$/\1/'"
    \\@T@@T@@T@s/.*/GIT_${uid}_EMAIL='&'/p
    \\
    \\@T@@T@@T@g
    \\@T@@T@@T@s/^$lid "'[^<]* <[^>]*> \(.*\)$/@\1/'"
    \\@T@@T@@T@s/.*/GIT_${uid}_DATE='&'/p
    \\@T@@T@}
    \\@T@@T@"
    \\@T@done
    \\@T@echo '/^$/q'
    \\}
    \\
    \\# Create a pick-script as above and feed it to sed. Stdout is suitable for
    \\# feeding to eval.
    \\parse_ident_from_commit () {
    \\@T@LANG=C LC_ALL=C sed -ne "$(pick_ident_script "$@")"
    \\}
    \\
    \\# Parse the author from a commit given as an argument. Stdout is suitable for
    \\# feeding to eval to set the usual GIT_* ident variables.
    \\get_author_ident_from_commit () {
    \\@T@encoding=$(git config i18n.commitencoding || echo UTF-8)
    \\@T@git show -s --pretty=raw --encoding="$encoding" "$1" -- |
    \\@T@parse_ident_from_commit author AUTHOR
    \\}
    \\
    \\# Generate a virtual base file for a two-file merge. Uses git apply to
    \\# remove lines from $1 that are not in $2, leaving only common lines.
    \\create_virtual_base() {
    \\@T@sz0=$(wc -c <"$1")
    \\@T@diff -u -La/"$1" -Lb/"$1" "$1" "$2" | git apply --no-add
    \\@T@sz1=$(wc -c <"$1")
    \\
    \\@T@# If we do not have enough common material, it is not
    \\@T@# worth trying two-file merge using common subsections.
    \\@T@expr $sz0 \< $sz1 \* 2 >/dev/null || : >"$1"
    \\}
    \\
    \\
    \\# Platform specific tweaks to work around some commands
    \\case $(uname -s) in
    \\*MINGW*)
    \\@T@# Windows has its own (incompatible) sort and find
    \\@T@sort () {
    \\@T@@T@/usr/bin/sort "$@"
    \\@T@}
    \\@T@find () {
    \\@T@@T@/usr/bin/find "$@"
    \\@T@}
    \\@T@# git sees Windows-style pwd
    \\@T@pwd () {
    \\@T@@T@builtin pwd -W
    \\@T@}
    \\@T@is_absolute_path () {
    \\@T@@T@case "$1" in
    \\@T@@T@[/\\]* | [A-Za-z]:*)
    \\@T@@T@@T@return 0 ;;
    \\@T@@T@esac
    \\@T@@T@return 1
    \\@T@}
    \\@T@;;
    \\*)
    \\@T@is_absolute_path () {
    \\@T@@T@case "$1" in
    \\@T@@T@/*)
    \\@T@@T@@T@return 0 ;;
    \\@T@@T@esac
    \\@T@@T@return 1
    \\@T@}
    \\esac
    \\
    \\# Make sure we are in a valid repository of a vintage we understand,
    \\# if we require to be in a git repository.
    \\git_dir_init () {
    \\@T@GIT_DIR=$(git rev-parse --git-dir) || exit
    \\@T@if [ -z "$SUBDIRECTORY_OK" ]
    \\@T@then
    \\@T@@T@test -z "$(git rev-parse --show-cdup)" || {
    \\@T@@T@@T@exit=$?
    \\@T@@T@@T@gettextln "You need to run this command from the toplevel of the working tree." >&2
    \\@T@@T@@T@exit $exit
    \\@T@@T@}
    \\@T@fi
    \\@T@test -n "$GIT_DIR" && GIT_DIR=$(cd "$GIT_DIR" && pwd) || {
    \\@T@@T@gettextln "Unable to determine absolute path of git directory" >&2
    \\@T@@T@exit 1
    \\@T@}
    \\@T@: "${GIT_OBJECT_DIRECTORY="$(git rev-parse --git-path objects)"}"
    \\}
    \\
    \\if test -z "$NONGIT_OK"
    \\then
    \\@T@git_dir_init
    \\fi
    \\
    \\peel_committish () {
    \\@T@case "$1" in
    \\@T@:/*)
    \\@T@@T@peeltmp=$(git rev-parse --verify "$1") &&
    \\@T@@T@git rev-parse --verify "${peeltmp}^0"
    \\@T@@T@;;
    \\@T@*)
    \\@T@@T@git rev-parse --verify "${1}^0"
    \\@T@@T@;;
    \\@T@esac
    \\}
;

pub const sh_i18n =
    \\# This shell library is Git's interface to gettext.sh. See po/README
    \\# for usage instructions.
    \\#
    \\# Copyright (c) 2010 Ævar Arnfjörð Bjarmason
    \\#
    \\
    \\# Export the TEXTDOMAIN* data that we need for Git
    \\TEXTDOMAIN=git
    \\export TEXTDOMAIN
    \\if test -z "$GIT_TEXTDOMAINDIR"
    \\then
    \\@T@TEXTDOMAINDIR="/usr/local/share/locale"
    \\else
    \\@T@TEXTDOMAINDIR="$GIT_TEXTDOMAINDIR"
    \\fi
    \\export TEXTDOMAINDIR
    \\
    \\# First decide what scheme to use...
    \\GIT_INTERNAL_GETTEXT_SH_SCHEME=fallthrough
    \\if test -n "fallthrough"
    \\then
    \\@T@GIT_INTERNAL_GETTEXT_SH_SCHEME="fallthrough"
    \\elif test -n "$GIT_INTERNAL_GETTEXT_TEST_FALLBACKS"
    \\then
    \\@T@: no probing necessary
    \\elif type gettext.sh >/dev/null 2>&1
    \\then
    \\@T@# GNU libintl's gettext.sh
    \\@T@GIT_INTERNAL_GETTEXT_SH_SCHEME=gnu
    \\elif test "$(gettext -h 2>&1)" = "-h"
    \\then
    \\@T@# gettext binary exists but no gettext.sh. likely to be a gettext
    \\@T@# binary on a Solaris or something that is not GNU libintl and
    \\@T@# lack eval_gettext.
    \\@T@GIT_INTERNAL_GETTEXT_SH_SCHEME=gettext_without_eval_gettext
    \\fi
    \\export GIT_INTERNAL_GETTEXT_SH_SCHEME
    \\
    \\# ... and then follow that decision.
    \\case "$GIT_INTERNAL_GETTEXT_SH_SCHEME" in
    \\gnu)
    \\@T@# Use libintl's gettext.sh, or fall back to English if we can't.
    \\@T@. gettext.sh
    \\@T@;;
    \\gettext_without_eval_gettext)
    \\@T@# Solaris has a gettext(1) but no eval_gettext(1)
    \\@T@eval_gettext () {
    \\@T@@T@gettext "$1" | (
    \\@T@@T@@T@export PATH $(git sh-i18n--envsubst --variables "$1");
    \\@T@@T@@T@git sh-i18n--envsubst "$1"
    \\@T@@T@)
    \\@T@}
    \\
    \\@T@;;
    \\*)
    \\@T@gettext () {
    \\@T@@T@printf "%s" "$1"
    \\@T@}
    \\
    \\@T@eval_gettext () {
    \\@T@@T@printf "%s" "$1" | (
    \\@T@@T@@T@export PATH $(git sh-i18n--envsubst --variables "$1");
    \\@T@@T@@T@git sh-i18n--envsubst "$1"
    \\@T@@T@)
    \\@T@}
    \\
    \\@T@;;
    \\esac
    \\
    \\# Git-specific wrapper functions
    \\gettextln () {
    \\@T@gettext "$1"
    \\@T@echo
    \\}
    \\
    \\eval_gettextln () {
    \\@T@eval_gettext "$1"
    \\@T@echo
    \\}
;

/// Replace the @T@ placeholders with real tab characters.
pub fn expand(allocator: anytype, text: []const u8) []u8 {
    const std = @import("std");
    const t = std.mem.replaceOwned(u8, allocator, text, "@T@", "\t") catch @panic("OOM");
    return std.mem.concat(allocator, u8, &.{ t, "\n" }) catch @panic("OOM");
}
