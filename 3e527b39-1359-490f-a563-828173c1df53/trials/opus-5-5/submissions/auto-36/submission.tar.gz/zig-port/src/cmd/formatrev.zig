//! git format-rev (cmd_format_rev from builtin/name-rev.c).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const revision = @import("../revision.zig");
const pretty = @import("../pretty.zig");
const notes = @import("../notes.zig");
const cn = @import("../commitnode.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const color = @import("../color.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "(EXPERIMENTAL!) git format-rev --stdin-mode=<mode> --format=<pretty> [--[no-]notes=<ref>] [-z] [--[no-]null-output] [--[no-]null-input]",
};

var nul_input = false;
var nul_output = false;

fn nulCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    nul_input = true;
    nul_output = true;
}

const Fmt = struct {
    ctx: pretty.Context,
    want_notes: bool,
};

fn formatCommit(f: *Fmt, c: *cn.Commit, sb: *util.Buf) void {
    sb.clearRetainingCapacity();
    if (f.want_notes) {
        var nb: util.Buf = .empty;
        notes.formatDisplayNotes(c.obj.oid, &nb, pretty.logOutputEncoding(), f.ctx.fmt == .userformat);
        f.ctx.notes_message = nb.items;
    }
    pretty.prettyPrintCommit(&f.ctx, c, sb);
    f.ctx.notes_message = null;
}

fn isHexLower(ch: u8) bool {
    return (ch >= '0' and ch <= '9') or (ch >= 'a' and ch <= 'f');
}

fn formatLine(line: []const u8, f: *Fmt) void {
    var sb: util.Buf = .empty;
    var counter: usize = 0;
    var start: usize = 0;
    var i: usize = 0;
    while (i < line.len) : (i += 1) {
        if (!isHexLower(line[i])) {
            counter = 0;
            continue;
        }
        counter += 1;
        if (counter != 40 or (i + 1 < line.len and isHexLower(line[i + 1]))) continue;
        counter = 0;
        const hexs = line[i + 1 - 40 .. i + 1];
        var name: ?[]const u8 = null;
        if (hash.fromHex(hexs)) |oid| {
            if (cn.parseObject(oid)) |o| {
                if (o.typ == .commit) {
                    formatCommit(f, cn.Commit.fromObj(o), &sb);
                    name = sb.items;
                }
            }
        }
        if (name) |n| {
            util.out(line[start .. i + 1 - 40]);
            util.out(n);
        } else util.out(line[start .. i + 1]);
        start = i + 1;
    }
    if (start < line.len) util.out(line[start..]);
}

pub fn cmdFormatRev(args: []const []const u8) u8 {
    var format: ?[]const u8 = null;
    var stdin_mode_arg: ?[]const u8 = null;
    var notes_list: std.ArrayList([]const u8) = .empty;
    const opts = [_]po.Opt{
        po.string(0, "format", &format, "format", "pretty format to use"),
        po.string(0, "stdin-mode", &stdin_mode_arg, "stdin-mode", "how revs are processed"),
        po.list(0, "notes", &notes_list, "notes", "display notes for pretty format"),
        .{ .short = 'z', .long = "null", .kind = .callback, .cb = nulCb, .noarg = true, .noneg = true, .help = "Use NUL for input and output termination" },
        po.boolean(0, "null-input", &nul_input, "Use NUL for input termination"),
        po.boolean(0, "null-output", &nul_output, "Use NUL for output termination"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rest.len > 0) {
        util.eprint("error: too many arguments\n", .{});
        po.usageWithOptions(&usage, &opts);
    }
    const fmt_str = format orelse util.die("'{s}' is required", .{"--format"});
    const mode_arg = stdin_mode_arg orelse util.die("'{s}' is required", .{"--stdin-mode"});
    const text_mode = if (util.eql(mode_arg, "text"))
        true
    else if (util.eql(mode_arg, "revs") or util.eql(mode_arg, "rev"))
        false
    else
        util.die("'{s}' needs to be either text, revs, or rev", .{"--stdin-mode"});

    const in_term: u8 = if (nul_input) 0 else '\n';
    const out_term: []const u8 = if (nul_output) "\x00" else "\n";

    const prefix = if (repo_mod.repo_) |r| r.prefix else "";
    var revs = revision.RevInfo.init(prefix);
    pretty.getCommitFormat(fmt_str, &revs);
    var f = Fmt{ .ctx = .{}, .want_notes = false };
    f.ctx.rev = &revs;
    f.ctx.fmt = revs.commit_format;
    f.ctx.abbrev = revs.abbrev;
    f.ctx.date_mode_explicit = revs.date_mode_explicit;
    f.ctx.date_mode = revs.date_mode;
    f.ctx.output_encoding = pretty.logOutputEncoding();
    f.ctx.color = color.wantColorBool(.auto, null);
    if (f.ctx.fmt == .userformat) f.ctx.fmt_string = revs.user_format;

    f.want_notes = pretty.userformatFindRequirements(fmt_str).notes;
    if (f.want_notes) notes.loadDisplayNotes(-1, notes_list.items);

    const input = os.readAllFd(0) catch "";
    var lines: std.ArrayList([]const u8) = .empty;
    var p: usize = 0;
    while (p < input.len) {
        const e = std.mem.indexOfScalarPos(u8, input, p, in_term) orelse input.len;
        lines.append(gpa, input[p..e]) catch util.oom();
        p = e + 1;
    }

    var sb: util.Buf = .empty;
    for (lines.items) |line| {
        if (text_mode) {
            formatLine(line, &f);
            util.out(out_term);
            util.flushStdout();
            continue;
        }
        const oid = revparse.getOid(line) orelse {
            util.flushStdout();
            util.eprint("Could not get object name for {s}. Skipping.\n", .{line});
            continue;
        };
        const obj = cn.parseObject(oid) orelse {
            util.flushStdout();
            util.eprint("Could not get object for {s}. Skipping.\n", .{line});
            continue;
        };
        const peeled = cn.derefTag(obj);
        if (peeled == null or peeled.?.typ != .commit) {
            util.flushStdout();
            util.eprint("Could not get commit for {s}. Skipping.\n", .{line});
            continue;
        }
        formatCommit(&f, cn.Commit.fromObj(peeled.?), &sb);
        util.out(sb.items);
        util.out(out_term);
        util.flushStdout();
    }
    return 0;
}
