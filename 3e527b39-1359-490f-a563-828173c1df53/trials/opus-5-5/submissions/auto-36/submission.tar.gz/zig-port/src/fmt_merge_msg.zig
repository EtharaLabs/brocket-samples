//! Port of fmt-merge-msg.c

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const refs = @import("refs.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const cn = @import("commitnode.zig");
const creach = @import("commitreach.zig");
const revision = @import("revision.zig");
const pretty = @import("pretty.zig");
const trailer = @import("pretty_trailer.zig");
const wtstatus = @import("wtstatus.zig");
const wildmatch = @import("wildmatch.zig");
const ident = @import("ident.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const DEFAULT_MERGE_LOG_LEN: i32 = 20;

pub const Opts = struct {
    add_title: bool = true,
    credit_people: bool = true,
    shortlog_len: i32 = 0,
    into_name: ?[]const u8 = null,
};

var use_branch_desc = false;
var suppress_dest_pattern_seen = false;
var suppress_dest_patterns: std.ArrayList([]const u8) = .empty;
var config_loaded = false;

/// fmt_merge_msg_config(): returns merge.log value (-1 if unset).
pub fn loadConfig() i32 {
    var merge_log: i32 = -1;
    const cfg = &repo_mod.cfg;
    for (cfg.entries.items) |e| {
        if (util.eql(e.key, "merge.log") or util.eql(e.key, "merge.summary")) {
            var is_bool = false;
            const kvi = e.kvi();
            merge_log = config.configBoolOrInt(e.key, e.value, &kvi, &is_bool);
            if (!is_bool and merge_log < 0) {
                util.err("{s}: negative length {s}", .{ e.key, e.value orelse "" });
                util.die("bad config variable '{s}'", .{e.key});
            }
            if (is_bool and merge_log != 0) merge_log = DEFAULT_MERGE_LOG_LEN;
        } else if (util.eql(e.key, "merge.branchdesc")) {
            use_branch_desc = config.configBool(e.key, e.value);
        } else if (util.eql(e.key, "merge.suppressdest")) {
            const v = e.value orelse {
                _ = config.errorNonbool(e.key);
                util.die("bad config variable '{s}'", .{e.key});
            };
            if (v.len == 0) suppress_dest_patterns.clearRetainingCapacity() else suppress_dest_patterns.append(gpa, v) catch util.oom();
            suppress_dest_pattern_seen = true;
        }
    }
    config_loaded = true;
    return merge_log;
}

const SrcData = struct {
    branch: std.ArrayList([]const u8) = .empty,
    tag: std.ArrayList([]const u8) = .empty,
    r_branch: std.ArrayList([]const u8) = .empty,
    generic: std.ArrayList([]const u8) = .empty,
    head_status: u32 = 0,
};

const OriginData = struct {
    oid: Oid,
    is_local_branch: bool = false,
};

const MergeParent = struct { given: Oid, commit: Oid, used: bool = false };

const State = struct {
    srcs_names: std.ArrayList([]const u8) = .empty,
    srcs: std.ArrayList(*SrcData) = .empty,
    origins_names: std.ArrayList([]const u8) = .empty,
    origins: std.ArrayList(*OriginData) = .empty,
    parents: std.ArrayList(MergeParent) = .empty,

    fn findParent(self: *State, given: ?Oid, commit: ?Oid) ?*MergeParent {
        for (self.parents.items) |*p| {
            if (given) |g| if (!hash.eql(p.given, g)) continue;
            if (commit) |c| if (!hash.eql(p.commit, c)) continue;
            return p;
        }
        return null;
    }
};

fn handleLine(st: *State, line0: []const u8) u32 {
    const hexsz: usize = 40;
    var line = line0;
    if (line.len < hexsz + 3 or line[hexsz] != '\t') return 1;
    if (util.startsWith(line[hexsz + 1 ..], "not-for-merge")) return 0;
    if (line[hexsz + 1] != '\t') return 2;
    const oid = hash.fromHex(line[0..hexsz]) orelse return 3;
    if (st.findParent(oid, null) == null) return 0;
    const od = gpa.create(OriginData) catch util.oom();
    od.* = .{ .oid = oid };
    if (line[line.len - 1] == '\n') line = line[0 .. line.len - 1];
    line = line[hexsz + 2 ..];

    var src: []const u8 = undefined;
    var pulling_head = false;
    if (std.mem.indexOf(u8, line, " of ")) |p| {
        src = line[p + 4 ..];
        line = line[0..p];
    } else {
        src = line;
        pulling_head = true;
    }
    var sd: *SrcData = blk: {
        for (st.srcs_names.items, 0..) |n, i| if (util.eql(n, src)) break :blk st.srcs.items[i];
        const d = gpa.create(SrcData) catch util.oom();
        d.* = .{};
        st.srcs_names.append(gpa, src) catch util.oom();
        st.srcs.append(gpa, d) catch util.oom();
        break :blk d;
    };
    var origin: []const u8 = undefined;
    if (pulling_head) {
        origin = src;
        sd.head_status |= 1;
    } else if (util.skipPrefix(line, "branch ")) |o| {
        origin = o;
        od.is_local_branch = true;
        sd.branch.append(gpa, o) catch util.oom();
        sd.head_status |= 2;
    } else if (util.skipPrefix(line, "tag ")) |t| {
        origin = line;
        sd.tag.append(gpa, t) catch util.oom();
        sd.head_status |= 2;
    } else if (util.skipPrefix(line, "remote-tracking branch ")) |o| {
        origin = o;
        sd.r_branch.append(gpa, o) catch util.oom();
        sd.head_status |= 2;
    } else {
        origin = src;
        sd.generic.append(gpa, line) catch util.oom();
        sd.head_status |= 2;
    }
    if (util.eql(".", src) or util.eql(src, origin)) {
        if (origin.len >= 2 and origin[0] == '\'' and origin[origin.len - 1] == '\'') origin = origin[1 .. origin.len - 1];
    } else {
        origin = util.fmt("{s} of {s}", .{ origin, src });
    }
    if (!util.eql(".", src)) od.is_local_branch = false;
    st.origins_names.append(gpa, origin) catch util.oom();
    st.origins.append(gpa, od) catch util.oom();
    return 0;
}

fn printJoined(singular: []const u8, plural: []const u8, list: []const []const u8, out: *util.Buf) void {
    if (list.len == 0) return;
    if (list.len == 1) {
        util.bufAppend(out, singular);
        util.bufAppend(out, list[0]);
    } else {
        util.bufAppend(out, plural);
        for (list[0 .. list.len - 1], 0..) |s, i| {
            if (i > 0) util.bufAppend(out, ", ");
            util.bufAppend(out, s);
        }
        util.bufAppend(out, " and ");
        util.bufAppend(out, list[list.len - 1]);
    }
}

fn completeLine(out: *util.Buf) void {
    if (out.items.len > 0 and out.items[out.items.len - 1] != '\n') util.bufByte(out, '\n');
}

fn addBranchDesc(out: *util.Buf, name: []const u8) void {
    const desc = repo_mod.cfg.get(util.fmt("branch.{s}.description", .{name})) orelse return;
    var bp: usize = 0;
    while (bp < desc.len) {
        var ep = std.mem.indexOfScalarPos(u8, desc, bp, '\n') orelse desc.len;
        if (ep < desc.len) ep += 1;
        util.bufAppend(out, "  : ");
        util.bufAppend(out, desc[bp..ep]);
        bp = ep;
    }
    completeLine(out);
}

const Person = struct { name: []const u8, count: i32 };

fn recordPerson(which: u8, people: *std.ArrayList(Person), buffer: []const u8) void {
    const field = if (which == 'a') "\nauthor " else "\ncommitter ";
    const p = std.mem.indexOf(u8, buffer, field) orelse return;
    const start = p + field.len;
    const lt = std.mem.indexOfScalarPos(u8, buffer, start, '<') orelse (std.mem.indexOfScalarPos(u8, buffer, start, 0) orelse buffer.len);
    const name = std.mem.trimEnd(u8, buffer[start..lt], " \t\n\r\x0b\x0c");
    if (name.len == 0) return;
    // sorted insert (string_list_insert)
    var i: usize = 0;
    while (i < people.items.len) : (i += 1) {
        const o = std.mem.order(u8, people.items[i].name, name);
        if (o == .eq) {
            people.items[i].count += 1;
            return;
        }
        if (o == .gt) break;
    }
    people.insert(gpa, i, .{ .name = gpa.dupe(u8, name) catch util.oom(), .count = 1 }) catch util.oom();
}

fn addPeopleCount(out: *util.Buf, people: []const Person) void {
    if (people.len == 1) {
        util.bufAppend(out, people[0].name);
    } else if (people.len == 2) {
        util.bufAppend(out, util.fmt("{s} ({d}) and {s} ({d})", .{ people[0].name, people[0].count, people[1].name, people[1].count }));
    } else if (people.len > 0) {
        util.bufAppend(out, util.fmt("{s} ({d}) and others", .{ people[0].name, people[0].count }));
    }
}

fn creditPeople(out: *util.Buf, them: []const Person, kind: u8) void {
    const label = if (kind == 'a') "By" else "Via";
    const me = ident.ident(if (kind == 'a') .author else .committer, false);
    if (them.len == 0) return;
    if (them.len == 1) {
        if (util.skipPrefix(me, them[0].name)) |r| {
            if (util.startsWith(r, " <")) return;
        }
    }
    util.bufAppend(out, util.fmt("\n{s} {s} ", .{ trailer.commentLineStr(), label }));
    addPeopleCount(out, them);
}

fn personLess(_: void, a: Person, b: Person) bool {
    return a.count > b.count;
}

fn shortlog(name: []const u8, od: *OriginData, head: *cn.Commit, opts: *const Opts, out: *util.Buf) void {
    const obj = cn.parseObject(od.oid) orelse return;
    const branch = cn.derefTag(obj) orelse return;
    if (branch.typ != .commit) return;
    const limit = opts.shortlog_len;

    var revs = revision.RevInfo.init("");
    revision.diffMergesSuppress(&revs);
    revs.limited = true;
    _ = revision.setupRevisions(&revs, &.{"fmt-merge-msg"}, .{});
    revs.addPendingObject(branch, name);
    revs.addPendingObject(&head.obj, "^HEAD");
    head.obj.flags |= cn.UNINTERESTING;
    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});

    var subjects: std.ArrayList([]const u8) = .empty;
    var authors: std.ArrayList(Person) = .empty;
    var committers: std.ArrayList(Person) = .empty;
    var count: i32 = 0;
    while (revision.getRevision(&revs)) |commit| {
        _ = cn.parse(commit);
        const raw = commit.buffer;
        if (commit.parents != null and commit.parents.?.next != null) {
            if (opts.credit_people) recordPerson('c', &committers, raw);
            continue;
        }
        if (count == 0 and opts.credit_people) recordPerson('c', &committers, raw);
        if (opts.credit_people) recordPerson('a', &authors, raw);
        count += 1;
        if (@as(i64, @intCast(subjects.items.len)) > limit) continue;
        var sb: util.Buf = .empty;
        const ctx = pretty.Context{};
        pretty.formatCommitMessage(commit, "%s", &sb, &ctx);
        const s = std.mem.trimStart(u8, sb.items, " \t\n\r\x0b\x0c");
        subjects.append(gpa, if (s.len == 0) gpa.dupe(u8, &commit.hex()) catch util.oom() else s) catch util.oom();
    }
    if (opts.credit_people) {
        std.mem.sort(Person, authors.items, {}, personLess);
        std.mem.sort(Person, committers.items, {}, personLess);
        creditPeople(out, authors.items, 'a');
        creditPeople(out, committers.items, 'c');
    }
    if (count > limit) {
        util.bufAppend(out, util.fmt("\n* {s}: ({d} commits)\n", .{ name, count }));
    } else {
        util.bufAppend(out, util.fmt("\n* {s}:\n", .{name}));
    }
    if (od.is_local_branch and use_branch_desc) addBranchDesc(out, name);
    for (subjects.items, 0..) |s, i| {
        if (i >= @as(usize, @intCast(limit))) {
            util.bufAppend(out, "  ...\n");
        } else {
            util.bufAppend(out, util.fmt("  {s}\n", .{s}));
        }
    }
    cn.clearAllObjectFlags(cn.ALL_REV_FLAGS);
}

fn destSuppressed(dest: []const u8) bool {
    for (suppress_dest_patterns.items) |p| {
        if (wildmatch.match(p, dest, wildmatch.PATHNAME)) return true;
    }
    return false;
}

fn title(st: *State, out: *util.Buf, current_branch: []const u8) void {
    util.bufAppend(out, "Merge ");
    var sep: []const u8 = "";
    for (st.srcs.items, 0..) |sd, i| {
        var subsep: []const u8 = "";
        util.bufAppend(out, sep);
        sep = "; ";
        if (sd.head_status == 1) {
            util.bufAppend(out, st.srcs_names.items[i]);
            continue;
        }
        if (sd.head_status == 3) {
            subsep = ", ";
            util.bufAppend(out, "HEAD");
        }
        if (sd.branch.items.len > 0) {
            util.bufAppend(out, subsep);
            subsep = ", ";
            printJoined("branch ", "branches ", sd.branch.items, out);
        }
        if (sd.r_branch.items.len > 0) {
            util.bufAppend(out, subsep);
            subsep = ", ";
            printJoined("remote-tracking branch ", "remote-tracking branches ", sd.r_branch.items, out);
        }
        if (sd.tag.items.len > 0) {
            util.bufAppend(out, subsep);
            subsep = ", ";
            printJoined("tag ", "tags ", sd.tag.items, out);
        }
        if (sd.generic.items.len > 0) {
            util.bufAppend(out, subsep);
            printJoined("commit ", "commits ", sd.generic.items, out);
        }
        if (!util.eql(".", st.srcs_names.items[i])) util.bufAppend(out, util.fmt(" of {s}", .{st.srcs_names.items[i]}));
    }
    if (!destSuppressed(current_branch)) util.bufAppend(out, util.fmt(" into {s}", .{current_branch}));
    util.bufByte(out, '\n');
}

const sig_markers = [_][]const u8{ "-----BEGIN PGP SIGNATURE-----", "-----BEGIN PGP MESSAGE-----", "-----BEGIN SSH SIGNATURE-----", "-----BEGIN SIGNED MESSAGE-----" };

fn signatureStart(buf: []const u8) usize {
    var i: usize = 0;
    var found: usize = buf.len;
    while (i < buf.len) {
        const eol = std.mem.indexOfScalarPos(u8, buf, i, '\n') orelse buf.len;
        for (sig_markers) |m| {
            if (util.startsWith(buf[i..], m)) {
                found = i;
                break;
            }
        }
        if (found == i) {
            // keep searching for a later start (last signature wins)
        }
        i = eol + 1;
    }
    return found;
}

fn fmtTagSignature(tagbuf: *util.Buf, sig: []const u8, buf: []const u8) void {
    if (std.mem.indexOf(u8, buf, "\n\n")) |p| util.bufAppend(tagbuf, buf[p + 2 ..]);
    completeLine(tagbuf);
    if (sig.len > 0) {
        util.bufByte(tagbuf, '\n');
        wtstatus.addCommentedLines(tagbuf, trailer.commentLineStr(), sig);
    }
}

fn sigs(st: *State, out: *util.Buf) void {
    var tag_number: usize = 0;
    var first_tag: usize = 0;
    var tagbuf: util.Buf = .empty;
    const cs = trailer.commentLineStr();
    for (st.origins.items, 0..) |od, i| {
        const o = repo_mod.repo().odb().read(od.oid) orelse continue;
        if (o.typ != .tag) continue;
        var buf = o.data;
        var sig: []const u8 = "";
        const ss = signatureStart(buf);
        if (ss < buf.len) {
            sig = util.concat(&.{ buf[ss..], "gpg verification failed.\n" });
            buf = buf[0..ss];
        }
        if (tag_number == 0) {
            tag_number += 1;
            fmtTagSignature(&tagbuf, sig, buf);
            first_tag = i;
        } else {
            tag_number += 1;
            if (tag_number == 2) {
                var tl: util.Buf = .empty;
                util.bufByte(&tl, '\n');
                wtstatus.addCommentedLines(&tl, cs, st.origins_names.items[first_tag]);
                tagbuf.insertSlice(gpa, 0, tl.items) catch util.oom();
            }
            util.bufByte(&tagbuf, '\n');
            wtstatus.addCommentedLines(&tagbuf, cs, st.origins_names.items[i]);
            fmtTagSignature(&tagbuf, sig, buf);
        }
    }
    if (tagbuf.items.len > 0) {
        util.bufByte(out, '\n');
        util.bufAppend(out, tagbuf.items);
    }
}

fn findMergeParents(st: *State, in: []const u8, head: ?Oid) void {
    var parents: ?*cn.CommitList = null;
    var it = std.mem.splitScalar(u8, in, '\n');
    while (it.next()) |p| {
        if (p.len < 42) continue;
        const oid = hash.fromHex(p[0..40]) orelse continue;
        if (p[40] != '\t' or p[41] != '\t') continue;
        const obj = cn.parseObject(oid) orelse continue;
        const peeled = cn.derefTag(obj) orelse continue;
        if (peeled.typ != .commit) continue;
        const parent = cn.Commit.fromObj(peeled);
        _ = cn.listInsert(parent, &parents);
        if (st.findParent(obj.oid, parent.oid()) == null)
            st.parents.append(gpa, .{ .given = obj.oid, .commit = parent.oid() }) catch util.oom();
    }
    if (head) |h| {
        if (cn.lookupCommit(h)) |hc| _ = cn.listInsert(hc, &parents);
    }
    parents = creach.reduceHeads(parents);
    while (cn.popCommit(&parents)) |c| {
        for (st.parents.items) |*mp| {
            if (hash.eql(mp.commit, c.oid())) mp.used = true;
        }
    }
    var j: usize = 0;
    for (st.parents.items) |mp| {
        if (mp.used) {
            st.parents.items[j] = mp;
            j += 1;
        }
    }
    st.parents.shrinkRetainingCapacity(j);
}

/// fmt_merge_msg()
pub fn fmtMergeMsg(in: []const u8, out: *util.Buf, opts: *const Opts) void {
    if (!config_loaded) _ = loadConfig();
    if (!suppress_dest_pattern_seen) {
        suppress_dest_patterns.append(gpa, "main") catch util.oom();
        suppress_dest_patterns.append(gpa, "master") catch util.oom();
        suppress_dest_pattern_seen = true;
    }
    var st = State{};
    const r = refs.resolveFull("HEAD", true);
    if (r.broken) util.die("No current branch", .{});
    const head_oid: ?Oid = if (r.missing) null else r.oid;
    var current_branch = r.name;
    if (opts.into_name) |n| {
        current_branch = n;
    } else if (util.skipPrefix(current_branch, "refs/heads/")) |b| current_branch = b;

    findMergeParents(&st, in, head_oid);

    var lineno: usize = 0;
    var pos: usize = 0;
    while (pos < in.len) {
        const nl = std.mem.indexOfScalarPos(u8, in, pos, '\n');
        const end = nl orelse in.len;
        const p = in[pos..end];
        pos = if (nl) |n| n + 1 else in.len;
        lineno += 1;
        if (handleLine(&st, p) != 0) util.die("error in line {d}: {s}", .{ lineno, p });
    }
    if (opts.add_title and st.srcs.items.len > 0) title(&st, out, current_branch);
    if (st.origins.items.len > 0) sigs(&st, out);
    if (opts.shortlog_len != 0) {
        const head = (if (head_oid) |h| cn.lookupCommitReference(h) else null) orelse util.die("could not parse HEAD", .{});
        completeLine(out);
        for (st.origins.items, 0..) |od, i| shortlog(st.origins_names.items[i], od, head, opts, out);
    }
    completeLine(out);
}
