//! A few of git's t/helper test-tool subcommands that inspect on-disk
//! index state (reached when the binary is invoked as "test-tool").

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");

pub fn main(all0: []const []const u8) u8 {
    var all = all0;
    if (all.len > 2 and util.eql(all[1], "-C")) {
        if (!os.chdir(all[2])) util.die("cannot change working directory to '{s}'", .{all[2]});
        all = all[2..];
    }
    if (all.len < 2) util.die("usage: test-tool <cmd> [args]", .{});
    const cmd = all[1];
    const args = all[2..];
    if (util.eql(cmd, "dump-split-index")) return dumpSplitIndex(args);
    if (util.eql(cmd, "chmtime")) return chmtime(args);
    if (util.eql(cmd, "read-cache")) return readCache(args);
    if (util.eql(cmd, "dump-fsmonitor")) return dumpFsmonitor();
    if (util.eql(cmd, "dump-untracked-cache")) return dumpUntrackedCache();
    util.die("There is no test named '{s}'", .{cmd});
}

fn dumpSplitIndex(args: []const []const u8) u8 {
    repo_mod.setup(false);
    if (args.len < 1) util.die("usage: test-tool dump-split-index <file>", .{});
    const idx = index_mod.readRawFile(args[0]);
    util.outf("own {s}\n", .{&hash.hex(idx.oid)});
    const si = idx.split orelse {
        util.out("not a split index\n");
        return 0;
    };
    util.outf("base {s}\n", .{&hash.hex(si.base_oid)});
    for (idx.entries.items) |e| {
        util.outf("{o:0>6} {s} {d}\t{s}\n", .{ e.mode, &hash.hex(e.oid), e.stage(), e.path });
    }
    util.out("replacements:");
    if (si.replace_bm) |*bm| for (bm.bits()) |b| util.outf(" {d}", .{b});
    util.out("\ndeletions:");
    if (si.delete_bm) |*bm| for (bm.bits()) |b| util.outf(" {d}", .{b});
    util.out("\n");
    return 0;
}

/// test-dump-fsmonitor.c: reads the index without post-read tweaks.
fn dumpFsmonitor() u8 {
    repo_mod.setup(false);
    const idx = index_mod.readRawFile(repo_mod.repo().indexPath());
    const lu = idx.fsmonitor_last_update orelse {
        util.out("no fsmonitor\n");
        return 0;
    };
    util.outf("fsmonitor last update {s}\n", .{lu});
    for (idx.entries.items) |e| util.out(if (e.fsmonitor_valid) "+" else "-");
    return 0;
}

const Utimbuf = extern struct { actime: i64, modtime: i64 };
extern "c" fn utime(path: [*:0]const u8, times: *const Utimbuf) c_int;

/// test-tool chmtime [-g|--get] [-v|--verbose] [=|=+|=-|+|-]<seconds> <file>...
fn chmtime(args0: []const []const u8) u8 {
    var args = args0;
    var get = false;
    var verbose = false;
    while (args.len > 0) {
        if (util.eql(args[0], "-g") or util.eql(args[0], "--get")) {
            get = true;
        } else if (util.eql(args[0], "-v") or util.eql(args[0], "--verbose")) {
            verbose = true;
        } else break;
        args = args[1..];
    }
    var set_eq: u8 = 0; // 0 relative to file, 1 absolute, 2 relative to now
    var delta: i64 = 0;
    if (!get) {
        if (args.len == 0) util.die("usage: test-tool chmtime <time> <file>...", .{});
        var s = args[0];
        if (s.len > 0 and s[0] == '=') {
            set_eq = 1;
            s = s[1..];
            if (s.len > 0 and (s[0] == '+' or s[0] == '-')) set_eq = 2;
        }
        delta = std.fmt.parseInt(i64, s, 10) catch util.die("Not a base-10 integer: {s}", .{args[0]});
        args = args[1..];
    } else if (args.len > 0 and (args[0][0] == '=' or args[0][0] == '+' or args[0][0] == '-')) {
        args = args[1..];
    }
    const now = os.now();
    for (args) |f| {
        const st = os.statPath(f) orelse {
            util.eprint("Failed to stat {s}\n", .{f});
            return 1;
        };
        var mtime: i64 = st.mtime;
        if (!get) {
            mtime = switch (set_eq) {
                1 => delta,
                2 => now + delta,
                else => mtime + delta,
            };
        }
        if (get or verbose) util.outf("{d}\t{s}\n", .{ mtime, f });
        if (!get) {
            const ut = Utimbuf{ .actime = st.atime, .modtime = mtime };
            const z = util.concat(&.{ f, "\x00" });
            if (utime(z[0..f.len :0], &ut) != 0) {
                util.eprint("Failed to modify time on {s}\n", .{f});
                return 1;
            }
        }
    }
    return 0;
}

/// test-tool read-cache [--print-and-refresh=<path>] [--table] [--expand] [<count>]
fn readCache(args0: []const []const u8) u8 {
    const sparse_index = @import("../sparse_index.zig");
    var args = args0;
    var name: ?[]const u8 = null;
    var table = false;
    var expand = false;
    while (args.len > 0 and util.startsWith(args[0], "--")) : (args = args[1..]) {
        if (util.startsWith(args[0], "--print-and-refresh=")) {
            name = args[0]["--print-and-refresh=".len..];
        } else if (util.eql(args[0], "--table")) {
            table = true;
        } else if (util.eql(args[0], "--expand")) {
            expand = true;
        }
    }
    var cnt: i64 = 1;
    if (args.len == 1) cnt = std.fmt.parseInt(i64, args[0], 0) catch 0;
    repo_mod.setup(false);
    sparse_index.keep_sparse = true;
    var i: i64 = 0;
    while (i < cnt) : (i += 1) {
        index_mod.discard();
        const idx = index_mod.get();
        if (expand) sparse_index.ensureFull(idx);
        if (name) |n| {
            _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const @import("../pathspec.zig").Pathspec, null), null);
            const p = idx.findPos(n) orelse util.die("{s} not in index", .{n});
            util.outf("{s} is{s} up to date\n", .{ n, if (idx.entries.items[p].uptodate) "" else " not" });
            const content = std.fmt.allocPrint(util.gpa, "{d}\n", .{i}) catch util.oom();
            os.writeFile(n, content, 0o666) catch util.die("could not write {s}", .{n});
        }
        if (table) {
            for (idx.entries.items) |*e| {
                if (e.removed) continue;
                const m = e.mode & 0o170000;
                const typ = if (m == 0o040000) "tree" else if (m == 0o160000) "commit" else "blob";
                util.outf("{o:0>6} {s} {s}\t{s}\n", .{ e.mode & 0o177777, typ, &hash.hex(e.oid), e.path });
            }
        }
    }
    index_mod.discard();
    return 0;
}

/// test-tool dump-untracked-cache
fn dumpUntrackedCache() u8 {
    repo_mod.setup(false);
    const ip = repo_mod.repo().indexPath();
    if (!os.exists(ip)) {
        util.out("no untracked cache\n");
        return 0;
    }
    const idx = index_mod.readRawFile(ip);
    @import("../untracked_cache.zig").dump(idx.untracked);
    return 0;
}
