//! Port of mailinfo.c: parse an e-mail into authorship info, commit message
//! and patch (used by `git mailinfo` and `git am`).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const convert = @import("convert.zig");
const gpa = util.gpa;
const Buf = util.Buf;

pub const QuotedCr = enum { unset, nowarn, warn, strip };

pub fn parseQuotedCrAction(s: []const u8) ?QuotedCr {
    if (util.eql(s, "nowarn")) return .nowarn;
    if (util.eql(s, "warn")) return .warn;
    if (util.eql(s, "strip")) return .strip;
    return null;
}

/// git's sane isspace(): space, \t, \n, \r only.
pub fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r';
}

/// View of a buffer as a C string (up to the first NUL).
pub fn cstr(s: []const u8) []const u8 {
    return s[0 .. std.mem.indexOfScalar(u8, s, 0) orelse s.len];
}

/// stdio-like reader over an in-memory buffer, emulating fgetc/ungetc/feof and
/// strbuf_getwholeline() semantics.
pub const Input = struct {
    data: []const u8,
    pos: usize = 0,
    eof: bool = false,

    pub fn getc(self: *Input) ?u8 {
        if (self.pos >= self.data.len) {
            self.eof = true;
            return null;
        }
        const c = self.data[self.pos];
        self.pos += 1;
        return c;
    }

    pub fn ungetc(self: *Input) void {
        self.pos -= 1;
        self.eof = false;
    }

    /// strbuf_getwholeline(sb, fp, '\n'); returns true on EOF.
    pub fn getWholeLine(self: *Input, sb: *Buf) bool {
        if (self.eof) return true;
        sb.clearRetainingCapacity();
        if (self.pos >= self.data.len) {
            self.eof = true;
            return true;
        }
        var end: usize = undefined;
        if (std.mem.indexOfScalarPos(u8, self.data, self.pos, '\n')) |n| {
            end = n + 1;
        } else {
            end = self.data.len;
            self.eof = true;
        }
        util.bufAppend(sb, self.data[self.pos..end]);
        self.pos = end;
        return false;
    }

    /// strbuf_getline_lf(); returns true on EOF.
    pub fn getLineLf(self: *Input, sb: *Buf) bool {
        if (self.getWholeLine(sb)) return true;
        if (sb.items.len > 0 and sb.items[sb.items.len - 1] == '\n') sb.items.len -= 1;
        return false;
    }
};

const MAX_BOUNDARIES = 5;
const TransferEncoding = enum { dontcare, qp, base64 };
const header = [_][]const u8{ "From", "Subject", "Date" };
const SUBJECT = 1;

pub const MailInfo = struct {
    input: Input = .{ .data = "" },
    output: Buf = .empty,
    patchfile: Buf = .empty,

    name: Buf = .empty,
    email: Buf = .empty,
    keep_subject: bool = false,
    keep_non_patch_brackets_in_subject: bool = false,
    quoted_cr: QuotedCr = .warn,
    add_message_id: bool = false,
    use_scissors: bool = false,
    use_inbody_headers: bool = true,
    metainfo_charset: ?[]const u8 = null,

    content: [MAX_BOUNDARIES]?[]const u8 = @splat(null),
    content_top: usize = 0,
    charset: Buf = .empty,
    format_flowed: bool = false,
    delsp: bool = false,
    have_quoted_cr: bool = false,
    message_id: ?[]const u8 = null,
    transfer_encoding: TransferEncoding = .dontcare,
    patch_lines: usize = 0,
    filter_stage: u8 = 0,
    header_stage: bool = true,
    inbody_header_accum: Buf = .empty,
    p_hdr_data: [header.len]?Buf = @splat(null),
    s_hdr_data: [header.len]?Buf = @splat(null),

    log_message: Buf = .empty,
    input_error: bool = false,
};

/// setup_mailinfo(): defaults + mailinfo.* config.
pub fn setup(mi: *MailInfo) void {
    mi.* = .{};
    const cfg = &@import("repo.zig").cfg;
    if (cfg.getBool("mailinfo.scissors")) |b| mi.use_scissors = b;
    if (cfg.getEntry("mailinfo.quotedcr")) |e| {
        const v = e.value orelse util.die("missing value for '{s}'", .{"mailinfo.quotedcr"});
        mi.quoted_cr = parseQuotedCrAction(v) orelse {
            util.err("bad action '{s}' for '{s}'", .{ v, "mailinfo.quotedcr" });
            util.die("bad config variable '{s}'", .{"mailinfo.quotedcr"});
        };
    }
}

// ---------------------------------------------------------------- strbuf helpers

fn bufRemove(b: *Buf, pos: usize, n: usize) void {
    if (n == 0) return;
    std.mem.copyForwards(u8, b.items[pos..], b.items[pos + n ..]);
    b.items.len -= n;
}

fn bufInsert(b: *Buf, pos: usize, data: []const u8) void {
    if (data.len == 0) return;
    b.insertSlice(gpa, pos, data) catch util.oom();
}

fn bufSet(b: *Buf, data: []const u8) void {
    const copy = util.dupe(data);
    b.clearRetainingCapacity();
    util.bufAppend(b, copy);
}

fn rtrim(b: *Buf) void {
    while (b.items.len > 0 and isSpace(b.items[b.items.len - 1])) b.items.len -= 1;
}

fn trim(b: *Buf) void {
    rtrim(b);
    var i: usize = 0;
    while (i < b.items.len and isSpace(b.items[i])) i += 1;
    bufRemove(b, 0, i);
}

fn dupBuf(s: []const u8) Buf {
    var b: Buf = .empty;
    util.bufAppend(&b, s);
    return b;
}

fn indexOfIgnoreCase(hay: []const u8, needle: []const u8) ?usize {
    if (needle.len > hay.len) return null;
    var i: usize = 0;
    while (i + needle.len <= hay.len) : (i += 1) {
        if (std.ascii.eqlIgnoreCase(hay[i .. i + needle.len], needle)) return i;
    }
    return null;
}

fn hexval(c: u8) ?u8 {
    return switch (c) {
        '0'...'9' => c - '0',
        'a'...'f' => c - 'a' + 10,
        'A'...'F' => c - 'A' + 10,
        else => null,
    };
}

fn strcspn(s: []const u8, reject: []const u8) usize {
    var i: usize = 0;
    while (i < s.len and s[i] != 0 and std.mem.indexOfScalar(u8, reject, s[i]) == null) i += 1;
    return i;
}

// ---------------------------------------------------------------- From handling

fn cleanupSpace(sb: *Buf) void {
    var pos: usize = 0;
    while (pos < sb.items.len) : (pos += 1) {
        if (isSpace(sb.items[pos])) {
            sb.items[pos] = ' ';
            var cnt: usize = 0;
            while (pos + cnt + 1 < sb.items.len and isSpace(sb.items[pos + cnt + 1])) cnt += 1;
            bufRemove(sb, pos + 1, cnt);
        }
    }
}

fn saneName(name: []const u8, email: []const u8) []const u8 {
    if (name.len == 0 or 60 < name.len or std.mem.indexOfAny(u8, cstr(name), "@<>") != null)
        return email;
    return name;
}

fn parseBogusFrom(mi: *MailInfo, line: []const u8) void {
    if (mi.email.items.len > 0) return;
    const s = cstr(line);
    const bra = std.mem.indexOfScalar(u8, s, '<') orelse return;
    const ket = std.mem.indexOfScalarPos(u8, s, bra, '>') orelse return;
    bufSet(&mi.email, s[bra + 1 .. ket]);
    var nm = dupBuf(line[0..bra]);
    trim(&nm);
    bufSet(&mi.name, saneName(nm.items, mi.email.items));
}

fn unquoteComment(out: *Buf, in: []const u8, start: usize) usize {
    var take_next_literally = false;
    var depth: usize = 1;
    var i = start;
    util.bufByte(out, '(');
    while (i < in.len) {
        const c = in[i];
        i += 1;
        if (take_next_literally) {
            take_next_literally = false;
        } else {
            switch (c) {
                '\\' => {
                    take_next_literally = true;
                    continue;
                },
                '(' => {
                    util.bufByte(out, '(');
                    depth += 1;
                    continue;
                },
                ')' => {
                    util.bufByte(out, ')');
                    depth -= 1;
                    if (depth == 0) return i;
                    continue;
                },
                else => {},
            }
        }
        util.bufByte(out, c);
    }
    return i;
}

fn unquoteQuotedString(out: *Buf, in: []const u8, start: usize) usize {
    var take_next_literally = false;
    var i = start;
    while (i < in.len) {
        const c = in[i];
        i += 1;
        if (take_next_literally) {
            take_next_literally = false;
        } else {
            switch (c) {
                '\\' => {
                    take_next_literally = true;
                    continue;
                },
                '"' => return i,
                else => {},
            }
        }
        util.bufByte(out, c);
    }
    return i;
}

fn unquoteQuotedPair(line: []const u8) Buf {
    const in = cstr(line);
    var out: Buf = .empty;
    var i: usize = 0;
    while (i < in.len) {
        const c = in[i];
        i += 1;
        switch (c) {
            '"' => {
                i = unquoteQuotedString(&out, in, i);
                continue;
            },
            '(' => {
                i = unquoteComment(&out, in, i);
                continue;
            },
            else => {},
        }
        util.bufByte(&out, c);
    }
    return out;
}

fn handleFrom(mi: *MailInfo, from: []const u8) void {
    var f = unquoteQuotedPair(from);
    const at0 = std.mem.indexOfScalar(u8, f.items, '@') orelse {
        parseBogusFrom(mi, from);
        return;
    };
    if (mi.email.items.len > 0 and std.mem.indexOfScalarPos(u8, f.items, at0 + 1, '@') != null) return;

    var at = at0;
    while (at > 0) {
        const c = f.items[at - 1];
        if (isSpace(c)) break;
        if (c == '<') {
            f.items[at - 1] = ' ';
            break;
        }
        at -= 1;
    }
    const el = strcspn(f.items[at..], " \n\t\r\x0b\x0c>");
    bufSet(&mi.email, f.items[at .. at + el]);
    bufRemove(&f, at, el + @as(usize, if (at + el < f.items.len) 1 else 0));

    cleanupSpace(&f);
    trim(&f);
    if (f.items.len > 0 and f.items[0] == '(' and f.items[f.items.len - 1] == ')') {
        bufRemove(&f, 0, 1);
        f.items.len -= 1;
    }
    bufSet(&mi.name, saneName(f.items, mi.email.items));
}

// ---------------------------------------------------------------- MIME bits

fn slurpAttr(line: []const u8, name: []const u8, attr: *Buf) bool {
    attr.clearRetainingCapacity();
    const s = cstr(line);
    var ap = (indexOfIgnoreCase(s, name) orelse return false) + name.len;
    var ends: []const u8 = "; \t";
    if (ap < s.len and s[ap] == '"') {
        ap += 1;
        ends = "\"";
    }
    const sz = strcspn(s[ap..], ends);
    util.bufAppend(attr, s[ap .. ap + sz]);
    return true;
}

fn hasAttrValue(line: []const u8, name: []const u8, value: []const u8) bool {
    var sb: Buf = .empty;
    return slurpAttr(line, name, &sb) and std.ascii.eqlIgnoreCase(cstr(sb.items), value);
}

fn handleContentType(mi: *MailInfo, line: []const u8) void {
    mi.format_flowed = hasAttrValue(line, "format=", "flowed");
    mi.delsp = hasAttrValue(line, "delsp=", "yes");
    var boundary: Buf = .empty;
    if (slurpAttr(line, "boundary=", &boundary)) {
        bufInsert(&boundary, 0, "--");
        mi.content_top += 1;
        if (mi.content_top >= MAX_BOUNDARIES) {
            util.err("Too many boundaries to handle", .{});
            mi.input_error = true;
            mi.content_top = MAX_BOUNDARIES - 1;
        } else {
            mi.content[mi.content_top] = boundary.items;
        }
    }
    _ = slurpAttr(line, "charset=", &mi.charset);
}

fn handleContentTransferEncoding(mi: *MailInfo, line: []const u8) void {
    const s = cstr(line);
    if (indexOfIgnoreCase(s, "base64") != null) {
        mi.transfer_encoding = .base64;
    } else if (indexOfIgnoreCase(s, "quoted-printable") != null) {
        mi.transfer_encoding = .qp;
    } else {
        mi.transfer_encoding = .dontcare;
    }
}

fn isMultipartBoundary(mi: *MailInfo, line: []const u8) bool {
    const top = mi.content[mi.content_top].?;
    return top.len <= line.len and std.mem.eql(u8, line[0..top.len], top);
}

fn cleanupSubject(mi: *MailInfo, subject: *Buf) void {
    var at: usize = 0;
    while (at < subject.items.len) {
        switch (subject.items[at]) {
            'r', 'R' => {
                if (subject.items.len <= at + 3) break;
                if ((subject.items[at + 1] == 'e' or subject.items[at + 1] == 'E') and subject.items[at + 2] == ':') {
                    bufRemove(subject, at, 3);
                    continue;
                }
                break;
            },
            ' ', '\t', ':' => {
                bufRemove(subject, at, 1);
                continue;
            },
            '[' => {
                const rest = cstr(subject.items[at..]);
                const pos = std.mem.indexOfScalar(u8, rest, ']') orelse break;
                const remove = pos + 1;
                if (!mi.keep_non_patch_brackets_in_subject or
                    (7 <= remove and std.mem.indexOf(u8, subject.items[at .. at + remove], "PATCH") != null))
                {
                    bufRemove(subject, at, remove);
                } else {
                    at += remove;
                    if (at < subject.items.len and isSpace(subject.items[at])) at += 1;
                }
                continue;
            },
            else => break,
        }
    }
    trim(subject);
}

fn skipHeader(line: []const u8, hdr: []const u8) ?[]const u8 {
    if (line.len < hdr.len or !std.ascii.eqlIgnoreCase(line[0..hdr.len], hdr)) return null;
    var i = hdr.len;
    if (i >= line.len or line[i] != ':') return null;
    i += 1;
    while (i < line.len and isSpace(line[i])) i += 1;
    return line[i..];
}

fn isFormatPatchSeparator(line: []const u8) bool {
    const SAMPLE = "From e6807f3efca28b30decfecb1732a56c7db1137ee Mon Sep 17 00:00:00 2001\n";
    if (line.len != SAMPLE.len) return false;
    if (!util.startsWith(line, "From ")) return false;
    var n: usize = 0;
    while (5 + n < line.len and std.mem.indexOfScalar(u8, "0123456789abcdef", line[5 + n]) != null) n += 1;
    if (n != 40) return false;
    return std.mem.eql(u8, line[45..], SAMPLE[45..]);
}

fn decodeQSegment(out: *Buf, seg: []const u8, rfc2047: bool) void {
    const in = cstr(seg);
    var i: usize = 0;
    while (i < in.len) {
        var c = in[i];
        i += 1;
        if (c == '=') {
            if (i >= in.len or in[i] == '\n') break;
            if (i + 1 < in.len) {
                if (hexval(in[i])) |h| {
                    if (hexval(in[i + 1])) |l| {
                        util.bufByte(out, h * 16 + l);
                        i += 2;
                        continue;
                    }
                }
            }
        }
        if (rfc2047 and c == '_') c = 0x20;
        util.bufByte(out, c);
    }
}

fn decodeBSegment(out: *Buf, seg: []const u8) void {
    const in = cstr(seg);
    var pos: u8 = 0;
    var acc: u32 = 0;
    for (in) |ch| {
        var c: u32 = undefined;
        if (ch == '+') {
            c = 62;
        } else if (ch == '/') {
            c = 63;
        } else if ('A' <= ch and ch <= 'Z') {
            c = ch - 'A';
        } else if ('a' <= ch and ch <= 'z') {
            c = ch - 'a' + 26;
        } else if ('0' <= ch and ch <= '9') {
            c = ch - '0' + 52;
        } else continue;
        switch (pos) {
            0 => acc = c << 2,
            1 => {
                util.bufByte(out, @truncate(acc | (c >> 4)));
                acc = (c & 15) << 4;
            },
            2 => {
                util.bufByte(out, @truncate(acc | (c >> 2)));
                acc = (c & 3) << 6;
            },
            else => {
                util.bufByte(out, @truncate(acc | c));
                acc = 0;
            },
        }
        pos = (pos + 1) % 4;
    }
}

/// Returns false on conversion error (input_error set).
fn convertToUtf8(mi: *MailInfo, line: *Buf, charset0: []const u8) bool {
    const meta = mi.metainfo_charset orelse return true;
    const charset = cstr(charset0);
    if (charset.len == 0) return true;
    if (convert.sameEncoding(meta, charset)) return true;
    const out = convert.reencode(line.items, meta, charset) orelse {
        mi.input_error = true;
        util.err("cannot convert from {s} to {s}", .{ charset, meta });
        return false;
    };
    bufSet(line, out);
    return true;
}

fn decodeHeader(mi: *MailInfo, it: *Buf) void {
    const s = util.dupe(cstr(it.items));
    var outbuf: Buf = .empty;
    var found_error = true;
    var in: usize = 0;
    done: {
        while (std.mem.indexOfPos(u8, s, in, "=?")) |ep0| {
            if (in != ep0) {
                var scan = in;
                while (scan < ep0 and isSpace(s[scan])) scan += 1;
                if (scan != ep0 or in == 0) util.bufAppend(&outbuf, s[in..ep0]);
            }
            const ep = ep0 + 2;
            if (ep >= s.len) break :done;
            const cp = std.mem.indexOfScalarPos(u8, s, ep, '?') orelse break :done;
            if (cp + 2 >= s.len) break :done;
            const charset_q = s[ep..cp];
            const encoding = s[cp + 1];
            if (s[cp + 2] != '?') break :done;
            const ep2 = std.mem.indexOfPos(u8, s, cp + 3, "?=") orelse break :done;
            const piece = s[cp + 3 .. ep2];
            var dec: Buf = .empty;
            switch (std.ascii.toLower(encoding)) {
                'b' => {
                    decodeBSegment(&dec, piece);
                    found_error = false;
                },
                'q' => {
                    decodeQSegment(&dec, piece, true);
                    found_error = false;
                },
                else => break :done,
            }
            if (!convertToUtf8(mi, &dec, charset_q)) break :done;
            util.bufAppend(&outbuf, dec.items);
            in = ep2 + 2;
        }
        util.bufAppend(&outbuf, s[in..]);
        it.clearRetainingCapacity();
        util.bufAppend(it, outbuf.items);
        found_error = false;
    }
    if (found_error) mi.input_error = true;
}

fn parseHeader(line: []const u8, hdr: []const u8, mi: *MailInfo, val: *Buf) bool {
    const v = skipHeader(line, hdr) orelse return false;
    util.bufAppend(val, cstr(v));
    decodeHeader(mi, val);
    return true;
}

fn checkHeader(mi: *MailInfo, line: []const u8, hdr_data: *[header.len]?Buf, overwrite: bool) bool {
    var sb: Buf = .empty;
    for (header, 0..) |h, i| {
        if ((hdr_data[i] == null or overwrite) and parseHeader(line, h, mi, &sb)) {
            hdr_data[i] = sb;
            return true;
        }
    }
    if (parseHeader(line, "Content-Type", mi, &sb)) {
        handleContentType(mi, sb.items);
        return true;
    }
    if (parseHeader(line, "Content-Transfer-Encoding", mi, &sb)) {
        handleContentTransferEncoding(mi, sb.items);
        return true;
    }
    if (parseHeader(line, "Message-ID", mi, &sb)) {
        if (mi.add_message_id) mi.message_id = sb.items;
        return true;
    }
    return false;
}

fn isInbodyHeader(mi: *const MailInfo, line: []const u8) bool {
    for (header, 0..) |h, i| {
        if (mi.s_hdr_data[i] == null and skipHeader(line, h) != null) return true;
    }
    return false;
}

fn decodeTransferEncoding(mi: *MailInfo, line: *Buf) void {
    var ret: Buf = .empty;
    switch (mi.transfer_encoding) {
        .qp => decodeQSegment(&ret, line.items, false),
        .base64 => decodeBSegment(&ret, line.items),
        .dontcare => return,
    }
    line.clearRetainingCapacity();
    util.bufAppend(line, ret.items);
}

fn patchbreak(line: []const u8) bool {
    if (util.startsWith(line, "diff -")) return true;
    if (util.startsWith(line, "Index: ")) return true;
    if (line.len < 4) return false;
    if (util.startsWith(line, "---")) {
        const c4: u8 = if (line.len > 4) line[4] else 0;
        if (line[3] == ' ' and !isSpace(c4)) return true;
        var i: usize = 3;
        while (i < line.len) : (i += 1) {
            const c = line[i];
            if (c == '\n') return true;
            if (!isSpace(c)) break;
        }
        return false;
    }
    return false;
}

pub fn isScissorsLine(line0: []const u8) bool {
    const line = cstr(line0);
    var scissors: i64 = 0;
    var gap: i64 = 0;
    var first_nonblank: ?usize = null;
    var last_nonblank: ?usize = null;
    var perforation: i64 = 0;
    var in_perforation = false;
    var c: usize = 0;
    while (c < line.len) : (c += 1) {
        if (isSpace(line[c])) {
            if (in_perforation) {
                perforation += 1;
                gap += 1;
            }
            continue;
        }
        last_nonblank = c;
        if (first_nonblank == null) first_nonblank = c;
        if (line[c] == '-') {
            in_perforation = true;
            perforation += 1;
            continue;
        }
        const rest = line[c..];
        if (util.startsWith(rest, ">8") or util.startsWith(rest, "8<") or
            util.startsWith(rest, ">%") or util.startsWith(rest, "%<"))
        {
            in_perforation = true;
            perforation += 2;
            scissors += 2;
            c += 1;
            continue;
        }
        in_perforation = false;
    }
    var visible: i64 = 0;
    if (first_nonblank != null and last_nonblank != null)
        visible = @as(i64, @intCast(last_nonblank.?)) - @as(i64, @intCast(first_nonblank.?)) + 1;
    return scissors != 0 and 8 <= visible and visible < perforation * 3 and gap * 2 < perforation;
}

fn flushInbodyHeaderAccum(mi: *MailInfo) void {
    if (mi.inbody_header_accum.items.len == 0) return;
    const acc = util.dupe(mi.inbody_header_accum.items);
    if (!checkHeader(mi, acc, &mi.s_hdr_data, false))
        util.die("BUG: inbody_header_accum, if not empty, must always contain a valid in-body header", .{});
    mi.inbody_header_accum.clearRetainingCapacity();
}

fn checkInbodyHeader(mi: *MailInfo, line: []const u8) bool {
    if (mi.inbody_header_accum.items.len > 0 and line.len > 0 and (line[0] == ' ' or line[0] == '\t')) {
        if (mi.use_scissors and isScissorsLine(line)) {
            flushInbodyHeaderAccum(mi);
            return false;
        }
        const acc = &mi.inbody_header_accum;
        if (acc.items.len > 0 and acc.items[acc.items.len - 1] == '\n') acc.items.len -= 1;
        util.bufAppend(acc, line);
        return true;
    }
    flushInbodyHeaderAccum(mi);

    if (util.startsWith(line, ">From") and line.len > 5 and isSpace(line[5]))
        return isFormatPatchSeparator(line[1..]);
    if (util.startsWith(line, "[PATCH]") and line.len > 7 and isSpace(line[7])) {
        mi.s_hdr_data[SUBJECT] = dupBuf(line);
        return true;
    }
    if (isInbodyHeader(mi, line)) {
        util.bufAppend(&mi.inbody_header_accum, line);
        return true;
    }
    return false;
}

fn handleCommitMsg(mi: *MailInfo, line: *Buf) bool {
    if (mi.header_stage) {
        if (line.items.len == 0 or (line.items.len == 1 and line.items[0] == '\n')) {
            if (mi.inbody_header_accum.items.len > 0) {
                flushInbodyHeaderAccum(mi);
                mi.header_stage = false;
            }
            return false;
        }
    }

    if (mi.use_inbody_headers and mi.header_stage) {
        mi.header_stage = checkInbodyHeader(mi, line.items);
        if (mi.header_stage) return false;
    } else {
        mi.header_stage = false;
    }

    if (!convertToUtf8(mi, line, mi.charset.items)) return false;

    if (mi.use_scissors and isScissorsLine(line.items)) {
        mi.log_message.clearRetainingCapacity();
        mi.header_stage = true;
        mi.s_hdr_data = @splat(null);
        return false;
    }

    if (patchbreak(line.items)) {
        if (mi.message_id) |id| util.bufPrint(&mi.log_message, "Message-ID: {s}\n", .{cstr(id)});
        return true;
    }

    util.bufAppend(&mi.log_message, line.items);
    return false;
}

fn handlePatch(mi: *MailInfo, line: []const u8) void {
    util.bufAppend(&mi.patchfile, line);
    mi.patch_lines += 1;
}

fn handleFilter(mi: *MailInfo, line: *Buf) void {
    if (mi.filter_stage == 0) {
        if (!handleCommitMsg(mi, line)) return;
        mi.filter_stage += 1;
    }
    handlePatch(mi, line.items);
}

fn isRfc2822Header(line: []const u8) bool {
    if (util.startsWith(line, "From ") or util.startsWith(line, ">From ")) return true;
    for (line) |ch| {
        if (ch == 0) break;
        if (ch == ':') return true;
        if ((33 <= ch and ch <= 57) or (59 <= ch and ch <= 126)) continue;
        break;
    }
    return false;
}

fn readOneHeaderLine(line: *Buf, in: *Input) bool {
    if (in.getLineLf(line)) return false;
    rtrim(line);
    if (line.items.len == 0 or !isRfc2822Header(line.items)) {
        util.bufByte(line, '\n');
        return false;
    }
    var continuation: Buf = .empty;
    while (true) {
        const peek = in.getc() orelse break;
        in.ungetc();
        if (peek != ' ' and peek != '\t') break;
        if (in.getLineLf(&continuation)) break;
        continuation.items[0] = ' ';
        rtrim(&continuation);
        util.bufAppend(line, continuation.items);
    }
    return true;
}

fn findBoundary(mi: *MailInfo, line: *Buf) bool {
    while (!mi.input.getLineLf(line)) {
        if (mi.content[mi.content_top] != null and isMultipartBoundary(mi, line.items)) return true;
    }
    return false;
}

fn handleBoundary(mi: *MailInfo, line: *Buf) bool {
    while (true) {
        const top = mi.content[mi.content_top].?;
        if (line.items.len >= top.len + 2 and std.mem.eql(u8, line.items[top.len .. top.len + 2], "--")) {
            mi.content[mi.content_top] = null;
            if (mi.content_top == 0) {
                util.err("Detected mismatched boundaries, can't recover", .{});
                mi.input_error = true;
                return false;
            }
            mi.content_top -= 1;
            var newline = dupBuf("\n");
            handleFilter(mi, &newline);
            if (mi.input_error) return false;
            if (!findBoundary(mi, line)) return false;
            continue;
        }
        break;
    }
    mi.transfer_encoding = .dontcare;
    mi.charset.clearRetainingCapacity();
    while (readOneHeaderLine(line, &mi.input)) {
        const l = util.dupe(line.items);
        _ = checkHeader(mi, l, &mi.p_hdr_data, false);
    }
    if (mi.input.getLineLf(line)) return false;
    util.bufByte(line, '\n');
    return true;
}

fn handleFilterFlowed(mi: *MailInfo, line: *Buf, prev: *Buf) void {
    var len = line.items.len;
    if (!mi.format_flowed) {
        if (len >= 2 and line.items[len - 2] == '\r' and line.items[len - 1] == '\n') {
            mi.have_quoted_cr = true;
            if (mi.quoted_cr == .strip) {
                line.items.len = len - 2;
                util.bufByte(line, '\n');
            }
        }
        handleFilter(mi, line);
        return;
    }
    if (len > 0 and line.items[len - 1] == '\n') {
        len -= 1;
        if (len > 0 and line.items[len - 1] == '\r') len -= 1;
    }
    if (util.startsWith(line.items, "-- ") and len == 3) {
        if (prev.items.len > 0) {
            handleFilter(mi, prev);
            prev.clearRetainingCapacity();
        }
        handleFilter(mi, line);
        return;
    }
    if (len > 0 and line.items[0] == ' ') {
        bufRemove(line, 0, 1);
        len -= 1;
    }
    if (len > 0 and line.items[len - 1] == ' ') {
        util.bufAppend(prev, line.items[0 .. len - @as(usize, if (mi.delsp) 1 else 0)]);
        return;
    }
    bufInsert(line, 0, prev.items);
    prev.clearRetainingCapacity();
    handleFilter(mi, line);
}

fn summarizeQuotedCr(mi: *MailInfo) void {
    if (mi.have_quoted_cr and mi.quoted_cr == .warn) util.warn("quoted CRLF detected", .{});
}

fn handleBody(mi: *MailInfo, line: *Buf) void {
    var prev: Buf = .empty;
    if (mi.content[mi.content_top] != null) {
        if (!findBoundary(mi, line)) return;
    }
    while (true) {
        if (mi.content[mi.content_top] != null and isMultipartBoundary(mi, line.items)) {
            if (prev.items.len > 0) {
                handleFilter(mi, &prev);
                prev.clearRetainingCapacity();
            }
            summarizeQuotedCr(mi);
            mi.have_quoted_cr = false;
            if (!handleBoundary(mi, line)) return;
        }

        decodeTransferEncoding(mi, line);

        switch (mi.transfer_encoding) {
            .base64, .qp => {
                bufInsert(line, 0, prev.items);
                prev.clearRetainingCapacity();
                var pieces: std.ArrayList(Buf) = .empty;
                var rest: []const u8 = line.items;
                while (rest.len > 0) {
                    const n = if (std.mem.indexOfScalar(u8, rest, '\n')) |e| e + 1 else rest.len;
                    pieces.append(gpa, dupBuf(rest[0..n])) catch util.oom();
                    rest = rest[n..];
                }
                for (pieces.items, 0..) |*sb, idx| {
                    if (idx + 1 == pieces.items.len and sb.items[sb.items.len - 1] != '\n') {
                        util.bufAppend(&prev, sb.items);
                        break;
                    }
                    handleFilterFlowed(mi, sb, &prev);
                }
            },
            .dontcare => handleFilterFlowed(mi, line, &prev),
        }

        if (mi.input_error) break;
        if (mi.input.getWholeLine(line)) break;
    }
    if (prev.items.len > 0) handleFilter(mi, &prev);
    summarizeQuotedCr(mi);
    flushInbodyHeaderAccum(mi);
}

fn outputHeaderLines(out: *Buf, hdr: []const u8, data: []const u8) void {
    var sp = data;
    while (true) {
        const s = cstr(sp);
        if (std.mem.indexOfScalar(u8, s, '\n')) |ep| {
            util.bufPrint(out, "{s}: {s}\n", .{ hdr, s[0..ep] });
            sp = sp[ep + 1 ..];
        } else {
            util.bufPrint(out, "{s}: {s}\n", .{ hdr, s });
            break;
        }
    }
}

fn handleInfo(mi: *MailInfo) void {
    for (header, 0..) |h, i| {
        var hdr: *Buf = undefined;
        if (mi.patch_lines > 0 and mi.s_hdr_data[i] != null) {
            hdr = &mi.s_hdr_data[i].?;
        } else if (mi.p_hdr_data[i] != null) {
            hdr = &mi.p_hdr_data[i].?;
        } else continue;

        if (std.mem.indexOfScalar(u8, hdr.items, 0) != null) {
            util.err("a NUL byte in '{s}' is not allowed.", .{h});
            mi.input_error = true;
        }

        if (i == SUBJECT) {
            if (!mi.keep_subject) {
                cleanupSubject(mi, hdr);
                cleanupSpace(hdr);
            }
            outputHeaderLines(&mi.output, "Subject", hdr.items);
        } else if (i == 0) {
            cleanupSpace(hdr);
            handleFrom(mi, hdr.items);
            util.bufPrint(&mi.output, "Author: {s}\n", .{cstr(mi.name.items)});
            util.bufPrint(&mi.output, "Email: {s}\n", .{cstr(mi.email.items)});
        } else {
            cleanupSpace(hdr);
            util.bufPrint(&mi.output, "{s}: {s}\n", .{ h, cstr(hdr.items) });
        }
    }
    util.bufByte(&mi.output, '\n');
}

fn openForWrite(path: []const u8) c_int {
    return os.openFile(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_CLOEXEC, 0o666);
}

/// mailinfo(): returns 0 on success, -1 on error. Info is left in mi.output.
pub fn mailinfo(mi: *MailInfo, msg: []const u8, patch: []const u8) i32 {
    const msg_fd = openForWrite(msg);
    if (msg_fd < 0) {
        util.eprint("{s}: {s}\n", .{ msg, os.lastErr() });
        return -1;
    }
    const patch_fd = openForWrite(patch);
    if (patch_fd < 0) {
        util.eprint("{s}: {s}\n", .{ patch, os.lastErr() });
        os.close(msg_fd);
        return -1;
    }

    while (true) {
        const peek = mi.input.getc() orelse {
            os.close(msg_fd);
            os.close(patch_fd);
            util.err("empty patch: '{s}'", .{patch});
            return -1;
        };
        if (!isSpace(peek)) break;
    }
    mi.input.ungetc();

    var line: Buf = .empty;
    while (readOneHeaderLine(&line, &mi.input)) {
        const l = util.dupe(line.items);
        _ = checkHeader(mi, l, &mi.p_hdr_data, true);
    }

    handleBody(mi, &line);
    os.writeAll(msg_fd, mi.log_message.items) catch {};
    os.close(msg_fd);
    os.writeAll(patch_fd, mi.patchfile.items) catch {};
    os.close(patch_fd);

    handleInfo(mi);
    return if (mi.input_error) -1 else 0;
}
