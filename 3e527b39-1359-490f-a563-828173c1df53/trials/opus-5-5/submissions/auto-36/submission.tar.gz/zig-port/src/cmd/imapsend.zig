//! git imap-send (port of imap-send.c, without OpenSSL/curl support)
//!
//! Messages in mbox format are read from stdin and uploaded to an IMAP
//! folder, either through `imap.tunnel` (a shell command whose stdin/stdout
//! speak IMAP) or a plain TCP connection to `imap.host`.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const proc = @import("../proc.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const advice = @import("../advice.zig");
const credential = @import("../credential.zig");
const connect = @import("../connect.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git imap-send [-v] [-q] [--[no-]curl] [--[no-]draft] [(--folder|-f) <folder>] < <mbox>",
    "git imap-send --list",
};

var verbosity: i32 = 0;
var list_folders = false;
var use_curl = false;
var opt_draft = false;
var opt_folder: ?[]const u8 = null;

const RESP_OK = 0;
const RESP_NO = 1;
const RESP_BAD = 2;

const DRV_OK = 0;
const DRV_MSG_BAD = -1;
const DRV_STORE_BAD = -3;

const cap_list = [_][]const u8{
    "LOGINDISABLED", "UIDPLUS",       "LITERAL+",          "NAMESPACE",     "STARTTLS",
    "AUTH=PLAIN",    "AUTH=CRAM-MD5", "AUTH=OAUTHBEARER", "AUTH=XOAUTH2",
};
const Cap = enum(u5) { NOLOGIN = 0, UIDPLUS, LITERALPLUS, NAMESPACE, STARTTLS, AUTH_PLAIN, AUTH_CRAM_MD5, AUTH_OAUTHBEARER, AUTH_XOAUTH2 };

const ServerConf = struct {
    tunnel: ?[]const u8 = null,
    host: ?[]const u8 = null,
    port: i64 = 0,
    folder: ?[]const u8 = null,
    user: ?[]const u8 = null,
    pass: ?[]const u8 = null,
    use_ssl: bool = false,
    ssl_verify: bool = true,
    use_html: bool = false,
    auth_method: ?[]const u8 = null,
};

const ContFn = *const fn (ctx: *Store, prompt: []const u8) bool;

const Cmd = struct {
    tag: i32,
    cmd: []const u8,
    data: ?[]const u8 = null,
    cont: ?ContFn = null,
};

const Store = struct {
    cfg: *ServerConf,
    fd_in: c_int = -1,
    fd_out: c_int = -1,
    tunnel_pid: c_int = -1,
    caps: u32 = 0,
    rcaps: u32 = 0,
    nexttag: i32 = 0,
    buf: [1024]u8 = undefined,
    bytes: usize = 0,
    offset: usize = 0,
    name: []const u8 = "",

    fn cap(self: *const Store, c: Cap) bool {
        return self.caps & (@as(u32, 1) << @intFromEnum(c)) != 0;
    }

    fn sockRead(self: *Store, dst: []u8) isize {
        while (true) {
            const n = std.c.read(self.fd_in, dst.ptr, dst.len);
            if (n < 0 and os.errno() == 4) continue;
            if (n <= 0) {
                if (n == 0) util.eprint("read: unexpected EOF\n", .{}) else util.eprint("read: {s}\n", .{os.lastErr()});
                self.closeFds();
            }
            return n;
        }
    }

    fn sockWrite(self: *Store, data: []const u8) bool {
        if (self.fd_out < 0) return false;
        os.writeAll(self.fd_out, data) catch {
            util.eprint("write: {s}\n", .{os.lastErr()});
            self.closeFds();
            return false;
        };
        return true;
    }

    fn closeFds(self: *Store) void {
        if (self.fd_in >= 0) _ = std.c.close(self.fd_in);
        if (self.fd_out >= 0 and self.fd_out != self.fd_in) _ = std.c.close(self.fd_out);
        self.fd_in = -1;
        self.fd_out = -1;
    }

    /// buffer_gets(): one CRLF-terminated line (without the CRLF)
    fn getLine(self: *Store) ?[]const u8 {
        var start = self.offset;
        while (true) {
            if (self.offset + 1 >= self.bytes) {
                if (start != 0) {
                    const n = self.bytes - start;
                    if (n != 0) std.mem.copyForwards(u8, self.buf[0..n], self.buf[start..self.bytes]);
                    self.offset -= start;
                    self.bytes = n;
                    start = 0;
                }
                if (self.bytes >= self.buf.len) {
                    util.eprint("IMAP error: response line too long\n", .{});
                    return null;
                }
                if (self.fd_in < 0) return null;
                const n = self.sockRead(self.buf[self.bytes..]);
                if (n <= 0) return null;
                self.bytes += @intCast(n);
            }
            if (self.buf[self.offset] == '\r' and self.buf[self.offset + 1] == '\n') {
                const line = self.buf[start..self.offset];
                self.offset += 2;
                if (verbosity > 0 or (list_folders and std.mem.indexOf(u8, line, "* LIST") != null)) {
                    util.stdout.write(line);
                    util.stdout.byte('\n');
                    util.flushStdout();
                }
                return util.dupe(line);
            }
            self.offset += 1;
        }
    }
};

fn imapInfo(comptime f: []const u8, args: anytype) void {
    if (verbosity >= 0) {
        util.stdout.print(f, args);
        util.flushStdout();
    }
}

fn imapWarn(comptime f: []const u8, args: anytype) void {
    if (verbosity > -2) util.eprint(f, args);
}

fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r' or ch == 0x0b or ch == 0x0c;
}

/// next_arg(): `s` is null once exhausted
fn nextArg(s: *?[]const u8) ?[]const u8 {
    var str = s.* orelse return null;
    var i: usize = 0;
    while (i < str.len and isSpace(str[i])) i += 1;
    str = str[i..];
    if (str.len == 0) {
        s.* = null;
        return null;
    }
    var ret: []const u8 = undefined;
    var rest: ?[]const u8 = null;
    if (str[0] == '"') {
        str = str[1..];
        if (std.mem.indexOfScalar(u8, str, '"')) |q| {
            ret = str[0..q];
            rest = str[q + 1 ..];
        } else {
            ret = str;
            rest = null;
        }
    } else {
        var j: usize = 0;
        while (j < str.len and !isSpace(str[j])) j += 1;
        ret = str[0..j];
        rest = if (j < str.len) str[j + 1 ..] else null;
    }
    if (rest) |r| {
        if (r.len == 0) rest = null;
    }
    s.* = rest;
    return ret;
}

fn skipListL(s: []const u8, pos: *usize, level: u32) bool {
    var i = pos.*;
    while (true) {
        while (i < s.len and isSpace(s[i])) i += 1;
        if (level > 0 and i < s.len and s[i] == ')') {
            i += 1;
            break;
        }
        if (i < s.len and s[i] == '(') {
            i += 1;
            if (!skipListL(s, &i, level + 1)) return false;
        } else if (i < s.len and s[i] == '"') {
            i += 1;
            while (true) : (i += 1) {
                if (i >= s.len) return false;
                if (s[i] == '"') break;
            }
            i += 1;
        } else {
            while (i < s.len and !isSpace(s[i])) : (i += 1) {
                if (level > 0 and s[i] == ')') break;
            }
        }
        if (level == 0) break;
        if (i >= s.len) return false;
    }
    pos.* = i;
    return true;
}

fn skipList(s: *?[]const u8) void {
    const str = s.* orelse return;
    var i: usize = 0;
    if (skipListL(str, &i, 0)) s.* = if (i < str.len) str[i..] else null;
}

fn parseCapability(ctx: *Store, line: ?[]const u8) void {
    var cmd = line;
    ctx.caps = 0x80000000;
    while (nextArg(&cmd)) |arg| {
        for (cap_list, 0..) |cname, i| {
            if (util.eql(cname, arg)) ctx.caps |= @as(u32, 1) << @intCast(i);
        }
    }
    ctx.rcaps = ctx.caps;
}

fn parsePosInt(s: []const u8) ?i64 {
    const v = std.fmt.parseInt(i64, s, 10) catch return null;
    if (v == 0) return null;
    return v;
}

fn parseResponseCode(ctx: *Store, line: ?[]const u8, appenduid: bool) u8 {
    const s0 = line orelse return RESP_OK;
    if (s0.len == 0 or s0[0] != '[') return RESP_OK;
    const s1 = s0[1..];
    const close = std.mem.indexOfScalar(u8, s1, ']') orelse {
        util.eprint("IMAP error: malformed response code\n", .{});
        return RESP_BAD;
    };
    var s: ?[]const u8 = s1[0..close];
    var p = s1[close + 1 ..];
    const arg = nextArg(&s) orelse {
        util.eprint("IMAP error: empty response code\n", .{});
        return RESP_BAD;
    };
    if (util.eql(arg, "UIDVALIDITY")) {
        const a = nextArg(&s);
        if (a == null or parsePosInt(a.?) == null) {
            util.eprint("IMAP error: malformed UIDVALIDITY status\n", .{});
            return RESP_BAD;
        }
    } else if (util.eql(arg, "UIDNEXT")) {
        const a = nextArg(&s);
        if (a == null or parsePosInt(a.?) == null) {
            util.eprint("IMAP error: malformed NEXTUID status\n", .{});
            return RESP_BAD;
        }
    } else if (util.eql(arg, "CAPABILITY")) {
        parseCapability(ctx, s);
    } else if (util.eql(arg, "ALERT")) {
        while (p.len > 0 and isSpace(p[0])) p = p[1..];
        util.eprint("*** IMAP ALERT *** {s}\n", .{p});
    } else if (appenduid and util.eql(arg, "APPENDUID")) {
        const a = nextArg(&s);
        const b = nextArg(&s);
        if (a == null or parsePosInt(a.?) == null or b == null or parsePosInt(b.?) == null) {
            util.eprint("IMAP error: malformed APPENDUID status\n", .{});
            return RESP_BAD;
        }
    }
    return RESP_OK;
}

fn displayCmd(cmd: []const u8) []const u8 {
    return if (util.startsWith(cmd, "LOGIN")) "LOGIN <user> <pass>" else cmd;
}

/// issue_imap_cmd() + get_cmd_result() for a single command
fn exec(ctx: *Store, cmd_text: []const u8, data: ?[]const u8, cont: ?ContFn) u8 {
    ctx.nexttag += 1;
    var cmd = Cmd{ .tag = ctx.nexttag, .cmd = cmd_text, .data = data, .cont = cont };
    const literalplus = ctx.cap(.LITERALPLUS);
    const line = if (data) |d|
        util.fmt("{d} {s}{{{d}{s}}}\r\n", .{ cmd.tag, cmd.cmd, d.len, if (literalplus) "+" else "" })
    else
        util.fmt("{d} {s}\r\n", .{ cmd.tag, cmd.cmd });
    if (verbosity > 0) {
        if (!util.startsWith(cmd.cmd, "LOGIN"))
            util.stdout.print(">>> {s}", .{line})
        else
            util.stdout.print(">>> {d} LOGIN <user> <pass>\n", .{cmd.tag});
        util.flushStdout();
    }
    if (!ctx.sockWrite(line)) return RESP_BAD;
    if (cmd.data) |d| {
        if (literalplus) {
            if (!ctx.sockWrite(d) or !ctx.sockWrite("\r\n")) return RESP_BAD;
            cmd.data = null;
        }
    }
    return getCmdResult(ctx, &cmd);
}

fn getCmdResult(ctx: *Store, cmdp: *Cmd) u8 {
    while (true) {
        const full = ctx.getLine() orelse return RESP_BAD;
        var rest: ?[]const u8 = full;
        const arg = nextArg(&rest) orelse {
            util.eprint("IMAP error: empty response\n", .{});
            return RESP_BAD;
        };
        if (arg.len > 0 and arg[0] == '*') {
            const a = nextArg(&rest) orelse {
                util.eprint("IMAP error: unable to parse untagged response\n", .{});
                return RESP_BAD;
            };
            if (util.eql(a, "NAMESPACE")) {
                skipList(&rest);
                skipList(&rest);
                skipList(&rest);
            } else if (util.eql(a, "OK") or util.eql(a, "BAD") or util.eql(a, "NO") or util.eql(a, "BYE")) {
                const r = parseResponseCode(ctx, rest, false);
                if (r != RESP_OK) return r;
            } else if (util.eql(a, "CAPABILITY")) {
                parseCapability(ctx, rest);
            } else if (nextArg(&rest) != null) {
                // unhandled response-data with at least two words
            } else {
                util.eprint("IMAP error: unable to parse untagged response\n", .{});
                return RESP_BAD;
            }
        } else if (arg.len > 0 and arg[0] == '+') {
            if (cmdp.data) |d| {
                if (!ctx.sockWrite(d)) return RESP_BAD;
                cmdp.data = null;
            } else if (cmdp.cont) |f| {
                if (!f(ctx, rest orelse "")) return RESP_BAD;
            } else {
                util.eprint("IMAP error: unexpected command continuation request\n", .{});
                return RESP_BAD;
            }
            if (!ctx.sockWrite("\r\n")) return RESP_BAD;
        } else {
            const tag = std.fmt.parseInt(i32, arg, 10) catch {
                util.eprint("IMAP error: malformed tag {s}\n", .{arg});
                return RESP_BAD;
            };
            if (tag != cmdp.tag) {
                util.eprint("IMAP error: unexpected tag {s}\n", .{arg});
                return RESP_BAD;
            }
            const st = nextArg(&rest) orelse "";
            var resp: u8 = RESP_OK;
            if (!util.eql(st, "OK")) {
                resp = if (util.eql(st, "NO")) RESP_NO else RESP_BAD;
                util.eprint("IMAP command '{s}' returned response ({s}) - {s}\n", .{ displayCmd(cmdp.cmd), st, rest orelse "" });
            }
            const r2 = parseResponseCode(ctx, rest, util.startsWith(cmdp.cmd, "APPEND"));
            if (r2 > resp) resp = r2;
            return resp;
        }
    }
}

fn execM(ctx: *Store, cmd: []const u8, data: ?[]const u8) i32 {
    return switch (exec(ctx, cmd, data, null)) {
        RESP_BAD => DRV_STORE_BAD,
        RESP_NO => DRV_MSG_BAD,
        else => DRV_OK,
    };
}

fn b64(raw: []const u8) []u8 {
    const enc = std.base64.standard.Encoder;
    const out = gpa.alloc(u8, enc.calcSize(raw.len)) catch util.oom();
    _ = enc.encode(out, raw);
    return out;
}

fn authPlain(ctx: *Store, _: []const u8) bool {
    const raw = util.fmt("\x00{s}\x00{s}", .{ ctx.cfg.user orelse "", ctx.cfg.pass orelse "" });
    if (!ctx.sockWrite(b64(raw))) {
        util.err("IMAP error: sending PLAIN response failed", .{});
        return false;
    }
    return true;
}

fn authCramMd5(ctx: *Store, prompt: []const u8) bool {
    const dec = std.base64.standard.Decoder;
    const n = dec.calcSizeForSlice(prompt) catch util.die("invalid challenge {s}", .{prompt});
    const challenge = gpa.alloc(u8, n) catch util.oom();
    dec.decode(challenge, prompt) catch util.die("invalid challenge {s}", .{prompt});
    const Hmac = std.crypto.auth.hmac.HmacMd5;
    var mac: [Hmac.mac_length]u8 = undefined;
    Hmac.create(&mac, challenge, ctx.cfg.pass orelse "");
    const hex = std.fmt.bytesToHex(mac, .lower);
    const response = util.fmt("{s} {s}", .{ ctx.cfg.user orelse "", &hex });
    if (!ctx.sockWrite(b64(response))) {
        util.err("IMAP error: sending CRAM-MD5 response failed", .{});
        return false;
    }
    return true;
}

fn authOauthbearer(ctx: *Store, _: []const u8) bool {
    const raw = util.fmt("n,a={s},\x01auth=Bearer {s}\x01\x01", .{ ctx.cfg.user orelse "", ctx.cfg.pass orelse "" });
    if (!ctx.sockWrite(b64(raw))) {
        util.err("IMAP error: sending OAUTHBEARER response failed", .{});
        return false;
    }
    return true;
}

fn authXoauth2(ctx: *Store, _: []const u8) bool {
    const raw = util.fmt("user={s}\x01auth=Bearer {s}\x01\x01", .{ ctx.cfg.user orelse "", ctx.cfg.pass orelse "" });
    if (!ctx.sockWrite(b64(raw))) {
        util.err("IMAP error: sending XOAUTH2 response failed", .{});
        return false;
    }
    return true;
}

fn tryAuthMethod(ctx: *Store, method: []const u8, c: Cap, f: ContFn) bool {
    if (!ctx.cap(c)) {
        util.eprint("You specified {s} as authentication method, but {s} doesn't support it.\n", .{ method, ctx.cfg.host orelse "" });
        return false;
    }
    if (exec(ctx, util.fmt("AUTHENTICATE {s}", .{method}), null, f) != RESP_OK) {
        util.eprint("IMAP error: AUTHENTICATE {s} failed\n", .{method});
        return false;
    }
    return true;
}

fn serverFillCredential(srvc: *ServerConf, cred: *credential.Credential) void {
    if (srvc.user != null and srvc.pass != null) return;
    cred.protocol = if (srvc.use_ssl) "imaps" else "imap";
    cred.host = util.fmt("{s}:{d}", .{ srvc.host orelse "", srvc.port });
    cred.username = srvc.user;
    cred.password = srvc.pass;
    credential.fill(cred, true);
    if (srvc.user == null) srvc.user = cred.username;
    if (srvc.pass == null) srvc.pass = cred.password;
}

fn closeStore(ctx: *Store) void {
    if (ctx.fd_in >= 0) {
        _ = exec(ctx, "LOGOUT", null, null);
        ctx.closeFds();
    }
    if (ctx.tunnel_pid > 0) {
        _ = proc.wait(ctx.tunnel_pid);
        ctx.tunnel_pid = -1;
    }
}

fn openStore(srvc: *ServerConf, folder: []const u8) ?*Store {
    const ctx = gpa.create(Store) catch util.oom();
    ctx.* = .{ .cfg = srvc };
    var cred: credential.Credential = .{};

    if (srvc.tunnel) |t| {
        imapInfo("Starting tunnel '{s}'... ", .{t});
        const ch = proc.spawn(&.{ "/bin/sh", "-c", t }, .{ .pipe_in = true, .pipe_out = true });
        ctx.tunnel_pid = ch.pid;
        ctx.fd_in = ch.out;
        ctx.fd_out = ch.in;
        imapInfo("OK\n", .{});
    } else {
        const host = srvc.host orelse "";
        imapInfo("Resolving {s}... ", .{host});
        imapInfo("OK\n", .{});
        imapInfo("Connecting to {s}:{d}... ", .{ host, srvc.port });
        const hp = if (std.mem.indexOfScalar(u8, host, ':') != null and !util.startsWith(host, "["))
            util.fmt("[{s}]:{d}", .{ host, srvc.port })
        else
            util.fmt("{s}:{d}", .{ host, srvc.port });
        const s = connect.tcpConnect(hp, 0, false);
        if (s < 0) {
            util.ewrite("error: unable to connect to server\n");
            return bail(ctx, &cred);
        }
        ctx.fd_in = s;
        ctx.fd_out = std.c.dup(s);
        if (srvc.use_ssl) {
            util.err("SSL requested but SSL support not compiled in", .{});
            ctx.closeFds();
            return bail(ctx, &cred);
        }
        imapInfo("OK\n", .{});
    }

    // greeting
    const greet = ctx.getLine() orelse {
        util.eprint("IMAP error: no greeting response\n", .{});
        return bail(ctx, &cred);
    };
    var rsp: ?[]const u8 = greet;
    const a0 = nextArg(&rsp);
    var arg: ?[]const u8 = null;
    if (a0 != null and a0.?.len > 0 and a0.?[0] == '*') arg = nextArg(&rsp);
    if (arg == null) {
        util.eprint("IMAP error: invalid greeting response\n", .{});
        return bail(ctx, &cred);
    }
    var preauth = false;
    if (util.eql(arg.?, "PREAUTH")) {
        preauth = true;
    } else if (!util.eql(arg.?, "OK")) {
        util.eprint("IMAP error: unknown greeting response\n", .{});
        return bail(ctx, &cred);
    }
    _ = parseResponseCode(ctx, rsp, false);
    if (ctx.caps == 0 and exec(ctx, "CAPABILITY", null, null) != RESP_OK) return bail(ctx, &cred);

    if (!preauth) {
        imapInfo("Logging in...\n", .{});
        serverFillCredential(srvc, &cred);
        if (srvc.auth_method) |m| {
            const ok = if (util.eql(m, "PLAIN"))
                tryAuthMethod(ctx, "PLAIN", .AUTH_PLAIN, authPlain)
            else if (util.eql(m, "CRAM-MD5"))
                tryAuthMethod(ctx, "CRAM-MD5", .AUTH_CRAM_MD5, authCramMd5)
            else if (util.eql(m, "OAUTHBEARER"))
                tryAuthMethod(ctx, "OAUTHBEARER", .AUTH_OAUTHBEARER, authOauthbearer)
            else if (util.eql(m, "XOAUTH2"))
                tryAuthMethod(ctx, "XOAUTH2", .AUTH_XOAUTH2, authXoauth2)
            else blk: {
                util.eprint("unknown authentication mechanism: {s}\n", .{m});
                break :blk false;
            };
            if (!ok) return bail(ctx, &cred);
        } else {
            if (ctx.cap(.NOLOGIN)) {
                util.eprint("skipping account {s}@{s}, server forbids LOGIN\n", .{ srvc.user orelse "(null)", srvc.host orelse "(null)" });
                return bail(ctx, &cred);
            }
            imapWarn("*** IMAP Warning *** Password is being sent in the clear\n", .{});
            if (exec(ctx, util.fmt("LOGIN \"{s}\" \"{s}\"", .{ srvc.user orelse "", srvc.pass orelse "" }), null, null) != RESP_OK) {
                util.eprint("IMAP error: LOGIN failed\n", .{});
                return bail(ctx, &cred);
            }
        }
    }

    if (cred.username != null) credential.approve(&cred);

    ctx.name = folder;
    switch (exec(ctx, util.fmt("EXAMINE \"{s}\"", .{folder}), null, null)) {
        RESP_OK => {},
        RESP_BAD => {
            util.eprint("IMAP error: could not check mailbox\n", .{});
            closeStore(ctx);
            return null;
        },
        else => {
            if (exec(ctx, util.fmt("CREATE \"{s}\"", .{folder}), null, null) == RESP_OK) {
                imapInfo("Created missing mailbox\n", .{});
            } else {
                util.eprint("IMAP error: could not create missing mailbox\n", .{});
                closeStore(ctx);
                return null;
            }
        },
    }
    return ctx;
}

fn bail(ctx: *Store, cred: *credential.Credential) ?*Store {
    if (cred.username != null) credential.reject(cred);
    closeStore(ctx);
    return null;
}

fn lfToCrlf(msg: []const u8) []u8 {
    var b: util.Buf = .empty;
    var lastc: u8 = 0;
    for (msg) |ch| {
        if (ch == '\n' and lastc != '\r') util.bufByte(&b, '\r');
        util.bufByte(&b, ch);
        lastc = ch;
    }
    return b.items;
}

fn storeMsg(ctx: *Store, msg: []const u8) i32 {
    const data = lfToCrlf(msg);
    const box = ctx.name;
    const ret = execM(ctx, util.fmt("APPEND \"{s}\" {s}", .{ box, if (opt_draft) "(\\Draft) " else "" }), data);
    ctx.caps = ctx.rcaps;
    return ret;
}

fn wrapInHtml(msg: []const u8) []const u8 {
    const body_at = std.mem.indexOf(u8, msg, "\n\n") orelse return msg;
    const body = msg[body_at + 2 ..];
    var b: util.Buf = .empty;
    util.bufAppend(&b, msg[0 .. body_at + 1]);
    util.bufAppend(&b, "Content-Type: text/html;\n");
    util.bufByte(&b, '\n');
    util.bufAppend(&b, "<pre>\n");
    for (body) |ch| {
        switch (ch) {
            '"' => util.bufAppend(&b, "&quot;"),
            '<' => util.bufAppend(&b, "&lt;"),
            '>' => util.bufAppend(&b, "&gt;"),
            '&' => util.bufAppend(&b, "&amp;"),
            0 => break,
            else => util.bufByte(&b, ch),
        }
    }
    util.bufAppend(&b, "</pre>\n");
    return b.items;
}

fn strstrFrom(s: []const u8, from: usize, needle: []const u8) ?usize {
    if (from > s.len) return null;
    return std.mem.indexOfPos(u8, s, from, needle);
}

fn countMessages(all: []const u8) i32 {
    var count: i32 = 0;
    var p: usize = 0;
    while (true) {
        if (util.startsWith(all[p..], "From ")) {
            if (util.startsWith(all[p..], "From git-send-email")) {
                p = strstrFrom(all, p + 5, "\nFrom: ") orelse break;
                p += 7;
                p = strstrFrom(all, p, "\nTo: ") orelse break;
                p += 5;
                count += 1;
            } else {
                p = strstrFrom(all, p + 5, "\nFrom: ") orelse break;
                p = strstrFrom(all, p + 7, "\nDate: ") orelse break;
                p = strstrFrom(all, p + 7, "\nSubject: ") orelse break;
                p += 10;
                count += 1;
            }
        }
        p = strstrFrom(all, p + 5, "\nFrom ") orelse break;
        p += 1;
    }
    return count;
}

fn splitMsg(all: []const u8, ofs: *usize) ?[]const u8 {
    if (ofs.* >= all.len) return null;
    var data = all[ofs.*..];
    if (data.len < 5 or !util.startsWith(data, "From ")) return null;
    if (std.mem.indexOfScalar(u8, data, '\n')) |nl| {
        ofs.* += nl + 1;
        data = data[nl + 1 ..];
    }
    var len = data.len;
    if (std.mem.indexOf(u8, data, "\nFrom ")) |p| len = p + 1;
    ofs.* += len;
    return data[0..len];
}

fn readConfig(srv: *ServerConf) void {
    const cfg = &repo_mod.cfg;
    for (cfg.entries.items) |e| {
        const k = e.key;
        if (!util.startsWith(k, "imap.")) continue;
        const v = e.value;
        if (util.eql(k, "imap.sslverify")) {
            srv.ssl_verify = if (v) |s| (config.parseBool(s) orelse util.die("bad boolean config value '{s}' for '{s}'", .{ s, k })) else true;
        } else if (util.eql(k, "imap.preformattedhtml")) {
            srv.use_html = if (v) |s| (config.parseBool(s) orelse util.die("bad boolean config value '{s}' for '{s}'", .{ s, k })) else true;
        } else if (util.eql(k, "imap.folder") or util.eql(k, "imap.user") or util.eql(k, "imap.pass") or
            util.eql(k, "imap.tunnel") or util.eql(k, "imap.authmethod") or util.eql(k, "imap.host"))
        {
            const s = v orelse {
                util.err("missing value for '{s}'", .{k});
                util.die("bad config variable '{s}'", .{k});
            };
            if (util.eql(k, "imap.folder")) srv.folder = s else if (util.eql(k, "imap.user")) srv.user = s else if (util.eql(k, "imap.pass")) srv.pass = s else if (util.eql(k, "imap.tunnel")) srv.tunnel = s else if (util.eql(k, "imap.authmethod")) srv.auth_method = s else {
                var h = s;
                if (util.skipPrefix(h, "imap:")) |r| {
                    h = r;
                } else if (util.skipPrefix(h, "imaps:")) |r| {
                    h = r;
                    srv.use_ssl = true;
                }
                if (util.skipPrefix(h, "//")) |r| h = r;
                srv.host = h;
            }
        } else if (util.eql(k, "imap.port")) {
            srv.port = cfg.getInt(k) orelse 0;
        }
    }
    // last value wins for getInt; re-read port with proper semantics
    if (cfg.get("imap.port") != null) srv.port = cfg.getInt("imap.port") orelse 0;
}

fn appendMsgs(server: *ServerConf, all: []const u8, total: i32) u8 {
    const folder = server.folder.?;
    const ctx = openStore(server, folder) orelse {
        util.eprint("failed to open store\n", .{});
        return 1;
    };
    ctx.name = folder;
    util.eprint("Sending {d} message{s} to {s} folder...\n", .{ total, if (total != 1) "s" else "", folder });
    var ofs: usize = 0;
    var n: i32 = 0;
    while (true) {
        const percent: u32 = @intCast(@divTrunc(n * 100, total));
        util.eprint("{d:>4}% ({d}/{d}) done\r", .{ percent, n, total });
        var msg = splitMsg(all, &ofs) orelse break;
        if (server.use_html) msg = wrapInHtml(msg);
        if (storeMsg(ctx, msg) != DRV_OK) break;
        n += 1;
    }
    util.eprint("\n", .{});
    closeStore(ctx);
    return 0;
}

fn listFolders(server: *ServerConf) u8 {
    const ctx = openStore(server, "INBOX") orelse {
        util.eprint("failed to connect to IMAP server\n", .{});
        return 1;
    };
    util.eprint("Fetching the list of available folders...\n", .{});
    if (exec(ctx, "LIST \"\" \"*\"", null, null) != RESP_OK) {
        util.eprint("failed to list folders\n", .{});
        closeStore(ctx);
        return 1;
    }
    closeStore(ctx);
    return 0;
}

pub fn cmdImapSend(args: []const []const u8) u8 {
    proc.ignoreSigpipe();
    var server = ServerConf{};
    readConfig(&server);

    const options = [_]po.Opt{
        po.verbose(&verbosity),
        po.quiet(&verbosity),
        po.boolean(0, "curl", &use_curl, "use libcurl to communicate with the IMAP server"),
        po.boolean(0, "draft", &opt_draft, "mark uploaded messages with the IMAP \\Draft flag"),
        po.string('f', "folder", &opt_folder, "folder", "specify the IMAP folder"),
        po.boolean(0, "list", &list_folders, "list all folders on the IMAP server"),
    };
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (opt_folder) |f| server.folder = f;
    if (rest.len > 0) po.usageWithOptions(&usage, &options);

    if (use_curl) {
        util.warn("--curl not supported in this build", .{});
        use_curl = false;
    }

    if (server.port == 0) server.port = if (server.use_ssl) 993 else 143;

    if (server.host == null) {
        if (server.tunnel == null) {
            util.err("no IMAP host specified", .{});
            advice.advise("set the IMAP host with 'git config imap.host <host>'.\n" ++
                "(e.g., 'git config imap.host imaps://imap.example.com')");
            return 1;
        }
        server.host = "tunnel";
    }

    if (list_folders) return listFolders(&server);

    if (server.folder == null) {
        util.err("no IMAP folder specified", .{});
        advice.advise("set the target folder with 'git config imap.folder <folder>'.\n" ++
            "(e.g., 'git config imap.folder Drafts')");
        return 1;
    }

    const all = os.readAllFd(0) catch {
        util.err("could not read from stdin: {s}", .{os.lastErr()});
        return 1;
    };
    if (all.len == 0) {
        util.eprint("nothing to send\n", .{});
        return 1;
    }
    const total = countMessages(all);
    if (total == 0) {
        util.eprint("no messages found to send\n", .{});
        return 1;
    }
    return appendMsgs(&server, all, total);
}
