//! git notes (port of builtin/notes.c and notes-merge.c).

const std = @import("std");
const util = @import("../util.zig");
const hash = @import("../hash.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const objects = @import("../objects.zig");
const notes = @import("../notes.zig");
const editor = @import("../editor.zig");
const wtstatus = @import("../wtstatus.zig");
const cn = @import("../commitnode.zig");
const commitreach = @import("../commitreach.zig");
const merge_ort = @import("../merge_ort.zig");
const pretty = @import("../pretty.zig");
const Oid = hash.Oid;
const gpa = util.gpa;
const NotesTree = notes.NotesTree;

const notes_usage = [_][]const u8{
    "git notes [--ref <notes-ref>] [list [<object>]]",
    "git notes [--ref <notes-ref>] add [-f] [--allow-empty] [--[no-]separator|--separator=<paragraph-break>] [--[no-]stripspace] [-m <msg> | -F <file> | (-c | -C) <object>] [<object>] [-e]",
    "git notes [--ref <notes-ref>] copy [-f] <from-object> <to-object>",
    "git notes [--ref <notes-ref>] append [--allow-empty] [--[no-]separator|--separator=<paragraph-break>] [--[no-]stripspace] [-m <msg> | -F <file> | (-c | -C) <object>] [<object>] [-e]",
    "git notes [--ref <notes-ref>] edit [--allow-empty] [<object>]",
    "git notes [--ref <notes-ref>] show [<object>]",
    "git notes [--ref <notes-ref>] merge [-v | -q] [-s <strategy>] <notes-ref>",
    "git notes merge --commit [-v | -q]",
    "git notes merge --abort [-v | -q]",
    "git notes [--ref <notes-ref>] remove [<object>...]",
    "git notes [--ref <notes-ref>] prune [-n] [-v]",
    "git notes [--ref <notes-ref>] get-ref",
};
const list_usage = [_][]const u8{"git notes [list [<object>]]"};
const add_usage = [_][]const u8{"git notes add [<options>] [<object>]"};
const copy_usage = [_][]const u8{ "git notes copy [<options>] <from-object> <to-object>", "git notes copy --stdin [<from-object> <to-object>]..." };
const append_usage = [_][]const u8{"git notes append [<options>] [<object>]"};
const edit_usage = [_][]const u8{"git notes edit [<object>]"};
const show_usage = [_][]const u8{"git notes show [<object>]"};
const merge_usage = [_][]const u8{ "git notes merge [<options>] <notes-ref>", "git notes merge --commit [<options>]", "git notes merge --abort [<options>]" };
const remove_usage = [_][]const u8{"git notes remove [<object>]"};
const prune_usage = [_][]const u8{"git notes prune [<options>]"};
const get_ref_usage = [_][]const u8{"git notes get-ref"};

const note_template = "Write/edit the notes for the following object:";

// ---------------- note data (option callbacks use globals) ----------------

const Msg = struct { buf: []const u8, stripspace: bool };

var separator: ?[]const u8 = "\n";
var d_msgs: std.ArrayList(Msg) = .empty;
var d_use_editor: bool = false;
var d_stripspace: i32 = -1;
var d_buf: util.Buf = .empty;
var d_edit_path: ?[]const u8 = null;

fn resetNoteData() void {
    d_msgs = .empty;
    d_use_editor = false;
    d_stripspace = -1;
    d_buf = .empty;
    d_edit_path = null;
}

fn cbMsg(arg: ?[]const u8, _: bool) void {
    d_msgs.append(gpa, .{ .buf = util.dupe(arg.?), .stripspace = true }) catch util.oom();
}

fn cbFile(arg: ?[]const u8, _: bool) void {
    const a = arg.?;
    var data: []const u8 = undefined;
    if (util.eql(a, "-")) {
        data = os.readAllFd(0) catch util.dieErrno("cannot read '{s}'", .{a});
    } else {
        const path = repo_mod.prefixPath(a) orelse a;
        data = os.readFile(path) orelse util.dieErrno("could not open or read '{s}'", .{a});
    }
    d_msgs.append(gpa, .{ .buf = data, .stripspace = true }) catch util.oom();
}

fn cbReuse(arg: ?[]const u8, _: bool) void {
    const a = arg.?;
    const oid = revparse.getOid(a) orelse util.die("failed to resolve '{s}' as a valid ref.", .{a});
    const obj = repo_mod.repo().odb().read(oid) orelse util.die("failed to read object '{s}'.", .{a});
    if (obj.typ != .blob) util.die("cannot read note data from non-blob object '{s}'.", .{a});
    d_msgs.append(gpa, .{ .buf = obj.data, .stripspace = false }) catch util.oom();
}

fn cbReedit(arg: ?[]const u8, unset: bool) void {
    d_use_editor = true;
    cbReuse(arg, unset);
}

fn cbSeparator(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        separator = null;
    } else separator = arg orelse "\n";
}

fn appendSeparator(b: *util.Buf) void {
    const sep = separator orelse return;
    if (sep.len > 0 and sep[sep.len - 1] == '\n') {
        util.bufAppend(b, sep);
    } else {
        util.bufAppend(b, sep);
        util.bufByte(b, '\n');
    }
}

fn concatMessages() void {
    for (d_msgs.items) |m| {
        if (d_buf.items.len > 0) appendSeparator(&d_buf);
        util.bufAppend(&d_buf, m.buf);
        if ((d_stripspace == -1 and m.stripspace) or d_stripspace == 1) {
            const s = util.stripspace(d_buf.items, null);
            d_buf = .empty;
            util.bufAppend(&d_buf, s);
        }
    }
}

fn selfExe() []const u8 {
    return os.readLink("/proc/self/exe") orelse "git";
}

fn writeCommentedObject(b: *util.Buf, object: Oid) void {
    const hx = hash.hex(object);
    const res = os.run(&.{ selfExe(), "show", "--stat", "--no-notes", &hx }, .{ .capture_stdout = true, .no_stdin = true });
    if (res.signaled or res.status == 255)
        util.die("unable to start 'show' for object '{s}'", .{hx});
    wtstatus.addCommentedLines(b, wtstatus.commentStr(), res.stdout);
    if (res.status != 0) util.die("failed to finish 'show' for object '{s}'", .{hx});
}

fn prepareNoteData(object: Oid, old_note: ?Oid) void {
    if (!(d_use_editor or d_msgs.items.len == 0)) return;
    const path = repo_mod.repo().gitPath("NOTES_EDITMSG");
    d_edit_path = path;
    var b: util.Buf = .empty;
    if (d_msgs.items.len > 0) {
        util.bufAppend(&b, d_buf.items);
    } else if (old_note) |on| {
        if (repo_mod.repo().odb().read(on)) |obj| util.bufAppend(&b, obj.data);
    }
    const cs = wtstatus.commentStr();
    util.bufByte(&b, '\n');
    wtstatus.addCommentedLines(&b, cs, "\n");
    wtstatus.addCommentedLines(&b, cs, note_template);
    wtstatus.addCommentedLines(&b, cs, "\n");
    writeCommentedObject(&b, object);
    os.writeFile(path, b.items, 0o600) catch util.dieErrno("could not open '{s}'", .{path});
    d_buf = .empty;
    if (editor.launch(path, &.{}))
        util.die("please supply the note contents using either -m or -F option", .{});
    const content = os.readFile(path) orelse "";
    util.bufAppend(&d_buf, content);
    if (d_stripspace != 0) {
        const s = util.stripspace(d_buf.items, cs);
        d_buf = .empty;
        util.bufAppend(&d_buf, s);
    }
}

fn freeNoteData() void {
    if (d_edit_path) |p| {
        if (!os.unlink(p)) {
            if (os.exists(p)) util.warn("unable to unlink '{s}': {s}", .{ p, os.lastErr() });
        }
    }
    d_edit_path = null;
}

fn writeNoteData() Oid {
    return repo_mod.repo().odb().write(.blob, d_buf.items);
}

// ---------------- helpers ----------------

fn initNotesCheck(subcommand: []const u8, flags: u32) *NotesTree {
    const t = &notes.default_tree;
    notes.initNotes(t, null, null, flags);
    const ref = if (flags & notes.INIT_WRITABLE != 0) t.update_ref.? else t.ref;
    if (!util.startsWith(ref, "refs/notes/"))
        util.die("refusing to {s} notes in {s} (outside of refs/notes/)", .{ subcommand, ref });
    return t;
}

fn resolveOrDie(name: []const u8) Oid {
    return revparse.getOid(name) orelse util.die("failed to resolve '{s}' as a valid ref.", .{name});
}

fn tooMany(usage: []const []const u8, opts: []const po.Opt) noreturn {
    util.err("too many arguments", .{});
    po.usageWithOptions(usage, opts);
}

// ---------------- subcommands ----------------

fn listEach(_: *anyopaque, object: Oid, note: Oid, _: []const u8) i32 {
    util.outf("{s} {s}\n", .{ hash.hex(note), hash.hex(object) });
    return 0;
}

fn cmdList(args: []const []const u8) u8 {
    const opts = [_]po.Opt{};
    var rest: []const []const u8 = &.{};
    if (args.len > 0) rest = po.parse(args[1..], &opts, &list_usage, .{});
    if (rest.len > 1) tooMany(&list_usage, &opts);
    const t = initNotesCheck("list", 0);
    if (rest.len > 0) {
        const object = resolveOrDie(rest[0]);
        if (notes.getNote(t, object)) |n| {
            util.outf("{s}\n", .{hash.hex(n)});
            return 0;
        }
        util.err("no note found for object {s}.", .{hash.hex(object)});
        return 1;
    }
    var dummy: u8 = 0;
    _ = notes.forEachNote(t, 0, listEach, &dummy);
    return 0;
}

fn msgOptions(allow_empty: *bool, force: ?*bool) [10]po.Opt {
    return .{
        .{ .short = 'm', .long = "message", .kind = .callback, .cb = cbMsg, .argh = "message", .help = "note contents as a string", .noneg = true },
        .{ .short = 'F', .long = "file", .kind = .callback, .cb = cbFile, .argh = "file", .help = "note contents in a file", .noneg = true },
        .{ .short = 'c', .long = "reedit-message", .kind = .callback, .cb = cbReedit, .argh = "object", .help = "reuse and edit specified note object", .noneg = true },
        po.boolean('e', "edit", &d_use_editor, "edit note message in editor"),
        .{ .short = 'C', .long = "reuse-message", .kind = .callback, .cb = cbReuse, .argh = "object", .help = "reuse specified note object", .noneg = true },
        po.boolean(0, "allow-empty", allow_empty, "allow storing empty note"),
        if (force) |f| .{ .short = 'f', .long = "force", .kind = .boolean, .b = f, .help = "replace existing notes", .nocomplete = true } else .{ .kind = .group, .hidden = true },
        .{ .long = "separator", .kind = .callback, .cb = cbSeparator, .optarg = true, .argh = "paragraph-break", .help = "insert <paragraph-break> between paragraphs" },
        .{ .long = "stripspace", .kind = .set_int, .i = &d_stripspace, .val = 1, .help = "remove unnecessary whitespace" },
        .{ .kind = .group, .hidden = true },
    };
}

fn cmdAdd(args: []const []const u8) u8 {
    var force = false;
    var allow_empty = false;
    resetNoteData();
    const opts0 = msgOptions(&allow_empty, &force);
    // the add option order: -m -F -c -e -C --allow-empty -f --separator --stripspace
    const opts = opts0[0..9];
    const rest = po.parse(args[1..], opts, &add_usage, .{});
    if (rest.len > 1) tooMany(&add_usage, opts);
    if (d_msgs.items.len > 0) concatMessages();
    const object_ref = if (rest.len > 0) rest[0] else "HEAD";
    const object = resolveOrDie(object_ref);
    const t = initNotesCheck("add", notes.INIT_WRITABLE);
    const note = notes.getNote(t, object);
    if (note != null) {
        if (!force) {
            if (d_msgs.items.len > 0) {
                util.err("Cannot add notes. Found existing notes for object {s}. Use '-f' to overwrite existing notes", .{hash.hex(object)});
                return 1;
            }
            // redirect to "edit"
            var eargs: std.ArrayList([]const u8) = .empty;
            eargs.append(gpa, "edit") catch util.oom();
            eargs.appendSlice(gpa, rest) catch util.oom();
            notes.default_tree = .{};
            return cmdAppendEdit(eargs.items);
        }
        util.eprint("Overwriting existing notes for object {s}\n", .{hash.hex(object)});
    }
    prepareNoteData(object, note);
    if (d_buf.items.len > 0 or allow_empty) {
        const new_note = writeNoteData();
        _ = notes.addNote(t, object, new_note, notes.combineOverwrite);
        notes.commitNotes(t, "Notes added by 'git notes add'");
    } else {
        util.eprint("Removing note for object {s}\n", .{hash.hex(object)});
        _ = notes.removeNote(t, object);
        notes.commitNotes(t, "Notes removed by 'git notes add'");
    }
    freeNoteData();
    return 0;
}

fn cmdAppendEdit(args: []const []const u8) u8 {
    var allow_empty = false;
    resetNoteData();
    const edit = util.eql(args[0], "edit");
    const usage: []const []const u8 = if (edit) &edit_usage else &append_usage;
    const all = msgOptions(&allow_empty, null);
    // append/edit option order: -m -F -c -C -e --allow-empty --separator --stripspace
    const opts = [_]po.Opt{ all[0], all[1], all[2], all[4], all[3], all[5], all[7], all[8] };
    const rest = po.parse(args[1..], &opts, usage, .{});
    if (rest.len > 1) tooMany(usage, &opts);
    if (d_msgs.items.len > 0) {
        concatMessages();
        if (edit) util.eprint("The -m/-F/-c/-C options have been deprecated for the 'edit' subcommand.\nPlease use 'git notes add -f -m/-F/-c/-C' instead.\n", .{});
    }
    const object_ref = if (rest.len > 0) rest[0] else "HEAD";
    const object = resolveOrDie(object_ref);
    const t = initNotesCheck(args[0], notes.INIT_WRITABLE);
    const note = notes.getNote(t, object);
    prepareNoteData(object, if (edit) note else null);
    if (note != null and !edit) {
        const prev = repo_mod.repo().odb().read(note.?) orelse util.die("unable to read {s}", .{hash.hex(note.?)});
        var b: util.Buf = .empty;
        util.bufAppend(&b, prev.data);
        if (d_buf.items.len > 0 and prev.data.len > 0) appendSeparator(&b);
        util.bufAppend(&b, d_buf.items);
        d_buf = b;
    }
    var logmsg: []const u8 = undefined;
    if (d_buf.items.len > 0 or allow_empty) {
        const new_note = writeNoteData();
        _ = notes.addNote(t, object, new_note, notes.combineOverwrite);
        logmsg = util.fmt("Notes added by 'git notes {s}'", .{args[0]});
    } else {
        util.eprint("Removing note for object {s}\n", .{hash.hex(object)});
        _ = notes.removeNote(t, object);
        logmsg = util.fmt("Notes removed by 'git notes {s}'", .{args[0]});
    }
    notes.commitNotes(t, logmsg);
    freeNoteData();
    return 0;
}

// --- copy ---

pub const RewriteCfg = struct {
    trees: []*NotesTree,
    combine: notes.CombineFn,
};

pub fn initCopyNotesForRewrite(cmd: []const u8) ?RewriteCfg {
    var enabled = true;
    var combine: ?notes.CombineFn = notes.combineConcatenate;
    var list: std.ArrayList([]const u8) = .empty;
    const mode_env = os.getenv("GIT_NOTES_REWRITE_MODE");
    const refs_env = os.getenv("GIT_NOTES_REWRITE_REF");
    if (mode_env) |m| {
        combine = notes.parseCombineFn(m);
        if (combine == null) util.err("Bad GIT_NOTES_REWRITE_MODE value: '{s}'", .{m});
    }
    if (refs_env) |r| notes.addRefsFromColonSep(&list, r);
    const cfg = &repo_mod.cfg;
    if (cfg.getBool(util.concat(&.{ "notes.rewrite.", cmd }))) |b| enabled = b;
    if (mode_env == null) {
        if (cfg.get("notes.rewritemode")) |v| {
            combine = notes.parseCombineFn(v);
            if (combine == null) util.err("Bad notes.rewriteMode value: '{s}'", .{v});
        }
    }
    if (refs_env == null) {
        for (cfg.getAll("notes.rewriteref")) |v| {
            if (util.startsWith(v, "refs/notes/"))
                notes.addRefsByGlob(&list, v)
            else
                util.warn("Refusing to rewrite notes in {s} (outside of refs/notes/)", .{v});
        }
    }
    if (!enabled or list.items.len == 0) return null;
    return .{ .trees = notes.loadNotesTrees(list.items, notes.INIT_WRITABLE, notes.combineConcatenate), .combine = combine orelse notes.combineConcatenate };
}

fn notesCopyFromStdin(force: bool, rewrite_cmd: ?[]const u8) u8 {
    var rc: ?RewriteCfg = null;
    var t: *NotesTree = undefined;
    const msg = "Notes added by 'git notes copy'";
    if (rewrite_cmd) |rcmd| {
        rc = initCopyNotesForRewrite(rcmd) orelse return 0;
    } else {
        t = &notes.default_tree;
        notes.initNotes(t, null, null, notes.INIT_WRITABLE);
    }
    var ret: u8 = 0;
    const input = os.readAllFd(0) catch "";
    var it = std.mem.splitScalar(u8, input, '\n');
    while (it.next()) |line0| {
        if (it.index == null and line0.len == 0) break;
        var split: std.ArrayList([]const u8) = .empty;
        var sit = std.mem.splitScalar(u8, line0, ' ');
        while (sit.next()) |f| split.append(gpa, std.mem.trim(u8, f, " \t\r\n")) catch util.oom();
        if (split.items.len < 2) util.die("malformed input line: '{s}'.", .{line0});
        const from = revparse.getOid(split.items[0]) orelse util.die("failed to resolve '{s}' as a valid ref.", .{split.items[0]});
        const to = revparse.getOid(split.items[1]) orelse util.die("failed to resolve '{s}' as a valid ref.", .{split.items[1]});
        var e: i32 = 0;
        if (rc) |c| {
            for (c.trees) |tr| {
                if (notes.copyNote(tr, from, to, true, c.combine) != 0) e = 1;
            }
        } else e = notes.copyNote(t, from, to, force, notes.combineOverwrite);
        if (e != 0) {
            util.err("failed to copy notes from '{s}' to '{s}'", .{ split.items[0], split.items[1] });
            ret = 1;
        }
    }
    if (rc) |c| {
        for (c.trees) |tr| notes.commitNotes(tr, msg);
    } else notes.commitNotes(t, msg);
    return ret;
}

fn cmdCopy(args: []const []const u8) u8 {
    var force = false;
    var from_stdin = false;
    var rewrite_cmd: ?[]const u8 = null;
    const opts = [_]po.Opt{
        .{ .short = 'f', .long = "force", .kind = .boolean, .b = &force, .help = "replace existing notes", .nocomplete = true },
        po.boolean(0, "stdin", &from_stdin, "read objects from stdin"),
        po.string(0, "for-rewrite", &rewrite_cmd, "command", "load rewriting config for <command> (implies --stdin)"),
    };
    const rest = po.parse(args[1..], &opts, &copy_usage, .{});
    if (from_stdin or rewrite_cmd != null) {
        if (rest.len > 0) tooMany(&copy_usage, &opts);
        return notesCopyFromStdin(force, rewrite_cmd);
    }
    if (rest.len < 1) {
        util.err("too few arguments", .{});
        po.usageWithOptions(&copy_usage, &opts);
    }
    if (rest.len > 2) tooMany(&copy_usage, &opts);
    const from_obj = resolveOrDie(rest[0]);
    const object_ref = if (rest.len > 1) rest[1] else "HEAD";
    const object = resolveOrDie(object_ref);
    const t = initNotesCheck("copy", notes.INIT_WRITABLE);
    if (notes.getNote(t, object) != null) {
        if (!force) {
            util.err("Cannot copy notes. Found existing notes for object {s}. Use '-f' to overwrite existing notes", .{hash.hex(object)});
            return 1;
        }
        util.eprint("Overwriting existing notes for object {s}\n", .{hash.hex(object)});
    }
    const from_note = notes.getNote(t, from_obj) orelse {
        util.err("missing notes on source object {s}. Cannot copy.", .{hash.hex(from_obj)});
        return 1;
    };
    _ = notes.addNote(t, object, from_note, notes.combineOverwrite);
    notes.commitNotes(t, "Notes added by 'git notes copy'");
    return 0;
}

fn cmdShowNote(args: []const []const u8) u8 {
    const opts = [_]po.Opt{};
    const rest = po.parse(args[1..], &opts, &show_usage, .{});
    if (rest.len > 1) tooMany(&show_usage, &opts);
    const object_ref = if (rest.len > 0) rest[0] else "HEAD";
    const object = resolveOrDie(object_ref);
    const t = initNotesCheck("show", 0);
    const note = notes.getNote(t, object) orelse {
        util.err("no note found for object {s}.", .{hash.hex(object)});
        return 1;
    };
    const hx = hash.hex(note);
    const log = @import("log.zig");
    return log.cmdShow(&.{ "show", util.dupe(&hx) });
}

// --- remove / prune / get-ref ---

fn removeOne(t: *NotesTree, name: []const u8, ignore_missing: bool) u8 {
    const oid = revparse.getOid(name) orelse {
        util.err("Failed to resolve '{s}' as a valid ref.", .{name});
        return 1;
    };
    const status = notes.removeNote(t, oid);
    if (status) {
        util.eprint("Object {s} has no note\n", .{name});
    } else util.eprint("Removing note for object {s}\n", .{name});
    return if (ignore_missing) 0 else @intFromBool(status);
}

fn cmdRemove(args: []const []const u8) u8 {
    var flag: i32 = 0;
    var from_stdin = false;
    const opts = [_]po.Opt{
        po.bit(0, "ignore-missing", &flag, 1, "attempt to remove non-existent note is not an error"),
        po.boolean(0, "stdin", &from_stdin, "read object names from the standard input"),
    };
    const rest = po.parse(args[1..], &opts, &remove_usage, .{});
    const t = initNotesCheck("remove", notes.INIT_WRITABLE);
    const ign = flag & 1 != 0;
    var retval: u8 = 0;
    if (rest.len == 0 and !from_stdin) {
        retval = removeOne(t, "HEAD", ign);
    } else {
        for (rest) |a| retval |= removeOne(t, a, ign);
    }
    if (from_stdin) {
        const input = os.readAllFd(0) catch "";
        var it = std.mem.splitScalar(u8, input, '\n');
        while (it.next()) |line| {
            if (it.index == null and line.len == 0) break;
            retval |= removeOne(t, std.mem.trimEnd(u8, line, " \t\r\n\x0b\x0c"), ign);
        }
    }
    if (retval == 0) notes.commitNotes(t, "Notes removed by 'git notes remove'");
    return retval;
}

fn cmdPrune(args: []const []const u8) u8 {
    var show_only = false;
    var verbose = false;
    const opts = [_]po.Opt{
        po.boolean('n', "dry-run", &show_only, "do not remove, show only"),
        po.boolean('v', "verbose", &verbose, "report pruned notes"),
    };
    const rest = po.parse(args[1..], &opts, &prune_usage, .{});
    if (rest.len > 0) tooMany(&prune_usage, &opts);
    const t = initNotesCheck("prune", notes.INIT_WRITABLE);
    var flags: u32 = 0;
    if (verbose) flags |= notes.PRUNE_VERBOSE;
    if (show_only) flags |= notes.PRUNE_VERBOSE | notes.PRUNE_DRYRUN;
    notes.pruneNotes(t, flags);
    if (!show_only) notes.commitNotes(t, "Notes removed by 'git notes prune'");
    return 0;
}

fn cmdGetRef(args: []const []const u8) u8 {
    const opts = [_]po.Opt{};
    const rest = po.parse(args[1..], &opts, &get_ref_usage, .{});
    if (rest.len > 0) tooMany(&get_ref_usage, &opts);
    util.outf("{s}\n", .{notes.defaultNotesRef()});
    return 0;
}

// ---------------- merge (notes-merge.c) ----------------

const Strategy = enum { manual, ours, theirs, union_, cat_sort_uniq };

fn parseStrategy(v: []const u8) ?Strategy {
    if (util.eql(v, "manual")) return .manual;
    if (util.eql(v, "ours")) return .ours;
    if (util.eql(v, "theirs")) return .theirs;
    if (util.eql(v, "union")) return .union_;
    if (util.eql(v, "cat_sort_uniq")) return .cat_sort_uniq;
    return null;
}

const MergeOpts = struct {
    local_ref: []const u8 = "",
    remote_ref: []const u8 = "",
    strategy: Strategy = .manual,
    verbosity: i32 = 2,
    commit_msg: util.Buf = .empty,
    has_worktree: bool = false,
};

const uninitialized: Oid = @splat(0xff);

const Pair = struct { obj: Oid, base: Oid, local: Oid, remote: Oid };

fn pathToOid(path: []const u8) ?Oid {
    var hx: [40]u8 = undefined;
    var i: usize = 0;
    for (path) |ch| {
        if (ch == '/') continue;
        if (i >= 40) return null;
        hx[i] = ch;
        i += 1;
    }
    if (i != 40) return null;
    return hash.fromHex(&hx);
}

fn notesMap(tree: Oid) hash.OidMap(Oid) {
    var m: hash.OidMap(Oid) = .empty;
    var flat: std.ArrayList(objects.FlatEntry) = .empty;
    objects.flattenTree(tree, "", &flat);
    for (flat.items) |e| {
        const o = pathToOid(e.path) orelse continue;
        m.put(gpa, o, e.oid) catch util.oom();
    }
    return m;
}

fn lessOid(_: void, a: Pair, b: Pair) bool {
    return hash.order(a.obj, b.obj) == .lt;
}

fn checkNotesMergeWorktree(o: *MergeOpts) void {
    const wt = repo_mod.repo().gitPath("NOTES_MERGE_WORKTREE");
    if (!o.has_worktree) {
        if (os.exists(wt)) {
            const ents = os.listDir(wt) orelse &.{};
            if (ents.len > 0) {
                const star = repo_mod.repo().gitPath("NOTES_MERGE_*");
                if (@import("../advice.zig").enabled("resolveConflict"))
                    util.die("You have not concluded your previous notes merge ({s} exists).\nPlease, use 'git notes merge --commit' or 'git notes merge --abort' to commit/abort the previous merge before you start a new notes merge.", .{star})
                else
                    util.die("You have not concluded your notes merge ({s} exists).", .{star});
            }
        }
        if (!os.mkdirAll(wt)) util.dieErrno("unable to create directory {s}", .{wt});
        o.has_worktree = true;
    } else if (!os.exists(wt)) util.die("missing '{s}'. This should not happen", .{wt});
}

fn writeBufToWorktree(obj: Oid, data: []const u8) void {
    const hx = hash.hex(obj);
    const path = repo_mod.repo().gitPath(util.concat(&.{ "NOTES_MERGE_WORKTREE/", &hx }));
    if (os.exists(path)) util.die("could not open '{s}': File exists", .{path});
    os.writeFile(path, data, 0o666) catch util.dieErrno("could not open '{s}'", .{path});
}

fn writeNoteToWorktree(obj: Oid, note: Oid) void {
    const o = repo_mod.repo().odb().read(note) orelse util.die("cannot read note {s} for object {s}", .{ hash.hex(note), hash.hex(obj) });
    if (o.typ != .blob) util.die("blob expected in note {s} for object {s}", .{ hash.hex(note), hash.hex(obj) });
    writeBufToWorktree(obj, o.data);
}

fn readBlobOrEmpty(oid: Oid) []const u8 {
    if (hash.isZero(oid)) return "";
    const o = repo_mod.repo().odb().read(oid) orelse return "";
    return o.data;
}

fn mergeOneManual(o: *MergeOpts, p: *const Pair, t: *NotesTree) i32 {
    const lref = if (o.local_ref.len > 0) o.local_ref else "local version";
    const rref = if (o.remote_ref.len > 0) o.remote_ref else "remote version";
    if (!o.has_worktree) util.bufAppend(&o.commit_msg, "\n\nConflicts:\n");
    util.bufPrint(&o.commit_msg, "\t{s}\n", .{hash.hex(p.obj)});
    if (o.verbosity >= 2) util.outf("Auto-merging notes for {s}\n", .{hash.hex(p.obj)});
    checkNotesMergeWorktree(o);
    if (hash.isZero(p.local)) {
        if (o.verbosity >= 1) util.outf("CONFLICT (delete/modify): Notes for object {s} deleted in {s} and modified in {s}. Version from {s} left in tree.\n", .{ hash.hex(p.obj), lref, rref, rref });
        writeNoteToWorktree(p.obj, p.remote);
    } else if (hash.isZero(p.remote)) {
        if (o.verbosity >= 1) util.outf("CONFLICT (delete/modify): Notes for object {s} deleted in {s} and modified in {s}. Version from {s} left in tree.\n", .{ hash.hex(p.obj), rref, lref, lref });
        writeNoteToWorktree(p.obj, p.local);
    } else {
        const reason = if (hash.isZero(p.base)) "add/add" else "content";
        if (o.verbosity >= 1) util.outf("CONFLICT ({s}): Merge conflict in notes for object {s}\n", .{ reason, hash.hex(p.obj) });
        const hx = hash.hex(p.obj);
        const lo = merge_ort.LlOpts{};
        const res = merge_ort.llMerge(&hx, readBlobOrEmpty(p.base), null, readBlobOrEmpty(p.local), o.local_ref, readBlobOrEmpty(p.remote), o.remote_ref, &lo);
        if (res.status == .binary_conflict) util.warn("Cannot merge binary files: {s} ({s} vs. {s})", .{ hx, o.local_ref, o.remote_ref });
        if (res.status == .err or res.result == null) util.die("Failed to execute internal merge", .{});
        writeBufToWorktree(p.obj, res.result.?);
    }
    _ = notes.removeNote(t, p.obj);
    return 1;
}

fn mergeOneChange(o: *MergeOpts, p: *const Pair, t: *NotesTree) i32 {
    switch (o.strategy) {
        .manual => return mergeOneManual(o, p, t),
        .ours => {
            if (o.verbosity >= 2) util.outf("Using local notes for {s}\n", .{hash.hex(p.obj)});
            return 0;
        },
        .theirs => {
            if (o.verbosity >= 2) util.outf("Using remote notes for {s}\n", .{hash.hex(p.obj)});
            _ = notes.addNote(t, p.obj, p.remote, notes.combineOverwrite);
            return 0;
        },
        .union_ => {
            if (o.verbosity >= 2) util.outf("Concatenating local and remote notes for {s}\n", .{hash.hex(p.obj)});
            if (notes.addNote(t, p.obj, p.remote, notes.combineConcatenate) != 0) util.die("failed to concatenate notes (combine_notes_concatenate)", .{});
            return 0;
        },
        .cat_sort_uniq => {
            if (o.verbosity >= 2) util.outf("Concatenating unique lines in local and remote notes for {s}\n", .{hash.hex(p.obj)});
            if (notes.addNote(t, p.obj, p.remote, notes.combineCatSortUniq) != 0) util.die("failed to concatenate notes (combine_notes_cat_sort_uniq)", .{});
            return 0;
        },
    }
}

fn mergeFromDiffs(o: *MergeOpts, base: Oid, local: Oid, remote: Oid, t: *NotesTree) i32 {
    var bm = notesMap(base);
    var lm = notesMap(local);
    var rm = notesMap(remote);
    var changes: std.ArrayList(Pair) = .empty;
    // remote changes: union of keys in base and remote
    var keys: hash.OidSet = .empty;
    var it1 = bm.iterator();
    while (it1.next()) |e| keys.put(gpa, e.key_ptr.*, {}) catch util.oom();
    var it2 = rm.iterator();
    while (it2.next()) |e| keys.put(gpa, e.key_ptr.*, {}) catch util.oom();
    var kit = keys.keyIterator();
    while (kit.next()) |k| {
        const b = bm.get(k.*) orelse hash.zero;
        const r = rm.get(k.*) orelse hash.zero;
        if (hash.eql(b, r)) continue;
        const l0 = lm.get(k.*) orelse hash.zero;
        const l = if (hash.eql(b, l0)) uninitialized else l0;
        changes.append(gpa, .{ .obj = k.*, .base = b, .local = l, .remote = r }) catch util.oom();
    }
    std.mem.sort(Pair, changes.items, {}, lessOid);
    var conflicts: i32 = 0;
    for (changes.items) |*p| {
        if (hash.eql(p.base, p.remote)) {} else if (hash.eql(p.local, p.remote)) {} else if (hash.eql(p.local, uninitialized) or hash.eql(p.local, p.base)) {
            _ = notes.addNote(t, p.obj, p.remote, notes.combineOverwrite);
        } else {
            conflicts += mergeOneChange(o, p, t);
        }
    }
    if (o.verbosity >= 4) {
        if (t.dirty)
            util.outf("Merge result: {d} unmerged notes and a dirty notes tree\n", .{conflicts})
        else
            util.outf("Merge result: {d} unmerged notes and a clean notes tree\n", .{conflicts});
    }
    return if (conflicts > 0) -1 else 1;
}

fn short7(o: Oid) []const u8 {
    const hx = hash.hex(o);
    return util.dupe(hx[0..7]);
}

fn notesMerge(o: *MergeOpts, local_tree: *NotesTree, result: *Oid) i32 {
    result.* = hash.zero;
    var local: ?*cn.Commit = null;
    var remote: ?*cn.Commit = null;
    const local_oid: Oid = refs.readOid(o.local_ref) orelse blk: {
        if (refs.checkRefnameFormat(o.local_ref, 0)) break :blk hash.zero;
        util.die("Failed to resolve local notes ref '{s}'", .{o.local_ref});
    };
    if (!hash.isZero(local_oid)) {
        local = cn.lookupCommitReference(local_oid) orelse util.die("Could not parse local commit {s} ({s})", .{ hash.hex(local_oid), o.local_ref });
    }
    var remote_oid: Oid = hash.zero;
    if (revparse.getOid(o.remote_ref)) |r| {
        remote_oid = r;
        remote = cn.lookupCommitReference(r) orelse util.die("Could not parse remote commit {s} ({s})", .{ hash.hex(r), o.remote_ref });
    } else if (!refs.checkRefnameFormat(o.remote_ref, 0)) {
        util.die("Failed to resolve remote notes ref '{s}'", .{o.remote_ref});
    }
    if (local == null and remote == null)
        util.die("Cannot merge empty notes ref ({s}) into empty notes ref ({s})", .{ o.remote_ref, o.local_ref });
    if (local == null) {
        result.* = remote_oid;
        return 0;
    }
    if (remote == null) {
        result.* = local_oid;
        return 0;
    }
    const lc = local.?;
    const rc = remote.?;
    const bases = commitreach.getMergeBases(lc, rc);
    var base_oid: Oid = hash.zero;
    var base_tree: Oid = undefined;
    if (bases == null) {
        base_tree = hash.fromHex("4b825dc642cb6eb9a060e54bf8d69288fbee4904").?;
        if (o.verbosity >= 4) util.out("No merge base found; doing history-less merge\n");
    } else {
        const b = bases.?.item;
        _ = cn.parse(b);
        base_oid = b.obj.oid;
        base_tree = b.tree;
        if (bases.?.next == null) {
            if (o.verbosity >= 4) util.outf("One merge base found ({s})\n", .{short7(base_oid)});
        } else if (o.verbosity >= 3) util.outf("Multiple merge bases found. Using the first ({s})\n", .{short7(base_oid)});
    }
    if (o.verbosity >= 4) util.outf("Merging remote commit {s} into local commit {s} with merge-base {s}\n", .{ short7(rc.obj.oid), short7(lc.obj.oid), short7(base_oid) });
    if (hash.eql(rc.obj.oid, base_oid)) {
        if (o.verbosity >= 2) util.out("Already up to date.\n");
        result.* = lc.obj.oid;
        return 0;
    }
    if (hash.eql(lc.obj.oid, base_oid)) {
        if (o.verbosity >= 2) util.out("Fast-forward\n");
        result.* = rc.obj.oid;
        return 0;
    }
    _ = cn.parse(lc);
    _ = cn.parse(rc);
    const res = mergeFromDiffs(o, base_tree, lc.tree, rc.tree, local_tree);
    if (res != 0) {
        result.* = notes.createNotesCommit(local_tree, &.{ lc.obj.oid, rc.obj.oid }, o.commit_msg.items);
    }
    return res;
}

fn mergeAbort(o: *MergeOpts) u8 {
    var ret: u8 = 0;
    refs.deleteRef("NOTES_MERGE_PARTIAL", null, 0, null) catch {
        util.err("failed to delete ref NOTES_MERGE_PARTIAL", .{});
        ret += 1;
    };
    refs.deleteRef("NOTES_MERGE_REF", null, refs.F_NO_DEREF, null) catch {
        util.err("failed to delete ref NOTES_MERGE_REF", .{});
        ret += 1;
    };
    const wt = repo_mod.repo().gitPath("NOTES_MERGE_WORKTREE");
    if (o.verbosity >= 3) util.outf("Removing notes merge worktree at {s}/*\n", .{wt});
    if (os.listDir(wt)) |ents| {
        for (ents) |e| os.removeTree(util.joinPath(wt, e.name));
    }
    return ret;
}

fn mergeCommit(o: *MergeOpts) u8 {
    const poid = revparse.getOid("NOTES_MERGE_PARTIAL") orelse util.die("failed to read ref NOTES_MERGE_PARTIAL", .{});
    const partial = cn.lookupCommitReference(poid) orelse util.die("could not find commit from NOTES_MERGE_PARTIAL.", .{});
    if (!cn.parse(partial)) util.die("could not parse commit from NOTES_MERGE_PARTIAL.", .{});
    const parent_oid: Oid = if (partial.parents) |pl| pl.item.obj.oid else hash.zero;
    var t: NotesTree = .{};
    notes.initNotes(&t, "NOTES_MERGE_PARTIAL", notes.combineOverwrite, 0);
    const r = refs.resolve("NOTES_MERGE_REF") orelse util.die("failed to resolve NOTES_MERGE_REF", .{});
    o.local_ref = r.name;

    // notes_merge_commit
    const wt = repo_mod.repo().gitPath("NOTES_MERGE_WORKTREE");
    if (o.verbosity >= 3) util.outf("Committing notes in notes merge worktree at {s}\n", .{wt});
    const buffer = partial.buffer;
    const mi = std.mem.indexOf(u8, buffer, "\n\n");
    if (mi == null or mi.? + 2 >= buffer.len) util.die("partial notes commit has empty message", .{});
    const msg = buffer[mi.? + 2 ..];
    const ents = os.listDir(wt) orelse util.dieErrno("could not open {s}", .{wt});
    for (ents) |e| {
        const obj_oid = hash.fromHex(e.name) orelse {
            if (o.verbosity >= 3) util.outf("Skipping non-SHA1 entry '{s}/{s}'\n", .{ wt, e.name });
            continue;
        };
        const path = util.joinPath(wt, e.name);
        const data = os.readFile(path) orelse util.dieErrno("Failed to stat '{s}'", .{path});
        const blob = repo_mod.repo().odb().write(.blob, data);
        if (notes.addNote(&t, obj_oid, blob, null) != 0) util.die("Failed to add resolved note '{s}' to notes tree", .{path});
        if (o.verbosity >= 4) util.outf("Added resolved note for object {s}: {s}\n", .{ hash.hex(obj_oid), hash.hex(blob) });
    }
    var parents: std.ArrayList(Oid) = .empty;
    var pl = partial.parents;
    while (pl) |p| : (pl = p.next) parents.append(gpa, p.item.obj.oid) catch util.oom();
    const result = notes.createNotesCommit(&t, parents.items, msg);
    if (o.verbosity >= 4) util.outf("Finalized notes merge commit: {s}\n", .{hash.hex(result)});

    var sb: util.Buf = .empty;
    const ctx = pretty.Context{};
    pretty.formatCommitMessage(partial, "%s", &sb, &ctx);
    const subj = std.mem.trim(u8, sb.items, " \t\n\r");
    const reflog = util.concat(&.{ "notes: ", subj });
    refs.updateOrDie(reflog, o.local_ref, result, if (hash.isZero(parent_oid)) null else parent_oid, 0);
    return mergeAbort(o);
}

var verbosity_v: i32 = 0;
fn cbVerbose(_: ?[]const u8, unset: bool) void {
    if (unset) {
        verbosity_v = 0;
    } else if (verbosity_v < 0) verbosity_v = 1 else verbosity_v += 1;
}
fn cbQuiet(_: ?[]const u8, unset: bool) void {
    if (unset) {
        verbosity_v = 0;
    } else if (verbosity_v > 0) verbosity_v = 0 else verbosity_v -= 1;
}

fn cmdMerge(args: []const []const u8) u8 {
    var do_commit: i32 = 0;
    var do_abort: i32 = 0;
    var strategy: ?[]const u8 = null;
    verbosity_v = 0;
    const opts = [_]po.Opt{
        po.group("General options"),
        .{ .short = 'v', .long = "verbose", .kind = .callback, .cb = cbVerbose, .noarg = true, .help = "be more verbose" },
        .{ .short = 'q', .long = "quiet", .kind = .callback, .cb = cbQuiet, .noarg = true, .help = "be more quiet" },
        po.group("Merge options"),
        po.string('s', "strategy", &strategy, "strategy", "resolve notes conflicts using the given strategy (manual/ours/theirs/union/cat_sort_uniq)"),
        po.group("Committing unmerged notes"),
        .{ .long = "commit", .kind = .set_int, .i = &do_commit, .val = 1, .noneg = true, .help = "finalize notes merge by committing unmerged notes" },
        po.group("Aborting notes merge resolution"),
        .{ .long = "abort", .kind = .set_int, .i = &do_abort, .val = 1, .noneg = true, .help = "abort notes merge" },
    };
    const rest = po.parse(args[1..], &opts, &merge_usage, .{});
    var do_merge: i32 = 0;
    if (strategy != null or do_commit + do_abort == 0) do_merge = 1;
    if (do_merge + do_commit + do_abort != 1) {
        util.err("cannot mix --commit, --abort or -s/--strategy", .{});
        po.usageWithOptions(&merge_usage, &opts);
    }
    if (do_merge != 0 and rest.len != 1) {
        util.err("must specify a notes ref to merge", .{});
        po.usageWithOptions(&merge_usage, &opts);
    } else if (do_merge == 0 and rest.len > 0) tooMany(&merge_usage, &opts);

    var o = MergeOpts{ .verbosity = verbosity_v + 2 };
    if (do_abort != 0) return mergeAbort(&o);
    if (do_commit != 0) return mergeCommit(&o);

    const notes_ref = notes.defaultNotesRef();
    o.local_ref = notes_ref;
    const remote_ref = notes.expandLooseNotesRef(rest[0]);
    o.remote_ref = remote_ref;
    const t = initNotesCheck("merge", notes.INIT_WRITABLE);
    if (strategy) |s| {
        o.strategy = parseStrategy(s) orelse {
            util.err("unknown -s/--strategy: {s}", .{s});
            po.usageWithOptions(&merge_usage, &opts);
        };
    } else {
        const short_ref = util.skipPrefix(o.local_ref, "refs/notes/") orelse
            util.die("BUG: local ref {s} is outside of refs/notes/", .{o.local_ref});
        const key = util.concat(&.{ "notes.", short_ref, ".mergestrategy" });
        if (configStrategy(key)) |s| {
            o.strategy = s;
        } else if (configStrategy("notes.mergestrategy")) |s| o.strategy = s;
    }
    const msg = util.fmt("notes: Merged notes from {s} into {s}", .{ remote_ref, notes_ref });
    util.bufAppend(&o.commit_msg, msg[7..]);
    var result_oid: Oid = hash.zero;
    const result = notesMerge(&o, t, &result_oid);
    if (result >= 0) {
        refs.updateOrDie(msg, notes_ref, result_oid, null, 0);
    } else {
        refs.updateOrDie(msg, "NOTES_MERGE_PARTIAL", result_oid, null, 0);
        if (refs.readSymbolic("NOTES_MERGE_REF")) |cur| {
            if (util.eql(cur, notes_ref))
                util.die("a notes merge into {s} is already in-progress at {s}", .{ notes_ref, repo_mod.repo().work_tree orelse repo_mod.repo().git_dir });
        }
        refs.writeSymref("NOTES_MERGE_REF", notes_ref, null) catch
            util.die("failed to store link to current notes ref ({s})", .{notes_ref});
        util.eprint("Automatic notes merge failed. Fix conflicts in {s} and commit the result with 'git notes merge --commit', or abort the merge with 'git notes merge --abort'.\n", .{repo_mod.repo().gitPath("NOTES_MERGE_WORKTREE")});
    }
    return if (result < 0) 1 else 0;
}

fn configStrategy(key: []const u8) ?Strategy {
    const v = repo_mod.cfg.get(key) orelse return null;
    return parseStrategy(v) orelse util.die("unknown notes merge strategy {s}", .{v});
}

// ---------------- entry ----------------

pub fn cmdNotes(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").notes);
    var override_ref: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.string(0, "ref", &override_ref, "notes-ref", "use notes from <notes-ref>"),
    };
    const rest = po.parse(args[1..], &opts, &notes_usage, .{ .stop_at_non_option = true });
    const Sub = struct { n: []const u8, f: *const fn ([]const []const u8) u8 };
    const subs = [_]Sub{
        .{ .n = "list", .f = cmdList },
        .{ .n = "add", .f = cmdAdd },
        .{ .n = "copy", .f = cmdCopy },
        .{ .n = "append", .f = cmdAppendEdit },
        .{ .n = "edit", .f = cmdAppendEdit },
        .{ .n = "show", .f = cmdShowNote },
        .{ .n = "merge", .f = cmdMerge },
        .{ .n = "remove", .f = cmdRemove },
        .{ .n = "prune", .f = cmdPrune },
        .{ .n = "get-ref", .f = cmdGetRef },
    };
    var f: ?*const fn ([]const []const u8) u8 = null;
    if (rest.len > 0) {
        for (subs) |s| {
            if (util.eql(s.n, rest[0])) f = s.f;
        }
        if (f == null) {
            util.err("unknown subcommand: `{s}'", .{rest[0]});
            po.usageWithOptions(&notes_usage, &opts);
        }
    }
    if (override_ref) |r| os.setEnv("GIT_NOTES_REF", notes.expandNotesRef(r));
    if (f) |func| return if (func(rest) != 0) 1 else 0;
    return if (cmdList(&.{}) != 0) 1 else 0;
}
