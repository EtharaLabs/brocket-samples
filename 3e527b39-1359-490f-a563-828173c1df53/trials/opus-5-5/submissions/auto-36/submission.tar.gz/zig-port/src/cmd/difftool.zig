//! git difftool (port of builtin/difftool.c) and the hidden
//! difftool--helper (port of git-difftool--helper.sh).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const odb = @import("../odb.zig");
const index_mod = @import("../index.zig");
const entry_mod = @import("../entry.zig");
const convert = @import("../convert.zig");
const proc = @import("../proc.zig");
const lib = @import("../mergetool_lib.zig");
const gpa = util.gpa;
const Buf = util.Buf;

extern "c" fn mkdtemp(template: [*:0]u8) ?[*:0]u8;

const usage = [_][]const u8{"git difftool [<options>] [<commit> [<commit>]] [--] [<path>...]"};

fn envNonEmpty(name: []const u8) ?[]const u8 {
    const v = os.getenv(name) orelse return null;
    return if (v.len == 0) null else v;
}

// ---------------------------------------------------------------------------
// difftool--helper

fn shouldPrompt() bool {
    const prompt_merge = lib.cfgBool("mergetool.prompt") orelse true;
    const prompt = lib.cfgBool("difftool.prompt") orelse prompt_merge;
    if (prompt) return envNonEmpty("GIT_DIFFTOOL_NO_PROMPT") == null;
    return envNonEmpty("GIT_DIFFTOOL_PROMPT") != null;
}

fn launchMergeTool(tool: []const u8, extcmd: ?[]const u8, merged: []const u8, local: []const u8, remote: []const u8, positional: []const []const u8) u8 {
    if (shouldPrompt()) {
        util.outf("\nViewing ({s}/{s}): '{s}'\n", .{ os.getenv("GIT_DIFF_PATH_COUNTER") orelse @as([]const u8, ""), os.getenv("GIT_DIFF_PATH_TOTAL") orelse @as([]const u8, ""), merged });
        util.outf("Launch '{s}' [Y/n]? ", .{extcmd orelse tool});
        const ans = lib.readLine() orelse return 1;
        if (util.eql(ans, "n")) return 0;
    }
    const v = lib.Vars{ .merged = merged, .local = local, .remote = remote, .base = merged };
    if (extcmd) |e| return lib.runExtCmd(e, v, positional);
    if (!lib.setupTool(tool, false)) os.exit(1);
    return lib.runMergeTool(tool, v, null);
}

pub fn cmdDifftoolHelper(args: []const []const u8) u8 {
    // The helper is a script in git: keep the inherited GIT_PREFIX and cwd.
    const saved_prefix: ?[]const u8 = if (os.getenv("GIT_PREFIX")) |p| util.dupe(p) else null;
    repo_mod.setup(true);
    if (saved_prefix) |p| os.setEnv("GIT_PREFIX", p) else os.unsetEnv("GIT_PREFIX");
    if (repo_mod.original_cwd.len > 0) _ = os.chdir(repo_mod.original_cwd);
    lib.mode = .diff;
    if (envNonEmpty("GIT_MERGETOOL_GUI")) |g| lib.gui = util.eql(g, "true");
    const extcmd = envNonEmpty("GIT_DIFFTOOL_EXTCMD");
    var tool: []const u8 = "";
    if (extcmd == null) {
        if (envNonEmpty("GIT_DIFF_TOOL")) |t| {
            tool = t;
        } else {
            tool = lib.getMergeTool().tool;
        }
    }
    const trust = util.eql(os.getenv("GIT_DIFFTOOL_TRUST_EXIT_CODE") orelse @as([]const u8, ""), "true");
    const a = args[1..];
    if (envNonEmpty("GIT_DIFFTOOL_DIRDIFF") != null) {
        const v = lib.Vars{ .local = if (a.len > 0) a[0] else "", .remote = if (a.len > 1) a[1] else "" };
        if (!lib.setupTool(tool, false)) return 1;
        const status = lib.runMergeTool(tool, v, false);
        if (status >= 126) return status;
        if (trust) return status;
        return 0;
    }
    var i: usize = 0;
    while (a.len - i > 6) : (i += 7) {
        const status = launchMergeTool(tool, extcmd, a[i], a[i + 1], a[i + 4], a[i..]);
        if (status >= 126) return status;
        if (status != 0 and trust) return status;
    }
    return 0;
}

// ---------------------------------------------------------------------------
// dir-diff

const Pair = struct { path: []const u8, left: []const u8 = "", right: []const u8 = "" };

fn addLeftOrRight(map: *std.ArrayList(Pair), path: []const u8, content: []const u8, is_right: bool) void {
    for (map.items) |*p| {
        if (util.eql(p.path, path)) {
            if (is_right) p.right = content else p.left = content;
            return;
        }
    }
    var p = Pair{ .path = path };
    if (is_right) p.right = content else p.left = content;
    map.append(gpa, p) catch util.oom();
}

const WtEntry = struct { name: []const u8, mode: u32, oid: hash.Oid };

fn ensureLeadingDirs(path: []const u8) bool {
    if (!os.mkdirLeading(path)) {
        util.err("could not create leading directories of '{s}'", .{path});
        return false;
    }
    return true;
}

fn writeFileInDirectory(dir: []const u8, path: []const u8, content: []const u8) void {
    const p = util.concat(&.{ dir, path });
    _ = ensureLeadingDirs(p);
    _ = os.unlink(p);
    var c = content;
    if (c.len > 0 and c[c.len - 1] != '\n') c = util.concat(&.{ c, "\n" });
    os.writeFile(p, c, 0o666) catch util.dieErrno("could not open '{s}' for writing", .{p});
}

fn hashContent(name: []const u8, path: []const u8) ?hash.Oid {
    const st = os.lstatPath(path) orelse return null;
    if (st.isLnk()) {
        const t = os.readLink(path) orelse return null;
        return odb.hashObject(.blob, t);
    }
    const d = os.readFile(path) orelse return null;
    return odb.hashObject(.blob, convert.toGit(name, d));
}

/// use_wt_file()
fn useWtFile(workdir: []const u8, name: []const u8, oid: *hash.Oid) bool {
    const p = util.joinPath(workdir, name);
    const st = os.lstatPath(p) orelse return false;
    if (st.isLnk()) return false;
    const d = os.readFile(p) orelse return false;
    const wt = odb.hashObject(.blob, convert.toGit(name, d));
    if (std.mem.eql(u8, &oid.*, &hash.zero)) {
        oid.* = wt;
        return true;
    }
    return std.mem.eql(u8, &oid.*, &wt);
}

fn getSymlink(has_symlinks: bool, oid: hash.Oid, path: []const u8) []const u8 {
    if (std.mem.eql(u8, &oid, &hash.zero)) {
        if (has_symlinks) {
            return os.readLink(path) orelse util.die("could not read symlink {s}", .{path});
        }
        return os.readFile(path) orelse util.die("could not read symlink file {s}", .{path});
    }
    const o = repo_mod.repo().odb().read(oid) orelse util.die("could not read object {s} for symlink {s}", .{ &hash.hex(oid), path });
    return o.data;
}

fn checkoutPath(mode: u32, oid: hash.Oid, path: []const u8, base_dir: []const u8) bool {
    var e = index_mod.Entry{ .mode = mode, .oid = oid, .path = path };
    var st = entry_mod.State{ .base_dir = base_dir, .force = true };
    return entry_mod.checkoutEntry(&e, &st, null);
}

fn parseOctal(s: []const u8, pos: *usize) u32 {
    var v: u32 = 0;
    while (pos.* < s.len and s[pos.*] >= '0' and s[pos.*] <= '7') : (pos.* += 1) v = v * 8 + (s[pos.*] - '0');
    return v;
}

fn copyFile(dst: []const u8, src: []const u8, mode: u32) bool {
    const d = os.readFile(src) orelse return false;
    const m: c_uint = if (mode & 0o111 != 0) 0o777 else 0o666;
    os.writeFile(dst, d, m) catch return false;
    return true;
}

fn runDirDiff(has_symlinks: bool, symlinks: bool, extcmd: ?[]const u8, prefix: []const u8, diff_args: []const []const u8) u8 {
    const r = repo_mod.repo();
    const workdir = r.work_tree orelse ".";
    var tmpdir: []const u8 = os.getenv("TMPDIR") orelse "/tmp";
    if (tmpdir.len == 0 or tmpdir[0] != '/') tmpdir = util.joinPath(os.getcwd(), tmpdir);
    tmpdir = std.mem.trimEnd(u8, tmpdir, "/");
    const tsrc = util.concat(&.{ tmpdir, "/git-difftool.XXXXXX" });
    const tmpl = gpa.allocSentinel(u8, tsrc.len, 0) catch util.oom();
    @memcpy(tmpl, tsrc);
    if (mkdtemp(tmpl.ptr) == null) {
        util.err("could not create '{s}'", .{tmpl});
        return 1;
    }
    const tdir: []const u8 = tmpl;
    const ldir = util.concat(&.{ tdir, "/left/" });
    const rdir = util.concat(&.{ tdir, "/right/" });
    var wtdir: []const u8 = workdir;
    if (wtdir.len == 0 or wtdir[wtdir.len - 1] != '/') wtdir = util.concat(&.{ wtdir, "/" });
    _ = os.mkdir(ldir, 0o700);
    _ = os.mkdir(rdir, 0o700);

    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, diff_args) catch util.oom();
    const res = os.run(argv.items, .{ .capture_stdout = true, .no_stdin = true, .cwd = if (prefix.len > 0) prefix else null });

    var submodules: std.ArrayList(Pair) = .empty;
    var symlinks2: std.ArrayList(Pair) = .empty;
    var wt_dups: std.ArrayList([]const u8) = .empty;
    var wtindex: std.ArrayList(WtEntry) = .empty;
    var fields = std.mem.splitScalar(u8, res.stdout, 0);
    var count: usize = 0;
    while (fields.next()) |info| {
        if (info.len == 0) break;
        if (util.startsWith(info, "::"))
            util.die("combined diff formats ('-c' and '--cc') are not supported in\ndirectory diff mode ('-d' and '--dir-diff').", .{});
        // :<mode1> <mode2> <oid1> <oid2> <status>
        if (info[0] != ':') {
            util.err("expected ':', got '{c}'", .{info[0]});
            break;
        }
        var p: usize = 1;
        const lmode = parseOctal(info, &p);
        p += 1;
        const rmode = parseOctal(info, &p);
        p += 1;
        if (p + 40 > info.len) break;
        const loid = hash.fromHex(info[p .. p + 40]) orelse break;
        p += 41;
        if (p + 40 > info.len) break;
        const roid0 = hash.fromHex(info[p .. p + 40]) orelse break;
        p += 41;
        if (p >= info.len) break;
        const status = info[p];
        const src_path = fields.next() orelse break;
        count += 1;
        var dst_path = src_path;
        if (status == 'C' or status == 'R') dst_path = fields.next() orelse break;
        var roid = roid0;

        if (lmode & os.S_IFMT == os.S_IFGITLINK or rmode & os.S_IFMT == os.S_IFGITLINK) {
            addLeftOrRight(&submodules, src_path, util.fmt("Subproject commit {s}", .{&hash.hex(loid)}), false);
            var rc = util.fmt("Subproject commit {s}", .{&hash.hex(roid)});
            if (std.mem.eql(u8, &loid, &roid)) rc = util.concat(&.{ rc, "-dirty" });
            addLeftOrRight(&submodules, dst_path, rc, true);
            continue;
        }
        if (lmode & os.S_IFMT == os.S_IFLNK) addLeftOrRight(&symlinks2, src_path, getSymlink(has_symlinks, loid, src_path), false);
        if (rmode & os.S_IFMT == os.S_IFLNK) addLeftOrRight(&symlinks2, dst_path, getSymlink(has_symlinks, roid, dst_path), true);

        if (lmode != 0 and status != 'C') {
            if (checkoutPath(lmode, loid, src_path, ldir)) {
                util.err("could not write '{s}'", .{src_path});
                return 1;
            }
        }
        if (rmode != 0 and rmode & os.S_IFMT != os.S_IFLNK) {
            var dup = false;
            for (wt_dups.items) |d| {
                if (util.eql(d, dst_path)) dup = true;
            }
            if (dup) continue;
            wt_dups.append(gpa, dst_path) catch util.oom();
            if (!useWtFile(workdir, dst_path, &roid)) {
                if (checkoutPath(rmode, roid, dst_path, rdir)) {
                    util.err("could not write '{s}'", .{dst_path});
                    return 1;
                }
            } else if (!std.mem.eql(u8, &roid, &hash.zero)) {
                wtindex.append(gpa, .{ .name = dst_path, .mode = rmode, .oid = roid }) catch util.oom();
                const rp = util.concat(&.{ rdir, dst_path });
                if (!ensureLeadingDirs(rp)) {
                    util.err("could not create directory for '{s}'", .{dst_path});
                    return 1;
                }
                const wp = util.concat(&.{ wtdir, dst_path });
                if (symlinks) {
                    if (!os.symlink(wp, rp)) {
                        util.err("could not symlink '{s}' to '{s}': {s}", .{ wp, rp, os.lastErr() });
                        return 1;
                    }
                } else {
                    const mode: u32 = if (os.statPath(wp)) |s| s.mode else 0o644;
                    if (!copyFile(rp, wp, mode)) {
                        util.err("could not copy '{s}' to '{s}'", .{ wp, rp });
                        return 1;
                    }
                }
            }
        }
    }
    if (res.status != 0) {
        util.err("error occurred running diff --raw", .{});
        return 1;
    }
    if (count == 0) return 0;

    for (submodules.items) |e| {
        if (e.left.len > 0) writeFileInDirectory(ldir, e.path, e.left);
        if (e.right.len > 0) writeFileInDirectory(rdir, e.path, e.right);
    }
    for (symlinks2.items) |e| {
        if (e.left.len > 0) writeFileInDirectory(ldir, e.path, e.left);
        if (e.right.len > 0) writeFileInDirectory(rdir, e.path, e.right);
    }

    var ret: u8 = 0;
    if (extcmd) |x| {
        ret = os.run(&.{ x, ldir, rdir }, .{}).status;
    } else {
        os.setEnv("GIT_DIFFTOOL_DIRDIFF", "true");
        ret = os.run(&.{ proc.gitBinary(), "difftool--helper", ldir, rdir }, .{}).status;
    }

    var err = false;
    for (wtindex.items) |e| {
        const rp = util.concat(&.{ rdir, e.name });
        const st = os.lstatPath(rp) orelse continue;
        if ((symlinks and st.isLnk()) or !st.isReg()) continue;
        const tmp_mod = if (hashContent(e.name, rp)) |o| !std.mem.eql(u8, &o, &e.oid) else true;
        if (!tmp_mod) continue;
        const wp = util.concat(&.{ wtdir, e.name });
        const wt_mod = if (hashContent(e.name, wp)) |o| !std.mem.eql(u8, &o, &e.oid) else true;
        if (wt_mod) {
            util.warn("both files modified: '{s}' and '{s}'.", .{ wp, rp });
            util.warn("working tree file has been left.", .{});
            util.warn("", .{});
            err = true;
        } else if (!os.unlink(wp) or !copyFile(wp, rp, st.mode)) {
            util.warn("could not copy '{s}' to '{s}': {s}", .{ rp, wp, os.lastErr() });
        }
    }
    if (err) {
        util.warn("temporary files exist in '{s}'.", .{tdir});
        util.warn("you may want to cleanup or recover these.", .{});
        ret = 1;
    } else {
        os.removeTree(tdir);
        if (ret != 0) util.warn("failed: {d}", .{ret});
    }
    return ret;
}

// ---------------------------------------------------------------------------
// difftool

pub fn cmdDifftool(args: []const []const u8) u8 {
    var use_gui: i32 = -1;
    var dir_diff = false;
    var prompt: i32 = -1;
    var tool_help = false;
    var no_index = false;
    var difftool_cmd: ?[]const u8 = null;
    var extcmd: ?[]const u8 = null;
    const has_symlinks = repo_mod.cfg.getBool("core.symlinks") orelse true;
    var symlinks = has_symlinks;
    var trust = repo_mod.cfg.getBool("difftool.trustexitcode") orelse false;
    const opts = [_]po.Opt{
        .{ .short = 'g', .long = "gui", .kind = .set_int, .i = &use_gui, .val = 1, .help = "use `diff.guitool` instead of `diff.tool`" },
        po.boolean('d', "dir-diff", &dir_diff, "perform a full-directory diff"),
        .{ .short = 'y', .long = "no-prompt", .kind = .set_int, .i = &prompt, .val = 0, .noneg = true, .help = "do not prompt before launching a diff tool" },
        .{ .long = "prompt", .kind = .set_int, .i = &prompt, .val = 1, .noneg = true, .hidden = true },
        po.boolean(0, "symlinks", &symlinks, "use symlinks in dir-diff mode"),
        po.string('t', "tool", &difftool_cmd, "tool", "use the specified diff tool"),
        po.boolean(0, "tool-help", &tool_help, "print a list of diff tools that may be used with `--tool`"),
        po.boolean(0, "trust-exit-code", &trust, "make 'git-difftool' exit when an invoked diff tool returns a non-zero exit code"),
        po.string('x', "extcmd", &extcmd, "command", "specify a custom command for viewing diffs"),
        po.boolean(0, "no-index", &no_index, "passed to `diff`"),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{ .keep_unknown = true, .keep_dashdash = true });

    if (tool_help) {
        lib.mode = .diff;
        lib.showToolHelp();
    }
    if (!no_index and !repo_mod.have_repository) util.die("difftool requires worktree or --no-index", .{});
    var prefix: []const u8 = "";
    if (!no_index) {
        const r = repo_mod.requireWorkTree("difftool");
        prefix = r.prefix;
        const cwd = os.getcwd();
        const gd = if (r.git_dir.len > 0 and r.git_dir[0] == '/') r.git_dir else util.joinPath(cwd, r.git_dir);
        os.setEnv("GIT_DIR", util.normalizePath(gd) orelse gd);
        const wt = r.work_tree orelse cwd;
        os.setEnv("GIT_WORK_TREE", if (wt.len > 0 and wt[0] == '/') wt else util.joinPath(cwd, wt));
    } else if (dir_diff) {
        po.dieExclusive("--dir-diff", "--no-index");
    }

    {
        var names: std.ArrayList([]const u8) = .empty;
        if (use_gui == 1) names.append(gpa, "--gui") catch util.oom();
        if (difftool_cmd != null) names.append(gpa, "--tool") catch util.oom();
        if (extcmd != null) names.append(gpa, "--extcmd") catch util.oom();
        if (names.items.len == 3) util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ names.items[0], names.items[1], names.items[2] });
        if (names.items.len == 2) po.dieExclusive(names.items[0], names.items[1]);
    }

    if (use_gui == 1) os.setEnv("GIT_MERGETOOL_GUI", "true") else if (use_gui == 0) os.setEnv("GIT_MERGETOOL_GUI", "false");
    if (difftool_cmd) |t| {
        if (t.len == 0) util.die("no <tool> given for --tool=<tool>", .{});
        os.setEnv("GIT_DIFF_TOOL", t);
    }
    if (extcmd) |x| {
        if (x.len == 0) util.die("no <cmd> given for --extcmd=<cmd>", .{});
        os.setEnv("GIT_DIFFTOOL_EXTCMD", x);
    }
    os.setEnv("GIT_DIFFTOOL_TRUST_EXIT_CODE", if (trust) "true" else "false");

    var dargs: std.ArrayList([]const u8) = .empty;
    dargs.append(gpa, "diff") catch util.oom();
    if (no_index) dargs.append(gpa, "--no-index") catch util.oom();
    if (dir_diff) dargs.appendSlice(gpa, &.{ "--raw", "--no-abbrev", "-z" }) catch util.oom();
    dargs.appendSlice(gpa, rest) catch util.oom();

    if (dir_diff) return runDirDiff(has_symlinks, symlinks, extcmd, prefix, dargs.items);

    var ext: Buf = .empty;
    util.sqQuote(&ext, proc.gitBinary());
    util.bufAppend(&ext, " difftool--helper");
    var env: std.ArrayList([2][]const u8) = .empty;
    env.append(gpa, .{ "GIT_PAGER", "" }) catch util.oom();
    env.append(gpa, .{ "GIT_EXTERNAL_DIFF", ext.items }) catch util.oom();
    if (prompt > 0) {
        env.append(gpa, .{ "GIT_DIFFTOOL_PROMPT", "true" }) catch util.oom();
    } else if (prompt == 0) {
        env.append(gpa, .{ "GIT_DIFFTOOL_NO_PROMPT", "true" }) catch util.oom();
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, dargs.items) catch util.oom();
    return os.run(argv.items, .{ .env = env.items, .cwd = if (prefix.len > 0) prefix else null }).status;
}
