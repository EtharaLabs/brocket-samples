//! git history (port of builtin/history.c): drop, fixup, reword, split

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const revision = @import("../revision.zig");
const cn = @import("../commitnode.zig");
const commitreach = @import("../commitreach.zig");
const mo = @import("../merge_ort.zig");
const commit_mod = @import("../commit.zig");
const seq = @import("../sequencer.zig");
const diff = @import("../diff.zig");
const treediff = @import("../treediff.zig");
const editor = @import("../editor.zig");
const wtstatus = @import("../wtstatus.zig");
const index_mod = @import("../index.zig");
const ut = @import("../unpacktrees.zig");
const objects = @import("../objects.zig");
const replay = @import("replay.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Commit = cn.Commit;

const drop_usage = "git history drop <commit> [--dry-run] [--update-refs=(branches|head)] [--empty=(drop|keep|abort)]";
const fixup_usage = "git history fixup <commit> [--dry-run] [--update-refs=(branches|head)] [--reedit-message] [--empty=(drop|keep|abort)]";
const reword_usage = "git history reword <commit> [--dry-run] [--update-refs=(branches|head)]";
const split_usage = "git history split <commit> [--dry-run] [--update-refs=(branches|head)] [--] [<pathspec>...]";
const all_usage = [_][]const u8{ drop_usage, fixup_usage, reword_usage, split_usage };

const RefAction = enum { default, branches, head };

var ref_action: RefAction = .default;
var empty_action: replay.Empty = .drop;

fn parseRefAction(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const v = arg orelse "";
    if (util.eql(v, "branches")) {
        ref_action = .branches;
    } else if (util.eql(v, "head")) {
        ref_action = .head;
    } else {
        util.err("update-refs expects one of 'branches' or 'head'", .{});
        util.flushStdout();
        os.exit(129);
    }
}

fn parseEmpty(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const v = arg orelse "";
    if (util.eql(v, "drop")) {
        empty_action = .drop;
    } else if (util.eql(v, "keep")) {
        empty_action = .keep;
    } else if (util.eql(v, "abort")) {
        empty_action = .abort;
    } else util.die("unrecognized '--empty=' action '{s}'; valid values are \"drop\", \"keep\", and \"abort\".", .{v});
}

fn fail(comptime f: []const u8, args: anytype) u8 {
    util.err(f, args);
    return 255;
}

fn emptyTree() Oid {
    return hash.fromHex(hash.empty_tree_hex).?;
}

fn treeOf(c: *Commit) Oid {
    _ = cn.parse(c);
    return c.tree;
}

fn parentTree(c: *Commit) Oid {
    if (c.parents) |p| return treeOf(p.item);
    return emptyTree();
}

fn lookupByName(name: []const u8) ?*Commit {
    const oid = revparse.getOidCommittish(name) orelse return null;
    const c = cn.lookupCommitReference(oid) orelse return null;
    if (!cn.parse(c)) return null;
    return c;
}

fn isBare() bool {
    return repo_mod.repo().work_tree == null;
}

// ---------------------------------------------------------------------------
// commit message editing


/// wt_status_collect_changes_trees() + wt_status_print() for a commit template
fn appendStatus(buf: *util.Buf, old_tree: Oid, new_tree: Oid) void {
    var s = wtstatus.Status{};
    s.branch = null;
    s.reference = "HEAD";
    s.index_file = repo_mod.repo().indexPath();
    s.ahead_behind_flags = .quick;
    s.commit_template = true;
    s.colopts = 0;
    s.display_comment_prefix = true;
    s.hints = false;
    s.use_color = false;
    s.whence = .commit;
    s.committable = true;

    const o = gpa.create(diff.DiffOptions) catch util.oom();
    o.* = diff.DiffOptions.initBasic();
    o.detect_rename = 0;
    o.flags.recursive = true;
    o.output_format = diff.FMT_NO_OUTPUT;
    o.setupDone();
    diff.clearQueue();
    treediff.diffTreeOid(old_tree, new_tree, "", o);
    diff.diffcoreStd(o);
    for (diff.queue.items) |p| {
        const path = util.dupe(p.two.path);
        const gop = s.change_map.getOrPut(gpa, path) catch util.oom();
        if (!gop.found_existing) {
            const d = gpa.create(wtstatus.Change) catch util.oom();
            d.* = .{ .path = path };
            gop.value_ptr.* = d;
            s.change.append(gpa, d) catch util.oom();
        }
        const d = gop.value_ptr.*;
        if (d.index_status == 0) d.index_status = p.status;
        d.mode_head = p.one.mode;
        d.mode_index = p.two.mode;
        d.oid_head = p.one.oid;
        d.oid_index = p.two.oid;
        if (p.status == 'R' or p.status == 'C') {
            d.rename_source = util.dupe(p.one.path);
            d.rename_status = p.status;
        }
    }
    diff.clearQueue();
    std.mem.sort(*wtstatus.Change, s.change.items, {}, struct {
        fn lt(_: void, a: *wtstatus.Change, b: *wtstatus.Change) bool {
            return std.mem.order(u8, a.path, b.path) == .lt;
        }
    }.lt);
    s.state = wtstatus.getState(false);

    var out = util.Out{ .fd = -1, .capture = true };
    s.out = &out;
    s.out_is_stdout = false;
    wtstatus.print(&s);
    util.bufAppend(buf, out.buf.items);
}

/// fill_commit_message(); null on failure (message already printed)
fn fillCommitMessage(old_tree: Oid, new_tree: Oid, default_message: []const u8, action: []const u8) ?[]const u8 {
    const path = repo_mod.repo().gitPath("COMMIT_EDITMSG");
    const cs = wtstatus.commentStr();
    var buf: util.Buf = .empty;
    util.bufAppend(&buf, default_message);
    util.bufByte(&buf, '\n');
    wtstatus.addCommentedLines(&buf, cs, util.fmt("Please enter the commit message for the {s} changes. Lines starting\nwith '{s}' will be ignored, and an empty message aborts the commit.\n", .{ action, cs }));
    appendStatus(&buf, old_tree, new_tree);
    os.writeFile(path, buf.items, 0o666) catch {
        util.err("could not open '{s}': {s}", .{ path, os.lastErr() });
        return null;
    };
    if (editor.launch(path, &.{})) {
        util.ewrite("Aborting commit as launching the editor failed.\n");
        return null;
    }
    const edited = os.readFile(path) orelse "";
    const msg = util.stripspace(edited, cs);
    if (msg.len == 0) {
        util.ewrite("Aborting commit due to empty commit message.\n");
        return null;
    }
    return msg;
}

/// commit_tree_ext()
fn commitTreeExt(action: []const u8, with_message: *Commit, parents: []const Oid, old_tree: Oid, new_tree: Oid, edit: bool) ?*Commit {
    _ = cn.parse(with_message);
    const message = with_message.buffer;
    const author = cn.findHeader(message, "author");
    const body = seq.findCommitSubject(message).rest;
    const msg = if (edit) (fillCommitMessage(old_tree, new_tree, body, action) orelse return null) else body;
    const oid = commit_mod.create(.{
        .tree = new_tree,
        .parents = parents,
        .message = msg,
        .author = author,
        .extra_headers = extraHeaders(with_message),
    });
    const c = cn.lookupCommit(oid) orelse util.die("could not parse rewritten commit", .{});
    _ = cn.parse(c);
    return c;
}

fn extraHeaders(c: *Commit) []const u8 {
    const buf = c.buffer;
    var b: util.Buf = .empty;
    var pos: usize = 0;
    var keep = false;
    while (pos < buf.len) {
        const eol = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse buf.len;
        const line = buf[pos..eol];
        if (line.len == 0) break;
        if (line[0] != ' ') {
            const sp = std.mem.indexOfScalar(u8, line, ' ') orelse line.len;
            const key = line[0..sp];
            keep = !(util.eql(key, "tree") or util.eql(key, "parent") or util.eql(key, "author") or
                util.eql(key, "committer") or util.eql(key, "encoding") or util.eql(key, "gpgsig") or
                util.eql(key, "gpgsig-sha256"));
        }
        if (keep) {
            util.bufAppend(&b, line);
            util.bufByte(&b, '\n');
        }
        pos = eol + 1;
    }
    return b.items;
}

fn parentOids(c: *Commit) []const Oid {
    var l: std.ArrayList(Oid) = .empty;
    var p = c.parents;
    while (p) |x| : (p = x.next) l.append(gpa, x.item.oid()) catch util.oom();
    return l.items;
}

// ---------------------------------------------------------------------------
// rev walk / ref updates

fn newRevs() *revision.RevInfo {
    const revs = gpa.create(revision.RevInfo) catch util.oom();
    revs.* = revision.RevInfo.init(repo_mod.repo().prefix);
    return revs;
}

/// setup_revwalk(); returns null on error (already reported)
fn setupRevwalk(action: RefAction, original: *Commit) ?*revision.RevInfo {
    var args: std.ArrayList([]const u8) = .empty;
    const hex = hash.hex(original.oid());
    args.appendSlice(gpa, &.{ "ignored", "--reverse", "--topo-order", "--full-history" }) catch util.oom();
    args.append(gpa, util.concat(&.{ "--ancestry-path=", &hex })) catch util.oom();
    args.append(gpa, util.concat(&.{ "^", &hex })) catch util.oom();
    if (action == .head) {
        const head = lookupByName("HEAD") orelse {
            util.err("cannot look up HEAD", .{});
            return null;
        };
        const from = gpa.create(cn.CommitList) catch util.oom();
        from.* = .{ .item = original, .next = null };
        if (!commitreach.isDescendantOf(head, from)) {
            util.err("rewritten commit must be an ancestor of HEAD when using --update-refs=head", .{});
            return null;
        }
        args.append(gpa, "HEAD") catch util.oom();
    } else {
        args.appendSlice(gpa, &.{ "--branches", "HEAD" }) catch util.oom();
    }

    // revwalk_contains_merges()
    {
        var margs: std.ArrayList([]const u8) = .empty;
        margs.appendSlice(gpa, args.items) catch util.oom();
        margs.append(gpa, "--min-parents=2") catch util.oom();
        const mrevs = newRevs();
        _ = revision.setupRevisions(mrevs, margs.items, .{});
        if (!revision.prepareRevisionWalk(mrevs)) {
            util.err("error preparing revisions", .{});
            return null;
        }
        if (revision.getRevision(mrevs) != null) {
            util.err("replaying merge commits is not supported yet!", .{});
            return null;
        }
        revision.resetRevisionWalk();
    }

    const revs = newRevs();
    _ = revision.setupRevisions(revs, args.items, .{});
    return revs;
}

fn headIsDetached() bool {
    return switch (refs.readRawFull("HEAD")) {
        .symref => false,
        else => true,
    };
}

/// compute_pending_ref_updates(); 0 on success
fn computeUpdates(revs: *revision.RevInfo, action: RefAction, original: *Commit, rewritten: *Commit, empty: replay.Empty, out: *std.ArrayList(replay.Update)) i32 {
    const detached = headIsDetached();
    const opts = replay.Opts{ .empty = empty, .onto = util.dupe(&hash.hex(rewritten.oid())) };
    const ret = replay.replayRevisions(revs, &opts, out);
    if (ret != 0) return ret;

    // decorations of `original`: HEAD first, then branches (reverse order)
    const orig = original.oid();
    if (refs.readOid("HEAD")) |h| {
        if (std.mem.eql(u8, &h, &orig)) {
            if (action == .head or detached)
                out.append(gpa, .{ .refname = "HEAD", .old = orig, .new = rewritten.oid() }) catch util.oom();
        }
    }
    if (action == .branches) {
        const all = refs.iterate("refs/heads/", .{ .check_objects = false });
        var i = all.len;
        while (i > 0) {
            i -= 1;
            if (!std.mem.eql(u8, &all[i].oid, &orig)) continue;
            out.append(gpa, .{ .refname = all[i].name, .old = orig, .new = rewritten.oid() }) catch util.oom();
        }
    }
    return 0;
}

/// apply_pending_ref_updates(); 0 on success
fn applyUpdates(updates: []const replay.Update, reflog_msg: []const u8, dry_run: bool) i32 {
    if (dry_run) {
        for (updates) |u| util.outf("update {s} {s} {s}\n", .{ u.refname, hash.hex(u.new), hash.hex(u.old) });
        util.flushStdout();
        return 0;
    }
    const tx = refs.Transaction.init();
    for (updates) |u| {
        if (tx.update(u.refname, u.new, u.old, null, null, 0, reflog_msg) != .ok) {
            util.err("failed to update ref '{s}': {s}", .{ u.refname, tx.errMsg() });
            return -1;
        }
    }
    if (tx.commit() != .ok) {
        util.err("failed to commit ref transaction: {s}", .{tx.errMsg()});
        return -1;
    }
    return 0;
}

fn handleReferenceUpdates(revs: *revision.RevInfo, action: RefAction, original: *Commit, rewritten: *Commit, reflog_msg: []const u8, dry_run: bool, empty: replay.Empty) i32 {
    var updates: std.ArrayList(replay.Update) = .empty;
    const ret = computeUpdates(revs, action, original, rewritten, empty, &updates);
    if (ret != 0) return ret;
    return applyUpdates(updates.items, reflog_msg, dry_run);
}

// ---------------------------------------------------------------------------
// subcommands

fn commonOpts(comptime with_empty: bool, comptime with_reedit: bool, dry_run: *bool, reedit: *bool, empty_help: []const u8) []const po.Opt {
    var l: std.ArrayList(po.Opt) = .empty;
    l.append(gpa, .{ .long = "update-refs", .kind = .callback, .cb = parseRefAction, .argh = "(branches|head)", .noneg = true, .help = "control which refs should be updated" }) catch util.oom();
    l.append(gpa, po.boolean('n', "dry-run", dry_run, "perform a dry-run without updating any refs")) catch util.oom();
    if (with_reedit) l.append(gpa, po.boolean(0, "reedit-message", reedit, "open an editor to modify the commit message")) catch util.oom();
    if (with_empty) l.append(gpa, .{ .long = "empty", .kind = .callback, .cb = parseEmpty, .argh = "(drop|keep|abort)", .noneg = true, .help = empty_help }) catch util.oom();
    return l.items;
}

fn cmdFixup(args: []const []const u8) u8 {
    var dry_run = false;
    var reedit = false;
    const options = commonOpts(true, true, &dry_run, &reedit, "how to handle commits that become empty");
    const rest = po.parse(args[1..], options, &.{fixup_usage}, .{});
    if (rest.len != 1) return fail("command expects a single revision", .{});
    if (ref_action == .default) ref_action = .branches;
    if (isBare()) return fail("cannot run fixup in a bare repository", .{});
    const name = rest[0];
    const original = lookupByName(name) orelse return fail("commit cannot be found: {s}", .{name});
    const head_commit = lookupByName("HEAD") orelse return fail("cannot look up HEAD", .{});
    const head_tree = treeOf(head_commit);
    const idx = index_mod.get();
    const index_tree = idx.writeTree(false) orelse return fail("unable to write index as a tree", .{});
    if (std.mem.eql(u8, &index_tree, &head_tree)) return fail("nothing to fixup: no staged changes", .{});
    const original_tree = treeOf(original);

    var mopts = mo.initMergeOptions(false);
    mopts.show_rename_progress = false;
    mopts.ancestor = "HEAD";
    mopts.branch1 = name;
    mopts.branch2 = "staged";
    var result = mo.Result{};
    mo.mergeIncoreNonrecursive(&mopts, head_tree, original_tree, index_tree, &result);
    if (result.clean < 0) return fail("merge failed while applying fixup", .{});
    if (result.clean == 0) return fail("fixup would produce conflicts; aborting", .{});

    var skip_commit = false;
    var rewritten: *Commit = undefined;
    if (std.mem.eql(u8, &result.tree, &parentTree(original))) {
        switch (empty_action) {
            .drop => {
                const p = original.parents orelse
                    return fail("cannot drop root commit {s}: it has no parent to replay onto", .{name});
                rewritten = p.item;
                skip_commit = true;
            },
            .keep => {},
            .abort => return fail("fixup makes commit {s} empty", .{name}),
        }
    }

    const revs = setupRevwalk(ref_action, original) orelse return 255;
    if (!skip_commit) {
        rewritten = commitTreeExt("fixup", original, parentOids(original), original_tree, result.tree, reedit) orelse
            return fail("failed writing fixed-up commit", .{});
    }
    const msg = util.concat(&.{ "fixup: updating ", name });
    if (handleReferenceUpdates(revs, ref_action, original, rewritten, msg, dry_run, empty_action) < 0)
        return fail("failed replaying descendants", .{});
    return 0;
}

fn cmdReword(args: []const []const u8) u8 {
    var dry_run = false;
    var reedit = false;
    const options = commonOpts(false, false, &dry_run, &reedit, "");
    const rest = po.parse(args[1..], options, &.{reword_usage}, .{});
    if (rest.len != 1) return fail("command expects a single revision", .{});
    if (ref_action == .default) ref_action = .branches;
    const name = rest[0];
    const original = lookupByName(name) orelse return fail("commit cannot be found: {s}", .{name});
    const revs = setupRevwalk(ref_action, original) orelse return 255;

    if (original.parents) |p| {
        if (!cn.parse(p.item)) {
            util.err("unable to parse parent commit {s}", .{hash.hex(p.item.oid())});
            return fail("failed writing reworded commit", .{});
        }
    }
    const rewritten = commitTreeExt("reworded", original, parentOids(original), parentTree(original), treeOf(original), true) orelse
        return fail("failed writing reworded commit", .{});
    const msg = util.concat(&.{ "reword: updating ", name });
    if (handleReferenceUpdates(revs, ref_action, original, rewritten, msg, dry_run, .abort) < 0)
        return fail("failed replaying descendants", .{});
    return 0;
}

fn cmdSplit(args: []const []const u8) u8 {
    var dry_run = false;
    var reedit = false;
    const options = commonOpts(false, false, &dry_run, &reedit, "");
    const rest = po.parse(args[1..], options, &.{split_usage}, .{});
    if (rest.len < 1) return fail("command expects a committish", .{});
    if (ref_action == .default) ref_action = .branches;
    const name = rest[0];
    const original = lookupByName(name) orelse return fail("commit cannot be found: {s}", .{name});
    _ = setupRevwalk(ref_action, original) orelse return 255;
    if (original.parents) |p| {
        if (p.next != null) return fail("cannot split up merge commit", .{});
    }
    // Interactive hunk selection (add -p) is not available in this port.
    return fail("interactive hunk selection is not supported", .{});
}

/// reset_working_tree() with oid_from, two-way merge
fn updateWorktree(old_head: *Commit, new_head: *Commit, dry_run: bool) bool {
    const from_tree = objects.peelTo(old_head.oid(), .tree) orelse {
        util.err("failed to find tree of {s}", .{hash.hex(old_head.oid())});
        return false;
    };
    const to_tree = objects.peelTo(new_head.oid(), .tree) orelse {
        util.err("failed to find tree of {s}", .{hash.hex(new_head.oid())});
        return false;
    };
    const idx = if (dry_run) index_mod.readFrom(repo_mod.repo().indexPath()) else blk: {
        index_mod.discard();
        break :blk index_mod.lockAndRead();
    };
    _ = ut.readIndexUnmerged(idx);
    var uo = ut.Options{};
    ut.setupPorcelain(&uo, "checkout");
    uo.head_idx = 1;
    uo.src_index = idx;
    uo.dst_index = idx;
    uo.func = &ut.twowayMerge;
    uo.update = !dry_run;
    uo.dry_run = dry_run;
    uo.merge = true;
    uo.preserve_ignored = false;
    if (ut.unpackTrees(&.{ from_tree, to_tree }, &uo) != 0) {
        if (!dry_run) index_mod.get().rollback();
        return false;
    }
    if (!dry_run) index_mod.get().write();
    return true;
}

fn cmdDrop(args: []const []const u8) u8 {
    var dry_run = false;
    var reedit = false;
    const options = commonOpts(true, false, &dry_run, &reedit, "how to handle descendants that become empty");
    const rest = po.parse(args[1..], options, &.{drop_usage}, .{});
    if (rest.len != 1) return fail("command expects a single revision", .{});
    if (ref_action == .default) ref_action = .branches;
    const name = rest[0];
    const original = lookupByName(name) orelse return fail("commit cannot be found: {s}", .{name});
    const parents = original.parents orelse
        return fail("cannot drop root commit {s}: it has no parent to replay onto", .{name});
    if (parents.next != null) return fail("cannot drop merge commit: {s}", .{name});

    const revs = setupRevwalk(ref_action, original) orelse return 255;
    const rewritten = parents.item;
    _ = cn.parse(rewritten);

    var updates: std.ArrayList(replay.Update) = .empty;
    if (computeUpdates(revs, ref_action, original, rewritten, empty_action, &updates) != 0)
        return fail("failed replaying descendants", .{});

    var head_moves = false;
    var old_head: *Commit = undefined;
    var new_head: *Commit = undefined;
    if (!isBare()) {
        const head_target: []const u8 = switch (refs.readRawFull("HEAD")) {
            .symref => |t| t,
            else => "HEAD",
        };
        for (updates.items) |u| {
            if (!util.eql(u.refname, head_target)) continue;
            const oc = cn.lookupCommitReference(u.old);
            const nc = cn.lookupCommitReference(u.new);
            if (oc == null or nc == null) return fail("cannot resolve HEAD commit", .{});
            if (!std.mem.eql(u8, &treeOf(oc.?), &treeOf(nc.?))) {
                old_head = oc.?;
                new_head = nc.?;
                head_moves = true;
            }
            break;
        }
        if (head_moves and !updateWorktree(old_head, new_head, true))
            return fail("dropping this commit would overwrite local changes; aborting", .{});
    }

    const msg = util.concat(&.{ "drop: dropping ", name });
    if (applyUpdates(updates.items, msg, dry_run) < 0) return fail("failed to update references", .{});

    if (!dry_run and head_moves and !updateWorktree(old_head, new_head, false))
        return fail("could not update working tree to new commit {s}", .{hash.hex(new_head.oid())});
    return 0;
}

pub fn cmdHistory(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").history);
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&all_usage, &.{});
    }
    const sub = args[1];
    if (util.eql(sub, "-h") or util.eql(sub, "--help-all")) {
        po.printUsage(&all_usage, &.{}, false);
        util.flushStdout();
        os.exit(0);
    }
    if (util.eql(sub, "drop")) return cmdDrop(args[1..]);
    if (util.eql(sub, "fixup")) return cmdFixup(args[1..]);
    if (util.eql(sub, "reword")) return cmdReword(args[1..]);
    if (util.eql(sub, "split")) return cmdSplit(args[1..]);
    if (sub.len > 0 and sub[0] == '-') {
        if (util.startsWith(sub, "--")) {
            util.err("unknown option `{s}'", .{sub[2..]});
        } else util.err("unknown switch `{c}'", .{if (sub.len > 1) sub[1] else '-'});
    } else util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&all_usage, &.{});
}
