//! Port of bundle-uri.c: downloading bundles (and bundle lists) from a
//! URI before fetching, the creationToken heuristic, and the protocol v2
//! "bundle-uri" command (server and client parsing).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const config = @import("config.zig");
const pkt = @import("pktline.zig");
const proc = @import("proc.zig");
const t2 = @import("trace2.zig");
const bundle = @import("cmd/bundle.zig");
const gpa = util.gpa;

pub const Mode = enum { none, all, any };

pub const Info = struct {
    id: []const u8,
    uri: ?[]const u8 = null,
    file: ?[]const u8 = null,
    unbundled: bool = false,
    creation_token: u64 = 0,
};

/// Mirrors git's hashmap (strhash buckets, head insertion, x4 growth) so
/// that iteration order matches C.
const Map = struct {
    size: usize = 64,
    table: std.ArrayList(std.ArrayList(*Info)) = .empty,
    count: usize = 0,

    fn strhash(s: []const u8) u32 {
        var h: u32 = 0x811c9dc5;
        for (s) |ch| h = (h *% 0x01000193) ^ ch;
        return h;
    }
    fn ensure(self: *Map) void {
        if (self.table.items.len == 0) {
            for (0..self.size) |_| self.table.append(gpa, .empty) catch util.oom();
        }
    }
    fn bucket(self: *Map, s: []const u8) usize {
        return strhash(s) & @as(u32, @intCast(self.size - 1));
    }
    fn get(self: *Map, id: []const u8) ?*Info {
        self.ensure();
        for (self.table.items[self.bucket(id)].items) |e| {
            if (util.eql(e.id, id)) return e;
        }
        return null;
    }
    fn pushHead(self: *Map, e: *Info) void {
        const b = self.bucket(e.id);
        self.table.items[b].insert(gpa, 0, e) catch util.oom();
    }
    fn add(self: *Map, e: *Info) void {
        self.ensure();
        self.pushHead(e);
        self.count += 1;
        if (self.count > self.size * 80 / 100) {
            const old = self.table;
            self.size <<= 2;
            self.table = .empty;
            self.ensure();
            for (old.items) |chain| {
                for (chain.items) |e2| self.pushHead(e2);
            }
        }
    }
    fn items(self: *Map) []*Info {
        self.ensure();
        var l: std.ArrayList(*Info) = .empty;
        for (self.table.items) |chain| l.appendSlice(gpa, chain.items) catch util.oom();
        return l.items;
    }
};

pub const List = struct {
    mode: Mode = .all,
    version: i32 = 1,
    heuristic_token: bool = false,
    base_uri: ?[]const u8 = null,
    bundles: Map = .{},

    pub fn count(self: *const List) usize {
        return self.bundles.count;
    }
};

/// sscanf("%" PRIu64)
fn scanU64(s0: []const u8) ?u64 {
    var s = s0;
    while (s.len > 0 and (s[0] == ' ' or (s[0] >= 9 and s[0] <= 13))) s = s[1..];
    var neg = false;
    if (s.len > 0 and (s[0] == '+' or s[0] == '-')) {
        neg = s[0] == '-';
        s = s[1..];
    }
    var n: u64 = 0;
    var i: usize = 0;
    var overflow = false;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) {
        const m = @mulWithOverflow(n, 10);
        const a = @addWithOverflow(m[0], s[i] - '0');
        if (m[1] != 0 or a[1] != 0) overflow = true;
        n = a[0];
    }
    if (i == 0) return null;
    if (overflow) return std.math.maxInt(u64);
    return if (neg) 0 -% n else n;
}

/// bundle_list_update(): 0 if understood, -1 otherwise.
fn listUpdate(key: []const u8, value: ?[]const u8, list: *List) i32 {
    const pk = config.parseConfigKey(key, "bundle") orelse return -1;
    const sub = pk.sub orelse "";
    if (sub.len == 0) {
        if (util.eql(pk.key, "version")) {
            const v = value orelse return -1;
            const n = config.parseInt(v) orelse return -1;
            if (n < std.math.minInt(i32) or n > std.math.maxInt(i32)) return -1;
            if (n != 1) return -1;
            list.version = 1;
            return 0;
        }
        if (util.eql(pk.key, "mode")) {
            const v = value orelse return -1;
            if (util.eql(v, "all")) {
                list.mode = .all;
            } else if (util.eql(v, "any")) {
                list.mode = .any;
            } else return -1;
            return 0;
        }
        if (util.eql(pk.key, "heuristic")) {
            if (value) |v| {
                if (util.eql(v, "creationToken")) list.heuristic_token = true;
            }
            return 0;
        }
        return 0;
    }
    const b = list.bundles.get(sub) orelse blk: {
        const nb = gpa.create(Info) catch util.oom();
        nb.* = .{ .id = util.dupe(sub) };
        list.bundles.add(nb);
        break :blk nb;
    };
    if (util.eql(pk.key, "uri")) {
        if (b.uri != null) return -1;
        b.uri = @import("cmd/submodule.zig").relativeUrl(list.base_uri orelse "", value orelse "", null);
        return 0;
    }
    if (util.eql(pk.key, "creationtoken")) {
        const v = value orelse "";
        if (scanU64(v)) |n| {
            b.creation_token = n;
        } else util.warn("could not parse bundle list key {s} with value '{s}'", .{ "creationToken", v });
        return 0;
    }
    return 0;
}

fn configToList(ctx: *anyopaque, key: []const u8, value: ?[]const u8, _: *const config.KvInfo) i32 {
    const list: *List = @ptrCast(@alignCast(ctx));
    return listUpdate(key, value, list);
}

/// strbuf_strip_file_from_path()
fn stripFileFromPath(s: []const u8) []const u8 {
    const i = std.mem.lastIndexOfScalar(u8, s, '/') orelse return "";
    return s[0 .. i + 1];
}

/// bundle_uri_parse_config_format()
pub fn parseConfigFormat(uri: []const u8, filename: []const u8, list: *List) i32 {
    if (list.base_uri == null) list.base_uri = util.dupe(stripFileFromPath(uri));
    var result: i32 = 0;
    if (os.readFile(filename)) |data| {
        result = config.parseSource(.{ .data = data, .origin_type = .file, .name = filename, .scope = .unknown, .error_action = .err }, .{ .f = configToList, .ctx = list }, null, null);
    } else {
        util.warn("unable to access '{s}': {s}", .{ filename, os.lastErr() });
        result = -1;
    }
    if (result == 0 and list.mode == .none) {
        util.warn("bundle list at '{s}' has no mode", .{uri});
        result = 1;
    }
    if (result == 0) {
        for (list.bundles.items()) |b| {
            if (b.uri == null) {
                util.err("bundle list at '{s}': bundle '{s}' has no uri", .{ uri, b.id });
                result = 1;
            }
        }
    }
    return result;
}

/// find_temp_filename()
fn findTempFilename() ?[]const u8 {
    const objdir = repo_mod.repo().odb().objects_dir;
    const dir = util.concat(&.{ objdir, "/bundles" });
    var t = os.tmpFile(dir, "tmp_uri_");
    if (t.fd < 0) {
        if (os.errno() == os.ENOENT and os.mkdirAll(dir)) t = os.tmpFile(dir, "tmp_uri_");
    }
    if (t.fd < 0) {
        util.warn("failed to create temporary file", .{});
        return null;
    }
    os.close(t.fd);
    _ = os.unlink(t.path);
    return t.path;
}

/// download_https_uri_to_file()
fn downloadHttps(file: []const u8, uri: []const u8) i32 {
    if (std.mem.indexOfAny(u8, uri, " \n") != null) {
        util.err("bundle-uri: URI is malformed: '{s}'", .{file});
        return -1;
    }
    if (std.mem.indexOfScalar(u8, file, '\n') != null) {
        util.err("bundle-uri: filename is malformed: '{s}'", .{file});
        return -1;
    }
    const ch = proc.spawn(&.{ "git-remote-https", uri }, .{ .pipe_in = true, .pipe_out = true, .pipe_err = true });
    var result: i32 = 0;
    os.writeAll(ch.in, "capabilities\n") catch {};
    var found_get = false;
    var line: util.Buf = .empty;
    while (true) {
        var byte: [1]u8 = undefined;
        const n = std.c.read(ch.out, &byte, 1);
        if (n <= 0) break;
        if (byte[0] != '\n') {
            line.append(gpa, byte[0]) catch util.oom();
            continue;
        }
        if (line.items.len == 0) break;
        if (util.eql(line.items, "get")) found_get = true;
        line.clearRetainingCapacity();
    }
    if (!found_get) {
        util.err("insufficient capabilities", .{});
        result = -1;
    } else {
        os.writeAll(ch.in, util.fmt("get {s} {s}\n\n", .{ uri, file })) catch {};
    }
    os.close(ch.in);
    // drain the helper's stderr (cp.err = -1 in C)
    _ = os.readAllFd(ch.err) catch "";
    if (proc.wait(ch.pid) != 0) result = 1;
    os.close(ch.out);
    os.close(ch.err);
    return result;
}

/// copy_file(dst, src, 0)
fn copyFile(dst: []const u8, src: []const u8) i32 {
    const fdi = os.openFile(src, os.O_RDONLY, 0);
    if (fdi < 0) return -1;
    defer os.close(fdi);
    const fdo = os.openFile(dst, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666);
    if (fdo < 0) return -1;
    const data = os.readAllFd(fdi) catch {
        util.err("copy-fd: read returned: {s}", .{os.lastErr()});
        os.close(fdo);
        return -1;
    };
    os.writeAll(fdo, data) catch {
        util.err("copy-fd: write returned: {s}", .{os.lastErr()});
        os.close(fdo);
        return -1;
    };
    os.close(fdo);
    return 0;
}

/// copy_uri_to_file()
fn copyUriToFile(filename: []const u8, uri0: []const u8) i32 {
    if (util.startsWith(uri0, "https:") or util.startsWith(uri0, "http:"))
        return downloadHttps(filename, uri0);
    const uri = util.skipPrefix(uri0, "file://") orelse uri0;
    return copyFile(filename, uri);
}

/// fetch_pack_fsck_objects()
fn fsckObjects() bool {
    const cfg = repo_mod.cfg;
    if (cfg.getBool("fetch.fsckobjects")) |b| return b;
    if (cfg.getBool("transfer.fsckobjects")) |b| return b;
    return false;
}

/// unbundle_from_file()
fn unbundleFromFile(file: []const u8) i32 {
    const h = gpa.create(bundle.Header) catch util.oom();
    h.* = .{};
    bundle.readBundleHeader(file, h) orelse return 1;
    if (bundle.unbundleOpts(h, &.{}, .quiet, if (fsckObjects()) "" else null) != 0) return 1;
    repo_mod.repo().odb().reloadPacks();
    for (h.references.items) |r| {
        const branch = util.skipPrefix(r.name, "refs/") orelse continue;
        const name = util.concat(&.{ "refs/bundles/", branch });
        const cur = refs.resolveFull(name, true);
        const old: ?@import("hash.zig").Oid = if (!cur.missing and !cur.broken) cur.oid else null;
        refs.update(name, r.oid, old, "fetched bundle", false) catch {
            util.err("update_ref failed for ref '{s}': {s}", .{ name, refs.last_error });
        };
    }
    return 0;
}

const Ctx = struct {
    list: *List,
    mode: Mode,
    count: usize = 0,
    depth: i32 = 0,
};

/// download_bundle_to_file()
fn downloadBundleToFile(b: *Info, ctx: *Ctx) void {
    if (ctx.mode == .any and ctx.count != 0) return;
    if (fetchInternal(b, ctx.depth + 1, ctx.list) == 0) ctx.count += 1;
}

fn tokenGreater(_: void, a: *Info, b: *Info) bool {
    return a.creation_token > b.creation_token;
}

/// fetch_bundles_by_token(); 0 on success
fn fetchByToken(list: *List) i32 {
    const ctx = Ctx{ .list = list, .mode = list.mode };
    const all = list.bundles.items();
    if (all.len == 0) return 0;
    const sorted = gpa.dupe(*Info, all) catch util.oom();
    std.sort.insertion(*Info, sorted, {}, tokenGreater);

    var max_token: u64 = 0;
    var new_max: u64 = 0;
    if (repo_mod.cfg.get("fetch.bundlecreationtoken")) |s| {
        max_token = scanU64(s) orelse 0;
        if (sorted[0].creation_token <= max_token) return 0;
    }
    var cur: isize = 0;
    var dir: isize = 0;
    while (cur >= 0 and cur < @as(isize, @intCast(sorted.len))) {
        const b = sorted[@intCast(cur)];
        if (b.creation_token <= max_token) break;
        move: {
            if (b.file == null) {
                if (fetchInternal(b, ctx.depth + 1, ctx.list) != 0) {
                    b.unbundled = true;
                    dir = 1;
                    break :move;
                }
                if (!bundle.isBundle(b.file.?, true)) {
                    util.warn("file downloaded from '{s}' is not a bundle", .{b.uri orelse "(null)"});
                    break;
                }
            }
            if (b.file != null and !b.unbundled) {
                if (unbundleFromFile(b.file.?) != 0) {
                    dir = 1;
                } else {
                    dir = -1;
                    b.unbundled = true;
                    if (b.creation_token > new_max) new_max = b.creation_token;
                }
            }
        }
        cur += dir;
    }
    if (cur < 0) {
        const path = repo_mod.repo().commonPath("config");
        if (config.setInFileGently(path, "fetch.bundleCreationToken", null, util.fmt("{d}", .{new_max})) != 0)
            util.warn("failed to store maximum creation token", .{});
    }
    return if (cur >= 0) 1 else 0;
}

/// download_bundle_list()
fn downloadBundleList(local: *List, global: *List, depth: i32) i32 {
    var ctx = Ctx{ .list = global, .depth = depth + 1, .mode = local.mode };
    for (local.bundles.items()) |b| downloadBundleToFile(b, &ctx);
    return 0;
}

/// fetch_bundle_list_in_config_format()
fn fetchListInConfigFormat(global: *List, b: *Info, depth: i32) i32 {
    var from: List = .{};
    var result = parseConfigFormat(b.uri.?, b.file.?, &from);
    if (result != 0) return result;
    if (from.mode == .none) {
        util.warn("unrecognized bundle mode from URI '{s}'", .{b.uri.?});
        return -1;
    }
    if (from.heuristic_token) {
        result = fetchByToken(&from);
        global.heuristic_token = true;
    } else {
        result = downloadBundleList(&from, global, depth);
    }
    return result;
}

const max_depth: i32 = 4;

/// fetch_bundle_uri_internal()
fn fetchInternal(b: *Info, depth: i32, list: *List) i32 {
    if (depth >= max_depth) {
        util.warn("exceeded bundle URI recursion limit ({d})", .{max_depth});
        return -1;
    }
    const uri = b.uri orelse {
        util.err("bundle '{s}' has no uri", .{b.id});
        return -1;
    };
    var result: i32 = 0;
    cleanup: {
        if (b.file == null) {
            b.file = findTempFilename() orelse {
                result = -1;
                break :cleanup;
            };
        }
        result = copyUriToFile(b.file.?, uri);
        if (result != 0) {
            util.warn("failed to download bundle from URI '{s}'", .{uri});
            break :cleanup;
        }
        if (!bundle.isBundle(b.file.?, true)) {
            result = fetchListInConfigFormat(list, b, depth);
            if (result != 0) util.warn("file at URI '{s}' is not a bundle or bundle list", .{uri});
            break :cleanup;
        }
        const copy = gpa.create(Info) catch util.oom();
        copy.* = .{ .id = b.id, .file = b.file };
        list.bundles.add(copy);
    }
    if (result != 0) {
        if (b.file) |f| _ = os.unlink(f);
    }
    return result;
}

/// unbundle_all_bundles()
fn unbundleAll(list: *List) i32 {
    while (true) {
        var progress = false;
        for (list.bundles.items()) |info| {
            if (info.file == null or info.unbundled) continue;
            if (unbundleFromFile(info.file.?) == 0) {
                info.unbundled = true;
                progress = true;
                break;
            }
        }
        if (!progress) break;
    }
    return 0;
}

/// unlink_or_warn() on each downloaded bundle
fn unlinkBundles(list: *List) void {
    for (list.bundles.items()) |info| {
        const f = info.file orelse continue;
        if (!os.unlink(f) and os.errno() != os.ENOENT)
            util.warn("unable to unlink '{s}': {s}", .{ f, os.lastErr() });
    }
}

/// fetch_bundle_uri(); 0 on success
pub fn fetchBundleUri(uri: []const u8, has_heuristic: ?*bool) i32 {
    t2.regionEnter("fetch", "fetch-bundle-uri", true);
    var list: List = .{};
    var result: i32 = 0;
    if (uri.len > 0) {
        var b = Info{ .id = "", .uri = uri };
        list.mode = .all;
        result = fetchInternal(&b, 0, &list);
        if (result == 0) result = unbundleAll(&list);
    }
    if (has_heuristic) |p| p.* = list.heuristic_token;
    unlinkBundles(&list);
    t2.regionLeave("fetch", "fetch-bundle-uri", true);
    return result;
}

/// fetch_bundle_list(); 0 on success
pub fn fetchBundleList(list: *List) i32 {
    if (list.heuristic_token) return fetchByToken(list);
    var global: List = .{ .mode = .all };
    var result = downloadBundleList(list, &global, 0);
    if (result == 0) result = unbundleAll(&global);
    unlinkBundles(&global);
    return result;
}

// ---------------- protocol v2 ----------------

var advertise_cached: ?bool = null;

/// bundle_uri_advertise()
pub fn advertise() bool {
    if (advertise_cached) |v| return v;
    var v = false;
    if (repo_mod.cfg.getEntry("uploadpack.advertisebundleuris")) |e| {
        const r = config.parseMaybeBool(e.value);
        if (r >= 0) v = r != 0;
    }
    advertise_cached = v;
    return v;
}

/// bundle_uri_command() (server side)
pub fn command(rd: *pkt.Reader) void {
    while (rd.read() == .normal) util.die("bundle-uri: unexpected argument: '{s}'", .{rd.line});
    if (rd.status != .flush) util.die("bundle-uri: expected flush after arguments", .{});
    for (repo_mod.cfg.entries.items) |e| {
        if (!util.startsWith(e.key, "bundle.")) continue;
        if (e.value) |v| {
            if (v.len > 0) {
                pkt.writeFmt(1, "{s}={s}", .{ e.key, v });
                continue;
            }
        }
        util.warn("config '{s}' has no value", .{e.key});
    }
    pkt.flush(1);
}

/// bundle_uri_parse_line(); 0 on success
pub fn parseLine(list: *List, line: []const u8) i32 {
    if (line.len == 0) {
        util.err("bundle-uri: got an empty line", .{});
        return -1;
    }
    const eq = std.mem.indexOfScalar(u8, line, '=') orelse {
        util.err("bundle-uri: line is not of the form 'key=value'", .{});
        return -1;
    };
    if (eq == 0 or eq + 1 == line.len) {
        util.err("bundle-uri: line has empty key or value", .{});
        return -1;
    }
    return listUpdate(line[0..eq], line[eq + 1 ..], list);
}
