//! Ref plumbing: update-ref, symbolic-ref, show-ref, check-ref-format,
//! pack-refs, reflog, refs, for-each-ref.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const revparse = @import("../revparse.zig");
const objects = @import("../objects.zig");
const ident = @import("../ident.zig");
const date = @import("../date.zig");
const wildmatch = @import("../wildmatch.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

fn getOidQuiet(name: []const u8) ?Oid {
    const r = revparse.resolve(name, .{ .quiet = true }) orelse return null;
    return r.oid;
}

// =====================================================================
// update-ref
// =====================================================================

const update_ref_usage = [_][]const u8{
    "git update-ref [<options>] -d <refname> [<old-oid>]",
    "git update-ref [<options>]    <refname> <new-oid> [<old-oid>]",
    "git update-ref [<options>] --stdin [-z] [--batch-updates]",
};

var line_term: u8 = '\n';
var update_flags: u32 = 0;
var default_flags: u32 = 0;
var create_reflog_flag: u32 = 0;
var ur_msg: ?[]const u8 = null;
var allow_update_failures = false;

/// Input buffer for one command (may contain NULs with -z).
const Input = struct {
    buf: []const u8,
    fn at(self: Input, i: usize) u8 {
        return if (i < self.buf.len) self.buf[i] else 0;
    }
    /// C string starting at i (up to NUL or end).
    fn cstr(self: Input, i: usize) []const u8 {
        if (i >= self.buf.len) return "";
        const rest = self.buf[i..];
        const n = std.mem.indexOfScalar(u8, rest, 0) orelse rest.len;
        return rest[0..n];
    }
};

fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r' or ch == 11 or ch == 12;
}

fn parseArg(in: Input, next: *usize, arg: *util.Buf) void {
    if (in.at(next.*) == '"') {
        const orig = in.cstr(next.*);
        const r = util.cunquote(orig) orelse util.die("badly quoted argument: {s}", .{orig});
        util.bufAppend(arg, r.value);
        next.* += orig.len - r.rest.len;
        const ch = in.at(next.*);
        if (ch != 0 and !isSpace(ch)) util.die("unexpected character after quoted argument: {s}", .{orig});
    } else {
        while (in.at(next.*) != 0 and !isSpace(in.at(next.*))) {
            util.bufByte(arg, in.at(next.*));
            next.* += 1;
        }
    }
}

fn parseRefname(in: Input, next: *usize) ?[]const u8 {
    var ref: util.Buf = .empty;
    if (line_term != 0) {
        parseArg(in, next, &ref);
    } else {
        const s = in.cstr(next.*);
        util.bufAppend(&ref, s);
        next.* += s.len;
    }
    if (ref.items.len == 0) return null;
    if (!refs.checkRefnameFormat(ref.items, refs.ALLOW_ONELEVEL)) util.die("invalid ref format: {s}", .{ref.items});
    return ref.items;
}

fn parseNextRefname(in: Input, next: *usize) ?[]const u8 {
    if (line_term != 0) {
        const ch = in.at(next.*);
        if (ch == 0 or ch == line_term) return null;
        if (ch != ' ') util.die("expected SP but got: {s}", .{in.cstr(next.*)});
    } else {
        if (in.at(next.*) != 0) return null;
    }
    next.* += 1;
    return parseRefname(in, next);
}

fn parseNextArg(in: Input, next: *usize) ?[]const u8 {
    var arg: util.Buf = .empty;
    if (line_term != 0) {
        const ch = in.at(next.*);
        if (ch == 0 or ch == line_term) return null;
        if (ch != ' ') util.die("expected SP but got: {s}", .{in.cstr(next.*)});
    } else {
        if (in.at(next.*) != 0) return null;
    }
    next.* += 1;
    if (line_term != 0) {
        parseArg(in, next, &arg);
    } else {
        const s = in.cstr(next.*);
        util.bufAppend(&arg, s);
        next.* += s.len;
    }
    if (arg.items.len > 0) return arg.items;
    return null;
}

const PARSE_SHA1_OLD: u32 = 1;
const PARSE_SHA1_ALLOW_EMPTY: u32 = 2;

/// Returns null if no argument (C returns 1), else the oid.
fn parseNextOid(in: Input, next: *usize, command: []const u8, refname: []const u8, flags: u32) ?Oid {
    const end = in.buf.len;
    const which = if (flags & PARSE_SHA1_OLD != 0) "old" else "new";
    if (next.* == end) util.die("{s} {s}: unexpected end of input when reading <{s}-oid>", .{ command, refname, which });
    var arg: util.Buf = .empty;
    if (line_term != 0) {
        const ch = in.at(next.*);
        if (ch == 0 or ch == line_term) return null;
        if (ch != ' ') util.die("{s} {s}: expected SP but got: {s}", .{ command, refname, in.cstr(next.*) });
        next.* += 1;
        parseArg(in, next, &arg);
        if (arg.items.len > 0) {
            return getOidQuiet(arg.items) orelse util.die("{s} {s}: invalid <{s}-oid>: {s}", .{ command, refname, which, arg.items });
        }
        return hash.zero;
    } else {
        if (in.at(next.*) != 0) util.die("{s} {s}: expected NUL but got: {s}", .{ command, refname, in.cstr(next.*) });
        next.* += 1;
        if (next.* == end) util.die("{s} {s}: unexpected end of input when reading <{s}-oid>", .{ command, refname, which });
        const s = in.cstr(next.*);
        util.bufAppend(&arg, s);
        next.* += s.len;
        if (arg.items.len > 0) {
            return getOidQuiet(arg.items) orelse util.die("{s} {s}: invalid <{s}-oid>: {s}", .{ command, refname, which, arg.items });
        } else if (flags & PARSE_SHA1_ALLOW_EMPTY != 0) {
            util.warn("{s} {s}: missing <new-oid>, treating as zero", .{ command, refname });
            return hash.zero;
        }
        return null;
    }
}

fn printRejected(refname: []const u8, old_oid: ?Oid, new_oid: ?Oid, old_target: ?[]const u8, new_target: ?[]const u8, e: refs.TxErr, details: []const u8) void {
    if (details.len > 0) {
        util.flushStdout();
        util.err("{s}", .{details});
    }
    const n: []const u8 = if (new_oid) |o| &hash.hex(o) else (new_target orelse "(null)");
    const o: []const u8 = if (old_oid) |x| &hash.hex(x) else (old_target orelse "(null)");
    util.outf("rejected {s} {s} {s} {s}\n", .{ refname, n, o, e.msg() });
}

fn handleTxError(t: *refs.Transaction, refname: []const u8, new_oid: ?Oid, old_oid: ?Oid, new_target: ?[]const u8, old_target: ?[]const u8, e: refs.TxErr) void {
    if (e == .ok) return;
    if (e != .generic and allow_update_failures) {
        printRejected(refname, old_oid, new_oid, old_target, new_target, e, t.errMsg());
        return;
    }
    util.die("{s}", .{t.errMsg()});
}

fn atEnd(in: Input, next: usize) bool {
    return in.at(next) == line_term;
}

fn cmdUpdate(t: *refs.Transaction, in: Input, start: usize) void {
    var next = start;
    const refname = parseRefname(in, &next) orelse util.die("update: missing <ref>", .{});
    const new_oid = parseNextOid(in, &next, "update", refname, PARSE_SHA1_ALLOW_EMPTY) orelse util.die("update {s}: missing <new-oid>", .{refname});
    const old_oid = parseNextOid(in, &next, "update", refname, PARSE_SHA1_OLD);
    if (!atEnd(in, next)) util.die("update {s}: extra input: {s}", .{ refname, in.cstr(next) });
    const e = t.update(refname, new_oid, old_oid, null, null, update_flags | create_reflog_flag, ur_msg);
    handleTxError(t, refname, new_oid, old_oid, null, null, e);
    update_flags = default_flags;
}

fn cmdSymrefUpdate(t: *refs.Transaction, in: Input, start: usize) void {
    var next = start;
    const refname = parseRefname(in, &next) orelse util.die("symref-update: missing <ref>", .{});
    const new_target = parseNextRefname(in, &next) orelse util.die("symref-update {s}: missing <new-target>", .{refname});
    var old_target: ?[]const u8 = null;
    var old_oid: ?Oid = null;
    if (parseNextArg(in, &next)) |old_arg| {
        old_target = parseNextArg(in, &next) orelse util.die("symref-update {s}: expected old value", .{refname});
        if (util.eql(old_arg, "oid")) {
            old_oid = getOidQuiet(old_target.?) orelse util.die("symref-update {s}: invalid oid: {s}", .{ refname, old_target.? });
        } else if (util.eql(old_arg, "ref")) {
            if (!refs.checkRefnameFormat(old_target.?, refs.ALLOW_ONELEVEL)) util.die("symref-update {s}: invalid ref: {s}", .{ refname, old_target.? });
        } else {
            util.die("symref-update {s}: invalid arg '{s}' for old value", .{ refname, old_arg });
        }
    }
    if (!atEnd(in, next)) util.die("symref-update {s}: extra input: {s}", .{ refname, in.cstr(next) });
    const ot: ?[]const u8 = if (old_oid != null) null else old_target;
    const e = t.update(refname, null, old_oid, new_target, ot, update_flags | create_reflog_flag, ur_msg);
    handleTxError(t, refname, null, old_oid, new_target, ot, e);
    update_flags = default_flags;
}

fn cmdCreate(t: *refs.Transaction, in: Input, start: usize) void {
    var next = start;
    const refname = parseRefname(in, &next) orelse util.die("create: missing <ref>", .{});
    const new_oid = parseNextOid(in, &next, "create", refname, 0) orelse util.die("create {s}: missing <new-oid>", .{refname});
    if (hash.isZero(new_oid)) util.die("create {s}: zero <new-oid>", .{refname});
    if (!atEnd(in, next)) util.die("create {s}: extra input: {s}", .{ refname, in.cstr(next) });
    const e = t.create(refname, new_oid, null, update_flags | create_reflog_flag, ur_msg);
    handleTxError(t, refname, new_oid, null, null, null, e);
    update_flags = default_flags;
}

fn cmdSymrefCreate(t: *refs.Transaction, in: Input, start: usize) void {
    var next = start;
    const refname = parseRefname(in, &next) orelse util.die("symref-create: missing <ref>", .{});
    const new_target = parseNextRefname(in, &next) orelse util.die("symref-create {s}: missing <new-target>", .{refname});
    if (!atEnd(in, next)) util.die("symref-create {s}: extra input: {s}", .{ refname, in.cstr(next) });
    const e = t.create(refname, null, new_target, update_flags | create_reflog_flag, ur_msg);
    handleTxError(t, refname, null, null, new_target, null, e);
    update_flags = default_flags;
}

fn cmdDelete(t: *refs.Transaction, in: Input, start: usize) void {
    var next = start;
    const refname = parseRefname(in, &next) orelse util.die("delete: missing <ref>", .{});
    const old_oid = parseNextOid(in, &next, "delete", refname, PARSE_SHA1_OLD);
    if (old_oid) |o| {
        if (hash.isZero(o)) util.die("delete {s}: zero <old-oid>", .{refname});
    }
    if (!atEnd(in, next)) util.die("delete {s}: extra input: {s}", .{ refname, in.cstr(next) });
    if (t.delete(refname, old_oid, null, update_flags, ur_msg) != .ok) util.die("{s}", .{t.errMsg()});
    update_flags = default_flags;
}

fn cmdSymrefDelete(t: *refs.Transaction, in: Input, start: usize) void {
    var next = start;
    if (update_flags & refs.F_NO_DEREF == 0) util.die("symref-delete: cannot operate with deref mode", .{});
    const refname = parseRefname(in, &next) orelse util.die("symref-delete: missing <ref>", .{});
    const old_target = parseNextRefname(in, &next);
    if (!atEnd(in, next)) util.die("symref-delete {s}: extra input: {s}", .{ refname, in.cstr(next) });
    if (t.delete(refname, null, old_target, update_flags, ur_msg) != .ok) util.die("{s}", .{t.errMsg()});
    update_flags = default_flags;
}

fn cmdVerify(t: *refs.Transaction, in: Input, start: usize) void {
    var next = start;
    const refname = parseRefname(in, &next) orelse util.die("verify: missing <ref>", .{});
    const old_oid = parseNextOid(in, &next, "verify", refname, PARSE_SHA1_OLD) orelse hash.zero;
    if (!atEnd(in, next)) util.die("verify {s}: extra input: {s}", .{ refname, in.cstr(next) });
    if (t.verify(refname, old_oid, null, update_flags) != .ok) util.die("{s}", .{t.errMsg()});
    update_flags = default_flags;
}

fn cmdSymrefVerify(t: *refs.Transaction, in: Input, start: usize) void {
    var next = start;
    if (update_flags & refs.F_NO_DEREF == 0) util.die("symref-verify: cannot operate with deref mode", .{});
    const refname = parseRefname(in, &next) orelse util.die("symref-verify: missing <ref>", .{});
    const old_target = parseNextRefname(in, &next);
    if (!atEnd(in, next)) util.die("symref-verify {s}: extra input: {s}", .{ refname, in.cstr(next) });
    const oo: ?Oid = if (old_target == null) hash.zero else null;
    if (t.verify(refname, oo, old_target, update_flags) != .ok) util.die("{s}", .{t.errMsg()});
    update_flags = default_flags;
}

fn reportOk(command: []const u8) void {
    util.outf("{s}: ok\n", .{command});
    util.flushStdout();
}

fn cmdOption(in: Input, start: usize) void {
    const s = in.buf[@min(start, in.buf.len)..];
    if (util.skipPrefix(s, "no-deref")) |rest| {
        const ch: u8 = if (rest.len > 0) rest[0] else 0;
        if (ch == line_term) {
            update_flags |= refs.F_NO_DEREF;
            return;
        }
    }
    util.die("option unknown: {s}", .{in.cstr(start)});
}

fn printAllRejected(t: *refs.Transaction) void {
    for (t.updates.items) |u| {
        if (u.rejection == .ok) continue;
        const oo: ?Oid = if (u.flags & refs.F_HAVE_OLD != 0) u.old_oid else null;
        const no: ?Oid = if (u.flags & refs.F_HAVE_NEW != 0) u.new_oid else null;
        printRejected(u.refname, oo, no, u.old_target, u.new_target, u.rejection, u.rejection_details);
    }
}

const State = enum(u8) { open = 0, started = 1, prepared = 2, closed = 3 };

const StdinCmd = struct { prefix: []const u8, args: usize, state: State };
const stdin_cmds = [_]StdinCmd{
    .{ .prefix = "update", .args = 3, .state = .open },
    .{ .prefix = "create", .args = 2, .state = .open },
    .{ .prefix = "delete", .args = 2, .state = .open },
    .{ .prefix = "verify", .args = 2, .state = .open },
    .{ .prefix = "symref-update", .args = 4, .state = .open },
    .{ .prefix = "symref-create", .args = 2, .state = .open },
    .{ .prefix = "symref-delete", .args = 2, .state = .open },
    .{ .prefix = "symref-verify", .args = 2, .state = .open },
    .{ .prefix = "option", .args = 1, .state = .open },
    .{ .prefix = "start", .args = 0, .state = .started },
    .{ .prefix = "prepare", .args = 0, .state = .prepared },
    .{ .prefix = "abort", .args = 0, .state = .closed },
    .{ .prefix = "commit", .args = 0, .state = .closed },
};

/// Simple buffered line reader on stdin that does not read ahead past what
/// is needed more than one chunk (works with pipes/fifos).
const LineReader = struct {
    buf: std.ArrayList(u8) = .empty,
    pos: usize = 0,
    eof: bool = false,

    fn fill(self: *LineReader) bool {
        if (self.eof) return false;
        var tmp: [4096]u8 = undefined;
        while (true) {
            const n = std.c.read(0, &tmp, tmp.len);
            if (n < 0) {
                if (os.errno() == 4) continue;
                self.eof = true;
                return false;
            }
            if (n == 0) {
                self.eof = true;
                return false;
            }
            self.buf.appendSlice(gpa, tmp[0..@intCast(n)]) catch util.oom();
            return true;
        }
    }

    /// Read up to and including term. Returns null at EOF with no data.
    fn getLine(self: *LineReader, term: u8) ?[]const u8 {
        while (true) {
            if (std.mem.indexOfScalarPos(u8, self.buf.items, self.pos, term)) |i| {
                const line = self.buf.items[self.pos .. i + 1];
                self.pos = i + 1;
                return util.dupe(line);
            }
            if (!self.fill()) {
                if (self.pos >= self.buf.items.len) return null;
                const line = self.buf.items[self.pos..];
                self.pos = self.buf.items.len;
                return util.dupe(line);
            }
        }
    }
};

fn updateRefsStdin() void {
    var reader = LineReader{};
    var state: State = .open;
    var t = refs.Transaction.init();
    t.allow_failures = allow_update_failures;
    while (reader.getLine(line_term)) |first| {
        var input: util.Buf = .empty;
        util.bufAppend(&input, first);
        if (input.items[0] == line_term) util.die("empty command in input", .{});
        if (isSpace(input.items[0])) util.die("whitespace before command: {s}", .{(Input{ .buf = input.items }).cstr(0)});
        var cmd: ?*const StdinCmd = null;
        for (&stdin_cmds) |*c| {
            if (!util.startsWith(input.items, c.prefix)) continue;
            const ch: u8 = if (c.args > 0) ' ' else line_term;
            const at: u8 = if (c.prefix.len < input.items.len) input.items[c.prefix.len] else 0;
            if (at != ch) continue;
            cmd = c;
            break;
        }
        const c = cmd orelse util.die("unknown command: {s}", .{(Input{ .buf = input.items }).cstr(0)});
        if (line_term == 0) {
            var j: usize = 1;
            while (j < c.args) : (j += 1) {
                const more = reader.getLine(line_term) orelse break;
                util.bufAppend(&input, more);
            }
        }
        switch (state) {
            .open, .started => {
                if (state == .started and c.state == .started) util.die("cannot restart ongoing transaction", .{});
                if (@intFromEnum(c.state) >= @intFromEnum(state)) state = c.state;
            },
            .prepared => {
                if (c.state != .closed) util.die("prepared transactions can only be closed", .{});
                state = c.state;
            },
            .closed => {
                if (c.state != .started) util.die("transaction is closed", .{});
                state = c.state;
                t = refs.Transaction.init();
                t.allow_failures = allow_update_failures;
            },
        }
        const in = Input{ .buf = input.items };
        const start = c.prefix.len + @as(usize, if (c.args > 0) 1 else 0);
        const p = c.prefix;
        if (util.eql(p, "update")) {
            cmdUpdate(t, in, start);
        } else if (util.eql(p, "create")) {
            cmdCreate(t, in, start);
        } else if (util.eql(p, "delete")) {
            cmdDelete(t, in, start);
        } else if (util.eql(p, "verify")) {
            cmdVerify(t, in, start);
        } else if (util.eql(p, "symref-update")) {
            cmdSymrefUpdate(t, in, start);
        } else if (util.eql(p, "symref-create")) {
            cmdSymrefCreate(t, in, start);
        } else if (util.eql(p, "symref-delete")) {
            cmdSymrefDelete(t, in, start);
        } else if (util.eql(p, "symref-verify")) {
            cmdSymrefVerify(t, in, start);
        } else if (util.eql(p, "option")) {
            cmdOption(in, start);
        } else if (util.eql(p, "start")) {
            if (!atEnd(in, start)) util.die("start: extra input: {s}", .{in.cstr(start)});
            reportOk("start");
        } else if (util.eql(p, "prepare")) {
            if (!atEnd(in, start)) util.die("prepare: extra input: {s}", .{in.cstr(start)});
            if (t.prepare() != .ok) util.die("prepare: {s}", .{t.errMsg()});
            reportOk("prepare");
        } else if (util.eql(p, "abort")) {
            if (!atEnd(in, start)) util.die("abort: extra input: {s}", .{in.cstr(start)});
            t.abort();
            reportOk("abort");
        } else if (util.eql(p, "commit")) {
            if (!atEnd(in, start)) util.die("commit: extra input: {s}", .{in.cstr(start)});
            if (t.commit() != .ok) util.die("commit: {s}", .{t.errMsg()});
            printAllRejected(t);
            reportOk("commit");
        }
    }
    switch (state) {
        .open => {
            if (t.commit() != .ok) util.die("{s}", .{t.errMsg()});
            printAllRejected(t);
        },
        .started, .prepared => t.abort(),
        .closed => {},
    }
}

pub fn cmdUpdateRef(args: []const []const u8) u8 {
    var delete = false;
    var no_deref = false;
    var read_stdin = false;
    var end_null = false;
    var create_reflog = false;
    var batch: i32 = 0;
    const opts = [_]po.Opt{
        po.string('m', "", &ur_msg, "reason", "reason of the update"),
        po.boolean('d', "", &delete, "delete the reference"),
        po.boolean(0, "no-deref", &no_deref, "update <refname> not the one it points to"),
        po.boolean('z', "", &end_null, "stdin has NUL-terminated arguments"),
        po.boolean(0, "stdin", &read_stdin, "read updates from stdin"),
        po.boolean(0, "create-reflog", &create_reflog, "create a reflog"),
        po.bit('0', "batch-updates", &batch, 1, "batch reference updates"),
    };
    const rest = po.parse(args[1..], &opts, &update_ref_usage, .{});
    if (ur_msg) |m| {
        if (m.len == 0) util.die("Refusing to perform update with empty message.", .{});
    }
    create_reflog_flag = if (create_reflog) refs.F_FORCE_CREATE_REFLOG else 0;
    if (no_deref) {
        default_flags = refs.F_NO_DEREF;
        update_flags = default_flags;
    }
    if (read_stdin) {
        if (delete or rest.len > 0) po.usageWithOptions(&update_ref_usage, &opts);
        if (end_null) line_term = 0;
        allow_update_failures = batch != 0;
        updateRefsStdin();
        return 0;
    } else if (batch != 0) {
        util.die("--batch-updates can only be used with --stdin", .{});
    }
    if (end_null) po.usageWithOptions(&update_ref_usage, &opts);

    var refname: []const u8 = undefined;
    var oldval: ?[]const u8 = null;
    var oid: Oid = hash.zero;
    if (delete) {
        if (rest.len < 1 or rest.len > 2) po.usageWithOptions(&update_ref_usage, &opts);
        refname = rest[0];
        if (rest.len > 1) oldval = rest[1];
    } else {
        if (rest.len < 2 or rest.len > 3) po.usageWithOptions(&update_ref_usage, &opts);
        refname = rest[0];
        if (rest.len > 2) oldval = rest[2];
        oid = getOidQuiet(rest[1]) orelse util.die("{s}: not a valid SHA1", .{rest[1]});
    }
    var oldoid: ?Oid = null;
    if (oldval) |ov| {
        if (ov.len == 0) {
            oldoid = hash.zero;
        } else {
            oldoid = getOidQuiet(ov) orelse util.die("{s}: not a valid old SHA1", .{ov});
        }
    }
    if (delete) {
        const o: ?Oid = if (oldoid != null and !hash.isZero(oldoid.?)) oldoid else null;
        refs.deleteRef(refname, o, default_flags, ur_msg) catch {
            util.err("{s}", .{refs.last_error});
            return 1;
        };
        return 0;
    }
    refs.updateOrDie(ur_msg orelse "", refname, oid, oldoid, default_flags | create_reflog_flag);
    return 0;
}

// =====================================================================
// symbolic-ref
// =====================================================================

const symref_usage = [_][]const u8{
    "git symbolic-ref [-m <reason>] <name> <ref>",
    "git symbolic-ref [-q] [--short] [--no-recurse] <name>",
    "git symbolic-ref --delete [-q] <name>",
};

fn checkSymref(name: []const u8, quiet: bool, shorten: bool, recurse: bool, print: bool) u8 {
    var refname: []const u8 = name;
    var is_sym = false;
    if (recurse) {
        const r = refs.resolveFull(name, false);
        if (r.broken) util.die("No such ref: {s}", .{name});
        refname = r.name;
        is_sym = r.flags & refs.REF_ISSYMREF != 0;
    } else {
        if (!refs.checkRefnameFormat(name, refs.ALLOW_ONELEVEL) and !refs.refnameIsSafe(name)) util.die("No such ref: {s}", .{name});
        switch (refs.readRawFull(name)) {
            .symref => |t| {
                refname = t;
                is_sym = true;
            },
            .broken => util.die("No such ref: {s}", .{name}),
            else => {},
        }
    }
    if (!is_sym) {
        if (!quiet) util.die("ref {s} is not a symbolic ref", .{name});
        return 1;
    }
    if (print) {
        if (shorten) refname = refs.shortenUnambiguousStrict(refname, false);
        util.outf("{s}\n", .{refname});
    }
    return 0;
}

pub fn cmdSymbolicRef(args: []const []const u8) u8 {
    var quiet: i32 = 0;
    var delete = false;
    var shorten = false;
    var recurse = true;
    var msg: ?[]const u8 = null;
    const opts = [_]po.Opt{
        .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet, .val = -1, .help = "suppress error message for non-symbolic (detached) refs" },
        po.boolean('d', "delete", &delete, "delete symbolic ref"),
        po.boolean(0, "short", &shorten, "shorten ref output"),
        po.boolean(0, "recurse", &recurse, "recursively dereference (default)"),
        po.string('m', "", &msg, "reason", "reason of the update"),
    };
    const rest = po.parse(args[1..], &opts, &symref_usage, .{});
    if (msg) |m| {
        if (m.len == 0) util.die("Refusing to perform update with empty message", .{});
    }
    if (delete) {
        if (rest.len != 1) po.usageWithOptions(&symref_usage, &opts);
        if (checkSymref(rest[0], true, false, false, false) != 0) util.die("Cannot delete {s}, not a symbolic ref", .{rest[0]});
        if (util.eql(rest[0], "HEAD")) util.die("deleting '{s}' is not allowed", .{rest[0]});
        refs.deleteRef(rest[0], null, refs.F_NO_DEREF, null) catch {
            util.err("{s}", .{refs.last_error});
            return 1;
        };
        return 0;
    }
    switch (rest.len) {
        1 => return checkSymref(rest[0], quiet != 0, shorten, recurse, true),
        2 => {
            if (util.eql(rest[0], "HEAD") and !util.startsWith(rest[1], "refs/")) util.die("Refusing to point HEAD outside of refs/", .{});
            if (!refs.checkRefnameFormat(rest[1], refs.ALLOW_ONELEVEL)) util.die("Refusing to set '{s}' to invalid ref '{s}'", .{ rest[0], rest[1] });
            refs.writeSymref(rest[0], rest[1], msg) catch {
                util.err("{s}", .{refs.last_error});
                return 1;
            };
            return 0;
        },
        else => po.usageWithOptions(&symref_usage, &opts),
    }
}

// =====================================================================
// show-ref
// =====================================================================

const show_ref_usage = [_][]const u8{
    "git show-ref [--head] [-d | --dereference]\n" ++
        "             [-s | --hash[=<n>]] [--abbrev[=<n>]] [--branches] [--tags]\n" ++
        "             [--] [<pattern>...]",
    "git show-ref --verify [-q | --quiet] [-d | --dereference]\n" ++
        "             [-s | --hash[=<n>]] [--abbrev[=<n>]]\n" ++
        "             [--] [<ref>...]",
    "git show-ref --exclude-existing[=<pattern>]",
    "git show-ref --exists <ref>",
};

var sr_quiet: i32 = 0;
var sr_hash_only = false;
var sr_abbrev: usize = 0;
var sr_deref = false;
var sr_exclude_enabled = false;
var sr_exclude_pattern: ?[]const u8 = null;
var sr_opts_ptr: []const po.Opt = &.{};

fn parseAbbrevArg(arg: []const u8, optname: []const u8) usize {
    const v = std.fmt.parseInt(i64, arg, 10) catch {
        util.err("option `{s}' expects a numerical value", .{optname});
        po.usageExit(&show_ref_usage, sr_opts_ptr, true);
    };
    if (v == 0) return 0;
    if (v < 4) return 4;
    if (v > 40) return 40;
    return @intCast(v);
}

fn hashCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    sr_hash_only = true;
    if (arg) |a| sr_abbrev = parseAbbrevArg(a, "hash");
}

fn abbrevCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        sr_abbrev = 0;
        return;
    }
    if (arg) |a| {
        sr_abbrev = parseAbbrevArg(a, "abbrev");
    } else sr_abbrev = revparse.defaultAbbrev();
}

fn excludeExistingCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    sr_exclude_enabled = true;
    sr_exclude_pattern = arg;
}

fn abbrevHex(oid: Oid, n: usize) []const u8 {
    if (n == 0 or n >= 40) return hash.hexAlloc(oid);
    return revparse.abbrev(oid, n);
}

fn peeledOid(oid: Oid, packed_peeled: ?Oid) ?Oid {
    if (packed_peeled) |p| return p;
    const t = repo_mod.repo().odb().readType(oid) orelse return null;
    if (t != .tag) return null;
    const p = objects.peel(oid) orelse return null;
    return p.oid;
}

fn showOne(name: []const u8, oid: Oid, packed_peeled: ?Oid) void {
    if (!repo_mod.repo().odb().has(oid)) util.die("git show-ref: bad ref {s} ({s})", .{ name, hash.hex(oid) });
    if (sr_quiet != 0) return;
    const hex = abbrevHex(oid, sr_abbrev);
    if (sr_hash_only) {
        util.outf("{s}\n", .{hex});
    } else util.outf("{s} {s}\n", .{ hex, name });
    if (!sr_deref) return;
    if (peeledOid(oid, packed_peeled)) |p| {
        util.outf("{s} {s}^{{}}\n", .{ abbrevHex(p, sr_abbrev), name });
    }
}

fn showRefMatches(name: []const u8, patterns: []const []const u8) bool {
    if (patterns.len == 0) return true;
    for (patterns) |m| {
        if (m.len > name.len) continue;
        if (!util.endsWith(name, m)) continue;
        if (m.len == name.len) return true;
        if (name[name.len - m.len - 1] == '/') return true;
    }
    return false;
}

fn excludeExisting() u8 {
    var existing = std.StringHashMap(void).init(gpa);
    for (refs.iterate("refs/", .{})) |r| existing.put(r.name, {}) catch util.oom();
    const data = os.readAllFd(0) catch "";
    const pattern = sr_exclude_pattern;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        if (it.index == null and line0.len == 0) break;
        var line = line0;
        if (util.endsWith(line, "^{}")) line = line[0 .. line.len - 3];
        var start = line.len;
        while (start > 0 and !isSpace(line[start - 1])) start -= 1;
        const ref = line[start..];
        if (pattern) |p| {
            if (ref.len < p.len) continue;
            if (!util.startsWith(ref, p)) continue;
        }
        if (!refs.checkRefnameFormat(ref, 0)) {
            util.warn("ref '{s}' ignored", .{ref});
            continue;
        }
        if (!existing.contains(ref)) util.outf("{s}\n", .{line});
    }
    return 0;
}

fn rawExists(ref: []const u8) u8 {
    switch (refs.readRawFull(ref)) {
        .oid, .symref => return 0,
        .missing, .isdir => {
            util.err("reference does not exist", .{});
            return 2;
        },
        .broken => {
            util.err("failed to look up reference: Invalid argument", .{});
            return 1;
        },
    }
}

pub fn cmdShowRef(args: []const []const u8) u8 {
    var tags_only = false;
    var branches_only = false;
    var exists = false;
    var verify = false;
    var show_head = false;
    const opts = [_]po.Opt{
        po.boolean(0, "tags", &tags_only, "only show tags (can be combined with --branches)"),
        po.boolean(0, "branches", &branches_only, "only show branches (can be combined with --tags)"),
        .{ .long = "heads", .kind = .boolean, .b = &branches_only, .hidden = true, .help = "deprecated synonym for --branches" },
        po.boolean(0, "exists", &exists, "check for reference existence without resolving"),
        po.boolean(0, "verify", &verify, "stricter reference checking, requires exact ref path"),
        .{ .short = 'h', .kind = .boolean, .b = &show_head, .hidden = true, .help = "show the HEAD reference, even if it would be filtered out" },
        po.boolean(0, "head", &show_head, "show the HEAD reference, even if it would be filtered out"),
        po.boolean('d', "dereference", &sr_deref, "dereference tags into object IDs"),
        .{ .short = 's', .long = "hash", .kind = .callback, .cb = hashCb, .optarg = true, .argh = "n", .help = "only show SHA1 hash using <n> digits" },
        .{ .long = "abbrev", .kind = .callback, .cb = abbrevCb, .optarg = true, .argh = "n", .help = "use <n> digits to display object names" },
        .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &sr_quiet, .val = -1, .help = "do not print results to stdout (useful with --verify)" },
        .{ .long = "exclude-existing", .kind = .callback, .cb = excludeExistingCb, .optarg = true, .noneg = true, .argh = "pattern", .help = "show refs from stdin that aren't in local repository" },
    };
    sr_opts_ptr = &opts;
    const rest = po.parse(args[1..], &opts, &show_ref_usage, .{});
    {
        var names: std.ArrayList([]const u8) = .empty;
        if (sr_exclude_enabled) names.append(gpa, "--exclude-existing") catch util.oom();
        if (verify) names.append(gpa, "--verify") catch util.oom();
        if (exists) names.append(gpa, "--exists") catch util.oom();
        if (names.items.len == 3) util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ names.items[0], names.items[1], names.items[2] });
        if (names.items.len == 2) po.dieExclusive(names.items[0], names.items[1]);
    }
    if (sr_exclude_enabled) return excludeExisting();
    if (verify) {
        if (rest.len == 0) util.die("--verify requires a reference", .{});
        for (rest) |r| {
            var ok = false;
            if (util.startsWith(r, "refs/") or refs.refnameIsSafe(r)) {
                const res = refs.resolveFull(r, true);
                if (!res.broken) {
                    showOne(r, res.oid, null);
                    ok = true;
                }
            }
            if (!ok) {
                if (sr_quiet == 0) util.die("'{s}' - not a valid ref", .{r});
                return 1;
            }
        }
        return 0;
    }
    if (exists) {
        if (rest.len == 0) util.die("--exists requires a reference", .{});
        if (rest.len > 1) util.die("--exists requires exactly one reference", .{});
        return rawExists(rest[0]);
    }
    var found: usize = 0;
    if (show_head) {
        const res = refs.resolveFull("HEAD", true);
        if (!res.broken) {
            found += 1;
            showOne("HEAD", res.oid, null);
        }
    }
    var lists: std.ArrayList([]refs.Ref) = .empty;
    if (branches_only or tags_only) {
        if (branches_only) lists.append(gpa, refs.iterate("refs/heads/", .{ .include_broken = true, .check_objects = false })) catch util.oom();
        if (tags_only) lists.append(gpa, refs.iterate("refs/tags/", .{ .include_broken = true, .check_objects = false })) catch util.oom();
    } else lists.append(gpa, refs.iterate("refs/", .{ .include_broken = true, .check_objects = false })) catch util.oom();
    for (lists.items) |l| {
        for (l) |r| {
            // GIT_REF_PARANOIA: broken refs are included, dangling symrefs omitted
            if (r.flags & refs.REF_ISSYMREF != 0 and r.flags & refs.REF_ISBROKEN != 0) continue;
            if (!showRefMatches(r.name, rest)) continue;
            found += 1;
            showOne(r.name, r.oid, r.peeled);
        }
    }
    return if (found == 0) 1 else 0;
}

// =====================================================================
// check-ref-format
// =====================================================================

const crf_usage = "usage: git check-ref-format [--normalize] [<options>] <refname>\n   or: git check-ref-format --branch <branchname-shorthand>\n";

fn collapseSlashes(s: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var prev: u8 = '/';
    for (s) |ch| {
        if (prev == '/' and ch == prev) continue;
        util.bufByte(&b, ch);
        prev = ch;
    }
    return b.items;
}

/// check_branch_ref: returns the full ref name or null if invalid.
pub fn checkBranchRef(name: []const u8) struct { ok: bool, full: []const u8 } {
    var expanded = name;
    if (repo_mod.repo_ != null) expanded = @import("../reffilter.zig").copyBranchname(name, @import("../reffilter.zig").INTERPRET_BRANCH_LOCAL);
    const full = util.concat(&.{ "refs/heads/", expanded });
    if ((name.len > 0 and name[0] == '-') or util.eql(full, "refs/heads/HEAD")) return .{ .ok = false, .full = full };
    return .{ .ok = refs.checkRefnameFormat(full, 0), .full = full };
}

pub fn cmdCheckRefFormat(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.out(crf_usage);
        return 0;
    }
    if (args.len == 3 and util.eql(args[1], "--branch")) {
        const r = checkBranchRef(args[2]);
        const name = util.skipPrefix(r.full, "refs/heads/");
        if (!r.ok or name == null) util.die("'{s}' is not a valid branch name", .{args[2]});
        util.outf("{s}\n", .{name.?});
        return 0;
    }
    var normalize = false;
    var flags: u32 = 0;
    var i: usize = 1;
    while (i < args.len and args[i].len > 0 and args[i][0] == '-') : (i += 1) {
        const a = args[i];
        if (util.eql(a, "--normalize") or util.eql(a, "--print")) {
            normalize = true;
        } else if (util.eql(a, "--allow-onelevel")) {
            flags |= refs.ALLOW_ONELEVEL;
        } else if (util.eql(a, "--no-allow-onelevel")) {
            flags &= ~refs.ALLOW_ONELEVEL;
        } else if (util.eql(a, "--refspec-pattern")) {
            flags |= refs.REFSPEC_PATTERN;
        } else {
            util.ewrite(crf_usage);
            return 129;
        }
    }
    if (i != args.len - 1) {
        util.ewrite(crf_usage);
        return 129;
    }
    var refname = args[i];
    if (normalize) refname = collapseSlashes(refname);
    if (!refs.checkRefnameFormat(refname, flags)) return 1;
    if (normalize) util.outf("{s}\n", .{refname});
    return 0;
}

// =====================================================================
// pack-refs / refs optimize
// =====================================================================

fn packRefsCore(args: []const []const u8, usage: []const []const u8) u8 {
    var all = false;
    var flags: i32 = 1; // PRUNE
    var includes: std.ArrayList([]const u8) = .empty;
    var excludes: std.ArrayList([]const u8) = .empty;
    const opts = [_]po.Opt{
        po.boolean(0, "all", &all, "pack everything"),
        po.bit(0, "prune", &flags, 1, "prune loose refs (default)"),
        po.bit(0, "auto", &flags, 2, "auto-pack refs as needed"),
        po.list(0, "include", &includes, "pattern", "references to include"),
        po.list(0, "exclude", &excludes, "pattern", "references to exclude"),
    };
    const rest = po.parse(args, &opts, usage, .{});
    if (rest.len > 0) po.usageWithOptions(usage, &opts);
    if (all) includes.append(gpa, "*") catch util.oom();
    if (includes.items.len == 0) includes.append(gpa, "refs/tags/*") catch util.oom();
    _ = refs.packRefs(.{ .includes = includes.items, .excludes = excludes.items, .prune = flags & 1 != 0, .auto = flags & 2 != 0 });
    return 0;
}

pub fn cmdPackRefs(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git pack-refs [--all] [--no-prune] [--auto] [--include <pattern>] [--exclude <pattern>]"};
    return packRefsCore(args[1..], &usage);
}

// =====================================================================
// reflog
// =====================================================================

const reflog_show_usage_s = "git reflog [show] [<log-options>] [<ref>]";
const reflog_list_usage_s = "git reflog list";
const reflog_exists_usage_s = "git reflog exists <ref>";
const reflog_write_usage_s = "git reflog write <ref> <old-oid> <new-oid> <message>";
const reflog_delete_usage_s = "git reflog delete [--rewrite] [--updateref]\n" ++
    "                  [--dry-run | -n] [--verbose] <ref>@{<specifier>}...";
const reflog_drop_usage_s = "git reflog drop [--all [--single-worktree] | <refs>...]";
const reflog_expire_usage_s = "git reflog expire [--expire=<time>] [--expire-unreachable=<time>]\n" ++
    "                  [--rewrite] [--updateref] [--stale-fix]\n" ++
    "                  [--dry-run | -n] [--verbose] [--all [--single-worktree] | <refs>...]";
const reflog_usage = [_][]const u8{
    reflog_show_usage_s,
    reflog_list_usage_s,
    reflog_exists_usage_s,
    reflog_write_usage_s,
    reflog_delete_usage_s,
    reflog_drop_usage_s,
    reflog_expire_usage_s,
};

fn reflogShow(args: []const []const u8) u8 {
    const commands = @import("../commands.zig");
    var l: std.ArrayList([]const u8) = .empty;
    l.appendSlice(gpa, &.{ "-g", "--abbrev-commit", "--pretty=oneline" }) catch util.oom();
    l.appendSlice(gpa, args) catch util.oom();
    if (commands.find("log") == null) {
        util.die("reflog show requires 'git log', which is not available", .{});
    }
    return commands.dispatchName("log", l.items);
}

/// repo_dwim_log: find the reflog for a (short) ref name.
pub fn dwimLog(str0: []const u8) ?[]const u8 {
    var str = str0;
    if (util.eql(str, "@")) str = "HEAD";
    if (util.startsWith(str, "@{-")) {
        const b = revparse.interpretBranchName(str);
        if (!util.eql(b, str)) str = util.concat(&.{ "refs/heads/", b });
    }
    const rules = [_][]const u8{ "{s}", "refs/{s}", "refs/tags/{s}", "refs/heads/{s}", "refs/remotes/{s}", "refs/remotes/{s}/HEAD" };
    inline for (rules) |rule| {
        const path = util.fmt(rule, .{str});
        const r = refs.resolveFull(path, true);
        if (!r.broken) {
            if (refs.reflogExists(path)) return path;
            if (!util.eql(r.name, path) and refs.reflogExists(r.name)) return r.name;
        }
    }
    return null;
}

const ExpireOpts = struct {
    expire_total: i64 = 0,
    expire_unreachable: i64 = 0,
    stalefix: bool = false,
    recno: i64 = 0,
    rewrite: bool = false,
    updateref: bool = false,
    dry_run: bool = false,
    verbose: bool = false,
};

fn identTimestamp(id: []const u8) i64 {
    const gt = std.mem.lastIndexOfScalar(u8, id, '>') orelse return 0;
    const rest = util.trim(id[gt + 1 ..]);
    const sp = std.mem.indexOfScalar(u8, rest, ' ') orelse rest.len;
    return std.fmt.parseInt(i64, rest[0..sp], 10) catch 0;
}

fn markReachable(set: *hash.OidSet, tips: []const Oid) void {
    var stack: std.ArrayList(Oid) = .empty;
    stack.appendSlice(gpa, tips) catch util.oom();
    while (stack.pop()) |o| {
        if (set.contains(o)) continue;
        set.put(gpa, o, {}) catch util.oom();
        const c = objects.readCommit(o) orelse continue;
        for (c.parents) |p| {
            if (!set.contains(p)) stack.append(gpa, p) catch util.oom();
        }
    }
}

fn commitComplete(oid: Oid) bool {
    if (hash.isZero(oid)) return true;
    const p = objects.peelTo(oid, .commit) orelse return false;
    const c = objects.readCommit(p) orelse return false;
    return repo_mod.repo().odb().has(c.tree);
}

/// reftable_be_reflog_expire(): pruned entries get tombstones, kept ones are
/// rewritten in place (with --rewrite, old ids are backfilled).
fn expireReflogReftable(refname: []const u8, o: *ExpireOpts) u8 {
    if (!refs.reflogExists(refname)) return 0;
    var tip: Oid = hash.zero;
    switch (refs.readRawFull(refname)) {
        .oid => |x| tip = x,
        else => {},
    }
    const entries = refs.readReflog(refname);
    const is_head = util.eql(refname, "HEAD") or util.endsWith(refname, "/HEAD") and util.startsWith(refname, "worktrees/");
    const Kind = enum { always, normal, head };
    var kind: Kind = undefined;
    var tip_commit: ?Oid = null;
    if (o.expire_unreachable == 0 or is_head) {
        kind = .head;
    } else {
        tip_commit = if (hash.isZero(tip)) null else objects.peelTo(tip, .commit);
        kind = if (tip_commit != null) .normal else .always;
    }
    if (o.expire_unreachable <= o.expire_total) kind = .always;
    var reachable: hash.OidSet = .{};
    switch (kind) {
        .always => {},
        .head => {
            var tips: std.ArrayList(Oid) = .empty;
            for (refs.iterate("refs/", .{ .check_objects = false })) |r| {
                if (r.flags & refs.REF_ISSYMREF != 0) continue;
                if (objects.peelTo(r.oid, .commit)) |cc| tips.append(gpa, cc) catch util.oom();
            }
            if (refs.resolve("HEAD")) |h| {
                if (objects.peelTo(h.oid, .commit)) |cc| tips.append(gpa, cc) catch util.oom();
            }
            markReachable(&reachable, tips.items);
        },
        .normal => markReachable(&reachable, &.{tip_commit.?}),
    }
    const Unreach = struct {
        fn check(set: *hash.OidSet, oid: Oid) bool {
            if (hash.isZero(oid)) return false;
            const c = objects.peelTo(oid, .commit) orelse return false;
            return !set.contains(c);
        }
    };
    var kept: std.ArrayList(refs.ReflogEntry) = .empty;
    var last_kept: ?Oid = null;
    for (entries) |e| {
        const ts = identTimestamp(e.ident);
        var expire = false;
        if (ts < o.expire_total) {
            expire = true;
        } else if (o.stalefix and (!commitComplete(e.old) or !commitComplete(e.new))) {
            expire = true;
        } else if (ts < o.expire_unreachable and (kind == .always or Unreach.check(&reachable, e.old) or Unreach.check(&reachable, e.new))) {
            expire = true;
        } else if (o.recno != 0) {
            o.recno -= 1;
            if (o.recno == 0) expire = true;
        }
        if (o.verbose) {
            if (!expire) {
                util.outf("keep {s}\n", .{e.msg});
            } else if (o.dry_run) {
                util.outf("would prune {s}\n", .{e.msg});
            } else util.outf("prune {s}\n", .{e.msg});
        }
        if (expire) continue;
        var k = e;
        if (o.rewrite) {
            if (last_kept) |lk| k.old = lk;
        }
        util.append(refs.ReflogEntry, &kept, k);
        last_kept = e.new;
    }
    if (o.dry_run) return 0;
    const update_oid: ?Oid = if (o.updateref and last_kept != null and !hash.isZero(tip)) last_kept else null;
    return if (@import("../reftable_backend.zig").rewriteReflog(refname, kept.items, update_oid)) 0 else 1;
}

fn expireReflog(refname: []const u8, o: *ExpireOpts) u8 {
    if (refs.isReftable()) return expireReflogReftable(refname, o);
    const path = refs.refPath(refname);
    const lockfile = @import("../lockfile.zig");
    _ = os.mkdirLeading(path);
    const ref_lock = switch (lockfile.tryLock(path)) {
        .ok => |l| l,
        .err => |e| {
            util.err("cannot lock ref '{s}': {s}", .{ refname, lockfile.lockMessage(path, e) });
            return 1;
        },
    };
    defer ref_lock.rollback();
    if (!refs.reflogExists(refname)) return 0;
    var tip: Oid = hash.zero;
    switch (refs.readRawFull(refname)) {
        .oid => |x| tip = x,
        else => {},
    }
    const entries = refs.readReflog(refname);
    // prepare
    const Kind = enum { always, normal, head };
    var kind: Kind = undefined;
    const is_head = util.eql(refname, "HEAD") or util.endsWith(refname, "/HEAD") and util.startsWith(refname, "worktrees/");
    var tip_commit: ?Oid = null;
    if (o.expire_unreachable == 0 or is_head) {
        kind = .head;
    } else {
        tip_commit = if (hash.isZero(tip)) null else objects.peelTo(tip, .commit);
        kind = if (tip_commit != null) .normal else .always;
    }
    if (o.expire_unreachable <= o.expire_total) kind = .always;
    var reachable: hash.OidSet = .{};
    switch (kind) {
        .always => {},
        .head => {
            var tips: std.ArrayList(Oid) = .empty;
            for (refs.iterate("refs/", .{ .check_objects = false })) |r| {
                if (r.flags & refs.REF_ISSYMREF != 0) continue;
                if (objects.peelTo(r.oid, .commit)) |cc| tips.append(gpa, cc) catch util.oom();
            }
            if (refs.resolve("HEAD")) |h| {
                if (objects.peelTo(h.oid, .commit)) |cc| tips.append(gpa, cc) catch util.oom();
            }
            markReachable(&reachable, tips.items);
        },
        .normal => markReachable(&reachable, &.{tip_commit.?}),
    }
    const Unreach = struct {
        fn check(set: *hash.OidSet, oid: Oid) bool {
            if (hash.isZero(oid)) return false;
            const c = objects.peelTo(oid, .commit) orelse return false;
            return !set.contains(c);
        }
    };
    var out: util.Buf = .empty;
    var last_kept: Oid = hash.zero;
    for (entries) |e| {
        const ooid = if (o.rewrite) last_kept else e.old;
        const ts = identTimestamp(e.ident);
        var expire = false;
        if (ts < o.expire_total) {
            expire = true;
        } else if (o.stalefix and (!commitComplete(ooid) or !commitComplete(e.new))) {
            expire = true;
        } else if (ts < o.expire_unreachable and (kind == .always or Unreach.check(&reachable, ooid) or Unreach.check(&reachable, e.new))) {
            expire = true;
        } else if (o.recno != 0) {
            o.recno -= 1;
            if (o.recno == 0) expire = true;
        }
        if (o.verbose) {
            if (!expire) {
                util.outf("keep {s}\n", .{e.msg});
            } else if (o.dry_run) {
                util.outf("would prune {s}\n", .{e.msg});
            } else util.outf("prune {s}\n", .{e.msg});
        }
        if (expire or o.dry_run) continue;
        util.bufPrint(&out, "{s} {s} {s}\t{s}\n", .{ hash.hex(ooid), hash.hex(e.new), e.ident, e.msg });
        last_kept = e.new;
    }
    if (o.dry_run) return 0;
    const lp = refs.reflogPath(refname);
    const log_lock = switch (lockfile.tryLock(lp)) {
        .ok => |l| l,
        .err => |e| {
            util.err("{s}", .{lockfile.lockMessage(lp, e)});
            return 1;
        },
    };
    log_lock.write(out.items);
    var update = false;
    if (o.updateref and !hash.isZero(last_kept)) {
        switch (refs.readRawFull(refname)) {
            .oid => update = true,
            else => {},
        }
    }
    if (update) ref_lock.write(util.concat(&.{ &hash.hex(last_kept), "\n" }));
    if (!log_lock.commit()) {
        util.err("unable to write reflog '{s}' ({s})", .{ lp, os.lastErr() });
        return 1;
    }
    if (update) {
        if (!ref_lock.commit()) {
            util.err("couldn't set {s}", .{refname});
            return 1;
        }
    }
    return 0;
}

const ExpireCfg = struct {
    default_total: i64,
    default_unreach: i64,
    pats: std.ArrayList(struct { pattern: []const u8, total: ?i64 = null, unreach: ?i64 = null }) = .empty,
};

fn loadExpireCfg(now: i64) ExpireCfg {
    var c = ExpireCfg{ .default_total = now - 30 * 24 * 3600 * 3, .default_unreach = now - 30 * 24 * 3600 };
    const cfg = repo_mod.cfg;
    if (cfg.get("gc.reflogexpire")) |v| c.default_total = date.parseExpiryDate(v) orelse util.die("'{s}' for 'gc.reflogexpire' is not a valid timestamp", .{v});
    if (cfg.get("gc.reflogexpireunreachable")) |v| c.default_unreach = date.parseExpiryDate(v) orelse util.die("'{s}' for 'gc.reflogexpireunreachable' is not a valid timestamp", .{v});
    for (cfg.entries.items) |e| {
        const key = e.key;
        if (!util.startsWith(key, "gc.")) continue;
        const last_dot = std.mem.lastIndexOfScalar(u8, key, '.') orelse continue;
        if (last_dot <= 3) continue;
        const sub = key[3..last_dot];
        const var_name = key[last_dot + 1 ..];
        const is_total = util.eql(var_name, "reflogexpire");
        const is_unreach = util.eql(var_name, "reflogexpireunreachable");
        if (!is_total and !is_unreach) continue;
        const v = e.value orelse continue;
        const t = date.parseExpiryDate(v) orelse continue;
        var found: ?usize = null;
        for (c.pats.items, 0..) |p, i| {
            if (util.eql(p.pattern, sub)) found = i;
        }
        if (found == null) {
            c.pats.append(gpa, .{ .pattern = sub }) catch util.oom();
            found = c.pats.items.len - 1;
        }
        if (is_total) c.pats.items[found.?].total = t else c.pats.items[found.?].unreach = t;
    }
    return c;
}

fn setExpireForRef(o: *ExpireOpts, c: *const ExpireCfg, explicit_total: bool, explicit_unreach: bool, ref: []const u8) void {
    if (explicit_total and explicit_unreach) return;
    for (c.pats.items) |p| {
        if (wildmatch.match(p.pattern, ref, 0)) {
            if (!explicit_total) o.expire_total = p.total orelse 0;
            if (!explicit_unreach) o.expire_unreachable = p.unreach orelse 0;
            return;
        }
    }
    if (util.eql(ref, "refs/stash")) {
        if (!explicit_total) o.expire_total = 0;
        if (!explicit_unreach) o.expire_unreachable = 0;
        return;
    }
    if (!explicit_total) o.expire_total = c.default_total;
    if (!explicit_unreach) o.expire_unreachable = c.default_unreach;
}

var rx_expire_total: ?i64 = null;
var rx_expire_unreach: ?i64 = null;

fn expireTotalCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    rx_expire_total = date.parseExpiryDate(arg.?) orelse util.die("invalid timestamp '{s}' given to '--expire'", .{arg.?});
}
fn expireUnreachCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    rx_expire_unreach = date.parseExpiryDate(arg.?) orelse util.die("invalid timestamp '{s}' given to '--expire-unreachable'", .{arg.?});
}

fn reflogExpire(args: []const []const u8) u8 {
    var flags: i32 = 0;
    var verbose = false;
    var stalefix = false;
    var do_all = false;
    var single_wt = false;
    const usage = [_][]const u8{reflog_expire_usage_s};
    const opts = [_]po.Opt{
        po.bit('n', "dry-run", &flags, 1, "do not actually prune any entries"),
        po.bit(0, "rewrite", &flags, 2, "rewrite the old SHA1 with the new SHA1 of the entry that now precedes it"),
        po.bit(0, "updateref", &flags, 4, "update the reference to the value of the top reflog entry"),
        po.boolean(0, "verbose", &verbose, "print extra information on screen"),
        .{ .long = "expire", .kind = .callback, .cb = expireTotalCb, .noneg = true, .argh = "timestamp", .help = "prune entries older than the specified time" },
        .{ .long = "expire-unreachable", .kind = .callback, .cb = expireUnreachCb, .noneg = true, .argh = "timestamp", .help = "prune entries older than <time> that are not reachable from the current tip of the branch" },
        po.boolean(0, "stale-fix", &stalefix, "prune any reflog entries that point to broken commits"),
        po.boolean(0, "all", &do_all, "process the reflogs of all references"),
        po.boolean(0, "single-worktree", &single_wt, "limits processing to reflogs from the current worktree only"),
    };
    const now = os.now();
    const cfg = loadExpireCfg(now);
    const rest = po.parse(args, &opts, &usage, .{});
    if (verbose and stalefix) {
        util.out("Marking reachable objects...");
        util.out("\n");
    }
    var status: u8 = 0;
    const base = ExpireOpts{
        .expire_total = rx_expire_total orelse cfg.default_total,
        .expire_unreachable = rx_expire_unreach orelse cfg.default_unreach,
        .stalefix = stalefix,
        .dry_run = flags & 1 != 0,
        .rewrite = flags & 2 != 0,
        .updateref = flags & 4 != 0,
        .verbose = verbose,
    };
    if (do_all) {
        for (refs.listReflogs()) |name| {
            var o = base;
            setExpireForRef(&o, &cfg, rx_expire_total != null, rx_expire_unreach != null, name);
            status |= expireReflog(name, &o);
        }
    }
    for (rest) |a| {
        const ref = dwimLog(a) orelse {
            util.err("reflog could not be found: '{s}'", .{a});
            status |= 1;
            continue;
        };
        var o = base;
        setExpireForRef(&o, &cfg, rx_expire_total != null, rx_expire_unreach != null, ref);
        status |= expireReflog(ref, &o);
    }
    return status;
}

fn reflogDeleteOne(rev: []const u8, flags: i32, verbose: bool) u8 {
    const at = std.mem.indexOf(u8, rev, "@{") orelse {
        util.err("not a reflog: {s}", .{rev});
        return 1;
    };
    const ref = dwimLog(rev[0..at]) orelse {
        util.err("no reflog for '{s}'", .{rev});
        return 1;
    };
    const spec = rev[at + 2 ..];
    var o = ExpireOpts{
        .dry_run = flags & 1 != 0,
        .rewrite = flags & 2 != 0,
        .updateref = flags & 4 != 0,
        .verbose = verbose,
    };
    const entries = refs.readReflog(ref);
    var digits: usize = 0;
    while (digits < spec.len and std.ascii.isDigit(spec[digits])) digits += 1;
    if (digits < spec.len and spec[digits] == '}') {
        const n = std.fmt.parseInt(i64, spec[0..digits], 10) catch 0;
        o.recno = @as(i64, @intCast(entries.len)) - n;
        if (o.recno <= 0) o.recno = 0;
        // recno==0 means "no record-based deletion"; C uses unsigned
        // wrap-around semantics which never hit zero in that case.
    } else {
        const end = std.mem.indexOfScalar(u8, spec, '}') orelse spec.len;
        const t = date.approxidate(spec[0..end]);
        var cnt: i64 = 0;
        for (entries) |e| {
            if (t == 0 or identTimestamp(e.ident) < t) cnt += 1;
        }
        o.recno = cnt;
    }
    if (o.recno == 0) return 0;
    return expireReflog(ref, &o);
}

fn reflogDelete(args: []const []const u8) u8 {
    var flags: i32 = 0;
    var verbose = false;
    const usage = [_][]const u8{reflog_delete_usage_s};
    const opts = [_]po.Opt{
        po.bit('n', "dry-run", &flags, 1, "do not actually prune any entries"),
        po.bit(0, "rewrite", &flags, 2, "rewrite the old SHA1 with the new SHA1 of the entry that now precedes it"),
        po.bit(0, "updateref", &flags, 4, "update the reference to the value of the top reflog entry"),
        po.boolean(0, "verbose", &verbose, "print extra information on screen"),
    };
    const rest = po.parse(args, &opts, &usage, .{});
    if (rest.len < 1) {
        util.err("no reflog specified to delete", .{});
        return 1;
    }
    var status: u8 = 0;
    for (rest) |r| status |= reflogDeleteOne(r, flags, verbose);
    return status;
}

fn reflogDrop(args: []const []const u8) u8 {
    var do_all = false;
    var single_wt = false;
    const usage = [_][]const u8{reflog_drop_usage_s};
    const opts = [_]po.Opt{
        po.boolean(0, "all", &do_all, "drop the reflogs of all references"),
        po.boolean(0, "single-worktree", &single_wt, "drop reflogs from the current worktree only"),
    };
    const rest = po.parse(args, &opts, &usage, .{});
    if (rest.len > 0 and do_all) util.usageDie("usage: references specified along with --all", .{});
    var ret: u8 = 0;
    if (do_all) {
        for (refs.listReflogs()) |n| {
            if (refs.isReftable()) {
                if (!refs.deleteReflog(n)) ret |= 1;
                continue;
            }
            const lp = refs.reflogPath(n);
            if (!os.unlink(lp) and os.errno() != os.ENOENT) ret |= 1 else refs.removeRefParents(lp, n);
        }
        return ret;
    }
    for (rest) |a| {
        const ref = dwimLog(a) orelse {
            util.err("reflog could not be found: '{s}'", .{a});
            ret |= 1;
            continue;
        };
        if (refs.isReftable()) {
            if (!refs.deleteReflog(ref)) ret |= 1;
            continue;
        }
        const lp = refs.reflogPath(ref);
        if (!os.unlink(lp) and os.errno() != os.ENOENT) ret |= 1 else refs.removeRefParents(lp, ref);
    }
    return ret;
}

fn reflogWrite(args: []const []const u8) u8 {
    const usage = [_][]const u8{reflog_write_usage_s};
    const opts = [_]po.Opt{};
    const rest = po.parse(args, &opts, &usage, .{});
    if (rest.len != 4) po.usageWithOptions(&usage, &opts);
    const ref = rest[0];
    if (!refs.isRootRef(ref) and !refs.checkRefnameFormat(ref, 0)) util.die("invalid reference name: {s}", .{ref});
    const odb = repo_mod.repo().odb();
    const old = (if (rest[1].len == 40) hash.fromHex(rest[1]) else null) orelse util.die("invalid old object ID: '{s}'", .{rest[1]});
    if (!hash.isZero(old) and !odb.has(old)) util.die("old object '{s}' does not exist", .{rest[1]});
    const new = (if (rest[2].len == 40) hash.fromHex(rest[2]) else null) orelse util.die("invalid new object ID: '{s}'", .{rest[2]});
    if (!hash.isZero(new) and !odb.has(new)) util.die("new object '{s}' does not exist", .{rest[2]});
    refs.appendReflog(ref, old, new, rest[3], true);
    return 0;
}

pub fn cmdReflog(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").reflog);
    const rest = args[1..];
    if (rest.len > 0) {
        const sub = rest[0];
        const sargs = rest[1..];
        if (util.eql(sub, "show")) {
            const usage = [_][]const u8{reflog_show_usage_s};
            if (sargs.len == 1 and util.eql(sargs[0], "-h")) po.usageExit(&usage, &.{}, false);
            return reflogShow(sargs);
        }
        if (util.eql(sub, "list")) {
            const usage = [_][]const u8{reflog_list_usage_s};
            const r = po.parse(sargs, &.{}, &usage, .{});
            if (r.len > 0) {
                util.err("{s} does not accept arguments: '{s}'", .{ "list", r[0] });
                return 1;
            }
            for (refs.listReflogs()) |n| util.outf("{s}\n", .{n});
            return 0;
        }
        if (util.eql(sub, "exists")) {
            const usage = [_][]const u8{reflog_exists_usage_s};
            const r = po.parse(sargs, &.{}, &usage, .{});
            if (r.len == 0) po.usageWithOptions(&usage, &.{});
            if (!refs.checkRefnameFormat(r[0], refs.ALLOW_ONELEVEL)) util.die("invalid ref format: {s}", .{r[0]});
            return if (refs.reflogExists(r[0])) 0 else 1;
        }
        if (util.eql(sub, "write")) return reflogWrite(sargs);
        if (util.eql(sub, "delete")) return reflogDelete(sargs);
        if (util.eql(sub, "drop")) return reflogDrop(sargs);
        if (util.eql(sub, "expire")) return reflogExpire(sargs);
        if (util.eql(sub, "-h")) po.usageExit(&reflog_usage, &.{}, false);
    }
    return reflogShow(rest);
}

// =====================================================================
// git refs
// =====================================================================

const refs_usage = [_][]const u8{
    "git refs migrate --ref-format=<format> [--no-reflog] [--dry-run]",
    "git refs verify [--strict] [--verbose]",
    "git refs list [--count=<count>] [--shell|--perl|--python|--tcl]\n" ++
        "                         [(--sort=<key>)...] [--format=<format>]\n" ++
        "                         [--include-root-refs] [--points-at=<object>]\n" ++
        "                         [--merged[=<object>]] [--no-merged[=<object>]]\n" ++
        "                         [--contains[=<object>]] [--no-contains[=<object>]]\n" ++
        "                         [(--exclude=<pattern>)...] [--start-after=<marker>]\n" ++
        "                         [ --stdin | (<pattern>...)]",
    "git refs exists <ref>",
    "git refs optimize [--all] [--no-prune] [--auto] [--include <pattern>] [--exclude <pattern>]",
    "git refs create [--message=<reason>] [--no-deref] [--create-reflog] <ref> <new-value>",
    "git refs delete [--message=<reason>] [--no-deref] <ref> [<old-value>]",
    "git refs update [--message=<reason>] [--no-deref] [--create-reflog] <ref> <new-value> [<old-value>]",
    "git refs rename [--message=<reason>] <old-ref> <new-ref>",
};

pub fn cmdRefs(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").refs);
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&refs_usage, &.{});
    }
    const sub = args[1];
    const sargs = args[2..];
    if (util.eql(sub, "-h")) po.usageExit(&refs_usage, &.{}, false);
    if (util.eql(sub, "exists")) {
        const usage = [_][]const u8{"git refs exists <ref>"};
        const r = po.parse(sargs, &.{}, &usage, .{});
        if (r.len != 1) util.die("'git refs exists' requires a reference", .{});
        return rawExists(r[0]);
    }
    if (util.eql(sub, "optimize")) {
        const usage = [_][]const u8{"git refs optimize [--all] [--no-prune] [--auto] [--include <pattern>] [--exclude <pattern>]"};
        return packRefsCore(sargs, &usage);
    }
    if (util.eql(sub, "list")) {
        var l: std.ArrayList([]const u8) = .empty;
        l.append(gpa, "refs list") catch util.oom();
        l.appendSlice(gpa, sargs) catch util.oom();
        return cmdForEachRefImpl(l.items, true);
    }
    if (util.eql(sub, "verify")) {
        var verbose = false;
        var strict = false;
        const usage = [_][]const u8{"git refs verify [--strict] [--verbose]"};
        const opts = [_]po.Opt{
            po.boolean(0, "verbose", &verbose, "be verbose"),
            po.boolean(0, "strict", &strict, "enable strict checking"),
        };
        const r = po.parse(sargs, &opts, &usage, .{});
        if (r.len > 0) util.usageDie("usage: 'git refs verify' takes no arguments", .{});
        var failed = false;
        for (@import("../worktree.zig").getAllWithoutHead()) |wt| {
            if (verbose) util.eprint("Checking references consistency\n", .{});
            if (refs.isReftable()) {
                if (@import("../reftable_backend.zig").fsck(.{ .verbose = verbose, .strict = strict }, wt.id)) failed = true;
            }
        }
        return if (failed) 255 else 0;
    }
    if (util.eql(sub, "migrate")) {
        var fmt_s: ?[]const u8 = null;
        var flags: i32 = 0;
        const usage = [_][]const u8{"git refs migrate --ref-format=<format> [--no-reflog] [--dry-run]"};
        const opts = [_]po.Opt{
            .{ .long = "ref-format", .kind = .string, .s = &fmt_s, .noneg = true, .argh = "format", .help = "specify the reference format to convert to" },
            po.bit(0, "dry-run", &flags, 1, "perform a non-destructive dry-run"),
            po.bit(0, "no-reflog", &flags, 2, "drop reflogs entirely during the migration"),
        };
        const r = po.parse(sargs, &opts, &usage, .{});
        if (r.len > 0) util.usageDie("usage: too many arguments", .{});
        const f = fmt_s orelse util.usageDie("usage: missing --ref-format=<format>", .{});
        if (!util.eql(f, "files") and !util.eql(f, "reftable")) {
            util.err("unknown ref storage format '{s}'", .{f});
            return 1;
        }
        if (util.eql(repo_mod.repo().ref_storage, f)) {
            util.err("repository already uses '{s}' format", .{f});
            return 1;
        }
        if (@import("../refs_migrate.zig").migrate(f, .{ .dry_run = flags & 1 != 0, .skip_reflog = flags & 2 != 0 })) |msg| {
            util.err("{s}", .{msg});
            return 1;
        }
        return 0;
    }
    if (util.eql(sub, "create") or util.eql(sub, "update") or util.eql(sub, "delete")) {
        var message: ?[]const u8 = null;
        var flags: i32 = 0;
        const is_delete = util.eql(sub, "delete");
        const usage_create = [_][]const u8{"git refs create [--message=<reason>] [--no-deref] [--create-reflog] <ref> <new-value>"};
        const usage_update = [_][]const u8{"git refs update [--message=<reason>] [--no-deref] [--create-reflog] <ref> <new-value> [<old-value>]"};
        const usage_delete = [_][]const u8{"git refs delete [--message=<reason>] [--no-deref] <ref> [<old-value>]"};
        const usage: []const []const u8 = if (is_delete) &usage_delete else if (util.eql(sub, "create")) &usage_create else &usage_update;
        const opts_full = [_]po.Opt{
            po.string(0, "message", &message, "reason", "reason of the update"),
            po.bit(0, "no-deref", &flags, @intCast(refs.F_NO_DEREF), "update <refname> not the one it points to"),
            po.bit(0, "create-reflog", &flags, @intCast(refs.F_FORCE_CREATE_REFLOG), "create a reflog"),
        };
        const opts: []const po.Opt = if (is_delete) opts_full[0..2] else &opts_full;
        const r = po.parse(sargs, opts, usage, .{});
        if (util.eql(sub, "create")) {
            if (r.len != 2) util.usageDie("usage: create requires reference name and an object ID", .{});
        } else if (is_delete) {
            if (r.len < 1 or r.len > 2) util.usageDie("usage: delete requires reference name and an optional old object ID", .{});
        } else {
            if (r.len < 2 or r.len > 3) util.usageDie("usage: update requires reference name, new value and an optional old value", .{});
        }
        if (message) |m| {
            if (m.len == 0) util.die("refusing to perform update with empty message", .{});
        }
        const uflags: u32 = @intCast(flags);
        if (is_delete) {
            var old: ?Oid = null;
            if (r.len == 2) {
                old = getOidQuiet(r[1]) orelse util.die("invalid old object ID: '{s}'", .{r[1]});
                if (hash.isZero(old.?)) util.die("cannot delete reference with null old object ID", .{});
            }
            refs.deleteRef(r[0], old, uflags, message) catch {
                util.err("{s}", .{refs.last_error});
                return 1;
            };
            return 0;
        }
        if (util.eql(sub, "create")) {
            const new = getOidQuiet(r[1]) orelse util.die("invalid object ID: '{s}'", .{r[1]});
            if (hash.isZero(new)) util.die("cannot create reference with null new object ID", .{});
            refs.updateFlags(r[0], new, hash.zero, message orelse "", uflags) catch {
                util.err("update_ref failed for ref '{s}': {s}", .{ r[0], refs.last_error });
                return 1;
            };
            return 0;
        }
        const new = getOidQuiet(r[1]) orelse util.die("invalid new object ID: '{s}'", .{r[1]});
        var old: ?Oid = null;
        if (r.len == 3) old = getOidQuiet(r[2]) orelse util.die("invalid old object ID: '{s}'", .{r[2]});
        refs.updateFlags(r[0], new, old, message orelse "", uflags) catch {
            util.err("update_ref failed for ref '{s}': {s}", .{ r[0], refs.last_error });
            return 1;
        };
        return 0;
    }
    if (util.eql(sub, "rename")) {
        var message: ?[]const u8 = null;
        const usage = [_][]const u8{"git refs rename [--message=<reason>] <old-ref> <new-ref>"};
        const opts = [_]po.Opt{po.string(0, "message", &message, "reason", "reason of the update")};
        const r = po.parse(sargs, &opts, &usage, .{});
        if (r.len != 2) util.usageDie("usage: rename requires old and new reference name", .{});
        if (message) |m| {
            if (m.len == 0) util.die("refusing to perform update with empty message", .{});
        }
        if (!refs.checkRefnameFormat(r[0], 0)) util.die("invalid ref format: '{s}'", .{r[0]});
        if (!refs.checkRefnameFormat(r[1], 0)) util.die("invalid ref format: '{s}'", .{r[1]});
        if (refs.readRaw(r[0]) == null) util.die("reference does not exist: '{s}'", .{r[0]});
        if (refs.readRaw(r[1]) != null) util.die("reference already exists: '{s}'", .{r[1]});
        return if (refs.renameRef(r[0], r[1], message orelse "", false)) 0 else 1;
    }
    util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&refs_usage, &.{});
}

// =====================================================================
// for-each-ref
// =====================================================================

pub fn cmdForEachRef(args: []const []const u8) u8 {
    return cmdForEachRefImpl(args, false);
}

fn cmdForEachRefImpl(args: []const []const u8, is_refs_list: bool) u8 {
    const reffilter = @import("../reffilter.zig");
    return reffilter.forEachRefMain(args, is_refs_list);
}
