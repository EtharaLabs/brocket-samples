//! pkt-line framing and side-band multiplexing (port of pkt-line.c / sideband.c).

const std = @import("std");
const c = std.c;
const util = @import("util.zig");
const os = @import("os.zig");
const gpa = util.gpa;

pub const LARGE_PACKET_MAX: usize = 65520;
pub const LARGE_PACKET_DATA_MAX: usize = LARGE_PACKET_MAX - 4;

fn writeOrDie(fd: c_int, data: []const u8) void {
    os.writeAll(fd, data) catch {
        // check_pipe(): die silently on EPIPE like write_or_die()
        if (os.errno() == 32) os.exit(141);
        util.die("unable to write to remote: {s}", .{os.lastErr()});
    };
}

/// Write one pkt-line containing `data` verbatim.
pub fn write(fd: c_int, data: []const u8) void {
    if (data.len > LARGE_PACKET_DATA_MAX) util.die("protocol error: impossibly long line", .{});
    packetTrace(data, true);
    var b: util.Buf = .empty;
    var hdr: [4]u8 = undefined;
    _ = std.fmt.bufPrint(&hdr, "{x:0>4}", .{data.len + 4}) catch unreachable;
    util.bufAppend(&b, &hdr);
    util.bufAppend(&b, data);
    writeOrDie(fd, b.items);
}

pub fn writeFmt(fd: c_int, comptime f: []const u8, args: anytype) void {
    write(fd, util.fmt(f, args));
}

/// Append a pkt-line to a buffer.
pub fn bufWrite(b: *util.Buf, data: []const u8) void {
    packetTrace(data, true);
    var hdr: [4]u8 = undefined;
    _ = std.fmt.bufPrint(&hdr, "{x:0>4}", .{data.len + 4}) catch unreachable;
    util.bufAppend(b, &hdr);
    util.bufAppend(b, data);
}

pub fn bufFmt(b: *util.Buf, comptime f: []const u8, args: anytype) void {
    bufWrite(b, util.fmt(f, args));
}

pub fn flush(fd: c_int) void {
    packetTrace("0000", true);
    writeOrDie(fd, "0000");
}
pub fn delim(fd: c_int) void {
    packetTrace("0001", true);
    writeOrDie(fd, "0001");
}
pub fn responseEnd(fd: c_int) void {
    packetTrace("0002", true);
    writeOrDie(fd, "0002");
}

/// Send data over side-band `band`, chunked.
pub fn sendSideband(fd: c_int, band: u8, data: []const u8, max: usize) void {
    var p = data;
    while (p.len > 0) {
        const n = @min(p.len, max - 5);
        var b: util.Buf = .empty;
        var hdr: [4]u8 = undefined;
        _ = std.fmt.bufPrint(&hdr, "{x:0>4}", .{n + 5}) catch unreachable;
        util.bufAppend(&b, &hdr);
        util.bufByte(&b, band);
        util.bufAppend(&b, p[0..n]);
        writeOrDie(fd, b.items);
        p = p[n..];
    }
}

pub const Status = enum { normal, flush, delim, response_end, eof };

pub const Packet = struct {
    status: Status,
    /// payload (valid until next read)
    line: []u8 = &.{},
};

pub const Reader = struct {
    fd: c_int,
    buf: [65536]u8 = undefined,
    pos: usize = 0,
    len: usize = 0,
    pkt: [LARGE_PACKET_MAX + 1]u8 = undefined,
    chomp: bool = true,
    gentle_eof: bool = false,
    die_on_err_packet: bool = true,
    /// last read packet
    status: Status = .normal,
    line: []u8 = &.{},
    /// one-packet pushback
    peeked: bool = false,

    pub fn init(fd: c_int) Reader {
        return .{ .fd = fd };
    }

    fn fill(self: *Reader) bool {
        if (self.pos < self.len) return true;
        while (true) {
            const n = c.read(self.fd, &self.buf, self.buf.len);
            if (n < 0) {
                if (os.errno() == 4) continue;
                util.die("read error: {s}", .{os.lastErr()});
            }
            if (n == 0) return false;
            self.pos = 0;
            self.len = @intCast(n);
            return true;
        }
    }

    /// Read exactly dst.len bytes; returns false on EOF before any/partial data.
    fn readExact(self: *Reader, dst: []u8) bool {
        var off: usize = 0;
        while (off < dst.len) {
            if (!self.fill()) return false;
            const n = @min(dst.len - off, self.len - self.pos);
            @memcpy(dst[off..][0..n], self.buf[self.pos..][0..n]);
            self.pos += n;
            off += n;
        }
        return true;
    }

    /// Raw read (for un-framed data following pkt-lines). Returns 0 on EOF.
    pub fn readRaw(self: *Reader, dst: []u8) usize {
        if (!self.fill()) return 0;
        const n = @min(dst.len, self.len - self.pos);
        @memcpy(dst[0..n], self.buf[self.pos..][0..n]);
        self.pos += n;
        return n;
    }

    pub fn unread(self: *Reader) void {
        self.peeked = true;
    }

    pub fn peek(self: *Reader) Status {
        const st = self.read();
        self.peeked = true;
        return st;
    }

    pub fn read(self: *Reader) Status {
        if (self.peeked) {
            self.peeked = false;
            return self.status;
        }
        var hdr: [4]u8 = undefined;
        if (!self.readExact(&hdr)) {
            if (self.gentle_eof) {
                self.status = .eof;
                self.line = &.{};
                return .eof;
            }
            util.die("the remote end hung up unexpectedly", .{});
        }
        const len = std.fmt.parseInt(usize, &hdr, 16) catch
            util.die("protocol error: bad line length character: {s}", .{hdr});
        switch (len) {
            0 => {
                packetTrace("0000", false);
                self.status = .flush;
                self.line = &.{};
                return .flush;
            },
            1 => {
                packetTrace("0001", false);
                self.status = .delim;
                self.line = &.{};
                return .delim;
            },
            2 => {
                packetTrace("0002", false);
                self.status = .response_end;
                self.line = &.{};
                return .response_end;
            },
            3 => util.die("protocol error: bad line length {d}", .{len}),
            else => {},
        }
        if (len > LARGE_PACKET_MAX) util.die("protocol error: bad line length {d}", .{len});
        const n = len - 4;
        if (!self.readExact(self.pkt[0..n])) util.die("the remote end hung up unexpectedly", .{});
        var l = self.pkt[0..n];
        if (self.chomp and l.len > 0 and l[l.len - 1] == '\n') l = l[0 .. l.len - 1];
        packetTrace(l, false);
        if (self.die_on_err_packet and util.startsWith(l, "ERR "))
            util.die("remote error: {s}", .{l[4..]});
        self.status = .normal;
        self.line = l;
        return .normal;
    }

    /// Read a normal line or die; returns null on flush.
    pub fn readLine(self: *Reader) ?[]u8 {
        const st = self.read();
        return switch (st) {
            .normal => self.line,
            else => null,
        };
    }
};

// ---------------- side-band demux ----------------

fn addSanitized(dest: *util.Buf, src: []const u8) void {
    var i: usize = 0;
    while (i < src.len) : (i += 1) {
        const ch = src[i];
        if (ch == 0) break;
        if (!(ch < 0x20 or ch == 0x7f) or ch == '\t' or ch == '\n') {
            util.bufByte(dest, ch);
        } else if (ch == 0x1b and i + 1 < src.len and src[i + 1] == '[') {
            // allow color sequences ESC [ <digits;> m
            var j = i + 2;
            while (j < src.len and (std.ascii.isDigit(src[j]) or src[j] == ';')) j += 1;
            if (j < src.len and src[j] == 'm') {
                util.bufAppend(dest, src[i .. j + 1]);
                i = j;
            } else {
                util.bufByte(dest, '^');
                util.bufByte(dest, 0x40 + ch);
            }
        } else {
            util.bufByte(dest, '^');
            util.bufByte(dest, if (ch == 0x7f) '?' else 0x40 + ch);
        }
    }
}

pub const Demux = struct {
    scratch: util.Buf = .empty,
    prefix: []const u8 = "",
    suffix: []const u8 = "",
    inited: bool = false,

    fn initPS(self: *Demux) void {
        if (self.inited) return;
        self.inited = true;
        const term = os.getenv("TERM");
        const dumb = term == null or util.eql(term.?, "dumb");
        if (os.isatty(2) and !dumb) {
            self.prefix = "\x1b[Kremote: ";
            self.suffix = "";
        } else {
            self.prefix = "remote: ";
            self.suffix = "        ";
        }
    }

    /// Handle a band-2 message chunk.
    pub fn progress(self: *Demux, data: []const u8) void {
        self.initPS();
        var b = data;
        while (std.mem.indexOfAny(u8, b, "\n\r")) |brk| {
            const linelen = brk;
            if (self.scratch.items.len > 0 and linelen == 0) util.bufAppend(&self.scratch, self.suffix);
            if (self.scratch.items.len == 0) util.bufAppend(&self.scratch, self.prefix);
            if (linelen > 0) {
                addSanitized(&self.scratch, b[0..linelen]);
                util.bufAppend(&self.scratch, self.suffix);
            }
            util.bufByte(&self.scratch, b[brk]);
            os.writeAll(2, self.scratch.items) catch {};
            self.scratch.clearRetainingCapacity();
            b = b[brk + 1 ..];
        }
        if (b.len > 0) {
            if (self.scratch.items.len == 0) util.bufAppend(&self.scratch, self.prefix);
            addSanitized(&self.scratch, b);
        }
    }

    pub fn finish(self: *Demux) void {
        if (self.scratch.items.len > 0) {
            util.bufByte(&self.scratch, '\n');
            os.writeAll(2, self.scratch.items) catch {};
            self.scratch.clearRetainingCapacity();
        }
    }

    /// Process one packet read by `r` (already read). Returns band-1 payload
    /// or null when the packet was consumed (band 2) or the stream ended (flush).
    pub fn handle(self: *Demux, r: *Reader, me: []const u8) union(enum) { data: []u8, consumed, end } {
        self.initPS();
        switch (r.status) {
            .eof => {
                const sep: []const u8 = if (self.scratch.items.len > 0) "\n" else "";
                util.die("{s}{s}{s}: unexpected disconnect while reading sideband packet", .{ self.scratch.items, sep, me });
            },
            .normal => {},
            else => {
                self.finish();
                return .end;
            },
        }
        const l = r.line;
        if (l.len == 0) {
            const sep: []const u8 = if (self.scratch.items.len > 0) "\n" else "";
            util.die("{s}{s}{s}: protocol error: missing sideband designator", .{ self.scratch.items, sep, me });
        }
        switch (l[0]) {
            1 => return .{ .data = l[1..] },
            2 => {
                self.progress(l[1..]);
                return .consumed;
            },
            3 => util.die("remote error: {s}", .{l[1..]}),
            else => {
                const sep: []const u8 = if (self.scratch.items.len > 0) "\n" else "";
                util.die("{s}{s}{s}: protocol error: bad band #{d}", .{ self.scratch.items, sep, me, l[0] });
            },
        }
    }
};

/// Copy a side-band multiplexed stream from `r` into `out_fd` until flush.
/// Band 2 goes to stderr with the "remote: " prefix.
pub fn demuxTo(r: *Reader, out_fd: c_int, me: []const u8) void {
    const saved_chomp = r.chomp;
    const saved_gentle = r.gentle_eof;
    r.chomp = false;
    r.gentle_eof = true;
    defer {
        r.chomp = saved_chomp;
        r.gentle_eof = saved_gentle;
    }
    var d: Demux = .{};
    while (true) {
        _ = r.read();
        switch (d.handle(r, me)) {
            .data => |data| {
                if (out_fd >= 0) os.writeAll(out_fd, data) catch {};
            },
            .consumed => {},
            .end => break,
        }
    }
}

// ---------------- GIT_TRACE_PACKET ----------------

const trace = @import("trace.zig");

/// packet_trace_identity()
pub var trace_identity: []const u8 = "git";
/// set while reading packets on behalf of a (C: async) sideband demuxer
pub var in_async: bool = false;
var trace_in_pack = false;
var trace_pack_sideband = false;

pub fn traceIdentity(prog: []const u8) void {
    trace_identity = prog;
}

/// packet_trace()
pub fn packetTrace(buf0: []const u8, write_: bool) void {
    if (!trace.want(&trace.packet_key)) return;
    var buf = buf0;
    if (trace_in_pack) {
        if (!trace_pack_sideband) return;
        if (buf.len > 0 and buf[0] == 1) return;
    } else if (util.startsWith(buf, "PACK") or util.startsWith(buf, "\x01PACK")) {
        trace_in_pack = true;
        trace_pack_sideband = buf[0] == 1;
        buf = "PACK ...";
    }
    var out: util.Buf = .empty;
    const prefix = if (in_async) "sideband" else trace_identity;
    var i: usize = prefix.len;
    util.bufAppend(&out, "packet: ");
    while (i < 12) : (i += 1) util.bufByte(&out, ' ');
    util.bufAppend(&out, prefix);
    util.bufByte(&out, if (write_) '>' else '<');
    util.bufByte(&out, ' ');
    for (buf) |ch| {
        if (ch == '\n') continue;
        if (ch >= 0x20 and ch <= 0x7e) {
            util.bufByte(&out, ch);
        } else if (ch >= 0x80) {
            util.bufPrint(&out, "\\{o}", .{@as(u32, @bitCast(@as(i32, @as(i8, @bitCast(ch)))))});
        } else util.bufPrint(&out, "\\{o}", .{ch});
    }
    trace.printf(&trace.packet_key, "pkt-line.c", 85, "{s}", .{out.items});
}

pub fn bufFlush(b: *util.Buf) void {
    packetTrace("0000", true);
    util.bufAppend(b, "0000");
}

pub fn bufDelim(b: *util.Buf) void {
    packetTrace("0001", true);
    util.bufAppend(b, "0001");
}
