//! git bugreport and git diagnose (ports of builtin/bugreport.c,
//! builtin/diagnose.c and diagnose.c).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hook = @import("../hook.zig");
const editor = @import("../editor.zig");
const countobjects = @import("countobjects.zig");
const gpa = util.gpa;

extern "c" fn time(t: ?*i64) i64;
extern "c" fn localtime_r(t: *const i64, tm: *[16]c_int) ?*anyopaque;
extern "c" fn strftime(s: [*]u8, max: usize, format: [*:0]const u8, tm: *const [16]c_int) usize;
extern "c" fn uname(buf: *[6 * 65]u8) c_int;
extern "c" fn gnu_get_libc_version() [*:0]const u8;
extern "c" fn statvfs(path: [*:0]const u8, buf: *[16]u64) c_int;

const Mode = enum { none, stats, all };

fn addFtime(b: *util.Buf, format: []const u8, tm: *const [16]c_int) void {
    if (format.len == 0) return;
    var size: usize = 256;
    while (size < 1 << 20) : (size *= 2) {
        const buf = gpa.alloc(u8, size) catch util.oom();
        // append a space so a zero return unambiguously means "too small"
        const fmtz = util.concat(&.{ format, " " });
        const n = strftime(buf.ptr, size, os.z(fmtz), tm);
        if (n > 0) {
            util.bufAppend(b, buf[0 .. n - 1]);
            return;
        }
    }
}

fn versionInfo(b: *util.Buf) void {
    const r = os.run(&.{ proc.gitBinary(), "version", "--build-options" }, .{ .capture_stdout = true, .no_stdin = true });
    util.bufAppend(b, r.stdout);
}

fn cstr(s: []const u8) []const u8 {
    return std.mem.sliceTo(s, 0);
}

fn unameInfo(b: *util.Buf) void {
    var u: [6 * 65]u8 = undefined;
    if (uname(&u) != 0) {
        util.bufAppend(b, util.fmt("uname() failed with error '{s}' ({d})\n", .{ os.lastErr(), os.errno() }));
        return;
    }
    util.bufAppend(b, util.fmt("{s} {s} {s} {s}\n", .{ cstr(u[0..65]), cstr(u[130..195]), cstr(u[195..260]), cstr(u[260..325]) }));
}

fn diskInfo(b: *util.Buf) bool {
    const rp = os.realPath(".") orelse ".";
    var st: [16]u64 = undefined;
    if (statvfs(os.z(rp), &st) < 0) {
        util.eprint("error: could not determine free disk size for '{s}'\n", .{rp});
        return false;
    }
    util.bufAppend(b, util.fmt("Available space on '{s}': ", .{rp}));
    countobjects.humaniseBytes(b, st[0] *% st[4]);
    util.bufAppend(b, util.fmt(" (mount flags 0x{x})\n", .{st[9]}));
    return true;
}

fn packStats(b: *util.Buf, objdir: []const u8) void {
    util.bufAppend(b, util.fmt("Contents of {s}:\n", .{objdir}));
    const pdir = util.concat(&.{ objdir, "/pack" });
    const ents = os.listDir(pdir) orelse return;
    for (ents) |e| {
        const full = util.concat(&.{ pdir, "/", e.name });
        if (os.statPath(full)) |st| {
            const sz = util.fmt("{d}", .{st.size});
            util.bufAppend(b, e.name);
            var pad: usize = e.name.len;
            while (pad < 70) : (pad += 1) util.bufByte(b, ' ');
            util.bufByte(b, ' ');
            pad = sz.len;
            while (pad < 16) : (pad += 1) util.bufByte(b, ' ');
            util.bufAppend(b, sz);
            util.bufByte(b, '\n');
        }
    }
}

fn isHex2(s: []const u8) bool {
    return s.len == 2 and std.ascii.isHex(s[0]) and std.ascii.isHex(s[1]);
}

fn entIsDir(base: []const u8, e: os.DirEntry) bool {
    if (e.typ == os.DT_DIR) return true;
    if (e.typ != os.DT_UNKNOWN) return false;
    const st = os.lstatPath(util.concat(&.{ base, e.name })) orelse return false;
    return st.isDir();
}

fn entIsReg(base: []const u8, e: os.DirEntry) bool {
    if (e.typ == os.DT_REG) return true;
    if (e.typ != os.DT_UNKNOWN) return false;
    const st = os.lstatPath(util.concat(&.{ base, e.name })) orelse return false;
    return st.isReg();
}

fn looseStats(b: *util.Buf, path: []const u8) void {
    const ents = os.listDir(path) orelse return;
    const abs = absPath(path);
    util.bufAppend(b, util.fmt("Object directory stats for {s}:\n", .{abs}));
    const base = util.concat(&.{ abs, "/" });
    var total: usize = 0;
    for (ents) |e| {
        if (!isHex2(e.name) or !entIsDir(base, e)) continue;
        const sub = util.concat(&.{ base, e.name, "/" });
        var count: usize = 0;
        if (os.listDir(sub)) |files| {
            for (files) |f| {
                if (entIsReg(sub, f)) count += 1;
            }
        }
        total += count;
        util.bufAppend(b, util.fmt("{s} : {d: >7} files\n", .{ e.name, count }));
    }
    util.bufAppend(b, util.fmt("Total: {d} loose objects", .{total}));
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return p;
    return util.concat(&.{ os.getcwd(), "/", p });
}

fn addDirectory(args: *std.ArrayList([]const u8), path: []const u8, recurse: bool) bool {
    const at_root = path.len == 0;
    const dirpath = if (at_root) "." else path;
    const ents = os.listDir(dirpath) orelse {
        if (!os.exists(dirpath)) {
            util.eprint("warning: could not archive missing directory '{s}'\n", .{path});
            return true;
        }
        util.eprint("error: could not open directory '{s}': {s}\n", .{ path, os.lastErr() });
        return false;
    };
    const pre = if (at_root) "" else util.concat(&.{ path, "/" });
    args.append(gpa, util.concat(&.{ "--prefix=", pre })) catch util.oom();
    const absbase = util.concat(&.{ absPath(dirpath), "/" });
    for (ents) |e| {
        const rel = util.concat(&.{ pre, e.name });
        if (entIsReg(absbase, e)) {
            args.append(gpa, util.concat(&.{ "--add-file=", rel })) catch util.oom();
        } else if (!entIsDir(absbase, e)) {
            util.eprint("warning: skipping '{s}', which is neither file nor directory\n", .{rel});
        } else if (recurse) {
            if (!addDirectory(args, rel, recurse)) return false;
        }
    }
    return true;
}

/// create_diagnostics_archive(); returns true on error.
fn createDiagnosticsArchive(zip_path: []const u8, mode: Mode) bool {
    if (mode == .none) return false;
    const fd = os.openFile(zip_path, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o666);
    if (fd < 0) util.die("could not open '{s}' for writing: {s}", .{ zip_path, os.lastErr() });
    defer os.close(fd);

    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, &.{ proc.gitBinary(), "archive", "--format=zip" }) catch util.oom();

    var buf: util.Buf = .empty;
    util.bufAppend(&buf, "Collecting diagnostic info\n\n");
    versionInfo(&buf);
    const wt: []const u8 = if (repo_mod.repo_) |r| (r.work_tree orelse "(null)") else "(null)";
    util.bufAppend(&buf, util.fmt("Repository root: {s}\n", .{wt}));
    _ = diskInfo(&buf);
    util.out(buf.items);
    util.flushStdout();
    args.append(gpa, util.concat(&.{ "--add-virtual-file=diagnostics.log:", buf.items })) catch util.oom();

    var pk: util.Buf = .empty;
    util.bufAppend(&pk, "--add-virtual-file=packs-local.txt:");
    if (repo_mod.repo_) |r| {
        const objdir = r.odb().objects_dir;
        packStats(&pk, objdir);
        if (os.readFile(util.concat(&.{ objdir, "/info/alternates" }))) |alt| {
            var it = std.mem.splitScalar(u8, alt, '\n');
            while (it.next()) |l0| {
                const l = std.mem.trim(u8, l0, " \t\r");
                if (l.len == 0 or l[0] == '#') continue;
                const ap = if (l[0] == '/') l else util.normalizePath(util.concat(&.{ objdir, "/", l })) orelse l;
                packStats(&pk, ap);
            }
        }
    }
    args.append(gpa, pk.items) catch util.oom();

    var lo: util.Buf = .empty;
    util.bufAppend(&lo, "--add-virtual-file=objects-local.txt:");
    looseStats(&lo, ".git/objects");
    args.append(gpa, lo.items) catch util.oom();

    if (mode == .all) {
        const dirs = [_]struct { p: []const u8, r: bool }{
            .{ .p = ".git", .r = false },
            .{ .p = ".git/hooks", .r = false },
            .{ .p = ".git/info", .r = false },
            .{ .p = ".git/logs", .r = true },
            .{ .p = ".git/objects/info", .r = false },
        };
        for (dirs) |d| {
            if (!addDirectory(&args, d.p, d.r)) {
                util.eprint("error: could not add directory '{s}' to archiver: {s}\n", .{ d.p, os.lastErr() });
                return true;
            }
        }
    }
    args.appendSlice(gpa, &.{ "--prefix=", "4b825dc642cb6eb9a060e54bf8d69288fbee4904", "--" }) catch util.oom();

    const child = proc.spawn(args.items, .{ .out_fd = fd, .no_stdin = true });
    if (proc.wait(child.pid) != 0) {
        util.eprint("error: failed to write archive\n", .{});
        return true;
    }
    util.eprint("\nDiagnostics complete.\nAll of the gathered info is captured in '{s}'\n", .{zip_path});
    return false;
}

var diag_mode: Mode = .none;
var mode_optname: []const u8 = "diagnose";

fn parseMode(arg: ?[]const u8, unset: bool) void {
    const a = arg orelse {
        diag_mode = if (unset) .none else .stats;
        return;
    };
    if (util.eql(a, "stats")) {
        diag_mode = .stats;
    } else if (util.eql(a, "all")) {
        diag_mode = .all;
    } else {
        util.eprint("error: invalid --{s} value '{s}'\n", .{ mode_optname, a });
        os.exit(129);
    }
}

fn prefixStr() []const u8 {
    if (repo_mod.repo_) |r| return r.prefix;
    return "";
}

fn nowTm(tm: *[16]c_int) void {
    var t: i64 = time(null);
    _ = localtime_r(&t, tm);
}

fn leadingDirs(path: []const u8) bool {
    const slash = std.mem.lastIndexOfScalar(u8, path, '/') orelse return true;
    if (slash == 0) return true;
    return os.mkdirAll(path[0..slash]);
}

const bugreport_usage = [_][]const u8{
    "git bugreport [(-o | --output-directory) <path>]\n              [(-s | --suffix) <format> | --no-suffix]\n              [--diagnose[=<mode>]]",
};

pub fn cmdBugreport(args: []const []const u8) u8 {
    var output: ?[]const u8 = null;
    var suffix: ?[]const u8 = "%Y-%m-%d-%H%M";
    diag_mode = .none;
    mode_optname = "diagnose";
    const opts = [_]po.Opt{
        .{ .long = "diagnose", .kind = .callback, .cb = parseMode, .argh = "mode", .optarg = true, .help = "create an additional zip archive of detailed diagnostics (default 'stats')" },
        po.string('o', "output-directory", &output, "path", "specify a destination for the bugreport file(s)"),
        po.string('s', "suffix", &suffix, "format", "specify a strftime format suffix for the filename(s)"),
    };
    const rest = po.parse(args[1..], &opts, &bugreport_usage, .{});
    if (rest.len > 0) {
        util.eprint("error: unknown argument `{s}'\n", .{rest[0]});
        util.eprint("usage: {s}\n", .{bugreport_usage[0]});
        return 129;
    }
    const prefix = prefixStr();
    var tm: [16]c_int = undefined;
    nowTm(&tm);

    var path: util.Buf = .empty;
    const o = output orelse "";
    if (o.len > 0 and o[0] == '/') util.bufAppend(&path, o) else util.bufAppend(&path, util.concat(&.{ prefix, o }));
    if (path.items.len > 0 and path.items[path.items.len - 1] != '/') util.bufByte(&path, '/');
    const dir_len = path.items.len;
    util.bufAppend(&path, "git-bugreport");
    if (suffix) |s| {
        util.bufByte(&path, '-');
        addFtime(&path, s, &tm);
    }
    util.bufAppend(&path, ".txt");
    const report_path = util.dupe(path.items);
    if (!leadingDirs(report_path)) util.die("could not create leading directories for '{s}'", .{report_path});

    if (diag_mode != .none) {
        var zp: util.Buf = .empty;
        util.bufAppend(&zp, report_path[0..dir_len]);
        util.bufAppend(&zp, "git-diagnostics-");
        addFtime(&zp, suffix orelse "", &tm);
        util.bufAppend(&zp, ".zip");
        if (createDiagnosticsArchive(zp.items, diag_mode))
            util.die("unable to create diagnostics archive {s}: {s}", .{ zp.items, os.lastErr() });
    }

    var b: util.Buf = .empty;
    util.bufAppend(&b,
        \\Thank you for filling out a Git bug report!
        \\Please answer the following questions to help us understand your issue.
        \\
        \\What did you do before the bug happened? (Steps to reproduce your issue)
        \\
        \\What did you expect to happen? (Expected behavior)
        \\
        \\What happened instead? (Actual behavior)
        \\
        \\What's different between what you expected and what actually happened?
        \\
        \\Anything else you want to add:
        \\
        \\Please review the rest of the bug report below.
        \\You can delete any lines you don't wish to share.
        \\
    );
    util.bufAppend(&b, "\n\n[System Info]\n");
    util.bufAppend(&b, "git version:\n");
    versionInfo(&b);
    util.bufAppend(&b, "uname: ");
    unameInfo(&b);
    util.bufAppend(&b, "compiler info: no compiler information available\n");
    util.bufAppend(&b, util.fmt("libc info: glibc: {s}\n", .{std.mem.sliceTo(gnu_get_libc_version(), 0)}));
    util.bufAppend(&b, util.fmt("$SHELL (typically, interactive shell): {s}\n", .{os.getenv("SHELL") orelse "<unset>"}));
    util.bufAppend(&b, "\n\n[Enabled Hooks]\n");
    if (!repo_mod.have_repository) {
        util.bufAppend(&b, "not run from a git repository - no hooks to show\n");
    } else {
        for (hook.known_hooks) |h| {
            if (hook.exists(h)) util.bufAppend(&b, util.fmt("{s}\n", .{h}));
        }
    }

    const fd = os.openFile(report_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o666);
    if (fd < 0) util.die("could not open '{s}' for writing: {s}", .{ report_path, os.lastErr() });
    os.writeAll(fd, b.items) catch util.die("unable to write to {s}: {s}", .{ report_path, os.lastErr() });
    os.close(fd);

    const rel = if (prefix.len > 0) (util.skipPrefix(report_path, prefix) orelse report_path) else report_path;
    util.eprint("Created new report at '{s}'.\n", .{rel});
    return if (editor.launch(report_path, &.{})) 1 else 0;
}

const diagnose_usage = [_][]const u8{
    "git diagnose [(-o | --output-directory) <path>] [(-s | --suffix) <format>]\n             [--mode=<mode>]",
};

pub fn cmdDiagnose(args: []const []const u8) u8 {
    var output: ?[]const u8 = null;
    var suffix: ?[]const u8 = "%Y-%m-%d-%H%M";
    diag_mode = .stats;
    mode_optname = "mode";
    const opts = [_]po.Opt{
        po.string('o', "output-directory", &output, "path", "specify a destination for the diagnostics archive"),
        po.string('s', "suffix", &suffix, "format", "specify a strftime format suffix for the filename"),
        .{ .long = "mode", .kind = .callback, .cb = parseMode, .argh = "(stats|all)", .literal_argh = true, .noneg = true, .help = "specify the content of the diagnostic archive" },
    };
    _ = po.parse(args[1..], &opts, &diagnose_usage, .{});
    const prefix = prefixStr();
    var tm: [16]c_int = undefined;
    nowTm(&tm);
    var path: util.Buf = .empty;
    const o = output orelse "";
    if (o.len > 0 and o[0] == '/') util.bufAppend(&path, o) else util.bufAppend(&path, util.concat(&.{ prefix, o }));
    if (path.items.len > 0 and path.items[path.items.len - 1] != '/') util.bufByte(&path, '/');
    util.bufAppend(&path, "git-diagnostics-");
    addFtime(&path, suffix orelse "", &tm);
    util.bufAppend(&path, ".zip");
    const zip_path = util.dupe(path.items);
    if (!leadingDirs(zip_path)) util.die("could not create leading directories for '{s}': {s}", .{ zip_path, os.lastErr() });
    if (createDiagnosticsArchive(zip_path, diag_mode))
        util.die("unable to create diagnostics archive {s}: {s}", .{ zip_path, os.lastErr() });
    return 0;
}
