//! git mv (builtin/mv.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const sparse = @import("../sparse.zig");
const entry_mod = @import("../entry.zig");
const dir_mod = @import("../dir.zig");
const advice = @import("../advice.zig");
const add_cmd = @import("add.zig");
const rm_cmd = @import("rm.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git mv [-v] [-f] [-n] [-k] <source> <destination>",
    "git mv [-v] [-f] [-n] [-k] <source>... <destination-directory>",
};

const WORKING_DIRECTORY: u32 = 1 << 1;
const INDEX: u32 = 1 << 2;
const SPARSE: u32 = 1 << 3;
const SKIP_WORKTREE_DIR: u32 = 1 << 4;
const MOVE_VIA_PARENT_DIR: u32 = 1 << 5;

const DUP_BASENAME: u32 = 1;
const KEEP_TRAILING_SLASH: u32 = 2;

var verbose: i32 = 0;
var show_only = false;
var force: i32 = 0;
var ignore_errors = false;
var ignore_sparse = false;

const options = [_]po.Opt{
    .{ .short = 'v', .long = "verbose", .kind = .counter, .i = &verbose, .help = "be verbose" },
    po.boolean('n', "dry-run", &show_only, "dry run"),
    po.noComplete(po.counter('f', "force", &force, "force move/rename even if target exists")),
    po.boolean('k', "", &ignore_errors, "skip move/rename errors"),
    po.boolean(0, "sparse", &ignore_sparse, "allow updating entries outside of the sparse-checkout cone"),
};

fn needsWorktreeRename(mode: u32, dst_mode: u32) bool {
    return mode & (INDEX | SPARSE | SKIP_WORKTREE_DIR) == 0 and
        dst_mode & (SKIP_WORKTREE_DIR | SPARSE) == 0;
}

fn prefixPath(prefix: []const u8, path: []const u8) []const u8 {
    var plen = prefix.len;
    return pathspec_mod.prefixPathGently(prefix, &plen, path) orelse
        util.die("'{s}' is outside repository at '{s}'", .{ path, repo_mod.repo().work_tree orelse "" });
}

fn internalPrefix(out: *std.ArrayList([]const u8), prefix: []const u8, paths: []const []const u8, flags: u32) void {
    for (paths) |p| {
        var n = p.len;
        while (flags & KEEP_TRAILING_SLASH == 0 and n > 0 and p[n - 1] == '/') n -= 1;
        const trimmed = p[0..n];
        const name = if (flags & DUP_BASENAME != 0) basename(trimmed) else trimmed;
        out.append(gpa, prefixPath(prefix, name)) catch util.oom();
    }
}

/// POSIX basename() on an already slash-trimmed path.
fn basename(p: []const u8) []const u8 {
    if (p.len == 0) return ".";
    const s = std.mem.lastIndexOfScalar(u8, p, '/') orelse return p;
    return p[s + 1 ..];
}

fn addSlash(p: []const u8) []const u8 {
    if (p.len > 0 and p[p.len - 1] != '/') return util.concat(&.{ p, "/" });
    return p;
}

/// index_name_pos() >= 0, i.e. a stage-0 entry exists
fn stage0Pos(idx: *index_mod.Index, path: []const u8) ?usize {
    return idx.findPos(path);
}

/// index_range_of_same_dir(): returns [first, last) of entries under src/.
fn indexRangeOfSameDir(idx: *index_mod.Index, src: []const u8) [2]usize {
    const ws = addSlash(src);
    if (stage0Pos(idx, ws) != null) util.die("{s} is in index", .{ws});
    const first = idx.firstPos(ws);
    var last = first;
    while (last < idx.entries.items.len and util.startsWith(idx.entries.items[last].path, ws)) last += 1;
    return .{ first, last };
}

/// empty_dir_has_sparse_contents()
fn emptyDirHasSparseContents(idx: *index_mod.Index, name: []const u8) bool {
    const ws = addSlash(name);
    if (stage0Pos(idx, ws) != null) return false;
    const pos = idx.firstPos(ws);
    if (pos >= idx.entries.items.len) return false;
    const ce = &idx.entries.items[pos];
    if (!util.startsWith(ce.path, ws)) return false;
    return ce.skipWorktree();
}

fn pathInConeModeSparseCheckout(path: []const u8) bool {
    if (path.len == 0) return true;
    const p = sparse.current() orelse return true;
    if (!p.use_cone) return true;
    return p.pathIn(path, dir_mod.DT_REG);
}

/// index_file_exists(): any stage
fn indexFileExists(idx: *index_mod.Index, path: []const u8) ?usize {
    if (stage0Pos(idx, path)) |p| return p;
    const p = idx.firstPos(path);
    if (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, path)) return p;
    return null;
}

fn hasSymlinkLeadingPath(p: []const u8) bool {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, p, i, '/')) |s| : (i = s + 1) {
        const st = os.lstatPath(p[0..s]) orelse return false;
        if (st.isLnk()) return true;
        if (!st.isDir()) return false;
    }
    return false;
}

fn ignoreCase() bool {
    return repo_mod.cfg.getBool("core.ignorecase") orelse false;
}

fn adviseOnMovingDirtyPath(list: []const []const u8) void {
    if (list.len == 0) return;
    util.ewrite("The following paths have been moved outside the\n" ++
        "sparse-checkout definition but are not sparse due to local\n" ++
        "modifications.\n");
    for (list) |p| util.eprint("{s}\n", .{p});
    advice.adviseIfEnabled("updateSparsePath", "To correct the sparsity of these paths, do the following:\n" ++
        "* Use \"git add --sparse <paths>\" to update the index\n" ++
        "* Use \"git sparse-checkout reapply\" to apply the sparsity rules");
}

/// rename_index_entry_at()
fn renameIndexEntryAt(idx: *index_mod.Index, pos: usize, dst: []const u8) void {
    var ne = idx.entries.items[pos];
    ne.path = util.dupe(dst);
    ne.uptodate = false;
    ne.removed = false;
    idx.removeAt(pos);
    _ = idx.add(ne, .{});
    idx.changed = true;
}

pub fn cmdMv(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    const argv = po.parse(args[1..], &options, &usage, .{});
    if (argv.len < 2) po.usageWithOptions(&usage, &options);
    var argc = argv.len - 1;

    const idx = index_mod.lockAndRead();
    const prefix = r.prefix;

    var sources: std.ArrayList([]const u8) = .empty;
    internalPrefix(&sources, prefix, argv[0..argc], 0);
    var modes: std.ArrayList(u32) = .empty;
    modes.appendNTimes(gpa, 0, argc) catch util.oom();
    // submodule_gitfiles: null = not a submodule, "" = SUBMODULE_WITH_GITDIR
    var gitfiles: std.ArrayList(?[]const u8) = .empty;
    gitfiles.appendNTimes(gpa, null, argc) catch util.oom();
    var dst_mode: u32 = 0;

    var flags: u32 = KEEP_TRAILING_SLASH;
    if (argc == 1 and os.isDir(argv[0]) and !os.isDir(argv[1])) flags = 0;
    var dest_paths: std.ArrayList([]const u8) = .empty;
    internalPrefix(&dest_paths, prefix, argv[argc .. argc + 1], flags);
    const dst_w_slash = addSlash(dest_paths.items[0]);

    var destinations: std.ArrayList([]const u8) = .empty;
    if (dest_paths.items[0].len == 0) {
        internalPrefix(&destinations, dest_paths.items[0], argv[0..argc], DUP_BASENAME);
    } else if (if (os.lstatPath(dest_paths.items[0])) |st| st.isDir() else false) {
        internalPrefix(&destinations, dst_w_slash, argv[0..argc], DUP_BASENAME);
    } else if (!sparse.pathInSparseCheckout(dst_w_slash) and emptyDirHasSparseContents(idx, dst_w_slash)) {
        internalPrefix(&destinations, dst_w_slash, argv[0..argc], DUP_BASENAME);
        dst_mode = SKIP_WORKTREE_DIR;
    } else if (argc != 1) {
        util.die("destination '{s}' is not a directory", .{dest_paths.items[0]});
    } else {
        destinations.append(gpa, dest_paths.items[0]) catch util.oom();
        if (!pathInConeModeSparseCheckout(destinations.items[0])) dst_mode = SPARSE;
    }

    var src_dir: std.ArrayList([]const u8) = .empty;
    var moved_dirs: std.StringHashMapUnmanaged(void) = .empty;
    var src_for_dst: std.StringHashMapUnmanaged(void) = .empty;
    var only_match_skip_worktree: std.ArrayList([]const u8) = .empty;
    var dirty_paths: std.ArrayList([]const u8) = .empty;

    // Checking
    var i: usize = 0;
    while (i < argc) : (i +%= 1) {
        const src = sources.items[i];
        const dst = destinations.items[i];
        var bad: ?[]const u8 = null;
        var skip_sparse = false;
        if (show_only) util.outf("Checking rename of '{s}' to '{s}'\n", .{ src, dst });

        check: {
            var is_dir = false;
            if (os.lstatPath(src)) |st| {
                if (util.startsWith(dst, src) and (dst.len == src.len or dst[src.len] == '/')) {
                    bad = "can not move directory into itself";
                    break :check;
                }
                if (st.isDir() and os.lstatPath(dst) != null) {
                    bad = "destination already exists";
                    break :check;
                }
                is_dir = st.isDir();
            } else {
                if (stage0Pos(idx, src)) |pos| {
                    const ce = &idx.entries.items[pos];
                    if (!ce.skipWorktree()) {
                        bad = "bad source";
                        break :check;
                    }
                    if (!ignore_sparse) {
                        only_match_skip_worktree.append(gpa, src) catch util.oom();
                        break :check;
                    }
                    if (stage0Pos(idx, dst) == null) {
                        modes.items[i] |= SPARSE;
                        break :check;
                    }
                    if (force == 0) {
                        bad = "destination exists";
                        break :check;
                    }
                    modes.items[i] |= SPARSE;
                    break :check;
                }
                if (!sparse.pathInSparseCheckout(addSlash(src)) and emptyDirHasSparseContents(idx, src)) {
                    modes.items[i] |= SKIP_WORKTREE_DIR;
                    is_dir = true;
                } else {
                    // only error if existence is expected.
                    if (modes.items[i] & SPARSE == 0) bad = "bad source";
                    break :check;
                }
            }

            // dir_check:
            if (is_dir) {
                if (stage0Pos(idx, src)) |first| {
                    if (idx.entries.items[first].mode != 0o160000)
                        util.die("Directory {s} is in index and no submodule?", .{src});
                    if (!rm_cmd.isStagingGitmodulesOk(idx))
                        util.die("Please stage your changes to .gitmodules or stash them to proceed", .{});
                    gitfiles.items[i] = repo_mod.readGitfile(util.concat(&.{ src, "/.git" })) orelse "";
                    break :check;
                }
                const range = indexRangeOfSameDir(idx, src);
                if (range[1] <= range[0]) {
                    bad = "source directory is empty";
                    break :check;
                }
                moved_dirs.put(gpa, src, {}) catch util.oom();
                modes.items[i] |= WORKING_DIRECTORY;
                src_dir.append(gpa, src) catch util.oom();
                const dws = addSlash(dst);
                var j = range[0];
                while (j < range[1]) : (j += 1) {
                    const ce = &idx.entries.items[j];
                    sources.append(gpa, ce.path) catch util.oom();
                    destinations.append(gpa, prefixPath(dws, ce.path[src.len + 1 ..])) catch util.oom();
                    modes.append(gpa, MOVE_VIA_PARENT_DIR | (if (ce.skipWorktree()) SPARSE else INDEX)) catch util.oom();
                    gitfiles.append(gpa, null) catch util.oom();
                }
                argc += range[1] - range[0];
                break :check;
            }
            const pos = indexFileExists(idx, src) orelse {
                bad = "not under version control";
                break :check;
            };
            if (idx.entries.items[pos].stage() != 0) {
                bad = "conflicted";
                break :check;
            }
            if (os.lstatPath(dst)) |dst_st| {
                if (!ignoreCase() or !std.ascii.eqlIgnoreCase(src, dst)) {
                    bad = "destination exists";
                    if (force != 0) {
                        // only files can overwrite each other
                        if (dst_st.isReg() or dst_st.isLnk()) {
                            if (verbose != 0) util.warn("overwriting '{s}'", .{dst});
                            bad = null;
                        } else bad = "Cannot overwrite";
                    }
                    break :check;
                }
            }
            if (src_for_dst.contains(dst)) {
                bad = "multiple sources for the same target";
                break :check;
            }
            if (dst.len > 0 and dst[dst.len - 1] == '/') {
                bad = "destination directory does not exist";
                break :check;
            }
            if (hasSymlinkLeadingPath(dst)) {
                bad = "destination is beyond a symbolic link";
                break :check;
            }
            // If we are going to move SRC to DST on disk, DST's leading
            // directories must already exist.
            if (needsWorktreeRename(modes.items[i], dst_mode)) {
                if (std.mem.lastIndexOfScalar(u8, dst, '/')) |s| {
                    if (os.lstatPath(dst[0..s])) |ds| {
                        if (!ds.isDir()) bad = "destination is not a directory";
                    } else {
                        const e = os.errno();
                        if (e == os.ENOENT or e == os.ENOTDIR) bad = "destination directory does not exist";
                    }
                }
                if (bad != null) break :check;
            }
            if (ignore_sparse and dst_mode & (SKIP_WORKTREE_DIR | SPARSE) != 0 and indexFileExists(idx, dst) != null) {
                bad = "destination exists in the index";
                if (force != 0) {
                    if (verbose != 0) util.warn("overwriting '{s}'", .{dst});
                    bad = null;
                } else break :check;
            }
            // We check if the paths are in the sparse-checkout definition
            // as a very final check.
            if (!ignore_sparse and !sparse.pathInSparseCheckout(src)) {
                only_match_skip_worktree.append(gpa, src) catch util.oom();
                skip_sparse = true;
            }
            if (!ignore_sparse and !sparse.pathInSparseCheckout(dst)) {
                only_match_skip_worktree.append(gpa, dst) catch util.oom();
                skip_sparse = true;
            }
            if (skip_sparse) break :check;
            src_for_dst.put(gpa, dst, {}) catch util.oom();
        }

        // act_on_entry:
        if (!skip_sparse) {
            const b = bad orelse continue;
            if (!ignore_errors) util.die("{s}, source={s}, destination={s}", .{ b, src, dst });
        }
        // remove_entry:
        argc -= 1;
        if (argc > 0) {
            _ = sources.orderedRemove(i);
            _ = destinations.orderedRemove(i);
            _ = modes.orderedRemove(i);
            _ = gitfiles.orderedRemove(i);
            i -%= 1;
        }
    }

    for (0..argc) |k| {
        if (modes.items[k] & MOVE_VIA_PARENT_DIR != 0) continue;
        var p = sources.items[k];
        while (std.mem.lastIndexOfScalar(u8, p, '/')) |s| {
            if (s == 0) break;
            p = p[0..s];
            if (moved_dirs.contains(p))
                util.die("cannot move both '{s}' and its parent directory '{s}'", .{ sources.items[k], p });
        }
    }

    if (only_match_skip_worktree.items.len > 0) {
        add_cmd.adviseOnUpdatingSparsePaths(only_match_skip_worktree.items);
        if (!ignore_errors) {
            idx.rollback();
            return 1;
        }
    }

    const cone = sparse.configApply() and sparse.configCone();
    var gitmodules_modified = false;
    for (0..argc) |k| {
        const src = sources.items[k];
        const dst = destinations.items[k];
        const mode = modes.items[k];
        if (show_only or verbose != 0) util.outf("Renaming {s} to {s}\n", .{ src, dst });
        if (show_only) continue;
        if (needsWorktreeRename(mode, dst_mode) and !os.rename(src, dst)) {
            if (ignore_errors) continue;
            util.dieErrno("renaming '{s}' to '{s}' failed", .{ src, dst });
        }
        if (gitfiles.items[k]) |gf| {
            if (rm_cmd.updatePathInGitmodules(idx, src, dst)) gitmodules_modified = true;
            if (gf.len > 0) rm_cmd.connectWorkTreeAndGitDir(dst, gf);
        }
        if (mode & (WORKING_DIRECTORY | SKIP_WORKTREE_DIR) != 0) continue;
        const pos = stage0Pos(idx, src) orelse util.die("BUG: could not find source in index: '{s}'", .{src});
        var sparse_and_dirty = false;
        if (mode & SPARSE == 0) {
            if (os.lstatPath(src)) |st| sparse_and_dirty = idx.modified(&idx.entries.items[pos], st);
        }
        renameIndexEntryAt(idx, pos, dst);

        if (ignore_sparse and cone) {
            if (mode & SPARSE != 0 and sparse.pathInSparseCheckout(dst)) {
                // from out-of-cone to in-cone
                const dpos = stage0Pos(idx, dst) orelse continue;
                const dce = &idx.entries.items[dpos];
                dce.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
                var state = entry_mod.State{ .force = force != 0, .istate = idx };
                if (entry_mod.checkoutEntry(dce, &state, null)) util.die("cannot checkout {s}", .{dce.path});
            } else if (dst_mode & (SKIP_WORKTREE_DIR | SPARSE) != 0 and mode & SPARSE == 0 and
                !sparse.pathInSparseCheckout(dst))
            {
                // from in-cone to out-of-cone
                const dpos = stage0Pos(idx, dst) orelse continue;
                const dce = &idx.entries.items[dpos];
                if (!sparse_and_dirty) {
                    dce.ext_flags |= index_mod.CE_SKIP_WORKTREE;
                    if (!os.unlink(src) and os.errno() != os.ENOENT)
                        util.warn("unable to unlink '{s}': {s}", .{ src, os.lastErr() });
                } else {
                    dirty_paths.append(gpa, dst) catch util.oom();
                    _ = os.mkdirLeading(dst);
                    _ = os.rename(src, dst);
                }
            }
        }
    }

    // remove_empty_src_dirs()
    for (src_dir.items) |d| {
        const range = indexRangeOfSameDir(idx, d);
        if (range[1] <= range[0]) os.removeTree(d);
    }

    if (gitmodules_modified) rm_cmd.stageUpdatedGitmodules(idx);

    adviseOnMovingDirtyPath(dirty_paths.items);

    if (idx.changed) idx.write() else idx.rollback();
    return 0;
}
