//! git repo (port of builtin/repo.c): `info` and `structure`.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const revision = @import("../revision.zig");
const cn = @import("../commitnode.zig");
const objects = @import("../objects.zig");
const odb_mod = @import("../odb.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

const info_usage_1 = "git repo info [--format=(lines|nul) | -z] [--all | <key>...]";
const info_usage_2 = "git repo info --keys [--format=(lines|nul) | -z]";
const structure_usage_1 = "git repo structure [--format=(table|lines|nul) | -z]";

const repo_usage = [_][]const u8{ info_usage_1, info_usage_2, structure_usage_1 };
const repo_info_usage = [_][]const u8{ info_usage_1, info_usage_2 };
const repo_structure_usage = [_][]const u8{structure_usage_1};

const Format = enum { table, lines, nul };
var format: Format = .lines;

fn formatCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse "";
    if (util.eql(a, "nul")) {
        format = .nul;
    } else if (util.eql(a, "lines")) {
        format = .lines;
    } else if (util.eql(a, "table")) {
        format = .table;
    } else util.die("invalid format '{s}'", .{a});
}

fn zCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    format = .nul;
}

// ---------------------------------------------------------------------------
// path helpers (path.c format_path)

fn realpathForgiving(path: []const u8) []const u8 {
    if (os.realPath(path)) |r| return r;
    const abs = if (path.len > 0 and path[0] == '/') path else util.concat(&.{ os.getcwd(), "/", path });
    const n = util.normalizePath(abs) orelse abs;
    var end = n.len;
    while (end > 1) {
        const slash = std.mem.lastIndexOfScalar(u8, n[0..end], '/') orelse break;
        if (slash == 0) break;
        if (os.realPath(n[0..slash])) |r| return util.concat(&.{ r, n[slash..] });
        end = slash;
    }
    return n;
}

/// relative_path() from path.c
fn relativePath(in: []const u8, prefix: []const u8) []const u8 {
    if (in.len == 0) return "./";
    if (prefix.len == 0) return in;
    const in_abs = in[0] == '/';
    const pre_abs = prefix[0] == '/';
    if (in_abs != pre_abs) return in;
    var i: usize = 0;
    var j: usize = 0;
    var in_off: usize = 0;
    var prefix_off: usize = 0;
    while (i < prefix.len and j < in.len and prefix[i] == in[j]) {
        if (prefix[i] == '/') {
            while (i < prefix.len and prefix[i] == '/') i += 1;
            while (j < in.len and in[j] == '/') j += 1;
            prefix_off = i;
            in_off = j;
        } else {
            i += 1;
            j += 1;
        }
    }
    if (i >= prefix.len and prefix_off < prefix.len) {
        if (j >= in.len) {
            in_off = in.len;
        } else if (in[j] == '/') {
            while (j < in.len and in[j] == '/') j += 1;
            in_off = j;
        } else {
            i = prefix_off;
        }
    } else if (j >= in.len and in_off < in.len) {
        if (i < prefix.len and prefix[i] == '/') {
            while (i < prefix.len and prefix[i] == '/') i += 1;
            in_off = in.len;
        }
    }
    const rest = in[in_off..];
    if (i >= prefix.len) {
        return if (rest.len == 0) "./" else rest;
    }
    var b: util.Buf = .empty;
    while (i < prefix.len) {
        if (prefix[i] == '/') {
            util.bufAppend(&b, "../");
            while (i < prefix.len and prefix[i] == '/') i += 1;
            continue;
        }
        i += 1;
    }
    if (prefix[prefix.len - 1] != '/') util.bufAppend(&b, "../");
    util.bufAppend(&b, rest);
    return b.items;
}

fn formatRelative(path0: []const u8) []const u8 {
    const r = repo_mod.repo();
    var prefix: []const u8 = if (r.prefix.len > 0) r.prefix else os.getcwd();
    var path = path0;
    if (path.len == 0 or path[0] != '/') path = realpathForgiving(path);
    if (prefix.len == 0 or prefix[0] != '/') prefix = realpathForgiving(prefix);
    return relativePath(path, prefix);
}

// ---------------------------------------------------------------------------
// info

const Field = struct { key: []const u8, get: *const fn () []const u8 };

fn getBare() []const u8 {
    const r = repo_mod.repo();
    return if (r.bare_cfg != 0 and r.work_tree == null) "true" else "false";
}
fn getShallow() []const u8 {
    const sh = os.statPath(repo_mod.repo().gitPath("shallow"));
    return if (sh != null and sh.?.size > 0) "true" else "false";
}
fn getObjectFormat() []const u8 {
    return repo_mod.repo().object_format;
}
fn getCommonAbs() []const u8 {
    return realpathForgiving(repo_mod.repo().common_dir);
}
fn getCommonRel() []const u8 {
    return formatRelative(repo_mod.repo().common_dir);
}
fn getGitdirAbs() []const u8 {
    return realpathForgiving(repo_mod.repo().git_dir);
}
fn getGitdirRel() []const u8 {
    return formatRelative(repo_mod.repo().git_dir);
}
fn getRefFormat() []const u8 {
    return repo_mod.repo().ref_storage;
}

const fields = [_]Field{
    .{ .key = "layout.bare", .get = getBare },
    .{ .key = "layout.shallow", .get = getShallow },
    .{ .key = "object.format", .get = getObjectFormat },
    .{ .key = "path.commondir.absolute", .get = getCommonAbs },
    .{ .key = "path.commondir.relative", .get = getCommonRel },
    .{ .key = "path.gitdir.absolute", .get = getGitdirAbs },
    .{ .key = "path.gitdir.relative", .get = getGitdirRel },
    .{ .key = "references.format", .get = getRefFormat },
};

fn printField(key: []const u8, value: []const u8) void {
    switch (format) {
        .lines => util.outf("{s}={s}\n", .{ key, util.cquote(value) }),
        .nul => util.outf("{s}\n{s}\x00", .{ key, value }),
        .table => unreachable,
    }
}

fn cmdInfo(args: []const []const u8) u8 {
    format = .lines;
    var all = false;
    var keys = false;
    const options = [_]po.Opt{
        .{ .long = "format", .kind = .callback, .cb = formatCb, .argh = "format", .noneg = true, .help = "output format" },
        .{ .short = 'z', .kind = .callback, .cb = zCb, .noarg = true, .noneg = true, .help = "synonym for --format=nul" },
        po.boolean(0, "all", &all, "print all keys/values"),
        po.boolean(0, "keys", &keys, "show keys"),
    };
    const rest = po.parse(args, &options, &repo_info_usage, .{});
    if (keys and (all or rest.len > 0)) util.die("--keys cannot be used with a <key> or --all", .{});
    if (keys) {
        const sep: u8 = switch (format) {
            .lines => '\n',
            .nul => 0,
            .table => util.die("--keys can only be used with --format=lines or --format=nul", .{}),
        };
        for (fields) |f| util.outf("{s}{c}", .{ f.key, sep });
        util.flushStdout();
        return 0;
    }
    if (format != .lines and format != .nul) util.die("unsupported output format", .{});
    if (all and rest.len > 0) util.die("--all and <key> cannot be used together", .{});
    var ret: u8 = 0;
    if (all) {
        for (fields) |f| printField(f.key, f.get());
    } else {
        for (rest) |key| {
            var found: ?Field = null;
            for (fields) |f| {
                if (util.eql(f.key, key)) found = f;
            }
            if (found) |f| {
                printField(f.key, f.get());
            } else {
                util.flushStdout();
                util.err("key '{s}' not found", .{key});
                ret = 1;
            }
        }
    }
    util.flushStdout();
    return ret;
}

// ---------------------------------------------------------------------------
// structure

const ObjData = struct { oid: Oid = hash.zero, value: usize = 0 };
const Values = struct { tags: usize = 0, commits: usize = 0, trees: usize = 0, blobs: usize = 0 };

const Stats = struct {
    branches: usize = 0,
    remotes: usize = 0,
    tags: usize = 0,
    others: usize = 0,
    counts: Values = .{},
    inflated: Values = .{},
    disk: Values = .{},
    tag_size: ObjData = .{},
    commit_size: ObjData = .{},
    tree_size: ObjData = .{},
    blob_size: ObjData = .{},
    parent_count: ObjData = .{},
    tree_entries: ObjData = .{},
};

fn checkLargest(d: *ObjData, oid: Oid, value: usize) void {
    if (value > d.value or hash.isZero(d.oid)) {
        d.oid = oid;
        d.value = value;
    }
}

fn total(v: Values) usize {
    return v.tags + v.commits + v.trees + v.blobs;
}

/// Sorted entry offsets of a pack, for computing on-disk sizes.
const PackOffsets = struct { pack: *odb_mod.Pack, offsets: []u64, end: u64 };
var pack_offsets: std.ArrayList(PackOffsets) = .empty;

fn diskSize(oid: Oid) usize {
    const db = repo_mod.repo().odb();
    if (db.findPacked(oid)) |f| {
        var po_: ?*PackOffsets = null;
        for (pack_offsets.items) |*p| {
            if (p.pack == f.pack) po_ = p;
        }
        if (po_ == null) {
            const offs = gpa.alloc(u64, f.pack.num) catch util.oom();
            var i: u32 = 0;
            while (i < f.pack.num) : (i += 1) offs[i] = f.pack.offsetAt(i);
            std.mem.sort(u64, offs, {}, std.sort.asc(u64));
            const st = os.statPath(f.pack.pack_path);
            const sz: u64 = if (st) |s| @intCast(@max(s.size, 20)) else 20;
            pack_offsets.append(gpa, .{ .pack = f.pack, .offsets = offs, .end = sz - 20 }) catch util.oom();
            po_ = &pack_offsets.items[pack_offsets.items.len - 1];
        }
        const p = po_.?;
        const off = f.pack.offsetAt(f.idx);
        var lo: usize = 0;
        var hi: usize = p.offsets.len;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            if (p.offsets[mid] <= off) lo = mid + 1 else hi = mid;
        }
        const next = if (lo < p.offsets.len) p.offsets[lo] else p.end;
        return @intCast(next - off);
    }
    for (db.allDirs()) |dir| {
        if (os.statPath(db.looseObjectPath(dir, oid))) |st| return @intCast(@max(st.size, 0));
    }
    return 0;
}

const Type = enum(u8) { tag = 0, blob = 1, tree = 2, commit = 3 };

const PathList = struct { typ: Type, oids: std.ArrayList(Oid) = .empty, seq: usize = 0 };

const Walk = struct {
    lists: std.StringHashMap(*PathList),
    pushed: std.StringHashMap(void),
    stack: std.ArrayList([]const u8) = .empty,
    seen: hash.OidSet = .empty,
    seq: usize = 0,
    stats: *Stats,

    fn list(w: *Walk, path: []const u8, typ: Type) *PathList {
        if (w.lists.get(path)) |l| return l;
        const l = gpa.create(PathList) catch util.oom();
        l.* = .{ .typ = typ };
        w.lists.put(util.dupe(path), l) catch util.oom();
        return l;
    }

    fn push(w: *Walk, path: []const u8) void {
        if (w.pushed.contains(path)) return;
        const p = util.dupe(path);
        w.pushed.put(p, {}) catch util.oom();
        w.seq += 1;
        if (w.lists.get(p)) |l| l.seq = w.seq;
        w.stack.append(gpa, p) catch util.oom();
    }

    fn rank(t: Type) u8 {
        return switch (t) {
            .tag => 0,
            .blob => 1,
            else => 2,
        };
    }

    /// prio_queue_get with compare_by_type (ties broken by insertion order).
    fn pop(w: *Walk) ?[]const u8 {
        if (w.stack.items.len == 0) return null;
        var best: usize = 0;
        for (w.stack.items, 0..) |p, i| {
            if (i == 0) continue;
            if (w.before(p, w.stack.items[best])) best = i;
        }
        return w.stack.orderedRemove(best);
    }

    fn before(w: *Walk, a: []const u8, b: []const u8) bool {
        const la = w.lists.get(a);
        const lb = w.lists.get(b);
        if (la == null or lb == null or la.?.typ == lb.?.typ or rank(la.?.typ) == rank(lb.?.typ)) {
            const o = std.mem.order(u8, a, b);
            if (o != .eq or la == null or lb == null) return o == .lt;
            return false;
        }
        return rank(la.?.typ) < rank(lb.?.typ);
    }

    fn addTreeEntries(w: *Walk, base: []const u8, oid: Oid) void {
        const obj = repo_mod.repo().odb().read(oid) orelse return;
        if (obj.typ != .tree) return;
        var it = objects.TreeIter{ .data = obj.data };
        while (it.next()) |e| {
            if (e.mode & 0o170000 == 0o160000) continue;
            const is_tree = e.mode & 0o170000 == 0o040000;
            if (w.seen.contains(e.oid)) continue;
            w.seen.put(gpa, e.oid, {}) catch util.oom();
            const path = if (is_tree) util.concat(&.{ base, e.name, "/" }) else util.concat(&.{ base, e.name });
            const l = w.list(path, if (is_tree) .tree else .blob);
            l.oids.append(gpa, e.oid) catch util.oom();
            w.push(path);
        }
    }

    fn countObjects(w: *Walk, oids: []const Oid, typ: Type) void {
        const s = w.stats;
        const db = repo_mod.repo().odb();
        for (oids) |oid| {
            const obj = db.readNoReplace(oid) orelse continue;
            const inflated = obj.data.len;
            const disk = diskSize(oid);
            switch (typ) {
                .tag => {
                    s.counts.tags += 1;
                    s.inflated.tags += inflated;
                    s.disk.tags += disk;
                    checkLargest(&s.tag_size, oid, inflated);
                },
                .commit => {
                    s.counts.commits += 1;
                    s.inflated.commits += inflated;
                    s.disk.commits += disk;
                    checkLargest(&s.commit_size, oid, inflated);
                    var np: usize = 0;
                    if (cn.lookupCommit(oid)) |c| {
                        _ = cn.parse(c);
                        var p = c.parents;
                        while (p) |pp| : (p = pp.next) np += 1;
                    }
                    checkLargest(&s.parent_count, oid, np);
                },
                .tree => {
                    s.counts.trees += 1;
                    s.inflated.trees += inflated;
                    s.disk.trees += disk;
                    checkLargest(&s.tree_size, oid, inflated);
                    var n: usize = 0;
                    var it = objects.TreeIter{ .data = obj.data };
                    while (it.next()) |_| n += 1;
                    checkLargest(&s.tree_entries, oid, n);
                },
                .blob => {
                    s.counts.blobs += 1;
                    s.inflated.blobs += inflated;
                    s.disk.blobs += disk;
                    checkLargest(&s.blob_size, oid, inflated);
                },
            }
        }
    }

    fn walkPath(w: *Walk, path: []const u8) void {
        const l = w.lists.get(path) orelse return;
        _ = w.lists.remove(path);
        if (l.oids.items.len == 0) return;
        w.countObjects(l.oids.items, l.typ);
        if (l.typ == .tree) {
            const expand = if (util.eql(path, "/tagged-trees")) "" else path;
            for (l.oids.items) |o| w.addTreeEntries(expand, o);
        }
    }
};

fn countRefsAndObjects(stats: *Stats) void {
    var revs = revision.RevInfo.init(repo_mod.repo().prefix);
    const db = repo_mod.repo().odb();
    var w = Walk{
        .lists = std.StringHashMap(*PathList).init(gpa),
        .pushed = std.StringHashMap(void).init(gpa),
        .stats = stats,
    };
    const root = w.list("", .tree);
    w.push("");

    var tags: std.ArrayList(Oid) = .empty;
    var tagged_blobs: std.ArrayList(Oid) = .empty;
    var tagged_trees: std.ArrayList(Oid) = .empty;
    var commits_pending: std.ArrayList(Oid) = .empty;

    for (refs.iterate("refs/", .{ .check_objects = false })) |ref| {
        if (util.startsWith(ref.name, "refs/heads/")) {
            stats.branches += 1;
        } else if (util.startsWith(ref.name, "refs/remotes/")) {
            stats.remotes += 1;
        } else if (util.startsWith(ref.name, "refs/tags/")) {
            stats.tags += 1;
        } else stats.others += 1;

        var oid = ref.oid;
        var typ = db.readType(oid) orelse continue;
        var stop = false;
        while (typ == .tag) {
            if (w.seen.contains(oid)) {
                stop = true;
                break;
            }
            w.seen.put(gpa, oid, {}) catch util.oom();
            tags.append(gpa, oid) catch util.oom();
            const obj = db.read(oid) orelse {
                stop = true;
                break;
            };
            const t = objects.parseTag(obj.data) orelse {
                stop = true;
                break;
            };
            oid = t.object;
            typ = db.readType(oid) orelse {
                stop = true;
                break;
            };
        }
        if (stop) continue;
        switch (typ) {
            .commit => commits_pending.append(gpa, oid) catch util.oom(),
            .tree => {
                if (!w.seen.contains(oid)) {
                    w.seen.put(gpa, oid, {}) catch util.oom();
                    tagged_trees.append(gpa, oid) catch util.oom();
                }
            },
            .blob => {
                if (!w.seen.contains(oid)) {
                    w.seen.put(gpa, oid, {}) catch util.oom();
                    tagged_blobs.append(gpa, oid) catch util.oom();
                }
            },
            else => {},
        }
    }
    if (tagged_blobs.items.len > 0) {
        w.list("/tagged-blobs", .blob).oids = tagged_blobs;
        w.push("/tagged-blobs");
    }
    if (tagged_trees.items.len > 0) {
        w.list("/tagged-trees", .tree).oids = tagged_trees;
        w.push("/tagged-trees");
    }
    if (tags.items.len > 0) {
        w.list("/tags", .tag).oids = tags;
        w.push("/tags");
    }

    for (commits_pending.items) |c| revision.addPendingOid(&revs, "", c, 0);
    var commits: std.ArrayList(Oid) = .empty;
    if (commits_pending.items.len > 0) {
        if (!revision.prepareRevisionWalk(&revs)) util.die("failed to setup revision walk", .{});
        while (revision.getRevision(&revs)) |c| {
            commits.append(gpa, c.obj.oid) catch util.oom();
            if (w.seen.contains(c.tree)) continue;
            w.seen.put(gpa, c.tree, {}) catch util.oom();
            root.oids.append(gpa, c.tree) catch util.oom();
        }
    }
    if (commits.items.len > 0) w.countObjects(commits.items, .commit);
    while (w.pop()) |p| w.walkPath(p);
}

fn humaniseCount(n: usize) struct { v: []const u8, u: ?[]const u8 } {
    if (n >= 1000000000) {
        const x = n + 5000000;
        return .{ .v = util.fmt("{d}.{d:0>2}", .{ x / 1000000000, x % 1000000000 / 10000000 }), .u = "G" };
    } else if (n >= 1000000) {
        const x = n + 5000;
        return .{ .v = util.fmt("{d}.{d:0>2}", .{ x / 1000000, x % 1000000 / 10000 }), .u = "M" };
    } else if (n >= 1000) {
        const x = n + 5;
        return .{ .v = util.fmt("{d}.{d:0>2}", .{ x / 1000, x % 1000 / 10 }), .u = "k" };
    }
    return .{ .v = util.fmt("{d}", .{n}), .u = null };
}

fn humaniseBytes(bytes: usize) struct { v: []const u8, u: ?[]const u8 } {
    if (bytes > 1 << 30) {
        return .{ .v = util.fmt("{d}.{d:0>2}", .{ bytes >> 30, @as(u32, @truncate(bytes & ((1 << 30) - 1))) / 10737419 }), .u = "GiB" };
    } else if (bytes > 1 << 20) {
        const x: u32 = @truncate(bytes + 5243);
        return .{ .v = util.fmt("{d}.{d:0>2}", .{ x >> 20, ((x & ((1 << 20) - 1)) * 100) >> 20 }), .u = "MiB" };
    } else if (bytes > 1 << 10) {
        const x: u32 = @truncate(bytes + 5);
        return .{ .v = util.fmt("{d}.{d:0>2}", .{ x >> 10, ((x & ((1 << 10) - 1)) * 100) >> 10 }), .u = "KiB" };
    }
    return .{ .v = util.fmt("{d}", .{bytes}), .u = "B" };
}

const Row = struct {
    name: []const u8,
    has_entry: bool = false,
    value: []const u8 = "",
    unit: ?[]const u8 = null,
    index: usize = 0,
    has_oid: bool = false,
};

const Table = struct {
    rows: std.ArrayList(Row) = .empty,
    annotations: std.ArrayList([]const u8) = .empty,
    name_w: usize = 0,
    value_w: usize = 0,
    unit_w: usize = 0,

    fn add(t: *Table, row0: Row, oid: ?Oid) void {
        var row = row0;
        const nw = row.name.len;
        if (nw > t.name_w) t.name_w = nw;
        if (row.has_entry) {
            if (oid) |o| {
                if (!hash.isZero(o)) {
                    row.has_oid = true;
                    row.index = t.annotations.items.len + 1;
                    t.annotations.append(gpa, util.fmt("[{d}] {s}", .{ row.index, hash.hex(o) })) catch util.oom();
                }
            }
            const vw = row.value.len;
            if (vw > t.value_w) t.value_w = vw;
            if (row.unit) |u| {
                const uw = u.len;
                if (uw > t.unit_w) t.unit_w = uw;
            }
        }
        t.rows.append(gpa, row) catch util.oom();
    }
    fn heading(t: *Table, name: []const u8) void {
        t.add(.{ .name = name }, null);
    }
    fn count(t: *Table, name: []const u8, n: usize) void {
        const h = humaniseCount(n);
        t.add(.{ .name = name, .has_entry = true, .value = h.v, .unit = h.u }, null);
    }
    fn objCount(t: *Table, name: []const u8, d: ObjData) void {
        const h = humaniseCount(d.value);
        t.add(.{ .name = name, .has_entry = true, .value = h.v, .unit = h.u }, d.oid);
    }
    fn size(t: *Table, name: []const u8, n: usize) void {
        const h = humaniseBytes(n);
        t.add(.{ .name = name, .has_entry = true, .value = h.v, .unit = h.u }, null);
    }
    fn objSize(t: *Table, name: []const u8, d: ObjData) void {
        const h = humaniseBytes(d.value);
        t.add(.{ .name = name, .has_entry = true, .value = h.v, .unit = h.u }, d.oid);
    }
};

fn alignLeft(b: *util.Buf, width: usize, s: []const u8) void {
    util.bufAppend(b, s);
    const w = s.len;
    var i = w;
    while (i < width) : (i += 1) util.bufByte(b, ' ');
}

fn alignRight(b: *util.Buf, width: usize, s: []const u8) void {
    const w = s.len;
    var i = w;
    while (i < width) : (i += 1) util.bufByte(b, ' ');
    util.bufAppend(b, s);
}

const INDEX_WIDTH = 4;

fn printTable(s: *const Stats) void {
    var t = Table{};
    t.heading("* References");
    t.count("  * Count", s.branches + s.remotes + s.tags + s.others);
    t.count("    * Branches", s.branches);
    t.count("    * Tags", s.tags);
    t.count("    * Remotes", s.remotes);
    t.count("    * Others", s.others);
    t.heading("");
    t.heading("* Reachable objects");
    t.count("  * Count", total(s.counts));
    t.count("    * Commits", s.counts.commits);
    t.count("    * Trees", s.counts.trees);
    t.count("    * Blobs", s.counts.blobs);
    t.count("    * Tags", s.counts.tags);
    t.size("  * Inflated size", total(s.inflated));
    t.size("    * Commits", s.inflated.commits);
    t.size("    * Trees", s.inflated.trees);
    t.size("    * Blobs", s.inflated.blobs);
    t.size("    * Tags", s.inflated.tags);
    t.size("  * Disk size", total(s.disk));
    t.size("    * Commits", s.disk.commits);
    t.size("    * Trees", s.disk.trees);
    t.size("    * Blobs", s.disk.blobs);
    t.size("    * Tags", s.disk.tags);
    t.heading("");
    t.heading("* Largest objects");
    t.heading("  * Commits");
    t.objSize("    * Maximum size", s.commit_size);
    t.objCount("    * Maximum parents", s.parent_count);
    t.heading("  * Trees");
    t.objSize("    * Maximum size", s.tree_size);
    t.objCount("    * Maximum entries", s.tree_entries);
    t.heading("  * Blobs");
    t.objSize("    * Maximum size", s.blob_size);
    t.heading("  * Tags");
    t.objSize("    * Maximum size", s.tag_size);

    const name_title = "Repository structure";
    const value_title = "Value";
    var name_w = t.name_w;
    var value_w = t.value_w;
    const unit_w = t.unit_w;
    if (name_title.len > name_w) name_w = name_title.len;
    if (value_title.len > value_w + unit_w + 1) value_w = value_title.len - unit_w;

    var b: util.Buf = .empty;
    util.bufAppend(&b, "| ");
    alignLeft(&b, name_w + INDEX_WIDTH, name_title);
    util.bufAppend(&b, " | ");
    alignLeft(&b, value_w + unit_w + 1, value_title);
    util.bufAppend(&b, " |\n| ");
    var i: usize = 0;
    while (i < name_w + INDEX_WIDTH) : (i += 1) util.bufByte(&b, '-');
    util.bufAppend(&b, " | ");
    i = 0;
    while (i < value_w + unit_w + 1) : (i += 1) util.bufByte(&b, '-');
    util.bufAppend(&b, " |\n");
    for (t.rows.items) |row| {
        util.bufAppend(&b, "| ");
        alignLeft(&b, name_w, row.name);
        if (row.has_oid) {
            util.bufAppend(&b, util.fmt(" [{d}]", .{row.index}));
        } else util.bufAppend(&b, "    ");
        util.bufAppend(&b, " | ");
        alignRight(&b, value_w, row.value);
        util.bufByte(&b, ' ');
        alignLeft(&b, unit_w, row.unit orelse "");
        util.bufAppend(&b, " |\n");
    }
    if (t.annotations.items.len > 0) {
        util.bufByte(&b, '\n');
        for (t.annotations.items) |a| {
            util.bufAppend(&b, a);
            util.bufByte(&b, '\n');
        }
    }
    util.out(b.items);
}

fn kv(key: []const u8, kd: u8, v: usize, vd: u8) void {
    util.outf("{s}{c}{d}{c}", .{ key, kd, v, vd });
}

fn kvObj(key: []const u8, kd: u8, d: ObjData, vd: u8) void {
    kv(key, kd, d.value, vd);
    util.outf("{s}_oid{c}{s}{c}", .{ key, kd, hash.hex(d.oid), vd });
}

fn printKeyValue(s: *const Stats, kd: u8, vd: u8) void {
    kv("references.branches.count", kd, s.branches, vd);
    kv("references.tags.count", kd, s.tags, vd);
    kv("references.remotes.count", kd, s.remotes, vd);
    kv("references.others.count", kd, s.others, vd);
    kv("objects.commits.count", kd, s.counts.commits, vd);
    kv("objects.trees.count", kd, s.counts.trees, vd);
    kv("objects.blobs.count", kd, s.counts.blobs, vd);
    kv("objects.tags.count", kd, s.counts.tags, vd);
    kv("objects.commits.inflated_size", kd, s.inflated.commits, vd);
    kv("objects.trees.inflated_size", kd, s.inflated.trees, vd);
    kv("objects.blobs.inflated_size", kd, s.inflated.blobs, vd);
    kv("objects.tags.inflated_size", kd, s.inflated.tags, vd);
    kv("objects.commits.disk_size", kd, s.disk.commits, vd);
    kv("objects.trees.disk_size", kd, s.disk.trees, vd);
    kv("objects.blobs.disk_size", kd, s.disk.blobs, vd);
    kv("objects.tags.disk_size", kd, s.disk.tags, vd);
    kvObj("objects.commits.max_size", kd, s.commit_size, vd);
    kvObj("objects.trees.max_size", kd, s.tree_size, vd);
    kvObj("objects.blobs.max_size", kd, s.blob_size, vd);
    kvObj("objects.tags.max_size", kd, s.tag_size, vd);
    kvObj("objects.commits.max_parents", kd, s.parent_count, vd);
    kvObj("objects.trees.max_entries", kd, s.tree_entries, vd);
}

fn cmdStructure(args: []const []const u8) u8 {
    format = .table;
    var progress = false;
    const options = [_]po.Opt{
        .{ .long = "format", .kind = .callback, .cb = formatCb, .argh = "format", .noneg = true, .help = "output format" },
        .{ .short = 'z', .kind = .callback, .cb = zCb, .noarg = true, .noneg = true, .help = "synonym for --format=nul" },
        po.boolean(0, "progress", &progress, "show progress"),
    };
    const rest = po.parse(args, &options, &repo_structure_usage, .{});
    if (rest.len > 0) {
        util.eprint("usage: too many arguments\n", .{});
        os.exit(129);
    }
    var stats = Stats{};
    countRefsAndObjects(&stats);
    switch (format) {
        .table => printTable(&stats),
        .lines => printKeyValue(&stats, '=', '\n'),
        .nul => printKeyValue(&stats, '\n', 0),
    }
    util.flushStdout();
    return 0;
}

pub fn cmdRepo(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").repo);
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&repo_usage, &.{});
    }
    const sub = args[1];
    const rest = args[2..];
    if (util.eql(sub, "-h") or util.eql(sub, "--help-all")) po.usageExit(&repo_usage, &.{}, false);
    if (util.eql(sub, "info")) return cmdInfo(rest);
    if (util.eql(sub, "structure")) return cmdStructure(rest);
    if (sub.len > 0 and sub[0] == '-') {
        if (util.startsWith(sub, "--")) {
            util.err("unknown option `{s}'", .{sub[2..]});
        } else util.err("unknown switch `{c}'", .{if (sub.len > 1) sub[1] else '-'});
    } else util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&repo_usage, &.{});
}
