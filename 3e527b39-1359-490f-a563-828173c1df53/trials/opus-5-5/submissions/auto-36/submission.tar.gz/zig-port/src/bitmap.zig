//! Reachability bitmaps: EWAH compressed bitmaps (ewah/*.c), the pack
//! .bitmap writer (pack-bitmap-write.c) and a reader for rev-list
//! --use-bitmap-index / --test-bitmap (pack-bitmap.c).  Single-pack
//! bitmaps only; multi-pack (.midx) bitmaps are neither read nor written.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const objects = @import("objects.zig");
const cn = @import("commitnode.zig");
const progress = @import("progress.zig");
const pack = @import("pack.zig");
const revision = @import("revision.zig");
const objfilter = @import("objfilter.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;

pub const OPT_FULL_DAG: u16 = 0x1;
pub const OPT_HASH_CACHE: u16 = 0x4;
pub const OPT_LOOKUP_TABLE: u16 = 0x10;
pub const OPT_PSEUDO_MERGES: u16 = 0x20;

// ------------------------------------------------------------------ EWAH

const BITS: usize = 64;
const LARGEST_RUNNING: u64 = (1 << 32) - 1;
const LARGEST_LITERAL: u64 = (1 << 31) - 1;
const RUNNING_SHIFT: u64 = LARGEST_RUNNING << 1;
const RUNNING_LEN_PLUS_BIT: u64 = (1 << 33) - 1;

fn runBit(w: u64) bool {
    return w & 1 != 0;
}
fn setRunBit(w: *u64, b: bool) void {
    if (b) w.* |= 1 else w.* &= ~@as(u64, 1);
}
fn runningLen(w: u64) u64 {
    return (w >> 1) & LARGEST_RUNNING;
}
fn setRunningLen(w: *u64, l: u64) void {
    w.* |= RUNNING_SHIFT;
    w.* &= (l << 1) | ~RUNNING_SHIFT;
}
fn literalWords(w: u64) u64 {
    return w >> 33;
}
fn setLiteralWords(w: *u64, l: u64) void {
    w.* |= ~RUNNING_LEN_PLUS_BIT;
    w.* &= (l << 33) | RUNNING_LEN_PLUS_BIT;
}
fn rlwSize(w: u64) u64 {
    return runningLen(w) + literalWords(w);
}

pub const Ewah = struct {
    buf: std.ArrayList(u64) = .empty,
    bit_size: usize = 0,
    rlw: usize = 0,

    pub fn init() Ewah {
        var e = Ewah{};
        e.buf.append(gpa, 0) catch util.oom();
        return e;
    }

    fn rlwp(self: *Ewah) *u64 {
        return &self.buf.items[self.rlw];
    }
    fn push(self: *Ewah, v: u64) void {
        self.buf.append(gpa, v) catch util.oom();
    }
    fn pushRlw(self: *Ewah, v: u64) void {
        self.push(v);
        self.rlw = self.buf.items.len - 1;
    }

    fn addEmptyWordsRaw(self: *Ewah, v: bool, number0: usize) usize {
        var number: u64 = number0;
        var added: usize = 0;
        const r = self.rlwp().*;
        if (runBit(r) != v and rlwSize(r) == 0) {
            setRunBit(self.rlwp(), v);
        } else if (literalWords(r) != 0 or runBit(r) != v) {
            self.pushRlw(0);
            if (v) setRunBit(self.rlwp(), v);
            added += 1;
        }
        const runlen = runningLen(self.rlwp().*);
        const can_add = @min(number, LARGEST_RUNNING - runlen);
        setRunningLen(self.rlwp(), runlen + can_add);
        number -= can_add;
        while (number >= LARGEST_RUNNING) {
            self.pushRlw(0);
            added += 1;
            if (v) setRunBit(self.rlwp(), v);
            setRunningLen(self.rlwp(), LARGEST_RUNNING);
            number -= LARGEST_RUNNING;
        }
        if (number > 0) {
            self.pushRlw(0);
            added += 1;
            if (v) setRunBit(self.rlwp(), v);
            setRunningLen(self.rlwp(), number);
        }
        return added;
    }

    pub fn addEmptyWords(self: *Ewah, v: bool, number: usize) usize {
        if (number == 0) return 0;
        self.bit_size += number * BITS;
        return self.addEmptyWordsRaw(v, number);
    }

    fn addLiteral(self: *Ewah, data: u64) usize {
        const cur = literalWords(self.rlwp().*);
        if (cur >= LARGEST_LITERAL) {
            self.pushRlw(0);
            setLiteralWords(self.rlwp(), 1);
            self.push(data);
            return 2;
        }
        setLiteralWords(self.rlwp(), cur + 1);
        self.push(data);
        return 1;
    }

    pub fn addDirtyWords(self: *Ewah, words0: []const u64, negate: bool) void {
        var words = words0;
        var number: usize = words.len;
        while (true) {
            const literals = literalWords(self.rlwp().*);
            const can_add: usize = @intCast(@min(@as(u64, number), LARGEST_LITERAL - literals));
            setLiteralWords(self.rlwp(), literals + can_add);
            for (words[0..can_add]) |w| self.push(if (negate) ~w else w);
            self.bit_size += can_add * BITS;
            if (number - can_add == 0) break;
            self.pushRlw(0);
            words = words[can_add..];
            number -= can_add;
        }
    }

    fn addEmptyWord(self: *Ewah, v: bool) usize {
        const no_literal = literalWords(self.rlwp().*) == 0;
        const run_len = runningLen(self.rlwp().*);
        if (no_literal and run_len == 0) setRunBit(self.rlwp(), v);
        if (no_literal and runBit(self.rlwp().*) == v and run_len < LARGEST_RUNNING) {
            setRunningLen(self.rlwp(), run_len + 1);
            return 0;
        }
        self.pushRlw(0);
        setRunBit(self.rlwp(), v);
        setRunningLen(self.rlwp(), 1);
        return 1;
    }

    pub fn add(self: *Ewah, word: u64) usize {
        self.bit_size += BITS;
        if (word == 0) return self.addEmptyWord(false);
        if (word == ~@as(u64, 0)) return self.addEmptyWord(true);
        return self.addLiteral(word);
    }

    /// ewah_set(): bits must be set in increasing order.
    pub fn set(self: *Ewah, i: usize) void {
        const dist = (i + 1 + BITS - 1) / BITS - (self.bit_size + BITS - 1) / BITS;
        self.bit_size = i + 1;
        const bit = @as(u64, 1) << @intCast(i % BITS);
        if (dist > 0) {
            if (dist > 1) _ = self.addEmptyWordsRaw(false, dist - 1);
            _ = self.addLiteral(bit);
            return;
        }
        if (literalWords(self.rlwp().*) == 0) {
            setRunningLen(self.rlwp(), runningLen(self.rlwp().*) - 1);
            _ = self.addLiteral(bit);
            return;
        }
        const last = &self.buf.items[self.buf.items.len - 1];
        last.* |= bit;
        if (last.* == ~@as(u64, 0)) {
            self.buf.items.len -= 1;
            setLiteralWords(self.rlwp(), literalWords(self.rlwp().*) - 1);
            _ = self.addEmptyWord(true);
        }
    }

    pub fn serialize(self: *const Ewah, out: *util.Buf) void {
        put32(out, @truncate(self.bit_size));
        put32(out, @intCast(self.buf.items.len));
        for (self.buf.items) |w| put64(out, w);
        put32(out, @intCast(self.rlw));
    }

    /// ewah_read_mmap(); returns bytes consumed or null (error printed).
    pub fn read(self: *Ewah, data: []const u8) ?usize {
        if (data.len < 4) return errNull("corrupt ewah bitmap: eof before bit size", .{});
        self.bit_size = std.mem.readInt(u32, data[0..4], .big);
        if (data.len < 8) return errNull("corrupt ewah bitmap: eof before length", .{});
        const n: usize = std.mem.readInt(u32, data[4..8], .big);
        const dlen = n * 8;
        if (data.len - 8 < dlen) return errNull("corrupt ewah bitmap: eof in data ({d} bytes short)", .{dlen - (data.len - 8)});
        self.buf = .empty;
        self.buf.ensureTotalCapacity(gpa, n) catch util.oom();
        var k: usize = 0;
        while (k < n) : (k += 1) self.buf.appendAssumeCapacity(std.mem.readInt(u64, data[8 + k * 8 ..][0..8], .big));
        const p = 8 + dlen;
        if (data.len - p < 4) return errNull("corrupt ewah bitmap: eof before rlw", .{});
        self.rlw = std.mem.readInt(u32, data[p..][0..4], .big);
        return p + 4;
    }

    pub fn checksum(self: *const Ewah) u32 {
        var crc: u32 = @truncate(self.bit_size);
        const bytes = std.mem.sliceAsBytes(self.buf.items);
        for (bytes) |b| crc = (crc << 5) -% crc +% b;
        return crc;
    }

    pub fn toBitmap(self: *const Ewah) Bitmap {
        var b = Bitmap{};
        var it = EwahIter.init(self);
        while (it.next()) |w| b.words.append(gpa, w) catch util.oom();
        return b;
    }
};

fn errNull(comptime f: []const u8, args: anytype) ?usize {
    util.err(f, args);
    return null;
}

const EwahIter = struct {
    buffer: []const u64,
    pointer: usize = 0,
    lw: u64 = 0,
    rl: u64 = 0,
    compressed: u64 = 0,
    literals: u64 = 0,
    b: bool = false,

    fn init(e: *const Ewah) EwahIter {
        var it = EwahIter{ .buffer = e.buf.items };
        if (it.pointer < it.buffer.len) it.readNewRlw();
        return it;
    }
    fn readNewRlw(it: *EwahIter) void {
        it.literals = 0;
        it.compressed = 0;
        while (true) {
            const w = it.buffer[it.pointer];
            it.rl = runningLen(w);
            it.lw = literalWords(w);
            it.b = runBit(w);
            if (it.rl != 0 or it.lw != 0) return;
            if (it.pointer < it.buffer.len - 1) {
                it.pointer += 1;
            } else {
                it.pointer = it.buffer.len;
                return;
            }
        }
    }
    fn next(it: *EwahIter) ?u64 {
        if (it.pointer >= it.buffer.len) return null;
        var out: u64 = 0;
        if (it.compressed < it.rl) {
            it.compressed += 1;
            out = if (it.b) ~@as(u64, 0) else 0;
        } else {
            it.literals += 1;
            it.pointer += 1;
            if (it.pointer >= it.buffer.len) return null;
            out = it.buffer[it.pointer];
        }
        if (it.compressed == it.rl and it.literals == it.lw) {
            it.pointer += 1;
            if (it.pointer < it.buffer.len) it.readNewRlw();
        }
        return out;
    }
};

const RlwIt = struct {
    buffer: []const u64,
    pointer: usize = 0,
    literal_word_start: usize = 0,
    literal_words: usize = 0,
    running_len: usize = 0,
    literal_word_offset: usize = 0,
    running_bit: bool = false,

    fn nextWord(it: *RlwIt) bool {
        if (it.pointer >= it.buffer.len) return false;
        const w = it.buffer[it.pointer];
        it.pointer += @intCast(literalWords(w) + 1);
        it.literal_words = @intCast(literalWords(w));
        it.running_len = @intCast(runningLen(w));
        it.running_bit = runBit(w);
        it.literal_word_offset = 0;
        return true;
    }
    fn init(e: *const Ewah) RlwIt {
        var it = RlwIt{ .buffer = e.buf.items };
        _ = it.nextWord();
        it.literal_word_start = it.literalPos() + it.literal_word_offset;
        return it;
    }
    fn literalPos(it: *const RlwIt) usize {
        return it.pointer - it.literal_words;
    }
    fn wordSize(it: *const RlwIt) usize {
        return it.running_len + it.literal_words;
    }
    fn discardFirstWords(it: *RlwIt, x0: usize) void {
        var x = x0;
        while (x > 0) {
            if (it.running_len > x) {
                it.running_len -= x;
                return;
            }
            x -= it.running_len;
            it.running_len = 0;
            const discard = @min(x, it.literal_words);
            it.literal_word_start += discard;
            it.literal_words -= discard;
            x -= discard;
            if (x > 0 or it.wordSize() == 0) {
                if (!it.nextWord()) break;
                it.literal_word_start = it.literalPos() + it.literal_word_offset;
            }
        }
    }
    fn discharge(it: *RlwIt, out: *Ewah, max: usize, negate: bool) usize {
        var index: usize = 0;
        while (index < max and it.wordSize() > 0) {
            var pl = it.running_len;
            if (pl > max - index) pl = max - index;
            _ = out.addEmptyWords(it.running_bit != negate, pl);
            index += pl;
            var pd = it.literal_words;
            if (pd > max - index) pd = max - index;
            out.addDirtyWords(it.buffer[it.literal_word_start..][0..pd], negate);
            it.discardFirstWords(pd + pl);
            index += pd;
        }
        return index;
    }
};

pub fn ewahXor(a: *const Ewah, b: *const Ewah) Ewah {
    var out = Ewah.init();
    var ri = RlwIt.init(a);
    var rj = RlwIt.init(b);
    while (ri.wordSize() > 0 and rj.wordSize() > 0) {
        while (ri.running_len > 0 or rj.running_len > 0) {
            var prey: *RlwIt = &rj;
            var predator: *RlwIt = &ri;
            if (ri.running_len < rj.running_len) {
                prey = &ri;
                predator = &rj;
            }
            const negate = predator.running_bit;
            const index = prey.discharge(&out, predator.running_len, negate);
            _ = out.addEmptyWords(negate, predator.running_len - index);
            predator.discardFirstWords(predator.running_len);
        }
        const literals = @min(ri.literal_words, rj.literal_words);
        if (literals > 0) {
            var k: usize = 0;
            while (k < literals) : (k += 1)
                _ = out.add(ri.buffer[ri.literal_word_start + k] ^ rj.buffer[rj.literal_word_start + k]);
            ri.discardFirstWords(literals);
            rj.discardFirstWords(literals);
        }
    }
    if (ri.wordSize() > 0)
        _ = ri.discharge(&out, std.math.maxInt(usize), false)
    else
        _ = rj.discharge(&out, std.math.maxInt(usize), false);
    out.bit_size = @max(a.bit_size, b.bit_size);
    return out;
}

// ------------------------------------------------------------ dense bitmap

pub const Bitmap = struct {
    words: std.ArrayList(u64) = .empty,

    fn grow(self: *Bitmap, n: usize) void {
        while (self.words.items.len < n) self.words.append(gpa, 0) catch util.oom();
    }
    pub fn set(self: *Bitmap, pos: usize) void {
        self.grow(pos / BITS + 1);
        self.words.items[pos / BITS] |= @as(u64, 1) << @intCast(pos % BITS);
    }
    pub fn unset(self: *Bitmap, pos: usize) void {
        if (pos / BITS < self.words.items.len)
            self.words.items[pos / BITS] &= ~(@as(u64, 1) << @intCast(pos % BITS));
    }
    pub fn get(self: *const Bitmap, pos: usize) bool {
        if (pos / BITS >= self.words.items.len) return false;
        return self.words.items[pos / BITS] & (@as(u64, 1) << @intCast(pos % BITS)) != 0;
    }
    pub fn orWith(self: *Bitmap, other: *const Bitmap) void {
        self.grow(other.words.items.len);
        for (other.words.items, 0..) |w, i| self.words.items[i] |= w;
    }
    pub fn orEwah(self: *Bitmap, e: *const Ewah) void {
        self.grow(e.bit_size / BITS + 1);
        var it = EwahIter.init(e);
        var i: usize = 0;
        while (it.next()) |w| : (i += 1) {
            self.grow(i + 1);
            self.words.items[i] |= w;
        }
    }
    pub fn andNot(self: *Bitmap, other: *const Bitmap) void {
        const n = @min(self.words.items.len, other.words.items.len);
        for (0..n) |i| self.words.items[i] &= ~other.words.items[i];
    }
    pub fn popcount(self: *const Bitmap) usize {
        var c: usize = 0;
        for (self.words.items) |w| c += @popCount(w);
        return c;
    }
    pub fn equals(self: *const Bitmap, other: *const Bitmap) bool {
        const a = self.words.items;
        const b = other.words.items;
        const n = @min(a.len, b.len);
        for (0..n) |i| if (a[i] != b[i]) return false;
        for (a[n..]) |w| if (w != 0) return false;
        for (b[n..]) |w| if (w != 0) return false;
        return true;
    }
    pub fn dup(self: *const Bitmap) Bitmap {
        var b = Bitmap{};
        b.words.appendSlice(gpa, self.words.items) catch util.oom();
        return b;
    }
    /// bitmap_to_ewah()
    pub fn toEwah(self: *const Bitmap) Ewah {
        var e = Ewah.init();
        var running_empty: usize = 0;
        var last: u64 = 0;
        for (self.words.items) |w| {
            if (w == 0) {
                running_empty += 1;
                continue;
            }
            if (last != 0) _ = e.add(last);
            if (running_empty > 0) {
                _ = e.addEmptyWords(false, running_empty);
                running_empty = 0;
            }
            last = w;
        }
        _ = e.add(last);
        return e;
    }
};

fn put32(b: *util.Buf, v: u32) void {
    var x: [4]u8 = undefined;
    std.mem.writeInt(u32, &x, v, .big);
    util.bufAppend(b, &x);
}
fn put64(b: *util.Buf, v: u64) void {
    var x: [8]u8 = undefined;
    std.mem.writeInt(u64, &x, v, .big);
    util.bufAppend(b, &x);
}
fn put16(b: *util.Buf, v: u16) void {
    var x: [2]u8 = undefined;
    std.mem.writeInt(u16, &x, v, .big);
    util.bufAppend(b, &x);
}

// ------------------------------------------------------------------ writer

pub const WriteObj = struct { oid: Oid, typ: ObjType, name_hash: u32 };

const Selected = struct {
    commit: *cn.Commit,
    bitmap: Ewah = .{},
    write_as: Ewah = .{},
    xor_offset: u8 = 0,
    commit_pos: u32 = 0,
};

const BWriter = struct {
    pos: hash.OidMap(u32) = .empty,
    objs: []const WriteObj,
    selected: std.ArrayList(Selected) = .empty,
    selected_map: hash.OidMap(u32) = .empty,
    computed: std.ArrayList(?Bitmap) = .empty,

    fn findPos(w: *BWriter, oid: Oid) ?u32 {
        if (w.pos.get(oid)) |p| return p;
        util.warn("Failed to write bitmap index. Packfile doesn't have full closure (object {s} is missing)", .{hash.hex(oid)});
        return null;
    }

    fn pushCommit(w: *BWriter, c: *cn.Commit) void {
        const gop = w.selected_map.getOrPut(gpa, c.oid()) catch util.oom();
        if (gop.found_existing) util.die("duplicate entry when writing bitmap index: {s}", .{hash.hex(c.oid())});
        gop.value_ptr.* = @intCast(w.selected.items.len);
        w.selected.append(gpa, .{ .commit = c }) catch util.oom();
    }

    fn fillTree(w: *BWriter, bm: *Bitmap, tree: Oid, pos: u32) bool {
        bm.set(pos);
        const o = repo_mod.repo().odb().read(tree) orelse util.die("unable to load tree object {s}", .{hash.hex(tree)});
        if (o.typ != .tree) util.die("unable to load tree object {s}", .{hash.hex(tree)});
        var it = objects.TreeIter{ .data = o.data };
        while (it.next()) |e| {
            const fmt = e.mode & 0o170000;
            if (fmt == 0o040000) {
                const p = w.findPos(e.oid) orelse return false;
                if (bm.get(p)) continue;
                if (!w.fillTree(bm, e.oid, p)) return false;
            } else if (fmt == 0o160000) {
                continue;
            } else {
                const p = w.findPos(e.oid) orelse return false;
                bm.set(p);
            }
        }
        return true;
    }

    fn fillCommit(w: *BWriter, bm: *Bitmap, start: *cn.Commit) bool {
        var queue: std.ArrayList(*cn.Commit) = .empty;
        var trees: std.ArrayList(Oid) = .empty;
        queue.append(gpa, start) catch util.oom();
        while (queue.pop()) |c| {
            if (c != start) {
                if (w.selected_map.get(c.oid())) |si| {
                    if (w.computed.items[si]) |*sb| {
                        bm.orWith(sb);
                        continue;
                    }
                }
            }
            cn.parseOrDie(c);
            const p = w.findPos(c.oid()) orelse return false;
            bm.set(p);
            trees.append(gpa, c.tree) catch util.oom();
            var pl = c.parents;
            while (pl) |x| : (pl = x.next) {
                const pp = w.findPos(x.item.oid()) orelse return false;
                if (!bm.get(pp)) {
                    bm.set(pp);
                    queue.append(gpa, x.item) catch util.oom();
                }
            }
        }
        for (trees.items) |t| {
            const p = w.findPos(t) orelse return false;
            if (bm.get(p)) continue;
            if (!w.fillTree(bm, t, p)) return false;
        }
        return true;
    }
};

fn dateDesc(_: void, a: *cn.Commit, b: *cn.Commit) bool {
    return a.date > b.date;
}
fn selDateAsc(_: void, a: Selected, b: Selected) bool {
    return a.commit.date < b.commit.date;
}

fn nextCommitIndex(idx: usize) usize {
    const MIN_COMMITS = 100;
    const MAX_COMMITS = 5000;
    const MUST_REGION = 100;
    const MIN_REGION = 20000;
    if (idx <= MUST_REGION) return 0;
    if (idx <= MIN_REGION) {
        const off = idx - MUST_REGION;
        return @min(off, MIN_COMMITS);
    }
    const off = idx - MIN_REGION;
    const nx = @min(off, MAX_COMMITS);
    return @max(nx, MIN_COMMITS);
}

/// Write `<path>` for a pack whose objects (in pack order) are `objs`.
/// `sorted` holds the same oids in .idx order.  Returns false (after
/// printing a warning) when the pack is not closed under reachability.
pub fn writePackBitmap(path: []const u8, pack_sum: Oid, objs: []const WriteObj, sorted: []const Oid, indexed0: []const *cn.Commit, options: u16, show_progress: bool) bool {
    var w = BWriter{ .objs = objs };
    var ct = Ewah.init();
    var tt = Ewah.init();
    var bt = Ewah.init();
    var gt = Ewah.init();
    for (objs, 0..) |o, i| {
        w.pos.put(gpa, o.oid, @intCast(i)) catch util.oom();
        switch (o.typ) {
            .commit => ct.set(i),
            .tree => tt.set(i),
            .blob => bt.set(i),
            .tag => gt.set(i),
            else => {
                switch (repo_mod.repo().odb().readType(o.oid) orelse .none) {
                    .commit => ct.set(i),
                    .tree => tt.set(i),
                    .blob => bt.set(i),
                    .tag => gt.set(i),
                    else => {},
                }
            },
        }
    }

    // select commits
    const indexed = gpa.dupe(*cn.Commit, indexed0) catch util.oom();
    for (indexed) |c| cn.parseOrDie(c);
    std.mem.sort(*cn.Commit, indexed, {}, dateDesc);
    if (indexed.len < 100) {
        for (indexed) |c| w.pushCommit(c);
    } else {
        var sp: ?*progress.Progress = if (show_progress) progress.start("Selecting bitmap commits", 0) else null;
        var i: usize = 0;
        while (true) {
            const nx = nextCommitIndex(i);
            if (i + nx >= indexed.len) break;
            var chosen: *cn.Commit = undefined;
            if (nx == 0) {
                chosen = indexed[i];
            } else {
                chosen = indexed[i + nx];
                var j: usize = 0;
                while (j <= nx) : (j += 1) {
                    const cm = indexed[i + j];
                    if (cm.parents) |p| {
                        if (p.next != null) chosen = cm;
                    }
                }
            }
            w.pushCommit(chosen);
            i += nx + 1;
            progress.update(sp, i);
        }
        if (sp) |p| p.stop();
        sp = null;
    }

    // build
    const nsel = w.selected.items.len;
    var bp: ?*progress.Progress = if (show_progress) progress.start("Building bitmaps", nsel) else null;
    w.computed.appendNTimes(gpa, null, nsel) catch util.oom();
    const order = gpa.alloc(u32, nsel) catch util.oom();
    for (order, 0..) |*o, k| o.* = @intCast(k);
    const OrdCtx = struct {
        sel: []const Selected,
        fn less(ctx: @This(), a: u32, b: u32) bool {
            return ctx.sel[a].commit.date < ctx.sel[b].commit.date;
        }
    };
    std.mem.sort(u32, order, OrdCtx{ .sel = w.selected.items }, OrdCtx.less);
    var nr_stored: usize = 0;
    for (order) |si| {
        var bm = Bitmap{};
        if (!w.fillCommit(&bm, w.selected.items[si].commit)) {
            if (bp) |p| p.stop();
            return false;
        }
        w.selected.items[si].bitmap = bm.toEwah();
        w.computed.items[si] = bm;
        nr_stored += 1;
        progress.update(bp, nr_stored);
    }
    if (bp) |p| p.stop();
    bp = null;

    // compute_xor_offsets
    if (nsel > 1) std.mem.sort(Selected, w.selected.items, {}, selDateAsc);
    for (w.selected.items, 0..) |*st, next| {
        var best_offset: u8 = 0;
        var best = st.bitmap;
        var k: usize = 1;
        while (k <= 10) : (k += 1) {
            if (k > next) break;
            const test_xor = ewahXor(&w.selected.items[next - k].bitmap, &st.bitmap);
            if (test_xor.buf.items.len < best.buf.items.len) {
                best = test_xor;
                best_offset = @intCast(k);
            }
        }
        st.xor_offset = best_offset;
        st.write_as = best;
    }

    // finish
    var out: util.Buf = .empty;
    util.bufAppend(&out, "BITM");
    put16(&out, 1);
    put16(&out, OPT_FULL_DAG | options);
    put32(&out, @intCast(nsel));
    util.bufAppend(&out, &pack_sum);
    ct.serialize(&out);
    tt.serialize(&out);
    bt.serialize(&out);
    gt.serialize(&out);
    for (w.selected.items) |*st| {
        st.commit_pos = oidPos(sorted, st.commit.oid()) orelse util.die("BUG: trying to write commit not in index", .{});
    }
    const offsets = gpa.alloc(u64, nsel) catch util.oom();
    for (w.selected.items, 0..) |st, k| {
        offsets[k] = out.items.len;
        put32(&out, st.commit_pos);
        util.bufAppend(&out, &[_]u8{ st.xor_offset, 0 });
        st.write_as.serialize(&out);
    }
    if (options & OPT_LOOKUP_TABLE != 0) {
        const table = gpa.alloc(u32, nsel) catch util.oom();
        const table_inv = gpa.alloc(u32, nsel) catch util.oom();
        for (table, 0..) |*t, k| t.* = @intCast(k);
        const TCtx = struct {
            sel: []const Selected,
            fn less(ctx: @This(), a: u32, b: u32) bool {
                return ctx.sel[a].commit_pos < ctx.sel[b].commit_pos;
            }
        };
        std.mem.sort(u32, table, TCtx{ .sel = w.selected.items }, TCtx.less);
        for (table, 0..) |t, k| table_inv[t] = @intCast(k);
        for (table) |t| {
            const st = w.selected.items[t];
            const xor_row: u32 = if (st.xor_offset != 0) table_inv[t - st.xor_offset] else 0xffffffff;
            put32(&out, st.commit_pos);
            put64(&out, offsets[t]);
            put32(&out, xor_row);
        }
    }
    if (options & OPT_HASH_CACHE != 0) {
        for (sorted) |oid| {
            const p = w.pos.get(oid).?;
            put32(&out, objs[p].name_hash);
        }
    }
    const sum = hash.hashData(out.items);
    util.bufAppend(&out, &sum);
    pack.writeNewFile(path, out.items, 0o444);
    return true;
}

fn oidPos(sorted: []const Oid, oid: Oid) ?u32 {
    var lo: usize = 0;
    var hi: usize = sorted.len;
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        switch (hash.order(oid, sorted[mid])) {
            .eq => return @intCast(mid),
            .lt => hi = mid,
            .gt => lo = mid + 1,
        }
    }
    return null;
}

// ------------------------------------------------------------------ reader

const Stored = struct {
    root: Ewah,
    xor: ?u32,
    map_pos: usize,
};

const ExtObj = struct { obj: *cn.Obj };

pub const Index = struct {
    pack: *odb_mod.Pack,
    data: []const u8,
    pos: usize = 0,
    version: u16 = 0,
    entry_count: u32 = 0,
    has_table: bool = false,
    hashes: ?[]const u8 = null,
    commits: Ewah = .{},
    trees: Ewah = .{},
    blobs: Ewah = .{},
    tags: Ewah = .{},
    dense: [4]Bitmap = .{ .{}, .{}, .{}, .{} },
    stored: std.ArrayList(Stored) = .empty,
    stored_map: hash.OidMap(u32) = .empty,
    pos_to_idx: []u32 = &.{},
    idx_to_pos: []u32 = &.{},
    ext: std.ArrayList(*cn.Obj) = .empty,
    ext_map: hash.OidMap(u32) = .empty,

    fn num(ix: *const Index) u32 {
        return ix.pack.num;
    }

    fn loadHeader(ix: *Index) bool {
        const d = ix.data;
        const header_size: usize = 12 + 20;
        if (d.len < header_size + 20) {
            util.err("corrupted bitmap index (too small)", .{});
            return false;
        }
        if (!std.mem.eql(u8, d[0..4], "BITM")) {
            util.err("corrupted bitmap index file (wrong header)", .{});
            return false;
        }
        ix.version = std.mem.readInt(u16, d[4..6], .big);
        if (ix.version != 1) {
            util.err("unsupported version '{d}' for bitmap index file", .{ix.version});
            return false;
        }
        const flags = std.mem.readInt(u16, d[6..8], .big);
        const cache_size: usize = @as(usize, ix.num()) * 4;
        var index_end: usize = d.len - 20;
        if (flags & OPT_FULL_DAG == 0)
            util.die("BUG: unsupported options for bitmap index file (Git requires BITMAP_OPT_FULL_DAG)", .{});
        ix.entry_count = std.mem.readInt(u32, d[8..12], .big);
        if (flags & OPT_HASH_CACHE != 0) {
            if (cache_size > index_end - header_size) {
                util.err("corrupted bitmap index file (too short to fit hash cache)", .{});
                return false;
            }
            ix.hashes = d[index_end - cache_size .. index_end];
            index_end -= cache_size;
        }
        if (flags & OPT_LOOKUP_TABLE != 0) {
            const table_size: usize = @as(usize, ix.entry_count) * 16;
            if (table_size > index_end - header_size) {
                util.err("corrupted bitmap index file (too short to fit lookup table)", .{});
                return false;
            }
            ix.has_table = envBool("GIT_TEST_READ_COMMIT_TABLE", true);
            index_end -= table_size;
        }
        ix.pos = header_size;
        return true;
    }

    fn readBitmap(ix: *Index) ?Ewah {
        var e = Ewah{};
        const n = e.read(ix.data[ix.pos..]) orelse {
            util.err("failed to load bitmap index (corrupted?)", .{});
            return null;
        };
        ix.pos += n;
        return e;
    }

    fn load(ix: *Index) bool {
        // reverse index: pack position <-> idx position
        const n = ix.num();
        ix.pos_to_idx = gpa.alloc(u32, n) catch util.oom();
        ix.idx_to_pos = gpa.alloc(u32, n) catch util.oom();
        const offs = gpa.alloc(u64, n) catch util.oom();
        for (ix.pos_to_idx, 0..) |*p, k| {
            p.* = @intCast(k);
            offs[k] = ix.pack.offsetAt(@intCast(k));
        }
        const Ctx = struct {
            o: []const u64,
            fn less(c: @This(), a: u32, b: u32) bool {
                return c.o[a] < c.o[b];
            }
        };
        std.mem.sort(u32, ix.pos_to_idx, Ctx{ .o = offs }, Ctx.less);
        for (ix.pos_to_idx, 0..) |idx, p| ix.idx_to_pos[idx] = @intCast(p);

        ix.commits = ix.readBitmap() orelse return false;
        ix.trees = ix.readBitmap() orelse return false;
        ix.blobs = ix.readBitmap() orelse return false;
        ix.tags = ix.readBitmap() orelse return false;
        ix.dense = .{ ix.commits.toBitmap(), ix.trees.toBitmap(), ix.blobs.toBitmap(), ix.tags.toBitmap() };

        // load_bitmap_entries_v1
        const MAX_XOR_OFFSET = 160;
        var recent: [MAX_XOR_OFFSET]?u32 = @splat(null);
        var i: u32 = 0;
        while (i < ix.entry_count) : (i += 1) {
            if (ix.data.len - ix.pos < 6) {
                util.err("corrupt ewah bitmap: truncated header for entry {d}", .{i});
                return false;
            }
            const entry_pos = ix.pos;
            const commit_idx = std.mem.readInt(u32, ix.data[ix.pos..][0..4], .big);
            const xor_offset: u32 = ix.data[ix.pos + 4];
            ix.pos += 6;
            if (commit_idx >= n) {
                util.err("corrupt ewah bitmap: commit index {d} out of range", .{commit_idx});
                return false;
            }
            if (xor_offset > MAX_XOR_OFFSET or xor_offset > i) {
                util.err("corrupted bitmap pack index", .{});
                return false;
            }
            var xor_with: ?u32 = null;
            if (xor_offset > 0) {
                xor_with = recent[(i - xor_offset) % MAX_XOR_OFFSET];
                if (xor_with == null) {
                    util.err("invalid XOR offset in bitmap pack index", .{});
                    return false;
                }
            }
            const bm = ix.readBitmap() orelse return false;
            const oid = ix.pack.oidAt(commit_idx);
            const gop = ix.stored_map.getOrPut(gpa, oid) catch util.oom();
            if (gop.found_existing) {
                util.err("duplicate entry in bitmap index: '{s}'", .{hash.hex(oid)});
                recent[i % MAX_XOR_OFFSET] = null;
                continue;
            }
            gop.value_ptr.* = @intCast(ix.stored.items.len);
            recent[i % MAX_XOR_OFFSET] = @intCast(ix.stored.items.len);
            ix.stored.append(gpa, .{ .root = bm, .xor = xor_with, .map_pos = entry_pos }) catch util.oom();
        }
        return true;
    }

    fn lookupStored(ix: *Index, si: u32) *const Ewah {
        const st = &ix.stored.items[si];
        if (st.xor) |x| {
            const parent = ix.lookupStored(x);
            const composed = ewahXor(&ix.stored.items[si].root, parent);
            ix.stored.items[si].root = composed;
            ix.stored.items[si].xor = null;
        }
        return &ix.stored.items[si].root;
    }

    pub fn bitmapFor(ix: *Index, oid: Oid) ?*const Ewah {
        const si = ix.stored_map.get(oid) orelse return null;
        return ix.lookupStored(si);
    }

    fn position(ix: *const Index, oid: Oid) ?usize {
        if (ix.pack.find(oid)) |i| return ix.idx_to_pos[i];
        if (ix.ext_map.get(oid)) |e| return @as(usize, ix.num()) + e;
        return null;
    }

    fn extAdd(ix: *Index, o: *cn.Obj) usize {
        const gop = ix.ext_map.getOrPut(gpa, o.oid) catch util.oom();
        if (!gop.found_existing) {
            gop.value_ptr.* = @intCast(ix.ext.items.len);
            ix.ext.append(gpa, o) catch util.oom();
        }
        return @as(usize, ix.num()) + gop.value_ptr.*;
    }

    fn posOrAdd(ix: *Index, o: *cn.Obj) usize {
        return ix.position(o.oid) orelse ix.extAdd(o);
    }

    fn typeDense(ix: *const Index, t: ObjType) *const Bitmap {
        return switch (t) {
            .commit => &ix.dense[0],
            .tree => &ix.dense[1],
            .blob => &ix.dense[2],
            else => &ix.dense[3],
        };
    }
};

fn envBool(name: []const u8, def: bool) bool {
    const v = os.getenv(name) orelse return def;
    return @import("config.zig").configBool(name, v);
}

fn bitmapPathFor(p: *const odb_mod.Pack) []const u8 {
    const pp = p.pack_path;
    const stem = if (util.endsWith(pp, ".pack")) pp[0 .. pp.len - 5] else pp;
    return util.concat(&.{ stem, ".bitmap" });
}

/// open_bitmap(): the first pack with a loadable .bitmap header.
pub fn open() ?*Index {
    const odb = repo_mod.repo().odb();
    odb.loadPacks();
    for (odb.packs.items) |p| {
        const path = bitmapPathFor(p);
        const data = os.readFile(path) orelse continue;
        if (!os.exists(p.pack_path)) continue;
        const ix = gpa.create(Index) catch util.oom();
        ix.* = .{ .pack = p, .data = data };
        if (!ix.loadHeader()) continue;
        return ix;
    }
    return null;
}

/// prepare_bitmap_git(): open and fully load.
pub fn prepare() ?*Index {
    const ix = open() orelse return null;
    if (!ix.load()) return null;
    return ix;
}

// ----------------------------------------------------------- bitmap walk

const Walk = struct {
    ix: *Index,
    base: *Bitmap,
    seen: ?*const Bitmap,

    fn inSeenOrBase(w: *Walk, pos: usize) bool {
        if (w.seen) |s| if (s.get(pos)) return true;
        return w.base.get(pos);
    }

    fn tree(w: *Walk, o: *cn.Obj) void {
        if (w.ix.position(o.oid)) |p| {
            if (w.inSeenOrBase(p)) return;
        }
        const pos = w.ix.posOrAdd(o);
        w.base.set(pos);
        const data = repo_mod.repo().odb().read(o.oid) orelse return;
        if (data.typ != .tree) return;
        var it = objects.TreeIter{ .data = data.data };
        while (it.next()) |e| {
            const fmt = e.mode & 0o170000;
            if (fmt == 0o160000) continue;
            if (fmt == 0o040000) {
                const t = cn.lookup(e.oid, .tree) orelse continue;
                w.tree(t);
            } else {
                const b = cn.lookup(e.oid, .blob) orelse continue;
                if (w.ix.position(b.oid)) |p| {
                    if (w.inSeenOrBase(p)) continue;
                }
                w.base.set(w.ix.posOrAdd(b));
            }
        }
    }

    /// fill_in_bitmap(): walk from `roots` (not covered by `base`).
    fn fill(w: *Walk, roots: []const *cn.Obj) void {
        var q = cn.PrioQueue{ .compare = cn.compareByCommitDate };
        var queued: hash.OidSet = .empty;
        var others: std.ArrayList(*cn.Obj) = .empty;
        var trees: std.ArrayList(*cn.Obj) = .empty;
        for (roots) |o| {
            if (o.typ == .commit) {
                const c = cn.Commit.fromObj(o);
                if (!cn.parse(c)) continue;
                queued.put(gpa, o.oid, {}) catch util.oom();
                q.put(c);
            } else others.append(gpa, o) catch util.oom();
        }
        while (q.get()) |c| {
            const pos = w.ix.posOrAdd(&c.obj);
            if (w.inSeenOrBase(pos)) continue;
            if (w.ix.bitmapFor(c.oid())) |e| {
                w.base.orEwah(e);
                continue;
            }
            w.base.set(pos);
            if (!cn.parse(c)) continue;
            if (cn.lookup(c.tree, .tree)) |t| trees.append(gpa, t) catch util.oom();
            var pl = c.parents;
            while (pl) |x| : (pl = x.next) {
                const gop = queued.getOrPut(gpa, x.item.oid()) catch util.oom();
                if (gop.found_existing) continue;
                if (!cn.parse(x.item)) continue;
                q.put(x.item);
            }
        }
        for (others.items) |o| {
            switch (o.typ) {
                .tree => w.tree(o),
                else => {
                    if (w.ix.position(o.oid)) |p| {
                        if (w.inSeenOrBase(p)) continue;
                    }
                    w.base.set(w.ix.posOrAdd(o));
                },
            }
        }
        for (trees.items) |t| w.tree(t);
    }
};

fn findObjects(ix: *Index, roots: []const *cn.Obj, seen: ?*const Bitmap) Bitmap {
    var base: ?Bitmap = null;
    var not_mapped: std.ArrayList(*cn.Obj) = .empty;
    for (roots) |o| {
        if (base) |*b| {
            if (ix.position(o.oid)) |p| {
                if (b.get(p)) continue;
            }
        }
        if (o.typ == .commit) {
            if (ix.bitmapFor(o.oid)) |e| {
                if (base == null) base = e.toBitmap() else base.?.orEwah(e);
                continue;
            }
        }
        not_mapped.insert(gpa, 0, o) catch util.oom();
    }
    var b = base orelse Bitmap{};
    if (not_mapped.items.len == 0) return b;
    var walk_roots: std.ArrayList(*cn.Obj) = .empty;
    for (not_mapped.items) |o| {
        const p = ix.position(o.oid);
        if (p == null or base == null or !b.get(p.?)) walk_roots.append(gpa, o) catch util.oom();
    }
    if (walk_roots.items.len > 0) {
        var w = Walk{ .ix = ix, .base = &b, .seen = seen };
        w.fill(walk_roots.items);
    }
    return b;
}

fn canFilter(f: ?*objfilter.Filter) bool {
    const x = f orelse return true;
    return switch (x.kind) {
        .blob_none, .blob_limit, .object_type => true,
        .tree_depth => x.depth == 0,
        .sparse_oid => false,
        .combine => blk: {
            for (x.subs) |*s| if (!canFilter(s)) break :blk false;
            break :blk true;
        },
    };
}

fn tipBitmap(ix: *Index, tips: ?[]const *cn.Obj, t: ObjType) Bitmap {
    var b = Bitmap{};
    for (tips orelse &.{}) |o| {
        if (o.typ != t) continue;
        if (ix.position(o.oid)) |p| b.set(p);
    }
    return b;
}

fn excludeType(ix: *Index, tips: ?[]const *cn.Obj, res: *Bitmap, t: ObjType) void {
    const tb = tipBitmap(ix, tips, t);
    const td = ix.typeDense(t);
    const n = @min(res.words.items.len, td.words.items.len);
    for (0..n) |i| {
        var mask = td.words.items[i];
        if (i < tb.words.items.len) mask &= ~tb.words.items[i];
        res.words.items[i] &= ~mask;
    }
    for (ix.ext.items, 0..) |o, i| {
        const p = @as(usize, ix.num()) + i;
        if (o.typ == t and res.get(p) and !tb.get(p)) res.unset(p);
    }
}

fn sizeOf(oid: Oid) usize {
    const o = repo_mod.repo().odb().read(oid) orelse util.die("unable to get size of {s}", .{hash.hex(oid)});
    return o.data.len;
}

fn applyFilter(ix: *Index, tips: ?[]const *cn.Obj, res: *Bitmap, f0: ?*objfilter.Filter) void {
    const f = f0 orelse return;
    switch (f.kind) {
        .blob_none => excludeType(ix, tips, res, .blob),
        .tree_depth => {
            excludeType(ix, tips, res, .tree);
            excludeType(ix, tips, res, .blob);
        },
        .object_type => {
            for ([_]ObjType{ .tag, .commit, .tree, .blob }) |t| {
                if (t != f.typ) excludeType(ix, tips, res, t);
            }
        },
        .blob_limit => {
            const tb = tipBitmap(ix, tips, .blob);
            const bd = ix.typeDense(.blob);
            const n = @min(res.words.items.len, bd.words.items.len);
            for (0..n) |i| {
                const word = res.words.items[i] & bd.words.items[i];
                if (word == 0) continue;
                for (0..BITS) |off| {
                    if (word & (@as(u64, 1) << @intCast(off)) == 0) continue;
                    const p = i * BITS + off;
                    if (!tb.get(p) and sizeOf(ix.pack.oidAt(ix.pos_to_idx[p])) >= f.limit) res.unset(p);
                }
            }
            for (ix.ext.items, 0..) |o, i| {
                const p = @as(usize, ix.num()) + i;
                if (o.typ == .blob and res.get(p) and !tb.get(p) and sizeOf(o.oid) >= f.limit) res.unset(p);
            }
        },
        .combine => for (f.subs) |*s| applyFilter(ix, tips, res, s),
        .sparse_oid => {},
    }
}

pub const WalkResult = struct {
    ix: *Index,
    result: Bitmap,
};

/// prepare_bitmap_walk() (classic, non-boundary traversal).
pub fn prepareWalk(revs: *revision.RevInfo, filter_provided: bool) ?WalkResult {
    if (revs.prune or !revs.prune_data.isEmpty()) return null;
    if (!canFilter(revs.obj_filter)) return null;
    if (revs.unpacked) return null;
    const ix = open() orelse return null;

    var wants: std.ArrayList(*cn.Obj) = .empty;
    var haves: std.ArrayList(*cn.Obj) = .empty;
    for (revs.pending.items) |pe| {
        var o = pe.item;
        if (o.typ == .none) o = cn.parseObject(o.oid) orelse util.die("unable to parse object {s}", .{hash.hex(o.oid)});
        while (o.typ == .tag) {
            if (o.flags & cn.UNINTERESTING != 0) haves.insert(gpa, 0, o) catch util.oom() else wants.insert(gpa, 0, o) catch util.oom();
            const data = repo_mod.repo().odb().read(o.oid) orelse util.die("unable to parse object {s}", .{hash.hex(o.oid)});
            const tg = objects.parseTag(data.data) orelse util.die("unable to parse object {s}", .{hash.hex(o.oid)});
            const nx = cn.parseObject(tg.object) orelse util.die("unable to parse object {s}", .{hash.hex(tg.object)});
            nx.flags |= o.flags & cn.UNINTERESTING;
            o = nx;
        }
        if (o.flags & cn.UNINTERESTING != 0) haves.insert(gpa, 0, o) catch util.oom() else wants.insert(gpa, 0, o) catch util.oom();
    }
    if (haves.items.len > 0) {
        var any = false;
        for (haves.items) |h| {
            if (ix.pack.find(h.oid) != null) any = true;
        }
        if (!any) return null;
    }
    if (wants.items.len == 0) return null;
    if (!ix.load()) return null;

    var haves_bm: ?Bitmap = null;
    if (haves.items.len > 0) haves_bm = findObjects(ix, haves.items, null);
    var res = findObjects(ix, wants.items, if (haves_bm) |*h| h else null);
    if (haves_bm) |*h| res.andNot(h);
    applyFilter(ix, if (revs.obj_filter != null and filter_provided) null else wants.items, &res, revs.obj_filter);
    return .{ .ix = ix, .result = res };
}

fn showType(wr: *WalkResult, t: ObjType) void {
    const td = wr.ix.typeDense(t);
    const r = wr.result.words.items;
    const n = @min(r.len, td.words.items.len);
    for (0..n) |i| {
        const word = r[i] & td.words.items[i];
        if (word == 0) continue;
        for (0..BITS) |off| {
            if (word & (@as(u64, 1) << @intCast(off)) == 0) continue;
            const p = i * BITS + off;
            util.outf("{s}\n", .{hash.hex(wr.ix.pack.oidAt(wr.ix.pos_to_idx[p]))});
        }
    }
}

fn countType(wr: *WalkResult, t: ObjType) usize {
    const td = wr.ix.typeDense(t);
    const r = wr.result.words.items;
    const n = @min(r.len, td.words.items.len);
    var c: usize = 0;
    for (0..n) |i| c += @popCount(r[i] & td.words.items[i]);
    for (wr.ix.ext.items, 0..) |o, i| {
        if (o.typ == t and wr.result.get(@as(usize, wr.ix.num()) + i)) c += 1;
    }
    return c;
}

/// rev-list --use-bitmap-index: try_bitmap_count() and
/// try_bitmap_traversal().  Returns true when the output was produced.
pub fn tryRevList(revs: *revision.RevInfo, filter_provided: bool, disk_usage: bool) bool {
    if (revs.count) {
        if (revs.left_right or revs.cherry_mark) return false;
        if (revs.max_count >= 0 and (revs.tag_objects or revs.tree_objects or revs.blob_objects)) return false;
        const max_count = revs.max_count;
        var wr = prepareWalk(revs, filter_provided) orelse return false;
        var commits = countType(&wr, .commit);
        var total: usize = 0;
        if (revs.tree_objects) total += countType(&wr, .tree);
        if (revs.blob_objects) total += countType(&wr, .blob);
        if (revs.tag_objects) total += countType(&wr, .tag);
        if (max_count >= 0 and max_count < commits) commits = @intCast(max_count);
        util.outf("{d}\n", .{commits + total});
        return true;
    }
    if (disk_usage) return false;
    if (revs.max_count >= 0 or revs.left_right) return false;
    var wr = prepareWalk(revs, filter_provided) orelse return false;
    showType(&wr, .commit);
    if (revs.tree_objects) showType(&wr, .tree);
    if (revs.blob_objects) showType(&wr, .blob);
    if (revs.tag_objects) showType(&wr, .tag);
    for (wr.ix.ext.items, 0..) |o, i| {
        if (!wr.result.get(@as(usize, wr.ix.num()) + i)) continue;
        if ((o.typ == .blob and !revs.blob_objects) or (o.typ == .tree and !revs.tree_objects) or (o.typ == .tag and !revs.tag_objects)) continue;
        util.outf("{s}\n", .{hash.hex(o.oid)});
    }
    return true;
}

// ----------------------------------------------------------- test-bitmap

const TestData = struct {
    ix: *Index,
    base: Bitmap = .{},
    prg: ?*progress.Progress = null,
    seen: usize = 0,

    fn check(td: *TestData, obj: *cn.Obj) void {
        const pos = td.ix.position(obj.oid) orelse util.die("object not in bitmap: '{s}'", .{hash.hex(obj.oid)});
        var bt: ObjType = .none;
        var nr: u32 = 0;
        const types = [_]ObjType{ .commit, .tree, .blob, .tag };
        for (types, 0..) |t, k| {
            if (td.ix.dense[k].get(pos)) {
                bt = t;
                nr += 1;
            }
        }
        if (bt == .none) util.die("object '{s}' not found in type bitmaps", .{hash.hex(obj.oid)});
        if (nr > 1) util.die("object '{s}' does not have a unique type", .{hash.hex(obj.oid)});
        if (bt != obj.typ) util.die("object '{s}': real type '{s}', expected: '{s}'", .{ hash.hex(obj.oid), obj.typ.name(), bt.name() });
        td.base.set(pos);
        td.seen += 1;
        progress.update(td.prg, td.seen);
    }
};

fn testShowCommit(c: *cn.Commit, data: ?*anyopaque) void {
    const td: *TestData = @ptrCast(@alignCast(data.?));
    td.check(&c.obj);
}
fn testShowObject(o: *cn.Obj, name: []const u8, data: ?*anyopaque) void {
    _ = name;
    const td: *TestData = @ptrCast(@alignCast(data.?));
    td.check(o);
}

/// rev-list --test-bitmap <commit>
pub fn testBitmapWalk(revs: *revision.RevInfo) void {
    const ix = prepare() orelse util.die("failed to load bitmap indexes", .{});
    if (revs.pending.items.len != 1) util.die("you must specify exactly one commit to test", .{});
    util.eprint("Bitmap v{d} test ({d} entries{s}, {d} total)\n", .{ ix.version, ix.entry_count, if (ix.has_table) "" else " loaded", ix.entry_count });
    const root = revs.pending.items[0].item;
    const bm = ix.bitmapFor(root.oid) orelse util.die("commit '{s}' doesn't have an indexed bitmap", .{hash.hex(root.oid)});
    util.eprint("Found bitmap for '{s}'. {d} bits / {x:0>8} checksum\n", .{ hash.hex(root.oid), bm.bit_size, bm.checksum() });
    const idx = ix.pack.idx;
    util.eprint("Located via pack '{s}'.\n", .{hash.hex(idx[idx.len - 40 ..][0..20].*)});
    const result = bm.toBitmap();
    revs.tag_objects = true;
    revs.tree_objects = true;
    revs.blob_objects = true;
    const popcnt = result.popcount();
    if (!revision.prepareRevisionWalk(revs)) util.die("revision walk setup failed", .{});
    var td = TestData{ .ix = ix };
    td.prg = progress.start("Verifying bitmap entries", popcnt);
    revision.traverseCommitList(revs, testShowCommit, testShowObject, &td);
    if (td.prg) |p| p.stop();
    if (result.equals(&td.base)) util.eprint("OK!\n", .{}) else util.die("mismatch in bitmap results", .{});
}
