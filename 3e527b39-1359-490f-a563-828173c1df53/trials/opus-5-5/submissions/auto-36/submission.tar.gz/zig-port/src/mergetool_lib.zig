//! Port of git-mergetool--lib.sh: merge/diff tool selection, validation,
//! --tool-help listing and running of builtin (mergetools/*) and
//! user-defined (<mode>tool.<tool>.cmd) tools.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const data = @import("mergetools_data.zig");
const gpa = util.gpa;
const Buf = util.Buf;

pub const Mode = enum { diff, merge };

pub var mode: Mode = .merge;
/// GIT_MERGETOOL_GUI equivalent; null = consult <mode>tool.guiDefault
pub var gui: ?bool = null;

extern "c" fn utimes(path: [*:0]const u8, times: ?*const anyopaque) c_int;
extern "c" fn read(fd: c_int, buf: [*]u8, n: usize) isize;

pub fn modeName() []const u8 {
    return if (mode == .diff) "diff" else "merge";
}

// ---------------------------------------------------------------------------
// config helpers ("git config <key>")

pub fn cfgGet(key: []const u8) ?[]const u8 {
    if (key.len == 0) return null;
    const v = repo_mod.cfg.get(key) orelse return null;
    return std.mem.trimEnd(u8, v, "\n");
}

pub fn cfgBool(key: []const u8) ?bool {
    return repo_mod.cfg.getBool(key);
}

fn nonEmpty(v: ?[]const u8) ?[]const u8 {
    const s = v orelse return null;
    return if (s.len == 0) null else s;
}

// ---------------------------------------------------------------------------
// stdin

/// `read ans` (with IFS=LF): returns null on EOF before a newline.
pub fn readLine() ?[]const u8 {
    util.flushStdout();
    var b: Buf = .empty;
    while (true) {
        var ch: [1]u8 = undefined;
        const n = read(0, &ch, 1);
        if (n <= 0) return null;
        if (ch[0] == '\n') break;
        b.append(gpa, ch[0]) catch util.oom();
    }
    // read without -r: backslash escapes the next character
    var o: Buf = .empty;
    var i: usize = 0;
    while (i < b.items.len) : (i += 1) {
        if (b.items[i] == '\\' and i + 1 < b.items.len) {
            i += 1;
        }
        o.append(gpa, b.items[i]) catch util.oom();
    }
    return o.items;
}

// ---------------------------------------------------------------------------
// shell `type` emulation

const shell_builtins = [_][]const u8{ "echo", "printf", "true", "false", "test", ":", "[", "cd", "pwd", "read", "type", "eval", "exec", "set", "export", "kill", "exit", "return", "shift", "times", "trap", "umask", "wait", "command", "alias", "unset", "local" };

pub fn typeExists(name: []const u8) bool {
    if (name.len == 0) return false;
    if (std.mem.indexOfScalar(u8, name, '/') != null) {
        const st = os.statPath(name) orelse return false;
        return st.isReg() and os.access(name, 1);
    }
    for (shell_builtins) |b| if (util.eql(b, name)) return true;
    const path = os.getenv("PATH") orelse "/usr/bin:/bin";
    var it = std.mem.splitScalar(u8, path, ':');
    while (it.next()) |dir| {
        const p = util.joinPath(if (dir.len == 0) "." else dir, name);
        const st = os.statPath(p) orelse continue;
        if (st.isReg() and os.access(p, 1)) return true;
    }
    return false;
}

// ---------------------------------------------------------------------------
// builtin tool data

const script_names = blk: {
    var names: [data.scripts.len + 2][]const u8 = undefined;
    for (data.scripts, 0..) |s, i| names[i] = s.name;
    names[data.scripts.len] = "gvimdiff";
    names[data.scripts.len + 1] = "nvimdiff";
    break :blk names;
};

fn scriptBody(name: []const u8) []const u8 {
    const n = if (util.eql(name, "gvimdiff") or util.eql(name, "nvimdiff")) "vimdiff" else name;
    for (data.scripts) |s| if (util.eql(s.name, n)) return s.body;
    return "";
}

fn hasScript(name: []const u8) bool {
    for (script_names) |s| if (util.eql(s, name)) return true;
    return false;
}

/// The mergetools/ script a tool name maps to (setup_tool's lookup).
pub fn findScript(tool: []const u8) ?[]const u8 {
    if (tool.len == 0) return null;
    if (hasScript(tool)) return tool;
    if (std.ascii.isDigit(tool[tool.len - 1]) and hasScript(tool[0 .. tool.len - 1])) return tool[0 .. tool.len - 1];
    return null;
}

/// Canonical script (vimdiff family share one).
fn base(script: []const u8) []const u8 {
    if (util.eql(script, "gvimdiff") or util.eql(script, "nvimdiff")) return "vimdiff";
    return script;
}

fn variants(script: []const u8) []const []const u8 {
    const b = base(script);
    if (util.eql(b, "bc")) return &.{ "bc", "bc3", "bc4" };
    if (util.eql(b, "vimdiff")) {
        if (mode == .diff) return &.{ "vimdiff", "gvimdiff", "nvimdiff" };
        return &.{ "vimdiff", "vimdiff1", "vimdiff2", "vimdiff3", "gvimdiff", "gvimdiff1", "gvimdiff2", "gvimdiff3", "nvimdiff", "nvimdiff1", "nvimdiff2", "nvimdiff3" };
    }
    const l = gpa.alloc([]const u8, 1) catch util.oom();
    l[0] = script;
    return l;
}

fn canDiff(script: []const u8) bool {
    return !util.eql(script, "tortoisemerge");
}
fn canMerge(script: []const u8) bool {
    return !util.eql(script, "kompare");
}

fn modeOk(script: []const u8) bool {
    return if (mode == .diff) canDiff(script) else canMerge(script);
}

fn exitCodeTrustable(script: []const u8) bool {
    const b = base(script);
    for ([_][]const u8{ "deltawalker", "diffmerge", "tkdiff", "emerge", "guiffy", "vimdiff", "kdiff3", "kompare" }) |t| {
        if (util.eql(t, b)) return true;
    }
    return false;
}

const help_table = [_][2][]const u8{
    .{ "araxis", "Use Araxis Merge (requires a graphical session)" },
    .{ "bc", "Use Beyond Compare (requires a graphical session)" },
    .{ "codecompare", "Use Code Compare (requires a graphical session)" },
    .{ "deltawalker", "Use DeltaWalker (requires a graphical session)" },
    .{ "diffmerge", "Use DiffMerge (requires a graphical session)" },
    .{ "diffuse", "Use Diffuse (requires a graphical session)" },
    .{ "ecmerge", "Use ECMerge (requires a graphical session)" },
    .{ "emerge", "Use Emacs' Emerge" },
    .{ "examdiff", "Use ExamDiff Pro (requires a graphical session)" },
    .{ "guiffy", "Use Guiffy's Diff Tool (requires a graphical session)" },
    .{ "kdiff3", "Use KDiff3 (requires a graphical session)" },
    .{ "kompare", "Use Kompare (requires a graphical session)" },
    .{ "meld", "Use Meld (requires a graphical session)" },
    .{ "opendiff", "Use FileMerge (requires a graphical session)" },
    .{ "p4merge", "Use HelixCore P4Merge (requires a graphical session)" },
    .{ "smerge", "Use Sublime Merge (requires a graphical session)" },
    .{ "tkdiff", "Use TkDiff (requires a graphical session)" },
    .{ "tortoisemerge", "Use TortoiseMerge (requires a graphical session)" },
    .{ "vscode", "Use Visual Studio Code (requires a graphical session)" },
    .{ "winmerge", "Use WinMerge (requires a graphical session)" },
    .{ "xxdiff", "Use xxdiff (requires a graphical session)" },
};

fn helpText(script: []const u8, tool: []const u8) []const u8 {
    const b = base(script);
    if (util.eql(b, "vimdiff")) {
        const who: []const u8 = if (util.startsWith(tool, "nvimdiff")) "Use Neovim" else if (util.startsWith(tool, "gvimdiff")) "Use gVim (requires a graphical session)" else if (util.startsWith(tool, "vimdiff")) "Use Vim" else "";
        if (mode == .diff) return who;
        const layout: []const u8 = if (util.endsWith(tool, "1")) "with a 2 panes layout (LOCAL and REMOTE)" else if (util.endsWith(tool, "2")) "with a 3 panes layout (LOCAL, MERGED and REMOTE)" else if (util.endsWith(tool, "3")) "where only the MERGED file is shown" else "with a custom layout (see `git help mergetool`'s `BACKEND SPECIFIC HINTS` section)";
        return util.concat(&.{ who, " ", layout });
    }
    if (util.eql(b, "meld") and mode == .merge)
        return "Use Meld (requires a graphical session) with optional `auto merge` (see `git help mergetool`'s `CONFIGURATION` section)";
    for (help_table) |h| if (util.eql(h[0], b)) return h[1];
    return "";
}

/// translate_merge_tool_path
fn translatePath(script: ?[]const u8, tool: []const u8) []const u8 {
    const s = base(script orelse return tool);
    if (util.eql(s, "araxis")) return "compare";
    if (util.eql(s, "bc")) return if (typeExists("bcomp")) "bcomp" else "bcompare";
    if (util.eql(s, "codecompare")) return if (mode == .merge) "CodeMerge" else "CodeCompare";
    if (util.eql(s, "deltawalker")) return "DeltaWalker";
    if (util.eql(s, "emerge")) return "emacs";
    if (util.eql(s, "examdiff")) return "ExamDiff.com";
    if (util.eql(s, "kdiff3")) return if (typeExists("kdiff3")) "kdiff3" else "kdiff3.exe";
    if (util.eql(s, "tortoisemerge")) return if (typeExists("tortoisegitmerge")) "tortoisegitmerge" else "tortoisemerge";
    if (util.eql(s, "vscode")) return "code";
    if (util.eql(s, "winmerge")) return "WinMergeU.exe";
    if (util.eql(s, "vimdiff")) {
        if (util.startsWith(tool, "nvimdiff")) return "nvim";
        if (util.startsWith(tool, "gvimdiff")) return "gvim";
        if (util.startsWith(tool, "vimdiff")) return "vim";
        return "";
    }
    return tool;
}

// ---------------------------------------------------------------------------
// tool setup / validation

pub fn getMergeToolCmd(tool: []const u8) ?[]const u8 {
    if (mode == .diff) {
        if (cfgGet(util.concat(&.{ "difftool.", tool, ".cmd" }))) |v| return v;
    }
    return cfgGet(util.concat(&.{ "mergetool.", tool, ".cmd" }));
}

/// setup_tool(); prints errors unless quiet.
pub fn setupTool(tool: []const u8, quiet: bool) bool {
    const script = findScript(tool) orelse {
        if (nonEmpty(getMergeToolCmd(tool)) == null) {
            if (!quiet) util.eprint("error: {s}tool.{s}.cmd not set for tool '{s}'\n", .{ modeName(), tool, tool });
            return false;
        }
        return true;
    };
    const user = nonEmpty(getMergeToolCmd(tool)) != null;
    if (!user) {
        var found = false;
        for (variants(script)) |v| {
            if (util.eql(v, tool)) found = true;
        }
        if (!found) {
            if (!quiet) util.eprint("error: unknown tool variant '{s}'\n", .{tool});
            return false;
        }
    }
    if (mode == .merge and !canMerge(script)) {
        if (!quiet) util.eprint("error: '{s}' can not be used to resolve merges\n", .{tool});
        return false;
    } else if (mode == .diff and !canDiff(script)) {
        if (!quiet) util.eprint("error: '{s}' can only be used to resolve merges\n", .{tool});
        return false;
    }
    return true;
}

pub fn validTool(tool: []const u8) bool {
    if (setupTool(tool, true)) return true;
    return nonEmpty(getMergeToolCmd(tool)) != null;
}

fn isAvailable(tool: []const u8) bool {
    return typeExists(translatePath(findScript(tool), tool));
}

pub fn guiMode() bool {
    if (gui == null) {
        const key = if (mode == .diff) "difftool.guiDefault" else "mergetool.guiDefault";
        const v = cfgGet(key) orelse "false";
        if (std.ascii.eqlIgnoreCase(v, "auto")) {
            gui = (os.getenv("DISPLAY") orelse @as([]const u8, "")).len > 0;
        } else {
            gui = cfgBool(key) orelse false;
        }
    }
    return gui.?;
}

/// get_configured_merge_tool; returns "" when none is configured (or the
/// configured one is invalid).
fn getConfiguredMergeTool() []const u8 {
    const keys: []const []const u8 = if (mode == .diff)
        (if (guiMode()) &.{ "diff.guitool", "merge.guitool", "diff.tool", "merge.tool" } else &.{ "diff.tool", "merge.tool" })
    else
        (if (guiMode()) &.{ "merge.guitool", "merge.tool" } else &.{"merge.tool"});
    var tool: []const u8 = "";
    for (keys) |k| {
        if (nonEmpty(cfgGet(k))) |v| {
            tool = v;
            break;
        }
    }
    if (tool.len > 0 and !validTool(tool)) {
        util.eprint("git config option {s}.tool set to unknown tool: {s}\nResetting to default...\n", .{ modeName(), tool });
        return "";
    }
    return tool;
}

fn mergeToolCandidates() []const u8 {
    var tools: []const u8 = if (mode == .merge) "tortoisemerge" else "kompare";
    if ((os.getenv("DISPLAY") orelse @as([]const u8, "")).len > 0) {
        if ((os.getenv("GNOME_DESKTOP_SESSION_ID") orelse @as([]const u8, "")).len > 0) {
            tools = util.concat(&.{ "meld opendiff kdiff3 tkdiff xxdiff ", tools });
        } else {
            tools = util.concat(&.{ "opendiff kdiff3 tkdiff xxdiff meld ", tools });
        }
        tools = util.concat(&.{ tools, " gvimdiff diffuse diffmerge ecmerge p4merge araxis bc codecompare smerge" });
    }
    const ed = nonEmpty(os.getenv("VISUAL")) orelse os.getenv("EDITOR") orelse "";
    if (std.mem.indexOf(u8, ed, "nvim") != null) {
        tools = util.concat(&.{ tools, " nvimdiff vimdiff emerge" });
    } else if (std.mem.indexOf(u8, ed, "vim") != null) {
        tools = util.concat(&.{ tools, " vimdiff nvimdiff emerge" });
    } else {
        tools = util.concat(&.{ tools, " emerge vimdiff nvimdiff" });
    }
    return tools;
}

pub const Selected = struct { tool: []const u8, guessed: bool, failed: bool = false };

/// get_merge_tool
pub fn getMergeTool() Selected {
    const t = getConfiguredMergeTool();
    if (t.len > 0) return .{ .tool = t, .guessed = false };
    const tools = mergeToolCandidates();
    const m = modeName();
    util.eprint("\nThis message is displayed because '{s}.tool' is not configured.\nSee 'git {s}tool --tool-help' or 'git help config' for more details.\n'git {s}tool' will now attempt to use one of the following tools:\n{s}\n", .{ m, m, m, tools });
    var it = std.mem.tokenizeScalar(u8, tools, ' ');
    while (it.next()) |cand| {
        if (isAvailable(cand)) return .{ .tool = cand, .guessed = true };
    }
    util.eprint("No known {s} tool is available.\n", .{m});
    return .{ .tool = "", .guessed = true, .failed = true };
}

/// get_merge_tool_path; exits 1 on failure (like the script).
pub fn getMergeToolPath(tool: []const u8) []const u8 {
    if (!validTool(tool)) {
        util.eprint("Unknown {s} tool {s}\n", .{ modeName(), tool });
        os.exit(1);
    }
    var path: []const u8 = "";
    if (mode == .diff) {
        path = cfgGet(util.concat(&.{ "difftool.", tool, ".path" })) orelse
            cfgGet(util.concat(&.{ "mergetool.", tool, ".path" })) orelse "";
    } else {
        path = cfgGet(util.concat(&.{ "mergetool.", tool, ".path" })) orelse "";
    }
    if (path.len == 0) path = translatePath(findScript(tool), tool);
    if (nonEmpty(getMergeToolCmd(tool)) == null and !typeExists(path)) {
        util.eprint("The {s} tool {s} is not available as '{s}'\n", .{ modeName(), tool, path });
        os.exit(1);
    }
    return path;
}

/// trust_exit_code
pub fn trustExitCode(tool: []const u8) bool {
    if (cfgBool(util.concat(&.{ "mergetool.", tool, ".trustExitCode" }))) |b| return b;
    const s = findScript(tool) orelse return false;
    return exitCodeTrustable(s);
}

// ---------------------------------------------------------------------------
// running tools

pub const Vars = struct {
    merged: []const u8 = "",
    local: []const u8 = "",
    remote: []const u8 = "",
    base: []const u8 = "",
    backup: []const u8 = "",
};

const preamble =
    \\diff_mode () {
    \\    test "$TOOL_MODE" = diff
    \\}
    \\merge_mode () {
    \\    test "$TOOL_MODE" = merge
    \\}
    \\die () {
    \\    printf >&2 '%s\n' "$*"
    \\    exit 1
    \\}
    \\mergetool_find_win32_cmd () {
    \\    executable=$1
    \\    sub_directory=$2
    \\    if type -p "$executable" >/dev/null 2>&1
    \\    then
    \\        printf '%s' "$executable"
    \\        return
    \\    fi
    \\    for directory in $(env | grep -Ei '^PROGRAM(FILES(\(X86\))?|W6432)=' |
    \\        cut -d '=' -f 2- | sort -u)
    \\    do
    \\        if test -n "$directory" && test -x "$directory/$sub_directory/$executable"
    \\        then
    \\            printf '%s' "$directory/$sub_directory/$executable"
    \\            return
    \\        fi
    \\    done
    \\    printf '%s' "$executable"
    \\}
    \\can_merge () {
    \\    return 0
    \\}
    \\can_diff () {
    \\    return 0
    \\}
    \\diff_cmd () {
    \\    return 1
    \\}
    \\merge_cmd () {
    \\    return 1
    \\}
    \\
;

fn sq(b: *Buf, s: []const u8) void {
    util.sqQuote(b, s);
}

fn assign(b: *Buf, name: []const u8, value: []const u8) void {
    util.bufAppend(b, name);
    util.bufByte(b, '=');
    sq(b, value);
    util.bufByte(b, '\n');
}

fn scriptHeader(b: *Buf) void {
    util.bufAppend(b, "IFS='\n'\n");
    util.bufAppend(b, "TOOL_MODE=");
    util.bufAppend(b, modeName());
    util.bufByte(b, '\n');
}

/// Run the tool's diff_cmd/merge_cmd in a shell; returns its exit status.
fn runCmd(tool: []const u8, path: []const u8, v: Vars, base_present: ?bool) u8 {
    var b: Buf = .empty;
    scriptHeader(&b);
    util.bufAppend(&b, preamble);
    if (findScript(tool)) |s| {
        util.bufAppend(&b, scriptBody(s));
        util.bufByte(&b, '\n');
    }
    if (nonEmpty(getMergeToolCmd(tool))) |cmd| {
        assign(&b, "merge_tool_cmd", cmd);
        util.bufAppend(&b, "diff_cmd () {\n\t( eval $merge_tool_cmd )\n}\nmerge_cmd () {\n\t( eval $merge_tool_cmd )\n}\n");
    }
    assign(&b, "MERGED", v.merged);
    assign(&b, "LOCAL", v.local);
    assign(&b, "REMOTE", v.remote);
    assign(&b, "BASE", v.base);
    assign(&b, "BACKUP", v.backup);
    assign(&b, "tool", tool);
    assign(&b, "merge_tool", tool);
    assign(&b, "merge_tool_path", path);
    assign(&b, "base_present", if (base_present) |bp| (if (bp) "true" else "false") else "");
    util.bufAppend(&b, if (mode == .diff) "diff_cmd " else "merge_cmd ");
    sq(&b, tool);
    util.bufByte(&b, '\n');
    const r = os.run(&.{ "/bin/sh", "-c", b.items, "git-mergetool" }, .{});
    return r.status;
}

/// Evaluate --extcmd like git-difftool--helper: eval $GIT_DIFFTOOL_EXTCMD
/// '"$LOCAL"' '"$REMOTE"' with the helper's positional parameters.
pub fn runExtCmd(extcmd: []const u8, v: Vars, positional: []const []const u8) u8 {
    var b: Buf = .empty;
    scriptHeader(&b);
    assign(&b, "MERGED", v.merged);
    assign(&b, "LOCAL", v.local);
    assign(&b, "REMOTE", v.remote);
    assign(&b, "BASE", v.base);
    util.bufAppend(&b, "export BASE\neval $GIT_DIFFTOOL_EXTCMD '\"$LOCAL\"' '\"$REMOTE\"'\n");
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ "/bin/sh", "-c", b.items, "git-difftool--helper" }) catch util.oom();
    argv.appendSlice(gpa, positional) catch util.oom();
    const r = os.run(argv.items, .{ .env = &.{.{ "GIT_DIFFTOOL_EXTCMD", extcmd }} });
    return r.status;
}

fn mtimeNs(p: []const u8) ?i128 {
    const st = os.statPath(p) orelse return null;
    return @as(i128, st.mtime) * 1_000_000_000 + st.mtime_ns;
}

pub fn touch(p: []const u8) void {
    if (os.statPath(p) == null) {
        const fd = os.openFile(p, os.O_WRONLY | os.O_CREAT, 0o666);
        if (fd >= 0) os.close(fd);
    }
    _ = utimes(os.z(p), null);
}

/// check_unchanged; true = success
fn checkUnchanged(v: Vars) bool {
    if (mtimeNs(v.merged)) |m| {
        if (mtimeNs(v.backup)) |bk| {
            if (m > bk) return true;
        } else return true;
    }
    while (true) {
        util.outf("{s} seems unchanged.\n", .{v.merged});
        util.out("Was the merge successful [y/n]? ");
        const ans = readLine() orelse return false;
        if (ans.len > 0 and (ans[0] == 'y' or ans[0] == 'Y')) return true;
        if (ans.len > 0 and (ans[0] == 'n' or ans[0] == 'N')) return false;
    }
}

/// run_merge_tool: exits 1 when the tool path cannot be determined.
pub fn runMergeTool(tool: []const u8, v: Vars, base_present: ?bool) u8 {
    if ((os.getenv("GIT_PREFIX") orelse @as([]const u8, "")).len == 0) os.setEnv("GIT_PREFIX", ".");
    const path = getMergeToolPath(tool);
    if (mode == .merge) {
        if (trustExitCode(tool)) return runCmd(tool, path, v, base_present);
        touch(v.backup);
        _ = runCmd(tool, path, v, base_present);
        return if (checkUnchanged(v)) 0 else 1;
    }
    return runCmd(tool, path, v, base_present);
}

// ---------------------------------------------------------------------------
// --tool-help

fn listConfigTools(out: *std.ArrayList([]const u8), section: []const u8) void {
    const pre = util.concat(&.{ section, "." });
    for (repo_mod.cfg.entries.items) |e| {
        if (!std.ascii.startsWithIgnoreCase(e.key, pre)) continue;
        if (std.mem.indexOf(u8, e.key[pre.len..], ".cmd") == null) continue;
        // `read -r key value` with IFS=LF keeps the whole line in $key
        var line = util.concat(&.{ e.key, " ", e.value orelse "" });
        if (e.value == null) line = util.dupe(e.key);
        var name: []const u8 = line[pre.len..];
        if (util.endsWith(name, ".cmd")) name = name[0 .. name.len - 4];
        out.append(gpa, util.concat(&.{ "\t\t", name })) catch util.oom();
    }
}

fn allToolNames() [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    for (script_names) |s| {
        for (variants(s)) |v| {
            var dup = false;
            for (l.items) |x| {
                if (util.eql(x, v)) dup = true;
            }
            if (!dup) l.append(gpa, v) catch util.oom();
        }
    }
    util.sortStrings(l.items);
    return l.items;
}

fn showToolNames(available: bool, preamble_in: []const u8, not_found: []const u8, extra: []const u8) bool {
    var pre = preamble_in;
    var shown = false;
    for (allToolNames()) |t| {
        if (!setupTool(t, true)) continue;
        const s = findScript(t).?;
        if (!modeOk(s)) continue;
        if (isAvailable(t) != available) continue;
        if (pre.len > 0) {
            util.outf("{s}\n", .{pre});
            pre = "";
        }
        shown = true;
        util.outf("\t\t{s:<15}  {s}\n", .{ t, helpText(s, t) });
    }
    if (extra.len > 0) {
        if (pre.len > 0) {
            util.out(pre);
            pre = "";
        }
        shown = true;
        util.outf("\n{s}\n", .{extra});
    }
    if (pre.len > 0 and not_found.len > 0) util.outf("{s}\n", .{not_found});
    return shown;
}

pub fn showToolHelp() noreturn {
    const m = modeName();
    const tool_opt = util.fmt("'git {s}tool --tool=<tool>'", .{m});
    var cfg_tools: std.ArrayList([]const u8) = .empty;
    if (mode == .diff) listConfigTools(&cfg_tools, "difftool");
    listConfigTools(&cfg_tools, "mergetool");
    util.sortStrings(cfg_tools.items);
    var extra: []const u8 = "";
    if (cfg_tools.items.len > 0) {
        extra = util.concat(&.{ "\tuser-defined:\n", std.mem.join(gpa, "\n", cfg_tools.items) catch util.oom() });
    }
    var any = false;
    if (showToolNames(true, util.fmt("{s} may be set to one of the following:", .{tool_opt}), util.fmt("No suitable tool for 'git {s}tool --tool=<tool>' found.", .{m}), extra)) any = true;
    if (showToolNames(false, "\nThe following tools are valid, but not currently available:", "", "")) any = true;
    if (any) {
        util.out("\nSome of the tools listed above only work in a windowed\nenvironment. If run in a terminal-only session, they will fail.\n");
    }
    os.exit(0);
}
