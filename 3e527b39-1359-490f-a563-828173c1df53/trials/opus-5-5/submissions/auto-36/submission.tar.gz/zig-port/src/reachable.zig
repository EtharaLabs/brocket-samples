//! Port of reachable.c: compute the set of objects reachable from refs,
//! HEADs of all worktrees, the index files, rebase state files and
//! (optionally) reflogs, plus "recent" unreachable objects.
//! Used by prune (and available to gc/repack).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const index_mod = @import("index.zig");
const worktree = @import("worktree.zig");
const fsck = @import("fsck.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;

pub const Options = struct {
    mark_reflog: bool = true,
    /// mark objects whose mtime is newer than this (0 = don't)
    mark_recent: i64 = 0,
    /// extra starting points (e.g. command line heads)
    extra: []const Oid = &.{},
};

const Item = struct { oid: Oid, typ: ?ObjType };

const Walker = struct {
    seen: hash.OidSet = .empty,
    stack: std.ArrayList(Item) = .empty,
    ignore_missing: bool = false,

    fn add(self: *Walker, oid: Oid, typ: ?ObjType) void {
        if (self.seen.contains(oid)) return;
        self.seen.put(gpa, oid, {}) catch util.oom();
        self.stack.append(gpa, .{ .oid = oid, .typ = typ }) catch util.oom();
    }

    fn run(self: *Walker) void {
        while (self.stack.pop()) |it| {
            if (it.typ) |t| {
                if (t == .blob) continue;
            }
            const rd = fsck.readObject(it.oid, true) orelse {
                if (self.ignore_missing) continue;
                if (@import("promisor.zig").hasRemote() and @import("promisor.zig").isPromisorObject(it.oid)) continue;
                const tn = if (it.typ) |t| t.name() else "object";
                util.die("bad {s} object {s}", .{ tn, &hash.hex(it.oid) });
            };
            switch (rd.typ) {
                .commit => self.walkCommit(it.oid, rd.data),
                .tree => self.walkTree(rd.data),
                .tag => self.walkTag(rd.data),
                else => {},
            }
        }
    }

    fn walkCommit(self: *Walker, oid: Oid, data: []const u8) void {
        var it = std.mem.splitScalar(u8, data, '\n');
        const shallow = fsck.isShallow(oid);
        while (it.next()) |line| {
            if (line.len == 0) break;
            if (util.skipPrefix(line, "tree ")) |h| {
                if (hash.fromHex(h)) |t| self.add(t, .tree);
            } else if (util.skipPrefix(line, "parent ")) |h| {
                if (shallow) continue;
                if (hash.fromHex(h)) |p| self.add(p, .commit);
            }
        }
    }

    fn walkTree(self: *Walker, data: []const u8) void {
        var p: usize = 0;
        while (p < data.len) {
            const sp = std.mem.indexOfScalarPos(u8, data, p, ' ') orelse return;
            const nul = std.mem.indexOfScalarPos(u8, data, sp, 0) orelse return;
            if (nul + 21 > data.len) return;
            const mode = std.fmt.parseInt(u32, data[p..sp], 8) catch 0;
            const oid: Oid = data[nul + 1 ..][0..20].*;
            p = nul + 21;
            switch (mode & os.S_IFMT) {
                os.S_IFDIR => self.add(oid, .tree),
                os.S_IFGITLINK => {},
                else => self.add(oid, .blob),
            }
        }
    }

    fn walkTag(self: *Walker, data: []const u8) void {
        if (!util.startsWith(data, "object ") or data.len < 47) return;
        const oid = hash.fromHex(data[7..47]) orelse return;
        var typ: ?ObjType = null;
        if (std.mem.indexOf(u8, data, "\ntype ")) |tp| {
            const s = data[tp + 6 ..];
            const e = std.mem.indexOfScalar(u8, s, '\n') orelse s.len;
            typ = ObjType.fromName(s[0..e]);
        }
        self.add(oid, typ);
    }
};

fn addRef(w: *Walker, name: []const u8, oid: Oid) void {
    if (!fsck.hasObject(oid)) util.die("unable to parse object: {s}", .{name});
    w.add(oid, null);
}

fn worktreeRefName(wt: *const worktree.Worktree, name: []const u8) []const u8 {
    if (!wt.is_current) {
        if (wt.isMain()) return util.concat(&.{ "main-worktree/", name });
        return util.concat(&.{ "worktrees/", wt.id.?, "/", name });
    }
    return name;
}

fn addCacheTree(w: *Walker, ct: *index_mod.CacheTree) void {
    if (ct.entry_count >= 0) {
        if (fsck.hasObject(ct.oid)) w.add(ct.oid, .tree);
    }
    for (ct.children.items) |c| addCacheTree(w, c);
}

fn addIndex(w: *Walker, path: []const u8) void {
    if (!os.exists(path)) return;
    const idx = index_mod.readFrom(path);
    for (idx.entries.items) |e| {
        if (e.mode & os.S_IFMT == os.S_IFGITLINK) continue;
        w.add(e.oid, .blob);
    }
    if (idx.cache_tree) |ct| addCacheTree(w, ct);
}

fn collectLogs(base: []const u8, rel: []const u8, out: *std.ArrayList([]const u8)) void {
    const dir = if (rel.len == 0) base else util.concat(&.{ base, "/", rel });
    const ents = os.listDir(dir) orelse return;
    for (ents) |e| {
        const name = if (rel.len == 0) e.name else util.concat(&.{ rel, "/", e.name });
        const full = util.concat(&.{ base, "/", name });
        if (os.isDir(full)) collectLogs(base, name, out) else if (os.isFile(full)) out.append(gpa, name) catch util.oom();
    }
}

/// Reflog names (with worktree prefixes) of every worktree; shared logs
/// are listed once.
pub fn allReflogNames() [][]const u8 {
    var names: std.ArrayList([]const u8) = .empty;
    names.appendSlice(gpa, refs.listReflogs()) catch util.oom();
    for (worktree.getAllWithoutHead()) |wt| {
        if (wt.is_current) continue;
        var tmp: std.ArrayList([]const u8) = .empty;
        collectLogs(util.concat(&.{ wt.gitDir(), "/logs" }), "", &tmp);
        for (tmp.items) |n| {
            if (!refs.isPerWorktreeRef(n)) continue;
            if (!refs.checkRefnameFormat(n, refs.ALLOW_ONELEVEL)) continue;
            names.append(gpa, worktreeRefName(wt, n)) catch util.oom();
        }
    }
    return names.items;
}

fn addReflogs(w: *Walker) void {
    for (allReflogNames()) |n| {
        var warned = false;
        for (refs.readReflog(n)) |e| {
            for ([_]Oid{ e.old, e.new }) |o| {
                if (hash.isZero(o)) continue;
                if (fsck.hasObject(o)) {
                    w.add(o, null);
                } else if (!warned) {
                    util.warn("reflog of '{s}' references pruned commits", .{n});
                    warned = true;
                }
            }
        }
    }
}

fn addOneFile(w: *Walker, path: []const u8) void {
    const data = os.readFile(path) orelse return;
    const t = util.trim(data);
    if (t.len < 40) return;
    const oid = hash.fromHex(t[0..40]) orelse return;
    if (!fsck.hasObject(oid)) util.die("unable to parse object: {s}", .{t});
    w.add(oid, null);
}

/// mark_reachable_objects(): returns the set of reachable object ids.
pub fn markReachable(opts: Options) hash.OidSet {
    var w = Walker{};
    const r = repo_mod.repo();

    // index files of all worktrees
    for (worktree.getAllWithoutHead()) |wt| {
        const path = if (wt.is_current) r.indexPath() else wt.gitPath("index");
        addIndex(&w, path);
    }
    // refs
    for (refs.iterate("refs/", .{ .include_broken = true, .check_objects = false })) |ref| {
        if (ref.flags & refs.REF_ISSYMREF != 0 and (ref.flags & refs.REF_ISBROKEN != 0 or hash.isZero(ref.oid))) {
            util.warn("symbolic ref is dangling: {s}", .{ref.name});
            continue;
        }
        if (hash.isZero(ref.oid)) continue;
        addRef(&w, ref.name, ref.oid);
    }
    // HEADs
    for (worktree.getAllWithoutHead()) |wt| {
        const name = worktreeRefName(wt, "HEAD");
        const res = refs.resolveFull(name, true);
        if (res.missing or res.broken or hash.isZero(res.oid)) continue;
        addRef(&w, name, res.oid);
    }
    // rebase state
    for (worktree.getAllWithoutHead()) |wt| {
        const gd = wt.gitDir();
        for ([_][]const u8{ "rebase-apply/autostash", "rebase-apply/orig-head", "rebase-merge/autostash", "rebase-merge/orig-head" }) |f| {
            addOneFile(&w, util.concat(&.{ gd, "/", f }));
        }
    }
    if (opts.mark_reflog) addReflogs(&w);
    for (opts.extra) |o| w.add(o, null);
    w.run();

    if (opts.mark_recent != 0) {
        w.ignore_missing = true;
        addRecent(&w, opts.mark_recent);
        w.run();
    }
    return w.seen;
}

fn addRecent(w: *Walker, ts: i64) void {
    const odb = repo_mod.repo().odb();
    const dir = odb.objects_dir;
    var b: usize = 0;
    while (b < 256) : (b += 1) {
        const hx = util.fmt("{x:0>2}", .{b});
        const sub = util.concat(&.{ dir, "/", hx });
        const ents = os.listDir(sub) orelse continue;
        for (ents) |e| {
            if (e.name.len != 38) continue;
            const oid = hash.fromHex(util.concat(&.{ hx, e.name })) orelse continue;
            const st = os.statPath(util.concat(&.{ sub, "/", e.name })) orelse continue;
            if (st.mtime <= ts) continue;
            w.add(oid, null);
        }
    }
    odb.loadPacks();
    const pfx = util.concat(&.{ dir, "/pack/" });
    for (odb.packs.items) |p| {
        if (!util.startsWith(p.pack_path, pfx)) continue;
        const st = os.statPath(p.pack_path) orelse continue;
        if (st.mtime <= ts) continue;
        var i: u32 = 0;
        while (i < p.num) : (i += 1) w.add(p.oidAt(i), null);
    }
}
