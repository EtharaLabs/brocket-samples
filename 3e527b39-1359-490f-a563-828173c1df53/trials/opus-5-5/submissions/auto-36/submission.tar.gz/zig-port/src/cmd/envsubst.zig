//! git sh-i18n--envsubst (port of sh-i18n--envsubst.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const gpa = util.gpa;

fn isStart(c: u8) bool {
    return (c >= 'A' and c <= 'Z') or (c >= 'a' and c <= 'z') or c == '_';
}

fn isCont(c: u8) bool {
    return isStart(c) or (c >= '0' and c <= '9');
}

/// find_variables(): $VAR and ${VAR} occurrences in `s`
fn findVariables(s: []const u8, out: *std.ArrayList([]const u8)) void {
    var i: usize = 0;
    while (i < s.len) {
        const ch = s[i];
        i += 1;
        if (ch != '$') continue;
        var brace = false;
        if (i < s.len and s[i] == '{') {
            brace = true;
            i += 1;
        }
        const start = i;
        if (i < s.len and isStart(s[i])) {
            i += 1;
            while (i < s.len and isCont(s[i])) i += 1;
            const end = i;
            var valid = true;
            if (brace) {
                if (i < s.len and s[i] == '}') i += 1 else valid = false;
            }
            if (valid) out.append(gpa, s[start..end]) catch util.oom();
        }
    }
}

fn member(vars: []const []const u8, name: []const u8) bool {
    for (vars) |v| if (util.eql(v, name)) return true;
    return false;
}

fn substFromStdin(vars: []const []const u8) void {
    const in = os.readAllFd(0) catch "";
    const out = &util.stdout;
    var i: usize = 0;
    while (i < in.len) {
        const c = in[i];
        i += 1;
        if (c != '$') {
            out.byte(c);
            continue;
        }
        var opening = false;
        if (i < in.len and in[i] == '{') {
            opening = true;
            i += 1;
        }
        if (i < in.len and isStart(in[i])) {
            const start = i;
            while (i < in.len and isCont(in[i])) i += 1;
            const name = in[start..i];
            var closing = false;
            var valid = true;
            if (opening) {
                if (i < in.len and in[i] == '}') {
                    closing = true;
                    i += 1;
                } else valid = false;
            }
            if (valid and !member(vars, name)) valid = false;
            if (valid) {
                if (os.getenv(name)) |v| out.write(v);
            } else {
                out.byte('$');
                if (opening) out.byte('{');
                out.write(name);
                if (closing) out.byte('}');
            }
        } else {
            out.byte('$');
            if (opening) out.byte('{');
        }
    }
}

pub fn cmdEnvsubst(args: []const []const u8) u8 {
    switch (args.len) {
        1 => util.err("we won't substitute all variables on stdin for you", .{}),
        2 => {
            var vars: std.ArrayList([]const u8) = .empty;
            findVariables(args[1], &vars);
            substFromStdin(vars.items);
        },
        3 => {
            if (!util.eql(args[1], "--variables"))
                util.err("first argument must be --variables when two are given", .{});
            var vars: std.ArrayList([]const u8) = .empty;
            findVariables(args[2], &vars);
            for (vars.items) |v| {
                util.stdout.write(v);
                util.stdout.byte('\n');
            }
        },
        else => util.err("too many arguments", .{}),
    }
    util.flushStdout();
    return 0;
}
