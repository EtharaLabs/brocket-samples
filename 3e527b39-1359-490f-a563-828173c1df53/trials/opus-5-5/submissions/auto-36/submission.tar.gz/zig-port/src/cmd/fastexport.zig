//! git fast-export (port of builtin/fast-export.c).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const odb_mod = @import("../odb.zig");
const refs = @import("../refs.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const revision = @import("../revision.zig");
const cn = @import("../commitnode.zig");
const objects = @import("../objects.zig");
const pathspec = @import("../pathspec.zig");
const pretty = @import("../pretty.zig");
const diff = @import("../diff.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const Commit = cn.Commit;
const Obj = cn.Obj;
const gpa = util.gpa;

const usage_str = [_][]const u8{"git fast-export [<options>] [<revision-range>] [[--] <path>...]"};

const SignMode = enum { abort, verbatim, warn_verbatim, warn_strip, strip };
const TagFilterMode = enum { abort, drop, rewrite };
const ReencodeMode = enum { abort, yes, no };

var progress: i32 = 0;
var signed_tag_mode: SignMode = .abort;
var signed_commit_mode: SignMode = .strip;
var tag_of_filtered_mode: TagFilterMode = .abort;
var reencode_mode: ReencodeMode = .abort;
var fake_missing_tagger = false;
var use_done_feature = false;
var no_data = false;
var full_tree = false;
var reference_excluded_commits = false;
var show_original_ids = false;
var mark_tags = false;
var anonymize = false;
var export_filename: ?[]const u8 = null;
var import_filename: ?[]const u8 = null;
var import_filename_if_exists: ?[]const u8 = null;
var refspecs_list: std.ArrayList([]const u8) = .empty;
var anonymize_map: std.ArrayList([]const u8) = .empty;

const NamedRef = struct { name: []const u8, obj: *Obj };
var extra_refs: std.ArrayList(NamedRef) = .empty;
var tag_refs: std.ArrayList(NamedRef) = .empty;
var sources: cn.Slab(?[]const u8) = cn.Slab(?[]const u8).init(null);
var revs: revision.RevInfo = undefined;
var rename_opt: ?*diff.DiffOptions = null;

// ------------------------------------------------------------------ marks (struct decoration)

const DecoEntry = struct { oid: Oid, is_commit: bool, mark: u32 };
var deco_entries: []?DecoEntry = &.{};
var deco_nr: usize = 0;
var mark_lookup: hash.OidMap(u32) = .empty;
var last_idnum: u32 = 0;

fn oidhash(oid: Oid) u32 {
    return std.mem.readInt(u32, oid[0..4], .little);
}

fn decoInsert(e: DecoEntry) void {
    const size = deco_entries.len;
    var j: usize = oidhash(e.oid) % size;
    while (deco_entries[j]) |*x| {
        if (hash.eql(x.oid, e.oid)) {
            x.mark = e.mark;
            return;
        }
        j += 1;
        if (j >= size) j = 0;
    }
    deco_entries[j] = e;
    deco_nr += 1;
}

fn markObject(obj: *const Obj, mark: u32) void {
    if (deco_nr + 1 > deco_entries.len * 2 / 3) {
        const old = deco_entries;
        const new_size = (old.len + 1000) * 3 / 2;
        deco_entries = gpa.alloc(?DecoEntry, new_size) catch util.oom();
        @memset(deco_entries, null);
        deco_nr = 0;
        for (old) |x| if (x) |e| decoInsert(e);
    }
    decoInsert(.{ .oid = obj.oid, .is_commit = obj.typ == .commit, .mark = mark });
    mark_lookup.put(gpa, obj.oid, mark) catch util.oom();
}

fn markNextObject(obj: *const Obj) void {
    last_idnum += 1;
    markObject(obj, last_idnum);
}

fn getObjectMark(obj: ?*const Obj) u32 {
    const o = obj orelse return 0;
    return mark_lookup.get(o.oid) orelse 0;
}

// ------------------------------------------------------------------ output helpers

fn out(s: []const u8) void {
    util.out(s);
}

fn outf(comptime f: []const u8, args: anytype) void {
    util.outf(f, args);
}

var progress_counter: i32 = 0;
fn showProgress() void {
    if (progress == 0) return;
    progress_counter += 1;
    if (@rem(progress_counter, progress) == 0) outf("progress {d} objects\n", .{progress_counter});
}

fn printPath(path0: []const u8) void {
    var path = path0;
    if (anonymize) {
        var b: util.Buf = .empty;
        anonymizePath(&b, path0, &anon_paths, .path);
        path = b.items;
    }
    const q = util.cquote(path);
    if (q.len != path.len or !util.eql(q, path)) {
        out(q);
    } else if (std.mem.indexOfScalar(u8, path, ' ') != null) {
        outf("\"{s}\"", .{path});
    } else out(path);
}

const null_hex = "0000000000000000000000000000000000000000";

// ------------------------------------------------------------------ anonymize

const AnonMap = std.StringHashMapUnmanaged([]const u8);
var anon_seeds: AnonMap = .empty;
var anon_paths: AnonMap = .empty;
var anon_refs: AnonMap = .empty;
var anon_objs: AnonMap = .empty;
var anon_idents: AnonMap = .empty;
var anon_tags: AnonMap = .empty;
var anon_ctr_path: u32 = 0;
var anon_ctr_ref: u32 = 0;
var anon_ctr_oid: u32 = 1;
var anon_ctr_ident: u32 = 0;
var anon_ctr_msg: u32 = 0;
var anon_ctr_tag: u32 = 0;
var anon_ctr_blob: u32 = 0;

const AnonKind = enum { path, ref, oid, ident, tag };

fn anonGenerate(kind: AnonKind) []const u8 {
    switch (kind) {
        .path => {
            defer anon_ctr_path += 1;
            return util.fmt("path{d}", .{anon_ctr_path});
        },
        .ref => {
            defer anon_ctr_ref += 1;
            return util.fmt("ref{d}", .{anon_ctr_ref});
        },
        .oid => {
            var oid: Oid = hash.zero;
            std.mem.writeInt(u32, oid[oid.len - 4 ..][0..4], anon_ctr_oid, .big);
            anon_ctr_oid += 1;
            return util.dupe(&hash.hex(oid));
        },
        .ident => {
            defer anon_ctr_ident += 1;
            return util.fmt("User {d} <user{d}@example.com>", .{ anon_ctr_ident, anon_ctr_ident });
        },
        .tag => {
            defer anon_ctr_tag += 1;
            return util.fmt("tag message {d}", .{anon_ctr_tag});
        },
    }
}

fn anonymizeStr(map: *AnonMap, kind: AnonKind, orig: []const u8) []const u8 {
    if (anon_seeds.get(orig)) |v| return v;
    if (map.get(orig)) |v| return v;
    const v = anonGenerate(kind);
    map.put(gpa, util.dupe(orig), v) catch util.oom();
    return v;
}

fn anonymizePath(o: *util.Buf, path0: []const u8, map: *AnonMap, kind: AnonKind) void {
    var path = path0;
    while (path.len > 0) {
        const end = std.mem.indexOfScalar(u8, path, '/') orelse path.len;
        util.bufAppend(o, anonymizeStr(map, kind, path[0..end]));
        path = path[end..];
        if (path.len > 0) {
            util.bufByte(o, '/');
            path = path[1..];
        }
    }
}

fn anonymizeOid(hex: []const u8) []const u8 {
    return anonymizeStr(&anon_objs, .oid, hex);
}

fn anonymizeRefname(refname0: []const u8) []const u8 {
    const prefixes = [_][]const u8{ "refs/heads/", "refs/tags/", "refs/remotes/", "refs/" };
    var refname = refname0;
    var o: util.Buf = .empty;
    for (prefixes) |p| {
        if (util.skipPrefix(refname, p)) |r| {
            util.bufAppend(&o, p);
            refname = r;
            break;
        }
    }
    anonymizePath(&o, refname, &anon_refs, .ref);
    return o.items;
}

fn anonymizeCommitMessage() []const u8 {
    defer anon_ctr_msg += 1;
    return util.fmt("subject {d}\n\nbody\n", .{anon_ctr_msg});
}

fn isSpaceC(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r' or ch == 0x0b or ch == 0x0c;
}

/// anonymize_ident_line(): line is "<header> Name <email> date tz"
fn anonymizeIdentLine(line: []const u8) []const u8 {
    const sp = std.mem.indexOfScalar(u8, line, ' ') orelse util.die("BUG: malformed line fed to anonymize_ident_line: {s}", .{line});
    var o: util.Buf = .empty;
    util.bufAppend(&o, line[0 .. sp + 1]);
    const id = line[sp + 1 ..];
    malformed: {
        const lt = std.mem.indexOfScalar(u8, id, '<') orelse break :malformed;
        const mail_end = std.mem.indexOfScalarPos(u8, id, lt + 1, '>') orelse break :malformed;
        const last_gt = std.mem.lastIndexOfScalar(u8, id, '>').?;
        var cp = last_gt + 1;
        while (cp < id.len and isSpaceC(id[cp])) cp += 1;
        if (cp >= id.len) break :malformed;
        const date_begin = cp;
        while (cp < id.len and std.ascii.isDigit(id[cp])) cp += 1;
        if (cp == date_begin) break :malformed;
        while (cp < id.len and isSpaceC(id[cp])) cp += 1;
        if (cp >= id.len or (id[cp] != '+' and id[cp] != '-')) break :malformed;
        cp += 1;
        const tz_digits = cp;
        while (cp < id.len and std.ascii.isDigit(id[cp])) cp += 1;
        if (cp == tz_digits) break :malformed;
        util.bufAppend(&o, anonymizeStr(&anon_idents, .ident, id[0..mail_end]));
        util.bufByte(&o, ' ');
        util.bufAppend(&o, id[date_begin..cp]);
        return o.items;
    }
    util.bufAppend(&o, "Malformed Ident <malformed@example.com> 0 -0000");
    return o.items;
}

fn addAnonymizeSeed(arg: []const u8) void {
    var key = arg;
    var value = arg;
    if (std.mem.indexOfScalar(u8, arg, ':')) |d| {
        key = arg[0..d];
        value = arg[d + 1 ..];
    }
    if (key.len == 0 or value.len == 0) {
        util.err("--anonymize-map token cannot be empty", .{});
        os.exit(129);
    }
    anon_seeds.put(gpa, key, value) catch util.oom();
}

// ------------------------------------------------------------------ blobs

fn exportBlob(oid: Oid) void {
    if (no_data) return;
    if (hash.isZero(oid)) return;
    if (cn.lookupAny(oid)) |o| {
        if (o.flags & cn.SHOWN != 0) return;
    }
    var data: []const u8 = undefined;
    var object: *Obj = undefined;
    if (anonymize) {
        data = util.fmt("anonymous blob {d}", .{anon_ctr_blob});
        anon_ctr_blob += 1;
        object = cn.lookup(oid, .blob) orelse util.die("could not read blob {s}", .{hash.hex(oid)});
    } else {
        const obj = repo_mod.repo().odb().read(oid) orelse util.die("could not read blob {s}", .{hash.hex(oid)});
        object = cn.lookup(oid, obj.typ) orelse util.die("could not read blob {s}", .{hash.hex(oid)});
        data = obj.data;
    }
    markNextObject(object);
    var b: util.Buf = .empty;
    util.bufPrint(&b, "blob\nmark :{d}\n", .{last_idnum});
    if (show_original_ids) util.bufPrint(&b, "original-oid {s}\n", .{hash.hex(oid)});
    util.bufPrint(&b, "data {d}\n", .{data.len});
    out(b.items);
    out(data);
    out("\n");
    showProgress();
    object.flags |= cn.SHOWN;
}

// ------------------------------------------------------------------ tree diff

const Pair = struct {
    status: u8,
    path: []const u8,
    old_path: []const u8 = "",
    old_mode: u32 = 0,
    old_oid: Oid = hash.zero,
    new_mode: u32 = 0,
    new_oid: Oid = hash.zero,
};

var queue: std.ArrayList(Pair) = .empty;

fn isDirMode(m: u32) bool {
    return m & 0o170000 == 0o040000;
}

fn interesting(full: []const u8, is_dir: bool) bool {
    const ps = &revs.prune_data;
    if (ps.isEmpty()) return true;
    if (is_dir) return ps.matches(full, true) or ps.couldMatchUnder(full);
    return ps.matches(full, false);
}

fn joinBase(base: []const u8, name: []const u8) []const u8 {
    if (base.len == 0) return name;
    return util.concat(&.{ base, "/", name });
}

fn readTreeEntries(oid: ?Oid) []objects.TreeEntry {
    const o = oid orelse return &.{};
    return objects.readTree(o) orelse util.die("unable to read tree {s}", .{hash.hex(o)});
}

fn oneSide(oid: Oid, base: []const u8, add: bool) void {
    for (readTreeEntries(oid)) |e| {
        const full = joinBase(base, e.name);
        if (!interesting(full, e.isDir())) continue;
        if (e.isDir()) {
            oneSide(e.oid, full, add);
        } else if (add) {
            queue.append(gpa, .{ .status = 'A', .path = full, .new_mode = e.mode, .new_oid = e.oid }) catch util.oom();
        } else {
            queue.append(gpa, .{ .status = 'D', .path = full, .old_mode = e.mode, .old_oid = e.oid }) catch util.oom();
        }
    }
}

fn diffTrees(a: ?Oid, b: ?Oid, base: []const u8) void {
    const ea = readTreeEntries(a);
    const eb = readTreeEntries(b);
    var i: usize = 0;
    var j: usize = 0;
    while (i < ea.len or j < eb.len) {
        var ord: std.math.Order = undefined;
        if (i >= ea.len) {
            ord = .gt;
        } else if (j >= eb.len) {
            ord = .lt;
        } else ord = objects.baseNameCompare(ea[i].name, ea[i].mode, eb[j].name, eb[j].mode);
        switch (ord) {
            .lt => {
                const e = ea[i];
                i += 1;
                const full = joinBase(base, e.name);
                if (!interesting(full, e.isDir())) continue;
                if (e.isDir()) oneSide(e.oid, full, false) else queue.append(gpa, .{ .status = 'D', .path = full, .old_mode = e.mode, .old_oid = e.oid }) catch util.oom();
            },
            .gt => {
                const e = eb[j];
                j += 1;
                const full = joinBase(base, e.name);
                if (!interesting(full, e.isDir())) continue;
                if (e.isDir()) oneSide(e.oid, full, true) else queue.append(gpa, .{ .status = 'A', .path = full, .new_mode = e.mode, .new_oid = e.oid }) catch util.oom();
            },
            .eq => {
                const x = ea[i];
                const y = eb[j];
                i += 1;
                j += 1;
                if (hash.eql(x.oid, y.oid) and x.mode == y.mode) continue;
                const full = joinBase(base, x.name);
                if (!interesting(full, x.isDir())) continue;
                if (x.isDir() and y.isDir()) {
                    diffTrees(x.oid, y.oid, full);
                } else {
                    const st: u8 = if ((x.mode & 0o170000) != (y.mode & 0o170000)) 'T' else 'M';
                    queue.append(gpa, .{ .status = st, .path = full, .old_mode = x.mode, .old_oid = x.oid, .new_mode = y.mode, .new_oid = y.oid }) catch util.oom();
                }
            },
        }
    }
}

fn sortName(p: Pair) []const u8 {
    return if (p.old_path.len > 0) p.old_path else p.path;
}

/// diff_tree_oid + export_blob + diffcore_std (log_tree_diff_flush) with
/// rename/copy detection; results land in `queue`.
fn diffWithRenames(o: *diff.DiffOptions, old: ?Oid, new: Oid) void {
    diff.clearQueue();
    o.pathspec = revs.prune_data;
    diff.diffTree(o, old, new, "");
    for (diff.queue.items) |p| {
        if (p.two.mode & 0o170000 != 0o160000) exportBlob(p.two.oid);
    }
    diff.diffcoreStd(o);
    for (diff.queue.items) |p| {
        var e: Pair = .{ .status = p.status, .path = p.two.path, .old_mode = p.one.mode, .old_oid = p.one.oid, .new_mode = p.two.mode, .new_oid = p.two.oid };
        switch (p.status) {
            'D' => e.path = p.one.path,
            'R', 'C' => e.old_path = p.one.path,
            'A', 'M', 'T' => {},
            else => util.die("unexpected comparison status '{c}' for {s}, {s}", .{ p.status, p.one.path, p.two.path }),
        }
        queue.append(gpa, e) catch util.oom();
    }
    diff.clearQueue();
}

fn depthFirstLess(_: void, a: Pair, b: Pair) bool {
    const na = sortName(a);
    const nb = sortName(b);
    const len = @min(na.len, nb.len);
    const o = std.mem.order(u8, na[0..len], nb[0..len]);
    if (o != .eq) return o == .lt;
    if (na.len != nb.len) return na.len > nb.len;
    return @intFromBool(a.status == 'R') < @intFromBool(b.status == 'R');
}

fn showFilemodify() void {
    std.mem.sort(Pair, queue.items, {}, depthFirstLess);
    var changed: std.StringHashMapUnmanaged(void) = .empty;
    for (queue.items) |p| {
        switch (p.status) {
            'D' => {
                out("D ");
                printPath(p.path);
                changed.put(gpa, p.path, {}) catch util.oom();
                out("\n");
            },
            else => {
                if ((p.status == 'R' or p.status == 'C') and !changed.contains(p.old_path)) {
                    outf("{c} ", .{p.status});
                    printPath(p.old_path);
                    out(" ");
                    printPath(p.path);
                    changed.put(gpa, p.path, {}) catch util.oom();
                    out("\n");
                    if (hash.eql(p.old_oid, p.new_oid) and p.old_mode == p.new_mode) continue;
                }
                if (no_data or p.new_mode & 0o170000 == 0o160000) {
                    outf("M {o:0>6} {s} ", .{ p.new_mode, if (anonymize) anonymizeOid(&hash.hex(p.new_oid)) else &hash.hex(p.new_oid) });
                } else {
                    outf("M {o:0>6} :{d} ", .{ p.new_mode, getObjectMark(cn.lookupAny(p.new_oid)) });
                }
                printPath(p.path);
                changed.put(gpa, p.path, {}) catch util.oom();
                out("\n");
            },
        }
    }
}

// ------------------------------------------------------------------ commits

fn rewriteCommit(p0: *Commit) ?*Commit {
    var p = p0;
    while (true) {
        if (p.parents) |pl| {
            if (pl.next != null) break;
        }
        if (p.obj.flags & cn.UNINTERESTING != 0) break;
        if (p.obj.flags & cn.TREESAME == 0) break;
        const pl = p.parents orelse return null;
        p = pl.item;
    }
    return p;
}

/// find_commit_header(): value of the first header line "key " in buf
/// (stops at the blank line). Returns slice into buf.
fn findCommitHeader(buf: []const u8, start: usize, key: []const u8) ?struct { start: usize, len: usize } {
    var line = start;
    while (line < buf.len) {
        const eol = std.mem.indexOfScalarPos(u8, buf, line, '\n') orelse buf.len;
        if (eol == line) return null;
        const l = buf[line..eol];
        if (l.len > key.len and util.startsWith(l, key) and l[key.len] == ' ')
            return .{ .start = line + key.len + 1, .len = eol - line - key.len - 1 };
        line = eol + 1;
    }
    return null;
}

const Sig = struct { data: []const u8, algo: []const u8 };

/// find_commit_multiline_header; returns value and position of the '\n' after it.
fn findMultilineHeader(buf: []const u8, start: usize, key: []const u8) ?struct { val: []const u8, end: usize } {
    const h = findCommitHeader(buf, start, key) orelse return null;
    var val: util.Buf = .empty;
    util.bufAppend(&val, buf[h.start .. h.start + h.len]);
    var eol = h.start + h.len;
    while (eol + 1 < buf.len and buf[eol] == '\n' and buf[eol + 1] == ' ') {
        const bol = eol + 2;
        eol = std.mem.indexOfScalarPos(u8, buf, bol, '\n') orelse buf.len;
        util.bufByte(&val, '\n');
        util.bufAppend(&val, buf[bol..eol]);
    }
    return .{ .val = val.items, .end = eol };
}

fn appendSignatures(sigs: *std.ArrayList(Sig), buf: []const u8, pos: usize, header: []const u8, algo: []const u8) usize {
    var start = pos;
    var end = pos;
    while (findMultilineHeader(buf, start + 1, header)) |r| {
        sigs.append(gpa, .{ .data = r.val, .algo = algo }) catch util.oom();
        end = r.end;
        start = end;
    }
    return end;
}

fn signatureFormat(sig: []const u8) []const u8 {
    if (util.startsWith(sig, "-----BEGIN PGP SIGNATURE-----") or util.startsWith(sig, "-----BEGIN PGP MESSAGE-----")) return "openpgp";
    if (util.startsWith(sig, "-----BEGIN SIGNED MESSAGE-----")) return "x509";
    if (util.startsWith(sig, "-----BEGIN SSH SIGNATURE-----")) return "ssh";
    return "unknown";
}

fn removeExtraRef(name: []const u8) void {
    var i: usize = 0;
    while (i < extra_refs.items.len) : (i += 1) {
        if (util.eql(extra_refs.items[i].name, name)) {
            _ = extra_refs.orderedRemove(i);
            return;
        }
    }
}

fn handleCommit(commit: *Commit) void {
    cn.parseOrDie(commit);
    const buf = commit.buffer;
    const hx = commit.hex();
    const a0 = std.mem.indexOf(u8, buf, "\nauthor ") orelse util.die("could not find author in commit {s}", .{hx});
    const author_start = a0 + 1;
    const author_end = std.mem.indexOfScalarPos(u8, buf, author_start, '\n') orelse buf.len;
    const c0 = std.mem.indexOfPos(u8, buf, author_end, "\ncommitter ") orelse util.die("could not find committer in commit {s}", .{hx});
    const committer_start = c0 + 1;
    const committer_end = std.mem.indexOfScalarPos(u8, buf, committer_start, '\n') orelse buf.len;
    var cursor = committer_end;
    var encoding: ?[]const u8 = null;
    if (cursor < buf.len and buf[cursor] == '\n') {
        if (findCommitHeader(buf, cursor + 1, "encoding")) |h| {
            encoding = buf[h.start .. h.start + h.len];
            cursor = h.start + h.len;
        }
    }
    var sigs: std.ArrayList(Sig) = .empty;
    if (cursor < buf.len and buf[cursor] == '\n') {
        const after1 = appendSignatures(&sigs, buf, cursor, "gpgsig", "sha1");
        const after256 = appendSignatures(&sigs, buf, cursor, "gpgsig-sha256", "sha256");
        cursor = @max(after1, after256);
    }
    var message: ?[]const u8 = null;
    if (std.mem.indexOfPos(u8, buf, cursor, "\n\n")) |m| message = buf[m + 2 ..];
    if (message) |m| {
        if (std.mem.indexOfScalar(u8, m, 0)) |z| message = m[0..z];
    }

    queue.clearRetainingCapacity();
    var parent_tree: ?Oid = null;
    if (commit.parents != null and (getObjectMark(&commit.parents.?.item.obj) != 0 or reference_excluded_commits) and !full_tree) {
        const p = commit.parents.?.item;
        cn.parseOrDie(p);
        parent_tree = p.tree;
    }
    if (rename_opt) |o| {
        diffWithRenames(o, parent_tree, commit.tree);
    } else {
        diffTrees(parent_tree, commit.tree, "");
        for (queue.items) |p| {
            if (p.new_mode & 0o170000 != 0o160000) exportBlob(p.new_oid);
        }
    }

    var refname: []const u8 = (sources.peek(commit) orelse &@as(?[]const u8, null)).* orelse "";
    removeExtraRef(refname);
    var author_line = buf[author_start..author_end];
    var committer_line = buf[committer_start..committer_end];
    if (anonymize) {
        refname = anonymizeRefname(refname);
        committer_line = anonymizeIdentLine(committer_line);
        author_line = anonymizeIdentLine(author_line);
    }

    markNextObject(&commit.obj);
    var reencoded: ?[]const u8 = null;
    if (anonymize) {
        reencoded = anonymizeCommitMessage();
    } else if (encoding) |enc| {
        switch (reencode_mode) {
            .yes => reencoded = pretty.reencodeString(message orelse "", "UTF-8", enc),
            .no => {},
            .abort => util.die("encountered commit-specific encoding {s} in commit {s}; use --reencode=[yes|no] to handle it", .{ enc, hx }),
        }
    }
    if (commit.parents == null) outf("reset {s}\n", .{refname});
    outf("commit {s}\nmark :{d}\n", .{ refname, last_idnum });
    if (show_original_ids) outf("original-oid {s}\n", .{hx});
    outf("{s}\n{s}\n", .{ author_line, committer_line });
    if (sigs.items.len > 0) {
        switch (signed_commit_mode) {
            .warn_verbatim, .verbatim => {
                if (signed_commit_mode == .warn_verbatim) util.warn("exporting {d} signature(s) for commit {s}", .{ sigs.items.len, hx });
                for (sigs.items) |s| {
                    outf("gpgsig {s} {s}\ndata {d}\n{s}\n", .{ s.algo, signatureFormat(s.data), s.data.len, s.data });
                }
            },
            .warn_strip => util.warn("stripping signature(s) from commit {s}", .{hx}),
            .strip => {},
            .abort => util.die("encountered signed commit {s}; use --signed-commits=<mode> to handle it", .{hx}),
        }
    }
    if (reencoded == null) {
        if (encoding) |e| outf("encoding {s}\n", .{e});
    }
    const msg = reencoded orelse message orelse "";
    outf("data {d}\n", .{msg.len});
    out(msg);

    var i: usize = 0;
    var pl = commit.parents;
    while (pl) |p| : (pl = p.next) {
        const mark = getObjectMark(&p.item.obj);
        if (mark == 0 and !reference_excluded_commits) continue;
        out(if (i == 0) "from " else "merge ");
        if (mark != 0) outf(":{d}\n", .{mark}) else outf("{s}\n", .{if (anonymize) anonymizeOid(&p.item.hex()) else &p.item.hex()});
        i += 1;
    }
    if (full_tree) out("deleteall\n");
    showFilemodify();
    out("\n");
    showProgress();
}

// ------------------------------------------------------------------ tags

fn parseSignedBuffer(b: []const u8) usize {
    var len: usize = 0;
    var match: usize = b.len;
    while (len < b.len) {
        const rest = b[len..];
        if (util.startsWith(rest, "-----BEGIN PGP SIGNATURE-----") or util.startsWith(rest, "-----BEGIN PGP MESSAGE-----") or
            util.startsWith(rest, "-----BEGIN SIGNED MESSAGE-----") or util.startsWith(rest, "-----BEGIN SSH SIGNATURE-----"))
            match = len;
        const eol = std.mem.indexOfScalarPos(u8, b, len, '\n');
        len = if (eol) |x| x + 1 else b.len;
    }
    return match;
}

/// tag->tagged as an object (type taken from the tag's "type" header, like parse_tag)
fn tagTarget(tag: *Obj) ?*Obj {
    const o = repo_mod.repo().odb().read(tag.oid) orelse return null;
    const t = objects.parseTag(o.data) orelse return null;
    const typ = t.typ;
    return cn.lookup(t.object, typ);
}

fn handleTag(name0: []const u8, tag: *Obj) void {
    var name = name0;
    const thx = hash.hex(tag.oid);
    var tagged = tagTarget(tag) orelse util.die("could not read tag {s}", .{thx});
    var t2 = tagged;
    while (t2.typ == .tag) t2 = tagTarget(t2) orelse util.die("could not read tag {s}", .{hash.hex(t2.oid)});
    if (t2.typ == .tree) {
        util.warn("omitting tag {s},\nsince tags of trees (or tags of tags of trees, etc.) are not supported.", .{thx});
        return;
    }
    const obj = repo_mod.repo().odb().read(tag.oid) orelse util.die("could not read tag {s}", .{thx});
    const buf = obj.data;
    var message: ?[]const u8 = null;
    var message_size: usize = 0;
    var hdr_end = buf.len;
    if (std.mem.indexOf(u8, buf, "\n\n")) |m| {
        message = buf[m + 2 ..];
        if (std.mem.indexOfScalar(u8, message.?, 0)) |z| message = message.?[0..z];
        message_size = message.?.len;
        hdr_end = m + 2;
    }
    var tagger: []const u8 = "";
    if (std.mem.indexOf(u8, buf[0..hdr_end], "\ntagger ")) |tp| {
        const s = tp + 1;
        const e = std.mem.indexOfScalarPos(u8, buf, s, '\n') orelse buf.len;
        tagger = buf[s..e];
        if (anonymize) tagger = anonymizeIdentLine(tagger);
    } else if (fake_missing_tagger) {
        tagger = "tagger Unspecified Tagger <unspecified-tagger> 0 +0000";
    }
    if (anonymize) {
        name = anonymizeRefname(name);
        if (message) |m| {
            message = anonymizeStr(&anon_tags, .tag, m[0..message_size]);
            message_size = message.?.len;
        }
    }

    if (message) |m| {
        const sig_offset = parseSignedBuffer(m[0..message_size]);
        if (sig_offset < message_size) {
            switch (signed_tag_mode) {
                .warn_verbatim => util.warn("exporting signed tag {s}", .{thx}),
                .verbatim => {},
                .warn_strip, .strip => {
                    if (signed_tag_mode == .warn_strip) util.warn("stripping signature from tag {s}", .{thx});
                    message_size = sig_offset;
                },
                .abort => util.die("encountered signed tag {s}; use --signed-tags=<mode> to handle it", .{thx}),
            }
        }
    }

    tagged = tagTarget(tag).?;
    var tagged_mark = getObjectMark(tagged);
    if (tagged_mark == 0) {
        switch (tag_of_filtered_mode) {
            .abort => util.die("tag {s} tags unexported object; use --tag-of-filtered-object=<mode> to handle it", .{thx}),
            .drop => return,
            .rewrite => {
                if (tagged.typ == .tag and !mark_tags) {
                    util.die("cannot export nested tags unless --mark-tags is specified.", .{});
                } else if (tagged.typ == .commit) {
                    const p = rewriteCommit(Commit.fromObj(tagged)) orelse {
                        outf("reset {s}\nfrom {s}\n\n", .{ name, null_hex });
                        return;
                    };
                    tagged_mark = getObjectMark(&p.obj);
                } else tagged_mark = getObjectMark(tagged);
            },
        }
    }
    if (tagged.typ == .tag) outf("reset {s}\nfrom {s}\n\n", .{ name, null_hex });
    if (util.skipPrefix(name, "refs/tags/")) |n| name = n;
    outf("tag {s}\n", .{name});
    if (mark_tags) {
        markNextObject(tag);
        outf("mark :{d}\n", .{last_idnum});
    }
    if (tagged_mark != 0) outf("from :{d}\n", .{tagged_mark}) else outf("from {s}\n", .{hash.hex(tagged.oid)});
    if (show_original_ids) outf("original-oid {s}\n", .{thx});
    out(tagger);
    if (tagger.len > 0) out("\n");
    outf("data {d}\n", .{message_size});
    if (message) |m| out(m[0..message_size]);
    out("\n");
}

// ------------------------------------------------------------------ refs

fn dwimRef(name: []const u8) ?struct { full: []const u8, count: usize } {
    const rules = [_][]const u8{ "{s}", "refs/{s}", "refs/tags/{s}", "refs/heads/{s}", "refs/remotes/{s}", "refs/remotes/{s}/HEAD" };
    var found: ?[]const u8 = null;
    var count: usize = 0;
    inline for (rules, 0..) |rule, ri| {
        const full = util.fmt(rule, .{name});
        var ok = true;
        if (ri == 0 and !util.startsWith(full, "refs/")) {
            for (full) |ch| {
                if (!std.ascii.isUpper(ch) and ch != '_') ok = false;
            }
        }
        if (ok) {
            if (refs.resolve(full)) |r| {
                if (found == null) found = r.name;
                count += 1;
            }
        }
    }
    const f = found orelse return null;
    return .{ .full = f, .count = count };
}

const Refspec = struct { src: []const u8, dst: []const u8, pattern: bool };
var refspecs: std.ArrayList(Refspec) = .empty;

fn parseRefspec(s0: []const u8) Refspec {
    var s = s0;
    if (s.len > 0 and s[0] == '+') s = s[1..];
    const colon = std.mem.lastIndexOfScalar(u8, s, ':');
    const src = if (colon) |c| s[0..c] else s;
    const dst = if (colon) |c| s[c + 1 ..] else s;
    const pat = std.mem.indexOfScalar(u8, src, '*') != null;
    if (pat != (std.mem.indexOfScalar(u8, dst, '*') != null) and dst.len > 0)
        util.die("invalid refspec '{s}'", .{s0});
    return .{ .src = src, .dst = dst, .pattern = pat };
}

fn applyRefspecs(name: []const u8) ?[]const u8 {
    for (refspecs.items) |r| {
        if (r.src.len == 0) continue;
        if (r.pattern) {
            const star = std.mem.indexOfScalar(u8, r.src, '*').?;
            const pre = r.src[0..star];
            const suf = r.src[star + 1 ..];
            if (name.len >= pre.len + suf.len and util.startsWith(name, pre) and std.mem.endsWith(u8, name, suf)) {
                const mid = name[pre.len .. name.len - suf.len];
                const dstar = std.mem.indexOfScalar(u8, r.dst, '*').?;
                return util.concat(&.{ r.dst[0..dstar], mid, r.dst[dstar + 1 ..] });
            }
        } else if (util.eql(r.src, name)) {
            return r.dst;
        }
    }
    return null;
}

fn getTagsAndDuplicates() void {
    for (revs.cmdline.items) |e| {
        if (e.flags & cn.UNINTERESTING != 0) continue;
        const d = dwimRef(e.name) orelse continue;
        if (d.count != 1) continue;
        var full_name = d.full;
        if (refspecs.items.len > 0) {
            if (applyRefspecs(full_name)) |p| full_name = p;
        }
        // get_commit()
        var commit: ?*Obj = null;
        switch (e.item.typ) {
            .commit => commit = e.item,
            .tag => {
                var t: ?*Obj = e.item;
                while (t != null and t.?.typ == .tag) {
                    tag_refs.append(gpa, .{ .name = full_name, .obj = t.? }) catch util.oom();
                    t = tagTarget(t.?);
                }
                commit = t orelse util.die("tag {s} points nowhere?", .{e.name});
            },
            else => {},
        }
        const c = commit orelse {
            util.warn("{s}: unexpected object of type {s}, skipping.", .{ e.name, e.item.typ.name() });
            continue;
        };
        switch (c.typ) {
            .commit => {},
            .blob => {
                exportBlob(c.oid);
                continue;
            },
            else => {
                util.warn("tag points to object of unexpected type {s}, skipping.", .{c.typ.name()});
                continue;
            },
        }
        if (e.item.typ != .tag) extra_refs.append(gpa, .{ .name = full_name, .obj = c }) catch util.oom();
        const slot = sources.at(Commit.fromObj(c));
        if (slot.* == null) slot.* = full_name;
    }
    // string_list_sort_u
    std.mem.sort(NamedRef, extra_refs.items, {}, struct {
        fn lt(_: void, a: NamedRef, b: NamedRef) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    var j: usize = 0;
    for (extra_refs.items) |r| {
        if (j > 0 and util.eql(extra_refs.items[j - 1].name, r.name)) continue;
        extra_refs.items[j] = r;
        j += 1;
    }
    extra_refs.shrinkRetainingCapacity(j);
}

fn handleTagsAndDuplicates(extras: []const NamedRef) void {
    var i = extras.len;
    while (i > 0) {
        i -= 1;
        const name0 = extras[i].name;
        const object = extras[i].obj;
        switch (object.typ) {
            .tag => handleTag(name0, object),
            .commit => {
                const name = if (anonymize) anonymizeRefname(name0) else name0;
                const commit = rewriteCommit(Commit.fromObj(object)) orelse {
                    outf("reset {s}\nfrom {s}\n\n", .{ name, null_hex });
                    continue;
                };
                const mark = getObjectMark(&commit.obj);
                if (mark == 0) {
                    if (!reference_excluded_commits) {
                        outf("reset {s}\nfrom {s}\n\n", .{ name, null_hex });
                        continue;
                    }
                    outf("reset {s}\nfrom {s}\n\n", .{ name, commit.hex() });
                    continue;
                }
                outf("reset {s}\nfrom :{d}\n\n", .{ name, mark });
                showProgress();
            },
            else => {},
        }
    }
}

fn exportMarks(file: []const u8) void {
    var b: util.Buf = .empty;
    for (deco_entries) |x| {
        if (x) |e| {
            if (e.is_commit) util.bufPrint(&b, ":{d} {s}\n", .{ e.mark, hash.hex(e.oid) });
        }
    }
    const fd = os.openFile(file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_CLOEXEC, 0o666);
    if (fd < 0) util.dieErrno("unable to open marks file {s} for writing.", .{file});
    os.writeAll(fd, b.items) catch util.err("unable to write marks file {s}.", .{file});
    os.close(fd);
}

fn importMarks(file: []const u8, check_exists: bool) void {
    if (check_exists and !os.exists(file)) return;
    const data = os.readFile(file) orelse util.dieErrno("could not open '{s}' for reading", .{file});
    var pos: usize = 0;
    while (pos < data.len) {
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n');
        const line = data[pos .. nl orelse data.len];
        pos = if (nl) |x| x + 1 else data.len;
        if (line.len == 0 or line[0] != ':' or nl == null) util.die("corrupt mark line: {s}", .{line});
        var i: usize = 1;
        var mark: u64 = 0;
        while (i < line.len and std.ascii.isDigit(line[i])) : (i += 1) mark = mark *% 10 +% (line[i] - '0');
        if (mark == 0 or i == 1 or i >= line.len or line[i] != ' ' or line.len < i + 41)
            util.die("corrupt mark line: {s}", .{line});
        const oid = hash.fromHex(line[i + 1 .. i + 41]) orelse util.die("corrupt mark line: {s}", .{line});
        const m32: u32 = @truncate(mark);
        if (last_idnum < m32) last_idnum = m32;
        const typ = cn.objType(oid) orelse util.die("object not found: {s}", .{hash.hex(oid)});
        if (typ != .commit) continue;
        const commit = cn.lookupCommit(oid) orelse util.die("not a commit? can't happen: {s}", .{hash.hex(oid)});
        if (commit.obj.flags & cn.SHOWN != 0) util.err("object {s} already has a mark", .{hash.hex(oid)});
        markObject(&commit.obj, m32);
        commit.obj.flags |= cn.SHOWN;
    }
}

fn handleDeletes() void {
    for (refspecs.items) |r| {
        if (r.src.len > 0) continue;
        outf("reset {s}\nfrom {s}\n\n", .{ r.dst, null_hex });
    }
}

// ------------------------------------------------------------------ options

fn parseSignMode(arg: []const u8) ?SignMode {
    if (util.eql(arg, "abort")) return .abort;
    if (util.eql(arg, "verbatim") or util.eql(arg, "ignore")) return .verbatim;
    if (util.eql(arg, "warn-verbatim") or util.eql(arg, "warn")) return .warn_verbatim;
    if (util.eql(arg, "warn-strip")) return .warn_strip;
    if (util.eql(arg, "strip")) return .strip;
    return null;
}

fn cbSignedTags(a: ?[]const u8, unset: bool) void {
    if (unset) return;
    signed_tag_mode = parseSignMode(a.?) orelse {
        util.err("unknown signed-tags mode: {s}", .{a.?});
        os.exit(129);
    };
}
fn cbSignedCommits(a: ?[]const u8, unset: bool) void {
    if (unset) return;
    signed_commit_mode = parseSignMode(a.?) orelse {
        util.err("unknown signed-commits mode: {s}", .{a.?});
        os.exit(129);
    };
}
fn cbTagOfFiltered(a: ?[]const u8, unset: bool) void {
    if (unset or util.eql(a.?, "abort")) {
        tag_of_filtered_mode = .abort;
    } else if (util.eql(a.?, "drop")) {
        tag_of_filtered_mode = .drop;
    } else if (util.eql(a.?, "rewrite")) {
        tag_of_filtered_mode = .rewrite;
    } else {
        util.err("unknown tag-of-filtered mode: {s}", .{a.?});
        os.exit(129);
    }
}
fn cbReencode(a: ?[]const u8, unset: bool) void {
    if (unset) {
        reencode_mode = .abort;
        return;
    }
    const v = a.?;
    if (std.ascii.eqlIgnoreCase(v, "abort")) {
        reencode_mode = .abort;
    } else if (parseMaybeBool(v)) |b| {
        reencode_mode = if (b) .yes else .no;
    } else {
        util.err("unknown reencoding mode: {s}", .{v});
        os.exit(129);
    }
}

fn parseMaybeBool(v: []const u8) ?bool {
    const t = [_][]const u8{ "true", "yes", "on", "1" };
    const f = [_][]const u8{ "false", "no", "off", "0", "" };
    for (t) |x| if (std.ascii.eqlIgnoreCase(v, x)) return true;
    for (f) |x| if (std.ascii.eqlIgnoreCase(v, x)) return false;
    return null;
}

const options = [_]po.Opt{
    po.integer(0, "progress", &progress, "n", "show progress after <n> objects"),
    po.callback(0, "signed-tags", cbSignedTags, "mode", "select handling of signed tags"),
    po.callback(0, "signed-commits", cbSignedCommits, "mode", "select handling of signed commits"),
    po.callback(0, "tag-of-filtered-object", cbTagOfFiltered, "mode", "select handling of tags that tag filtered objects"),
    po.callback(0, "reencode", cbReencode, "mode", "select handling of commit messages in an alternate encoding"),
    po.string(0, "export-marks", &export_filename, "file", "dump marks to this file"),
    po.string(0, "import-marks", &import_filename, "file", "import marks from this file"),
    po.string(0, "import-marks-if-exists", &import_filename_if_exists, "file", "import marks from this file if it exists"),
    po.boolean(0, "fake-missing-tagger", &fake_missing_tagger, "fake a tagger when tags lack one"),
    po.boolean(0, "full-tree", &full_tree, "output full tree for each commit"),
    po.boolean(0, "use-done-feature", &use_done_feature, "use the done feature to terminate the stream"),
    po.boolean(0, "no-data", &no_data, "skip output of blob data"),
    po.list(0, "refspec", &refspecs_list, "refspec", "apply refspec to exported refs"),
    po.boolean(0, "anonymize", &anonymize, "anonymize output"),
    .{ .long = "anonymize-map", .kind = .list, .l = &anonymize_map, .argh = "from:to", .help = "convert <from> to <to> in anonymized output", .noneg = true },
    po.boolean(0, "reference-excluded-parents", &reference_excluded_commits, "reference parents which are not in fast-export stream by object id"),
    po.boolean(0, "show-original-ids", &show_original_ids, "show original object ids of blobs/commits"),
    po.boolean(0, "mark-tags", &mark_tags, "label tags with mark ids"),
};

fn isDiffRenameOpt(a: []const u8) bool {
    if (util.startsWith(a, "-M") or util.startsWith(a, "-C")) return true;
    const longs = [_][]const u8{ "--find-renames", "--find-copies", "--find-copies-harder" };
    for (longs) |l| {
        if (util.eql(a, l) or (util.startsWith(a, l) and a.len > l.len and a[l.len] == '=')) return true;
    }
    return false;
}

pub fn cmdFastExport(args: []const []const u8) u8 {
    if (args.len == 1) po.usageWithOptions(&usage_str, &options);
    const rest = po.parse(args[1..], &options, &usage_str, .{ .keep_unknown = true, .keep_dashdash = true });

    for (anonymize_map.items) |m| addAnonymizeSeed(m);
    if (anonymize_map.items.len > 0 and !anonymize)
        util.die("the option '{s}' requires '{s}'", .{ "--anonymize-map", "--anonymize" });

    revs = revision.RevInfo.init(repo_mod.repo().prefix);
    revs.topo_order = true;
    revs.sources = &sources;
    revs.rewrite_parents = true;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "fast-export") catch util.oom();
    var after_dashdash = false;
    var rename_args: std.ArrayList([]const u8) = .empty;
    for (rest) |a| {
        if (util.eql(a, "--")) after_dashdash = true;
        if (!after_dashdash and isDiffRenameOpt(a)) {
            rename_args.append(gpa, a) catch util.oom();
            continue;
        }
        argv.append(gpa, a) catch util.oom();
    }
    const left = revision.setupRevisions(&revs, argv.items, .{});
    if (rename_args.items.len > 0) {
        const o = gpa.create(diff.DiffOptions) catch util.oom();
        o.* = diff.DiffOptions.initBasic();
        var k: usize = 0;
        while (k < rename_args.items.len) {
            const n = o.parseOpt(rename_args.items, k);
            k += if (n == 0) 1 else n;
        }
        o.flags.recursive = true;
        o.setupDone();
        if (o.detect_rename != 0) rename_opt = o;
    }
    if (left.len > 1) po.usageWithOptions(&usage_str, &options);

    for (refspecs_list.items) |r| refspecs.append(gpa, parseRefspec(r)) catch util.oom();

    if (use_done_feature) out("feature done\n");

    if (import_filename != null and import_filename_if_exists != null)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--import-marks", "--import-marks-if-exists" });
    if (import_filename) |f| {
        importMarks(f, false);
    } else if (import_filename_if_exists) |f| importMarks(f, true);
    const lastimportid = last_idnum;

    if (import_filename != null and !revs.prune_data.isEmpty()) full_tree = true;

    getTagsAndDuplicates();

    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    revs.reverse = true;
    while (revision.getRevision(&revs)) |commit| handleCommit(commit);

    handleTagsAndDuplicates(extra_refs.items);
    handleTagsAndDuplicates(tag_refs.items);
    handleDeletes();

    if (export_filename) |f| {
        if (lastimportid != last_idnum) exportMarks(f);
    }
    if (use_done_feature) out("done\n");
    util.flushStdout();
    return 0;
}
