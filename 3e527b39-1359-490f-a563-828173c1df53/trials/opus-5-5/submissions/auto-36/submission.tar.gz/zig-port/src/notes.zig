//! Port of notes.c and notes-utils.c: the in-memory 16-way notes trie,
//! loading/writing of notes trees (with git's fanout heuristics) and the
//! display integration used by log (format_display_notes).

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const revparse = @import("revparse.zig");
const objects = @import("objects.zig");
const commit_mod = @import("commit.zig");
const pretty = @import("pretty.zig");
const wildmatch = @import("wildmatch.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const DEFAULT_REF = "refs/notes/commits";
const KEY_INDEX = 19;
const RAWSZ = 20;

pub const CombineFn = *const fn (cur: *Oid, new: Oid) i32;

const Leaf = struct { key: Oid, val: Oid };

const Ptr = union(enum) {
    none,
    internal: *IntNode,
    note: *Leaf,
    subtree: *Leaf,
};

const IntNode = struct {
    a: [16]Ptr = @splat(.none),
};

const NonNote = struct { path: []const u8, mode: u32, oid: Oid };

pub const NotesTree = struct {
    root: *IntNode = undefined,
    non_notes: std.ArrayList(NonNote) = .empty,
    ref: []const u8 = "",
    update_ref: ?[]const u8 = null,
    combine: CombineFn = combineConcatenate,
    initialized: bool = false,
    dirty: bool = false,
};

pub var default_tree: NotesTree = .{};

fn nibble(n: usize, h: *const Oid) u4 {
    const shift: u3 = if (n & 1 == 0) 4 else 0;
    return @intCast((h[n >> 1] >> shift) & 0x0f);
}

fn subtreePrefixMatch(key: *const Oid, subtree_key: *const Oid) bool {
    const len = subtree_key[KEY_INDEX];
    return std.mem.eql(u8, key[0..len], subtree_key[0..len]);
}

fn newNode() *IntNode {
    const n = gpa.create(IntNode) catch util.oom();
    n.* = .{};
    return n;
}

fn newLeaf(key: Oid, val: Oid) *Leaf {
    const l = gpa.create(Leaf) catch util.oom();
    l.* = .{ .key = key, .val = val };
    return l;
}

/// note_tree_search
fn search(t: *NotesTree, tree: **IntNode, n: *usize, key: *const Oid) *Ptr {
    while (true) {
        const p0 = tree.*.a[0];
        if (p0 == .subtree) {
            const l = p0.subtree;
            if (subtreePrefixMatch(key, &l.key)) {
                tree.*.a[0] = .none;
                loadSubtree(t, l, tree.*, n.*);
                continue;
            }
        }
        const i = nibble(n.*, key);
        const p = tree.*.a[i];
        switch (p) {
            .internal => |node| {
                tree.* = node;
                n.* += 1;
                continue;
            },
            .subtree => |l| {
                if (subtreePrefixMatch(key, &l.key)) {
                    tree.*.a[i] = .none;
                    loadSubtree(t, l, tree.*, n.*);
                    continue;
                }
                return &tree.*.a[i];
            },
            else => return &tree.*.a[i],
        }
    }
}

fn find(t: *NotesTree, tree0: *IntNode, n0: usize, key: *const Oid) ?*Leaf {
    var tree = tree0;
    var n = n0;
    const p = search(t, &tree, &n, key);
    if (p.* == .note and hash.eql(p.note.key, key.*)) return p.note;
    return null;
}

/// note_tree_consolidate; returns true when consolidated
fn consolidate(tree: *IntNode, parent: *IntNode, index: u4) bool {
    var p: Ptr = .none;
    for (tree.a) |e| {
        if (e != .none) {
            if (p != .none) return false;
            p = e;
        }
    }
    if (p != .none and p != .note) return false;
    parent.a[index] = p;
    return true;
}

/// note_tree_remove; on success entry.val receives the removed value
fn treeRemove(t: *NotesTree, tree0: *IntNode, n0: usize, entry: *Leaf) void {
    var tree = tree0;
    var n = n0;
    const p = search(t, &tree, &n, &entry.key);
    if (p.* != .note) return;
    const l = p.note;
    if (!hash.eql(l.key, entry.key)) return;
    entry.val = l.val;
    p.* = .none;
    if (n == 0) return;
    var stack: [RAWSZ * 2 + 1]*IntNode = undefined;
    stack[0] = t.root;
    var i: usize = 0;
    while (i < n) : (i += 1) {
        const j = nibble(i, &entry.key);
        stack[i + 1] = stack[i].a[j].internal;
    }
    while (i > 0 and consolidate(stack[i], stack[i - 1], nibble(i - 1, &entry.key))) i -= 1;
}

const PtrType = enum { note, subtree };

/// note_tree_insert
fn treeInsert(t: *NotesTree, tree0: *IntNode, n0: usize, entry: *Leaf, typ: PtrType, combine: CombineFn) i32 {
    var tree = tree0;
    var n = n0;
    const p = search(t, &tree, &n, &entry.key);
    switch (p.*) {
        .none => {
            if (!hash.isZero(entry.val)) {
                p.* = if (typ == .note) .{ .note = entry } else .{ .subtree = entry };
            }
            return 0;
        },
        .note => |l| {
            switch (typ) {
                .note => {
                    if (hash.eql(l.key, entry.key)) {
                        if (hash.eql(l.val, entry.val)) return 0;
                        const ret = combine(&l.val, entry.val);
                        if (ret == 0 and hash.isZero(l.val)) treeRemove(t, tree, n, entry);
                        return ret;
                    }
                },
                .subtree => {
                    if (subtreePrefixMatch(&l.key, &entry.key)) {
                        loadSubtree(t, entry, tree, n);
                        return 0;
                    }
                },
            }
        },
        .subtree => |l| {
            if (subtreePrefixMatch(&entry.key, &l.key)) {
                p.* = .none;
                loadSubtree(t, l, tree, n);
                return treeInsert(t, tree, n, entry, typ, combine);
            }
        },
        .internal => unreachable,
    }
    if (hash.isZero(entry.val)) return 0;
    const node = newNode();
    const old = p.*;
    const old_leaf = switch (old) {
        .note => |l| l,
        .subtree => |l| l,
        else => unreachable,
    };
    const ret = treeInsert(t, node, n + 1, old_leaf, if (old == .note) .note else .subtree, combine);
    if (ret != 0) return ret;
    p.* = .{ .internal = node };
    return treeInsert(t, node, n + 1, entry, typ, combine);
}

/// add_non_note: keep sorted by path; overwrite on equal path
fn addNonNote(t: *NotesTree, path: []const u8, mode: u32, oid: Oid) void {
    const items = t.non_notes.items;
    var lo: usize = 0;
    var hi: usize = items.len;
    while (lo < hi) {
        const mid = (lo + hi) / 2;
        switch (std.mem.order(u8, items[mid].path, path)) {
            .lt => lo = mid + 1,
            .gt => hi = mid,
            .eq => {
                items[mid].mode = mode;
                items[mid].oid = oid;
                return;
            },
        }
    }
    t.non_notes.insert(gpa, lo, .{ .path = path, .mode = mode, .oid = oid }) catch util.oom();
}

fn hexToBytes(out: []u8, s: []const u8) bool {
    if (s.len != out.len * 2) return false;
    for (out, 0..) |*b, i| {
        const hi = std.fmt.charToDigit(s[2 * i], 16) catch return false;
        const lo = std.fmt.charToDigit(s[2 * i + 1], 16) catch return false;
        b.* = @intCast(hi * 16 + lo);
    }
    return true;
}

fn loadSubtree(t: *NotesTree, subtree: *Leaf, node: *IntNode, n: usize) void {
    const obj = repo_mod.repo().odb().read(subtree.val) orelse
        util.die("Could not read {s} for notes-index", .{hash.hex(subtree.val)});
    if (obj.typ != .tree) util.die("Could not read {s} for notes-index", .{hash.hex(subtree.val)});
    const prefix_len: usize = subtree.key[KEY_INDEX];
    var object_oid: Oid = hash.zero;
    @memcpy(object_oid[0..prefix_len], subtree.key[0..prefix_len]);
    var it = objects.TreeIter{ .data = obj.data };
    while (it.next()) |entry| {
        var typ: PtrType = .note;
        var ok = false;
        if (entry.name.len == 2 * (RAWSZ - prefix_len)) {
            if (entry.mode & 0o170000 == 0o100000 and hexToBytes(object_oid[prefix_len..], entry.name)) {
                typ = .note;
                ok = true;
            }
        } else if (entry.name.len == 2) {
            if (entry.mode & 0o170000 == 0o040000 and hexToBytes(object_oid[prefix_len .. prefix_len + 1], entry.name)) {
                const len = prefix_len + 1;
                @memset(object_oid[len..KEY_INDEX], 0);
                object_oid[KEY_INDEX] = @intCast(len);
                typ = .subtree;
                ok = true;
            }
        }
        if (ok) {
            const l = newLeaf(object_oid, entry.oid);
            if (treeInsert(t, node, n, l, typ, combineConcatenate) != 0)
                util.die("Failed to load {s} {s} into notes tree from {s}", .{ if (typ == .note) "note" else "subtree", hash.hex(object_oid), t.ref });
            continue;
        }
        // non-note
        var b: util.Buf = .empty;
        const q = hash.hex(subtree.key);
        for (0..prefix_len) |i| {
            util.bufAppend(&b, q[2 * i .. 2 * i + 2]);
            util.bufByte(&b, '/');
        }
        util.bufAppend(&b, entry.name);
        addNonNote(t, b.items, entry.mode, entry.oid);
    }
}

fn determineFanout(tree: *IntNode, n: usize, fanout: usize) usize {
    if (n % 2 != 0 or n > 2 * fanout) return fanout;
    for (tree.a) |p| {
        switch (p) {
            .subtree, .internal => continue,
            else => return fanout,
        }
    }
    return fanout + 1;
}

fn pathWithFanout(h: Oid, fanout: usize, b: *util.Buf) void {
    b.clearRetainingCapacity();
    const x = hash.hex(h);
    var j: usize = 0;
    var f = fanout;
    while (f > 0) : (f -= 1) {
        util.bufAppend(b, x[j .. j + 2]);
        util.bufByte(b, '/');
        j += 2;
    }
    util.bufAppend(b, x[j..]);
}

pub const FOR_EACH_NOTE_DONT_UNPACK_SUBTREES: u32 = 1;
pub const FOR_EACH_NOTE_YIELD_SUBTREES: u32 = 2;

pub const EachFn = *const fn (ctx: *anyopaque, object: Oid, note: Oid, path: []const u8) i32;

fn forEachHelper(t: *NotesTree, tree: *IntNode, n: usize, fanout0: usize, flags: u32, f: EachFn, ctx: *anyopaque) i32 {
    const fanout = determineFanout(tree, n, fanout0);
    var path: util.Buf = .empty;
    var i: usize = 0;
    while (i < 16) : (i += 1) {
        var ret: i32 = 0;
        redo: while (true) {
            const p = tree.a[i];
            switch (p) {
                .internal => |node| ret = forEachHelper(t, node, n + 1, fanout, flags, f, ctx),
                .subtree => |l| {
                    if (n < 2 * fanout and flags & FOR_EACH_NOTE_YIELD_SUBTREES != 0) {
                        const path_len = @as(usize, l.key[KEY_INDEX]) * 2 + fanout;
                        pathWithFanout(l.key, fanout, &path);
                        path.items.len = path_len;
                        if (path.items[path_len - 1] != '/') util.bufByte(&path, '/');
                        ret = f(ctx, l.key, l.val, path.items);
                    }
                    if (n >= 2 * fanout or flags & FOR_EACH_NOTE_DONT_UNPACK_SUBTREES == 0) {
                        tree.a[i] = .none;
                        loadSubtree(t, l, tree, n);
                        continue :redo;
                    }
                },
                .note => |l| {
                    pathWithFanout(l.key, fanout, &path);
                    ret = f(ctx, l.key, l.val, path.items);
                },
                .none => {},
            }
            break;
        }
        if (ret != 0) return ret;
    }
    return 0;
}

pub fn forEachNote(t: *NotesTree, flags: u32, f: EachFn, ctx: *anyopaque) i32 {
    std.debug.assert(t.initialized);
    return forEachHelper(t, t.root, 0, 0, flags, f, ctx);
}

// ---------------- writing ----------------

const WriteStack = struct {
    next: ?*WriteStack = null,
    buf: util.Buf = .empty,
    path: [2]u8 = .{ 0, 0 },
};

fn matchesStack(tws: *WriteStack, full: []const u8) bool {
    return full.len >= 3 and full[0] == tws.path[0] and full[1] == tws.path[1] and full[2] == '/';
}

fn writeTreeEntry(b: *util.Buf, mode: u32, path: []const u8, h: Oid) void {
    util.bufPrint(b, "{o} {s}\x00", .{ mode, path });
    util.bufAppend(b, &h);
}

fn stackInitSubtree(tws: *WriteStack, path: []const u8) void {
    const n = gpa.create(WriteStack) catch util.oom();
    n.* = .{};
    tws.next = n;
    tws.path = .{ path[0], path[1] };
}

fn stackFinishSubtree(tws: *WriteStack) void {
    if (tws.next) |n| {
        stackFinishSubtree(n);
        const s = repo_mod.repo().odb().write(.tree, n.buf.items);
        tws.next = null;
        writeTreeEntry(&tws.buf, 0o40000, &tws.path, s);
        tws.path = .{ 0, 0 };
    }
}

fn writeEachNoteHelper(root: *WriteStack, path: []const u8, mode: u32, oid: Oid) void {
    var tws = root;
    var n: usize = 0;
    while (3 * n < path.len and matchesStack(tws, path[3 * n ..])) {
        n += 1;
        tws = tws.next.?;
    }
    stackFinishSubtree(tws);
    while (3 * n + 2 < path.len and path[3 * n + 2] == '/') {
        stackInitSubtree(tws, path[3 * n ..]);
        n += 1;
        tws = tws.next.?;
    }
    writeTreeEntry(&tws.buf, mode, path[3 * n ..], oid);
}

const WriteData = struct {
    root: *WriteStack,
    nn: []const NonNote,
    nn_pos: usize = 0,
};

fn writeNonNotesUntil(d: *WriteData, note_path: ?[]const u8) void {
    while (d.nn_pos < d.nn.len) {
        const nn = d.nn[d.nn_pos];
        var cmp: std.math.Order = .lt;
        if (note_path) |np| {
            cmp = std.mem.order(u8, nn.path, np);
            if (cmp == .gt) break;
        }
        if (cmp != .eq) writeEachNoteHelper(d.root, nn.path, nn.mode, nn.oid);
        d.nn_pos += 1;
    }
}

fn writeEachNote(ctx: *anyopaque, _: Oid, note: Oid, path0: []const u8) i32 {
    const d: *WriteData = @ptrCast(@alignCast(ctx));
    var path = path0;
    var mode: u32 = 0o100644;
    if (path[path.len - 1] == '/') {
        path = path[0 .. path.len - 1];
        mode = 0o40000;
    }
    const p = util.dupe(path);
    writeNonNotesUntil(d, p);
    writeEachNoteHelper(d.root, p, mode, note);
    return 0;
}

/// write_notes_tree
pub fn writeNotesTree(t: *NotesTree) Oid {
    std.debug.assert(t.initialized);
    var root = WriteStack{};
    var d = WriteData{ .root = &root, .nn = t.non_notes.items };
    _ = forEachNote(t, FOR_EACH_NOTE_DONT_UNPACK_SUBTREES | FOR_EACH_NOTE_YIELD_SUBTREES, writeEachNote, &d);
    writeNonNotesUntil(&d, null);
    stackFinishSubtree(&root);
    return repo_mod.repo().odb().write(.tree, root.buf.items);
}

// ---------------- combine functions ----------------

fn readBlob(oid: Oid) ?[]const u8 {
    const obj = repo_mod.repo().odb().read(oid) orelse return null;
    if (obj.typ != .blob) return null;
    return obj.data;
}

pub fn combineConcatenate(cur: *Oid, new: Oid) i32 {
    const new_msg = (if (!hash.isZero(new)) readBlob(new) else null) orelse return 0;
    if (new_msg.len == 0) return 0;
    const cur_msg = (if (!hash.isZero(cur.*)) readBlob(cur.*) else null) orelse {
        cur.* = new;
        return 0;
    };
    if (cur_msg.len == 0) {
        cur.* = new;
        return 0;
    }
    var cl = cur_msg.len;
    if (cur_msg[cl - 1] == '\n') cl -= 1;
    const buf = util.concat(&.{ cur_msg[0..cl], "\n\n", new_msg });
    cur.* = repo_mod.repo().odb().write(.blob, buf);
    return 0;
}

pub fn combineOverwrite(cur: *Oid, new: Oid) i32 {
    cur.* = new;
    return 0;
}

pub fn combineIgnore(_: *Oid, _: Oid) i32 {
    return 0;
}

fn addNoteLines(list: *std.ArrayList([]const u8), oid: Oid) bool {
    if (hash.isZero(oid)) return true;
    const obj = repo_mod.repo().odb().read(oid) orelse return false;
    if (obj.typ != .blob) return false;
    if (obj.data.len == 0) return true;
    var it = std.mem.splitScalar(u8, obj.data, '\n');
    while (it.next()) |l| list.append(gpa, l) catch util.oom();
    return true;
}

pub fn combineCatSortUniq(cur: *Oid, new: Oid) i32 {
    var list: std.ArrayList([]const u8) = .empty;
    if (!addNoteLines(&list, cur.*)) return 1;
    if (!addNoteLines(&list, new)) return 1;
    var filtered: std.ArrayList([]const u8) = .empty;
    for (list.items) |l| if (l.len > 0) filtered.append(gpa, l) catch util.oom();
    std.mem.sort([]const u8, filtered.items, {}, util.strLess);
    var b: util.Buf = .empty;
    var prev: ?[]const u8 = null;
    for (filtered.items) |l| {
        if (prev) |p| if (util.eql(p, l)) continue;
        prev = l;
        util.bufAppend(&b, l);
        util.bufByte(&b, '\n');
    }
    cur.* = repo_mod.repo().odb().write(.blob, b.items);
    return 0;
}

pub fn parseCombineFn(v: []const u8) ?CombineFn {
    if (std.ascii.eqlIgnoreCase(v, "overwrite")) return combineOverwrite;
    if (std.ascii.eqlIgnoreCase(v, "ignore")) return combineIgnore;
    if (std.ascii.eqlIgnoreCase(v, "concatenate")) return combineConcatenate;
    if (std.ascii.eqlIgnoreCase(v, "cat_sort_uniq")) return combineCatSortUniq;
    return null;
}

// ---------------- refs ----------------

pub fn defaultNotesRef() []const u8 {
    if (os.getenv("GIT_NOTES_REF")) |e| return util.dupe(e);
    if (repo_mod.cfg.get("core.notesref")) |v| return v;
    return DEFAULT_REF;
}

pub fn expandNotesRef(s: []const u8) []const u8 {
    if (util.startsWith(s, "refs/notes/")) return s;
    if (util.startsWith(s, "notes/")) return util.concat(&.{ "refs/", s });
    return util.concat(&.{ "refs/notes/", s });
}

pub fn expandLooseNotesRef(s: []const u8) []const u8 {
    if (revparse.getOid(s) == null) return expandNotesRef(s);
    return s;
}

pub const INIT_EMPTY: u32 = 1;
pub const INIT_WRITABLE: u32 = 2;

/// init_notes
pub fn initNotes(t: *NotesTree, notes_ref0: ?[]const u8, combine: ?CombineFn, flags: u32) void {
    const notes_ref = notes_ref0 orelse defaultNotesRef();
    t.* = .{
        .root = newNode(),
        .ref = notes_ref,
        .update_ref = if (flags & INIT_WRITABLE != 0) notes_ref else null,
        .combine = combine orelse combineConcatenate,
        .initialized = true,
    };
    if (flags & INIT_EMPTY != 0) return;
    const r = revparse.resolve(notes_ref, .{ .want = .treeish }) orelse return;
    var object_oid = r.oid;
    if (flags & INIT_WRITABLE != 0) {
        object_oid = refs.readOid(notes_ref) orelse util.die("Cannot use notes ref {s}", .{notes_ref});
    }
    const tree = objects.peelTo(object_oid, .tree) orelse
        util.die("Failed to read notes tree referenced by {s} ({s})", .{ notes_ref, hash.hex(object_oid) });
    var root_leaf = Leaf{ .key = hash.zero, .val = tree };
    loadSubtree(t, &root_leaf, t.root, 0);
}

pub fn addNote(t: *NotesTree, object: Oid, note: Oid, combine: ?CombineFn) i32 {
    std.debug.assert(t.initialized);
    t.dirty = true;
    const l = newLeaf(object, note);
    return treeInsert(t, t.root, 0, l, .note, combine orelse t.combine);
}

/// remove_note: returns true if no note was removed
pub fn removeNote(t: *NotesTree, object: Oid) bool {
    std.debug.assert(t.initialized);
    var l = Leaf{ .key = object, .val = hash.zero };
    treeRemove(t, t.root, 0, &l);
    if (hash.isZero(l.val)) return true;
    t.dirty = true;
    return false;
}

pub fn getNote(t: *NotesTree, object: Oid) ?Oid {
    std.debug.assert(t.initialized);
    const l = find(t, t.root, 0, &object) orelse return null;
    return l.val;
}

/// copy_note: returns non-zero on failure (existing note without force)
pub fn copyNote(t: *NotesTree, from: Oid, to: Oid, force: bool, combine: ?CombineFn) i32 {
    const note = getNote(t, from);
    const existing = getNote(t, to);
    if (!force and existing != null) return 1;
    if (note) |n| return addNote(t, to, n, combine);
    if (existing != null) return addNote(t, to, hash.zero, combine);
    return 0;
}

pub const PRUNE_VERBOSE: u32 = 1;
pub const PRUNE_DRYRUN: u32 = 2;

fn pruneCollect(ctx: *anyopaque, object: Oid, _: Oid, _: []const u8) i32 {
    const l: *std.ArrayList(Oid) = @ptrCast(@alignCast(ctx));
    if (repo_mod.repo().odb().has(object)) return 0;
    l.append(gpa, object) catch util.oom();
    return 0;
}

pub fn pruneNotes(t: *NotesTree, flags: u32) void {
    var l: std.ArrayList(Oid) = .empty;
    _ = forEachNote(t, 0, pruneCollect, &l);
    // C builds a LIFO list
    var i = l.items.len;
    while (i > 0) {
        i -= 1;
        const o = l.items[i];
        if (flags & PRUNE_VERBOSE != 0) util.outf("{s}\n", .{hash.hex(o)});
        if (flags & PRUNE_DRYRUN == 0) _ = removeNote(t, o);
    }
}

/// create_notes_commit
pub fn createNotesCommit(t: *NotesTree, parents: ?[]const Oid, msg: []const u8) Oid {
    const tree = writeNotesTree(t);
    var plist: std.ArrayList(Oid) = .empty;
    if (parents) |ps| {
        plist.appendSlice(gpa, ps) catch util.oom();
    } else if (refs.readOid(t.ref)) |p| {
        if (objects.readCommit(p) == null) util.die("Failed to find/parse commit {s}", .{t.ref});
        plist.append(gpa, p) catch util.oom();
    }
    return commit_mod.create(.{ .tree = tree, .parents = plist.items, .message = msg });
}

/// commit_notes
pub fn commitNotes(t: *NotesTree, msg: []const u8) void {
    if (!t.initialized or t.update_ref == null or t.update_ref.?.len == 0)
        util.die("Cannot commit uninitialized/unreferenced notes tree", .{});
    if (!t.dirty) return;
    var b: util.Buf = .empty;
    util.bufAppend(&b, msg);
    if (b.items.len > 0 and b.items[b.items.len - 1] != '\n') util.bufByte(&b, '\n');
    const c = createNotesCommit(t, null, b.items);
    const reflog = util.concat(&.{ "notes: ", b.items });
    refs.updateOrDie(reflog, t.update_ref.?, c, null, 0);
}

// ---------------- display ----------------

fn hasGlobSpecials(s: []const u8) bool {
    return std.mem.indexOfAny(u8, s, "?*[\\") != null;
}

fn listHas(l: *const std.ArrayList([]const u8), s: []const u8) bool {
    for (l.items) |x| if (util.eql(x, s)) return true;
    return false;
}

/// string_list_add_refs_by_glob
pub fn addRefsByGlob(list: *std.ArrayList([]const u8), glob: []const u8) void {
    if (hasGlobSpecials(glob)) {
        const pat = if (util.startsWith(glob, "refs/")) glob else util.concat(&.{ "refs/", glob });
        for (refs.iterate("refs/", .{ .check_objects = false })) |r| {
            if (wildmatch.match(pat, r.name, 0)) {
                if (!listHas(list, r.name)) list.append(gpa, r.name) catch util.oom();
            }
        }
    } else {
        if (revparse.getOid(glob) == null) util.warn("notes ref {s} is invalid", .{glob});
        if (!listHas(list, glob)) list.append(gpa, glob) catch util.oom();
    }
}

pub fn addRefsFromColonSep(list: *std.ArrayList([]const u8), globs: []const u8) void {
    var it = std.mem.splitScalar(u8, globs, ':');
    while (it.next()) |g| {
        if (g.len == 0) continue;
        addRefsByGlob(list, g);
    }
}

pub fn loadNotesTrees(names: []const []const u8, flags: u32, combine: CombineFn) []*NotesTree {
    var out: std.ArrayList(*NotesTree) = .empty;
    for (names) |n| {
        const t = gpa.create(NotesTree) catch util.oom();
        initNotes(t, n, combine, flags);
        out.append(gpa, t) catch util.oom();
    }
    return out.items;
}

var display_trees: ?[]*NotesTree = null;

/// load_display_notes; use_default as in display_notes_opt.use_default_notes
pub fn loadDisplayNotes(use_default: i32, extra_refs: []const []const u8) void {
    if (display_trees != null) return;
    var list: std.ArrayList([]const u8) = .empty;
    var load_config_refs = false;
    if (use_default > 0 or (use_default == -1 and extra_refs.len == 0)) {
        list.append(gpa, defaultNotesRef()) catch util.oom();
        if (os.getenv("GIT_NOTES_DISPLAY_REF")) |e| {
            addRefsFromColonSep(&list, e);
        } else load_config_refs = true;
    }
    if (load_config_refs) {
        for (repo_mod.cfg.getAll("notes.displayref")) |v| addRefsByGlob(&list, v);
    }
    for (extra_refs) |r| addRefsByGlob(&list, expandNotesRef(r));
    display_trees = loadNotesTrees(list.items, 0, combineIgnore);
}

/// format_note
pub fn formatNote(t: *NotesTree, object: Oid, sb: *util.Buf, output_encoding: []const u8, raw: bool) void {
    if (!t.initialized) initNotes(t, null, null, 0);
    const note = getNote(t, object) orelse return;
    const obj = repo_mod.repo().odb().read(note) orelse return;
    if (obj.typ != .blob) return;
    var msg: []const u8 = obj.data;
    if (output_encoding.len > 0 and !pretty.isEncodingUtf8(output_encoding)) {
        if (pretty.reencodeString(msg, output_encoding, "utf-8")) |r| msg = r;
    }
    if (msg.len > 0 and msg[msg.len - 1] == '\n') msg = msg[0 .. msg.len - 1];
    if (!raw) {
        var ref = t.ref;
        if (ref.len == 0 or util.eql(ref, DEFAULT_REF)) {
            util.bufAppend(sb, "\nNotes:\n");
        } else {
            ref = util.skipPrefix(ref, "refs/") orelse ref;
            ref = util.skipPrefix(ref, "notes/") orelse ref;
            util.bufPrint(sb, "\nNotes ({s}):\n", .{ref});
        }
    }
    var p: usize = 0;
    while (p < msg.len) {
        const e = std.mem.indexOfScalarPos(u8, msg, p, '\n') orelse msg.len;
        if (!raw) util.bufAppend(sb, "    ");
        util.bufAppend(sb, msg[p..e]);
        util.bufByte(sb, '\n');
        p = e + 1;
    }
}

pub fn formatDisplayNotes(object: Oid, sb: *util.Buf, output_encoding: []const u8, raw: bool) void {
    if (display_trees == null) loadDisplayNotes(-1, &.{});
    for (display_trees.?) |t| formatNote(t, object, sb, output_encoding, raw);
}

// ---------------- hooks ----------------

const logtree = @import("logtree.zig");
const revision = @import("revision.zig");

fn loadHook(revs: *revision.RevInfo) void {
    loadDisplayNotes(revs.notes_use_default, revs.notes_refs.items);
}

fn displayHook(oid: Oid, sb: *util.Buf, encoding: []const u8, raw: bool) void {
    formatDisplayNotes(oid, sb, encoding, raw);
}

pub fn installHooks() void {
    logtree.display_notes_hook = displayHook;
    logtree.load_display_notes_hook = loadHook;
}
