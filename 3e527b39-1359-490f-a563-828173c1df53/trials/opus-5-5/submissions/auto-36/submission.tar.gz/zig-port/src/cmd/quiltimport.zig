//! git quiltimport (port of git-quiltimport.sh)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const gpa = util.gpa;

const options_spec =
    \\git quiltimport [options]
    \\--
    \\n,dry-run     dry run
    \\author=       author name and email address for patches without any
    \\patches=      path to the quilt patches
    \\series=       path to the quilt series file
    \\keep-non-patch Pass -b to git mailinfo
    \\
;

fn gitArgv(args: []const []const u8) []const []const u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return argv.items;
}

fn stripNl(s: []const u8) []const u8 {
    var r = s;
    while (r.len > 0 and r[r.len - 1] == '\n') r = r[0 .. r.len - 1];
    return r;
}

fn shDie(comptime f: []const u8, a: anytype) noreturn {
    util.flushStdout();
    util.eprint(f ++ "\n", a);
    os.exit(1);
}

fn isWs(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n';
}

/// Parse `git rev-parse --sq`-style quoted words.
pub fn parseSq(s: []const u8) [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    var cur: util.Buf = .empty;
    var in_word = false;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        const ch = s[i];
        if (ch == '\'') {
            in_word = true;
            i += 1;
            while (i < s.len and s[i] != '\'') : (i += 1) util.bufByte(&cur, s[i]);
        } else if (ch == '\\' and i + 1 < s.len) {
            in_word = true;
            i += 1;
            util.bufByte(&cur, s[i]);
        } else if (isWs(ch)) {
            if (in_word) {
                l.append(gpa, cur.items) catch util.oom();
                cur = .empty;
                in_word = false;
            }
        } else {
            in_word = true;
            util.bufByte(&cur, ch);
        }
    }
    if (in_word) l.append(gpa, cur.items) catch util.oom();
    return l.items;
}

/// Run the arguments through `git rev-parse --parseopt` like git-sh-setup.
/// Returns the normalized argument list (after "set --").
pub fn shParseopt(spec: []const u8, args: []const []const u8, keep_dashdash: bool, stuck_long: bool) [][]const u8 {
    var a: std.ArrayList([]const u8) = .empty;
    a.appendSlice(gpa, &.{ "rev-parse", "--parseopt" }) catch util.oom();
    if (keep_dashdash) a.append(gpa, "--keep-dashdash") catch util.oom();
    if (stuck_long) a.append(gpa, "--stuck-long") catch util.oom();
    a.append(gpa, "--") catch util.oom();
    a.appendSlice(gpa, args) catch util.oom();
    const r = os.run(gitArgv(a.items), .{ .capture_stdout = true, .stdin_data = spec });
    var out: []const u8 = r.stdout;
    if (r.status == 0 and util.startsWith(out, "set --")) {
        out = stripNl(out["set --".len..]);
        return parseSq(out);
    }
    // a shell snippet showing usage (and exiting)
    var script = out;
    if (r.status != 0) script = util.fmt("{s}\nexit {d}", .{ out, r.status });
    const s = os.run(&.{ "/bin/sh", "-c", script }, .{});
    os.exit(s.status);
}

/// expr "z$s" : 'z\(.*[^ ]\) *<.*'  and  expr "z$s" : '.*<\([^>]*\)'
fn splitAuthor(s: []const u8) ?[2][]const u8 {
    const lt = std.mem.lastIndexOfScalar(u8, s, '<') orelse return null;
    const name = std.mem.trimEnd(u8, s[0..lt], " ");
    if (name.len == 0) return null;
    const rest = s[lt + 1 ..];
    const email = rest[0 .. std.mem.indexOfScalar(u8, rest, '>') orelse rest.len];
    if (email.len == 0) return null;
    return .{ name, email };
}

/// sed -ne 's/<key>//p' file
fn sedField(info: []const u8, key: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var it = std.mem.splitScalar(u8, info, '\n');
    var first = true;
    while (it.next()) |line| {
        if (it.index == null and line.len == 0) break;
        const i = std.mem.indexOf(u8, line, key) orelse continue;
        if (!first) util.bufByte(&b, '\n');
        first = false;
        util.bufAppend(&b, line[0..i]);
        util.bufAppend(&b, line[i + key.len ..]);
    }
    return b.items;
}

fn readStdinLine() ?[]const u8 {
    var b: util.Buf = .empty;
    while (true) {
        var ch: [1]u8 = undefined;
        const n = std.c.read(0, &ch, 1);
        if (n <= 0) {
            if (b.items.len == 0) return null;
            break;
        }
        if (ch[0] == '\n') break;
        util.bufByte(&b, ch[0]);
    }
    return std.mem.trim(u8, b.items, " \t");
}

pub fn cmdQuiltimport(args: []const []const u8) u8 {
    const argv = shParseopt(options_spec, args[1..], false, false);

    // git_dir_init
    const gd = os.run(gitArgv(&.{ "rev-parse", "--git-dir" }), .{ .capture_stdout = true });
    if (gd.status != 0) os.exit(gd.status);
    const cdup = os.run(gitArgv(&.{ "rev-parse", "--show-cdup" }), .{ .capture_stdout = true });
    if (stripNl(cdup.stdout).len > 0) {
        util.eprint("You need to run this command from the toplevel of the working tree.\n", .{});
        os.exit(1);
    }
    const cwd = os.getcwd();
    const gdo = stripNl(gd.stdout);
    const git_dir = if (gdo.len > 0 and gdo[0] == '/') gdo else (util.normalizePath(util.joinPath(cwd, gdo)) orelse gdo);

    var dry_run = false;
    var quilt_author: []const u8 = "";
    var quilt_patches: []const u8 = os.getenv("QUILT_PATCHES") orelse "";
    var quilt_series: []const u8 = os.getenv("QUILT_SERIES") orelse "";
    var mailinfo_opt: ?[]const u8 = null;
    {
        var i: usize = 0;
        while (i < argv.len) : (i += 1) {
            const a = argv[i];
            if (util.eql(a, "--author")) {
                i += 1;
                quilt_author = if (i < argv.len) argv[i] else "";
            } else if (util.eql(a, "-n") or util.eql(a, "--dry-run")) {
                dry_run = true;
            } else if (util.eql(a, "--patches")) {
                i += 1;
                quilt_patches = if (i < argv.len) argv[i] else "";
            } else if (util.eql(a, "--series")) {
                i += 1;
                quilt_series = if (i < argv.len) argv[i] else "";
            } else if (util.eql(a, "--keep-non-patch")) {
                mailinfo_opt = "-b";
            } else if (util.eql(a, "--")) {
                break;
            } else {
                // usage: "$0" -h; exit 1
                const r = os.run(gitArgv(&.{ "quiltimport", "-h" }), .{});
                _ = r;
                os.exit(1);
            }
        }
    }

    var qa_name: []const u8 = "";
    var qa_email: []const u8 = "";
    if (quilt_author.len > 0) {
        const p = splitAuthor(quilt_author) orelse shDie("malformed --author parameter", .{});
        qa_name = p[0];
        qa_email = p[1];
    }

    if (quilt_patches.len == 0) quilt_patches = "patches";
    if (!os.isDir(quilt_patches)) {
        util.outf("The \"{s}\" directory does not exist.\n", .{quilt_patches});
        return 1;
    }
    if (quilt_series.len == 0) quilt_series = util.concat(&.{ quilt_patches, "/series" });
    if (!os.exists(quilt_series)) {
        util.outf("The \"{s}\" file does not exist.\n", .{quilt_series});
        return 1;
    }

    const tmp_dir = util.concat(&.{ git_dir, "/rebase-apply" });
    const tmp_msg = util.concat(&.{ tmp_dir, "/msg" });
    const tmp_patch = util.concat(&.{ tmp_dir, "/patch" });
    const tmp_info = util.concat(&.{ tmp_dir, "/info" });

    const head = os.run(gitArgv(&.{ "rev-parse", "HEAD" }), .{ .capture_stdout = true });
    var commit: []const u8 = stripNl(head.stdout);

    const series = os.readFile(quilt_series) orelse "";
    if (!os.mkdir(tmp_dir, 0o777)) {
        util.flushStdout();
        util.eprint("mkdir: cannot create directory '{s}': {s}\n", .{ tmp_dir, os.lastErr() });
        return 2;
    }

    var it = std.mem.splitScalar(u8, series, '\n');
    while (it.next()) |line0| {
        if (it.index == null and line0.len == 0) break;
        // read patch_name level garbage
        var fields: [3][]const u8 = .{ "", "", "" };
        {
            var t = std.mem.trim(u8, line0, " \t");
            var k: usize = 0;
            while (k < 2 and t.len > 0) : (k += 1) {
                const e = std.mem.indexOfAny(u8, t, " \t") orelse t.len;
                fields[k] = t[0..e];
                t = std.mem.trimStart(u8, t[e..], " \t");
            }
            fields[2] = t;
        }
        const patch_name = fields[0];
        var level = fields[1];
        const garbage = fields[2];
        if (patch_name.len == 0 or patch_name[0] == '#') continue;
        if (util.startsWith(level, "-p")) {} else if (level.len == 0 or level[0] == '#') {
            level = "";
        } else {
            util.out("unable to parse patch level, ignoring it.\n");
            level = "";
        }
        if (!(garbage.len == 0 or garbage[0] == '#')) {
            util.outf("trailing garbage found in series file: {s}\n", .{garbage});
            return 1;
        }
        const patch_path = util.concat(&.{ quilt_patches, "/", patch_name });
        if (!os.isFile(patch_path)) {
            util.outf("{s} doesn't exist. Skipping.\n", .{patch_name});
            continue;
        }
        util.outf("{s}\n", .{patch_name});
        const pdata = os.readFile(patch_path) orelse "";
        var mi: std.ArrayList([]const u8) = .empty;
        mi.append(gpa, "mailinfo") catch util.oom();
        if (mailinfo_opt) |o| mi.append(gpa, o) catch util.oom();
        mi.appendSlice(gpa, &.{ tmp_msg, tmp_patch }) catch util.oom();
        const mr = os.run(gitArgv(mi.items), .{ .capture_stdout = true, .stdin_data = pdata });
        os.writeFile(tmp_info, mr.stdout, 0o666) catch {};
        if (mr.status != 0) return 3;
        const pst = os.statPath(tmp_patch);
        if (pst == null or pst.?.size == 0) {
            util.out("Patch is empty.  Was it split wrong?\n");
            return 1;
        }
        const info = mr.stdout;
        var a_name = stripNl(sedField(info, "Author: "));
        var a_email = stripNl(sedField(info, "Email: "));
        while (a_email.len == 0 and a_name.len == 0) {
            if (quilt_author.len > 0) {
                a_name = qa_name;
                a_email = qa_email;
            } else if (dry_run) {
                util.flushStdout();
                util.eprint("No author found in {s}\n", .{patch_name});
                a_name = "dry-run-not-found";
                a_email = "dry-run-not-found";
            } else {
                util.flushStdout();
                util.eprint("No author found in {s}\n", .{patch_name});
                util.out("---\n");
                util.out(os.readFile(tmp_msg) orelse "");
                util.out("Author: ");
                util.flushStdout();
                const pa = readStdinLine() orelse return 1;
                util.outf("{s}\n", .{pa});
                if (splitAuthor(pa)) |p| {
                    a_name = p[0];
                    a_email = p[1];
                }
            }
        }
        const a_date = stripNl(sedField(info, "Date: "));
        var subject = stripNl(sedField(info, "Subject: "));
        if (subject.len == 0) {
            subject = patch_name;
            if (subject.len >= 6 and util.eql(subject[subject.len - 5 ..], "patch")) subject = subject[0 .. subject.len - 6];
        }

        if (!dry_run) {
            const env = [_][2][]const u8{
                .{ "GIT_AUTHOR_NAME", a_name },
                .{ "GIT_AUTHOR_EMAIL", a_email },
                .{ "GIT_AUTHOR_DATE", a_date },
                .{ "SUBJECT", subject },
            };
            var ap: std.ArrayList([]const u8) = .empty;
            ap.appendSlice(gpa, &.{ "apply", "--index", "-C1" }) catch util.oom();
            if (level.len > 0) ap.append(gpa, level) catch util.oom();
            ap.append(gpa, tmp_patch) catch util.oom();
            if (os.run(gitArgv(ap.items), .{ .env = &env }).status != 0) return 4;
            const wt = os.run(gitArgv(&.{"write-tree"}), .{ .capture_stdout = true, .env = &env });
            if (wt.status != 0) return 4;
            const tree = stripNl(wt.stdout);
            const msg = util.concat(&.{ subject, "\n\n", os.readFile(tmp_msg) orelse "" });
            var ct: std.ArrayList([]const u8) = .empty;
            ct.appendSlice(gpa, &.{ "commit-tree", tree, "-p", commit }) catch util.oom();
            const cr = os.run(gitArgv(ct.items), .{ .capture_stdout = true, .stdin_data = msg, .env = &env });
            if (cr.status != 0) return 4;
            commit = stripNl(cr.stdout);
            const ur = os.run(gitArgv(&.{ "update-ref", "-m", util.concat(&.{ "quiltimport: ", patch_name }), "HEAD", commit }), .{ .env = &env });
            if (ur.status != 0) return 4;
        }
    }
    os.removeTree(tmp_dir);
    return 0;
}
