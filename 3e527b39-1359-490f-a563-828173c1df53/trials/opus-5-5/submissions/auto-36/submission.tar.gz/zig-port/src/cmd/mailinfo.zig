//! git mailinfo (builtin/mailinfo.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const mailinfo = @import("../mailinfo.zig");

const usage = [_][]const u8{"git mailinfo [<options>] <msg> <patch> < mail >info"};

const CHARSET_DEFAULT: i32 = 0;
const CHARSET_NO_REENCODE: i32 = 1;
const CHARSET_EXPLICIT: i32 = 2;

var policy: i32 = CHARSET_DEFAULT;
var explicit_charset: []const u8 = "";
var mi: mailinfo.MailInfo = .{};

fn encodingCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    policy = CHARSET_EXPLICIT;
    explicit_charset = arg orelse "";
}

fn quotedCrCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse "";
    mi.quoted_cr = mailinfo.parseQuotedCrAction(a) orelse {
        util.err("bad action '{s}' for '{s}'", .{ a, "--quoted-cr" });
        os.exit(129);
    };
}

fn prefixFilename(arg: []const u8) []const u8 {
    if (arg.len > 0 and arg[0] == '/') return arg;
    if (po.prefix.len == 0) return arg;
    return util.concat(&.{ po.prefix, arg });
}

pub fn cmdMailinfo(args: []const []const u8) u8 {
    mailinfo.setup(&mi);
    policy = CHARSET_DEFAULT;
    const options = [_]po.Opt{
        po.boolean('k', "", &mi.keep_subject, "keep subject"),
        po.boolean('b', "", &mi.keep_non_patch_brackets_in_subject, "keep non patch brackets in subject"),
        po.boolean('m', "message-id", &mi.add_message_id, "copy Message-ID to the end of commit message"),
        .{ .short = 'u', .kind = .set_int, .i = &policy, .val = CHARSET_DEFAULT, .noneg = true, .help = "re-code metadata to i18n.commitEncoding" },
        .{ .short = 'n', .kind = .set_int, .i = &policy, .val = CHARSET_NO_REENCODE, .noneg = true, .help = "disable charset re-coding of metadata" },
        .{ .long = "encoding", .kind = .callback, .cb = encodingCb, .argh = "encoding", .noneg = true, .help = "re-code metadata to this encoding" },
        po.boolean(0, "scissors", &mi.use_scissors, "use scissors"),
        .{ .long = "quoted-cr", .kind = .callback, .cb = quotedCrCb, .argh = "action", .noneg = true, .help = "action when quoted CR is found" },
        .{ .long = "inbody-headers", .kind = .boolean, .b = &mi.use_inbody_headers, .hidden = true, .help = "use headers in message's body" },
    };
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len != 2) po.usageWithOptions(&usage, &options);

    switch (policy) {
        CHARSET_DEFAULT => mi.metainfo_charset = repo_mod.cfg.get("i18n.commitencoding") orelse "UTF-8",
        CHARSET_NO_REENCODE => mi.metainfo_charset = null,
        else => mi.metainfo_charset = explicit_charset,
    }

    mi.input.data = os.readAllFd(0) catch "";
    const msgfile = prefixFilename(rest[0]);
    const patchfile = prefixFilename(rest[1]);
    const status = mailinfo.mailinfo(&mi, msgfile, patchfile);
    util.out(mi.output.items);
    return if (status != 0) 1 else 0;
}
