//! git mailsplit (builtin/mailsplit.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const mailinfo = @import("../mailinfo.zig");
const gpa = util.gpa;
const Buf = util.Buf;
const Input = mailinfo.Input;

const git_mailsplit_usage = "git mailsplit [-d<prec>] [-f<n>] [-b] [--keep-cr] -o<directory> [(<mbox>|<Maildir>)...]";

var buf: Buf = .empty;
var keep_cr = false;
var mboxrd = false;

fn isDigit(c: u8) bool {
    return c >= '0' and c <= '9';
}

/// strtol(s, NULL, 10), clamped to i64.
fn strtol(s: []const u8) i64 {
    var i: usize = 0;
    while (i < s.len and (s[i] == ' ' or (s[i] >= 9 and s[i] <= 13))) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    var v: i64 = 0;
    while (i < s.len and isDigit(s[i])) : (i += 1) {
        v = std.math.mul(i64, v, 10) catch std.math.maxInt(i64);
        v = std.math.add(i64, v, s[i] - '0') catch std.math.maxInt(i64);
    }
    return if (neg) -v else v;
}

fn isFromLine(line: []const u8) bool {
    const len = line.len;
    if (len < 20 or !util.startsWith(line, "From ")) return false;
    var colon: usize = len - 2;
    while (true) {
        if (colon < 5) return false;
        colon -= 1;
        if (line[colon] == ':') break;
    }
    if (!isDigit(line[colon - 4]) or !isDigit(line[colon - 2]) or !isDigit(line[colon - 1]) or
        !isDigit(line[colon + 1]) or !isDigit(line[colon + 2])) return false;
    if (strtol(mailinfo.cstr(line[colon + 3 ..])) <= 90) return false;
    return true;
}

fn isGtfrom(b: []const u8) bool {
    if (b.len < 6) return false;
    var ngt: usize = 0;
    while (ngt < b.len and b[ngt] == '>') ngt += 1;
    return ngt > 0 and util.startsWith(b[ngt..], "From ");
}

fn splitOne(mbox: *Input, name: []const u8, allow_bare: bool) bool {
    var status = false;
    const is_bare = !isFromLine(buf.items);
    if (is_bare and !allow_bare) {
        util.ewrite("corrupt mailbox\n");
        os.exit(1);
    }
    const fd = os.openFile(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o666);
    if (fd < 0) util.dieErrno("could not open '{s}' for writing", .{name});
    var out: Buf = .empty;
    while (true) {
        const n = buf.items.len;
        if (!keep_cr and n > 1 and buf.items[n - 1] == '\n' and buf.items[n - 2] == '\r') {
            buf.items.len = n - 2;
            util.bufByte(&buf, '\n');
        }
        if (mboxrd and isGtfrom(buf.items)) {
            std.mem.copyForwards(u8, buf.items[0..], buf.items[1..]);
            buf.items.len -= 1;
        }
        util.bufAppend(&out, buf.items);
        if (mbox.getWholeLine(&buf)) {
            status = true;
            break;
        }
        if (!is_bare and isFromLine(buf.items)) break;
    }
    os.writeAll(fd, out.items) catch util.dieErrno("cannot write output", .{});
    os.close(fd);
    return status;
}

fn outName(dir: []const u8, prec: usize, n: i64) []const u8 {
    const digits = util.fmt("{d}", .{n});
    var b: Buf = .empty;
    util.bufAppend(&b, dir);
    util.bufByte(&b, '/');
    var i = digits.len;
    while (i < prec) : (i += 1) util.bufByte(&b, '0');
    util.bufAppend(&b, digits);
    return b.items;
}

fn maildirFilenameCmp(a0: []const u8, b0: []const u8) i64 {
    var a = a0;
    var b = b0;
    while (a.len > 0 and b.len > 0) {
        if (isDigit(a[0]) and isDigit(b[0])) {
            var ia: usize = 0;
            while (ia < a.len and isDigit(a[ia])) ia += 1;
            var ib: usize = 0;
            while (ib < b.len and isDigit(b[ib])) ib += 1;
            const na = strtol(a[0..ia]);
            const nb = strtol(b[0..ib]);
            a = a[ia..];
            b = b[ib..];
            if (na != nb) return na - nb;
        } else {
            if (a[0] != b[0]) return @as(i64, a[0]) - @as(i64, b[0]);
            a = a[1..];
            b = b[1..];
        }
    }
    const ca: i64 = if (a.len > 0) a[0] else 0;
    const cb: i64 = if (b.len > 0) b[0] else 0;
    return ca - cb;
}

fn populateMaildirList(list: *std.ArrayList([]const u8), path: []const u8) bool {
    for ([_][]const u8{ "cur", "new" }) |sub| {
        const name = util.fmt("{s}/{s}", .{ path, sub });
        const ents = os.listDir(name) orelse {
            if (os.errno() == os.ENOENT) continue;
            util.err("cannot opendir {s}: {s}", .{ name, os.lastErr() });
            return false;
        };
        for (ents) |e| {
            if (e.name.len > 0 and e.name[0] == '.') continue;
            const item = util.fmt("{s}/{s}", .{ sub, e.name });
            // sorted insert, skipping duplicates (string_list_insert)
            var lo: usize = 0;
            var hi: usize = list.items.len;
            var dup = false;
            while (lo < hi) {
                const mid = (lo + hi) / 2;
                const c = maildirFilenameCmp(list.items[mid], item);
                if (c == 0) {
                    dup = true;
                    break;
                }
                if (c < 0) lo = mid + 1 else hi = mid;
            }
            if (!dup) list.insert(gpa, lo, item) catch util.oom();
        }
    }
    return true;
}

fn splitMaildir(maildir: []const u8, dir: []const u8, nr_prec: usize, skip0: i64) i64 {
    var skip = skip0;
    var list: std.ArrayList([]const u8) = .empty;
    if (!populateMaildirList(&list, maildir)) return -1;
    for (list.items) |item| {
        const file = util.fmt("{s}/{s}", .{ maildir, item });
        const data = os.readFile(file) orelse {
            util.err("cannot open mail {s}: {s}", .{ file, os.lastErr() });
            return -1;
        };
        var in: Input = .{ .data = data };
        if (in.getWholeLine(&buf)) {
            util.err("cannot read mail {s}: {s}", .{ file, os.lastErr() });
            return -1;
        }
        skip += 1;
        _ = splitOne(&in, outName(dir, nr_prec, skip), true);
    }
    return skip;
}

fn splitMbox(file: []const u8, dir: []const u8, allow_bare: bool, nr_prec: usize, skip0: i64) i64 {
    var skip = skip0;
    const is_stdin = util.eql(file, "-");
    var data: []const u8 = undefined;
    if (is_stdin) {
        if (os.isatty(0)) util.warn("reading patches from stdin/tty...", .{});
        data = os.readAllFd(0) catch "";
    } else {
        data = os.readFile(file) orelse {
            util.err("cannot open mbox {s}: {s}", .{ file, os.lastErr() });
            return -1;
        };
    }
    var in: Input = .{ .data = data };
    while (true) {
        const peek = in.getc() orelse {
            if (is_stdin) return skip;
            util.err("empty mbox: '{s}'", .{file});
            return -1;
        };
        if (!mailinfo.isSpace(peek)) break;
    }
    in.ungetc();
    var file_done = false;
    if (in.getWholeLine(&buf)) {
        if (!is_stdin) {
            util.err("cannot read mbox {s}", .{file});
            return -1;
        }
        file_done = true;
    }
    while (!file_done) {
        skip += 1;
        file_done = splitOne(&in, outName(dir, nr_prec, skip), allow_bare);
    }
    return skip;
}

fn usageDie() noreturn {
    util.ewrite("usage: " ++ git_mailsplit_usage ++ "\n");
    os.exit(129);
}

pub fn cmdMailsplit(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.out("usage: " ++ git_mailsplit_usage ++ "\n");
        util.flushStdout();
        os.exit(0);
    }
    var nr: i64 = 0;
    var nr_prec: i64 = 4;
    var num: i64 = 0;
    var allow_bare = false;
    var dir: ?[]const u8 = null;
    var argp: usize = 1;
    while (argp < args.len) : (argp += 1) {
        const arg = args[argp];
        if (arg.len == 0 or arg[0] != '-') break;
        const a1: u8 = if (arg.len > 1) arg[1] else 0;
        if (a1 == 'd') {
            nr_prec = strtol(arg[2..]);
            if (nr_prec < 3 or 10 <= nr_prec) usageDie();
        } else if (a1 == 'f') {
            nr = strtol(arg[2..]);
        } else if (a1 == 'b' and arg.len == 2) {
            allow_bare = true;
        } else if (util.eql(arg, "--keep-cr")) {
            keep_cr = true;
        } else if (a1 == 'o' and arg.len > 2) {
            dir = arg[2..];
        } else if (util.eql(arg, "--mboxrd")) {
            mboxrd = true;
        } else if (a1 == '-' and arg.len == 2) {
            argp += 1;
            break;
        } else {
            util.die("unknown option: {s}", .{arg});
        }
    }

    var inputs: []const []const u8 = undefined;
    const remaining = args[argp..];
    if (dir == null) {
        switch (remaining.len) {
            1 => {
                dir = remaining[0];
                inputs = &.{"-"};
            },
            2 => {
                dir = remaining[1];
                inputs = remaining[0..1];
            },
            else => usageDie(),
        }
    } else {
        inputs = if (remaining.len == 0) &.{"-"} else remaining;
    }
    const d = dir.?;
    const prec: usize = @intCast(nr_prec);

    for (inputs) |arg| {
        var ret: i64 = 0;
        if (util.eql(arg, "-")) {
            ret = splitMbox(arg, d, allow_bare, prec, nr);
            if (ret < 0) {
                util.err("cannot split patches from stdin", .{});
                return 1;
            }
            num += ret - nr;
            nr = ret;
            continue;
        }
        const st = os.statPath(arg) orelse {
            util.err("cannot stat {s}: {s}", .{ arg, os.lastErr() });
            return 1;
        };
        if (st.isDir()) {
            ret = splitMaildir(arg, d, prec, nr);
        } else {
            ret = splitMbox(arg, d, allow_bare, prec, nr);
        }
        if (ret < 0) {
            util.err("cannot split patches from {s}", .{arg});
            return 1;
        }
        num += ret - nr;
        nr = ret;
    }
    util.outf("{d}\n", .{num});
    return 0;
}
