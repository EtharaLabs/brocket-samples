//! Credential handling (port of credential.c, prompt.c, compat/terminal.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const proc = @import("proc.zig");
const config = @import("config.zig");
const repo_mod = @import("repo.zig");
const gpa = util.gpa;

pub const TIME_MAX: u64 = std.math.maxInt(u64);

pub const OpType = enum { initial, helper, response };

pub const Capa = struct {
    request_initial: bool = false,
    request_helper: bool = false,
    response: bool = false,

    pub fn set(self: *Capa, op: OpType) void {
        switch (op) {
            .initial => self.request_initial = true,
            .helper => self.request_helper = true,
            .response => self.response = true,
        }
    }

    pub fn has(self: *const Capa, op: OpType) bool {
        return switch (op) {
            .helper => self.request_initial,
            .response => self.request_initial and self.request_helper,
            else => false,
        };
    }
};

const StrList = std.ArrayList([]const u8);

pub const Credential = struct {
    helpers: StrList = .empty,
    wwwauth: StrList = .empty,
    state_headers: StrList = .empty,
    state_to_send: StrList = .empty,
    approved: bool = false,
    ephemeral: bool = false,
    configured: bool = false,
    multistage: bool = false,
    quit: bool = false,
    use_http_path: bool = false,
    username_from_proto: bool = false,
    sanitize_prompt: bool = true,
    protect_protocol: bool = true,
    capa_authtype: Capa = .{},
    capa_state: Capa = .{},
    username: ?[]const u8 = null,
    password: ?[]const u8 = null,
    credential: ?[]const u8 = null,
    protocol: ?[]const u8 = null,
    host: ?[]const u8 = null,
    path: ?[]const u8 = null,
    oauth_refresh_token: ?[]const u8 = null,
    authtype: ?[]const u8 = null,
    password_expiry_utc: u64 = TIME_MAX,

    pub fn clear(self: *Credential) void {
        self.* = .{};
    }

    pub fn clearSecrets(self: *Credential) void {
        self.password = null;
        self.credential = null;
    }

    pub fn nextState(self: *Credential) void {
        self.state_to_send = self.state_headers;
        self.state_headers = .empty;
    }

    pub fn setAllCapabilities(self: *Credential, op: OpType) void {
        self.capa_authtype.set(op);
        self.capa_state.set(op);
    }
};

pub fn announceCapabilities(c: *const Credential, b: *util.Buf) void {
    util.bufAppend(b, "version 0\n");
    if (c.capa_authtype.request_initial) util.bufAppend(b, "capability authtype\n");
    if (c.capa_state.request_initial) util.bufAppend(b, "capability state\n");
}

fn checkEq(want: ?[]const u8, have: ?[]const u8) bool {
    const w = want orelse return true;
    const h = have orelse return false;
    return util.eql(w, h);
}

pub fn match(want: *const Credential, have: *const Credential, match_password: bool) bool {
    return checkEq(want.protocol, have.protocol) and
        checkEq(want.host, have.host) and
        checkEq(want.path, have.path) and
        checkEq(want.username, have.username) and
        (!match_password or checkEq(want.password, have.password)) and
        (!match_password or checkEq(want.credential, have.credential));
}

// ---------------------------------------------------------------------------
// line reader (strbuf_getline on an fd, without over-reading much)

pub const Reader = struct {
    fd: c_int,
    buf: [4096]u8 = undefined,
    start: usize = 0,
    end: usize = 0,
    eof: bool = false,

    fn fill(self: *Reader) bool {
        if (self.eof) return false;
        while (true) {
            const n = std.c.read(self.fd, &self.buf, self.buf.len);
            if (n < 0) {
                if (os.errno() == os.EINTR) continue;
                self.eof = true;
                return false;
            }
            if (n == 0) {
                self.eof = true;
                return false;
            }
            self.start = 0;
            self.end = @intCast(n);
            return true;
        }
    }

    /// strbuf_getline_lf: returns null on EOF with no data.
    pub fn getlineLf(self: *Reader) ?[]u8 {
        var line: util.Buf = .empty;
        var got = false;
        while (true) {
            if (self.start >= self.end) {
                if (!self.fill()) break;
            }
            got = true;
            const avail = self.buf[self.start..self.end];
            if (std.mem.indexOfScalar(u8, avail, '\n')) |i| {
                util.bufAppend(&line, avail[0..i]);
                self.start += i + 1;
                return line.items;
            }
            util.bufAppend(&line, avail);
            self.start = self.end;
        }
        if (!got) return null;
        return line.items;
    }

    /// strbuf_getline: also strips a trailing CR.
    pub fn getline(self: *Reader) ?[]u8 {
        const l = self.getlineLf() orelse return null;
        if (l.len > 0 and l[l.len - 1] == '\r') return l[0 .. l.len - 1];
        return l;
    }

    pub fn readAll(self: *Reader) []u8 {
        var b: util.Buf = .empty;
        while (true) {
            if (self.start < self.end) {
                util.bufAppend(&b, self.buf[self.start..self.end]);
                self.start = self.end;
            }
            if (!self.fill()) break;
        }
        return b.items;
    }
};

/// parse_timestamp(value, NULL, 10) (strtoumax semantics) with the
/// "0 or ERANGE means TIME_MAX" rule.
fn parseExpiry(v: []const u8) u64 {
    var i: usize = 0;
    while (i < v.len and (v[i] == ' ' or (v[i] >= 9 and v[i] <= 13))) i += 1;
    var neg = false;
    if (i < v.len and (v[i] == '+' or v[i] == '-')) {
        neg = v[i] == '-';
        i += 1;
    }
    var n: u64 = 0;
    while (i < v.len and std.ascii.isDigit(v[i])) : (i += 1) {
        const m = @mulWithOverflow(n, 10);
        if (m[1] != 0) return TIME_MAX;
        const a = @addWithOverflow(m[0], v[i] - '0');
        if (a[1] != 0) return TIME_MAX;
        n = a[0];
    }
    if (neg) n = 0 -% n;
    if (n == 0) return TIME_MAX;
    return n;
}

/// credential_read(): returns false on an invalid line.
pub fn read(c: *Credential, r: *Reader, op: OpType) bool {
    while (r.getline()) |line| {
        if (line.len == 0) break;
        const eq = std.mem.indexOfScalar(u8, line, '=') orelse {
            util.warn("invalid credential line: {s}", .{line});
            return false;
        };
        const key = line[0..eq];
        const value = util.dupe(line[eq + 1 ..]);
        if (util.eql(key, "username")) {
            c.username = value;
            c.username_from_proto = true;
        } else if (util.eql(key, "password")) {
            c.password = value;
        } else if (util.eql(key, "credential")) {
            c.credential = value;
        } else if (util.eql(key, "protocol")) {
            c.protocol = value;
        } else if (util.eql(key, "host")) {
            c.host = value;
        } else if (util.eql(key, "path")) {
            c.path = value;
        } else if (util.eql(key, "ephemeral")) {
            c.ephemeral = config.configBool("ephemeral", value);
        } else if (util.eql(key, "wwwauth[]")) {
            c.wwwauth.append(gpa, value) catch util.oom();
        } else if (util.eql(key, "state[]")) {
            c.state_headers.append(gpa, value) catch util.oom();
        } else if (util.eql(key, "capability[]")) {
            if (util.eql(value, "authtype")) {
                c.capa_authtype.set(op);
            } else if (util.eql(value, "state")) c.capa_state.set(op);
        } else if (util.eql(key, "continue")) {
            c.multistage = config.configBool("continue", value);
        } else if (util.eql(key, "password_expiry_utc")) {
            c.password_expiry_utc = parseExpiry(value);
        } else if (util.eql(key, "oauth_refresh_token")) {
            c.oauth_refresh_token = value;
        } else if (util.eql(key, "authtype")) {
            c.authtype = value;
        } else if (util.eql(key, "url")) {
            fromUrl(c, value);
        } else if (util.eql(key, "quit")) {
            c.quit = config.configBool("quit", value);
        }
    }
    return true;
}

/// Destination for credential_write(); on a fatal error the partial
/// output is flushed to `fd` before dying (like stdio does in C).
pub const Writer = struct {
    buf: util.Buf = .empty,
    fd: c_int,

    fn flushPartial(self: *Writer) void {
        if (self.fd == 1) {
            util.out(self.buf.items);
            util.flushStdout();
        } else {
            os.writeAll(self.fd, self.buf.items) catch {};
        }
        self.buf = .empty;
    }
};

fn writeItem(c: *const Credential, w: *Writer, key: []const u8, value: ?[]const u8) void {
    const v = value orelse return;
    if (std.mem.indexOfScalar(u8, v, '\n') != null) {
        w.flushPartial();
        util.die("credential value for {s} contains newline", .{key});
    }
    if (c.protect_protocol and std.mem.indexOfScalar(u8, v, '\r') != null) {
        w.flushPartial();
        util.die("credential value for {s} contains carriage return\nIf this is intended, set `credential.protectProtocol=false`", .{key});
    }
    util.bufPrint(&w.buf, "{s}={s}\n", .{ key, v });
}

pub fn write(c: *const Credential, w: *Writer, op: OpType) void {
    if (c.capa_authtype.has(op)) writeItem(c, w, "capability[]", "authtype");
    if (c.capa_state.has(op)) writeItem(c, w, "capability[]", "state");
    if (c.capa_authtype.has(op)) {
        writeItem(c, w, "authtype", c.authtype);
        writeItem(c, w, "credential", c.credential);
        if (c.ephemeral) writeItem(c, w, "ephemeral", "1");
    }
    if (c.protocol == null) util.die("BUG: credential value for protocol is missing", .{});
    if (c.host == null) util.die("BUG: credential value for host is missing", .{});
    writeItem(c, w, "protocol", c.protocol);
    writeItem(c, w, "host", c.host);
    writeItem(c, w, "path", c.path);
    writeItem(c, w, "username", c.username);
    writeItem(c, w, "password", c.password);
    writeItem(c, w, "oauth_refresh_token", c.oauth_refresh_token);
    if (c.password_expiry_utc != TIME_MAX) writeItem(c, w, "password_expiry_utc", util.fmt("{d}", .{c.password_expiry_utc}));
    for (c.wwwauth.items) |h| writeItem(c, w, "wwwauth[]", h);
    if (c.capa_state.has(op)) {
        if (c.multistage) writeItem(c, w, "continue", "1");
        for (c.state_to_send.items) |h| writeItem(c, w, "state[]", h);
    }
}

// ---------------------------------------------------------------------------
// URL handling

const STRBUF_URL_UNSAFE = " <>\"%{}|\\^`:?#[]@!$&'()*+,;=";
const ENCODE_SLASH = 1;
const ENCODE_HOST_AND_PORT = 2;

fn percentEncode(b: *util.Buf, src: []const u8, flags: u32) void {
    for (src) |ch| {
        const enc = ch <= 0x1f or ch >= 0x7f or (ch == '/' and (flags & ENCODE_SLASH) != 0) or
            (if ((flags & ENCODE_HOST_AND_PORT) != 0)
                !std.ascii.isAlphanumeric(ch) and std.mem.indexOfScalar(u8, "-.:[]", ch) == null
            else
                std.mem.indexOfScalar(u8, STRBUF_URL_UNSAFE, ch) != null);
        if (enc) util.bufPrint(b, "%{X:0>2}", .{ch}) else util.bufByte(b, ch);
    }
}

fn hexval(ch: u8) ?u8 {
    return std.fmt.charToDigit(ch, 16) catch null;
}

fn urlDecodeInternal(out: *util.Buf, q: []const u8) void {
    var i: usize = 0;
    while (i < q.len) {
        const ch = q[i];
        if (ch == 0) break;
        if (ch == '%' and q.len - i >= 3) {
            if (hexval(q[i + 1])) |hi| {
                if (hexval(q[i + 2])) |lo| {
                    const v = hi * 16 + lo;
                    if (v > 0) {
                        util.bufByte(out, v);
                        i += 3;
                        continue;
                    }
                }
            }
        }
        util.bufByte(out, ch);
        i += 1;
    }
}

/// url_decode_mem(): note that the part before the first colon is copied verbatim.
pub fn urlDecodeMem(url: []const u8) []u8 {
    var out: util.Buf = .empty;
    var u = url;
    if (std.mem.indexOfScalar(u8, u, ':')) |colon| {
        if (colon > 0) {
            util.bufAppend(&out, u[0..colon]);
            u = u[colon..];
        }
    }
    urlDecodeInternal(&out, u);
    return out.items;
}

fn checkUrlComponent(url: []const u8, quiet: bool, name: []const u8, value: ?[]const u8) bool {
    const v = value orelse return true;
    if (std.mem.indexOfScalar(u8, v, '\n') == null) return true;
    if (!quiet) util.warn("url contains a newline in its {s} component: {s}", .{ name, url });
    return false;
}

fn fromUrl1(c: *Credential, url: []const u8, allow_partial: bool, quiet: bool) bool {
    c.clear();
    const proto_end = std.mem.indexOf(u8, url, "://");
    if (!allow_partial and (proto_end == null or proto_end.? == 0)) {
        if (!quiet) util.warn("url has no scheme: {s}", .{url});
        return false;
    }
    const cp_off: usize = if (proto_end) |p| p + 3 else 0;
    const cp = url[cp_off..];
    const at = std.mem.indexOfScalar(u8, cp, '@');
    const colon = std.mem.indexOfScalar(u8, cp, ':');
    var slash: usize = 0;
    while (slash < cp.len and std.mem.indexOfScalar(u8, "/?#", cp[slash]) == null) slash += 1;
    var host_off: usize = 0;
    if (at == null or slash <= at.?) {
        host_off = 0;
    } else if (colon == null or at.? <= colon.?) {
        const u = urlDecodeMem(cp[0..at.?]);
        c.username = u;
        if (u.len > 0) c.username_from_proto = true;
        host_off = at.? + 1;
    } else {
        const u = urlDecodeMem(cp[0..colon.?]);
        c.username = u;
        if (u.len > 0) c.username_from_proto = true;
        c.password = urlDecodeMem(cp[colon.? + 1 .. at.?]);
        host_off = at.? + 1;
    }
    if (proto_end) |p| {
        if (p > 0) c.protocol = util.dupe(url[0..p]);
    }
    if (!allow_partial or slash > host_off) c.host = urlDecodeMem(cp[host_off..slash]);
    var s = slash;
    while (s < cp.len and cp[s] == '/') s += 1;
    if (s < cp.len) {
        var p = urlDecodeMem(cp[s..]);
        var n = p.len;
        while (n > 1 and p[n - 1] == '/') n -= 1;
        p = p[0..n];
        c.path = p;
    }
    if (!checkUrlComponent(url, quiet, "username", c.username) or
        !checkUrlComponent(url, quiet, "password", c.password) or
        !checkUrlComponent(url, quiet, "protocol", c.protocol) or
        !checkUrlComponent(url, quiet, "host", c.host) or
        !checkUrlComponent(url, quiet, "path", c.path))
        return false;
    return true;
}

pub fn fromUrlGently(c: *Credential, url: []const u8, quiet: bool) bool {
    return fromUrl1(c, url, false, quiet);
}

pub fn fromUrl(c: *Credential, url: []const u8) void {
    if (!fromUrlGently(c, url, false)) util.die("credential url cannot be parsed: {s}", .{url});
}

fn describe(c: *const Credential, b: *util.Buf) void {
    const proto = c.protocol orelse return;
    util.bufPrint(b, "{s}://", .{proto});
    if (c.username) |u| {
        if (u.len > 0) util.bufPrint(b, "{s}@", .{u});
    }
    if (c.host) |h| util.bufAppend(b, h);
    if (c.path) |p| util.bufPrint(b, "/{s}", .{p});
}

fn format(c: *const Credential, b: *util.Buf) void {
    const proto = c.protocol orelse return;
    util.bufPrint(b, "{s}://", .{proto});
    if (c.username) |u| {
        if (u.len > 0) {
            percentEncode(b, u, ENCODE_SLASH);
            util.bufByte(b, '@');
        }
    }
    if (c.host) |h| percentEncode(b, h, ENCODE_HOST_AND_PORT);
    if (c.path) |p| {
        util.bufByte(b, '/');
        percentEncode(b, p, 0);
    }
}

// ---------------------------------------------------------------------------
// config

fn dieBadConfig(e: config.Entry) noreturn {
    if (e.origin_type == .cmdline or e.origin.len == 0)
        util.die("unable to parse '{s}' from command-line config", .{e.key});
    util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
}

fn configCallback(c: *Credential, key: []const u8, e: config.Entry) void {
    const value = e.value orelse {
        _ = config.errorNonbool(util.concat(&.{ "credential.", key }));
        dieBadConfig(e);
    };
    const v = util.concat(&.{ "credential.", key });
    if (util.eql(key, "helper")) {
        if (value.len > 0) {
            c.helpers.append(gpa, value) catch util.oom();
        } else c.helpers = .empty;
    } else if (util.eql(key, "username")) {
        if (!c.username_from_proto) c.username = value;
    } else if (util.eql(key, "usehttppath")) {
        c.use_http_path = config.configBool(v, value);
    } else if (util.eql(key, "sanitizeprompt")) {
        c.sanitize_prompt = config.configBool(v, value);
    } else if (util.eql(key, "protectprotocol")) {
        c.protect_protocol = config.configBool(v, value);
    }
}

fn matchPartialUrl(url: []const u8, c: *const Credential) bool {
    var want = Credential{};
    if (!fromUrl1(&want, url, true, false)) {
        util.warn("skipping credential lookup for key: credential.{s}", .{url});
        return false;
    }
    return match(&want, c, false);
}

fn protoIsHttp(s: ?[]const u8) bool {
    const p = s orelse return false;
    return util.eql(p, "https") or util.eql(p, "http");
}

pub fn applyConfig(c: *Credential) void {
    if (c.host == null) util.die("refusing to work with credential missing host field", .{});
    if (c.protocol == null) util.die("refusing to work with credential missing protocol field", .{});
    if (c.configured) return;

    var urlb: util.Buf = .empty;
    format(c, &urlb);
    const info: ?config.UrlInfo = switch (config.urlNormalize(urlb.items, false)) {
        .ok => |i| i,
        .err => null,
    };
    for (repo_mod.cfg.entries.items) |e| {
        const rest = util.skipPrefix(e.key, "credential.") orelse continue;
        var key = rest;
        if (std.mem.lastIndexOfScalar(u8, key, '.')) |dot| {
            const config_url = key[0..dot];
            const matched = switch (config.urlNormalize(config_url, true)) {
                .ok => |ni| if (info) |*ui| config.matchUrls(ui, &ni) != null else false,
                .err => matchPartialUrl(config_url, c),
            };
            if (!matched) continue;
            key = key[dot + 1 ..];
        }
        configCallback(c, key, e);
    }
    c.configured = true;
    if (!c.use_http_path and protoIsHttp(c.protocol)) c.path = null;
}

// ---------------------------------------------------------------------------
// prompting

const Termios = extern struct {
    iflag: u32,
    oflag: u32,
    cflag: u32,
    lflag: u32,
    line: u8,
    cc: [32]u8,
    ispeed: u32,
    ospeed: u32,
};
extern "c" fn tcgetattr(fd: c_int, t: *Termios) c_int;
extern "c" fn tcsetattr(fd: c_int, act: c_int, t: *const Termios) c_int;
const ECHO_FLAG: u32 = 0o10;

fn terminalPrompt(ptext: []const u8, echo: bool) ?[]u8 {
    const fd = os.openFile("/dev/tty", os.O_RDWR | os.O_CLOEXEC, 0);
    if (fd < 0) return null;
    defer os.close(fd);
    var old: Termios = undefined;
    var restored = true;
    if (!echo) {
        if (tcgetattr(fd, &old) == 0) {
            var t = old;
            t.lflag &= ~ECHO_FLAG;
            _ = tcsetattr(fd, 0, &t);
            restored = false;
        }
    }
    os.writeAll(fd, ptext) catch {};
    var r = Reader{ .fd = fd };
    const line = r.getlineLf();
    if (!echo) os.writeAll(fd, "\n") catch {};
    if (!restored) _ = tcsetattr(fd, 0, &old);
    return line;
}

fn envBool(name: []const u8, def: bool) bool {
    const v = os.getenv(name) orelse return def;
    return config.configBool(name, v);
}

fn canExec(cmd: []const u8) bool {
    if (std.mem.indexOfScalar(u8, cmd, '/') != null) return os.access(cmd, 1) and !os.isDir(cmd);
    const path = os.getenv("PATH") orelse return false;
    var it = std.mem.splitScalar(u8, path, ':');
    while (it.next()) |d| {
        const p = util.concat(&.{ if (d.len == 0) "." else d, "/", cmd });
        if (os.access(p, 1) and !os.isDir(p)) return true;
    }
    return false;
}

fn doAskpass(cmd: []const u8, ptext: []const u8) ?[]u8 {
    if (!canExec(cmd)) {
        const e = if (os.access(cmd, 0) or std.mem.indexOfScalar(u8, cmd, '/') == null) os.strErr(os.EACCES) else os.strErr(os.ENOENT);
        util.err("cannot run {s}: {s}", .{ cmd, if (std.mem.indexOfScalar(u8, cmd, '/') == null) os.strErr(os.ENOENT) else e });
        return null;
    }
    const ch = proc.spawn(&.{ cmd, ptext }, .{ .pipe_out = true });
    var r = Reader{ .fd = ch.out };
    const data = r.readAll();
    os.close(ch.out);
    const st = proc.wait(ch.pid);
    if (st != 0) {
        util.err("unable to read askpass response from '{s}'", .{cmd});
        return null;
    }
    var n: usize = 0;
    while (n < data.len and data[n] != '\r' and data[n] != '\n') n += 1;
    return data[0..n];
}

/// git_prompt() with PROMPT_ASKPASS.
pub fn prompt(text: []const u8, echo: bool) []u8 {
    var r: ?[]u8 = null;
    var askpass: ?[]const u8 = os.getenv("GIT_ASKPASS");
    if (askpass == null) askpass = repo_mod.cfg.get("core.askpass");
    if (askpass == null) askpass = os.getenv("SSH_ASKPASS");
    if (askpass) |a| {
        if (a.len > 0) r = doAskpass(a, text);
    }
    if (r == null) {
        var e: []const u8 = undefined;
        if (envBool("GIT_TERMINAL_PROMPT", true)) {
            r = terminalPrompt(text, echo);
            e = os.lastErr();
        } else {
            e = "terminal prompts disabled";
        }
        if (r == null) util.die("could not read {s}{s}", .{ text, e });
    }
    return r.?;
}

fn askOne(what: []const u8, c: *const Credential, echo: bool) []u8 {
    var desc: util.Buf = .empty;
    if (c.sanitize_prompt) format(c, &desc) else describe(c, &desc);
    const p = if (desc.items.len > 0) util.fmt("{s} for '{s}': ", .{ what, desc.items }) else util.fmt("{s}: ", .{what});
    return prompt(p, echo);
}

fn getpass(c: *Credential) bool {
    if (repo_mod.cfg.get("credential.interactive")) |v| {
        if (config.parseMaybeBool(v) == 0) return false;
        if (util.eql(v, "never")) return false;
    }
    if (c.username == null) c.username = askOne("Username", c, true);
    if (c.password == null) c.password = askOne("Password", c, false);
    return true;
}

// ---------------------------------------------------------------------------
// helpers

const SHELL_META = "|&;<>()$`\\\"' \t\n*?[#~=%";

fn runHelper(c: *Credential, cmd: []const u8, want_output: bool) bool {
    var argv: StrList = .empty;
    if (std.mem.indexOfAny(u8, cmd, SHELL_META) != null) {
        argv.appendSlice(gpa, &.{ "/bin/sh", "-c", cmd }) catch util.oom();
    } else argv.append(gpa, cmd) catch util.oom();

    var devnull: c_int = -1;
    if (!want_output) devnull = os.openFile("/dev/null", os.O_WRONLY | os.O_CLOEXEC, 0);
    const ch = proc.spawn(argv.items, .{ .pipe_in = true, .pipe_out = want_output, .out_fd = devnull });
    if (devnull >= 0) os.close(devnull);

    proc.ignoreSigpipe();
    var w = Writer{ .fd = ch.in };
    write(c, &w, if (want_output) .helper else .response);
    os.writeAll(ch.in, w.buf.items) catch {};
    os.close(ch.in);

    if (want_output) {
        var r = Reader{ .fd = ch.out };
        const ok = read(c, &r, .helper);
        os.close(ch.out);
        if (!ok) {
            _ = proc.wait(ch.pid);
            return false;
        }
    }
    return proc.wait(ch.pid) == 0;
}

fn isAbsolute(p: []const u8) bool {
    return p.len > 0 and p[0] == '/';
}

fn credentialDo(c: *Credential, helper: []const u8, operation: []const u8) bool {
    var cmd: util.Buf = .empty;
    if (helper[0] == '!') {
        util.bufAppend(&cmd, helper[1..]);
    } else if (isAbsolute(helper)) {
        util.bufAppend(&cmd, helper);
    } else util.bufPrint(&cmd, "git credential-{s}", .{helper});
    util.bufPrint(&cmd, " {s}", .{operation});
    return runHelper(c, cmd.items, util.eql(operation, "get"));
}

fn nowU() u64 {
    const t = os.now();
    return if (t < 0) 0 else @intCast(t);
}

pub fn fill(c: *Credential, all_capabilities: bool) void {
    if ((c.username != null and c.password != null) or c.credential != null) return;
    c.nextState();
    c.multistage = false;
    applyConfig(c);
    if (all_capabilities) c.setAllCapabilities(.initial);
    for (c.helpers.items) |h| {
        _ = credentialDo(c, h, "get");
        if (c.password_expiry_utc < nowU()) {
            c.clearSecrets();
            c.password_expiry_utc = TIME_MAX;
        }
        if ((c.username != null and c.password != null) or c.credential != null) {
            c.wwwauth = .empty;
            return;
        }
        if (c.quit) util.die("credential helper '{s}' told us to quit", .{h});
    }
    if (!getpass(c) or (c.username == null and c.password == null and c.credential == null))
        util.die("unable to get password from user", .{});
}

pub fn approve(c: *Credential) void {
    if (c.approved) return;
    if (((c.username == null or c.password == null) and c.credential == null) or c.password_expiry_utc < nowU()) return;
    c.nextState();
    applyConfig(c);
    for (c.helpers.items) |h| _ = credentialDo(c, h, "store");
    c.approved = true;
}

pub fn reject(c: *Credential) void {
    c.nextState();
    applyConfig(c);
    for (c.helpers.items) |h| _ = credentialDo(c, h, "erase");
    c.clearSecrets();
    c.username = null;
    c.oauth_refresh_token = null;
    c.password_expiry_utc = TIME_MAX;
    c.approved = false;
}
