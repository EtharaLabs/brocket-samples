//! Port of transport-helper.c: the git-remote-<helper> protocol for
//! helpers (capabilities, list, fetch, import, push, export, option,
//! connect, stateless-connect).
const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const proc = @import("proc.zig");
const refs = @import("refs.zig");
const hash = @import("hash.zig");
const pkt = @import("pktline.zig");
const repo_mod = @import("repo.zig");
const tp = @import("transport.zig");
const gpa = util.gpa;
const Transport = tp.Transport;
const Ref = tp.Ref;

extern "c" fn signal(sig: c_int, handler: usize) usize;
extern "c" fn dup(fd: c_int) c_int;
extern "c" fn rename(a: [*:0]const u8, b: [*:0]const u8) c_int;

pub const Helper = struct {
    name: []const u8,
    child: proc.Child,
    fetch: bool = false,
    import: bool = false,
    bidi_import: bool = false,
    @"export": bool = false,
    option: bool = false,
    push: bool = false,
    connect: bool = false,
    stateless_connect: bool = false,
    signed_tags: bool = false,
    check_connectivity: bool = false,
    no_disconnect_req: bool = false,
    no_private_update: bool = false,
    object_format: bool = false,
    get_refs_list_called: bool = false,
    export_marks: ?[]const u8 = null,
    import_marks: ?[]const u8 = null,
    rs: tp.Refspec = .{ .fetch = true },
};

var debug_checked = false;
var debug = false;

fn isDebug() bool {
    if (!debug_checked) {
        debug_checked = true;
        debug = os.getenv("GIT_TRANSPORT_HELPER_DEBUG") != null;
    }
    return debug;
}

fn dbg(comptime f: []const u8, args: anytype) void {
    if (isDebug()) util.ewrite(util.fmt(f, args));
}

fn readLineFd(fd: c_int) ?[]const u8 {
    var b: util.Buf = .empty;
    var ch: [1]u8 = undefined;
    while (true) {
        const r = std.c.read(fd, &ch, 1);
        if (r < 0) {
            if (os.errno() == 4) continue;
            if (b.items.len == 0) return null;
            break;
        }
        if (r == 0) {
            if (b.items.len == 0) return null;
            break;
        }
        if (ch[0] == '\n') break;
        util.bufByte(&b, ch[0]);
    }
    if (b.items.len > 0 and b.items[b.items.len - 1] == '\r') b.items.len -= 1;
    return b.items;
}

fn sendline(h: *Helper, s: []const u8) void {
    dbg("Debug: Remote helper: -> {s}", .{s});
    os.writeAll(h.child.in, s) catch util.dieErrno("full write to remote helper failed", .{});
}

fn recvline(h: *Helper) ?[]const u8 {
    dbg("Debug: Remote helper: Waiting...\n", .{});
    const line = readLineFd(h.child.out) orelse {
        dbg("Debug: Remote helper quit.\n", .{});
        return null;
    };
    dbg("Debug: Remote helper: <- {s}\n", .{line});
    return line;
}

fn writeConstantGently(fd: c_int, s: []const u8) bool {
    dbg("Debug: Remote helper: -> {s}", .{s});
    os.writeAll(fd, s) catch return false;
    return true;
}

fn writeConstant(fd: c_int, s: []const u8) void {
    if (!writeConstantGently(fd, s)) util.dieErrno("full write to remote helper failed", .{});
}

fn removeExtForce(url: []const u8) []const u8 {
    if (std.mem.indexOfScalar(u8, url, ':')) |c| {
        if (c + 1 < url.len and url[c + 1] == ':') return url[c + 2 ..];
    }
    return url;
}

/// True while this transport talks the helper protocol (not taken over).
pub fn active(t: *const Transport) bool {
    return t.hd != null;
}

/// get_helper()
pub fn getHelper(t: *Transport) *Helper {
    if (t.hd) |h| return h;
    const name = t.helper.?;
    const cmdname = util.fmt("remote-{s}", .{name});
    var env: std.ArrayList([2][]const u8) = .empty;
    if (repo_mod.repo_) |r| env.append(gpa, .{ "GIT_DIR", r.git_dir }) catch util.oom();
    const ch = proc.spawn(&.{ proc.gitBinary(), cmdname, t.remote.name, removeExtForce(t.url) }, .{
        .pipe_in = true,
        .pipe_out = true,
        .env = env.items,
        .trace2_class = cmdname,
    });
    const h = gpa.create(Helper) catch util.oom();
    h.* = .{ .name = util.dupe(name), .child = ch };
    t.hd = h;

    const old = signal(13, 1);
    if (!writeConstantGently(ch.in, "capabilities\n")) util.die("remote helper '{s}' aborted session", .{name});
    _ = signal(13, old);

    while (true) {
        const line = recvline(h) orelse util.die("remote helper '{s}' aborted session", .{name});
        if (line.len == 0) break;
        const mandatory = line[0] == '*';
        const cap = if (mandatory) line[1..] else line;
        dbg("Debug: Got cap {s}\n", .{cap});
        if (util.eql(cap, "fetch")) {
            h.fetch = true;
        } else if (util.eql(cap, "option")) {
            h.option = true;
        } else if (util.eql(cap, "push")) {
            h.push = true;
        } else if (util.eql(cap, "import")) {
            h.import = true;
        } else if (util.eql(cap, "bidi-import")) {
            h.bidi_import = true;
        } else if (util.eql(cap, "export")) {
            h.@"export" = true;
        } else if (util.eql(cap, "check-connectivity")) {
            h.check_connectivity = true;
        } else if (util.skipPrefix(cap, "refspec ")) |arg| {
            h.rs.append(arg);
        } else if (util.eql(cap, "connect")) {
            h.connect = true;
        } else if (util.eql(cap, "stateless-connect")) {
            h.stateless_connect = true;
        } else if (util.eql(cap, "signed-tags")) {
            h.signed_tags = true;
        } else if (util.skipPrefix(cap, "export-marks ")) |arg| {
            h.export_marks = util.dupe(arg);
        } else if (util.skipPrefix(cap, "import-marks ")) |arg| {
            h.import_marks = util.dupe(arg);
        } else if (util.startsWith(cap, "no-private-update")) {
            h.no_private_update = true;
        } else if (util.startsWith(cap, "object-format")) {
            h.object_format = true;
        } else if (mandatory) {
            util.die("unknown mandatory capability {s}; this remote helper probably needs newer version of Git", .{cap});
        }
    }
    if (h.rs.items.items.len == 0 and (h.import or h.bidi_import or h.@"export"))
        util.warn("this remote helper should implement refspec capability", .{});
    dbg("Debug: Capabilities complete.\n", .{});
    standardOptions(t);
    return h;
}

fn standardOptions(t: *Transport) void {
    _ = setOption(t, "progress", if (t.progress) "true" else "false");
    _ = setOption(t, "verbosity", util.fmt("{d}", .{t.verbose + 1}));
    switch (t.family) {
        4 => _ = setOption(t, "family", "ipv4"),
        6 => _ = setOption(t, "family", "ipv6"),
        else => {},
    }
}

/// disconnect_helper(); returns the helper's exit status.
pub fn disconnect(t: *Transport) u8 {
    const h = t.hd orelse return 0;
    dbg("Debug: Disconnecting.\n", .{});
    if (!h.no_disconnect_req) {
        const old = signal(13, 1);
        _ = std.c.write(h.child.in, "\n", 1);
        _ = signal(13, old);
    }
    proc.closeFd(&h.child.in);
    proc.closeFd(&h.child.out);
    const res = proc.wait(h.child.pid);
    t.hd = null;
    return res;
}

fn strbufSetHelperOption(h: *Helper, line: []const u8) i32 {
    sendline(h, line);
    const resp = recvline(h) orelse os.exit(128);
    if (util.eql(resp, "ok")) return 0;
    if (util.startsWith(resp, "error")) return -1;
    if (util.eql(resp, "unsupported")) return 1;
    util.warn("{s} unexpectedly said: '{s}'", .{ h.name, resp });
    return 1;
}

const unsupported_options = [_][]const u8{ "uploadpack", "receivepack", "thin", "keep" };
const boolean_options = [_][]const u8{ "thin", "keep", "followtags", "deepen-relative" };

/// set_helper_option(); `value` null means false/unset.
/// Returns 0 on success, 1 when unsupported, -1 for an invalid value.
pub fn setOption(t: *Transport, name: []const u8, value: ?[]const u8) i32 {
    if (t.helper == null) return 1;
    const h = getHelper(t);
    if (!h.option) return 1;
    for (unsupported_options) |u| {
        if (util.eql(name, u)) return 1;
    }
    var is_bool = false;
    for (boolean_options) |b| {
        if (util.eql(name, b)) is_bool = true;
    }
    var b: util.Buf = .empty;
    util.bufPrint(&b, "option {s} ", .{name});
    if (is_bool) {
        util.bufAppend(&b, if (value != null) "true" else "false");
    } else util.bufAppend(&b, util.cquote(value orelse ""));
    util.bufByte(&b, '\n');
    return strbufSetHelperOption(h, b.items);
}

/// set_helper_option() for list-valued options (deepen-not).
pub fn setOptionList(t: *Transport, name: []const u8, list: []const []const u8) i32 {
    if (t.helper == null) return 1;
    const h = getHelper(t);
    if (!h.option) return 1;
    for (list) |item| {
        const r = strbufSetHelperOption(h, util.fmt("option {s} {s}\n", .{ name, util.cquote(item) }));
        if (r != 0) return r;
    }
    return 0;
}

/// Wrapper used by commands: only talks to the helper for helper transports.
pub fn transportSetOption(t: *Transport, name: []const u8, value: ?[]const u8) void {
    if (t.helper == null or t.child != null) return;
    _ = setOption(t, name, value);
}

pub fn transportSetOptionList(t: *Transport, name: []const u8, list: []const []const u8) void {
    if (t.helper == null or t.child != null) return;
    _ = setOptionList(t, name, list);
}

// ---------------- connect / stateless-connect ----------------

fn runConnect(t: *Transport, h: *Helper, cmd: []const u8) bool {
    _ = t;
    sendline(h, cmd);
    const resp = readLineFd(h.child.out) orelse os.exit(128);
    if (resp.len == 0) {
        h.no_disconnect_req = true;
        dbg("Debug: Smart transport connection ready.\n", .{});
        return true;
    } else if (util.eql(resp, "fallback")) {
        dbg("Debug: Falling back to dumb transport.\n", .{});
        return false;
    }
    util.die("unknown response to connect: {s}", .{resp});
}

/// process_connect_service(); returns true if the connection is ready.
fn processConnectService(t: *Transport, service: tp.Service, exec: []const u8) bool {
    const h = getHelper(t);
    if (!util.eql(service.cmd(), exec)) {
        const r = setOption(t, "servpath", exec);
        if (r > 0) {
            util.warn("setting remote service path not supported by protocol", .{});
        } else if (r < 0) util.warn("invalid remote service path", .{});
    }
    if (h.connect) {
        return runConnect(t, h, util.fmt("connect {s}\n", .{service.cmd()}));
    } else if (h.stateless_connect and tp.protocolVersionConfig() == 2 and
        (service == .upload_pack or service == .upload_archive))
    {
        const ok = runConnect(t, h, util.fmt("stateless-connect {s}\n", .{service.cmd()}));
        if (ok) t.stateless_rpc = true;
        return ok;
    }
    return false;
}

/// transport_take_over(): the helper's pipes become the smart connection.
fn takeOver(t: *Transport) proc.Child {
    const h = t.hd.?;
    t.hd = null;
    return h.child;
}

/// process_connect(): if the helper can connect, take it over and return
/// the child (the caller then speaks the git protocol over it).
pub fn processConnect(t: *Transport, for_push: bool) ?proc.Child {
    _ = getHelper(t);
    const service: tp.Service = if (for_push) .receive_pack else .upload_pack;
    const exec = (if (for_push) t.receivepack else t.uploadpack) orelse service.cmd();
    if (processConnectService(t, service, exec)) return takeOver(t);
    return null;
}

/// connect_helper(): used by archive --remote and friends; dies on failure.
pub fn connectHelper(t: *Transport, service: tp.Service, exec: []const u8) proc.Child {
    _ = getHelper(t);
    if (!processConnectService(t, service, exec)) util.die("can't connect to subservice {s}", .{service.cmd()});
    return takeOver(t);
}

// ---------------- list ----------------

fn hasAttribute(attrs: []const u8, attr: []const u8) bool {
    var it = std.mem.splitScalar(u8, attrs, ' ');
    while (it.next()) |a| {
        if (util.eql(a, attr)) return true;
    }
    return false;
}

/// get_refs_list_using_list()
pub fn getRefsListUsingList(t: *Transport, for_push: bool) []*Ref {
    const h = getHelper(t);
    h.get_refs_list_called = true;
    if (h.object_format) _ = setOption(t, "object-format", "true");
    if (h.push and for_push) {
        writeConstant(h.child.in, "list for-push\n");
    } else writeConstant(h.child.in, "list\n");
    var list: std.ArrayList(*Ref) = .empty;
    while (true) {
        const line = recvline(h) orelse os.exit(128);
        if (line.len == 0) break;
        if (line[0] == ':') {
            if (util.skipPrefix(line, ":object-format ")) |v| {
                if (!util.eql(v, "sha1")) util.die("unsupported object format '{s}'", .{v});
            }
            continue;
        }
        const eov = std.mem.indexOfScalar(u8, line, ' ') orelse util.die("malformed response in ref list: {s}", .{line});
        const rest = line[eov + 1 ..];
        const eon = std.mem.indexOfScalar(u8, rest, ' ');
        const name = if (eon) |e| rest[0..e] else rest;
        const r = tp.allocRef(name);
        const v = line[0..eov];
        if (v.len > 0 and v[0] == '@') {
            r.symref = util.dupe(v[1..]);
        } else if (!(v.len > 0 and v[0] == '?')) {
            r.old_oid = hash.fromHex(v) orelse hash.zero;
        }
        if (eon) |e| {
            if (hasAttribute(rest[e + 1 ..], "unchanged")) {
                r.status = .uptodate;
                const rr = refs.resolve(r.name) orelse util.die("could not read ref {s}", .{r.name});
                r.old_oid = rr.oid;
            }
        }
        list.append(gpa, r) catch util.oom();
    }
    dbg("Debug: Read ref listing.\n", .{});
    for (list.items) |r| {
        const sym = r.symref orelse continue;
        for (list.items) |o| {
            if (util.eql(o.name, sym)) {
                r.old_oid = o.old_oid;
                break;
            }
        }
    }
    return list.items;
}

// ---------------- fetch ----------------

pub const FetchOptions = struct {
    filter: ?[]const u8 = null,
};

fn fetchWithFetch(t: *Transport, h: *Helper, to_fetch: []const *Ref) i32 {
    var b: util.Buf = .empty;
    for (to_fetch) |r| {
        if (r.status == .uptodate) continue;
        util.bufPrint(&b, "fetch {s} {s}\n", .{ hash.hex(r.old_oid), r.symref orelse r.name });
    }
    util.bufByte(&b, '\n');
    sendline(h, b.items);
    while (true) {
        const line = recvline(h) orelse os.exit(128);
        if (util.skipPrefix(line, "lock ")) |name| {
            if (t.pack_lockfiles.items.len > 0) {
                util.warn("{s} also locked {s}", .{ h.name, name });
            } else t.pack_lockfiles.append(gpa, util.dupe(name)) catch util.oom();
        } else if (h.check_connectivity and t.check_self_contained and util.eql(line, "connectivity-ok")) {
            t.self_contained_and_connected = true;
        } else if (line.len == 0) {
            break;
        } else util.warn("{s} unexpectedly said: '{s}'", .{ h.name, line });
    }
    repo_mod.repo().odb().reloadPacks();
    return 0;
}

fn fetchWithImport(t: *Transport, h: *Helper, to_fetch: []const *Ref) i32 {
    _ = t;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "fast-import", "--allow-unsafe-features", if (isDebug()) "--stats" else "--quiet" }) catch util.oom();
    var cat_blob_fd: c_int = -1;
    if (h.bidi_import) {
        cat_blob_fd = dup(h.child.in);
        argv.append(gpa, util.fmt("--cat-blob-fd={d}", .{cat_blob_fd})) catch util.oom();
    }
    var in_fd = dup(h.child.out);
    if (in_fd < 0) util.die("couldn't run fast-import", .{});
    const fi = proc.spawn(argv.items, .{ .in_fd = in_fd });
    proc.closeFd(&in_fd);
    for (to_fetch) |r| {
        if (r.status == .uptodate) continue;
        sendline(h, util.fmt("import {s}\n", .{r.symref orelse r.name}));
    }
    writeConstant(h.child.in, "\n");
    if (proc.wait(fi.pid) != 0) util.die("error while running fast-import", .{});
    if (cat_blob_fd >= 0) proc.closeFd(&cat_blob_fd);
    repo_mod.repo().odb().reloadPacks();
    for (to_fetch) |r| {
        if (r.status == .uptodate) continue;
        const name = r.symref orelse r.name;
        const private: ?[]const u8 = if (h.rs.items.items.len > 0) h.rs.applyRefspecs(name) else name;
        if (private) |p| {
            const rr = refs.resolve(p) orelse util.die("could not read ref {s}", .{p});
            r.old_oid = rr.oid;
        }
    }
    return 0;
}

/// fetch_refs() for helpers that were not taken over.
pub fn fetchRefs(t: *Transport, to_fetch: []const *Ref, o: FetchOptions) i32 {
    const h = getHelper(t);
    if (!h.get_refs_list_called) _ = getRefsListUsingList(t, false);
    var count: usize = 0;
    for (to_fetch) |r| {
        if (r.status != .uptodate) count += 1;
    }
    if (count == 0) return 0;
    if (h.check_connectivity and t.check_self_contained) _ = setOption(t, "check-connectivity", "true");
    if (t.cloning) _ = setOption(t, "cloning", "true");
    if (t.update_shallow) _ = setOption(t, "update-shallow", "true");
    if (t.refetch) _ = setOption(t, "refetch", "true");
    if (o.filter) |f| _ = setOption(t, "filter", f);
    if (h.fetch) return fetchWithFetch(t, h, to_fetch);
    if (h.import) return fetchWithImport(t, h, to_fetch);
    return -1;
}

// ---------------- push ----------------

pub const PushFlags = struct {
    force: bool = false,
    mirror: bool = false,
    atomic: bool = false,
    dry_run: bool = false,
    cert: enum { never, always, if_asked } = .never,
    force_if_includes: bool = false,
    push_options: ?[]const []const u8 = null,
};

const UpdateState = struct {
    hint: ?*Ref = null,
    new_report: bool = false,
    has_report: bool = false,
};

fn findRefFrom(list: []const *Ref, start: ?*Ref, name: []const u8) ?*Ref {
    // C searches from the hint onwards first, then the whole list.
    if (start) |s| {
        var found = false;
        for (list) |r| {
            if (r == s) found = true;
            if (found and util.eql(r.name, name)) return r;
        }
    }
    return null;
}

fn pushUpdateRefStatus(line: []const u8, st: *UpdateState, list: []const *Ref) void {
    if (util.skipPrefix(line, "option ")) |kv| {
        if (st.hint == null or !(st.has_report or st.new_report))
            util.die("'option' without a matching 'ok/error' directive", .{});
        st.new_report = false;
        st.has_report = true;
        const h = st.hint.?;
        const sp = std.mem.indexOfScalar(u8, kv, ' ');
        const key = if (sp) |s| kv[0..s] else kv;
        const val: ?[]const u8 = if (sp) |s| kv[s + 1 ..] else null;
        if (util.eql(key, "refname")) {
            if (val) |v| h.name = util.dupe(v);
        } else if (util.eql(key, "old-oid")) {
            if (val) |v| if (v.len >= 40) if (hash.fromHex(v[0..40])) |o| {
                h.old_oid = o;
            };
        } else if (util.eql(key, "new-oid")) {
            if (val) |v| if (v.len >= 40) if (hash.fromHex(v[0..40])) |o| {
                h.new_oid = o;
            };
        } else if (util.eql(key, "forced-update")) h.forced_update = true;
        return;
    }
    st.has_report = false;
    st.new_report = false;
    var status: tp.PushStatus = undefined;
    var refname: []const u8 = undefined;
    if (util.skipPrefix(line, "ok ")) |r| {
        status = .ok;
        refname = r;
    } else if (util.skipPrefix(line, "error ")) |r| {
        status = .remote_reject;
        refname = r;
    } else util.die("expected ok/error, helper said '{s}'", .{line});
    var msg: ?[]const u8 = null;
    var forced = false;
    if (std.mem.indexOfScalar(u8, refname, ' ')) |sp| {
        const raw = refname[sp + 1 ..];
        refname = refname[0..sp];
        var m: []const u8 = raw;
        if (util.cunquote(raw)) |u| m = u.value;
        msg = m;
        const map = [_]struct { []const u8, ?tp.PushStatus }{
            .{ "no match", .none },
            .{ "up to date", .uptodate },
            .{ "non-fast forward", .reject_nonfastforward },
            .{ "already exists", .reject_already_exists },
            .{ "fetch first", .reject_fetch_first },
            .{ "needs force", .reject_needs_force },
            .{ "stale info", .reject_stale },
            .{ "remote ref updated since checkout", .reject_remote_updated },
            .{ "forced update", null },
            .{ "expecting report", .expecting_report },
        };
        for (map) |e| {
            if (util.eql(m, e[0])) {
                if (e[1]) |s| status = s else forced = true;
                msg = null;
                break;
            }
        }
    }
    var hint: ?*Ref = null;
    if (st.hint != null) hint = findRefFrom(list, st.hint, refname);
    if (hint == null) hint = tp.findRefByName(list, refname);
    st.hint = hint;
    const h = hint orelse {
        util.warn("helper reported unexpected status of {s}", .{refname});
        return;
    };
    if (h.status != .none and status == .none) return;
    if (status == .ok) st.new_report = true;
    h.status = status;
    h.forced_update = h.forced_update or forced;
    h.remote_status = msg;
}

fn pushUpdateRefsStatus(h: *Helper, list: []const *Ref, f: PushFlags) i32 {
    var st = UpdateState{};
    while (true) {
        const line = recvline(h) orelse return 1;
        if (line.len == 0) break;
        pushUpdateRefStatus(line, &st, list);
    }
    if (f.dry_run or h.rs.items.items.len == 0 or h.no_private_update) return 0;
    for (list) |r| {
        if (r.status != .ok) continue;
        const private = h.rs.applyRefspecs(r.name) orelse continue;
        refs.updateFlags(private, r.new_oid, null, "update by helper", 0) catch util.err("{s}", .{refs.last_error});
    }
    return 0;
}

fn setCommonPushOptions(t: *Transport, name: []const u8, f: PushFlags) void {
    if (f.dry_run) {
        if (setOption(t, "dry-run", "true") != 0) util.die("helper {s} does not support dry-run", .{name});
    } else if (f.cert == .always) {
        if (setOption(t, "pushcert", "true") != 0) util.die("helper {s} does not support --signed", .{name});
    } else if (f.cert == .if_asked) {
        if (setOption(t, "pushcert", "if-asked") != 0) util.die("helper {s} does not support --signed=if-asked", .{name});
    }
    if (f.atomic) {
        if (setOption(t, "atomic", "true") != 0) util.die("helper {s} does not support --atomic", .{name});
    }
    if (f.force_if_includes) {
        if (setOption(t, "force-if-includes", "true") != 0) util.die("helper {s} does not support --{s}", .{ name, "force-if-includes" });
    }
    if (f.push_options) |po| {
        for (po) |item| {
            if (setOption(t, "push-option", item) != 0) util.die("helper {s} does not support 'push-option'", .{name});
        }
    }
}

fn rejectAtomicPush(list: []const *Ref, mirror: bool) void {
    for (list) |r| {
        if (r.peer_ref == null and !mirror) continue;
        switch (r.status) {
            .none, .ok, .expecting_report => r.status = .atomic_push_failed,
            else => {},
        }
    }
}

fn pushRefsWithPush(t: *Transport, list: []const *Ref, f: PushFlags) i32 {
    const h = getHelper(t);
    if (!h.push) return 1;
    var b: util.Buf = .empty;
    var cas: std.ArrayList([]const u8) = .empty;
    for (list) |r| {
        if (r.peer_ref == null and !f.mirror) continue;
        switch (r.status) {
            .reject_nonfastforward, .reject_stale, .reject_already_exists, .reject_remote_updated => {
                if (f.atomic) {
                    rejectAtomicPush(list, f.mirror);
                    return 0;
                }
                continue;
            },
            .uptodate => continue,
            else => {},
        }
        if (f.force) r.force = true;
        util.bufAppend(&b, "push ");
        if (!r.deletion) {
            if (r.force) util.bufByte(&b, '+');
            if (r.peer_ref) |p| util.bufAppend(&b, p.name) else util.bufAppend(&b, &hash.hex(r.new_oid));
        }
        util.bufByte(&b, ':');
        util.bufAppend(&b, r.name);
        util.bufByte(&b, '\n');
        if (r.expect_old_sha1) cas.append(gpa, util.fmt("{s}:{s}", .{ r.name, hash.hex(r.old_oid_expect) })) catch util.oom();
    }
    if (b.items.len == 0) return 0;
    for (cas.items) |c| _ = setOption(t, "cas", c);
    setCommonPushOptions(t, h.name, f);
    util.bufByte(&b, '\n');
    sendline(h, b.items);
    return pushUpdateRefsStatus(h, list, f);
}

fn pushRefsWithExport(t: *Transport, list: []const *Ref, f: PushFlags) i32 {
    const h0 = getHelper(t);
    if (h0.rs.items.items.len == 0) util.die("remote-helper doesn't support push; refspec needed", .{});
    setCommonPushOptions(t, h0.name, f);
    if (f.force) {
        if (setOption(t, "force", "true") != 0) util.warn("helper {s} does not support '--force'", .{h0.name});
    }
    const h = getHelper(t);
    writeConstant(h.child.in, "export\n");
    var args: std.ArrayList([]const u8) = .empty;
    for (list) |r| {
        if (h.rs.applyRefspecs(r.name)) |private| {
            if (@import("revparse.zig").getOid(private)) |oid| {
                args.append(gpa, util.fmt("^{s}", .{private})) catch util.oom();
                r.old_oid = oid;
            }
        }
        if (r.peer_ref) |p| {
            if (!util.eql(r.name, p.name)) {
                var spec: []const u8 = undefined;
                if (!r.deletion) {
                    var name = p.name;
                    const rr = refs.resolveFull(p.name, true);
                    if (!rr.missing and !rr.broken and rr.flags & refs.REF_ISSYMREF != 0) name = rr.name;
                    spec = util.fmt("{s}:{s}", .{ name, r.name });
                } else spec = util.fmt(":{s}", .{r.name});
                args.append(gpa, "--refspec") catch util.oom();
                args.append(gpa, spec) catch util.oom();
            }
            if (!r.deletion) args.append(gpa, p.name) catch util.oom();
        }
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "fast-export", "--use-done-feature", if (h.signed_tags) "--signed-tags=verbatim" else "--signed-tags=warn-strip" }) catch util.oom();
    if (h.export_marks) |m| argv.append(gpa, util.fmt("--export-marks={s}.tmp", .{m})) catch util.oom();
    if (h.import_marks) |m| argv.append(gpa, util.fmt("--import-marks={s}", .{m})) catch util.oom();
    argv.appendSlice(gpa, args.items) catch util.oom();
    var out_fd = dup(h.child.in);
    if (out_fd < 0) util.die("couldn't run fast-export", .{});
    const fe = proc.spawn(argv.items, .{ .out_fd = out_fd });
    proc.closeFd(&out_fd);
    if (proc.wait(fe.pid) != 0) util.die("error while running fast-export", .{});
    if (pushUpdateRefsStatus(h, list, f) != 0) return 1;
    if (h.export_marks) |m| {
        const tmp = util.fmt("{s}.tmp", .{m});
        if (rename(os.z(tmp), os.z(m)) != 0)
            util.warn("could not rename '{s}' to '{s}': {s}", .{ tmp, m, os.lastErr() });
    }
    return 0;
}

/// push_refs() for helpers that were not taken over.
pub fn pushRefs(t: *Transport, list: []const *Ref, f: PushFlags) i32 {
    const h = getHelper(t);
    if (list.len == 0) {
        util.ewrite("No refs in common and none specified; doing nothing.\nPerhaps you should specify a branch.\n");
        return 0;
    }
    if (h.push) return pushRefsWithPush(t, list, f);
    if (h.@"export") return pushRefsWithExport(t, list, f);
    return -1;
}

/// check_stateless_delimiter()
pub fn checkStatelessDelimiter(t: *Transport, msg: []const u8) void {
    if (!t.stateless_rpc) return;
    if (t.rd.read() != .response_end) util.die("{s}", .{msg});
}

comptime {
    _ = pkt;
}
