//! git pull (builtin/pull.c): runs `git fetch` then `git merge FETCH_HEAD`
//! (or `git rebase`) as subprocesses.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const proc = @import("../proc.zig");
const advice = @import("../advice.zig");
const cn = @import("../commitnode.zig");
const creach = @import("../commitreach.zig");
const index_mod = @import("../index.zig");
const ut = @import("../unpacktrees.zig");
const tp = @import("../transport.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

const REBASE_INVALID: i32 = -1;
const REBASE_FALSE: i32 = 0;
const REBASE_TRUE: i32 = 1;
const REBASE_MERGES: i32 = 2;
const REBASE_INTERACTIVE: i32 = 3;

const usage = [_][]const u8{"git pull [<options>] [<repository> [<refspec>...]]"};

var opt_verbosity: i32 = 0;
var opt_progress: ?[]const u8 = null;
var recurse_cli: ?[]const u8 = null;
var recurse_submodules: bool = false;

var opt_rebase: i32 = -2; // -2 == unspecified
var opt_diffstat: ?[]const u8 = null;
var opt_log: ?[]const u8 = null;
var opt_signoff: ?[]const u8 = null;
var opt_squash: ?[]const u8 = null;
var opt_commit: ?[]const u8 = null;
var opt_edit: ?[]const u8 = null;
var cleanup_arg: ?[]const u8 = null;
var opt_ff: ?[]const u8 = null;
var opt_verify_signatures: ?[]const u8 = null;
var opt_verify: ?[]const u8 = null;
var opt_autostash: i32 = -1;
var autostash_set: bool = false;
var autostash_val: bool = false;
var config_rebase_autostash: bool = false;
var config_pull_autostash: i32 = -1;
var opt_strategies: std.ArrayList([]const u8) = .empty;
var opt_strategy_opts: std.ArrayList([]const u8) = .empty;
var opt_gpg_sign: ?[]const u8 = null;
var opt_allow_unrelated: i32 = 0;

var opt_all: ?[]const u8 = null;
var opt_append: ?[]const u8 = null;
var opt_upload_pack: ?[]const u8 = null;
var opt_force: i32 = 0;
var opt_tags: ?[]const u8 = null;
var opt_prune: ?[]const u8 = null;
var max_children: ?[]const u8 = null;
var opt_dry_run: bool = false;
var opt_keep: ?[]const u8 = null;
var opt_depth: ?[]const u8 = null;
var opt_unshallow: ?[]const u8 = null;
var opt_update_shallow: ?[]const u8 = null;
var opt_refmap: ?[]const u8 = null;
var opt_ipv4: ?[]const u8 = null;
var opt_ipv6: ?[]const u8 = null;
var opt_show_forced: i32 = -1;
var sfu_set: bool = false;
var sfu_val: bool = false;
var set_upstream: ?[]const u8 = null;
var opt_fetch: std.ArrayList([]const u8) = .empty;

/// OPT_PASSTHRU formatting (parse_opt_passthru)
fn passthruText(o: *const po.Opt, arg: ?[]const u8, unset: bool) []const u8 {
    if (o.long.len > 0) {
        return util.concat(&.{ "--", if (unset) "no-" else "", o.long, if (arg != null) "=" else "", arg orelse "" });
    }
    return util.concat(&.{ "-", &[_]u8{o.short}, arg orelse "" });
}

fn cbPassthru(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    o.s.?.* = passthruText(o, arg, unset);
}

fn cbPassthruArgv(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    o.l.?.append(gpa, passthruText(o, arg, unset)) catch util.oom();
}

fn pt(short: u8, long: []const u8, s: *?[]const u8, argh: []const u8, help: []const u8, noarg: bool, optarg: bool, noneg: bool) po.Opt {
    return .{ .short = short, .long = long, .kind = .callback, .cbx = cbPassthru, .s = s, .argh = argh, .help = help, .noarg = noarg, .optarg = optarg, .noneg = noneg };
}

fn ptv(short: u8, long: []const u8, l: *std.ArrayList([]const u8), argh: []const u8, help: []const u8) po.Opt {
    return .{ .short = short, .long = long, .kind = .callback, .cbx = cbPassthruArgv, .l = l, .argh = argh, .help = help };
}

fn rebaseParseValue(value: []const u8) i32 {
    const v = config.parseMaybeBool(value);
    if (v == 0) return REBASE_FALSE;
    if (v > 0) return REBASE_TRUE;
    if (util.eql(value, "merges") or util.eql(value, "m")) return REBASE_MERGES;
    if (util.eql(value, "interactive") or util.eql(value, "i")) return REBASE_INTERACTIVE;
    if (util.eql(value, "preserve") or util.eql(value, "p"))
        util.err("{s}: 'preserve' superseded by 'merges'", .{value});
    return REBASE_INVALID;
}

fn parseConfigRebase(key: []const u8, value: []const u8, fatal: bool) i32 {
    const v = rebaseParseValue(value);
    if (v != REBASE_INVALID) return v;
    if (fatal) util.die("invalid value for '{s}': '{s}'", .{ key, value });
    util.err("invalid value for '{s}': '{s}'", .{ key, value });
    return REBASE_INVALID;
}

fn cbRebase(arg: ?[]const u8, unset: bool) void {
    if (arg) |a| {
        opt_rebase = parseConfigRebase("--rebase", a, false);
        if (opt_rebase == REBASE_INVALID) os.exit(129);
    } else opt_rebase = if (unset) REBASE_FALSE else REBASE_TRUE;
}

fn cbRecurse(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        recurse_cli = "no";
        return;
    }
    const a = arg orelse "on";
    const b = config.parseMaybeBool(a);
    if (util.eql(a, "on-demand")) {
        recurse_cli = "on-demand";
    } else if (b == 1) {
        recurse_cli = "on";
    } else if (b == 0) {
        recurse_cli = "no";
    } else util.die("bad {s} argument: {s}", .{ "recurse-submodules", a });
}

fn cbAutostash(_: ?[]const u8, unset: bool) void {
    opt_autostash = if (unset) 0 else 1;
}

fn cbSfu(_: ?[]const u8, unset: bool) void {
    opt_show_forced = if (unset) 0 else 1;
}

fn cbForce(_: ?[]const u8, unset: bool) void {
    if (unset) opt_force = 0 else opt_force += 1;
}

fn cbCleanup(arg: ?[]const u8, unset: bool) void {
    cleanup_arg = if (unset) null else arg;
}

const options = [_]po.Opt{
    po.verbose(&opt_verbosity),
    po.quiet(&opt_verbosity),
    pt(0, "progress", &opt_progress, "", "force progress reporting", true, false, false),
    .{ .long = "recurse-submodules", .kind = .callback, .cb = cbRecurse, .argh = "on-demand", .help = "control for recursive fetching of submodules", .optarg = true },
    po.group("Options related to merging"),
    .{ .short = 'r', .long = "rebase", .kind = .callback, .cb = cbRebase, .argh = "(false|true|merges|interactive)", .help = "incorporate changes by rebasing rather than merging", .optarg = true, .literal_argh = true },
    pt('n', "", &opt_diffstat, "", "do not show a diffstat at the end of the merge", true, false, true),
    pt(0, "stat", &opt_diffstat, "", "show a diffstat at the end of the merge", true, false, false),
    .{ .long = "summary", .kind = .callback, .cbx = cbPassthru, .s = &opt_diffstat, .help = "(synonym to --stat)", .noarg = true, .hidden = true },
    pt(0, "compact-summary", &opt_diffstat, "", "show a compact-summary at the end of the merge", true, false, false),
    pt(0, "log", &opt_log, "n", "add (at most <n>) entries from shortlog to merge commit message", false, true, false),
    pt(0, "signoff", &opt_signoff, "", "add a Signed-off-by trailer", false, true, false),
    pt(0, "squash", &opt_squash, "", "create a single commit instead of doing a merge", true, false, false),
    pt(0, "commit", &opt_commit, "", "perform a commit if the merge succeeds (default)", true, false, false),
    pt(0, "edit", &opt_edit, "", "edit message before committing", true, false, false),
    .{ .long = "cleanup", .kind = .callback, .cb = cbCleanup, .argh = "mode", .help = "how to strip spaces and #comments from message" },
    pt(0, "ff", &opt_ff, "", "allow fast-forward", true, false, false),
    pt(0, "ff-only", &opt_ff, "", "abort if fast-forward is not possible", true, false, true),
    pt(0, "verify", &opt_verify, "", "control use of pre-merge-commit and commit-msg hooks", true, false, false),
    pt(0, "verify-signatures", &opt_verify_signatures, "", "verify that the named commit has a valid GPG signature", true, false, false),
    po.callbackNoArg(0, "autostash", cbAutostash, "automatically stash/stash pop before and after"),
    ptv('s', "strategy", &opt_strategies, "strategy", "merge strategy to use"),
    ptv('X', "strategy-option", &opt_strategy_opts, "option=value", "option for selected merge strategy"),
    pt('S', "gpg-sign", &opt_gpg_sign, "key-id", "GPG sign commit", false, true, false),
    po.setInt(0, "allow-unrelated-histories", &opt_allow_unrelated, 1, "allow merging unrelated histories"),
    po.group("Options related to fetching"),
    pt(0, "all", &opt_all, "", "fetch from all remotes", true, false, false),
    pt('a', "append", &opt_append, "", "append to .git/FETCH_HEAD instead of overwriting", true, false, false),
    pt(0, "upload-pack", &opt_upload_pack, "path", "path to upload pack on remote end", false, false, false),
    .{ .short = 'f', .long = "force", .kind = .callback, .cb = cbForce, .noarg = true, .help = "force overwrite of local branch" },
    pt('t', "tags", &opt_tags, "", "fetch all tags and associated objects", true, false, false),
    pt('p', "prune", &opt_prune, "", "prune remote-tracking branches no longer on remote", true, false, false),
    pt('j', "jobs", &max_children, "n", "number of submodules pulled in parallel", false, true, false),
    po.boolean(0, "dry-run", &opt_dry_run, "dry run"),
    pt('k', "keep", &opt_keep, "", "keep downloaded pack", true, false, false),
    pt(0, "depth", &opt_depth, "depth", "deepen history of shallow clone", false, false, false),
    ptv(0, "shallow-since", &opt_fetch, "time", "deepen history of shallow repository based on time"),
    ptv(0, "shallow-exclude", &opt_fetch, "ref", "deepen history of shallow clone, excluding ref"),
    ptv(0, "deepen", &opt_fetch, "n", "deepen history of shallow clone"),
    pt(0, "unshallow", &opt_unshallow, "", "convert to a complete repository", true, false, true),
    pt(0, "update-shallow", &opt_update_shallow, "", "accept refs that update .git/shallow", true, false, false),
    pt(0, "refmap", &opt_refmap, "refmap", "specify fetch refmap", false, false, true),
    ptv('o', "server-option", &opt_fetch, "server-specific", "option to transmit"),
    pt('4', "ipv4", &opt_ipv4, "", "use IPv4 addresses only", true, false, false),
    pt('6', "ipv6", &opt_ipv6, "", "use IPv6 addresses only", true, false, false),
    ptv(0, "negotiation-restrict", &opt_fetch, "revision", "report that we have only objects reachable from this object"),
    po.fromAlias(ptv(0, "negotiation-tip", &opt_fetch, "revision", "alias of --negotiation-restrict")),
    ptv(0, "negotiation-include", &opt_fetch, "revision", "ensure this ref is always sent as a negotiation have"),
    po.callbackNoArg(0, "show-forced-updates", cbSfu, "check for forced-updates on all updated branches"),
    pt(0, "set-upstream", &set_upstream, "", "set upstream for git pull/fetch", true, false, false),
};

fn pushVerbosity(a: *std.ArrayList([]const u8)) void {
    var v = opt_verbosity;
    while (v > 0) : (v -= 1) a.append(gpa, "-v") catch util.oom();
    v = opt_verbosity;
    while (v < 0) : (v += 1) a.append(gpa, "-q") catch util.oom();
}

fn push(a: *std.ArrayList([]const u8), s: ?[]const u8) void {
    if (s) |x| a.append(gpa, x) catch util.oom();
}

fn runGit(args: []const []const u8) u8 {
    util.flushStdout();
    const ch = proc.spawnGit(args, .{});
    return proc.wait(ch.pid);
}

fn runFetch(repo: ?[]const u8, refspecs: []const []const u8) u8 {
    var a: std.ArrayList([]const u8) = .empty;
    a.appendSlice(gpa, &.{ "fetch", "--update-head-ok" }) catch util.oom();
    pushVerbosity(&a);
    push(&a, opt_progress);
    push(&a, opt_all);
    push(&a, opt_append);
    push(&a, opt_upload_pack);
    var f = opt_force;
    while (f > 0) : (f -= 1) push(&a, "-f");
    push(&a, opt_tags);
    push(&a, opt_prune);
    if (recurse_cli) |r| push(&a, util.concat(&.{ "--recurse-submodules=", r }));
    push(&a, max_children);
    if (opt_dry_run) push(&a, "--dry-run");
    push(&a, opt_keep);
    push(&a, opt_depth);
    push(&a, opt_unshallow);
    push(&a, opt_update_shallow);
    push(&a, opt_refmap);
    push(&a, opt_ipv4);
    push(&a, opt_ipv6);
    if (opt_show_forced > 0) push(&a, "--show-forced-updates") else if (opt_show_forced == 0) push(&a, "--no-show-forced-updates");
    push(&a, set_upstream);
    a.appendSlice(gpa, opt_fetch.items) catch util.oom();
    if (repo) |r| {
        push(&a, r);
        a.appendSlice(gpa, refspecs) catch util.oom();
    }
    return runGit(a.items);
}

fn runMerge() u8 {
    var a: std.ArrayList([]const u8) = .empty;
    push(&a, "merge");
    pushVerbosity(&a);
    push(&a, opt_progress);
    push(&a, opt_diffstat);
    push(&a, opt_log);
    push(&a, opt_signoff);
    push(&a, opt_squash);
    push(&a, opt_commit);
    push(&a, opt_edit);
    if (cleanup_arg) |c| push(&a, util.concat(&.{ "--cleanup=", c }));
    push(&a, opt_ff);
    push(&a, opt_verify);
    push(&a, opt_verify_signatures);
    a.appendSlice(gpa, opt_strategies.items) catch util.oom();
    a.appendSlice(gpa, opt_strategy_opts.items) catch util.oom();
    push(&a, opt_gpg_sign);
    if (opt_autostash == 0) push(&a, "--no-autostash") else if (opt_autostash == 1) push(&a, "--autostash");
    if (opt_allow_unrelated > 0) push(&a, "--allow-unrelated-histories");
    push(&a, "FETCH_HEAD");
    return runGit(a.items);
}

fn runRebase(newbase: Oid, upstream: Oid) u8 {
    var a: std.ArrayList([]const u8) = .empty;
    push(&a, "rebase");
    pushVerbosity(&a);
    if (opt_rebase == REBASE_MERGES) push(&a, "--rebase-merges") else if (opt_rebase == REBASE_INTERACTIVE) push(&a, "--interactive");
    push(&a, opt_diffstat);
    a.appendSlice(gpa, opt_strategies.items) catch util.oom();
    a.appendSlice(gpa, opt_strategy_opts.items) catch util.oom();
    push(&a, opt_gpg_sign);
    if (opt_signoff) |s| push(&a, s);
    if (opt_autostash == 0) push(&a, "--no-autostash") else if (opt_autostash == 1) push(&a, "--autostash");
    if (opt_verify_signatures != null and util.eql(opt_verify_signatures.?, "--verify-signatures"))
        util.warn("ignoring --verify-signatures for rebase", .{});
    push(&a, "--onto");
    push(&a, &hash.hex(newbase));
    push(&a, util.dupe(&hash.hex(upstream)));
    return runGit(a.items);
}

fn configGetFf() ?[]const u8 {
    const value = repo_mod.cfg.get("pull.ff") orelse return null;
    const b = config.parseMaybeBool(value);
    if (b == 0) return "--no-ff";
    if (b == 1) return "--ff";
    if (util.eql(value, "only")) return "--ff-only";
    util.die("invalid value for '{s}': '{s}'", .{ "pull.ff", value });
}

fn configGetRebase(unspecified: *bool) i32 {
    if (tp.branchGet("HEAD")) |b| {
        const key = util.concat(&.{ "branch.", b.name, ".rebase" });
        if (repo_mod.cfg.get(key)) |v| return parseConfigRebase(key, v, true);
    }
    if (repo_mod.cfg.get("pull.rebase")) |v| return parseConfigRebase("pull.rebase", v, true);
    unspecified.* = true;
    return REBASE_FALSE;
}

fn getMergeHeads(out: *std.ArrayList(Oid)) void {
    const path = repo_mod.repo().gitPath("FETCH_HEAD");
    const data = os.readFile(path) orelse util.die("could not open '{s}' for reading: {s}", .{ path, os.lastErr() });
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line| {
        if (line.len < 40) continue;
        const oid = hash.fromHex(line) orelse continue;
        const p = line[40..];
        if (std.mem.startsWith(u8, p, "\tnot-for-merge\t")) continue;
        out.append(gpa, oid) catch util.oom();
    }
}

fn dieNoMergeCandidates(repo: ?[]const u8, refspecs: []const []const u8) noreturn {
    const curr = tp.branchGet("HEAD");
    const remote: ?[]const u8 = if (curr) |c| c.remote_name else null;
    var b: util.Buf = .empty;
    const rebasing = opt_rebase > 0;
    if (refspecs.len > 0) {
        if (rebasing)
            util.bufAppend(&b, "There is no candidate for rebasing against among the refs that you just fetched.\n")
        else
            util.bufAppend(&b, "There are no candidates for merging among the refs that you just fetched.\n");
        util.bufAppend(&b, "Generally this means that you provided a wildcard refspec which had no\nmatches on the remote end.\n");
    } else if (repo != null and curr != null and (remote == null or !util.eql(repo.?, remote.?))) {
        util.bufPrint(&b, "You asked to pull from the remote '{s}', but did not specify\n" ++
            "a branch. Because this is not the default configured remote\n" ++
            "for your current branch, you must specify a branch on the command line.\n", .{repo.?});
    } else if (curr == null) {
        util.bufAppend(&b, "You are not currently on a branch.\n");
        util.bufAppend(&b, if (rebasing) "Please specify which branch you want to rebase against.\n" else "Please specify which branch you want to merge with.\n");
        util.bufAppend(&b, "See git-pull(1) for details.\n\n    git pull <remote> <branch>\n\n");
    } else if (curr.?.merge.items.len == 0) {
        const names = tp.remoteNames();
        const remote_name = if (names.len == 1) names[0] else "<remote>";
        util.bufAppend(&b, "There is no tracking information for the current branch.\n");
        util.bufAppend(&b, if (rebasing) "Please specify which branch you want to rebase against.\n" else "Please specify which branch you want to merge with.\n");
        util.bufAppend(&b, "See git-pull(1) for details.\n\n    git pull <remote> <branch>\n\n");
        util.bufAppend(&b, "If you wish to set tracking information for this branch you can do so with:\n\n");
        util.bufPrint(&b, "    git branch --set-upstream-to={s}/<branch> {s}\n\n", .{ remote_name, curr.?.name });
    } else {
        util.bufPrint(&b, "Your configuration specifies to merge with the ref '{s}'\nfrom the remote, but no such ref was fetched.\n", .{curr.?.merge.items[0]});
    }
    util.ewrite(b.items);
    os.exit(1);
}

fn showAdvicePullNonFf() void {
    advice.advise("You have divergent branches and need to specify how to reconcile them.\n" ++
        "You can do so by running one of the following commands sometime before\n" ++
        "your next pull:\n" ++
        "\n" ++
        "  git config pull.rebase false  # merge\n" ++
        "  git config pull.rebase true   # rebase\n" ++
        "  git config pull.ff only       # fast-forward only\n" ++
        "\n" ++
        "You can replace \"git config\" with \"git config --global\" to set a default\n" ++
        "preference for all repositories. You can also pass --rebase, --no-rebase,\n" ++
        "or --ff-only on the command line to override the configured default per\n" ++
        "invocation.");
}

fn dieFfImpossible() noreturn {
    advice.adviseIfEnabled("diverging", "Diverging branches can't be fast-forwarded, you need to either:\n" ++
        "\n" ++
        "\tgit merge --no-ff\n" ++
        "\n" ++
        "or:\n" ++
        "\n" ++
        "\tgit rebase\n");
    util.die("Not possible to fast-forward, aborting.", .{});
}

fn commitOf(oid: Oid) *cn.Commit {
    return cn.lookupCommitReference(oid) orelse os.exit(128);
}

/// merge_head is a descendant of head?
fn getCanFf(orig_head: Oid, heads: []const Oid) bool {
    if (heads.len > 1) return false;
    return creach.inMergeBases(commitOf(orig_head), commitOf(heads[0]));
}

fn alreadyUpToDate(orig_head: Oid, heads: []const Oid) bool {
    const ours = commitOf(orig_head);
    for (heads) |h| {
        if (!creach.inMergeBases(commitOf(h), ours)) return false;
    }
    return true;
}

const empty_tree_hex = "4b825dc642cb6eb9a060e54bf8d69288fbee4904";

fn checkoutFastForward(from: []const u8, to: Oid) bool {
    return runGit(&.{ "read-tree", "-m", "-u", from, util.dupe(&hash.hex(to)) }) == 0;
}

fn pullIntoVoid(merge_head: Oid, curr_head: ?Oid) u8 {
    if (!checkoutFastForward(empty_tree_hex, merge_head)) return 1;
    refs.updateFlags("HEAD", merge_head, curr_head orelse hash.zero, "initial pull", 0) catch {
        util.die("{s}", .{refs.last_error});
    };
    return 0;
}

pub fn cmdPull(args: []const []const u8) u8 {
    if (os.getenv("GIT_REFLOG_ACTION") == null) {
        var b: util.Buf = .empty;
        for (args, 0..) |a, i| {
            if (i > 0) util.bufByte(&b, ' ');
            util.bufAppend(&b, a);
        }
        os.setEnv("GIT_REFLOG_ACTION", b.items);
    }
    config_rebase_autostash = repo_mod.cfg.getBool("rebase.autostash") orelse false;
    if (repo_mod.cfg.getBool("pull.autostash")) |v| config_pull_autostash = @intFromBool(v);
    if (repo_mod.cfg.getBool("submodule.recurse")) |v| recurse_submodules = v;

    const rest = po.parse(args[1..], &options, &usage, .{});
    if (opt_autostash == -1) opt_autostash = config_pull_autostash;
    if (recurse_cli) |r| recurse_submodules = !util.eql(r, "no");

    if (cleanup_arg) |c| {
        const ok = for ([_][]const u8{ "strip", "whitespace", "verbatim", "scissors", "default" }) |m| {
            if (util.eql(c, m)) break true;
        } else false;
        if (!ok) util.die("Invalid cleanup mode {s}", .{c});
    }

    const repo: ?[]const u8 = if (rest.len > 0) rest[0] else null;
    const refspecs: []const []const u8 = if (rest.len > 0) rest[1..] else &.{};

    if (opt_ff == null) {
        opt_ff = configGetFf();
        if (opt_rebase >= 0 and opt_ff != null and util.eql(opt_ff.?, "--ff-only")) opt_ff = "--ff";
    }

    var rebase_unspecified = false;
    if (opt_rebase < 0) opt_rebase = configGetRebase(&rebase_unspecified);
    if (opt_rebase == REBASE_INVALID) opt_rebase = REBASE_FALSE;

    if (ut.readIndexUnmerged(index_mod.get())) advice.dieResolveConflict("pull");
    if (os.exists(repo_mod.repo().gitPath("MERGE_HEAD"))) advice.dieConcludeMerge();

    const orig_head: ?Oid = revparse.getOid("HEAD");

    if (opt_rebase > 0) {
        if (opt_autostash == -1) opt_autostash = @intFromBool(config_rebase_autostash);
        if (orig_head == null and index_mod.get().entries.items.len > 0)
            util.die("Updating an unborn branch with changes added to the index.", .{});
    }

    if (runFetch(repo, refspecs) != 0) return 1;
    if (opt_dry_run) return 0;

    const curr_head: ?Oid = revparse.getOid("HEAD");

    if (orig_head != null and curr_head != null and !hash.eql(orig_head.?, curr_head.?)) {
        const oh = util.dupe(&hash.hex(orig_head.?));
        util.warn("fetch updated the current branch head.\n" ++
            "fast-forwarding your working tree from\n" ++
            "commit {s}.", .{oh});
        if (!checkoutFastForward(oh, curr_head.?))
            util.die("Cannot fast-forward your working tree.\n" ++
                "After making sure that you saved anything precious from\n" ++
                "$ git diff {s}\n" ++
                "output, run\n" ++
                "$ git reset --hard\n" ++
                "to recover.", .{oh});
    }

    var merge_heads: std.ArrayList(Oid) = .empty;
    getMergeHeads(&merge_heads);
    if (merge_heads.items.len == 0) dieNoMergeCandidates(repo, refspecs);

    if (orig_head == null) {
        if (merge_heads.items.len > 1) util.die("Cannot merge multiple branches into empty head.", .{});
        return pullIntoVoid(merge_heads.items[0], curr_head);
    }
    if (merge_heads.items.len > 1) {
        if (opt_rebase > 0) util.die("Cannot rebase onto multiple branches.", .{});
        if (opt_ff != null and util.eql(opt_ff.?, "--ff-only")) util.die("Cannot fast-forward to multiple branches.", .{});
    }

    const can_ff = getCanFf(orig_head.?, merge_heads.items);
    const divergent = !can_ff and !alreadyUpToDate(orig_head.?, merge_heads.items);

    if (opt_ff != null and util.eql(opt_ff.?, "--ff-only")) {
        if (divergent) dieFfImpossible();
        opt_rebase = REBASE_FALSE;
    }
    if (opt_ff == null and rebase_unspecified and divergent) {
        showAdvicePullNonFf();
        util.die("Need to specify how to reconcile divergent branches.", .{});
    }

    var ret: u8 = 0;
    if (opt_rebase > 0) {
        if (can_ff) {
            opt_ff = "--ff-only";
            ret = runMerge();
        } else {
            ret = runRebase(merge_heads.items[0], merge_heads.items[0]);
        }
        if (ret == 0 and recurse_submodules) {
            var a: std.ArrayList([]const u8) = .empty;
            a.appendSlice(gpa, &.{ "submodule", "update", "--recursive", "--rebase" }) catch util.oom();
            pushVerbosity(&a);
            ret = runGit(a.items);
        }
    } else {
        ret = runMerge();
        if (ret == 0 and recurse_submodules) {
            var a: std.ArrayList([]const u8) = .empty;
            a.appendSlice(gpa, &.{ "submodule", "update", "--recursive", "--checkout" }) catch util.oom();
            pushVerbosity(&a);
            ret = runGit(a.items);
        }
    }
    return ret;
}
