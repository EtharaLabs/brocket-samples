//! git verify-tag / git verify-commit (builtin/verify-tag.c, builtin/verify-commit.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const revparse = @import("../revparse.zig");
const gpa = util.gpa;

const FLAG_VERBOSE: i32 = 1;
const FLAG_RAW: i32 = 2;
const FLAG_OMIT_STATUS: i32 = 4;

const SigFormat = enum { openpgp, x509, ssh };

const markers = [_]struct { m: []const u8, f: SigFormat }{
    .{ .m = "-----BEGIN PGP SIGNATURE-----", .f = .openpgp },
    .{ .m = "-----BEGIN PGP MESSAGE-----", .f = .openpgp },
    .{ .m = "-----BEGIN SIGNED MESSAGE-----", .f = .x509 },
    .{ .m = "-----BEGIN SSH SIGNATURE-----", .f = .ssh },
};

fn markerFormat(line: []const u8) ?SigFormat {
    for (markers) |m| if (util.startsWith(line, m.m)) return m.f;
    return null;
}

/// Offset of the start of the signature in a tag buffer (last line starting with a marker).
fn parseSignedBuffer(buf: []const u8) usize {
    var pos: usize = 0;
    var match: usize = buf.len;
    while (pos < buf.len) {
        if (markerFormat(buf[pos..]) != null) match = pos;
        const nl = std.mem.indexOfScalarPos(u8, buf, pos, '\n') orelse break;
        pos = nl + 1;
    }
    return match;
}

const SigResult = struct { ok: bool, status: []const u8 = "", payload: []const u8 = "" };

fn checkSignature(payload: []const u8, sig: []const u8) SigResult {
    const fmt_ = markerFormat(sig) orelse .openpgp;
    const cfg = &repo_mod.cfg;
    var prog: []const u8 = switch (fmt_) {
        .openpgp => "gpg",
        .x509 => "gpgsm",
        .ssh => "ssh-keygen",
    };
    switch (fmt_) {
        .openpgp => {
            if (cfg.get("gpg.program")) |v| prog = v;
            if (cfg.get("gpg.openpgp.program")) |v| prog = v;
        },
        .x509 => if (cfg.get("gpg.x509.program")) |v| {
            prog = v;
        },
        .ssh => {
            if (cfg.get("gpg.ssh.program")) |v| prog = v;
            if (cfg.get("gpg.ssh.allowedsignersfile") == null) {
                util.err("gpg.ssh.allowedSignersFile needs to be configured and exist for ssh signature verification", .{});
                return .{ .ok = false, .payload = payload };
            }
        },
    }
    // write the signature to a temp file, feed the payload on stdin
    const tmpdir = os.getenv("TMPDIR") orelse "/tmp";
    const t = os.tmpFile(tmpdir, ".git_vtag_tmp");
    os.writeAll(t.fd, sig) catch {};
    _ = std.c.close(t.fd);
    defer _ = os.unlink(t.path);
    const r = os.run(&.{ prog, "--keyid-format=long", "--status-fd=1", "--verify", t.path, "-" }, .{
        .capture_stdout = true,
        .stdin_data = payload,
    });
    const status = r.stdout;
    const good = !r.signaled and r.status == 0 and
        (util.startsWith(status, "[GNUPG:] GOODSIG ") or std.mem.indexOf(u8, status, "\n[GNUPG:] GOODSIG ") != null);
    return .{ .ok = good, .status = status, .payload = payload };
}

fn printSignatureBuffer(res: SigResult, flags: i32) void {
    if (flags & FLAG_VERBOSE != 0 and res.payload.len > 0) {
        util.out(res.payload);
        util.flushStdout();
    }
    if (flags & FLAG_RAW != 0 and res.status.len > 0) util.eprint("{s}", .{res.status});
}

const tag_usage = [_][]const u8{"git verify-tag [-v | --verbose] [--format=<format>] [--raw] <tag>..."};
const commit_usage = [_][]const u8{"git verify-commit [-v | --verbose] [--raw] <commit>..."};

pub fn cmdVerifyTag(args: []const []const u8) u8 {
    var verbose: i32 = 0;
    var flags: i32 = 0;
    var format: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.counter('v', "verbose", &verbose, "print tag contents"),
        po.bit(0, "raw", &flags, FLAG_RAW, "print raw gpg status output"),
        po.string(0, "format", &format, "format", "format to use for the output"),
    };
    const rest = po.parse(args[1..], &opts, &tag_usage, .{});
    if (rest.len == 0) po.usageWithOptions(&tag_usage, &opts);
    if (verbose != 0) flags |= FLAG_VERBOSE;
    if (format != null) flags |= FLAG_OMIT_STATUS;
    const odb = repo_mod.repo().odb();
    var had_error: u8 = 0;
    for (rest) |name| {
        const oid = revparse.getOid(name) orelse {
            util.err("tag '{s}' not found.", .{name});
            had_error = 1;
            continue;
        };
        const obj = odb.read(oid);
        if (obj == null or obj.?.typ != .tag) {
            const tn = if (obj) |o| o.typ.name() else "bad";
            util.err("{s}: cannot verify a non-tag object of type {s}.", .{ name, tn });
            had_error = 1;
            continue;
        }
        const buf = obj.?.data;
        const sp = parseSignedBuffer(buf);
        if (sp == buf.len) {
            if (flags & FLAG_VERBOSE != 0) {
                util.flushStdout();
                util.out(buf);
                util.flushStdout();
            }
            util.err("no signature found", .{});
            had_error = 1;
            continue;
        }
        const res = checkSignature(buf[0..sp], buf[sp..]);
        if (flags & FLAG_OMIT_STATUS == 0) printSignatureBuffer(res, flags);
        if (!res.ok) {
            had_error = 1;
            continue;
        }
        if (format) |f| {
            // minimal pretty_print_ref support for common atoms
            util.outf("{s}\n", .{expandFormat(f, name, oid)});
        }
    }
    return had_error;
}

fn expandFormat(f: []const u8, name: []const u8, oid: [20]u8) []const u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (i < f.len) {
        if (util.startsWith(f[i..], "%(refname)")) {
            util.bufAppend(&b, name);
            i += 10;
        } else if (util.startsWith(f[i..], "%(objectname)")) {
            util.bufAppend(&b, &@import("../hash.zig").hex(oid));
            i += 13;
        } else if (util.startsWith(f[i..], "%%")) {
            util.bufByte(&b, '%');
            i += 2;
        } else {
            util.bufByte(&b, f[i]);
            i += 1;
        }
    }
    return b.items;
}

/// Split a commit buffer into payload (without gpgsig headers) and signature.
fn parseBufferSignedByHeader(buf: []const u8, payload: *util.Buf, sig: *util.Buf) bool {
    const hdr = "gpgsig";
    var in_sig = false;
    var saw = false;
    var other = false;
    var pos: usize = 0;
    while (pos < buf.len) {
        const nl = std.mem.indexOfScalarPos(u8, buf, pos, '\n');
        const next = if (nl) |x| x + 1 else buf.len;
        const line = buf[pos..next];
        var s: ?[]const u8 = null;
        if (in_sig and line.len > 0 and line[0] == ' ') {
            s = line[1..];
        } else if (util.startsWith(line, hdr) and line.len > hdr.len and line[hdr.len] == ' ') {
            s = line[hdr.len + 1 ..];
            other = false;
        } else if (util.startsWith(line, "gpgsig")) {
            other = true;
        } else if (other and (line.len == 0 or line[0] != ' ')) {
            other = false;
        }
        if (s) |x| {
            util.bufAppend(sig, x);
            saw = true;
            in_sig = true;
        } else {
            if (line.len > 0 and line[0] == '\n') {
                // the rest is the message
                if (!other) util.bufAppend(payload, buf[pos..]);
                break;
            }
            in_sig = false;
            if (!other) util.bufAppend(payload, line);
        }
        pos = next;
    }
    return saw;
}

pub fn cmdVerifyCommit(args: []const []const u8) u8 {
    var verbose: i32 = 0;
    var flags: i32 = 0;
    const opts = [_]po.Opt{
        po.counter('v', "verbose", &verbose, "print commit contents"),
        po.bit(0, "raw", &flags, FLAG_RAW, "print raw gpg status output"),
    };
    const rest = po.parse(args[1..], &opts, &commit_usage, .{});
    if (rest.len == 0) po.usageWithOptions(&commit_usage, &opts);
    if (verbose != 0) flags |= FLAG_VERBOSE;
    os.ignoreSigpipe();
    const odb = repo_mod.repo().odb();
    var had_error: u8 = 0;
    for (rest) |name| {
        const oid = revparse.getOid(name) orelse {
            util.err("commit '{s}' not found.", .{name});
            had_error = 1;
            continue;
        };
        const obj = odb.read(oid) orelse {
            util.err("{s}: unable to read file.", .{name});
            had_error = 1;
            continue;
        };
        if (obj.typ != .commit) {
            util.err("{s}: cannot verify a non-commit object of type {s}.", .{ name, obj.typ.name() });
            had_error = 1;
            continue;
        }
        var payload: util.Buf = .empty;
        var sig: util.Buf = .empty;
        if (!parseBufferSignedByHeader(obj.data, &payload, &sig)) {
            had_error = 1;
            continue;
        }
        const res = checkSignature(payload.items, sig.items);
        printSignatureBuffer(res, flags);
        if (!res.ok) had_error = 1;
    }
    return had_error;
}
