//! GIT_TRACE* support (port of trace.c, subset).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");

pub const Key = struct {
    name: []const u8,
    initialized: bool = false,
    fd: c_int = 0,
};

pub var default_key = Key{ .name = "GIT_TRACE" };
pub var setup_key = Key{ .name = "GIT_TRACE_SETUP" };
pub var perf_key = Key{ .name = "GIT_TRACE_PERFORMANCE" };
pub var packet_key = Key{ .name = "GIT_TRACE_PACKET" };
var bare_key = Key{ .name = "GIT_TRACE_BARE" };

fn getFd(key: *Key) c_int {
    if (key.initialized) return key.fd;
    key.initialized = true;
    const t = os.getenv(key.name) orelse "";
    if (t.len == 0 or util.eql(t, "0") or std.ascii.eqlIgnoreCase(t, "false")) {
        key.fd = 0;
    } else if (util.eql(t, "1") or std.ascii.eqlIgnoreCase(t, "true")) {
        key.fd = 2;
    } else if (t.len == 1 and std.ascii.isDigit(t[0])) {
        key.fd = t[0] - '0';
    } else if (t[0] == '/') {
        const fd = os.openFile(t, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o666);
        if (fd < 0) {
            util.warn("could not open '{s}' for tracing: {s}", .{ t, os.lastErr() });
            key.fd = 0;
        } else key.fd = fd;
    } else {
        util.warn("unknown trace value for '{s}': {s}\n         If you want to trace into a file, then please set {s}\n         to an absolute pathname (starting with /)", .{ key.name, t, key.name });
        key.fd = 0;
    }
    return key.fd;
}

pub fn want(key: *Key) bool {
    return getFd(key) != 0;
}

fn prepare(b: *util.Buf, file: []const u8, line: u32) void {
    if (want(&bare_key)) return;
    const us = os.nowMicros();
    const secs = @divFloor(us, 1000000);
    const tm = os.localtime(secs);
    util.bufPrint(b, "{d:0>2}:{d:0>2}:{d:0>2}.{d:0>6} {s}:{d}", .{
        @as(u32, @intCast(tm.hour)), @as(u32, @intCast(tm.min)), @as(u32, @intCast(tm.sec)),
        @as(u64, @intCast(@mod(us, 1000000))), file, line,
    });
    while (b.items.len < 40) util.bufByte(b, ' ');
}

fn emit(key: *Key, b: *util.Buf) void {
    if (b.items.len == 0 or b.items[b.items.len - 1] != '\n') util.bufByte(b, '\n');
    os.writeAll(getFd(key), b.items) catch {
        util.warn("unable to write trace for {s}: {s}", .{ key.name, os.lastErr() });
        key.fd = 0;
    };
}

/// trace_printf_key()
pub fn printf(key: *Key, file: []const u8, line: u32, comptime f: []const u8, args: anytype) void {
    if (!want(key)) return;
    var b: util.Buf = .empty;
    prepare(&b, file, line);
    util.bufPrint(&b, f, args);
    emit(key, &b);
}

/// trace_argv_printf(): "<prefix> 'arg1' 'arg2'..." using sq_quote_argv.
pub fn argv(file: []const u8, line: u32, prefix: []const u8, args: []const []const u8) void {
    if (!want(&default_key)) return;
    var b: util.Buf = .empty;
    prepare(&b, file, line);
    util.bufAppend(&b, prefix);
    for (args) |a| {
        util.bufByte(&b, ' ');
        quoteArg(&b, a);
    }
    emit(&default_key, &b);
}

/// sq_quote_argv_pretty style quoting of one argument.
pub fn quoteArg(b: *util.Buf, a: []const u8) void {
    if (a.len == 0) {
        util.bufAppend(b, "''");
        return;
    }
    var plain = true;
    for (a) |ch| {
        if (!(std.ascii.isAlphanumeric(ch) or std.mem.indexOfScalar(u8, "+,-./:=@_^", ch) != null)) {
            plain = false;
            break;
        }
    }
    if (plain) {
        util.bufAppend(b, a);
    } else {
        util.sqQuote(b, a);
    }
}

/// quote_crnl(): escape CR/LF/backslash in trace output.
pub fn quoteCrnl(s: []const u8) []const u8 {
    if (std.mem.indexOfAny(u8, s, "\r\n\\") == null) return s;
    var b: util.Buf = .empty;
    for (s) |ch| switch (ch) {
        '\\' => util.bufAppend(&b, "\\\\"),
        '\n' => util.bufAppend(&b, "\\n"),
        '\r' => util.bufAppend(&b, "\\r"),
        else => util.bufByte(&b, ch),
    };
    return b.items;
}
