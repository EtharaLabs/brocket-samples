//! Parsing and formatting of commit, tree and tag objects.

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

pub const Commit = struct {
    oid: Oid,
    tree: Oid,
    parents: []Oid,
    author: []const u8,
    committer: []const u8,
    encoding: ?[]const u8 = null,
    message: []const u8,
    raw: []const u8,
    /// header section (before blank line)
    headers: []const u8,

    pub fn commitTime(self: *const Commit) i64 {
        return identTime(self.committer);
    }
    pub fn authorTime(self: *const Commit) i64 {
        return identTime(self.author);
    }
};

pub fn identTime(line: []const u8) i64 {
    const gt = std.mem.lastIndexOfScalar(u8, line, '>') orelse return 0;
    var it = std.mem.tokenizeScalar(u8, line[gt + 1 ..], ' ');
    const t = it.next() orelse return 0;
    return std.fmt.parseInt(i64, t, 10) catch 0;
}

pub fn parseCommit(oid: Oid, data: []const u8) ?Commit {
    var c = Commit{ .oid = oid, .tree = hash.zero, .parents = &.{}, .author = "", .committer = "", .message = "", .raw = data, .headers = "" };
    var parents: std.ArrayList(Oid) = .empty;
    var pos: usize = 0;
    var have_tree = false;
    while (pos < data.len) {
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n') orelse data.len;
        const line = data[pos..nl];
        if (line.len == 0) {
            c.headers = data[0..pos];
            c.message = if (nl + 1 <= data.len) data[nl + 1 ..] else "";
            break;
        }
        if (util.skipPrefix(line, "tree ")) |h| {
            c.tree = hash.fromHex(h) orelse return null;
            have_tree = true;
        } else if (util.skipPrefix(line, "parent ")) |h| {
            parents.append(gpa, hash.fromHex(h) orelse return null) catch util.oom();
        } else if (util.skipPrefix(line, "author ")) |a| {
            c.author = a;
        } else if (util.skipPrefix(line, "committer ")) |a| {
            c.committer = a;
        } else if (util.skipPrefix(line, "encoding ")) |e| {
            c.encoding = e;
        }
        pos = nl + 1;
        if (pos >= data.len) {
            c.headers = data;
        }
    }
    if (!have_tree) return null;
    c.parents = parents.items;
    return c;
}

var commit_cache: hash.OidMap(*Commit) = .empty;

/// Read and parse a commit (cached). Applies grafts/replace? (not supported)
pub fn readCommit(oid: Oid) ?*Commit {
    if (commit_cache.get(oid)) |c| return c;
    const obj = repo_mod.repo().odb().read(oid) orelse return null;
    if (obj.typ != .commit) return null;
    const parsed = parseCommit(oid, obj.data) orelse return null;
    const c = gpa.create(Commit) catch util.oom();
    c.* = parsed;
    applyGrafts(c);
    commit_cache.put(gpa, oid, c) catch util.oom();
    return c;
}

/// set by `git replace --convert-graft-file` (commit.c no_graft_file_deprecated_advice)
pub var no_graft_file_deprecated_advice = false;
var grafts_loaded = false;
var grafts: hash.OidMap([]Oid) = .empty;

fn applyGrafts(c: *Commit) void {
    if (!grafts_loaded) {
        grafts_loaded = true;
        loadShallowAndGrafts();
    }
    if (grafts.get(c.oid)) |p| c.parents = p;
}

fn loadShallowAndGrafts() void {
    const r = repo_mod.repo();
    const os = @import("os.zig");
    const spath: ?[]const u8 = if (os.getenv("GIT_SHALLOW_FILE")) |p| (if (p.len == 0) null else p) else r.commonPath("shallow");
    if (spath) |sp| {
        if (os.readFile(sp)) |data| {
            var it = std.mem.splitScalar(u8, data, '\n');
            while (it.next()) |line| {
                const o = hash.fromHex(line) orelse continue;
                grafts.put(gpa, o, &.{}) catch util.oom();
                shallow_set.put(gpa, o, {}) catch util.oom();
            }
        }
    }
    const gpath = os.getenv("GIT_GRAFT_FILE") orelse r.commonPath("info/grafts");
    if (os.readFile(gpath)) |data| {
        if (!no_graft_file_deprecated_advice and @import("advice.zig").enabled("graftFileDeprecated"))
            @import("advice.zig").advise("Support for <GIT_DIR>/info/grafts is deprecated\nand will be removed in a future Git version.\n\nPlease use \"git replace --convert-graft-file\"\nto convert the grafts into replace refs.\n\nTurn this message off by running\n\"git config set advice.graftFileDeprecated false\"");
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line| {
            if (line.len == 0 or line[0] == '#') continue;
            var toks = std.mem.tokenizeScalar(u8, line, ' ');
            const first = hash.fromHex(toks.next() orelse continue) orelse continue;
            var ps: std.ArrayList(Oid) = .empty;
            while (toks.next()) |t| {
                if (hash.fromHex(t)) |p| ps.append(gpa, p) catch util.oom();
            }
            grafts.put(gpa, first, ps.items) catch util.oom();
        }
    }
}

var shallow_set: hash.OidMap(void) = .empty;

fn ensureGrafts() void {
    if (!grafts_loaded) {
        grafts_loaded = true;
        loadShallowAndGrafts();
    }
}

/// register_shallow(): mark `oid` as a shallow boundary for this process.
pub fn registerShallow(oid: Oid) void {
    ensureGrafts();
    grafts.put(gpa, oid, &.{}) catch util.oom();
    shallow_set.put(gpa, oid, {}) catch util.oom();
    if (commit_cache.get(oid)) |c| c.parents = &.{};
}

/// unregister_shallow()
pub fn unregisterShallow(oid: Oid) bool {
    ensureGrafts();
    if (!shallow_set.contains(oid)) return false;
    _ = shallow_set.remove(oid);
    _ = grafts.remove(oid);
    if (commit_cache.get(oid)) |c| {
        if (repo_mod.repo().odb().read(oid)) |obj| {
            if (parseCommit(oid, obj.data)) |p| c.parents = p.parents;
        }
    }
    return true;
}

/// Sorted list of shallow boundary commits (registered + from the shallow file).
pub fn shallowList() []Oid {
    ensureGrafts();
    var out: std.ArrayList(Oid) = .empty;
    var it = shallow_set.keyIterator();
    while (it.next()) |k| out.append(gpa, k.*) catch util.oom();
    std.mem.sort(Oid, out.items, {}, struct {
        fn lt(_: void, a: Oid, b: Oid) bool {
            return std.mem.order(u8, &a, &b) == .lt;
        }
    }.lt);
    return out.items;
}

pub fn isShallow(oid: Oid) bool {
    if (!grafts_loaded) {
        grafts_loaded = true;
        loadShallowAndGrafts();
    }
    if (grafts.get(oid)) |p| return p.len == 0;
    return false;
}

pub fn resetCaches() void {
    commit_cache = .empty;
    grafts_loaded = false;
    grafts = .empty;
    shallow_set = .empty;
}

// ---------------- trees ----------------

pub const TreeEntry = struct {
    mode: u32,
    name: []const u8,
    oid: Oid,

    pub fn isDir(self: TreeEntry) bool {
        return self.mode == 0o40000;
    }
};

pub const TreeIter = struct {
    data: []const u8,
    pos: usize = 0,

    pub fn next(self: *TreeIter) ?TreeEntry {
        if (self.pos >= self.data.len) return null;
        const sp = std.mem.indexOfScalarPos(u8, self.data, self.pos, ' ') orelse return null;
        const nul = std.mem.indexOfScalarPos(u8, self.data, sp, 0) orelse return null;
        if (nul + 21 > self.data.len) return null;
        const mode = std.fmt.parseInt(u32, self.data[self.pos..sp], 8) catch return null;
        const e = TreeEntry{ .mode = mode, .name = self.data[sp + 1 .. nul], .oid = self.data[nul + 1 ..][0..20].* };
        self.pos = nul + 21;
        return e;
    }
};

pub fn readTree(oid: Oid) ?[]TreeEntry {
    const obj = repo_mod.repo().odb().read(oid) orelse return null;
    if (obj.typ != .tree) return null;
    return parseTree(obj.data);
}

pub fn parseTree(data: []const u8) []TreeEntry {
    var list: std.ArrayList(TreeEntry) = .empty;
    var it = TreeIter{ .data = data };
    while (it.next()) |e| list.append(gpa, e) catch util.oom();
    return list.items;
}

/// Compare names as git does for tree ordering (directories sort as name + '/').
pub fn baseNameCompare(n1: []const u8, mode1: u32, n2: []const u8, mode2: u32) std.math.Order {
    const len = @min(n1.len, n2.len);
    const o = std.mem.order(u8, n1[0..len], n2[0..len]);
    if (o != .eq) return o;
    const c1: u8 = if (n1.len > len) n1[len] else if (mode1 & 0o170000 == 0o040000) '/' else 0;
    const c2: u8 = if (n2.len > len) n2[len] else if (mode2 & 0o170000 == 0o040000) '/' else 0;
    return std.math.order(c1, c2);
}

pub fn sortTreeEntries(entries: []TreeEntry) void {
    std.mem.sort(TreeEntry, entries, {}, struct {
        fn lt(_: void, a: TreeEntry, b: TreeEntry) bool {
            return baseNameCompare(a.name, a.mode, b.name, b.mode) == .lt;
        }
    }.lt);
}

pub fn formatTree(entries: []const TreeEntry) []u8 {
    var b: util.Buf = .empty;
    for (entries) |e| {
        util.bufPrint(&b, "{o} {s}\x00", .{ e.mode, e.name });
        util.bufAppend(&b, &e.oid);
    }
    return b.items;
}

pub fn writeTree(entries: []TreeEntry) Oid {
    sortTreeEntries(entries);
    return repo_mod.repo().odb().write(.tree, formatTree(entries));
}

/// Look up a path within a tree. Returns entry (mode + oid).
pub fn treeLookup(tree: Oid, path: []const u8) ?TreeEntry {
    var cur = tree;
    var rest = path;
    while (rest.len > 0 and rest[rest.len - 1] == '/') rest = rest[0 .. rest.len - 1];
    if (rest.len == 0) return .{ .mode = 0o40000, .name = "", .oid = tree };
    while (true) {
        const sl = std.mem.indexOfScalar(u8, rest, '/');
        const comp = if (sl) |s| rest[0..s] else rest;
        const entries = readTree(cur) orelse return null;
        var found: ?TreeEntry = null;
        for (entries) |e| {
            if (util.eql(e.name, comp)) {
                found = e;
                break;
            }
        }
        const f = found orelse return null;
        if (sl) |s| {
            if (!f.isDir()) return null;
            cur = f.oid;
            rest = rest[s + 1 ..];
            if (rest.len == 0) return f;
        } else return f;
    }
}

/// Recursively list all blobs in a tree with full paths.
pub const FlatEntry = struct { path: []const u8, mode: u32, oid: Oid };

pub fn flattenTree(tree: Oid, prefix: []const u8, out: *std.ArrayList(FlatEntry)) void {
    const entries = readTree(tree) orelse return;
    for (entries) |e| {
        const p = if (prefix.len == 0) util.dupe(e.name) else util.concat(&.{ prefix, "/", e.name });
        if (e.isDir()) {
            flattenTree(e.oid, p, out);
        } else {
            out.append(gpa, .{ .path = p, .mode = e.mode, .oid = e.oid }) catch util.oom();
        }
    }
}

// ---------------- tags ----------------

pub const Tag = struct {
    object: Oid,
    typ: odb_mod.ObjType,
    tag: []const u8,
    tagger: ?[]const u8,
    message: []const u8,
    headers: []const u8,
};

pub fn parseTag(data: []const u8) ?Tag {
    var t = Tag{ .object = hash.zero, .typ = .none, .tag = "", .tagger = null, .message = "", .headers = data };
    var pos: usize = 0;
    var have_obj = false;
    while (pos < data.len) {
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n') orelse data.len;
        const line = data[pos..nl];
        if (line.len == 0) {
            t.headers = data[0..pos];
            t.message = if (nl + 1 <= data.len) data[nl + 1 ..] else "";
            break;
        }
        if (util.skipPrefix(line, "object ")) |h| {
            t.object = hash.fromHex(h) orelse return null;
            have_obj = true;
        } else if (util.skipPrefix(line, "type ")) |ty| {
            t.typ = odb_mod.ObjType.fromName(ty) orelse return null;
        } else if (util.skipPrefix(line, "tag ")) |n| {
            t.tag = n;
        } else if (util.skipPrefix(line, "tagger ")) |n| {
            t.tagger = n;
        }
        pos = nl + 1;
    }
    if (!have_obj) return null;
    return t;
}

/// Peel an object through tags. Returns final object id and type.
pub fn peel(oid: Oid) ?struct { oid: Oid, typ: odb_mod.ObjType } {
    var cur = oid;
    var depth: u32 = 0;
    while (depth < 100) : (depth += 1) {
        const obj = repo_mod.repo().odb().read(cur) orelse return null;
        if (obj.typ != .tag) return .{ .oid = cur, .typ = obj.typ };
        const t = parseTag(obj.data) orelse return null;
        cur = t.object;
    }
    return null;
}

/// Peel to a specific type (commit or tree). Commit -> tree supported.
pub fn peelTo(oid: Oid, want: odb_mod.ObjType) ?Oid {
    const p = peel(oid) orelse return null;
    if (p.typ == want) return p.oid;
    if (want == .tree and p.typ == .commit) {
        const c = readCommit(p.oid) orelse return null;
        return c.tree;
    }
    return null;
}

pub fn typeOf(oid: Oid) ?odb_mod.ObjType {
    const obj = repo_mod.repo().odb().read(oid) orelse return null;
    return obj.typ;
}
