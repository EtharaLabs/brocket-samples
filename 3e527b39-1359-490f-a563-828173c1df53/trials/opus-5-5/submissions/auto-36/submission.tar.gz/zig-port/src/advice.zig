//! Port of advice.c

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");

fn globallyEnabled() bool {
    if (os.getenv("GIT_ADVICE")) |v| return config.parseBool(v) orelse true;
    return true;
}

/// Is advice `key` (e.g. "defaultBranchName") enabled?
pub fn enabled(key: []const u8) bool {
    if (!globallyEnabled()) return false;
    const v = repo_mod.cfg.getBool(util.lower(util.concat(&.{ "advice.", key })));
    return v orelse true;
}

/// Print a hint block to stderr.
fn adviceColor(hint: bool) []const u8 {
    const color = @import("color.zig");
    var cb: color.ColorBool = .unknown;
    if (repo_mod.cfg.getEntry("color.advice")) |e| cb = color.configColorBool("color.advice", e.value);
    if (cb == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| cb = color.configColorBool("color.ui", e.value);
    }
    if (!color.wantColorBool(cb, os.isatty(2))) return "";
    const slot: []const u8 = if (hint) "color.advice.hint" else "color.advice.reset";
    if (repo_mod.cfg.get(slot)) |v| {
        if (color.parseColor(v)) |c| return c;
    }
    return if (hint) "\x1b[33m" else "\x1b[m";
}

/// Print a hint block to stderr (vadvise()).
pub fn advise(msg: []const u8) void {
    var b: util.Buf = .empty;
    const hc = adviceColor(true);
    const rc = adviceColor(false);
    var cp: usize = 0;
    while (cp < msg.len) {
        const np = std.mem.indexOfScalarPos(u8, msg, cp, '\n') orelse msg.len;
        util.bufPrint(&b, "{s}hint:{s}{s}{s}\n", .{ hc, if (np == cp) "" else " ", msg[cp..np], rc });
        cp = if (np < msg.len) np + 1 else np;
    }
    util.ewrite(b.items);
}

pub fn adviseIfEnabled(key: []const u8, msg: []const u8) void {
    if (!enabled(key)) return;
    const configured = repo_mod.cfg.getBool(util.lower(util.concat(&.{ "advice.", key }))) != null;
    if (configured) {
        advise(msg);
    } else {
        advise(util.concat(&.{ msg, "\nDisable this message with \"git config set advice.", key, " false\"" }));
    }
}

/// error_resolve_conflict (advice.c)
pub fn errorResolveConflict(me: []const u8) void {
    if (std.mem.eql(u8, me, "cherry-pick"))
        util.err("Cherry-picking is not possible because you have unmerged files.", .{})
    else if (std.mem.eql(u8, me, "commit"))
        util.err("Committing is not possible because you have unmerged files.", .{})
    else if (std.mem.eql(u8, me, "merge"))
        util.err("Merging is not possible because you have unmerged files.", .{})
    else if (std.mem.eql(u8, me, "pull"))
        util.err("Pulling is not possible because you have unmerged files.", .{})
    else if (std.mem.eql(u8, me, "revert"))
        util.err("Reverting is not possible because you have unmerged files.", .{})
    else if (std.mem.eql(u8, me, "rebase"))
        util.err("Rebasing is not possible because you have unmerged files.", .{});
    if (enabled("resolveConflict"))
        advise("Fix them up in the work tree, and then use 'git add/rm <file>'\nas appropriate to mark resolution and make a commit.");
}

pub fn dieResolveConflict(me: []const u8) noreturn {
    errorResolveConflict(me);
    util.die("Exiting because of an unresolved conflict.", .{});
}

pub fn dieConcludeMerge() noreturn {
    util.err("You have not concluded your merge (MERGE_HEAD exists).", .{});
    if (enabled("resolveConflict")) advise("Please, commit your changes before merging.");
    util.die("Exiting because of unfinished merge.", .{});
}
