//! git ls-files, git ls-tree

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const dir_mod = @import("../dir.zig");
const convert = @import("../convert.zig");
const revparse = @import("../revparse.zig");
const objects = @import("../objects.zig");
const hash = @import("../hash.zig");
const proc = @import("../proc.zig");
const wtstatus = @import("../wtstatus.zig");
const gpa = util.gpa;

const Oid = hash.Oid;
const Entry = index_mod.Entry;

fn isGitlink(mode: u32) bool {
    return mode & 0o170000 == 0o160000;
}
fn isReg(mode: u32) bool {
    return mode & 0o170000 == 0o100000;
}
fn isDirMode(mode: u32) bool {
    return mode & 0o170000 == 0o040000;
}

fn typeName(mode: u32) []const u8 {
    if (isDirMode(mode)) return "tree";
    if (isGitlink(mode)) return "commit";
    return "blob";
}

/// abbrev semantic of OPT__ABBREV: 0 = full, <0 = default, n = min length n
fn abbrevHex(oid: Oid, a: i32) []const u8 {
    if (a == 0 or a >= 40) return hash.hexAlloc(oid);
    if (a < 0) return revparse.abbrev(oid, 0);
    return revparse.abbrev(oid, @intCast(a));
}

fn fixAbbrev(a: i32) i32 {
    if (a > 0 and a < 4) return 4;
    if (a > 40) return 40;
    return a;
}

fn objectSize(b: *util.Buf, oid: Oid, mode: u32, padded: bool) void {
    var s: []const u8 = "-";
    if (!isDirMode(mode) and !isGitlink(mode)) {
        const obj = repo_mod.repo().odb().read(oid) orelse
            util.die("could not get object info about '{s}'", .{hash.hexAlloc(oid)});
        s = util.fmt("{d}", .{obj.data.len});
    }
    if (padded and s.len < 7) b.appendNTimes(gpa, ' ', 7 - s.len) catch util.oom();
    util.bufAppend(b, s);
}

fn hexVal(ch: u8) ?u8 {
    return std.fmt.charToDigit(ch, 16) catch null;
}

/// strbuf_expand_literal(): returns bytes consumed (0 if not a literal)
fn expandLiteral(b: *util.Buf, f: []const u8) usize {
    if (f.len == 0) return 0;
    switch (f[0]) {
        'n' => {
            util.bufByte(b, '\n');
            return 1;
        },
        'x' => {
            if (f.len < 3) return 0;
            const h = hexVal(f[1]) orelse return 0;
            const l = hexVal(f[2]) orelse return 0;
            util.bufByte(b, h * 16 + l);
            return 3;
        },
        else => return 0,
    }
}

fn badFormat(f: []const u8, command: []const u8) noreturn {
    if (f.len == 0 or f[0] != '(')
        util.die("bad {s} format: element '{s}' does not start with '('", .{ command, f });
    const end = std.mem.indexOfScalarPos(u8, f, 1, ')') orelse
        util.die("bad {s} format: element '{s}' does not end in ')'", .{ command, f });
    util.die("bad {s} format: %{s}", .{ command, f[0 .. end + 1] });
}

// ===================================================================
// ls-files

const ls_files_usage = [_][]const u8{"git ls-files [<options>] [<file>...]"};

var abbrev: i32 = 0;
var show_deleted = false;
var show_cached = false;
var show_others = false;
var show_stage = false;
var show_unmerged = false;
var show_resolve_undo = false;
var show_modified = false;
var show_killed = false;
var show_valid_bit = false;
var show_fsmonitor_bit = false;
var line_terminator: i32 = '\n';
var debug_mode = false;
var show_eol = false;
var recurse_submodules = false;
/// --recurse-submodules: path of this repository inside the top-level superproject
/// (with trailing slash), the top-level cwd prefix, and our own arguments.
var super_prefix: []const u8 = "";
var top_prefix: []const u8 = "";
var saved_args: []const []const u8 = &.{};
var skipping_duplicates = false;
var show_sparse_dirs = false;
var show_tag = false;

var prefix: []const u8 = "";
var prefix_len: i32 = 0;
var max_prefix_len: usize = 0;
var pathspec: pathspec_mod.Pathspec = .{};
var error_unmatch = false;
var ps_matched: ?[]u8 = null;
var with_tree: ?[]const u8 = null;
var exc_given = false;
var format: ?[]const u8 = null;
var exclude_per_dir: ?[]const u8 = null;
var exclude_list: std.ArrayList([]const u8) = .empty;
var dirflags: i32 = 0;

const DIR_SHOW_IGNORED: i32 = 1;
const DIR_SHOW_OTHER_DIRECTORIES: i32 = 2;
const DIR_HIDE_EMPTY_DIRECTORIES: i32 = 4;

var dir: dir_mod.Dir = .{};

var tag_cached: []const u8 = "";
var tag_unmerged: []const u8 = "";
var tag_removed: []const u8 = "";
var tag_other: []const u8 = "";
var tag_killed: []const u8 = "";
var tag_modified: []const u8 = "";
var tag_skip_worktree: []const u8 = "";
var tag_resolve_undo: []const u8 = "";

fn optExclude(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    exc_given = true;
    exclude_list.append(gpa, arg.?) catch util.oom();
}

fn optExcludeFrom(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    exc_given = true;
    dir.addExcludesFile(arg.?);
}

fn optExcludeStandard(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    exc_given = true;
    dir.setupStandardExcludes();
}

fn writeEolinfo(idx: *index_mod.Index, ce: ?*const Entry, path: []const u8) void {
    if (!show_eol) return;
    var i_txt: []const u8 = "";
    var w_txt: []const u8 = "";
    const a_txt = convert.getConvertAttrAscii(path);
    if (ce) |e| {
        if (isReg(e.mode)) i_txt = convert.getCachedConvertStatsAscii(idx, e.path);
    }
    if (os.lstatPath(path)) |st| {
        if (st.isReg()) w_txt = convert.getWtConvertStatsAscii(path);
    }
    util.outf("i/{s: <5} w/{s: <5} attr/{s: <17}\t", .{ i_txt, w_txt, a_txt });
}

fn relName(name: []const u8) []const u8 {
    if (prefix_len != 0) return util.relativePath(name, prefix);
    return name;
}

fn writeName(name: []const u8) void {
    const rel = relName(name);
    if (line_terminator != 0) {
        util.out(util.cquote(rel));
        util.out("\n");
    } else {
        util.out(rel);
        util.out("\x00");
    }
}

fn writeNameToBuf(b: *util.Buf, name: []const u8) void {
    const rel = relName(name);
    if (line_terminator != 0) {
        if (util.needsQuote(rel)) {
            util.bufByte(b, '"');
            util.cquoteInto(b, rel);
            util.bufByte(b, '"');
        } else util.bufAppend(b, rel);
    } else util.bufAppend(b, rel);
}

fn getTag(ce: *const Entry, tag: []const u8) []const u8 {
    if (tag.len > 0 and ((show_valid_bit and ce.flags & index_mod.CE_VALID != 0) or (show_fsmonitor_bit and ce.fsmonitor_valid))) {
        var alt = gpa.alloc(u8, tag.len) catch util.oom();
        @memcpy(alt, tag);
        if (std.ascii.isAlphabetic(tag[0])) {
            alt[0] = std.ascii.toLower(tag[0]);
        } else if (tag[0] == '?') {
            alt[0] = '!';
        } else {
            return util.concat(&.{ "v", tag[0..1], " " });
        }
        return alt;
    }
    return tag;
}

fn printDebug(ce: *const Entry) void {
    if (!debug_mode) return;
    util.outf("  ctime: {d}:{d}\n", .{ ce.ctime_s, ce.ctime_ns });
    util.outf("  mtime: {d}:{d}\n", .{ ce.mtime_s, ce.mtime_ns });
    util.outf("  dev: {d}\tino: {d}\n", .{ ce.dev, ce.ino });
    util.outf("  uid: {d}\tgid: {d}\n", .{ ce.uid, ce.gid });
    // in-core ce_flags: stage bits (<<12) | assume-valid etc.
    var flags: u32 = @as(u32, ce.flags & (index_mod.CE_STAGEMASK | index_mod.CE_VALID));
    if (ce.ext_flags & index_mod.CE_INTENT_TO_ADD != 0) flags |= 1 << 29;
    if (ce.ext_flags & index_mod.CE_SKIP_WORKTREE != 0) flags |= 1 << 30;
    util.outf("  size: {d}\tflags: {x}\n", .{ ce.size, flags });
}

fn showDirEntry(idx: *index_mod.Index, tag: []const u8, name: []const u8) void {
    if (max_prefix_len > name.len)
        util.die("git ls-files: internal error - directory entry not superset of prefix", .{});
    if (ps_matched) |seen| {
        const trailing = name.len > 0 and name[name.len - 1] == '/';
        const n = if (trailing) name[0 .. name.len - 1] else name;
        _ = pathspec.matchFlags(n, max_prefix_len, seen, if (trailing) pathspec_mod.DO_MATCH_DIRECTORY else 0);
    }
    util.out(tag);
    writeEolinfo(idx, null, name);
    writeName(name);
}

fn showOtherFiles(idx: *index_mod.Index) void {
    for (dir.entries.items) |e| {
        if (!dir_mod.indexNameIsOther(idx, e.name)) continue;
        showDirEntry(idx, tag_other, e.name);
    }
}

fn showKilledFiles(idx: *index_mod.Index) void {
    const ents = idx.entries.items;
    for (dir.entries.items) |e| {
        const name = e.name;
        var killed = false;
        var cp: usize = 0;
        while (cp < name.len) {
            const sp_rel = std.mem.indexOfScalarPos(u8, name, cp, '/');
            if (sp_rel == null) {
                var p: usize = switch (idx.pos(name, 0)) {
                    .found => |x| x,
                    .missing => |x| x,
                };
                while (p < ents.len and ents[p].stage() != 0) p += 1;
                if (p >= ents.len) break;
                const cn = ents[p].path;
                if (name.len < cn.len and std.mem.startsWith(u8, cn, name) and cn[name.len] == '/')
                    killed = true;
                break;
            }
            const sp = sp_rel.?;
            switch (idx.pos(name[0..sp], 0)) {
                .found => {
                    killed = true;
                    break;
                },
                .missing => {},
            }
            cp = sp + 1;
        }
        if (killed) showDirEntry(idx, tag_killed, name);
    }
}

fn showCeFmt(idx: *index_mod.Index, ce: *const Entry, fmt0: []const u8, fullname: []const u8) void {
    var b: util.Buf = .empty;
    var f = fmt0;
    while (f.len > 0) {
        const pct = std.mem.indexOfScalar(u8, f, '%') orelse {
            util.bufAppend(&b, f);
            break;
        };
        util.bufAppend(&b, f[0..pct]);
        f = f[pct + 1 ..];
        if (util.skipPrefix(f, "%")) |r| {
            util.bufByte(&b, '%');
            f = r;
            continue;
        }
        const lit = expandLiteral(&b, f);
        if (lit != 0) {
            f = f[lit..];
        } else if (util.skipPrefix(f, "(objectmode)")) |r| {
            util.bufPrint(&b, "{o:0>6}", .{ce.mode});
            f = r;
        } else if (util.skipPrefix(f, "(objectname)")) |r| {
            util.bufAppend(&b, abbrevHex(ce.oid, abbrev));
            f = r;
        } else if (util.skipPrefix(f, "(objecttype)")) |r| {
            util.bufAppend(&b, typeName(ce.mode));
            f = r;
        } else if (util.skipPrefix(f, "(objectsize:padded)")) |r| {
            objectSize(&b, ce.oid, ce.mode, true);
            f = r;
        } else if (util.skipPrefix(f, "(objectsize)")) |r| {
            objectSize(&b, ce.oid, ce.mode, false);
            f = r;
        } else if (util.skipPrefix(f, "(stage)")) |r| {
            util.bufPrint(&b, "{d}", .{ce.stage()});
            f = r;
        } else if (util.skipPrefix(f, "(eolinfo:index)")) |r| {
            if (isReg(ce.mode)) util.bufAppend(&b, convert.getCachedConvertStatsAscii(idx, ce.path));
            f = r;
        } else if (util.skipPrefix(f, "(eolinfo:worktree)")) |r| {
            if (os.lstatPath(ce.path)) |st| {
                if (st.isReg()) util.bufAppend(&b, convert.getWtConvertStatsAscii(ce.path));
            }
            f = r;
        } else if (util.skipPrefix(f, "(eolattr)")) |r| {
            util.bufAppend(&b, convert.getConvertAttrAscii(ce.path));
            f = r;
        } else if (util.skipPrefix(f, "(path)")) |r| {
            writeNameToBuf(&b, fullname);
            f = r;
        } else badFormat(f, "ls-files");
    }
    util.bufByte(&b, @intCast(line_terminator));
    util.out(b.items);
}

const sub_unset_env = [_][]const u8{
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CONFIG",     "GIT_OBJECT_DIRECTORY", "GIT_DIR",
    "GIT_WORK_TREE",                    "GIT_IMPLICIT_WORK_TREE", "GIT_GRAFT_FILE", "GIT_INDEX_FILE",
    "GIT_NO_REPLACE_OBJECTS",           "GIT_REPLACE_REF_BASE",   "GIT_PREFIX",     "GIT_SHALLOW_FILE",
    "GIT_COMMON_DIR",
};

/// show_submodule(): list the files of an active, populated submodule.
fn showSubmodule(path: []const u8) void {
    if (os.lstatPath(util.concat(&.{ path, "/.git" })) == null) return;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "ls-files") catch util.oom();
    argv.appendSlice(gpa, saved_args) catch util.oom();
    const ch = proc.spawnGit(argv.items, .{
        .cwd = path,
        .unset_env = &sub_unset_env,
        .env = &.{
            .{ "GIT_INTERNAL_LS_FILES_SUPER_PREFIX", util.concat(&.{ super_prefix, path, "/" }) },
            .{ "GIT_INTERNAL_LS_FILES_TOP_PREFIX", top_prefix },
        },
    });
    _ = proc.wait(ch.pid);
}

fn showCe(idx: *index_mod.Index, ce: *const Entry, tag0: []const u8) void {
    if (recurse_submodules and isGitlink(ce.mode) and wtstatus.isSubmoduleActive(ce.path)) {
        showSubmodule(ce.path);
        return;
    }
    const fullname = if (super_prefix.len > 0) util.concat(&.{ super_prefix, ce.path }) else ce.path;
    if (max_prefix_len > fullname.len)
        util.die("git ls-files: internal error - cache entry not superset of prefix", .{});
    if (pathspec.matchFlags(fullname, max_prefix_len, ps_matched, if (isGitlink(ce.mode) or isDirMode(ce.mode)) pathspec_mod.DO_MATCH_DIRECTORY else 0) == 0)
        return;
    if (format) |f| {
        showCeFmt(idx, ce, f, fullname);
        printDebug(ce);
        return;
    }
    const tag = getTag(ce, tag0);
    if (!show_stage) {
        util.out(tag);
    } else {
        util.outf("{s}{o:0>6} {s} {d}\t", .{ tag, ce.mode, abbrevHex(ce.oid, abbrev), ce.stage() });
    }
    writeEolinfo(idx, ce, ce.path);
    writeName(fullname);
    printDebug(ce);
}

fn showRuInfo(idx: *index_mod.Index) void {
    for (idx.reuc.items) |ru| {
        const path = ru.path;
        if (path.len < max_prefix_len) continue;
        if (pathspec.matchFlags(path, max_prefix_len, ps_matched, 0) == 0) continue;
        for (0..3) |i| {
            if (ru.modes[i] == 0) continue;
            util.outf("{s}{o:0>6} {s} {d}\t", .{ tag_resolve_undo, ru.modes[i], abbrevHex(ru.oids[i], abbrev), i + 1 });
            writeName(path);
        }
    }
}

fn ceToDtype(mode: u32) u8 {
    if (isReg(mode)) return dir_mod.DT_REG;
    if (isDirMode(mode) or isGitlink(mode)) return dir_mod.DT_DIR;
    if (mode & 0o170000 == 0o120000) return dir_mod.DT_LNK;
    return dir_mod.DT_UNKNOWN;
}

fn showFiles(idx: *index_mod.Index, ents: []Entry, skip: []bool) void {
    if (show_others or show_killed) {
        if (!show_others) dir.flags.collect_killed_only = true;
        _ = dir.fill(idx, &pathspec);
        if (show_others) showOtherFiles(idx);
        if (show_killed) showKilledFiles(idx);
    }
    if (!(show_cached or show_stage or show_deleted or show_modified)) return;

    var i: usize = 0;
    while (i < ents.len) : (i += 1) {
        const ce = &ents[i];
        const fullname = ce.path;
        var skip_to_next = false;
        blk: {
            if (dir.flags.show_ignored) {
                var dt = ceToDtype(ce.mode);
                if (!dir.isExcluded(fullname, &dt)) break :blk;
            }
            if (skip[i]) break :blk;
            if ((show_cached or show_stage) and (!show_unmerged or ce.stage() != 0)) {
                showCe(idx, ce, if (ce.stage() != 0) tag_unmerged else if (ce.skipWorktree()) tag_skip_worktree else tag_cached);
                if (skipping_duplicates) {
                    skip_to_next = true;
                    break :blk;
                }
            }
            if (!(show_deleted or show_modified)) break :blk;
            if (ce.skipWorktree()) break :blk;
            if (pathspec.items.len == 1 and pathspec.matchFlags(fullname, max_prefix_len, null, if (isGitlink(ce.mode) or isDirMode(ce.mode)) pathspec_mod.DO_MATCH_DIRECTORY else 0) == 0)
                break :blk;
            const st = os.lstatPath(fullname);
            if (st == null) {
                const e = os.errno();
                if (e != os.ENOENT and e != os.ENOTDIR)
                    util.err("cannot lstat '{s}': {s}", .{ fullname, os.strErr(e) });
            }
            if (st == null and show_deleted) {
                showCe(idx, ce, tag_removed);
                if (skipping_duplicates) {
                    skip_to_next = true;
                    break :blk;
                }
            }
            if (show_modified and (st == null or idx.modified(ce, st.?))) {
                showCe(idx, ce, tag_modified);
                if (skipping_duplicates) {
                    skip_to_next = true;
                    break :blk;
                }
            }
        }
        if (skip_to_next) {
            var j = i + 1;
            while (j < ents.len and util.eql(ce.path, ents[j].path)) j += 1;
            i = j - 1;
        }
    }
}

/// overlay_tree_on_index()
fn overlayTree(ents: *std.ArrayList(Entry), tree_name: []const u8, pfx: []const u8) []bool {
    const oid = revparse.getOid(tree_name) orelse util.die("tree-ish {s} not found.", .{tree_name});
    const tree = objects.peelTo(oid, .tree) orelse util.die("bad tree-ish {s}", .{tree_name});
    for (ents.items) |*e| {
        if (e.stage() != 0) e.setStage(3);
    }
    var flat: std.ArrayList(objects.FlatEntry) = .empty;
    objects.flattenTree(tree, "", &flat);
    for (flat.items) |fe| {
        if (pfx.len > 0 and !(std.mem.startsWith(u8, fe.path, pfx) and (fe.path.len == pfx.len or pfx[pfx.len - 1] == '/' or fe.path[pfx.len] == '/')))
            continue;
        var e = Entry{ .path = fe.path, .mode = fe.mode, .oid = fe.oid };
        e.setStage(1);
        // replace an existing stage-1 entry of the same name
        var replaced = false;
        for (ents.items) |*x| {
            if (x.stage() == 1 and util.eql(x.path, fe.path)) {
                x.* = e;
                replaced = true;
                break;
            }
        }
        if (!replaced) ents.append(gpa, e) catch util.oom();
    }
    std.mem.sort(Entry, ents.items, {}, index_mod.entryLess);
    const skip = gpa.alloc(bool, ents.items.len) catch util.oom();
    @memset(skip, false);
    var last0: ?[]const u8 = null;
    for (ents.items, 0..) |e, i| {
        switch (e.stage()) {
            0 => last0 = e.path,
            1 => {
                if (last0) |l| {
                    if (util.eql(l, e.path)) skip[i] = true;
                }
            },
            else => {},
        }
    }
    return skip;
}

pub fn cmdLsFiles(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    const opts = [_]po.Opt{
        po.setInt('z', "", &line_terminator, 0, "separate paths with the NUL character"),
        po.boolean('t', "", &show_tag, "identify the file status with tags"),
        po.boolean('v', "", &show_valid_bit, "use lowercase letters for 'assume unchanged' files"),
        po.boolean('f', "", &show_fsmonitor_bit, "use lowercase letters for 'fsmonitor clean' files"),
        po.boolean('c', "cached", &show_cached, "show cached files in the output (default)"),
        po.boolean('d', "deleted", &show_deleted, "show deleted files in the output"),
        po.boolean('m', "modified", &show_modified, "show modified files in the output"),
        po.boolean('o', "others", &show_others, "show other files in the output"),
        po.bit('i', "ignored", &dirflags, DIR_SHOW_IGNORED, "show ignored files in the output"),
        po.boolean('s', "stage", &show_stage, "show staged contents' object name in the output"),
        po.boolean('k', "killed", &show_killed, "show files on the filesystem that need to be removed"),
        po.bit(0, "directory", &dirflags, DIR_SHOW_OTHER_DIRECTORIES, "show 'other' directories' names only"),
        po.boolean(0, "eol", &show_eol, "show line endings of files"),
        .{ .long = "empty-directory", .kind = .negbit, .i = &dirflags, .val = DIR_HIDE_EMPTY_DIRECTORIES, .help = "don't show empty directories" },
        po.boolean('u', "unmerged", &show_unmerged, "show unmerged files in the output"),
        po.boolean(0, "resolve-undo", &show_resolve_undo, "show resolve-undo information"),
        .{ .short = 'x', .long = "exclude", .kind = .callback, .cb = optExclude, .argh = "pattern", .help = "skip files matching pattern", .noneg = true },
        .{ .short = 'X', .long = "exclude-from", .kind = .callback, .cb = optExcludeFrom, .argh = "file", .help = "read exclude patterns from <file>", .noneg = true },
        po.string(0, "exclude-per-directory", &exclude_per_dir, "file", "read additional per-directory exclude patterns in <file>"),
        .{ .long = "exclude-standard", .kind = .callback, .cb = optExcludeStandard, .noarg = true, .noneg = true, .help = "add the standard git exclusions" },
        .{ .long = "full-name", .kind = .set_int, .i = &prefix_len, .val = 0, .noneg = true, .help = "make the output relative to the project top directory" },
        po.boolean(0, "recurse-submodules", &recurse_submodules, "recurse through submodules"),
        po.boolean(0, "error-unmatch", &error_unmatch, "if any <file> is not in the index, treat this as an error"),
        po.string(0, "with-tree", &with_tree, "tree-ish", "pretend that paths removed since <tree-ish> are still present"),
        .{ .long = "abbrev", .kind = .int, .i = &abbrev, .val = -1, .optarg = true, .argh = "n", .help = "use <n> digits to display object names" },
        po.boolean(0, "debug", &debug_mode, "show debugging data"),
        po.boolean(0, "deduplicate", &skipping_duplicates, "suppress duplicate entries"),
        po.boolean(0, "sparse", &show_sparse_dirs, "show sparse directories in the presence of a sparse index"),
        .{ .long = "format", .kind = .string, .s = &format, .argh = "format", .noneg = true, .help = "format to use for the output" },
    };

    prefix = r.prefix;
    top_prefix = prefix;
    saved_args = args[1..];
    if (os.getenv("GIT_INTERNAL_LS_FILES_SUPER_PREFIX")) |sp| {
        super_prefix = sp;
        top_prefix = os.getenv("GIT_INTERNAL_LS_FILES_TOP_PREFIX") orelse "";
        prefix = top_prefix;
    }
    prefix_len = @intCast(prefix.len);
    po.prefix = prefix;
    // show_usage_with_options_if_asked(): before the index is read
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all")))
        po.usageExit(&ls_files_usage, &opts, false);
    const sparse_index = @import("../sparse_index.zig");
    sparse_index.keep_sparse = true;
    const idx = index_mod.get();

    const argv = po.parse(args[1..], &opts, &ls_files_usage, .{});
    if (!show_sparse_dirs) sparse_index.ensureFull(idx);
    abbrev = fixAbbrev(abbrev);
    dir.flags.show_ignored = dirflags & DIR_SHOW_IGNORED != 0;
    dir.flags.show_other_directories = dirflags & DIR_SHOW_OTHER_DIRECTORIES != 0;
    dir.flags.hide_empty_directories = dirflags & DIR_HIDE_EMPTY_DIRECTORIES != 0;
    if (exclude_per_dir) |e| dir.exclude_per_dir = e;

    {
        const pl = dir.addPatternList(dir_mod.EXC_CMDL, "--exclude option");
        for (exclude_list.items) |p| dir.addPatternSrcpos(pl, p, 0);
    }

    if (format != null and (show_stage or show_others or show_killed or show_resolve_undo or skipping_duplicates or show_eol or show_tag)) {
        util.eprint("fatal: --format cannot be used with -s, -o, -k, -t, --resolve-undo, --deduplicate, --eol\n\n", .{});
        po.usageWithOptions(&ls_files_usage, &opts);
    }

    if (show_tag or show_valid_bit or show_fsmonitor_bit) {
        tag_cached = "H ";
        tag_unmerged = "M ";
        tag_removed = "R ";
        tag_modified = "C ";
        tag_other = "? ";
        tag_killed = "K ";
        tag_skip_worktree = "S ";
        tag_resolve_undo = "U ";
    }
    var require_work_tree = false;
    if (show_modified or show_others or show_deleted or dir.flags.show_ignored or show_killed)
        require_work_tree = true;
    if (show_unmerged) show_stage = true;
    if (show_tag or show_stage) skipping_duplicates = false;
    if (exclude_per_dir != null) exc_given = true;

    if (require_work_tree and r.work_tree == null)
        util.die("this operation must be run in a work tree", .{});

    if (recurse_submodules and (show_deleted or show_others or show_unmerged or show_killed or show_modified or show_resolve_undo or with_tree != null))
        util.die("ls-files --recurse-submodules unsupported mode", .{});
    if (recurse_submodules and error_unmatch)
        util.die("ls-files --recurse-submodules does not support --error-unmatch", .{});

    pathspec = pathspec_mod.parse(prefix, argv, .{ .prefer_cwd = true });

    var max_prefix: []const u8 = "";
    if (!recurse_submodules) max_prefix = pathspec.commonPrefix();
    max_prefix_len = max_prefix.len;
    if (max_prefix_len > 0 and max_prefix[max_prefix_len - 1] == '/') max_prefix_len -= 1;

    // prune_index
    var ents: std.ArrayList(Entry) = .empty;
    for (idx.entries.items) |e| {
        if (e.removed) continue;
        if (max_prefix_len > 0 and !std.mem.startsWith(u8, e.path, max_prefix[0..max_prefix_len])) continue;
        ents.append(gpa, e) catch util.oom();
    }

    if (pathspec.items.len > 0 and error_unmatch) ps_matched = pathspec.newSeen();

    if (dir.flags.show_ignored and !show_others and !show_cached)
        util.die("ls-files -i must be used with either -o or -c", .{});
    if (dir.flags.show_ignored and !exc_given)
        util.die("ls-files --ignored needs some exclude pattern", .{});

    if (!(show_stage or show_deleted or show_others or show_unmerged or show_killed or show_modified or show_resolve_undo))
        show_cached = true;

    var skip: []bool = undefined;
    if (with_tree) |wt| {
        if (show_stage or show_unmerged)
            util.die("options '{s}' and '{s}' cannot be used together", .{ "ls-files --with-tree", "-s/-u" });
        skip = overlayTree(&ents, wt, max_prefix);
    } else {
        skip = gpa.alloc(bool, ents.items.len) catch util.oom();
        @memset(skip, false);
    }

    showFiles(idx, ents.items, skip);

    if (show_resolve_undo) showRuInfo(idx);

    var ret: u8 = 0;
    if (ps_matched) |seen| {
        if (pathspec.reportPathError(seen) != 0) {
            util.eprint("Did you forget to 'git add'?\n", .{});
            ret = 1;
        }
    }
    return ret;
}

// ===================================================================
// ls-tree

const ls_tree_usage = [_][]const u8{"git ls-tree [<options>] <tree-ish> [<path>...]"};

const LS_RECURSIVE: i32 = 1;
const LS_TREE_ONLY: i32 = 2;
const LS_SHOW_TREES: i32 = 4;

const Mode = enum(i32) { default = 0, long = 1, name_only = 2, name_status = 3, object_only = 4 };

var t_ls_options: i32 = 0;
var t_null = false;
var t_abbrev: i32 = 0;
var t_prefix: []const u8 = "";
var t_format: ?[]const u8 = null;
var t_cmdmode: Mode = .default;
var t_cmdmode_name: []const u8 = "";
var t_specs: []const []const u8 = &.{};
var t_mode_fast: Mode = .default;
var t_use_fmt = false;

fn setCmdmode(m: Mode, name: []const u8) void {
    if (t_cmdmode != .default and t_cmdmode != m) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ name, t_cmdmode_name });
        os.exit(129);
    }
    t_cmdmode = m;
    t_cmdmode_name = name;
}
fn cbLong(_: ?[]const u8, unset: bool) void {
    if (unset) t_cmdmode = .default else setCmdmode(.long, "-l");
}
fn cbNameOnly(_: ?[]const u8, unset: bool) void {
    if (unset) t_cmdmode = .default else setCmdmode(.name_only, "--name-only");
}
fn cbNameStatus(_: ?[]const u8, unset: bool) void {
    if (unset) t_cmdmode = .default else setCmdmode(.name_status, "--name-status");
}
fn cbObjectOnly(_: ?[]const u8, unset: bool) void {
    if (unset) t_cmdmode = .default else setCmdmode(.object_only, "--object-only");
}

fn showRecursive(base: []const u8, pathname: []const u8) bool {
    if (t_ls_options & LS_RECURSIVE != 0) return true;
    for (t_specs) |spec0| {
        if (!std.mem.startsWith(u8, spec0, base)) continue;
        const spec = spec0[base.len..];
        if (spec.len <= pathname.len) continue;
        if (spec[pathname.len] != '/') continue;
        if (!std.mem.eql(u8, spec[0..pathname.len], pathname)) continue;
        return true;
    }
    return false;
}

/// tree_entry_interesting for literal pathspecs. Returns: 0 no, 1 yes, 2 all entries below interesting
fn interesting(base: []const u8, name: []const u8, mode: u32) u8 {
    if (t_specs.len == 0) return 2;
    const is_dir = isDirMode(mode) or isGitlink(mode);
    var any = false;
    for (t_specs) |m| {
        if (base.len >= m.len) {
            // match_dir_prefix
            if (!std.mem.startsWith(u8, base, m)) continue;
            if (m.len == 0 or m[m.len - 1] == '/' or base.len == m.len or base[m.len] == '/') return 2;
            continue;
        }
        if (!std.mem.startsWith(u8, m, base)) continue;
        const rest = m[base.len..];
        // match_entry
        if (rest.len > name.len) {
            if (rest[name.len] != '/') continue;
            if (!is_dir) continue;
            if (std.mem.eql(u8, rest[0..name.len], name)) any = true;
            continue;
        }
        if (std.mem.eql(u8, rest, name)) {
            any = true;
            continue;
        }
        // name longer than rest: match is a leading dir of name? (rest ends with '/')
        if (rest.len > 0 and rest[rest.len - 1] == '/' and rest.len - 1 == name.len and std.mem.eql(u8, rest[0 .. rest.len - 1], name) and is_dir) {
            any = true;
        }
    }
    return if (any) 1 else 0;
}

fn writeTreeName(full: []const u8) void {
    const rel = if (t_prefix.len > 0) util.relativePath(full, t_prefix) else full;
    if (t_null) {
        util.out(rel);
        util.out("\x00");
    } else {
        util.out(util.cquote(rel));
        util.out("\n");
    }
}

fn showTreeFmt(oid: Oid, base: []const u8, pathname: []const u8, mode: u32) bool {
    var recurse = false;
    const is_tree = isDirMode(mode);
    if (is_tree and showRecursive(base, pathname)) recurse = true;
    if (is_tree and recurse and t_ls_options & LS_SHOW_TREES == 0) return recurse;
    if (!is_tree and !isGitlink(mode) and t_ls_options & LS_TREE_ONLY != 0) return false;

    var b: util.Buf = .empty;
    var f = t_format.?;
    while (f.len > 0) {
        const pct = std.mem.indexOfScalar(u8, f, '%') orelse {
            util.bufAppend(&b, f);
            break;
        };
        util.bufAppend(&b, f[0..pct]);
        f = f[pct + 1 ..];
        if (util.skipPrefix(f, "%")) |r| {
            util.bufByte(&b, '%');
            f = r;
            continue;
        }
        const lit = expandLiteral(&b, f);
        if (lit != 0) {
            f = f[lit..];
        } else if (util.skipPrefix(f, "(objectmode)")) |r| {
            util.bufPrint(&b, "{o:0>6}", .{mode});
            f = r;
        } else if (util.skipPrefix(f, "(objecttype)")) |r| {
            util.bufAppend(&b, typeName(mode));
            f = r;
        } else if (util.skipPrefix(f, "(objectsize:padded)")) |r| {
            objectSize(&b, oid, mode, true);
            f = r;
        } else if (util.skipPrefix(f, "(objectsize)")) |r| {
            objectSize(&b, oid, mode, false);
            f = r;
        } else if (util.skipPrefix(f, "(objectname)")) |r| {
            util.bufAppend(&b, abbrevHex(oid, t_abbrev));
            f = r;
        } else if (util.skipPrefix(f, "(path)")) |r| {
            const full = util.concat(&.{ base, pathname });
            const rel = if (t_prefix.len > 0) util.relativePath(full, t_prefix) else full;
            if (util.needsQuote(rel)) {
                util.bufByte(&b, '"');
                util.cquoteInto(&b, rel);
                util.bufByte(&b, '"');
            } else util.bufAppend(&b, rel);
            f = r;
        } else badFormat(f, "ls-tree");
    }
    util.bufByte(&b, if (t_null) 0 else '\n');
    util.out(b.items);
    return recurse;
}

/// show_tree_common: returns null to continue showing, or the early return value
fn showTreeCommon(recurse: *bool, base: []const u8, pathname: []const u8, mode: u32) ?bool {
    recurse.* = false;
    if (isDirMode(mode)) {
        if (showRecursive(base, pathname)) {
            recurse.* = true;
            if (t_ls_options & LS_SHOW_TREES == 0) return true;
        }
    } else if (!isGitlink(mode)) {
        if (t_ls_options & LS_TREE_ONLY != 0) return false;
    }
    return null;
}

fn showTree(oid: Oid, base: []const u8, pathname: []const u8, mode: u32) bool {
    if (t_use_fmt) return showTreeFmt(oid, base, pathname, mode);
    var recurse = false;
    if (showTreeCommon(&recurse, base, pathname, mode)) |e| return e;
    switch (t_mode_fast) {
        .default, .name_status => {
            util.outf("{o:0>6} {s} {s}\t", .{ mode, typeName(mode), abbrevHex(oid, t_abbrev) });
            writeTreeName(util.concat(&.{ base, pathname }));
        },
        .long => {
            var size_text: []const u8 = "-";
            if (!isDirMode(mode) and !isGitlink(mode)) {
                if (repo_mod.repo().odb().read(oid)) |obj| {
                    size_text = util.fmt("{d}", .{obj.data.len});
                } else size_text = "BAD";
            }
            util.outf("{o:0>6} {s} {s} {s: >7}\t", .{ mode, typeName(mode), abbrevHex(oid, t_abbrev), size_text });
            writeTreeName(util.concat(&.{ base, pathname }));
        },
        .name_only => writeTreeName(util.concat(&.{ base, pathname })),
        .object_only => {
            util.out(abbrevHex(oid, t_abbrev));
            util.out(if (t_null) "\x00" else "\n");
        },
    }
    return recurse;
}

fn readTreeRec(tree: Oid, base: []const u8, all: bool) bool {
    const entries = objects.readTree(tree) orelse {
        util.err("Could not read {s}", .{hash.hex(tree)});
        return false;
    };
    for (entries) |te| {
        var sub_all = all;
        if (!all) {
            const i = interesting(base, te.name, te.mode);
            if (i == 0) continue;
            if (i == 2) sub_all = true;
        }
        const rec = showTree(te.oid, base, te.name, te.mode);
        if (!rec) continue;
        if (isDirMode(te.mode)) {
            if (!readTreeRec(te.oid, util.concat(&.{ base, te.name, "/" }), sub_all)) return false;
        }
    }
    return true;
}

pub fn cmdLsTree(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    var pfx: []const u8 = r.prefix;
    var full_name = pfx.len == 0;
    var full_tree = false;
    const opts = [_]po.Opt{
        po.bit('d', "", &t_ls_options, LS_TREE_ONLY, "only show trees"),
        po.bit('r', "", &t_ls_options, LS_RECURSIVE, "recurse into subtrees"),
        po.bit('t', "", &t_ls_options, LS_SHOW_TREES, "show trees when recursing"),
        po.boolean('z', "", &t_null, "terminate entries with NUL byte"),
        .{ .short = 'l', .long = "long", .kind = .callback, .cb = cbLong, .noarg = true, .noneg = true, .help = "include object size" },
        .{ .short = 0, .long = "name-only", .kind = .callback, .cb = cbNameOnly, .noarg = true, .noneg = true, .help = "list only filenames" },
        .{ .short = 0, .long = "name-status", .kind = .callback, .cb = cbNameStatus, .noarg = true, .noneg = true, .help = "list only filenames" },
        .{ .short = 0, .long = "object-only", .kind = .callback, .cb = cbObjectOnly, .noarg = true, .noneg = true, .help = "list only objects" },
        po.boolean(0, "full-name", &full_name, "use full path names"),
        po.boolean(0, "full-tree", &full_tree, "list entire tree; not just current directory (implies --full-name)"),
        .{ .long = "format", .kind = .string, .s = &t_format, .argh = "format", .noneg = true, .help = "format to use for the output" },
        .{ .long = "abbrev", .kind = .int, .i = &t_abbrev, .val = -1, .optarg = true, .argh = "n", .help = "use <n> digits to display object names" },
    };
    po.prefix = pfx;
    const argv = po.parse(args[1..], &opts, &ls_tree_usage, .{});
    t_abbrev = fixAbbrev(t_abbrev);
    if (full_tree) pfx = "";
    t_prefix = if (full_name) "" else pfx;

    var cmdmode = t_cmdmode;
    if (cmdmode == .name_status) cmdmode = .name_only;
    if (t_ls_options & (LS_TREE_ONLY | LS_RECURSIVE) == (LS_TREE_ONLY | LS_RECURSIVE))
        t_ls_options |= LS_SHOW_TREES;

    if (t_format != null and cmdmode != .default) {
        util.eprint("fatal: --format can't be combined with other format-altering options\n\n", .{});
        po.usageWithOptions(&ls_tree_usage, &opts);
    }
    if (argv.len < 1) po.usageWithOptions(&ls_tree_usage, &opts);
    const oid = revparse.getOid(argv[0]) orelse util.die("Not a valid object name {s}", .{argv[0]});

    const ps = pathspec_mod.parse(pfx, argv[1..], .{
        .prefer_cwd = true,
        .magic_mask = pathspec_mod.MAGIC_GLOB | pathspec_mod.MAGIC_ICASE | pathspec_mod.MAGIC_EXCLUDE | pathspec_mod.MAGIC_ATTR | pathspec_mod.MAGIC_MAXDEPTH,
    });
    var specs: std.ArrayList([]const u8) = .empty;
    for (ps.items) |it| specs.append(gpa, it.match) catch util.oom();
    t_specs = specs.items;

    const tree = objects.peelTo(oid, .tree) orelse util.die("not a tree object", .{});

    // choose fast path
    t_mode_fast = cmdmode;
    t_use_fmt = false;
    if (t_format) |f| {
        if (util.eql(f, "%(objectmode) %(objecttype) %(objectname)%x09%(path)")) {
            t_mode_fast = .default;
        } else if (util.eql(f, "%(objectmode) %(objecttype) %(objectname) %(objectsize:padded)%x09%(path)")) {
            t_mode_fast = .long;
        } else if (util.eql(f, "%(path)")) {
            t_mode_fast = .name_only;
        } else if (util.eql(f, "%(objectname)")) {
            t_mode_fast = .object_only;
        } else t_use_fmt = true;
    }
    if (!readTreeRec(tree, "", false)) return 1;
    return 0;
}
