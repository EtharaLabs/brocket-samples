//! Line-level log (git log -L): port of line-log.c, line-range.c and the
//! line-range output filter from diff.c.

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const cn = @import("commitnode.zig");
const objects = @import("objects.zig");
const revision = @import("revision.zig");
const diff = @import("diff.zig");
const treediff = @import("treediff.zig");
const xdiff = @import("xdiff.zig");
const regex = @import("regex.zig");
const userdiff = @import("userdiff.zig");
const pathspec_mod = @import("pathspec.zig");
const gpa = util.gpa;

const Commit = cn.Commit;
const RevInfo = revision.RevInfo;
const Oid = hash.Oid;

pub const Range = diff.LineRange;
pub const RangeSet = std.ArrayList(Range);

const DiffRanges = struct {
    parent: RangeSet = .empty,
    target: RangeSet = .empty,
};

pub const Data = struct {
    next: ?*Data = null,
    path: []const u8,
    ranges: RangeSet = .empty,
    pair: ?*diff.FilePair = null,
    diff: DiffRanges = .{},
};

// ---------------------------------------------------------------------------
// range sets

fn rsAppendUnsafe(rs: *RangeSet, a: i64, b: i64) void {
    std.debug.assert(a <= b);
    rs.append(gpa, .{ .start = a, .end = b }) catch util.oom();
}

fn rsAppend(rs: *RangeSet, a: i64, b: i64) void {
    rsAppendUnsafe(rs, a, b);
}

fn rsCopy(src: *const RangeSet) RangeSet {
    var d: RangeSet = .empty;
    d.appendSlice(gpa, src.items) catch util.oom();
    return d;
}

fn lessRange(_: void, a: Range, b: Range) bool {
    return a.start < b.start;
}

fn sortAndMerge(rs: *RangeSet) void {
    std.sort.pdq(Range, rs.items, {}, lessRange);
    var o: usize = 0;
    for (0..rs.items.len) |i| {
        const r = rs.items[i];
        if (r.start == r.end) continue;
        if (o > 0 and r.start <= rs.items[o - 1].end) {
            if (rs.items[o - 1].end < r.end) rs.items[o - 1].end = r.end;
        } else {
            rs.items[o] = r;
            o += 1;
        }
    }
    rs.items.len = o;
}

fn rsUnion(out: *RangeSet, a: *const RangeSet, b: *const RangeSet) void {
    var i: usize = 0;
    var j: usize = 0;
    const ra = a.items;
    const rb = b.items;
    while (i < ra.len or j < rb.len) {
        var nr: Range = undefined;
        if (i < ra.len and j < rb.len) {
            if (ra[i].start < rb[j].start) {
                nr = ra[i];
                i += 1;
            } else if (ra[i].start > rb[j].start) {
                nr = rb[j];
                j += 1;
            } else if (ra[i].end < rb[j].end) {
                nr = ra[i];
                i += 1;
            } else {
                nr = rb[j];
                j += 1;
            }
        } else if (i < ra.len) {
            nr = ra[i];
            i += 1;
        } else {
            nr = rb[j];
            j += 1;
        }
        if (nr.start == nr.end) {} else if (out.items.len == 0 or out.items[out.items.len - 1].end < nr.start) {
            out.append(gpa, nr) catch util.oom();
        } else if (out.items[out.items.len - 1].end < nr.end) {
            out.items[out.items.len - 1].end = nr.end;
        }
    }
}

fn rsDifference(out: *RangeSet, a: *const RangeSet, b: *const RangeSet) void {
    var j: usize = 0;
    const bb = b.items;
    for (a.items) |r| {
        var start = r.start;
        const end = r.end;
        while (start < end) {
            while (j < bb.len and start >= bb[j].end) j += 1;
            if (j >= bb.len or end <= bb[j].start) {
                rsAppend(out, start, end);
                break;
            }
            if (start >= bb[j].start) {
                start = bb[j].end;
            } else if (end > bb[j].start) {
                if (start < bb[j].start) rsAppend(out, start, bb[j].start);
                start = bb[j].end;
            }
        }
    }
}

fn rangesOverlap(a: Range, b: Range) bool {
    return !(a.end <= b.start or b.end <= a.start);
}

fn filterTouched(out: *DiffRanges, d: *const DiffRanges, rs: *const RangeSet) void {
    var j: usize = 0;
    for (d.target.items, 0..) |t, i| {
        while (t.start >= rs.items[j].end) {
            j += 1;
            if (j == rs.items.len) return;
        }
        if (rangesOverlap(t, rs.items[j])) {
            rsAppend(&out.parent, d.parent.items[i].start, d.parent.items[i].end);
            rsAppend(&out.target, t.start, t.end);
        }
    }
}

fn shiftDiff(out: *RangeSet, rs: *const RangeSet, d: *const DiffRanges) void {
    var j: usize = 0;
    var offset: i64 = 0;
    const target = d.target.items;
    const parent = d.parent.items;
    for (rs.items) |s| {
        while (j < target.len and s.start >= target[j].start) {
            offset += (parent[j].end - parent[j].start) - (target[j].end - target[j].start);
            j += 1;
        }
        rsAppend(out, s.start + offset, s.end + offset);
    }
}

fn mapAcrossDiff(out: *RangeSet, rs: *const RangeSet, d: *const DiffRanges) *DiffRanges {
    const touched = gpa.create(DiffRanges) catch util.oom();
    touched.* = .{};
    filterTouched(touched, d, rs);
    var tmp1: RangeSet = .empty;
    var tmp2: RangeSet = .empty;
    rsDifference(&tmp1, rs, &touched.target);
    shiftDiff(&tmp2, &tmp1, d);
    rsUnion(out, &tmp2, &touched.parent);
    return touched;
}

// ---------------------------------------------------------------------------
// line_log_data lists

fn search(list: ?*Data, path: []const u8, ip: ?*?*Data) ?*Data {
    var p = list;
    if (ip) |x| x.* = null;
    while (p) |pp| : (p = pp.next) {
        const cmp = std.mem.order(u8, pp.path, path);
        if (cmp == .eq) return pp;
        if (ip) |x| {
            if (cmp == .lt) x.* = pp;
        }
    }
    return null;
}

fn insert(list: *?*Data, path: []const u8, begin: i64, end: i64) void {
    var ip: ?*Data = null;
    if (search(list.*, path, &ip)) |p| {
        rsAppendUnsafe(&p.ranges, begin, end);
        return;
    }
    const p = gpa.create(Data) catch util.oom();
    p.* = .{ .path = path };
    rsAppend(&p.ranges, begin, end);
    if (ip) |x| {
        p.next = x.next;
        x.next = p;
    } else {
        p.next = list.*;
        list.* = p;
    }
}

fn copyOne(r: *const Data) *Data {
    const d = gpa.create(Data) catch util.oom();
    d.* = .{ .path = r.path, .ranges = rsCopy(&r.ranges) };
    return d;
}

fn copyList(r0: *const Data) *Data {
    const head = copyOne(r0);
    var prev = head;
    var r = r0.next;
    while (r) |x| : (r = x.next) {
        const t = copyOne(x);
        prev.next = t;
        prev = t;
    }
    return head;
}

fn mergeLists(a0: ?*Data, b0: ?*Data) ?*Data {
    var head: ?*Data = null;
    var pp: *?*Data = &head;
    var a = a0;
    var b = b0;
    while (a != null or b != null) {
        var src: *Data = undefined;
        var src2: ?*Data = null;
        const cmp: std.math.Order = if (a == null) .gt else if (b == null) .lt else std.mem.order(u8, a.?.path, b.?.path);
        switch (cmp) {
            .lt => {
                src = a.?;
                a = a.?.next;
            },
            .eq => {
                src = a.?;
                a = a.?.next;
                src2 = b.?;
                b = b.?.next;
            },
            .gt => {
                src = b.?;
                b = b.?.next;
            },
        }
        const d = gpa.create(Data) catch util.oom();
        d.* = .{ .path = src.path };
        pp.* = d;
        pp = &d.next;
        if (src2) |s2| rsUnion(&d.ranges, &src.ranges, &s2.ranges) else d.ranges = rsCopy(&src.ranges);
    }
    return head;
}

// per-commit decoration (revs->line_log_data)
var deco: cn.Slab(?*Data) = cn.Slab(?*Data).init(null);

fn addLineRange(commit: *Commit, range: ?*Data) void {
    const old = deco.at(commit).*;
    var new: ?*Data = null;
    if (old != null and range != null) {
        new = mergeLists(old, range);
    } else if (range) |r| new = copyList(r);
    if (new) |n| deco.at(commit).* = n;
}

fn clearLineRange(commit: *Commit) void {
    deco.at(commit).* = null;
}

fn lookupLineRange(commit: *Commit) ?*Data {
    return deco.at(commit).*;
}

// ---------------------------------------------------------------------------
// line-range.c

const NthLine = struct {
    data: []const u8,
    lines: i64,
    ends: []const usize,

    /// offset of the start of (0-based) line `line`
    fn at(self: *const NthLine, line: i64) usize {
        std.debug.assert(line <= self.lines);
        if (line == 0) return 0;
        return self.ends[@intCast(line)] + 1;
    }
};

const Strtol = struct { v: i64, end: usize };

/// strtol(s + pos, &end, 10)
fn strtol(s: []const u8, pos: usize) Strtol {
    var i = pos;
    while (i < s.len and (s[i] == ' ' or (s[i] >= '\t' and s[i] <= '\r'))) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    const ds = i;
    var v: i64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) v = v *% 10 +% (s[i] - '0');
    if (i == ds) return .{ .v = 0, .end = pos };
    return .{ .v = if (neg) -v else v, .end = i };
}

fn compileBre(pat: []const u8) regex.Regex {
    return switch (regex.Regex.compile(pat, .{ .newline = true })) {
        .ok => |r| r,
        .err => |m| util.die("-L parameter '{s}': {s}", .{ pat, m }),
    };
}

/// parse_loc(); returns the index into spec after the parsed part
fn parseLoc(spec: []const u8, si: usize, nl: ?*const NthLine, begin0: i64, ret: ?*i64) usize {
    var begin = begin0;
    var s = si;
    if (1 <= begin and s < spec.len and (spec[s] == '+' or spec[s] == '-')) {
        const r = strtol(spec, s + 1);
        if (r.end != s + 1) {
            const out = ret orelse return r.end;
            var num = r.v;
            if (num == 0) util.die("-L invalid empty range", .{});
            if (spec[s] == '-') num = -num;
            if (0 < num) {
                out.* = begin + num - 2;
            } else if (num == 0) {
                out.* = begin;
            } else out.* = if (begin + num > 0) begin + num else 1;
            return r.end;
        }
        return s;
    }
    const r = strtol(spec, s);
    if (r.end != s) {
        if (ret) |out| {
            if (r.v <= 0) util.die("-L invalid line number: {d}", .{r.v});
            out.* = r.v;
        }
        return r.end;
    }
    if (begin < 0) {
        if (s >= spec.len or spec[s] != '^') {
            begin = -begin;
        } else {
            begin = 1;
            s += 1;
        }
    }
    if (s >= spec.len or spec[s] != '/') return s;
    var term = s + 1;
    while (term < spec.len and spec[term] != '/') : (term += 1) {
        if (spec[term] == '\\') term += 1;
    }
    if (term >= spec.len or spec[term] != '/') return s;
    const out = ret orelse return term + 1;
    const n = nl.?;
    const pat = spec[s + 1 .. term];
    begin -= 1;
    var line = n.at(begin);
    const re = switch (regex.Regex.compile(pat, .{ .newline = true })) {
        .ok => |rr| rr,
        .err => |m| util.die("-L parameter '{s}' starting at line {d}: {s}", .{ pat, begin + 1, m }),
    };
    const m = re.find(n.data[line..], false) orelse
        util.die("-L parameter '{s}' starting at line {d}: {s}", .{ pat, begin + 1, "No match" });
    const cp = line + @as(usize, @intCast(m.so));
    while (true) {
        const cond = begin < n.lines;
        begin += 1;
        if (!cond) break;
        const nline = n.at(begin);
        if (line <= cp and cp < nline) break;
        line = nline;
    }
    out.* = begin;
    return term + 1;
}

fn matchFuncname(ff: ?xdiff.FindFunc, line: []const u8) bool {
    if (ff) |f| {
        var buf: [1]u8 = undefined;
        return f.func(f.ctx, line, &buf) >= 0;
    }
    if (line.len == 0) return false;
    return std.ascii.isAlphabetic(line[0]) or line[0] == '_' or line[0] == '$';
}

fn findFuncnameMatching(ff: ?xdiff.FindFunc, data: []const u8, start0: usize, re: regex.Regex) ?usize {
    var start = start0;
    while (start < data.len) {
        const s = data[start..];
        const m = re.find(s, false) orelse return null;
        var bol: usize = @intCast(m.so);
        var eol: usize = @intCast(m.eo);
        while (bol > 0) {
            bol -= 1;
            if (s[bol] == '\n') break;
        }
        if (bol < s.len and s[bol] == '\n') bol += 1;
        while (eol < s.len and s[eol] != '\n') eol += 1;
        if (eol < s.len and s[eol] == '\n') eol += 1;
        if (matchFuncname(ff, s[bol..eol])) return start + bol;
        start += eol;
    }
    return null;
}

/// parse_range_funcname(); returns index after the funcname, or null
fn parseRangeFuncname(arg: []const u8, nl: ?*const NthLine, anchor0: i64, begin: ?*i64, end: ?*i64, path: []const u8) ?usize {
    var anchor = anchor0;
    var a: usize = 0;
    if (a < arg.len and arg[a] == '^') {
        anchor = 1;
        a += 1;
    }
    std.debug.assert(arg[a] == ':');
    var term = a + 1;
    while (term < arg.len and arg[term] != ':') {
        if (arg[term] == '\\' and term + 1 < arg.len) term += 1;
        term += 1;
    }
    if (term == a + 1) return null;
    const b = begin orelse return term;
    const e = end.?;
    const n = nl.?;
    const pattern = arg[a + 1 .. term];
    anchor -= 1;
    const start = n.at(anchor);
    var ff: ?xdiff.FindFunc = null;
    if (userdiff.findByPath(path)) |drv| {
        if (drv.funcname) |pat| {
            ff = xdiff.RegexFindFunc.init(pat, .{ .extended = drv.funcname_extended, .icase = drv.funcname_icase }).findFunc();
        }
    }
    const re = compileBre(pattern);
    const p = findFuncnameMatching(ff, n.data, start, re) orelse
        util.die("-L parameter '{s}' starting at line {d}: no match", .{ pattern, anchor + 1 });
    b.* = 0;
    while (p > n.at(b.*)) b.* += 1;
    if (b.* >= n.lines) util.die("-L parameter '{s}' matches at EOF", .{pattern});
    e.* = b.* + 1;
    while (e.* < n.lines) {
        const bol = n.at(e.*);
        const eol = n.at(e.* + 1);
        if (matchFuncname(ff, n.data[bol..eol])) break;
        e.* += 1;
    }
    b.* += 1;
    return term;
}

fn isFuncnameArg(arg: []const u8) bool {
    return (arg.len > 0 and arg[0] == ':') or (arg.len > 1 and arg[0] == '^' and arg[1] == ':');
}

/// parse_range_arg(); returns false on malformed input
fn parseRangeArg(arg: []const u8, nl: *const NthLine, anchor0: i64, begin: *i64, end: *i64, path: []const u8) bool {
    begin.* = 0;
    end.* = 0;
    var anchor = anchor0;
    if (anchor < 1) anchor = 1;
    if (anchor > nl.lines) anchor = nl.lines + 1;
    if (isFuncnameArg(arg)) {
        const t = parseRangeFuncname(arg, nl, anchor, begin, end, path) orelse return false;
        return t == arg.len;
    }
    var i = parseLoc(arg, 0, nl, -anchor, begin);
    if (i < arg.len and arg[i] == ',') i = parseLoc(arg, i + 1, nl, begin.* + 1, end);
    if (i < arg.len) return false;
    if (begin.* != 0 and end.* != 0 and end.* < begin.*) std.mem.swap(i64, begin, end);
    return true;
}

/// skip_range_arg(); returns index into arg (null: bad funcname)
fn skipRangeArg(arg: []const u8) ?usize {
    if (isFuncnameArg(arg)) return parseRangeFuncname(arg, null, 0, null, null, "");
    var i = parseLoc(arg, 0, null, -1, null);
    if (i < arg.len and arg[i] == ',') i = parseLoc(arg, i + 1, null, 0, null);
    return i;
}

// ---------------------------------------------------------------------------
// setup

fn checkSingleCommit(revs: *RevInfo) *Commit {
    var commit: ?*cn.Obj = null;
    var found: usize = 0;
    for (revs.pending.items, 0..) |e, i| {
        if (e.item.flags & cn.UNINTERESTING != 0) continue;
        const o = cn.derefTag(e.item);
        if (o == null or o.?.typ != .commit) util.die("Non commit {s}?", .{e.name});
        if (commit != null) util.die("More than one commit to dig from: {s} and {s}?", .{ e.name, revs.pending.items[found].name });
        commit = o.?;
        found = i;
    }
    const c = commit orelse util.die("No commit specified?", .{});
    return Commit.fromObj(c);
}

fn lineEnds(data: []const u8) struct { lines: i64, ends: []usize } {
    var ends: std.ArrayList(usize) = .empty;
    ends.append(gpa, 0) catch util.oom();
    for (data, 0..) |ch, num| {
        if (ch == '\n' or num == data.len - 1) ends.append(gpa, num) catch util.oom();
    }
    return .{ .lines = @intCast(ends.items.len - 1), .ends = ends.items };
}

fn parseLines(commit: *Commit, prefix: []const u8, args: []const []const u8) ?*Data {
    var ranges: ?*Data = null;
    cn.parseOrDie(commit);
    for (args) |item| {
        const np = skipRangeArg(item);
        if (np == null or np.? >= item.len or item[np.?] != ':' or np.? + 1 >= item.len)
            util.die("-L argument not 'start,end:file' or ':funcname:file': {s}", .{item});
        const range_part = item[0..np.?];
        const name_part = item[np.? + 1 ..];
        var plen = prefix.len;
        const full_name = pathspec_mod.prefixPathGently(prefix, &plen, name_part) orelse
            util.die("'{s}' is outside repository", .{name_part});
        const te = objects.treeLookup(commit.tree, full_name) orelse
            util.die("There is no path {s} in the commit", .{full_name});
        const spec = diff.allocFilespec(full_name, te.oid, true, te.mode);
        if (diff.populateFilespec(spec, false) != 0) util.die("Cannot read blob {s}", .{hash.hex(te.oid)});
        const data = spec.data orelse "";
        const le = lineEnds(data);
        const nl = NthLine{ .data = data, .lines = le.lines, .ends = le.ends };
        var anchor: i64 = 1;
        if (search(ranges, full_name, null)) |p| {
            if (p.ranges.items.len > 0) anchor = p.ranges.items[p.ranges.items.len - 1].end + 1;
        }
        var begin: i64 = 0;
        var end: i64 = 0;
        if (!parseRangeArg(range_part, &nl, anchor, &begin, &end, full_name))
            util.die("malformed -L argument '{s}'", .{range_part});
        const lines = nl.lines;
        if ((lines == 0 and (begin != 0 or end != 0)) or lines < begin)
            util.die("file {s} has only {d} lines", .{ name_part, lines });
        if (begin < 1) begin = 1;
        if (end < 1 or lines < end) end = lines;
        begin -= 1;
        insert(&ranges, full_name, begin, end);
    }
    var p = ranges;
    while (p) |x| : (p = x.next) sortAndMerge(&x.ranges);
    return ranges;
}

fn revOpts(revs: *RevInfo) *diff.DiffOptions {
    return @ptrCast(@alignCast(revs.diffopt.?));
}

fn pathspecFromRanges(range: ?*Data) pathspec_mod.Pathspec {
    var arr: std.ArrayList([]const u8) = .empty;
    var r = range;
    while (r) |x| : (r = x.next) arr.append(gpa, x.path) catch util.oom();
    return pathspec_mod.parse("", arr.items, .{ .prefer_full = true });
}

fn samePaths(ps: *const pathspec_mod.Pathspec, range: ?*Data) bool {
    var i: usize = 0;
    var r = range;
    while (i < ps.items.len and r != null) : (i += 1) {
        if (!util.eql(ps.items[i].match, r.?.path)) return false;
        r = r.?.next;
    }
    return i >= ps.items.len and r == null;
}

/// line_log_init()
pub fn init(revs: *RevInfo, prefix: []const u8, args: []const []const u8) void {
    const commit = checkSingleCommit(revs);
    const range = parseLines(commit, prefix, args);
    addLineRange(commit, range);
    revOpts(revs).pathspec = pathspecFromRanges(range);
    revs.line_log_ops = &ops;
    diff.line_range_outf = rangeDiffOutf;
}

pub const ops = revision.LineLogOps{
    .process = processRangesArbitraryCommit,
    .filter = filter,
    .queue_pairs = queuePairs,
};

// ---------------------------------------------------------------------------
// walking

fn filterDiffsForPaths(range: ?*Data, keep_deletions: bool) void {
    var outq: diff.Queue = .empty;
    for (diff.queue.items) |p| {
        if (!diff.fileValid(p.two)) {
            if (keep_deletions) outq.append(gpa, p) catch util.oom();
            continue;
        }
        var rg = range;
        while (rg) |x| : (rg = x.next) {
            if (util.eql(x.path, p.two.path)) break;
        }
        if (rg != null) outq.append(gpa, p) catch util.oom();
    }
    diff.queue = outq;
}

fn diffMightBeRename() bool {
    for (diff.queue.items) |p| {
        if (!diff.fileValid(p.one)) return true;
    }
    return false;
}

fn queueDiffs(range: ?*Data, o: *diff.DiffOptions, commit: *Commit, parent: ?*Commit) diff.Queue {
    cn.parseOrDie(commit);
    const tree = commit.tree;
    var ptree: ?Oid = null;
    if (parent) |p| {
        cn.parseOrDie(p);
        ptree = p.tree;
    }
    if (o.detect_rename != 0 and !samePaths(&o.pathspec, range)) o.pathspec = pathspecFromRanges(range);
    diff.clearQueue();
    treediff.diffTreeOid(ptree, tree, "", o);
    if (o.detect_rename != 0 and diffMightBeRename()) {
        const ro = gpa.create(diff.DiffOptions) catch util.oom();
        ro.* = diff.DiffOptions.init();
        ro.flags.recursive = true;
        ro.detect_rename = o.detect_rename;
        ro.rename_score = o.rename_score;
        ro.output_format = diff.FMT_NO_OUTPUT;
        ro.setupDone();
        diff.clearQueue();
        treediff.diffTreeOid(ptree, tree, "", ro);
        filterDiffsForPaths(range, true);
        diff.diffcoreStd(ro);
        filterDiffsForPaths(range, false);
    }
    const q = diff.queue;
    diff.clearQueue();
    return q;
}

fn collectCb(ctx: ?*anyopaque, start_a: isize, count_a: isize, start_b: isize, count_b: isize) void {
    const d: *DiffRanges = @ptrCast(@alignCast(ctx.?));
    if (count_a >= 0) rsAppend(&d.parent, start_a, start_a + count_a);
    if (count_b >= 0) rsAppend(&d.target, start_b, start_b + count_b);
}

fn collectDiff(a0: []const u8, b0: []const u8, out: *DiffRanges) bool {
    const t = xdiff.trimCommonTail(a0, b0);
    var d = xdiff.diff(t.a, t.b, .{}) catch return false;
    defer d.deinit();
    var eo = xdiff.EmitOpts{};
    eo.context = 0;
    eo.interhunk = 0;
    xdiff.forEachHunkRange(&d, eo, out, collectCb);
    return true;
}

fn processDiffFilepair(pair: *diff.FilePair, range: ?*Data, diff_out: *?*DiffRanges) bool {
    var rg = range;
    while (rg) |x| : (rg = x.next) {
        if (util.eql(x.path, pair.two.path)) break;
    }
    const r = rg orelse return false;
    if (r.ranges.items.len == 0) return false;
    _ = diff.populateFilespec(pair.two, false);
    const target = pair.two.data orelse "";
    var parent: []const u8 = "";
    if (pair.one.oid_valid) {
        _ = diff.populateFilespec(pair.one, false);
        parent = pair.one.data orelse "";
    }
    var d = DiffRanges{};
    if (!collectDiff(parent, target, &d)) util.die("unable to generate diff for {s}", .{pair.one.path});
    r.path = pair.one.path;
    var tmp: RangeSet = .empty;
    diff_out.* = mapAcrossDiff(&tmp, &r.ranges, &d);
    r.ranges = tmp;
    return diff_out.*.?.parent.items.len > 0;
}

fn processAllFiles(range_out: *?*Data, queue: *const diff.Queue, range: *Data) usize {
    range_out.* = copyList(range);
    var changed: usize = 0;
    for (queue.items) |pair| {
        var pairdiff: ?*DiffRanges = null;
        if (processDiffFilepair(pair, range_out.*, &pairdiff)) {
            changed += 1;
            var rg: ?*Data = range;
            while (rg) |x| {
                if (util.eql(x.path, pair.two.path)) break;
                rg = x.next;
            }
            const r = rg.?;
            r.pair = pair;
            r.diff = pairdiff.?.*;
        }
    }
    return changed;
}

/// line_log_queue_pairs()
fn queuePairs(revs: *RevInfo, commit: *Commit) void {
    _ = revs;
    var r = lookupLineRange(commit);
    while (r) |x| : (r = x.next) {
        if (x.pair) |p| {
            const np = gpa.create(diff.FilePair) catch util.oom();
            np.* = p.*;
            np.line_ranges = x.ranges.items;
            diff.queue.append(gpa, np) catch util.oom();
        }
    }
}

fn processOrdinaryCommit(revs: *RevInfo, commit: *Commit, range: *Data) bool {
    const parent: ?*Commit = if (commit.parents) |p| p.item else null;
    const q = queueDiffs(range, revOpts(revs), commit, parent);
    var parent_range: ?*Data = null;
    const changed = processAllFiles(&parent_range, &q, range);
    if (parent) |p| addLineRange(p, parent_range);
    return changed != 0;
}

fn processMergeCommit(revs: *RevInfo, commit: *Commit, range: *Data) bool {
    var nparents = cn.listCount(commit.parents);
    if (nparents > 1 and revs.first_parent_only) nparents = 1;
    const cand = gpa.alloc(?*Data, nparents) catch util.oom();
    @memset(cand, null);
    var p = commit.parents;
    var i: usize = 0;
    while (p) |pp| : ({
        p = pp.next;
        i += 1;
    }) {
        if (i >= nparents) break;
        const parent = pp.item;
        const q = queueDiffs(range, revOpts(revs), commit, parent);
        const changed = processAllFiles(&cand[i], &q, range);
        if (changed == 0) {
            addLineRange(parent, cand[i]);
            var nl: ?*cn.CommitList = null;
            _ = cn.listAppend(parent, &nl);
            commit.parents = nl;
            clearLineRange(commit);
            return false;
        }
    }
    p = commit.parents;
    i = 0;
    while (p) |pp| : ({
        p = pp.next;
        i += 1;
    }) {
        if (i >= nparents) break;
        addLineRange(pp.item, cand[i]);
    }
    clearLineRange(commit);
    return true;
}

/// line_log_process_ranges_arbitrary_commit()
fn processRangesArbitraryCommit(revs: *RevInfo, commit: *Commit) bool {
    var changed = false;
    if (lookupLineRange(commit)) |range| {
        if (commit.parents != null and commit.parents.?.next != null) {
            changed = processMergeCommit(revs, commit, range);
        } else changed = processOrdinaryCommit(revs, commit, range);
    }
    if (!changed) commit.obj.flags |= cn.TREESAME;
    return changed;
}

fn rewriteOne(_: *RevInfo, pp: **Commit) revision.RewriteResult {
    while (true) {
        const p = pp.*;
        if (p.parents != null and p.parents.?.next != null) return .ok;
        if (p.obj.flags & cn.UNINTERESTING != 0) return .ok;
        if (p.obj.flags & cn.TREESAME == 0) return .ok;
        const par = p.parents orelse return .noparents;
        pp.* = par.item;
    }
}

/// line_log_filter()
fn filter(revs: *RevInfo) void {
    var list = revs.commits;
    var out: ?*cn.CommitList = null;
    var pp: *?*cn.CommitList = &out;
    while (list) |l| {
        const next = l.next;
        if (processRangesArbitraryCommit(revs, l.item)) {
            pp.* = l;
            pp = &l.next;
        }
        list = next;
    }
    pp.* = null;
    var o = out;
    while (o) |l| : (o = l.next) _ = revision.rewriteParentsWith(revs, l.item, rewriteOne);
    revs.commits = out;
}

// ---------------------------------------------------------------------------
// diff output filter (line_range_callback in diff.c)

const RangeFilter = struct {
    orig_ctx: *anyopaque,
    orig_fn: diff.LineFn,
    ranges: []const Range,
    cur_range: usize = 0,
    lno_post: i64 = 0,
    lno_pre: i64 = 0,
    func: []const u8 = "",
    rhunk: std.ArrayList(u8) = .empty,
    rhunk_old_begin: i64 = 0,
    rhunk_old_count: i64 = 0,
    rhunk_new_begin: i64 = 0,
    rhunk_new_count: i64 = 0,
    rhunk_active: bool = false,
    rhunk_has_changes: bool = false,
    pending_rm: std.ArrayList(u8) = .empty,
    pending_rm_count: i64 = 0,
    pending_rm_pre_begin: i64 = 0,

    fn discardPending(s: *RangeFilter) void {
        s.pending_rm.clearRetainingCapacity();
        s.pending_rm_count = 0;
    }

    fn flush(s: *RangeFilter) void {
        if (!s.rhunk_active) return;
        if (s.pending_rm_count != 0) {
            s.rhunk.appendSlice(gpa, s.pending_rm.items) catch util.oom();
            s.rhunk_old_count += s.pending_rm_count;
            s.rhunk_has_changes = true;
            s.discardPending();
        }
        if (!s.rhunk_has_changes) {
            s.rhunk_active = false;
            s.rhunk.clearRetainingCapacity();
            return;
        }
        var hdr: std.ArrayList(u8) = .empty;
        util.bufAppend(&hdr, util.fmt("@@ -{d},{d} +{d},{d} @@", .{ s.rhunk_old_begin, s.rhunk_old_count, s.rhunk_new_begin, s.rhunk_new_count }));
        if (s.func.len > 0) {
            util.bufByte(&hdr, ' ');
            util.bufAppend(&hdr, s.func);
        }
        util.bufByte(&hdr, '\n');
        s.orig_fn(s.orig_ctx, hdr.items);
        var p: usize = 0;
        const buf = s.rhunk.items;
        while (p < buf.len) {
            const eol = std.mem.indexOfScalarPos(u8, buf, p, '\n');
            const e = if (eol) |x| x + 1 else buf.len;
            s.orig_fn(s.orig_ctx, buf[p..e]);
            p = e;
        }
        s.rhunk_active = false;
        s.rhunk.clearRetainingCapacity();
    }

    fn hunkHeader(s: *RangeFilter, hdr_line: []const u8) void {
        // "@@ -a[,b] +c[,d] @@[ func]\n"
        var i: usize = 4;
        const a = strtol(hdr_line, i);
        i = a.end;
        if (i < hdr_line.len and hdr_line[i] == ',') i = strtol(hdr_line, i + 1).end;
        while (i < hdr_line.len and hdr_line[i] != '+') i += 1;
        const c = strtol(hdr_line, i + 1);
        s.lno_pre = a.v;
        s.lno_post = c.v;
        var f: []const u8 = "";
        if (std.mem.indexOfPos(u8, hdr_line, c.end, "@@")) |at| {
            var rest = hdr_line[at + 2 ..];
            if (rest.len > 0 and rest[rest.len - 1] == '\n') rest = rest[0 .. rest.len - 1];
            if (rest.len > 0 and rest[0] == ' ') rest = rest[1..];
            f = rest;
        }
        s.func = util.dupe(f);
    }

    fn line(s: *RangeFilter, ln: []const u8) void {
        if (ln[0] == '@') return s.hunkHeader(ln);
        if (ln[0] == '-') {
            if (s.pending_rm_count == 0) s.pending_rm_pre_begin = s.lno_pre;
            s.lno_pre += 1;
            s.pending_rm.appendSlice(gpa, ln) catch util.oom();
            s.pending_rm_count += 1;
            return;
        }
        if (ln[0] == '\\') {
            if (s.pending_rm_count != 0) {
                s.pending_rm.appendSlice(gpa, ln) catch util.oom();
            } else if (s.rhunk_active) s.rhunk.appendSlice(gpa, ln) catch util.oom();
            return;
        }
        const lno_0 = s.lno_post - 1;
        const cur_pre = s.lno_pre;
        s.lno_post += 1;
        if (ln[0] == ' ') s.lno_pre += 1;
        while (s.cur_range < s.ranges.len and lno_0 >= s.ranges[s.cur_range].end) {
            if (s.rhunk_active) s.flush();
            s.discardPending();
            s.cur_range += 1;
        }
        if (s.cur_range >= s.ranges.len) {
            s.discardPending();
            return;
        }
        const cur = s.ranges[s.cur_range];
        if (lno_0 < cur.start) {
            s.discardPending();
            return;
        }
        if (!s.rhunk_active) {
            s.rhunk_active = true;
            s.rhunk_has_changes = false;
            s.rhunk_new_begin = lno_0 + 1;
            s.rhunk_old_begin = if (s.pending_rm_count != 0) s.pending_rm_pre_begin else cur_pre;
            s.rhunk_old_count = 0;
            s.rhunk_new_count = 0;
            s.rhunk.clearRetainingCapacity();
        }
        if (s.pending_rm_count != 0) {
            s.rhunk.appendSlice(gpa, s.pending_rm.items) catch util.oom();
            s.rhunk_old_count += s.pending_rm_count;
            s.rhunk_has_changes = true;
            s.discardPending();
        }
        s.rhunk.appendSlice(gpa, ln) catch util.oom();
        s.rhunk_new_count += 1;
        if (ln[0] == '+') {
            s.rhunk_has_changes = true;
        } else s.rhunk_old_count += 1;
    }
};

fn filterLine(ctx: *anyopaque, ln: []const u8) void {
    const s: *RangeFilter = @ptrCast(@alignCast(ctx));
    s.line(ln);
}

/// xdi_diff_outf() restricted to the given post-image line ranges
/// (the line_ranges branch of builtin_diff()). Returns false on failure.
pub fn rangeDiffOutf(a: []const u8, b: []const u8, flags: xdiff.Flags, eo0: xdiff.EmitOpts, ranges: []const Range, ctx: *anyopaque, f: diff.LineFn) bool {
    var eo = eo0;
    var max_span: i64 = 0;
    for (ranges) |r| max_span = @max(max_span, r.end - r.start);
    if (max_span > @as(i64, @intCast(eo.context))) eo.context = @intCast(max_span);
    var s = RangeFilter{ .orig_ctx = ctx, .orig_fn = f, .ranges = ranges };
    if (!diff.xdiDiffOutf(a, b, flags, eo, &s, filterLine)) return false;
    s.flush();
    return true;
}
