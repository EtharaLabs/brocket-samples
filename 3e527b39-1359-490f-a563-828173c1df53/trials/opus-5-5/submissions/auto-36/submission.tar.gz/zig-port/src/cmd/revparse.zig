//! git rev-parse

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const wildmatch = @import("../wildmatch.zig");
const date = @import("../date.zig");
const commitnode = @import("../commitnode.zig");
const commitreach = @import("../commitreach.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

const DO_REVS: u32 = 1;
const DO_NOREV: u32 = 2;
const DO_FLAGS: u32 = 4;
const DO_NONFLAGS: u32 = 8;

const NORMAL = false;
const REVERSED = true;

var filter: u32 = 0xf;
var def: ?[]const u8 = null;
var show_type: bool = NORMAL;
const Symbolic = enum { none, asis, full };
var symbolic: Symbolic = .none;
var abbrev: usize = 0;
var abbrev_ref = false;
var abbrev_ref_strict = false;
var output_sq = false;
var excludes: std.ArrayList([]const u8) = .empty;

const builtin_usage =
    "git rev-parse --parseopt [<options>] -- [<args>...]\n" ++
    "   or: git rev-parse --sq-quote [<arg>...]\n" ++
    "   or: git rev-parse [<options>] [<arg>...]\n" ++
    "\n" ++
    "Run \"git rev-parse --parseopt -h\" for more information on the first usage.";

fn isRevArgument(arg: []const u8) bool {
    const rev_args = [_][]const u8{
        "--all",           "--bisect",       "--dense",          "--branches=",   "--branches",
        "--header",        "--ignore-missing", "--max-age=",     "--max-count=",  "--min-age=",
        "--no-merges",     "--min-parents=", "--no-min-parents", "--max-parents=", "--no-max-parents",
        "--objects",       "--objects-edge", "--parents",        "--pretty",      "--remotes=",
        "--remotes",       "--glob=",        "--sparse",         "--tags=",       "--tags",
        "--topo-order",    "--date-order",   "--unpacked",
    };
    if (arg.len > 1 and arg[0] == '-' and std.ascii.isDigit(arg[1])) return true;
    for (rev_args) |s| {
        if (util.eql(arg, s)) return true;
        if (s[s.len - 1] == '=' and util.startsWith(arg, s)) return true;
    }
    return false;
}

fn show(arg: []const u8) void {
    if (output_sq) {
        var b: util.Buf = .empty;
        util.bufByte(&b, '\'');
        for (arg) |ch| {
            if (ch == '\'') util.bufAppend(&b, "'\\'");
            util.bufByte(&b, ch);
        }
        util.bufAppend(&b, "' ");
        util.out(b.items);
    } else {
        util.outf("{s}\n", .{arg});
    }
}

fn showWithType(t: bool, arg: []const u8) void {
    if (t != show_type) util.out("^");
    show(arg);
}

fn showRev(t: bool, oid: Oid, name: ?[]const u8) void {
    if (filter & DO_REVS == 0) return;
    def = null;
    if ((symbolic != .none or abbrev_ref) and name != null) {
        const n = name.?;
        if (symbolic == .full or abbrev_ref) {
            if (dwimRefFull(n)) |res| {
                if (res.count == 1) {
                    var full = res.name;
                    if (abbrev_ref) full = refs.shortenUnambiguousStrict(full, abbrev_ref_strict);
                    showWithType(t, full);
                } else {
                    util.err("refname '{s}' is ambiguous", .{n});
                }
            }
        } else {
            showWithType(t, n);
        }
    } else if (abbrev > 0) {
        showWithType(t, revparse.abbrev(oid, abbrev));
    } else {
        showWithType(t, &hash.hex(oid));
    }
}

/// repo_dwim_ref() including @{-N}, @{upstream} and "HEAD"-like forms.
fn dwimRefFull(name: []const u8) ?struct { name: []const u8, count: usize } {
    var n = name;
    // @{-N} and upstream forms resolve to a branch name first
    if (util.startsWith(n, "@{-")) {
        const b = revparse.interpretBranchName(n);
        if (!util.eql(b, n)) {
            const full = util.concat(&.{ "refs/heads/", b });
            if (refs.readOid(full) != null) return .{ .name = full, .count = 1 };
            return null;
        }
    }
    if (std.mem.indexOf(u8, n, "@{")) |at| {
        const suffix = n[at..];
        const lower = util.lower(suffix);
        if (util.eql(lower, "@{u}") or util.eql(lower, "@{upstream}") or util.eql(lower, "@{push}")) {
            const br0 = n[0..at];
            const br = if (br0.len == 0 or util.eql(br0, "HEAD")) (refs.currentBranch() orelse return null) else br0;
            const short = if (util.skipPrefix(br, "refs/heads/")) |s| s else br;
            switch (revparse.upstreamOf(short, util.eql(lower, "@{push}"))) {
                .ok => |u| return .{ .name = u, .count = 1 },
                .err => |e| util.die("{s}", .{e}),
            }
        }
        // reflog selectors: dwim on the base
        n = n[0..at];
        if (n.len == 0) n = "HEAD";
    }
    if (util.eql(n, "@")) n = "HEAD";
    const r = refs.dwimRef(n) orelse return null;
    return .{ .name = refs.resolveTarget(r.name), .count = r.count };
}

fn showFlag(arg: []const u8) bool {
    if (filter & DO_FLAGS == 0) return false;
    if (filter & (if (isRevArgument(arg)) DO_REVS else DO_NOREV) != 0) {
        show(arg);
        return true;
    }
    return false;
}

fn showDefault() bool {
    if (def) |s| {
        def = null;
        if (revparse.getOid(s)) |oid| {
            showRev(NORMAL, oid, s);
            return true;
        }
    }
    return false;
}

fn showFile(arg: []const u8, output_prefix: bool) bool {
    _ = showDefault();
    if (filter & (DO_NONFLAGS | DO_NOREV) == (DO_NONFLAGS | DO_NOREV)) {
        if (output_prefix) {
            const p = if (repo_mod.repo_) |r| r.prefix else "";
            show(if (arg.len > 0 and arg[0] == '/') arg else util.concat(&.{ p, arg }));
        } else show(arg);
        return true;
    }
    return false;
}

fn showDatestring(flag: []const u8, datestr: []const u8) void {
    if (filter & (DO_FLAGS | DO_REVS) != (DO_FLAGS | DO_REVS)) return;
    show(util.fmt("{s}{d}", .{ flag, date.approxidate(datestr) }));
}

fn tryDifference(arg: []const u8) bool {
    const dd = std.mem.indexOf(u8, arg, "..") orelse return false;
    var start: []const u8 = arg[0..dd];
    var end: []const u8 = arg[dd + 2 ..];
    const symmetric = end.len > 0 and end[0] == '.';
    if (symmetric) end = end[1..];
    const end_default = end.len == 0;
    const start_default = dd == 0;
    if (end_default) end = "HEAD";
    if (start_default) start = "HEAD";
    if (start_default and end_default and !symmetric) return false;
    const s_oid = revparse.getOidCommittish(start) orelse return false;
    const e_oid = revparse.getOidCommittish(end) orelse return false;
    showRev(NORMAL, e_oid, end);
    showRev(if (symmetric) NORMAL else REVERSED, s_oid, start);
    if (symmetric) {
        const a = commitnode.lookupCommitReference(s_oid) orelse return false;
        const b = commitnode.lookupCommitReference(e_oid) orelse return false;
        var l = commitreach.getMergeBases(a, b);
        while (l) |node| : (l = node.next) {
            showRev(REVERSED, node.item.obj.oid, null);
        }
    }
    return true;
}

fn tryParentShorthands(arg: []const u8) bool {
    var include_rev = false;
    var include_parents = false;
    var exclude_parent: usize = 0;
    var mark: usize = undefined;
    if (std.mem.indexOf(u8, arg, "^!")) |m| {
        mark = m;
        include_rev = true;
        if (m + 2 != arg.len) return false;
    } else if (std.mem.indexOf(u8, arg, "^@")) |m| {
        mark = m;
        include_parents = true;
        if (m + 2 != arg.len) return false;
    } else if (std.mem.indexOf(u8, arg, "^-")) |m| {
        mark = m;
        include_rev = true;
        exclude_parent = 1;
        if (m + 2 != arg.len) {
            exclude_parent = std.fmt.parseInt(usize, arg[m + 2 ..], 10) catch return false;
            if (exclude_parent == 0) return false;
        }
    } else return false;
    const base = arg[0..mark];
    const oid = revparse.getOidCommittish(base) orelse return false;
    const commit = commitnode.lookupCommitReference(oid) orelse return false;
    _ = commitnode.parse(commit);
    var count: usize = 0;
    var p = commit.parents;
    while (p) |node| : (p = node.next) count += 1;
    if (exclude_parent > 0 and exclude_parent > count) return false;
    if (include_rev) showRev(NORMAL, oid, base);
    p = commit.parents;
    var num: usize = 1;
    while (p) |node| : ({
        p = node.next;
        num += 1;
    }) {
        if (exclude_parent > 0 and num != exclude_parent) continue;
        const name: ?[]const u8 = if (symbolic != .none) util.fmt("{s}^{d}", .{ base, num }) else null;
        showRev(if (include_parents) NORMAL else REVERSED, node.item.obj.oid, name);
    }
    return true;
}

fn refExcluded(name: []const u8) bool {
    for (excludes.items) |pat| {
        if (wildmatch.match(pat, name, 0)) return true;
    }
    return false;
}

fn handleRefOpt(pattern: ?[]const u8, prefix: ?[]const u8) void {
    const all = refs.iterate("refs/", .{});
    var real_pattern: ?[]const u8 = null;
    if (pattern) |pat| {
        var b: util.Buf = .empty;
        if (prefix == null and !util.startsWith(pat, "refs/")) util.bufAppend(&b, "refs/") else if (prefix) |p| util.bufAppend(&b, p);
        util.bufAppend(&b, pat);
        if (!wildmatch.hasGlobChars(pat)) {
            if (b.items.len > 0 and b.items[b.items.len - 1] != '/') util.bufByte(&b, '/');
            util.bufByte(&b, '*');
        }
        real_pattern = b.items;
    }
    for (all) |r| {
        if (prefix) |p| {
            if (!util.startsWith(r.name, p)) continue;
        }
        if (real_pattern) |rp| {
            if (!wildmatch.match(rp, r.name, 0)) continue;
        }
        const shown = if (prefix) |p| r.name[p.len..] else r.name;
        if (refExcluded(shown)) continue;
        showRev(NORMAL, r.oid, shown);
    }
    excludes.clearRetainingCapacity();
}

// ---------------- path formatting ----------------

const PathFormat = enum { unmodified, relative, relative_if_shared, canonical };
const FormatType = enum { relative, canonical, default };

fn realpathForgiving(path: []const u8) []const u8 {
    if (os.realPath(path)) |r| return r;
    const abs = if (path.len > 0 and path[0] == '/') path else util.concat(&.{ os.getcwd(), "/", path });
    const n = util.normalizePath(abs) orelse abs;
    // resolve the longest existing leading directory
    var end = n.len;
    while (end > 1) {
        const slash = std.mem.lastIndexOfScalar(u8, n[0..end], '/') orelse break;
        if (slash == 0) break;
        if (os.realPath(n[0..slash])) |r| return util.concat(&.{ r, n[slash..] });
        end = slash;
    }
    return n;
}

/// relative_path() from path.c
fn relativePath(in: []const u8, prefix: []const u8) []const u8 {
    if (in.len == 0) return "./";
    if (prefix.len == 0) return in;
    const in_abs = in[0] == '/';
    const pre_abs = prefix[0] == '/';
    if (in_abs != pre_abs) return in;
    var i: usize = 0;
    var j: usize = 0;
    var in_off: usize = 0;
    var prefix_off: usize = 0;
    while (i < prefix.len and j < in.len and prefix[i] == in[j]) {
        if (prefix[i] == '/') {
            while (i < prefix.len and prefix[i] == '/') i += 1;
            while (j < in.len and in[j] == '/') j += 1;
            prefix_off = i;
            in_off = j;
        } else {
            i += 1;
            j += 1;
        }
    }
    if (i >= prefix.len and prefix_off < prefix.len) {
        if (j >= in.len) {
            in_off = in.len;
        } else if (in[j] == '/') {
            while (j < in.len and in[j] == '/') j += 1;
            in_off = j;
        } else {
            i = prefix_off;
        }
    } else if (j >= in.len and in_off < in.len) {
        if (i < prefix.len and prefix[i] == '/') {
            while (i < prefix.len and prefix[i] == '/') i += 1;
            in_off = in.len;
        }
    }
    const rest = in[in_off..];
    if (i >= prefix.len) {
        return if (rest.len == 0) "./" else rest;
    }
    var b: util.Buf = .empty;
    while (i < prefix.len) {
        if (prefix[i] == '/') {
            util.bufAppend(&b, "../");
            while (i < prefix.len and prefix[i] == '/') i += 1;
            continue;
        }
        i += 1;
    }
    if (prefix[prefix.len - 1] != '/') util.bufAppend(&b, "../");
    util.bufAppend(&b, rest);
    return b.items;
}

fn printPath(path: []const u8, prefix: ?[]const u8, format: FormatType, dflt: PathFormat) void {
    const fmt: PathFormat = switch (format) {
        .default => dflt,
        .relative => .relative,
        .canonical => .canonical,
    };
    const out = switch (fmt) {
        .unmodified => path,
        .relative => blk: {
            var pfx = prefix orelse os.getcwd();
            var p = path;
            if (p.len == 0 or p[0] != '/') p = realpathForgiving(p);
            if (pfx.len == 0 or pfx[0] != '/') pfx = realpathForgiving(pfx);
            break :blk relativePath(p, pfx);
        },
        .relative_if_shared => relativePath(path, prefix orelse ""),
        .canonical => realpathForgiving(path),
    };
    util.outf("{s}\n", .{out});
}

/// repo_git_path(): path to a file in the git dir, honoring env overrides and common dir.
fn gitPath(name: []const u8) []const u8 {
    const r = repo_mod.repo();
    if (util.eql(name, "index")) {
        if (os.getenv("GIT_INDEX_FILE")) |p| return p;
    }
    if (util.eql(name, "objects") or util.startsWith(name, "objects/")) {
        if (os.getenv("GIT_OBJECT_DIRECTORY")) |p| return util.concat(&.{ p, name[7..] });
    }
    if (util.eql(name, "info/grafts")) {
        if (os.getenv("GIT_GRAFT_FILE")) |p| return p;
    }
    if (util.eql(name, "hooks") or util.startsWith(name, "hooks/")) {
        if (repo_mod.cfg.get("core.hookspath")) |hp| return util.concat(&.{ hp, name[5..] });
    }
    if (!util.eql(r.git_dir, r.common_dir) and isCommonPath(name)) return util.concat(&.{ r.common_dir, "/", name });
    return util.concat(&.{ r.git_dir, "/", name });
}

fn isCommonPath(name: []const u8) bool {
    const Common = struct { p: []const u8, dir: bool, exclude: bool };
    const common = [_]Common{
        .{ .p = "branches", .dir = true, .exclude = false },
        .{ .p = "common", .dir = true, .exclude = false },
        .{ .p = "config", .dir = false, .exclude = false },
        .{ .p = "hooks", .dir = true, .exclude = false },
        .{ .p = "info", .dir = true, .exclude = false },
        .{ .p = "info/sparse-checkout", .dir = false, .exclude = true },
        .{ .p = "logs", .dir = true, .exclude = true },
        .{ .p = "logs/HEAD", .dir = false, .exclude = true },
        .{ .p = "logs/refs/bisect", .dir = true, .exclude = true },
        .{ .p = "logs/refs/rewritten", .dir = true, .exclude = true },
        .{ .p = "logs/refs/worktree", .dir = true, .exclude = true },
        .{ .p = "lost-found", .dir = true, .exclude = false },
        .{ .p = "objects", .dir = true, .exclude = false },
        .{ .p = "packed-refs", .dir = false, .exclude = false },
        .{ .p = "refs", .dir = true, .exclude = false },
        .{ .p = "refs/bisect", .dir = true, .exclude = true },
        .{ .p = "refs/rewritten", .dir = true, .exclude = true },
        .{ .p = "refs/worktree", .dir = true, .exclude = true },
        .{ .p = "remotes", .dir = true, .exclude = false },
        .{ .p = "worktrees", .dir = true, .exclude = false },
        .{ .p = "rr-cache", .dir = true, .exclude = false },
        .{ .p = "svn", .dir = true, .exclude = false },
        .{ .p = "shallow", .dir = false, .exclude = false },
    };
    // longest matching entry decides
    var best: ?Common = null;
    for (common) |c| {
        const matches = if (c.dir)
            (util.eql(name, c.p) or (util.startsWith(name, c.p) and name.len > c.p.len and name[c.p.len] == '/'))
        else
            util.eql(name, c.p);
        if (matches and (best == null or c.p.len > best.?.p.len)) best = c;
    }
    const b = best orelse return false;
    return !b.exclude;
}

// ---------------- --parseopt ----------------

var parsed: util.Buf = .empty;
var stuck_long = false;

fn parseoptDump(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    if (unset) {
        util.bufPrint(&parsed, " --no-{s}", .{o.long});
    } else if (o.short != 0 and (o.long.len == 0 or !stuck_long)) {
        util.bufPrint(&parsed, " -{c}", .{o.short});
    } else {
        util.bufPrint(&parsed, " --{s}", .{o.long});
    }
    if (arg) |a| {
        if (!stuck_long) {
            util.bufByte(&parsed, ' ');
        } else if (o.long.len > 0) util.bufByte(&parsed, '=');
        util.sqQuote(&parsed, a);
    }
}

fn dummyCb(_: ?[]const u8, _: bool) void {}

fn cmdParseopt(args: []const []const u8) u8 {
    var keep_dashdash = false;
    var stop_at_non_option = false;
    const popts = [_]po.Opt{
        po.boolean(0, "keep-dashdash", &keep_dashdash, "keep the `--` passed as an arg"),
        po.boolean(0, "stop-at-non-option", &stop_at_non_option, "stop parsing after the first non-option argument"),
        po.boolean(0, "stuck-long", &stuck_long, "output in stuck long form"),
    };
    const pusage = [_][]const u8{"git rev-parse --parseopt [<options>] -- [<args>...]"};
    const rest = po.parse(args, &popts, &pusage, .{ .keep_dashdash = true });
    if (rest.len < 1 or !util.eql(rest[0], "--")) po.usageExit(&pusage, &popts, true);

    const input = os.readAllFd(0) catch util.die("could not read from stdin", .{});
    var lines: std.ArrayList([]const u8) = .empty;
    {
        var it = std.mem.splitScalar(u8, input, '\n');
        while (it.next()) |l0| {
            var l = l0;
            if (l.len > 0 and l[l.len - 1] == '\r') l = l[0 .. l.len - 1];
            lines.append(gpa, l) catch util.oom();
        }
        if (input.len > 0 and input[input.len - 1] == '\n') _ = lines.pop();
        if (input.len == 0) _ = lines.pop();
    }
    var usage: std.ArrayList([]const u8) = .empty;
    var li: usize = 0;
    while (true) : (li += 1) {
        if (li >= lines.items.len) util.die("premature end of input", .{});
        const l = lines.items[li];
        if (util.eql(l, "--")) {
            if (usage.items.len == 0) util.die("no usage string given before the `--' separator", .{});
            li += 1;
            break;
        }
        usage.append(gpa, l) catch util.oom();
    }
    var opts: std.ArrayList(po.Opt) = .empty;
    while (li < lines.items.len) : (li += 1) {
        const l = lines.items[li];
        if (l.len == 0) continue;
        const help_pos = std.mem.indexOfAny(u8, l, " \t\n\r\x0b\x0c");
        if (help_pos == null or help_pos.? == 0) {
            opts.append(gpa, .{ .kind = .group, .help = std.mem.trimStart(u8, l, " \t\n\r\x0b\x0c") }) catch util.oom();
            continue;
        }
        const hp = help_pos.?;
        var o = po.Opt{ .kind = .callback, .cb = dummyCb, .cbx = parseoptDump, .noarg = true };
        o.help = std.mem.trimStart(u8, l[hp + 1 ..], " \t\n\r\x0b\x0c");
        const spec = l[0..hp];
        var s = std.mem.indexOfAny(u8, spec, "*=?!") orelse hp;
        if (s == 0) util.die("missing opt-spec before option flags", .{});
        if (s == 1) {
            o.short = spec[0];
        } else if (spec[1] != ',') {
            o.long = spec[0..s];
        } else {
            o.short = spec[0];
            o.long = spec[2..s];
        }
        while (s < hp) {
            switch (spec[s]) {
                '=' => o.noarg = false,
                '?' => {
                    o.noarg = false;
                    o.optarg = true;
                },
                '!' => o.noneg = true,
                '*' => o.hidden = true,
                else => break,
            }
            s += 1;
        }
        if (s < hp) o.argh = spec[s..hp];
        opts.append(gpa, o) catch util.oom();
    }
    util.bufAppend(&parsed, "set --");
    po.shell_eval = true;
    const remaining = po.parse(rest[1..], opts.items, usage.items, .{ .keep_dashdash = keep_dashdash, .stop_at_non_option = stop_at_non_option });
    util.bufAppend(&parsed, " --");
    for (remaining) |a| {
        util.bufByte(&parsed, ' ');
        util.sqQuote(&parsed, a);
    }
    util.outf("{s}\n", .{parsed.items});
    return 0;
}

fn dieNoSingleRev(quiet: bool) noreturn {
    if (quiet) os.exit(1);
    util.die("Needed a single revision", .{});
}

fn optWithValue(arg: []const u8, opt: []const u8) ?struct { v: ?[]const u8 } {
    const r = util.skipPrefix(arg, opt) orelse return null;
    if (r.len == 0) return .{ .v = null };
    if (r[0] == '=') return .{ .v = r[1..] };
    return null;
}

const local_repo_env = [_][]const u8{
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CONFIG",                  "GIT_CONFIG_COUNT",
    "GIT_CONFIG_PARAMETERS",            "GIT_DIR",                     "GIT_GRAFT_FILE",
    "GIT_IMPLICIT_WORK_TREE",           "GIT_INDEX_FILE",              "GIT_INTERNAL_SUPER_PREFIX",
    "GIT_NO_REPLACE_OBJECTS",           "GIT_OBJECT_DIRECTORY",        "GIT_PREFIX",
    "GIT_REPLACE_REF_BASE",             "GIT_SHALLOW_FILE",            "GIT_COMMON_DIR",
    "GIT_WORK_TREE",
};

pub fn cmdRevParse(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.outf("usage: {s}\n", .{builtin_usage});
        os.exit(0);
    }
    if (args.len > 1 and util.eql(args[1], "--parseopt")) return cmdParseopt(args[2..]);
    if (args.len > 1 and util.eql(args[1], "--sq-quote")) {
        var b: util.Buf = .empty;
        for (args[2..]) |a| {
            util.bufByte(&b, ' ');
            util.sqQuote(&b, a);
        }
        util.outf("{s}\n", .{b.items});
        return 0;
    }
    var has_dashdash = false;
    for (args[1..]) |a| {
        if (util.eql(a, "--")) {
            has_dashdash = true;
            break;
        }
    }
    if (args.len == 1) {
        repo_mod.setup(false);
        return 0;
    }
    var as_is: u8 = 0;
    var verify = false;
    var quiet = false;
    var revs_count: usize = 0;
    var typ: bool = NORMAL;
    var did_setup = false;
    var output_prefix = false;
    var last_oid: Oid = hash.zero;
    var name: []const u8 = "";
    var seen_eoo = false;
    var format: FormatType = .default;
    var prefix: ?[]const u8 = null;

    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (as_is != 0) {
            if (showFile(arg, output_prefix) and as_is < 2) revparse.verifyFilename(prefix orelse "", arg, false);
            continue;
        }
        if (!seen_eoo) {
            if (util.eql(arg, "--local-env-vars")) {
                for (local_repo_env) |e| util.outf("{s}\n", .{e});
                continue;
            }
            if (util.eql(arg, "--resolve-git-dir")) {
                i += 1;
                if (i >= args.len) util.die("--resolve-git-dir requires an argument", .{});
                const gd = args[i];
                if (repo_mod.isGitDirectory(gd)) {
                    util.outf("{s}\n", .{gd});
                } else {
                    const st = os.statPath(gd);
                    if (st != null and st.?.isReg()) {
                        util.outf("{s}\n", .{repo_mod.readGitfile(gd) orelse util.die("not a gitdir '{s}'", .{gd})});
                    } else util.die("not a gitdir '{s}'", .{gd});
                }
                continue;
            }
        }
        if (!did_setup) {
            repo_mod.setup(false);
            did_setup = true;
            const p = repo_mod.repo().prefix;
            prefix = if (p.len > 0) p else null;
        }
        if (util.eql(arg, "--")) {
            as_is = 2;
            if (filter & (DO_FLAGS | DO_REVS) != 0) _ = showFile(arg, false);
            continue;
        }
        if (!seen_eoo and arg.len > 0 and arg[0] == '-') {
            if (util.eql(arg, "--git-path")) {
                if (i + 1 >= args.len) util.die("--git-path requires an argument", .{});
                printPath(gitPath(args[i + 1]), prefix, format, .relative_if_shared);
                i += 1;
                continue;
            }
            if (util.eql(arg, "-n")) {
                i += 1;
                if (i >= args.len) util.die("-n requires an argument", .{});
                if (filter & DO_FLAGS != 0 and filter & DO_REVS != 0) {
                    show(arg);
                    show(args[i]);
                }
                continue;
            }
            if (util.startsWith(arg, "-n")) {
                if (filter & DO_FLAGS != 0 and filter & DO_REVS != 0) show(arg);
                continue;
            }
            if (optWithValue(arg, "--path-format")) |ov| {
                const v = ov.v orelse util.die("--path-format requires an argument", .{});
                if (util.eql(v, "absolute")) {
                    format = .canonical;
                } else if (util.eql(v, "relative")) {
                    format = .relative;
                } else util.die("unknown argument to --path-format: {s}", .{v});
                continue;
            }
            if (util.eql(arg, "--default")) {
                i += 1;
                if (i >= args.len) util.die("--default requires an argument", .{});
                def = args[i];
                continue;
            }
            if (util.eql(arg, "--prefix")) {
                i += 1;
                if (i >= args.len) util.die("--prefix requires an argument", .{});
                prefix = args[i];
                repo_mod.repo().prefix = args[i];
                output_prefix = true;
                continue;
            }
            if (util.eql(arg, "--revs-only")) {
                filter &= ~DO_NOREV;
                continue;
            }
            if (util.eql(arg, "--no-revs")) {
                filter &= ~DO_REVS;
                continue;
            }
            if (util.eql(arg, "--flags")) {
                filter &= ~DO_NONFLAGS;
                continue;
            }
            if (util.eql(arg, "--no-flags")) {
                filter &= ~DO_FLAGS;
                continue;
            }
            if (util.eql(arg, "--verify")) {
                filter &= ~(DO_FLAGS | DO_NOREV);
                verify = true;
                continue;
            }
            if (util.eql(arg, "--quiet") or util.eql(arg, "-q")) {
                quiet = true;
                continue;
            }
            if (optWithValue(arg, "--output-object-format")) |ov| {
                const v = ov.v orelse util.die("no object format specified", .{});
                if (util.eql(v, "sha1") or util.eql(v, "storage")) continue;
                util.die("unsupported object format: {s}", .{v});
            }
            if (optWithValue(arg, "--short")) |ov| {
                filter &= ~(DO_FLAGS | DO_NOREV);
                verify = true;
                abbrev = revparse.defaultAbbrev();
                if (ov.v) |v| {
                    const n = std.fmt.parseInt(i64, v, 10) catch 0;
                    abbrev = if (n < 4) 4 else if (n >= 40) 40 else @intCast(n);
                }
                continue;
            }
            if (util.eql(arg, "--sq")) {
                output_sq = true;
                continue;
            }
            if (util.eql(arg, "--not")) {
                show_type = !show_type;
                continue;
            }
            if (util.eql(arg, "--symbolic")) {
                symbolic = .asis;
                continue;
            }
            if (util.eql(arg, "--symbolic-full-name")) {
                symbolic = .full;
                continue;
            }
            if (optWithValue(arg, "--abbrev-ref")) |ov| {
                abbrev_ref = true;
                abbrev_ref_strict = repo_mod.cfg.getBool("core.warnambiguousrefs") orelse true;
                if (ov.v) |v| {
                    if (util.eql(v, "strict")) {
                        abbrev_ref_strict = true;
                    } else if (util.eql(v, "loose")) {
                        abbrev_ref_strict = false;
                    } else util.die("unknown mode for --abbrev-ref: {s}", .{v});
                }
                continue;
            }
            if (util.eql(arg, "--all")) {
                for (refs.iterate("refs/", .{})) |r| {
                    if (refExcluded(r.name)) continue;
                    showRev(NORMAL, r.oid, r.name);
                }
                excludes.clearRetainingCapacity();
                continue;
            }
            if (util.skipPrefix(arg, "--disambiguate=")) |pfx| {
                if (pfx.len < 4 or pfx.len > 40 or !allHex(pfx)) continue;
                var l: std.ArrayList(Oid) = .empty;
                repo_mod.repo().odb().findByPrefix(pfx, &l);
                std.mem.sort(Oid, l.items, {}, hash.lessThan);
                var prev: ?Oid = null;
                for (l.items) |o| {
                    if (prev) |pv| {
                        if (hash.eql(pv, o)) continue;
                    }
                    prev = o;
                    showRev(NORMAL, o, null);
                }
                continue;
            }
            if (util.eql(arg, "--bisect")) {
                var bad: []const u8 = "bad";
                var good: []const u8 = "good";
                if (os.readFile(repo_mod.repo().gitPath("BISECT_TERMS"))) |t| {
                    var it = std.mem.splitScalar(u8, t, '\n');
                    if (it.next()) |b| bad = b;
                    if (it.next()) |g| good = g;
                }
                const bp = util.concat(&.{ "refs/bisect/", bad });
                const gp = util.concat(&.{ "refs/bisect/", good });
                for (refs.iterate(bp, .{})) |r| {
                    if (refExcluded(r.name)) continue;
                    showRev(NORMAL, r.oid, r.name);
                }
                for (refs.iterate(gp, .{})) |r| showRev(REVERSED, r.oid, r.name);
                continue;
            }
            if (optWithValue(arg, "--branches")) |ov| {
                handleRefOpt(ov.v, "refs/heads/");
                continue;
            }
            if (optWithValue(arg, "--tags")) |ov| {
                handleRefOpt(ov.v, "refs/tags/");
                continue;
            }
            if (util.skipPrefix(arg, "--glob=")) |g| {
                handleRefOpt(g, null);
                continue;
            }
            if (optWithValue(arg, "--remotes")) |ov| {
                handleRefOpt(ov.v, "refs/remotes/");
                continue;
            }
            if (util.skipPrefix(arg, "--exclude=")) |e| {
                excludes.append(gpa, e) catch util.oom();
                continue;
            }
            if (util.skipPrefix(arg, "--exclude-hidden=")) |_| {
                continue;
            }
            if (util.eql(arg, "--show-toplevel")) {
                const wt = repo_mod.repo().work_tree orelse util.die("this operation must be run in a work tree", .{});
                printPath(wt, prefix, format, .unmodified);
                continue;
            }
            if (util.eql(arg, "--show-superproject-working-tree")) continue;
            if (util.eql(arg, "--show-prefix")) {
                util.outf("{s}\n", .{prefix orelse ""});
                continue;
            }
            if (util.eql(arg, "--show-cdup")) {
                if (!revparse.isInsideWorkTree()) {
                    if (repo_mod.repo().work_tree) |wt| util.outf("{s}\n", .{wt});
                    continue;
                }
                if (prefix) |p| {
                    for (p) |ch| {
                        if (ch == '/') util.out("../");
                    }
                }
                util.out("\n");
                continue;
            }
            if (util.eql(arg, "--git-dir") or util.eql(arg, "--absolute-git-dir")) {
                var gitdir = os.getenv("GIT_DIR");
                var wanted = format;
                if (arg[2] == 'g') {
                    if (gitdir) |g| {
                        printPath(g, prefix, format, .unmodified);
                        continue;
                    }
                    if (prefix == null) {
                        printPath(".git", prefix, format, .unmodified);
                        continue;
                    }
                } else {
                    wanted = .canonical;
                    if (gitdir == null and prefix == null) gitdir = ".git";
                    if (gitdir) |g| {
                        util.outf("{s}\n", .{os.realPath(g) orelse realpathForgiving(g)});
                        continue;
                    }
                }
                const cwd = os.getcwd();
                const p = util.concat(&.{ cwd, if (cwd.len > 0 and cwd[cwd.len - 1] != '/') "/" else "", ".git" });
                printPath(p, prefix, wanted, .canonical);
                continue;
            }
            if (util.eql(arg, "--git-common-dir")) {
                printPath(repo_mod.repo().common_dir, prefix, format, .relative_if_shared);
                continue;
            }
            if (util.eql(arg, "--is-inside-git-dir")) {
                util.outf("{s}\n", .{if (revparse.isInsideGitDir()) "true" else "false"});
                continue;
            }
            if (util.eql(arg, "--is-inside-work-tree")) {
                util.outf("{s}\n", .{if (revparse.isInsideWorkTree()) "true" else "false"});
                continue;
            }
            if (util.eql(arg, "--is-bare-repository")) {
                const r = repo_mod.repo();
                const bare = r.bare_cfg != 0 and r.work_tree == null;
                util.outf("{s}\n", .{if (bare) "true" else "false"});
                continue;
            }
            if (util.eql(arg, "--is-shallow-repository")) {
                const sh = os.statPath(repo_mod.repo().gitPath("shallow"));
                util.outf("{s}\n", .{if (sh != null and sh.?.size > 0) "true" else "false"});
                continue;
            }
            if (util.eql(arg, "--shared-index-path")) {
                const sidx = @import("../index.zig").get();
                if (sidx.split) |si| {
                    const hx = hash.hex(si.base_oid);
                    printPath(gitPath(util.concat(&.{ "sharedindex.", &hx })), prefix, format, .relative);
                }
                continue;
            }
            if (util.skipPrefix(arg, "--since=") orelse util.skipPrefix(arg, "--after=")) |v| {
                showDatestring("--max-age=", v);
                continue;
            }
            if (util.skipPrefix(arg, "--before=") orelse util.skipPrefix(arg, "--until=")) |v| {
                showDatestring("--min-age=", v);
                continue;
            }
            if (optWithValue(arg, "--show-object-format")) |ov| {
                const v = ov.v orelse "storage";
                if (!util.eql(v, "storage") and !util.eql(v, "compat") and !util.eql(v, "input") and !util.eql(v, "output"))
                    util.die("unknown mode for --show-object-format: {s}", .{v});
                if (util.eql(v, "compat")) util.out("\n") else util.outf("{s}\n", .{repo_mod.repo().object_format});
                continue;
            }
            if (util.eql(arg, "--show-ref-format")) {
                util.outf("{s}\n", .{repo_mod.repo().ref_storage});
                continue;
            }
            if (util.eql(arg, "--end-of-options")) {
                seen_eoo = true;
                if (filter & (DO_FLAGS | DO_REVS) != 0) _ = showFile(arg, false);
                continue;
            }
            if (showFlag(arg) and verify) dieNoSingleRev(quiet);
            continue;
        }

        // not a flag
        if (tryDifference(arg)) continue;
        if (tryParentShorthands(arg)) continue;
        name = arg;
        typ = NORMAL;
        if (arg.len > 0 and arg[0] == '^') {
            name = arg[1..];
            typ = REVERSED;
        }
        if (revparse.resolve(name, .{ .quiet = quiet, .quietly = quiet })) |res| {
            last_oid = res.oid;
            if (verify) revs_count += 1 else showRev(typ, res.oid, name);
            continue;
        }
        if (verify) dieNoSingleRev(quiet);
        if (has_dashdash) util.die("bad revision '{s}'", .{arg});
        as_is = 1;
        if (!showFile(arg, output_prefix)) continue;
        revparse.verifyFilename(prefix orelse "", arg, true);
    }
    if (verify) {
        if (revs_count == 1) {
            showRev(typ, last_oid, name);
            return 0;
        } else if (revs_count == 0 and showDefault()) return 0;
        dieNoSingleRev(quiet);
    } else _ = showDefault();
    return 0;
}

fn allHex(s: []const u8) bool {
    for (s) |ch| if (!std.ascii.isHex(ch)) return false;
    return true;
}
