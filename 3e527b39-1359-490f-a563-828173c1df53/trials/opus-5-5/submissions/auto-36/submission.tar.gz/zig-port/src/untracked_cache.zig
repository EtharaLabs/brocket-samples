//! Untracked cache (dir.c: UNTR index extension, struct untracked_cache).
//!
//! Data structures, (de)serialization and invalidation live here; the
//! directory walk that uses/refreshes the cache is in dir.zig.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const ewah = @import("ewah.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const index_mod = @import("index.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

pub const DIR_SHOW_IGNORED: u32 = 1 << 0;
pub const DIR_SHOW_OTHER_DIRECTORIES: u32 = 1 << 1;
pub const DIR_HIDE_EMPTY_DIRECTORIES: u32 = 1 << 2;
pub const DIR_NO_GITLINKS: u32 = 1 << 3;
pub const DIR_COLLECT_IGNORED: u32 = 1 << 4;
pub const DIR_SHOW_IGNORED_TOO: u32 = 1 << 5;
pub const DIR_COLLECT_KILLED_ONLY: u32 = 1 << 6;
pub const DIR_KEEP_UNTRACKED_CONTENTS: u32 = 1 << 7;
pub const DIR_SHOW_IGNORED_TOO_MODE_MATCHING: u32 = 1 << 8;
pub const DIR_SKIP_NESTED_GIT: u32 = 1 << 9;

/// struct stat_data
pub const StatData = struct {
    ctime_s: u32 = 0,
    ctime_ns: u32 = 0,
    mtime_s: u32 = 0,
    mtime_ns: u32 = 0,
    dev: u32 = 0,
    ino: u32 = 0,
    uid: u32 = 0,
    gid: u32 = 0,
    size: u32 = 0,

    /// fill_stat_data()
    pub fn fill(self: *StatData, st: os.Stat) void {
        self.ctime_s = @truncate(@as(u64, @bitCast(st.ctime)));
        self.ctime_ns = @truncate(@as(u64, @bitCast(st.ctime_ns)));
        self.mtime_s = @truncate(@as(u64, @bitCast(st.mtime)));
        self.mtime_ns = @truncate(@as(u64, @bitCast(st.mtime_ns)));
        self.dev = @truncate(st.dev);
        self.ino = @truncate(st.ino);
        self.uid = st.uid;
        self.gid = st.gid;
        self.size = @truncate(@as(u64, @bitCast(st.size)));
    }

    /// match_stat_data() (without USE_NSEC / USE_STDEV); nonzero if changed.
    pub fn matches(self: *const StatData, st: os.Stat) bool {
        const trust_ctime = repo_mod.cfg.getBool("core.trustctime") orelse true;
        const check_stat = !util.eql(repo_mod.cfg.get("core.checkstat") orelse "default", "minimal");
        if (self.mtime_s != @as(u32, @truncate(@as(u64, @bitCast(st.mtime))))) return false;
        if (trust_ctime and check_stat and self.ctime_s != @as(u32, @truncate(@as(u64, @bitCast(st.ctime))))) return false;
        if (check_stat) {
            if (self.uid != st.uid or self.gid != st.gid) return false;
            if (self.ino != @as(u32, @truncate(st.ino))) return false;
        }
        if (self.size != @as(u32, @truncate(@as(u64, @bitCast(st.size))))) return false;
        return true;
    }

    /// !match_stat_data_racy(): true when unchanged and not racy.
    pub fn matchesRacy(self: *const StatData, idx: ?*const index_mod.Index, st: os.Stat) bool {
        if (idx) |ix| {
            if (ix.timestamp_s != 0 and ix.timestamp_s <= self.mtime_s) return false;
        }
        return self.matches(st);
    }

    fn toDisk(self: *const StatData, b: *util.Buf) void {
        const vals = [_]u32{ self.ctime_s, self.ctime_ns, self.mtime_s, self.mtime_ns, self.dev, self.ino, self.uid, self.gid, self.size };
        var t: [4]u8 = undefined;
        for (vals) |v| {
            std.mem.writeInt(u32, &t, v, .big);
            util.bufAppend(b, &t);
        }
    }

    fn fromDisk(d: []const u8) StatData {
        const r = struct {
            fn g(x: []const u8, i: usize) u32 {
                return std.mem.readInt(u32, x[i * 4 ..][0..4], .big);
            }
        }.g;
        return .{ .ctime_s = r(d, 0), .ctime_ns = r(d, 1), .mtime_s = r(d, 2), .mtime_ns = r(d, 3), .dev = r(d, 4), .ino = r(d, 5), .uid = r(d, 6), .gid = r(d, 7), .size = r(d, 8) };
    }
};
const STAT_DATA_SIZE = 36;

/// struct oid_stat
pub const OidStat = struct {
    stat: StatData = .{},
    oid: Oid = hash.zero,
    valid: bool = false,
};

/// struct untracked_cache_dir
pub const UDir = struct {
    dirs: std.ArrayList(*UDir) = .empty,
    untracked: std.ArrayList([]const u8) = .empty,
    stat_data: StatData = .{},
    check_only: bool = false,
    /// all data except 'dirs' in this struct are good
    valid: bool = false,
    recurse: bool = false,
    /// null oid: this directory does not have .gitignore
    exclude_oid: Oid = hash.zero,
    name: []const u8,
};

pub const Cache = struct {
    raw: []const u8 = "",
    ss_info_exclude: OidStat = .{},
    ss_excludes_file: OidStat = .{},
    exclude_per_dir: []const u8 = ".gitignore",
    /// includes the trailing NUL
    ident: []const u8 = "",
    dir_flags: u32 = 0,
    root: ?*UDir = null,
    // statistics
    dir_created: i64 = 0,
    gitignore_invalidated: i64 = 0,
    dir_invalidated: i64 = 0,
    dir_opened: i64 = 0,
    use_fsmonitor: bool = false,
};

// ---------------------------------------------------------------------------
// varint.c

pub fn encodeVarint(value0: u64, b: *util.Buf) void {
    var varint: [16]u8 = undefined;
    var pos: usize = varint.len - 1;
    var value = value0;
    varint[pos] = @intCast(value & 127);
    value >>= 7;
    while (value != 0) : (value >>= 7) {
        value -= 1;
        pos -= 1;
        varint[pos] = @intCast(128 | (value & 127));
    }
    util.bufAppend(b, varint[pos..]);
}

/// decode_varint(); advances *p. Returns 0 on overflow (like C). Reading past
/// the end yields a position beyond data.len (callers check).
fn decodeVarint(data: []const u8, p: *usize) u64 {
    var i = p.*;
    if (i >= data.len) {
        p.* = data.len + 1;
        return 0;
    }
    var c = data[i];
    i += 1;
    var val: u64 = c & 127;
    while (c & 128 != 0) {
        val +%= 1;
        if (val == 0 or (val >> 57) != 0) return 0;
        if (i >= data.len) {
            p.* = data.len + 1;
            return 0;
        }
        c = data[i];
        i += 1;
        val = (val << 7) + (c & 127);
    }
    p.* = i;
    return val;
}

// ---------------------------------------------------------------------------
// ident

const Utsname = extern struct {
    sysname: [65]u8,
    nodename: [65]u8,
    release: [65]u8,
    version: [65]u8,
    machine: [65]u8,
    domainname: [65]u8,
};
extern "c" fn uname(buf: *Utsname) c_int;

var ident_cache: ?[]const u8 = null;

/// get_ident_string()
pub fn identString() []const u8 {
    if (ident_cache) |s| return s;
    var u: Utsname = undefined;
    if (uname(&u) < 0) util.die("failed to get kernel name and information", .{});
    const sys = std.mem.sliceTo(&u.sysname, 0);
    const wt = if (repo_mod.repo_) |r| (r.work_tree orelse "") else "";
    const awt = if (wt.len > 0 and wt[0] != '/') (os.realPath(wt) orelse wt) else wt;
    ident_cache = util.fmt("Location {s}, system {s}", .{ awt, sys });
    return ident_cache.?;
}

/// ident_in_untracked()
pub fn identMatches(uc: *const Cache) bool {
    const first = std.mem.sliceTo(uc.ident, 0);
    return util.eql(first, identString());
}

// ---------------------------------------------------------------------------
// core.untrackedCache

pub const Setting = enum { keep, remove, write };

/// repo settings core_untracked_cache
pub fn coreSetting() Setting {
    var s: Setting = .keep;
    if (repo_mod.cfg.getBool("feature.manyfiles") orelse false) s = .write;
    if (repo_mod.cfg.get("core.untrackedcache")) |v| {
        if (config.parseBool(v)) |b| s = if (b) .write else .remove;
    }
    return s;
}

/// new_untracked_cache_flags()
pub fn newFlags() u32 {
    if (repo_mod.cfg.get("status.showuntrackedfiles")) |v| {
        if (util.eql(v, "all")) return 0;
    }
    return DIR_SHOW_OTHER_DIRECTORIES | DIR_HIDE_EMPTY_DIRECTORIES;
}

/// new_untracked_cache()
pub fn newCache(idx: *index_mod.Index, flags: ?u32) void {
    const uc = gpa.create(Cache) catch util.oom();
    uc.* = .{
        .dir_flags = flags orelse newFlags(),
        .ident = util.concat(&.{ identString(), "\x00" }),
    };
    idx.untracked = uc;
    idx.changed = true;
}

pub fn newDir(name: []const u8) *UDir {
    const d = gpa.create(UDir) catch util.oom();
    d.* = .{ .name = util.dupe(name) };
    return d;
}

/// lookup_untracked(): find or create the child `name` (trailing '/' ignored).
pub fn lookup(uc: ?*Cache, dir: ?*UDir, name0: []const u8) ?*UDir {
    const d = dir orelse return null;
    var name = name0;
    if (name.len > 0 and name[name.len - 1] == '/') name = name[0 .. name.len - 1];
    var first: usize = 0;
    var last: usize = d.dirs.items.len;
    while (last > first) {
        const next = first + ((last - first) >> 1);
        const c = d.dirs.items[next];
        // strncmp(name, c->name, len), then longer c->name sorts after
        var cmp = strncmp(name, c.name, name.len);
        if (cmp == 0 and c.name.len > name.len) cmp = -1;
        if (cmp == 0) return c;
        if (cmp < 0) {
            last = next;
            continue;
        }
        first = next + 1;
    }
    if (uc) |u| u.dir_created += 1;
    const nd = newDir(name);
    d.dirs.insert(gpa, first, nd) catch util.oom();
    return nd;
}

fn strncmp(a: []const u8, b: []const u8, n: usize) i32 {
    var i: usize = 0;
    while (i < n) : (i += 1) {
        const ca: u8 = if (i < a.len) a[i] else 0;
        const cb: u8 = if (i < b.len) b[i] else 0;
        if (ca != cb) return if (ca < cb) -1 else 1;
        if (ca == 0) return 0;
    }
    return 0;
}

fn doInvalidateGitignore(dir: *UDir) void {
    dir.valid = false;
    dir.untracked.items.len = 0;
    for (dir.dirs.items) |d| doInvalidateGitignore(d);
}

/// invalidate_gitignore()
pub fn invalidateGitignore(uc: *Cache, dir: *UDir) void {
    uc.gitignore_invalidated += 1;
    doInvalidateGitignore(dir);
}

/// invalidate_directory()
pub fn invalidateDirectory(uc: *Cache, dir: *UDir) void {
    if (dir.valid) uc.dir_invalidated += 1;
    dir.valid = false;
    dir.untracked.items.len = 0;
    for (dir.dirs.items) |d| d.recurse = false;
}

pub fn addUntracked(dir: ?*UDir, name: []const u8) void {
    const d = dir orelse return;
    d.untracked.append(gpa, util.dupe(name)) catch util.oom();
}

// ---------------------------------------------------------------------------
// read_untracked_extension()

const OUC_SIZE = 2 * STAT_DATA_SIZE + 4;

const ReadData = struct {
    index: usize = 0,
    ucd: []*UDir,
    data: []const u8, // whole buffer up to `end`
    p: usize,
};

fn readOneDir(rd: *ReadData) ?*UDir {
    const data = rd.data;
    var p = rd.p;
    const unr = decodeVarint(data, &p);
    if (p > data.len) return null;
    const dnr = decodeVarint(data, &p);
    if (p > data.len) return null;
    const eos = std.mem.indexOfScalarPos(u8, data, p, 0) orelse return null;
    const ud = newDir(data[p..eos]);
    ud.recurse = true;
    p = eos + 1;
    var i: u64 = 0;
    while (i < unr) : (i += 1) {
        if (p > data.len) return null;
        const e = std.mem.indexOfScalarPos(u8, data, p, 0) orelse return null;
        ud.untracked.append(gpa, util.dupe(data[p..e])) catch util.oom();
        p = e + 1;
    }
    if (rd.index >= rd.ucd.len) return null;
    rd.ucd[rd.index] = ud;
    rd.index += 1;
    rd.p = p;
    i = 0;
    while (i < dnr) : (i += 1) {
        const c = readOneDir(rd) orelse return null;
        ud.dirs.append(gpa, c) catch util.oom();
    }
    return ud;
}

/// read_untracked_extension(): null on corruption (silently, like C).
pub fn readExtension(data0: []const u8) ?*Cache {
    if (data0.len <= 1 or data0[data0.len - 1] != 0) return null;
    const data = data0[0 .. data0.len - 1]; // end--
    var next: usize = 0;
    const ident_len = decodeVarint(data, &next);
    if (next > data.len or ident_len > data.len - next) return null;
    const ident = data[next .. next + @as(usize, @intCast(ident_len))];
    next += @intCast(ident_len);
    const epd_off = OUC_SIZE + 2 * hash.RAWSZ;
    if (next + epd_off + 1 > data.len) return null;

    const uc = gpa.create(Cache) catch util.oom();
    uc.* = .{ .ident = util.dupe(ident) };
    uc.ss_info_exclude = .{ .stat = StatData.fromDisk(data[next..]), .valid = true };
    uc.ss_excludes_file = .{ .stat = StatData.fromDisk(data[next + STAT_DATA_SIZE ..]), .valid = true };
    @memcpy(&uc.ss_info_exclude.oid, data[next + OUC_SIZE ..][0..hash.RAWSZ]);
    @memcpy(&uc.ss_excludes_file.oid, data[next + OUC_SIZE + hash.RAWSZ ..][0..hash.RAWSZ]);
    uc.dir_flags = std.mem.readInt(u32, data[next + 2 * STAT_DATA_SIZE ..][0..4], .big);
    // exclude_per_dir: NUL-terminated (the terminator may be the final NUL)
    const epd_start = next + epd_off;
    const epd_end = std.mem.indexOfScalarPos(u8, data, epd_start, 0) orelse data.len;
    uc.exclude_per_dir = util.dupe(data[epd_start..epd_end]);
    next = epd_end + 1;
    if (next >= data.len) {
        return if (next == data.len) uc else null;
    }

    const varint_len = decodeVarint(data, &next);
    if (next > data.len or varint_len == 0) {
        return if (next == data.len) uc else null;
    }
    if (varint_len > data.len) return null;
    var rd = ReadData{
        .ucd = gpa.alloc(*UDir, @intCast(varint_len)) catch util.oom(),
        .data = data,
        .p = next,
    };
    const root = readOneDir(&rd) orelse return null;
    if (rd.index != varint_len) return null;
    uc.root = root;
    next = rd.p;
    const valid = ewah.Bitmap.read(data[next..]) orelse return null;
    next += valid.len;
    const check_only = ewah.Bitmap.read(data[next..]) orelse return null;
    next += check_only.len;
    const sha1_valid = ewah.Bitmap.read(data[next..]) orelse return null;
    next += sha1_valid.len;

    for (check_only.bm.bits()) |pos| {
        if (pos >= rd.index) return null;
        rd.ucd[pos].check_only = true;
    }
    for (valid.bm.bits()) |pos| {
        if (pos >= rd.index) return null;
        if (next + STAT_DATA_SIZE > data.len) return null;
        rd.ucd[pos].stat_data = StatData.fromDisk(data[next..]);
        rd.ucd[pos].valid = true;
        next += STAT_DATA_SIZE;
    }
    for (sha1_valid.bm.bits()) |pos| {
        if (pos >= rd.index) return null;
        if (next + hash.RAWSZ > data.len) return null;
        @memcpy(&rd.ucd[pos].exclude_oid, data[next..][0..hash.RAWSZ]);
        next += hash.RAWSZ;
    }
    if (next != data.len) return null;
    return uc;
}

// ---------------------------------------------------------------------------
// write_untracked_extension()

const WriteData = struct {
    index: usize = 0,
    check_only: ewah.Bitmap,
    valid: ewah.Bitmap,
    sha1_valid: ewah.Bitmap,
    out: util.Buf = .empty,
    sb_stat: util.Buf = .empty,
    sb_sha1: util.Buf = .empty,
};

fn writeOneDir(u: *UDir, wd: *WriteData) void {
    const i = wd.index;
    wd.index += 1;
    if (!u.valid) {
        u.untracked.items.len = 0;
        u.check_only = false;
    }
    if (u.check_only) wd.check_only.set(i);
    if (u.valid) {
        wd.valid.set(i);
        u.stat_data.toDisk(&wd.sb_stat);
    }
    if (!hash.isZero(u.exclude_oid)) {
        wd.sha1_valid.set(i);
        util.bufAppend(&wd.sb_sha1, &u.exclude_oid);
    }
    encodeVarint(u.untracked.items.len, &wd.out);
    var value: u64 = 0;
    for (u.dirs.items) |d| {
        if (d.recurse) value += 1;
    }
    encodeVarint(value, &wd.out);
    util.bufAppend(&wd.out, u.name);
    util.bufByte(&wd.out, 0);
    for (u.untracked.items) |s| {
        util.bufAppend(&wd.out, s);
        util.bufByte(&wd.out, 0);
    }
    for (u.dirs.items) |d| {
        if (d.recurse) writeOneDir(d, wd);
    }
}

/// write_untracked_extension()
pub fn writeExtension(c: *Cache, b: *util.Buf) void {
    encodeVarint(c.ident.len, b);
    util.bufAppend(b, c.ident);
    c.ss_info_exclude.stat.toDisk(b);
    c.ss_excludes_file.stat.toDisk(b);
    var t: [4]u8 = undefined;
    std.mem.writeInt(u32, &t, c.dir_flags, .big);
    util.bufAppend(b, &t);
    util.bufAppend(b, &c.ss_info_exclude.oid);
    util.bufAppend(b, &c.ss_excludes_file.oid);
    util.bufAppend(b, c.exclude_per_dir);
    util.bufByte(b, 0);
    const root = c.root orelse {
        encodeVarint(0, b);
        return;
    };
    var wd = WriteData{ .check_only = ewah.Bitmap.init(), .valid = ewah.Bitmap.init(), .sha1_valid = ewah.Bitmap.init() };
    writeOneDir(root, &wd);
    encodeVarint(wd.index, b);
    util.bufAppend(b, wd.out.items);
    wd.valid.serialize(b);
    wd.check_only.serialize(b);
    wd.sha1_valid.serialize(b);
    util.bufAppend(b, wd.sb_stat.items);
    util.bufAppend(b, wd.sb_sha1.items);
    util.bufByte(b, 0);
}

// ---------------------------------------------------------------------------
// index hooks

/// tweak_untracked_cache(): apply core.untrackedCache.
pub fn tweak(idx: *index_mod.Index) void {
    switch (coreSetting()) {
        .remove => remove(idx),
        .write => add(idx),
        .keep => {},
    }
}

/// add_untracked_cache()
pub fn add(idx: *index_mod.Index) void {
    if (idx.untracked) |u| {
        if (!identMatches(u)) newCache(idx, null);
    } else newCache(idx, null);
}

/// remove_untracked_cache()
pub fn remove(idx: *index_mod.Index) void {
    if (idx.untracked != null) {
        idx.untracked = null;
        idx.changed = true;
    }
}

fn invalidateOneDirectory(uc: *Cache, d: *UDir) void {
    uc.dir_invalidated += 1;
    d.valid = false;
    d.untracked.items.len = 0;
}

fn invalidateOneComponent(uc: *Cache, dir: *UDir, path: []const u8) bool {
    if (std.mem.indexOfScalar(u8, path, '/')) |sl| {
        const d = lookup(uc, dir, path[0..sl]).?;
        const ret = invalidateOneComponent(uc, d, path[sl + 1 ..]);
        if (ret) invalidateOneDirectory(uc, dir);
        return ret;
    }
    invalidateOneDirectory(uc, dir);
    return uc.dir_flags & DIR_SHOW_OTHER_DIRECTORIES != 0;
}

/// untracked_cache_invalidate_path()
pub fn invalidatePath(idx: *index_mod.Index, path: []const u8, safe_path: bool) void {
    const uc = idx.untracked orelse return;
    const root = uc.root orelse return;
    if (!safe_path and !index_mod.verifyPath(path, 0)) return;
    _ = invalidateOneComponent(uc, root, path);
}

/// untracked_cache_invalidate_trimmed_path()
pub fn invalidateTrimmedPath(idx: *index_mod.Index, path: []const u8, safe_path: bool) void {
    if (path.len == 0) return;
    if (path[path.len - 1] != '/') {
        invalidatePath(idx, path, safe_path);
    } else invalidatePath(idx, path[0 .. path.len - 1], safe_path);
}

/// untracked_cache_add_to_index() / untracked_cache_remove_from_index()
pub fn addToIndex(idx: *index_mod.Index, path: []const u8) void {
    invalidatePath(idx, path, true);
}
pub fn removeFromIndex(idx: *index_mod.Index, path: []const u8) void {
    invalidatePath(idx, path, true);
}

// ---------------------------------------------------------------------------
// test-tool dump-untracked-cache

fn dumpDir(u: *UDir, base: *util.Buf) void {
    std.mem.sort([]const u8, u.untracked.items, {}, struct {
        fn lt(_: void, a: []const u8, b: []const u8) bool {
            return std.mem.order(u8, a, b) == .lt;
        }
    }.lt);
    std.mem.sort(*UDir, u.dirs.items, {}, struct {
        fn lt(_: void, a: *UDir, b: *UDir) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    const len = base.items.len;
    util.bufAppend(base, u.name);
    util.bufByte(base, '/');
    var line: util.Buf = .empty;
    util.bufAppend(&line, base.items);
    util.bufByte(&line, ' ');
    util.bufAppend(&line, &hash.hex(u.exclude_oid));
    if (u.recurse) util.bufAppend(&line, " recurse");
    if (u.check_only) util.bufAppend(&line, " check_only");
    if (u.valid) util.bufAppend(&line, " valid");
    util.bufByte(&line, '\n');
    for (u.untracked.items) |s| {
        util.bufAppend(&line, s);
        util.bufByte(&line, '\n');
    }
    util.out(line.items);
    for (u.dirs.items) |d| dumpDir(d, base);
    base.items.len = len;
}

/// t/helper/test-dump-untracked-cache.c
pub fn dump(uc0: ?*Cache) void {
    const uc = uc0 orelse {
        util.out("no untracked cache\n");
        return;
    };
    util.outf("info/exclude {s}\n", .{&hash.hex(uc.ss_info_exclude.oid)});
    util.outf("core.excludesfile {s}\n", .{&hash.hex(uc.ss_excludes_file.oid)});
    util.outf("exclude_per_dir {s}\n", .{uc.exclude_per_dir});
    util.outf("flags {x:0>8}\n", .{uc.dir_flags});
    if (uc.root) |r| {
        var base: util.Buf = .empty;
        dumpDir(r, &base);
    }
}

/// git_env_bool(): null when unset.
pub fn envBool(name: []const u8) ?bool {
    const v = os.getenv(name) orelse return null;
    return config.parseBool(v) orelse false;
}

extern "c" fn mkdtemp(template: [*:0]u8) ?[*:0]u8;
extern "c" fn sleep(secs: c_uint) c_uint;

fn mtimeDirStat(dir: []const u8) os.Stat {
    return os.statPath(dir) orelse util.dieErrno("failed to stat {s}", .{dir});
}

fn mtimeTestCleanup(dir: []const u8) void {
    _ = os.unlink(util.concat(&.{ dir, "/new-dir/new" }));
    _ = os.rmdir(util.concat(&.{ dir, "/new-dir" }));
    _ = os.unlink(util.concat(&.{ dir, "/newfile" }));
    _ = os.rmdir(dir);
}

/// test_if_untracked_cache_is_supported() of builtin/update-index.c
pub fn testIfSupported() bool {
    var tmpl = "mtime-test-XXXXXX".*;
    if (mkdtemp(&tmpl) == null) util.dieErrno("Could not make temporary directory", .{});
    const dir: []const u8 = util.dupe(tmpl[0..17]);
    defer mtimeTestCleanup(dir);
    const newfile = util.concat(&.{ dir, "/newfile" });
    const newdir = util.concat(&.{ dir, "/new-dir" });
    const newnew = util.concat(&.{ dir, "/new-dir/new" });

    util.eprint("Testing mtime in '{s}' ", .{os.getcwd()});
    var base: StatData = .{};
    base.fill(mtimeDirStat(dir));
    util.eprint(".", .{});

    _ = sleep(1);
    const fd = os.openFile(newfile, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600);
    if (fd < 0) util.dieErrno("failed to create file {s}", .{newfile});
    var st = mtimeDirStat(dir);
    if (base.matches(st)) {
        os.close(fd);
        util.eprint("\ndirectory stat info does not change after adding a new file\n", .{});
        return false;
    }
    base.fill(st);
    util.eprint(".", .{});

    _ = sleep(1);
    if (!os.mkdir(newdir, 0o777)) util.dieErrno("failed to create directory {s}", .{newdir});
    st = mtimeDirStat(dir);
    if (base.matches(st)) {
        os.close(fd);
        util.eprint("\ndirectory stat info does not change after adding a new directory\n", .{});
        return false;
    }
    base.fill(st);
    util.eprint(".", .{});

    _ = sleep(1);
    os.writeAll(fd, "data") catch util.dieErrno("write error", .{});
    os.close(fd);
    st = mtimeDirStat(dir);
    if (!base.matches(st)) {
        util.eprint("\ndirectory stat info changes after updating a file\n", .{});
        return false;
    }
    util.eprint(".", .{});

    _ = sleep(1);
    const fd2 = os.openFile(newnew, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600);
    if (fd2 < 0) util.dieErrno("failed to create file {s}", .{newnew});
    os.close(fd2);
    st = mtimeDirStat(dir);
    if (!base.matches(st)) {
        util.eprint("\ndirectory stat info changes after adding a file inside subdirectory\n", .{});
        return false;
    }
    util.eprint(".", .{});

    _ = sleep(1);
    if (!os.unlink(newfile)) util.dieErrno("failed to unlink {s}", .{newfile});
    st = mtimeDirStat(dir);
    if (base.matches(st)) {
        util.eprint("\ndirectory stat info does not change after deleting a file\n", .{});
        return false;
    }
    base.fill(st);
    util.eprint(".", .{});

    _ = sleep(1);
    _ = os.unlink(newnew);
    _ = os.rmdir(newdir);
    st = mtimeDirStat(dir);
    if (base.matches(st)) {
        util.eprint("\ndirectory stat info does not change after deleting a directory\n", .{});
        return false;
    }
    if (!os.rmdir(dir)) util.dieErrno("failed to delete directory {s}", .{dir});
    util.eprint(" OK\n", .{});
    return true;
}
