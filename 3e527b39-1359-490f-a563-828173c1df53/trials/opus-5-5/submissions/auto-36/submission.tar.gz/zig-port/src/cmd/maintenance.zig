//! git maintenance (builtin/gc.c maintenance part) and git for-each-repo
//! (builtin/for-each-repo.c).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const proc = @import("../proc.zig");
const date = @import("../date.zig");
const hook = @import("../hook.zig");
const hash = @import("../hash.zig");
const config = @import("../config.zig");
const refs = @import("../refs.zig");
const objects = @import("../objects.zig");
const lockfile = @import("../lockfile.zig");
const transport = @import("../transport.zig");
const worktree = @import("../worktree.zig");
const main = @import("../main.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

extern "c" fn fork() c_int;
extern "c" fn setsid() c_int;
extern "c" fn dup2(old: c_int, new: c_int) c_int;
extern "c" fn getuid() u32;

// ---------------------------------------------------------------------------
// minimal trace2 event output (child_start / region_enter / region_leave),
// enough for test_subcommand / test_region

/// child_start is emitted by os.run()/proc.spawn(); kept for call sites.
pub fn traceChildStart(argv: []const []const u8, git_cmd: bool) void {
    _ = argv;
    _ = git_cmd;
}

fn traceRegion(enter: bool, category: []const u8, label: []const u8) void {
    const t2 = @import("../trace2.zig");
    if (enter) t2.regionEnter(category, label, true) else t2.regionLeave(category, label, true);
}

/// run_command() with git_cmd = 1. Returns the exit status.
fn runGitOpts(args: []const []const u8, o: os.SpawnOpts) u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    const r = os.run(argv.items, o);
    return r.status;
}

fn runGit(args: []const []const u8) u8 {
    return runGitOpts(args, .{});
}

/// run_auto_maintenance(): for commands that want to trigger
/// `git maintenance run --auto` after doing their work.
pub fn runAutoMaintenance(quiet: bool) u8 {
    const cfg = &repo_mod.cfg;
    if (cfg.getBool("maintenance.auto")) |en| {
        if (!en) return 0;
    }
    const auto_detach = cfg.getBool("maintenance.autodetach") orelse (cfg.getBool("gc.autodetach") orelse true);
    return runGit(&.{ "maintenance", "run", "--auto", if (quiet) "--quiet" else "--no-quiet", if (auto_detach) "--detach" else "--no-detach" });
}

// ---------------------------------------------------------------------------
// gc_config subset

const GcConfig = struct {
    pack_refs: i32 = 1,
    prune_reflogs: bool = true,
    cruft_packs: bool = true,
    max_cruft_size: u64 = 0,
    prune_expire: ?[]const u8 = "2.weeks.ago",
    prune_worktrees_expire: []const u8 = "3.months.ago",
};

fn isNever(key: []const u8) bool {
    const v = repo_mod.cfg.get(key) orelse return false;
    const t = date.parseExpiryDate(v) orelse util.die("failed to parse '{s}' value '{s}'", .{ key, v });
    return t == 0;
}

fn getExpiry(key: []const u8) ?[]const u8 {
    const v = repo_mod.cfg.get(key) orelse return null;
    if (!util.eql(v, "now") and date.parseExpiryDate(v) == null)
        util.die("'{s}' for '{s}' is not a valid timestamp", .{ v, key });
    return v;
}

fn gcConfig() GcConfig {
    const cfg = &repo_mod.cfg;
    var c = GcConfig{};
    if (cfg.get("gc.packrefs")) |v| {
        c.pack_refs = if (util.eql(v, "notbare")) -1 else @intFromBool(cfg.getBool("gc.packrefs") orelse true);
    }
    if (isNever("gc.reflogexpire") and isNever("gc.reflogexpireunreachable")) c.prune_reflogs = false;
    if (cfg.getBool("gc.cruftpacks")) |b| c.cruft_packs = b;
    if (cfg.getInt("gc.maxcruftsize")) |v| c.max_cruft_size = @intCast(@max(v, 0));
    if (getExpiry("gc.pruneexpire")) |v| c.prune_expire = v;
    if (getExpiry("gc.worktreepruneexpire")) |v| c.prune_worktrees_expire = v;
    _ = getExpiry("gc.logexpiry");
    return c;
}

fn cfgInt(key: []const u8, def: i64) i64 {
    return repo_mod.cfg.getInt(key) orelse def;
}

// ---------------------------------------------------------------------------
// run options

const Schedule = enum(u8) { none = 0, weekly = 1, daily = 2, hourly = 3 };

fn parseSchedule(v: []const u8) Schedule {
    if (std.ascii.eqlIgnoreCase(v, "hourly")) return .hourly;
    if (std.ascii.eqlIgnoreCase(v, "daily")) return .daily;
    if (std.ascii.eqlIgnoreCase(v, "weekly")) return .weekly;
    return .none;
}

fn frequencyName(s: Schedule) []const u8 {
    return switch (s) {
        .hourly => "hourly",
        .daily => "daily",
        .weekly => "weekly",
        .none => unreachable,
    };
}

var opt_auto = false;
var opt_detach: i32 = -1;
var opt_quiet = false;
var opt_schedule: Schedule = .none;
var selected: std.ArrayList(usize) = .empty;
var run_tasks: std.ArrayList(usize) = .empty;

var cur_usage: []const []const u8 = &.{};
var cur_opts: []const po.Opt = &.{};

// ---------------------------------------------------------------------------
// tasks

const TaskFn = *const fn (gc: *const GcConfig) bool; // true = failure
const AutoFn = *const fn (gc: *const GcConfig) bool; // true = should run

const Task = struct {
    name: []const u8,
    fg: ?TaskFn = null,
    bg: ?TaskFn = null,
    auto: ?AutoFn = null,
};

const T_PREFETCH = 0;
const T_LOOSE = 1;
const T_INCREMENTAL = 2;
const T_GEOMETRIC = 3;
const T_GC = 4;
const T_COMMIT_GRAPH = 5;
const T_PACK_REFS = 6;
const T_REFLOG = 7;
const T_WORKTREE = 8;
const T_RERERE = 9;
const TASK_COUNT = 10;

const tasks = [TASK_COUNT]Task{
    .{ .name = "prefetch", .bg = taskPrefetch },
    .{ .name = "loose-objects", .bg = taskLooseObjects, .auto = looseAuto },
    .{ .name = "incremental-repack", .bg = taskIncrementalRepack, .auto = incrementalAuto },
    .{ .name = "geometric-repack", .bg = taskGeometricRepack, .auto = geometricAuto },
    .{ .name = "gc", .fg = taskGcForeground, .bg = taskGcBackground, .auto = gcAuto },
    .{ .name = "commit-graph", .bg = taskCommitGraph, .auto = commitGraphAuto },
    .{ .name = "pack-refs", .fg = taskPackRefs, .auto = packRefsAuto },
    .{ .name = "reflog-expire", .fg = taskReflogExpire, .auto = reflogAuto },
    .{ .name = "worktree-prune", .bg = taskWorktreePrune, .auto = worktreeAuto },
    .{ .name = "rerere-gc", .bg = taskRerereGc, .auto = rerereAuto },
};

fn objectsDir() []const u8 {
    return repo_mod.repo().odb().objects_dir;
}

fn coreMultiPackIndex() bool {
    return repo_mod.cfg.getBool("core.multipackindex") orelse true;
}

// --- prefetch

fn taskPrefetch(_: *const GcConfig) bool {
    for (transport.allRemotes()) |r| {
        if (r.skip_default_update) continue;
        var args: std.ArrayList([]const u8) = .empty;
        args.appendSlice(gpa, &.{ "fetch", r.name, "--prefetch", "--prune", "--no-tags", "--no-write-fetch-head", "--recurse-submodules=no" }) catch util.oom();
        if (opt_quiet) args.append(gpa, "--quiet") catch util.oom();
        if (runGit(args.items) != 0) {
            util.err("failed to prefetch remotes", .{});
            return true;
        }
    }
    return false;
}

// --- loose objects

fn isHexName(s: []const u8) bool {
    for (s) |ch| {
        if (!((ch >= '0' and ch <= '9') or (ch >= 'a' and ch <= 'f'))) return false;
    }
    return true;
}

/// Iterate loose objects of the main object directory; the callback
/// returns true to stop. Returns true if stopped.
fn forEachLoose(ctx: anytype, comptime cb: fn (@TypeOf(ctx), []const u8) bool) bool {
    const od = objectsDir();
    var i: usize = 0;
    while (i < 256) : (i += 1) {
        var dn: [2]u8 = undefined;
        _ = std.fmt.bufPrint(&dn, "{x:0>2}", .{i}) catch unreachable;
        const ents = os.listDir(util.concat(&.{ od, "/", &dn })) orelse continue;
        for (ents) |e| {
            if (e.name.len != hash.HEXSZ - 2 or !isHexName(e.name)) continue;
            if (cb(ctx, util.concat(&.{ &dn, e.name }))) return true;
        }
    }
    return false;
}

const CountCtx = struct { count: i64 = 0, limit: i64 };

fn countCb(c: *CountCtx, _: []const u8) bool {
    c.count += 1;
    return c.count >= c.limit;
}

fn looseAuto(_: *const GcConfig) bool {
    const limit = cfgInt("maintenance.loose-objects.auto", 100);
    if (limit == 0) return false;
    if (limit < 0) return true;
    var c = CountCtx{ .limit = limit };
    return forEachLoose(&c, countCb);
}

fn bailCb(_: void, _: []const u8) bool {
    return true;
}

const WriteCtx = struct { buf: util.Buf = .empty, count: i64 = 0, batch: i64 };

fn writeCb(c: *WriteCtx, hex: []const u8) bool {
    util.bufAppend(&c.buf, hex);
    util.bufByte(&c.buf, '\n');
    c.count += 1;
    return c.count > c.batch;
}

fn taskLooseObjects(_: *const GcConfig) bool {
    // prune_packed
    if (runGit(if (opt_quiet) &.{ "prune-packed", "--quiet" } else &.{"prune-packed"}) != 0) return true;
    // pack_loose
    if (!forEachLoose({}, bailCb)) return false;
    var batch = cfgInt("maintenance.loose-objects.batchsize", 50000);
    if (batch == 0) batch = std.math.maxInt(i32) else if (batch > 0) batch -= 1;
    var w = WriteCtx{ .batch = batch };
    _ = forEachLoose(&w, writeCb);
    const dest = util.concat(&.{ objectsDir(), "/pack/loose" });
    const st = runGitOpts(&.{ "pack-objects", if (opt_quiet) "--quiet" else "--no-quiet", dest }, .{ .stdin_data = w.buf.items, .capture_stdout = true });
    if (st != 0) {
        util.err("failed to finish 'git pack-objects' process", .{});
        return true;
    }
    return false;
}

// --- packs helpers

const PackInfo = struct { idx_path: []const u8, pack_path: []const u8, size: u64, num: u32, local: bool, keep: bool, cruft: bool, promisor: bool };

fn allPacks() []PackInfo {
    const odb = repo_mod.repo().odb();
    odb.reloadPacks();
    var out: std.ArrayList(PackInfo) = .empty;
    for (odb.packs.items) |p| {
        const base = p.pack_path[0 .. p.pack_path.len - 5];
        const st = os.statPath(p.pack_path);
        out.append(gpa, .{
            .idx_path = p.idx_path,
            .pack_path = p.pack_path,
            .size = if (st) |s| @intCast(@max(s.size, 0)) else 0,
            .num = p.num,
            .local = util.startsWith(p.pack_path, odb.objects_dir),
            .keep = os.exists(util.concat(&.{ base, ".keep" })),
            .cruft = os.exists(util.concat(&.{ base, ".mtimes" })),
            .promisor = os.exists(util.concat(&.{ base, ".promisor" })),
        }) catch util.oom();
    }
    return out.items;
}

fn be32(b: []const u8) u32 {
    return std.mem.readInt(u32, b[0..4], .big);
}
fn be64(b: []const u8) u64 {
    return std.mem.readInt(u64, b[0..8], .big);
}

/// Names of the packs (".idx" names) covered by the multi-pack-index.
fn midxPackNames() [][]const u8 {
    var names: std.ArrayList([]const u8) = .empty;
    const data = os.readFile(util.concat(&.{ objectsDir(), "/pack/multi-pack-index" })) orelse return names.items;
    if (data.len < 12 or !std.mem.eql(u8, data[0..4], "MIDX")) return names.items;
    const nchunks = data[6];
    const npacks = be32(data[8..12]);
    var i: usize = 0;
    while (i < nchunks) : (i += 1) {
        const off = 12 + i * 12;
        if (off + 24 > data.len) break;
        if (!std.mem.eql(u8, data[off .. off + 4], "PNAM")) continue;
        var pos: usize = @intCast(be64(data[off + 4 .. off + 12]));
        var n: u32 = 0;
        while (n < npacks and pos < data.len) : (n += 1) {
            const end = std.mem.indexOfScalarPos(u8, data, pos, 0) orelse break;
            names.append(gpa, data[pos..end]) catch util.oom();
            pos = end + 1;
        }
    }
    return names.items;
}

fn inMidx(names: []const []const u8, p: PackInfo) bool {
    const b = util.basename(p.idx_path);
    for (names) |n| {
        if (util.eql(n, b)) return true;
        // names may also be recorded with ".pack"
        if (util.endsWith(n, ".pack") and util.eql(n[0 .. n.len - 5], b[0 .. b.len - 4])) return true;
    }
    return false;
}

// --- incremental repack

fn incrementalAuto(_: *const GcConfig) bool {
    if (!coreMultiPackIndex()) return false;
    const limit = cfgInt("maintenance.incremental-repack.auto", 10);
    if (limit == 0) return false;
    if (limit < 0) return true;
    const names = midxPackNames();
    var count: i64 = 0;
    for (allPacks()) |p| {
        if (count >= limit) break;
        if (!inMidx(names, p)) count += 1;
    }
    return count >= limit;
}

fn autoPackSize() u64 {
    var max: u64 = 0;
    var second: u64 = 0;
    for (allPacks()) |p| {
        if (p.size > max) {
            second = max;
            max = p.size;
        } else if (p.size > second) second = p.size;
    }
    var r = second + 1;
    if (r > std.math.maxInt(i32)) r = std.math.maxInt(i32);
    return r;
}

fn taskIncrementalRepack(_: *const GcConfig) bool {
    if (!coreMultiPackIndex()) {
        util.warn("skipping incremental-repack task because core.multiPackIndex is disabled", .{});
        return false;
    }
    const prog = if (opt_quiet) "--no-progress" else "--progress";
    if (runGit(&.{ "multi-pack-index", "write", prog }) != 0) {
        util.err("failed to write multi-pack-index", .{});
        return true;
    }
    if (runGit(&.{ "multi-pack-index", "expire", prog }) != 0) {
        util.err("'git multi-pack-index expire' failed", .{});
        return true;
    }
    if (runGit(&.{ "multi-pack-index", "repack", prog, util.fmt("--batch-size={d}", .{autoPackSize()}) }) != 0) {
        util.err("'git multi-pack-index repack' failed", .{});
        return true;
    }
    return false;
}

// --- geometric repack

fn splitFactor() u64 {
    const v = cfgInt("maintenance.geometric-repack.splitfactor", 2);
    return @intCast(@max(v, 0));
}

const Geometry = struct { split: usize, pack_nr: usize };

fn geometry() Geometry {
    var packs: std.ArrayList(u64) = .empty;
    for (allPacks()) |p| {
        if (!p.local or p.keep or p.cruft or p.promisor) continue;
        packs.append(gpa, p.num) catch util.oom();
    }
    std.mem.sort(u64, packs.items, {}, std.sort.asc(u64));
    const w = packs.items;
    const f = splitFactor();
    if (w.len == 0) return .{ .split = 0, .pack_nr = 0 };
    var i: usize = w.len - 1;
    while (i > 0) : (i -= 1) {
        if (w[i] < f * w[i - 1]) break;
    }
    var split = i;
    if (split != 0) split += 1;
    var total: u64 = 0;
    for (w[0..split]) |x| total += x;
    var k = split;
    while (k < w.len) : (k += 1) {
        if (w[k] < f * total) {
            split += 1;
            total += w[k];
        } else break;
    }
    return .{ .split = split, .pack_nr = w.len };
}

fn tooManyLoose(limit: i64) bool {
    if (limit <= 0) return false;
    const ents = os.listDir(util.concat(&.{ objectsDir(), "/17" })) orelse return false;
    var n: u64 = 0;
    for (ents) |e| {
        if (e.name.len == hash.HEXSZ - 2 and isHexName(e.name)) n += 1;
    }
    const lim: u64 = @intCast(limit);
    return n * 256 > ((lim + 255) / 256) * 256;
}

fn tooManyPacks(limit: i64) bool {
    if (limit <= 0) return false;
    var cnt: i64 = 0;
    for (allPacks()) |p| {
        if (p.local and !p.keep) cnt += 1;
    }
    return limit < cnt;
}

fn geometricAuto(_: *const GcConfig) bool {
    const auto_value = cfgInt("maintenance.geometric-repack.auto", 6700);
    if (auto_value == 0) return false;
    if (auto_value < 0) return true;
    if (geometry().split != 0) return true;
    return tooManyLoose(auto_value);
}

fn addRepackAllOption(args: *std.ArrayList([]const u8), gc: *const GcConfig) void {
    const cfg = &repo_mod.cfg;
    if (gc.prune_expire != null and util.eql(gc.prune_expire.?, "now")) {
        args.append(gpa, "-a") catch util.oom();
    } else if (gc.cruft_packs) {
        args.append(gpa, "--cruft") catch util.oom();
        if (gc.prune_expire) |p| args.append(gpa, util.concat(&.{ "--cruft-expiration=", p })) catch util.oom();
        if (gc.max_cruft_size != 0) args.append(gpa, util.fmt("--max-cruft-size={d}", .{gc.max_cruft_size})) catch util.oom();
    } else {
        args.append(gpa, "-A") catch util.oom();
        if (gc.prune_expire) |p| args.append(gpa, util.concat(&.{ "--unpack-unreachable=", p })) catch util.oom();
    }
    if (cfg.get("gc.repackfilter")) |f| {
        if (f.len > 0) args.append(gpa, util.concat(&.{ "--filter=", f })) catch util.oom();
    }
    if (cfg.get("gc.repackfilterto")) |f| {
        if (f.len > 0) args.append(gpa, util.concat(&.{ "--filter-to=", f })) catch util.oom();
    }
}

fn taskGeometricRepack(gc: *const GcConfig) bool {
    if (repo_mod.cfg.getBool("extensions.preciousobjects") orelse false) return false;
    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, &.{ "repack", "-d", "-l" }) catch util.oom();
    if (opt_quiet) args.append(gpa, "-q") catch util.oom();
    const g = geometry();
    if (g.split < g.pack_nr) {
        args.append(gpa, util.fmt("--geometric={d}", .{splitFactor()})) catch util.oom();
    } else addRepackAllOption(&args, gc);
    if (coreMultiPackIndex()) args.append(gpa, "--write-midx") catch util.oom();
    if (runGit(args.items) != 0) {
        util.err("failed to run {s}", .{"repack"});
        return true;
    }
    return false;
}

// --- gc

fn packRefsArgs() []const []const u8 {
    return if (opt_auto) &.{ "pack-refs", "--all", "--prune", "--auto" } else &.{ "pack-refs", "--all", "--prune" };
}

fn taskGcForeground(gc: *const GcConfig) bool {
    if (gc.pack_refs != 0 and runGit(packRefsArgs()) != 0) {
        util.err("failed to run {s}", .{"pack-refs"});
        return true;
    }
    if (gc.prune_reflogs and runGit(&.{ "reflog", "expire", "--all" }) != 0) {
        util.err("failed to run {s}", .{"reflog"});
        return true;
    }
    return false;
}

fn taskGcBackground(_: *const GcConfig) bool {
    var args: std.ArrayList([]const u8) = .empty;
    args.append(gpa, "gc") catch util.oom();
    if (opt_auto) args.append(gpa, "--auto") catch util.oom();
    args.append(gpa, if (opt_quiet) "--quiet" else "--no-quiet") catch util.oom();
    args.append(gpa, "--no-detach") catch util.oom();
    args.append(gpa, "--skip-foreground-tasks") catch util.oom();
    return runGit(args.items) != 0;
}

fn gcAuto(_: *const GcConfig) bool {
    const threshold = cfgInt("gc.auto", 6700);
    const pack_limit = cfgInt("gc.autopacklimit", 50);
    if (threshold <= 0) return false;
    return tooManyPacks(pack_limit) or tooManyLoose(threshold);
}

// --- commit-graph

fn loadGraphFile(path: []const u8, set: *std.AutoHashMap(Oid, void)) void {
    const data = os.readFile(path) orelse return;
    if (data.len < 8 or !std.mem.eql(u8, data[0..4], "CGPH")) return;
    const nchunks = data[6];
    var oidf: ?usize = null;
    var oidl: ?usize = null;
    var i: usize = 0;
    while (i < nchunks) : (i += 1) {
        const off = 8 + i * 12;
        if (off + 12 > data.len) return;
        const id = data[off .. off + 4];
        const at: usize = @intCast(be64(data[off + 4 .. off + 12]));
        if (std.mem.eql(u8, id, "OIDF")) oidf = at;
        if (std.mem.eql(u8, id, "OIDL")) oidl = at;
    }
    const f = oidf orelse return;
    const l = oidl orelse return;
    if (f + 1024 > data.len) return;
    const n = be32(data[f + 255 * 4 ..]);
    var k: usize = 0;
    while (k < n) : (k += 1) {
        const p = l + k * hash.RAWSZ;
        if (p + hash.RAWSZ > data.len) return;
        var oid: Oid = undefined;
        @memcpy(&oid, data[p .. p + hash.RAWSZ]);
        set.put(oid, {}) catch util.oom();
    }
}

fn loadCommitGraph() std.AutoHashMap(Oid, void) {
    var set = std.AutoHashMap(Oid, void).init(gpa);
    if (!(repo_mod.cfg.getBool("core.commitgraph") orelse true)) return set;
    const info = util.concat(&.{ objectsDir(), "/info" });
    if (os.readFile(util.concat(&.{ info, "/commit-graphs/commit-graph-chain" }))) |chain| {
        var it = std.mem.tokenizeScalar(u8, chain, '\n');
        while (it.next()) |h| {
            loadGraphFile(util.concat(&.{ info, "/commit-graphs/graph-", util.trim(h), ".graph" }), &set);
        }
    } else loadGraphFile(util.concat(&.{ info, "/commit-graph" }), &set);
    return set;
}

fn commitGraphAuto(_: *const GcConfig) bool {
    const limit = cfgInt("maintenance.commit-graph.auto", 100);
    if (limit == 0) return false;
    if (limit < 0) return true;
    var graph = loadCommitGraph();
    var seen = std.AutoHashMap(Oid, void).init(gpa);
    const odb = repo_mod.repo().odb();
    var count: i64 = 0;
    for (refs.iterate("refs/", .{ .check_objects = false })) |r| {
        const pe = objects.peel(r.oid) orelse continue;
        if (pe.typ != .commit) continue;
        if (seen.contains(pe.oid)) continue;
        seen.put(pe.oid, {}) catch util.oom();
        if (graph.contains(pe.oid)) continue;
        count += 1;
        if (count >= limit) return true;
        var stack: std.ArrayList(Oid) = .empty;
        stack.append(gpa, pe.oid) catch util.oom();
        while (stack.pop()) |c| {
            const obj = odb.read(c) orelse continue;
            const commit = objects.parseCommit(c, obj.data) orelse continue;
            for (commit.parents) |p| {
                if (graph.contains(p) or seen.contains(p)) continue;
                if (!odb.has(p)) continue;
                seen.put(p, {}) catch util.oom();
                count += 1;
                if (count >= limit) return true;
                stack.append(gpa, p) catch util.oom();
            }
        }
    }
    return false;
}

fn taskCommitGraph(_: *const GcConfig) bool {
    if (!(repo_mod.cfg.getBool("core.commitgraph") orelse true)) return false;
    if (runGit(&.{ "commit-graph", "write", "--split", "--reachable", if (opt_quiet) "--no-progress" else "--progress" }) != 0) {
        util.err("failed to write commit-graph", .{});
        return true;
    }
    return false;
}

// --- pack-refs

fn taskPackRefs(_: *const GcConfig) bool {
    return runGit(packRefsArgs()) != 0;
}

fn packRefsAuto(_: *const GcConfig) bool {
    return refs.packRefsRequired(.{ .includes = &.{"*"}, .prune = true, .auto = true });
}

// --- reflog-expire

fn reflogAuto(_: *const GcConfig) bool {
    const limit = cfgInt("maintenance.reflog-expire.auto", 100);
    if (limit == 0) return false;
    if (limit < 0) return true;
    const now = os.now();
    const cfg = &repo_mod.cfg;
    var expire_total: i64 = now - 90 * 24 * 3600;
    var expire_unreach: i64 = now - 30 * 24 * 3600;
    if (cfg.get("gc.reflogexpire")) |v| expire_total = date.parseExpiryDate(v) orelse expire_total;
    if (cfg.get("gc.reflogexpireunreachable")) |v| expire_unreach = date.parseExpiryDate(v) orelse expire_unreach;
    if (cfg.get("gc.head.reflogexpire")) |v| expire_total = date.parseExpiryDate(v) orelse expire_total;
    if (cfg.get("gc.head.reflogexpireunreachable")) |v| expire_unreach = date.parseExpiryDate(v) orelse expire_unreach;
    // entries whose commits are no longer reachable from HEAD expire
    // with expire_unreachable; approximate reachability by the set of
    // commits reachable from the current HEAD.
    var reach: ?std.AutoHashMap(Oid, void) = null;
    var count: i64 = 0;
    for (refs.readReflog("HEAD")) |e| {
        const ts = objects.identTime(e.ident);
        var expire = ts < expire_total;
        if (!expire and ts < expire_unreach) {
            if (reach == null) reach = reachableFromHead();
            const unreachable_new = !hash.isZero(e.new) and !reach.?.contains(e.new);
            const unreachable_old = !hash.isZero(e.old) and !reach.?.contains(e.old);
            expire = unreachable_new or unreachable_old;
        }
        if (expire) count += 1;
        if (count >= limit) return true;
    }
    return count >= limit;
}

fn reachableFromHead() std.AutoHashMap(Oid, void) {
    var set = std.AutoHashMap(Oid, void).init(gpa);
    const head = refs.readOid("HEAD") orelse return set;
    const odb = repo_mod.repo().odb();
    var stack: std.ArrayList(Oid) = .empty;
    stack.append(gpa, head) catch util.oom();
    set.put(head, {}) catch util.oom();
    while (stack.pop()) |c| {
        const obj = odb.read(c) orelse continue;
        if (obj.typ != .commit) continue;
        const commit = objects.parseCommit(c, obj.data) orelse continue;
        for (commit.parents) |p| {
            if (set.contains(p)) continue;
            set.put(p, {}) catch util.oom();
            stack.append(gpa, p) catch util.oom();
        }
    }
    return set;
}

fn taskReflogExpire(_: *const GcConfig) bool {
    return runGit(&.{ "reflog", "expire", "--all" }) != 0;
}

// --- worktree-prune

fn taskWorktreePrune(gc: *const GcConfig) bool {
    return runGit(&.{ "worktree", "prune", "--expire", gc.prune_worktrees_expire }) != 0;
}

fn worktreeAuto(gc: *const GcConfig) bool {
    var limit = cfgInt("maintenance.worktree-prune.auto", 1);
    if (limit <= 0) return limit < 0;
    const expiry = date.parseExpiryDate(gc.prune_worktrees_expire) orelse return false;
    const ents = os.listDir(repo_mod.repo().commonPath("worktrees")) orelse return false;
    for (ents) |e| {
        if (limit == 0) break;
        var wtpath: ?[]const u8 = null;
        if (worktree.shouldPrune(e.name, &wtpath, expiry) != null) limit -= 1;
    }
    return limit == 0;
}

// --- rerere-gc

fn taskRerereGc(_: *const GcConfig) bool {
    return runGit(&.{ "rerere", "gc" }) != 0;
}

fn rerereExpiry(key: []const u8, now: i64, def_days: i64) i64 {
    const v = repo_mod.cfg.get(key) orelse return now - def_days * 86400;
    if (std.fmt.parseInt(i32, util.trim(v), 10)) |days| {
        return now - @as(i64, days) * 86400;
    } else |_| {}
    return date.parseExpiryDate(v) orelse now - def_days * 86400;
}

fn mtimeOf(p: []const u8) i64 {
    const st = os.statPath(p) orelse return 0;
    return st.mtime;
}

fn rerereAuto(_: *const GcConfig) bool {
    const limit = cfgInt("maintenance.rerere-gc.auto", 512);
    if (limit == 0) return false;
    if (limit < 0) return true;
    const rr = repo_mod.repo().commonPath("rr-cache");
    const ents = os.listDir(rr) orelse return false;
    const now = os.now();
    const cutoff_resolve = rerereExpiry("gc.rerereresolved", now, 60);
    const cutoff_noresolve = rerereExpiry("gc.rerereunresolved", now, 15);
    var count: i64 = 0;
    for (ents) |e| {
        if (!util.startsWith(e.name, "17") or e.name.len != hash.HEXSZ or !isHexName(e.name)) continue;
        const dir = util.concat(&.{ rr, "/", e.name });
        const files = os.listDir(dir) orelse continue;
        // collect variants
        var variants: std.ArrayList([]const u8) = .empty;
        for (files) |f| {
            var suffix: ?[]const u8 = null;
            if (util.skipPrefix(f.name, "preimage")) |s| suffix = s;
            if (util.skipPrefix(f.name, "postimage")) |s| suffix = s;
            const s = suffix orelse continue;
            if (s.len > 0 and (s[0] != '.' or s.len < 2 or util.parseInt(u32, s[1..]) == null)) continue;
            var dup = false;
            for (variants.items) |v| {
                if (util.eql(v, s)) dup = true;
            }
            if (!dup) variants.append(gpa, s) catch util.oom();
        }
        for (variants.items) |s| {
            const post = mtimeOf(util.concat(&.{ dir, "/postimage", s }));
            var stale = false;
            if (post != 0) {
                stale = post < cutoff_resolve;
            } else {
                const pre = mtimeOf(util.concat(&.{ dir, "/preimage", s }));
                stale = pre != 0 and pre < cutoff_noresolve;
            }
            if (stale) {
                count += 256;
                if (count >= limit) return true;
            }
        }
    }
    return false;
}

// ---------------------------------------------------------------------------
// strategies

const TYPE_SCHEDULED: u8 = 1;
const TYPE_MANUAL: u8 = 2;

const StratTask = struct { typ: u8 = 0, schedule: Schedule = .none };
const Strategy = [TASK_COUNT]StratTask;

fn strategyNone() Strategy {
    return @splat(.{});
}

fn strategyGc() Strategy {
    var s = strategyNone();
    s[T_GC] = .{ .typ = TYPE_MANUAL | TYPE_SCHEDULED, .schedule = .daily };
    return s;
}

fn strategyIncremental() Strategy {
    var s = strategyNone();
    s[T_COMMIT_GRAPH] = .{ .typ = TYPE_SCHEDULED, .schedule = .hourly };
    s[T_PREFETCH] = .{ .typ = TYPE_SCHEDULED, .schedule = .hourly };
    s[T_INCREMENTAL] = .{ .typ = TYPE_SCHEDULED, .schedule = .daily };
    s[T_LOOSE] = .{ .typ = TYPE_SCHEDULED, .schedule = .daily };
    s[T_PACK_REFS] = .{ .typ = TYPE_SCHEDULED, .schedule = .weekly };
    s[T_GC] = .{ .typ = TYPE_MANUAL };
    return s;
}

fn strategyGeometric() Strategy {
    var s = strategyNone();
    const both = TYPE_SCHEDULED | TYPE_MANUAL;
    s[T_COMMIT_GRAPH] = .{ .typ = both, .schedule = .hourly };
    s[T_GEOMETRIC] = .{ .typ = both, .schedule = .daily };
    s[T_PACK_REFS] = .{ .typ = both, .schedule = .daily };
    s[T_RERERE] = .{ .typ = both, .schedule = .weekly };
    s[T_REFLOG] = .{ .typ = both, .schedule = .weekly };
    s[T_WORKTREE] = .{ .typ = both, .schedule = .weekly };
    return s;
}

fn parseStrategy(name: []const u8) Strategy {
    if (std.ascii.eqlIgnoreCase(name, "incremental")) return strategyIncremental();
    if (std.ascii.eqlIgnoreCase(name, "gc")) return strategyGc();
    if (std.ascii.eqlIgnoreCase(name, "geometric")) return strategyGeometric();
    util.die("unknown maintenance strategy: '{s}'", .{name});
}

fn initializeTaskConfig() void {
    run_tasks.clearRetainingCapacity();
    if (selected.items.len > 0) {
        run_tasks.appendSlice(gpa, selected.items) catch util.oom();
        return;
    }
    const cfg = &repo_mod.cfg;
    var strategy: Strategy = undefined;
    var typ: u8 = undefined;
    if (opt_schedule != .none) {
        strategy = strategyNone();
        typ = TYPE_SCHEDULED;
    } else {
        strategy = strategyGeometric();
        typ = TYPE_MANUAL;
    }
    if (cfg.get("maintenance.strategy")) |s| strategy = parseStrategy(s);
    for (tasks, 0..) |t, i| {
        if (cfg.getBool(util.fmt("maintenance.{s}.enabled", .{t.name}))) |en| {
            strategy[i].typ = if (en) typ else 0;
        }
        if (strategy[i].typ & typ == 0) continue;
        if (opt_schedule != .none) {
            if (cfg.get(util.fmt("maintenance.{s}.schedule", .{t.name}))) |s| strategy[i].schedule = parseSchedule(s);
            if (@intFromEnum(strategy[i].schedule) < @intFromEnum(opt_schedule)) continue;
        }
        run_tasks.append(gpa, i) catch util.oom();
    }
}

// ---------------------------------------------------------------------------
// option callbacks

fn taskCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse "";
    var found: ?usize = null;
    for (tasks, 0..) |t, i| {
        if (std.ascii.eqlIgnoreCase(t.name, a)) {
            found = i;
            break;
        }
    }
    const idx = found orelse {
        util.err("'{s}' is not a valid task", .{a});
        po.usageWithOptions(cur_usage, cur_opts);
    };
    for (selected.items) |s| {
        if (s == idx) {
            util.err("task '{s}' cannot be selected multiple times", .{a});
            po.usageWithOptions(cur_usage, cur_opts);
        }
    }
    selected.append(gpa, idx) catch util.oom();
}

fn scheduleCb(arg: ?[]const u8, unset: bool) void {
    if (unset) util.die("--no-schedule is not allowed", .{});
    const a = arg orelse "";
    opt_schedule = parseSchedule(a);
    if (opt_schedule == .none) util.die("unrecognized --schedule argument '{s}'", .{a});
}

fn detachCb(_: ?[]const u8, unset: bool) void {
    opt_detach = if (unset) 0 else 1;
}

// ---------------------------------------------------------------------------
// run

fn maybeRunTask(idx: usize, foreground: bool, gc: *const GcConfig, hook_result: *u8) bool {
    const t = tasks[idx];
    const f = (if (foreground) t.fg else t.bg) orelse return false;
    if (opt_auto) {
        if (hook_result.* == 2) return false;
        const cond = t.auto orelse return false;
        if (!cond(gc)) return false;
        if (hook_result.* == 0) hook_result.* = if (hook.run("pre-auto-gc", &.{}, .{}) != 0) 2 else 1;
        if (hook_result.* == 2) return false;
    }
    const region = if (foreground) "maintenance foreground" else "maintenance";
    traceRegion(true, region, t.name);
    var failed = false;
    if (f(gc)) {
        util.err("task '{s}' failed", .{t.name});
        failed = true;
    }
    traceRegion(false, region, t.name);
    return failed;
}

fn daemonize() void {
    util.flushStdout();
    const pid = fork();
    if (pid < 0) return; // failure to daemonize is ok
    if (pid > 0) os.exit(0);
    _ = setsid();
    const nul = os.openFile("/dev/null", os.O_RDWR, 0);
    if (nul >= 0) {
        _ = dup2(nul, 0);
        _ = dup2(nul, 1);
        _ = dup2(nul, 2);
        if (nul > 2) os.close(nul);
    }
}

fn runTasks(gc: *const GcConfig) u8 {
    const lock_path = util.concat(&.{ objectsDir(), "/maintenance" });
    const lk = switch (lockfile.tryLock(lock_path)) {
        .ok => |l| l,
        .err => {
            if (!opt_auto and !opt_quiet) util.warn("lock file '{s}' exists, skipping maintenance", .{lock_path});
            return 0;
        },
    };
    var result: u8 = 0;
    var hook_result: u8 = 0;
    for (run_tasks.items) |i| {
        if (maybeRunTask(i, true, gc, &hook_result)) result = 1;
    }
    if (opt_detach > 0) {
        traceRegion(true, "maintenance", "detach");
        daemonize();
        traceRegion(false, "maintenance", "detach");
    }
    for (run_tasks.items) |i| {
        if (maybeRunTask(i, false, gc, &hook_result)) result = 1;
    }
    lk.rollback();
    return result;
}

const run_usage = [_][]const u8{"git maintenance run [--auto] [--[no-]quiet] [--task=<task>] [--schedule]"};

fn cmdRun(args: []const []const u8) u8 {
    opt_quiet = !os.isatty(2);
    const options = [_]po.Opt{
        po.boolean(0, "auto", &opt_auto, "run tasks based on the state of the repository"),
        .{ .long = "detach", .kind = .callback, .cb = detachCb, .noarg = true, .help = "perform maintenance in the background" },
        .{ .long = "schedule", .kind = .callback, .cb = scheduleCb, .argh = "frequency", .help = "run tasks based on frequency" },
        po.boolean(0, "quiet", &opt_quiet, "do not report progress or other information over stderr"),
        .{ .long = "task", .kind = .callback, .cb = taskCb, .argh = "task", .noneg = true, .help = "run a specific task" },
    };
    cur_usage = &run_usage;
    cur_opts = &options;
    const rest = po.parse(args, &options, &run_usage, .{ .stop_at_non_option = true });
    if (opt_auto and opt_schedule != .none)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--auto", "--schedule=" });
    if (selected.items.len > 0 and opt_schedule != .none)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--task=", "--schedule=" });
    const gc = gcConfig();
    initializeTaskConfig();
    if (rest.len != 0) po.usageWithOptions(&run_usage, &options);
    return runTasks(&gc);
}

const is_needed_usage = [_][]const u8{"git maintenance is-needed [--task=<task>] [--schedule]"};

fn cmdIsNeeded(args: []const []const u8) u8 {
    const options = [_]po.Opt{
        po.boolean(0, "auto", &opt_auto, "run tasks based on the state of the repository"),
        .{ .long = "task", .kind = .callback, .cb = taskCb, .argh = "task", .noneg = true, .help = "check a specific task" },
    };
    cur_usage = &is_needed_usage;
    cur_opts = &options;
    const rest = po.parse(args, &options, &is_needed_usage, .{ .stop_at_non_option = true });
    if (rest.len != 0) po.usageWithOptions(&is_needed_usage, &options);
    const gc = gcConfig();
    initializeTaskConfig();
    var needed = false;
    if (opt_auto) {
        for (run_tasks.items) |i| {
            if (tasks[i].auto) |cond| {
                if (cond(&gc)) {
                    needed = true;
                    break;
                }
            }
        }
    } else needed = true;
    return if (needed) 0 else 1;
}

// ---------------------------------------------------------------------------
// register / unregister

fn maintPath() []const u8 {
    const r = repo_mod.repo();
    const p = r.work_tree orelse r.git_dir;
    return os.realPath(p) orelse util.die("unable to get real path of '{s}'", .{p});
}

const register_usage = [_][]const u8{"git maintenance register [--config-file <path>]"};

fn cmdRegister(args: []const []const u8) u8 {
    var config_file: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.string(0, "config-file", &config_file, "file", "use given config file"),
    };
    const rest = po.parse(args, &options, &register_usage, .{});
    if (rest.len != 0) po.usageWithOptions(&register_usage, &options);
    return doRegister(config_file);
}

fn repoConfigSet(key: []const u8, value: []const u8) void {
    const path = repo_mod.repo().commonPath("config");
    const rc = config.setInFileGently(path, key, null, value);
    if (rc != 0) util.die("could not set '{s}' to '{s}'", .{ key, value });
}

fn doRegister(config_file_in: ?[]const u8) u8 {
    const key = "maintenance.repo";
    const maintpath = maintPath();
    const cfg = &repo_mod.cfg;
    repoConfigSet("maintenance.auto", "false");
    if (cfg.getEntry("maintenance.strategy") == null) repoConfigSet("maintenance.strategy", "incremental");
    var found = false;
    for (cfg.getAll(key)) |v| {
        if (util.eql(v, maintpath)) found = true;
    }
    if (!found) {
        const config_file = config_file_in orelse config.globalConfigFile() orelse util.die("$HOME not set", .{});
        const rc = config.setMultivarInFile(config_file, key, maintpath, .none, null, .{});
        if (rc != 0) util.die("unable to add '{s}' value of '{s}'", .{ key, maintpath });
    }
    return 0;
}

const unregister_usage = [_][]const u8{"git maintenance unregister [--config-file <path>] [--force]"};

fn cmdUnregister(args: []const []const u8) u8 {
    var config_file: ?[]const u8 = null;
    var force: i32 = 0;
    const options = [_]po.Opt{
        po.string(0, "config-file", &config_file, "file", "use given config file"),
        po.counter('f', "force", &force, "return success even if repository was not registered"),
    };
    const rest = po.parse(args, &options, &unregister_usage, .{});
    if (rest.len != 0) po.usageWithOptions(&unregister_usage, &options);
    const key = "maintenance.repo";
    const maintpath = maintPath();
    var values: [][]const u8 = undefined;
    if (config_file) |cf| {
        var cs: config.Config = .{};
        _ = config.readFileInto(&cs, cf, .command);
        values = cs.getAll(key);
    } else values = repo_mod.cfg.getAll(key);
    var found = false;
    for (values) |v| {
        if (util.eql(v, maintpath)) found = true;
    }
    if (found) {
        const cf = config_file orelse config.globalConfigFile() orelse util.die("$HOME not set", .{});
        const rc = config.setMultivarInFile(cf, key, null, .{ .pattern = maintpath }, null, .{ .multi_replace = true, .fixed_value = true });
        if (rc != 0 and (force == 0 or rc == 5))
            util.die("unable to unset '{s}' value of '{s}'", .{ key, maintpath });
    } else if (force == 0) {
        util.die("repository '{s}' is not registered", .{maintpath});
    }
    return 0;
}

// ---------------------------------------------------------------------------
// schedulers

/// GIT_TEST_MAINT_SCHEDULER mock lookup. Returns null when the variable
/// is unset; otherwise whether `cmd` is mocked and the command to use.
fn getScheduleCmd(cmd: []const u8) ?struct { available: bool, cmd: []const u8 } {
    const testing = os.getenv("GIT_TEST_MAINT_SCHEDULER") orelse return null;
    var it = std.mem.splitScalar(u8, testing, ',');
    while (it.next()) |item| {
        if (std.mem.count(u8, item, ":") != 1) continue;
        const colon = std.mem.indexOfScalar(u8, item, ':').?;
        if (util.eql(item[0..colon], cmd)) return .{ .available = true, .cmd = item[colon + 1 ..] };
    }
    return .{ .available = false, .cmd = cmd };
}

fn scheduleCmd(cmd: []const u8) []const u8 {
    if (getScheduleCmd(cmd)) |r| return r.cmd;
    return cmd;
}

fn splitCmd(cmd: []const u8, extra: []const []const u8) []const []const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    var it = std.mem.tokenizeAny(u8, cmd, " \t\n\r\x0b\x0c");
    while (it.next()) |w| l.append(gpa, w) catch util.oom();
    l.appendSlice(gpa, extra) catch util.oom();
    return l.items;
}

fn randomMinute() u32 {
    if (os.getenv("GIT_TEST_MAINT_SCHEDULER") != null) return 13;
    return @intCast(@mod(os.nowMicros(), 60));
}

fn execPath() []const u8 {
    return main.exec_path;
}

const extra_config = [_][]const u8{ "credential.interactive=false", "core.askPass=true" };

fn extraConfigParameters() []const u8 {
    var b: util.Buf = .empty;
    for (extra_config) |s| util.bufPrint(&b, "-c {s} ", .{s});
    return b.items;
}

fn extraLaunchctlStrings() []const u8 {
    var b: util.Buf = .empty;
    for (extra_config) |s| {
        util.bufAppend(&b, "<string>-c</string>\n");
        util.bufPrint(&b, "<string>{s}</string>\n", .{s});
    }
    return b.items;
}

const RunRes = struct { started: bool, status: u8 };

fn runExternal(argv: []const []const u8, o: os.SpawnOpts) RunRes {
    traceChildStart(argv, false);
    const r = os.run(argv, o);
    if (!r.signaled and r.status == 127) return .{ .started = false, .status = 127 };
    return .{ .started = true, .status = r.status };
}

// --- launchctl

fn isLaunchctlAvailable() bool {
    if (getScheduleCmd("launchctl")) |r| return r.available;
    return @import("builtin").os.tag == .macos;
}

fn launchctlFilename(name: []const u8) []const u8 {
    const f = util.fmt("~/Library/LaunchAgents/{s}.plist", .{name});
    return config.interpolatePath(f, true) orelse util.die("failed to expand path '{s}'", .{f});
}

fn launchctlBoot(enable: bool, filename: []const u8) u8 {
    const cmd = scheduleCmd("launchctl");
    const uid = util.fmt("gui/{d}", .{getuid()});
    const r = runExternal(splitCmd(cmd, &.{ if (enable) "bootstrap" else "bootout", uid, filename }), .{ .capture_stdout = true, .no_stderr = true });
    if (!r.started) util.die("failed to start launchctl", .{});
    return r.status;
}

fn launchctlRemove(s: Schedule) u8 {
    const name = util.fmt("org.git-scm.git.{s}", .{frequencyName(s)});
    const filename = launchctlFilename(name);
    const r = launchctlBoot(false, filename);
    _ = os.unlink(filename);
    return r;
}

fn launchctlListContains(name: []const u8, cmd: []const u8) bool {
    const r = runExternal(splitCmd(cmd, &.{ "list", name }), .{ .capture_stdout = true, .no_stderr = true });
    if (!r.started) util.die("failed to start launchctl", .{});
    return r.status == 0;
}

fn launchctlSchedule(s: Schedule) u8 {
    const freq = frequencyName(s);
    const name = util.fmt("org.git-scm.git.{s}", .{freq});
    const filename = launchctlFilename(name);
    const cmd = scheduleCmd("launchctl");
    const minute = randomMinute();
    const ep = execPath();
    var b: util.Buf = .empty;
    util.bufPrint(&b, "<?xml version=\"1.0\"?>\n" ++
        "<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n" ++
        "<plist version=\"1.0\">" ++
        "<dict>\n" ++
        "<key>Label</key><string>{s}</string>\n" ++
        "<key>ProgramArguments</key>\n" ++
        "<array>\n" ++
        "<string>{s}/git</string>\n" ++
        "<string>--exec-path={s}</string>\n" ++
        "{s}" ++
        "<string>for-each-repo</string>\n" ++
        "<string>--keep-going</string>\n" ++
        "<string>--config=maintenance.repo</string>\n" ++
        "<string>maintenance</string>\n" ++
        "<string>run</string>\n" ++
        "<string>--schedule={s}</string>\n" ++
        "</array>\n" ++
        "<key>StartCalendarInterval</key>\n" ++
        "<array>\n", .{ name, ep, ep, extraLaunchctlStrings(), freq });
    switch (s) {
        .hourly => {
            var i: u32 = 1;
            while (i <= 23) : (i += 1) util.bufPrint(&b, "<dict>\n<key>Hour</key><integer>{d}</integer>\n<key>Minute</key><integer>{d}</integer>\n</dict>\n", .{ i, minute });
        },
        .daily => {
            var i: u32 = 1;
            while (i <= 6) : (i += 1) util.bufPrint(&b, "<dict>\n<key>Weekday</key><integer>{d}</integer>\n<key>Hour</key><integer>0</integer>\n<key>Minute</key><integer>{d}</integer>\n</dict>\n", .{ i, minute });
        },
        .weekly => util.bufPrint(&b, "<dict>\n<key>Weekday</key><integer>0</integer>\n<key>Hour</key><integer>0</integer>\n<key>Minute</key><integer>{d}</integer>\n</dict>\n", .{minute}),
        .none => {},
    }
    util.bufAppend(&b, "</array>\n</dict>\n</plist>\n");
    if (!os.mkdirLeading(filename)) util.die("failed to create directories for '{s}'", .{filename});
    const lk = lockfile.lockOrDie(filename);
    if (os.readFile(filename)) |old| {
        if (std.mem.eql(u8, old, b.items) and launchctlListContains(name, cmd)) {
            lk.rollback();
            return 0;
        }
    }
    lk.write(b.items);
    if (!lk.commit()) util.dieErrno("could not write '{s}'", .{filename});
    _ = launchctlBoot(false, filename);
    if (launchctlBoot(true, filename) != 0) util.die("failed to bootstrap service {s}", .{filename});
    return 0;
}

fn launchctlUpdate(enable: bool, _: *lockfile.Lock) u8 {
    if (enable) {
        if (launchctlSchedule(.hourly) != 0) return 1;
        if (launchctlSchedule(.daily) != 0) return 1;
        if (launchctlSchedule(.weekly) != 0) return 1;
        return 0;
    }
    if (launchctlRemove(.hourly) != 0) return 1;
    if (launchctlRemove(.daily) != 0) return 1;
    if (launchctlRemove(.weekly) != 0) return 1;
    return 0;
}

// --- schtasks

fn isSchtasksAvailable() bool {
    if (getScheduleCmd("schtasks")) |r| return r.available;
    return false;
}

fn schtasksRemove(s: Schedule) u8 {
    const name = util.fmt("Git Maintenance ({s})", .{frequencyName(s)});
    const r = runExternal(splitCmd(scheduleCmd("schtasks"), &.{ "/delete", "/tn", name, "/f" }), .{});
    return r.status;
}

fn schtasksSchedule(s: Schedule) u8 {
    const freq = frequencyName(s);
    const name = util.fmt("Git Maintenance ({s})", .{freq});
    const minute = randomMinute();
    const cmd = scheduleCmd("schtasks");
    const t = os.tmpFile(repo_mod.repo().common_dir, util.fmt("schedule_{s}_", .{freq}));
    if (t.fd < 0) util.dieErrno("unable to create temporary file", .{});
    var b: util.Buf = .empty;
    util.bufAppend(&b, "<?xml version=\"1.0\" ?>\n" ++
        "<Task version=\"1.4\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">\n" ++
        "<Triggers>\n" ++
        "<CalendarTrigger>\n");
    switch (s) {
        .hourly => util.bufPrint(&b, "<StartBoundary>2020-01-01T01:{d:0>2}:00</StartBoundary>\n" ++
            "<Enabled>true</Enabled>\n" ++
            "<ScheduleByDay>\n" ++
            "<DaysInterval>1</DaysInterval>\n" ++
            "</ScheduleByDay>\n" ++
            "<Repetition>\n" ++
            "<Interval>PT1H</Interval>\n" ++
            "<Duration>PT23H</Duration>\n" ++
            "<StopAtDurationEnd>false</StopAtDurationEnd>\n" ++
            "</Repetition>\n", .{minute}),
        .daily => util.bufPrint(&b, "<StartBoundary>2020-01-01T00:{d:0>2}:00</StartBoundary>\n" ++
            "<Enabled>true</Enabled>\n" ++
            "<ScheduleByWeek>\n" ++
            "<DaysOfWeek>\n" ++
            "<Monday />\n" ++
            "<Tuesday />\n" ++
            "<Wednesday />\n" ++
            "<Thursday />\n" ++
            "<Friday />\n" ++
            "<Saturday />\n" ++
            "</DaysOfWeek>\n" ++
            "<WeeksInterval>1</WeeksInterval>\n" ++
            "</ScheduleByWeek>\n", .{minute}),
        .weekly => util.bufPrint(&b, "<StartBoundary>2020-01-01T00:{d:0>2}:00</StartBoundary>\n" ++
            "<Enabled>true</Enabled>\n" ++
            "<ScheduleByWeek>\n" ++
            "<DaysOfWeek>\n" ++
            "<Sunday />\n" ++
            "</DaysOfWeek>\n" ++
            "<WeeksInterval>1</WeeksInterval>\n" ++
            "</ScheduleByWeek>\n", .{minute}),
        .none => {},
    }
    const ep = execPath();
    util.bufPrint(&b, "</CalendarTrigger>\n" ++
        "</Triggers>\n" ++
        "<Principals>\n" ++
        "<Principal id=\"Author\">\n" ++
        "<LogonType>InteractiveToken</LogonType>\n" ++
        "<RunLevel>LeastPrivilege</RunLevel>\n" ++
        "</Principal>\n" ++
        "</Principals>\n" ++
        "<Settings>\n" ++
        "<MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>\n" ++
        "<Enabled>true</Enabled>\n" ++
        "<Hidden>true</Hidden>\n" ++
        "<UseUnifiedSchedulingEngine>true</UseUnifiedSchedulingEngine>\n" ++
        "<WakeToRun>false</WakeToRun>\n" ++
        "<ExecutionTimeLimit>PT72H</ExecutionTimeLimit>\n" ++
        "<Priority>7</Priority>\n" ++
        "</Settings>\n" ++
        "<Actions Context=\"Author\">\n" ++
        "<Exec>\n" ++
        "<Command>\"{s}\\headless-git.exe\"</Command>\n" ++
        "<Arguments>--exec-path=\"{s}\" {s} for-each-repo --keep-going --config=maintenance.repo maintenance run --schedule={s}</Arguments>\n" ++
        "</Exec>\n" ++
        "</Actions>\n" ++
        "</Task>\n", .{ ep, ep, extraConfigParameters(), freq });
    os.writeAll(t.fd, b.items) catch {};
    os.close(t.fd);
    const r = runExternal(splitCmd(cmd, &.{ "/create", "/tn", name, "/f", "/xml", t.path }), .{ .capture_stdout = true, .no_stderr = true });
    _ = os.unlink(t.path);
    if (!r.started) util.die("failed to start schtasks", .{});
    return r.status;
}

fn schtasksUpdate(enable: bool, _: *lockfile.Lock) u8 {
    if (enable) {
        if (schtasksSchedule(.hourly) != 0) return 1;
        if (schtasksSchedule(.daily) != 0) return 1;
        if (schtasksSchedule(.weekly) != 0) return 1;
        return 0;
    }
    if (schtasksRemove(.hourly) != 0) return 1;
    if (schtasksRemove(.daily) != 0) return 1;
    if (schtasksRemove(.weekly) != 0) return 1;
    return 0;
}

// --- crontab

fn isCrontabAvailable() bool {
    if (getScheduleCmd("crontab")) |r| return r.available;
    if (@import("builtin").os.tag == .macos) return false;
    const r = runExternal(splitCmd("crontab", &.{"-l"}), .{ .no_stdin = true, .capture_stdout = true, .no_stderr = true });
    return r.started;
}

const BEGIN_LINE = "# BEGIN GIT MAINTENANCE SCHEDULE";
const END_LINE = "# END GIT MAINTENANCE SCHEDULE";

fn crontabUpdate(enable: bool, lk: *lockfile.Lock) u8 {
    const cmd = scheduleCmd("crontab");
    const minute = randomMinute();
    // crontab -l > lockfile
    {
        const argv = splitCmd(cmd, &.{"-l"});
        traceChildStart(argv, false);
        const ch = proc.spawn(argv, .{ .out_fd = lk.fd });
        const st = proc.wait(ch.pid);
        if (st == 127) {
            util.err("failed to run 'crontab -l'; your system might not support 'cron'", .{});
            return 1;
        }
    }
    const tmpdir = os.getenv("TMPDIR") orelse "/tmp";
    const t = os.tmpFile(if (tmpdir.len > 0) tmpdir else "/tmp", ".git_cron_edit_tmp");
    if (t.fd < 0) {
        util.err("failed to create crontab temporary file", .{});
        return 1;
    }
    defer _ = os.unlink(t.path);
    const old = os.readFile(lk.lock_path) orelse "";
    var b: util.Buf = .empty;
    var in_old = false;
    var it = std.mem.splitScalar(u8, old, '\n');
    var lines: std.ArrayList([]const u8) = .empty;
    while (it.next()) |l| lines.append(gpa, l) catch util.oom();
    if (lines.items.len > 0 and lines.items[lines.items.len - 1].len == 0) lines.items.len -= 1;
    for (lines.items) |line| {
        if (!in_old and util.eql(line, BEGIN_LINE)) {
            in_old = true;
        } else if (in_old and util.eql(line, END_LINE)) {
            in_old = false;
        } else if (!in_old) {
            util.bufAppend(&b, line);
            util.bufByte(&b, '\n');
        }
    }
    if (enable) {
        const ep = execPath();
        util.bufPrint(&b, "{s}\n", .{BEGIN_LINE});
        util.bufAppend(&b, "# The following schedule was created by Git\n");
        util.bufAppend(&b, "# Any edits made in this region might be\n");
        util.bufAppend(&b, "# replaced in the future by a Git command.\n\n");
        const extra = extraConfigParameters();
        const rows = [_][3][]const u8{ .{ "1-23", "*", "hourly" }, .{ "0", "1-6", "daily" }, .{ "0", "0", "weekly" } };
        for (rows) |row| {
            util.bufPrint(&b, "{d} {s} * * {s} \"{s}/git\" --exec-path=\"{s}\" {s} for-each-repo --keep-going --config=maintenance.repo maintenance run --schedule={s}\n", .{ minute, row[0], row[1], ep, ep, extra, row[2] });
        }
        util.bufPrint(&b, "\n{s}\n", .{END_LINE});
    }
    os.writeAll(t.fd, b.items) catch {};
    os.close(t.fd);
    const r = runExternal(splitCmd(cmd, &.{t.path}), .{});
    if (!r.started) {
        util.err("failed to run 'crontab'; your system might not support 'cron'", .{});
        return 1;
    }
    if (r.status != 0) {
        util.err("'crontab' died", .{});
        return 1;
    }
    return 0;
}

// --- systemd

fn isSystemdAvailable() bool {
    if (getScheduleCmd("systemctl")) |r| return r.available;
    const r = runExternal(&.{ "systemctl", "--user", "list-timers" }, .{ .no_stdin = true, .capture_stdout = true, .no_stderr = true });
    return r.started and r.status == 0;
}

fn systemdPath(filename: []const u8) []const u8 {
    if (os.getenv("XDG_CONFIG_HOME")) |x| {
        if (x.len > 0) return util.concat(&.{ x, "/systemd/user/", filename });
    }
    const home = os.getenv("HOME") orelse util.die("$HOME not set", .{});
    return util.concat(&.{ home, "/.config/systemd/user/", filename });
}

fn unlinkMissingOk(path: []const u8, is_warn: bool) u8 {
    if (!os.unlink(path) and os.errno() != os.ENOENT and os.errno() != 20) {
        if (is_warn) util.warn("failed to delete '{s}'", .{path}) else util.err("failed to delete '{s}': {s}", .{ path, os.lastErr() });
        return 1;
    }
    return 0;
}

fn systemdWriteTimer(s: Schedule, minute: u32) bool {
    const freq = frequencyName(s);
    const filename = systemdPath(util.fmt("git-maintenance@{s}.timer", .{freq}));
    if (!os.mkdirLeading(filename)) {
        util.err("failed to create directories for '{s}'", .{filename});
        return false;
    }
    const pattern = switch (s) {
        .hourly => util.fmt("*-*-* 1..23:{d:0>2}:00", .{minute}),
        .daily => util.fmt("Tue..Sun *-*-* 0:{d:0>2}:00", .{minute}),
        .weekly => util.fmt("Mon 0:{d:0>2}:00", .{minute}),
        .none => unreachable,
    };
    const unit = util.fmt("# This file was created and is maintained by Git.\n" ++
        "# Any edits made in this file might be replaced in the future\n" ++
        "# by a Git command.\n" ++
        "\n" ++
        "[Unit]\n" ++
        "Description=Optimize Git repositories data\n" ++
        "\n" ++
        "[Timer]\n" ++
        "OnCalendar={s}\n" ++
        "Persistent=true\n" ++
        "\n" ++
        "[Install]\n" ++
        "WantedBy=timers.target\n", .{pattern});
    os.writeFile(filename, unit, 0o666) catch {
        util.warn("unable to access '{s}': {s}", .{ filename, os.lastErr() });
        return false;
    };
    return true;
}

fn systemdWriteService() bool {
    const filename = systemdPath("git-maintenance@.service");
    if (!os.mkdirLeading(filename)) {
        util.err("failed to create directories for '{s}'", .{filename});
        return false;
    }
    const ep = execPath();
    const unit = util.fmt("# This file was created and is maintained by Git.\n" ++
        "# Any edits made in this file might be replaced in the future\n" ++
        "# by a Git command.\n" ++
        "\n" ++
        "[Unit]\n" ++
        "Description=Optimize Git repositories data\n" ++
        "\n" ++
        "[Service]\n" ++
        "Type=oneshot\n" ++
        "ExecStart=\"{s}/git\" --exec-path=\"{s}\" {s} for-each-repo --keep-going --config=maintenance.repo maintenance run --schedule=%i\n" ++
        "LockPersonality=yes\n" ++
        "MemoryDenyWriteExecute=yes\n" ++
        "NoNewPrivileges=yes\n" ++
        "RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6 AF_VSOCK\n" ++
        "RestrictNamespaces=yes\n" ++
        "RestrictRealtime=yes\n" ++
        "RestrictSUIDSGID=yes\n" ++
        "SystemCallArchitectures=native\n" ++
        "SystemCallFilter=@system-service\n", .{ ep, ep, extraConfigParameters() });
    os.writeFile(filename, unit, 0o666) catch {
        util.warn("unable to access '{s}': {s}", .{ filename, os.lastErr() });
        return false;
    };
    return true;
}

fn systemdEnableUnit(enable: bool, s: Schedule, minute: u32) u8 {
    const freq = frequencyName(s);
    if (enable and !systemdWriteTimer(s, minute)) return 1;
    const cmd = scheduleCmd("systemctl");
    const unit = util.fmt("git-maintenance@{s}.timer", .{freq});
    const r = runExternal(splitCmd(cmd, &.{ "--user", if (enable) "enable" else "disable", "--now", unit }), .{ .no_stderr = !enable });
    if (!r.started) {
        util.err("failed to start systemctl", .{});
        return 1;
    }
    if (r.status != 0 and enable) {
        util.err("failed to run systemctl", .{});
        return 1;
    }
    return 0;
}

fn systemdDeleteStaleTemplates() void {
    _ = unlinkMissingOk(systemdPath("git-maintenance@.timer"), true);
}

fn systemdDeleteUnitFiles() u8 {
    systemdDeleteStaleTemplates();
    var r: u8 = 0;
    r |= unlinkMissingOk(systemdPath("git-maintenance@hourly.timer"), false);
    r |= unlinkMissingOk(systemdPath("git-maintenance@daily.timer"), false);
    r |= unlinkMissingOk(systemdPath("git-maintenance@weekly.timer"), false);
    r |= unlinkMissingOk(systemdPath("git-maintenance@.service"), false);
    return r;
}

fn systemdDeleteUnits() u8 {
    const minute = randomMinute();
    var r: u8 = 0;
    r |= systemdEnableUnit(false, .hourly, minute);
    r |= systemdEnableUnit(false, .daily, minute);
    r |= systemdEnableUnit(false, .weekly, minute);
    r |= systemdDeleteUnitFiles();
    return r;
}

fn systemdUpdate(enable: bool, _: *lockfile.Lock) u8 {
    if (!enable) return systemdDeleteUnits();
    const minute = randomMinute();
    const failed = !systemdWriteService() or
        systemdEnableUnit(true, .hourly, minute) != 0 or
        systemdEnableUnit(true, .daily, minute) != 0 or
        systemdEnableUnit(true, .weekly, minute) != 0;
    if (failed) {
        _ = systemdDeleteUnits();
        return 1;
    }
    systemdDeleteStaleTemplates();
    return 0;
}

const Scheduler = enum(u8) { auto = 0, cron = 1, systemd = 2, launchctl = 3, schtasks = 4 };

const SchedulerFn = struct {
    name: []const u8,
    available: *const fn () bool,
    update: *const fn (bool, *lockfile.Lock) u8,
};

const scheduler_fns = [_]SchedulerFn{
    .{ .name = "", .available = isCrontabAvailable, .update = crontabUpdate },
    .{ .name = "crontab", .available = isCrontabAvailable, .update = crontabUpdate },
    .{ .name = "systemctl", .available = isSystemdAvailable, .update = systemdUpdate },
    .{ .name = "launchctl", .available = isLaunchctlAvailable, .update = launchctlUpdate },
    .{ .name = "schtasks", .available = isSchtasksAvailable, .update = schtasksUpdate },
};

var opt_scheduler: Scheduler = .auto;

fn schedulerCb(arg: ?[]const u8, _: bool) void {
    const v = arg orelse "";
    if (std.ascii.eqlIgnoreCase(v, "auto")) {
        opt_scheduler = .auto;
    } else if (std.ascii.eqlIgnoreCase(v, "cron") or std.ascii.eqlIgnoreCase(v, "crontab")) {
        opt_scheduler = .cron;
    } else if (std.ascii.eqlIgnoreCase(v, "systemd") or std.ascii.eqlIgnoreCase(v, "systemd-timer")) {
        opt_scheduler = .systemd;
    } else if (std.ascii.eqlIgnoreCase(v, "launchctl")) {
        opt_scheduler = .launchctl;
    } else if (std.ascii.eqlIgnoreCase(v, "schtasks")) {
        opt_scheduler = .schtasks;
    } else {
        util.err("unrecognized --scheduler argument '{s}'", .{v});
        po.usageWithOptions(cur_usage, cur_opts);
    }
}

fn resolveScheduler(s: Scheduler) Scheduler {
    if (s != .auto) return s;
    switch (@import("builtin").os.tag) {
        .macos => return .launchctl,
        .windows => return .schtasks,
        .linux => {
            if (isSystemdAvailable()) return .systemd;
            if (isCrontabAvailable()) return .cron;
            util.die("neither systemd timers nor crontab are available", .{});
        },
        else => return .cron,
    }
}

fn updateBackgroundSchedule(enable: bool, sched: Scheduler) u8 {
    const lock_path = util.concat(&.{ objectsDir(), "/schedule" });
    const lk = switch (lockfile.tryLock(lock_path)) {
        .ok => |l| l,
        .err => |e| {
            if (e == os.EEXIST) {
                const abs = if (lock_path.len > 0 and lock_path[0] == '/') lock_path else util.concat(&.{ os.getcwd(), "/", lock_path });
                util.err("unable to create '{s}.lock': {s}.\n\n" ++
                    "Another scheduled git-maintenance(1) process seems to be running in this\n" ++
                    "repository. Please make sure no other maintenance processes are running and\n" ++
                    "then try again. If it still fails, a git-maintenance(1) process may have\n" ++
                    "crashed in this repository earlier: remove the file manually to continue.", .{ abs, os.strErr(e) });
            } else util.err("cannot acquire lock for scheduled background maintenance: {s}", .{os.strErr(e)});
            return 1;
        },
    };
    var i: usize = 1;
    while (i < scheduler_fns.len) : (i += 1) {
        if (enable and @intFromEnum(sched) == i) continue;
        if (!scheduler_fns[i].available()) continue;
        _ = scheduler_fns[i].update(false, lk);
    }
    var result: u8 = 0;
    if (enable) result = scheduler_fns[@intFromEnum(sched)].update(true, lk);
    lk.rollback();
    return result;
}

const start_usage = [_][]const u8{"git maintenance start [--scheduler=<scheduler>]"};

fn cmdStart(args: []const []const u8) u8 {
    const options = [_]po.Opt{
        .{ .long = "scheduler", .kind = .callback, .cb = schedulerCb, .argh = "scheduler", .noneg = true, .help = "scheduler to trigger git maintenance run" },
    };
    cur_usage = &start_usage;
    cur_opts = &options;
    const rest = po.parse(args, &options, &start_usage, .{});
    if (rest.len != 0) po.usageWithOptions(&start_usage, &options);
    const sched = resolveScheduler(opt_scheduler);
    if (!scheduler_fns[@intFromEnum(sched)].available())
        util.die("{s} scheduler is not available", .{scheduler_fns[@intFromEnum(sched)].name});
    if (updateBackgroundSchedule(true, sched) != 0) util.die("failed to set up maintenance schedule", .{});
    if (doRegister(null) != 0) util.warn("failed to add repo to global config", .{});
    return 0;
}

const stop_usage = [_][]const u8{"git maintenance stop"};

fn cmdStop(args: []const []const u8) u8 {
    const rest = po.parse(args, &.{}, &stop_usage, .{});
    if (rest.len != 0) po.usageWithOptions(&stop_usage, &.{});
    return updateBackgroundSchedule(false, .auto);
}

// ---------------------------------------------------------------------------

const maint_usage = [_][]const u8{"git maintenance <subcommand> [<options>]"};

pub fn cmdMaintenance(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").maintenance);
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&maint_usage, &.{});
    }
    const sub = args[1];
    const rest = args[2..];
    if (util.eql(sub, "-h") or util.eql(sub, "--help-all")) po.usageExit(&maint_usage, &.{}, false);
    if (util.eql(sub, "run")) return cmdRun(rest);
    if (util.eql(sub, "start")) return cmdStart(rest);
    if (util.eql(sub, "stop")) return cmdStop(rest);
    if (util.eql(sub, "register")) return cmdRegister(rest);
    if (util.eql(sub, "unregister")) return cmdUnregister(rest);
    if (util.eql(sub, "is-needed")) return cmdIsNeeded(rest);
    if (sub.len > 0 and sub[0] == '-') {
        if (util.startsWith(sub, "--")) {
            util.err("unknown option `{s}'", .{sub[2..]});
        } else util.err("unknown switch `{c}'", .{if (sub.len > 1) sub[1] else '-'});
    } else util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&maint_usage, &.{});
}

// ---------------------------------------------------------------------------
// for-each-repo

const fer_usage = [_][]const u8{"git for-each-repo --config=<config> [--] <arguments>"};

pub fn cmdForEachRepo(args: []const []const u8) u8 {
    var config_key: ?[]const u8 = null;
    var keep_going = false;
    const options = [_]po.Opt{
        po.string(0, "config", &config_key, "config", "config key storing a list of repository paths"),
        po.boolean(0, "keep-going", &keep_going, "keep going even if command fails in a repository"),
    };
    const rest = po.parse(args[1..], &options, &fer_usage, .{ .stop_at_non_option = true });
    const key = config_key orelse util.die("missing --config=<config>", .{});

    // validate the key and collect values (NULL values are an error)
    const bad = switch (config.parseKeyFull(key, false)) {
        .ok => false,
        .err => true,
    };
    var values: std.ArrayList([]const u8) = .empty;
    if (!bad) {
        const ck = config.canonicalKey(key) orelse key;
        for (repo_mod.cfg.entries.items) |e| {
            if (!util.eql(e.key, ck)) continue;
            if (e.value) |v| {
                values.append(gpa, v) catch util.oom();
            } else {
                util.err("missing value for '{s}'", .{e.key});
                util.flushStdout();
                util.eprint("fatal: got bad config --config={s}\n\n", .{key});
                po.usageWithOptions(&fer_usage, &options);
            }
        }
    } else {
        util.eprint("fatal: got bad config --config={s}\n\n", .{key});
        po.usageWithOptions(&fer_usage, &options);
    }
    if (values.items.len == 0) return 0;

    var unset: std.ArrayList([]const u8) = .empty;
    for (transport.local_repo_env) |v| {
        if (util.eql(v, "GIT_CONFIG_PARAMETERS") or util.eql(v, "GIT_CONFIG_COUNT")) continue;
        unset.append(gpa, v) catch util.oom();
    }
    var result: u8 = 0;
    for (values.items) |p| {
        const abspath = config.interpolatePath(p, false) orelse p;
        var cargs: std.ArrayList([]const u8) = .empty;
        cargs.appendSlice(gpa, &.{ "-C", abspath }) catch util.oom();
        cargs.appendSlice(gpa, rest) catch util.oom();
        const ret = runGitOpts(cargs.items, .{ .unset_env = unset.items });
        if (ret != 0) {
            if (!keep_going) return ret;
            result = 1;
        }
    }
    return result;
}
