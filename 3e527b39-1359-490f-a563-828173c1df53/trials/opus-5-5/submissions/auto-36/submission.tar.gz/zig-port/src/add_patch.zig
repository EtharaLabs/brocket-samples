//! Interactive hunk selection (add-patch.c): `git add -p`, `git stash -p`,
//! `git reset -p`, `git checkout -p`, `git restore -p`.
//! Colors follow color.interactive / color.diff (with interactive.diffFilter).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const proc = @import("proc.zig");
const repo_mod = @import("repo.zig");
const revparse = @import("revparse.zig");
const hash = @import("hash.zig");
const regex = @import("regex.zig");
const editor = @import("editor.zig");
const pretty_trailer = @import("pretty_trailer.zig");
const advice = @import("advice.zig");

const gpa = util.gpa;
const color = @import("color.zig");

const Colors = struct {
    use_diff: bool = false,
    header: []const u8 = "",
    help: []const u8 = "",
    prompt: []const u8 = "",
    err: []const u8 = "",
    reset_i: []const u8 = "",
    fraginfo: []const u8 = "",
    context: []const u8 = "",
    old: []const u8 = "",
    new: []const u8 = "",
    reset_d: []const u8 = "",
    diff_filter: ?[]const u8 = null,
};
var colors: Colors = .{};

fn checkColorConfig(key: []const u8) color.ColorBool {
    var cb: color.ColorBool = .unknown;
    if (repo_mod.cfg.getEntry(key)) |e| cb = color.configColorBool(key, e.value);
    if (cb == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| cb = color.configColorBool("color.ui", e.value);
    }
    return cb;
}

fn initColor(use: bool, slot: []const u8, default: []const u8) []const u8 {
    if (!use) return "";
    if (repo_mod.cfg.get(util.concat(&.{ "color.", slot }))) |v| {
        if (color.parseColor(v)) |c| return c;
    }
    return default;
}

fn initColors() void {
    const ui = color.wantColorBool(checkColorConfig("color.interactive"), null);
    colors.header = initColor(ui, "interactive.header", color.BOLD);
    colors.help = initColor(ui, "interactive.help", color.BOLD_RED);
    colors.prompt = initColor(ui, "interactive.prompt", color.BOLD_BLUE);
    colors.err = initColor(ui, "interactive.error", color.BOLD_RED);
    colors.reset_i = if (ui) color.RESET else "";
    const ud = color.wantColorBool(checkColorConfig("color.diff"), null);
    colors.use_diff = ud;
    colors.fraginfo = initColor(ud, "diff.frag", color.CYAN);
    colors.context = if (repo_mod.cfg.get("color.diff.context") != null) initColor(ud, "diff.context", "") else initColor(ud, "diff.plain", "");
    colors.old = initColor(ud, "diff.old", color.RED);
    colors.new = initColor(ud, "diff.new", color.GREEN);
    colors.reset_d = if (ud) color.RESET else "";
    colors.diff_filter = repo_mod.cfg.get("interactive.difffilter");
}

/// color_fprintf(stdout, ...)
fn colorOut(c: []const u8, text: []const u8) void {
    if (c.len > 0) {
        util.out(c);
        util.out(text);
        util.out(color.RESET);
    } else util.out(text);
}

fn colorOutLn(c: []const u8, text: []const u8) void {
    colorOut(c, text);
    util.out("\n");
}

pub const Mode = enum { add, stash, reset, checkout, worktree };

pub const Options = struct {
    context: i32 = -1,
    interhunkcontext: i32 = -1,
    auto_advance: bool = true,
};

pub const DISALLOW_EDIT: u32 = 1;

const PatchMode = struct {
    diff_cmd: []const []const u8,
    apply_args: []const []const u8 = &.{},
    apply_check_args: []const []const u8 = &.{},
    is_reverse: bool = false,
    index_only: bool = false,
    apply_for_checkout: bool = false,
    prompt_mode: [4][]const u8,
    edit_hunk_hint: []const u8,
    help_patch_text: []const u8,
};

fn helpText(comptime verb: []const u8, comptime rest: []const u8, comptime a_verb: []const u8) []const u8 {
    return "y - " ++ verb ++ " this hunk" ++ rest ++ "\n" ++
        "n - do not " ++ verb ++ " this hunk" ++ rest ++ "\n" ++
        "q - quit; do not " ++ verb ++ " this hunk or any of the remaining ones\n" ++
        "a - " ++ a_verb ++ " this hunk and all later hunks in the file\n" ++
        "d - do not " ++ a_verb ++ " this hunk or any of the later hunks in the file\n";
}

fn prompts(comptime pre: []const u8, comptime post: []const u8) [4][]const u8 {
    return .{
        pre ++ " mode change" ++ post ++ "%s [y,n,q,a,d%s,?]? ",
        pre ++ " deletion" ++ post ++ "%s [y,n,q,a,d%s,?]? ",
        pre ++ " addition" ++ post ++ "%s [y,n,q,a,d%s,?]? ",
        pre ++ " this hunk" ++ post ++ "%s [y,n,q,a,d%s,?]? ",
    };
}

fn hint(comptime what: []const u8) []const u8 {
    return "If the patch applies cleanly, the edited hunk will immediately be marked for " ++ what ++ ".";
}

const mode_add = PatchMode{
    .diff_cmd = &.{"diff-files"},
    .apply_args = &.{"--cached"},
    .apply_check_args = &.{"--cached"},
    .prompt_mode = prompts("Stage", ""),
    .edit_hunk_hint = hint("staging"),
    .help_patch_text = helpText("stage", "", "stage"),
};

const mode_stash = PatchMode{
    .diff_cmd = &.{ "diff-index", "HEAD" },
    .apply_args = &.{"--cached"},
    .apply_check_args = &.{"--cached"},
    .prompt_mode = prompts("Stash", ""),
    .edit_hunk_hint = hint("stashing"),
    .help_patch_text = helpText("stash", "", "stash"),
};

const mode_reset_head = PatchMode{
    .diff_cmd = &.{ "diff-index", "--cached" },
    .apply_args = &.{ "-R", "--cached" },
    .apply_check_args = &.{ "-R", "--cached" },
    .is_reverse = true,
    .index_only = true,
    .prompt_mode = prompts("Unstage", ""),
    .edit_hunk_hint = hint("unstaging"),
    .help_patch_text = helpText("unstage", "", "unstage"),
};

const mode_reset_nothead = PatchMode{
    .diff_cmd = &.{ "diff-index", "-R", "--cached" },
    .apply_args = &.{"--cached"},
    .apply_check_args = &.{"--cached"},
    .index_only = true,
    .prompt_mode = .{
        "Apply mode change to index%s [y,n,q,a,d%s,?]? ",
        "Apply deletion to index%s [y,n,q,a,d%s,?]? ",
        "Apply addition to index%s [y,n,q,a,d%s,?]? ",
        "Apply this hunk to index%s [y,n,q,a,d%s,?]? ",
    },
    .edit_hunk_hint = hint("applying"),
    .help_patch_text = "y - apply this hunk to index\n" ++
        "n - do not apply this hunk to index\n" ++
        "q - quit; do not apply this hunk or any of the remaining ones\n" ++
        "a - apply this hunk and all later hunks in the file\n" ++
        "d - do not apply this hunk or any of the later hunks in the file\n",
};

const mode_checkout_index = PatchMode{
    .diff_cmd = &.{"diff-files"},
    .apply_args = &.{"-R"},
    .apply_check_args = &.{"-R"},
    .is_reverse = true,
    .prompt_mode = prompts("Discard", " from worktree"),
    .edit_hunk_hint = hint("discarding"),
    .help_patch_text = helpText("discard", " from worktree", "discard"),
};

const mode_checkout_head = PatchMode{
    .diff_cmd = &.{"diff-index"},
    .apply_for_checkout = true,
    .apply_check_args = &.{"-R"},
    .is_reverse = true,
    .prompt_mode = prompts("Discard", " from index and worktree"),
    .edit_hunk_hint = hint("discarding"),
    .help_patch_text = helpText("discard", " from index and worktree", "discard"),
};

const mode_checkout_nothead = PatchMode{
    .diff_cmd = &.{ "diff-index", "-R" },
    .apply_for_checkout = true,
    .prompt_mode = .{
        "Apply mode change to index and worktree%s [y,n,q,a,d%s,?]? ",
        "Apply deletion to index and worktree%s [y,n,q,a,d%s,?]? ",
        "Apply addition to index and worktree%s [y,n,q,a,d%s,?]? ",
        "Apply this hunk to index and worktree%s [y,n,q,a,d%s,?]? ",
    },
    .edit_hunk_hint = hint("applying"),
    .help_patch_text = "y - apply this hunk to index and worktree\n" ++
        "n - do not apply this hunk to index and worktree\n" ++
        "q - quit; do not apply this hunk or any of the remaining ones\n" ++
        "a - apply this hunk and all later hunks in the file\n" ++
        "d - do not apply this hunk or any of the later hunks in the file\n",
};

const mode_worktree_head = PatchMode{
    .diff_cmd = &.{"diff-index"},
    .apply_args = &.{"-R"},
    .apply_check_args = &.{"-R"},
    .is_reverse = true,
    .prompt_mode = prompts("Discard", " from worktree"),
    .edit_hunk_hint = hint("discarding"),
    .help_patch_text = helpText("discard", " from worktree", "discard"),
};

const mode_worktree_nothead = PatchMode{
    .diff_cmd = &.{ "diff-index", "-R" },
    .prompt_mode = .{
        "Apply mode change to worktree%s [y,n,q,a,d%s,?]? ",
        "Apply deletion to worktree%s [y,n,q,a,d%s,?]? ",
        "Apply addition to worktree%s [y,n,q,a,d%s,?]? ",
        "Apply this hunk to worktree%s [y,n,q,a,d%s,?]? ",
    },
    .edit_hunk_hint = hint("applying"),
    .help_patch_text = "y - apply this hunk to worktree\n" ++
        "n - do not apply this hunk to worktree\n" ++
        "q - quit; do not apply this hunk or any of the remaining ones\n" ++
        "a - apply this hunk and all later hunks in the file\n" ++
        "d - do not apply this hunk or any of the later hunks in the file\n",
};

const help_patch_remainder =
    "j - go to the next undecided hunk, roll over at the bottom\n" ++
    "J - go to the next hunk, roll over at the bottom\n" ++
    "k - go to the previous undecided hunk, roll over at the top\n" ++
    "K - go to the previous hunk, roll over at the top\n" ++
    "g - select a hunk to go to\n" ++
    "/ - search for a hunk matching the given regex\n" ++
    "s - split the current hunk into smaller hunks\n" ++
    "e - manually edit the current hunk\n" ++
    "p - print the current hunk\n" ++
    "P - print the current hunk using the pager\n" ++
    "> - go to the next file, roll over at the bottom\n" ++
    "< - go to the previous file, roll over at the top\n" ++
    "? - print help\n" ++
    "HUNKS SUMMARY - Hunks: %d, USE: %d, SKIP: %d\n";

const Use = enum { undecided, skip, use };

const HunkHeader = struct {
    old_offset: i64 = 0,
    old_count: i64 = 0,
    new_offset: i64 = 0,
    new_count: i64 = 0,
    extra_start: usize = 0,
    extra_end: usize = 0,
    colored_extra_start: usize = 0,
    colored_extra_end: usize = 0,
    suppress_colored_line_range: bool = false,
};

const Hunk = struct {
    start: usize = 0,
    end: usize = 0,
    colored_start: usize = 0,
    colored_end: usize = 0,
    splittable_into: usize = 0,
    delta: i64 = 0,
    use: Use = .undecided,
    header: HunkHeader = .{},
};

const FileDiff = struct {
    head: Hunk = .{},
    hunks: std.ArrayList(Hunk) = .empty,
    deleted: bool = false,
    added: bool = false,
    mode_change: bool = false,
    binary: bool = false,
};

const State = struct {
    mode: *const PatchMode,
    revision: ?[]const u8,
    index_file: []const u8,
    opts: Options,
    context: i32 = -1,
    interhunkcontext: i32 = -1,
    plain: util.Buf = .empty,
    colored: util.Buf = .empty,
    buf: util.Buf = .empty,
    answer: util.Buf = .empty,
    files: std.ArrayList(FileDiff) = .empty,
};

// ---------------- helpers ----------------

pub fn readLine(out: *util.Buf) bool {
    util.flushStdout();
    out.clearRetainingCapacity();
    var got = false;
    while (true) {
        var ch: [1]u8 = undefined;
        const n = std.c.read(0, &ch, 1);
        if (n <= 0) break;
        got = true;
        if (ch[0] == '\n') {
            if (out.items.len > 0 and out.items[out.items.len - 1] == '\r') out.items.len -= 1;
            return true;
        }
        out.append(gpa, ch[0]) catch util.oom();
    }
    return got;
}

fn errOut(comptime f: []const u8, args: anytype) void {
    util.out(colors.err);
    util.outf(f, args);
    util.out(colors.reset_i);
    util.out("\n");
}

fn runGit(s: *const State, args: []const []const u8, stdin_data: ?[]const u8, capture: bool) os.ChildResult {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    const env = [_][2][]const u8{.{ "GIT_INDEX_FILE", s.index_file }};
    return os.run(argv.items, .{ .env = &env, .stdin_data = stdin_data, .capture_stdout = capture });
}

fn findNextLine(b: []const u8, offset: usize) usize {
    if (std.mem.indexOfScalarPos(u8, b, offset, '\n')) |e| return e + 1;
    return b.len;
}

fn normalizeMarker(b: []const u8, p: usize) u8 {
    if (p >= b.len) return 0;
    if (b[p] == '\n' or (b[p] == '\r' and p + 1 < b.len and b[p + 1] == '\n')) return ' ';
    return b[p];
}

/// printf-style substitution of successive "%s" and "%d"
fn subst(fmt: []const u8, args: []const []const u8) []const u8 {
    var out: util.Buf = .empty;
    var i: usize = 0;
    var ai: usize = 0;
    while (i < fmt.len) {
        if (fmt[i] == '%' and i + 1 < fmt.len and (fmt[i + 1] == 's' or fmt[i + 1] == 'd')) {
            if (ai < args.len) util.bufAppend(&out, args[ai]);
            ai += 1;
            i += 2;
            continue;
        }
        util.bufByte(&out, fmt[i]);
        i += 1;
    }
    return out.items;
}

fn parseRange(line: []const u8, pos: *usize, offset: *i64, count: *i64) bool {
    var p = pos.*;
    const s = p;
    while (p < line.len and std.ascii.isDigit(line[p])) p += 1;
    if (p == s) return false;
    offset.* = std.fmt.parseInt(i64, line[s..p], 10) catch return false;
    if (p >= line.len or line[p] != ',') {
        count.* = 1;
        pos.* = p;
        return true;
    }
    p += 1;
    const cs = p;
    while (p < line.len and std.ascii.isDigit(line[p])) p += 1;
    if (p == cs) return false;
    count.* = std.fmt.parseInt(i64, line[cs..p], 10) catch return false;
    pos.* = p;
    return true;
}

fn parseHunkHeader(s: *State, hunk: *Hunk) bool {
    const b = s.plain.items;
    const eol = std.mem.indexOfScalarPos(u8, b, hunk.start, '\n') orelse b.len;
    const line = b[hunk.start..eol];
    var p: usize = 0;
    const h = &hunk.header;
    const ok = blk: {
        if (!std.mem.startsWith(u8, line, "@@ -")) break :blk false;
        p = 4;
        if (!parseRange(line, &p, &h.old_offset, &h.old_count)) break :blk false;
        if (!std.mem.startsWith(u8, line[p..], " +")) break :blk false;
        p += 2;
        if (!parseRange(line, &p, &h.new_offset, &h.new_count)) break :blk false;
        if (!std.mem.startsWith(u8, line[p..], " @@")) break :blk false;
        p += 3;
        break :blk true;
    };
    if (!ok) {
        util.err("could not parse hunk header '{s}'", .{line});
        return false;
    }
    const line_start = hunk.start;
    hunk.start = eol + @intFromBool(eol < b.len);
    h.extra_start = line_start + p;
    h.extra_end = hunk.start;
    if (s.colored.items.len == 0) {
        h.colored_extra_start = 0;
        h.colored_extra_end = 0;
        return true;
    }
    const cb = s.colored.items;
    const ceol = std.mem.indexOfScalarPos(u8, cb, hunk.colored_start, '\n') orelse cb.len;
    const cline = cb[hunk.colored_start..ceol];
    var found = false;
    if (std.mem.indexOf(u8, cline, "@@ -")) |a| {
        if (std.mem.indexOf(u8, cline[a + 4 ..], " @@")) |e| {
            h.colored_extra_start = hunk.colored_start + a + 4 + e + 3;
            found = true;
        }
    }
    if (!found) {
        h.colored_extra_start = hunk.colored_start;
        h.suppress_colored_line_range = true;
    }
    hunk.colored_start = ceol + @intFromBool(ceol < cb.len);
    h.colored_extra_end = hunk.colored_start;
    return true;
}

fn isOctal(p: []const u8) bool {
    if (p.len == 0) return false;
    for (p) |ch| if (ch < '0' or ch > '7') return false;
    return true;
}

fn completeFile(marker: u8, hunk: ?*Hunk) void {
    if (hunk) |h| if (marker == '-' or marker == '+') {
        h.splittable_into += 1;
    };
}

// ---------------- parse ----------------

fn parseDiff(s: *State, ps: []const []const u8) bool {
    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, s.mode.diff_cmd) catch util.oom();
    if (s.context != -1) args.append(gpa, util.fmt("--unified={d}", .{s.context})) catch util.oom();
    if (s.interhunkcontext != -1) args.append(gpa, util.fmt("--inter-hunk-context={d}", .{s.interhunkcontext})) catch util.oom();
    if (repo_mod.cfg.get("diff.algorithm")) |a| args.append(gpa, util.fmt("--diff-algorithm={s}", .{a})) catch util.oom();
    if (s.revision) |rev| {
        if (util.eql(rev, "HEAD") and revparse.getOid("HEAD") == null) {
            args.append(gpa, hash.empty_tree_hex) catch util.oom();
        } else args.append(gpa, rev) catch util.oom();
    }
    args.appendSlice(gpa, &.{ "--no-color", "--ignore-submodules=dirty", "-p", "--" }) catch util.oom();
    args.appendSlice(gpa, ps) catch util.oom();
    const res = runGit(s, args.items, null, true);
    if (res.status != 0) {
        util.err("could not parse diff", .{});
        return false;
    }
    if (res.stdout.len == 0) return true;
    s.plain.appendSlice(gpa, res.stdout) catch util.oom();
    if (s.plain.items[s.plain.items.len - 1] != '\n') util.bufByte(&s.plain, '\n');

    const colored_on = colors.use_diff;
    if (colored_on) {
        for (args.items) |*a| {
            if (util.eql(a.*, "--no-color")) {
                a.* = "--color";
                break;
            }
        }
        const cres = runGit(s, args.items, null, true);
        if (cres.status != 0) {
            util.err("could not parse colored diff", .{});
            return false;
        }
        var cout = cres.stdout;
        if (colors.diff_filter) |filter| {
            const env = [_][2][]const u8{.{ "GIT_INDEX_FILE", s.index_file }};
            const fr = os.run(&.{filter}, .{ .env = &env, .use_shell = true, .stdin_data = cout, .capture_stdout = true });
            cout = fr.stdout;
        }
        s.colored.appendSlice(gpa, cout) catch util.oom();
        if (s.colored.items.len > 0 and s.colored.items[s.colored.items.len - 1] != '\n') util.bufByte(&s.colored, '\n');
    }
    const cb = s.colored.items;
    var cp: usize = 0;

    const b = s.plain.items;
    var p: usize = 0;
    var marker: u8 = 0;
    var fd: ?*FileDiff = null;
    // hunk is identified as either the head (-1) or index into fd.hunks
    var hunk_idx: isize = -1;
    while (p < b.len) {
        const eol = std.mem.indexOfScalarPos(u8, b, p, '\n') orelse b.len;
        const line = b[p..eol];
        const ch = normalizeMarker(b, p);
        var deleted = false;
        var mode_change = false;
        const cur_hunk: ?*Hunk = if (fd) |f| (if (hunk_idx < 0) &f.head else &f.hunks.items[@intCast(hunk_idx)]) else null;
        if (std.mem.startsWith(u8, line, "diff ") or std.mem.startsWith(u8, line, "* Unmerged path ")) {
            completeFile(marker, cur_hunk);
            s.files.append(gpa, .{}) catch util.oom();
            fd = &s.files.items[s.files.items.len - 1];
            hunk_idx = -1;
            fd.?.head.start = p;
            fd.?.head.colored_start = cp;
            marker = 0;
        } else if (fd == null) {
            util.die("BUG: diff starts with unexpected line:\n{s}\n", .{line});
        } else if (fd.?.deleted) {
            // keep the rest of the file in a single "hunk"
        } else if (std.mem.startsWith(u8, line, "@@ ") or (hunk_idx < 0 and std.mem.startsWith(u8, line, "deleted file"))) {
            deleted = std.mem.startsWith(u8, line, "deleted file") and hunk_idx < 0 and !std.mem.startsWith(u8, line, "@@ ");
            if (marker == '-' or marker == '+') cur_hunk.?.splittable_into += 1;
            fd.?.hunks.append(gpa, .{}) catch util.oom();
            hunk_idx = @intCast(fd.?.hunks.items.len - 1);
            const h = &fd.?.hunks.items[@intCast(hunk_idx)];
            h.start = p;
            h.colored_start = cp;
            if (deleted) {
                fd.?.deleted = true;
            } else if (!parseHunkHeader(s, h)) return false;
            marker = ch;
        } else if (hunk_idx < 0 and std.mem.startsWith(u8, line, "new file")) {
            fd.?.added = true;
        } else if (hunk_idx < 0 and std.mem.startsWith(u8, line, "old mode ") and isOctal(line[9..])) {
            mode_change = true;
            fd.?.mode_change = true;
            fd.?.hunks.append(gpa, .{}) catch util.oom();
            fd.?.hunks.items[0].start = p;
            fd.?.hunks.items[0].colored_start = cp;
        } else if (hunk_idx < 0 and std.mem.startsWith(u8, line, "new mode ") and isOctal(line[9..])) {
            mode_change = true;
        } else if (hunk_idx < 0 and std.mem.startsWith(u8, line, "Binary files ")) {
            fd.?.binary = true;
        }

        const hk: *Hunk = if (hunk_idx < 0) &fd.?.head else &fd.?.hunks.items[@intCast(hunk_idx)];
        if ((marker == '-' or marker == '+') and ch == ' ') hk.splittable_into += 1;
        if (marker != 0 and ch != '\\') marker = ch;

        p = if (eol == b.len) b.len else eol + 1;
        hk.end = p;
        if (colored_on) {
            if (std.mem.indexOfScalarPos(u8, cb, cp, '\n')) |ce| {
                cp = ce + 1;
            } else if (p != b.len or cp == cb.len) {
                return mismatchedOutput();
            } else cp = cb.len;
            hk.colored_end = cp;
        }
        if (mode_change and fd.?.mode_change and fd.?.hunks.items.len >= 1) {
            fd.?.hunks.items[0].end = hk.end;
            fd.?.hunks.items[0].colored_end = hk.colored_end;
        }
    }
    if (colored_on and cp != cb.len) return mismatchedOutput();
    if (fd) |f| completeFile(marker, if (hunk_idx < 0) &f.head else &f.hunks.items[@intCast(hunk_idx)]);
    return true;
}

fn mismatchedOutput() bool {
    util.err("mismatched output from interactive.diffFilter", .{});
    advice.advise("Your filter must maintain a one-to-one correspondence\nbetween its input and output lines.");
    return false;
}

// ---------------- render ----------------

fn renderHunk(s: *State, hunk: *const Hunk, delta: i64, out: *util.Buf) void {
    renderHunkC(s, hunk, delta, false, out);
}

fn renderHunkC(s: *State, hunk: *const Hunk, delta: i64, colored: bool, out: *util.Buf) void {
    const h = &hunk.header;
    if (h.old_offset != 0 or h.new_offset != 0) {
        var old_offset = h.old_offset;
        var new_offset = h.new_offset;
        var extra: []const u8 = undefined;
        if (!colored) {
            extra = s.plain.items[h.extra_start..h.extra_end];
        } else if (h.suppress_colored_line_range) {
            util.bufAppend(out, s.colored.items[h.colored_extra_start..h.colored_extra_end]);
            util.bufAppend(out, s.colored.items[hunk.colored_start..hunk.colored_end]);
            return;
        } else {
            util.bufAppend(out, colors.fraginfo);
            extra = s.colored.items[h.colored_extra_start..h.colored_extra_end];
        }
        if (s.mode.is_reverse) old_offset -= delta else new_offset += delta;
        util.bufPrint(out, "@@ -{d}", .{old_offset});
        if (h.old_count != 1) util.bufPrint(out, ",{d}", .{h.old_count});
        util.bufPrint(out, " +{d}", .{new_offset});
        if (h.new_count != 1) util.bufPrint(out, ",{d}", .{h.new_count});
        util.bufAppend(out, " @@");
        if (extra.len > 0) {
            util.bufAppend(out, extra);
        } else if (colored) {
            util.bufAppend(out, colors.reset_d);
            util.bufByte(out, '\n');
        } else util.bufByte(out, '\n');
    }
    if (colored) {
        util.bufAppend(out, s.colored.items[hunk.colored_start..hunk.colored_end]);
    } else util.bufAppend(out, s.plain.items[hunk.start..hunk.end]);
}

fn renderDiffHeader(s: *State, fd: *FileDiff, out: *util.Buf) void {
    renderDiffHeaderC(s, fd, false, out);
}

fn renderDiffHeaderC(s: *State, fd: *FileDiff, colored: bool, out: *util.Buf) void {
    const skip_mode_change = fd.mode_change and fd.hunks.items[0].use != .use;
    if (!skip_mode_change) {
        renderHunkC(s, &fd.head, 0, colored, out);
        return;
    }
    const first = &fd.hunks.items[0];
    if (colored) {
        const p = s.colored.items;
        util.bufAppend(out, p[fd.head.colored_start..first.colored_start]);
        util.bufAppend(out, p[first.colored_end..fd.head.colored_end]);
        return;
    }
    const p = s.plain.items;
    util.bufAppend(out, p[fd.head.start..first.start]);
    util.bufAppend(out, p[first.end..fd.head.end]);
}

fn mergeHunks(s: *State, fd: *FileDiff, hunk_index: *usize, use_all: bool, merged: *Hunk) bool {
    var i = hunk_index.*;
    const first = &fd.hunks.items[i];
    if (!use_all and first.use != .use) return false;
    merged.* = first.*;
    const header = &merged.header;
    while (i + 1 < fd.hunks.items.len) : (i += 1) {
        const hunk = &fd.hunks.items[i + 1];
        const next = &hunk.header;
        if ((!use_all and hunk.use != .use) or
            header.new_offset >= next.new_offset + merged.delta or
            header.new_offset + header.new_count < next.new_offset + merged.delta)
            break;
        var delta: i64 = 0;
        if (merged.start < hunk.start and merged.end > hunk.start) {
            merged.end = hunk.end;
            delta = 0;
        } else {
            const overlapping: i64 = header.new_offset + header.new_count - merged.delta - next.new_offset;
            var overlap_end = hunk.start;
            var overlap_start = overlap_end;
            var j: i64 = 0;
            while (j < overlapping) : (j += 1) {
                const overlap_next = findNextLine(s.plain.items, overlap_end);
                if (overlap_next > hunk.end) util.die("BUG: failed to find {d} context lines", .{overlapping});
                if (normalizeMarker(s.plain.items, overlap_end) != ' ') {
                    util.err("expected context line #{d} in\n{s}", .{ j + 1, s.plain.items[hunk.start..hunk.end] });
                    return false;
                }
                overlap_start = overlap_end;
                overlap_end = overlap_next;
            }
            const len = overlap_end - overlap_start;
            if (len > merged.end - merged.start or
                !std.mem.eql(u8, s.plain.items[merged.end - len .. merged.end], s.plain.items[overlap_start..overlap_end]))
            {
                util.err("hunks do not overlap:\n{s}\n\tdoes not end with:\n{s}", .{ s.plain.items[merged.start..merged.end], s.plain.items[overlap_start..overlap_end] });
                return false;
            }
            if (merged.end != s.plain.items.len) {
                const start = s.plain.items.len;
                const piece = util.dupe(s.plain.items[merged.start..merged.end]);
                util.bufAppend(&s.plain, piece);
                merged.start = start;
                merged.end = s.plain.items.len;
            }
            const piece2 = util.dupe(s.plain.items[overlap_end..hunk.end]);
            util.bufAppend(&s.plain, piece2);
            merged.end = s.plain.items.len;
            merged.splittable_into += hunk.splittable_into;
            delta = merged.delta;
            merged.delta += hunk.delta;
        }
        header.old_count = next.old_offset + next.old_count - header.old_offset;
        header.new_count = next.new_offset + delta + next.new_count - header.new_offset;
    }
    if (i == hunk_index.*) return false;
    hunk_index.* = i;
    return true;
}

fn reassemblePatch(s: *State, fd: *FileDiff, use_all: bool, out: *util.Buf) void {
    const save_len = s.plain.items.len;
    var delta: i64 = 0;
    renderDiffHeader(s, fd, out);
    var i: usize = @intFromBool(fd.mode_change);
    while (i < fd.hunks.items.len) : (i += 1) {
        const hunk = &fd.hunks.items[i];
        if (!use_all and hunk.use != .use) {
            delta += hunk.header.old_count - hunk.header.new_count;
        } else {
            var merged = Hunk{};
            const use: *const Hunk = if (mergeHunks(s, fd, &i, use_all, &merged)) &merged else hunk;
            renderHunk(s, use, delta, out);
            s.plain.items.len = save_len;
            delta += use.delta;
        }
    }
}

fn splitHunk(s: *State, fd: *FileDiff, hunk_index: usize) bool {
    var splittable_into = fd.hunks.items[hunk_index].splittable_into;
    if (splittable_into < 2) return false;
    const end = fd.hunks.items[hunk_index].end;
    const colored = s.colored.items.len > 0;
    const colored_end = fd.hunks.items[hunk_index].colored_end;
    var colored_current: usize = 0;
    var remaining = fd.hunks.items[hunk_index].header;

    // insert splittable_into - 1 new hunks after hunk_index
    var k: usize = 0;
    while (k < splittable_into - 1) : (k += 1) {
        fd.hunks.insert(gpa, hunk_index + 1, .{}) catch util.oom();
    }
    var hi = hunk_index;
    var hunk = &fd.hunks.items[hi];
    hunk.splittable_into = 1;
    hunk.use = .undecided;
    var header = &hunk.header;
    header.old_count = 0;
    header.new_count = 0;

    var current = hunk.start;
    if (colored) colored_current = hunk.colored_start;
    var marker: u8 = 0;
    var context_line_count: i64 = 0;
    var first = true;
    const b = s.plain.items;
    while (splittable_into > 1) {
        var ch = normalizeMarker(b, current);
        if (ch == 0) util.die("BUG: buffer overrun while splitting hunks", .{});
        if ((marker == '-' or marker == '+') and ch == ' ') {
            first = false;
            fd.hunks.items[hi + 1].start = current;
            if (colored) fd.hunks.items[hi + 1].colored_start = colored_current;
            context_line_count = 0;
        }
        var new_hunk = false;
        if (marker != ' ' or (ch != '-' and ch != '+')) {
            // fallthrough to next_hunk_line
        } else if (first) {
            header.old_count = context_line_count;
            header.new_count = context_line_count;
            context_line_count = 0;
            first = false;
        } else {
            new_hunk = true;
        }
        if (!new_hunk) {
            if (ch == '\\') ch = if (marker != 0) marker else ' ';
            if (ch == ' ') {
                context_line_count += 1;
            } else if (ch == '-') {
                header.old_count += 1;
            } else if (ch == '+') {
                header.new_count += 1;
            } else util.die("BUG: unhandled diff marker: '{c}'", .{ch});
            marker = ch;
            current = findNextLine(b, current);
            if (colored) colored_current = findNextLine(s.colored.items, colored_current);
            continue;
        }
        remaining.old_offset += header.old_count;
        remaining.old_count -= header.old_count;
        remaining.new_offset += header.new_count;
        remaining.new_count -= header.new_count;

        fd.hunks.items[hi + 1].header.old_offset = header.old_offset + header.old_count;
        fd.hunks.items[hi + 1].header.new_offset = header.new_offset + header.new_count;

        header.old_count += context_line_count;
        header.new_count += context_line_count;
        hunk.end = current;
        if (colored) hunk.colored_end = colored_current;

        hi += 1;
        hunk = &fd.hunks.items[hi];
        hunk.splittable_into = 1;
        hunk.use = .undecided;
        header = &hunk.header;
        header.old_count = context_line_count;
        header.new_count = context_line_count;
        context_line_count = 0;
        splittable_into -= 1;
        marker = ch;
    }
    header.old_count = remaining.old_count;
    header.new_count = remaining.new_count;
    hunk.end = end;
    if (colored) hunk.colored_end = colored_end;
    return true;
}

// ---------------- edit ----------------

fn commentedAdd(out: *util.Buf, comment: []const u8, text: []const u8) void {
    var it = std.mem.splitScalar(u8, text, '\n');
    var lines: std.ArrayList([]const u8) = .empty;
    while (it.next()) |l| lines.append(gpa, l) catch util.oom();
    if (lines.items.len > 0 and lines.items[lines.items.len - 1].len == 0) lines.items.len -= 1;
    for (lines.items) |l| {
        util.bufAppend(out, comment);
        if (l.len > 0) {
            util.bufByte(out, ' ');
            util.bufAppend(out, l);
        }
        util.bufByte(out, '\n');
    }
}

fn recolorHunk(s: *State, hunk: *Hunk) void {
    if (s.colored.items.len == 0) return;
    const plain = s.plain.items;
    hunk.colored_start = s.colored.items.len;
    var current = hunk.start;
    while (current < hunk.end) {
        var eol = current;
        while (eol < hunk.end and plain[eol] != '\n') eol += 1;
        const next = eol + @intFromBool(eol < hunk.end);
        if (eol > current and plain[eol - 1] == '\r') eol -= 1;
        util.bufAppend(&s.colored, if (plain[current] == '-') colors.old else if (plain[current] == '+') colors.new else colors.context);
        util.bufAppend(&s.colored, plain[current..eol]);
        util.bufAppend(&s.colored, colors.reset_d);
        if (next > eol) util.bufAppend(&s.colored, plain[eol..next]);
        current = next;
    }
    hunk.colored_end = s.colored.items.len;
}

fn editHunkManually(s: *State, hunk: *Hunk) i32 {
    const comment = pretty_trailer.commentLineStr();
    var b: util.Buf = .empty;
    commentedAdd(&b, comment, "Manual hunk edit mode -- see bottom for a quick guide.\n");
    renderHunk(s, hunk, 0, &b);
    commentedAdd(&b, comment, util.fmt("---\nTo remove '{c}' lines, make them ' ' lines (context).\nTo remove '{c}' lines, delete them.\nLines starting with {s} will be removed.\n", .{
        @as(u8, if (s.mode.is_reverse) '+' else '-'),
        @as(u8, if (s.mode.is_reverse) '-' else '+'),
        comment,
    }));
    commentedAdd(&b, comment, s.mode.edit_hunk_hint);
    commentedAdd(&b, comment, "If it does not apply cleanly, you will be given an opportunity to\nedit again.  If all lines of the hunk are removed, then the edit is\naborted and the hunk is left unchanged.\n");
    const path = util.joinPath(repo_mod.repo().git_dir, "addp-hunk-edit.diff");
    os.writeFile(path, b.items, 0o666) catch {
        util.err("could not write '{s}'", .{path});
        return -1;
    };
    if (editor.launch(path, &.{})) return -1;
    const data = os.readFile(path) orelse return -1;
    hunk.start = s.plain.items.len;
    var i: usize = 0;
    while (i < data.len) {
        const next = findNextLine(data, i);
        if (!std.mem.startsWith(u8, data[i..], comment)) util.bufAppend(&s.plain, data[i..next]);
        i = next;
    }
    if (s.plain.items.len > 0 and s.plain.items[s.plain.items.len - 1] != '\n' and s.plain.items.len > hunk.start) util.bufByte(&s.plain, '\n');
    hunk.end = s.plain.items.len;
    if (hunk.end == hunk.start) return 0;
    recolorHunk(s, hunk);
    if (s.plain.items[hunk.start] == '@' and !parseHunkHeader(s, hunk)) {
        util.err("could not parse hunk header", .{});
        return -1;
    }
    return 1;
}

fn recountEditedHunk(s: *State, hunk: *Hunk, orig_old: i64, orig_new: i64) i64 {
    const h = &hunk.header;
    hunk.splittable_into = 0;
    h.old_count = 0;
    h.new_count = 0;
    var marker: u8 = ' ';
    var i = hunk.start;
    while (i < hunk.end) {
        const ch = normalizeMarker(s.plain.items, i);
        switch (ch) {
            '-' => {
                h.old_count += 1;
                if (marker == ' ') hunk.splittable_into += 1;
                marker = ch;
            },
            '+' => {
                h.new_count += 1;
                if (marker == ' ') hunk.splittable_into += 1;
                marker = ch;
            },
            ' ' => {
                h.old_count += 1;
                h.new_count += 1;
                marker = ch;
            },
            else => {},
        }
        i = findNextLine(s.plain.items, i);
    }
    return orig_old - orig_new - h.old_count + h.new_count;
}

fn runApplyCheck(s: *State, fd: *FileDiff) bool {
    var b: util.Buf = .empty;
    reassemblePatch(s, fd, true, &b);
    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, &.{ "apply", "--check" }) catch util.oom();
    args.appendSlice(gpa, s.mode.apply_check_args) catch util.oom();
    if (runGit(s, args.items, b.items, false).status != 0) {
        util.err("'git apply --cached' failed", .{});
        return false;
    }
    return true;
}

fn promptYesNo(s: *State, prompt: []const u8) i32 {
    while (true) {
        colorOut(colors.prompt, prompt);
        if (!readLine(&s.answer)) return -1;
        if (s.answer.items.len == 0) continue;
        switch (std.ascii.toLower(s.answer.items[0])) {
            'n' => return 0,
            'y' => return 1,
            else => {},
        }
    }
}

fn editHunkLoop(s: *State, fd: *FileDiff, hi: usize) i32 {
    const plain_len = s.plain.items.len;
    const colored_len = s.colored.items.len;
    const backup = fd.hunks.items[hi];
    while (true) {
        const hunk = &fd.hunks.items[hi];
        const res = editHunkManually(s, hunk);
        if (res == 0) {
            fd.hunks.items[hi] = backup;
            return -1;
        }
        if (res > 0) {
            hunk.delta += recountEditedHunk(s, hunk, backup.header.old_count, backup.header.new_count);
            if (runApplyCheck(s, fd)) return 0;
        }
        s.plain.items.len = plain_len;
        s.colored.items.len = colored_len;
        fd.hunks.items[hi] = backup;
        const r = promptYesNo(s, "Your edited hunk does not apply. Edit again (saying \"no\" discards!) [y/n]? ");
        if (r < 1) return -1;
    }
}

fn applyForCheckout(s: *State, diff: []const u8, is_reverse: bool) void {
    var a1: std.ArrayList([]const u8) = .empty;
    a1.appendSlice(gpa, &.{ "apply", "--cached", "--check" }) catch util.oom();
    if (is_reverse) a1.append(gpa, "-R") catch util.oom();
    const applies_index = runGit(s, a1.items, diff, false).status == 0;
    var a2: std.ArrayList([]const u8) = .empty;
    a2.appendSlice(gpa, &.{ "apply", "--check" }) catch util.oom();
    if (is_reverse) a2.append(gpa, "-R") catch util.oom();
    const applies_worktree = runGit(s, a2.items, diff, false).status == 0;
    var a3: std.ArrayList([]const u8) = .empty;
    a3.appendSlice(gpa, &.{ "apply", "--cached" }) catch util.oom();
    if (is_reverse) a3.append(gpa, "-R") catch util.oom();
    var a4: std.ArrayList([]const u8) = .empty;
    a4.append(gpa, "apply") catch util.oom();
    if (is_reverse) a4.append(gpa, "-R") catch util.oom();
    if (applies_worktree and applies_index) {
        _ = runGit(s, a3.items, diff, false);
        _ = runGit(s, a4.items, diff, false);
        return;
    }
    if (!applies_index) {
        errOut("The selected hunks do not apply to the index!", .{});
        if (promptYesNo(s, "Apply them to the worktree anyway? ") > 0) {
            _ = runGit(s, a4.items, diff, false);
            return;
        }
        errOut("Nothing was applied.\n", .{});
    } else {
        util.out(diff);
    }
}

fn applyPatch(s: *State, fd: *FileDiff) void {
    var any = false;
    for (fd.hunks.items) |h| if (h.use == .use) {
        any = true;
    };
    if (!any and !(fd.hunks.items.len == 0 and fd.head.use == .use)) return;
    var b: util.Buf = .empty;
    reassemblePatch(s, fd, false, &b);
    if (s.mode.apply_for_checkout) {
        applyForCheckout(s, b.items, s.mode.is_reverse);
    } else {
        var args: std.ArrayList([]const u8) = .empty;
        args.append(gpa, "apply") catch util.oom();
        args.appendSlice(gpa, s.mode.apply_args) catch util.oom();
        if (runGit(s, args.items, b.items, false).status != 0) util.err("'git apply' failed", .{});
    }
    _ = runGit(s, &.{ "update-index", "-q", "--refresh" }, null, false);
}

fn summarizeHunk(s: *State, hunk: *const Hunk, out: *util.Buf) void {
    const h = &hunk.header;
    const len = out.items.len;
    util.bufPrint(out, " -{d},{d} +{d},{d} ", .{ h.old_offset, h.old_count, h.new_offset, h.new_count });
    while (out.items.len - len < 20) util.bufByte(out, ' ');
    const p = s.plain.items;
    var i = hunk.start;
    while (i < hunk.end) : (i = findNextLine(p, i)) {
        if (p[i] != ' ') break;
    }
    if (i < hunk.end) util.bufAppend(out, p[i..findNextLine(p, i)]);
    if (out.items.len - len > 80) out.items.len = len + 80;
    if (out.items.len > 0 and out.items[out.items.len - 1] != '\n') util.bufByte(out, '\n');
}

fn displayHunks(s: *State, fd: *FileDiff, start_index0: usize) usize {
    var start_index = start_index0;
    var end_index = start_index + 20;
    if (end_index > fd.hunks.items.len) end_index = fd.hunks.items.len;
    while (start_index < end_index) {
        const hunk = &fd.hunks.items[start_index];
        start_index += 1;
        var b: util.Buf = .empty;
        const c: u8 = switch (hunk.use) {
            .use => '+',
            .skip => '-',
            .undecided => ' ',
        };
        util.bufPrint(&b, "{c}{d:>2}: ", .{ c, start_index });
        summarizeHunk(s, hunk, &b);
        util.out(b.items);
    }
    return end_index;
}

fn decMod(a: usize, m: usize) usize {
    return if (a > 0) a - 1 else m - 1;
}

fn incMod(a: usize, m: usize) usize {
    return if (a < m - 1) a + 1 else 0;
}

fn firstUndecided(fd: *const FileDiff) ?usize {
    for (fd.hunks.items, 0..) |h, i| if (h.use == .undecided) return i;
    return null;
}

const ALLOW_PREV_HUNK: u32 = 1 << 0;
const ALLOW_PREV_UNDECIDED: u32 = 1 << 1;
const ALLOW_NEXT_HUNK: u32 = 1 << 2;
const ALLOW_NEXT_UNDECIDED: u32 = 1 << 3;
const ALLOW_SEARCH: u32 = 1 << 4;
const ALLOW_SPLIT: u32 = 1 << 5;
const ALLOW_EDIT: u32 = 1 << 6;
const ALLOW_PREV_FILE: u32 = 1 << 7;
const ALLOW_NEXT_FILE: u32 = 1 << 8;

fn patchUpdateFile(s: *State, idx: usize, flags: u32) usize {
    var hunk_index: usize = 0;
    var rendered_hunk_index: isize = -1;
    var all_decided = false;
    const fd = &s.files.items[idx];
    var resp = idx;

    if (fd.hunks.items.len == 0 and !fd.added) return resp + 1;

    {
        var b: util.Buf = .empty;
        renderDiffHeaderC(s, fd, s.colored.items.len > 0, &b);
        util.out(b.items);
    }
    while (true) {
        var permitted: u32 = 0;
        const nr = fd.hunks.items.len;
        if (hunk_index >= nr) hunk_index = 0;
        const hunk: *Hunk = if (nr > 0) &fd.hunks.items[hunk_index] else &fd.head;
        var undecided_previous: isize = -1;
        var undecided_next: isize = -1;
        if (nr > 0) {
            var i = decMod(hunk_index, nr);
            while (i != hunk_index) : (i = decMod(i, nr)) {
                if (fd.hunks.items[i].use == .undecided) {
                    undecided_previous = @intCast(i);
                    break;
                }
            }
            i = incMod(hunk_index, nr);
            while (i != hunk_index) : (i = incMod(i, nr)) {
                if (fd.hunks.items[i].use == .undecided) {
                    undecided_next = @intCast(i);
                    break;
                }
            }
        }
        if (undecided_previous < 0 and undecided_next < 0 and hunk.use != .undecided) {
            if (!s.opts.auto_advance) {
                all_decided = true;
            } else {
                resp += 1;
                break;
            }
        }
        var extra: util.Buf = .empty;
        if (nr > 0) {
            if (rendered_hunk_index != @as(isize, @intCast(hunk_index))) {
                var b: util.Buf = .empty;
                renderHunkC(s, hunk, 0, s.colored.items.len > 0, &b);
                util.out(b.items);
                rendered_hunk_index = @intCast(hunk_index);
            }
            if (undecided_previous >= 0) {
                permitted |= ALLOW_PREV_UNDECIDED;
                util.bufAppend(&extra, ",k");
            }
            if (nr > 1) {
                permitted |= ALLOW_PREV_HUNK;
                util.bufAppend(&extra, ",K");
            }
            if (undecided_next >= 0) {
                permitted |= ALLOW_NEXT_UNDECIDED;
                util.bufAppend(&extra, ",j");
            }
            if (nr > 1) {
                permitted |= ALLOW_NEXT_HUNK;
                util.bufAppend(&extra, ",J");
            }
            if (nr > 1) {
                permitted |= ALLOW_SEARCH;
                util.bufAppend(&extra, ",g,/");
            }
            if (hunk.splittable_into > 1) {
                permitted |= ALLOW_SPLIT;
                util.bufAppend(&extra, ",s");
            }
            if (flags & DISALLOW_EDIT == 0 and hunk_index + 1 > @intFromBool(fd.mode_change) and !fd.deleted) {
                permitted |= ALLOW_EDIT;
                util.bufAppend(&extra, ",e");
            }
            if (!s.opts.auto_advance and s.files.items.len > 1) {
                permitted |= ALLOW_NEXT_FILE;
                util.bufAppend(&extra, ",>");
            }
            if (!s.opts.auto_advance and s.files.items.len > 1) {
                permitted |= ALLOW_PREV_FILE;
                util.bufAppend(&extra, ",<");
            }
            util.bufAppend(&extra, ",p,P");
        }
        const pm: usize = if (fd.deleted) 1 else if (fd.added) 2 else if (fd.mode_change and hunk_index == 0) 0 else 3;
        util.outf("{s}({d}/{d}) ", .{ colors.prompt, hunk_index + 1, if (nr > 0) nr else 1 });
        const decision: []const u8 = switch (hunk.use) {
            .undecided => "",
            .use => " (was: y)",
            .skip => " (was: n)",
        };
        util.out(subst(s.mode.prompt_mode[pm], &.{ decision, extra.items }));
        util.out(colors.reset_i);
        if (!readLine(&s.answer)) {
            resp = s.files.items.len;
            break;
        }
        const ans = s.answer.items;
        if (ans.len == 0) continue;
        const ch = std.ascii.toLower(ans[0]);
        if (ans.len != 1 and ch != 'g' and ch != '/') {
            errOut("Only one letter is expected, got '{s}'", .{ans});
            continue;
        }
        if (ch == 'y' or ch == 'n') {
            hunk.use = if (ch == 'y') .use else .skip;
            hunk_index = if (undecided_next < 0) nr else @intCast(undecided_next);
        } else if (ch == 'a' or ch == 'd') {
            const v: Use = if (ch == 'a') .use else .skip;
            if (nr > 0) {
                while (hunk_index < nr) : (hunk_index += 1) {
                    if (fd.hunks.items[hunk_index].use == .undecided) fd.hunks.items[hunk_index].use = v;
                }
                hunk_index = firstUndecided(fd) orelse 0;
            } else if (hunk.use == .undecided) {
                hunk.use = v;
            }
        } else if (ch == 'q') {
            resp = s.files.items.len;
            break;
        } else if (!s.opts.auto_advance and ans[0] == '>') {
            if (permitted & ALLOW_NEXT_FILE != 0) {
                resp = if (resp == s.files.items.len - 1) 0 else resp + 1;
                break;
            }
            errOut("No next file", .{});
            continue;
        } else if (!s.opts.auto_advance and ans[0] == '<') {
            if (permitted & ALLOW_PREV_FILE != 0) {
                resp = if (resp == 0) s.files.items.len - 1 else resp - 1;
                break;
            }
            errOut("No previous file", .{});
            continue;
        } else if (ans[0] == 'K') {
            if (permitted & ALLOW_PREV_HUNK != 0) hunk_index = decMod(hunk_index, nr) else errOut("No other hunk", .{});
        } else if (ans[0] == 'J') {
            if (permitted & ALLOW_NEXT_HUNK != 0) hunk_index += 1 else errOut("No other hunk", .{});
        } else if (ans[0] == 'k') {
            if (permitted & ALLOW_PREV_UNDECIDED != 0) hunk_index = @intCast(undecided_previous) else errOut("No other undecided hunk", .{});
        } else if (ans[0] == 'j') {
            if (permitted & ALLOW_NEXT_UNDECIDED != 0) hunk_index = @intCast(undecided_next) else errOut("No other undecided hunk", .{});
        } else if (ans[0] == 'g') {
            if (permitted & ALLOW_SEARCH == 0) {
                errOut("No other hunks to goto", .{});
                continue;
            }
            var a = util.dupe(std.mem.trim(u8, ans[1..], " \t\n\r"));
            var i: usize = if (hunk_index >= 10) hunk_index - 10 else 0;
            if (i < @intFromBool(fd.mode_change)) i = @intFromBool(fd.mode_change);
            while (a.len == 0) {
                i = displayHunks(s, fd, i);
                util.out(if (i < nr) "go to which hunk (<ret> to see more)? " else "go to which hunk? ");
                if (!readLine(&s.answer)) break;
                a = util.dupe(s.answer.items);
            }
            a = util.dupe(std.mem.trim(u8, a, " \t\n\r"));
            const response = std.fmt.parseInt(usize, a, 10) catch {
                errOut("Invalid number: '{s}'", .{a});
                continue;
            };
            if (response > 0 and response <= nr) {
                hunk_index = response - 1;
            } else if (nr == 1) {
                errOut("Sorry, only {d} hunk available.", .{nr});
            } else errOut("Sorry, only {d} hunks available.", .{nr});
        } else if (ans[0] == '/') {
            if (permitted & ALLOW_SEARCH == 0) {
                errOut("No other hunks to search", .{});
                continue;
            }
            var pat = util.dupe(ans[1..]);
            if (pat.len == 0) {
                util.out("search for regex? ");
                if (!readLine(&s.answer)) break;
                pat = util.dupe(s.answer.items);
                if (pat.len == 0) continue;
            }
            const re = switch (regex.Regex.compile(pat, .{ .extended = true, .newline = true })) {
                .ok => |r| r,
                .err => |e| {
                    errOut("Malformed search regexp {s}: {s}", .{ pat, e });
                    continue;
                },
            };
            var i = hunk_index;
            var b: util.Buf = .empty;
            util.bufAppend(&b, extra.items);
            while (true) {
                renderHunk(s, &fd.hunks.items[i], 0, &b);
                if (re.isMatch(b.items)) break;
                i += 1;
                if (i == nr) i = 0;
                if (i != hunk_index) continue;
                errOut("No hunk matches the given pattern", .{});
                break;
            }
            hunk_index = i;
        } else if (ans[0] == 's') {
            const n = hunk.splittable_into;
            if (permitted & ALLOW_SPLIT == 0) {
                errOut("Sorry, cannot split this hunk", .{});
            } else if (splitHunk(s, fd, hunk_index)) {
                colorOutLn(colors.header, util.fmt("Split into {d} hunks.", .{n}));
                rendered_hunk_index = -1;
            }
        } else if (ans[0] == 'e') {
            if (permitted & ALLOW_EDIT == 0) {
                errOut("Sorry, cannot edit this hunk", .{});
            } else if (editHunkLoop(s, fd, hunk_index) >= 0) {
                fd.hunks.items[hunk_index].use = .use;
                hunk_index = if (undecided_next < 0) nr else @intCast(undecided_next);
            }
        } else if (ch == 'p') {
            rendered_hunk_index = -1;
        } else if (ans[0] == '?') {
            colorOut(colors.help, s.mode.help_patch_text);
            var it = std.mem.splitScalar(u8, help_patch_remainder, '\n');
            while (it.next()) |line| {
                if (line.len == 0) continue;
                if (all_decided and std.mem.startsWith(u8, line, "HUNKS SUMMARY")) {
                    var used: usize = 0;
                    var skipped: usize = 0;
                    for (fd.hunks.items) |h| {
                        if (h.use == .use) used += 1;
                        if (h.use == .skip) skipped += 1;
                    }
                    colorOutLn(colors.help, util.fmt("HUNKS SUMMARY - Hunks: {d}, USE: {d}, SKIP: {d}", .{ nr, used, skipped }));
                }
                if (line[0] != '?' and std.mem.indexOfScalar(u8, extra.items, line[0]) == null) continue;
                colorOutLn(colors.help, line);
            }
        } else {
            errOut("Unknown command '{s}' (use '?' for help)", .{ans});
        }
    }
    if (s.opts.auto_advance) applyPatch(s, &s.files.items[idx]);
    util.out("\n");
    return resp;
}

/// run_add_p(). `index_file` is the index the diff/apply children operate on.
pub fn run(mode: Mode, opts: Options, revision: ?[]const u8, index_file: []const u8, ps: []const []const u8, flags: u32) i32 {
    const pm: *const PatchMode = switch (mode) {
        .add => &mode_add,
        .stash => &mode_stash,
        .reset => if (revision == null or util.eql(revision.?, "HEAD")) &mode_reset_head else &mode_reset_nothead,
        .checkout => if (revision == null) &mode_checkout_index else if (util.eql(revision.?, "HEAD")) &mode_checkout_head else &mode_checkout_nothead,
        .worktree => if (revision == null) &mode_checkout_index else if (util.eql(revision.?, "HEAD")) &mode_worktree_head else &mode_worktree_nothead,
    };
    initColors();
    var s = State{ .mode = pm, .revision = revision, .index_file = index_file, .opts = opts };
    const cfg = &repo_mod.cfg;
    if (cfg.getInt("diff.context")) |c| {
        if (c < 0) util.die("{s} cannot be negative", .{"diff.context"});
        s.context = @intCast(c);
    }
    if (cfg.getInt("diff.interhunkcontext")) |c| {
        if (c < 0) util.die("{s} cannot be negative", .{"diff.interHunkContext"});
        s.interhunkcontext = @intCast(c);
    }
    if (opts.context != -1) {
        if (opts.context < 0) util.die("{s} cannot be negative", .{"--unified"});
        s.context = opts.context;
    }
    if (opts.interhunkcontext != -1) {
        if (opts.interhunkcontext < 0) util.die("{s} cannot be negative", .{"--inter-hunk-context"});
        s.interhunkcontext = opts.interhunkcontext;
    }
    if (!pm.index_only) _ = runGit(&s, &.{ "update-index", "-q", "--refresh" }, null, false);

    if (!parseDiff(&s, ps)) return -1;
    var binary_count: usize = 0;
    var i: usize = 0;
    while (i < s.files.items.len) {
        if (s.files.items[i].binary and s.files.items[i].hunks.items.len == 0) {
            binary_count += 1;
            i += 1;
            continue;
        }
        i = patchUpdateFile(&s, i, flags);
        if (i == s.files.items.len) break;
    }
    if (!s.opts.auto_advance) {
        for (s.files.items) |*fd| applyPatch(&s, fd);
    }
    if (s.files.items.len == 0) {
        errOut("No changes.", .{});
    } else if (binary_count == s.files.items.len) {
        errOut("Only binary files changed.", .{});
    }
    return 0;
}

/// Convenience wrapper: run against the repository's index with a parsed
/// pathspec (whose originals carry :(prefix:N) magic when parsed with
/// prefix_origin).
pub fn runPathspec(mode: Mode, opts: Options, revision: ?[]const u8, ps: *const @import("pathspec.zig").Pathspec, flags: u32) i32 {
    var args: std.ArrayList([]const u8) = .empty;
    for (ps.items) |it| args.append(gpa, it.original) catch util.oom();
    const r = repo_mod.repo();
    if (r.work_tree) |wt| {
        const cwd = os.getcwd();
        if (!util.eql(cwd, wt)) _ = repo_mod.chdirNotify(wt);
    }
    return run(mode, opts, revision, r.indexPath(), args.items, flags);
}
