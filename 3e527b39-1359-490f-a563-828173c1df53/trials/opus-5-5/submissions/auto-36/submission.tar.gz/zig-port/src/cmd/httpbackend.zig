//! git http-backend (port of http-backend.c): a CGI program serving git
//! repositories over HTTP (both the "dumb" and the "smart" protocols).

const std = @import("std");
const c = std.c;
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const pkt = @import("../pktline.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const refs = @import("../refs.zig");
const objects = @import("../objects.zig");
const hash = @import("../hash.zig");
const date = @import("../date.zig");
const zlib = @import("../zlib.zig");
const up = @import("uploadpack.zig");
const gpa = util.gpa;

const content_type = "Content-Type";
const content_length = "Content-Length";
const last_modified = "Last-Modified";

var getanyfile = true;
var max_request_buffer: u64 = 10 * 1024 * 1024;

const RpcService = struct {
    name: []const u8,
    config_name: []const u8,
    buffer_input: bool,
    enabled: i8,
};

var rpc_service = [_]RpcService{
    .{ .name = "upload-pack", .config_name = "uploadpack", .buffer_input = true, .enabled = 1 },
    .{ .name = "receive-pack", .config_name = "receivepack", .buffer_input = false, .enabled = -1 },
    .{ .name = "upload-archive", .config_name = "uploadarchive", .buffer_input = false, .enabled = -1 },
};

// ---------------------------------------------------------------- output

fn writeOrDie(fd: c_int, data: []const u8) void {
    os.writeAll(fd, data) catch {
        if (os.errno() == 32) os.exit(141);
        util.die("write error", .{});
    };
}

const Hdr = util.Buf;

fn httpStatus(hdr: *Hdr, code: u32, msg: []const u8) void {
    util.bufPrint(hdr, "Status: {d} {s}\r\n", .{ code, msg });
}

fn hdrStr(hdr: *Hdr, name: []const u8, value: []const u8) void {
    util.bufPrint(hdr, "{s}: {s}\r\n", .{ name, value });
}

fn hdrInt(hdr: *Hdr, name: []const u8, value: u64) void {
    util.bufPrint(hdr, "{s}: {d}\r\n", .{ name, value });
}

fn hdrDate(hdr: *Hdr, name: []const u8, when: i64) void {
    hdrStr(hdr, name, date.showDate(when, 0, date.DateMode.of(.rfc2822)));
}

fn hdrNocache(hdr: *Hdr) void {
    hdrStr(hdr, "Expires", "Fri, 01 Jan 1980 00:00:00 GMT");
    hdrStr(hdr, "Pragma", "no-cache");
    hdrStr(hdr, "Cache-Control", "no-cache, max-age=0, must-revalidate");
}

fn hdrCacheForever(hdr: *Hdr) void {
    const now = os.now();
    hdrDate(hdr, "Date", now);
    hdrDate(hdr, "Expires", now + 31536000);
    hdrStr(hdr, "Cache-Control", "public, max-age=31536000");
}

fn endHeaders(hdr: *Hdr) void {
    util.bufAppend(hdr, "\r\n");
    writeOrDie(1, hdr.items);
    hdr.* = .empty;
}

fn notFound(hdr: *Hdr, comptime f: []const u8, args: anytype) noreturn {
    httpStatus(hdr, 404, "Not Found");
    hdrNocache(hdr);
    endHeaders(hdr);
    util.eprint(f ++ "\n", args);
    os.exit(0);
}

fn forbidden(hdr: *Hdr, comptime f: []const u8, args: anytype) noreturn {
    httpStatus(hdr, 403, "Forbidden");
    hdrNocache(hdr);
    endHeaders(hdr);
    util.eprint(f ++ "\n", args);
    os.exit(0);
}

fn selectGetanyfile(hdr: *Hdr) void {
    if (!getanyfile) forbidden(hdr, "Unsupported service: getanyfile", .{});
}

fn sendBuf(hdr: *Hdr, typ: []const u8, buf: []const u8) void {
    hdrInt(hdr, content_length, buf.len);
    hdrStr(hdr, content_type, typ);
    endHeaders(hdr);
    writeOrDie(1, buf);
}

fn sendLocalFile(hdr: *Hdr, the_type: []const u8, name: []const u8) void {
    const p = repo_mod.repo().gitPath(name);
    const fd = os.openFile(p, os.O_RDONLY, 0);
    if (fd < 0) notFound(hdr, "Cannot open '{s}': {s}", .{ p, os.lastErr() });
    const st = os.fstatFd(fd) orelse util.dieErrno("Cannot stat '{s}'", .{p});
    hdrInt(hdr, content_length, @intCast(st.size));
    hdrStr(hdr, content_type, the_type);
    hdrDate(hdr, last_modified, st.mtime);
    endHeaders(hdr);
    var buf: [8192]u8 = undefined;
    while (true) {
        const n = c.read(fd, &buf, buf.len);
        if (n < 0) {
            if (os.errno() == 4 or os.errno() == 11) continue;
            util.dieErrno("Cannot read '{s}'", .{p});
        }
        if (n == 0) break;
        writeOrDie(1, buf[0..@intCast(n)]);
    }
    os.close(fd);
}

fn getTextFile(hdr: *Hdr, name: []const u8) void {
    selectGetanyfile(hdr);
    hdrNocache(hdr);
    sendLocalFile(hdr, "text/plain", name);
}

fn getLooseObject(hdr: *Hdr, name: []const u8) void {
    selectGetanyfile(hdr);
    hdrCacheForever(hdr);
    sendLocalFile(hdr, "application/x-git-loose-object", name);
}

fn getPackFile(hdr: *Hdr, name: []const u8) void {
    selectGetanyfile(hdr);
    hdrCacheForever(hdr);
    sendLocalFile(hdr, "application/x-git-packed-objects", name);
}

fn getIdxFile(hdr: *Hdr, name: []const u8) void {
    selectGetanyfile(hdr);
    hdrCacheForever(hdr);
    sendLocalFile(hdr, "application/x-git-packed-objects-toc", name);
}

// ---------------------------------------------------------------- config

fn httpConfig() void {
    const cfg = &repo_mod.cfg;
    if (cfg.getBool("http.getanyfile")) |b| getanyfile = b;
    if (cfg.getInt("http.maxrequestbuffer")) |n| {
        if (n >= 0) max_request_buffer = @intCast(n);
    }
    for (&rpc_service) |*svc| {
        const key = util.concat(&.{ "http.", svc.config_name });
        if (cfg.getBool(key)) |b| svc.enabled = if (b) 1 else 0;
    }
}

fn selectService(hdr: *Hdr, name: []const u8) *RpcService {
    const svc_name = util.skipPrefix(name, "git-") orelse
        forbidden(hdr, "Unsupported service: '{s}'", .{name});
    var svc: ?*RpcService = null;
    for (&rpc_service) |*s| {
        if (util.eql(s.name, svc_name)) {
            svc = s;
            break;
        }
    }
    const s = svc orelse forbidden(hdr, "Unsupported service: '{s}'", .{name});
    if (s.enabled < 0) {
        const user = os.getenv("REMOTE_USER");
        s.enabled = if (user != null and user.?.len > 0) 1 else 0;
    }
    if (s.enabled == 0) forbidden(hdr, "Service not enabled: '{s}'", .{s.name});
    return s;
}

// ---------------------------------------------------------------- request body

fn writeToChild(out: c_int, buf: []const u8, prog_name: []const u8) void {
    os.writeAll(out, buf) catch util.die("unable to write to '{s}'", .{prog_name});
}

/// read() retrying on EINTR/EAGAIN; returns -1 on error.
fn xread(fd: c_int, buf: []u8) isize {
    while (true) {
        const n = c.read(fd, buf.ptr, buf.len);
        if (n < 0 and (os.errno() == 4 or os.errno() == 11)) continue;
        return n;
    }
}

/// read_in_full(): returns bytes read (less than buf.len only at EOF) or -1.
fn readInFull(fd: c_int, buf: []u8) isize {
    var total: usize = 0;
    while (total < buf.len) {
        const n = xread(fd, buf[total..]);
        if (n < 0) return -1;
        if (n == 0) break;
        total += @intCast(n);
    }
    return @intCast(total);
}

fn readRequestEof(fd: c_int) ?[]u8 {
    var len: usize = 0;
    var alloc: usize = 8192;
    var buf = gpa.alloc(u8, alloc) catch util.oom();
    if (max_request_buffer < alloc) max_request_buffer = alloc;
    while (true) {
        const cnt = readInFull(fd, buf[len..alloc]);
        if (cnt < 0) return null;
        len += @intCast(cnt);
        if (len < alloc) return buf[0..len];
        if (alloc == max_request_buffer)
            util.die("request was larger than our maximum size ({d}); try setting GIT_HTTP_MAX_REQUEST_BUFFER", .{max_request_buffer});
        alloc = (alloc + 16) * 3 / 2;
        if (alloc > max_request_buffer) alloc = @intCast(max_request_buffer);
        buf = gpa.realloc(buf, alloc) catch util.oom();
    }
}

fn readRequestFixedLen(fd: c_int, req_len: i64) ?[]u8 {
    if (max_request_buffer < @as(u64, @intCast(req_len)))
        util.die("request was larger than our maximum size ({d}): {d}; try setting GIT_HTTP_MAX_REQUEST_BUFFER", .{ max_request_buffer, req_len });
    const buf = gpa.alloc(u8, @intCast(req_len)) catch util.oom();
    const cnt = readInFull(fd, buf);
    if (cnt < 0) return null;
    return buf[0..@intCast(cnt)];
}

fn readRequest(fd: c_int, req_len: i64) ?[]u8 {
    if (req_len < 0) return readRequestEof(fd);
    return readRequestFixedLen(fd, req_len);
}

fn getContentLength() i64 {
    const str = os.getenv("CONTENT_LENGTH") orelse return -1;
    if (str.len == 0) return -1;
    return switch (config.parseSigned(str, std.math.maxInt(i64))) {
        .ok => |n| n,
        .err => util.die("failed to parse CONTENT_LENGTH: {s}", .{str}),
    };
}

extern "c" fn inflateInit2_(strm: *zlib.ZStream, window_bits: c_int, version: [*:0]const u8, size: c_int) c_int;

fn inflateRequest(prog_name: []const u8, out: c_int, buffer_input: bool, req_len: i64) void {
    var stream = zlib.ZStream{};
    // gzip only: windowBits 15 + 16
    if (inflateInit2_(&stream, 15 + 16, zlib.zlibVersion(), @sizeOf(zlib.ZStream)) != zlib.Z_OK)
        util.die("unable to initialize zlib", .{});
    var full_request: ?[]u8 = null;
    var in_buf: [8192]u8 = undefined;
    var out_buf: [8192]u8 = undefined;
    var cnt: u64 = 0;
    const req_len_defined = req_len >= 0;
    var req_remaining_len: u64 = if (req_len_defined) @intCast(req_len) else 0;

    outer: while (true) {
        var n: isize = 0;
        if (buffer_input) {
            if (full_request != null) {
                n = 0;
            } else {
                if (readRequest(0, req_len)) |b| {
                    full_request = b;
                    n = @intCast(b.len);
                } else n = -1;
            }
            if (full_request) |b| stream.next_in = b.ptr;
        } else {
            var buffer_len: usize = in_buf.len;
            if (req_len_defined and req_remaining_len <= in_buf.len) buffer_len = @intCast(req_remaining_len);
            n = xread(0, in_buf[0..buffer_len]);
            stream.next_in = &in_buf;
            if (req_len_defined and n > 0) req_remaining_len -= @intCast(n);
        }
        if (n <= 0) util.die("request ended in the middle of the gzip stream", .{});
        stream.avail_in = @intCast(n);

        while (stream.avail_in > 0) {
            stream.next_out = &out_buf;
            stream.avail_out = out_buf.len;
            const ret = zlib.inflate(&stream, zlib.Z_NO_FLUSH);
            if (ret != zlib.Z_OK and ret != zlib.Z_STREAM_END)
                util.die("zlib error inflating request, result {d}", .{ret});
            const produced: usize = @intCast(stream.total_out - cnt);
            writeToChild(out, out_buf[0..produced], prog_name);
            cnt = stream.total_out;
            if (ret == zlib.Z_STREAM_END) break :outer;
        }
    }
    _ = zlib.inflateEnd(&stream);
    os.close(out);
}

fn copyRequest(prog_name: []const u8, out: c_int, req_len: i64) void {
    const buf = readRequest(0, req_len) orelse util.dieErrno("error reading request body", .{});
    writeToChild(out, buf, prog_name);
    os.close(out);
}

fn pipeFixedLength(prog_name: []const u8, out: c_int, req_len: u64) void {
    var buf: [8192]u8 = undefined;
    var remaining = req_len;
    while (remaining > 0) {
        const chunk: usize = @intCast(@min(remaining, buf.len));
        const n = xread(0, buf[0..chunk]);
        if (n < 0) util.dieErrno("Reading request failed", .{});
        // C loops forever on EOF here as well (n == 0); bail out instead.
        if (n == 0) break;
        writeToChild(out, buf[0..@intCast(n)], prog_name);
        remaining -= @intCast(n);
    }
    os.close(out);
}

fn runService(argv: []const []const u8, buffer_input: bool) void {
    const encoding = os.getenv("HTTP_CONTENT_ENCODING");
    var user = os.getenv("REMOTE_USER") orelse "";
    var host = os.getenv("REMOTE_ADDR") orelse "";
    const req_len = getContentLength();
    var gzipped_request = false;
    if (encoding) |e| {
        if (util.eql(e, "gzip") or util.eql(e, "x-gzip")) gzipped_request = true;
    }
    if (user.len == 0) user = "anonymous";
    if (host.len == 0) host = "(none)";

    var env: std.ArrayList([2][]const u8) = .empty;
    if (os.getenv("GIT_COMMITTER_NAME") == null)
        env.append(gpa, .{ "GIT_COMMITTER_NAME", user }) catch util.oom();
    if (os.getenv("GIT_COMMITTER_EMAIL") == null)
        env.append(gpa, .{ "GIT_COMMITTER_EMAIL", util.concat(&.{ user, "@http.", host }) }) catch util.oom();

    const pipe_in = buffer_input or gzipped_request or req_len >= 0;
    var ch = proc.spawnGit(argv, .{ .pipe_in = pipe_in, .env = env.items });

    os.close(1);
    if (gzipped_request) {
        inflateRequest(argv[0], ch.in, buffer_input, req_len);
    } else if (buffer_input) {
        copyRequest(argv[0], ch.in, req_len);
    } else if (req_len >= 0) {
        pipeFixedLength(argv[0], ch.in, @intCast(req_len));
    } else {
        os.close(0);
    }
    ch.in = -1;
    if (proc.wait(ch.pid) != 0) os.exit(1);
}

// ---------------------------------------------------------------- namespaces

fn namespacePrefix() []const u8 {
    const ns = os.getenv("GIT_NAMESPACE") orelse return "";
    var b: util.Buf = .empty;
    var it = std.mem.splitScalar(u8, ns, '/');
    while (it.next()) |comp| {
        if (comp.len == 0) continue;
        util.bufAppend(&b, "refs/namespaces/");
        util.bufAppend(&b, comp);
        util.bufAppend(&b, "/");
    }
    return b.items;
}

fn stripNamespace(ns: []const u8, name: []const u8) []const u8 {
    return util.skipPrefix(name, ns) orelse "(null)";
}

// ---------------------------------------------------------------- handlers

fn getInfoRefs(hdr: *Hdr, arg: []const u8) void {
    _ = arg;
    const service_name = getParameter("service");
    hdrNocache(hdr);
    if (service_name) |sn| {
        const svc = selectService(hdr, sn);
        hdrStr(hdr, content_type, util.fmt("application/x-git-{s}-advertisement", .{svc.name}));
        endHeaders(hdr);
        if (up.protocolVersionServer() != 2) {
            pkt.writeFmt(1, "# service=git-{s}\n", .{svc.name});
            pkt.flush(1);
        }
        runService(&.{ svc.name, "--http-backend-info-refs", "." }, false);
    } else {
        const ns = namespacePrefix();
        var buf: util.Buf = .empty;
        selectGetanyfile(hdr);
        const odb = repo_mod.repo().odb();
        for (refs.list(util.concat(&.{ ns, "refs/" }))) |r| {
            const obj = odb.read(r.oid) orelse continue;
            const name_nons = stripNamespace(ns, r.name);
            util.bufPrint(&buf, "{s}\t{s}\n", .{ hash.hex(r.oid), name_nons });
            if (obj.typ == .tag) {
                const p = objects.peel(r.oid) orelse continue;
                util.bufPrint(&buf, "{s}\t{s}^{{}}\n", .{ hash.hex(p.oid), name_nons });
            }
        }
        sendBuf(hdr, "text/plain", buf.items);
    }
}

fn getHead(hdr: *Hdr, arg: []const u8) void {
    _ = arg;
    const ns = namespacePrefix();
    var buf: util.Buf = .empty;
    selectGetanyfile(hdr);
    const head = util.concat(&.{ ns, "HEAD" });
    if (refs.readRaw(head)) |raw| {
        switch (raw) {
            .symref => {
                if (refs.resolve(head)) |res| {
                    util.bufPrint(&buf, "ref: {s}\n", .{stripNamespace(ns, res.name)});
                }
            },
            .oid => |o| util.bufPrint(&buf, "{s}\n", .{hash.hex(o)}),
        }
    }
    sendBuf(hdr, "text/plain", buf.items);
}

const PackEnt = struct { name: []const u8, mtime: i64, mtime_ns: i64 };

fn getInfoPacks(hdr: *Hdr, arg: []const u8) void {
    _ = arg;
    selectGetanyfile(hdr);
    const objdir = repo_mod.repo().odb().objects_dir;
    const pdir = util.concat(&.{ objdir, "/pack" });
    var packs: std.ArrayList(PackEnt) = .empty;
    if (os.listDir(pdir)) |ents| {
        for (ents) |e| {
            if (!util.endsWith(e.name, ".idx")) continue;
            const base = e.name[0 .. e.name.len - 4];
            const pack_name = util.concat(&.{ base, ".pack" });
            const st = os.statPath(util.concat(&.{ pdir, "/", pack_name })) orelse continue;
            packs.append(gpa, .{ .name = pack_name, .mtime = st.mtime, .mtime_ns = st.mtime_ns }) catch util.oom();
        }
    }
    std.mem.sort(PackEnt, packs.items, {}, struct {
        fn lt(_: void, a: PackEnt, b: PackEnt) bool {
            if (a.mtime != b.mtime) return a.mtime > b.mtime;
            if (a.mtime_ns != b.mtime_ns) return a.mtime_ns > b.mtime_ns;
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    var buf: util.Buf = .empty;
    for (packs.items) |p| util.bufPrint(&buf, "P {s}\n", .{p.name});
    util.bufByte(&buf, '\n');
    hdrNocache(hdr);
    sendBuf(hdr, "text/plain; charset=utf-8", buf.items);
}

fn checkContentType(hdr: *Hdr, accepted_type: []const u8) void {
    const actual_type = os.getenv("CONTENT_TYPE") orelse "";
    if (!util.eql(actual_type, accepted_type)) {
        httpStatus(hdr, 415, "Unsupported Media Type");
        hdrNocache(hdr);
        endHeaders(hdr);
        writeOrDie(1, util.fmt("Expected POST with Content-Type '{s}', but received '{s}' instead.\n", .{ accepted_type, actual_type }));
        os.exit(0);
    }
}

fn serviceRpc(hdr: *Hdr, service_name: []const u8) void {
    const svc = selectService(hdr, service_name);
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, svc.name) catch util.oom();
    if (!util.eql(service_name, "git-upload-archive")) argv.append(gpa, "--stateless-rpc") catch util.oom();
    argv.append(gpa, ".") catch util.oom();

    checkContentType(hdr, util.fmt("application/x-git-{s}-request", .{svc.name}));
    hdrNocache(hdr);
    hdrStr(hdr, content_type, util.fmt("application/x-git-{s}-result", .{svc.name}));
    endHeaders(hdr);
    runService(argv.items, svc.buffer_input);
}

// ---------------------------------------------------------------- query string

const Param = struct { name: []const u8, value: []const u8 };
var query_params: ?[]Param = null;

fn hexVal(ch: u8) ?u8 {
    return switch (ch) {
        '0'...'9' => ch - '0',
        'a'...'f' => ch - 'a' + 10,
        'A'...'F' => ch - 'A' + 10,
        else => null,
    };
}

/// url_decode_internal(): decode up to (and consume) `stop_at`.
fn urlDecodePart(q: *[]const u8, stop_at: []const u8) []const u8 {
    var out: util.Buf = .empty;
    var s = q.*;
    while (s.len > 0) {
        const ch = s[0];
        if (std.mem.indexOfScalar(u8, stop_at, ch) != null) {
            s = s[1..];
            break;
        }
        if (ch == '%' and s.len >= 3) {
            if (hexVal(s[1])) |h| if (hexVal(s[2])) |l| {
                util.bufByte(&out, h * 16 + l);
                s = s[3..];
                continue;
            };
        }
        util.bufByte(&out, if (ch == '+') ' ' else ch);
        s = s[1..];
    }
    q.* = s;
    return out.items;
}

fn getParameter(name: []const u8) ?[]const u8 {
    if (query_params == null) {
        var l: std.ArrayList(Param) = .empty;
        var q: []const u8 = os.getenv("QUERY_STRING") orelse "";
        while (q.len > 0) {
            const n = urlDecodePart(&q, "&=");
            const v = urlDecodePart(&q, "&");
            var found = false;
            for (l.items) |*p| {
                if (util.eql(p.name, n)) {
                    p.value = v;
                    found = true;
                }
            }
            if (!found) l.append(gpa, .{ .name = n, .value = v }) catch util.oom();
        }
        query_params = l.items;
    }
    for (query_params.?) |p| {
        if (util.eql(p.name, name)) return p.value;
    }
    return null;
}

// ---------------------------------------------------------------- main

var dead: u32 = 0;

fn dieWebcgi(msg: []const u8) void {
    _ = msg;
    if (dead == 0) {
        dead += 1;
        var hdr: Hdr = .empty;
        httpStatus(&hdr, 500, "Internal Server Error");
        hdrNocache(&hdr);
        util.bufAppend(&hdr, "\r\n");
        os.writeAll(1, hdr.items) catch {};
    }
    os.exit(0);
}

/// daemon_avoid_alias(): reject paths with //, /./, /../, /. or /.. components.
fn daemonAvoidAlias(path: []const u8) bool {
    if (path.len == 0 or (path[0] != '/' and path[0] != '~')) return true;
    var sl = true;
    var ndot: u32 = 0;
    var i: usize = 1;
    while (true) : (i += 1) {
        const ch: u8 = if (i < path.len) path[i] else 0;
        if (sl) {
            if (ch == '.') {
                ndot += 1;
            } else if (ch == '/') {
                if (ndot < 3) return true;
                ndot = 0;
            } else if (ch == 0) {
                if (0 < ndot and ndot < 3) return true;
                return false;
            } else {
                sl = false;
                ndot = 0;
            }
        } else if (ch == 0) {
            return false;
        } else if (ch == '/') {
            sl = true;
            ndot = 0;
        }
    }
}

fn getdir() []u8 {
    const pathinfo_env = os.getenv("PATH_INFO");
    const root = os.getenv("GIT_PROJECT_ROOT");
    const path = os.getenv("PATH_TRANSLATED");
    if (root != null and root.?.len > 0) {
        var pathinfo = pathinfo_env orelse "";
        if (pathinfo.len == 0) util.die("GIT_PROJECT_ROOT is set but PATH_INFO is not", .{});
        if (daemonAvoidAlias(pathinfo)) util.die("'{s}': aliased", .{pathinfo});
        var b: util.Buf = .empty;
        util.bufAppend(&b, root.?);
        if (b.items.len == 0 or b.items[b.items.len - 1] != '/') util.bufByte(&b, '/');
        if (pathinfo[0] == '/') pathinfo = pathinfo[1..];
        util.bufAppend(&b, pathinfo);
        return b.items;
    } else if (path != null and path.?.len > 0) {
        return util.dupe(path.?);
    }
    util.die("No GIT_PROJECT_ROOT or PATH_TRANSLATED from server", .{});
}

const Handler = *const fn (hdr: *Hdr, arg: []const u8) void;

/// A pattern element: literal text or a run of `n` lowercase hex digits.
const Pat = union(enum) { lit: []const u8, hex: usize };

const ServiceCmd = struct {
    method: []const u8,
    pattern: []const Pat,
    imp: Handler,
};

const services = [_]ServiceCmd{
    .{ .method = "GET", .pattern = &.{.{ .lit = "/HEAD" }}, .imp = getHead },
    .{ .method = "GET", .pattern = &.{.{ .lit = "/info/refs" }}, .imp = getInfoRefs },
    .{ .method = "GET", .pattern = &.{.{ .lit = "/objects/info/alternates" }}, .imp = getTextFile },
    .{ .method = "GET", .pattern = &.{.{ .lit = "/objects/info/http-alternates" }}, .imp = getTextFile },
    .{ .method = "GET", .pattern = &.{.{ .lit = "/objects/info/packs" }}, .imp = getInfoPacks },
    .{ .method = "GET", .pattern = &.{ .{ .lit = "/objects/" }, .{ .hex = 2 }, .{ .lit = "/" }, .{ .hex = 38 } }, .imp = getLooseObject },
    .{ .method = "GET", .pattern = &.{ .{ .lit = "/objects/" }, .{ .hex = 2 }, .{ .lit = "/" }, .{ .hex = 62 } }, .imp = getLooseObject },
    .{ .method = "GET", .pattern = &.{ .{ .lit = "/objects/pack/pack-" }, .{ .hex = 40 }, .{ .lit = ".pack" } }, .imp = getPackFile },
    .{ .method = "GET", .pattern = &.{ .{ .lit = "/objects/pack/pack-" }, .{ .hex = 64 }, .{ .lit = ".pack" } }, .imp = getPackFile },
    .{ .method = "GET", .pattern = &.{ .{ .lit = "/objects/pack/pack-" }, .{ .hex = 40 }, .{ .lit = ".idx" } }, .imp = getIdxFile },
    .{ .method = "GET", .pattern = &.{ .{ .lit = "/objects/pack/pack-" }, .{ .hex = 64 }, .{ .lit = ".idx" } }, .imp = getIdxFile },
    .{ .method = "POST", .pattern = &.{.{ .lit = "/git-upload-pack" }}, .imp = serviceRpc },
    .{ .method = "POST", .pattern = &.{.{ .lit = "/git-upload-archive" }}, .imp = serviceRpc },
    .{ .method = "POST", .pattern = &.{.{ .lit = "/git-receive-pack" }}, .imp = serviceRpc },
};

/// All patterns are fixed length and anchored at the end ("...$"), so the
/// only possible match is a suffix. Returns the match start.
fn matchSuffix(dir: []const u8, pattern: []const Pat) ?usize {
    var total: usize = 0;
    for (pattern) |p| total += switch (p) {
        .lit => |l| l.len,
        .hex => |n| n,
    };
    if (dir.len < total) return null;
    const start = dir.len - total;
    var i = start;
    for (pattern) |p| switch (p) {
        .lit => |l| {
            if (!util.eql(dir[i .. i + l.len], l)) return null;
            i += l.len;
        },
        .hex => |n| {
            for (dir[i .. i + n]) |ch| {
                if (!((ch >= '0' and ch <= '9') or (ch >= 'a' and ch <= 'f'))) return null;
            }
            i += n;
        },
    };
    return start;
}

fn badRequest(hdr: *Hdr, cmd: *const ServiceCmd) u8 {
    const proto = os.getenv("SERVER_PROTOCOL");
    if (proto != null and util.eql(proto.?, "HTTP/1.1")) {
        httpStatus(hdr, 405, "Method Not Allowed");
        hdrStr(hdr, "Allow", if (util.eql(cmd.method, "GET")) "GET, HEAD" else cmd.method);
    } else httpStatus(hdr, 400, "Bad Request");
    hdrNocache(hdr);
    endHeaders(hdr);
    return 0;
}

fn envUlong(name: []const u8, def: u64) u64 {
    const v = os.getenv(name) orelse return def;
    return switch (config.parseSigned(v, std.math.maxInt(i64))) {
        .ok => |n| if (n < 0) util.die("failed to parse {s}", .{name}) else @intCast(n),
        .err => util.die("failed to parse {s}", .{name}),
    };
}

pub fn cmdHttpBackend(args: []const []const u8) u8 {
    _ = args;
    var hdr: Hdr = .empty;
    util.die_hook = dieWebcgi;

    var method = os.getenv("REQUEST_METHOD") orelse util.die("No REQUEST_METHOD from server", .{});
    if (util.eql(method, "HEAD")) method = "GET";
    var dir = getdir();

    var cmd: ?*const ServiceCmd = null;
    var cmd_arg: []const u8 = "";
    for (&services) |*sc| {
        if (matchSuffix(dir, sc.pattern)) |start| {
            if (!util.eql(method, sc.method)) return badRequest(&hdr, sc);
            cmd = sc;
            cmd_arg = util.dupe(dir[start + 1 ..]);
            dir = dir[0..start];
            break;
        }
    }
    const command = cmd orelse notFound(&hdr, "Request not supported: '{s}'", .{dir});

    if (!up.enterRepo(dir, false)) notFound(&hdr, "Not a git repository: '{s}'", .{dir});
    util.die_hook = dieWebcgi;
    if (os.getenv("GIT_HTTP_EXPORT_ALL") == null and !os.access("git-daemon-export-ok", 0))
        notFound(&hdr, "Repository not exported: '{s}'", .{dir});

    httpConfig();
    max_request_buffer = envUlong("GIT_HTTP_MAX_REQUEST_BUFFER", max_request_buffer);
    if (os.getenv("HTTP_GIT_PROTOCOL")) |ph| {
        if (os.getenv("GIT_PROTOCOL") == null) os.setEnv("GIT_PROTOCOL", ph);
    }
    command.imp(&hdr, cmd_arg);
    return 0;
}
