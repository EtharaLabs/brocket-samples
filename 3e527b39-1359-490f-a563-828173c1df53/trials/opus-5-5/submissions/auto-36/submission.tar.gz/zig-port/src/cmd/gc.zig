//! git gc (builtin/gc.c, odb/source-files.c optimize)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const proc = @import("../proc.zig");
const date = @import("../date.zig");
const hook = @import("../hook.zig");
const gpa = util.gpa;

const usage = [_][]const u8{"git gc [<options>]"};

const sentinel: []const u8 = "sentinel";

var quiet = false;
var prune_arg: ?[]const u8 = sentinel;
var cruft_packs = true;
var max_cruft_size: ?[]const u8 = null;
var aggressive = false;
var auto_flag = false;
var detach: i32 = -1;
var force = false;
var keep_largest_pack: i32 = -1;
var expire_to: ?[]const u8 = null;
var skip_foreground = false;

fn detachCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    detach = if (unset) 0 else 1;
}
fn keepLargestCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    keep_largest_pack = if (unset) 0 else 1;
}
fn quietCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    quiet = !unset;
}

const options = [_]po.Opt{
    .{ .short = 'q', .long = "quiet", .kind = .callback, .cb = quietCb, .noarg = true, .help = "suppress progress reporting" },
    .{ .long = "prune", .kind = .string, .s = &prune_arg, .optarg = true, .def = sentinel, .argh = "date", .help = "prune unreferenced objects" },
    po.boolean(0, "cruft", &cruft_packs, "pack unreferenced objects separately"),
    po.noNeg(po.string(0, "max-cruft-size", &max_cruft_size, "n", "with --cruft, limit the size of new cruft packs")),
    po.boolean(0, "aggressive", &aggressive, "be more thorough (increased runtime)"),
    po.noComplete(po.boolean(0, "auto", &auto_flag, "enable auto-gc mode")),
    .{ .long = "detach", .kind = .callback, .cb = detachCb, .noarg = true, .help = "perform garbage collection in the background" },
    po.noComplete(po.boolean(0, "force", &force, "force running gc even if there may be another gc running")),
    .{ .long = "keep-largest-pack", .kind = .callback, .cb = keepLargestCb, .noarg = true, .help = "repack all other packs except the largest pack" },
    po.string(0, "expire-to", &expire_to, "dir", "pack prefix to store a pack containing pruned objects"),
    .{ .long = "skip-foreground-tasks", .kind = .boolean, .b = &skip_foreground, .hidden = true, .help = "skip maintenance tasks typically done in the foreground" },
};

fn runGit(args: []const []const u8) bool {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    const r = os.run(argv.items, .{ .no_stdin = true });
    return r.status == 0 and !r.signaled;
}

fn isNever(key: []const u8) bool {
    const v = repo_mod.cfg.get(key) orelse return false;
    const t = date.parseExpiryDate(v) orelse util.die("failed to parse '{s}' value '{s}'", .{ key, v });
    return t == 0;
}

fn tooManyLoose(limit: i64) bool {
    if (limit <= 0) return false;
    const odb = repo_mod.repo().odb();
    const ents = os.listDir(util.concat(&.{ odb.objects_dir, "/17" })) orelse return false;
    var n: u64 = 0;
    for (ents) |e| {
        if (e.name.len != 38) continue;
        var ok = true;
        for (e.name) |ch| {
            if (!((ch >= '0' and ch <= '9') or (ch >= 'a' and ch <= 'f'))) ok = false;
        }
        if (ok) n += 1;
    }
    const lim: u64 = @intCast(limit);
    return n * 256 > ((lim + 255) / 256) * 256;
}

const PackSz = struct { path: []const u8, size: u64, keep: bool, cruft: bool };

fn localPacks() []PackSz {
    const odb = repo_mod.repo().odb();
    odb.reloadPacks();
    var out: std.ArrayList(PackSz) = .empty;
    for (odb.packs.items) |p| {
        const base = p.pack_path[0 .. p.pack_path.len - 5];
        const st = os.statPath(p.pack_path);
        out.append(gpa, .{
            .path = p.pack_path,
            .size = if (st) |s| @intCast(s.size) else 0,
            .keep = os.exists(util.concat(&.{ base, ".keep" })),
            .cruft = os.exists(util.concat(&.{ base, ".mtimes" })),
        }) catch util.oom();
    }
    return out.items;
}

fn tooManyPacks(limit: i64) bool {
    if (limit <= 0) return false;
    var cnt: i64 = 0;
    for (localPacks()) |p| {
        if (!p.keep) cnt += 1;
    }
    return limit < cnt;
}

/// find_base_packs(): with limit, all non-cruft packs at least that large;
/// otherwise the largest non-cruft pack.
fn findBasePacks(keep: *std.ArrayList([]const u8), limit: u64) void {
    var base: ?PackSz = null;
    for (localPacks()) |p| {
        if (p.cruft) continue;
        if (limit != 0) {
            if (p.size >= limit) keep.append(gpa, p.path) catch util.oom();
        } else if (base == null or base.?.size < p.size) base = p;
    }
    if (base) |b| keep.append(gpa, b.path) catch util.oom();
}

fn addRepackAllOption(args: *std.ArrayList([]const u8), prune_expire: ?[]const u8, keep: []const []const u8) void {
    const cfg = &repo_mod.cfg;
    const push = struct {
        fn f(l: *std.ArrayList([]const u8), s: []const u8) void {
            l.append(gpa, s) catch util.oom();
        }
    }.f;
    if (prune_expire != null and util.eql(prune_expire.?, "now") and !(cruft_packs and expire_to != null)) {
        push(args, "-a");
    } else if (cruft_packs) {
        push(args, "--cruft");
        if (prune_expire) |p| push(args, util.concat(&.{ "--cruft-expiration=", p }));
        if (max_cruft_size) |m| {
            if (!util.eql(m, "0")) push(args, util.concat(&.{ "--max-cruft-size=", m }));
        }
        if (expire_to) |e| push(args, util.concat(&.{ "--expire-to=", e }));
    } else {
        push(args, "-A");
        if (prune_expire) |p| push(args, util.concat(&.{ "--unpack-unreachable=", p }));
    }
    for (keep) |k| push(args, util.concat(&.{ "--keep-pack=", util.basename(k) }));
    if (cfg.get("gc.repackfilter")) |f| {
        if (f.len > 0) push(args, util.concat(&.{ "--filter=", f }));
    }
    if (cfg.get("gc.repackfilterto")) |f| {
        if (f.len > 0) push(args, util.concat(&.{ "--filter-to=", f }));
    }
}

extern "c" fn gethostname(name: [*]u8, len: usize) c_int;
extern "c" fn getpid() c_int;
extern "c" fn kill(pid: c_int, sig: c_int) c_int;
extern "c" fn fork() c_int;
extern "c" fn setsid() c_int;
extern "c" fn dup2(old: c_int, new: c_int) c_int;
extern "c" fn time(t: ?*i64) i64;

var pidfile_path: ?[]const u8 = null;

fn hostname() []const u8 {
    var buf: [256]u8 = undefined;
    if (gethostname(&buf, buf.len) != 0) return "unknown";
    const n = std.mem.indexOfScalar(u8, &buf, 0) orelse buf.len;
    return util.dupe(buf[0..n]);
}

/// lock_repo_for_gc(): null on success, else the host holding the lock.
fn lockRepoForGc(pid_out: *u64) ?[]const u8 {
    if (pidfile_path != null) return null;
    const r = repo_mod.repo();
    const path = util.concat(&.{ r.git_dir, "/gc.pid" });
    const my_host = hostname();
    if (!force) {
        if (os.statPath(path)) |st| {
            if (time(null) - st.mtime <= 12 * 3600) {
                if (os.readFile(path)) |data| {
                    var it = std.mem.tokenizeAny(u8, data, " \n");
                    const ps = it.next();
                    const hs = it.next();
                    if (ps != null and hs != null) {
                        if (std.fmt.parseInt(u64, ps.?, 10)) |pid| {
                            const alive = kill(@intCast(pid), 0) == 0 or os.errno() == 1;
                            if (!util.eql(hs.?, my_host) or alive) {
                                pid_out.* = pid;
                                return hs.?;
                            }
                        } else |_| {}
                    }
                }
            }
        }
    }
    const lock = util.concat(&.{ path, ".lock" });
    const fd = os.openFile(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666);
    if (fd < 0) util.dieErrno("Unable to create '{s}'", .{lock});
    os.writeAll(fd, util.fmt("{d} {s}", .{ getpid(), my_host })) catch {};
    os.close(fd);
    _ = os.rename(lock, path);
    pidfile_path = path;
    return null;
}

fn releasePidfile() void {
    if (pidfile_path) |p| _ = os.unlink(p);
    pidfile_path = null;
}

fn reportLastGcError() u8 {
    const r = repo_mod.repo();
    const path = util.concat(&.{ r.git_dir, "/gc.log" });
    const st = os.statPath(path) orelse return 0;
    const expire_s = repo_mod.cfg.get("gc.logexpiry") orelse "1.day.ago";
    const expire = date.parseExpiryDate(expire_s) orelse util.die("failed to parse gc.logExpiry value {s}", .{expire_s});
    if (st.mtime < expire) return 0;
    const data = os.readFile(path) orelse return 0;
    if (data.len == 0) return 0;
    util.warn("The last gc run reported the following. Please correct the root cause\n" ++
        "and remove {s}\n" ++
        "Automatic cleanup will not be performed until the file is removed.\n\n{s}", .{ path, data });
    return 1;
}

fn foregroundTasks(pack_refs: bool, prune_reflogs: bool) bool {
    if (pack_refs) {
        const ok = if (auto_flag) runGit(&.{ "pack-refs", "--all", "--prune", "--auto" }) else runGit(&.{ "pack-refs", "--all", "--prune" });
        if (!ok) {
            util.err("failed to run {s}", .{"pack-refs"});
            return false;
        }
    }
    if (prune_reflogs and !runGit(&.{ "reflog", "expire", "--all" })) {
        util.err("failed to run {s}", .{"reflog"});
        return false;
    }
    return true;
}

pub fn cmdGc(args: []const []const u8) u8 {
    const cfg = &repo_mod.cfg;
    const r = repo_mod.repo();
    var pack_refs: i32 = 1;
    if (cfg.get("gc.packrefs")) |v| {
        pack_refs = if (util.eql(v, "notbare")) -1 else @intFromBool(cfg.getBool("gc.packrefs") orelse true);
    }
    var prune_reflogs = true;
    if (isNever("gc.reflogexpire") and isNever("gc.reflogexpireunreachable")) prune_reflogs = false;
    var aggressive_window: i64 = 250;
    var aggressive_depth: i64 = 50;
    if (cfg.getInt("gc.aggressivewindow")) |v| aggressive_window = v;
    if (cfg.getInt("gc.aggressivedepth")) |v| aggressive_depth = v;
    const detach_auto = cfg.getBool("gc.autodetach") orelse true;
    if (cfg.getBool("gc.cruftpacks")) |b| cruft_packs = b;
    if (cfg.get("gc.maxcruftsize")) |v| max_cruft_size = v;
    var prune_expire: ?[]const u8 = cfg.get("gc.pruneexpire") orelse "2.weeks.ago";
    const prune_worktrees_expire: ?[]const u8 = cfg.get("gc.worktreepruneexpire") orelse "3.months.ago";
    if (cfg.get("gc.logexpiry")) |v| {
        if (date.parseExpiryDate(v) == null) util.die("failed to parse gc.logExpiry value {s}", .{v});
    }
    if (pack_refs < 0) pack_refs = @intFromBool(!r.bare);

    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len > 0) po.usageWithOptions(&usage, &options);

    if (prune_arg == null or prune_arg.?.ptr != sentinel.ptr) prune_expire = prune_arg;
    if (prune_expire) |p| {
        if (date.parseExpiryDate(p) == null) util.die("failed to parse prune expiry value {s}", .{p});
    }

    const gc_auto_threshold = cfg.getInt("gc.auto") orelse 6700;
    const gc_auto_pack_limit = cfg.getInt("gc.autopacklimit") orelse 50;

    if (auto_flag) {
        if (detach_auto and detach < 0) detach = 1;
        if (gc_auto_threshold <= 0) return 0;
        if (!tooManyPacks(gc_auto_pack_limit) and !tooManyLoose(gc_auto_threshold)) return 0;
        if (hook.run("pre-auto-gc", &.{}, .{}) != 0) return 0;
        if (!quiet) {
            if (detach > 0)
                util.ewrite("Auto packing the repository in background for optimum performance.\n")
            else
                util.ewrite("Auto packing the repository for optimum performance.\n");
            util.ewrite("See \"git help gc\" for manual housekeeping.\n");
        }
    }

    var daemonized = false;
    var pid: u64 = 0;
    if (detach > 0) {
        const ret = reportLastGcError();
        if (ret == 1) return 0;
        if (!skip_foreground) {
            if (lockRepoForGc(&pid) != null) return 0;
            if (!foregroundTasks(pack_refs != 0, prune_reflogs)) os.exit(128);
            releasePidfile();
        }
        util.flushStdout();
        const child = fork();
        if (child > 0) os.exit(0);
        if (child == 0) {
            daemonized = true;
            _ = setsid();
            const nul = os.openFile("/dev/null", os.O_RDWR, 0);
            if (nul >= 0) {
                _ = dup2(nul, 0);
                _ = dup2(nul, 1);
            }
        }
    }

    if (lockRepoForGc(&pid)) |name| {
        if (auto_flag) return 0;
        util.die("gc is already running on machine '{s}' pid {d} (use --force if not)", .{ name, pid });
    }
    defer releasePidfile();

    const log_path = util.concat(&.{ r.git_dir, "/gc.log" });
    if (daemonized) {
        const fd = os.openFile(log_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o666);
        if (fd >= 0) _ = dup2(fd, 2);
    }

    if (detach <= 0 and !skip_foreground) _ = foregroundTasks(pack_refs != 0, prune_reflogs);

    if (prune_worktrees_expire) |w| {
        if (!runGit(&.{ "worktree", "prune", "--expire", w })) util.die("failed to run {s}", .{"worktree"});
    }
    if (findCommand("rerere")) {
        if (!runGit(&.{ "rerere", "gc" })) util.die("failed to run {s}", .{"rerere"});
    }

    // maintenance_task_odb
    if (!(cfg.getBool("extensions.preciousobjects") orelse false)) {
        var rargs: std.ArrayList([]const u8) = .empty;
        rargs.appendSlice(gpa, &.{ "repack", "-d", "-l" }) catch util.oom();
        if (aggressive) {
            rargs.append(gpa, "-f") catch util.oom();
            if (aggressive_depth > 0) rargs.append(gpa, util.fmt("--depth={d}", .{aggressive_depth})) catch util.oom();
            if (aggressive_window > 0) rargs.append(gpa, util.fmt("--window={d}", .{aggressive_window})) catch util.oom();
        }
        if (quiet) rargs.append(gpa, "-q") catch util.oom();
        const big: u64 = if (cfg.getInt("gc.bigpackthreshold")) |v| @intCast(@max(v, 0)) else 0;
        var keep: std.ArrayList([]const u8) = .empty;
        if (!auto_flag) {
            if (keep_largest_pack != -1) {
                if (keep_largest_pack != 0) findBasePacks(&keep, 0);
            } else if (big != 0) findBasePacks(&keep, big);
            addRepackAllOption(&rargs, prune_expire, keep.items);
        } else if (tooManyPacks(gc_auto_pack_limit)) {
            if (big != 0) {
                findBasePacks(&keep, big);
                if (keep.items.len >= @as(usize, @intCast(@max(gc_auto_pack_limit, 0)))) {
                    keep.items.len = 0;
                    findBasePacks(&keep, 0);
                }
            }
            addRepackAllOption(&rargs, prune_expire, keep.items);
        } else {
            rargs.append(gpa, "--no-write-bitmap-index") catch util.oom();
        }
        if (!runGit(rargs.items)) {
            util.err("failed to run {s}", .{"repack"});
            os.exit(128);
        }
        if (prune_expire) |p| {
            if (quiet) {
                if (!runGit(&.{ "prune", "--expire", p, "--no-progress" })) {
                    util.err("failed to run {s}", .{"prune"});
                    os.exit(128);
                }
            } else if (!runGit(&.{ "prune", "--expire", p })) {
                util.err("failed to run {s}", .{"prune"});
                os.exit(128);
            }
        }
        if (auto_flag and tooManyLoose(gc_auto_threshold))
            util.warn("There are too many unreachable loose objects; run 'git prune' to remove them.", .{});
    }

    cleanPackGarbage();

    // gc.writeCommitGraph: write_commit_graph_reachable()
    if (cfg.getBool("gc.writecommitgraph") orelse true) {
        const prog = !quiet and !daemonized and os.isatty(2);
        _ = runGit(&.{ "commit-graph", "write", "--reachable", if (prog) "--progress" else "--no-progress" });
    }

    if (!daemonized) {
        _ = os.unlink(log_path);
    } else {
        if (os.statPath(log_path)) |st| {
            if (st.size == 0) _ = os.unlink(log_path);
        }
    }
    return 0;
}

fn findCommand(name: []const u8) bool {
    const commands = @import("../commands.zig");
    return commands.find(name) != null;
}

/// Remove .idx files in objects/pack that have no matching .pack.
fn cleanPackGarbage() void {
    const odb = repo_mod.repo().odb();
    const pdir = util.concat(&.{ odb.objects_dir, "/pack" });
    const ents = os.listDir(pdir) orelse return;
    for (ents) |e| {
        if (!util.endsWith(e.name, ".idx")) continue;
        const base = e.name[0 .. e.name.len - 4];
        if (util.startsWith(e.name, "multi-pack-index")) continue;
        var has_other = false;
        for (ents) |o| {
            if (o.name.len > base.len and util.startsWith(o.name, base) and o.name[base.len] == '.' and !util.eql(o.name, e.name)) has_other = true;
        }
        if (!has_other) {
            const p = util.concat(&.{ pdir, "/", e.name });
            if (!os.unlink(p)) util.warn("unable to unlink '{s}': {s}", .{ p, os.lastErr() });
        }
    }
}
