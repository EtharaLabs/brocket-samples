//! EWAH compressed bitmaps (ewah/ewah_bitmap.c, ewah_io.c), bit-compatible with C git.
//! Only the operations the index extensions need: sequential ewah_set(),
//! serialization, reading and iterating set bits.

const std = @import("std");
const util = @import("util.zig");
const gpa = util.gpa;

const RUNNING_BITS: u6 = 32;
const LITERAL_BITS: u6 = 31;
const LARGEST_RUNNING: u64 = (@as(u64, 1) << RUNNING_BITS) - 1;
const LARGEST_LITERAL: u64 = (@as(u64, 1) << LITERAL_BITS) - 1;
const RUNNING_SHIFT: u64 = LARGEST_RUNNING << 1;
const RUNNING_LEN_PLUS_BIT: u64 = (@as(u64, 1) << (RUNNING_BITS + 1)) - 1;

fn runBit(w: u64) bool {
    return w & 1 != 0;
}
fn setRunBit(w: *u64, b: bool) void {
    if (b) w.* |= 1 else w.* &= ~@as(u64, 1);
}
fn runLen(w: u64) u64 {
    return (w >> 1) & LARGEST_RUNNING;
}
fn setRunLen(w: *u64, l: u64) void {
    w.* |= RUNNING_SHIFT;
    w.* &= (l << 1) | ~RUNNING_SHIFT;
}
fn litWords(w: u64) u64 {
    return w >> (1 + RUNNING_BITS);
}
fn setLitWords(w: *u64, l: u64) void {
    w.* |= ~RUNNING_LEN_PLUS_BIT;
    w.* &= (l << (RUNNING_BITS + 1)) | RUNNING_LEN_PLUS_BIT;
}

pub const Bitmap = struct {
    buffer: std.ArrayList(u64) = .empty,
    bit_size: usize = 0,
    rlw: usize = 0,

    pub fn init() Bitmap {
        var b = Bitmap{};
        b.buffer.append(gpa, 0) catch util.oom();
        return b;
    }

    fn rw(self: *Bitmap) *u64 {
        return &self.buffer.items[self.rlw];
    }

    fn push(self: *Bitmap, v: u64) void {
        self.buffer.append(gpa, v) catch util.oom();
    }
    fn pushRlw(self: *Bitmap, v: u64) void {
        self.push(v);
        self.rlw = self.buffer.items.len - 1;
    }

    fn addEmptyWords(self: *Bitmap, v: bool, number0: u64) void {
        var number = number0;
        const w = self.rw();
        if (runBit(w.*) != v and runLen(w.*) + litWords(w.*) == 0) {
            setRunBit(w, v);
        } else if (litWords(w.*) != 0 or runBit(w.*) != v) {
            self.pushRlw(0);
            if (v) setRunBit(self.rw(), v);
        }
        const rl = runLen(self.rw().*);
        const can_add = @min(number, LARGEST_RUNNING - rl);
        setRunLen(self.rw(), rl + can_add);
        number -= can_add;
        while (number >= LARGEST_RUNNING) {
            self.pushRlw(0);
            if (v) setRunBit(self.rw(), v);
            setRunLen(self.rw(), LARGEST_RUNNING);
            number -= LARGEST_RUNNING;
        }
        if (number > 0) {
            self.pushRlw(0);
            if (v) setRunBit(self.rw(), v);
            setRunLen(self.rw(), number);
        }
    }

    fn addLiteral(self: *Bitmap, data: u64) void {
        const cur = litWords(self.rw().*);
        if (cur >= LARGEST_LITERAL) {
            self.pushRlw(0);
            setLitWords(self.rw(), 1);
            self.push(data);
            return;
        }
        setLitWords(self.rw(), cur + 1);
        self.push(data);
    }

    fn addEmptyWord(self: *Bitmap, v: bool) void {
        const w = self.rw();
        const no_literal = litWords(w.*) == 0;
        const rl = runLen(w.*);
        if (no_literal and rl == 0) setRunBit(w, v);
        if (no_literal and runBit(w.*) == v and rl < LARGEST_RUNNING) {
            setRunLen(w, rl + 1);
            return;
        }
        self.pushRlw(0);
        setRunBit(self.rw(), v);
        setRunLen(self.rw(), 1);
    }

    /// ewah_set(): bits must be set in increasing order.
    pub fn set(self: *Bitmap, i: usize) void {
        const dist = (i + 1 + 63) / 64 -% (self.bit_size + 63) / 64;
        self.bit_size = i + 1;
        const bit = @as(u64, 1) << @intCast(i % 64);
        if (dist > 0) {
            if (dist > 1) self.addEmptyWords(false, dist - 1);
            self.addLiteral(bit);
            return;
        }
        if (litWords(self.rw().*) == 0) {
            setRunLen(self.rw(), runLen(self.rw().*) - 1);
            self.addLiteral(bit);
            return;
        }
        const last = &self.buffer.items[self.buffer.items.len - 1];
        last.* |= bit;
        if (last.* == ~@as(u64, 0)) {
            self.buffer.items.len -= 1;
            setLitWords(self.rw(), litWords(self.rw().*) - 1);
            self.addEmptyWord(true);
        }
    }

    /// ewah_serialize_strbuf()
    pub fn serialize(self: *const Bitmap, b: *util.Buf) void {
        var t4: [4]u8 = undefined;
        std.mem.writeInt(u32, &t4, @truncate(self.bit_size), .big);
        util.bufAppend(b, &t4);
        std.mem.writeInt(u32, &t4, @intCast(self.buffer.items.len), .big);
        util.bufAppend(b, &t4);
        var t8: [8]u8 = undefined;
        for (self.buffer.items) |w| {
            std.mem.writeInt(u64, &t8, w, .big);
            util.bufAppend(b, &t8);
        }
        std.mem.writeInt(u32, &t4, @intCast(self.rlw), .big);
        util.bufAppend(b, &t4);
    }

    /// ewah_read_mmap(): returns bytes consumed, or null on corruption.
    pub fn read(data: []const u8) ?struct { bm: Bitmap, len: usize } {
        if (data.len < 8) return null;
        var b = Bitmap{};
        b.bit_size = std.mem.readInt(u32, data[0..4], .big);
        const n = std.mem.readInt(u32, data[4..8], .big);
        var p: usize = 8;
        if (data.len - p < @as(usize, n) * 8) return null;
        b.buffer.ensureTotalCapacity(gpa, n) catch util.oom();
        var k: usize = 0;
        while (k < n) : (k += 1) {
            b.buffer.appendAssumeCapacity(std.mem.readInt(u64, data[p..][0..8], .big));
            p += 8;
        }
        if (data.len - p < 4) return null;
        b.rlw = std.mem.readInt(u32, data[p..][0..4], .big);
        p += 4;
        if (b.buffer.items.len == 0) {
            b.buffer.append(gpa, 0) catch util.oom();
            b.rlw = 0;
        }
        return .{ .bm = b, .len = p };
    }

    /// ewah_each_bit(): collect positions of set bits.
    pub fn bits(self: *const Bitmap) []usize {
        var out: std.ArrayList(usize) = .empty;
        var pos: usize = 0;
        var ptr: usize = 0;
        const buf = self.buffer.items;
        while (ptr < buf.len) {
            const word = buf[ptr];
            const rl: usize = @intCast(runLen(word));
            if (runBit(word)) {
                var k: usize = 0;
                while (k < rl * 64) : (k += 1) {
                    out.append(gpa, pos) catch util.oom();
                    pos += 1;
                }
            } else pos += rl * 64;
            ptr += 1;
            var k: usize = 0;
            const lw: usize = @intCast(litWords(word));
            while (k < lw and ptr < buf.len) : (k += 1) {
                var c: u7 = 0;
                while (c < 64) : (c += 1) {
                    if (buf[ptr] & (@as(u64, 1) << @intCast(c)) != 0) out.append(gpa, pos) catch util.oom();
                    pos += 1;
                }
                ptr += 1;
            }
        }
        return out.items;
    }
};

pub fn new() Bitmap {
    return Bitmap.init();
}
