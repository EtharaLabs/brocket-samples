//! git ls-remote (port of builtin/ls-remote.c)

const std = @import("std");
const util = @import("../util.zig");
const po = @import("../parseopt.zig");
const tp = @import("../transport.zig");
const hash = @import("../hash.zig");
const wildmatch = @import("../wildmatch.zig");
const gpa = util.gpa;

const usage = [_][]const u8{
    "git ls-remote [--branches] [--tags] [--refs] [--upload-pack=<exec>]\n" ++
        "              [-q | --quiet] [--exit-code] [--get-url] [--sort=<key>]\n" ++
        "              [--symref] [<repository> [<patterns>...]]",
};

const REF_NORMAL: i32 = 1;
const REF_BRANCHES: i32 = 2;
const REF_TAGS: i32 = 4;

var quiet: i32 = 0;
var uploadpack: ?[]const u8 = null;
var flags: i32 = 0;
var get_url = false;
var sort_keys: std.ArrayList([]const u8) = .empty;
var status: i32 = 0;
var show_symref = false;
var server_options: std.ArrayList([]const u8) = .empty;

const options = [_]po.Opt{
    po.quiet(&quiet),
    po.string(0, "upload-pack", &uploadpack, "exec", "path of git-upload-pack on the remote host"),
    .{ .long = "exec", .kind = .string, .s = &uploadpack, .argh = "exec", .help = "path of git-upload-pack on the remote host", .hidden = true },
    po.bit('t', "tags", &flags, REF_TAGS, "limit to tags"),
    po.bit('b', "branches", &flags, REF_BRANCHES, "limit to branches"),
    .{ .short = 'h', .long = "heads", .kind = .bit, .i = &flags, .val = REF_BRANCHES, .help = "deprecated synonym for --branches", .hidden = true },
    po.bit(0, "refs", &flags, REF_NORMAL, "do not show peeled tags"),
    po.boolean(0, "get-url", &get_url, "take url.<base>.insteadOf into account"),
    po.list(0, "sort", &sort_keys, "key", "field name to sort on"),
    po.noComplete(po.setInt(0, "exit-code", &status, 2, "exit with exit code 2 if no matching refs are found")),
    po.boolean(0, "symref", &show_symref, "show underlying ref in addition to the object pointed by it"),
    po.list('o', "server-option", &server_options, "server-specific", "option to transmit"),
};

fn checkRef(name0: []const u8, f: i32) bool {
    if (f == 0) return true;
    const name = util.skipPrefix(name0, "refs/") orelse return false;
    if ((f & REF_NORMAL) != 0 and !@import("../refs.zig").checkRefnameFormat(name, 0)) return false;
    if ((f & REF_BRANCHES) != 0 and util.startsWith(name, "heads/")) return true;
    if ((f & REF_TAGS) != 0 and util.startsWith(name, "tags/")) return true;
    return (f & ~REF_NORMAL) == 0;
}

fn tailMatch(patterns: []const []const u8, path: []const u8) bool {
    if (patterns.len == 0) return true;
    const p = util.concat(&.{ "/", path });
    for (patterns) |pat| {
        if (wildmatch.match(pat, p, 0)) return true;
    }
    return false;
}

var sort_desc = false;
fn lessRef(_: void, a: *tp.Ref, b: *tp.Ref) bool {
    const o = std.mem.order(u8, a.name, b.name);
    return if (sort_desc) o == .gt else o == .lt;
}

pub fn cmdLsRemote(args: []const []const u8) u8 {
    @import("../pktline.zig").traceIdentity("ls-remote");
    const rest = po.parse(args[1..], &options, &usage, .{ .stop_at_non_option = true });
    const dest: ?[]const u8 = if (rest.len > 0) rest[0] else null;
    var patterns: std.ArrayList([]const u8) = .empty;
    if (rest.len > 1) {
        for (rest[1..]) |a| patterns.append(gpa, util.concat(&.{ "*/", a })) catch util.oom();
    }
    var prefixes: std.ArrayList([]const u8) = .empty;
    if ((flags & REF_TAGS) != 0) prefixes.append(gpa, "refs/tags/") catch util.oom();
    if ((flags & REF_BRANCHES) != 0) prefixes.append(gpa, "refs/heads/") catch util.oom();

    const remote = tp.remoteGet(dest) orelse {
        if (dest) |d| util.die("bad repository '{s}'", .{d});
        util.die("No remote configured to list refs from.", .{});
    };
    if (get_url) {
        util.outf("{s}\n", .{remote.urls.items[0]});
        return 0;
    }
    const t = tp.transportGet(remote, null);
    if (uploadpack) |u| {
        t.uploadpack = u;
        @import("../transport_helper.zig").transportSetOption(t, "uploadpack", u);
    }
    t.server_options = server_options.items;
    const list = tp.getRemoteRefs(t, prefixes.items);
    if (dest == null and quiet == 0) util.eprint("From {s}\n", .{remote.urls.items[0]});
    var arr: std.ArrayList(*tp.Ref) = .empty;
    for (list) |r| {
        if (!checkRef(r.name, flags)) continue;
        if (!tailMatch(patterns.items, r.name)) continue;
        arr.append(gpa, r) catch util.oom();
    }
    for (sort_keys.items) |k| {
        sort_desc = k.len > 0 and k[0] == '-';
    }
    std.sort.block(*tp.Ref, arr.items, {}, lessRef);
    for (arr.items) |r| {
        if (show_symref) {
            if (r.symref) |s| util.outf("ref: {s}\t{s}\n", .{ s, r.name });
        }
        util.outf("{s}\t{s}\n", .{ hash.hex(r.old_oid), r.name });
        status = 0;
    }
    if (tp.disconnect(t) != 0) status = 1;
    return @intCast(status);
}
