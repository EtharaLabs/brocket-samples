//! git shell (port of shell.c): restricted login shell for Git-only SSH access.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const gpa = util.gpa;

extern "c" fn execv(file: [*:0]const u8, argv: [*:null]const ?[*:0]const u8) c_int;

const COMMAND_DIR = "git-shell-commands";
const HELP_COMMAND = COMMAND_DIR ++ "/help";
const NOLOGIN_COMMAND = COMMAND_DIR ++ "/no-interactive-login";
const MAX_INTERACTIVE_COMMAND: usize = 4 * 1024 * 1024;

fn needBsQuote(ch: u8) bool {
    return ch == '\'' or ch == '!';
}

fn sqDequote(arg: []const u8) ?[]const u8 {
    if (arg.len == 0 or arg[0] != '\'') return null;
    var b: util.Buf = .empty;
    var i: usize = 0;
    while (true) {
        i += 1;
        if (i >= arg.len) return null;
        const ch = arg[i];
        if (ch != '\'') {
            util.bufByte(&b, ch);
            continue;
        }
        i += 1;
        if (i >= arg.len) return b.items;
        if (arg[i] == '\\' and i + 2 < arg.len and needBsQuote(arg[i + 1]) and arg[i + 2] == '\'') {
            util.bufByte(&b, arg[i + 1]);
            i += 2; // now at the reopening quote
            continue;
        }
        return null;
    }
}

const SplitErr = error{ BadEnding, UnclosedQuote };

fn splitErrStr(e: SplitErr) []const u8 {
    return switch (e) {
        error.BadEnding => "cmdline ends with \\",
        error.UnclosedQuote => "unclosed quote",
    };
}

/// split_cmdline() from alias.c
fn splitCmdline(s: []const u8) SplitErr![][]const u8 {
    var res: std.ArrayList([]const u8) = .empty;
    var cur: util.Buf = .empty;
    var quoted: u8 = 0;
    var i: usize = 0;
    while (i < s.len) {
        var ch = s[i];
        if (quoted == 0 and std.ascii.isWhitespace(ch)) {
            res.append(gpa, cur.items) catch util.oom();
            cur = .empty;
            i += 1;
            while (i < s.len and std.ascii.isWhitespace(s[i])) i += 1;
        } else if (quoted == 0 and (ch == '\'' or ch == '"')) {
            quoted = ch;
            i += 1;
        } else if (ch == quoted) {
            quoted = 0;
            i += 1;
        } else {
            if (ch == '\\' and quoted != '\'') {
                i += 1;
                if (i >= s.len) return error.BadEnding;
                ch = s[i];
            }
            util.bufByte(&cur, ch);
            i += 1;
        }
    }
    if (quoted != 0) return error.UnclosedQuote;
    res.append(gpa, cur.items) catch util.oom();
    return res.items;
}

fn doGenericCmd(me0: []const u8, arg0: ?[]const u8) u8 {
    const arg = sqDequote(arg0 orelse util.die("bad argument", .{})) orelse util.die("bad argument", .{});
    if (arg.len > 0 and arg[0] == '-') util.die("bad argument", .{});
    const me = util.skipPrefix(me0, "git-") orelse util.die("bad command", .{});
    util.flushStdout();
    const git = proc.gitBinary();
    const argv = [_:null]?[*:0]const u8{ "git", os.z(me), os.z(arg), null };
    _ = execv(os.z(git), &argv);
    const r = os.run(&.{ "git", me, arg }, .{});
    return r.status;
}

fn isValidCmdName(cmd: []const u8) bool {
    return std.mem.indexOfAny(u8, cmd, "./") == null;
}

fn cdToHomedir() void {
    const home = os.getenv("HOME") orelse util.die("could not determine user's home directory; HOME is unset", .{});
    if (!os.chdir(home)) util.die("could not chdir to user's home directory", .{});
}

fn runChild(argv: []const []const u8) u8 {
    const r = os.run(argv, .{ .no_stderr = false });
    return r.status;
}

fn readLine(buf: *util.Buf) bool {
    buf.clearRetainingCapacity();
    while (true) {
        if (rd_pos >= rd_len) {
            const n = std.c.read(0, &rd_buf, rd_buf.len);
            if (n <= 0) return buf.items.len > 0;
            rd_len = @intCast(n);
            rd_pos = 0;
        }
        const ch = rd_buf[rd_pos];
        rd_pos += 1;
        util.bufByte(buf, ch);
        if (ch == '\n') return true;
        if (buf.items.len >= MAX_INTERACTIVE_COMMAND - 1) return true;
    }
}

var rd_buf: [65536]u8 = undefined;
var rd_pos: usize = 0;
var rd_len: usize = 0;

fn runShell() void {
    if (os.exists(NOLOGIN_COMMAND)) {
        const st = runChild(&.{NOLOGIN_COMMAND});
        os.exit(st);
    }
    // Print help if enabled
    if (os.access(HELP_COMMAND, 1)) _ = runChild(&.{HELP_COMMAND});

    var line: util.Buf = .empty;
    var done = false;
    while (!done) {
        util.flushStdout();
        util.eprint("git> ", .{});
        if (!readLine(&line)) {
            util.eprint("\n", .{});
            break;
        }
        var len = line.items.len;
        if (len >= MAX_INTERACTIVE_COMMAND - 1) util.die("invalid command format: input too long", .{});
        if (len > 0 and line.items[len - 1] == '\n') {
            len -= 1;
            if (len > 0 and line.items[len - 1] == '\r') len -= 1;
        }
        const raw = util.dupe(line.items[0..len]);
        const argv = splitCmdline(raw) catch |e| {
            util.eprint("invalid command format '{s}': {s}\n", .{ raw, splitErrStr(e) });
            continue;
        };
        const prog = argv[0];
        if (prog.len == 0) {} else if (util.eql(prog, "quit") or util.eql(prog, "logout") or
            util.eql(prog, "exit") or util.eql(prog, "bye"))
        {
            done = true;
        } else if (isValidCmdName(prog)) {
            const full = util.concat(&.{ COMMAND_DIR, "/", prog });
            if (!os.exists(full)) {
                util.eprint("unrecognized command '{s}'\n", .{prog});
            } else {
                var a: std.ArrayList([]const u8) = .empty;
                a.append(gpa, full) catch util.oom();
                a.appendSlice(gpa, argv[1..]) catch util.oom();
                _ = runChild(a.items);
            }
        } else {
            util.eprint("invalid command format '{s}'\n", .{prog});
        }
    }
}

pub fn cmdShell(args: []const []const u8) u8 {
    var cmdarg: []const u8 = undefined;
    if (args.len == 2 and util.eql(args[1], "cvs server")) {
        cmdarg = args[1];
    } else if (args.len == 1) {
        cdToHomedir();
        if (!os.access(COMMAND_DIR, 4 | 1)) {
            util.die("Interactive git shell is not enabled.\nhint: ~/" ++ COMMAND_DIR ++ " should exist and have read and execute access.", .{});
        }
        runShell();
        return 0;
    } else if (args.len != 3 or !util.eql(args[1], "-c")) {
        util.die("Run with no arguments or with -c cmd", .{});
    } else {
        cmdarg = args[2];
    }

    var prog = util.dupe(cmdarg);
    if (prog.len > 3 and util.startsWith(prog, "git") and std.ascii.isWhitespace(prog[3])) prog[3] = '-';

    const cmd_list = [_][]const u8{ "git-receive-pack", "git-upload-pack", "git-upload-archive" };
    for (cmd_list) |name| {
        if (!util.startsWith(prog, name)) continue;
        if (prog.len == name.len) return doGenericCmd(name, null);
        if (prog[name.len] == ' ') return doGenericCmd(name, prog[name.len + 1 ..]);
    }

    cdToHomedir();
    const user_argv = splitCmdline(prog) catch |e| {
        util.die("invalid command format '{s}': {s}", .{ cmdarg, splitErrStr(e) });
    };
    if (isValidCmdName(user_argv[0])) {
        const cmd = util.concat(&.{ COMMAND_DIR, "/", user_argv[0] });
        util.flushStdout();
        const cargv = gpa.allocSentinel(?[*:0]const u8, user_argv.len, null) catch util.oom();
        for (user_argv, 0..) |a, i| cargv[i] = os.z(a);
        _ = execv(os.z(cmd), cargv.ptr);
    }
    util.die("unrecognized command '{s}'", .{cmdarg});
}
