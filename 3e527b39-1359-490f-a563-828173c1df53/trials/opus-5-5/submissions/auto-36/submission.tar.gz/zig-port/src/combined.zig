//! Port of combine-diff.c (diff -c / --cc, combined raw output).
//!
//!   combined.diffTreeCombined(oid, parents, o, revs, dense, all_paths)
//!   combined.diffTreeCombinedMerge(commit, revs, o)
//!   combined.showCombinedDiff(path, num_parent, o, dense)  (diff-files / diff-index -c)

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const objects = @import("objects.zig");
const odb_mod = @import("odb.zig");
const repo_mod = @import("repo.zig");
const revparse = @import("revparse.zig");
const xdiff = @import("xdiff.zig");
const userdiff = @import("userdiff.zig");
const index_mod = @import("index.zig");
const revision = @import("revision.zig");
const cn = @import("commitnode.zig");
const logtree = @import("logtree.zig");
const pretty = @import("pretty.zig");
const diff = @import("diff.zig");
const treediff = @import("treediff.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Buf = util.Buf;
const CombinePath = treediff.CombinePath;
const DiffOptions = diff.DiffOptions;

const S_IFMT: u32 = 0o170000;
fn isDir(m: u32) bool {
    return m & S_IFMT == 0o040000;
}
fn isLnk(m: u32) bool {
    return m & S_IFMT == 0o120000;
}
fn isGitlink(m: u32) bool {
    return m & S_IFMT == 0o160000;
}

fn comparePaths(one: *const CombinePath, two: *const diff.Filespec) std.math.Order {
    if (!isDir(one.mode) and !isDir(two.mode)) return std.mem.order(u8, one.path, two.path);
    return objects.baseNameCompare(one.path, one.mode, two.path, two.mode);
}

fn filenameChanged(status: u8) bool {
    return status == 'R' or status == 'C';
}

fn newPath(path: []const u8, mode: u32, oid: Oid, num_parent: usize) *CombinePath {
    const p = gpa.create(CombinePath) catch util.oom();
    p.* = .{ .path = path, .mode = mode, .oid = oid, .parent = gpa.alloc(treediff.CombineParent, num_parent) catch util.oom() };
    for (p.parent) |*x| x.* = .{};
    return p;
}

fn intersectPaths(curr: *std.ArrayList(*CombinePath), n: usize, num_parent: usize, all_paths: bool) void {
    const q = diff.queue.items;
    if (n == 0) {
        for (q) |qp| {
            if (diff.unmodifiedPair(qp)) continue;
            const p = newPath(qp.two.path, qp.two.mode, qp.two.oid, num_parent);
            p.parent[n].oid = qp.one.oid;
            p.parent[n].mode = qp.one.mode;
            p.parent[n].status = qp.status;
            if (all_paths and filenameChanged(qp.status)) p.parent[n].path = qp.one.path;
            curr.append(gpa, p) catch util.oom();
        }
        return;
    }
    var out: std.ArrayList(*CombinePath) = .empty;
    var i: usize = 0;
    var k: usize = 0;
    while (k < curr.items.len) {
        const p = curr.items[k];
        const cmp: std.math.Order = if (i >= q.len) .lt else comparePaths(p, q[i].two);
        if (cmp == .lt) {
            k += 1;
            continue;
        }
        if (cmp == .gt) {
            i += 1;
            continue;
        }
        p.parent[n].oid = q[i].one.oid;
        p.parent[n].mode = q[i].one.mode;
        p.parent[n].status = q[i].status;
        if (all_paths and filenameChanged(q[i].status)) p.parent[n].path = q[i].one.path;
        out.append(gpa, p) catch util.oom();
        k += 1;
        i += 1;
    }
    curr.* = out;
}

const Lline = struct {
    next: ?*Lline = null,
    prev: ?*Lline = null,
    parent_map: u64,
    line: []const u8,
};

const Plost = struct {
    head: ?*Lline = null,
    tail: ?*Lline = null,
    len: usize = 0,
};

const Sline = struct {
    lost: ?*Lline = null,
    lenlost: usize = 0,
    plost: Plost = .{},
    bol: ?[]const u8 = null,
    len: usize = 0,
    flag: u64 = 0,
    p_lno: ?[]u64 = null,
};

fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r' or c == 0x0b or c == 0x0c;
}

fn matchStringSpaces(l1: []const u8, l2: []const u8, flags: xdiff.Flags) bool {
    var len1 = l1.len;
    var len2 = l2.len;
    const any_ws = flags.ignore_ws or flags.ignore_ws_change or flags.ignore_ws_eol or flags.ignore_cr_eol;
    if (any_ws) {
        while (len1 > 0 and isSpace(l1[len1 - 1])) len1 -= 1;
        while (len2 > 0 and isSpace(l2[len2 - 1])) len2 -= 1;
    }
    if (!flags.ignore_ws and !flags.ignore_ws_change)
        return len1 == len2 and std.mem.eql(u8, l1[0..len1], l2[0..len2]);
    while (len1 > 0 and len2 > 0) {
        len1 -= 1;
        len2 -= 1;
        if (isSpace(l1[len1]) or isSpace(l2[len2])) {
            if (flags.ignore_ws_change and (!isSpace(l1[len1]) or !isSpace(l2[len2]))) return false;
            while (len1 > 0 and isSpace(l1[len1])) len1 -= 1;
            while (len2 > 0 and isSpace(l2[len2])) len2 -= 1;
        }
        if (l1[len1] != l2[len2]) return false;
    }
    if (flags.ignore_ws) {
        while (len1 > 0 and isSpace(l1[len1 - 1])) len1 -= 1;
        while (len2 > 0 and isSpace(l2[len2 - 1])) len2 -= 1;
    }
    return len1 == 0 and len2 == 0;
}

const Dir = enum(u8) { match, base, new };

fn coalesceLines(base0: ?*Lline, lenbase: *usize, newline0: ?*Lline, lennew: usize, parent: usize, flags: xdiff.Flags) ?*Lline {
    var base = base0;
    var newline = newline0;
    if (newline == null) return base;
    if (base == null) {
        lenbase.* = lennew;
        return newline;
    }
    const origbaselen = lenbase.*;
    const w = lennew + 1;
    const lcs = gpa.alloc(u32, (origbaselen + 1) * w) catch util.oom();
    @memset(lcs, 0);
    const dirs = gpa.alloc(Dir, (origbaselen + 1) * w) catch util.oom();
    @memset(dirs, .match);
    for (0..origbaselen + 1) |i| dirs[i * w] = .base;
    for (1..lennew + 1) |j| dirs[j] = .new;

    var baseend: ?*Lline = base;
    var newend: ?*Lline = null;
    var i: usize = 1;
    while (i < origbaselen + 1) : (i += 1) {
        newend = newline;
        var j: usize = 1;
        while (j < lennew + 1) : (j += 1) {
            if (matchStringSpaces(baseend.?.line, newend.?.line, flags)) {
                lcs[i * w + j] = lcs[(i - 1) * w + j - 1] + 1;
                dirs[i * w + j] = .match;
            } else if (lcs[i * w + j - 1] >= lcs[(i - 1) * w + j]) {
                lcs[i * w + j] = lcs[i * w + j - 1];
                dirs[i * w + j] = .new;
            } else {
                lcs[i * w + j] = lcs[(i - 1) * w + j];
                dirs[i * w + j] = .base;
            }
            if (newend.?.next) |nx| newend = nx;
        }
        if (baseend.?.next) |nx| baseend = nx;
    }
    i -= 1;
    var j: usize = lennew;
    while (i != 0 or j != 0) {
        const d = dirs[i * w + j];
        if (d == .match) {
            baseend.?.parent_map |= @as(u64, 1) << @intCast(parent);
            baseend = baseend.?.prev;
            newend = newend.?.prev;
            i -= 1;
            j -= 1;
        } else if (d == .new) {
            const ll = newend.?;
            if (ll.prev) |pv| pv.next = ll.next else newline = ll.next;
            if (ll.next) |nx| nx.prev = ll.prev;
            newend = ll.prev;
            j -= 1;
            if (baseend) |be| {
                ll.next = be.next;
                ll.prev = be;
                be.next = ll;
            } else {
                ll.next = base;
                ll.prev = null;
                base = ll;
            }
            lenbase.* += 1;
            if (ll.next) |nx| nx.prev = ll;
        } else {
            baseend = baseend.?.prev;
            i -= 1;
        }
    }
    return base;
}

fn grabBlob(oid: Oid, mode: u32, textconv: ?*userdiff.Driver, path: []const u8) []const u8 {
    if (isGitlink(mode)) return util.fmt("Subproject commit {s}\n", .{hash.hexAlloc(oid)});
    if (hash.isZero(oid)) return "";
    if (textconv) |tc| {
        const df = diff.allocFilespec(path, oid, true, mode);
        return diff.fillTextconv(tc, df);
    }
    const obj = repo_mod.repo().odb().read(oid) orelse util.die("unable to read {s}", .{hash.hexAlloc(oid)});
    if (obj.typ != .blob) util.die("object '{s}' is not a blob!", .{hash.hexAlloc(oid)});
    return obj.data;
}

fn appendLost(sl: *Sline, n: usize, line0: []const u8) void {
    var line = line0;
    if (line.len > 0 and line[line.len - 1] == '\n') line = line[0 .. line.len - 1];
    const ll = gpa.create(Lline) catch util.oom();
    ll.* = .{ .parent_map = @as(u64, 1) << @intCast(n), .line = line, .prev = sl.plost.tail };
    if (ll.prev) |pv| pv.next = ll else sl.plost.head = ll;
    sl.plost.tail = ll;
    sl.plost.len += 1;
}

const State = struct {
    lno: usize = 1,
    ob: isize = 0,
    on: isize = 0,
    nb: isize = 0,
    nn: isize = 0,
    nmask: u64,
    num_parent: usize,
    n: usize,
    sline: []Sline,
    lost_bucket: ?*Sline = null,
};

fn ensureLno(sl: *Sline, num_parent: usize) void {
    if (sl.p_lno == null) {
        const a = gpa.alloc(u64, num_parent) catch util.oom();
        @memset(a, 0);
        sl.p_lno = a;
    }
}

fn consumeHunk(ctx: ?*anyopaque, h: xdiff.HunkInfo) void {
    const st: *State = @ptrCast(@alignCast(ctx.?));
    st.ob = h.old_begin;
    st.on = h.old_nr;
    st.nb = h.new_begin;
    st.nn = h.new_nr;
    st.lno = @intCast(st.nb);
    if (st.nn == 0) {
        st.lost_bucket = &st.sline[@intCast(st.nb)];
        if (st.nb == 0) st.nb = 1;
    } else {
        st.lost_bucket = &st.sline[@intCast(st.nb - 1)];
    }
    const sl = &st.sline[@intCast(st.nb - 1)];
    ensureLno(sl, st.num_parent);
    sl.p_lno.?[st.n] = @intCast(st.ob);
}

fn consumeLine(ctx: ?*anyopaque, kind: xdiff.LineKind, text: []const u8) void {
    const st: *State = @ptrCast(@alignCast(ctx.?));
    const bucket = st.lost_bucket orelse return;
    switch (kind) {
        .del => appendLost(bucket, st.n, text),
        .add => {
            st.sline[st.lno - 1].flag |= st.nmask;
            st.lno += 1;
        },
        else => {},
    }
}

fn combineDiff(parent: Oid, mode: u32, result: []const u8, sline: []Sline, cnt: usize, n: usize, num_parent: usize, result_deleted: bool, textconv: ?*userdiff.Driver, path: []const u8, flags: xdiff.Flags) void {
    if (result_deleted) return;
    const nmask = @as(u64, 1) << @intCast(n);
    const pf = grabBlob(parent, mode, textconv, path);
    var st = State{ .nmask = nmask, .sline = sline, .num_parent = num_parent, .n = n };
    const t = xdiff.trimCommonTail(pf, result);
    var d = xdiff.diff(t.a, t.b, flags) catch util.die("unable to generate combined diff for {s}", .{hash.hexAlloc(parent)});
    defer d.deinit();
    xdiff.emitDiff(&d, .{ .context = 0, .funcnames = false }, .{ .ctx = &st, .hunk = consumeHunk, .line = consumeLine });

    var p_lno: u64 = 1;
    var lno: usize = 0;
    while (lno <= cnt) : (lno += 1) {
        sline[lno].p_lno.?[n] = p_lno;
        if (sline[lno].plost.head != null) {
            const sl = &sline[lno];
            sl.lost = coalesceLines(sl.lost, &sl.lenlost, sl.plost.head, sl.plost.len, n, flags);
            sl.plost = .{};
        }
        var ll = sline[lno].lost;
        while (ll) |l| : (ll = l.next) {
            if (l.parent_map & nmask != 0) p_lno += 1;
        }
        if (lno < cnt and sline[lno].flag & nmask == 0) p_lno += 1;
    }
    sline[lno].p_lno.?[n] = p_lno;
}

var context: usize = 3;
const combine_marker: u8 = '@';

fn interesting(sl: *const Sline, all_mask: u64) bool {
    return (sl.flag & all_mask) != 0 or sl.lost != null;
}

fn adjustHunkTail(sline: []Sline, all_mask: u64, hunk_begin: usize, i_start: usize) usize {
    var i = i_start;
    if (hunk_begin + 1 <= i and sline[i - 1].flag & all_mask == 0) i -= 1;
    return i;
}

fn findNext(sline: []Sline, mark: u64, i_start: usize, cnt: usize, look_for_uninteresting: bool) usize {
    var i = i_start;
    while (i <= cnt) {
        const m = sline[i].flag & mark != 0;
        if (if (look_for_uninteresting) !m else m) return i;
        i += 1;
    }
    return i;
}

fn giveContext(sline: []Sline, cnt: usize, num_parent: usize) bool {
    const all_mask = (@as(u64, 1) << @intCast(num_parent)) - 1;
    const mark = @as(u64, 1) << @intCast(num_parent);
    const no_pre_delete = @as(u64, 2) << @intCast(num_parent);
    var i = findNext(sline, mark, 0, cnt, false);
    if (cnt < i) return false;
    while (i <= cnt) {
        var j: usize = if (context < i) i - context else 0;
        while (j < i) : (j += 1) {
            if (sline[j].flag & mark == 0) sline[j].flag |= no_pre_delete;
            sline[j].flag |= mark;
        }
        while (true) {
            j = findNext(sline, mark, i, cnt, true);
            if (cnt < j) return true;
            var k = findNext(sline, mark, j, cnt, false);
            j = adjustHunkTail(sline, all_mask, i, j);
            if (k < j + context) {
                while (j < k) : (j += 1) sline[j].flag |= mark;
                i = k;
                continue;
            }
            i = k;
            k = if (j + context < cnt + 1) j + context else cnt + 1;
            while (j < k) : (j += 1) sline[j].flag |= mark;
            break;
        }
    }
    return true;
}

fn makeHunks(sline: []Sline, cnt: usize, num_parent: usize, dense: bool) bool {
    const all_mask = (@as(u64, 1) << @intCast(num_parent)) - 1;
    const mark = @as(u64, 1) << @intCast(num_parent);
    for (0..cnt + 1) |i| {
        if (interesting(&sline[i], all_mask)) sline[i].flag |= mark else sline[i].flag &= ~mark;
    }
    if (!dense) return giveContext(sline, cnt, num_parent);
    var i: usize = 0;
    while (i <= cnt) {
        while (i <= cnt and sline[i].flag & mark == 0) i += 1;
        if (cnt < i) break;
        const hunk_begin = i;
        var j: usize = i + 1;
        while (j <= cnt) : (j += 1) {
            if (sline[j].flag & mark == 0) {
                var la = adjustHunkTail(sline, all_mask, hunk_begin, j);
                la = if (la + context < cnt + 1) la + context else cnt + 1;
                var contin = false;
                while (la > 0) {
                    la -= 1;
                    if (!(j <= la)) break;
                    if (sline[la].flag & mark != 0) {
                        contin = true;
                        break;
                    }
                }
                if (!contin) break;
                j = la;
            }
        }
        const hunk_end = j;
        var same_diff: u64 = 0;
        var has_interesting = false;
        j = i;
        while (j < hunk_end and !has_interesting) : (j += 1) {
            var this_diff = sline[j].flag & all_mask;
            if (this_diff != 0) {
                if (same_diff == 0) {
                    same_diff = this_diff;
                } else if (same_diff != this_diff) {
                    has_interesting = true;
                    break;
                }
            }
            var ll = sline[j].lost;
            while (ll != null and !has_interesting) : (ll = ll.?.next) {
                this_diff = ll.?.parent_map;
                if (same_diff == 0) {
                    same_diff = this_diff;
                } else if (same_diff != this_diff) has_interesting = true;
            }
        }
        if (!has_interesting and same_diff != all_mask) {
            j = hunk_begin;
            while (j < hunk_end) : (j += 1) sline[j].flag &= ~mark;
        }
        i = hunk_end;
    }
    return giveContext(sline, cnt, num_parent);
}

fn hunkCommentLine(bol: ?[]const u8) bool {
    const b = bol orelse return false;
    if (b.len == 0) return false;
    const ch = b[0];
    return std.ascii.isAlphabetic(ch) or ch == '_' or ch == '$';
}

fn showLineToEol(f: *util.Out, line: []const u8, reset: []const u8) void {
    const cr = line.len > 0 and line[line.len - 1] == '\r';
    f.write(line[0 .. line.len - @intFromBool(cr)]);
    f.write(reset);
    if (cr) f.write("\r");
    f.write("\n");
}

fn dumpSline(f: *util.Out, o: *DiffOptions, sline: []Sline, line_prefix: []const u8, cnt: usize, num_parent: usize, result_deleted: bool) void {
    const mark = @as(u64, 1) << @intCast(num_parent);
    const no_pre_delete = @as(u64, 2) << @intCast(num_parent);
    const c_frag = diff.getColor(o, .fraginfo);
    const c_func = diff.getColor(o, .funcinfo);
    const c_new = diff.getColor(o, .new);
    const c_old = diff.getColor(o, .old);
    const c_context = diff.getColor(o, .context);
    const c_reset = diff.getColor(o, .reset);
    if (result_deleted) return;
    var lno: usize = 0;
    while (true) {
        var hunk_comment: ?[]const u8 = null;
        var null_context: u64 = 0;
        while (lno <= cnt and sline[lno].flag & mark == 0) {
            if (hunkCommentLine(sline[lno].bol)) hunk_comment = sline[lno].bol;
            lno += 1;
        }
        if (cnt < lno) break;
        var hunk_end = lno + 1;
        while (hunk_end <= cnt) : (hunk_end += 1) {
            if (sline[hunk_end].flag & mark == 0) break;
        }
        var rlines: u64 = hunk_end - lno;
        if (cnt < hunk_end) rlines -%= 1;
        if (context == 0) {
            var j = lno;
            while (j < hunk_end) : (j += 1) {
                if (sline[j].flag & (mark - 1) == 0) null_context += 1;
            }
            rlines -%= null_context;
        }
        f.write(line_prefix);
        f.write(c_frag);
        for (0..num_parent + 1) |_| f.byte(combine_marker);
        for (0..num_parent) |n| {
            const l0 = sline[lno].p_lno.?[n];
            const l1 = sline[hunk_end].p_lno.?[n];
            f.print(" -{d},{d}", .{ l0, l1 -% l0 -% null_context });
        }
        f.print(" +{d},{d} ", .{ lno + 1, rlines });
        for (0..num_parent + 1) |_| f.byte(combine_marker);
        if (hunk_comment) |hc| {
            var comment_end: usize = 0;
            var i: usize = 0;
            while (i < 40) : (i += 1) {
                const ch: u8 = if (i < hc.len) hc[i] else 0;
                if (ch == 0 or ch == '\n') break;
                if (!isSpace(ch)) comment_end = i;
            }
            if (comment_end != 0) {
                f.write(c_reset);
                f.write(c_context);
                f.write(" ");
                f.write(c_reset);
                f.write(c_func);
            }
            f.write(hc[0..comment_end]);
        }
        f.write(c_reset);
        f.write("\n");
        while (lno < hunk_end) {
            const sl = &sline[lno];
            lno += 1;
            var ll = if (sl.flag & no_pre_delete != 0) null else sl.lost;
            while (ll) |l| : (ll = l.next) {
                f.write(line_prefix);
                f.write(c_old);
                for (0..num_parent) |j| f.byte(if (l.parent_map & (@as(u64, 1) << @intCast(j)) != 0) '-' else ' ');
                showLineToEol(f, l.line, c_reset);
            }
            if (cnt < lno) break;
            var p_mask: u64 = 1;
            f.write(line_prefix);
            if (sl.flag & (mark - 1) == 0) {
                if (context == 0) continue;
                f.write(c_context);
            } else f.write(c_new);
            for (0..num_parent) |_| {
                f.byte(if (p_mask & sl.flag != 0) '+' else ' ');
                p_mask <<= 1;
            }
            showLineToEol(f, (sl.bol orelse @as([]const u8, ""))[0..sl.len], c_reset);
        }
    }
}

fn reuseCombineDiff(sline: []Sline, cnt: usize, i: usize, j: usize) void {
    const imask = @as(u64, 1) << @intCast(i);
    const jmask = @as(u64, 1) << @intCast(j);
    for (0..cnt + 1) |lno| {
        const sl = &sline[lno];
        sl.p_lno.?[i] = sl.p_lno.?[j];
        var ll = sl.lost;
        while (ll) |l| : (ll = l.next) {
            if (l.parent_map & jmask != 0) l.parent_map |= imask;
        }
        if (sl.flag & jmask != 0) sl.flag |= imask;
    }
    sline[cnt + 1].p_lno.?[i] = sline[cnt + 1].p_lno.?[j];
}

fn dumpQuotedPath(f: *util.Out, head: []const u8, prefix: []const u8, path: []const u8, line_prefix: []const u8, c_meta: []const u8, c_reset: []const u8) void {
    f.write(line_prefix);
    f.write(c_meta);
    f.write(head);
    f.write(diff.quoteTwo(prefix, path));
    f.write(c_reset);
    f.write("\n");
}

pub const Ctx = struct {
    o: *DiffOptions,
    revs: ?*revision.RevInfo = null,
    dense: bool = false,
    all_paths: bool = false,

    fn showLogFirst(c: *const Ctx) void {
        if (c.revs) |r| {
            if (r.loginfo != null and !r.no_commit_id) logtree.showLog(r);
        }
    }
};

fn abbrevHex(oid: Oid, full: bool) []const u8 {
    if (full) return hash.hexAlloc(oid);
    return diff.diffAbbrevOid(oid, -1);
}

fn showCombinedHeader(c: *const Ctx, elem: *CombinePath, num_parent: usize, line_prefix: []const u8, mode_differs: bool, show_file_header: bool) void {
    const o = c.o;
    const f = o.out();
    const full = o.flags.full_index;
    const a_prefix = o.a_prefix orelse "a/";
    const b_prefix = o.b_prefix orelse "b/";
    const c_meta = diff.getColor(o, .metainfo);
    const c_reset = diff.getColor(o, .reset);
    var added = false;
    var deleted = false;
    c.showLogFirst();
    dumpQuotedPath(f, if (c.dense) "diff --cc " else "diff --combined ", "", elem.path, line_prefix, c_meta, c_reset);
    f.write(line_prefix);
    f.write(c_meta);
    f.write("index ");
    for (0..num_parent) |i| {
        if (i > 0) f.write(",");
        f.write(abbrevHex(elem.parent[i].oid, full));
    }
    f.write("..");
    f.write(abbrevHex(elem.oid, full));
    f.write(c_reset);
    f.write("\n");
    if (mode_differs) {
        deleted = elem.mode == 0;
        added = !deleted;
        for (0..num_parent) |i| {
            if (!added) break;
            if (elem.parent[i].status != diff.STATUS_ADDED) added = false;
        }
        if (added) {
            f.write(line_prefix);
            f.write(c_meta);
            f.print("new file mode {o:0>6}", .{elem.mode});
        } else {
            if (deleted) {
                f.write(line_prefix);
                f.write(c_meta);
                f.write("deleted file ");
            }
            f.write("mode ");
            for (0..num_parent) |i| f.print("{s}{o:0>6}", .{ if (i > 0) "," else "", elem.parent[i].mode });
            if (elem.mode != 0) f.print("..{o:0>6}", .{elem.mode});
        }
        f.write(c_reset);
        f.write("\n");
    }
    if (!show_file_header) return;
    if (c.all_paths) {
        for (0..num_parent) |i| {
            const path = elem.parent[i].path orelse elem.path;
            if (elem.parent[i].status == diff.STATUS_ADDED) {
                dumpQuotedPath(f, "--- ", "", "/dev/null", line_prefix, c_meta, c_reset);
            } else dumpQuotedPath(f, "--- ", a_prefix, path, line_prefix, c_meta, c_reset);
        }
    } else {
        if (added) {
            dumpQuotedPath(f, "--- ", "", "/dev/null", line_prefix, c_meta, c_reset);
        } else dumpQuotedPath(f, "--- ", a_prefix, elem.path, line_prefix, c_meta, c_reset);
    }
    if (deleted) {
        dumpQuotedPath(f, "+++ ", "", "/dev/null", line_prefix, c_meta, c_reset);
    } else dumpQuotedPath(f, "+++ ", b_prefix, elem.path, line_prefix, c_meta, c_reset);
}

fn canonMode(mode: u32) u32 {
    if (mode & S_IFMT == 0o100000) return 0o100000 | (if (mode & 0o100 != 0) @as(u32, 0o755) else 0o644);
    if (isLnk(mode)) return 0o120000;
    if (isDir(mode)) return 0o040000;
    if (isGitlink(mode)) return 0o160000;
    return mode;
}

fn showPatchDiff(c: *const Ctx, elem: *CombinePath, num_parent: usize, working_tree_file: bool) void {
    const o = c.o;
    const f = o.out();
    const line_prefix = diff.linePrefix(o);
    context = @intCast(@max(o.context, 0));
    var result_deleted = false;
    var drv = userdiff.findByPath(elem.path) orelse userdiff.findByName("default");
    var textconv: ?*userdiff.Driver = null;
    if (o.flags.allow_textconv) {
        if (drv) |d| textconv = userdiff.getTextconv(d);
    }
    var result: []const u8 = "";
    if (!working_tree_file) {
        result = grabBlob(elem.oid, elem.mode, textconv, elem.path);
    } else {
        if (os.lstatPath(elem.path)) |st| {
            if (st.isLnk()) {
                result = os.readLink(elem.path) orelse {
                    util.err("readlink({s}): {s}", .{ elem.path, os.lastErr() });
                    return;
                };
                elem.mode = canonMode(st.mode);
            } else if (st.isDir()) {
                if (index_mod.gitlinkHead(elem.path)) |h| {
                    result = grabBlob(h, elem.mode, null, "");
                } else result = grabBlob(elem.oid, elem.mode, null, "");
            } else if (textconv) |tc| {
                const df = diff.allocFilespec(elem.path, hash.zero, false, st.mode);
                result = diff.fillTextconv(tc, df);
            } else if (os.readFile(elem.path)) |data| {
                elem.mode = canonMode(st.mode);
                var is_file = repo_mod.cfg.getBool("core.symlinks") orelse true;
                var i: usize = 0;
                while (!is_file and i < num_parent) : (i += 1) is_file = !isLnk(elem.parent[i].mode);
                if (!is_file) elem.mode = canonMode(0o120000);
                result = data;
            } else {
                result_deleted = true;
                elem.mode = 0;
            }
        } else {
            result_deleted = true;
            elem.mode = 0;
        }
    }
    var mode_differs = false;
    for (0..num_parent) |i| {
        if (elem.parent[i].mode != elem.mode) {
            mode_differs = true;
            break;
        }
    }
    var is_binary = false;
    if (textconv != null) {
        is_binary = false;
    } else if (drv != null and drv.?.binary != -1) {
        is_binary = drv.?.binary == 1;
    } else {
        is_binary = diff.bufferIsBinary(result);
        var i: usize = 0;
        while (!is_binary and i < num_parent) : (i += 1) {
            if (diff.bufferIsBinary(grabBlob(elem.parent[i].oid, elem.parent[i].mode, null, ""))) is_binary = true;
        }
    }
    drv = null;
    if (is_binary) {
        showCombinedHeader(c, elem, num_parent, line_prefix, mode_differs, false);
        f.write("Binary files differ\n");
        return;
    }
    var cnt: usize = 0;
    for (result) |ch| {
        if (ch == '\n') cnt += 1;
    }
    if (result.len > 0 and result[result.len - 1] != '\n') cnt += 1;
    const sline = gpa.alloc(Sline, cnt + 2) catch util.oom();
    for (sline) |*s| s.* = .{};
    sline[0].bol = result;
    {
        var lno: usize = 0;
        var start: usize = 0;
        for (result, 0..) |ch, pos| {
            if (ch == '\n') {
                sline[lno].bol = result[start..];
                sline[lno].len = pos - start;
                lno += 1;
                start = pos + 1;
                if (lno < cnt) sline[lno].bol = result[start..];
            }
        }
        if (result.len > 0 and result[result.len - 1] != '\n') {
            sline[cnt - 1].bol = result[start..];
            sline[cnt - 1].len = result.len - start;
        }
    }
    const lnos = gpa.alloc(u64, (cnt + 2) * num_parent) catch util.oom();
    @memset(lnos, 0);
    for (0..cnt + 2) |lno| sline[lno].p_lno = lnos[lno * num_parent .. (lno + 1) * num_parent];

    const flags = diff.xflagsFrom(o);
    for (0..num_parent) |i| {
        var j: usize = 0;
        while (j < i) : (j += 1) {
            if (hash.eql(elem.parent[i].oid, elem.parent[j].oid)) {
                reuseCombineDiff(sline, cnt, i, j);
                break;
            }
        }
        if (i <= j) combineDiff(elem.parent[i].oid, elem.parent[i].mode, result, sline, cnt, i, num_parent, result_deleted, textconv, elem.path, flags);
    }
    const show_hunks = makeHunks(sline, cnt, num_parent, c.dense);
    if (show_hunks or mode_differs or working_tree_file) {
        showCombinedHeader(c, elem, num_parent, line_prefix, mode_differs, true);
        dumpSline(f, o, sline, line_prefix, cnt, num_parent, result_deleted);
    }
}

fn showRawDiff(c: *const Ctx, p: *CombinePath, num_parent: usize) void {
    const o = c.o;
    const f = o.out();
    const line_prefix = diff.linePrefix(o);
    const lt = o.line_termination;
    const inter: u8 = if (lt == 0) 0 else '\t';
    c.showLogFirst();
    if (o.output_format & diff.FMT_RAW != 0) {
        f.write(line_prefix);
        for (0..num_parent) |_| f.byte(':');
        for (0..num_parent) |i| f.print("{o:0>6} ", .{p.parent[i].mode});
        f.print("{o:0>6}", .{p.mode});
        for (0..num_parent) |i| f.print(" {s}", .{diff.alignedAbbrev(p.parent[i].oid, o.abbrev)});
        f.print(" {s} ", .{diff.alignedAbbrev(p.oid, o.abbrev)});
    }
    if (o.output_format & (diff.FMT_RAW | diff.FMT_NAME_STATUS) != 0) {
        for (0..num_parent) |i| f.byte(p.parent[i].status);
        f.byte(inter);
    }
    if (c.all_paths) {
        for (0..num_parent) |i| diff.writeNameQuoted(f, p.parent[i].path orelse p.path, inter);
    }
    diff.writeNameQuoted(f, p.path, lt);
}

/// show_combined_diff(): result from the working tree (diff-files / diff-index -c)
pub fn showCombinedDiff(p: *CombinePath, num_parent: usize, o: *DiffOptions, dense: bool) void {
    const c = Ctx{ .o = o, .revs = null, .dense = dense };
    if (o.output_format & (diff.FMT_RAW | diff.FMT_NAME | diff.FMT_NAME_STATUS) != 0) {
        showRawDiff(&c, p, num_parent);
    } else if (o.output_format & diff.FMT_PATCH != 0) {
        showPatchDiff(&c, p, num_parent, true);
    }
}

const STAT_FORMAT_MASK = diff.FMT_NUMSTAT | diff.FMT_SHORTSTAT | diff.FMT_SUMMARY | diff.FMT_DIRSTAT | diff.FMT_DIFFSTAT;

fn findPathsGeneric(oid: Oid, parents: []const Oid, opt: *DiffOptions, all_paths: bool) []*CombinePath {
    var paths: std.ArrayList(*CombinePath) = .empty;
    const output_format = opt.output_format;
    const orderfile = opt.orderfile;
    opt.output_format = diff.FMT_NO_OUTPUT;
    opt.orderfile = null;
    for (parents, 0..) |par, i| {
        const stat_opt = output_format & STAT_FORMAT_MASK;
        opt.output_format = if (i == 0 and stat_opt != 0) stat_opt else diff.FMT_NO_OUTPUT;
        treediff.diffTreeOid(par, oid, "", opt);
        diff.diffcoreStd(opt);
        intersectPaths(&paths, i, parents.len, all_paths);
        if (opt.output_format != diff.FMT_NO_OUTPUT) {
            if (orderfile) |of| diff.diffcore.order(of);
        }
        diff.flush(opt);
    }
    opt.output_format = output_format;
    opt.orderfile = orderfile;
    return paths.items;
}

fn keepAll(ctx: ?*anyopaque, opt: *DiffOptions, p: *CombinePath) bool {
    _ = ctx;
    _ = opt;
    _ = p;
    return true;
}

fn matchObjfind(p: *const CombinePath, set: *hash.OidSet) bool {
    if (set.contains(p.oid)) return true;
    for (p.parent) |pp| {
        if (set.contains(pp.oid)) return true;
    }
    return false;
}

/// diff_tree_combined()
pub fn diffTreeCombined(oid: Oid, parents: []const Oid, c: *const Ctx) void {
    const opt = c.o;
    if (opt.ignore_regex.items.len > 0)
        util.die("combined diff and '{s}' cannot be used together", .{"--ignore-matching-lines"});
    if (opt.close_file)
        util.die("combined diff and '{s}' cannot be used together", .{"--output"});
    if (parents.len == 0) return;
    const f = opt.out();
    if (c.revs) |r| {
        if (r.loginfo != null and !r.no_commit_id) {
            logtree.showLog(r);
            if (r.verbose_header and opt.output_format != 0 and opt.output_format != diff.FMT_NO_OUTPUT and
                !pretty.commitFormatIsEmpty(r.commit_format))
            {
                f.write(diff.linePrefix(opt));
                f.byte(opt.line_termination);
            }
        }
    }
    var diffopts = opt.*;
    diffopts.flags.allow_external = false;
    diffopts.flags.recursive = true;

    const need_generic = opt.skip_stat_unmatch != 0 or opt.flags.follow_renames or opt.break_opt != -1 or
        opt.detect_rename != 0 or (opt.pickaxe_opts & (diff.PICKAXE_KINDS_MASK & ~diff.PICKAXE_KIND_OBJFIND)) != 0 or
        opt.filter != 0;
    var paths: []*CombinePath = undefined;
    const saved_queue = diff.queue;
    diff.queue = .empty;
    if (need_generic) {
        paths = findPathsGeneric(oid, parents, &diffopts, c.all_paths);
    } else {
        const popt = gpa.alloc(?Oid, parents.len) catch util.oom();
        for (parents, 0..) |po, k| popt[k] = po;
        paths = treediff.diffTreePaths(oid, popt, "", &diffopts, keepAll, null);
        if (opt.pickaxe_opts & diff.PICKAXE_KIND_OBJFIND != 0) {
            var kept: std.ArrayList(*CombinePath) = .empty;
            for (paths) |p| {
                if (matchObjfind(p, opt.objfind.?)) kept.append(gpa, p) catch util.oom();
            }
            paths = kept.items;
        }
        const stat_opt = opt.output_format & STAT_FORMAT_MASK;
        if (stat_opt != 0) {
            diffopts.output_format = stat_opt;
            treediff.diffTreeOid(parents[0], oid, "", &diffopts);
            diff.diffcoreStd(&diffopts);
            if (opt.orderfile) |of| diff.diffcore.order(of);
            diff.flush(&diffopts);
        }
    }
    diff.queue = saved_queue;

    if (opt.orderfile) |of| {
        if (paths.len > 0) paths = diff.diffcore.orderPaths(of, paths);
    }
    if (paths.len > 0) {
        var needsep = false;
        if (opt.output_format & (diff.FMT_RAW | diff.FMT_NAME | diff.FMT_NAME_STATUS) != 0) {
            for (paths) |p| showRawDiff(c, p, parents.len);
            needsep = true;
        } else if (opt.output_format & STAT_FORMAT_MASK != 0) needsep = true;
        if (opt.output_format & diff.FMT_PATCH != 0) {
            if (needsep) {
                f.write(diff.linePrefix(opt));
                f.byte(opt.line_termination);
            }
            for (paths) |p| showPatchDiff(c, p, parents.len, false);
        }
    }
    // propagate accumulated state
    opt.flags.has_changes = opt.flags.has_changes or diffopts.flags.has_changes;
    if (diffopts.needed_rename_limit > opt.needed_rename_limit) opt.needed_rename_limit = diffopts.needed_rename_limit;
    if (diffopts.degraded_cc_to_c) opt.degraded_cc_to_c = true;
}

/// diff_tree_combined_merge()
pub fn diffTreeCombinedMerge(commit: *cn.Commit, revs: *revision.RevInfo, o: *DiffOptions) void {
    var parents: std.ArrayList(Oid) = .empty;
    var pl = revision.getSavedParents(revs, commit);
    while (pl) |x| : (pl = x.next) parents.append(gpa, x.item.obj.oid) catch util.oom();
    const c = Ctx{ .o = o, .revs = revs, .dense = revs.dense_combined_merges, .all_paths = revs.combined_all_paths };
    diffTreeCombined(commit.obj.oid, parents.items, &c);
}
