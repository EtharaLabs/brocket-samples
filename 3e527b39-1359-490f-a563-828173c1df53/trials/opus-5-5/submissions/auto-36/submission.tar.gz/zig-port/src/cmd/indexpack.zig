//! git index-pack, unpack-objects, verify-pack, show-index.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const odb_mod = @import("../odb.zig");
const pack = @import("../pack.zig");
const progress = @import("../progress.zig");
const proc = @import("../proc.zig");
const zlib = @import("../zlib.zig");
const fsck = @import("../fsck.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

const index_pack_usage = "git index-pack [-v] [-o <index-file>] [--keep | --keep=<msg>] [--[no-]rev-index] [--verify] [--strict[=<msg-id>=<severity>...]] [--fsck-objects[=<msg-id>=<severity>...]] (<pack-file> | --stdin [--fix-thin] [<pack-file>])";

fn usageDie(u: []const u8) noreturn {
    util.eprint("usage: {s}\n", .{u});
    os.exit(129);
}

fn showUsageIfAsked(args: []const []const u8, u: []const u8) void {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.outf("usage: {s}\n", .{u});
        util.flushStdout();
        os.exit(0);
    }
}

fn deriveFilename(name: []const u8, strip: []const u8, suffix: []const u8) []const u8 {
    // derive_filename: name must end in ".<strip>"
    const dot_strip = util.concat(&.{ ".", strip });
    if (!util.endsWith(name, dot_strip)) util.die("packfile name '{s}' does not end with '.{s}'", .{ name, strip });
    return util.concat(&.{ name[0 .. name.len - strip.len], suffix });
}

fn optArg(arg: []const u8, name: []const u8) ?[]const u8 {
    // skip_to_optional_arg: "--name" -> "", "--name=x" -> "x"
    if (!util.startsWith(arg, name)) return null;
    const rest = arg[name.len..];
    if (rest.len == 0) return "";
    if (rest[0] == '=') return rest[1..];
    return null;
}

fn haveRepo() bool {
    return repo_mod.repo_ != null;
}

pub fn cmdIndexPack(args: []const []const u8) u8 {
    @import("../promisor.zig").fetch_if_missing = false;
    showUsageIfAsked(args, index_pack_usage);
    var from_stdin = false;
    var fix_thin = false;
    var verify = false;
    var show_stat = false;
    var stat_only = false;
    var strict = false;
    var do_fsck_object = false;
    var check_self_contained = false;
    var fsck_opts = fsck.Options{ .strict = true, .error_func = printMissingGitmodules, .walk = markLink };
    var foreign_nr: u32 = 1;
    var verbose = false;
    var keep_msg: ?[]const u8 = null;
    var promisor_msg: ?[]const u8 = null;
    var progress_title: ?[]const u8 = null;
    var report_eoi = false;
    var show_resolving = false;
    var index_name: ?[]const u8 = null;
    var pack_name: ?[]const u8 = null;
    var opts = pack.IdxOpts{};
    var rev_index = true;
    if (repo_mod.repo_ != null) {
        if (repo_mod.cfg.getInt("pack.indexversion")) |v| {
            if (v > 2) util.die("bad pack.indexVersion={d}", .{v});
            opts.version = @intCast(v);
        }
        if (repo_mod.cfg.getBool("pack.writereverseindex")) |b| rev_index = b;
    }
    if (os.getenv("GIT_TEST_NO_WRITE_REV_INDEX")) |v| {
        if (util.eql(v, "1") or util.eql(v, "true")) rev_index = false;
    }
    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (arg.len > 0 and arg[0] == '-') {
            if (util.eql(arg, "--stdin")) {
                from_stdin = true;
            } else if (util.eql(arg, "--fix-thin")) {
                fix_thin = true;
            } else if (optArg(arg, "--strict")) |m| {
                strict = true;
                do_fsck_object = true;
                fsck.setMsgTypes(&fsck_opts, m);
            } else if (util.eql(arg, "--check-self-contained-and-connected")) {
                strict = true;
                check_self_contained = true;
            } else if (optArg(arg, "--fsck-objects")) |m| {
                do_fsck_object = true;
                fsck.setMsgTypes(&fsck_opts, m);
            } else if (util.eql(arg, "--verify")) {
                verify = true;
            } else if (util.eql(arg, "--verify-stat")) {
                verify = true;
                show_stat = true;
            } else if (util.eql(arg, "--verify-stat-only")) {
                verify = true;
                show_stat = true;
                stat_only = true;
            } else if (optArg(arg, "--keep")) |m| {
                keep_msg = m;
            } else if (optArg(arg, "--promisor")) |m| {
                promisor_msg = m;
            } else if (util.startsWith(arg, "--threads=")) {
                _ = std.fmt.parseInt(u32, arg[10..], 0) catch usageDie(index_pack_usage);
            } else if (util.startsWith(arg, "--pack_header=")) {
                util.die("bad --pack_header: {s}", .{arg[14..]});
            } else if (util.eql(arg, "-v")) {
                verbose = true;
            } else if (util.eql(arg, "--progress-title")) {
                if (progress_title != null or i + 1 >= args.len) usageDie(index_pack_usage);
                i += 1;
                progress_title = args[i];
            } else if (util.eql(arg, "--show-resolving-progress")) {
                show_resolving = true;
            } else if (util.eql(arg, "--report-end-of-input")) {
                report_eoi = true;
            } else if (util.eql(arg, "-o")) {
                if (index_name != null or i + 1 >= args.len) usageDie(index_pack_usage);
                i += 1;
                index_name = args[i];
            } else if (util.startsWith(arg, "--index-version=")) {
                const v = arg[16..];
                var it = std.mem.splitScalar(u8, v, ',');
                const ver = it.next().?;
                opts.version = std.fmt.parseInt(u32, ver, 10) catch util.die("bad {s}", .{arg});
                if (opts.version > 2) util.die("bad {s}", .{arg});
                if (it.next()) |o| {
                    opts.off32_limit = std.fmt.parseInt(u64, o, 0) catch util.die("bad {s}", .{arg});
                }
                if (opts.off32_limit & 0x80000000 != 0) util.die("bad {s}", .{arg});
            } else if (util.startsWith(arg, "--max-input-size=")) {} else if (util.startsWith(arg, "--object-format=")) {
                const f = arg[16..];
                if (!util.eql(f, "sha1")) util.die("unknown hash algorithm '{s}'", .{f});
            } else if (util.eql(arg, "--rev-index")) {
                rev_index = true;
            } else if (util.eql(arg, "--no-rev-index")) {
                rev_index = false;
            } else usageDie(index_pack_usage);
            continue;
        }
        if (pack_name != null) usageDie(index_pack_usage);
        pack_name = arg;
    }
    if (pack_name == null and !from_stdin) usageDie(index_pack_usage);
    if (fix_thin and !from_stdin) util.die("the option '{s}' requires '{s}'", .{ "--fix-thin", "--stdin" });
    if (promisor_msg != null and pack_name != null) util.die("--promisor cannot be used with a pack name", .{});
    if (from_stdin and !haveRepo()) util.die("--stdin requires a git repository", .{});
    // relative paths are relative to the original cwd (prefix)
    if (repo_mod.repo_) |r| {
        if (r.prefix.len > 0) {
            if (pack_name) |p| {
                if (p[0] != '/') pack_name = util.concat(&.{ r.prefix, p });
            }
            if (index_name) |p| {
                if (p[0] != '/') index_name = util.concat(&.{ r.prefix, p });
            }
        }
    }
    if (index_name == null and pack_name != null) index_name = deriveFilename(pack_name.?, "pack", "idx");
    var rev_index_name: ?[]const u8 = null;
    if (rev_index and index_name != null) rev_index_name = deriveFilename(index_name.?, "idx", "rev");

    var existing_idx: ?[]u8 = null;
    if (verify) {
        if (index_name == null) util.die("--verify with no packfile name given", .{});
        existing_idx = os.readFile(index_name.?);
        if (existing_idx) |d| {
            if (d.len >= 8 and std.mem.eql(u8, d[0..4], "\xfftOc")) {
                opts.version = std.mem.readInt(u32, d[4..8], .big);
            } else opts.version = 1;
            if (opts.version == 2 and d.len >= 8 + 1024) {
                // read_v2_anomalous_offsets()
                const n: usize = std.mem.readInt(u32, d[8 + 1020 ..][0..4], .big);
                const t1 = 8 + 1024 + n * 24;
                const t2 = t1 + n * 4;
                var an: std.ArrayList(u64) = .empty;
                var k: usize = 0;
                while (k < n and t1 + k * 4 + 4 <= d.len) : (k += 1) {
                    const off = std.mem.readInt(u32, d[t1 + k * 4 ..][0..4], .big);
                    if (off & 0x80000000 == 0) continue;
                    const p = t2 + @as(usize, off & 0x7fffffff) * 8;
                    if (p + 8 > d.len) continue;
                    const v = std.mem.readInt(u64, d[p..][0..8], .big);
                    if (v >> 32 != 0) continue;
                    an.append(gpa, v) catch util.oom();
                }
                std.mem.sort(u64, an.items, {}, std.sort.asc(u64));
                opts.anomaly = an.items;
            }
        }
        opts.strict = true;
    }
    if (strict) opts.strict = true;

    // ---- read the pack
    var in: pack.Input = undefined;
    var out_fd: c_int = -1;
    var curr_pack: []const u8 = "";
    if (from_stdin) {
        in = .{ .fd = 0 };
        if (pack_name) |p| {
            out_fd = os.openFile(p, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600);
            if (out_fd < 0) util.dieErrno("could not open '{s}'", .{p});
            curr_pack = p;
        } else {
            const odb = repo_mod.repo().odb();
            const pdir = util.concat(&.{ odb.objects_dir, "/pack" });
            _ = os.mkdirAll(pdir);
            const t = os.tmpFile(pdir, "tmp_pack_");
            if (t.fd < 0) util.dieErrno("unable to create temporary file", .{});
            out_fd = t.fd;
            curr_pack = t.path;
        }
    } else {
        const d = os.readFile(pack_name.?) orelse util.dieErrno("could not open '{s}'", .{pack_name.?});
        in = pack.Input.fromBytes(d);
        curr_pack = pack_name.?;
    }
    const hdr = pack.readHeader(&in);
    var prog: ?*progress.Progress = null;
    if (verbose) prog = progress.start(progress_title orelse if (from_stdin) "Receiving objects" else "Indexing objects", hdr.nr);
    var res = pack.Resolver{};
    var nr_ofs: u32 = 0;
    var nr_ref: u32 = 0;
    var n: u32 = 0;
    while (n < hdr.nr) : (n += 1) {
        const e = pack.readEntry(&in);
        if (e.typ == .ofs_delta) nr_ofs += 1;
        if (e.typ == .ref_delta) nr_ref += 1;
        res.add(e);
        progress.update(prog, n + 1);
    }
    const end_of_objects = in.pos;
    var pack_sha = pack.readTrailer(&in);
    if (prog) |p| p.stop();
    prog = null;
    if (!from_stdin and in.pos != in.data.items.len) util.die("pack has junk at the end", .{});
    if (report_eoi) util.ewrite("\x00");
    const pack_bytes_len = in.pos;

    // ---- resolve deltas
    const nr_deltas = nr_ofs + nr_ref;
    if (nr_deltas > 0 and (verbose or show_resolving)) prog = progress.start("Resolving deltas", nr_deltas);
    var unresolved = res.resolveAll();
    var appended: std.ArrayList(u32) = .empty;
    if (unresolved > 0 and fix_thin) {
        var tried: hash.OidSet = .empty;
        const odb = repo_mod.repo().odb();
        while (unresolved > 0) {
            const base = res.firstMissingBase(&tried) orelse break;
            tried.put(gpa, base, {}) catch util.oom();
            const o = odb.read(base) orelse continue;
            if (!hash.eql(odb_mod.hashObject(o.typ, o.data), base)) util.die("local object {s} is corrupt", .{hash.hex(base)});
            const idx = res.addExternal(o.typ, @constCast(o.data));
            appended.append(gpa, idx) catch util.oom();
            unresolved = res.resolveAll();
        }
    }
    if (prog) |p| {
        progress.update(p, nr_deltas - unresolved);
        if (appended.items.len > 0) {
            p.stopMsg(util.fmt("completed with {d} local object{s}", .{ appended.items.len, if (appended.items.len == 1) "" else "s" }));
        } else p.stop();
    }
    if (unresolved > 0) util.die("pack has {d} unresolved delta{s}", .{ unresolved, if (unresolved == 1) "" else "s" });

    const total: usize = res.entries.items.len;
    // offsets/crcs of appended objects; build final pack bytes for stdin
    if (from_stdin) {
        var final_pack: util.Buf = .empty;
        if (appended.items.len > 0) {
            util.bufAppend(&final_pack, in.data.items[0..end_of_objects]);
            std.mem.writeInt(u32, final_pack.items[8..12], @intCast(total), .big);
            const level = pack.packCompressionLevel();
            for (appended.items) |ai| {
                const e = &res.entries.items[ai];
                const bytes = pack.encodeFullEntry(e.typ, e.data, level);
                e.offset = final_pack.items.len;
                e.crc = zlib.crc(0, bytes);
                util.bufAppend(&final_pack, bytes);
                e.end = final_pack.items.len;
            }
            pack_sha = hash.hashData(final_pack.items);
            util.bufAppend(&final_pack, &pack_sha);
        } else {
            util.bufAppend(&final_pack, in.data.items[0..pack_bytes_len]);
        }
        os.writeAll(out_fd, final_pack.items) catch util.dieErrno("write error", .{});
    }

    // ---- collision check against existing objects
    if (repo_mod.repo_ != null) {
        const odb = repo_mod.repo().odb();
        for (res.entries.items, 0..) |_, k| {
            if (std.mem.indexOfScalar(u32, appended.items, @intCast(k)) != null) continue;
            const oid = res.oids.items[k];
            if (!odb.has(oid)) continue;
            const data = res.get(@intCast(k)) orelse continue;
            const o = odb.read(oid) orelse util.die("cannot read existing object {s}", .{hash.hex(oid)});
            if (o.typ != res.types.items[k] or !std.mem.eql(u8, o.data, data))
                util.die("SHA1 COLLISION FOUND WITH {s} !", .{hash.hex(oid)});
        }
    }

    // ---- fsck checks (sha1_object) and link check (check_objects)
    if (strict or do_fsck_object) {
        for (res.entries.items, 0..) |e, k| {
            if (pack.isDelta(e.typ)) continue;
            if (std.mem.indexOfScalar(u32, appended.items, @intCast(k)) != null) continue;
            sha1Object(&res, @intCast(k), strict, do_fsck_object, &fsck_opts);
        }
        for (res.entries.items, 0..) |e, k| {
            if (!pack.isDelta(e.typ)) continue;
            sha1Object(&res, @intCast(k), strict, do_fsck_object, &fsck_opts);
        }
    }
    if (strict) foreign_nr = checkLinkedObjects();

    if (show_stat) showPackInfo(&res, stat_only, nr_deltas);

    // ---- index
    var ient = gpa.alloc(pack.IdxEntry, total) catch util.oom();
    for (res.entries.items, 0..) |e, k| ient[k] = .{ .oid = res.oids.items[k], .offset = e.offset, .crc = e.crc };
    const idx_data = pack.buildIdx(ient, pack_sha, opts);
    const rev_data: ?[]u8 = if (rev_index) pack.buildRev(ient, pack_sha) else null;

    if (verify) {
        if (existing_idx == null or !std.mem.eql(u8, existing_idx.?, idx_data))
            util.die("sha1 file '{s}' validation error", .{index_name.?});
        if (do_fsck_object) finishFsck(&fsck_opts, null, null);
        return if (check_self_contained and foreign_nr > 0) 1 else 0;
    }

    if (from_stdin) os.close(out_fd);
    const hex = hash.hex(pack_sha);
    var report: []const u8 = "pack";
    const odb_pack_dir: []const u8 = if (repo_mod.repo_) |r| util.concat(&.{ r.odb().objects_dir, "/pack/pack-", &hex, "." }) else "";
    if (keep_msg) |m| {
        const kname = if (pack_name) |p| deriveFilename(p, "pack", "keep") else util.concat(&.{ odb_pack_dir, "keep" });
        if (writeSpecial(kname, m)) report = "keep";
    }
    if (promisor_msg) |m| {
        const pname = util.concat(&.{ odb_pack_dir, "promisor" });
        _ = writeSpecial(pname, m);
    }
    // pack
    if (pack_name == null) {
        const final = util.concat(&.{ odb_pack_dir, "pack" });
        finalizeFile(curr_pack, final, "pack");
    } else if (from_stdin) {
        _ = os.chmod(pack_name.?, 0o444);
    }
    if (rev_data) |rd| {
        const final = rev_index_name orelse util.concat(&.{ odb_pack_dir, "rev" });
        writeIdxLike(final, rd);
    }
    {
        const final = index_name orelse util.concat(&.{ odb_pack_dir, "idx" });
        writeIdxLike(final, idx_data);
    }
    if (!from_stdin) {
        util.outf("{s}\n", .{hex});
    } else {
        util.outf("{s}\t{s}\n", .{ report, hex });
        util.flushStdout();
        os.writeAll(1, in.data.items[in.pos..]) catch {};
    }
    if (do_fsck_object) finishFsck(&fsck_opts, index_name orelse util.concat(&.{ odb_pack_dir, "idx" }), pack_name orelse util.concat(&.{ odb_pack_dir, "pack" }));
    if (check_self_contained and foreign_nr > 0) return 1;
    return 0;
}

// ---------------------------------------------------------------- fsck hooks (index-pack)

const FLAG_LINK: u32 = 1 << 20;
const FLAG_CHECKED: u32 = 1 << 21;

/// mark_link(): fsck walk callback recording objects referenced by the pack.
fn markLink(obj: ?*fsck.Obj, typ: ?ObjType, _: ?*fsck.Obj, _: *fsck.Options) i32 {
    const ob = obj orelse return -1;
    if (typ) |t| {
        if (ob.typ != t) util.die("object type mismatch at {s}", .{&hash.hex(ob.oid)});
    }
    ob.flags |= FLAG_LINK;
    return 0;
}

/// fsck_objects_error_cb_print_missing_gitmodules()
fn printMissingGitmodules(o: *fsck.Options, oid: ?Oid, typ: ObjType, mt: fsck.MsgType, id: fsck.MsgId, msg: []const u8) i32 {
    if (id == .gitmodules_missing) {
        if (oid) |x| util.outf("{s}\n", .{&hash.hex(x)});
        return 0;
    }
    return fsck.objectsErrorFunction(o, oid, typ, mt, id, msg);
}

/// The strict/fsck part of sha1_object().
fn sha1Object(res: *pack.Resolver, k: u32, strict: bool, do_fsck: bool, fo: *fsck.Options) void {
    const data = res.get(k) orelse return;
    const oid = res.oids.items[k];
    const typ = res.types.items[k];
    if (typ == .blob) {
        const b = fsck.lookupTyped(oid, .blob) orelse util.die("invalid blob object {s}", .{&hash.hex(oid)});
        b.flags |= FLAG_CHECKED;
        if (do_fsck and fsck.fsckObject(b, data, fo) != 0) util.die("fsck error in packed object", .{});
        return;
    }
    const obj = fsck.parseObjectBuffer(oid, typ, data) orelse util.die("invalid {s}", .{typ.name()});
    if (do_fsck and fsck.fsckObject(obj, data, fo) != 0) util.die("fsck error in packed object", .{});
    if (strict and fsck.fsckWalk(obj, null, fo) != 0)
        util.die("Not all child objects of {s} are reachable", .{&hash.hex(obj.oid)});
    obj.flags |= FLAG_CHECKED;
}

/// check_objects(): every linked object must be in the pack or the odb.
fn checkLinkedObjects() u32 {
    var foreign: u32 = 0;
    for (fsck.obj_hash) |slot| {
        const obj = slot orelse continue;
        if (obj.flags & FLAG_LINK == 0 or obj.flags & FLAG_CHECKED != 0) continue;
        const t = fsck.readObjectType(obj.oid) orelse util.die("did not receive expected object {s}", .{&hash.hex(obj.oid)});
        if (t != obj.typ) util.die("object {s}: expected type {s}, found {s}", .{ &hash.hex(obj.oid), obj.typ.name(), t.name() });
        obj.flags |= FLAG_CHECKED;
        foreign += 1;
    }
    return foreign;
}

fn hasQueuedChecks(fo: *fsck.Options) bool {
    for (fo.gitmodules_found.list.items) |x| {
        if (!fo.gitmodules_done.contains(x)) return true;
    }
    for (fo.gitattributes_found.list.items) |x| {
        if (!fo.gitattributes_done.contains(x)) return true;
    }
    return false;
}

/// Queued (.gitmodules/.gitattributes) checks after the pack is in place.
fn finishFsck(fo: *fsck.Options, idx_path: ?[]const u8, pack_path: ?[]const u8) void {
    if (!haveRepo()) {
        if (hasQueuedChecks(fo)) util.die("cannot perform queued object checks outside of a repository", .{});
    } else {
        const odb = repo_mod.repo().odb();
        odb.reloadPacks();
        if (idx_path != null and pack_path != null) {
            var known = false;
            for (odb.packs.items) |p| {
                if (util.eql(p.idx_path, idx_path.?)) known = true;
            }
            if (!known) {
                if (odb_mod.openIdx(idx_path.?, pack_path.?)) |p| odb.packs.insert(gpa, 0, p) catch util.oom();
            }
        }
    }
    if (fsck.fsckFinish(fo) != 0) util.die("fsck error in pack objects", .{});
    util.flushStdout();
}

fn writeIdxLike(path: []const u8, data: []const u8) void {
    _ = os.unlink(path);
    pack.writeNewFile(path, data, 0o444);
}

fn finalizeFile(tmp: []const u8, final: []const u8, ext: []const u8) void {
    _ = os.chmod(tmp, 0o444);
    if (os.exists(final)) {
        // finalize_object_file: existing file is kept
        _ = os.unlink(tmp);
        return;
    }
    if (!os.link(tmp, final)) {
        if (!os.rename(tmp, final)) util.die("unable to rename temporary '*.{s}' file to '{s}'", .{ ext, final });
        return;
    }
    _ = os.unlink(tmp);
}

fn writeSpecial(path: []const u8, msg: []const u8) bool {
    _ = os.mkdirLeading(path);
    const fd = os.openFile(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666);
    if (fd < 0) {
        if (os.errno() != os.EEXIST) util.dieErrno("cannot write {s} file '{s}'", .{ util.basename(path), path });
        return false;
    }
    if (msg.len > 0) {
        os.writeAll(fd, msg) catch {};
        os.writeAll(fd, "\n") catch {};
    }
    os.close(fd);
    return true;
}

fn showPackInfo(res: *pack.Resolver, stat_only: bool, nr_deltas: u32) void {
    const total = res.entries.items.len;
    var deepest: u32 = 0;
    for (res.entries.items, 0..) |e, k| {
        if (pack.isDelta(e.typ)) deepest = @max(deepest, res.depth.items[k]);
    }
    const hist = gpa.alloc(u64, deepest + 1) catch util.oom();
    @memset(hist, 0);
    for (res.entries.items, 0..) |e, k| {
        if (pack.isDelta(e.typ)) hist[res.depth.items[k] - 1] += 1;
        if (stat_only) continue;
        const sz_in_pack = e.end - e.offset;
        util.outf("{s} {s: <6} {d} {d} {d}", .{ hash.hex(res.oids.items[k]), res.types.items[k].name(), e.size, sz_in_pack, e.offset });
        if (pack.isDelta(e.typ)) {
            util.outf(" {d} {s}", .{ res.depth.items[k], hash.hex(res.oids.items[res.base_idx.items[k]]) });
        }
        util.outf("\n", .{});
    }
    const base_objects = total - nr_deltas;
    if (base_objects > 0) util.outf("non delta: {d} object{s}\n", .{ base_objects, if (base_objects == 1) "" else "s" });
    var d: u32 = 0;
    while (d < deepest) : (d += 1) {
        if (hist[d] == 0) continue;
        util.outf("chain length = {d}: {d} object{s}\n", .{ d + 1, hist[d], if (hist[d] == 1) "" else "s" });
    }
}

// ---------------------------------------------------------------- verify-pack

const verify_pack_usage = [_][]const u8{"git verify-pack [-v | --verbose] [-s | --stat-only] [--] <pack>.idx..."};

pub fn cmdVerifyPack(args: []const []const u8) u8 {
    var verbose = false;
    var stat_only = false;
    var object_format: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.boolean('v', "verbose", &verbose, "verbose"),
        po.boolean('s', "stat-only", &stat_only, "show statistics only"),
        po.string(0, "object-format", &object_format, "hash", "specify the hash algorithm to use"),
    };
    const rest = po.parse(args[1..], &options, &verify_pack_usage, .{});
    if (rest.len < 1) po.usageWithOptions(&verify_pack_usage, &options);
    var err: u8 = 0;
    for (rest) |path| {
        var a = path;
        if (util.endsWith(a, ".idx")) {
            a = util.concat(&.{ a[0 .. a.len - 4], ".pack" });
        } else if (!util.endsWith(a, ".pack")) a = util.concat(&.{ a, ".pack" });
        var argv: std.ArrayList([]const u8) = .empty;
        argv.appendSlice(gpa, &.{ proc.gitBinary(), "index-pack" }) catch util.oom();
        argv.append(gpa, if (stat_only) "--verify-stat-only" else if (verbose) "--verify-stat" else "--verify") catch util.oom();
        if (object_format) |f| argv.append(gpa, util.concat(&.{ "--object-format=", f })) catch util.oom();
        argv.append(gpa, a) catch util.oom();
        const r = os.run(argv.items, .{});
        const failed = r.signaled or r.status != 0;
        if (verbose or stat_only) {
            if (failed) {
                util.outf("{s}: bad\n", .{a});
            } else if (!stat_only) util.outf("{s}: ok\n", .{a});
        }
        if (failed) err = 1;
    }
    return err;
}

// ---------------------------------------------------------------- show-index

const show_index_usage = [_][]const u8{"git show-index [--object-format=<hash-algorithm>] < <pack-idx-file>"};

pub fn cmdShowIndex(args: []const []const u8) u8 {
    var object_format: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.string(0, "object-format", &object_format, "hash-algorithm", "specify the hash algorithm to use"),
    };
    _ = po.parse(args[1..], &options, &show_index_usage, .{});
    if (object_format) |f| {
        if (!util.eql(f, "sha1")) util.die("Unknown hash algorithm", .{});
    } else if (repo_mod.repo_ == null) {
        util.warn("assuming SHA-1; use --object-format to override", .{});
    }
    const data = os.readAllFd(0) catch util.die("unable to read header", .{});
    var pos: usize = 0;
    if (data.len < 8) util.die("unable to read header", .{});
    var version: u32 = 1;
    var fan: [256]u32 = undefined;
    if (std.mem.eql(u8, data[0..4], "\xfftOc")) {
        version = std.mem.readInt(u32, data[4..8], .big);
        if (version != 2) util.die("unknown index version", .{});
        pos = 8;
    }
    if (data.len < pos + 1024) util.die("unable to read index", .{});
    for (&fan, 0..) |*f, k| f.* = std.mem.readInt(u32, data[pos + 4 * k ..][0..4], .big);
    pos += 1024;
    var nr: u32 = 0;
    for (fan) |f| {
        if (f < nr) util.die("corrupt index file", .{});
        nr = f;
    }
    if (version == 1) {
        var k: u32 = 0;
        while (k < nr) : (k += 1) {
            if (data.len < pos + 24) util.die("unable to read entry {d}/{d}", .{ k, nr });
            const off = std.mem.readInt(u32, data[pos..][0..4], .big);
            util.outf("{d} {s}\n", .{ off, hash.hex(data[pos + 4 ..][0..20].*) });
            pos += 24;
        }
        return 0;
    }
    const oids_at = pos;
    if (data.len < pos + 20 * @as(usize, nr)) util.die("unable to read sha1 {d}/{d}", .{ (data.len - pos) / 20, nr });
    pos += 20 * @as(usize, nr);
    const crc_at = pos;
    if (data.len < pos + 4 * @as(usize, nr)) util.die("unable to read crc {d}/{d}", .{ (data.len - pos) / 4, nr });
    pos += 4 * @as(usize, nr);
    const off_at = pos;
    if (data.len < pos + 4 * @as(usize, nr)) util.die("unable to read 32b offset {d}/{d}", .{ (data.len - pos) / 4, nr });
    pos += 4 * @as(usize, nr);
    var off64_nr: u32 = 0;
    var k: usize = 0;
    while (k < nr) : (k += 1) {
        const off = std.mem.readInt(u32, data[off_at + 4 * k ..][0..4], .big);
        var offset: u64 = off;
        if (off & 0x80000000 != 0) {
            if ((off & 0x7fffffff) != off64_nr) util.die("inconsistent 64b offset index", .{});
            if (data.len < pos + 8) util.die("unable to read 64b offset {d}", .{off64_nr});
            offset = std.mem.readInt(u64, data[pos..][0..8], .big);
            pos += 8;
            off64_nr += 1;
        }
        const crc = std.mem.readInt(u32, data[crc_at + 4 * k ..][0..4], .big);
        util.outf("{d} {s} ({x:0>8})\n", .{ offset, hash.hex(data[oids_at + 20 * k ..][0..20].*), crc });
    }
    return 0;
}

// ---------------------------------------------------------------- unpack-objects

const unpack_usage = "git unpack-objects [-n] [-q] [-r] [--strict]";

const UpDelta = struct { nr: u32, base_oid: Oid, base_offset: u64, delta: []u8 };

const FLAG_OPEN: u32 = 1 << 20;
const FLAG_WRITTEN: u32 = 1 << 21;

/// --strict: structured objects held in core until their links are verified.
var held_buffers: hash.OidMap([]u8) = .empty;
var unpack_fsck_opts = fsck.Options{ .strict = true };

/// check_object(): verify reachability/validity recursively, then write.
fn unpackCheckObject(obj0: ?*fsck.Obj, typ: ?ObjType, _: ?*fsck.Obj, _: *fsck.Options) i32 {
    const obj = obj0 orelse return 1;
    if (obj.flags & FLAG_WRITTEN != 0) return 0;
    if (typ) |t| {
        if (obj.typ != t) util.die("object type mismatch", .{});
    }
    if (obj.flags & FLAG_OPEN == 0) {
        const t = fsck.readObjectType(obj.oid);
        if (t == null or t.? != obj.typ) util.die("object of unexpected type", .{});
        obj.flags |= FLAG_WRITTEN;
        return 0;
    }
    const buf = held_buffers.get(obj.oid) orelse util.die("Whoops! Cannot find object '{s}'", .{&hash.hex(obj.oid)});
    if (fsck.fsckObject(obj, buf, &unpack_fsck_opts) != 0) util.die("fsck error in packed object", .{});
    unpack_fsck_opts.walk = unpackCheckObject;
    if (fsck.fsckWalk(obj, null, &unpack_fsck_opts) != 0) util.die("Error on reachable objects of {s}", .{&hash.hex(obj.oid)});
    _ = repo_mod.repo().odb().write(obj.typ, buf);
    obj.flags |= FLAG_WRITTEN;
    return 0;
}

const Unpacker = struct {
    in: pack.Input,
    dry_run: bool = false,
    recover: bool = false,
    has_errors: bool = false,
    offsets: []u64 = &.{},
    oids: []Oid = &.{},
    valid: []bool = &.{},
    deltas: std.ArrayList(UpDelta) = .empty,
    strict: bool = false,
    objs: []?*fsck.Obj = &.{},

    fn getData(u: *Unpacker, size: usize) ?[]u8 {
        const r = u.in.inflateGently(size);
        if (r.data == null) {
            util.err("inflate returned {d}", .{r.ret});
            if (!u.recover) os.exit(1);
            u.has_errors = true;
            return null;
        }
        if (u.dry_run) return null;
        return r.data;
    }

    fn writeObject(u: *Unpacker, nr: u32, typ: ObjType, buf: []u8) void {
        const odb = repo_mod.repo().odb();
        if (!u.strict) {
            u.oids[nr] = odb.write(typ, buf);
            u.valid[nr] = true;
            u.addedObject(nr, typ, buf);
        } else if (typ == .blob) {
            u.oids[nr] = odb.write(typ, buf);
            u.valid[nr] = true;
            u.addedObject(nr, typ, buf);
            const b = fsck.lookupTyped(u.oids[nr], .blob) orelse util.die("invalid blob object", .{});
            b.flags |= FLAG_WRITTEN;
        } else {
            const oid = odb_mod.hashObject(typ, buf);
            u.oids[nr] = oid;
            u.valid[nr] = true;
            u.addedObject(nr, typ, buf);
            const obj = fsck.parseObjectBuffer(oid, typ, buf) orelse util.die("invalid {s}", .{typ.name()});
            held_buffers.put(gpa, oid, buf) catch util.oom();
            obj.flags |= FLAG_OPEN;
            u.objs[nr] = obj;
        }
    }

    /// resolve_against_held()
    fn resolveAgainstHeld(u: *Unpacker, nr: u32, base: Oid, delta: []const u8) bool {
        const obj = fsck.lookupObject(base) orelse return false;
        const buf = held_buffers.get(base) orelse return false;
        u.resolveDelta(nr, obj.typ, buf, delta);
        return true;
    }

    fn addedObject(u: *Unpacker, nr: u32, typ: ObjType, data: []u8) void {
        var i: usize = 0;
        while (i < u.deltas.items.len) {
            const d = u.deltas.items[i];
            const match = (d.base_offset == 0 and hash.eql(d.base_oid, u.oids[nr])) or
                (d.base_offset != 0 and d.base_offset == u.offsets[nr]);
            if (match) {
                _ = u.deltas.orderedRemove(i);
                u.resolveDelta(d.nr, typ, data, d.delta);
                i = 0;
                continue;
            }
            i += 1;
        }
    }

    fn resolveDelta(u: *Unpacker, nr: u32, typ: ObjType, base: []const u8, delta: []const u8) void {
        const result = odb_mod.applyDelta(base, delta) orelse util.die("failed to apply delta", .{});
        u.writeObject(nr, typ, result);
    }

    fn unpackDelta(u: *Unpacker, typ: ObjType, size: usize, nr: u32) void {
        const odb = repo_mod.repo().odb();
        var base_oid: Oid = undefined;
        if (typ == .ref_delta) {
            u.in.fill(20);
            base_oid = u.in.data.items[u.in.pos..][0..20].*;
            u.in.pos += 20;
            const delta = u.getData(size) orelse return;
            if (!odb.has(base_oid)) {
                if (u.resolveAgainstHeld(nr, base_oid, delta)) return;
                u.valid[nr] = false;
                u.deltas.append(gpa, .{ .nr = nr, .base_oid = base_oid, .base_offset = 0, .delta = delta }) catch util.oom();
                return;
            }
            u.resolveFromOdb(nr, base_oid, delta);
        } else {
            var c = u.in.byte();
            var ofs: u64 = c & 127;
            while (c & 128 != 0) {
                ofs += 1;
                if (ofs == 0 or (ofs >> 57) != 0) util.die("offset value overflow for delta base object", .{});
                c = u.in.byte();
                ofs = (ofs << 7) + (c & 127);
            }
            if (ofs == 0 or ofs >= u.offsets[nr]) util.die("offset value out of bound for delta base object", .{});
            const base_offset = u.offsets[nr] - ofs;
            const delta = u.getData(size) orelse return;
            // binary search for the base among earlier entries
            var lo: usize = 0;
            var hi: usize = nr;
            var found = false;
            while (lo < hi) {
                const mid = lo + (hi - lo) / 2;
                if (base_offset < u.offsets[mid]) {
                    hi = mid;
                } else if (base_offset > u.offsets[mid]) {
                    lo = mid + 1;
                } else {
                    base_oid = u.oids[mid];
                    found = u.valid[mid];
                    break;
                }
            }
            if (!found) {
                u.valid[nr] = false;
                u.deltas.append(gpa, .{ .nr = nr, .base_oid = hash.zero, .base_offset = base_offset, .delta = delta }) catch util.oom();
                return;
            }
            u.resolveFromOdb(nr, base_oid, delta);
        }
    }

    fn resolveFromOdb(u: *Unpacker, nr: u32, base_oid: Oid, delta: []u8) void {
        if (u.resolveAgainstHeld(nr, base_oid, delta)) return;
        const base = repo_mod.repo().odb().read(base_oid) orelse {
            util.err("failed to read delta-pack base object {s}", .{hash.hex(base_oid)});
            if (!u.recover) os.exit(1);
            u.has_errors = true;
            return;
        };
        u.resolveDelta(nr, base.typ, base.data, delta);
    }

    fn unpackOne(u: *Unpacker, nr: u32) void {
        u.offsets[nr] = u.in.pos;
        var c = u.in.byte();
        const t: u3 = @intCast((c >> 4) & 7);
        var size: usize = c & 15;
        var shift: u6 = 4;
        while (c & 0x80 != 0) {
            if (shift > 57) util.die("object size too large for this platform", .{});
            c = u.in.byte();
            size +%= @as(usize, c & 0x7f) << shift;
            shift += 7;
        }
        const typ: ObjType = @enumFromInt(t);
        switch (typ) {
            .commit, .tree, .blob, .tag => {
                const buf = u.getData(size) orelse return;
                u.writeObject(nr, typ, buf);
            },
            .ref_delta, .ofs_delta => u.unpackDelta(typ, size, nr),
            else => {
                util.err("bad object type {d}", .{t});
                u.has_errors = true;
                if (u.recover) return;
                os.exit(1);
            },
        }
    }
};

pub fn cmdUnpackObjects(args: []const []const u8) u8 {
    var u = Unpacker{ .in = .{ .fd = 0 } };
    var quiet = !os.isatty(2);
    showUsageIfAsked(args, unpack_usage);
    for (args[1..]) |arg| {
        if (arg.len > 0 and arg[0] == '-') {
            if (util.eql(arg, "-n")) {
                u.dry_run = true;
                continue;
            }
            if (util.eql(arg, "-q")) {
                quiet = true;
                continue;
            }
            if (util.eql(arg, "-r")) {
                u.recover = true;
                continue;
            }
            if (util.eql(arg, "--strict")) {
                u.strict = true;
                continue;
            }
            if (util.skipPrefix(arg, "--strict=")) |m| {
                u.strict = true;
                fsck.setMsgTypes(&unpack_fsck_opts, m);
                continue;
            }
            if (util.startsWith(arg, "--pack_header=")) {
                const h = pack.parsePackHeaderOption(arg[14..]) orelse util.die("bad --pack_header: {s}", .{arg[14..]});
                u.in.data.appendSlice(gpa, &h) catch util.oom();
                continue;
            }
            if (util.startsWith(arg, "--max-input-size=")) continue;
            usageDie(unpack_usage);
        }
        usageDie(unpack_usage);
    }
    u.in.fill(12);
    const h = u.in.data.items[0..12];
    if (!std.mem.eql(u8, h[0..4], "PACK")) util.die("bad pack file", .{});
    const ver = std.mem.readInt(u32, h[4..8], .big);
    if (ver != 2 and ver != 3) util.die("unknown pack file version {d}", .{ver});
    const nr = std.mem.readInt(u32, h[8..12], .big);
    u.in.pos = 12;
    u.offsets = gpa.alloc(u64, nr) catch util.oom();
    u.oids = gpa.alloc(Oid, nr) catch util.oom();
    u.valid = gpa.alloc(bool, nr) catch util.oom();
    @memset(u.valid, false);
    u.objs = gpa.alloc(?*fsck.Obj, nr) catch util.oom();
    @memset(u.objs, null);
    var prog: ?*progress.Progress = null;
    if (!quiet) prog = progress.start("Unpacking objects", nr);
    var k: u32 = 0;
    while (k < nr) : (k += 1) {
        u.unpackOne(k);
        progress.update(prog, k + 1);
    }
    if (prog) |p| p.stop();
    if (u.deltas.items.len > 0) util.die("unresolved deltas left after unpacking", .{});
    const sum = hash.hashData(u.in.data.items[0..u.in.pos]);
    if (u.strict) {
        for (u.objs) |o| {
            if (o) |obj| _ = unpackCheckObject(obj, null, null, &unpack_fsck_opts);
        }
        if (fsck.fsckFinish(&unpack_fsck_opts) != 0) util.die("fsck error in pack objects", .{});
    }
    u.in.fill(20);
    if (!std.mem.eql(u8, u.in.data.items[u.in.pos..][0..20], &sum)) util.die("final sha1 did not match", .{});
    u.in.pos += 20;
    os.writeAll(1, u.in.data.items[u.in.pos..]) catch {};
    return @intFromBool(u.has_errors);
}
