//! git last-modified (port of builtin/last-modified.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const revision = @import("../revision.zig");
const cn = @import("../commitnode.zig");
const commitreach = @import("../commitreach.zig");
const diff = @import("../diff.zig");
const treediff = @import("../treediff.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Commit = cn.Commit;

const usage = [_][]const u8{
    "git last-modified [--recursive] [--show-trees] [--max-depth=<depth>] [-z]\n" ++
        "                  [<revision-range>] [[--] <pathspec>...]",
};

const Entry = struct {
    path: []const u8,
    oid: Oid,
    idx: usize = 0,
    hash: u32,
    next: ?*Entry = null,
};

fn strhash(s: []const u8) u32 {
    var h: u32 = 0x811c9dc5;
    for (s) |c| h = (h *% 0x01000193) ^ c;
    return h;
}

/// Emulation of git's hashmap insertion order (for iteration order).
const OrderMap = struct {
    table: []?*Entry,
    count: usize = 0,

    fn init() OrderMap {
        const t = gpa.alloc(?*Entry, 64) catch util.oom();
        @memset(t, null);
        return .{ .table = t };
    }
    fn add(m: *OrderMap, e: *Entry) void {
        const b = e.hash & @as(u32, @intCast(m.table.len - 1));
        e.next = m.table[b];
        m.table[b] = e;
        m.count += 1;
        if (m.count > m.table.len * 80 / 100) m.rehash(m.table.len << 2);
    }
    fn rehash(m: *OrderMap, size: usize) void {
        const old = m.table;
        m.table = gpa.alloc(?*Entry, size) catch util.oom();
        @memset(m.table, null);
        for (old) |head| {
            var e = head;
            while (e) |ent| {
                const nx = ent.next;
                const b = ent.hash & @as(u32, @intCast(size - 1));
                ent.next = m.table[b];
                m.table[b] = ent;
                e = nx;
            }
        }
    }
};

const State = struct {
    paths: std.StringHashMap(*Entry),
    all_paths: []*Entry = &.{},
    nul: bool = false,
    active: std.AutoHashMap(*Commit, []bool),
    out: *util.Out,
};

fn activeFor(st: *State, c: *Commit) []bool {
    const gop = st.active.getOrPut(c) catch util.oom();
    if (!gop.found_existing) {
        const b = gpa.alloc(bool, st.all_paths.len) catch util.oom();
        @memset(b, false);
        gop.value_ptr.* = b;
    }
    return gop.value_ptr.*;
}

fn activeFree(st: *State, c: *Commit) void {
    if (st.active.fetchRemove(c)) |kv| gpa.free(kv.value);
}

fn isEmpty(b: []const bool) bool {
    for (b) |x| if (x) return false;
    return true;
}

fn emit(st: *State, path: []const u8, c: *const Commit) void {
    const f = st.out;
    if (c.obj.flags & cn.BOUNDARY != 0) f.byte('^');
    f.write(&hash.hex(c.obj.oid));
    f.byte('\t');
    if (st.nul) {
        f.write(path);
        f.byte(0);
    } else diff.writeNameQuoted(f, path, '\n');
}

fn markPath(st: *State, path: []const u8, oid: ?Oid, c: *const Commit) void {
    const ent = st.paths.get(path) orelse return;
    if (oid) |o| if (!std.mem.eql(u8, &o, &ent.oid)) return;
    emit(st, path, c);
    _ = st.paths.remove(path);
}

pub fn cmdLastModified(args: []const []const u8) u8 {
    var max_depth: i32 = 0;
    var show_trees = false;
    var nul = false;
    const options = [_]po.Opt{
        po.setInt('r', "recursive", &max_depth, -1, "recurse into subtrees"),
        po.boolean('t', "show-trees", &show_trees, "show tree entries when recursing into subtrees"),
        .{ .long = "max-depth", .kind = .int, .i = &max_depth, .argh = "n", .noneg = true, .help = "maximum tree depth to recurse" },
        po.boolean('z', "", &nul, "lines are separated with NUL character"),
    };
    const rest = po.parse(args[1..], &options, &usage, .{ .keep_unknown = true, .keep_dashdash = true });

    const revs = gpa.create(revision.RevInfo) catch util.oom();
    revs.* = revision.RevInfo.init(repo_mod.repo().prefix);
    const o = gpa.create(diff.DiffOptions) catch util.oom();
    o.* = diff.DiffOptions.initBasic();
    diff.setupRevDiffWith(revs, o);
    revs.combine_merges = true;
    revs.show_root_diff = true;
    revs.boundary = 1;
    revs.no_commit_id = true;
    revs.diff = true;
    revs.diff_recursive = true;
    revs.diff_tree_in_recursive = show_trees;
    o.flags.recursive = true;
    o.flags.tree_in_recursive = show_trees;
    o.max_depth = max_depth;
    o.max_depth_valid = max_depth >= 0;

    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "last-modified") catch util.oom();
    argv.appendSlice(gpa, rest) catch util.oom();
    const left = revision.setupRevisions(revs, argv.items, .{ .def = "HEAD" });
    if (left.len > 1) {
        util.err("unknown last-modified argument: {s}", .{left[1]});
        po.usageWithOptions(&usage, &options);
    }
    o.flags.recursive = true;
    o.flags.tree_in_recursive = show_trees;
    o.max_depth = max_depth;
    o.max_depth_valid = max_depth >= 0;
    o.pathspec = revs.prune_data;
    o.output_format = diff.FMT_NO_OUTPUT;

    var st = State{
        .paths = std.StringHashMap(*Entry).init(gpa),
        .active = std.AutoHashMap(*Commit, []bool).init(gpa),
        .nul = nul,
        .out = &util.stdout,
    };

    // populate_paths_from_revs()
    var order = OrderMap.init();
    var num_interesting: usize = 0;
    for (revs.pending.items) |e| {
        if (e.item.flags & cn.UNINTERESTING != 0) continue;
        num_interesting += 1;
        if (num_interesting > 1) {
            util.err("last-modified can only operate on one commit at a time", .{});
            return 255;
        }
        const c = cn.lookupCommitReference(e.item.oid) orelse {
            util.err("revision argument '{s}' is a {s}, not a commit-ish", .{ e.name, e.item.typ.name() });
            return 255;
        };
        if (!cn.parse(c)) util.die("unable to parse commit {s}", .{hash.hex(c.obj.oid)});
        diff.clearQueue();
        treediff.diffTreeOid(null, c.tree, "", o);
        for (diff.queue.items) |p| {
            const ent = gpa.create(Entry) catch util.oom();
            ent.* = .{ .path = util.dupe(p.two.path), .oid = p.two.oid, .hash = strhash(p.two.path) };
            st.paths.put(ent.path, ent) catch util.oom();
            order.add(ent);
        }
        diff.clearQueue();
    }
    var all: std.ArrayList(*Entry) = .empty;
    for (order.table) |head| {
        var e = head;
        while (e) |ent| : (e = ent.next) {
            ent.idx = all.items.len;
            all.append(gpa, ent) catch util.oom();
        }
    }
    st.all_paths = all.items;

    // last_modified_run()
    revs.no_walk = true;
    if (!revision.prepareRevisionWalk(revs)) return 128;
    const max_count = revs.max_count;
    var queue_popped: i32 = 0;
    var queue = cn.PrioQueue{ .compare = commitreach.compareByGenThenDate };
    var not_queue = cn.PrioQueue{ .compare = commitreach.compareByGenThenDate };
    const scratch = gpa.alloc(bool, st.all_paths.len) catch util.oom();
    @memset(scratch, false);

    var list = revs.commits;
    while (list) |l| : (list = l.next) {
        const c = l.item;
        if (c.obj.flags & cn.BOTTOM != 0) {
            not_queue.put(c);
            c.obj.flags |= cn.PARENT2;
        } else if (c.obj.flags & cn.PARENT1 == 0) {
            queue.put(c);
            c.obj.flags |= cn.PARENT1;
            @memset(activeFor(&st, c), true);
        }
    }

    while (queue.get()) |c| {
        const active_c = activeFor(&st, c);
        queue_popped += 1;
        if ((0 <= max_count and max_count < queue_popped) or c.obj.flags & cn.PARENT2 != 0) {
            c.obj.flags |= cn.PARENT2 | cn.BOUNDARY;
            if (cn.parse(c)) {
                diff.clearQueue();
                treediff.diffTreeOid(null, c.tree, "", o);
                for (diff.queue.items) |p| {
                    if (p.two.mode == 0) continue;
                    markPath(&st, p.two.path, p.two.oid, c);
                }
                diff.clearQueue();
            }
            activeFree(&st, c);
            continue;
        }
        if (!cn.parse(c)) {
            activeFree(&st, c);
            continue;
        }
        while (not_queue.get()) |n| {
            if (!cn.parse(n)) continue;
            var np = n.parents;
            while (np) |pl| : (np = pl.next) {
                if (pl.item.obj.flags & cn.PARENT2 == 0) {
                    not_queue.put(pl.item);
                    pl.item.obj.flags |= cn.PARENT2;
                }
            }
            if (commitreach.generation(n) < commitreach.generation(c)) break;
        }

        var p = c.parents;
        while (p) |pl| : (p = pl.next) {
            const parent = pl.item;
            if (cn.parse(parent)) {
                const active_p = activeFor(&st, parent);
                diff.clearQueue();
                treediff.diffTreeOid(parent.tree, c.tree, "", o);
                diff.diffcoreStd(o);
                for (diff.queue.items) |fp| {
                    if (st.paths.get(fp.two.path)) |ent| {
                        if (active_c[ent.idx]) scratch[ent.idx] = true;
                    }
                }
                for (active_c, 0..) |a, i| {
                    if (a and !scratch[i]) {
                        active_c[i] = false;
                        active_p[i] = true;
                    }
                }
                if (!isEmpty(active_p) and parent.obj.flags & cn.PARENT1 == 0) {
                    parent.obj.flags |= cn.PARENT1;
                    queue.put(parent);
                }
                if (parent.obj.flags & cn.PARENT1 == 0) activeFree(&st, parent);
                @memset(scratch, false);
                diff.clearQueue();
            }
            if (isEmpty(active_c)) break;
        }

        if (!isEmpty(active_c)) {
            for (active_c, 0..) |a, i| {
                if (a) markPath(&st, st.all_paths[i].path, null, c);
            }
        }
        activeFree(&st, c);
    }

    if (st.paths.count() != 0) util.die("BUG: paths remaining beyond boundary in last-modified", .{});
    util.flushStdout();
    return 0;
}
