//! git credential / credential-store (builtin/credential.c, builtin/credential-store.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const config = @import("../config.zig");
const repo_mod = @import("../repo.zig");
const lockfile = @import("../lockfile.zig");
const cred = @import("../credential.zig");
const gpa = util.gpa;

extern "c" fn umask(mask: c_uint) c_uint;
extern "c" fn usleep(us: c_uint) c_int;

const credential_usage = "git credential (fill|approve|reject)";

fn usageCred() noreturn {
    util.eprint("usage: {s}\n", .{credential_usage});
    os.exit(129);
}

pub fn cmdCredential(args: []const []const u8) u8 {
    if (args.len == 2 and (util.eql(args[1], "-h") or util.eql(args[1], "--help-all"))) {
        util.outf("usage: {s}\n", .{credential_usage});
        return 0;
    }
    if (args.len != 2) usageCred();
    const op = args[1];
    var c = cred.Credential{};
    if (util.eql(op, "capability")) {
        c.setAllCapabilities(.initial);
        var b: util.Buf = .empty;
        cred.announceCapabilities(&c, &b);
        util.out(b.items);
        return 0;
    }
    var r = cred.Reader{ .fd = 0 };
    if (!cred.read(&c, &r, .initial)) util.die("unable to read credential from stdin", .{});

    if (util.eql(op, "fill")) {
        cred.fill(&c, false);
        c.nextState();
        var w = cred.Writer{ .fd = 1 };
        cred.write(&c, &w, .response);
        util.out(w.buf.items);
    } else if (util.eql(op, "approve")) {
        c.setAllCapabilities(.helper);
        cred.approve(&c);
    } else if (util.eql(op, "reject")) {
        c.setAllCapabilities(.helper);
        cred.reject(&c);
    } else usageCred();
    return 0;
}

// ---------------------------------------------------------------------------
// credential-store

var store_lock: ?*lockfile.Lock = null;

const LineCb = *const fn (line: []const u8) void;

fn printLine(line: []const u8) void {
    const l = store_lock.?;
    os.writeAll(l.fd, line) catch util.dieErrno("write error", .{});
    os.writeAll(l.fd, "\n") catch util.dieErrno("write error", .{});
}

fn printEntry(e: *const cred.Credential) void {
    util.outf("username={s}\n", .{e.username.?});
    util.outf("password={s}\n", .{e.password.?});
}

fn parseCredentialFile(fname: []const u8, c: *const cred.Credential, match_cb: ?*const fn (*const cred.Credential) void, other_cb: ?LineCb, match_password: bool) bool {
    const fd = os.openFile(fname, os.O_RDONLY | os.O_CLOEXEC, 0);
    if (fd < 0) {
        const e = os.errno();
        if (e != os.ENOENT and e != os.EACCES) util.dieErrno("unable to open {s}", .{fname});
        return false;
    }
    defer os.close(fd);
    var found = false;
    var r = cred.Reader{ .fd = fd };
    var entry = cred.Credential{};
    while (r.getlineLf()) |line| {
        if (cred.fromUrlGently(&entry, line, true) and entry.username != null and entry.password != null and
            cred.match(c, &entry, match_password))
        {
            found = true;
            if (match_cb) |m| {
                m(&entry);
                break;
            }
        } else if (other_cb) |o| o(line);
    }
    return found;
}

/// Follow symlinks like lockfile.c's resolve_symlink().
fn resolveSymlink(path: []const u8) []const u8 {
    var p: []const u8 = path;
    var depth: usize = 0;
    while (depth < 5) : (depth += 1) {
        const st = os.lstatPath(p) orelse break;
        if (!st.isLnk()) break;
        const target = os.readLink(p) orelse break;
        if (target.len > 0 and target[0] == '/') {
            p = target;
        } else {
            const d = util.dirname(p);
            p = if (d.len == 0 and !(p.len > 0 and p[0] == '/')) target else util.concat(&.{ d, "/", target });
        }
    }
    return p;
}

fn rewriteCredentialFile(fname: []const u8, c: *const cred.Credential, extra: ?[]const u8, match_password: bool) void {
    var timeout_ms: i64 = 1000;
    if (repo_mod.cfg.getInt("credentialstore.locktimeoutms")) |t| timeout_ms = t;
    const target = resolveSymlink(fname);
    var waited: i64 = 0;
    var delay: i64 = 1;
    while (true) {
        switch (lockfile.tryLock(target)) {
            .ok => |l| {
                store_lock = l;
                break;
            },
            .err => |e| {
                if (e != os.EEXIST or waited >= timeout_ms) {
                    os.setErrno(e);
                    util.dieErrno("unable to get credential storage lock in {d} ms", .{timeout_ms});
                }
                var d = delay;
                if (waited + d > timeout_ms) d = timeout_ms - waited;
                if (d < 1) d = 1;
                _ = usleep(@intCast(d * 1000));
                waited += d;
                if (delay < 1000) delay *= 2;
            },
        }
    }
    if (extra) |x| printLine(x);
    _ = parseCredentialFile(fname, c, null, printLine, match_password);
    if (!store_lock.?.commit()) util.dieErrno("unable to write credential store", .{});
}

fn isUnreserved(ch: u8) bool {
    return std.ascii.isAlphanumeric(ch) or ch == '-' or ch == '_' or ch == '.' or ch == '~';
}

fn isReservedOrUnreserved(ch: u8) bool {
    if (isUnreserved(ch)) return true;
    return std.mem.indexOfScalar(u8, "!*'();:@&=+$,/?#[]", ch) != null;
}

fn urlencode(b: *util.Buf, s: []const u8, allow: *const fn (u8) bool) void {
    for (s) |ch| {
        if (allow(ch)) util.bufByte(b, ch) else util.bufPrint(b, "%{x:0>2}", .{ch});
    }
}

fn storeCredentialFile(fname: []const u8, c: *const cred.Credential) void {
    var b: util.Buf = .empty;
    util.bufPrint(&b, "{s}://", .{c.protocol.?});
    urlencode(&b, c.username.?, isUnreserved);
    util.bufByte(&b, ':');
    urlencode(&b, c.password.?, isUnreserved);
    util.bufByte(&b, '@');
    if (c.host) |h| urlencode(&b, h, isUnreserved);
    if (c.path) |p| {
        util.bufByte(&b, '/');
        urlencode(&b, p, isReservedOrUnreserved);
    }
    rewriteCredentialFile(fname, c, b.items, false);
}

fn storeCredential(fns: []const []const u8, c: *const cred.Credential) void {
    if (c.protocol == null or (c.host == null and c.path == null) or c.username == null or c.password == null) return;
    for (fns) |f| {
        if (os.access(f, 0)) {
            storeCredentialFile(f, c);
            return;
        }
    }
    if (fns.len > 0) storeCredentialFile(fns[0], c);
}

fn removeCredential(fns: []const []const u8, c: *const cred.Credential) void {
    if (c.protocol == null and c.host == null and c.path == null and c.username == null) return;
    for (fns) |f| {
        if (os.access(f, 0)) rewriteCredentialFile(f, c, null, true);
    }
}

fn lookupCredential(fns: []const []const u8, c: *const cred.Credential) void {
    for (fns) |f| {
        if (parseCredentialFile(f, c, printEntry, null, false)) return;
    }
}

const store_usage = [_][]const u8{"git credential-store [<options>] <action>"};

pub fn cmdCredentialStore(args: []const []const u8) u8 {
    var file: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.string(0, "file", &file, "path", "fetch and store credentials in <path>"),
    };
    _ = umask(0o077);
    const rest = po.parse(args[1..], &opts, &store_usage, .{});
    if (rest.len != 1) po.usageWithOptions(&store_usage, &opts);
    const op = rest[0];

    var fns: std.ArrayList([]const u8) = .empty;
    if (file) |f| {
        fns.append(gpa, f) catch util.oom();
    } else {
        if (config.interpolatePath("~/.git-credentials", false)) |p| fns.append(gpa, p) catch util.oom();
        if (config.xdgConfigHome("credentials")) |p| fns.append(gpa, p) catch util.oom();
    }
    if (fns.items.len == 0) util.die("unable to set up default path; use --file", .{});

    var c = cred.Credential{};
    var r = cred.Reader{ .fd = 0 };
    if (!cred.read(&c, &r, .helper)) util.die("unable to read credential", .{});

    if (util.eql(op, "get")) {
        lookupCredential(fns.items, &c);
    } else if (util.eql(op, "erase")) {
        removeCredential(fns.items, &c);
    } else if (util.eql(op, "store")) {
        storeCredential(fns.items, &c);
    }
    return 0;
}
