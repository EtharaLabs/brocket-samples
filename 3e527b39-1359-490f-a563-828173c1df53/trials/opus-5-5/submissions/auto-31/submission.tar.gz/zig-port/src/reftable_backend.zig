//! Reftable reference backend (port of refs/reftable-backend.c).
//!
//! The on-disk format lives in reftable.zig; this file maps the generic refs
//! API (refs.zig) onto reftable stacks: the main stack in
//! $GIT_COMMON_DIR/reftable and per-worktree stacks in
//! $GIT_COMMON_DIR/worktrees/<id>/reftable.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const rt = @import("reftable.zig");
const refs = @import("refs.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

extern "c" fn umask(mask: c_uint) c_uint;

var opts_cache: ?rt.StackOpts = null;
var stacks: std.StringHashMapUnmanaged(*rt.Stack) = .empty;

/// Forget all cached stacks/options (after re-initialising the repository).
pub fn reset() void {
    opts_cache = null;
    stacks = .empty;
}

fn envBool(name: []const u8, def: bool) bool {
    const v = os.getenv(name) orelse return def;
    return @import("config.zig").parseBool(v) orelse def;
}

/// reftable_be_config() + reftable_be_init() option defaults.
pub fn stackOpts() rt.StackOpts {
    if (opts_cache) |o| return o;
    const cfg = &repo_mod.cfg;
    const mask = umask(0);
    _ = umask(mask);
    var o = rt.StackOpts{ .lock_timeout_ms = 100, .default_permissions = 0o666 & ~mask };
    if (sharedPerm()) |p| o.default_permissions = p;
    o.disable_auto_compact = !envBool("GIT_TEST_REFTABLE_AUTOCOMPACTION", true);
    if (cfg.getInt("reftable.blocksize")) |v| {
        if (v > 16777215) util.die("reftable block size cannot exceed 16MB", .{});
        o.write.block_size = @intCast(@max(v, 0));
    }
    if (cfg.getInt("reftable.restartinterval")) |v| {
        if (v > 65535) util.die("reftable block size cannot exceed 65535", .{});
        o.write.restart_interval = @intCast(@max(v, 0));
    }
    if (cfg.getBool("reftable.indexobjects")) |b| o.write.skip_index_objects = !b;
    if (cfg.getInt("reftable.geometricfactor")) |v| {
        if (v > 255) util.die("reftable geometric factor cannot exceed 255", .{});
        o.auto_compaction_factor = @intCast(@max(v, 0));
    }
    if (cfg.getInt("reftable.locktimeout")) |v| {
        if (v < 0 and v != -1) util.die("reftable lock timeout does not support negative values other than -1", .{});
        o.lock_timeout_ms = v;
    }
    if (o.write.block_size == 0) o.write.block_size = 4096;
    if (o.write.restart_interval == 0) o.write.restart_interval = 16;
    opts_cache = o;
    return o;
}

/// calc_shared_perm(0666) when core.sharedRepository is set.
fn sharedPerm() ?c_uint {
    const v = repo_mod.cfg.get("core.sharedrepository") orelse return null;
    var perm: c_uint = 0;
    if (std.ascii.eqlIgnoreCase(v, "group") or std.ascii.eqlIgnoreCase(v, "true") or util.eql(v, "1")) {
        perm = 0o660;
    } else if (std.ascii.eqlIgnoreCase(v, "all") or std.ascii.eqlIgnoreCase(v, "world") or std.ascii.eqlIgnoreCase(v, "everybody") or util.eql(v, "2")) {
        perm = 0o664;
    } else if (v.len > 0 and v[0] == '0') {
        const n = std.fmt.parseInt(c_uint, v, 8) catch return null;
        return n & 0o666;
    } else return null;
    const mask = umask(0);
    _ = umask(mask);
    return (0o666 & ~mask) | perm;
}

fn openStack(dir: []const u8) *rt.Stack {
    if (stacks.get(dir)) |st| {
        st.reload() catch |e| util.die("unable to reload reftable stack '{s}': {s}", .{ dir, rt.errStr(e) });
        return st;
    }
    const st = rt.Stack.open(dir, stackOpts()) catch |e| util.die("unable to open reftable stack '{s}': {s}", .{ dir, rt.errStr(e) });
    stacks.put(gpa, util.dupe(dir), st) catch util.oom();
    return st;
}

fn inWorktree() bool {
    const r = repo_mod.repo();
    return !util.eql(r.git_dir, r.common_dir);
}

pub fn mainStack() *rt.Stack {
    return openStack(util.concat(&.{ repo_mod.repo().common_dir, "/reftable" }));
}

fn worktreeStack() ?*rt.Stack {
    if (!inWorktree()) return null;
    return openStack(util.concat(&.{ repo_mod.repo().git_dir, "/reftable" }));
}

fn otherWorktreeStack(id: []const u8) *rt.Stack {
    return openStack(util.concat(&.{ repo_mod.repo().common_dir, "/worktrees/", id, "/reftable" }));
}

/// is_current_worktree_ref()
pub fn isCurrentWorktreeRef(name: []const u8) bool {
    return refs.isRootRefSyntax(name) or util.startsWith(name, "refs/bisect/") or
        util.startsWith(name, "refs/worktree/") or util.startsWith(name, "refs/rewritten/");
}

pub const Backend = struct { st: *rt.Stack, name: []const u8 };

/// backend_for(): the stack holding `name` and its name within that stack.
pub fn backendFor(name: []const u8) Backend {
    if (util.skipPrefix(name, "worktrees/")) |rest| {
        if (std.mem.indexOfScalar(u8, rest, '/')) |sl| {
            if (sl > 0 and isCurrentWorktreeRef(rest[sl + 1 ..])) {
                const id = rest[0..sl];
                const bare = rest[sl + 1 ..];
                // the current worktree may be addressed by its id, too
                if (inWorktree() and util.eql(std.fs.path.basename(repo_mod.repo().git_dir), id))
                    return .{ .st = worktreeStack().?, .name = bare };
                return .{ .st = otherWorktreeStack(id), .name = bare };
            }
        }
    }
    if (util.skipPrefix(name, "main-worktree/")) |rest| {
        if (isCurrentWorktreeRef(rest)) return .{ .st = mainStack(), .name = rest };
    }
    if (isCurrentWorktreeRef(name)) {
        if (worktreeStack()) |w| return .{ .st = w, .name = name };
    }
    return .{ .st = mainStack(), .name = name };
}

// ---------------------------------------------------------------- reading

/// reftable_be_read_raw_ref()
pub fn readRaw(name: []const u8) refs.RawRead {
    const b = backendFor(name);
    const rec = b.st.readRef(b.name) orelse return .missing;
    return switch (rec.value) {
        .val1 => |o| .{ .oid = o },
        .val2 => |v| .{ .oid = v.oid },
        .symref => |t| .{ .symref = t },
        .deletion => .missing,
    };
}

/// Peeled value stored with a ref (val2), if any.
pub fn peeledOf(name: []const u8) ?Oid {
    const b = backendFor(name);
    const rec = b.st.readRef(b.name) orelse return null;
    return switch (rec.value) {
        .val2 => |v| v.peeled,
        else => null,
    };
}

const Named = struct { name: []const u8, rec: rt.RefRecord };

/// Live records visible from the current worktree, merged as
/// ref_iterator_select() does, sorted by name.
fn visibleRefs() []Named {
    var out: std.ArrayList(Named) = .empty;
    const main = mainStack();
    const wt = worktreeStack();
    if (wt == null) {
        for (main.refs()) |r| {
            if (r.isDeletion()) continue;
            util.append(Named, &out, .{ .name = r.name, .rec = r });
        }
        return out.items;
    }
    const a = wt.?.refs();
    const m = main.refs();
    var i: usize = 0;
    var j: usize = 0;
    while (i < a.len or j < m.len) {
        if (j < m.len and (i >= a.len or std.mem.order(u8, m[j].name, a[i].name) == .lt)) {
            const r = m[j];
            j += 1;
            if (r.isDeletion() or isCurrentWorktreeRef(r.name)) continue;
            util.append(Named, &out, .{ .name = r.name, .rec = r });
            continue;
        }
        const r = a[i];
        i += 1;
        if (j < m.len and util.eql(m[j].name, r.name)) j += 1;
        if (r.isDeletion()) continue;
        util.append(Named, &out, .{ .name = r.name, .rec = r });
    }
    return out.items;
}

fn refFromRecord(n: Named, opts: refs.IterOpts) ?refs.Ref {
    var ref = refs.Ref{ .name = n.name, .oid = hash.zero };
    switch (n.rec.value) {
        .val1 => |o| ref.oid = o,
        .val2 => |v| {
            ref.oid = v.oid;
            ref.peeled = v.peeled;
        },
        .symref => |t| {
            const res = refs.resolveFull(n.name, true);
            ref.flags |= res.flags & ~refs.REF_ISPACKED;
            ref.symref = t;
            if (!res.broken) ref.oid = res.oid;
        },
        .deletion => return null,
    }
    if (hash.isZero(ref.oid)) ref.flags |= refs.REF_ISBROKEN;
    if (!refs.checkRefnameFormat(n.name, refs.ALLOW_ONELEVEL)) {
        if (!refs.refnameIsSafe(n.name)) util.die("refname is dangerous: {s}", .{n.name});
        ref.oid = hash.zero;
        ref.flags |= refs.REF_BAD_NAME | refs.REF_ISBROKEN;
    }
    if (!opts.include_broken) {
        if (ref.flags & refs.REF_ISBROKEN != 0) return null;
        if (opts.check_objects and !repo_mod.repo().odb().has(ref.oid)) {
            util.err("{s} does not point to a valid object!", .{n.name});
            return null;
        }
    }
    return ref;
}

/// Refs under refs/ starting with prefix, sorted.
pub fn iterate(prefix: []const u8, opts: refs.IterOpts) []refs.Ref {
    var out: std.ArrayList(refs.Ref) = .empty;
    for (visibleRefs()) |n| {
        if (!util.startsWith(n.name, "refs/")) continue;
        if (!util.startsWith(n.name, prefix)) continue;
        if (refFromRecord(n, opts)) |r| util.append(refs.Ref, &out, r);
    }
    return out.items;
}

/// Root refs (HEAD, ORIG_HEAD, ...) of the current worktree, sorted.
pub fn listRootRefs() []refs.Ref {
    var out: std.ArrayList(refs.Ref) = .empty;
    for (visibleRefs()) |n| {
        if (!refs.isRootRef(n.name)) continue;
        if (refFromRecord(n, .{ .check_objects = false })) |r| util.append(refs.Ref, &out, r);
    }
    // pseudorefs and other root refs still living in files
    return out.items;
}

/// Names of all live refs starting with `dir` (used for D/F checks).
pub fn namesUnder(dir: []const u8) []const []const u8 {
    var out: std.ArrayList([]const u8) = .empty;
    for (visibleRefs()) |n| {
        if (util.startsWith(n.name, dir)) util.append([]const u8, &out, n.name);
    }
    return out.items;
}

// ---------------------------------------------------------------- reflogs

fn tzString(tz: i16) []u8 {
    const a: u32 = @abs(@as(i32, tz));
    return util.fmt("{c}{d:0>4}", .{ @as(u8, if (tz < 0) '-' else '+'), a });
}

fn isMarker(u: rt.LogUpdate) bool {
    return hash.isZero(u.old) and hash.isZero(u.new);
}

fn entryFromLog(l: rt.LogRecord) refs.ReflogEntry {
    const u = l.value.update;
    var msg = u.message;
    if (msg.len > 0 and msg[msg.len - 1] == '\n') msg = msg[0 .. msg.len - 1];
    return .{
        .old = u.old,
        .new = u.new,
        .ident = util.fmt("{s} <{s}> {d} {s}", .{ u.name, u.email, u.time, tzString(u.tz) }),
        .msg = msg,
        .update_index = l.update_index,
    };
}

/// Reflog entries, oldest first.
pub fn readReflog(name: []const u8) []refs.ReflogEntry {
    const b = backendFor(name);
    const ls = b.st.logsFor(b.name);
    var out: std.ArrayList(refs.ReflogEntry) = .empty;
    var i = ls.len;
    while (i > 0) {
        i -= 1;
        const l = ls[i];
        if (l.isDeletion() or isMarker(l.value.update)) continue;
        util.append(refs.ReflogEntry, &out, entryFromLog(l));
    }
    return out.items;
}

fn liveLogs(b: Backend) []rt.LogRecord {
    var out: std.ArrayList(rt.LogRecord) = .empty;
    for (b.st.logsFor(b.name)) |l| {
        if (!l.isDeletion()) util.append(rt.LogRecord, &out, l);
    }
    return out.items;
}

pub fn reflogExists(name: []const u8) bool {
    return liveLogs(backendFor(name)).len > 0;
}

/// Names that have reflogs, as seen from the current worktree, sorted.
pub fn listReflogs() [][]const u8 {
    var names: std.ArrayList([]const u8) = .empty;
    const main = mainStack();
    const wt = worktreeStack();
    const S = struct {
        fn collect(st: *rt.Stack, list: *std.ArrayList([]const u8), filter: enum { all, shared }) void {
            var last: []const u8 = "";
            for (st.logs()) |l| {
                if (l.isDeletion()) continue;
                if (util.eql(l.name, last)) continue;
                last = l.name;
                if (filter == .shared and isCurrentWorktreeRef(l.name)) continue;
                if (!refs.checkRefnameFormat(l.name, refs.ALLOW_ONELEVEL)) continue;
                util.append([]const u8, list, l.name);
            }
        }
    };
    if (wt) |w| {
        S.collect(w, &names, .all);
        S.collect(main, &names, .shared);
    } else S.collect(main, &names, .all);
    util.sortStrings(names.items);
    var out: std.ArrayList([]const u8) = .empty;
    for (names.items) |n| {
        if (out.items.len > 0 and util.eql(out.items[out.items.len - 1], n)) continue;
        util.append([]const u8, &out, n);
    }
    return out.items;
}

/// Split "Name <email> time tz" as fill_reftable_log_record() does.
pub fn logFromIdent(s: []const u8) rt.LogUpdate {
    var lu = rt.LogUpdate{};
    const lt = std.mem.indexOfScalar(u8, s, '<') orelse return lu;
    const gt = std.mem.lastIndexOfScalar(u8, s, '>') orelse return lu;
    if (gt < lt) return lu;
    var nm = s[0..lt];
    while (nm.len > 0 and nm[nm.len - 1] == ' ') nm = nm[0 .. nm.len - 1];
    lu.name = nm;
    lu.email = s[lt + 1 .. gt];
    var it = std.mem.tokenizeScalar(u8, s[gt + 1 ..], ' ');
    if (it.next()) |t| lu.time = std.fmt.parseInt(u64, t, 10) catch 0;
    if (it.next()) |z0| {
        var z = z0;
        var sign: i32 = 1;
        if (z.len > 0 and z[0] == '-') {
            sign = -1;
            z = z[1..];
        } else if (z.len > 0 and z[0] == '+') z = z[1..];
        var n: i32 = 0;
        for (z) |ch| {
            if (ch < '0' or ch > '9') break;
            n = n *% 10 +% (ch - '0');
        }
        lu.tz = @truncate(sign * n);
    }
    return lu;
}

fn truncMsg(msg: []const u8) []const u8 {
    const lim = stackOpts().write.block_size / 2;
    return if (msg.len > lim) msg[0..lim] else msg;
}

fn newAddition(st: *rt.Stack) rt.Error!rt.Addition {
    return st.newAddition();
}

/// reftable_be_create_reflog(): write an existence marker if there is no log.
pub fn createReflog(name: []const u8) ?[]const u8 {
    const b = backendFor(name);
    var add = newAddition(b.st) catch |e| return rt.errStr(e);
    defer add.close();
    if (liveLogs(b).len > 0) return null;
    const ts = add.next_update_index;
    var logs = [_]rt.LogRecord{.{ .name = b.name, .update_index = ts, .value = .{ .update = .{ .no_message = true } } }};
    add.add(ts, ts, &.{}, &logs) catch |e| return rt.errStr(e);
    add.commit() catch |e| return rt.errStr(e);
    return null;
}

/// reftable_be_delete_reflog(): tombstone every live log record.
pub fn deleteReflog(name: []const u8) bool {
    const b = backendFor(name);
    var add = newAddition(b.st) catch return false;
    defer add.close();
    const ts = add.next_update_index;
    var logs: std.ArrayList(rt.LogRecord) = .empty;
    for (liveLogs(b)) |l| util.append(rt.LogRecord, &logs, .{ .name = b.name, .update_index = l.update_index, .value = .deletion });
    if (logs.items.len == 0) return false;
    add.add(ts, ts, &.{}, logs.items) catch return false;
    add.commit() catch return false;
    return true;
}

/// Rewrite the reflog of `name` to exactly `entries` (as returned by
/// readReflog, possibly modified): dropped entries get tombstones, kept ones
/// are rewritten at their original update index (reflog expire/stash drop).
/// `update_oid`: also point the ref at this value (EXPIRE_REFLOGS_UPDATE_REF).
pub fn rewriteReflog(name: []const u8, entries: []const refs.ReflogEntry, update_oid: ?Oid) bool {
    const b = backendFor(name);
    var add = newAddition(b.st) catch |e| {
        util.err("{s}", .{rt.errStr(e)});
        return false;
    };
    defer add.close();
    const ts = add.next_update_index;
    var logs: std.ArrayList(rt.LogRecord) = .empty;
    var ref_recs: std.ArrayList(rt.RefRecord) = .empty;
    for (liveLogs(b)) |l| {
        if (isMarker(l.value.update)) continue;
        var keep: ?refs.ReflogEntry = null;
        for (entries) |e| {
            if (e.update_index == l.update_index) keep = e;
        }
        if (keep) |e| {
            var u = logFromIdent(e.ident);
            u.old = e.old;
            u.new = e.new;
            u.message = e.msg;
            util.append(rt.LogRecord, &logs, .{ .name = b.name, .update_index = l.update_index, .value = .{ .update = u } });
        } else {
            util.append(rt.LogRecord, &logs, .{ .name = b.name, .update_index = l.update_index, .value = .deletion });
        }
    }
    if (entries.len == 0) {
        util.append(rt.LogRecord, &logs, .{ .name = b.name, .update_index = ts, .value = .{ .update = .{ .no_message = true } } });
    }
    if (update_oid) |o| {
        if (!hash.isZero(o)) {
            const val: rt.RefValue = if (refs.peeledOf(o)) |p| .{ .val2 = .{ .oid = o, .peeled = p } } else .{ .val1 = o };
            util.append(rt.RefRecord, &ref_recs, .{ .name = b.name, .update_index = ts, .value = val });
        }
    }
    add.add(ts, ts, ref_recs.items, logs.items) catch |e| {
        util.err("{s}", .{rt.errStr(e)});
        return false;
    };
    add.commit() catch |e| {
        util.err("{s}", .{rt.errStr(e)});
        return false;
    };
    return true;
}

// ---------------------------------------------------------------- transactions

const Queued = struct { u: *refs.Update, current: Oid };

const Arg = struct {
    st: *rt.Stack,
    add: rt.Addition,
    ups: std.ArrayList(Queued) = .empty,
};

pub const TxData = struct {
    args: std.ArrayList(*Arg) = .empty,

    fn close(self: *TxData) void {
        for (self.args.items) |a| a.add.close();
        self.args.clearRetainingCapacity();
    }
};

fn txData(t: *refs.Transaction) ?*TxData {
    const p = t.rt_data orelse return null;
    return @ptrCast(@alignCast(p));
}

fn argFor(t: *refs.Transaction, td: *TxData, st: *rt.Stack) ?*Arg {
    for (td.args.items) |a| {
        if (a.st == st) return a;
    }
    const add = st.newAddition() catch |e| {
        if (e == error.Lock) {
            t.setErr("cannot lock references", .{});
        } else t.setErr("reftable: transaction prepare: {s}", .{rt.errStr(e)});
        return null;
    };
    const a = gpa.create(Arg) catch util.oom();
    a.* = .{ .st = st, .add = add };
    util.append(*Arg, &td.args, a);
    return a;
}

fn hasNullNew(u: *const refs.Update) bool {
    return u.new_target == null and hash.isZero(u.new_oid);
}

/// The object checks ref_transaction_update() does in refs.c.
fn checkNewValue(t: *refs.Transaction, u: *refs.Update) refs.TxErr {
    if (u.flags & refs.F_HAVE_NEW == 0 or u.new_target != null or hash.isZero(u.new_oid)) return .ok;
    if (u.flags & (refs.F_SKIP_OID_VERIFICATION | refs.F_LOG_ONLY) != 0) return .ok;
    const ty = repo_mod.repo().odb().readType(u.new_oid) orelse {
        t.setErr("trying to write ref '{s}' with nonexistent object {s}", .{ u.refname, hash.hex(u.new_oid) });
        return .invalid_new_value;
    };
    const is_branch = util.eql(u.refname, "HEAD") or util.startsWith(u.refname, "refs/heads/");
    if (ty != .commit and is_branch) {
        t.setErr("trying to write non-commit object {s} to branch '{s}'", .{ hash.hex(u.new_oid), u.refname });
        return .invalid_new_value;
    }
    if (ty == .tag) u.peeled = refs.peeledOf(u.new_oid);
    return .ok;
}

fn failPrepare(t: *refs.Transaction, td: *TxData, e: refs.TxErr) refs.TxErr {
    td.close();
    t.rt_data = null;
    t.state = .closed;
    if (t.err.items.len == 0) t.setErr("reftable: transaction prepare: {s}", .{"general error"});
    return e;
}

/// reftable_be_transaction_prepare()
pub fn prepare(t: *refs.Transaction) refs.TxErr {
    const td = gpa.create(TxData) catch util.oom();
    td.* = .{};
    t.rt_data = td;
    for (t.updates.items) |u| {
        const e = checkNewValue(t, u);
        if (e != .ok) return failPrepare(t, td, e);
    }
    for (t.updates.items) |u| {
        _ = argFor(t, td, backendFor(u.refname).st) orelse return failPrepare(t, td, .generic);
    }
    var head_ref: ?[]const u8 = null;
    {
        const hb = backendFor("HEAD");
        if (hb.st.readRef(hb.name)) |r| switch (r.value) {
            .symref => |s| head_ref = s,
            else => {},
        };
    }
    var to_check: std.ArrayList(*refs.Update) = .empty;
    var i: usize = 0;
    while (i < t.updates.items.len) : (i += 1) {
        const u = t.updates.items[i];
        const e = prepareSingle(t, td, u, head_ref, &to_check);
        if (e != .ok) {
            if (t.maybeReject(u, e)) continue;
            return failPrepare(t, td, e);
        }
    }
    var extras: std.ArrayList([]const u8) = .empty;
    for (t.updates.items) |u| {
        if (u.flags & refs.F_LOG_ONLY == 0) util.append([]const u8, &extras, u.refname);
    }
    for (to_check.items) |u| {
        if (u.rejection != .ok) continue;
        if (refs.verifyAvailable(u.refname, extras.items, &.{}, .all, &t.err)) |e| {
            if (t.maybeReject(u, e)) continue;
            return failPrepare(t, td, e);
        }
    }
    t.state = .prepared;
    return .ok;
}

fn queue(t: *refs.Transaction, td: *TxData, st: *rt.Stack, u: *refs.Update, current: Oid) bool {
    const a = argFor(t, td, st) orelse return false;
    a.ups.append(gpa, .{ .u = u, .current = current }) catch util.oom();
    return true;
}

fn prepareSingle(t: *refs.Transaction, td: *TxData, u: *refs.Update, head_ref: ?[]const u8, to_check: *std.ArrayList(*refs.Update)) refs.TxErr {
    const b = backendFor(u.refname);
    if (u.flags & refs.F_LOG_USE_PROVIDED_OIDS != 0) {
        const need = refs.F_HAVE_OLD | refs.F_HAVE_NEW | refs.F_LOG_ONLY;
        if (u.flags & need != need) {
            t.setErr("trying to write reflog for '{s}' with incomplete values", .{u.refname});
            return .generic;
        }
        if (!queue(t, td, b.st, u, u.old_oid)) return .generic;
        return .ok;
    }
    if (head_ref) |hr| {
        if (u.flags & (refs.F_LOG_ONLY | refs.F_UPDATE_VIA_HEAD) == 0 and util.eql(b.name, hr)) {
            if (t.hasRefname("HEAD")) {
                t.setErr("multiple updates for 'HEAD' (including one via its referent '{s}') are not allowed", .{u.refname});
                return .name_conflict;
            }
            _ = t.addUpdate(.{
                .refname = "HEAD",
                .flags = u.flags | refs.F_LOG_ONLY | refs.F_NO_DEREF,
                .new_oid = u.new_oid,
                .old_oid = u.old_oid,
                .peeled = u.peeled,
                .msg = u.msg,
            });
        }
    }
    var current: Oid = hash.zero;
    var referent: []const u8 = "";
    u.is_symref = false;
    const rec = b.st.readRef(b.name);
    if (rec) |r| switch (r.value) {
        .val1 => |o| current = o,
        .val2 => |v| current = v.oid,
        .symref => |s| {
            u.is_symref = true;
            referent = s;
        },
        .deletion => {},
    };
    if (rec == null) {
        const expects = u.flags & refs.F_HAVE_OLD != 0 and (u.old_target != null or !hash.isZero(u.old_oid));
        if (!expects) {
            to_check.append(gpa, u) catch util.oom();
            if (u.flags & refs.F_HAVE_NEW != 0 and !hasNullNew(u)) {
                if (!queue(t, td, b.st, u, current)) return .generic;
            }
            return .ok;
        }
        t.setErr("cannot lock ref '{s}': unable to resolve reference '{s}'", .{ u.originalName(), u.refname });
        return .nonexistent_ref;
    }
    if (u.is_symref) {
        const rr = refs.resolveFull(u.refname, false);
        const resolved = !(rr.broken and !rr.missing);
        current = if (resolved and !rr.missing) rr.oid else hash.zero;
        if (u.flags & refs.F_NO_DEREF != 0) {
            if (u.flags & refs.F_HAVE_OLD != 0 and !resolved) {
                t.setErr("cannot lock ref '{s}': error reading reference", .{u.refname});
                return .generic;
            }
        } else {
            if (t.hasRefname(referent)) {
                t.setErr("multiple updates for '{s}' (including one via symref '{s}') are not allowed", .{ referent, u.refname });
                return .name_conflict;
            }
            var nf = u.flags;
            if (util.eql(b.name, "HEAD")) nf |= refs.F_UPDATE_VIA_HEAD;
            const nu = t.addUpdate(.{
                .refname = referent,
                .flags = nf,
                .new_oid = if (u.new_target != null) hash.zero else u.new_oid,
                .old_oid = if (u.old_target != null) hash.zero else u.old_oid,
                .peeled = u.peeled,
                .new_target = u.new_target,
                .old_target = u.old_target,
                .committer = u.committer,
                .msg = u.msg,
            });
            nu.parent = u;
            u.flags |= refs.F_LOG_ONLY | refs.F_NO_DEREF;
        }
    }
    if (u.old_target) |ot| {
        if (!u.is_symref) {
            t.setErr("cannot lock ref '{s}': expected symref with target '{s}': but is a regular ref", .{ u.originalName(), ot });
            return .expected_symref;
        }
        if (!util.eql(referent, ot)) {
            if (referent.len == 0) {
                t.setErr("verifying symref target: '{s}': reference is missing but expected {s}", .{ u.originalName(), ot });
                return .nonexistent_ref;
            }
            t.setErr("verifying symref target: '{s}': is at {s} but expected {s}", .{ u.originalName(), referent, ot });
            return .incorrect_old_value;
        }
    } else if (u.flags & (refs.F_LOG_ONLY | refs.F_HAVE_OLD) == refs.F_HAVE_OLD) {
        if (hash.eql(current, u.old_oid)) {
            if (u.flags & refs.F_NO_DEREF != 0 and referent.len > 0 and hash.isZero(u.old_oid)) {
                t.setErr("cannot lock ref '{s}': dangling symref already exists", .{u.originalName()});
                return .create_exists;
            }
        } else if (hash.isZero(u.old_oid)) {
            t.setErr("cannot lock ref '{s}': reference already exists", .{u.originalName()});
            return .create_exists;
        } else if (hash.isZero(current)) {
            t.setErr("cannot lock ref '{s}': reference is missing but expected {s}", .{ u.originalName(), hash.hex(u.old_oid) });
            return .nonexistent_ref;
        } else {
            t.setErr("cannot lock ref '{s}': is at {s} but expected {s}", .{ u.originalName(), hash.hex(current), hash.hex(u.old_oid) });
            return .incorrect_old_value;
        }
    }
    if (u.is_symref or u.flags & refs.F_LOG_ONLY != 0 or (u.flags & refs.F_HAVE_NEW != 0 and !hash.eql(current, u.new_oid))) {
        if (!queue(t, td, b.st, u, current)) return .generic;
    }
    return .ok;
}

fn shouldWriteLog(name: []const u8) bool {
    return refs.shouldAutocreateReflog(name) or reflogExists(name);
}

/// write_transaction_table()
fn writeTransactionTable(t: *refs.Transaction, a: *Arg) rt.Error!void {
    const ts = a.add.next_update_index;
    const committer = @import("ident.zig").committer();
    std.mem.sort(Queued, a.ups.items, {}, struct {
        fn lt(_: void, x: Queued, y: Queued) bool {
            if (x.u.index != y.u.index) return x.u.index < y.u.index;
            return std.mem.order(u8, x.u.refname, y.u.refname) == .lt;
        }
    }.lt);
    var ref_recs: std.ArrayList(rt.RefRecord) = .empty;
    var logs: std.ArrayList(rt.LogRecord) = .empty;
    for (a.ups.items) |q| {
        const u = q.u;
        if (u.rejection != .ok) continue;
        const name = backendFor(u.refname).name;
        if (u.flags & refs.F_HAVE_NEW != 0 and !u.is_symref and hasNullNew(u)) {
            for (a.st.logsFor(name)) |l| {
                if (l.isDeletion()) continue;
                util.append(rt.LogRecord, &logs, .{ .name = name, .update_index = l.update_index, .value = .deletion });
            }
        } else if (u.flags & refs.F_SKIP_CREATE_REFLOG == 0 and u.flags & refs.F_HAVE_NEW != 0 and
            (u.flags & refs.F_FORCE_CREATE_REFLOG != 0 or shouldWriteLog(u.refname)))
        {
            var create = true;
            var new = u.new_oid;
            if (u.new_target) |nt| {
                const rr = refs.resolveFull(nt, true);
                if (rr.broken) create = false else new = rr.oid;
            }
            if (create) {
                var lu = logFromIdent(u.committer orelse committer);
                lu.new = new;
                lu.old = q.current;
                lu.message = truncMsg(u.msg);
                util.append(rt.LogRecord, &logs, .{ .name = name, .update_index = ts + u.index, .value = .{ .update = lu } });
            }
        }
        if (u.flags & refs.F_LOG_ONLY != 0) continue;
        if (u.new_target) |nt| {
            util.append(rt.RefRecord, &ref_recs, .{ .name = name, .update_index = ts, .value = .{ .symref = nt } });
        } else if (u.flags & refs.F_HAVE_NEW != 0 and hasNullNew(u)) {
            util.append(rt.RefRecord, &ref_recs, .{ .name = name, .update_index = ts, .value = .deletion });
        } else if (u.flags & refs.F_HAVE_NEW != 0) {
            const val: rt.RefValue = if (u.peeled) |p| .{ .val2 = .{ .oid = u.new_oid, .peeled = p } } else .{ .val1 = u.new_oid };
            util.append(rt.RefRecord, &ref_recs, .{ .name = name, .update_index = ts, .value = val });
        }
    }
    try a.add.add(ts, ts + t.max_index, ref_recs.items, logs.items);
}

/// reftable_be_transaction_finish()
pub fn finish(t: *refs.Transaction) refs.TxErr {
    const td = txData(t) orelse return .ok;
    defer {
        td.close();
        t.rt_data = null;
    }
    for (td.args.items) |a| {
        writeTransactionTable(t, a) catch |e| {
            t.setErr("reftable: transaction failure: {s}", .{rt.errStr(e)});
            return .generic;
        };
        a.add.commit() catch |e| {
            t.setErr("reftable: transaction failure: {s}", .{rt.errStr(e)});
            return .generic;
        };
    }
    return .ok;
}

pub fn abort(t: *refs.Transaction) void {
    const td = txData(t) orelse return;
    td.close();
    t.rt_data = null;
}

/// ref_transaction_update_reflog() for a single entry outside of a
/// transaction (git reflog write, appendReflog).
pub fn appendReflog(name: []const u8, old: Oid, new: Oid, msg: []const u8) void {
    const t = refs.Transaction.init();
    var e = t.updateReflog(name, new, old, null, msg, 0);
    if (e == .ok) e = t.commit();
    if (e != .ok) util.err("{s}", .{t.errMsg()});
}

// ---------------------------------------------------------------- rename/copy

/// reftable_be_rename_ref() / reftable_be_copy_ref()
pub fn renameRef(oldname: []const u8, newname: []const u8, logmsg0: []const u8, copy: bool) bool {
    const logmsg = truncMsg(refs.normalizeReflogMsg(logmsg0));
    const b = backendFor(newname);
    const ob = backendFor(oldname);
    var add = newAddition(b.st) catch |e| {
        util.err("{s}", .{rt.errStr(e)});
        return false;
    };
    defer add.close();
    const old_ref = b.st.readRef(ob.name) orelse {
        util.err("refname {s} not found", .{oldname});
        return false;
    };
    if (old_ref.value == .symref) {
        util.err("refname {s} is a symbolic ref, copying it is not supported", .{oldname});
        return false;
    }
    if (util.eql(oldname, newname)) return true;
    var errb: util.Buf = .empty;
    const skip: []const []const u8 = if (copy) &.{} else &.{oldname};
    if (refs.verifyAvailable(newname, &.{}, skip, .all, &errb) != null) {
        util.err("{s}", .{errb.items});
        return false;
    }
    const deletion_ts = add.next_update_index;
    const creation_ts = if (copy) deletion_ts else deletion_ts + 1;
    const committer = logFromIdent(@import("ident.zig").committer());
    const old_oid = old_ref.oid() orelse hash.zero;

    var ref_recs: std.ArrayList(rt.RefRecord) = .empty;
    var nr = old_ref;
    nr.name = b.name;
    nr.update_index = creation_ts;
    util.append(rt.RefRecord, &ref_recs, nr);
    if (!copy) util.append(rt.RefRecord, &ref_recs, .{ .name = ob.name, .update_index = deletion_ts, .value = .deletion });

    var logs: std.ArrayList(rt.LogRecord) = .empty;
    if (!copy) {
        var lu = committer;
        lu.message = logmsg;
        lu.old = old_oid;
        util.append(rt.LogRecord, &logs, .{ .name = b.name, .update_index = deletion_ts, .value = .{ .update = lu } });
        const hb = backendFor("HEAD");
        if (hb.st.readRef(hb.name)) |h| {
            if (h.value == .symref and util.eql(h.value.symref, oldname))
                util.append(rt.LogRecord, &logs, .{ .name = "HEAD", .update_index = deletion_ts, .value = .{ .update = lu } });
        }
    }
    {
        var lu = committer;
        lu.message = logmsg;
        lu.new = old_oid;
        util.append(rt.LogRecord, &logs, .{ .name = b.name, .update_index = creation_ts, .value = .{ .update = lu } });
    }
    for (b.st.logsFor(ob.name)) |l| {
        if (l.isDeletion()) continue;
        var c = l;
        c.name = b.name;
        util.append(rt.LogRecord, &logs, c);
        if (!copy) util.append(rt.LogRecord, &logs, .{ .name = ob.name, .update_index = l.update_index, .value = .deletion });
    }
    add.add(deletion_ts, creation_ts, ref_recs.items, logs.items) catch |e| {
        util.err("{s}", .{rt.errStr(e)});
        return false;
    };
    add.commit() catch |e| {
        util.err("{s}", .{rt.errStr(e)});
        return false;
    };
    return true;
}

// ---------------------------------------------------------------- optimize

fn optimizeStack() *rt.Stack {
    return worktreeStack() orelse mainStack();
}

/// reftable_be_optimize()
pub fn optimize(auto: bool) bool {
    const st = optimizeStack();
    const res = if (auto) st.autoCompact() else st.compactAll();
    res catch |e| {
        util.err("unable to compact stack: {s}", .{rt.errStr(e)});
        return false;
    };
    st.clean() catch {};
    return true;
}

pub fn optimizeRequired(auto: bool) bool {
    return optimizeStack().compactionRequired(auto);
}

// ---------------------------------------------------------------- fsck

pub const FsckOpts = struct { verbose: bool = false, strict: bool = false };

fn report(o: FsckOpts, path: []const u8, id: []const u8, sev: enum { err, warn, info }, msg: []const u8) bool {
    var s = sev;
    if (s == .info) s = .warn else if (s == .warn and o.strict) s = .err;
    if (s == .warn) {
        util.warn("{s}: {s}: {s}", .{ path, id, msg });
        return false;
    }
    util.err("{s}: {s}: {s}", .{ path, id, msg });
    return true;
}

/// reftable_be_fsck() for the worktree with id `wt_id` (null = main).
/// Returns true if errors were found.
pub fn fsck(o: FsckOpts, wt_id: ?[]const u8) bool {
    const st = if (wt_id) |id| otherWorktreeStack(id) else mainStack();
    var errors = false;
    for (st.tables) |tb| {
        if (o.verbose) util.eprint("Checking table: {s}\n", .{tb.name});
        if (!rt.validTableName(tb.name)) {
            if (report(o, tb.name, "badReftableTableName", .warn, "invalid reftable table name")) errors = true;
        }
    }
    for (st.refs()) |r| {
        const path = if (wt_id) |id| util.concat(&.{ "worktrees/", id, "/", r.name }) else r.name;
        switch (r.value) {
            .deletion => {},
            .val1, .val2 => {
                const oid = r.oid().?;
                if (hash.isZero(oid)) {
                    if (report(o, path, "badRefOid", .err, util.fmt("points to invalid object ID '{s}'", .{hash.hex(oid)}))) errors = true;
                }
            },
            .symref => |target| {
                if (util.eql(r.name, "HEAD") and !util.startsWith(target, "refs/heads/")) {
                    if (report(o, path, "badHeadTarget", .err, util.fmt("HEAD points to non-branch '{s}'", .{target}))) {
                        errors = true;
                        continue;
                    }
                }
                if (refs.isRootRef(target)) continue;
                if (!refs.checkRefnameFormat(target, 0)) {
                    if (report(o, path, "badReferentName", .err, util.fmt("points to invalid refname '{s}'", .{target}))) {
                        errors = true;
                        continue;
                    }
                }
                if (!util.startsWith(target, "refs/") and !util.startsWith(target, "worktrees/")) {
                    if (report(o, path, "symrefTargetIsNotARef", .info, util.fmt("points to non-ref target '{s}'", .{target}))) errors = true;
                }
            },
        }
    }
    return errors;
}

// ---------------------------------------------------------------- on-disk setup

/// reftable_be_create_on_disk(): reftable/ plus the stubs that keep older
/// gits from treating the directory as a non-repository.
pub fn createOnDisk(gitdir: []const u8) void {
    const dir = util.concat(&.{ gitdir, "/reftable" });
    _ = os.mkdir(dir, 0o777);
    if (sharedPerm()) |p| _ = os.chmod(dir, (p & 0o666) | ((p & 0o444) >> 2) | 0o700);
    os.writeFile(util.concat(&.{ gitdir, "/HEAD" }), "ref: refs/heads/.invalid\n", 0o666) catch {};
    _ = os.mkdir(util.concat(&.{ gitdir, "/refs" }), 0o777);
    os.writeFile(util.concat(&.{ gitdir, "/refs/heads" }), "this repository uses the reftable format\n", 0o666) catch {};
}

/// reftable_be_remove_on_disk()
pub fn removeOnDisk(gitdir: []const u8) bool {
    var ok = true;
    const dir = util.concat(&.{ gitdir, "/reftable" });
    os.removeTree(dir);
    if (os.exists(dir)) {
        util.err("could not delete reftables: {s}", .{os.lastErr()});
        ok = false;
    }
    if (!os.unlink(util.concat(&.{ gitdir, "/HEAD" }))) {
        util.err("could not delete stub HEAD: {s}", .{os.lastErr()});
        ok = false;
    }
    if (!os.unlink(util.concat(&.{ gitdir, "/refs/heads" }))) {
        util.err("could not delete stub heads: {s}", .{os.lastErr()});
        ok = false;
    }
    if (!os.rmdir(util.concat(&.{ gitdir, "/refs" }))) {
        util.err("could not delete refs directory: {s}", .{os.lastErr()});
        ok = false;
    }
    stacks = .empty;
    return ok;
}

/// Write records directly into the stack at `dir` (used by migration and
/// clone). Records' update indices must lie in [min, max] relative to the
/// stack's next update index (1 for a new stack).
pub fn writeRecordsAt(dir: []const u8, min: u64, max: u64, ref_recs: []rt.RefRecord, logs: []rt.LogRecord) rt.Error!void {
    var o = stackOpts();
    o.disable_auto_compact = true;
    const st = try rt.Stack.open(dir, o);
    var add = try st.newAddition();
    defer add.close();
    try add.add(min, max, ref_recs, logs);
    try add.commit();
}
