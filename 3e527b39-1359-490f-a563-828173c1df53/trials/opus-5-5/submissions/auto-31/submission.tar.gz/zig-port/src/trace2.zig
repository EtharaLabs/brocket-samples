//! trace2 (port of trace2.c and trace2/*: normal, perf and event targets).
//!
//! Everything is a no-op unless `enabled` (one of the targets is wanted);
//! callers on hot paths should check `trace2.enabled` before formatting.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const gpa = util.gpa;

pub const version_string = "2.56.1";
const event_version = "4";

/// trace2_is_enabled()
pub var enabled: bool = false;
var redact: bool = true;

var us_start_process: i64 = 0;
var next_child_id: i32 = 0;
var next_exec_id: i32 = 0;
var next_repo_id: i32 = 1;
/// trace2_repo_id of the_repository (0 until def_repo).
pub var repo_id: i32 = 0;

// region stack of the main thread; [0] is the process start
var region_starts: std.ArrayList(i64) = .empty;

var exit_code: u8 = 0;
/// __FILE__/__LINE__ of the exit() call reported by the "exit" event.
pub var exit_file: []const u8 = "git.c";
pub var exit_line: u32 = 789;
var exit_emitted = false;
var atexit_emitted = false;

// ---------------------------------------------------------------- sysenv

const Var = enum(u8) { cfg_param, env_vars, dst_debug, normal, normal_brief, event, event_brief, event_nesting, perf, perf_brief, max_files };

const SysEnv = struct {
    env: []const u8,
    cfg: []const u8,
    value: ?[]const u8 = null,
    getenv_called: bool = false,
};

var sysenv = [_]SysEnv{
    .{ .env = "GIT_TRACE2_CONFIG_PARAMS", .cfg = "trace2.configparams" },
    .{ .env = "GIT_TRACE2_ENV_VARS", .cfg = "trace2.envvars" },
    .{ .env = "GIT_TRACE2_DST_DEBUG", .cfg = "trace2.destinationdebug" },
    .{ .env = "GIT_TRACE2", .cfg = "trace2.normaltarget" },
    .{ .env = "GIT_TRACE2_BRIEF", .cfg = "trace2.normalbrief" },
    .{ .env = "GIT_TRACE2_EVENT", .cfg = "trace2.eventtarget" },
    .{ .env = "GIT_TRACE2_EVENT_BRIEF", .cfg = "trace2.eventbrief" },
    .{ .env = "GIT_TRACE2_EVENT_NESTING", .cfg = "trace2.eventnesting" },
    .{ .env = "GIT_TRACE2_PERF", .cfg = "trace2.perftarget" },
    .{ .env = "GIT_TRACE2_PERF_BRIEF", .cfg = "trace2.perfbrief" },
    .{ .env = "GIT_TRACE2_MAX_FILES", .cfg = "trace2.maxfiles" },
};

fn sysenvGet(v: Var) ?[]const u8 {
    const e = &sysenv[@intFromEnum(v)];
    if (!e.getenv_called) {
        e.getenv_called = true;
        if (os.getenv(e.env)) |val| {
            if (val.len > 0) e.value = val;
        }
    }
    return e.value;
}

fn containsIgnoreCase(hay: []const u8, needle: []const u8) bool {
    if (hay.len < needle.len) return false;
    var i: usize = 0;
    while (i + needle.len <= hay.len) : (i += 1) {
        if (std.ascii.eqlIgnoreCase(hay[i .. i + needle.len], needle)) return true;
    }
    return false;
}

fn sysenvCb(_: *anyopaque, key: []const u8, value: ?[]const u8, _: *const config.KvInfo) i32 {
    if (!util.startsWith(key, "trace2.")) return 0;
    for (&sysenv) |*e| {
        if (util.eql(key, e.cfg)) {
            const v = value orelse return config.errorNonbool(key);
            e.value = util.dupe(v);
            return 0;
        }
    }
    return 0;
}

const config = @import("config.zig");

/// tr2_sysenv_load(): read_very_early_config() (system + global, with
/// includes). Files that cannot mention trace2 settings are not parsed.
fn sysenvLoad() void {
    var dummy: u8 = 0;
    const cb = config.Callback{ .f = sysenvCb, .ctx = &dummy };
    var paths: [3]?[]const u8 = .{ null, null, null };
    if (config.useSystemConfig()) paths[0] = config.systemConfigPath();
    const g = config.globalConfigPaths();
    paths[1] = g.xdg;
    paths[2] = g.user;
    for (paths, 0..) |p_opt, i| {
        const p = p_opt orelse continue;
        const data = os.readFile(p) orelse continue;
        if (!containsIgnoreCase(data, "trace2") and !containsIgnoreCase(data, "include")) continue;
        _ = config.configWithOptionsScoped(.{ .file = p }, if (i == 0) .system else .global, cb, &config.Options{});
    }
}

// ---------------------------------------------------------------- destinations

const Dst = struct {
    v: Var,
    fd: c_int = 0,
    initialized: bool = false,
    need_close: bool = false,
    too_many_files: bool = false,
};

var dst_normal = Dst{ .v = .normal };
var dst_perf = Dst{ .v = .perf };
var dst_event = Dst{ .v = .event };

var normal_brief = false;
var perf_brief = false;
var event_brief = false;
var event_max_nesting: usize = 2;

var dst_debug: i32 = -1;

fn wantWarning() bool {
    if (dst_debug == -1) {
        const v = sysenvGet(.dst_debug) orelse "";
        dst_debug = if (v.len == 0) 0 else if ((std.fmt.parseInt(i32, v, 10) catch 0) > 0) 1 else 0;
    }
    return dst_debug == 1;
}

fn displayName(v: Var) []const u8 {
    return sysenv[@intFromEnum(v)].env;
}

fn dstDisable(d: *Dst) void {
    if (d.need_close) os.close(d.fd);
    d.fd = 0;
    d.initialized = true;
    d.need_close = false;
}

fn atoi(s: []const u8) i64 {
    var i: usize = 0;
    while (i < s.len and (s[i] == ' ' or s[i] == '\t')) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '-' or s[i] == '+')) {
        neg = s[i] == '-';
        i += 1;
    }
    var n: i64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) n = n *% 10 +% (s[i] - '0');
    return if (neg) -n else n;
}

/// tr2_dst_too_many_files(): 0 = proceed, 1 = sentinel exists, -1 = too many.
fn tooManyFiles(d: *Dst, prefix: []const u8) i32 {
    var max_files: i64 = 0;
    if (sysenvGet(.max_files)) |m| {
        const n = atoi(m);
        if (n >= 0) max_files = n;
    }
    if (max_files == 0) return 0;
    var path: util.Buf = .empty;
    util.bufAppend(&path, prefix);
    if (path.items[path.items.len - 1] != '/') util.bufByte(&path, '/');
    const sentinel = util.concat(&.{ path.items, "git-trace2-discard" });
    if (os.statPath(sentinel) != null) return 1;
    var count: i64 = 0;
    if (os.listDir(path.items)) |ents| {
        // readdir() also returns "." and ".."
        count = @as(i64, @intCast(ents.len)) + 2;
    }
    if (count >= max_files) {
        d.too_many_files = true;
        d.fd = os.openFile(sentinel, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666);
        return -1;
    }
    return 0;
}

fn tryAutoPath(d: *Dst, prefix: []const u8) c_int {
    var s = sidGet();
    if (std.mem.lastIndexOfScalar(u8, s, '/')) |i| s = s[i + 1 ..];
    var path: util.Buf = .empty;
    util.bufAppend(&path, prefix);
    if (path.items[path.items.len - 1] != '/') util.bufByte(&path, '/');
    util.bufAppend(&path, s);
    const base_len = path.items.len;
    const tmf = tooManyFiles(d, prefix);
    if (tmf == 0) {
        var attempt: u32 = 0;
        while (attempt < 10) : (attempt += 1) {
            if (attempt > 0) {
                path.shrinkRetainingCapacity(base_len);
                util.bufPrint(&path, ".{d}", .{attempt});
            }
            d.fd = os.openFile(path.items, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666);
            if (d.fd != -1) break;
        }
    } else if (tmf == 1) {
        if (wantWarning()) util.warn("trace2: not opening {s} trace file due to too many files in target directory {s}", .{ displayName(d.v), prefix });
        return 0;
    }
    if (d.fd == -1) {
        if (wantWarning()) util.warn("trace2: could not open '{s}' for '{s}' tracing: {s}", .{ path.items[0..base_len], displayName(d.v), os.lastErr() });
        dstDisable(d);
        return 0;
    }
    d.need_close = true;
    d.initialized = true;
    return d.fd;
}

fn getFd(d: *Dst) c_int {
    if (d.initialized) return d.fd;
    d.initialized = true;
    const t = sysenvGet(d.v) orelse "";
    if (t.len == 0 or util.eql(t, "0") or std.ascii.eqlIgnoreCase(t, "false")) {
        d.fd = 0;
        return 0;
    }
    if (util.eql(t, "1") or std.ascii.eqlIgnoreCase(t, "true")) {
        d.fd = 2;
        return 2;
    }
    if (t.len == 1 and std.ascii.isDigit(t[0])) {
        d.fd = t[0] - '0';
        return d.fd;
    }
    if (t[0] == '/') {
        if (os.isDir(t)) return tryAutoPath(d, t);
        const fd = os.openFile(t, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o666);
        if (fd == -1) {
            if (wantWarning()) util.warn("trace2: could not open '{s}' for '{s}' tracing: {s}", .{ t, displayName(d.v), os.lastErr() });
            dstDisable(d);
            return 0;
        }
        d.fd = fd;
        d.need_close = true;
        return fd;
    }
    if (util.startsWith(t, "af_unix:")) {
        // sockets are not supported by this port
        if (wantWarning()) util.warn("trace2: could not connect to socket '{s}' for '{s}' tracing: {s}", .{ t, displayName(d.v), "Operation not supported" });
        dstDisable(d);
        return 0;
    }
    util.warn("trace2: unknown value for '{s}': '{s}'", .{ displayName(d.v), t });
    dstDisable(d);
    return 0;
}

fn want(d: *Dst) bool {
    return getFd(d) != 0;
}

extern "c" fn write(fd: c_int, buf: [*]const u8, n: usize) isize;
extern "c" fn signal(sig: c_int, handler: usize) usize;

fn writeLine(d: *Dst, b: *util.Buf) void {
    const fd = getFd(d);
    if (b.items.len == 0 or b.items[b.items.len - 1] != '\n') util.bufByte(b, '\n');
    const old = signal(13, 1);
    const n = write(fd, b.items.ptr, b.items.len);
    _ = signal(13, old);
    if (n >= 0) return;
    dstDisable(d);
    if (wantWarning()) util.warn("unable to write trace to '{s}': {s}", .{ displayName(d.v), os.lastErr() });
}

fn parseMaybeBool(v: []const u8) i32 {
    return config.parseMaybeBool(v);
}

fn initTargets() u32 {
    var n: u32 = 0;
    if (want(&dst_normal)) {
        n += 1;
        if (sysenvGet(.normal_brief)) |b| if (b.len > 0) {
            const r = parseMaybeBool(b);
            if (r != -1) normal_brief = r == 1;
        };
    }
    if (want(&dst_perf)) {
        n += 1;
        if (sysenvGet(.perf_brief)) |b| if (b.len > 0) {
            const r = parseMaybeBool(b);
            if (r != -1) perf_brief = r == 1;
        };
    }
    if (want(&dst_event)) {
        n += 1;
        if (sysenvGet(.event_nesting)) |s| if (s.len > 0) {
            const m = atoi(s);
            if (m > 0) event_max_nesting = @intCast(m);
        };
        if (sysenvGet(.event_brief)) |b| if (b.len > 0) {
            const r = parseMaybeBool(b);
            if (r != -1) event_brief = r == 1;
        };
    }
    return n;
}

// ---------------------------------------------------------------- sid / names

var sid_buf: util.Buf = .empty;
var sid_depth: i32 = 0;

extern "c" fn getpid() c_int;
extern "c" fn getppid() c_int;
extern "c" fn gethostname(name: [*]u8, len: usize) c_int;

fn sidGet() []const u8 {
    if (sid_buf.items.len > 0) return sid_buf.items;
    if (os.getenv("GIT_TRACE2_PARENT_SID")) |p| {
        if (p.len > 0) {
            for (p) |ch| {
                if (ch == '/') sid_depth += 1;
            }
            util.bufAppend(&sid_buf, p);
            util.bufByte(&sid_buf, '/');
            sid_depth += 1;
        }
    }
    const us = os.nowMicros();
    const tm = os.gmtime(@divFloor(us, 1000000));
    util.bufPrint(&sid_buf, "{d:0>4}{d:0>2}{d:0>2}T{d:0>2}{d:0>2}{d:0>2}.{d:0>6}Z", .{
        @as(u32, @intCast(tm.year + 1900)), @as(u32, @intCast(tm.mon + 1)), @as(u32, @intCast(tm.mday)),
        @as(u32, @intCast(tm.hour)),        @as(u32, @intCast(tm.min)),     @as(u32, @intCast(tm.sec)),
        @as(u64, @intCast(@mod(us, 1000000))),
    });
    util.bufByte(&sid_buf, '-');
    var hn: [256]u8 = undefined;
    if (gethostname(&hn, hn.len) != 0) {
        util.bufAppend(&sid_buf, "Localhost");
    } else {
        const n = std.mem.indexOfScalar(u8, &hn, 0) orelse hn.len;
        var h = std.crypto.hash.Sha1.init(.{});
        h.update(hn[0..n]);
        var d: [20]u8 = undefined;
        h.final(&d);
        const hx = std.fmt.bytesToHex(d, .lower);
        util.bufByte(&sid_buf, 'H');
        util.bufAppend(&sid_buf, hx[0..8]);
    }
    util.bufPrint(&sid_buf, "-P{x:0>8}", .{@as(u32, @bitCast(getpid()))});
    os.setEnv("GIT_TRACE2_PARENT_SID", sid_buf.items);
    return sid_buf.items;
}

/// trace2_session_id()
pub fn sessionId() []const u8 {
    return sidGet();
}

var hierarchy: []const u8 = "";

// ---------------------------------------------------------------- formatting helpers

fn jsonStr(b: *util.Buf, s: []const u8) void {
    util.bufByte(b, '"');
    for (s) |ch| {
        switch (ch) {
            '"' => util.bufAppend(b, "\\\""),
            '\\' => util.bufAppend(b, "\\\\"),
            '\n' => util.bufAppend(b, "\\n"),
            '\r' => util.bufAppend(b, "\\r"),
            '\t' => util.bufAppend(b, "\\t"),
            0x0c => util.bufAppend(b, "\\f"),
            0x08 => util.bufAppend(b, "\\b"),
            else => if (ch < 0x20) util.bufPrint(b, "\\u{x:0>4}", .{ch}) else util.bufByte(b, ch),
        }
    }
    util.bufByte(b, '"');
}

fn jKey(b: *util.Buf, key: []const u8) void {
    util.bufByte(b, ',');
    jsonStr(b, key);
    util.bufByte(b, ':');
}

fn jString(b: *util.Buf, key: []const u8, v: []const u8) void {
    jKey(b, key);
    jsonStr(b, v);
}

fn jInt(b: *util.Buf, key: []const u8, v: i64) void {
    jKey(b, key);
    util.bufPrint(b, "{d}", .{v});
}

/// "%.6f" of a microsecond count
fn secs(b: *util.Buf, us: i64) void {
    const u: u64 = if (us < 0) 0 else @intCast(us);
    util.bufPrint(b, "{d}.{d:0>6}", .{ u / 1000000, u % 1000000 });
}

fn jDouble(b: *util.Buf, key: []const u8, us: i64) void {
    jKey(b, key);
    secs(b, us);
}

fn jArgv(b: *util.Buf, key: []const u8, prefix_git: bool, argv: []const []const u8) void {
    jKey(b, key);
    util.bufByte(b, '[');
    var first = true;
    if (prefix_git) {
        jsonStr(b, "git");
        first = false;
    }
    for (argv) |a| {
        if (!first) util.bufByte(b, ',');
        first = false;
        jsonStr(b, a);
    }
    util.bufByte(b, ']');
}

/// sq_quote_buf_pretty()
fn sqPretty(b: *util.Buf, s: []const u8) void {
    @import("trace.zig").quoteArg(b, s);
}

/// sq_append_quote_argv_pretty()
fn sqArgv(b: *util.Buf, argv: []const []const u8) void {
    for (argv, 0..) |a, i| {
        if (i > 0) util.bufByte(b, ' ');
        sqPretty(b, a);
    }
}

fn nowUs() i64 {
    return os.nowMicros();
}

fn elapsedAbs(now: i64) i64 {
    return now - us_start_process;
}

fn nrOpen() usize {
    return region_starts.items.len;
}

fn regionElapsed(now: i64) i64 {
    if (region_starts.items.len == 0) return 0;
    return now - region_starts.items[region_starts.items.len - 1];
}

fn eventPrepare(b: *util.Buf, name: []const u8, file: []const u8, line: u32, with_repo: bool) void {
    util.bufAppend(b, "{\"event\":");
    jsonStr(b, name);
    jString(b, "sid", sidGet());
    jString(b, "thread", "main");
    if (!event_brief or util.eql(name, "version") or util.eql(name, "atexit")) {
        const us = nowUs();
        const tm = os.gmtime(@divFloor(us, 1000000));
        jKey(b, "time");
        util.bufPrint(b, "\"{d:0>4}-{d:0>2}-{d:0>2}T{d:0>2}:{d:0>2}:{d:0>2}.{d:0>6}Z\"", .{
            @as(u32, @intCast(tm.year + 1900)), @as(u32, @intCast(tm.mon + 1)), @as(u32, @intCast(tm.mday)),
            @as(u32, @intCast(tm.hour)),        @as(u32, @intCast(tm.min)),     @as(u32, @intCast(tm.sec)),
            @as(u64, @intCast(@mod(us, 1000000))),
        });
    }
    if (!event_brief and file.len > 0) {
        jString(b, "file", file);
        jInt(b, "line", line);
    }
    if (with_repo) jInt(b, "repo", repo_id);
}

fn eventWrite(b: *util.Buf) void {
    util.bufByte(b, '}');
    writeLine(&dst_event, b);
}

fn localTime(b: *util.Buf) void {
    const us = nowUs();
    const tm = os.localtime(@divFloor(us, 1000000));
    util.bufPrint(b, "{d:0>2}:{d:0>2}:{d:0>2}.{d:0>6}", .{
        @as(u32, @intCast(tm.hour)), @as(u32, @intCast(tm.min)), @as(u32, @intCast(tm.sec)),
        @as(u64, @intCast(@mod(us, 1000000))),
    });
}

fn normalWrite(file: []const u8, line: u32, payload: []const u8) void {
    var b: util.Buf = .empty;
    if (!normal_brief) {
        localTime(&b);
        util.bufByte(&b, ' ');
        if (file.len > 0) util.bufPrint(&b, "{s}:{d} ", .{ file, line });
        while (b.items.len < 50) util.bufByte(&b, ' ');
    }
    util.bufAppend(&b, payload);
    writeLine(&dst_normal, &b);
}

fn padTo(b: *util.Buf, col: usize) void {
    while (b.items.len < col) util.bufByte(b, ' ');
}

fn perfWrite(file: []const u8, line: u32, event: []const u8, with_repo: bool, abs: ?i64, rel: ?i64, category: ?[]const u8, payload: []const u8) void {
    var b: util.Buf = .empty;
    if (!perf_brief) {
        localTime(&b);
        util.bufByte(&b, ' ');
        const fl_end = b.items.len + 28;
        if (file.len > 0) {
            const fl = util.fmt("{s}:{d}", .{ file, line });
            if (fl.len <= 28) {
                util.bufAppend(&b, fl);
            } else {
                util.bufAppend(&b, "...");
                util.bufAppend(&b, fl[fl.len - 25 ..]);
            }
        }
        padTo(&b, fl_end);
        util.bufAppend(&b, " | ");
    }
    _ = sidGet();
    util.bufPrint(&b, "d{d} | ", .{sid_depth});
    util.bufPrint(&b, "{s:<24} | {s:<12} | ", .{ "main", event });
    const rl = b.items.len + 3;
    if (with_repo) util.bufPrint(&b, "r{d} ", .{repo_id});
    padTo(&b, rl);
    util.bufAppend(&b, " | ");
    inline for (.{ abs, rel }) |t| {
        if (t) |us| {
            var s: util.Buf = .empty;
            secs(&s, us);
            var k = s.items.len;
            while (k < 9) : (k += 1) util.bufByte(&b, ' ');
            util.bufAppend(&b, s.items);
            util.bufAppend(&b, " | ");
        } else {
            util.bufAppend(&b, "          | ");
        }
    }
    const cat = category orelse "";
    const c12 = if (cat.len > 12) cat[0..12] else cat;
    util.bufPrint(&b, "{s:<12} | ", .{c12});
    if (nrOpen() > 0) {
        var k: usize = 0;
        while (k < (nrOpen() - 1) * 2) : (k += 1) util.bufByte(&b, '.');
    }
    util.bufAppend(&b, payload);
    writeLine(&dst_perf, &b);
}

// targets wanted (checked per event like for_each_wanted_builtin)
fn wNormal() bool {
    return want(&dst_normal);
}
fn wPerf() bool {
    return want(&dst_perf);
}
fn wEvent() bool {
    return want(&dst_event);
}

// ---------------------------------------------------------------- redaction

fn redactArg(arg: []const u8) []const u8 {
    if (!redact) return arg;
    const p = util.skipPrefix(arg, "https://") orelse util.skipPrefix(arg, "http://") orelse return arg;
    const at = std.mem.indexOfAny(u8, p, "@/") orelse p.len;
    if (at >= p.len or p[at] != '@') return arg;
    const colon = std.mem.indexOfScalar(u8, p[0..at], ':') orelse return arg;
    const scheme_len = arg.len - p.len;
    return util.concat(&.{ arg[0 .. scheme_len + colon], ":<REDACTED>", p[at..] });
}

fn redactArgv(argv: []const []const u8) []const []const u8 {
    if (!redact) return argv;
    var changed = false;
    for (argv) |a| {
        if (redactArg(a).ptr != a.ptr) {
            changed = true;
            break;
        }
    }
    if (!changed) return argv;
    const out = gpa.alloc([]const u8, argv.len) catch util.oom();
    for (argv, 0..) |a, i| out[i] = redactArg(a);
    return out;
}

// ---------------------------------------------------------------- startup / exit

/// trace2_initialize_clock(): call as early as possible.
pub fn initializeClock() void {
    us_start_process = os.nowMicros();
}

/// trace2_initialize() + trace2_cmd_start() + process info (ancestry).
pub fn initialize(argv: []const []const u8) void {
    if (us_start_process == 0) initializeClock();
    // Cheap check first: no env var and no config file -> disabled.
    sysenvLoad();
    if (initTargets() == 0) return;
    enabled = true;
    if (os.getenv("GIT_TRACE2_REDACT")) |v| {
        if (config.parseMaybeBool(v) == 0) redact = false;
    }
    _ = sidGet();
    region_starts.append(gpa, us_start_process) catch util.oom();

    // version
    if (wNormal()) normalWrite("common-init.c", 77, "version " ++ version_string);
    if (wPerf()) perfWrite("common-init.c", 77, "version", false, null, null, null, version_string);
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "version", "common-init.c", 77, false);
        jString(&b, "evt", event_version);
        jString(&b, "exe", version_string);
        eventWrite(&b);
        if (dst_event.too_many_files) {
            var t: util.Buf = .empty;
            eventPrepare(&t, "too_many_files", "common-init.c", 77, false);
            eventWrite(&t);
        }
    }
    cmdStart(argv);
    collectAncestry();
}

fn cmdStart(argv_in: []const []const u8) void {
    const argv = redactArgv(argv_in);
    const abs = elapsedAbs(nowUs());
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, "start ");
        sqArgv(&p, argv);
        normalWrite("common-init.c", 78, p.items);
    }
    if (wPerf()) {
        var p: util.Buf = .empty;
        sqArgv(&p, argv);
        perfWrite("common-init.c", 78, "start", false, abs, null, null, p.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "start", "common-init.c", 78, false);
        jDouble(&b, "t_abs", abs);
        jArgv(&b, "argv", false, argv);
        eventWrite(&b);
    }
}

fn statParent(pid: c_int, names: *std.ArrayList([]const u8)) void {
    var depth: u32 = 0;
    var p = pid;
    while (p != 0 and depth < 64) : (depth += 1) {
        const data = os.readFile(util.fmt("/proc/{d}/stat", .{p})) orelse return;
        const d = data[0..@min(data.len, 64)];
        const lhs = std.mem.indexOfScalar(u8, d, '(') orelse return;
        const rhs = std.mem.lastIndexOfScalar(u8, d, ')') orelse return;
        if (rhs + 4 > d.len) return;
        const ppid_s = d[rhs + 4 ..];
        const sp = std.mem.indexOfScalar(u8, ppid_s, ' ') orelse return;
        const ppid = std.fmt.parseInt(c_int, ppid_s[0..sp], 10) catch return;
        names.append(gpa, d[lhs + 1 .. rhs]) catch util.oom();
        p = ppid;
    }
}

fn collectAncestry() void {
    var names: std.ArrayList([]const u8) = .empty;
    statParent(getppid(), &names);
    if (names.items.len == 0) return;
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, "cmd_ancestry ");
        for (names.items, 0..) |n, i| {
            if (i > 0) util.bufAppend(&p, " <- ");
            util.bufAppend(&p, n);
        }
        normalWrite("compat/linux/procinfo.c", 170, p.items);
    }
    if (wPerf()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, "ancestry:[");
        sqArgv(&p, names.items);
        util.bufByte(&p, ']');
        perfWrite("compat/linux/procinfo.c", 170, "cmd_ancestry", false, null, null, null, p.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "cmd_ancestry", "compat/linux/procinfo.c", 170, false);
        jArgv(&b, "ancestry", false, names.items);
        eventWrite(&b);
    }
}

/// trace2_cmd_exit(): emit "exit" (once).
pub fn cmdExit(code: u8) void {
    if (!enabled or exit_emitted) return;
    exit_emitted = true;
    exit_code = code;
    const abs = elapsedAbs(nowUs());
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, "exit elapsed:");
        secs(&p, abs);
        util.bufPrint(&p, " code:{d}", .{code});
        normalWrite(exit_file, exit_line, p.items);
    }
    if (wPerf()) perfWrite(exit_file, exit_line, "exit", false, abs, null, null, util.fmt("code:{d}", .{code}));
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "exit", exit_file, exit_line, false);
        jDouble(&b, "t_abs", abs);
        jInt(&b, "code", code);
        eventWrite(&b);
    }
}

/// tr2main_atexit_handler(): emit "atexit" and close the targets.
pub fn atexit() void {
    if (!enabled or atexit_emitted) return;
    atexit_emitted = true;
    const abs = elapsedAbs(nowUs());
    if (region_starts.items.len > 1) region_starts.shrinkRetainingCapacity(1);
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, "atexit elapsed:");
        secs(&p, abs);
        util.bufPrint(&p, " code:{d}", .{exit_code});
        normalWrite("trace2/tr2_tgt_normal.c", 128, p.items);
    }
    if (wPerf()) perfWrite("trace2/tr2_tgt_perf.c", 219, "atexit", false, abs, null, null, util.fmt("code:{d}", .{exit_code}));
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "atexit", "trace2/tr2_tgt_event.c", 207, false);
        jDouble(&b, "t_abs", abs);
        jInt(&b, "code", exit_code);
        eventWrite(&b);
    }
    dstDisable(&dst_normal);
    dstDisable(&dst_perf);
    dstDisable(&dst_event);
    enabled = false;
}

/// exit + atexit, for process exit paths.
pub fn finish(code: u8) void {
    if (!enabled) return;
    cmdExit(code);
    atexit();
}

// ---------------------------------------------------------------- errors

/// Convert a Zig format string to the C-ish one git would log in "fmt".
pub fn cFormat(comptime f: []const u8) []const u8 {
    comptime {
        @setEvalBranchQuota(100000);
        var out: []const u8 = "";
        var i: usize = 0;
        while (i < f.len) {
            const ch = f[i];
            if (ch == '{') {
                if (i + 1 < f.len and f[i + 1] == '{') {
                    out = out ++ "{";
                    i += 2;
                    continue;
                }
                const end = std.mem.indexOfScalarPos(u8, f, i, '}') orelse f.len - 1;
                const spec = f[i + 1 .. end];
                const conv: []const u8 = if (std.mem.indexOfScalar(u8, spec, 'd') != null) "%d" else if (std.mem.indexOfScalar(u8, spec, 'c') != null and spec.len == 1) "%c" else if (std.mem.indexOfScalar(u8, spec, 'x') != null) "%x" else "%s";
                out = out ++ conv;
                i = end + 1;
                continue;
            }
            if (ch == '}' and i + 1 < f.len and f[i + 1] == '}') {
                out = out ++ "}";
                i += 2;
                continue;
            }
            out = out ++ &[_]u8{ch};
            i += 1;
        }
        const final = out;
        return final;
    }
}

/// trace2_cmd_error_va()
pub fn cmdError(msg: []const u8, fmt_: []const u8, line: u32) void {
    if (!enabled) return;
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, "error");
        if (fmt_.len > 0) {
            util.bufByte(&p, ' ');
            util.bufAppend(&p, msg);
        }
        normalWrite("usage.c", line, p.items);
    }
    if (wPerf()) perfWrite("usage.c", line, "error", false, null, null, null, if (fmt_.len > 0) msg else "");
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "error", "usage.c", line, false);
        if (fmt_.len > 0) {
            jString(&b, "msg", msg);
            jString(&b, "fmt", fmt_);
        }
        eventWrite(&b);
    }
}

// ---------------------------------------------------------------- command info

/// trace2_cmd_name()
pub fn cmdName(name: []const u8) void {
    if (!enabled) return;
    var h: util.Buf = .empty;
    if (os.getenv("GIT_TRACE2_PARENT_NAME")) |p| {
        if (p.len > 0) {
            util.bufAppend(&h, p);
            util.bufByte(&h, '/');
        }
    }
    util.bufAppend(&h, name);
    hierarchy = h.items;
    os.setEnv("GIT_TRACE2_PARENT_NAME", hierarchy);
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "cmd_name {s}", .{name});
        if (hierarchy.len > 0) util.bufPrint(&p, " ({s})", .{hierarchy});
        normalWrite("git.c", 0, p.items);
    }
    if (wPerf()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, name);
        if (hierarchy.len > 0) util.bufPrint(&p, " ({s})", .{hierarchy});
        perfWrite("git.c", 0, "cmd_name", false, null, null, null, p.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "cmd_name", "git.c", 0, false);
        jString(&b, "name", name);
        if (hierarchy.len > 0) jString(&b, "hierarchy", hierarchy);
        eventWrite(&b);
    }
    listConfig();
    listEnvVars();
}

/// trace2_cmd_mode()
pub fn cmdMode(mode: []const u8) void {
    if (!enabled) return;
    if (wNormal()) normalWrite("", 0, util.fmt("cmd_mode {s}", .{mode}));
    if (wPerf()) perfWrite("", 0, "cmd_mode", false, null, null, null, mode);
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "cmd_mode", "", 0, false);
        jString(&b, "name", mode);
        eventWrite(&b);
    }
}

/// trace2_cmd_alias()
pub fn cmdAlias(alias: []const u8, argv: []const []const u8) void {
    if (!enabled) return;
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "alias {s} -> ", .{alias});
        sqArgv(&p, argv);
        normalWrite("git.c", 0, p.items);
    }
    if (wPerf()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "alias:{s} argv:[", .{alias});
        sqArgv(&p, argv);
        util.bufByte(&p, ']');
        perfWrite("git.c", 0, "alias", false, null, null, null, p.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "alias", "git.c", 0, false);
        jString(&b, "alias", alias);
        jArgv(&b, "argv", false, argv);
        eventWrite(&b);
    }
}

/// trace2_cmd_path()
pub fn cmdPath(path: []const u8) void {
    if (!enabled) return;
    if (wNormal()) normalWrite("", 0, util.fmt("cmd_path {s}", .{path}));
    if (wPerf()) perfWrite("", 0, "cmd_path", false, null, null, null, path);
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "cmd_path", "", 0, false);
        jString(&b, "path", path);
        eventWrite(&b);
    }
}

/// trace2_def_param()
pub fn defParam(param: []const u8, value_in: ?[]const u8, scope: []const u8) void {
    if (!enabled) return;
    const value: ?[]const u8 = if (value_in) |v| redactArg(v) else null;
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "def_param scope:{s} {s}", .{ scope, param });
        if (value) |v| util.bufPrint(&p, "={s}", .{v});
        normalWrite("", 0, p.items);
    }
    if (wPerf()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, param);
        if (value) |v| util.bufPrint(&p, ":{s}", .{v});
        perfWrite("", 0, "def_param", false, null, null, util.fmt("scope:{s}", .{scope}), p.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "def_param", "", 0, false);
        jString(&b, "scope", scope);
        jString(&b, "param", param);
        if (value) |v| jString(&b, "value", v);
        eventWrite(&b);
    }
}

var cfg_patterns: ?[][]const u8 = null;

fn splitList(s: []const u8) [][]const u8 {
    var l: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, s, ',');
    while (it.next()) |part| {
        const t = std.mem.trim(u8, part, " \t\n\r\x0b\x0c");
        l.append(gpa, t) catch util.oom();
    }
    return l.items;
}

fn loadPatterns() [][]const u8 {
    if (cfg_patterns) |p| return p;
    const v = sysenvGet(.cfg_param) orelse "";
    cfg_patterns = if (v.len == 0) &.{} else splitList(v);
    return cfg_patterns.?;
}

fn cfgMatch(key: []const u8) bool {
    const wm = @import("wildmatch.zig");
    for (loadPatterns()) |p| {
        if (wm.match(p, key, wm.CASEFOLD)) return true;
    }
    return false;
}

var config_listed = false;
var env_listed = false;

/// trace2_cmd_list_config()
pub fn listConfig() void {
    if (!enabled or config_listed) return;
    config_listed = true;
    if (loadPatterns().len == 0) return;
    const cfg = @import("help.zig").earlyConfig();
    for (cfg.entries.items) |e| {
        if (cfgMatch(e.key)) defParam(e.key, e.value, e.scope.name());
    }
}

/// trace2_cmd_list_env_vars()
pub fn listEnvVars() void {
    if (!enabled or env_listed) return;
    env_listed = true;
    const v = sysenvGet(.env_vars) orelse return;
    if (v.len == 0) return;
    for (splitList(v)) |name| {
        if (name.len == 0) continue;
        const val = os.getenv(name) orelse continue;
        if (val.len > 0) defParam(name, val, "command");
    }
}

/// trace2_cmd_set_config()
pub fn cmdSetConfig(key: []const u8, value: ?[]const u8) void {
    if (!enabled) return;
    if (loadPatterns().len == 0) return;
    if (cfgMatch(key)) defParam(key, value, "unknown");
}

/// trace2_def_repo(): the_repository got a worktree.
pub fn defRepo(worktree: []const u8) void {
    if (!enabled or repo_id != 0) return;
    repo_id = next_repo_id;
    next_repo_id += 1;
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, "worktree ");
        sqPretty(&p, worktree);
        normalWrite("repository.c", 256, p.items);
    }
    if (wPerf()) {
        var p: util.Buf = .empty;
        util.bufAppend(&p, "worktree:");
        sqPretty(&p, worktree);
        perfWrite("repository.c", 256, "def_repo", true, null, null, null, p.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "def_repo", "repository.c", 256, true);
        jString(&b, "worktree", worktree);
        eventWrite(&b);
    }
}

// ---------------------------------------------------------------- children

pub const ChildInfo = struct {
    argv: []const []const u8,
    /// argv omits the leading "git" (run_command with git_cmd = 1)
    git_cmd: bool = false,
    class: ?[]const u8 = null,
    hook_name: ?[]const u8 = null,
    dir: ?[]const u8 = null,
    use_shell: bool = false,
};

pub const Child = struct {
    id: i32 = -1,
    us_start: i64 = 0,
};

const PidEntry = struct { pid: c_int, child: Child };
var pid_children: std.ArrayList(PidEntry) = .empty;

/// trace2_child_start()
pub fn childStart(info: ChildInfo) Child {
    if (!enabled) return .{};
    const now = nowUs();
    const abs = elapsedAbs(now);
    const ch = Child{ .id = next_child_id, .us_start = now };
    next_child_id += 1;
    const argv = redactArgv(info.argv);
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "child_start[{d}]", .{ch.id});
        if (info.dir) |d| {
            util.bufAppend(&p, " cd ");
            sqPretty(&p, d);
            util.bufAppend(&p, ";");
        }
        util.bufByte(&p, ' ');
        if (info.git_cmd) util.bufAppend(&p, "git ");
        sqArgv(&p, argv);
        normalWrite("run-command.c", 740, p.items);
    }
    if (wPerf()) {
        var p: util.Buf = .empty;
        if (info.hook_name) |h| {
            util.bufPrint(&p, "[ch{d}] class:hook hook:{s}", .{ ch.id, h });
        } else util.bufPrint(&p, "[ch{d}] class:{s}", .{ ch.id, info.class orelse "?" });
        if (info.dir) |d| {
            util.bufAppend(&p, " cd:");
            sqPretty(&p, d);
        }
        util.bufAppend(&p, " argv:[");
        if (info.git_cmd) {
            util.bufAppend(&p, "git");
            if (argv.len > 0) util.bufByte(&p, ' ');
        }
        sqArgv(&p, argv);
        util.bufByte(&p, ']');
        perfWrite("run-command.c", 740, "child_start", false, abs, null, null, p.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "child_start", "run-command.c", 740, false);
        jInt(&b, "child_id", ch.id);
        if (info.hook_name) |h| {
            jString(&b, "child_class", "hook");
            jString(&b, "hook_name", h);
        } else jString(&b, "child_class", info.class orelse "?");
        if (info.dir) |d| jString(&b, "cd", d);
        jKey(&b, "use_shell");
        util.bufAppend(&b, if (info.use_shell) "true" else "false");
        jArgv(&b, "argv", info.git_cmd, argv);
        eventWrite(&b);
    }
    return ch;
}

/// Derive ChildInfo from a spawn argv: our own git binary becomes git_cmd.
pub fn childInfoFor(argv: []const []const u8) ChildInfo {
    if (argv.len > 0 and util.eql(util.basename(argv[0]), "git")) {
        return .{ .argv = argv[1..], .git_cmd = true };
    }
    return .{ .argv = argv };
}

/// trace2_child_exit()
pub fn childExit(ch: Child, pid: c_int, code: i32) void {
    if (!enabled or ch.id < 0) return;
    const now = nowUs();
    const abs = elapsedAbs(now);
    const rel = if (ch.us_start != 0) now - ch.us_start else 0;
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "child_exit[{d}] pid:{d} code:{d} elapsed:", .{ ch.id, pid, code });
        secs(&p, rel);
        normalWrite("run-command.c", 1007, p.items);
    }
    if (wPerf()) perfWrite("run-command.c", 1007, "child_exit", false, abs, rel, null, util.fmt("[ch{d}] pid:{d} code:{d}", .{ ch.id, pid, code }));
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "child_exit", "run-command.c", 1007, false);
        jInt(&b, "child_id", ch.id);
        jInt(&b, "pid", pid);
        jInt(&b, "code", code);
        jDouble(&b, "t_rel", rel);
        eventWrite(&b);
    }
}

/// Remember a started child by pid (for spawn/wait style APIs).
pub fn registerPid(ch: Child, pid: c_int) void {
    if (!enabled or ch.id < 0) return;
    pid_children.append(gpa, .{ .pid = pid, .child = ch }) catch util.oom();
}

/// child_exit for a child registered with registerPid().
pub fn childExitPid(pid: c_int, code: i32) void {
    if (!enabled) return;
    for (pid_children.items, 0..) |e, i| {
        if (e.pid == pid) {
            _ = pid_children.swapRemove(i);
            childExit(e.child, pid, code);
            return;
        }
    }
}

/// trace2_child_ready()
pub fn childReady(ch: Child, pid: c_int, ready: []const u8) void {
    if (!enabled or ch.id < 0) return;
    const now = nowUs();
    const abs = elapsedAbs(now);
    const rel = if (ch.us_start != 0) now - ch.us_start else 0;
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "child_ready[{d}] pid:{d} ready:{s} elapsed:", .{ ch.id, pid, ready });
        secs(&p, rel);
        normalWrite("run-command.c", 2069, p.items);
    }
    if (wPerf()) perfWrite("run-command.c", 2069, "child_ready", false, abs, rel, null, util.fmt("[ch{d}] pid:{d} ready:{s}", .{ ch.id, pid, ready }));
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "child_ready", "run-command.c", 2069, false);
        jInt(&b, "child_id", ch.id);
        jInt(&b, "pid", pid);
        jString(&b, "ready", ready);
        jDouble(&b, "t_rel", rel);
        eventWrite(&b);
    }
}

/// trace2_exec(): returns the exec id (or -1).
pub fn exec(exe: ?[]const u8, argv_in: []const []const u8) i32 {
    if (!enabled) return -1;
    const abs = elapsedAbs(nowUs());
    const id = next_exec_id;
    next_exec_id += 1;
    const argv = redactArgv(argv_in);
    if (wNormal()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "exec[{d}] ", .{id});
        if (exe) |e| util.bufPrint(&p, "{s} ", .{e});
        sqArgv(&p, argv);
        normalWrite("run-command.c", 243, p.items);
    }
    if (wPerf()) {
        var p: util.Buf = .empty;
        util.bufPrint(&p, "id:{d} argv:[", .{id});
        if (exe) |e| {
            util.bufAppend(&p, e);
            if (argv.len > 0) util.bufByte(&p, ' ');
        }
        sqArgv(&p, argv);
        util.bufByte(&p, ']');
        perfWrite("run-command.c", 243, "exec", false, abs, null, null, p.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "exec", "run-command.c", 243, false);
        jInt(&b, "exec_id", id);
        if (exe) |e| jString(&b, "exe", e);
        jArgv(&b, "argv", false, argv);
        eventWrite(&b);
    }
    return id;
}

/// trace2_exec_result()
pub fn execResult(id: i32, code: i32) void {
    if (!enabled) return;
    const abs = elapsedAbs(nowUs());
    var p: util.Buf = .empty;
    util.bufPrint(&p, "exec_result[{d}] code:{d}", .{ id, code });
    if (code > 0) util.bufPrint(&p, " err:{s}", .{os.strErr(code)});
    if (wNormal()) normalWrite("run-command.c", 252, p.items);
    if (wPerf()) {
        var q: util.Buf = .empty;
        util.bufPrint(&q, "id:{d} code:{d}", .{ id, code });
        if (code > 0) util.bufPrint(&q, " err:{s}", .{os.strErr(code)});
        perfWrite("run-command.c", 252, "exec_result", false, abs, null, null, q.items);
    }
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "exec_result", "run-command.c", 252, false);
        jInt(&b, "exec_id", id);
        jInt(&b, "code", code);
        eventWrite(&b);
    }
}

// ---------------------------------------------------------------- regions and data

/// trace2_region_enter(category, label, repo). `repo` = pass the_repository.
pub fn regionEnter(category: []const u8, label: []const u8, repo: bool) void {
    regionEnterMsg(category, label, repo, null);
}

/// trace2_region_enter_printf()
pub fn regionEnterMsg(category: ?[]const u8, label: ?[]const u8, repo: bool, msg: ?[]const u8) void {
    if (!enabled) return;
    const now = nowUs();
    const abs = elapsedAbs(now);
    if (wPerf()) {
        var p: util.Buf = .empty;
        if (label) |l| util.bufPrint(&p, "label:{s}", .{l});
        if (msg) |m| if (m.len > 0) {
            util.bufByte(&p, ' ');
            util.bufAppend(&p, m);
        };
        perfWrite("", 0, "region_enter", repo, abs, null, category, p.items);
    }
    if (wEvent() and nrOpen() <= event_max_nesting) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "region_enter", "", 0, repo);
        jInt(&b, "nesting", @intCast(nrOpen()));
        if (category) |c| jString(&b, "category", c);
        if (label) |l| jString(&b, "label", l);
        if (msg) |m| if (m.len > 0) jString(&b, "msg", m);
        eventWrite(&b);
    }
    region_starts.append(gpa, now) catch util.oom();
}

/// trace2_region_leave(category, label, repo)
pub fn regionLeave(category: []const u8, label: []const u8, repo: bool) void {
    regionLeaveMsg(category, label, repo, null);
}

/// trace2_region_leave_printf()
pub fn regionLeaveMsg(category: ?[]const u8, label: ?[]const u8, repo: bool, msg: ?[]const u8) void {
    if (!enabled) return;
    const now = nowUs();
    const abs = elapsedAbs(now);
    const rel = regionElapsed(now);
    if (region_starts.items.len > 0) _ = region_starts.pop();
    if (wPerf()) {
        var p: util.Buf = .empty;
        if (label) |l| util.bufPrint(&p, "label:{s}", .{l});
        if (msg) |m| if (m.len > 0) {
            util.bufByte(&p, ' ');
            util.bufAppend(&p, m);
        };
        perfWrite("", 0, "region_leave", repo, abs, rel, category, p.items);
    }
    if (wEvent() and nrOpen() <= event_max_nesting) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "region_leave", "", 0, repo);
        jDouble(&b, "t_rel", rel);
        jInt(&b, "nesting", @intCast(nrOpen()));
        if (category) |c| jString(&b, "category", c);
        if (label) |l| jString(&b, "label", l);
        if (msg) |m| if (m.len > 0) jString(&b, "msg", m);
        eventWrite(&b);
    }
}

/// trace2_data_string()
pub fn dataString(category: []const u8, repo: bool, key: []const u8, value: []const u8) void {
    if (!enabled) return;
    const now = nowUs();
    const abs = elapsedAbs(now);
    const rel = regionElapsed(now);
    if (wPerf()) perfWrite("", 0, "data", repo, abs, rel, category, util.fmt("{s}:{s}", .{ key, value }));
    if (wEvent() and nrOpen() <= event_max_nesting) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "data", "", 0, repo);
        jDouble(&b, "t_abs", abs);
        jDouble(&b, "t_rel", rel);
        jInt(&b, "nesting", @intCast(nrOpen()));
        jString(&b, "category", category);
        jString(&b, "key", key);
        jString(&b, "value", value);
        eventWrite(&b);
    }
}

/// trace2_data_intmax()
pub fn dataInt(category: []const u8, repo: bool, key: []const u8, value: i64) void {
    if (!enabled) return;
    dataString(category, repo, key, util.fmt("{d}", .{value}));
}

/// trace2_data_json(): `json` is an already-serialized JSON value.
pub fn dataJson(category: []const u8, repo: bool, key: []const u8, json: []const u8) void {
    if (!enabled) return;
    const now = nowUs();
    const abs = elapsedAbs(now);
    const rel = regionElapsed(now);
    if (wPerf()) perfWrite("", 0, "data_json", repo, abs, rel, category, util.fmt("{s}:{s}", .{ key, json }));
    if (wEvent() and nrOpen() <= event_max_nesting) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "data_json", "", 0, repo);
        jDouble(&b, "t_abs", abs);
        jDouble(&b, "t_rel", rel);
        jInt(&b, "nesting", @intCast(nrOpen()));
        jString(&b, "category", category);
        jString(&b, "key", key);
        jKey(&b, "value");
        util.bufAppend(&b, json);
        eventWrite(&b);
    }
}

/// trace2_printf()
pub fn printf(msg: []const u8) void {
    if (!enabled) return;
    const abs = elapsedAbs(nowUs());
    if (wNormal()) normalWrite("", 0, msg);
    if (wPerf()) perfWrite("", 0, "printf", false, abs, null, null, msg);
    if (wEvent()) {
        var b: util.Buf = .empty;
        eventPrepare(&b, "printf", "", 0, false);
        jDouble(&b, "t_abs", abs);
        if (msg.len > 0) jString(&b, "msg", msg);
        eventWrite(&b);
    }
}
