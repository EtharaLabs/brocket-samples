//! git in Zig: entry point and command dispatch.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const cmds = @import("commands.zig");

pub const version = "2.56.1";

pub var argv0: []const u8 = "git";
pub var exec_path: []const u8 = "";
pub var use_pager: ?bool = null;

fn usage() noreturn {
    util.eprint(
        \\usage: git [-v | --version] [-h | --help] [-C <path>] [-c <name>=<value>]
        \\           [--exec-path[=<path>]] [--html-path] [--man-path] [--info-path]
        \\           [-p | --paginate | -P | --no-pager] [--no-replace-objects] [--no-lazy-fetch]
        \\           [--no-optional-locks] [--no-advice] [--bare] [--git-dir=<path>]
        \\           [--work-tree=<path>] [--namespace=<name>] [--config-env=<name>=<envvar>]
        \\           <command> [<args>]
        \\
    , .{});
    os.exit(129);
}

fn computeExecPath() []const u8 {
    if (os.getenv("GIT_EXEC_PATH")) |p| return p;
    // directory of the running binary
    if (os.readLink("/proc/self/exe")) |p| return util.dirname(p);
    return "/usr/libexec/git-core";
}

pub export fn main(argc: c_int, argv: [*][*:0]u8) callconv(.c) c_int {
    var args: std.ArrayList([]const u8) = .empty;
    var i: usize = 0;
    while (i < @as(usize, @intCast(argc))) : (i += 1) {
        args.append(util.gpa, std.mem.span(argv[i])) catch util.oom();
    }
    const code = run(args.items);
    util.flushStdout();
    os.waitPager();
    return code;
}

fn run(all: []const []const u8) u8 {
    if (all.len > 0) argv0 = all[0];
    exec_path = computeExecPath();
    var args = all[1..];
    // invoked as git-foo?
    const base = util.basename(argv0);
    if (util.startsWith(base, "git-")) {
        var l: std.ArrayList([]const u8) = .empty;
        l.append(util.gpa, base[4..]) catch util.oom();
        l.appendSlice(util.gpa, args) catch util.oom();
        return dispatch(l.items);
    }
    while (args.len > 0) {
        const a = args[0];
        if (a.len == 0 or a[0] != '-') break;
        if (util.eql(a, "--version") or util.eql(a, "-v")) {
            return cmds.dispatchName("version", args[1..]);
        } else if (util.eql(a, "--help") or util.eql(a, "-h")) {
            if (args.len > 1) {
                return cmds.dispatchName("help", args[1..]);
            }
            usage();
        } else if (util.startsWith(a, "--exec-path")) {
            if (util.skipPrefix(a, "--exec-path=")) |p| {
                os.setEnv("GIT_EXEC_PATH", p);
                exec_path = p;
            } else {
                util.outf("{s}\n", .{exec_path});
                return 0;
            }
        } else if (util.eql(a, "--html-path")) {
            util.out("/usr/share/doc/git/html\n");
            return 0;
        } else if (util.eql(a, "--man-path")) {
            util.out("/usr/share/man\n");
            return 0;
        } else if (util.eql(a, "--info-path")) {
            util.out("/usr/share/info\n");
            return 0;
        } else if (util.eql(a, "-p") or util.eql(a, "--paginate")) {
            use_pager = true;
        } else if (util.eql(a, "-P") or util.eql(a, "--no-pager")) {
            use_pager = false;
        } else if (util.eql(a, "--no-replace-objects")) {
            os.setEnv("GIT_NO_REPLACE_OBJECTS", "1");
        } else if (util.eql(a, "--no-lazy-fetch") or util.eql(a, "--no-optional-locks") or util.eql(a, "--no-advice")) {
            if (util.eql(a, "--no-optional-locks")) os.setEnv("GIT_OPTIONAL_LOCKS", "0");
            if (util.eql(a, "--no-advice")) os.setEnv("GIT_ADVICE", "0");
        } else if (util.eql(a, "--literal-pathspecs")) {
            os.setEnv("GIT_LITERAL_PATHSPECS", "1");
        } else if (util.eql(a, "--glob-pathspecs")) {
            os.setEnv("GIT_GLOB_PATHSPECS", "1");
        } else if (util.eql(a, "--noglob-pathspecs")) {
            os.setEnv("GIT_NOGLOB_PATHSPECS", "1");
        } else if (util.eql(a, "--icase-pathspecs")) {
            os.setEnv("GIT_ICASE_PATHSPECS", "1");
        } else if (util.eql(a, "--bare")) {
            const cwd = os.getcwd();
            os.setEnv("GIT_DIR", cwd);
            os.unsetEnv("GIT_WORK_TREE");
            os.setEnv("GIT_IMPLICIT_WORK_TREE", "0");
        } else if (util.startsWith(a, "--git-dir")) {
            if (util.skipPrefix(a, "--git-dir=")) |p| {
                os.setEnv("GIT_DIR", p);
            } else {
                if (args.len < 2) {
                    util.eprint("no directory given for --git-dir\n", .{});
                    usage();
                }
                os.setEnv("GIT_DIR", args[1]);
                args = args[1..];
            }
        } else if (util.startsWith(a, "--work-tree")) {
            if (util.skipPrefix(a, "--work-tree=")) |p| {
                os.setEnv("GIT_WORK_TREE", p);
            } else {
                if (args.len < 2) {
                    util.eprint("no directory given for --work-tree\n", .{});
                    usage();
                }
                os.setEnv("GIT_WORK_TREE", args[1]);
                args = args[1..];
            }
        } else if (util.startsWith(a, "--namespace")) {
            if (util.skipPrefix(a, "--namespace=")) |p| {
                os.setEnv("GIT_NAMESPACE", p);
            } else {
                if (args.len < 2) usage();
                os.setEnv("GIT_NAMESPACE", args[1]);
                args = args[1..];
            }
        } else if (util.eql(a, "-C")) {
            if (args.len < 2) {
                util.eprint("no directory given for -C\n", .{});
                usage();
            }
            if (args[1].len > 0 and !os.chdir(args[1])) util.dieErrno("cannot change to '{s}'", .{args[1]});
            args = args[1..];
        } else if (util.eql(a, "-c")) {
            if (args.len < 2) {
                util.eprint("-c expects a configuration string\n", .{});
                usage();
            }
            const kv = args[1];
            const eq = std.mem.indexOfScalar(u8, kv, '=');
            const key = if (eq) |e| kv[0..e] else kv;
            switch (@import("config.zig").parseKey(key)) {
                .ok => {},
                .err => |m| {
                    util.err("{s}", .{m});
                    util.die("unable to parse command-line config", .{});
                },
            }
            repo_mod.addCmdlineConfig(kv);
            args = args[1..];
        } else if (util.startsWith(a, "--config-env")) {
            var spec: []const u8 = undefined;
            if (util.skipPrefix(a, "--config-env=")) |p| {
                spec = p;
            } else {
                if (args.len < 2) usage();
                spec = args[1];
                args = args[1..];
            }
            const eq = std.mem.lastIndexOfScalar(u8, spec, '=') orelse util.die("missing config value for '{s}'", .{spec});
            const val = os.getenv(spec[eq + 1 ..]) orelse util.die("missing environment variable '{s}' for configuration '{s}'", .{ spec[eq + 1 ..], spec[0..eq] });
            repo_mod.addCmdlineConfig(util.concat(&.{ spec[0..eq], "=", val }));
            args = args[1..];
        } else if (util.eql(a, "--list-cmds") or util.startsWith(a, "--list-cmds=")) {
            cmds.listCommands();
            return 0;
        } else {
            util.eprint("unknown option: {s}\n", .{a});
            usage();
        }
        args = args[1..];
    }
    if (args.len == 0) {
        usage();
    }
    return dispatch(args);
}

fn dispatch(args: []const []const u8) u8 {
    return cmds.dispatch(args);
}
