//! Author/committer identities.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const date = @import("date.zig");

fn isCrud(ch: u8) bool {
    return ch <= 32 or ch == '.' or ch == ',' or ch == ':' or ch == ';' or ch == '<' or ch == '>' or ch == '"' or ch == '\\' or ch == '\'';
}

/// Strip leading/trailing crud and remove '<', '>' and newlines.
pub fn sanitize(s: []const u8) []const u8 {
    var start: usize = 0;
    var end: usize = s.len;
    while (start < end and isCrud(s[start])) start += 1;
    while (end > start and isCrud(s[end - 1])) end -= 1;
    var b: util.Buf = .empty;
    for (s[start..end]) |ch| {
        if (ch == '<' or ch == '>' or ch == '\n') continue;
        util.bufByte(&b, ch);
    }
    return b.items;
}

pub const Who = enum { author, committer };

pub fn getName(who: Who) ?[]const u8 {
    const env = if (who == .author) "GIT_AUTHOR_NAME" else "GIT_COMMITTER_NAME";
    if (os.getenv(env)) |v| return v;
    const key = if (who == .author) "author.name" else "committer.name";
    if (repo_mod.cfg.get(key)) |v| return v;
    if (repo_mod.cfg.get("user.name")) |v| return v;
    return null;
}

pub fn getEmail(who: Who) ?[]const u8 {
    const env = if (who == .author) "GIT_AUTHOR_EMAIL" else "GIT_COMMITTER_EMAIL";
    if (os.getenv(env)) |v| return v;
    const key = if (who == .author) "author.email" else "committer.email";
    if (repo_mod.cfg.get(key)) |v| return v;
    if (repo_mod.cfg.get("user.email")) |v| return v;
    if (os.getenv("EMAIL")) |v| return v;
    return null;
}

fn defaultName() []const u8 {
    if (os.getenv("USER")) |u| return u;
    return "unknown";
}

fn defaultEmail() []const u8 {
    var buf: [256]u8 = undefined;
    var host: []const u8 = "localhost";
    if (std.c.gethostname(&buf, buf.len) == 0) host = std.mem.sliceTo(&buf, 0);
    return util.concat(&.{ defaultName(), "@", host, ".(none)" });
}

pub fn identityUnknown() noreturn {
    util.eprint(
        \\Author identity unknown
        \\
        \\*** Please tell me who you are.
        \\
        \\Run
        \\
        \\  git config --global user.email "you@example.com"
        \\  git config --global user.name "Your Name"
        \\
        \\to set your account's default identity.
        \\Omit --global to set the identity only in this repository.
        \\
        \\
    , .{});
    util.die("unable to auto-detect email address (got '{s}')", .{defaultEmail()});
}

pub fn dateFor(who: Who) []const u8 {
    const env = if (who == .author) "GIT_AUTHOR_DATE" else "GIT_COMMITTER_DATE";
    if (os.getenv(env)) |v| {
        if (date.parseDate(v)) |d| return util.fmt("{d} {s}", .{ d.time, date.formatTz(d.tz) });
        util.die("invalid date format: {s}", .{v});
    }
    return date.nowString();
}

/// "Name <email> time tz"
pub fn ident(who: Who, strict: bool) []const u8 {
    const name0 = getName(who);
    const email0 = getEmail(who);
    if (strict and (name0 == null and email0 == null)) identityUnknown();
    const name = sanitize(name0 orelse defaultName());
    const email = sanitize(email0 orelse defaultEmail());
    if (strict and name.len == 0) {
        if (name0 != null) util.die("empty ident name (for <{s}>) not allowed", .{email});
    }
    return util.fmt("{s} <{s}> {s}", .{ name, email, dateFor(who) });
}

pub fn committer() []const u8 {
    return ident(.committer, false);
}
pub fn author() []const u8 {
    return ident(.author, false);
}
pub fn committerStrict() []const u8 {
    return ident(.committer, true);
}
pub fn authorStrict() []const u8 {
    return ident(.author, true);
}

pub const Split = struct {
    name: []const u8,
    email: []const u8,
    date: []const u8, // "time tz" (may be empty)
    time: i64 = 0,
    tz: i32 = 0,
};

/// Parse "Name <email> time tz"
pub fn split(line: []const u8) ?Split {
    const lt = std.mem.indexOfScalar(u8, line, '<') orelse return null;
    const gt = std.mem.lastIndexOfScalar(u8, line, '>') orelse return null;
    if (gt < lt) return null;
    var name = line[0..lt];
    while (name.len > 0 and name[name.len - 1] == ' ') name = name[0 .. name.len - 1];
    const email = line[lt + 1 .. gt];
    var rest = line[gt + 1 ..];
    while (rest.len > 0 and rest[0] == ' ') rest = rest[1..];
    var s = Split{ .name = name, .email = email, .date = rest };
    var it = std.mem.tokenizeScalar(u8, rest, ' ');
    if (it.next()) |t| s.time = std.fmt.parseInt(i64, t, 10) catch 0;
    if (it.next()) |z| s.tz = date.parseTzOffset(z) orelse 0;
    return s;
}
