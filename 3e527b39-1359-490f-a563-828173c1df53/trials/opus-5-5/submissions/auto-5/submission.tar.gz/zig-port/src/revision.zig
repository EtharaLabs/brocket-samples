//! Revision walking (port of revision.c, diff-merges.c and list-objects.c).
//!
//! Typical use:
//!   var revs = revision.RevInfo.init(prefix);
//!   const rest = revision.setupRevisions(&revs, args, .{ .def = "HEAD" });
//!   revision.prepareRevisionWalk(&revs);
//!   while (revision.getRevision(&revs)) |c| { ... }
//!
//! Diff / pretty integration is done via hooks (diff_parse, diff_finish,
//! format_hook, patch_id_hook) installed by the caller (cmd/log.zig).

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const cn = @import("commitnode.zig");
const date = @import("date.zig");
const graph_mod = @import("graph.zig");
const reflogwalk = @import("reflogwalk.zig");
const grepfilter = @import("grepfilter.zig");
const pathspec = @import("pathspec.zig");
const revparse = @import("revparse.zig");
const refs = @import("refs.zig");
const objects = @import("objects.zig");
const wildmatch = @import("wildmatch.zig");
const repo_mod = @import("repo.zig");
const commitreach = @import("commitreach.zig");
const mailmap_mod = @import("mailmap.zig");
const logtree = @import("logtree.zig");
const os = @import("os.zig");
const index_mod = @import("index.zig");
const Oid = hash.Oid;
const Commit = cn.Commit;
const CommitList = cn.CommitList;
const Obj = cn.Obj;
const gpa = util.gpa;

const SEEN = cn.SEEN;
const UNINTERESTING = cn.UNINTERESTING;
const TREESAME = cn.TREESAME;
const SHOWN = cn.SHOWN;
const TMP_MARK = cn.TMP_MARK;
const BOUNDARY = cn.BOUNDARY;
const CHILD_SHOWN = cn.CHILD_SHOWN;
const ADDED = cn.ADDED;
const SYMMETRIC_LEFT = cn.SYMMETRIC_LEFT;
const PATCHSAME = cn.PATCHSAME;
const BOTTOM = cn.BOTTOM;
const PULL_MERGE = cn.PULL_MERGE;
const NOT_USER_GIVEN = cn.NOT_USER_GIVEN;
const TRACK_LINEAR = cn.TRACK_LINEAR;
const ANCESTRY_PATH = cn.ANCESTRY_PATH;
const CHILD_VISITED = cn.CHILD_VISITED;

pub const CmitFmt = enum { raw, medium, short, full, fuller, oneline, email, mboxrd, userformat, unspecified };

pub const CommitAction = enum { ignore, show, error_ };

pub const UNSET_TIME: u64 = std.math.maxInt(u64);

// diff output format bits (diff.h)
pub const DIFF_FORMAT_RAW: u32 = 0x0001;
pub const DIFF_FORMAT_DIFFSTAT: u32 = 0x0002;
pub const DIFF_FORMAT_NUMSTAT: u32 = 0x0004;
pub const DIFF_FORMAT_SUMMARY: u32 = 0x0008;
pub const DIFF_FORMAT_PATCH: u32 = 0x0010;
pub const DIFF_FORMAT_SHORTSTAT: u32 = 0x0020;
pub const DIFF_FORMAT_DIRSTAT: u32 = 0x0040;
pub const DIFF_FORMAT_NAME: u32 = 0x0100;
pub const DIFF_FORMAT_NAME_STATUS: u32 = 0x0200;
pub const DIFF_FORMAT_CHECKDIFF: u32 = 0x0400;
pub const DIFF_FORMAT_NO_OUTPUT: u32 = 0x0800;
pub const DIFF_FORMAT_CALLBACK: u32 = 0x1000;

pub const REVARG_CANNOT_BE_FILENAME: u32 = 1;
pub const REVARG_COMMITTISH: u32 = 2;

pub const Whence = enum { rev, parents_only, left, right, merge_base, reflog, ref };

pub const PendingEntry = struct {
    item: *Obj,
    name: []const u8,
    mode: u32 = 0o170000, // S_IFINVALID
    path: ?[]const u8 = null,
};

pub const CmdlineEntry = struct {
    item: *Obj,
    name: []const u8,
    whence: Whence,
    flags: u32,
};

const TreesameState = struct {
    nparents: usize,
    treesame: []u8,
};

pub const SetupOpt = struct {
    def: ?[]const u8 = null,
    revarg_opt: u32 = 0,
    assume_dashdash: bool = false,
    tweak: ?*const fn (*RevInfo) void = null,
};

pub const RevInfo = struct {
    // --- work queue ---
    commits: ?*CommitList = null,
    pending: std.ArrayList(PendingEntry) = .empty,
    cmdline: std.ArrayList(CmdlineEntry) = .empty,
    boundary_commits: std.ArrayList(*Commit) = .empty,
    commit_queue: cn.PrioQueue = .{ .compare = cn.compareByCommitDate },
    // --- basic ---
    prefix: []const u8 = "",
    def: ?[]const u8 = null,
    prune_data: pathspec.Pathspec = .{},

    sort_order: cn.SortOrder = .graph,

    // traversal flags
    dense: bool = true,
    prune: bool = false,
    no_walk: bool = false,
    unsorted_input: bool = false,
    remove_empty_trees: bool = false,
    simplify_history: bool = true,
    show_pulls: bool = false,
    topo_order: bool = false,
    simplify_merges: bool = false,
    simplify_by_decoration: bool = false,
    single_worktree: bool = false,
    tag_objects: bool = false,
    tree_objects: bool = false,
    blob_objects: bool = false,
    verify_objects: bool = false,
    edge_hint: bool = false,
    edge_hint_aggressive: bool = false,
    limited: bool = false,
    unpacked: bool = false,
    /// 0, 1 or 2 (boundary:2 bitfield in C)
    boundary: u2 = 0,
    count: bool = false,
    left_right: bool = false,
    left_only: bool = false,
    right_only: bool = false,
    rewrite_parents: bool = false,
    print_parents: bool = false,
    show_decorations: bool = false,
    reverse: bool = false,
    reverse_output_stage: bool = false,
    cherry_pick: bool = false,
    cherry_mark: bool = false,
    bisect: bool = false,
    ancestry_path: bool = false,
    ancestry_path_implicit_bottoms: bool = false,
    ancestry_path_bottoms: ?*CommitList = null,
    first_parent_only: bool = false,
    exclude_first_parent_only: bool = false,
    line_level_traverse: bool = false,
    tree_blobs_in_commit_order: bool = false,
    maximal_only: bool = false,
    ignore_missing: bool = false,
    ignore_missing_links: bool = false,
    rev_input_given: bool = false,
    read_from_stdin: u32 = 0,
    disable_stdin: bool = false,
    children_enabled: bool = false,
    treesame_enabled: bool = false,

    // diff flags
    diff: bool = false,
    full_diff: bool = false,
    show_root_diff: bool = false,
    no_commit_id: bool = false,
    verbose_header: bool = false,
    always_show_header: bool = false,
    /// diffopt.output_format mirror (diff hooks keep it in sync)
    output_format: u32 = 0,
    diff_recursive: bool = false,
    diff_tree_in_recursive: bool = false,
    pickaxe_ignore_case: bool = false,
    /// set by the diff hook: pickaxe / filter / follow given
    diff_wants_diff: bool = false,
    follow_renames: bool = false,
    diff_objfind: bool = false,

    // diff-merges
    separate_merges: bool = false,
    first_parent_merges: bool = false,
    combine_merges: bool = false,
    dense_combined_merges: bool = false,
    combined_all_paths: bool = false,
    merges_imply_patch: bool = false,
    merges_need_diff: bool = false,
    remerge_diff: bool = false,
    explicit_diff_merges: bool = false,

    // format info
    shown_one: bool = false,
    shown_dashes: bool = false,
    show_merge: bool = false,
    pretty_given: bool = false,
    abbrev_commit: bool = false,
    abbrev_commit_given: bool = false,
    zero_commit: bool = false,
    use_terminator: bool = false,
    missing_newline: bool = false,
    date_mode_explicit: bool = false,
    preserve_subject: bool = false,
    force_in_body_from: bool = false,
    encode_email_headers: bool = false,
    show_notes: bool = false,
    show_notes_given: bool = false,
    show_notes_by_default: bool = false,
    notes_use_default: i32 = -1,
    notes_refs: std.ArrayList([]const u8) = .empty,
    show_signature: bool = false,
    track_linear: bool = false,
    track_first_time: bool = false,
    linear: bool = false,
    break_bar: []const u8 = "",
    previous_parents: ?*CommitList = null,

    date_mode: date.DateMode = .{},
    /// unset if negative
    expand_tabs_in_log: i32 = -1,
    expand_tabs_in_log_default: i32 = 8,
    /// 0 = full hex
    abbrev: usize = 0,
    commit_format: CmitFmt = .medium,
    /// user format string for .userformat (set by pretty.getCommitFormat)
    user_format: []const u8 = "",
    nr: i32 = 0,
    total: i32 = 0,
    subject_prefix: ?[]const u8 = null,
    show_log_size: bool = false,
    /// colors enabled for this output
    use_color: bool = false,
    /// mailmap enabled (--use-mailmap / log.mailmap)
    use_mailmap: bool = false,
    mailmap: ?*mailmap_mod.Map = null,

    // graph
    graph: ?*graph_mod.Graph = null,
    graph_max_lanes: i32 = 0,
    no_graph_indent: bool = false,
    graph_indent_set: bool = false,

    // limits
    skip_count: i32 = -1,
    max_count: i32 = -1,
    max_count_type: u8 = 0,
    max_count_stage: u8 = 0,
    max_age: u64 = UNSET_TIME,
    max_age_as_filter: u64 = UNSET_TIME,
    min_age: u64 = UNSET_TIME,
    min_parents: i32 = 0,
    max_parents: i32 = -1,

    /// --source: map commit index -> source name
    sources: ?*cn.Slab(?[]const u8) = null,

    /// reflog walk state (set for -g)
    reflog_info: ?*reflogwalk.Info = null,

    grep: grepfilter.Filter = .{},
    ref_excludes: std.ArrayList([]const u8) = .empty,
    hidden_refs_configured: bool = false,

    treesame: cn.Slab(?*TreesameState) = cn.Slab(?*TreesameState).init(null),
    simplified: cn.Slab(?*Commit) = cn.Slab(?*Commit).init(null),
    simplified_state: cn.Slab(bool) = cn.Slab(bool).init(false),
    children: cn.Slab(?*CommitList) = cn.Slab(?*CommitList).init(null),
    saved_parents: ?*cn.Slab(?SavedParents) = null,

    count_left: i32 = 0,
    count_right: i32 = 0,
    count_same: i32 = 0,

    // pruning diff state
    prune_has_changes: bool = false,

    // ---- hooks ----
    /// get_commit_format(arg, revs); arg null for bare --pretty
    format_hook: ?*const fn (*RevInfo, ?[]const u8) void = null,
    /// diff_opt_parse: returns number of args consumed (0 = unknown)
    diff_parse: ?*const fn (*RevInfo, []const []const u8) usize = null,
    /// called near the end of setupRevisions (diff_setup_done etc.)
    diff_finish: ?*const fn (*RevInfo) void = null,
    /// patch id of a commit (null if undefined, e.g. merges)
    patch_id_hook: ?*const fn (*RevInfo, *Commit) ?Oid = null,
    /// opaque per-command diff options
    diffopt: ?*anyopaque = null,
    /// diff machinery used by log-tree (installed by diff integration)
    diff_ops: ?*const DiffOps = null,
    /// diffopt.line_termination ('\0' with -z)
    line_termination: u8 = '\n',
    /// current log_info (set during logtree.logTreeCommit)
    loginfo: ?*LogInfo = null,
    /// format-patch / email output fields
    extra_headers: ?[]const u8 = null,
    add_signoff: bool = false,
    mime_boundary: ?[]const u8 = null,
    message_id: ?[]const u8 = null,
    ref_message_ids: std.ArrayList([]const u8) = .empty,
    numbered_files: bool = false,
    no_inline: bool = false,
    patch_suffix: []const u8 = ".patch",
    patch_name_max: usize = 64,
    reroll_count: ?[]const u8 = null,
    from_ident: ?[]const u8 = null,
    /// diffopt.stat_sep (for attachments)
    stat_sep: ?[]const u8 = null,

    pub fn init(prefix: []const u8) RevInfo {
        var r = RevInfo{ .prefix = prefix };
        r.abbrev = revparse.defaultAbbrev();
        return r;
    }

    /// pending object helpers
    pub fn addPendingObject(revs: *RevInfo, obj: *Obj, name: []const u8) void {
        addPendingObjectWithPath(revs, obj, name, 0o170000, null);
    }
};

pub const LogInfo = struct {
    commit: *Commit,
    parent: ?*Commit = null,
};

/// Diff machinery hooks used by log-tree (see diff.zig).
pub const DiffOps = struct {
    /// diff_tree_oid(old, new, "", &diffopt): queue the changes between two
    /// trees (old == null: root commit, compare against the empty tree)
    diff_tree: *const fn (revs: *RevInfo, old: ?Oid, new: Oid) void,
    /// diffcore_std(); returns false if the resulting queue is empty
    diffcore: *const fn (revs: *RevInfo) bool,
    /// diff_flush() with the configured output format (clears the queue)
    flush: *const fn (revs: *RevInfo) void,
    /// drop the queued pairs without output
    discard: *const fn (revs: *RevInfo) void,
    /// diff_line_prefix() (graph prefix etc.)
    line_prefix: *const fn (revs: *RevInfo) []const u8,
    /// diff_tree_combined_merge(commit, revs); must call
    /// logtree.showLog(revs) first when revs.loginfo != null and !revs.no_commit_id
    combined_merge: *const fn (revs: *RevInfo, commit: *Commit) void,
    /// diffopt.flags.exit_with_status
    exit_with_status: *const fn (revs: *RevInfo) bool,
    /// color for a diff slot (e.g. "commit", "reset", "frag", "whitespace")
    get_color: *const fn (revs: *RevInfo, slot: []const u8) []const u8,
};

pub const SavedParents = union(enum) { empty, list: ?*CommitList };

/// log output encoding (--encoding / i18n.logOutputEncoding). null = default.
pub var log_output_encoding: ?[]const u8 = null;

/// Re-encode hook for commit messages (set by pretty integration).
pub var reencode_hook: ?*const fn (*Commit, []const u8) []const u8 = null;

/// Default for "-m" (log.diffMerges)
pub const DiffMergesFn = enum { none, first_parent, separate, combined, dense_combined, remerge };
pub var diff_merges_default: DiffMergesFn = .separate;
pub var suppress_m_parsing: bool = false;

fn logOutputEncoding() []const u8 {
    if (log_output_encoding) |e| return e;
    if (repo_mod.cfg.get("i18n.logoutputencoding")) |e| return e;
    if (repo_mod.cfg.get("i18n.commitencoding")) |e| return e;
    return "UTF-8";
}

// ---------------------------------------------------------------------------
// trees

var tree_cache: hash.OidMap([]objects.TreeEntry) = .empty;

fn readTreeCached(oid: Oid) ?[]objects.TreeEntry {
    if (tree_cache.get(oid)) |t| return t;
    const t = objects.readTree(oid) orelse return null;
    tree_cache.put(gpa, oid, t) catch util.oom();
    return t;
}

fn isGitlink(mode: u32) bool {
    return mode & 0o170000 == 0o160000;
}

fn markBlobUninteresting(oid: Oid) void {
    const o = cn.lookup(oid, .blob) orelse return;
    o.flags |= UNINTERESTING;
}

fn markTreeContentsUninteresting(oid: Oid) void {
    const entries = readTreeCached(oid) orelse return;
    for (entries) |e| {
        if (e.isDir()) {
            if (cn.lookup(e.oid, .tree)) |t| markTreeUninteresting(t);
        } else if (!isGitlink(e.mode)) {
            markBlobUninteresting(e.oid);
        }
    }
}

pub fn markTreeUninteresting(tree: *Obj) void {
    if (tree.flags & UNINTERESTING != 0) return;
    tree.flags |= UNINTERESTING;
    markTreeContentsUninteresting(tree.oid);
}

fn commitTree(c: *Commit) ?*Obj {
    if (!cn.parse(c)) return null;
    return cn.lookup(c.tree, .tree);
}

// ---------------------------------------------------------------------------
// uninteresting marking

fn markOneParentUninteresting(revs: ?*RevInfo, commit: *Commit, pending: *std.ArrayList(*Commit)) void {
    if (commit.obj.flags & UNINTERESTING != 0) return;
    commit.obj.flags |= UNINTERESTING;
    var l = commit.parents;
    while (l) |x| : (l = x.next) {
        pending.append(gpa, x.item) catch util.oom();
        if (revs) |r| if (r.exclude_first_parent_only) break;
    }
}

pub fn markParentsUninteresting(revs: ?*RevInfo, commit: *Commit) void {
    var pending: std.ArrayList(*Commit) = .empty;
    var l = commit.parents;
    while (l) |x| : (l = x.next) {
        markOneParentUninteresting(revs, x.item, &pending);
        if (revs) |r| if (r.exclude_first_parent_only) break;
    }
    while (pending.pop()) |c| markOneParentUninteresting(revs, c, &pending);
}

// ---------------------------------------------------------------------------
// pending / cmdline

fn addPendingObjectWithPath(revs: *RevInfo, obj: *Obj, name: []const u8, mode: u32, path: ?[]const u8) void {
    if (revs.no_walk and obj.flags & UNINTERESTING != 0) revs.no_walk = false;
    if (revs.reflog_info) |ri| {
        if (obj.typ == .commit) {
            var nm = name;
            if (util.startsWith(name, "@{-")) {
                if (std.mem.indexOfScalar(u8, name, '}')) |close| {
                    const expanded = revparse.interpretBranchName(name[0 .. close + 1]);
                    if (!util.eql(expanded, name[0 .. close + 1])) nm = util.concat(&.{ expanded, name[close + 1 ..] });
                }
            }
            _ = reflogwalk.addReflogForWalk(ri, Commit.fromObj(obj), nm);
            return;
        }
    }
    revs.pending.append(gpa, .{ .item = obj, .name = name, .mode = mode, .path = path }) catch util.oom();
}

pub fn addPendingOid(revs: *RevInfo, name: []const u8, oid: Oid, flags: u32) void {
    const o = getReference(revs, name, oid, flags) orelse return;
    revs.addPendingObject(o, name);
}

pub fn addHeadToPending(revs: *RevInfo) void {
    const oid = revparse.getOid("HEAD") orelse return;
    const o = cn.parseObject(oid) orelse return;
    revs.addPendingObject(o, "HEAD");
}

fn getReference(revs: *RevInfo, name: []const u8, oid: Oid, flags: u32) ?*Obj {
    const o = cn.parseObject(oid) orelse {
        if (revs.ignore_missing) return null;
        util.die("bad object {s}", .{name});
    };
    o.flags |= flags;
    return o;
}

fn addRevCmdline(revs: *RevInfo, item: *Obj, name: []const u8, whence: Whence, flags: u32) void {
    revs.cmdline.append(gpa, .{ .item = item, .name = util.dupe(name), .whence = whence, .flags = flags }) catch util.oom();
}

fn addRevCmdlineList(revs: *RevInfo, list: ?*CommitList, whence: Whence, flags: u32) void {
    var l = list;
    while (l) |x| : (l = x.next) {
        const h = x.item.hex();
        addRevCmdline(revs, &x.item.obj, &h, whence, flags);
    }
}

fn addPendingCommitList(revs: *RevInfo, list: ?*CommitList, flags: u32) void {
    var l = list;
    while (l) |x| : (l = x.next) {
        x.item.obj.flags |= flags;
        const h = x.item.hex();
        revs.addPendingObject(&x.item.obj, util.dupe(&h));
    }
}

fn handleCommit(revs: *RevInfo, entry: PendingEntry) ?*Commit {
    var object = entry.item;
    const name = entry.name;
    var path = entry.path;
    var mode = entry.mode;
    const flags = object.flags;

    while (object.typ == .tag) {
        const data = repo_mod.repo().odb().read(object.oid) orelse util.die("bad object {s}", .{hash.hex(object.oid)});
        const tag = objects.parseTag(data.data) orelse util.die("bad object {s}", .{hash.hex(object.oid)});
        if (revs.tag_objects and flags & UNINTERESTING == 0)
            revs.addPendingObject(object, tag.tag);
        object = cn.parseObject(tag.object) orelse {
            if (revs.ignore_missing_links or flags & UNINTERESTING != 0) return null;
            util.die("bad object {s}", .{hash.hex(tag.object)});
        };
        object.flags |= flags;
        path = null;
        mode = 0;
    }

    if (object.typ == .commit) {
        const commit = Commit.fromObj(object);
        if (!cn.parse(commit)) util.die("unable to parse commit {s}", .{name});
        if (flags & UNINTERESTING != 0) {
            markParentsUninteresting(revs, commit);
            revs.limited = true;
        }
        if (revs.sources) |s| {
            const slot = s.at(commit);
            if (slot.* == null) slot.* = util.dupe(name);
        }
        return commit;
    }
    if (object.typ == .tree) {
        if (!revs.tree_objects) return null;
        if (flags & UNINTERESTING != 0) {
            markTreeContentsUninteresting(object.oid);
            return null;
        }
        addPendingObjectWithPath(revs, object, name, mode, path);
        return null;
    }
    if (object.typ == .blob) {
        if (!revs.blob_objects) return null;
        if (flags & UNINTERESTING != 0) return null;
        addPendingObjectWithPath(revs, object, name, mode, path);
        return null;
    }
    util.die("{s} is unknown object", .{name});
}

// ---------------------------------------------------------------------------
// relevance / treesame

fn relevantCommit(c: *Commit) bool {
    return c.obj.flags & (UNINTERESTING | BOTTOM) != UNINTERESTING;
}

fn oneRelevantParent(revs: *const RevInfo, orig: ?*CommitList) ?*Commit {
    const o = orig orelse return null;
    if (revs.first_parent_only or o.next == null) return o.item;
    var relevant: ?*Commit = null;
    var l: ?*CommitList = o;
    while (l) |x| : (l = x.next) {
        const commit = x.item;
        if (relevantCommit(commit)) {
            if (relevant != null) return null;
            relevant = commit;
        }
    }
    return relevant;
}

const REV_TREE_SAME: u8 = 0;
const REV_TREE_NEW: u8 = 1;
const REV_TREE_OLD: u8 = 2;
const REV_TREE_DIFFERENT: u8 = 3;

var tree_difference: u8 = REV_TREE_SAME;

fn pruneAddRemove(revs: *RevInfo, add: bool) void {
    tree_difference |= if (add) REV_TREE_NEW else REV_TREE_OLD;
    if (!revs.remove_empty_trees or tree_difference != REV_TREE_NEW)
        revs.prune_has_changes = true;
}

fn pruneChange(revs: *RevInfo) void {
    tree_difference = REV_TREE_DIFFERENT;
    revs.prune_has_changes = true;
}

fn entryInteresting(ps: *const pathspec.Pathspec, full: []const u8, is_dir: bool) bool {
    if (ps.isEmpty()) return true;
    if (is_dir) return ps.matches(full, true) or ps.couldMatchUnder(full);
    return ps.matches(full, false);
}

fn joinBase(base: []const u8, name: []const u8) []const u8 {
    if (base.len == 0) return name;
    return util.concat(&.{ base, "/", name });
}

/// one-sided subtree: report every interesting file as added/removed
fn pruneOneSide(revs: *RevInfo, oid: Oid, base: []const u8, add: bool) void {
    const entries = readTreeCached(oid) orelse return;
    for (entries) |e| {
        if (revs.prune_has_changes) return;
        const full = joinBase(base, e.name);
        if (!entryInteresting(&revs.prune_data, full, e.isDir())) continue;
        if (e.isDir()) {
            pruneOneSide(revs, e.oid, full, add);
        } else pruneAddRemove(revs, add);
    }
}

fn pruneDiffTrees(revs: *RevInfo, a: ?Oid, b: ?Oid, base: []const u8) void {
    const ea: []objects.TreeEntry = if (a) |x| (readTreeCached(x) orelse &.{}) else &.{};
    const eb: []objects.TreeEntry = if (b) |x| (readTreeCached(x) orelse &.{}) else &.{};
    var i: usize = 0;
    var j: usize = 0;
    while (i < ea.len or j < eb.len) {
        if (revs.prune_has_changes) return;
        var ord: std.math.Order = undefined;
        if (i >= ea.len) {
            ord = .gt;
        } else if (j >= eb.len) {
            ord = .lt;
        } else ord = objects.baseNameCompare(ea[i].name, ea[i].mode, eb[j].name, eb[j].mode);
        switch (ord) {
            .lt => {
                const e = ea[i];
                i += 1;
                const full = joinBase(base, e.name);
                if (!entryInteresting(&revs.prune_data, full, e.isDir())) continue;
                if (e.isDir()) pruneOneSide(revs, e.oid, full, false) else pruneAddRemove(revs, false);
            },
            .gt => {
                const e = eb[j];
                j += 1;
                const full = joinBase(base, e.name);
                if (!entryInteresting(&revs.prune_data, full, e.isDir())) continue;
                if (e.isDir()) pruneOneSide(revs, e.oid, full, true) else pruneAddRemove(revs, true);
            },
            .eq => {
                const x = ea[i];
                const y = eb[j];
                i += 1;
                j += 1;
                if (hash.eql(x.oid, y.oid) and x.mode == y.mode) continue;
                const full = joinBase(base, x.name);
                if (!entryInteresting(&revs.prune_data, full, x.isDir())) continue;
                if (x.isDir() and y.isDir()) {
                    pruneDiffTrees(revs, x.oid, y.oid, full);
                } else if (x.isDir() != y.isDir()) {
                    // cannot happen (baseNameCompare separates them)
                    pruneChange(revs);
                } else {
                    // type change (S_IFMT differs) is delete + add
                    if ((x.mode & 0o170000) != (y.mode & 0o170000)) {
                        pruneAddRemove(revs, false);
                        pruneAddRemove(revs, true);
                    } else pruneChange(revs);
                }
            },
        }
    }
}

fn revCompareTree(revs: *RevInfo, parent: *Commit, commit: *Commit, nth_parent: usize) u8 {
    _ = nth_parent;
    if (!cn.parse(parent)) return REV_TREE_NEW;
    if (!cn.parse(commit)) return REV_TREE_OLD;
    if (revs.simplify_by_decoration) {
        if (logtree.hasNameDecoration(&commit.obj)) return REV_TREE_DIFFERENT;
        if (revs.prune_data.isEmpty()) return REV_TREE_SAME;
    }
    tree_difference = REV_TREE_SAME;
    revs.prune_has_changes = false;
    pruneDiffTrees(revs, parent.tree, commit.tree, "");
    return tree_difference;
}

fn revSameTreeAsEmpty(revs: *RevInfo, commit: *Commit) bool {
    if (!cn.parse(commit)) return false;
    tree_difference = REV_TREE_SAME;
    revs.prune_has_changes = false;
    pruneDiffTrees(revs, null, commit.tree, "");
    return tree_difference == REV_TREE_SAME;
}

fn initialiseTreesame(revs: *RevInfo, commit: *Commit) *TreesameState {
    const n = commit.parentCount();
    const st = gpa.create(TreesameState) catch util.oom();
    const arr = gpa.alloc(u8, n) catch util.oom();
    @memset(arr, 0);
    st.* = .{ .nparents = n, .treesame = arr };
    revs.treesame.at(commit).* = st;
    return st;
}

fn lookupTreesame(revs: *RevInfo, commit: *Commit) ?*TreesameState {
    const p = revs.treesame.peek(commit) orelse return null;
    return p.*;
}

fn compactTreesame(revs: *RevInfo, commit: *Commit, nth_parent: usize) bool {
    if (commit.parents == null) {
        if (nth_parent != 0) util.die("compact_treesame {d}", .{nth_parent});
        const old_same = commit.obj.flags & TREESAME != 0;
        if (revSameTreeAsEmpty(revs, commit)) {
            commit.obj.flags |= TREESAME;
        } else commit.obj.flags &= ~TREESAME;
        return old_same;
    }
    const st = lookupTreesame(revs, commit) orelse util.die("compact_treesame {d}", .{nth_parent});
    if (nth_parent >= st.nparents) util.die("compact_treesame {d}", .{nth_parent});
    const old_same = st.treesame[nth_parent] != 0;
    std.mem.copyForwards(u8, st.treesame[nth_parent .. st.nparents - 1], st.treesame[nth_parent + 1 .. st.nparents]);
    st.nparents -= 1;
    if (st.nparents == 1) {
        if (commit.parents.?.next != null) util.die("compact_treesame parents mismatch", .{});
        if (st.treesame[0] != 0 and revs.dense) {
            commit.obj.flags |= TREESAME;
        } else commit.obj.flags &= ~TREESAME;
        revs.treesame.at(commit).* = null;
    }
    return old_same;
}

fn updateTreesame(revs: *RevInfo, commit: *Commit) bool {
    if (commit.parents != null and commit.parents.?.next != null) {
        const st = lookupTreesame(revs, commit) orelse util.die("update_treesame {s}", .{commit.hex()});
        var relevant_parents: usize = 0;
        var relevant_change = false;
        var irrelevant_change = false;
        var p = commit.parents;
        var n: usize = 0;
        while (p) |x| : ({
            p = x.next;
            n += 1;
        }) {
            if (relevantCommit(x.item)) {
                relevant_change = relevant_change or st.treesame[n] == 0;
                relevant_parents += 1;
            } else irrelevant_change = irrelevant_change or st.treesame[n] == 0;
        }
        if (if (relevant_parents != 0) relevant_change else irrelevant_change) {
            commit.obj.flags &= ~TREESAME;
        } else commit.obj.flags |= TREESAME;
    }
    return commit.obj.flags & TREESAME != 0;
}

fn limitingCanIncreaseTreesame(revs: *const RevInfo) bool {
    return revs.prune and revs.dense and !revs.simplify_history and !revs.first_parent_only;
}

fn tryToSimplifyCommit(revs: *RevInfo, commit: *Commit) void {
    if (!revs.prune) return;
    if (!cn.parse(commit)) return;
    if (commit.parents == null) {
        if (revSameTreeAsEmpty(revs, commit)) commit.obj.flags |= TREESAME;
        return;
    }
    if (!revs.dense and commit.parents.?.next == null) return;

    var ts: ?*TreesameState = null;
    var relevant_change = false;
    var irrelevant_change = false;
    var relevant_parents: usize = 0;
    var nth_parent: usize = 0;
    var pp: *?*CommitList = &commit.parents;
    while (pp.*) |parent| : ({
        pp = &parent.next;
        nth_parent += 1;
    }) {
        const p = parent.item;
        if (relevantCommit(p)) relevant_parents += 1;
        if (nth_parent == 1) {
            if (revs.first_parent_only) break;
            if (revs.treesame_enabled and !revs.simplify_history and commit.obj.flags & UNINTERESTING == 0) {
                ts = initialiseTreesame(revs, commit);
                if (!(irrelevant_change or relevant_change)) ts.?.treesame[0] = 1;
            }
        }
        if (!cn.parse(p))
            util.die("cannot simplify commit {s} (because of {s})", .{ commit.hex(), p.hex() });
        switch (revCompareTree(revs, p, commit, nth_parent)) {
            REV_TREE_SAME => {
                if (!revs.simplify_history or !relevantCommit(p)) {
                    if (ts) |t| t.treesame[nth_parent] = 1;
                    continue;
                }
                parent.next = null;
                commit.parents = parent;
                if (!revs.show_pulls or nth_parent == 0)
                    commit.obj.flags |= TREESAME;
                return;
            },
            else => |d| {
                if (d == REV_TREE_NEW) {
                    if (revs.remove_empty_trees and revSameTreeAsEmpty(revs, p)) {
                        if (!cn.parse(p))
                            util.die("cannot simplify commit {s} (invalid {s})", .{ commit.hex(), p.hex() });
                        p.parents = null;
                    }
                }
                if (relevantCommit(p)) {
                    relevant_change = true;
                } else irrelevant_change = true;
                if (nth_parent == 0) commit.obj.flags |= PULL_MERGE;
                continue;
            },
        }
    }
    if (if (relevant_parents != 0) !relevant_change else !irrelevant_change)
        commit.obj.flags |= TREESAME;
}

fn processParents(revs: *RevInfo, commit: *Commit, queue: ?*cn.PrioQueue) bool {
    if (commit.obj.flags & ADDED != 0) return true;
    commit.obj.flags |= ADDED;

    if (commit.obj.flags & UNINTERESTING != 0) {
        var parent = commit.parents;
        while (parent) |x| {
            const p = x.item;
            parent = x.next;
            p.obj.flags |= UNINTERESTING | CHILD_VISITED;
            if (!cn.parse(p)) {
                if (revs.exclude_first_parent_only) break;
                continue;
            }
            if (p.parents != null) markParentsUninteresting(revs, p);
            if (p.obj.flags & SEEN != 0) {
                if (revs.exclude_first_parent_only) break;
                continue;
            }
            p.obj.flags |= SEEN | NOT_USER_GIVEN;
            if (queue) |q| q.put(p);
            if (revs.exclude_first_parent_only) break;
        }
        return true;
    }

    tryToSimplifyCommit(revs, commit);
    if (revs.no_walk) return true;

    const pass_flags = commit.obj.flags & (SYMMETRIC_LEFT | ANCESTRY_PATH);
    var parent = commit.parents;
    while (parent) |x| : (parent = x.next) {
        const p = x.item;
        if (!cn.parse(p)) {
            if (!revs.ignore_missing_links) return false;
        }
        if (revs.sources) |s| {
            const slot = s.at(p);
            if (slot.* == null) slot.* = s.at(commit).*;
        }
        p.obj.flags |= pass_flags | CHILD_VISITED;
        if (p.obj.flags & SEEN == 0) {
            p.obj.flags |= SEEN | NOT_USER_GIVEN;
            if (queue) |q| q.put(p);
        }
        if (revs.first_parent_only) break;
    }
    return true;
}

// ---------------------------------------------------------------------------
// limiting

fn cherryPickList(list: ?*CommitList, revs: *RevInfo) void {
    var left_count: usize = 0;
    var right_count: usize = 0;
    var p = list;
    while (p) |x| : (p = x.next) {
        const flags = x.item.obj.flags;
        if (flags & BOUNDARY != 0) {} else if (flags & SYMMETRIC_LEFT != 0) {
            left_count += 1;
        } else right_count += 1;
    }
    if (left_count == 0 or right_count == 0) return;
    const hook = revs.patch_id_hook orelse return;
    const left_first = left_count < right_count;

    var ids: hash.OidMap(std.ArrayList(*Commit)) = .empty;
    p = list;
    while (p) |x| : (p = x.next) {
        const commit = x.item;
        const flags = commit.obj.flags;
        if (flags & BOUNDARY != 0) continue;
        if (left_first != (flags & SYMMETRIC_LEFT != 0)) continue;
        const id = hook(revs, commit) orelse continue;
        const gop = ids.getOrPut(gpa, id) catch util.oom();
        if (!gop.found_existing) gop.value_ptr.* = .empty;
        gop.value_ptr.append(gpa, commit) catch util.oom();
    }
    const cherry_flag: u32 = if (revs.cherry_mark) PATCHSAME else SHOWN;
    p = list;
    while (p) |x| : (p = x.next) {
        const commit = x.item;
        const flags = commit.obj.flags;
        if (flags & BOUNDARY != 0) continue;
        if (left_first == (flags & SYMMETRIC_LEFT != 0)) continue;
        if (commit.parents != null and commit.parents.?.next != null) continue;
        const id = hook(revs, commit) orelse continue;
        const lst = ids.getPtr(id) orelse continue;
        if (lst.items.len == 0) continue;
        commit.obj.flags |= cherry_flag;
        for (lst.items) |c| c.obj.flags |= cherry_flag;
    }
}

const SLOP = 5;

fn everybodyUninteresting(q: *cn.PrioQueue, cache: *?*Commit) bool {
    if (cache.*) |c| {
        if (c.obj.flags & UNINTERESTING == 0) return false;
    }
    for (q.items()) |it| {
        const c = it.data;
        if (c.obj.flags & UNINTERESTING != 0) continue;
        cache.* = c;
        return false;
    }
    return true;
}

fn stillInteresting(src: *cn.PrioQueue, d: u64, slop: i32, cache: *?*Commit) i32 {
    const commit = src.peek() orelse return 0;
    if (d <= commit.date) return SLOP;
    if (!everybodyUninteresting(src, cache)) return SLOP;
    return slop - 1;
}

fn limitToAncestry(bottoms: ?*CommitList, list: ?*CommitList) void {
    var rlist: ?*CommitList = null;
    var p = list;
    while (p) |x| : (p = x.next) _ = cn.listInsert(x.item, &rlist);
    p = bottoms;
    while (p) |x| : (p = x.next) x.item.obj.flags |= TMP_MARK;
    var made_progress = true;
    while (made_progress) {
        made_progress = false;
        p = rlist;
        while (p) |x| : (p = x.next) {
            const c = x.item;
            if (c.obj.flags & (TMP_MARK | UNINTERESTING) != 0) continue;
            var pa = c.parents;
            while (pa) |y| : (pa = y.next) {
                if (y.item.obj.flags & TMP_MARK == 0) continue;
                c.obj.flags |= TMP_MARK;
                made_progress = true;
                break;
            }
        }
    }
    p = list;
    while (p) |x| : (p = x.next) {
        const c = x.item;
        if (c.obj.flags & (TMP_MARK | ANCESTRY_PATH) != 0) continue;
        c.obj.flags |= UNINTERESTING;
    }
    p = list;
    while (p) |x| : (p = x.next) x.item.obj.flags &= ~(TMP_MARK | ANCESTRY_PATH);
    p = bottoms;
    while (p) |x| : (p = x.next) x.item.obj.flags &= ~(TMP_MARK | ANCESTRY_PATH);
}

fn limitLeftRight(list: ?*CommitList, revs: *RevInfo) void {
    var p = list;
    while (p) |x| : (p = x.next) {
        const c = x.item;
        if (revs.right_only) {
            if (c.obj.flags & SYMMETRIC_LEFT != 0) c.obj.flags |= SHOWN;
        } else if (c.obj.flags & SYMMETRIC_LEFT == 0) c.obj.flags |= SHOWN;
    }
}

fn limitList(revs: *RevInfo) bool {
    var slop: i32 = SLOP;
    var d: u64 = UNSET_TIME;
    var original_list = revs.commits;
    var newlist: ?*CommitList = null;
    var tail: *?*CommitList = &newlist;
    var interesting_cache: ?*Commit = null;
    var queue = cn.PrioQueue{ .compare = cn.compareByCommitDate };

    if (revs.ancestry_path_implicit_bottoms) {
        var l = original_list;
        while (l) |x| : (l = x.next) {
            if (x.item.obj.flags & BOTTOM != 0) _ = cn.listInsert(x.item, &revs.ancestry_path_bottoms);
        }
        if (revs.ancestry_path_bottoms == null)
            util.die("--ancestry-path given but there are no bottom commits", .{});
    }
    while (cn.popCommit(&original_list)) |c| queue.put(c);

    while (queue.get()) |commit| {
        const obj = &commit.obj;
        if (interesting_cache == commit) interesting_cache = null;
        if (revs.max_age != UNSET_TIME and commit.date < revs.max_age)
            obj.flags |= UNINTERESTING;
        if (!processParents(revs, commit, &queue)) return false;
        if (obj.flags & UNINTERESTING != 0) {
            markParentsUninteresting(revs, commit);
            slop = stillInteresting(&queue, d, slop, &interesting_cache);
            if (slop != 0) continue;
            break;
        }
        if (revs.min_age != UNSET_TIME and commit.date > revs.min_age and !revs.line_level_traverse) continue;
        if (revs.max_age_as_filter != UNSET_TIME and commit.date < revs.max_age_as_filter and !revs.line_level_traverse) continue;
        d = commit.date;
        tail = cn.listAppend(commit, tail);
    }
    if (revs.cherry_pick or revs.cherry_mark) cherryPickList(newlist, revs);
    if (revs.left_only or revs.right_only) limitLeftRight(newlist, revs);
    if (revs.ancestry_path) limitToAncestry(revs.ancestry_path_bottoms, newlist);
    if (limitingCanIncreaseTreesame(revs)) {
        var l = newlist;
        while (l) |x| : (l = x.next) {
            const c = x.item;
            if (c.obj.flags & (UNINTERESTING | TREESAME) != 0) continue;
            _ = updateTreesame(revs, c);
        }
    }
    revs.commits = newlist;
    return true;
}

// ---------------------------------------------------------------------------
// ref handling

pub fn refExcluded(revs: *const RevInfo, path: []const u8) bool {
    for (revs.ref_excludes.items) |pat| {
        if (wildmatch.match(pat, path, 0)) return true;
    }
    return false;
}

fn handleOneRef(revs: *RevInfo, name: []const u8, oid: Oid, flags: u32) void {
    if (refExcluded(revs, name)) return;
    const o = getReference(revs, name, oid, flags) orelse return;
    addRevCmdline(revs, o, name, .ref, flags);
    revs.addPendingObject(o, name);
}

fn handleRefsPrefix(revs: *RevInfo, prefix: []const u8, flags: u32) void {
    revs.rev_input_given = true;
    for (refs.iterate(prefix, .{})) |r| handleOneRef(revs, r.name, r.oid, flags);
}

fn handleHeadRef(revs: *RevInfo, flags: u32) void {
    revs.rev_input_given = true;
    const res = refs.resolveFull("HEAD", true);
    if (res.missing or res.broken) return;
    if (hash.isZero(res.oid)) return;
    handleOneRef(revs, "HEAD", res.oid, flags);
}

/// refs_for_each_glob_ref_in semantics
fn handleGlob(revs: *RevInfo, pattern: []const u8, prefix: ?[]const u8, flags: u32) void {
    revs.rev_input_given = true;
    var real: util.Buf = .empty;
    if (prefix == null and !util.startsWith(pattern, "refs/")) util.bufAppend(&real, "refs/");
    if (prefix) |p| util.bufAppend(&real, p);
    util.bufAppend(&real, pattern);
    if (!wildmatch.hasGlobChars(pattern)) {
        if (real.items.len > 0 and real.items[real.items.len - 1] != '/') util.bufByte(&real, '/');
        util.bufByte(&real, '*');
    }
    const pat = real.items;
    for (refs.iterate("", .{})) |r| {
        if (!util.startsWith(r.name, "refs/")) continue;
        if (!wildmatch.match(pat, r.name, wildmatch.PATHNAME)) continue;
        handleOneRef(revs, r.name, r.oid, flags);
    }
}

fn handleReflogs(revs: *RevInfo, flags: u32) void {
    for (refs.listReflogs()) |name| {
        var warned = false;
        for (refs.readReflog(name)) |e| {
            for ([_]Oid{ e.old, e.new }) |oid| {
                if (hash.isZero(oid)) continue;
                if (cn.parseObject(oid)) |o| {
                    o.flags |= flags;
                    revs.addPendingObject(o, "");
                } else if (!warned) {
                    util.warn("reflog of '{s}' references pruned commits", .{name});
                    warned = true;
                }
            }
        }
    }
}

fn addParentsOnly(revs: *RevInfo, arg_: []const u8, flags0: u32, exclude_parent: usize) i32 {
    var flags = flags0;
    var arg = arg_;
    if (arg.len > 0 and arg[0] == '^') {
        flags ^= UNINTERESTING | BOTTOM;
        arg = arg[1..];
    }
    var oid = revparse.getOidCommittish(arg) orelse return 0;
    var it: *Obj = undefined;
    while (true) {
        it = getReference(revs, arg, oid, 0) orelse {
            if (revs.ignore_missing) return 0;
            return -1;
        };
        if (it.typ != .tag) break;
        const data = repo_mod.repo().odb().read(it.oid) orelse return 0;
        const tag = objects.parseTag(data.data) orelse return 0;
        oid = tag.object;
    }
    if (it.typ != .commit) return 0;
    const commit = Commit.fromObj(it);
    if (exclude_parent != 0 and exclude_parent > commit.parentCount()) return 0;
    var parents = commit.parents;
    var parent_number: usize = 1;
    while (parents) |x| : ({
        parents = x.next;
        parent_number += 1;
    }) {
        if (exclude_parent != 0 and parent_number != exclude_parent) continue;
        const o = &x.item.obj;
        o.flags |= flags;
        addRevCmdline(revs, o, arg_, .parents_only, flags);
        revs.addPendingObject(o, arg);
    }
    return 1;
}

fn lookupOtherHead() struct { name: []const u8, oid: Oid } {
    const other_head = [_][]const u8{ "MERGE_HEAD", "CHERRY_PICK_HEAD", "REVERT_HEAD", "REBASE_HEAD" };
    for (other_head) |h| {
        if (refs.readRaw(h)) |raw| {
            switch (raw) {
                .oid => |o| return .{ .name = h, .oid = o },
                else => util.die("{s} exists but is a symbolic ref", .{h}),
            }
        }
    }
    util.die("--merge requires one of the pseudorefs MERGE_HEAD, CHERRY_PICK_HEAD, REVERT_HEAD or REBASE_HEAD", .{});
}

fn prepareShowMerge(revs: *RevInfo) void {
    const head_oid = revparse.getOid("HEAD") orelse util.die("--merge without HEAD?", .{});
    const head = cn.lookupCommitReference(head_oid) orelse util.die("could not parse HEAD", .{});
    const other_h = lookupOtherHead();
    const other = cn.lookupCommitReference(other_h.oid) orelse util.die("could not parse {s}", .{other_h.name});
    revs.addPendingObject(&head.obj, "HEAD");
    revs.addPendingObject(&other.obj, other_h.name);
    const bases = commitreach.getMergeBases(head, other);
    addRevCmdlineList(revs, bases, .merge_base, UNINTERESTING | BOTTOM);
    addPendingCommitList(revs, bases, UNINTERESTING | BOTTOM);
    head.obj.flags |= SYMMETRIC_LEFT;

    const idx = index_mod.get();
    var prune: std.ArrayList([]const u8) = .empty;
    var i: usize = 0;
    while (i < idx.entries.items.len) : (i += 1) {
        const ce = &idx.entries.items[i];
        if (ce.stage() == 0) continue;
        if (revs.prune_data.isEmpty() or revs.prune_data.matches(ce.path, false))
            prune.append(gpa, ce.path) catch util.oom();
        while (i + 1 < idx.entries.items.len and util.eql(ce.path, idx.entries.items[i + 1].path)) i += 1;
    }
    revs.prune_data = pathspec.parse("", prune.items, .{ .literal = true, .prefer_full = true });
    revs.limited = true;
}

fn dotdotMissing(full: []const u8, revs: *RevInfo, symmetric: bool) i32 {
    if (revs.ignore_missing) return 0;
    if (symmetric) util.die("Invalid symmetric difference expression {s}", .{full});
    util.die("Invalid revision range {s}", .{full});
}

fn handleDotdot(arg: []const u8, revs: *RevInfo, flags: u32, cant_be_filename: bool) i32 {
    const dd = std.mem.indexOf(u8, arg, "..") orelse return -1;
    var a_name = arg[0..dd];
    var rest = arg[dd + 2 ..];
    var symmetric = false;
    if (rest.len > 0 and rest[0] == '.') {
        symmetric = true;
        rest = rest[1..];
    }
    var b_name = rest;
    const flags_exclude = flags ^ (UNINTERESTING | BOTTOM);
    if (a_name.len == 0) a_name = "HEAD";
    if (b_name.len == 0) b_name = "HEAD";
    const ar = revparse.resolve(a_name, .{ .want = .committish, .quiet = true }) orelse return -1;
    const br = revparse.resolve(b_name, .{ .want = .committish, .quiet = true }) orelse return -1;
    if (!cant_be_filename) revparse.verifyNonFilename(revs.prefix, arg);
    const a_obj = cn.parseObject(ar.oid) orelse return dotdotMissing(arg, revs, symmetric);
    const b_obj = cn.parseObject(br.oid) orelse return dotdotMissing(arg, revs, symmetric);
    var a_flags: u32 = undefined;
    var b_flags: u32 = undefined;
    if (!symmetric) {
        b_flags = flags;
        a_flags = flags_exclude;
    } else {
        const a = cn.lookupCommitReference(a_obj.oid) orelse return dotdotMissing(arg, revs, symmetric);
        const b = cn.lookupCommitReference(b_obj.oid) orelse return dotdotMissing(arg, revs, symmetric);
        const exclude = commitreach.getMergeBases(a, b);
        addRevCmdlineList(revs, exclude, .merge_base, flags_exclude);
        addPendingCommitList(revs, exclude, flags_exclude);
        b_flags = flags;
        a_flags = flags | SYMMETRIC_LEFT;
    }
    a_obj.flags |= a_flags;
    b_obj.flags |= b_flags;
    addRevCmdline(revs, a_obj, a_name, .left, a_flags);
    addRevCmdline(revs, b_obj, b_name, .right, b_flags);
    addPendingObjectWithPath(revs, a_obj, a_name, if (ar.path != null) ar.mode else 0o170000, ar.path);
    addPendingObjectWithPath(revs, b_obj, b_name, if (br.path != null) br.mode else 0o170000, br.path);
    return 0;
}

fn handleRevisionArg1(arg_: []const u8, revs: *RevInfo, flags0: u32, revarg_opt: u32) i32 {
    var arg = arg_;
    const cant_be_filename = revarg_opt & REVARG_CANNOT_BE_FILENAME != 0;
    const flags: u32 = if (flags0 & UNINTERESTING != 0) flags0 | BOTTOM else flags0 & ~BOTTOM;

    if (!cant_be_filename and util.eql(arg, "..")) return -1;
    if (handleDotdot(arg, revs, flags, revarg_opt != 0) == 0) return 0;

    if (std.mem.indexOf(u8, arg, "^@")) |m| {
        if (m + 2 == arg.len) {
            if (addParentsOnly(revs, arg[0..m], flags, 0) != 0) return 0;
        }
    }
    if (std.mem.indexOf(u8, arg, "^!")) |m| {
        if (m + 2 == arg.len) {
            const a = util.dupe(arg[0..m]);
            if (addParentsOnly(revs, a, flags ^ (UNINTERESTING | BOTTOM), 0) != 0) arg = a;
        }
    }
    if (std.mem.indexOf(u8, arg, "^-")) |m| {
        var exclude_parent: usize = 1;
        if (m + 2 < arg.len) {
            const v = std.fmt.parseInt(i64, arg[m + 2 ..], 10) catch return -1;
            if (v < 1) return -1;
            exclude_parent = @intCast(v);
        }
        const a = util.dupe(arg[0..m]);
        if (addParentsOnly(revs, a, flags ^ (UNINTERESTING | BOTTOM), exclude_parent) != 0) arg = a;
    }

    var local_flags: u32 = 0;
    if (arg.len > 0 and arg[0] == '^') {
        local_flags = UNINTERESTING | BOTTOM;
        arg = arg[1..];
    }
    const want: revparse.Want = if (revarg_opt & REVARG_COMMITTISH != 0) .committish else .any;
    const res = revparse.resolve(arg, .{ .want = want, .quiet = true }) orelse {
        return if (revs.ignore_missing) 0 else -1;
    };
    if (!cant_be_filename) revparse.verifyNonFilename(revs.prefix, arg);
    const object = getReference(revs, arg, res.oid, flags ^ local_flags) orelse {
        return if (revs.ignore_missing) 0 else -1;
    };
    addRevCmdline(revs, object, arg_, .rev, flags ^ local_flags);
    addPendingObjectWithPath(revs, object, arg, if (res.path != null) res.mode else 0o170000, res.path);
    return 0;
}

/// handle_revision_arg: returns 0 on success.
pub fn handleRevisionArg(arg: []const u8, revs: *RevInfo, flags: u32, revarg_opt: u32) i32 {
    const ret = handleRevisionArg1(arg, revs, flags, revarg_opt);
    if (ret == 0) revs.rev_input_given = true;
    return ret;
}

// ---------------------------------------------------------------------------
// option parsing

fn parseCount(arg: []const u8) i32 {
    const s = std.mem.trimLeft(u8, arg, " \t\n");
    if (s.len == 0 or std.mem.indexOfScalar(u8, s, '_') != null)
        util.die("'{s}': not an integer", .{arg});
    return std.fmt.parseInt(i32, s, 10) catch util.die("'{s}': not an integer", .{arg});
}

fn parseAge(arg: []const u8) u64 {
    if (arg.len == 0) util.die("'{s}': not a number of seconds since epoch", .{arg});
    for (arg) |ch| if (!std.ascii.isDigit(ch)) util.die("'{s}': not a number of seconds since epoch", .{arg});
    return std.fmt.parseInt(u64, arg, 10) catch util.die("'{s}': not a number of seconds since epoch", .{arg});
}

fn approx(s: []const u8) u64 {
    return @bitCast(date.approxidate(s));
}

/// parse_long_opt: returns 0 (no match), 1 (stuck) or 2 (separate)
pub fn parseLongOpt(opt: []const u8, argv: []const []const u8, optarg: *[]const u8) usize {
    var arg = argv[0];
    arg = util.skipPrefix(arg, "--") orelse return 0;
    arg = util.skipPrefix(arg, opt) orelse return 0;
    if (arg.len > 0 and arg[0] == '=') {
        optarg.* = arg[1..];
        return 1;
    }
    if (arg.len != 0) return 0;
    if (argv.len < 2) util.die("Option '--{s}' requires a value", .{opt});
    optarg.* = argv[1];
    return 2;
}

fn incompatible2(a: []const u8, b: []const u8) noreturn {
    util.die("options '{s}' and '{s}' cannot be used together", .{ a, b });
}

// diff-merges
fn dmSuppress(r: *RevInfo) void {
    r.separate_merges = false;
    r.first_parent_merges = false;
    r.combine_merges = false;
    r.dense_combined_merges = false;
    r.combined_all_paths = false;
    r.merges_imply_patch = false;
    r.merges_need_diff = false;
    r.remerge_diff = false;
}
fn dmCommon(r: *RevInfo) void {
    dmSuppress(r);
    r.merges_need_diff = true;
}
fn dmSeparate(r: *RevInfo) void {
    dmCommon(r);
    r.separate_merges = true;
    r.simplify_history = false;
}
fn dmFirstParent(r: *RevInfo) void {
    dmSeparate(r);
    r.first_parent_merges = true;
}
fn dmCombined(r: *RevInfo) void {
    dmCommon(r);
    r.combine_merges = true;
    r.dense_combined_merges = false;
}
pub fn dmDenseCombined(r: *RevInfo) void {
    dmCommon(r);
    r.combine_merges = true;
    r.dense_combined_merges = true;
}
fn dmRemerge(r: *RevInfo) void {
    dmCommon(r);
    r.remerge_diff = true;
    r.simplify_history = false;
}
fn dmApply(r: *RevInfo, f: DiffMergesFn) void {
    switch (f) {
        .none => dmSuppress(r),
        .first_parent => dmFirstParent(r),
        .separate => dmSeparate(r),
        .combined => dmCombined(r),
        .dense_combined => dmDenseCombined(r),
        .remerge => dmRemerge(r),
    }
}
fn dmByOpt(v: []const u8) ?DiffMergesFn {
    if (util.eql(v, "off") or util.eql(v, "none")) return .none;
    if (util.eql(v, "1") or util.eql(v, "first-parent")) return .first_parent;
    if (util.eql(v, "separate")) return .separate;
    if (util.eql(v, "c") or util.eql(v, "combined")) return .combined;
    if (util.eql(v, "cc") or util.eql(v, "dense-combined")) return .dense_combined;
    if (util.eql(v, "r") or util.eql(v, "remerge")) return .remerge;
    if (util.eql(v, "m") or util.eql(v, "on")) return diff_merges_default;
    return null;
}

/// diff_merges_config (log.diffMerges); returns false if invalid.
pub fn diffMergesConfig(v: []const u8) bool {
    const f = dmByOpt(v) orelse return false;
    diff_merges_default = f;
    return true;
}

pub fn diffMergesSuppress(r: *RevInfo) void {
    dmSuppress(r);
}

pub fn diffMergesDefaultToFirstParent(r: *RevInfo) void {
    if (!r.explicit_diff_merges) r.separate_merges = true;
    if (r.separate_merges) r.first_parent_merges = true;
}

pub fn diffMergesDefaultToDenseCombined(r: *RevInfo) void {
    if (!r.explicit_diff_merges) dmDenseCombined(r);
}

pub fn diffMergesSetDenseCombinedIfUnset(r: *RevInfo) void {
    if (!r.combine_merges) dmDenseCombined(r);
}

fn diffMergesParseOpts(r: *RevInfo, argv: []const []const u8) usize {
    var argcount: usize = 1;
    const arg = argv[0];
    var optarg: []const u8 = "";
    if (!suppress_m_parsing and util.eql(arg, "-m")) {
        dmApply(r, diff_merges_default);
        r.merges_need_diff = false;
    } else if (util.eql(arg, "-c")) {
        dmCombined(r);
        r.merges_imply_patch = true;
    } else if (util.eql(arg, "--cc")) {
        dmDenseCombined(r);
        r.merges_imply_patch = true;
    } else if (util.eql(arg, "--dd")) {
        dmFirstParent(r);
        r.merges_imply_patch = true;
    } else if (util.eql(arg, "--remerge-diff")) {
        dmRemerge(r);
        r.merges_imply_patch = true;
    } else if (util.eql(arg, "--no-diff-merges")) {
        dmSuppress(r);
    } else if (util.eql(arg, "--combined-all-paths")) {
        r.combined_all_paths = true;
    } else {
        argcount = parseLongOpt("diff-merges", argv, &optarg);
        if (argcount == 0) return 0;
        const f = dmByOpt(optarg) orelse util.die("invalid value for '{s}': '{s}'", .{ "--diff-merges", optarg });
        dmApply(r, f);
    }
    r.explicit_diff_merges = true;
    return argcount;
}

fn diffMergesSetupRevs(r: *RevInfo) void {
    if (!r.combine_merges) r.dense_combined_merges = false;
    if (!r.separate_merges) r.first_parent_merges = false;
    if (r.combined_all_paths and !r.combine_merges)
        util.die("--combined-all-paths makes no sense without -c or --cc", .{});
    if (r.merges_imply_patch) r.diff = true;
    if (r.merges_imply_patch or r.merges_need_diff) {
        if (r.output_format == 0) r.output_format = DIFF_FORMAT_PATCH;
    }
}

fn isPseudoOpt(arg: []const u8) bool {
    const exact = [_][]const u8{ "--all", "--branches", "--tags", "--remotes", "--reflog", "--not", "--no-walk", "--do-walk", "--bisect", "--indexed-objects", "--alternate-refs" };
    for (exact) |e| if (util.eql(arg, e)) return true;
    const pre = [_][]const u8{ "--glob=", "--exclude=", "--exclude-hidden=", "--branches=", "--tags=", "--remotes=", "--no-walk=" };
    for (pre) |p| if (util.startsWith(arg, p)) return true;
    return false;
}

/// handle_revision_opt: >0 consumed, 0 unknown (appended to unk), <0 error
fn handleRevisionOpt(revs: *RevInfo, argv: []const []const u8, unk: *std.ArrayList([]const u8)) i32 {
    const arg = argv[0];
    var optarg: []const u8 = "";
    var argcount: usize = 0;

    if (isPseudoOpt(arg)) {
        unk.append(gpa, arg) catch util.oom();
        return 1;
    }

    argcount = parseLongOpt("max-count", argv, &optarg);
    if (argcount != 0) {
        if (revs.max_count_type == 1) incompatible2("--max-count", "--max-count-oldest");
        revs.max_count = parseCount(optarg);
        revs.no_walk = false;
        revs.max_count_type = 0;
        return @intCast(argcount);
    }
    argcount = parseLongOpt("max-count-oldest", argv, &optarg);
    if (argcount != 0) {
        if (revs.max_count_type == 0 and revs.max_count != -1) incompatible2("--max-count", "--max-count-oldest");
        if (revs.skip_count > 0) incompatible2("--skip", "--max-count-oldest");
        revs.max_count = parseCount(optarg);
        revs.no_walk = false;
        revs.max_count_type = 1;
        revs.max_count_stage = 0;
        return 1;
    }
    argcount = parseLongOpt("skip", argv, &optarg);
    if (argcount != 0) {
        if (revs.max_count_type == 1) incompatible2("--skip", "--max-count-oldest");
        revs.skip_count = parseCount(optarg);
        return @intCast(argcount);
    }
    if (arg.len >= 2 and arg[0] == '-' and std.ascii.isDigit(arg[1])) {
        revs.max_count = parseCount(arg[1..]);
        revs.no_walk = false;
        return 1;
    }
    if (util.eql(arg, "-n")) {
        if (argv.len <= 1) {
            util.err("-n requires an argument", .{});
            return -1;
        }
        revs.max_count = parseCount(argv[1]);
        revs.no_walk = false;
        return 2;
    }
    if (util.startsWith(arg, "-n")) {
        revs.max_count = parseCount(arg[2..]);
        revs.no_walk = false;
        return 1;
    }
    const age_opts = [_]struct { n: []const u8, kind: u8 }{
        .{ .n = "max-age", .kind = 0 },
        .{ .n = "since", .kind = 1 },
        .{ .n = "since-as-filter", .kind = 2 },
        .{ .n = "after", .kind = 1 },
        .{ .n = "min-age", .kind = 3 },
        .{ .n = "before", .kind = 4 },
        .{ .n = "until", .kind = 4 },
    };
    for (age_opts) |ao| {
        argcount = parseLongOpt(ao.n, argv, &optarg);
        if (argcount != 0) {
            switch (ao.kind) {
                0 => revs.max_age = parseAge(optarg),
                1 => revs.max_age = approx(optarg),
                2 => revs.max_age_as_filter = approx(optarg),
                3 => revs.min_age = parseAge(optarg),
                else => revs.min_age = approx(optarg),
            }
            return @intCast(argcount);
        }
    }
    if (util.eql(arg, "--maximal-only")) {
        revs.maximal_only = true;
    } else if (util.eql(arg, "--first-parent")) {
        revs.first_parent_only = true;
    } else if (util.eql(arg, "--exclude-first-parent-only")) {
        revs.exclude_first_parent_only = true;
    } else if (util.eql(arg, "--ancestry-path")) {
        revs.ancestry_path = true;
        revs.simplify_history = false;
        revs.limited = true;
        revs.ancestry_path_implicit_bottoms = true;
    } else if (util.skipPrefix(arg, "--ancestry-path=")) |v| {
        revs.ancestry_path = true;
        revs.simplify_history = false;
        revs.limited = true;
        const oid = revparse.getOidCommittish(v) orelse {
            util.err("could not get commit for --ancestry-path argument {s}", .{v});
            return -1;
        };
        _ = getReference(revs, v, oid, ANCESTRY_PATH);
        const c = cn.lookupCommitReference(oid) orelse {
            util.err("could not get commit for --ancestry-path argument {s}", .{v});
            return -1;
        };
        _ = cn.listInsert(c, &revs.ancestry_path_bottoms);
    } else if (util.eql(arg, "-g") or util.eql(arg, "--walk-reflogs")) {
        if (revs.reflog_info == null) revs.reflog_info = reflogwalk.init();
    } else if (util.eql(arg, "--default")) {
        if (argv.len <= 1) {
            util.err("bad --default argument", .{});
            return -1;
        }
        revs.def = argv[1];
        return 2;
    } else if (util.eql(arg, "--merge")) {
        revs.show_merge = true;
    } else if (util.eql(arg, "--topo-order")) {
        revs.sort_order = .graph;
        revs.topo_order = true;
    } else if (util.eql(arg, "--simplify-merges")) {
        revs.simplify_merges = true;
        revs.topo_order = true;
        revs.rewrite_parents = true;
        revs.simplify_history = false;
        revs.limited = true;
    } else if (util.eql(arg, "--simplify-by-decoration")) {
        revs.simplify_merges = true;
        revs.topo_order = true;
        revs.rewrite_parents = true;
        revs.simplify_history = false;
        revs.simplify_by_decoration = true;
        revs.limited = true;
        revs.prune = true;
    } else if (util.eql(arg, "--date-order")) {
        revs.sort_order = .commit_date;
        revs.topo_order = true;
    } else if (util.eql(arg, "--author-date-order")) {
        revs.sort_order = .author_date;
        revs.topo_order = true;
    } else if (util.eql(arg, "--parents")) {
        revs.rewrite_parents = true;
        revs.print_parents = true;
    } else if (util.eql(arg, "--dense")) {
        revs.dense = true;
    } else if (util.eql(arg, "--sparse")) {
        revs.dense = false;
    } else if (util.eql(arg, "--in-commit-order")) {
        revs.tree_blobs_in_commit_order = true;
    } else if (util.eql(arg, "--remove-empty")) {
        revs.remove_empty_trees = true;
    } else if (util.eql(arg, "--merges")) {
        revs.min_parents = 2;
    } else if (util.eql(arg, "--no-merges")) {
        revs.max_parents = 1;
    } else if (util.skipPrefix(arg, "--min-parents=")) |v| {
        revs.min_parents = parseCount(v);
    } else if (util.eql(arg, "--no-min-parents")) {
        revs.min_parents = 0;
    } else if (util.skipPrefix(arg, "--max-parents=")) |v| {
        revs.max_parents = parseCount(v);
    } else if (util.eql(arg, "--no-max-parents")) {
        revs.max_parents = -1;
    } else if (util.eql(arg, "--boundary")) {
        revs.boundary = 1;
    } else if (util.eql(arg, "--left-right")) {
        revs.left_right = true;
    } else if (util.eql(arg, "--left-only")) {
        if (revs.right_only) incompatible2("--left-only", "--right-only/--cherry");
        revs.left_only = true;
        revs.limited = true;
    } else if (util.eql(arg, "--right-only")) {
        if (revs.left_only) incompatible2("--right-only", "--left-only");
        revs.right_only = true;
        revs.limited = true;
    } else if (util.eql(arg, "--cherry")) {
        if (revs.left_only) incompatible2("--cherry", "--left-only");
        revs.cherry_mark = true;
        revs.right_only = true;
        revs.max_parents = 1;
        revs.limited = true;
    } else if (util.eql(arg, "--count")) {
        revs.count = true;
    } else if (util.eql(arg, "--cherry-mark")) {
        if (revs.cherry_pick) incompatible2("--cherry-mark", "--cherry-pick");
        revs.cherry_mark = true;
        revs.limited = true;
    } else if (util.eql(arg, "--cherry-pick")) {
        if (revs.cherry_mark) incompatible2("--cherry-pick", "--cherry-mark");
        revs.cherry_pick = true;
        revs.limited = true;
    } else if (util.eql(arg, "--objects")) {
        revs.tag_objects = true;
        revs.tree_objects = true;
        revs.blob_objects = true;
    } else if (util.eql(arg, "--objects-edge")) {
        revs.tag_objects = true;
        revs.tree_objects = true;
        revs.blob_objects = true;
        revs.edge_hint = true;
    } else if (util.eql(arg, "--objects-edge-aggressive")) {
        revs.tag_objects = true;
        revs.tree_objects = true;
        revs.blob_objects = true;
        revs.edge_hint = true;
        revs.edge_hint_aggressive = true;
    } else if (util.eql(arg, "--verify-objects")) {
        revs.tag_objects = true;
        revs.tree_objects = true;
        revs.blob_objects = true;
        revs.verify_objects = true;
    } else if (util.eql(arg, "--unpacked")) {
        revs.unpacked = true;
    } else if (util.startsWith(arg, "--unpacked=")) {
        util.die("--unpacked=<packfile> no longer supported", .{});
    } else if (util.eql(arg, "--no-kept-objects") or util.startsWith(arg, "--no-kept-objects=")) {
        // no packs are kept in this implementation
    } else if (util.eql(arg, "-r")) {
        revs.diff = true;
        revs.diff_recursive = true;
    } else if (util.eql(arg, "-t")) {
        revs.diff = true;
        revs.diff_recursive = true;
        revs.diff_tree_in_recursive = true;
    } else if (diffMergesParseOpts(revs, argv) != 0) {
        return @intCast(diffMergesParseOpts(revs, argv));
    } else if (util.eql(arg, "-v")) {
        revs.verbose_header = true;
    } else if (util.eql(arg, "--pretty")) {
        revs.verbose_header = true;
        revs.pretty_given = true;
        if (revs.format_hook) |h| h(revs, null);
    } else if (util.skipPrefix(arg, "--pretty=") orelse util.skipPrefix(arg, "--format=")) |v| {
        revs.verbose_header = true;
        revs.pretty_given = true;
        if (revs.format_hook) |h| h(revs, v);
    } else if (util.eql(arg, "--expand-tabs")) {
        revs.expand_tabs_in_log = 8;
    } else if (util.eql(arg, "--no-expand-tabs")) {
        revs.expand_tabs_in_log = 0;
    } else if (util.skipPrefix(arg, "--expand-tabs=")) |v| {
        const val = std.fmt.parseInt(i32, v, 10) catch util.die("'{s}': not a non-negative integer", .{v});
        if (val < 0) util.die("'{s}': not a non-negative integer", .{v});
        revs.expand_tabs_in_log = val;
    } else if (util.eql(arg, "--show-notes") or util.eql(arg, "--notes")) {
        revs.show_notes = true;
        if (revs.notes_use_default < 0) revs.notes_use_default = 1;
        revs.show_notes_given = true;
    } else if (util.eql(arg, "--show-signature")) {
        revs.show_signature = true;
    } else if (util.eql(arg, "--no-show-signature")) {
        revs.show_signature = false;
    } else if (util.eql(arg, "--show-linear-break")) {
        revs.break_bar = "                    ..........";
        revs.track_linear = true;
        revs.track_first_time = true;
    } else if (util.skipPrefix(arg, "--show-linear-break=")) |v| {
        revs.break_bar = v;
        revs.track_linear = true;
        revs.track_first_time = true;
    } else if (util.eql(arg, "--show-notes-by-default")) {
        revs.show_notes_by_default = true;
    } else if (util.skipPrefix(arg, "--show-notes=") orelse util.skipPrefix(arg, "--notes=")) |v| {
        if (util.startsWith(arg, "--show-notes=") and revs.notes_use_default < 0) revs.notes_use_default = 1;
        revs.show_notes = true;
        revs.notes_refs.append(gpa, v) catch util.oom();
        revs.show_notes_given = true;
    } else if (util.eql(arg, "--no-notes")) {
        revs.show_notes = false;
        revs.notes_use_default = 0;
        revs.notes_refs.clearRetainingCapacity();
        revs.show_notes_given = true;
    } else if (util.eql(arg, "--standard-notes")) {
        revs.show_notes_given = true;
        revs.notes_use_default = 1;
    } else if (util.eql(arg, "--no-standard-notes")) {
        revs.notes_use_default = 0;
    } else if (util.eql(arg, "--oneline")) {
        revs.verbose_header = true;
        if (revs.format_hook) |h| h(revs, "oneline") else revs.commit_format = .oneline;
        revs.pretty_given = true;
        revs.abbrev_commit = true;
    } else if (util.eql(arg, "--graph")) {
        graph_mod.clear(revs.graph);
        revs.graph = graph_mod.init(revs);
    } else if (util.eql(arg, "--no-graph")) {
        graph_mod.clear(revs.graph);
        revs.graph = null;
    } else if (util.skipPrefix(arg, "--graph-lane-limit=")) |v| {
        revs.graph_max_lanes = parseCount(v);
    } else if (util.eql(arg, "--graph-indent")) {
        revs.no_graph_indent = false;
        revs.graph_indent_set = true;
    } else if (util.eql(arg, "--no-graph-indent")) {
        revs.no_graph_indent = true;
        revs.graph_indent_set = true;
    } else if (util.eql(arg, "--encode-email-headers")) {
        revs.encode_email_headers = true;
    } else if (util.eql(arg, "--no-encode-email-headers")) {
        revs.encode_email_headers = false;
    } else if (util.eql(arg, "--root")) {
        revs.show_root_diff = true;
    } else if (util.eql(arg, "--no-commit-id")) {
        revs.no_commit_id = true;
    } else if (util.eql(arg, "--always")) {
        revs.always_show_header = true;
    } else if (util.eql(arg, "--no-abbrev")) {
        revs.abbrev = 0;
    } else if (util.eql(arg, "--abbrev")) {
        revs.abbrev = revparse.defaultAbbrev();
    } else if (util.skipPrefix(arg, "--abbrev=")) |v| {
        var n: usize = 0;
        for (v) |ch| {
            if (!std.ascii.isDigit(ch)) break;
            n = n *| 10 +| (ch - '0');
        }
        if (n < 4) n = 4 else if (n > 40) n = 40;
        revs.abbrev = n;
    } else if (util.eql(arg, "--abbrev-commit")) {
        revs.abbrev_commit = true;
        revs.abbrev_commit_given = true;
    } else if (util.eql(arg, "--no-abbrev-commit")) {
        revs.abbrev_commit = false;
    } else if (util.eql(arg, "--full-diff")) {
        revs.diff = true;
        revs.full_diff = true;
    } else if (util.eql(arg, "--show-pulls")) {
        revs.show_pulls = true;
    } else if (util.eql(arg, "--full-history")) {
        revs.simplify_history = false;
    } else if (util.eql(arg, "--relative-date")) {
        revs.date_mode = date.DateMode.of(.relative);
        revs.date_mode_explicit = true;
    } else if (blk: {
        argcount = parseLongOpt("date", argv, &optarg);
        break :blk argcount != 0;
    }) {
        revs.date_mode = date.parseDateFormatOrDie(optarg);
        revs.date_mode_explicit = true;
        return @intCast(argcount);
    } else if (util.eql(arg, "--log-size")) {
        revs.show_log_size = true;
    } else if (blk: {
        argcount = parseLongOpt("author", argv, &optarg);
        break :blk argcount != 0;
    }) {
        revs.grep.addHeader(.author, optarg);
        return @intCast(argcount);
    } else if (blk: {
        argcount = parseLongOpt("committer", argv, &optarg);
        break :blk argcount != 0;
    }) {
        revs.grep.addHeader(.committer, optarg);
        return @intCast(argcount);
    } else if (blk: {
        argcount = parseLongOpt("grep-reflog", argv, &optarg);
        break :blk argcount != 0;
    }) {
        revs.grep.addHeader(.reflog, optarg);
        return @intCast(argcount);
    } else if (blk: {
        argcount = parseLongOpt("grep", argv, &optarg);
        break :blk argcount != 0;
    }) {
        revs.grep.addBody(optarg);
        return @intCast(argcount);
    } else if (util.eql(arg, "--basic-regexp")) {
        revs.grep.pattern_type_option = .bre;
    } else if (util.eql(arg, "--extended-regexp") or util.eql(arg, "-E")) {
        revs.grep.pattern_type_option = .ere;
    } else if (util.eql(arg, "--regexp-ignore-case") or util.eql(arg, "-i")) {
        revs.grep.ignore_case = true;
        revs.pickaxe_ignore_case = true;
    } else if (util.eql(arg, "--fixed-strings") or util.eql(arg, "-F")) {
        revs.grep.pattern_type_option = .fixed;
    } else if (util.eql(arg, "--perl-regexp") or util.eql(arg, "-P")) {
        revs.grep.pattern_type_option = .pcre;
    } else if (util.eql(arg, "--all-match")) {
        revs.grep.all_match = true;
    } else if (util.eql(arg, "--invert-grep")) {
        revs.grep.no_body_match = true;
    } else if (blk: {
        argcount = parseLongOpt("encoding", argv, &optarg);
        break :blk argcount != 0;
    }) {
        log_output_encoding = if (util.eql(optarg, "none")) "" else optarg;
        return @intCast(argcount);
    } else if (util.eql(arg, "--reverse")) {
        revs.reverse = !revs.reverse;
    } else if (util.eql(arg, "--children")) {
        revs.children_enabled = true;
        revs.limited = true;
    } else if (util.eql(arg, "--ignore-missing")) {
        revs.ignore_missing = true;
    } else {
        var n: usize = 0;
        if (revs.diff_parse) |dp| n = dp(revs, argv);
        if (n == 0) unk.append(gpa, arg) catch util.oom();
        return @intCast(n);
    }
    return 1;
}

/// parse_revision_opt equivalent for callers with their own option loop:
/// returns number of args consumed (0 = unknown)
pub fn handleRevisionOptPublic(revs: *RevInfo, argv: []const []const u8) usize {
    var unk: std.ArrayList([]const u8) = .empty;
    const n = handleRevisionOpt(revs, argv, &unk);
    if (n < 0) os.exit(128);
    if (unk.items.len > 0) return 0;
    return @intCast(n);
}

pub fn revisionOptsFinish(revs: *RevInfo) void {
    if (revs.graph != null and revs.track_linear) incompatible2("--show-linear-break", "--graph");
    if (revs.graph != null) {
        revs.topo_order = true;
        revs.rewrite_parents = true;
    }
}

/// handle_revision_pseudo_opt: >0 consumed, 0 not a pseudo opt, <0 error
fn handlePseudoOpt(revs: *RevInfo, argv: []const []const u8, flags: *u32) i32 {
    const arg = argv[0];
    var optarg: []const u8 = "";
    if (util.eql(arg, "--all")) {
        handleRefsPrefix(revs, "refs/", flags.*);
        handleHeadRef(revs, flags.*);
        revs.ref_excludes.clearRetainingCapacity();
    } else if (util.eql(arg, "--branches")) {
        if (revs.hidden_refs_configured) {
            util.err("options '{s}' and '{s}' cannot be used together", .{ "--exclude-hidden", "--branches" });
            return -1;
        }
        handleRefsPrefix(revs, "refs/heads/", flags.*);
        revs.ref_excludes.clearRetainingCapacity();
    } else if (util.eql(arg, "--bisect")) {
        var bad: []const u8 = "bad";
        var good: []const u8 = "good";
        if (os.readFile(repo_mod.repo().gitPath("BISECT_TERMS"))) |t| {
            var it = std.mem.splitScalar(u8, t, '\n');
            if (it.next()) |b| bad = b;
            if (it.next()) |g| good = g;
        }
        handleRefsPrefix(revs, util.concat(&.{ "refs/bisect/", bad }), flags.*);
        handleRefsPrefix(revs, util.concat(&.{ "refs/bisect/", good, "-" }), flags.* ^ (UNINTERESTING | BOTTOM));
        revs.bisect = true;
    } else if (util.eql(arg, "--tags")) {
        if (revs.hidden_refs_configured) {
            util.err("options '{s}' and '{s}' cannot be used together", .{ "--exclude-hidden", "--tags" });
            return -1;
        }
        handleRefsPrefix(revs, "refs/tags/", flags.*);
        revs.ref_excludes.clearRetainingCapacity();
    } else if (util.eql(arg, "--remotes")) {
        if (revs.hidden_refs_configured) {
            util.err("options '{s}' and '{s}' cannot be used together", .{ "--exclude-hidden", "--remotes" });
            return -1;
        }
        handleRefsPrefix(revs, "refs/remotes/", flags.*);
        revs.ref_excludes.clearRetainingCapacity();
    } else if (blk: {
        const n = parseLongOpt("glob", argv, &optarg);
        if (n == 0) break :blk false;
        handleGlob(revs, optarg, null, flags.*);
        revs.ref_excludes.clearRetainingCapacity();
        return @intCast(n);
    }) {} else if (blk: {
        const n = parseLongOpt("exclude", argv, &optarg);
        if (n == 0) break :blk false;
        revs.ref_excludes.append(gpa, optarg) catch util.oom();
        return @intCast(n);
    }) {} else if (blk: {
        const n = parseLongOpt("exclude-hidden", argv, &optarg);
        if (n == 0) break :blk false;
        if (!util.eql(optarg, "fetch") and !util.eql(optarg, "receive") and !util.eql(optarg, "uploadpack"))
            util.die("unsupported section for hidden refs: {s}", .{optarg});
        if (revs.hidden_refs_configured) util.die("--exclude-hidden= passed more than once", .{});
        revs.hidden_refs_configured = true;
        return @intCast(n);
    }) {} else if (util.skipPrefix(arg, "--branches=")) |v| {
        if (revs.hidden_refs_configured) {
            util.err("options '{s}' and '{s}' cannot be used together", .{ "--exclude-hidden", "--branches" });
            return -1;
        }
        handleGlob(revs, v, "refs/heads/", flags.*);
        revs.ref_excludes.clearRetainingCapacity();
    } else if (util.skipPrefix(arg, "--tags=")) |v| {
        if (revs.hidden_refs_configured) {
            util.err("options '{s}' and '{s}' cannot be used together", .{ "--exclude-hidden", "--tags" });
            return -1;
        }
        handleGlob(revs, v, "refs/tags/", flags.*);
        revs.ref_excludes.clearRetainingCapacity();
    } else if (util.skipPrefix(arg, "--remotes=")) |v| {
        if (revs.hidden_refs_configured) {
            util.err("options '{s}' and '{s}' cannot be used together", .{ "--exclude-hidden", "--remotes" });
            return -1;
        }
        handleGlob(revs, v, "refs/remotes/", flags.*);
        revs.ref_excludes.clearRetainingCapacity();
    } else if (util.eql(arg, "--reflog")) {
        handleReflogs(revs, flags.*);
    } else if (util.eql(arg, "--indexed-objects")) {
        addIndexObjectsToPending(revs, flags.*);
    } else if (util.eql(arg, "--alternate-refs")) {
        // no alternates support
    } else if (util.eql(arg, "--not")) {
        flags.* ^= UNINTERESTING | BOTTOM;
    } else if (util.eql(arg, "--no-walk")) {
        revs.no_walk = true;
    } else if (util.skipPrefix(arg, "--no-walk=")) |v| {
        revs.no_walk = true;
        if (util.eql(v, "sorted")) {
            revs.unsorted_input = false;
        } else if (util.eql(v, "unsorted")) {
            revs.unsorted_input = true;
        } else {
            util.err("invalid argument to --no-walk", .{});
            return -1;
        }
    } else if (util.eql(arg, "--do-walk")) {
        revs.no_walk = false;
    } else if (util.eql(arg, "--single-worktree")) {
        revs.single_worktree = true;
    } else if (util.startsWith(arg, "--filter=") or util.eql(arg, "--no-filter")) {
        // object filters are not supported; accept silently
    } else return 0;
    return 1;
}

fn addIndexObjectsToPending(revs: *RevInfo, flags: u32) void {
    const idx = index_mod.get();
    for (idx.entries.items) |*ce| {
        if (isGitlink(ce.mode)) continue;
        const o = cn.lookup(ce.oid, .blob) orelse continue;
        o.flags |= flags;
        addPendingObjectWithPath(revs, o, "", ce.mode, ce.path);
    }
}

fn readLineStdin(b: *util.Buf) bool {
    b.clearRetainingCapacity();
    var got = false;
    while (true) {
        var ch: [1]u8 = undefined;
        const n = std.c.read(0, &ch, 1);
        if (n <= 0) return got;
        got = true;
        if (ch[0] == '\n') break;
        util.bufByte(b, ch[0]);
    }
    if (b.items.len > 0 and b.items[b.items.len - 1] == '\r') b.items.len -= 1;
    return true;
}

fn readRevisionsFromStdin(revs: *RevInfo, prune: *std.ArrayList([]const u8)) void {
    var sb: util.Buf = .empty;
    var seen_dashdash = false;
    var seen_end_of_options = false;
    var flags: u32 = 0;
    while (readLineStdin(&sb)) {
        if (sb.items.len == 0) break;
        const line = util.dupe(sb.items);
        if (util.eql(line, "--")) {
            seen_dashdash = true;
            break;
        }
        if (!seen_end_of_options and line[0] == '-') {
            if (util.eql(line, "--end-of-options")) {
                seen_end_of_options = true;
                continue;
            }
            const av = [_][]const u8{line};
            if (handlePseudoOpt(revs, &av, &flags) > 0) continue;
            util.die("invalid option '{s}' in --stdin mode", .{line});
        }
        if (handleRevisionArg(line, revs, flags, REVARG_CANNOT_BE_FILENAME) != 0)
            util.die("bad revision '{s}'", .{line});
    }
    if (seen_dashdash) {
        while (readLineStdin(&sb)) prune.append(gpa, util.dupe(sb.items)) catch util.oom();
    }
}

fn diagnoseMissingDefault(def: []const u8) noreturn {
    const res = refs.resolveFull(def, false);
    if (res.broken or res.flags & refs.REF_ISSYMREF == 0)
        util.die("your current branch appears to be broken", .{});
    var name = res.name;
    if (util.skipPrefix(name, "refs/heads/")) |n| name = n;
    util.die("your current branch '{s}' does not have any commits yet", .{name});
}

/// setup_revisions: returns leftover (unknown) args, with args[0] first.
pub fn setupRevisions(revs: *RevInfo, args_in: []const []const u8, opt: SetupOpt) []const []const u8 {
    var args = args_in;
    var prune_args: std.ArrayList([]const u8) = .empty;
    var seen_dashdash = false;
    var seen_end_of_options = false;
    if (opt.assume_dashdash) {
        seen_dashdash = true;
    } else {
        var i: usize = 1;
        while (i < args.len) : (i += 1) {
            if (!util.eql(args[i], "--")) continue;
            prune_args.appendSlice(gpa, args[i + 1 ..]) catch util.oom();
            args = args[0..i];
            seen_dashdash = true;
            break;
        }
    }
    var unk: std.ArrayList([]const u8) = .empty;
    if (args.len > 0) unk.append(gpa, args[0]) catch util.oom();
    var flags: u32 = 0;
    var revarg_opt = opt.revarg_opt;
    if (seen_dashdash) revarg_opt |= REVARG_CANNOT_BE_FILENAME;

    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (!seen_end_of_options and arg.len > 0 and arg[0] == '-') {
            const po = handlePseudoOpt(revs, args[i..], &flags);
            if (po > 0) {
                i += @as(usize, @intCast(po)) - 1;
                continue;
            }
            if (po < 0) os.exit(128);
            if (util.eql(arg, "--stdin")) {
                if (revs.disable_stdin) {
                    unk.append(gpa, arg) catch util.oom();
                    continue;
                }
                if (revs.read_from_stdin > 0) util.die("--stdin given twice?", .{});
                revs.read_from_stdin += 1;
                readRevisionsFromStdin(revs, &prune_args);
                continue;
            }
            if (util.eql(arg, "--end-of-options")) {
                seen_end_of_options = true;
                continue;
            }
            const n = handleRevisionOpt(revs, args[i..], &unk);
            if (n > 0) {
                i += @as(usize, @intCast(n)) - 1;
                continue;
            }
            if (n < 0) os.exit(128);
            continue;
        }
        if (handleRevisionArg(arg, revs, flags, revarg_opt) != 0) {
            if (seen_dashdash or (arg.len > 0 and arg[0] == '^'))
                util.die("bad revision '{s}'", .{arg});
            var j = i;
            while (j < args.len) : (j += 1) revparse.verifyFilename(revs.prefix, args[j], j == i);
            // prepend the remaining args before any "--" args
            var np: std.ArrayList([]const u8) = .empty;
            np.appendSlice(gpa, args[i..]) catch util.oom();
            np.appendSlice(gpa, prune_args.items) catch util.oom();
            prune_args = np;
            break;
        }
    }
    revisionOptsFinish(revs);

    if (prune_args.items.len > 0) {
        revs.prune_data = pathspec.parse(revs.prefix, prune_args.items, .{});
    }
    if (revs.def == null) revs.def = opt.def;
    if (opt.tweak) |t| t(revs);
    if (revs.show_merge) prepareShowMerge(revs);
    if (revs.def) |def| {
        if (revs.pending.items.len == 0 and !revs.rev_input_given) {
            const res = revparse.resolve(def, .{ .quiet = true }) orelse diagnoseMissingDefault(def);
            if (getReference(revs, def, res.oid, 0)) |o|
                addPendingObjectWithPath(revs, o, def, if (res.path != null) res.mode else 0o170000, null);
        }
    }
    if (revs.output_format & ~DIFF_FORMAT_NO_OUTPUT != 0) revs.diff = true;
    if (revs.diff_wants_diff) revs.diff = true;
    if (revs.diff_objfind) revs.simplify_history = false;
    if (revs.topo_order) revs.limited = true;
    if (!revs.prune_data.isEmpty()) {
        if (!revs.follow_renames) revs.prune = true;
    }
    diffMergesSetupRevs(revs);
    if (revs.diff_finish) |f| f(revs);

    revs.grep.config(&repo_mod.cfg);
    revs.grep.compile();

    if (revs.reflog_info != null and revs.limited)
        util.die("cannot combine --walk-reflogs with history-limiting options", .{});
    if (revs.rewrite_parents and revs.children_enabled) incompatible2("--parents", "--children");

    {
        var names: [3][]const u8 = undefined;
        var cnt: usize = 0;
        if (revs.graph != null) {
            names[cnt] = "--graph";
            cnt += 1;
        }
        if (revs.reverse) {
            names[cnt] = "--reverse";
            cnt += 1;
        }
        if (revs.reflog_info != null) {
            names[cnt] = "--walk-reflogs";
            cnt += 1;
        }
        if (cnt == 3) util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ names[0], names[1], names[2] });
        if (cnt == 2) incompatible2(names[0], names[1]);
    }
    if (revs.boundary != 0 and revs.maximal_only) incompatible2("--boundary", "--maximal-only");
    if (revs.no_walk and revs.graph != null) incompatible2("--no-walk", "--graph");
    if (revs.graph_max_lanes > 0 and revs.graph == null)
        util.die("the option '{s}' requires '{s}'", .{ "--graph-lane-limit", "--graph" });
    if (revs.graph_indent_set and revs.graph == null)
        util.die("the option '{s}' requires '{s}'", .{ "--[no-]graph-indent", "--graph" });
    if (revs.reflog_info == null and revs.grep.hasReflogFilter())
        util.die("the option '{s}' requires '{s}'", .{ "--grep-reflog", "--walk-reflogs" });
    if (revs.expand_tabs_in_log < 0) revs.expand_tabs_in_log = revs.expand_tabs_in_log_default;
    if (!revs.show_notes_given and revs.show_notes_by_default) {
        revs.show_notes = true;
        if (revs.notes_use_default < 0) revs.notes_use_default = 1;
        revs.show_notes_given = true;
    }
    return unk.items;
}

// ---------------------------------------------------------------------------
// merge simplification

fn removeDuplicateParents(revs: *RevInfo, commit: *Commit) usize {
    const ts = lookupTreesame(revs, commit);
    var pp: *?*CommitList = &commit.parents;
    var surviving: usize = 0;
    while (pp.*) |p| {
        const parent = p.item;
        if (parent.obj.flags & TMP_MARK != 0) {
            pp.* = p.next;
            if (ts != null) _ = compactTreesame(revs, commit, surviving);
            continue;
        }
        parent.obj.flags |= TMP_MARK;
        surviving += 1;
        pp = &p.next;
    }
    var l = commit.parents;
    while (l) |x| : (l = x.next) x.item.obj.flags &= ~TMP_MARK;
    return surviving;
}

fn markRedundantParents(commit: *Commit) usize {
    const h = commitreach.reduceHeads(commit.parents);
    var i: usize = 0;
    var marked: usize = 0;
    const orig_cnt = cn.listCount(commit.parents);
    const cnt = cn.listCount(h);
    var po = commit.parents;
    var pn = h;
    while (po) |x| : (po = x.next) {
        if (pn != null and x.item == pn.?.item) {
            pn = pn.?.next;
            i += 1;
        } else {
            x.item.obj.flags |= TMP_MARK;
            marked += 1;
        }
    }
    if (i != cnt or cnt + marked != orig_cnt)
        util.die("mark_redundant_parents {d} {d} {d} {d}", .{ orig_cnt, cnt, i, marked });
    return marked;
}

fn markTreesameRootParents(commit: *Commit) usize {
    var marked: usize = 0;
    var p = commit.parents;
    while (p) |x| : (p = x.next) {
        const parent = x.item;
        if (parent.parents == null and parent.obj.flags & TREESAME != 0) {
            parent.obj.flags |= TMP_MARK;
            marked += 1;
        }
    }
    return marked;
}

fn leaveOneTreesameToParent(revs: *RevInfo, commit: *Commit) usize {
    const ts = lookupTreesame(revs, commit) orelse return 0;
    var unmarked: ?*Commit = null;
    var marked: ?*Commit = null;
    var p = commit.parents;
    var n: usize = 0;
    while (p) |x| : ({
        p = x.next;
        n += 1;
    }) {
        if (ts.treesame[n] != 0) {
            if (x.item.obj.flags & TMP_MARK != 0) {
                if (marked == null) marked = x.item;
            } else {
                if (unmarked == null) {
                    unmarked = x.item;
                    break;
                }
            }
        }
    }
    if (unmarked == null and marked != null) {
        marked.?.obj.flags &= ~TMP_MARK;
        return 1;
    }
    return 0;
}

fn removeMarkedParents(revs: *RevInfo, commit: *Commit) usize {
    var pp: *?*CommitList = &commit.parents;
    var nth_parent: usize = 0;
    var removed: usize = 0;
    while (pp.*) |p| {
        const parent = p.item;
        if (parent.obj.flags & TMP_MARK != 0) {
            parent.obj.flags &= ~TMP_MARK;
            pp.* = p.next;
            removed += 1;
            _ = compactTreesame(revs, commit, nth_parent);
            continue;
        }
        pp = &p.next;
        nth_parent += 1;
    }
    if (removed != 0 and commit.obj.flags & TREESAME == 0) _ = updateTreesame(revs, commit);
    return nth_parent;
}

fn simplifiedOf(revs: *RevInfo, c: *Commit) *?*Commit {
    return revs.simplified.at(c);
}

fn simplifyOne(revs: *RevInfo, commit: *Commit, tail0: *?*CommitList) *?*CommitList {
    var tail = tail0;
    const st = simplifiedOf(revs, commit);
    if (st.* != null) return tail;
    if (commit.obj.flags & UNINTERESTING != 0 or commit.parents == null) {
        st.* = commit;
        return tail;
    }
    var cnt: usize = 0;
    var p = commit.parents;
    while (p) |x| : (p = x.next) {
        if (simplifiedOf(revs, x.item).* == null) {
            tail = cn.listAppend(x.item, tail);
            cnt += 1;
        }
        if (revs.first_parent_only) break;
    }
    if (cnt != 0) {
        tail = cn.listAppend(commit, tail);
        return tail;
    }
    p = commit.parents;
    while (p) |x| : (p = x.next) {
        x.item = simplifiedOf(revs, x.item).*.?;
        if (revs.first_parent_only) break;
    }
    if (revs.first_parent_only) {
        cnt = 1;
    } else cnt = removeDuplicateParents(revs, commit);

    if (1 < cnt) {
        var marked = markRedundantParents(commit);
        marked += markTreesameRootParents(commit);
        if (marked != 0) marked -= leaveOneTreesameToParent(revs, commit);
        if (marked != 0) cnt = removeMarkedParents(revs, commit);
    }
    const st2 = simplifiedOf(revs, commit);
    var parent: ?*Commit = null;
    if (cnt == 0 or commit.obj.flags & UNINTERESTING != 0 or commit.obj.flags & TREESAME == 0 or
        blk: {
            parent = oneRelevantParent(revs, commit.parents);
            break :blk parent == null;
        } or (revs.show_pulls and commit.obj.flags & PULL_MERGE != 0))
    {
        st2.* = commit;
    } else {
        st2.* = simplifiedOf(revs, parent.?).*;
    }
    return tail;
}

fn simplifyMerges(revs: *RevInfo) void {
    if (!revs.prune) return;
    var yet_to_do: ?*CommitList = null;
    var l = revs.commits;
    while (l) |x| : (l = x.next) _ = cn.listInsert(x.item, &yet_to_do);
    while (yet_to_do != null) {
        var list = yet_to_do;
        yet_to_do = null;
        var tail: *?*CommitList = &yet_to_do;
        while (cn.popCommit(&list)) |c| tail = simplifyOne(revs, c, tail);
    }
    var list = revs.commits;
    revs.commits = null;
    var tail: *?*CommitList = &revs.commits;
    while (cn.popCommit(&list)) |c| {
        if (simplifiedOf(revs, c).* == c) tail = cn.listAppend(c, tail);
    }
}

fn setChildren(revs: *RevInfo) void {
    var l = revs.commits;
    while (l) |x| : (l = x.next) {
        const commit = x.item;
        var p = commit.parents;
        while (p) |y| : (p = y.next) {
            const slot = revs.children.at(y.item);
            slot.* = cn.newNode(commit, slot.*);
        }
    }
}

/// children of a commit (with --children)
pub fn getChildren(revs: *RevInfo, c: *Commit) ?*CommitList {
    const p = revs.children.peek(c) orelse return null;
    return p.*;
}

pub fn resetRevisionWalk() void {
    cn.clearAllObjectFlags(SEEN | ADDED | SHOWN | cn.TOPO_WALK_EXPLORED | cn.TOPO_WALK_INDEGREE);
}

/// prepare_revision_walk; returns false on error.
pub fn prepareRevisionWalk(revs: *RevInfo) bool {
    const old_pending = revs.pending.items;
    revs.pending = .empty;
    var tail: *?*CommitList = &revs.commits;
    for (old_pending) |e| {
        if (handleCommit(revs, e)) |commit| {
            if (commit.obj.flags & SEEN == 0) {
                commit.obj.flags |= SEEN;
                tail = cn.listAppend(commit, tail);
            }
        }
    }
    if (revs.simplify_merges or (revs.limited and limitingCanIncreaseTreesame(revs)))
        revs.treesame_enabled = true;
    if (!revs.unsorted_input) cn.listSortByDate(&revs.commits);
    if (revs.no_walk) return true;
    if (revs.limited) {
        if (!limitList(revs)) return false;
        if (revs.topo_order) cn.sortInTopologicalOrder(&revs.commits, revs.sort_order);
    }
    if (revs.simplify_merges) simplifyMerges(revs);
    if (revs.children_enabled) setChildren(revs);
    return true;
}

// ---------------------------------------------------------------------------
// parent rewriting

const RewriteResult = enum { ok, noparents, err };

fn rewriteOne1(revs: *RevInfo, pp: **Commit, queue: *cn.PrioQueue) RewriteResult {
    while (true) {
        var p = pp.*;
        if (!revs.limited) {
            if (!processParents(revs, p, queue)) return .err;
        }
        if (p.obj.flags & UNINTERESTING != 0) return .ok;
        if (p.obj.flags & TREESAME == 0) return .ok;
        if (p.parents == null) return .noparents;
        p = oneRelevantParent(revs, p.parents) orelse return .ok;
        pp.* = p;
    }
}

fn rewriteOne(revs: *RevInfo, pp: **Commit) RewriteResult {
    var queue = cn.PrioQueue{ .compare = cn.compareByCommitDate };
    const ret = rewriteOne1(revs, pp, &queue);
    while (queue.get()) |c| revs.commit_queue.put(c);
    return ret;
}

fn rewriteParents(revs: *RevInfo, commit: *Commit) bool {
    var pp: *?*CommitList = &commit.parents;
    while (pp.*) |parent| {
        switch (rewriteOne(revs, &parent.item)) {
            .ok => {},
            .noparents => {
                pp.* = parent.next;
                continue;
            },
            .err => return false,
        }
        pp = &parent.next;
    }
    _ = removeDuplicateParents(revs, commit);
    return true;
}

// ---------------------------------------------------------------------------
// commit selection

fn applyMailmapToHeader(buf: *util.Buf, m: *mailmap_mod.Map) void {
    var out: util.Buf = .empty;
    var pos: usize = 0;
    const b = buf.items;
    var in_header = true;
    while (pos < b.len) {
        const nl = std.mem.indexOfScalarPos(u8, b, pos, '\n');
        const end = if (nl) |n| n + 1 else b.len;
        const line = b[pos..end];
        pos = end;
        if (!in_header) {
            util.bufAppend(&out, line);
            continue;
        }
        if (line.len == 1 and line[0] == '\n') {
            in_header = false;
            util.bufAppend(&out, line);
            continue;
        }
        var done = false;
        for ([_][]const u8{ "author ", "committer " }) |hdr| {
            if (!util.startsWith(line, hdr)) continue;
            const id = line[hdr.len..];
            const lt = std.mem.indexOfScalar(u8, id, '<') orelse break;
            const gt = std.mem.indexOfScalarPos(u8, id, lt, '>') orelse break;
            var name = id[0..lt];
            while (name.len > 0 and name[name.len - 1] == ' ') name = name[0 .. name.len - 1];
            const email = id[lt + 1 .. gt];
            if (mailmap_mod.mapUser(m, name, email)) |mp| {
                util.bufAppend(&out, hdr);
                util.bufAppend(&out, mp.name);
                util.bufAppend(&out, " <");
                util.bufAppend(&out, mp.email);
                util.bufAppend(&out, id[gt..]);
                done = true;
            }
            break;
        }
        if (!done) util.bufAppend(&out, line);
    }
    buf.* = out;
}

fn commitMatch(commit: *Commit, revs: *RevInfo) bool {
    if (revs.grep.isEmpty()) return true;
    var buf: util.Buf = .empty;
    if (revs.grep.hasReflogFilter()) {
        util.bufAppend(&buf, "reflog ");
        if (revs.reflog_info) |ri| reflogwalk.getReflogMessage(&buf, ri);
        util.bufByte(&buf, '\n');
    }
    _ = cn.parse(commit);
    var message = commit.buffer;
    if (reencode_hook) |h| message = h(commit, logOutputEncoding());
    if (buf.items.len > 0) util.bufAppend(&buf, message);
    if (revs.grep.header_list.items.len > 0 and revs.mailmap != null) {
        if (buf.items.len == 0) util.bufAppend(&buf, message);
        applyMailmapToHeader(&buf, revs.mailmap.?);
    }
    if (buf.items.len > 0) return revs.grep.matchBuffer(buf.items);
    return revs.grep.matchBuffer(message);
}

fn wantAncestry(revs: *const RevInfo) bool {
    return revs.rewrite_parents or revs.children_enabled;
}

fn comparisonDate(revs: *const RevInfo, commit: *Commit) u64 {
    if (revs.reflog_info) |ri| return reflogwalk.getReflogTimestamp(ri);
    return commit.date;
}

fn commitEarlyIgnore(revs: *const RevInfo, commit: *Commit) bool {
    if (commit.obj.flags & SHOWN != 0) return true;
    if (revs.maximal_only and commit.obj.flags & CHILD_VISITED != 0) return true;
    if (commit.obj.flags & UNINTERESTING != 0) return true;
    return false;
}

/// get_commit_action
pub fn getCommitAction(revs: *RevInfo, commit: *Commit) CommitAction {
    if (commitEarlyIgnore(revs, commit)) return .ignore;
    if (revs.min_age != UNSET_TIME and comparisonDate(revs, commit) > revs.min_age) return .ignore;
    if (revs.max_age_as_filter != UNSET_TIME and comparisonDate(revs, commit) < revs.max_age_as_filter) return .ignore;
    if (revs.min_parents != 0 or revs.max_parents >= 0) {
        const n: i32 = @intCast(commit.parentCount());
        if (n < revs.min_parents or (revs.max_parents >= 0 and n > revs.max_parents)) return .ignore;
    }
    if (!commitMatch(commit, revs)) return .ignore;
    if (revs.prune and revs.dense) {
        if (commit.obj.flags & TREESAME != 0) {
            if (!wantAncestry(revs)) return .ignore;
            if (revs.show_pulls and commit.obj.flags & PULL_MERGE != 0) return .show;
            var n: usize = 0;
            var p = commit.parents;
            while (p) |x| : (p = x.next) {
                if (relevantCommit(x.item)) {
                    n += 1;
                    if (n >= 2) return .show;
                }
            }
            return .ignore;
        }
    }
    return .show;
}

fn saveParents(revs: *RevInfo, commit: *Commit) void {
    if (revs.saved_parents == null) {
        const s = gpa.create(cn.Slab(?SavedParents)) catch util.oom();
        s.* = cn.Slab(?SavedParents).init(null);
        revs.saved_parents = s;
    }
    const pp = revs.saved_parents.?.at(commit);
    if (pp.* != null) return;
    if (commit.parents != null) {
        pp.* = .{ .list = cn.listCopy(commit.parents) };
    } else pp.* = .empty;
}

/// get_saved_parents: original parents (before rewriting) when --full-diff
pub fn getSavedParents(revs: *RevInfo, commit: *Commit) ?*CommitList {
    const s = revs.saved_parents orelse return commit.parents;
    const p = s.at(commit).*;
    if (p) |sp| {
        return switch (sp) {
            .empty => null,
            .list => |l| l,
        };
    }
    return null;
}

pub fn simplifyCommit(revs: *RevInfo, commit: *Commit) CommitAction {
    const action = getCommitAction(revs, commit);
    if (action == .show and revs.prune and revs.dense and wantAncestry(revs)) {
        if (revs.full_diff) saveParents(revs, commit);
        if (!rewriteParents(revs, commit)) return .error_;
    }
    return action;
}

fn trackLinear(revs: *RevInfo, commit: *Commit) void {
    if (revs.track_first_time) {
        revs.linear = true;
        revs.track_first_time = false;
    } else {
        var found = false;
        var p = revs.previous_parents;
        while (p) |x| : (p = x.next) {
            if (hash.eql(x.item.obj.oid, commit.obj.oid)) {
                found = true;
                break;
            }
        }
        revs.linear = found;
    }
    if (revs.reverse) {
        if (revs.linear) commit.obj.flags |= TRACK_LINEAR;
    }
    revs.previous_parents = cn.listCopy(commit.parents);
}

const WalkMode = enum { reflog, limited, no_walk, streaming };

fn getRevision1(revs: *RevInfo) ?*Commit {
    const mode: WalkMode = if (revs.reflog_info != null) .reflog else if (revs.limited) .limited else if (revs.no_walk) .no_walk else .streaming;
    if (mode == .streaming and revs.commits != null) {
        while (cn.popCommit(&revs.commits)) |c| revs.commit_queue.put(c);
    }
    while (true) {
        const commit: *Commit = switch (mode) {
            .reflog => reflogwalk.nextReflogEntry(revs.reflog_info.?),
            .limited, .no_walk => cn.popCommit(&revs.commits),
            .streaming => revs.commit_queue.get(),
        } orelse return null;
        if (mode == .reflog) commit.obj.flags &= ~(ADDED | SEEN | SHOWN);
        if (mode != .limited and revs.max_age != UNSET_TIME and comparisonDate(revs, commit) < revs.max_age) continue;
        switch (mode) {
            .reflog, .no_walk => tryToSimplifyCommit(revs, commit),
            .streaming => {
                if (!processParents(revs, commit, &revs.commit_queue)) {
                    if (!revs.ignore_missing_links)
                        util.die("Failed to traverse parents of commit {s}", .{commit.hex()});
                }
            },
            .limited => {},
        }
        switch (simplifyCommit(revs, commit)) {
            .ignore => continue,
            .error_ => util.die("Failed to simplify parents of commit {s}", .{commit.hex()}),
            .show => {
                if (revs.track_linear) trackLinear(revs, commit);
                return commit;
            },
        }
    }
}

fn createBoundaryCommitList(revs: *RevInfo) void {
    revs.commits = null;
    for (revs.boundary_commits.items) |c| {
        if (c.obj.flags & CHILD_SHOWN == 0) continue;
        if (c.obj.flags & (SHOWN | BOUNDARY) != 0) continue;
        c.obj.flags |= BOUNDARY;
        _ = cn.listInsert(c, &revs.commits);
    }
    cn.sortInTopologicalOrder(&revs.commits, revs.sort_order);
}

fn getRevisionInternal(revs: *RevInfo) ?*Commit {
    var c: ?*Commit = null;
    if (revs.boundary == 2) {
        c = cn.popCommit(&revs.commits);
        if (c) |x| x.obj.flags |= SHOWN;
        return c;
    }
    if (revs.max_count != 0) {
        c = getRevision1(revs);
        if (c != null) {
            while (revs.skip_count > 0) {
                revs.skip_count -= 1;
                c = getRevision1(revs);
                if (c == null) break;
            }
        }
        if (revs.max_count > 0) revs.max_count -= 1;
    }
    if (c) |x| x.obj.flags |= SHOWN;
    if (revs.boundary == 0) return c;
    const cc = c orelse {
        revs.boundary = 2;
        createBoundaryCommitList(revs);
        return getRevisionInternal(revs);
    };
    var l = cc.parents;
    while (l) |x| : (l = x.next) {
        const p = &x.item.obj;
        if (p.flags & (CHILD_SHOWN | SHOWN) != 0) continue;
        p.flags |= CHILD_SHOWN;
        revs.boundary_commits.append(gpa, x.item) catch util.oom();
    }
    return cc;
}

fn retrieveOldestCommits(revs: *RevInfo, queue: *?*CommitList) void {
    const max_count = revs.max_count;
    var queuei_count: i32 = 0;
    var queueo_count: i32 = 0;
    var queueo: ?*CommitList = null;
    var queuei: ?*CommitList = null;
    var reversed_queue: ?*CommitList = null;
    revs.max_count = -1;
    while (getRevisionInternal(revs)) |c0| {
        c0.obj.flags &= ~(SHOWN | CHILD_SHOWN);
        _ = cn.listInsert(c0, &queuei);
        if (c0.obj.flags & BOUNDARY == 0) queuei_count += 1;
        while (queuei_count + queueo_count > max_count) {
            if (queueo_count == 0) {
                while (cn.popCommit(&queuei)) |c| {
                    _ = cn.listInsert(c, &queueo);
                    queueo_count += 1;
                }
                queuei_count = 0;
            }
            const c = cn.popCommit(&queueo).?;
            queueo_count -= 1;
            var p = c.parents;
            while (p) |x| : (p = x.next) x.item.obj.flags &= ~CHILD_SHOWN;
        }
    }
    while (cn.popCommit(&queueo)) |c| _ = cn.listInsert(c, &reversed_queue);
    while (cn.popCommit(&queuei)) |c| _ = cn.listInsert(c, &queueo);
    while (cn.popCommit(&queueo)) |c| _ = cn.listInsert(c, &reversed_queue);
    while (cn.popCommit(&reversed_queue)) |c| _ = cn.listInsert(c, queue);
}

fn nextCommitToShow(revs: *RevInfo) ?*Commit {
    if (revs.max_count_stage == 0) return getRevisionInternal(revs);
    const c = cn.popCommit(&revs.commits) orelse return null;
    c.obj.flags |= SHOWN;
    if (c.obj.flags & BOUNDARY == 0) {
        var p = c.parents;
        while (p) |x| : (p = x.next) x.item.obj.flags |= CHILD_SHOWN;
    }
    return c;
}

/// get_revision
pub fn getRevision(revs: *RevInfo) ?*Commit {
    if (revs.max_count_type == 1 and revs.max_count_stage == 0) {
        var queue: ?*CommitList = null;
        retrieveOldestCommits(revs, &queue);
        revs.commits = queue;
        revs.max_count_stage = 1;
    }
    if (revs.reverse) {
        var reversed: ?*CommitList = null;
        if (revs.max_count_type == 1) {
            while (cn.popCommit(&revs.commits)) |c| _ = cn.listInsert(c, &reversed);
        } else {
            while (getRevisionInternal(revs)) |c| _ = cn.listInsert(c, &reversed);
        }
        revs.commits = reversed;
        revs.reverse = false;
        revs.reverse_output_stage = true;
    }
    if (revs.reverse_output_stage) {
        const c = cn.popCommit(&revs.commits);
        if (revs.track_linear) revs.linear = c != null and c.?.obj.flags & TRACK_LINEAR != 0;
        return c;
    }
    var c: ?*Commit = null;
    if (revs.graph) |g| {
        c = graph_mod.popLookahead(g);
        if (c == null) c = nextCommitToShow(revs);
    } else c = nextCommitToShow(revs);

    if (c != null and revs.graph != null) {
        const g = revs.graph.?;
        while (graph_mod.getLookaheadRoom(g) > 0) {
            const next = nextCommitToShow(revs) orelse break;
            graph_mod.pushLookahead(g, next);
        }
        graph_mod.update(g, c.?);
    }
    if (c == null) {
        revs.saved_parents = null;
        revs.previous_parents = null;
    }
    return c;
}

/// get_revision_mark: "<", ">", "-", "=", "+" or "" / "*" for graph.
pub fn getRevisionMark(revs: ?*const RevInfo, commit: *const Commit) []const u8 {
    const f = commit.obj.flags;
    if (f & cn.BOUNDARY != 0) return "-";
    if (f & cn.UNINTERESTING != 0) return "^";
    if (f & cn.PATCHSAME != 0) return "=";
    if (revs == null or revs.?.left_right) {
        if (f & cn.SYMMETRIC_LEFT != 0) return "<";
        return ">";
    }
    if (revs.?.graph != null) return "*";
    if (revs.?.cherry_mark) return "+";
    return "";
}

/// put_revision_mark: mark followed by a space (nothing if empty)
pub fn putRevisionMark(revs: ?*const RevInfo, commit: *const Commit) void {
    const m = getRevisionMark(revs, commit);
    if (m.len == 0) return;
    util.out(m);
    util.out(" ");
}

// ---------------------------------------------------------------------------
// list-objects

pub const ShowCommitFn = *const fn (*Commit, ?*anyopaque) void;
pub const ShowObjectFn = *const fn (*Obj, []const u8, ?*anyopaque) void;

const Traversal = struct {
    revs: *RevInfo,
    show_commit: ?ShowCommitFn,
    show_object: ?ShowObjectFn,
    data: ?*anyopaque,
};

fn travShowObject(ctx: *Traversal, obj: *Obj, name: []const u8) void {
    if (ctx.show_object) |f| f(obj, name, ctx.data);
}

fn traversalPathspec(revs: *RevInfo) *const pathspec.Pathspec {
    const S = struct {
        var empty: pathspec.Pathspec = .{};
    };
    if (revs.full_diff) return &S.empty;
    return &revs.prune_data;
}

fn processBlob(ctx: *Traversal, obj: *Obj, path: []const u8) void {
    if (!ctx.revs.blob_objects) return;
    if (obj.flags & (UNINTERESTING | SEEN) != 0) return;
    obj.flags |= SEEN;
    travShowObject(ctx, obj, path);
}

fn processTree(ctx: *Traversal, obj: *Obj, base: []const u8) void {
    const revs = ctx.revs;
    if (!revs.tree_objects) return;
    if (obj.flags & (UNINTERESTING | SEEN) != 0) return;
    const entries = readTreeCached(obj.oid);
    if (entries == null and !revs.ignore_missing_links)
        util.die("bad tree object {s}", .{hash.hex(obj.oid)});
    obj.flags |= SEEN;
    travShowObject(ctx, obj, base);
    const ents = entries orelse return;
    const ps = traversalPathspec(revs);
    for (ents) |e| {
        const full = joinBase(base, e.name);
        if (!ps.isEmpty() and !entryInteresting(ps, full, e.isDir())) continue;
        if (e.isDir()) {
            const t = cn.lookup(e.oid, .tree) orelse
                util.die("entry '{s}' in tree {s} has tree mode, but is not a tree", .{ e.name, hash.hex(obj.oid) });
            t.flags |= NOT_USER_GIVEN;
            processTree(ctx, t, full);
        } else if (isGitlink(e.mode)) {
            // ignore gitlink
        } else {
            const b = cn.lookup(e.oid, .blob) orelse
                util.die("entry '{s}' in tree {s} has blob mode, but is not a blob", .{ e.name, hash.hex(obj.oid) });
            b.flags |= NOT_USER_GIVEN;
            processBlob(ctx, b, full);
        }
    }
}

fn traverseNonCommits(ctx: *Traversal) void {
    const items = ctx.revs.pending.items;
    ctx.revs.pending = .empty;
    for (items) |p| {
        const obj = p.item;
        if (obj.flags & (UNINTERESTING | SEEN) != 0) continue;
        if (obj.typ == .tag) {
            obj.flags |= SEEN;
            travShowObject(ctx, obj, p.name);
            continue;
        }
        const path = p.path orelse "";
        if (obj.typ == .tree) {
            processTree(ctx, obj, path);
            continue;
        }
        if (obj.typ == .blob) {
            processBlob(ctx, obj, path);
            continue;
        }
        util.die("unknown pending object {s} ({s})", .{ hash.hex(obj.oid), p.name });
    }
}

/// traverse_commit_list
pub fn traverseCommitList(revs: *RevInfo, show_commit: ?ShowCommitFn, show_object: ?ShowObjectFn, data: ?*anyopaque) void {
    var ctx = Traversal{ .revs = revs, .show_commit = show_commit, .show_object = show_object, .data = data };
    while (getRevision(revs)) |commit| {
        if (revs.tree_objects) {
            if (commitTree(commit)) |t| {
                t.flags |= NOT_USER_GIVEN;
                revs.addPendingObject(t, "");
            } else util.die("unable to load root tree for commit {s}", .{commit.hex()});
        }
        if (show_commit) |f| f(commit, data);
        if (revs.tree_blobs_in_commit_order) traverseNonCommits(&ctx);
    }
    traverseNonCommits(&ctx);
}

pub const ShowEdgeFn = *const fn (*Commit) void;

/// mark_edges_uninteresting (non-sparse)
pub fn markEdgesUninteresting(revs: *RevInfo, show_edge: ShowEdgeFn) void {
    var list = revs.commits;
    while (list) |x| : (list = x.next) {
        const commit = x.item;
        if (commit.obj.flags & UNINTERESTING != 0) {
            if (commitTree(commit)) |t| markTreeUninteresting(t);
            if (revs.edge_hint_aggressive and commit.obj.flags & SHOWN == 0) {
                commit.obj.flags |= SHOWN;
                show_edge(commit);
            }
            continue;
        }
        var p = commit.parents;
        while (p) |y| : (p = y.next) {
            const parent = y.item;
            if (parent.obj.flags & UNINTERESTING == 0) continue;
            if (commitTree(parent)) |t| markTreeUninteresting(t);
            if (revs.edge_hint and parent.obj.flags & SHOWN == 0) {
                parent.obj.flags |= SHOWN;
                show_edge(parent);
            }
        }
    }
    if (revs.edge_hint_aggressive) {
        for (revs.cmdline.items) |e| {
            const obj = e.item;
            if (obj.typ != .commit or obj.flags & UNINTERESTING == 0) continue;
            const commit = Commit.fromObj(obj);
            if (commitTree(commit)) |t| markTreeUninteresting(t);
            if (obj.flags & SHOWN == 0) {
                obj.flags |= SHOWN;
                show_edge(commit);
            }
        }
    }
}
