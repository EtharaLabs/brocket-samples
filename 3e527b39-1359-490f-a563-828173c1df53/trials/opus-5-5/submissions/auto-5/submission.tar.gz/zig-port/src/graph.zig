//! Commit history graph (port of git's graph.c / graph.h).
//!
//! Usage mirrors the C API:
//!   g = graph.init(revs); per commit: graph.update(g, commit); then
//!   showCommit / nextLine / showCommitMsg / showRemainder ...
//! Output goes to util.out (stdout). `line_prefix` is the --line-prefix
//! string (diffopt->line_prefix) emitted before each graph line.

const std = @import("std");
const util = @import("util.zig");
const cn = @import("commitnode.zig");
const revision = @import("revision.zig");
const repo_mod = @import("repo.zig");

const gpa = util.gpa;

/// diffopt->line_prefix equivalent (--line-prefix). Emitted before graph lines.
pub var line_prefix: []const u8 = "";

// ---------------- colors ----------------

const GIT_COLOR_RESET = "\x1b[m";

const column_colors_ansi = [_][]const u8{
    "\x1b[31m", // red
    "\x1b[32m", // green
    "\x1b[33m", // yellow
    "\x1b[34m", // blue
    "\x1b[35m", // magenta
    "\x1b[36m", // cyan
    "\x1b[1;31m", // bold red
    "\x1b[1;32m",
    "\x1b[1;33m",
    "\x1b[1;34m",
    "\x1b[1;35m",
    "\x1b[1;36m",
    GIT_COLOR_RESET,
};

var column_colors: ?[]const []const u8 = null;
var column_colors_max: u16 = 0;

/// graph_set_column_colors: `colors[colors_max]` must be the reset escape.
pub fn setColumnColors(colors: []const []const u8, colors_max: u16) void {
    column_colors = colors;
    column_colors_max = colors_max;
}

fn columnGetColorCode(color: u16) []const u8 {
    return column_colors.?[color];
}

// ---- minimal port of color.c color_parse_mem ----

const ColorType = enum { unspecified, normal, ansi, c256, rgb };
const Color = struct {
    typ: ColorType = .unspecified,
    value: u8 = 0,
    red: u8 = 0,
    green: u8 = 0,
    blue: u8 = 0,
};

fn matchWord(word: []const u8, match: []const u8) bool {
    return word.len == match.len and std.ascii.eqlIgnoreCase(word, match);
}

fn hexval(ch: u8) u32 {
    return switch (ch) {
        '0'...'9' => ch - '0',
        'a'...'f' => ch - 'a' + 10,
        'A'...'F' => ch - 'A' + 10,
        else => 0xffff_ffff,
    };
}

fn getHexColor(in: []const u8, w: usize, outp: *u8) bool {
    const v = (hexval(in[0]) << 4) | hexval(in[w - 1]);
    if (v & ~@as(u32, 0xff) != 0) return false;
    outp.* = @intCast(v);
    return true;
}

fn parseAnsiColor(outp: *Color, name_in: []const u8) bool {
    const names = [_][]const u8{ "black", "red", "green", "yellow", "blue", "magenta", "cyan", "white" };
    var name = name_in;
    var offset: u8 = 30;
    if (matchWord(name, "default")) {
        outp.* = .{ .typ = .ansi, .value = 9 + offset };
        return true;
    }
    if (name.len >= 6 and std.ascii.eqlIgnoreCase(name[0..6], "bright")) {
        offset = 90;
        name = name[6..];
    }
    for (names, 0..) |n, i| {
        if (matchWord(name, n)) {
            outp.* = .{ .typ = .ansi, .value = @as(u8, @intCast(i)) + offset };
            return true;
        }
    }
    return false;
}

fn parseOneColor(outp: *Color, name: []const u8) bool {
    if (matchWord(name, "normal")) {
        outp.* = .{ .typ = .normal };
        return true;
    }
    if ((name.len == 7 or name.len == 4) and name[0] == '#') {
        const w: usize = if (name.len == 7) 2 else 1;
        var c: Color = .{ .typ = .rgb };
        if (getHexColor(name[1..], w, &c.red) and
            getHexColor(name[1 + w ..], w, &c.green) and
            getHexColor(name[1 + 2 * w ..], w, &c.blue))
        {
            outp.* = c;
            return true;
        }
    }
    if (parseAnsiColor(outp, name)) return true;
    // strtol-ish: optional whitespace/sign then digits, must consume all
    var i: usize = 0;
    while (i < name.len and std.ascii.isWhitespace(name[i])) i += 1;
    var neg = false;
    if (i < name.len and (name[i] == '-' or name[i] == '+')) {
        neg = name[i] == '-';
        i += 1;
    }
    const ds = i;
    var val: i64 = 0;
    while (i < name.len and std.ascii.isDigit(name[i])) : (i += 1) {
        if (val < 1_000_000) val = val * 10 + (name[i] - '0');
    }
    if (i > ds and i == name.len) {
        if (neg) val = -val;
        if (val < -1) {
            // error
        } else if (val < 0) {
            outp.* = .{ .typ = .normal };
            return true;
        } else if (val < 8) {
            outp.* = .{ .typ = .ansi, .value = @intCast(val + 30) };
            return true;
        } else if (val < 16) {
            outp.* = .{ .typ = .ansi, .value = @intCast(val - 8 + 90) };
            return true;
        } else if (val < 256) {
            outp.* = .{ .typ = .c256, .value = @intCast(val) };
            return true;
        }
    }
    return false;
}

fn parseAttr(name_in: []const u8) i32 {
    const Attr = struct { n: []const u8, val: i32, neg: i32 };
    const attrs = [_]Attr{
        .{ .n = "bold", .val = 1, .neg = 22 },
        .{ .n = "dim", .val = 2, .neg = 22 },
        .{ .n = "italic", .val = 3, .neg = 23 },
        .{ .n = "ul", .val = 4, .neg = 24 },
        .{ .n = "blink", .val = 5, .neg = 25 },
        .{ .n = "reverse", .val = 7, .neg = 27 },
        .{ .n = "strike", .val = 9, .neg = 29 },
    };
    var name = name_in;
    var negate = false;
    if (std.mem.startsWith(u8, name, "no")) {
        name = name[2..];
        if (std.mem.startsWith(u8, name, "-")) name = name[1..];
        negate = true;
    }
    for (attrs) |a| {
        if (std.mem.eql(u8, a.n, name)) return if (negate) a.neg else a.val;
    }
    return -1;
}

fn colorEmpty(c: Color) bool {
    return c.typ == .unspecified or c.typ == .normal;
}

fn colorOutput(b: *util.Buf, c: Color, background: bool) void {
    const off: u32 = if (background) 10 else 0;
    switch (c.typ) {
        .unspecified, .normal => {},
        .ansi => util.bufPrint(b, "{d}", .{c.value + off}),
        .c256 => util.bufPrint(b, "{d};5;{d}", .{ 38 + off, c.value }),
        .rgb => util.bufPrint(b, "{d};2;{d};{d};{d}", .{ 38 + off, c.red, c.green, c.blue }),
    }
}

/// color_parse_mem: returns the escape sequence, or null (after printing
/// "error: invalid color value") on failure.
fn colorParseMem(value: []const u8) ?[]const u8 {
    var p: usize = 0;
    while (p < value.len and std.ascii.isWhitespace(value[p])) p += 1;
    if (p == value.len) return "";
    var has_reset = false;
    var attr: u32 = 0;
    var fg: Color = .{};
    var bg: Color = .{};
    while (p < value.len) {
        const ws = p;
        while (p < value.len and !std.ascii.isWhitespace(value[p])) p += 1;
        const word = value[ws..p];
        while (p < value.len and std.ascii.isWhitespace(value[p])) p += 1;
        if (matchWord(word, "reset")) {
            has_reset = true;
            continue;
        }
        var c: Color = .{};
        if (parseOneColor(&c, word)) {
            if (fg.typ == .unspecified) {
                fg = c;
                continue;
            }
            if (bg.typ == .unspecified) {
                bg = c;
                continue;
            }
        } else {
            const v = parseAttr(word);
            if (v >= 0) {
                attr |= @as(u32, 1) << @intCast(v);
                continue;
            }
        }
        util.err("invalid color value: {s}", .{value});
        return null;
    }
    var b: util.Buf = .empty;
    if (has_reset or attr != 0 or !colorEmpty(fg) or !colorEmpty(bg)) {
        var sep: u32 = 0;
        util.bufAppend(&b, "\x1b[");
        if (has_reset) sep += 1;
        var i: u5 = 0;
        while (attr != 0) : (i += 1) {
            const bit = @as(u32, 1) << i;
            if (attr & bit == 0) continue;
            attr &= ~bit;
            if (sep != 0) util.bufByte(&b, ';');
            sep += 1;
            util.bufPrint(&b, "{d}", .{i});
        }
        if (!colorEmpty(fg)) {
            if (sep != 0) util.bufByte(&b, ';');
            sep += 1;
            colorOutput(&b, fg, false);
        }
        if (!colorEmpty(bg)) {
            if (sep != 0) util.bufByte(&b, ';');
            sep += 1;
            colorOutput(&b, bg, true);
        }
        util.bufByte(&b, 'm');
    }
    return b.items;
}

fn parseGraphColorsConfig(string: []const u8) []const []const u8 {
    var colors: std.ArrayList([]const u8) = .empty;
    var start: usize = 0;
    const end = string.len;
    while (start < end) {
        const comma = std.mem.indexOfScalarPos(u8, string, start, ',') orelse end;
        const piece = string[start..comma];
        if (colorParseMem(piece)) |c| {
            colors.append(gpa, c) catch util.oom();
        } else {
            util.warn("ignored invalid color '{s}' in log.graphColors", .{piece});
        }
        start = comma + 1;
    }
    colors.append(gpa, GIT_COLOR_RESET) catch util.oom();
    return colors.items;
}

// ---------------- graph state ----------------

const Column = struct {
    commit: *cn.Commit,
    color: u16 = 0,
    is_merge_parent: bool = false,
};

const State = enum {
    padding,
    skip,
    pre_commit,
    pre_root,
    commit,
    post_merge,
    collapsing,
};

const Line = struct {
    buf: *util.Buf,
    width: usize = 0,

    fn addch(l: *Line, ch: u8) void {
        util.bufByte(l.buf, ch);
        l.width += 1;
    }
    fn addchars(l: *Line, ch: u8, n: usize) void {
        l.buf.appendNTimes(gpa, ch, n) catch util.oom();
        l.width += n;
    }
    fn addstr(l: *Line, s: []const u8) void {
        util.bufAppend(l.buf, s);
        l.width += s.len;
    }
    fn addcolor(l: *Line, color: u16) void {
        util.bufAppend(l.buf, columnGetColorCode(color));
    }
    fn writeColumn(l: *Line, c: *const Column, col_char: u8) void {
        if (c.color < column_colors_max) l.addcolor(c.color);
        l.addch(col_char);
        if (c.color < column_colors_max) l.addcolor(column_colors_max);
    }
};

pub const Graph = struct {
    revs: *revision.RevInfo,
    commit: ?*cn.Commit = null,
    num_parents: i32 = 0,
    width: i32 = 0,
    expansion_row: i32 = 0,
    state: State = .padding,
    prev_state: State = .padding,
    commit_index: i32 = 0,
    prev_commit_index: i32 = 0,
    merge_layout: i32 = 0,
    edges_added: i32 = 0,
    prev_edges_added: i32 = 0,
    column_capacity: i32 = 0,
    num_columns: i32 = 0,
    num_new_columns: i32 = 0,
    mapping_size: i32 = 0,
    columns: []Column = &.{},
    new_columns: []Column = &.{},
    mapping: []i32 = &.{},
    old_mapping: []i32 = &.{},
    default_column_color: u16 = 0,
    prefix_buf: util.Buf = .empty,
    lookahead: [2]?*cn.Commit = .{ null, null },
    lookahead_nr: usize = 0,
    is_visual_root: bool = false,
    visual_root_depth: u32 = 0,
    visual_root_cascade: bool = false,
    commit_in_columns: bool = false,

    fn col(g: *Graph, i: i32) *Column {
        return &g.columns[@intCast(i)];
    }
    fn ncol(g: *Graph, i: i32) *Column {
        return &g.new_columns[@intCast(i)];
    }
    fn map(g: *Graph, i: i32) *i32 {
        return &g.mapping[@intCast(i)];
    }
    fn omap(g: *Graph, i: i32) *i32 {
        return &g.old_mapping[@intCast(i)];
    }
};

const LookaheadFlags = struct {
    is_next_visible: bool = false,
    is_next_visual_root: bool = false,
    next_has_column: bool = false,
};

fn needsTruncation(g: *const Graph, lane: i32) bool {
    const max = g.revs.graph_max_lanes;
    return max > 0 and lane >= max;
}

fn readConfig(revs: *revision.RevInfo) void {
    if (column_colors == null) {
        const e = repo_mod.cfg.getEntry("log.graphcolors");
        if (e != null and e.?.value != null) {
            const colors = parseGraphColorsConfig(e.?.value.?);
            setColumnColors(colors, @intCast(colors.len - 1));
        } else {
            setColumnColors(&column_colors_ansi, column_colors_ansi.len - 1);
        }
    }
    if (repo_mod.cfg.getBool("log.graphindent")) |v| revs.no_graph_indent = !v;
}

/// graph_init
pub fn init(revs: *revision.RevInfo) *Graph {
    readConfig(revs);
    const g = gpa.create(Graph) catch util.oom();
    g.* = .{ .revs = revs };
    // Start at max so first increment yields 0.
    g.default_column_color = if (column_colors_max > 0) column_colors_max - 1 else 0;
    g.column_capacity = 30;
    g.columns = gpa.alloc(Column, 30) catch util.oom();
    g.new_columns = gpa.alloc(Column, 30) catch util.oom();
    g.mapping = gpa.alloc(i32, 60) catch util.oom();
    g.old_mapping = gpa.alloc(i32, 60) catch util.oom();
    return g;
}

fn updateState(g: *Graph, s: State) void {
    g.prev_state = g.state;
    g.state = s;
}

fn ensureCapacity(g: *Graph, num_columns: i32) void {
    if (g.column_capacity >= num_columns) return;
    while (true) {
        g.column_capacity *= 2;
        if (g.column_capacity >= num_columns) break;
    }
    const cap: usize = @intCast(g.column_capacity);
    g.columns = gpa.realloc(g.columns, cap) catch util.oom();
    g.new_columns = gpa.realloc(g.new_columns, cap) catch util.oom();
    g.mapping = gpa.realloc(g.mapping, cap * 2) catch util.oom();
    g.old_mapping = gpa.realloc(g.old_mapping, cap * 2) catch util.oom();
}

fn isInteresting(g: *Graph, commit: *cn.Commit) bool {
    for (g.lookahead[0..g.lookahead_nr]) |c| {
        if (c == commit) return true;
    }
    if (g.revs.boundary != 0) {
        if (commit.obj.flags & cn.CHILD_SHOWN != 0) return true;
    }
    return revision.getCommitAction(g.revs, commit) == .show;
}

fn nextInterestingParent(g: *Graph, orig: *cn.CommitList) ?*cn.CommitList {
    if (g.revs.first_parent_only) return null;
    var l = orig.next;
    while (l) |p| : (l = p.next) {
        if (isInteresting(g, p.item)) return p;
    }
    return null;
}

fn firstInterestingParent(g: *Graph) ?*cn.CommitList {
    const parents = g.commit.?.parents orelse return null;
    if (isInteresting(g, parents.item)) return parents;
    return nextInterestingParent(g, parents);
}

fn getCurrentColumnColor(g: *const Graph) u16 {
    if (!g.revs.use_color) return column_colors_max;
    return g.default_column_color;
}

fn incrementColumnColor(g: *Graph) void {
    if (column_colors_max == 0) return;
    g.default_column_color = @intCast((@as(u32, g.default_column_color) + 1) % column_colors_max);
}

fn findCommitColor(g: *Graph, commit: *const cn.Commit) u16 {
    var i: i32 = 0;
    while (i < g.num_columns) : (i += 1) {
        if (g.col(i).commit == commit) return g.col(i).color;
    }
    return getCurrentColumnColor(g);
}

fn findNewColumnByCommit(g: *Graph, commit: *const cn.Commit) i32 {
    var i: i32 = 0;
    while (i < g.num_new_columns) : (i += 1) {
        if (g.ncol(i).commit == commit) return i;
    }
    return -1;
}

fn insertIntoNewColumns(g: *Graph, commit: *cn.Commit, idx: i32) void {
    const initial_merge_layout = g.merge_layout;
    var i = findNewColumnByCommit(g, commit);
    var mapping_idx: i32 = undefined;

    if (i < 0) {
        i = g.num_new_columns;
        g.num_new_columns += 1;
        g.ncol(i).* = .{ .commit = commit, .color = findCommitColor(g, commit), .is_merge_parent = false };
    }

    if (g.num_parents > 1 and idx > -1 and g.merge_layout == -1) {
        const dist = idx - i;
        const shift: i32 = if (dist > 1) 2 * dist - 3 else 1;
        g.merge_layout = if (dist > 0) 0 else 1;
        g.edges_added = g.num_parents + g.merge_layout - 2;
        mapping_idx = g.width + (g.merge_layout - 1) * shift;
        g.width += 2 * g.merge_layout;
    } else if (g.edges_added > 0 and i == g.map(g.width - 2).*) {
        mapping_idx = g.width - 2;
        g.edges_added = -1;
    } else {
        mapping_idx = g.width;
        g.width += 2;
    }

    g.map(mapping_idx).* = i;

    if (g.num_parents > 1 and initial_merge_layout >= 0 and idx > -1)
        g.ncol(i).is_merge_parent = true;
}

fn updateColumns(g: *Graph) void {
    std.mem.swap([]Column, &g.columns, &g.new_columns);
    g.num_columns = g.num_new_columns;
    g.num_new_columns = 0;

    const max_new_columns = g.num_columns + g.num_parents;
    ensureCapacity(g, max_new_columns);

    g.mapping_size = 2 * max_new_columns;
    var i: i32 = 0;
    while (i < g.mapping_size) : (i += 1) g.map(i).* = -1;

    g.width = 0;
    g.prev_edges_added = g.edges_added;
    g.edges_added = 0;

    const commit = g.commit.?;
    var seen_this = false;
    var is_commit_in_columns = true;
    i = 0;
    while (i <= g.num_columns) : (i += 1) {
        var col_commit: *cn.Commit = undefined;
        if (i == g.num_columns) {
            if (seen_this) break;
            is_commit_in_columns = false;
            col_commit = commit;
        } else {
            col_commit = g.col(i).commit;
        }

        if (col_commit == commit) {
            seen_this = true;
            g.commit_index = i;
            g.merge_layout = -1;
            var parent = firstInterestingParent(g);
            while (parent) |p| : (parent = nextInterestingParent(g, p)) {
                if (g.num_parents > 1 or !is_commit_in_columns)
                    incrementColumnColor(g);
                insertIntoNewColumns(g, p.item, i);
            }
            if (g.num_parents == 0) g.width += 2;
        } else {
            insertIntoNewColumns(g, col_commit, -1);
            const j = findNewColumnByCommit(g, col_commit);
            if (j >= 0 and g.col(i).is_merge_parent)
                g.ncol(j).is_merge_parent = true;
        }
    }

    g.commit_in_columns = is_commit_in_columns;

    if (g.revs.graph_max_lanes > 0) {
        const max_width = g.revs.graph_max_lanes * 2 + 2;
        if (g.width > max_width) g.width = max_width;
    }

    while (g.mapping_size > 1 and g.map(g.mapping_size - 1).* < 0)
        g.mapping_size -= 1;
}

fn numDashedParents(g: *Graph) i32 {
    return g.num_parents + g.merge_layout - 3;
}

fn numExpansionRows(g: *Graph) i32 {
    return numDashedParents(g) * 2;
}

fn needsPreCommitLine(g: *Graph) bool {
    return g.num_parents >= 3 and
        g.commit_index < (g.num_columns - 1) and
        g.expansion_row < numExpansionRows(g);
}

/// graph_pop_lookahead
pub fn popLookahead(g: *Graph) ?*cn.Commit {
    if (g.lookahead_nr == 0) return null;
    const c = g.lookahead[0] orelse
        @panic("BUG: lookahead buffer has entries but the first one is NULL");
    g.lookahead[0] = g.lookahead[1];
    g.lookahead[1] = null;
    g.lookahead_nr -= 1;
    return c;
}

/// graph_get_lookahead_room
pub fn getLookaheadRoom(g: *Graph) usize {
    return g.lookahead.len - g.lookahead_nr;
}

/// graph_push_lookahead
pub fn pushLookahead(g: *Graph, c: *cn.Commit) void {
    if (getLookaheadRoom(g) == 0)
        @panic("BUG: pushing into lookahead buffer when it is already full");
    g.lookahead[g.lookahead_nr] = c;
    g.lookahead_nr += 1;
}

fn isVisualRootCandidate(c: *cn.Commit, g: *Graph) bool {
    if (c.obj.flags & cn.BOUNDARY != 0) return false;
    var p = c.parents;
    while (p) |l| : (p = l.next) {
        if (isInteresting(g, l.item)) return false;
    }
    return true;
}

fn isVisualRoot(g: *Graph, flags: *const LookaheadFlags) bool {
    return isVisualRootCandidate(g.commit.?, g) and
        !(g.commit_in_columns and g.col(g.commit_index).is_merge_parent) and
        flags.is_next_visible and
        (!flags.next_has_column or g.visual_root_depth > 0);
}

fn peekNextVisible(g: *Graph, flags: *LookaheadFlags) void {
    flags.* = .{};
    if (g.lookahead_nr == 0) return;
    const next = g.lookahead[0].?;
    flags.is_next_visible = true;
    flags.next_has_column = findNewColumnByCommit(g, next) >= 0;
    if (!isVisualRootCandidate(next, g)) return;
    if (g.lookahead_nr >= 2) flags.is_next_visual_root = true;
}

fn needsPreRootLine(g: *Graph) bool {
    return g.commit_in_columns and g.is_visual_root and
        g.num_columns > 0 and !g.visual_root_cascade and
        !g.revs.no_graph_indent;
}

/// graph_update
pub fn update(g: *Graph, commit: *cn.Commit) void {
    g.commit = commit;

    g.num_parents = 0;
    var parent = firstInterestingParent(g);
    while (parent) |p| : (parent = nextInterestingParent(g, p)) g.num_parents += 1;

    g.prev_commit_index = g.commit_index;

    updateColumns(g);

    var flags: LookaheadFlags = .{};
    peekNextVisible(g, &flags);

    g.is_visual_root = isVisualRoot(g, &flags);

    if (g.is_visual_root) {
        if (g.visual_root_depth == 0 and flags.is_next_visual_root)
            g.visual_root_cascade = true;
        if (!flags.is_next_visual_root and g.visual_root_depth != 0 and
            g.visual_root_depth % 4 == 0)
            g.visual_root_cascade = false;
        g.visual_root_depth += 1;
    } else {
        g.visual_root_depth = 0;
        g.visual_root_cascade = false;
    }

    g.expansion_row = 0;

    if (g.state != .padding)
        g.state = .skip
    else if (needsPreRootLine(g))
        g.state = .pre_root
    else if (needsPreCommitLine(g))
        g.state = .pre_commit
    else
        g.state = .commit;
}

fn isMappingCorrect(g: *Graph) bool {
    var i: i32 = 0;
    while (i < g.mapping_size) : (i += 1) {
        const target = g.map(i).*;
        if (target < 0) continue;
        if (target == @divTrunc(i, 2)) continue;
        return false;
    }
    return true;
}

fn padHorizontally(g: *Graph, line: *Line) void {
    const w: usize = @intCast(@max(g.width, 0));
    if (line.width < w) line.addchars(' ', w - line.width);
}

fn outputPaddingLine(g: *Graph, line: *Line) void {
    var i: i32 = 0;
    while (i < g.num_new_columns) : (i += 1) {
        if (needsTruncation(g, i)) {
            line.addstr("~ ");
            break;
        }
        line.writeColumn(g.ncol(i), '|');
        line.addch(' ');
    }
}

/// graph_width
pub fn width(g: *Graph) usize {
    return @intCast(@max(g.width, 0));
}

fn outputSkipLine(g: *Graph, line: *Line) void {
    line.addstr("...");
    if (needsPreCommitLine(g))
        updateState(g, .pre_commit)
    else
        updateState(g, .commit);
}

fn outputPreCommitLine(g: *Graph, line: *Line) void {
    std.debug.assert(g.num_parents >= 3);
    var seen_this = false;
    var i: i32 = 0;
    while (i < g.num_columns) : (i += 1) {
        const c = g.col(i);
        if (c.commit == g.commit.?) {
            seen_this = true;
            line.writeColumn(c, '|');
            line.addchars(' ', @intCast(g.expansion_row));
        } else if (seen_this and needsTruncation(g, i)) {
            line.addstr("~ ");
            break;
        } else if (seen_this and g.expansion_row == 0) {
            if (g.prev_state == .post_merge and g.prev_commit_index < i)
                line.writeColumn(c, '\\')
            else
                line.writeColumn(c, '|');
        } else if (seen_this and g.expansion_row > 0) {
            line.writeColumn(c, '\\');
        } else {
            line.writeColumn(c, '|');
        }
        line.addch(' ');
    }

    g.expansion_row += 1;
    if (!needsPreCommitLine(g)) updateState(g, .commit);
}

fn outputCommitChar(g: *Graph, line: *Line) void {
    const commit = g.commit.?;
    if (commit.obj.flags & cn.BOUNDARY != 0) {
        line.addch('o');
        return;
    }
    line.addstr(revision.getRevisionMark(g.revs, commit));
}

fn drawOctopusMerge(g: *Graph, line: *Line) void {
    const dashed_parents = numDashedParents(g);
    var i: i32 = 0;
    while (i < dashed_parents) : (i += 1) {
        const j = g.map((g.commit_index + i + 2) * 2).*;
        const c = g.ncol(j);
        line.writeColumn(c, '-');
        if (needsTruncation(g, g.commit_index + 1 + i)) {
            line.addstr("~ ");
            break;
        }
        line.writeColumn(c, if (i == dashed_parents - 1) '.' else '-');
    }
}

fn outputCommitLine(g: *Graph, line: *Line) void {
    const commit = g.commit.?;
    var seen_this = false;
    var i: i32 = 0;
    while (i <= g.num_columns) : (i += 1) {
        var col_commit: *cn.Commit = undefined;
        if (i == g.num_columns) {
            if (seen_this) break;
            col_commit = commit;
        } else {
            col_commit = g.col(i).commit;
        }

        if (col_commit == commit) {
            seen_this = true;
            if (g.is_visual_root and !g.revs.no_graph_indent) {
                const depth: i64 = g.visual_root_depth;
                const cascade: i64 = if (g.visual_root_cascade) 1 else 0;
                const padding: i32 = @intCast(@rem(depth - cascade, 4) * 2);
                if (padding > 0) line.addchars(' ', @intCast(padding));
                g.width += padding;
            }
            outputCommitChar(g, line);

            if (needsTruncation(g, i)) {
                line.addch(' ');
                break;
            }
            if (g.num_parents > 2) drawOctopusMerge(g, line);
        } else if (needsTruncation(g, i)) {
            line.addstr("~ ");
            seen_this = true;
            break;
        } else if (seen_this and g.edges_added > 1) {
            line.writeColumn(g.col(i), '\\');
        } else if (seen_this and g.edges_added == 1) {
            if (g.prev_state == .post_merge and g.prev_edges_added > 0 and g.prev_commit_index < i)
                line.writeColumn(g.col(i), '\\')
            else
                line.writeColumn(g.col(i), '|');
        } else if (g.prev_state == .collapsing and
            g.omap(2 * i + 1).* == i and
            g.map(2 * i).* < i)
        {
            line.writeColumn(g.col(i), '/');
        } else {
            line.writeColumn(g.col(i), '|');
        }
        line.addch(' ');
    }

    if (g.num_parents > 1) {
        if (!needsTruncation(g, g.commit_index)) {
            updateState(g, .post_merge);
        } else {
            const p = firstInterestingParent(g) orelse
                @panic("BUG: num_parents > 1 but no interesting parent");
            const lane = findNewColumnByCommit(g, p.item);
            if (!needsTruncation(g, lane))
                updateState(g, .post_merge)
            else if (isMappingCorrect(g))
                updateState(g, .padding)
            else
                updateState(g, .collapsing);
        }
    } else if (isMappingCorrect(g)) {
        updateState(g, .padding);
    } else {
        updateState(g, .collapsing);
    }
}

const merge_chars = [_]u8{ '/', '|', '\\' };

fn outputPostMergeLine(g: *Graph, line: *Line) void {
    const commit = g.commit.?;
    var seen_this = false;
    const first_parent = firstInterestingParent(g).?;
    var parent_col: ?*Column = null;

    var i: i32 = 0;
    while (i <= g.num_columns) : (i += 1) {
        var c: ?*Column = null;
        var col_commit: *cn.Commit = undefined;
        if (i == g.num_columns) {
            if (seen_this) break;
            col_commit = commit;
        } else {
            c = g.col(i);
            col_commit = c.?.commit;
        }

        if (col_commit == commit) {
            var parents: ?*cn.CommitList = first_parent;
            var idx: usize = @intCast(g.merge_layout);
            var truncated = false;
            seen_this = true;

            var j: i32 = 0;
            while (j < g.num_parents) : (j += 1) {
                const par_column = findNewColumnByCommit(g, parents.?.item);
                std.debug.assert(par_column >= 0);
                const ch = merge_chars[idx];
                line.writeColumn(g.ncol(par_column), ch);

                if (needsTruncation(g, @divTrunc(j, 2) + i) and
                    @divTrunc(j, 2) + i <= g.num_columns)
                {
                    if (@rem(j + i * 2, 2) != 0) line.addch(' ');
                    line.addstr("~ ");
                    truncated = true;
                    break;
                }

                if (idx == 2) {
                    if (needsTruncation(g, @divTrunc(j + 1, 2) + i) and j < g.num_parents - 1) {
                        line.addstr("~ ");
                        truncated = true;
                        break;
                    } else if (g.edges_added > 0 or j < g.num_parents - 1) {
                        line.addch(' ');
                    }
                } else {
                    idx += 1;
                }
                parents = nextInterestingParent(g, parents.?);
            }
            if (truncated) break;
            if (g.edges_added == 0) line.addch(' ');
        } else if (needsTruncation(g, i)) {
            line.addstr("~ ");
            break;
        } else if (seen_this) {
            if (g.edges_added > 0)
                line.writeColumn(c.?, '\\')
            else
                line.writeColumn(c.?, '|');
            if (!needsTruncation(g, i + 1)) line.addch(' ');
        } else {
            line.writeColumn(c.?, '|');
            if (g.merge_layout != 0 or i != g.commit_index - 1) {
                if (parent_col) |pc|
                    line.writeColumn(pc, '_')
                else
                    line.addch(' ');
            }
        }

        if (col_commit == first_parent.item) parent_col = c;
    }

    if (isMappingCorrect(g))
        updateState(g, .padding)
    else
        updateState(g, .collapsing);
}

fn outputCollapsingLine(g: *Graph, line: *Line) void {
    var used_horizontal = false;
    var horizontal_edge: i32 = -1;
    var horizontal_edge_target: i32 = -1;
    var truncated = false;

    std.mem.swap([]i32, &g.mapping, &g.old_mapping);

    var i: i32 = 0;
    while (i < g.mapping_size) : (i += 1) g.map(i).* = -1;

    i = 0;
    while (i < g.mapping_size) : (i += 1) {
        const target = g.omap(i).*;
        if (target < 0) continue;

        std.debug.assert(target * 2 <= i);

        if (target * 2 == i) {
            g.map(i).* = target;
        } else if (g.map(i - 1).* < 0) {
            g.map(i - 1).* = target;
            if (horizontal_edge == -1) {
                horizontal_edge = i;
                horizontal_edge_target = target;
                var j: i32 = target * 2 + 3;
                while (j < i - 2) : (j += 2) g.map(j).* = target;
            }
        } else if (g.map(i - 1).* == target) {
            // merges with the line to our left
        } else {
            g.map(i - 2).* = target;
            if (horizontal_edge == -1) {
                horizontal_edge_target = target;
                horizontal_edge = i - 1;
                var j: i32 = target * 2 + 3;
                while (j < i - 2) : (j += 2) g.map(j).* = target;
            }
        }
    }

    const ms: usize = @intCast(g.mapping_size);
    @memcpy(g.old_mapping[0..ms], g.mapping[0..ms]);

    if (g.map(g.mapping_size - 1).* < 0) g.mapping_size -= 1;

    i = 0;
    while (i < g.mapping_size) : (i += 1) {
        const target = g.map(i).*;

        if (!truncated and needsTruncation(g, @divTrunc(i, 2))) {
            line.addstr("~ ");
            truncated = true;
        }

        if (target < 0) {
            if (!truncated) line.addch(' ');
        } else if (target * 2 == i) {
            if (!truncated) line.writeColumn(g.ncol(target), '|');
        } else if (target == horizontal_edge_target and i != horizontal_edge - 1) {
            if (i != target * 2 + 3) g.map(i).* = -1;
            used_horizontal = true;
            if (!truncated) line.writeColumn(g.ncol(target), '_');
        } else {
            if (used_horizontal and i < horizontal_edge) g.map(i).* = -1;
            if (!truncated) line.writeColumn(g.ncol(target), '/');
        }
    }

    if (isMappingCorrect(g)) updateState(g, .padding);
}

fn outputPreRootLine(g: *Graph, line: *Line) void {
    if (!g.is_visual_root) @panic("BUG: commit must be a visual root to call pre_root_line");
    var i: i32 = 0;
    while (i < g.num_columns) : (i += 1) {
        const c = g.col(i);
        if (c.commit == g.commit.?) {
            line.addch(' ');
            line.writeColumn(c, '\\');
        } else {
            line.writeColumn(c, '|');
        }
        line.addch(' ');
    }
    updateState(g, .commit);
}

fn nextLineImpl(g: *Graph, sb: *util.Buf) i32 {
    var line: Line = .{ .buf = sb };
    if (g.commit == null) return -1;
    var shown: i32 = 0;
    switch (g.state) {
        .padding => outputPaddingLine(g, &line),
        .skip => outputSkipLine(g, &line),
        .pre_commit => outputPreCommitLine(g, &line),
        .pre_root => outputPreRootLine(g, &line),
        .commit => {
            outputCommitLine(g, &line);
            shown = 1;
        },
        .post_merge => outputPostMergeLine(g, &line),
        .collapsing => outputCollapsingLine(g, &line),
    }
    padHorizontally(g, &line);
    return shown;
}

/// graph_next_line: appends one graph line (no newline) to sb; returns true
/// if it was the commit line.
pub fn nextLine(g: *Graph, sb: *util.Buf) bool {
    return nextLineImpl(g, sb) == 1;
}

fn paddingLine(g: *Graph, sb: *util.Buf) void {
    if (g.state != .commit) {
        _ = nextLineImpl(g, sb);
        return;
    }
    var line: Line = .{ .buf = sb };
    var i: i32 = 0;
    while (i < g.num_columns) : (i += 1) {
        const c = g.col(i);
        if (needsTruncation(g, i)) {
            line.addstr("~ ");
            break;
        }
        line.writeColumn(c, '|');
        if (c.commit == g.commit.? and g.num_parents > 2) {
            line.addchars(' ', @intCast((g.num_parents - 2) * 2));
        } else {
            line.addch(' ');
        }
    }
    padHorizontally(g, &line);
    g.prev_state = .padding;
}

/// diff_output_prefix_callback: line_prefix + a graph padding line. The
/// returned slice is valid until the next call.
pub fn linePrefix(g: ?*Graph) []const u8 {
    const gr = g orelse return line_prefix;
    gr.prefix_buf.clearRetainingCapacity();
    util.bufAppend(&gr.prefix_buf, line_prefix);
    paddingLine(gr, &gr.prefix_buf);
    return gr.prefix_buf.items;
}

/// Append the diff output prefix (as linePrefix) to an arbitrary buffer.
pub fn appendLinePrefix(g: ?*Graph, b: *util.Buf) void {
    util.bufAppend(b, line_prefix);
    if (g) |gr| paddingLine(gr, b);
}

pub fn isCommitFinished(g: *const Graph) bool {
    return g.state == .padding;
}

fn showLinePrefix() void {
    if (line_prefix.len > 0) util.out(line_prefix);
}

/// graph_show_commit
pub fn showCommit(g_opt: ?*Graph) void {
    showLinePrefix();
    const g = g_opt orelse return;
    var buf: util.Buf = .empty;
    defer buf.deinit(gpa);
    var shown = false;

    if (isCommitFinished(g)) {
        showPadding(g);
        shown = true;
    }

    while (!shown and !isCommitFinished(g)) {
        shown = nextLineImpl(g, &buf) == 1;
        util.out(buf.items);
        if (!shown) {
            util.out("\n");
            showLinePrefix();
        }
        buf.clearRetainingCapacity();
    }
}

/// graph_show_oneline
pub fn showOneline(g_opt: ?*Graph) void {
    showLinePrefix();
    const g = g_opt orelse return;
    var buf: util.Buf = .empty;
    defer buf.deinit(gpa);
    _ = nextLineImpl(g, &buf);
    util.out(buf.items);
}

/// graph_show_padding
pub fn showPadding(g_opt: ?*Graph) void {
    showLinePrefix();
    const g = g_opt orelse return;
    var buf: util.Buf = .empty;
    defer buf.deinit(gpa);
    paddingLine(g, &buf);
    util.out(buf.items);
}

/// graph_show_remainder
pub fn showRemainder(g_opt: ?*Graph) bool {
    showLinePrefix();
    const g = g_opt orelse return false;
    if (isCommitFinished(g)) return false;
    var buf: util.Buf = .empty;
    defer buf.deinit(gpa);
    while (true) {
        _ = nextLineImpl(g, &buf);
        util.out(buf.items);
        buf.clearRetainingCapacity();
        if (!isCommitFinished(g)) {
            util.out("\n");
            showLinePrefix();
        } else break;
    }
    return true;
}

fn showStrbuf(g: ?*Graph, sb: []const u8) void {
    var p: usize = 0;
    // C: while (p) - an empty buffer still runs once with len 0.
    while (true) {
        var next: ?usize = null;
        var len: usize = undefined;
        if (std.mem.indexOfScalarPos(u8, sb, p, '\n')) |nl| {
            next = nl + 1;
            len = nl + 1 - p;
        } else {
            len = sb.len - p;
        }
        util.out(sb[p .. p + len]);
        const n = next orelse break;
        if (n < sb.len) showOneline(g);
        p = n;
        if (p >= sb.len) break;
    }
}

/// graph_show_commit_msg
pub fn showCommitMsg(g: ?*Graph, msg: []const u8) void {
    showStrbuf(g, msg);
    const gr = g orelse return;
    const newline_terminated = msg.len > 0 and msg[msg.len - 1] == '\n';
    if (!isCommitFinished(gr)) {
        if (!newline_terminated) util.out("\n");
        _ = showRemainder(gr);
        if (newline_terminated) util.out("\n");
    }
}

/// graph_clear (memory is generally not freed in this port)
pub fn clear(g: ?*Graph) void {
    _ = g;
}
