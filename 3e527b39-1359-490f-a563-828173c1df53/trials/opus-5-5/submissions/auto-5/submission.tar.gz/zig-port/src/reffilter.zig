//! Port of ref-filter.c (formatting/filtering of refs) and for-each-ref.

const std = @import("std");
const util = @import("util.zig");

pub fn forEachRefMain(args: []const []const u8, is_refs_list: bool) u8 {
    _ = args;
    _ = is_refs_list;
    util.die("for-each-ref: not implemented", .{});
}
