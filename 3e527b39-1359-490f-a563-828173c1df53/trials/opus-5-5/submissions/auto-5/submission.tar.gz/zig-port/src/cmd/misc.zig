//! Small commands: version, help.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const main = @import("../main.zig");
const commands = @import("../commands.zig");

pub fn cmdVersion(args: []const []const u8) u8 {
    var build_options = false;
    const opts = [_]po.Opt{po.boolean(0, "build-options", &build_options, "also print build options")};
    _ = po.parse(args[1..], &opts, &.{"git version [--build-options]"}, .{});
    util.outf("git version {s}\n", .{main.version});
    if (build_options) {
        util.out("cpu: x86_64\nbuilt from commit: (none)\nsizeof-long: 8\nsizeof-size_t: 8\nshell-path: /bin/sh\nzlib: 1.3.1\nSHA-1: SHA1_DC\nSHA-256: SHA256_BLK\ndefault-ref-format: files\ndefault-hash: sha1\n");
    }
    return 0;
}

pub fn cmdHelp(args: []const []const u8) u8 {
    if (args.len < 2) {
        util.out(
            \\usage: git [-v | --version] [-h | --help] [-C <path>] [-c <name>=<value>]
            \\           [--exec-path[=<path>]] [--html-path] [--man-path] [--info-path]
            \\           [-p | --paginate | -P | --no-pager] [--no-replace-objects] [--no-lazy-fetch]
            \\           [--no-optional-locks] [--no-advice] [--bare] [--git-dir=<path>]
            \\           [--work-tree=<path>] [--namespace=<name>] [--config-env=<name>=<envvar>]
            \\           <command> [<args>]
            \\
            \\
        );
        return 0;
    }
    var i: usize = 1;
    while (i < args.len and args[i].len > 0 and args[i][0] == '-') : (i += 1) {
        if (util.eql(args[i], "-a") or util.eql(args[i], "--all")) {
            commands.listCommands();
            return 0;
        }
    }
    if (i >= args.len) return 0;
    const name = args[i];
    if (commands.find(name) == null) {
        util.eprint("git: '{s}' is not a git command. See 'git --help'.\n", .{name});
        return 1;
    }
    util.die("no man viewer handled the request", .{});
}
