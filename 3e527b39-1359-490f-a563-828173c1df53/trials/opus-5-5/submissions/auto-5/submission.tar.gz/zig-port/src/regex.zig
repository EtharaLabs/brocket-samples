//! POSIX regex via libc.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");

pub const RegexT = extern struct { data: [64]u8 align(8) };
pub const Match = extern struct { so: c_int, eo: c_int };

extern "c" fn regcomp(preg: *RegexT, pattern: [*:0]const u8, cflags: c_int) c_int;
extern "c" fn regexec(preg: *const RegexT, string: [*:0]const u8, nmatch: usize, pmatch: ?[*]Match, eflags: c_int) c_int;
extern "c" fn regerror(errcode: c_int, preg: *const RegexT, errbuf: [*]u8, size: usize) usize;

pub const REG_EXTENDED = 1;
pub const REG_ICASE = 2;
pub const REG_NEWLINE = 4;
pub const REG_NOSUB = 8;
pub const REG_NOTBOL = 1;
pub const REG_STARTEND = 4;

pub const Opts = struct {
    extended: bool = false,
    icase: bool = false,
    newline: bool = false,
};

pub const Regex = struct {
    re: *RegexT,

    pub fn compile(pattern: []const u8, opts: Opts) union(enum) { ok: Regex, err: []const u8 } {
        const re = util.gpa.create(RegexT) catch util.oom();
        var flags: c_int = 0;
        if (opts.extended) flags |= REG_EXTENDED;
        if (opts.icase) flags |= REG_ICASE;
        if (opts.newline) flags |= REG_NEWLINE;
        const r = regcomp(re, os.z(pattern), flags);
        if (r != 0) {
            var buf: [256]u8 = undefined;
            const n = regerror(r, re, &buf, buf.len);
            return .{ .err = util.dupe(buf[0 .. if (n > 0) n - 1 else 0]) };
        }
        return .{ .ok = .{ .re = re } };
    }

    pub fn isMatch(self: Regex, s: []const u8) bool {
        return regexec(self.re, os.z(s), 0, null, 0) == 0;
    }

    /// Find first match in s, starting at offset. Uses REG_STARTEND so NULs/anchors work.
    pub fn find(self: Regex, s: []const u8, notbol: bool) ?Match {
        var m: [1]Match = .{.{ .so = 0, .eo = @intCast(s.len) }};
        const zs = os.z(s);
        var flags: c_int = REG_STARTEND;
        if (notbol) flags |= REG_NOTBOL;
        if (regexec(self.re, zs, 1, &m, flags) != 0) return null;
        return m[0];
    }

    pub fn findGroups(self: Regex, s: []const u8, groups: []Match) bool {
        groups[0] = .{ .so = 0, .eo = @intCast(s.len) };
        return regexec(self.re, os.z(s), groups.len, groups.ptr, REG_STARTEND) == 0;
    }
};

pub fn matchSimple(pattern: []const u8, s: []const u8, opts: Opts) bool {
    switch (Regex.compile(pattern, opts)) {
        .ok => |re| return re.isMatch(s),
        .err => |e| util.die("invalid regex '{s}': {s}", .{ pattern, e }),
    }
}
