//! Git configuration: parsing, lookup and file editing.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const gpa = util.gpa;

pub const Scope = enum {
    system,
    global,
    local,
    worktree,
    command,
    unknown,
    pub fn name(self: Scope) []const u8 {
        return switch (self) {
            .system => "system",
            .global => "global",
            .local => "local",
            .worktree => "worktree",
            .command => "command",
            .unknown => "unknown",
        };
    }
};

pub const OriginType = enum { file, cmdline, stdin, blob };

pub const Entry = struct {
    key: []const u8,
    value: ?[]const u8,
    origin: []const u8, // file name, or "" for command line
    origin_type: OriginType,
    scope: Scope,
    line: u32,
};

/// An event from parsing a file, used for editing.
pub const Event = struct {
    kind: enum { section, entry, comment, whitespace },
    start: usize,
    end: usize, // exclusive, includes trailing newline
    section: []const u8 = "", // canonical "section" or "section.subsection" (for section and entry)
    key: []const u8 = "", // full canonical key (entry)
    value: ?[]const u8 = null,
};

pub const ParseError = error{BadConfig};

pub fn isKeyChar(ch: u8) bool {
    return std.ascii.isAlphanumeric(ch) or ch == '-';
}

const Parser = struct {
    data: []const u8,
    pos: usize = 0,
    line: u32 = 1,
    eof: bool = false,

    fn next(self: *Parser) u8 {
        if (self.pos >= self.data.len) {
            if (!self.eof) {
                self.eof = true;
                self.line += 1;
            }
            return '\n';
        }
        var c = self.data[self.pos];
        self.pos += 1;
        if (c == '\r') {
            if (self.pos < self.data.len and self.data[self.pos] == '\n') {
                c = '\n';
                self.pos += 1;
            }
        }
        if (c == '\n') self.line += 1;
        return c;
    }
};

pub const ParseResult = struct {
    events: []Event,
    err_line: ?u32 = null,
};

/// Parse config text. Calls `cb` for each key/value. Returns events for editing.
pub fn parseText(data: []const u8, ctx: anytype, cb: fn (@TypeOf(ctx), []const u8, ?[]const u8, u32) void) ParseResult {
    var events: std.ArrayList(Event) = .empty;
    var p = Parser{ .data = data };
    var section: util.Buf = .empty;
    var comment = false;
    var ev_start: usize = 0;
    // skip BOM
    if (std.mem.startsWith(u8, data, "\xef\xbb\xbf")) p.pos = 3;
    while (true) {
        const start = p.pos;
        const c = p.next();
        if (c == '\n') {
            if (p.eof) {
                return .{ .events = events.items };
            }
            if (comment) {
                events.append(gpa, .{ .kind = .comment, .start = ev_start, .end = p.pos }) catch util.oom();
            } else {
                events.append(gpa, .{ .kind = .whitespace, .start = start, .end = p.pos }) catch util.oom();
            }
            comment = false;
            continue;
        }
        if (comment) continue;
        if (std.ascii.isWhitespace(c)) continue;
        if (c == '#' or c == ';') {
            comment = true;
            ev_start = start;
            continue;
        }
        if (c == '[') {
            section.clearRetainingCapacity();
            // base var
            var ok = false;
            while (true) {
                const ch = p.next();
                if (p.eof) break;
                if (ch == ']') {
                    ok = true;
                    break;
                }
                if (std.ascii.isWhitespace(ch)) {
                    // extended
                    var ch2 = ch;
                    while (std.ascii.isWhitespace(ch2)) {
                        if (ch2 == '\n') break;
                        ch2 = p.next();
                    }
                    if (ch2 != '"') break;
                    util.bufByte(&section, '.');
                    var good = true;
                    while (true) {
                        var ch3 = p.next();
                        if (ch3 == '\n') {
                            good = false;
                            break;
                        }
                        if (ch3 == '"') break;
                        if (ch3 == '\\') {
                            ch3 = p.next();
                            if (ch3 == '\n') {
                                good = false;
                                break;
                            }
                        }
                        util.bufByte(&section, ch3);
                    }
                    if (!good) break;
                    if (p.next() != ']') break;
                    ok = true;
                    break;
                }
                if (!isKeyChar(ch) and ch != '.') break;
                util.bufByte(&section, std.ascii.toLower(ch));
            }
            if (!ok or section.items.len == 0) return .{ .events = events.items, .err_line = p.line };
            events.append(gpa, .{ .kind = .section, .start = start, .end = p.pos, .section = util.dupe(section.items) }) catch util.oom();
            continue;
        }
        if (!std.ascii.isAlphabetic(c)) return .{ .events = events.items, .err_line = p.line };
        // entry
        var name: util.Buf = .empty;
        util.bufAppend(&name, section.items);
        util.bufByte(&name, '.');
        util.bufByte(&name, std.ascii.toLower(c));
        var ch = p.next();
        while (!p.eof and isKeyChar(ch)) {
            util.bufByte(&name, std.ascii.toLower(ch));
            ch = p.next();
        }
        while (ch == ' ' or ch == '\t') ch = p.next();
        var value: ?[]const u8 = null;
        if (ch != '\n') {
            if (ch != '=') return .{ .events = events.items, .err_line = p.line };
            value = parseValue(&p) orelse return .{ .events = events.items, .err_line = p.line };
        }
        const line = if (p.eof) p.line - 1 else p.line - 1;
        if (section.items.len == 0) return .{ .events = events.items, .err_line = line };
        events.append(gpa, .{ .kind = .entry, .start = start, .end = p.pos, .section = util.dupe(section.items), .key = name.items, .value = value }) catch util.oom();
        cb(ctx, name.items, value, line);
    }
}

fn parseValue(p: *Parser) ?[]const u8 {
    var quote = false;
    var comment = false;
    var trim_len: usize = 0;
    var v: util.Buf = .empty;
    while (true) {
        var c = p.next();
        if (c == '\n') {
            if (quote) return null;
            if (trim_len != 0) v.shrinkRetainingCapacity(trim_len);
            return v.items;
        }
        if (comment) continue;
        if (std.ascii.isWhitespace(c) and !quote) {
            if (trim_len == 0) trim_len = v.items.len;
            if (v.items.len != 0) util.bufByte(&v, c);
            continue;
        }
        if (!quote and (c == ';' or c == '#')) {
            comment = true;
            continue;
        }
        trim_len = 0;
        if (c == '\\') {
            c = p.next();
            switch (c) {
                '\n' => continue,
                't' => c = '\t',
                'b' => c = 8,
                'n' => c = '\n',
                '\\', '"' => {},
                else => return null,
            }
            util.bufByte(&v, c);
            continue;
        }
        if (c == '"') {
            quote = !quote;
            continue;
        }
        util.bufByte(&v, c);
    }
}

// ---------------- the config set ----------------

pub const Config = struct {
    entries: std.ArrayList(Entry) = .empty,
    git_dir: ?[]const u8 = null,
    current_branch: ?[]const u8 = null,

    pub fn add(self: *Config, e: Entry) void {
        self.entries.append(gpa, e) catch util.oom();
    }

    pub fn get(self: *const Config, key: []const u8) ?[]const u8 {
        const k = canonicalKey(key) orelse return null;
        var i = self.entries.items.len;
        while (i > 0) {
            i -= 1;
            const e = self.entries.items[i];
            if (util.eql(e.key, k)) return e.value orelse "";
        }
        return null;
    }

    /// Returns the entry (to distinguish "no value" from "").
    pub fn getEntry(self: *const Config, key: []const u8) ?Entry {
        const k = canonicalKey(key) orelse return null;
        var i = self.entries.items.len;
        while (i > 0) {
            i -= 1;
            const e = self.entries.items[i];
            if (util.eql(e.key, k)) return e;
        }
        return null;
    }

    pub fn getAll(self: *const Config, key: []const u8) [][]const u8 {
        var l: std.ArrayList([]const u8) = .empty;
        const k = canonicalKey(key) orelse return l.items;
        for (self.entries.items) |e| {
            if (util.eql(e.key, k)) l.append(gpa, e.value orelse "") catch util.oom();
        }
        return l.items;
    }

    pub fn getBool(self: *const Config, key: []const u8) ?bool {
        const e = self.getEntry(key) orelse return null;
        const v = e.value orelse return true;
        return parseBool(v) orelse util.die("bad boolean config value '{s}' for '{s}'", .{ v, key });
    }

    pub fn getBoolDefault(self: *const Config, key: []const u8, def: bool) bool {
        return self.getBool(key) orelse def;
    }

    pub fn getInt(self: *const Config, key: []const u8) ?i64 {
        const v = self.get(key) orelse return null;
        return parseInt(v) orelse util.die("bad numeric config value '{s}' for '{s}': invalid unit", .{ v, key });
    }

    pub fn includeFile(self: *Config, ctx: *LoadCtx, path: []const u8) void {
        includeFileImpl(self, ctx, path);
    }
    pub fn includeCondition(self: *Config, ctx: *LoadCtx, cond: []const u8) bool {
        return includeConditionImpl(self, ctx, cond);
    }

    pub fn getPath(self: *const Config, key: []const u8) ?[]const u8 {
        const v = self.get(key) orelse return null;
        return expandPath(v);
    }
};

pub fn expandPath(v: []const u8) []const u8 {
    if (util.startsWith(v, "~/")) {
        const home = os.getenv("HOME") orelse return v;
        return util.concat(&.{ home, v[1..] });
    }
    return v;
}

pub fn parseBool(v: []const u8) ?bool {
    if (v.len == 0) return false;
    if (std.ascii.eqlIgnoreCase(v, "true") or std.ascii.eqlIgnoreCase(v, "yes") or std.ascii.eqlIgnoreCase(v, "on")) return true;
    if (std.ascii.eqlIgnoreCase(v, "false") or std.ascii.eqlIgnoreCase(v, "no") or std.ascii.eqlIgnoreCase(v, "off")) return false;
    const n = parseInt(v) orelse return null;
    return n != 0;
}

pub fn parseInt(v0: []const u8) ?i64 {
    const v = v0;
    if (v.len == 0) return null;
    var mult: i64 = 1;
    var num = v;
    const last = std.ascii.toLower(v[v.len - 1]);
    if (last == 'k') {
        mult = 1024;
        num = v[0 .. v.len - 1];
    } else if (last == 'm') {
        mult = 1024 * 1024;
        num = v[0 .. v.len - 1];
    } else if (last == 'g') {
        mult = 1024 * 1024 * 1024;
        num = v[0 .. v.len - 1];
    }
    const n = std.fmt.parseInt(i64, num, 0) catch return null;
    return std.math.mul(i64, n, mult) catch null;
}

/// Canonicalize a key: lowercase section and name; keep subsection.
pub fn canonicalKey(key: []const u8) ?[]const u8 {
    const first = std.mem.indexOfScalar(u8, key, '.') orelse return null;
    const last = std.mem.lastIndexOfScalar(u8, key, '.').?;
    const r = util.dupe(key);
    for (r[0..first]) |*ch| ch.* = std.ascii.toLower(ch.*);
    for (r[last + 1 ..]) |*ch| ch.* = std.ascii.toLower(ch.*);
    return r;
}

/// Validate key per git_config_parse_key. Returns canonical or error message.
pub fn parseKey(key: []const u8) union(enum) { ok: []const u8, err: []const u8 } {
    const last = std.mem.lastIndexOfScalar(u8, key, '.') orelse return .{ .err = util.fmt("key does not contain a section: {s}", .{key}) };
    if (last == 0) return .{ .err = util.fmt("key does not contain a section: {s}", .{key}) };
    if (last == key.len - 1) return .{ .err = util.fmt("key does not contain variable name: {s}", .{key}) };
    const first = std.mem.indexOfScalar(u8, key, '.').?;
    for (key[0..first]) |ch| {
        if (!isKeyChar(ch)) return .{ .err = util.fmt("invalid key: {s}", .{key}) };
    }
    const name = key[last + 1 ..];
    if (!std.ascii.isAlphabetic(name[0])) return .{ .err = util.fmt("invalid key: {s}", .{key}) };
    for (name) |ch| {
        if (!isKeyChar(ch)) return .{ .err = util.fmt("invalid key: {s}", .{key}) };
    }
    for (key[first..last]) |ch| {
        if (ch == '\n') return .{ .err = util.fmt("invalid key (newline): {s}", .{key}) };
    }
    return .{ .ok = canonicalKey(key).? };
}

pub const LoadCtx = struct {
    cfg: *Config,
    file: []const u8,
    origin_type: OriginType,
    scope: Scope,
    depth: u32,
};

fn loadCb(ctx: *LoadCtx, key: []const u8, value: ?[]const u8, line: u32) void {
    ctx.cfg.add(.{ .key = util.dupe(key), .value = if (value) |v| util.dupe(v) else null, .origin = ctx.file, .origin_type = ctx.origin_type, .scope = ctx.scope, .line = line });
    // includes
    if (util.eql(key, "include.path")) {
        if (value) |v| ctx.cfg.includeFile(ctx, v);
    } else if (util.startsWith(key, "includeif.") and util.endsWith(key, ".path")) {
        const cond = key["includeif.".len .. key.len - ".path".len];
        if (value) |v| {
            if (ctx.cfg.includeCondition(ctx, cond)) ctx.cfg.includeFile(ctx, v);
        }
    }
}

fn globMatch(pat: []const u8, s: []const u8, icase: bool) bool {
    const wildmatch = @import("wildmatch.zig");
    return wildmatch.match(pat, s, if (icase) wildmatch.CASEFOLD | wildmatch.PATHNAME else wildmatch.PATHNAME);
}

fn includeConditionImpl(cfg: *Config, ctx: *LoadCtx, cond: []const u8) bool {
    if (util.skipPrefix(cond, "gitdir:") orelse util.skipPrefix(cond, "gitdir/i:")) |pat0| {
        const icase = util.startsWith(cond, "gitdir/i:");
        const gd = cfg.git_dir orelse return false;
        var pat: []const u8 = expandPath(pat0);
        if (util.startsWith(pat, "./")) {
            if (ctx.origin_type != .file) return false;
            pat = util.joinPath(util.dirname(ctx.file), pat[2..]);
        } else if (pat.len > 0 and pat[0] != '/') {
            pat = util.concat(&.{ "**/", pat });
        }
        if (util.endsWith(pat, "/")) pat = util.concat(&.{ pat, "**" });
        const real = os.realPath(gd) orelse gd;
        return globMatch(pat, real, icase) or globMatch(pat, gd, icase);
    }
    if (util.skipPrefix(cond, "onbranch:")) |pat0| {
        const br = cfg.current_branch orelse return false;
        var pat: []const u8 = pat0;
        if (util.endsWith(pat, "/")) pat = util.concat(&.{ pat, "**" });
        return globMatch(pat, br, false);
    }
    return false;
}

pub fn readFileInto(cfg: *Config, path: []const u8, scope: Scope) bool {
    const data = os.readFile(path) orelse return false;
    var ctx = LoadCtx{ .cfg = cfg, .file = path, .origin_type = .file, .scope = scope, .depth = 0 };
    const r = parseText(data, &ctx, loadCb);
    if (r.err_line) |l| util.die("bad config line {d} in file {s}", .{ l, path });
    return true;
}

pub fn includeFileImpl(cfg: *Config, ctx: *LoadCtx, path0: []const u8) void {
    if (ctx.depth >= 10) util.die("exceeded maximum include depth (10) while including\n\t{s}\nfrom\n\t{s}\nThis might be due to circular includes.", .{ path0, ctx.file });
    var path: []const u8 = expandPath(path0);
    if (path.len > 0 and path[0] != '/') {
        if (ctx.origin_type != .file) util.die("relative config includes must come from files", .{});
        path = util.joinPath(util.dirname(ctx.file), path);
    }
    const data = os.readFile(path) orelse return;
    var sub = LoadCtx{ .cfg = cfg, .file = path, .origin_type = .file, .scope = ctx.scope, .depth = ctx.depth + 1 };
    const r = parseText(data, &sub, loadCb);
    if (r.err_line) |l| util.die("bad config line {d} in file {s}", .{ l, path });
}

pub fn addCmdline(cfg: *Config, kv: []const u8) void {
    // "key=value" or "key"
    if (std.mem.indexOfScalar(u8, kv, '=')) |eq| {
        const k = canonicalKey(kv[0..eq]) orelse util.die("bogus config parameter: {s}", .{kv});
        cfg.add(.{ .key = k, .value = kv[eq + 1 ..], .origin = "", .origin_type = .cmdline, .scope = .command, .line = 0 });
    } else {
        const k = canonicalKey(kv) orelse util.die("bogus config parameter: {s}", .{kv});
        cfg.add(.{ .key = k, .value = null, .origin = "", .origin_type = .cmdline, .scope = .command, .line = 0 });
    }
}

/// Parse GIT_CONFIG_PARAMETERS ('key=value' 'key2=value2' or 'key'='value')
pub fn parseConfigParameters(cfg: *Config, env: []const u8) void {
    var i: usize = 0;
    while (i < env.len) {
        while (i < env.len and std.ascii.isWhitespace(env[i])) i += 1;
        if (i >= env.len) break;
        // parse one sq-quoted word, possibly followed by = and another
        const w1 = sqDequoteWord(env, &i) orelse return;
        if (i < env.len and env[i] == '=') {
            i += 1;
            const w2 = sqDequoteWord(env, &i) orelse return;
            const k = canonicalKey(w1) orelse continue;
            cfg.add(.{ .key = k, .value = w2, .origin = "", .origin_type = .cmdline, .scope = .command, .line = 0 });
        } else {
            addCmdline(cfg, w1);
        }
    }
}

fn sqDequoteWord(s: []const u8, i: *usize) ?[]u8 {
    var b: util.Buf = .empty;
    if (i.* >= s.len or s[i.*] != '\'') return null;
    while (i.* < s.len) {
        if (s[i.*] == '\'') {
            i.* += 1;
            while (i.* < s.len and s[i.*] != '\'') : (i.* += 1) util.bufByte(&b, s[i.*]);
            if (i.* >= s.len) return null;
            i.* += 1;
            if (i.* < s.len and s[i.*] == '\\' and i.* + 1 < s.len) {
                util.bufByte(&b, s[i.* + 1]);
                i.* += 2;
                continue;
            }
            if (i.* < s.len and s[i.*] == '\'') continue;
            break;
        } else break;
    }
    return b.items;
}

// ---------------- editing ----------------

fn needsQuoting(v: []const u8) bool {
    if (v.len == 0) return false;
    if (v[0] == ' ' or v[v.len - 1] == ' ' or v[0] == '\t' or v[v.len - 1] == '\t') return true;
    for (v) |ch| {
        if (ch == ';' or ch == '#') return true;
    }
    return false;
}

pub fn formatValue(v: []const u8) []const u8 {
    var b: util.Buf = .empty;
    const q = needsQuoting(v);
    if (q) util.bufByte(&b, '"');
    for (v) |ch| {
        switch (ch) {
            '\n' => util.bufAppend(&b, "\\n"),
            '\t' => util.bufAppend(&b, "\\t"),
            '"' => util.bufAppend(&b, "\\\""),
            '\\' => util.bufAppend(&b, "\\\\"),
            else => util.bufByte(&b, ch),
        }
    }
    if (q) util.bufByte(&b, '"');
    return b.items;
}

/// key is canonical "section.sub.name". Returns the section header line for it.
fn sectionHeader(key: []const u8) []const u8 {
    const first = std.mem.indexOfScalar(u8, key, '.').?;
    const last = std.mem.lastIndexOfScalar(u8, key, '.').?;
    if (first == last) return util.fmt("[{s}]\n", .{key[0..first]});
    var b: util.Buf = .empty;
    util.bufByte(&b, '[');
    util.bufAppend(&b, key[0..first]);
    util.bufAppend(&b, " \"");
    for (key[first + 1 .. last]) |ch| {
        if (ch == '"' or ch == '\\') util.bufByte(&b, '\\');
        util.bufByte(&b, ch);
    }
    util.bufAppend(&b, "\"]\n");
    return b.items;
}

fn keyName(key: []const u8) []const u8 {
    return key[std.mem.lastIndexOfScalar(u8, key, '.').? + 1 ..];
}
fn keySection(key: []const u8) []const u8 {
    return key[0..std.mem.lastIndexOfScalar(u8, key, '.').?];
}

fn noopCb(_: void, _: []const u8, _: ?[]const u8, _: u32) void {}

pub const ValueMatcher = struct {
    regex: ?[]const u8 = null,
    fixed: bool = false,
    negate: bool = false,

    pub fn matches(self: ValueMatcher, v: ?[]const u8) bool {
        const pat = self.regex orelse return true;
        const val = v orelse "";
        var r: bool = undefined;
        if (self.fixed) {
            r = util.eql(pat, val);
        } else {
            const regex = @import("regex.zig");
            r = regex.matchSimple(pat, val, .{ .extended = true });
        }
        return if (self.negate) !r else r;
    }
};

pub const SetResult = enum { ok, multiple, invalid_file, lock_failed, nothing };

fn lockAndWrite(path: []const u8, content: []const u8) SetResult {
    const lock = util.concat(&.{ path, ".lock" });
    const fd = os.openFile(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666);
    if (fd < 0) {
        util.err("could not lock config file {s}: {s}", .{ path, os.lastErr() });
        return .lock_failed;
    }
    os.writeAll(fd, content) catch {};
    os.close(fd);
    // preserve mode of existing file
    if (os.statPath(path)) |st| _ = os.chmod(lock, st.mode & 0o7777);
    if (!os.rename(lock, path)) {
        _ = os.unlink(lock);
        return .lock_failed;
    }
    return .ok;
}

/// Set (or unset when value == null) key in file. If `all`, replace/remove all matching.
/// `append` adds a new entry without touching existing ones (--add).
pub fn setInFile(path: []const u8, key: []const u8, value: ?[]const u8, matcher: ValueMatcher, all: bool, append_: bool, comment: ?[]const u8) SetResult {
    const data = os.readFile(path) orelse "";
    const pr = parseText(data, {}, noopCb);
    if (pr.err_line) |l| {
        util.err("invalid config file {s}", .{path});
        _ = l;
        return .invalid_file;
    }
    const events = pr.events;
    const section = keySection(key);
    // find matching entries
    var matches: std.ArrayList(usize) = .empty;
    if (!append_) {
        for (events, 0..) |e, i| {
            if (e.kind == .entry and util.eql(e.key, key) and matcher.matches(e.value)) matches.append(gpa, i) catch util.oom();
        }
    }
    if (matches.items.len > 1 and !all and value != null) {
        return .multiple;
    }
    if (value == null and matches.items.len == 0) return .nothing;

    const line = blk: {
        if (value) |v| {
            var b: util.Buf = .empty;
            util.bufPrint(&b, "\t{s} = {s}", .{ keyName(key), formatValue(v) });
            if (comment) |cm| {
                util.bufByte(&b, ' ');
                util.bufAppend(&b, cm);
            }
            util.bufByte(&b, '\n');
            break :blk b.items;
        }
        break :blk "";
    };
    var out: util.Buf = .empty;
    if (matches.items.len > 0) {
        var pos: usize = 0;
        for (matches.items, 0..) |mi, n| {
            const e = events[mi];
            util.bufAppend(&out, data[pos..e.start]);
            // keep leading whitespace on the line? git replaces from the entry start
            if (value != null and (n == matches.items.len - 1 or all and n == 0)) {
                if (n == 0 or !all) util.bufAppend(&out, line);
            }
            pos = e.end;
            // if the entry was not newline-terminated, keep the structure sane
        }
        util.bufAppend(&out, data[pos..]);
        var result: []const u8 = out.items;
        if (value == null) result = removeEmptySections(result);
        return lockAndWrite(path, result);
    }
    // insert new: find last entry/section of matching section
    var insert_at: ?usize = null;
    var in_sec = false;
    for (events) |e| {
        switch (e.kind) {
            .section => {
                in_sec = util.eql(e.section, section);
                if (in_sec) insert_at = e.end;
            },
            .entry => {
                if (util.eql(e.section, section)) {
                    insert_at = e.end;
                }
            },
            else => {},
        }
    }
    if (insert_at) |at| {
        util.bufAppend(&out, data[0..at]);
        if (at > 0 and data[at - 1] != '\n') util.bufByte(&out, '\n');
        util.bufAppend(&out, line);
        util.bufAppend(&out, data[at..]);
    } else {
        util.bufAppend(&out, data);
        if (data.len > 0 and data[data.len - 1] != '\n') util.bufByte(&out, '\n');
        util.bufAppend(&out, sectionHeader(key));
        util.bufAppend(&out, line);
    }
    return lockAndWrite(path, out.items);
}

/// Remove section headers that have no entries and no comments following them.
fn removeEmptySections(data: []const u8) []const u8 {
    const pr = parseText(data, {}, noopCb);
    if (pr.err_line != null) return data;
    const events = pr.events;
    var out: util.Buf = .empty;
    var pos: usize = 0;
    var i: usize = 0;
    while (i < events.len) : (i += 1) {
        const e = events[i];
        if (e.kind != .section) continue;
        // check what follows until next section
        var j = i + 1;
        var empty = true;
        while (j < events.len and events[j].kind != .section) : (j += 1) {
            if (events[j].kind == .entry or events[j].kind == .comment) {
                empty = false;
                break;
            }
        }
        // also: a section header line that contains an entry on the same line
        if (empty) {
            // the header must end at a newline for clean removal
            var end = e.end;
            // skip rest of header line (whitespace)
            while (end < data.len and (data[end] == ' ' or data[end] == '\t')) end += 1;
            if (end < data.len and data[end] == '\n') end += 1;
            // check rest of header line had no entry
            if (j < events.len and events[j].kind == .section) {} else {}
            util.bufAppend(&out, data[pos..e.start]);
            pos = end;
            // skip whitespace events directly following
        }
    }
    util.bufAppend(&out, data[pos..]);
    return out.items;
}

/// Rename or remove a section. new_name null => remove.
pub fn renameSection(path: []const u8, old: []const u8, new: ?[]const u8) i32 {
    const data = os.readFile(path) orelse return 0;
    const pr = parseText(data, {}, noopCb);
    if (pr.err_line != null) return -1;
    const old_c = canonicalSection(old);
    var out: util.Buf = .empty;
    var pos: usize = 0;
    var count: i32 = 0;
    var removing = false;
    for (pr.events) |e| {
        if (e.kind == .section) {
            if (util.eql(e.section, old_c)) {
                count += 1;
                util.bufAppend(&out, data[pos..e.start]);
                if (new) |n| {
                    const hdr = sectionHeader(util.concat(&.{ canonicalSection(n), ".x" }));
                    util.bufAppend(&out, hdr[0 .. hdr.len - 1]);
                    pos = e.end;
                    removing = false;
                } else {
                    pos = e.end;
                    removing = true;
                }
                continue;
            }
            removing = false;
            continue;
        }
        if (removing) {
            util.bufAppend(&out, data[pos..e.start]);
            pos = e.end;
        }
    }
    util.bufAppend(&out, data[pos..]);
    if (count == 0) return 0;
    if (lockAndWrite(path, out.items) != .ok) return -1;
    return count;
}

pub fn canonicalSection(s: []const u8) []const u8 {
    const first = std.mem.indexOfScalar(u8, s, '.') orelse return util.lower(s);
    const r = util.dupe(s);
    for (r[0..first]) |*ch| ch.* = std.ascii.toLower(ch.*);
    return r;
}
