//! Port of wt-status.c (status machinery). STUB - being filled in.

const std = @import("std");
const util = @import("util.zig");
const repo_mod = @import("repo.zig");
const pathspec_mod = @import("pathspec.zig");
const hash = @import("hash.zig");
const gpa = util.gpa;

pub const Format = enum { unspecified, none, long, short, porcelain, porcelain_v2 };
pub const Whence = enum { commit, merge, cherry_pick_single, cherry_pick_multi, rebase_pick };
pub const UntrackedMode = enum { err, no, normal, all };
pub const IgnoredMode = enum { no, traditional, matching };
pub const AheadBehind = enum { unspecified, quick, full };

pub const Status = struct {
    is_initial: bool = false,
    branch: ?[]const u8 = null,
    reference: []const u8 = "HEAD",
    pathspec: pathspec_mod.Pathspec = .{},
    verbose: i32 = 0,
    amend: bool = false,
    whence: Whence = .commit,
    nowarn: bool = false,
    use_color: bool = false,
    no_gettext: bool = false,
    display_comment_prefix: bool = false,
    relative_paths: bool = true,
    submodule_summary: i32 = 0,
    show_ignored_mode: IgnoredMode = .no,
    show_untracked_files: UntrackedMode = .normal,
    ignore_submodule_arg: ?[]const u8 = null,
    null_termination: bool = false,
    commit_template: bool = false,
    show_branch: i32 = -1,
    show_stash: bool = false,
    hints: bool = true,
    ahead_behind_flags: AheadBehind = .unspecified,
    detect_rename: i32 = -1,
    rename_score: i32 = -1,
    rename_limit: i32 = -1,
    status_format: Format = .unspecified,
    added_cut_line: bool = false,
    oid_commit: hash.Oid = hash.zero,
    committable: bool = false,
    workdir_dirty: bool = false,
    index_file: []const u8 = "",
    out: *util.Out = &util.stdout,
    prefix: ?[]const u8 = null,
};

pub fn prepare() Status {
    return .{};
}
pub fn collect(s: *Status) void {
    _ = s;
}
pub fn print(s: *Status) void {
    _ = s;
}
pub fn printfLn(s: *Status, color: []const u8, comptime f: []const u8, args: anytype) void {
    _ = color;
    s.out.print(f ++ "\n", args);
}
pub fn printf(s: *Status, color: []const u8, comptime f: []const u8, args: anytype) void {
    _ = color;
    s.out.print(f, args);
}
pub fn addCutLine(s: *Status) void {
    _ = s;
}
pub fn locateEnd(buf: []const u8) usize {
    return buf.len;
}
pub fn appendCutLine(b: *util.Buf) void {
    _ = b;
}
pub fn determineWhence() Whence {
    return .commit;
}
pub fn commentStr() []const u8 {
    return repo_mod.cfg.get("core.commentstring") orelse repo_mod.cfg.get("core.commentchar") orelse "#";
}
