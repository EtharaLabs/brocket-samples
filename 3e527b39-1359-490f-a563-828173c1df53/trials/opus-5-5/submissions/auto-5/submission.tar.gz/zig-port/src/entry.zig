//! Port of entry.c (checkout_entry, unlink_entry) and the bits of symlinks.c
//! (check_leading_path, has_dirs_only_path, scheduled directory removal) it needs.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const convert = @import("convert.zig");
const gpa = util.gpa;

const Entry = index_mod.Entry;
const Index = index_mod.Index;

pub const State = struct {
    base_dir: []const u8 = "",
    force: bool = false,
    quiet: bool = false,
    not_new: bool = false,
    refresh_cache: bool = false,
    clone: bool = false,
    istate: ?*Index = null,
};

// ---------------- symlinks.c helpers ----------------

/// check_leading_path(): 0 if a leading component is missing, -1 if all
/// leading components are directories, else the length of the first leading
/// component that exists but is not a directory (or failed to lstat).
pub fn checkLeadingPath(name: []const u8, warn_on_err: bool) isize {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, name, i, '/')) |sl| {
        const comp = name[0..sl];
        if (os.lstatPath(comp)) |st| {
            if (!st.isDir()) return @intCast(sl);
        } else {
            const e = os.errno();
            if (e == os.ENOENT or e == os.ENOTDIR) return 0;
            if (warn_on_err) util.warn("failed to lstat '{s}': {s}", .{ comp, os.strErr(e) });
            return @intCast(sl);
        }
        i = sl + 1;
    }
    return -1;
}

/// has_dirs_only_path(): all components of name[0..len] are directories
/// (stat() is used for the first prefix_len bytes).
pub fn hasDirsOnlyPath(name: []const u8, prefix_len: usize) bool {
    if (name.len == 0) return true;
    var i: usize = 0;
    while (true) {
        const end = std.mem.indexOfScalarPos(u8, name, i, '/') orelse name.len;
        const comp = name[0..end];
        if (comp.len > 0) {
            const st = (if (end <= prefix_len) os.statPath(comp) else os.lstatPath(comp)) orelse return false;
            if (!st.isDir()) return false;
        }
        if (end >= name.len) return true;
        i = end + 1;
    }
}

var removal: util.Buf = .empty;

fn originalCwd() ?[]const u8 {
    const r = repo_mod.repo_ orelse return null;
    if (r.prefix.len == 0) return null;
    return r.prefix[0 .. r.prefix.len - 1];
}

fn doRemoveScheduledDirs(new_len: usize) void {
    const cwd = originalCwd();
    var len = removal.items.len;
    while (len > new_len) {
        const d = removal.items[0..len];
        if (cwd != null and util.eql(d, cwd.?)) break;
        if (!os.rmdir(d)) break;
        len -= 1;
        while (len > new_len and removal.items[len] != '/') len -= 1;
    }
    removal.items.len = new_len;
}

fn longestPathMatch(a: []const u8, b: []const u8) usize {
    const max = @min(a.len, b.len);
    var match: usize = 0;
    var i: usize = 0;
    while (i < max and a[i] == b[i]) : (i += 1) {
        if (a[i] == '/') match = i;
    }
    if (i >= max and ((a.len > b.len and a[b.len] == '/') or (a.len < b.len and b[a.len] == '/') or a.len == b.len)) match = i;
    return match;
}

pub fn scheduleDirForRemoval(name: []const u8) void {
    if (originalCwd()) |cwd| {
        if (util.eql(name, cwd)) return;
    }
    const match = longestPathMatch(name, removal.items);
    var last_slash = match;
    var i = match;
    while (i < name.len) : (i += 1) {
        if (name[i] == '/') last_slash = i;
    }
    if (match < last_slash and match < removal.items.len) doRemoveScheduledDirs(match);
    if (match < last_slash) util.bufAppend(&removal, name[match..last_slash]);
}

pub fn removeScheduledDirs() void {
    doRemoveScheduledDirs(0);
}

// ---------------- entry.c ----------------

fn createDirectories(path: []const u8, st: *const State) void {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, path, i, '/')) |sl| {
        const d = path[0..sl];
        i = sl + 1;
        if (d.len == 0) continue;
        if (hasDirsOnlyPath(d, st.base_dir.len)) continue;
        if (!os.mkdir(d, 0o777)) {
            if (os.errno() == os.EEXIST and st.force and os.unlink(d) and os.mkdir(d, 0o777)) continue;
            util.dieErrno("cannot create directory at '{s}'", .{d});
        }
    }
}

fn removeSubtree(path: []const u8) void {
    const ents = os.listDir(path) orelse util.dieErrno("cannot opendir '{s}'", .{path});
    for (ents) |de| {
        const p = util.concat(&.{ path, "/", de.name });
        const st = os.lstatPath(p) orelse util.dieErrno("cannot lstat '{s}'", .{p});
        if (st.isDir()) {
            removeSubtree(p);
        } else if (!os.unlink(p)) util.dieErrno("cannot unlink '{s}'", .{p});
    }
    if (!os.rmdir(path)) util.dieErrno("cannot rmdir '{s}'", .{path});
}

pub fn readBlob(oid: hash.Oid) ?[]const u8 {
    const obj = repo_mod.repo().odb().read(oid) orelse return null;
    if (obj.typ != .blob) return null;
    return obj.data;
}

fn hasSymlinks() bool {
    return repo_mod.cfg.getBool("core.symlinks") orelse true;
}

/// Open output file for an entry; to_tempfile creates .merge_file_XXXXXX in cwd.
fn openOutput(path: *[]const u8, e: *const Entry, to_tempfile: bool) c_int {
    const is_symlink = e.mode & os.S_IFMT != os.S_IFREG;
    if (to_tempfile) {
        const t = os.tmpFile(".", if (is_symlink) ".merge_link_" else ".merge_file_");
        // strip the leading "./"
        path.* = t.path[2..];
        return t.fd;
    }
    const mode: c_uint = if (!is_symlink and e.mode & 0o100 != 0) 0o777 else 0o666;
    return os.openFile(path.*, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode);
}

fn writeEntry(e: *Entry, path_in: []const u8, st: *State, to_tempfile: bool) ?[]const u8 {
    var path = path_in;
    const fmt = e.mode & os.S_IFMT;
    switch (fmt) {
        os.S_IFLNK, os.S_IFREG => {
            const blob = readBlob(e.oid) orelse {
                util.err("unable to read sha1 file of {s} ({s})", .{ e.path, &hash.hex(e.oid) });
                return null;
            };
            var data: []const u8 = blob;
            if (fmt == os.S_IFLNK and hasSymlinks() and !to_tempfile) {
                if (!os.symlink(blob, path)) {
                    util.err("unable to create symlink {s}: {s}", .{ path, os.lastErr() });
                    return null;
                }
            } else {
                if (fmt == os.S_IFREG) data = convert.toWorktree(e.path, blob);
                const fd = openOutput(&path, e, to_tempfile);
                if (fd < 0) {
                    util.err("unable to create file {s}: {s}", .{ path, os.lastErr() });
                    return null;
                }
                const ok = if (os.writeAll(fd, data)) true else |_| false;
                var fst: ?os.Stat = null;
                if (!to_tempfile and st.refresh_cache and st.base_dir.len == 0) fst = os.fstatFd(fd);
                os.close(fd);
                if (!ok) {
                    util.err("unable to write file {s}", .{path});
                    return null;
                }
                if (fst) |s| {
                    if (st.refresh_cache) {
                        e.fillStat(s);
                        e.uptodate = true;
                        if (st.istate) |ix| ix.changed = true;
                    }
                    return path;
                }
            }
        },
        os.S_IFGITLINK => {
            if (to_tempfile) {
                util.err("cannot create temporary submodule {s}", .{e.path});
                return null;
            }
            if (!os.mkdir(path, 0o777)) {
                util.err("cannot create submodule directory {s}", .{path});
                return null;
            }
        },
        else => {
            util.err("unknown file mode for {s} in index", .{e.path});
            return null;
        },
    }
    if (st.refresh_cache) {
        const s = os.lstatPath(e.path) orelse {
            util.err("unable to stat just-written file {s}: {s}", .{ e.path, os.lastErr() });
            return null;
        };
        e.fillStat(s);
        if (s.isReg()) e.uptodate = true;
        if (st.istate) |ix| ix.changed = true;
    }
    return path;
}

/// ie_match_stat with CE_MATCH_IGNORE_VALID | CE_MATCH_IGNORE_SKIP_WORKTREE.
pub fn matchStatIgnoreValid(idx: ?*const Index, e: *const Entry, st: os.Stat) u32 {
    if (e.intentToAdd()) return index_mod.DATA_CHANGED | index_mod.TYPE_CHANGED | index_mod.MODE_CHANGED;
    var changed = index_mod.matchStatBasic(e, st);
    if (changed == 0) {
        if (idx) |ix| {
            if (ix.isRacy(e) and index_mod.contentChanged(e, st)) changed |= index_mod.DATA_CHANGED;
        }
    }
    return changed;
}

/// Last temp file name written by checkoutEntryTemp.
pub var last_temp_path: []const u8 = "";

/// checkout_entry(); returns true on error.
pub fn checkoutEntry(e: *Entry, st: *State, nr_checkouts: ?*usize) bool {
    const path = util.concat(&.{ st.base_dir, e.path });
    if (blk: {
        // check_path()
        const slash = std.mem.lastIndexOfScalar(u8, path, '/') orelse 0;
        if (!hasDirsOnlyPath(path[0..slash], st.base_dir.len)) break :blk null;
        break :blk os.lstatPath(path);
    }) |s| {
        const changed = matchStatIgnoreValid(st.istate, e, s);
        if (changed == 0) return false;
        if (!st.force) {
            if (!st.quiet) util.eprint("{s} already exists, no checkout\n", .{path});
            return true;
        }
        if (s.isDir()) {
            if (e.mode & os.S_IFMT == os.S_IFGITLINK) return false;
            removeSubtree(path);
        } else if (!os.unlink(path)) {
            util.err("unable to unlink old '{s}': {s}", .{ path, os.lastErr() });
            return true;
        }
    } else if (st.not_new) return false;
    createDirectories(path, st);
    if (writeEntry(e, path, st, false) == null) return true;
    if (nr_checkouts) |n| n.* += 1;
    return false;
}

/// checkout_entry() with a topath: write to a temporary file; returns the
/// temp file name or null on error.
pub fn checkoutEntryTemp(e: *Entry, st: *State) ?[]const u8 {
    return writeEntry(e, "", st, true);
}

/// unlink_entry()
pub fn unlinkEntry(e: *const Entry) void {
    if (checkLeadingPath(e.path, true) >= 0) return;
    if (e.mode & os.S_IFMT == os.S_IFGITLINK) {
        if (!os.rmdir(e.path)) {
            const er = os.errno();
            if (er != os.ENOENT) {
                util.warn("unable to rmdir '{s}': {s}", .{ e.path, os.strErr(er) });
                return;
            }
        }
    } else if (!os.unlink(e.path)) {
        const er = os.errno();
        if (er != os.ENOENT) {
            util.warn("unable to unlink '{s}': {s}", .{ e.path, os.strErr(er) });
            return;
        }
    }
    scheduleDirForRemoval(e.path);
}
