//! git status (port of cmd_status from builtin/commit.c)

const std = @import("std");
const util = @import("../util.zig");
const wt = @import("../wtstatus.zig");

pub fn cmdStatus(args: []const []const u8) u8 {
    _ = args;
    var s = wt.prepare();
    wt.collect(&s);
    wt.print(&s);
    return 0;
}
