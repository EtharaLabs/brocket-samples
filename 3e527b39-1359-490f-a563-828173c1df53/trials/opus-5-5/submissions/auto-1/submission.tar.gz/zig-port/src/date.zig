//! Date parsing and formatting (stub; to be replaced with full port of date.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");

pub const Parsed = struct { time: i64, tz: i32 };

/// tz in minutes east of UTC from "+hhmm"/"-hhmm"
pub fn parseTzOffset(s: []const u8) ?i32 {
    if (s.len != 5 or (s[0] != '+' and s[0] != '-')) return null;
    const n = std.fmt.parseInt(i32, s[1..], 10) catch return null;
    const m = @divTrunc(n, 100) * 60 + @mod(n, 100);
    return if (s[0] == '-') -m else m;
}

pub fn formatTz(tz: i32) []const u8 {
    const sign: u8 = if (tz < 0) '-' else '+';
    const a: u32 = @intCast(if (tz < 0) -tz else tz);
    return util.fmt("{c}{d:0>2}{d:0>2}", .{ sign, a / 60, a % 60 });
}

pub fn parseDate(s: []const u8) ?Parsed {
    var str = util.trim(s);
    if (str.len > 0 and str[0] == '@') str = str[1..];
    var it = std.mem.tokenizeScalar(u8, str, ' ');
    const t = it.next() orelse return null;
    const time = std.fmt.parseInt(i64, t, 10) catch return null;
    var tz: i32 = 0;
    if (it.next()) |z| tz = parseTzOffset(z) orelse 0;
    return .{ .time = time, .tz = tz };
}

pub fn localTz(t: i64) i32 {
    const tm = os.localtime(t);
    return @intCast(@divTrunc(tm.gmtoff, 60));
}

pub fn nowString() []const u8 {
    const t = os.now();
    return util.fmt("{d} {s}", .{ t, formatTz(localTz(t)) });
}
