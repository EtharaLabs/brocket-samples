//! Repository discovery and global repository state.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const config = @import("config.zig");
const odb_mod = @import("odb.zig");
const gpa = util.gpa;

pub const Repo = struct {
    git_dir: []const u8,
    common_dir: []const u8,
    work_tree: ?[]const u8,
    prefix: []const u8 = "",
    bare: bool = false,
    odb_: ?*odb_mod.Odb = null,
    format_version: i64 = 0,
    worktree_config: bool = false,
    object_format: []const u8 = "sha1",

    pub fn odb(self: *Repo) *odb_mod.Odb {
        if (self.odb_ == null) {
            const dir = os.getenv("GIT_OBJECT_DIRECTORY") orelse util.concat(&.{ self.common_dir, "/objects" });
            self.odb_ = odb_mod.Odb.init(dir);
            if (cfg.getInt("core.loosecompression") orelse cfg.getInt("core.compression")) |lvl| {
                self.odb_.?.compression = @intCast(if (lvl == -1) 6 else lvl);
            }
        }
        return self.odb_.?;
    }

    /// Path inside the per-worktree git dir.
    pub fn gitPath(self: *Repo, name: []const u8) []u8 {
        return util.concat(&.{ self.git_dir, "/", name });
    }
    /// Path inside the common dir.
    pub fn commonPath(self: *Repo, name: []const u8) []u8 {
        return util.concat(&.{ self.common_dir, "/", name });
    }

    pub fn indexPath(self: *Repo) []const u8 {
        if (os.getenv("GIT_INDEX_FILE")) |p| return p;
        return self.gitPath("index");
    }
};

pub var repo_: ?*Repo = null;
pub var cfg: config.Config = .{};
pub var cmdline_config: std.ArrayList([]const u8) = .empty;

pub fn repo() *Repo {
    return repo_ orelse util.die("not a git repository (or any of the parent directories): .git", .{});
}

pub fn requireWorkTree(cmd: []const u8) *Repo {
    const r = repo();
    if (r.work_tree == null) util.die("this operation must be run in a work tree", .{});
    _ = cmd;
    return r;
}

fn validateHeadRef(path: []const u8) bool {
    const st = os.lstatPath(path) orelse return false;
    if (st.isLnk()) {
        const t = os.readLink(path) orelse return false;
        return util.startsWith(t, "refs/");
    }
    const data = os.readFile(path) orelse return false;
    if (util.startsWith(data, "ref:")) {
        var rest = data[4..];
        while (rest.len > 0 and std.ascii.isWhitespace(rest[0])) rest = rest[1..];
        return util.startsWith(rest, "refs/");
    }
    if (data.len >= 40 and util.isHex(data[0..40])) return true;
    return false;
}

fn getCommonDir(gitdir: []const u8) []const u8 {
    if (os.getenv("GIT_COMMON_DIR")) |c| return c;
    const data = os.readFile(util.concat(&.{ gitdir, "/commondir" })) orelse return gitdir;
    const t = util.trimRight(data);
    if (t.len > 0 and t[0] == '/') return t;
    return util.normalizePath(util.concat(&.{ gitdir, "/", t })) orelse t;
}

pub fn isGitDirectory(dir: []const u8) bool {
    if (!validateHeadRef(util.concat(&.{ dir, "/HEAD" }))) return false;
    const common = getCommonDir(dir);
    if (os.getenv("GIT_OBJECT_DIRECTORY")) |o| {
        if (!os.access(o, 1)) return false;
    } else if (!os.access(util.concat(&.{ common, "/objects" }), 1)) return false;
    if (!os.access(util.concat(&.{ common, "/refs" }), 1)) return false;
    return true;
}

/// Read a .git file. Returns the gitdir path or null if not a gitfile.
pub fn readGitfile(path: []const u8) ?[]const u8 {
    const st = os.statPath(path) orelse return null;
    if (!st.isReg()) return null;
    const data = os.readFile(path) orelse return null;
    const rest = util.skipPrefix(data, "gitdir: ") orelse util.die("invalid gitfile format: {s}", .{path});
    const p = util.trimRight(rest);
    var full: []const u8 = p;
    if (p.len > 0 and p[0] != '/') {
        full = util.joinPath(util.dirname(path), p);
        if (util.dirname(path).len == 0) full = p;
    }
    if (!isGitDirectory(full)) util.die("not a git repository: {s}", .{full});
    return full;
}

fn absPath(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return util.normalizePath(p) orelse p;
    return util.normalizePath(util.joinPath(os.getcwd(), p)) orelse p;
}

fn realOrAbs(p: []const u8) []const u8 {
    return os.realPath(p) orelse absPath(p);
}

const RepoFormat = struct {
    version: i64 = 0,
    bare: ?bool = null,
    work_tree: ?[]const u8 = null,
    worktree_config: bool = false,
    object_format: []const u8 = "sha1",
};

fn readRepoFormat(gitdir: []const u8) RepoFormat {
    var c: config.Config = .{};
    const common = getCommonDir(gitdir);
    _ = config.readFileInto(&c, util.concat(&.{ common, "/config" }), .local);
    var f = RepoFormat{};
    f.version = c.getInt("core.repositoryformatversion") orelse 0;
    f.bare = c.getBool("core.bare");
    f.work_tree = c.get("core.worktree");
    f.worktree_config = c.getBoolDefault("extensions.worktreeconfig", false);
    if (c.get("extensions.objectformat")) |of| f.object_format = of;
    if (f.version > 1) util.die("Expected git repo version <= 1, found {d}", .{f.version});
    if (f.worktree_config) {
        var wc: config.Config = .{};
        if (config.readFileInto(&wc, util.concat(&.{ gitdir, "/config.worktree" }), .worktree)) {
            if (wc.getBool("core.bare")) |b| f.bare = b;
            if (wc.get("core.worktree")) |w| f.work_tree = w;
        }
    }
    return f;
}

fn makeRepo(git_dir: []const u8, work_tree: ?[]const u8, prefix: []const u8, fmt_: RepoFormat) *Repo {
    const r = gpa.create(Repo) catch util.oom();
    r.* = .{
        .git_dir = git_dir,
        .common_dir = getCommonDir(git_dir),
        .work_tree = work_tree,
        .prefix = prefix,
        .bare = work_tree == null,
        .format_version = fmt_.version,
        .worktree_config = fmt_.worktree_config,
        .object_format = fmt_.object_format,
    };
    return r;
}

/// Is `dir` (absolute, normalized) inside `root`? Returns offset of the remainder.
fn dirInsideOf(dir: []const u8, root: []const u8) ?usize {
    if (util.eql(root, "/")) return 1;
    if (!util.startsWith(dir, root)) return null;
    if (dir.len == root.len) return dir.len;
    if (dir[root.len] != '/') return null;
    return root.len + 1;
}

fn discoverExplicit(gitdir_env: []const u8, cwd: []const u8, nongit_ok: bool) ?*Repo {
    var gitdir = gitdir_env;
    if (readGitfileQuiet(gitdir)) |g| gitdir = g;
    if (!isGitDirectory(gitdir)) {
        if (nongit_ok) return null;
        util.die("not a git repository: '{s}'", .{gitdir_env});
    }
    const f = readRepoFormat(gitdir);
    var worktree: ?[]const u8 = null;
    if (os.getenv("GIT_WORK_TREE")) |wt| {
        worktree = realOrAbs(wt);
    } else if (f.bare orelse false) {
        return makeRepo(gitdir, null, "", f);
    } else if (f.work_tree) |wt| {
        if (wt.len > 0 and wt[0] == '/') {
            worktree = realOrAbs(wt);
        } else {
            worktree = realOrAbs(util.concat(&.{ absPath(gitdir), "/", wt }));
        }
    } else if (os.getenv("GIT_IMPLICIT_WORK_TREE")) |v| {
        if (config.parseBool(v) == false) return makeRepo(gitdir, null, "", f);
        worktree = realOrAbs(".");
    } else {
        worktree = realOrAbs(".");
    }
    const wt = worktree.?;
    if (util.eql(cwd, wt)) return makeRepo(gitdir, wt, "", f);
    if (dirInsideOf(cwd, wt)) |off| {
        const gd = realOrAbs(gitdir);
        if (!os.chdir(wt)) util.dieErrno("cannot chdir to '{s}'", .{wt});
        return makeRepo(gd, wt, util.concat(&.{ cwd[off..], "/" }), f);
    }
    // cwd outside worktree
    const r = makeRepo(gitdir, wt, "", f);
    r.prefix = "";
    outside_worktree = true;
    return r;
}

pub var outside_worktree = false;

fn readGitfileQuiet(path: []const u8) ?[]const u8 {
    const st = os.statPath(path) orelse return null;
    if (!st.isReg()) return null;
    return readGitfile(path);
}

/// Set up the repository. If nongit_ok, returns without error when not in a repo.
pub fn setup(nongit_ok: bool) void {
    const cwd = os.getcwd();
    if (os.getenv("GIT_DIR")) |gd| {
        repo_ = discoverExplicit(gd, cwd, nongit_ok);
        finishSetup();
        return;
    }
    // ceiling dirs
    var ceil_len: ?usize = null;
    if (os.getenv("GIT_CEILING_DIRECTORIES")) |ceil| {
        var it = std.mem.splitScalar(u8, ceil, ':');
        while (it.next()) |c0| {
            if (c0.len == 0 or c0[0] != '/') continue;
            const c = os.realPath(c0) orelse (util.normalizePath(c0) orelse continue);
            const cn = if (c.len > 1 and c[c.len - 1] == '/') c[0 .. c.len - 1] else c;
            if (dirInsideOf(cwd, cn)) |_| {
                if (cwd.len > cn.len and (ceil_len == null or cn.len > ceil_len.?)) ceil_len = cn.len;
            }
        }
    }
    var dir: []const u8 = cwd;
    while (true) {
        const dotgit = util.joinPath(dir, ".git");
        var found: ?[]const u8 = null;
        if (os.statPath(dotgit)) |st| {
            if (st.isReg()) {
                found = readGitfile(dotgit);
            } else if (st.isDir()) {
                if (isGitDirectory(dotgit)) found = ".git";
            }
        }
        if (found) |gd0| {
            if (dir.len < cwd.len) {
                if (!os.chdir(dir)) util.die("cannot change to '{s}'", .{dir});
            }
            // gd0 may be relative to dir
            var gd = gd0;
            const f = readRepoFormat(gd);
            if (os.getenv("GIT_WORK_TREE") != null or f.work_tree != null) {
                if (dir.len != cwd.len and gd[0] != '/') gd = realOrAbs(gd);
                _ = os.chdir(cwd);
                repo_ = discoverExplicit(gd, cwd, nongit_ok);
                finishSetup();
                return;
            }
            if (f.bare orelse false) {
                if (dir.len != cwd.len) gd = realOrAbs(gd);
                _ = os.chdir(cwd);
                repo_ = makeRepo(gd, null, "", f);
                finishSetup();
                return;
            }
            var prefix: []const u8 = "";
            if (dir.len < cwd.len) {
                const off = if (util.eql(dir, "/")) 1 else dir.len + 1;
                prefix = util.concat(&.{ cwd[off..], "/" });
            }
            repo_ = makeRepo(gd, dir, prefix, f);
            finishSetup();
            return;
        }
        // bare?
        if (isGitDirectory(dir)) {
            if (dir.len < cwd.len) {
                if (!os.chdir(dir)) util.die("cannot change to '{s}'", .{dir});
            }
            const f = readRepoFormat(".");
            os.setEnv("GIT_IMPLICIT_WORK_TREE", "0");
            if (os.getenv("GIT_WORK_TREE") != null or f.work_tree != null) {
                const gd = if (dir.len == cwd.len) "." else dir;
                _ = os.chdir(cwd);
                repo_ = discoverExplicit(gd, cwd, nongit_ok);
                finishSetup();
                return;
            }
            if (dir.len != cwd.len) {
                _ = os.chdir(cwd);
                repo_ = makeRepo(dir, null, "", f);
            } else {
                repo_ = makeRepo(".", null, "", f);
            }
            finishSetup();
            return;
        }
        if (util.eql(dir, "/")) break;
        const parent = util.dirname(dir);
        const next = if (parent.len == 0) "/" else parent;
        if (ceil_len) |cl| {
            if (next.len < cl or (next.len == cl and true)) {
                if (next.len <= cl) break;
            }
        }
        dir = next;
    }
    if (!nongit_ok) util.die("not a git repository (or any of the parent directories): .git", .{});
    os.setEnv("GIT_PREFIX", "");
    loadConfig();
}

fn finishSetup() void {
    if (repo_) |r| {
        if (!util.eql(r.git_dir, ".git")) os.setEnv("GIT_DIR", r.git_dir);
        os.setEnv("GIT_PREFIX", r.prefix);
    } else {
        os.setEnv("GIT_PREFIX", "");
    }
    loadConfig();
}

pub fn currentBranchForConfig() ?[]const u8 {
    const r = repo_ orelse return null;
    const data = os.readFile(r.gitPath("HEAD")) orelse return null;
    const rest = util.skipPrefix(data, "ref: refs/heads/") orelse return null;
    return util.trimRight(rest);
}

pub fn globalConfigPaths() struct { xdg: ?[]const u8, home: ?[]const u8 } {
    if (os.getenv("GIT_CONFIG_GLOBAL")) |g| return .{ .xdg = null, .home = g };
    var xdg: ?[]const u8 = null;
    if (os.getenv("XDG_CONFIG_HOME")) |x| {
        if (x.len > 0) xdg = util.concat(&.{ x, "/git/config" });
    }
    const home = os.getenv("HOME");
    if (xdg == null) {
        if (home) |h| xdg = util.concat(&.{ h, "/.config/git/config" });
    }
    return .{ .xdg = xdg, .home = if (home) |h| util.concat(&.{ h, "/.gitconfig" }) else null };
}

pub fn systemConfigPath() ?[]const u8 {
    if (os.getenv("GIT_CONFIG_NOSYSTEM")) |v| {
        if (config.parseBool(v) orelse false) return null;
    }
    return os.getenv("GIT_CONFIG_SYSTEM") orelse "/etc/gitconfig";
}

pub fn loadConfig() void {
    cfg = .{};
    if (repo_) |r| {
        cfg.git_dir = r.git_dir;
        cfg.current_branch = currentBranchForConfig();
    }
    if (systemConfigPath()) |p| {
        if (p.len > 0) _ = config.readFileInto(&cfg, p, .system);
    }
    const g = globalConfigPaths();
    if (g.xdg) |x| _ = config.readFileInto(&cfg, x, .global);
    if (g.home) |h| {
        if (h.len > 0) _ = config.readFileInto(&cfg, h, .global);
    }
    if (repo_) |r| {
        _ = config.readFileInto(&cfg, r.commonPath("config"), .local);
        if (r.worktree_config) {
            _ = config.readFileInto(&cfg, r.gitPath("config.worktree"), .worktree);
        }
    }
    loadCmdlineConfig();
}

fn loadCmdlineConfig() void {
    if (os.getenv("GIT_CONFIG_COUNT")) |cnt_s| {
        const cnt = util.parseInt(usize, cnt_s) orelse util.die("bogus count in GIT_CONFIG_COUNT", .{});
        var i: usize = 0;
        while (i < cnt) : (i += 1) {
            const k = os.getenv(util.fmt("GIT_CONFIG_KEY_{d}", .{i})) orelse util.die("missing config key GIT_CONFIG_KEY_{d}", .{i});
            const v = os.getenv(util.fmt("GIT_CONFIG_VALUE_{d}", .{i})) orelse util.die("missing config value GIT_CONFIG_VALUE_{d}", .{i});
            const ck = config.canonicalKey(k) orelse util.die("bogus config parameter: {s}", .{k});
            cfg.add(.{ .key = ck, .value = v, .origin = "", .origin_type = .cmdline, .scope = .command, .line = 0 });
        }
    }
    if (os.getenv("GIT_CONFIG_PARAMETERS")) |p| config.parseConfigParameters(&cfg, p);
}

/// Record a -c option: exported via GIT_CONFIG_PARAMETERS for children.
pub fn addCmdlineConfig(kv: []const u8) void {
    var b: util.Buf = .empty;
    if (os.getenv("GIT_CONFIG_PARAMETERS")) |old| {
        util.bufAppend(&b, old);
        util.bufByte(&b, ' ');
    }
    if (std.mem.indexOfScalar(u8, kv, '=')) |eq| {
        util.sqQuote(&b, kv[0..eq]);
        util.bufByte(&b, '=');
        util.sqQuote(&b, kv[eq + 1 ..]);
    } else {
        util.sqQuote(&b, kv);
    }
    os.setEnv("GIT_CONFIG_PARAMETERS", b.items);
}

/// Path relative to worktree root, given a user-supplied path relative to cwd (prefix).
pub fn prefixPath(arg: []const u8) ?[]const u8 {
    const r = repo();
    var full: []const u8 = undefined;
    if (arg.len > 0 and arg[0] == '/') {
        const wt = r.work_tree orelse return null;
        const n = util.normalizePath(arg) orelse return null;
        if (util.eql(n, wt)) return "";
        if (util.startsWith(n, wt) and n.len > wt.len and n[wt.len] == '/') return n[wt.len + 1 ..];
        // try realpath
        if (os.realPath(util.dirname(arg))) |rp| {
            const n2 = util.joinPath(rp, util.basename(arg));
            if (util.startsWith(n2, wt) and n2.len > wt.len and n2[wt.len] == '/') return n2[wt.len + 1 ..];
            if (util.eql(rp, wt) and util.basename(arg).len == 0) return "";
        }
        return null;
    }
    full = util.concat(&.{ r.prefix, arg });
    const n = util.normalizePath(full) orelse return null;
    return n;
}
