//! builtin/am.c -- apply a series of patches from a mailbox.
const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const repo_mod = @import("../repo.zig");
const apply = @import("../apply.zig");
const po = @import("../parseopt.zig");
const index_mod = @import("../index.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const revparse = @import("../revparse.zig");
const objects = @import("../objects.zig");
const commit_mod = @import("../commit.zig");
const ident = @import("../ident.zig");
const date = @import("../date.zig");
const hook = @import("../hook.zig");
const advice = @import("../advice.zig");
const merge_ort = @import("../merge_ort.zig");
const ut = @import("../unpacktrees.zig");
const branchstate = @import("../branchstate.zig");
const editor = @import("../editor.zig");
const pathspec_mod = @import("../pathspec.zig");
const commands = @import("../commands.zig");
const cmd_commit = @import("commit.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Buf = util.Buf;

const PatchFormat = enum(i32) { unknown = 0, mbox, stgit, stgit_series, hg, mboxrd };
const KEEP_FALSE: i32 = 0;
const KEEP_TRUE: i32 = 1;
const KEEP_NON_PATCH: i32 = 2;
const SCISSORS_UNSET: i32 = -1;
const SIGNOFF_EXPLICIT: i32 = 2;

const Resume = enum(i32) { none = 0, apply, resolved, skip, abort, quit, show_raw, show_diff, allow_empty };
const Empty = enum(i32) { stop = 0, drop, keep };

const QuotedCr = enum(i32) { unset = -1, nowarn = 0, warn, strip };

const State = struct {
    dir: []const u8 = "",
    cur: i32 = 0,
    last: i32 = 0,
    author_name: ?[]const u8 = null,
    author_email: ?[]const u8 = null,
    author_date: ?[]const u8 = null,
    msg: ?[]const u8 = null,
    orig_commit: ?Oid = null,
    prec: usize = 4,
    interactive: bool = false,
    no_verify: bool = false,
    threeway: bool = false,
    quiet: i32 = 0,
    signoff: i32 = 0,
    utf8: bool = true,
    keep: i32 = KEEP_FALSE,
    message_id: bool = false,
    scissors: i32 = SCISSORS_UNSET,
    quoted_cr: QuotedCr = .unset,
    empty_type: Empty = .stop,
    git_apply_opts: std.ArrayList([]const u8) = .empty,
    resolvemsg: ?[]const u8 = null,
    committer_date_is_author_date: bool = false,
    ignore_date: bool = false,
    allow_rerere_autoupdate: i32 = 0,
    sign_commit: ?[]const u8 = null,
    rebasing: bool = false,
};

fn selfExe() []const u8 {
    return os.readLink("/proc/self/exe") orelse "git";
}

fn linelen(msg: []const u8) usize {
    return std.mem.indexOfScalar(u8, msg, '\n') orelse msg.len;
}

fn firstLine(msg: ?[]const u8) []const u8 {
    const m = msg orelse return "";
    return m[0..linelen(m)];
}

fn amPath(state: *const State, name: []const u8) []const u8 {
    return util.concat(&.{ state.dir, "/", name });
}

fn writeFileOrDie(path: []const u8, data: []const u8) void {
    os.writeFile(path, data, 0o666) catch util.dieErrno("could not write to '{s}'", .{path});
}

fn writeStateText(state: *const State, name: []const u8, s: []const u8) void {
    var data: []const u8 = s;
    if (s.len > 0 and s[s.len - 1] != '\n') data = util.concat(&.{ s, "\n" });
    writeFileOrDie(amPath(state, name), data);
}

fn writeStateCount(state: *const State, name: []const u8, v: i32) void {
    writeStateText(state, name, util.fmt("{d}", .{v}));
}

fn writeStateBool(state: *const State, name: []const u8, v: bool) void {
    writeStateText(state, name, if (v) "t" else "f");
}

fn say(state: *const State, to_err: bool, msg: []const u8) void {
    if (state.quiet != 0) return;
    if (to_err) {
        util.flushStdout();
        util.eprint("{s}\n", .{msg});
    } else {
        util.out(msg);
        util.out("\n");
    }
}

fn isRegular(path: []const u8) bool {
    const st = os.lstatPath(path) orelse return false;
    return !st.isDir() and (st.mode & 0o170000) == 0o100000;
}

fn amInProgress(state: *const State) bool {
    const st = os.lstatPath(state.dir) orelse return false;
    if (!st.isDir()) return false;
    if (!isRegular(amPath(state, "last"))) return false;
    if (!isRegular(amPath(state, "next"))) return false;
    return true;
}

fn readStateFile(state: *const State, name: []const u8, trim: bool) ?[]const u8 {
    const data = os.readFile(amPath(state, name)) orelse return null;
    if (trim) return util.trim(data);
    return data;
}

fn isEmptyOrMissing(path: []const u8) bool {
    const st = os.statPath(path) orelse return true;
    return st.size == 0;
}

fn parseLeadingInt(s: []const u8) i32 {
    var i: usize = 0;
    while (i < s.len and std.ascii.isWhitespace(s[i])) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '-' or s[i] == '+')) {
        neg = s[i] == '-';
        i += 1;
    }
    var v: i64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) {
        v = v * 10 + (s[i] - '0');
        if (v > std.math.maxInt(i32)) v = std.math.maxInt(i32);
    }
    const r: i32 = @intCast(v);
    return if (neg) -r else r;
}

// ---------------------------------------------------------------------------
// shell (de)quoting

fn needBsQuote(c: u8) bool {
    return c == '\'' or c == '!';
}

/// sq_dequote_step: returns the dequoted word and the rest (null at end), or
/// null on a parse error.
fn sqDequoteStep(s: []const u8, rest: *?[]const u8, allow_next: bool) ?[]const u8 {
    if (s.len == 0 or s[0] != '\'') return null;
    var b: Buf = .empty;
    var i: usize = 1;
    while (true) {
        if (i >= s.len) return null;
        const c = s[i];
        if (c != '\'') {
            util.bufByte(&b, c);
            i += 1;
            continue;
        }
        i += 1;
        if (i >= s.len) {
            rest.* = null;
            return b.items;
        }
        if (s[i] == '\\' and i + 2 < s.len and needBsQuote(s[i + 1]) and s[i + 2] == '\'') {
            util.bufByte(&b, s[i + 1]);
            i += 3;
            continue;
        }
        if (!allow_next) return null;
        rest.* = s[i..];
        return b.items;
    }
}

fn sqDequoteToList(s0: []const u8, list: *std.ArrayList([]const u8)) bool {
    var s: []const u8 = s0;
    while (true) {
        while (s.len > 0 and std.ascii.isWhitespace(s[0])) s = s[1..];
        if (s.len == 0) return true;
        var rest: ?[]const u8 = null;
        const w = sqDequoteStep(s, &rest, true) orelse return false;
        list.append(gpa, w) catch util.oom();
        s = rest orelse return true;
    }
}

fn readAuthorScript(state: *State) bool {
    const path = amPath(state, "author-script");
    const data = os.readFile(path) orelse return true; // missing is OK
    if (data.len == 0) return true;
    var name_v: ?[]const u8 = null;
    var email_v: ?[]const u8 = null;
    var date_v: ?[]const u8 = null;
    var ok = true;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line| {
        if (line.len == 0) continue;
        const eq = std.mem.indexOfScalar(u8, line, '=') orelse return false;
        const key = line[0..eq];
        var rest: ?[]const u8 = null;
        const val = sqDequoteStep(line[eq + 1 ..], &rest, false) orelse return false;
        if (util.eql(key, "GIT_AUTHOR_NAME")) {
            if (name_v != null) {
                util.err("'GIT_AUTHOR_NAME' already given", .{});
                ok = false;
            }
            name_v = val;
        } else if (util.eql(key, "GIT_AUTHOR_EMAIL")) {
            if (email_v != null) {
                util.err("'GIT_AUTHOR_EMAIL' already given", .{});
                ok = false;
            }
            email_v = val;
        } else if (util.eql(key, "GIT_AUTHOR_DATE")) {
            if (date_v != null) {
                util.err("'GIT_AUTHOR_DATE' already given", .{});
                ok = false;
            }
            date_v = val;
        } else {
            util.err("unknown variable '{s}'", .{key});
            ok = false;
        }
    }
    if (name_v == null) util.err("missing 'GIT_AUTHOR_NAME'", .{});
    if (email_v == null) util.err("missing 'GIT_AUTHOR_EMAIL'", .{});
    if (date_v == null) util.err("missing 'GIT_AUTHOR_DATE'", .{});
    if (!ok or name_v == null or email_v == null or date_v == null) return false;
    state.author_name = name_v;
    state.author_email = email_v;
    state.author_date = date_v;
    return true;
}

fn writeAuthorScript(state: *const State) void {
    var b: Buf = .empty;
    util.bufAppend(&b, "GIT_AUTHOR_NAME=");
    util.sqQuote(&b, state.author_name orelse "");
    util.bufAppend(&b, "\nGIT_AUTHOR_EMAIL=");
    util.sqQuote(&b, state.author_email orelse "");
    util.bufAppend(&b, "\nGIT_AUTHOR_DATE=");
    util.sqQuote(&b, state.author_date orelse "");
    util.bufByte(&b, '\n');
    writeStateText(state, "author-script", b.items);
}

fn readCommitMsg(state: *State) bool {
    const data = readStateFile(state, "final-commit", false) orelse return false;
    state.msg = data;
    return true;
}

fn writeCommitMsg(state: *const State) void {
    writeFileOrDie(amPath(state, "final-commit"), state.msg orelse "");
}

fn parseQuotedCr(s: []const u8) ?QuotedCr {
    if (util.eql(s, "nowarn")) return .nowarn;
    if (util.eql(s, "warn")) return .warn;
    if (util.eql(s, "strip")) return .strip;
    return null;
}

fn amLoad(state: *State) void {
    const next = readStateFile(state, "next", true) orelse util.die("BUG: state file 'next' does not exist", .{});
    state.cur = parseLeadingInt(next);
    const last = readStateFile(state, "last", true) orelse util.die("BUG: state file 'last' does not exist", .{});
    state.last = parseLeadingInt(last);

    state.author_name = null;
    state.author_email = null;
    state.author_date = null;
    if (!readAuthorScript(state)) util.die("could not parse author script", .{});

    state.msg = null;
    _ = readCommitMsg(state);

    if (readStateFile(state, "original-commit", true)) |s| {
        state.orig_commit = hash.fromHex(s) orelse util.die("could not parse {s}", .{amPath(state, "original-commit")});
    } else state.orig_commit = null;

    state.threeway = util.eql(readStateFile(state, "threeway", true) orelse "", "t");
    state.quiet = if (util.eql(readStateFile(state, "quiet", true) orelse "", "t")) 1 else 0;
    state.signoff = if (util.eql(readStateFile(state, "sign", true) orelse "", "t")) 1 else 0;
    state.utf8 = util.eql(readStateFile(state, "utf8", true) orelse "", "t");

    if (os.exists(amPath(state, "rerere-autoupdate"))) {
        const v = readStateFile(state, "rerere-autoupdate", true) orelse "";
        state.allow_rerere_autoupdate = if (util.eql(v, "t")) 1 else 2;
    } else state.allow_rerere_autoupdate = 0;

    const k = readStateFile(state, "keep", true) orelse "";
    state.keep = if (util.eql(k, "t")) KEEP_TRUE else if (util.eql(k, "b")) KEEP_NON_PATCH else KEEP_FALSE;

    state.message_id = util.eql(readStateFile(state, "messageid", true) orelse "", "t");

    const sc = readStateFile(state, "scissors", true) orelse "";
    state.scissors = if (util.eql(sc, "t")) 1 else if (util.eql(sc, "f")) 0 else SCISSORS_UNSET;

    const qc = readStateFile(state, "quoted-cr", true) orelse "";
    if (qc.len == 0) {
        state.quoted_cr = .unset;
    } else {
        state.quoted_cr = parseQuotedCr(qc) orelse util.die("could not parse {s}", .{amPath(state, "quoted-cr")});
    }

    const ao = readStateFile(state, "apply-opt", true) orelse "";
    state.git_apply_opts = .empty;
    if (!sqDequoteToList(ao, &state.git_apply_opts)) util.die("could not parse {s}", .{amPath(state, "apply-opt")});

    state.rebasing = os.exists(amPath(state, "rebasing"));
}

fn amDestroy(state: *const State) void {
    os.removeTree(state.dir);
}

fn runApplypatchMsgHook(state: *State) u8 {
    var ret: u8 = 0;
    if (!state.no_verify) {
        util.flushStdout();
        ret = hook.run("applypatch-msg", &.{amPath(state, "final-commit")}, .{});
    }
    if (ret == 0) {
        state.msg = null;
        if (!readCommitMsg(state))
            util.die("'{s}' was deleted by the applypatch-msg hook", .{amPath(state, "final-commit")});
    }
    return ret;
}

fn runPostRewriteHook(state: *const State) void {
    const data = os.readFile(amPath(state, "rewritten")) orelse "";
    util.flushStdout();
    _ = hook.run("post-rewrite", &.{"rebase"}, .{ .stdin_data = data });
}

// ---------------------------------------------------------------------------
// patch format detection / splitting

fn headerLike(line: []const u8) bool {
    var i: usize = 0;
    while (i < line.len) : (i += 1) {
        const c = line[i];
        if (c == ':') return i > 0;
        if (!((c >= '!' and c <= '9') or (c >= ';' and c <= '~'))) return false;
    }
    return false;
}

/// Split into lines like strbuf_getline (strips "\n" and a preceding "\r").
const LineIter = struct {
    data: []const u8,
    pos: usize = 0,
    fn next(self: *LineIter) ?[]const u8 {
        if (self.pos >= self.data.len) return null;
        const start = self.pos;
        const nl = std.mem.indexOfScalarPos(u8, self.data, start, '\n');
        var end: usize = undefined;
        if (nl) |n| {
            end = n;
            self.pos = n + 1;
        } else {
            end = self.data.len;
            self.pos = self.data.len;
        }
        var line = self.data[start..end];
        if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
        return line;
    }
};

fn isMail(data: []const u8) bool {
    var it = LineIter{ .data = data };
    while (it.next()) |line| {
        if (line.len == 0) break;
        if (line[0] == '\t' or line[0] == ' ') continue;
        if (!headerLike(line)) return false;
    }
    return true;
}

fn detectPatchFormat(paths: []const []const u8) PatchFormat {
    if (paths.len == 0 or util.eql(paths[0], "-") or os.isDir(paths[0])) return .mbox;
    const data = os.readFile(paths[0]) orelse util.dieErrno("could not open '{s}' for reading", .{paths[0]});
    var it = LineIter{ .data = data };
    var l1: []const u8 = "";
    while (it.next()) |line| {
        l1 = line;
        if (line.len > 0) break;
    }
    if (util.startsWith(l1, "From ") or util.startsWith(l1, "From: ")) return .mbox;
    if (util.startsWith(l1, "# This series applies on GIT commit")) return .stgit_series;
    if (util.eql(l1, "# HG changeset patch")) return .hg;
    const l2 = it.next() orelse "";
    const l3 = it.next() orelse "";
    if (l1.len > 0 and l2.len == 0 and (util.startsWith(l3, "From:") or util.startsWith(l3, "Author:") or util.startsWith(l3, "Date:")))
        return .stgit;
    if (l1.len > 0 and isMail(data)) return .mbox;
    return .unknown;
}

fn splitMailMbox(state: *State, paths: []const []const u8, keep_cr: bool, mboxrd: bool) bool {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, selfExe()) catch util.oom();
    argv.append(gpa, "mailsplit") catch util.oom();
    argv.append(gpa, util.fmt("-d{d}", .{state.prec})) catch util.oom();
    argv.append(gpa, util.fmt("-o{s}", .{state.dir})) catch util.oom();
    argv.append(gpa, "-b") catch util.oom();
    if (keep_cr) argv.append(gpa, "--keep-cr") catch util.oom();
    if (mboxrd) argv.append(gpa, "--mboxrd") catch util.oom();
    argv.append(gpa, "--") catch util.oom();
    argv.appendSlice(gpa, paths) catch util.oom();
    util.flushStdout();
    const res = os.run(argv.items, .{ .capture_stdout = true });
    if (res.status != 0) return false;
    state.cur = 1;
    state.last = parseLeadingInt(res.stdout);
    return true;
}

const ConvFn = *const fn (out: *Buf, in: []const u8) bool;

fn readLf(data: []const u8, pos: *usize) ?[]const u8 {
    if (pos.* >= data.len) return null;
    const start = pos.*;
    if (std.mem.indexOfScalarPos(u8, data, start, '\n')) |n| {
        pos.* = n + 1;
        return data[start..n];
    }
    pos.* = data.len;
    return data[start..];
}

fn strIsSpace(s: []const u8) bool {
    for (s) |c| if (!std.ascii.isWhitespace(c)) return false;
    return true;
}

fn stgitPatchToMail(out: *Buf, in: []const u8) bool {
    var pos: usize = 0;
    var subject_printed = false;
    while (readLf(in, &pos)) |line| {
        if (strIsSpace(line)) {
            continue;
        } else if (util.startsWith(line, "Author:")) {
            util.bufPrint(out, "From:{s}\n", .{line[7..]});
        } else if (util.startsWith(line, "From") or util.startsWith(line, "Date")) {
            util.bufPrint(out, "{s}\n", .{line});
        } else if (!subject_printed) {
            util.bufPrint(out, "Subject: {s}\n", .{line});
            subject_printed = true;
        } else {
            util.bufPrint(out, "\n{s}\n", .{line});
            break;
        }
    }
    util.bufAppend(out, in[pos..]);
    return true;
}

fn hgPatchToMail(out: *Buf, in: []const u8) bool {
    var pos: usize = 0;
    while (readLf(in, &pos)) |line| {
        if (util.startsWith(line, "# User ")) {
            util.bufPrint(out, "From: {s}\n", .{line[7..]});
        } else if (util.startsWith(line, "# Date ")) {
            const str = line[7..];
            var i: usize = 0;
            while (i < str.len and std.ascii.isDigit(str[i])) i += 1;
            const ts = std.fmt.parseInt(i64, str[0..i], 10) catch {
                util.err("invalid timestamp", .{});
                return false;
            };
            if (i >= str.len or str[i] != ' ') {
                util.err("invalid Date line", .{});
                return false;
            }
            const tzs = str[i + 1 ..];
            var j: usize = 0;
            if (j < tzs.len and (tzs[j] == '-' or tzs[j] == '+')) j += 1;
            while (j < tzs.len and std.ascii.isDigit(tzs[j])) j += 1;
            const tz = std.fmt.parseInt(i64, tzs[0..j], 10) catch 0;
            if (j != tzs.len) {
                util.err("invalid Date line", .{});
                return false;
            }
            const a: i64 = if (tz < 0) -tz else tz;
            var tz2: i64 = @divTrunc(a, 3600) * 100 + @divTrunc(@rem(a, 3600), 60);
            if (tz > 0) tz2 = -tz2;
            util.bufPrint(out, "Date: {s}\n", .{date.showDate(ts, @intCast(tz2), date.DateMode.of(.rfc2822))});
        } else if (util.startsWith(line, "# ")) {
            continue;
        } else {
            util.bufPrint(out, "\n{s}\n", .{line});
            break;
        }
    }
    util.bufAppend(out, in[pos..]);
    return true;
}

fn splitMailConv(f: ConvFn, state: *State, paths0: []const []const u8) bool {
    const stdin_only = [_][]const u8{"-"};
    const paths: []const []const u8 = if (paths0.len == 0) &stdin_only else paths0;
    for (paths, 0..) |p, i| {
        const in: []const u8 = if (util.eql(p, "-"))
            (os.readAllFd(0) catch "")
        else
            os.readFile(p) orelse {
                util.err("could not open '{s}' for reading: {s}", .{ p, os.lastErr() });
                return false;
            };
        const mail = util.fmt("{s}/{d:0>4}", .{ state.dir, i + 1 });
        var out: Buf = .empty;
        const ok = f(&out, in);
        os.writeFile(mail, out.items, 0o666) catch {
            util.err("could not open '{s}' for writing: {s}", .{ mail, os.lastErr() });
            return false;
        };
        if (!ok) {
            util.err("could not parse patch '{s}'", .{p});
            return false;
        }
    }
    state.cur = 1;
    state.last = @intCast(paths.len);
    return true;
}

fn splitMailStgitSeries(state: *State, paths: []const []const u8) bool {
    if (paths.len != 1) {
        util.err("Only one StGIT patch series can be applied at once", .{});
        return false;
    }
    const series_dir = util.dirname(paths[0]);
    const data = os.readFile(paths[0]) orelse {
        util.err("could not open '{s}' for reading: {s}", .{ paths[0], os.lastErr() });
        return false;
    };
    var patches: std.ArrayList([]const u8) = .empty;
    var pos: usize = 0;
    while (readLf(data, &pos)) |line| {
        if (line.len > 0 and line[0] == '#') continue;
        patches.append(gpa, util.concat(&.{ series_dir, "/", line })) catch util.oom();
    }
    return splitMailConv(stgitPatchToMail, state, patches.items);
}

fn splitMail(state: *State, fmt_: PatchFormat, paths: []const []const u8, keep_cr0: i32) bool {
    var keep_cr = keep_cr0;
    if (keep_cr < 0) {
        keep_cr = if (repo_mod.cfg.getBool("am.keepcr") orelse false) 1 else 0;
    }
    return switch (fmt_) {
        .mbox => splitMailMbox(state, paths, keep_cr != 0, false),
        .stgit => splitMailConv(stgitPatchToMail, state, paths),
        .stgit_series => splitMailStgitSeries(state, paths),
        .hg => splitMailConv(hgPatchToMail, state, paths),
        .mboxrd => splitMailMbox(state, paths, keep_cr != 0, true),
        .unknown => util.die("BUG: invalid patch_format", .{}),
    };
}

fn headOid() ?Oid {
    return revparse.getOid("HEAD");
}

fn amSetup(state: *State, fmt0: PatchFormat, paths: []const []const u8, keep_cr: i32) void {
    var fmt_ = fmt0;
    if (fmt_ == .unknown) fmt_ = detectPatchFormat(paths);
    if (fmt_ == .unknown) {
        util.flushStdout();
        util.ewrite("Patch format detection failed.\n");
        os.exit(128);
    }
    if (!os.mkdir(state.dir, 0o777) and !os.isDir(state.dir))
        util.dieErrno("failed to create directory '{s}'", .{state.dir});
    refs.deleteRef("REBASE_HEAD", null, refs.F_NO_DEREF, null) catch {};

    if (!splitMail(state, fmt_, paths, keep_cr)) {
        amDestroy(state);
        util.die("Failed to split patches.", .{});
    }

    if (state.rebasing) state.threeway = true;

    writeStateBool(state, "threeway", state.threeway);
    writeStateBool(state, "quiet", state.quiet != 0);
    writeStateBool(state, "sign", state.signoff != 0);
    writeStateBool(state, "utf8", state.utf8);
    if (state.allow_rerere_autoupdate != 0)
        writeStateBool(state, "rerere-autoupdate", state.allow_rerere_autoupdate == 1);

    writeStateText(state, "keep", switch (state.keep) {
        KEEP_TRUE => "t",
        KEEP_NON_PATCH => "b",
        else => "f",
    });
    writeStateBool(state, "messageid", state.message_id);
    writeStateText(state, "scissors", if (state.scissors == SCISSORS_UNSET) "" else if (state.scissors != 0) "t" else "f");
    writeStateText(state, "quoted-cr", switch (state.quoted_cr) {
        .unset => "",
        .nowarn => "nowarn",
        .warn => "warn",
        .strip => "strip",
    });

    var sb: Buf = .empty;
    for (state.git_apply_opts.items) |a| {
        util.bufByte(&sb, ' ');
        util.sqQuote(&sb, a);
    }
    writeStateText(state, "apply-opt", sb.items);

    if (state.rebasing) writeStateText(state, "rebasing", "") else writeStateText(state, "applying", "");

    if (headOid()) |h| {
        writeStateText(state, "abort-safety", &hash.hex(h));
        if (!state.rebasing) refs.updateOrDie("am", "ORIG_HEAD", h, null, 0);
    } else {
        writeStateText(state, "abort-safety", "");
        if (!state.rebasing) refs.deleteRef("ORIG_HEAD", null, 0, null) catch {};
    }

    writeStateCount(state, "next", state.cur);
    writeStateCount(state, "last", state.last);
}

fn amNext(state: *State) void {
    state.author_name = null;
    state.author_email = null;
    state.author_date = null;
    state.msg = null;
    _ = os.unlink(amPath(state, "author-script"));
    _ = os.unlink(amPath(state, "final-commit"));
    state.orig_commit = null;
    _ = os.unlink(amPath(state, "original-commit"));
    refs.deleteRef("REBASE_HEAD", null, refs.F_NO_DEREF, null) catch {};
    if (headOid()) |h| writeStateText(state, "abort-safety", &hash.hex(h)) else writeStateText(state, "abort-safety", "");
    state.cur += 1;
    writeStateCount(state, "next", state.cur);
}

fn msgnum(state: *const State) []const u8 {
    return util.fmt("{d:0>4}", .{@as(u32, @intCast(@max(state.cur, 0)))});
}

fn headTreeOrEmpty() Oid {
    if (headOid()) |h| {
        if (objects.peelTo(h, .tree)) |t| return t;
    }
    return hash.fromHex(hash.empty_tree_hex).?;
}

/// repo_index_has_changes(): returns the space-separated list of changed
/// paths, or null if there are none.
fn indexChanges() ?[]const u8 {
    if (headOid()) |h| {
        const t = objects.peelTo(h, .tree) orelse return null;
        const ch = merge_ort.indexChangesAgainst(t);
        return if (ch.len > 0) ch else null;
    }
    const idx = index_mod.get();
    if (idx.entries.items.len == 0) return null;
    var b: Buf = .empty;
    for (idx.entries.items, 0..) |e, i| {
        if (i > 0) util.bufByte(&b, ' ');
        util.bufAppend(&b, e.path);
    }
    return b.items;
}

fn dieUserResolve(state: *const State) noreturn {
    util.flushStdout();
    if (state.resolvemsg) |m| {
        advice.adviseIfEnabled("mergeConflict", m);
    } else {
        const cmdline = if (state.interactive) "git am -i" else "git am";
        var b: Buf = .empty;
        util.bufPrint(&b, "When you have resolved this problem, run \"{s} --continue\".\n", .{cmdline});
        util.bufPrint(&b, "If you prefer to skip this patch, run \"{s} --skip\" instead.\n", .{cmdline});
        if (advice.enabled("amWorkDir") and isEmptyOrMissing(amPath(state, "patch")) and indexChanges() == null)
            util.bufPrint(&b, "To record the empty patch as an empty commit, run \"{s} --allow-empty\".\n", .{cmdline});
        util.bufPrint(&b, "To restore the original branch and stop patching, run \"{s} --abort\".", .{cmdline});
        advice.adviseIfEnabled("mergeConflict", b.items);
    }
    os.exit(128);
}

fn amAppendSignoff(state: *State) void {
    var b: Buf = .empty;
    util.bufAppend(&b, state.msg orelse "");
    cmd_commit.appendSignoff(&b, 0, false);
    state.msg = b.items;
}

/// Parse the mail with git-mailinfo. Returns true if it should be skipped.
fn parseMail(state: *State, mail: []const u8) bool {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, selfExe()) catch util.oom();
    argv.append(gpa, "mailinfo") catch util.oom();
    if (state.keep == KEEP_TRUE) argv.append(gpa, "-k") catch util.oom();
    if (state.keep == KEEP_NON_PATCH) argv.append(gpa, "-b") catch util.oom();
    if (state.message_id) argv.append(gpa, "-m") catch util.oom();
    if (state.scissors == 1) argv.append(gpa, "--scissors") catch util.oom();
    if (state.scissors == 0) argv.append(gpa, "--no-scissors") catch util.oom();
    switch (state.quoted_cr) {
        .unset => {},
        .nowarn => argv.append(gpa, "--quoted-cr=nowarn") catch util.oom(),
        .warn => argv.append(gpa, "--quoted-cr=warn") catch util.oom(),
        .strip => argv.append(gpa, "--quoted-cr=strip") catch util.oom(),
    }
    if (state.utf8) {
        const enc = @import("../pretty.zig").logOutputEncoding();
        argv.append(gpa, util.fmt("--encoding={s}", .{enc})) catch util.oom();
    } else {
        argv.append(gpa, "-n") catch util.oom();
    }
    argv.append(gpa, amPath(state, "msg")) catch util.oom();
    argv.append(gpa, amPath(state, "patch")) catch util.oom();

    const input = os.readFile(mail) orelse util.dieErrno("could not open '{s}' for reading", .{mail});
    util.flushStdout();
    const res = os.run(argv.items, .{ .stdin_data = input, .capture_stdout = true });
    if (res.status != 0) util.die("could not parse patch", .{});
    writeFileOrDie(amPath(state, "info"), res.stdout);

    var msg: Buf = .empty;
    var author_name: []const u8 = "";
    var author_email: []const u8 = "";
    var author_date: []const u8 = "";
    var pos: usize = 0;
    while (readLf(res.stdout, &pos)) |line| {
        if (util.startsWith(line, "Subject: ")) {
            if (msg.items.len > 0) util.bufByte(&msg, '\n');
            util.bufAppend(&msg, line[9..]);
        } else if (util.startsWith(line, "Author: ")) {
            author_name = util.concat(&.{ author_name, line[8..] });
        } else if (util.startsWith(line, "Email: ")) {
            author_email = util.concat(&.{ author_email, line[7..] });
        } else if (util.startsWith(line, "Date: ")) {
            author_date = util.concat(&.{ author_date, line[6..] });
        }
    }

    if (util.eql(author_name, "Mail System Internal Data")) return true;

    util.bufAppend(&msg, "\n\n");
    util.bufAppend(&msg, os.readFile(amPath(state, "msg")) orelse "");
    state.author_name = author_name;
    state.author_email = author_email;
    state.author_date = author_date;
    state.msg = util.stripspace(msg.items, null);
    return false;
}

fn getMailCommitOid(mail: []const u8) ?Oid {
    const data = os.readFile(mail) orelse util.dieErrno("could not open '{s}' for reading", .{mail});
    var pos: usize = 0;
    const line = readLf(data, &pos) orelse return null;
    if (!util.startsWith(line, "From ")) return null;
    if (line.len < 5 + hash.HEXSZ) return null;
    return hash.fromHex(line[5 .. 5 + hash.HEXSZ]);
}

fn findHeader(buf: []const u8, key: []const u8) ?[]const u8 {
    var pos: usize = 0;
    while (readLf(buf, &pos)) |line| {
        if (line.len == 0) return null;
        if (line.len > key.len and util.startsWith(line, key) and line[key.len] == ' ') return line[key.len + 1 ..];
    }
    return null;
}

fn getCommitInfo(state: *State, c: Oid) void {
    const obj = repo_mod.repo().odb().read(c) orelse util.die("could not parse {s}", .{&hash.hex(c)});
    const buffer = obj.data;
    const ident_line = findHeader(buffer, "author") orelse util.die("missing author line in commit {s}", .{&hash.hex(c)});
    const id = ident.split(ident_line) orelse util.die("invalid ident line: {s}", .{ident_line});
    state.author_name = id.name;
    state.author_email = id.email;
    state.author_date = date.showDate(id.time, date.tzMinutesToHhmm(id.tz), .{});
    const m = std.mem.indexOf(u8, buffer, "\n\n") orelse util.die("unable to parse commit {s}", .{&hash.hex(c)});
    state.msg = buffer[m + 2 ..];
}

fn writeCommitPatch(state: *const State, c: Oid) void {
    util.flushStdout();
    const res = os.run(&.{ selfExe(), "diff-tree", "-p", "--root", "--no-commit-id", "--full-index", "--binary", "--no-color", "--no-ext-diff", util.dupe(&hash.hex(c)) }, .{ .capture_stdout = true });
    writeFileOrDie(amPath(state, "patch"), res.stdout);
}

fn writeIndexPatch(state: *const State) void {
    util.flushStdout();
    const tree = headTreeOrEmpty();
    const res = os.run(&.{ selfExe(), "diff-index", "-p", "--cached", "--no-color", "--no-ext-diff", util.dupe(&hash.hex(tree)) }, .{ .capture_stdout = true });
    writeFileOrDie(amPath(state, "patch"), res.stdout);
}

fn parseMailRebase(state: *State, mail: []const u8) bool {
    const c = getMailCommitOid(mail) orelse util.die("could not parse {s}", .{mail});
    if (objects.typeOf(c) != .commit) util.die("could not parse {s}", .{mail});
    getCommitInfo(state, c);
    writeCommitPatch(state, c);
    state.orig_commit = c;
    writeStateText(state, "original-commit", &hash.hex(c));
    refs.updateOrDie("am", "REBASE_HEAD", c, null, refs.F_NO_DEREF);
    return false;
}

/// Applies the current patch in-process. Returns true on success.
fn runApply(state: *const State, index_file: ?[]const u8) bool {
    var ast: apply.State = .{};
    if (apply.initState(&ast, null) != 0) util.die("BUG: init_apply_state() failed", .{});
    var force_apply = false;
    var options: u32 = 0;
    const usage_a = [_][]const u8{"git apply [<options>] [<patch>...]"};
    const left = apply.parseOptions(state.git_apply_opts.items, &ast, &force_apply, &options, &usage_a);
    if (left.len != 0) util.die("unknown option passed through to git apply", .{});
    if (index_file) |f| {
        ast.index_file = f;
        ast.cached = true;
    } else ast.check_index = true;
    if (state.threeway and index_file == null) ast.apply_verbosity = apply.VERBOSITY_SILENT;
    if (apply.checkState(&ast, force_apply) != 0) util.die("BUG: check_apply_state() failed", .{});
    util.flushStdout();
    const res = apply.applyAllPatches(&ast, &.{amPath(state, "patch")}, options);
    apply.muted = false;
    if (res != 0) {
        index_mod.discard();
        return false;
    }
    index_mod.discard();
    if (index_file) |f| {
        const idx = index_mod.readFrom(f);
        _ = index_mod.swapCurrent(idx);
    }
    return true;
}

fn buildFakeAncestor(state: *const State, index_file: []const u8) bool {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, selfExe()) catch util.oom();
    argv.append(gpa, "apply") catch util.oom();
    argv.appendSlice(gpa, state.git_apply_opts.items) catch util.oom();
    argv.append(gpa, util.fmt("--build-fake-ancestor={s}", .{index_file})) catch util.oom();
    argv.append(gpa, amPath(state, "patch")) catch util.oom();
    util.flushStdout();
    return os.run(argv.items, .{}).status == 0;
}

fn writeIndexAsTree(idx: *index_mod.Index) ?Oid {
    return idx.writeTree(false);
}

/// Returns true on success.
fn fallBackThreeway(state: *const State, index_path: []const u8) bool {
    const our_commit = headOid();
    const our_tree = headTreeOrEmpty();

    if (!buildFakeAncestor(state, index_path)) {
        util.err("could not build fake ancestor", .{});
        return false;
    }
    index_mod.discard();
    const fake = index_mod.readFrom(index_path);
    _ = index_mod.swapCurrent(fake);
    const base = writeIndexAsTree(fake) orelse {
        util.err("Repository lacks necessary blobs to fall back on 3-way merge.", .{});
        return false;
    };

    say(state, false, "Using index info to reconstruct a base tree...");

    if (state.quiet == 0) {
        util.flushStdout();
        const tree_hex = if (our_commit) |c| util.dupe(&hash.hex(c)) else hash.empty_tree_hex;
        _ = os.run(&.{ selfExe(), "diff-index", "--cached", "--name-status", "--diff-filter=AM", "--no-color", tree_hex }, .{ .env = &.{.{ "GIT_INDEX_FILE", index_path }} });
    }

    if (!runApply(state, index_path)) {
        util.err("Did you hand edit your patch?\nIt does not apply to blobs recorded in its index.", .{});
        return false;
    }

    const their_idx = index_mod.get();
    const their_tree = writeIndexAsTree(their_idx) orelse {
        util.err("could not write tree", .{});
        return false;
    };

    say(state, false, "Falling back to patching base and 3-way merge...");

    index_mod.discard();
    const idx = index_mod.lockAndRead();

    var o = merge_ort.initMergeOptions(true);
    o.branch1 = "HEAD";
    o.branch2 = firstLine(state.msg);
    o.ancestor = "constructed fake ancestor";
    o.detect_directory_renames = .none;
    if (state.quiet != 0) o.verbosity = 0;

    util.flushStdout();
    const clean = merge_ort.mergeOrtNonrecursive(&o, our_tree, their_tree, base);
    util.flushStdout();
    if (clean < 0) {
        index_mod.get().rollback();
        util.err("Failed to merge in the changes.", .{});
        return false;
    }
    const cur = index_mod.get();
    if (cur != idx and cur.lock == null) cur.lock = idx.lock;
    cur.write();
    if (clean == 0) {
        util.err("Failed to merge in the changes.", .{});
        return false;
    }
    return true;
}

fn fmtIdent(name: []const u8, email: []const u8, date_str: ?[]const u8, who: ident.Who) []const u8 {
    const sname = ident.sanitize(name);
    if (name.len == 0) util.die("empty ident name (for <{s}>) not allowed", .{email});
    if (sname.len == 0) util.die("name consists only of disallowed characters: {s}", .{name});
    var dstr: []const u8 = undefined;
    if (date_str) |d| {
        if (d.len > 0) {
            const p = date.parseDate(d) orelse util.die("invalid date format: {s}", .{d});
            dstr = util.fmt("{d} {s}", .{ p.time, date.formatTz(p.tz) });
        } else dstr = date.datestamp();
    } else dstr = date.datestamp();
    _ = who;
    return util.fmt("{s} <{s}> {s}", .{ sname, ident.sanitize(email), dstr });
}

fn doCommit(state: *const State) void {
    if (!state.no_verify) {
        util.flushStdout();
        if (hook.run("pre-applypatch", &.{}, .{}) != 0) os.exit(1);
    }
    index_mod.discard();
    const idx = index_mod.get();
    const tree = idx.writeTree(false) orelse util.die("git write-tree failed to write a tree", .{});

    var parents: std.ArrayList(Oid) = .empty;
    var old: ?Oid = null;
    if (revparse.getCommit("HEAD")) |p| {
        old = p;
        parents.append(gpa, p) catch util.oom();
    } else {
        say(state, true, "applying to an empty history");
    }

    const author = fmtIdent(state.author_name orelse "", state.author_email orelse "", if (state.ignore_date) null else state.author_date, .author);
    var committer: ?[]const u8 = null;
    if (state.committer_date_is_author_date) {
        const full = ident.committerStrict();
        const sp = ident.split(full).?;
        var dstr: []const u8 = date.datestamp();
        if (!state.ignore_date) {
            if (state.author_date) |d| {
                if (d.len > 0) {
                    const p = date.parseDate(d) orelse util.die("invalid date format: {s}", .{d});
                    dstr = util.fmt("{d} {s}", .{ p.time, date.formatTz(p.tz) });
                }
            }
        }
        committer = util.fmt("{s} <{s}> {s}", .{ sp.name, sp.email, dstr });
    }

    const msg = state.msg orelse "";
    const c = commit_mod.create(.{ .tree = tree, .parents = parents.items, .message = msg, .author = author, .committer = committer });

    const reflog_action = os.getenv("GIT_REFLOG_ACTION") orelse "am";
    const reflog_msg = util.fmt("{s}: {s}", .{ reflog_action, firstLine(msg) });
    refs.updateOrDie(reflog_msg, "HEAD", c, old, 0);

    if (state.rebasing) {
        const line = util.fmt("{s} {s}\n", .{ &hash.hex(state.orig_commit orelse hash.zero), &hash.hex(c) });
        os.appendFile(amPath(state, "rewritten"), line) catch util.dieErrno("could not open '{s}' for writing", .{amPath(state, "rewritten")});
    }

    util.flushStdout();
    _ = hook.run("post-applypatch", &.{}, .{});
}

fn validateResumeState(state: *const State) void {
    if (state.msg == null) util.die("cannot resume: {s} does not exist.", .{amPath(state, "final-commit")});
    if (state.author_name == null or state.author_email == null or state.author_date == null)
        util.die("cannot resume: {s} does not exist.", .{amPath(state, "author-script")});
}

fn readStdinLine() ?[]const u8 {
    var b: Buf = .empty;
    var ch: [1]u8 = undefined;
    while (true) {
        const n = std.c.read(0, &ch, 1);
        if (n <= 0) {
            if (b.items.len == 0) return null;
            return b.items;
        }
        util.bufByte(&b, ch[0]);
        if (ch[0] == '\n' or b.items.len >= 63) return b.items;
    }
}

/// Returns true if the patch should be skipped.
fn doInteractive(state: *State) bool {
    while (true) {
        util.out("Commit Body is:\n");
        util.out("--------------------------\n");
        util.out(state.msg orelse "");
        util.out("--------------------------\n");
        util.out("Apply? [y]es/[n]o/[e]dit/[v]iew patch/[a]ccept all: ");
        util.flushStdout();
        const reply = readStdinLine() orelse util.die("unable to read from stdin; aborting", .{});
        const c = if (reply.len > 0) reply[0] else 0;
        if (c == 'y' or c == 'Y') return false;
        if (c == 'a' or c == 'A') {
            state.interactive = false;
            return false;
        }
        if (c == 'n' or c == 'N') return true;
        if (c == 'e' or c == 'E') {
            const path = amPath(state, "final-commit");
            if (!editor.launch(path, &.{})) {
                if (os.readFile(path)) |m| state.msg = m;
            }
        } else if (c == 'v' or c == 'V') {
            const pager = os.getenv("GIT_PAGER") orelse repo_mod.cfg.get("core.pager") orelse os.getenv("PAGER") orelse "cat";
            _ = os.run(&.{ util.concat(&.{ pager, " \"$@\"" }), amPath(state, "patch") }, .{ .use_shell = true });
        }
    }
}

fn amRun(state: *State, resume0: bool) void {
    var resume_ = resume0;
    _ = os.unlink(amPath(state, "dirtyindex"));

    {
        index_mod.discard();
        const idx = index_mod.lockAndRead();
        _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
        idx.write();
    }

    if (indexChanges()) |ch| {
        writeStateBool(state, "dirtyindex", true);
        util.die("Dirty index: cannot apply patches (dirty: {s})", .{ch});
    }

    while (state.cur <= state.last) {
        const mail = amPath(state, msgnum(state));
        blk: {
            if (!os.exists(mail)) break :blk;

            if (resume_) {
                validateResumeState(state);
            } else {
                const skip = if (state.rebasing) parseMailRebase(state, mail) else parseMail(state, mail);
                if (skip) break :blk;
                if (state.signoff != 0) amAppendSignoff(state);
                writeAuthorScript(state);
                writeCommitMsg(state);
            }

            if (state.interactive and doInteractive(state)) break :blk;

            var to_keep = false;
            if (isEmptyOrMissing(amPath(state, "patch"))) {
                switch (state.empty_type) {
                    .drop => {
                        say(state, false, util.fmt("Skipping: {s}", .{firstLine(state.msg)}));
                        break :blk;
                    },
                    .keep => {
                        to_keep = true;
                        say(state, false, util.fmt("Creating an empty commit: {s}", .{firstLine(state.msg)}));
                    },
                    .stop => {
                        util.out("Patch is empty.\n");
                        dieUserResolve(state);
                    },
                }
            }

            if (runApplypatchMsgHook(state) != 0) os.exit(1);

            if (!to_keep) {
                say(state, false, util.fmt("Applying: {s}", .{firstLine(state.msg)}));

                var ok = runApply(state, null);
                if (!ok and state.threeway) {
                    ok = fallBackThreeway(state, amPath(state, "patch-merge-index"));
                    if (ok) {
                        index_mod.discard();
                        if (indexChanges() == null) {
                            say(state, false, "No changes -- Patch already applied.");
                            break :blk;
                        }
                    }
                }
                if (!ok) {
                    util.out(util.fmt("Patch failed at {s} {s}\n", .{ msgnum(state), firstLine(state.msg) }));
                    util.flushStdout();
                    if (advice.enabled("amWorkDir"))
                        advice.advise("Use 'git am --show-current-patch=diff' to see the failed patch");
                    dieUserResolve(state);
                }
            }

            doCommit(state);
        }
        // next:
        amNext(state);
        if (resume_) amLoad(state);
        resume_ = false;
    }

    if (!isEmptyOrMissing(amPath(state, "rewritten"))) {
        runPostRewriteHook(state);
    }

    if (!state.rebasing) {
        amDestroy(state);
    }
}

fn amResolve(state: *State, allow_empty: bool) void {
    validateResumeState(state);
    say(state, false, util.fmt("Applying: {s}", .{firstLine(state.msg)}));

    if (indexChanges() == null) {
        if (allow_empty and isEmptyOrMissing(amPath(state, "patch"))) {
            util.out("No changes - recorded it as an empty commit.\n");
        } else {
            util.out("No changes - did you forget to use 'git add'?\n" ++
                "If there is nothing left to stage, chances are that something else\n" ++
                "already introduced the same changes; you might want to skip this patch.\n");
            dieUserResolve(state);
        }
    }

    if (index_mod.get().unmerged()) {
        util.out("You still have unmerged paths in your index.\n" ++
            "You should 'git add' each file with resolved conflicts to mark them as such.\n" ++
            "You might run `git rm` on a file to accept \"deleted by them\" for it.\n");
        dieUserResolve(state);
    }

    var skip = false;
    if (state.interactive) {
        writeIndexPatch(state);
        skip = doInteractive(state);
    }
    if (!skip) doCommit(state);

    amNext(state);
    amLoad(state);
    amRun(state, false);
}

fn fastForwardTo(head: Oid, remote: Oid, reset: bool) bool {
    index_mod.discard();
    const idx = index_mod.lockAndRead();
    if (reset) _ = ut.readIndexUnmerged(idx);
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
    var o = ut.Options{};
    o.head_idx = 1;
    o.src_index = idx;
    o.dst_index = idx;
    o.update = true;
    o.merge = true;
    o.reset = if (reset) .protect_untracked else .none;
    o.preserve_ignored = false;
    o.func = &ut.twowayMerge;
    if (ut.unpackTrees(&.{ head, remote }, &o) != 0) {
        idx.rollback();
        return false;
    }
    idx.write();
    return true;
}

fn mergeTree(tree: Oid) bool {
    index_mod.discard();
    const idx = index_mod.lockAndRead();
    var o = ut.Options{};
    o.head_idx = 1;
    o.src_index = idx;
    o.dst_index = idx;
    o.merge = true;
    o.func = &ut.onewayMerge;
    if (ut.unpackTrees(&.{tree}, &o) != 0) {
        idx.rollback();
        return false;
    }
    idx.write();
    return true;
}

fn cleanIndex(head: Oid, remote: Oid) bool {
    const head_tree = objects.peelTo(head, .tree) orelse {
        util.err("Could not parse object '{s}'.", .{&hash.hex(head)});
        return false;
    };
    const remote_tree = objects.peelTo(remote, .tree) orelse {
        util.err("Could not parse object '{s}'.", .{&hash.hex(remote)});
        return false;
    };
    if (!fastForwardTo(head_tree, head_tree, true)) return false;
    index_mod.discard();
    const idx = index_mod.get();
    const index_tree = idx.writeTree(false) orelse return false;
    if (!fastForwardTo(index_tree, remote_tree, false)) return false;
    if (!mergeTree(remote_tree)) return false;
    branchstate.removeBranchState(false);
    return true;
}

fn amSkip(state: *State) void {
    const head = headOid() orelse hash.fromHex(hash.empty_tree_hex).?;
    if (!cleanIndex(head, head)) util.die("failed to clean index", .{});
    if (state.rebasing) {
        const line = util.fmt("{s} {s}\n", .{ &hash.hex(state.orig_commit orelse hash.zero), &hash.hex(head) });
        os.appendFile(amPath(state, "rewritten"), line) catch {};
    }
    amNext(state);
    amLoad(state);
    amRun(state, false);
}

fn safeToAbort(state: *const State) bool {
    if (os.exists(amPath(state, "dirtyindex"))) return false;
    var abort_safety: Oid = hash.zero;
    if (readStateFile(state, "abort-safety", true)) |s| {
        if (s.len > 0) abort_safety = hash.fromHex(s) orelse util.die("could not parse {s}", .{amPath(state, "abort-safety")});
    }
    const head = headOid() orelse hash.zero;
    if (hash.eql(head, abort_safety)) return true;
    util.warn("You seem to have moved HEAD since the last 'am' failure.\nNot rewinding to ORIG_HEAD", .{});
    return false;
}

fn amAbort(state: *State) void {
    if (!safeToAbort(state)) {
        amDestroy(state);
        return;
    }
    const empty = hash.fromHex(hash.empty_tree_hex).?;
    const r = refs.resolveFull("HEAD", false);
    var curr_branch: ?[]const u8 = null;
    var curr_head: ?Oid = null;
    if (!r.broken) {
        curr_branch = r.name;
        if (!r.missing and !hash.isZero(r.oid)) curr_head = r.oid;
    }
    const orig_head = revparse.getOid("ORIG_HEAD");
    if (!cleanIndex(curr_head orelse empty, orig_head orelse empty)) util.die("failed to clean index", .{});
    if (orig_head) |oh| {
        refs.updateOrDie("am --abort", "HEAD", oh, curr_head, 0);
    } else if (curr_branch) |b| {
        refs.deleteRef(b, null, refs.F_NO_DEREF, null) catch {};
    }
    amDestroy(state);
}

fn showPatch(state: *State, mode: Resume) u8 {
    if (state.orig_commit) |oc| {
        util.flushStdout();
        const res = os.run(&.{ selfExe(), "show", util.dupe(&hash.hex(oc)), "--" }, .{});
        return res.status;
    }
    const patch_path = switch (mode) {
        .show_raw => amPath(state, msgnum(state)),
        .show_diff => amPath(state, "patch"),
        else => util.die("BUG: invalid mode for --show-current-patch", .{}),
    };
    const data = os.readFile(patch_path) orelse util.dieErrno("failed to read '{s}'", .{patch_path});
    commands.setupPager();
    util.out(data);
    util.flushStdout();
    return 0;
}

// ---------------------------------------------------------------------------
// option parsing

var g_state: *State = undefined;
var g_resume: Resume = .none;
var g_resume_opt: ?*const po.Opt = null;
var g_patch_format: PatchFormat = .unknown;
var g_binary: bool = false;
var g_binary_set: bool = false;

fn optDisplayName(o: *const po.Opt) []const u8 {
    if (o.long.len > 0) return util.fmt("--{s}", .{o.long});
    return util.fmt("-{c}", .{o.short});
}

fn setResume(o: *const po.Opt, v: Resume) void {
    if (g_resume != .none and g_resume != v) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ optDisplayName(o), optDisplayName(g_resume_opt.?) });
        os.exit(129);
    }
    g_resume = v;
    g_resume_opt = o;
}

fn cmdmodeCb(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    setResume(o, @enumFromInt(o.val));
}

fn showPatchCb(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse {
        setResume(o, .show_raw);
        return;
    };
    if (util.eql(a, "raw")) {
        setResume(o, .show_raw);
    } else if (util.eql(a, "diff")) {
        setResume(o, .show_diff);
    } else {
        util.err("invalid value for '{s}': '{s}'", .{ "--show-current-patch", a });
        os.exit(129);
    }
}

fn passthruCb(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    var b: Buf = .empty;
    if (o.long.len > 0) {
        util.bufAppend(&b, if (unset) "--no-" else "--");
        util.bufAppend(&b, o.long);
        if (arg) |a| {
            util.bufByte(&b, '=');
            util.bufAppend(&b, a);
        }
    } else if (o.short != 0 and !unset) {
        util.bufByte(&b, '-');
        util.bufByte(&b, o.short);
        if (arg) |a| util.bufAppend(&b, a);
    } else os.exit(129);
    g_state.git_apply_opts.append(gpa, b.items) catch util.oom();
}

fn quotedCrCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse "";
    g_state.quoted_cr = parseQuotedCr(a) orelse {
        util.err("bad action '{s}' for '{s}'", .{ a, "--quoted-cr" });
        os.exit(129);
    };
}

fn emptyCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse "";
    if (util.eql(a, "stop")) {
        g_state.empty_type = .stop;
    } else if (util.eql(a, "drop")) {
        g_state.empty_type = .drop;
    } else if (util.eql(a, "keep")) {
        g_state.empty_type = .keep;
    } else {
        util.err("invalid value for '{s}': '{s}'", .{ "--empty", a });
        os.exit(129);
    }
}

fn patchFormatCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        g_patch_format = .unknown;
        return;
    }
    const a = arg orelse "";
    if (util.eql(a, "mbox")) {
        g_patch_format = .mbox;
    } else if (util.eql(a, "stgit")) {
        g_patch_format = .stgit;
    } else if (util.eql(a, "stgit-series")) {
        g_patch_format = .stgit_series;
    } else if (util.eql(a, "hg")) {
        g_patch_format = .hg;
    } else if (util.eql(a, "mboxrd")) {
        g_patch_format = .mboxrd;
    } else {
        util.err("invalid value for '{s}': '{s}'", .{ "--patch-format", a });
        os.exit(129);
    }
}

fn scissorsCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    g_state.scissors = if (unset) 0 else 1;
}

fn binaryCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    g_binary = !unset;
    g_binary_set = true;
}

fn rerereCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    g_state.allow_rerere_autoupdate = if (unset) 2 else 1;
}

const usage_str = [_][]const u8{
    "git am [<options>] [(<mbox> | <Maildir>)...]",
    "git am [<options>] (--continue | --skip | --abort)",
};

fn passthru(short: u8, long: []const u8, argh: []const u8, noarg: bool) po.Opt {
    return .{ .short = short, .long = long, .kind = .callback, .cb = dummyCb, .cbx = passthruCb, .argh = argh, .noarg = noarg, .help = "pass it through git-apply" };
}

fn dummyCb(_: ?[]const u8, _: bool) void {}

fn cmdmode(short: u8, long: []const u8, v: Resume, help: []const u8) po.Opt {
    return .{ .short = short, .long = long, .kind = .callback, .cb = dummyCb, .cbx = cmdmodeCb, .noarg = true, .noneg = true, .val = @intFromEnum(v), .help = help };
}

pub fn cmdAm(args: []const []const u8) u8 {
    var state: State = .{};
    g_state = &state;
    state.dir = repo_mod.repo().gitPath("rebase-apply");
    state.prec = 4;
    if (repo_mod.cfg.getBool("am.threeway")) |b| state.threeway = b;
    if (repo_mod.cfg.getBool("am.messageid")) |b| state.message_id = b;
    if (repo_mod.cfg.getBool("commit.gpgsign")) |b| state.sign_commit = if (b) "" else null;

    var keep_cr: i32 = -1;

    const in_progress = amInProgress(&state);
    if (in_progress) amLoad(&state);

    const options = [_]po.Opt{
        po.boolean('i', "interactive", &state.interactive, "run interactively"),
        po.boolean('n', "no-verify", &state.no_verify, "bypass pre-applypatch and applypatch-msg hooks"),
        .{ .short = 'b', .long = "binary", .kind = .callback, .cb = binaryCb, .noarg = true, .hidden = true, .help = "historical option -- no-op" },
        po.boolean('3', "3way", &state.threeway, "allow fall back on 3way merging if needed"),
        po.counter('q', "quiet", &state.quiet, "be quiet"),
        po.setInt('s', "signoff", &state.signoff, SIGNOFF_EXPLICIT, "add a Signed-off-by trailer to the commit message"),
        po.boolean('u', "utf8", &state.utf8, "recode into utf8 (default)"),
        po.setInt('k', "keep", &state.keep, KEEP_TRUE, "pass -k flag to git-mailinfo"),
        po.setInt(0, "keep-non-patch", &state.keep, KEEP_NON_PATCH, "pass -b flag to git-mailinfo"),
        po.boolean('m', "message-id", &state.message_id, "pass -m flag to git-mailinfo"),
        po.setInt(0, "keep-cr", &keep_cr, 1, "pass --keep-cr flag to git-mailsplit for mbox format"),
        .{ .short = 'c', .long = "scissors", .kind = .callback, .cb = scissorsCb, .noarg = true, .help = "strip everything before a scissors line" },
        .{ .long = "quoted-cr", .kind = .callback, .cb = quotedCrCb, .argh = "action", .noneg = true, .help = "pass it through git-mailinfo" },
        passthru(0, "whitespace", "action", false),
        passthru(0, "ignore-space-change", "", true),
        passthru(0, "ignore-whitespace", "", true),
        passthru(0, "directory", "root", false),
        passthru(0, "exclude", "path", false),
        passthru(0, "include", "path", false),
        passthru('C', "", "n", false),
        passthru('p', "", "num", false),
        .{ .long = "patch-format", .kind = .callback, .cb = patchFormatCb, .argh = "format", .help = "format the patch(es) are in" },
        passthru(0, "reject", "", true),
        po.string(0, "resolvemsg", &state.resolvemsg, "", "override error message when patch failure occurs"),
        cmdmode(0, "continue", .resolved, "continue applying patches after resolving a conflict"),
        cmdmode('r', "resolved", .resolved, "synonyms for --continue"),
        cmdmode(0, "skip", .skip, "skip the current patch"),
        cmdmode(0, "abort", .abort, "restore the original branch and abort the patching operation"),
        cmdmode(0, "quit", .quit, "abort the patching operation but keep HEAD where it is"),
        .{ .long = "show-current-patch", .kind = .callback, .cb = dummyCb, .cbx = showPatchCb, .optarg = true, .noneg = true, .literal_argh = true, .argh = "(diff|raw)", .help = "show the patch being applied" },
        cmdmode(0, "retry", .apply, "try to apply current patch again"),
        cmdmode(0, "allow-empty", .allow_empty, "record the empty patch as an empty commit"),
        po.boolean(0, "committer-date-is-author-date", &state.committer_date_is_author_date, "lie about committer date"),
        po.boolean(0, "ignore-date", &state.ignore_date, "use current timestamp for author date"),
        .{ .long = "rerere-autoupdate", .kind = .callback, .cb = rerereCb, .noarg = true, .help = "update the index with reused conflict resolution if possible" },
        po.optString('S', "gpg-sign", &state.sign_commit, "", "key-id", "GPG-sign commits"),
        .{ .long = "empty", .kind = .callback, .cb = emptyCb, .argh = "(stop|drop|keep)", .literal_argh = true, .noneg = true, .help = "how to handle empty patches" },
        .{ .long = "rebasing", .kind = .boolean, .b = &state.rebasing, .hidden = true, .help = "(internal use for git-rebase)" },
    };

    const rest = po.parse(args[1..], &options, &usage_str, .{});

    if (g_binary_set)
        util.ewrite("The -b/--binary option has been a no-op for long time, and\nit will be removed. Please do not use it anymore.\n");

    _ = ident.committerStrict();

    _ = index_mod.get();

    var resume_mode = g_resume;

    if (in_progress) {
        if (rest.len > 0 or (resume_mode == .none and !os.isatty(0)))
            util.die("previous rebase directory {s} still exists but mbox given.", .{state.dir});
        if (resume_mode == .none) resume_mode = .apply;
        if (state.signoff == SIGNOFF_EXPLICIT) amAppendSignoff(&state);
    } else {
        if (os.exists(state.dir) and !state.rebasing) {
            if (resume_mode == .abort or resume_mode == .quit) {
                amDestroy(&state);
                return 0;
            }
            util.die("Stray {s} directory found.\nUse \"git am --abort\" to remove it.", .{state.dir});
        }
        if (resume_mode != .none) util.die("Resolve operation not in progress, we are not resuming.", .{});

        const prefix = repo_mod.repo().prefix;
        var paths: std.ArrayList([]const u8) = .empty;
        for (rest) |a| {
            if (a.len > 0 and a[0] == '/' or prefix.len == 0)
                paths.append(gpa, a) catch util.oom()
            else
                paths.append(gpa, util.concat(&.{ prefix, a })) catch util.oom();
        }
        if (state.interactive and paths.items.len == 0)
            util.die("interactive mode requires patches on the command line", .{});
        amSetup(&state, g_patch_format, paths.items, keep_cr);
    }

    var ret: u8 = 0;
    switch (resume_mode) {
        .none => amRun(&state, false),
        .apply => amRun(&state, true),
        .resolved, .allow_empty => amResolve(&state, resume_mode == .allow_empty),
        .skip => amSkip(&state),
        .abort => amAbort(&state),
        .quit => amDestroy(&state),
        .show_raw, .show_diff => ret = showPatch(&state, resume_mode),
    }
    util.flushStdout();
    return ret;
}
