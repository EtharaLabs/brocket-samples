//! git repack (builtin/repack.c, repack.c, repack-cruft.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const proc = @import("../proc.zig");
const serverinfo = @import("../serverinfo.zig");
const midx_lib = @import("../midx.zig");
const hash = @import("../hash.zig");
const gpa = util.gpa;

const ALL_INTO_ONE: i32 = 1;
const LOOSEN_UNREACHABLE: i32 = 2;
const PACK_CRUFT: i32 = 4;

const usage = [_][]const u8{
    "git repack [-a] [-A] [-d] [-f] [-F] [-l] [-n] [-q] [-b] [-m]\n" ++
        "[--window=<n>] [--depth=<n>] [--threads=<n>] [--keep-pack=<pack-name>]\n" ++
        "[--write-midx[=<mode>]] [--name-hash-version=<n>] [--path-walk]\n" ++
        "[--filter=<filter-spec>] [--drop-filtered [--dry-run]]",
};

var pack_everything: i32 = 0;
var delete_redundant = false;
var no_reuse_delta = false;
var no_reuse_object = false;
var quiet = false;
var local = false;
var run_update_server_info: i32 = 1;
var write_bitmaps: i32 = -1;
var delta_islands = false;
var unpack_unreachable: ?[]const u8 = null;
var keep_unreachable = false;
var opt_window: ?[]const u8 = null;
var opt_window_memory: ?[]const u8 = null;
var opt_depth: ?[]const u8 = null;
var opt_threads: ?[]const u8 = null;
var max_pack_size: ?[]const u8 = null;
var max_cruft_size: ?[]const u8 = null;
var combine_cruft_below_size: ?[]const u8 = null;
var cruft_expiration: ?[]const u8 = null;
var pack_kept_objects: i32 = -1;
var pack_kept_bool = false;
var pack_kept_given = false;
var keep_pack_list: std.ArrayList([]const u8) = .empty;
var geometric: i32 = 0;
var write_midx: ?[]const u8 = null;
var write_midx_m: i32 = 0;
var name_hash_version: i32 = 0;
var path_walk = false;
var filter: ?[]const u8 = null;
var expire_to: ?[]const u8 = null;
var filter_to: ?[]const u8 = null;
var drop_filtered = false;
var dry_run = false;
var delta_base_offset = true;
var midx_must_contain_cruft = true;

/// existing.midx_packs: basenames ("pack-X.pack") of packs in the MIDX.
fn midxPacks() []const []const u8 {
    const m = midx_lib.get(repo_mod.repo().odb().objects_dir) orelse return &.{};
    var l: std.ArrayList([]const u8) = .empty;
    var x: ?*midx_lib.Midx = m;
    while (x) |mm| : (x = mm.base) {
        for (mm.pack_names) |n| {
            const b = if (util.endsWith(n, ".idx")) util.concat(&.{ n[0 .. n.len - 4], ".pack" }) else n;
            l.append(gpa, b) catch util.oom();
        }
    }
    return l.items;
}

/// midx_has_unknown_packs(): note that the C version compares "pack-X.pack"
/// names against ".idx" names, so any MIDX'd pack counts as unknown.
fn midxHasUnknownPacks() bool {
    return midxPacks().len > 0;
}

fn bitmapCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    write_bitmaps = if (unset) 0 else 1;
    write_bitmaps_given = true;
}
var write_bitmaps_given = false;
fn packKeptCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    pack_kept_objects = if (unset) 0 else 1;
}

const options = [_]po.Opt{
    po.bit('a', "", &pack_everything, ALL_INTO_ONE, "pack everything in a single pack"),
    po.bit('A', "", &pack_everything, LOOSEN_UNREACHABLE | ALL_INTO_ONE, "same as -a, and turn unreachable objects loose"),
    po.bit(0, "cruft", &pack_everything, PACK_CRUFT, "same as -a, pack unreachable cruft objects separately"),
    po.string(0, "cruft-expiration", &cruft_expiration, "approxidate", "with --cruft, expire objects older than this"),
    po.noNeg(po.string(0, "combine-cruft-below-size", &combine_cruft_below_size, "n", "with --cruft, only repack cruft packs smaller than this")),
    po.noNeg(po.string(0, "max-cruft-size", &max_cruft_size, "n", "with --cruft, limit the size of new cruft packs")),
    po.boolean('d', "", &delete_redundant, "remove redundant packs, and run git-prune-packed"),
    po.boolean('f', "", &no_reuse_delta, "pass --no-reuse-delta to git-pack-objects"),
    po.boolean('F', "", &no_reuse_object, "pass --no-reuse-object to git-pack-objects"),
    po.integer(0, "name-hash-version", &name_hash_version, "n", "specify the name hash version to use for grouping similar objects by path"),
    po.boolean(0, "path-walk", &path_walk, "pass --path-walk to git-pack-objects"),
    .{ .short = 'n', .kind = .negbit, .i = &run_update_server_info, .val = 1, .help = "do not run git-update-server-info" },
    po.boolean('q', "quiet", &quiet, "be quiet"),
    po.boolean('l', "local", &local, "pass --local to git-pack-objects"),
    .{ .short = 'b', .long = "write-bitmap-index", .kind = .callback, .cb = bitmapCb, .noarg = true, .help = "write bitmap index" },
    po.boolean('i', "delta-islands", &delta_islands, "pass --delta-islands to git-pack-objects"),
    po.string(0, "unpack-unreachable", &unpack_unreachable, "approxidate", "with -A, do not loosen objects older than this"),
    po.boolean('k', "keep-unreachable", &keep_unreachable, "with -a, repack unreachable objects"),
    po.string(0, "window", &opt_window, "n", "size of the window used for delta compression"),
    po.string(0, "window-memory", &opt_window_memory, "bytes", "same as the above, but limit memory size instead of entries count"),
    po.string(0, "depth", &opt_depth, "n", "limits the maximum delta depth"),
    po.string(0, "threads", &opt_threads, "n", "limits the maximum number of threads"),
    po.noNeg(po.string(0, "max-pack-size", &max_pack_size, "n", "maximum size of each packfile")),
    po.string(0, "filter", &filter, "args", "object filtering"),
    .{ .long = "pack-kept-objects", .kind = .callback, .cb = packKeptCb, .noarg = true, .help = "repack objects in packs marked with .keep" },
    po.list(0, "keep-pack", &keep_pack_list, "name", "do not repack this pack"),
    po.integer('g', "geometric", &geometric, "n", "find a geometric progression with factor <N>"),
    .{ .long = "write-midx", .kind = .string, .s = &write_midx, .optarg = true, .def = "", .argh = "mode", .help = "write a multi-pack index of the resulting packs" },
    .{ .short = 'm', .kind = .set_int, .i = &write_midx_m, .val = 1, .hidden = true, .help = "write a multi-pack index of the resulting packs" },
    po.string(0, "expire-to", &expire_to, "dir", "pack prefix to store a pack containing pruned objects"),
    po.string(0, "filter-to", &filter_to, "dir", "pack prefix to store a pack containing filtered out objects"),
    po.boolean(0, "drop-filtered", &drop_filtered, "delete filtered out objects (requires --filter)"),
    po.boolean(0, "dry-run", &dry_run, "only show which objects would be dropped"),
};

const Existing = struct {
    kept: std.ArrayList([]const u8) = .empty,
    non_kept: std.ArrayList([]const u8) = .empty,
    cruft: std.ArrayList([]const u8) = .empty,
};

fn lessStr(_: void, a: []const u8, b: []const u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

fn collectExisting(packdir: []const u8) Existing {
    var ex: Existing = .{};
    const odb = repo_mod.repo().odb();
    odb.reloadPacks();
    for (odb.packs.items) |p| {
        if (!util.startsWith(p.idx_path, util.concat(&.{ packdir, "/" }))) continue;
        const bn = util.basename(p.pack_path);
        const base = bn[0 .. bn.len - 5];
        const full = p.pack_path[0 .. p.pack_path.len - 5];
        var kept = false;
        for (keep_pack_list.items) |k| {
            if (util.eql(k, bn)) kept = true;
        }
        if (kept or os.exists(util.concat(&.{ full, ".keep" }))) {
            ex.kept.append(gpa, base) catch util.oom();
        } else if (os.exists(util.concat(&.{ full, ".mtimes" }))) {
            ex.cruft.append(gpa, base) catch util.oom();
        } else ex.non_kept.append(gpa, base) catch util.oom();
    }
    std.mem.sort([]const u8, ex.kept.items, {}, lessStr);
    std.mem.sort([]const u8, ex.non_kept.items, {}, lessStr);
    std.mem.sort([]const u8, ex.cruft.items, {}, lessStr);
    return ex;
}

fn preparePackObjects(argv: *std.ArrayList([]const u8), out: []const u8, cruft_args: bool) void {
    const a = struct {
        fn push(l: *std.ArrayList([]const u8), s: []const u8) void {
            l.append(gpa, s) catch util.oom();
        }
    }.push;
    a(argv, proc.gitBinary());
    a(argv, "pack-objects");
    const cfg = &repo_mod.cfg;
    var w = opt_window;
    var wm = opt_window_memory;
    var d = opt_depth;
    var t = opt_threads;
    var mps = max_pack_size;
    if (cruft_args) {
        if (cfg.get("repack.cruftwindow")) |v| w = v;
        if (cfg.get("repack.cruftwindowmemory")) |v| wm = v;
        if (cfg.get("repack.cruftdepth")) |v| d = v;
        if (cfg.get("repack.cruftthreads")) |v| t = v;
        if (max_cruft_size) |v| mps = v;
    }
    if (w) |v| a(argv, util.concat(&.{ "--window=", v }));
    if (wm) |v| a(argv, util.concat(&.{ "--window-memory=", v }));
    if (d) |v| a(argv, util.concat(&.{ "--depth=", v }));
    if (t) |v| a(argv, util.concat(&.{ "--threads=", v }));
    if (mps) |v| {
        if (!util.eql(v, "0")) a(argv, util.concat(&.{ "--max-pack-size=", v }));
    }
    if (!cruft_args) {
        if (no_reuse_delta) a(argv, "--no-reuse-delta");
        if (no_reuse_object) a(argv, "--no-reuse-object");
        if (name_hash_version != 0) a(argv, util.fmt("--name-hash-version={d}", .{name_hash_version}));
        if (path_walk) a(argv, "--path-walk");
    }
    if (local) a(argv, "--local");
    if (quiet) a(argv, "--quiet");
    if (delta_base_offset) a(argv, "--delta-base-offset");
    if (cruft_args or pack_kept_objects == 0) a(argv, "--honor-pack-keep");
    a(argv, out);
}

/// repack_promisor_objects(): every object in a promisor pack goes into a
/// new promisor pack.
fn repackPromisorObjects(packtmp: []const u8, names: *std.ArrayList([]const u8), to_drop: ?*const hash.OidSet) void {
    const odb = repo_mod.repo().odb();
    odb.loadPacks();
    var in: util.Buf = .empty;
    var seen: hash.OidSet = .empty;
    for (odb.packs.items) |p| {
        if (!@import("../promisor.zig").isPromisorPack(p.pack_path)) continue;
        var i: u32 = 0;
        while (i < p.num) : (i += 1) {
            const oid = p.oidAt(i);
            if (seen.contains(oid)) continue;
            seen.put(gpa, oid, {}) catch util.oom();
            if (to_drop) |d| if (d.contains(oid)) continue;
            util.bufPrint(&in, "{s}\n", .{hash.hex(oid)});
        }
    }
    if (in.items.len == 0) return;
    var argv: std.ArrayList([]const u8) = .empty;
    preparePackObjects(&argv, packtmp, false);
    const start = names.items.len;
    if (!finishPackObjects(argv.items, in.items, names, true))
        util.die("could not finish pack-objects to repack promisor objects", .{});
    for (names.items[start..]) |n| {
        const pname = util.fmt("{s}-{s}.promisor", .{ packtmp, n });
        os.writeFile(pname, "", 0o666) catch util.die("could not write '{s}' promisor file", .{pname});
    }
}

/// Run pack-objects and collect the hex names it prints.
fn finishPackObjects(argv: []const []const u8, stdin_data: ?[]const u8, names: *std.ArrayList([]const u8), is_local: bool) bool {
    const r = os.run(argv, .{ .capture_stdout = true, .stdin_data = stdin_data, .no_stdin = stdin_data == null });
    var it = std.mem.splitScalar(u8, r.stdout, '\n');
    while (it.next()) |line| {
        if (line.len == 0 and it.peek() == null) break;
        if (line.len != 40) util.die("repack: Expecting full hex object ID lines only from pack-objects.", .{});
        if (is_local) names.append(gpa, util.dupe(line)) catch util.oom();
    }
    return r.status == 0 and !r.signaled;
}

fn hasName(names: []const []const u8, s: []const u8) bool {
    for (names) |n| {
        if (util.eql(n, s)) return true;
    }
    return false;
}

const GPack = struct { base: []const u8, bn: []const u8, num: u32, local: bool };
const Geometry = struct {
    packs: std.ArrayList(GPack) = .empty,
    split: usize = 0,
};

fn lessGPack(_: void, a: GPack, b: GPack) bool {
    return a.num < b.num;
}

/// pack_geometry_init() + pack_geometry_split() (repack-geometry.c)
fn geometryInit(geo: *Geometry, existing: *const Existing, packdir: []const u8, factor: u32) void {
    const odb = repo_mod.repo().odb();
    for (odb.packs.items) |p| {
        const is_local = util.startsWith(p.idx_path, util.concat(&.{ packdir, "/" }));
        if (local and !is_local) continue;
        const bn = util.basename(p.pack_path);
        const base = bn[0 .. bn.len - 5];
        const full = p.pack_path[0 .. p.pack_path.len - 5];
        if (pack_kept_objects == 0) {
            if (os.exists(util.concat(&.{ full, ".keep" }))) continue;
            if (hasName(existing.kept.items, base)) continue;
        }
        if (os.exists(util.concat(&.{ full, ".mtimes" }))) continue;
        if (os.exists(util.concat(&.{ full, ".promisor" }))) continue;
        geo.packs.append(gpa, .{ .base = base, .bn = bn, .num = p.num, .local = is_local }) catch util.oom();
    }
    std.mem.sort(GPack, geo.packs.items, {}, lessGPack);

    const pk = geo.packs.items;
    if (pk.len == 0) return;
    var i: usize = pk.len - 1;
    while (i > 0) : (i -= 1) {
        const prev: u64 = pk[i - 1].num;
        if (@as(u64, factor) * prev > 0xffffffff)
            util.die("pack {s} too large to consider in geometric progression", .{pk[i - 1].bn});
        if (pk[i].num < factor * prev) break;
    }
    var split = i;
    if (split != 0) split += 1;
    var total: u64 = 0;
    for (pk[0..split]) |p| total += p.num;
    var j = split;
    while (j < pk.len) : (j += 1) {
        if (pk[j].num < @as(u64, factor) * total) {
            split += 1;
            total += pk[j].num;
        } else break;
    }
    geo.split = split;
}

/// pack_geometry_preferred_pack()
fn geometryPreferred(geo: *const Geometry) ?[]const u8 {
    if (geo.split == geo.packs.items.len) return null;
    var i = geo.packs.items.len;
    while (i > geo.split) : (i -= 1) {
        if (geo.packs.items[i - 1].local) return geo.packs.items[i - 1].bn;
    }
    return null;
}

/// midx_included_packs() + write_midx_included_packs() (repack-midx.c)
fn writeMidxIncludedPacks(existing: *const Existing, geo: ?*const Geometry, names: []const []const u8, packdir: []const u8, show_progress: bool, bitmaps: bool, incremental: bool, deleting: bool) bool {
    var include: std.ArrayList([]const u8) = .empty;
    for (existing.kept.items) |k| include.append(gpa, util.concat(&.{ k, ".idx" })) catch util.oom();
    for (names) |n| include.append(gpa, util.concat(&.{ "pack-", n, ".idx" })) catch util.oom();
    if (geo) |g| {
        for (g.packs.items[g.split..]) |p| {
            if (!p.local) continue;
            include.append(gpa, util.concat(&.{ p.base, ".idx" })) catch util.oom();
        }
    } else {
        for (existing.non_kept.items) |item| {
            if (deleting and (item.len < 40 or !hasName(names, item[item.len - 40 ..]))) continue;
            include.append(gpa, util.concat(&.{ item, ".idx" })) catch util.oom();
        }
    }
    if (midx_must_contain_cruft or midxHasUnknownPacks()) {
        for (existing.cruft.items) |item| {
            if (deleting and (item.len < 40 or !hasName(names, item[item.len - 40 ..]))) continue;
            include.append(gpa, util.concat(&.{ item, ".idx" })) catch util.oom();
        }
    }
    std.mem.sort([]const u8, include.items, {}, lessStr);
    var uniq: std.ArrayList([]const u8) = .empty;
    for (include.items) |s| {
        if (uniq.items.len > 0 and util.eql(uniq.items[uniq.items.len - 1], s)) continue;
        uniq.append(gpa, s) catch util.oom();
    }
    if (uniq.items.len == 0) return true;

    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ proc.gitBinary(), "multi-pack-index", "write" }) catch util.oom();
    if (incremental) argv.append(gpa, "--incremental") catch util.oom();
    argv.append(gpa, if (show_progress) "--progress" else "--no-progress") catch util.oom();
    if (bitmaps) argv.append(gpa, "--bitmap") catch util.oom();
    const gpref: ?[]const u8 = if (geo) |g| geometryPreferred(g) else null;
    if (gpref) |p| argv.append(gpa, util.concat(&.{ "--preferred-pack=", p })) catch util.oom() else for (names) |n| {
        if (os.exists(util.concat(&.{ packdir, "/pack-", n, ".mtimes" }))) continue;
        argv.append(gpa, util.concat(&.{ "--preferred-pack=pack-", n, ".pack" })) catch util.oom();
        break;
    }
    argv.append(gpa, "--stdin-packs") catch util.oom();
    var in: std.ArrayList(u8) = .empty;
    for (uniq.items) |s| {
        in.appendSlice(gpa, s) catch util.oom();
        in.append(gpa, '\n') catch util.oom();
    }
    const r = os.run(argv.items, .{ .stdin_data = in.items });
    if (r.status != 0 or r.signaled) return false;
    if (bitmaps) {
        for (uniq.items) |s| {
            const p = util.concat(&.{ packdir, "/", s[0 .. s.len - 4], ".bitmap" });
            if (!os.unlink(p) and os.errno() != os.ENOENT) util.warn("could not remove stale bitmap: {s}", .{p});
        }
    }
    return true;
}

fn unlinkPackPath(base: []const u8) void {
    const exts = [_][]const u8{ ".idx", ".pack", ".rev", ".keep", ".bitmap", ".promisor", ".mtimes" };
    for (exts) |e| _ = os.unlink(util.concat(&.{ base, e }));
}

pub fn cmdRepack(args: []const []const u8) u8 {
    const cfg = &repo_mod.cfg;
    if (cfg.getBool("repack.usedeltabaseoffset")) |b| delta_base_offset = b;
    if (cfg.getBool("repack.packkeptobjects")) |b| pack_kept_objects = @intFromBool(b);
    if (cfg.getBool("pack.writebitmaps")) |b| write_bitmaps = @intFromBool(b);
    if (cfg.getBool("repack.writebitmaps")) |b| write_bitmaps = @intFromBool(b);
    if (cfg.getBool("repack.usedeltaislands")) |b| delta_islands = b;
    if (cfg.getBool("repack.updateserverinfo")) |b| run_update_server_info = @intFromBool(b);
    if (cfg.getBool("repack.midxmustcontaincruft")) |b| midx_must_contain_cruft = b;

    const rest = po.parse(args[1..], &options, &usage, .{});
    _ = rest;
    const r = repo_mod.repo();

    if (drop_filtered and filter_to != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--drop-filtered", "--filter-to" });
    if (dry_run and !drop_filtered) util.die("--dry-run only takes effect with --drop-filtered", .{});
    if (drop_filtered) {
        if (filter == null) util.die("--drop-filtered requires --filter", .{});
        if (pack_everything & ALL_INTO_ONE == 0) util.die("--drop-filtered requires -a", .{});
        const fl = @import("../objfilter.zig").parse(filter.?);
        if (fl.kind != .blob_limit) util.die("--drop-filtered only supports --filter=blob:limit=<n> for now", .{});
        if (write_bitmaps_given and write_bitmaps > 0)
            util.die("options '{s}' and '{s}' cannot be used together", .{ "--drop-filtered", "--write-bitmap-index" });
        if (!@import("../promisor.zig").hasRemote()) util.die("--drop-filtered requires a promisor remote", .{});
        if (!r.bare and operationInProgress(r))
            util.die("--drop-filtered cannot be used while another operation (merge, rebase, am, cherry-pick, revert, or bisect) is in progress", .{});
        write_bitmaps = 0;
        if (!dry_run) delete_redundant = true;
        enumeratePromisorBlobs(fl, &drop_oids);
        if (!r.bare and drop_oids.count() > 0) {
            const idx = @import("../index.zig").readFrom(r.indexPath());
            for (idx.entries.items) |e| {
                if (drop_oids.contains(e.oid))
                    util.die("cannot drop '{s}' ({s}): it is referenced by the current index", .{ e.path, hash.hex(e.oid) });
            }
        }
        if (dry_run) {
            for (drop_list.items) |oid| util.outf("{s}\n", .{hash.hex(oid)});
        }
    }

    if (delete_redundant) {
        if (cfg.getBool("extensions.preciousobjects") orelse false)
            util.die("cannot delete packs in a precious-objects repo", .{});
    }
    {
        const a_set = unpack_unreachable != null or (pack_everything & LOOSEN_UNREACHABLE != 0);
        const k_set = keep_unreachable;
        const c_set = pack_everything & PACK_CRUFT != 0;
        if (a_set and k_set and c_set) util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ "-A", "-k/--keep-unreachable", "--cruft" });
        if (a_set and k_set) util.die("options '{s}' and '{s}' cannot be used together", .{ "-A", "-k/--keep-unreachable" });
        if (a_set and c_set) util.die("options '{s}' and '{s}' cannot be used together", .{ "-A", "--cruft" });
        if (k_set and c_set) util.die("options '{s}' and '{s}' cannot be used together", .{ "-k/--keep-unreachable", "--cruft" });
    }
    if (pack_everything & PACK_CRUFT != 0) pack_everything |= ALL_INTO_ONE;

    const midx = write_midx != null or write_midx_m != 0;
    if (write_bitmaps < 0) {
        if (!midx and (pack_everything & ALL_INTO_ONE == 0 or !r.bare)) write_bitmaps = 0;
    }
    if (pack_kept_objects < 0) pack_kept_objects = @intFromBool(write_bitmaps > 0 and !midx);
    if (write_bitmaps > 0 and pack_everything & ALL_INTO_ONE == 0 and !midx)
        util.die("Incremental repacks are incompatible with bitmap indexes.  Use\n--no-write-bitmap-index or disable the pack.writeBitmaps configuration.", .{});
    if (write_bitmaps > 0 and local and r.odb().alternates.items.len > 0) {
        util.warn("disabling bitmap writing, as some objects are not being packed", .{});
        write_bitmaps = 0;
    }

    const objdir = r.odb().objects_dir;
    const packdir = util.concat(&.{ objdir, "/pack" });
    const packtmp_name = util.fmt(".tmp-{d}-pack", .{std.c.getpid()});
    const packtmp = util.concat(&.{ packdir, "/", packtmp_name });
    _ = os.mkdirAll(packdir);

    var existing = collectExisting(packdir);

    if (geometric != 0 and pack_everything != 0)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--geometric", "-A/-a" });
    var geometry: Geometry = .{};
    if (geometric != 0) geometryInit(&geometry, &existing, packdir, @intCast(geometric));

    var argv: std.ArrayList([]const u8) = .empty;
    preparePackObjects(&argv, packtmp, false);
    const show_progress = !quiet and os.isatty(2);

    const push = struct {
        fn f(l: *std.ArrayList([]const u8), s: []const u8) void {
            l.append(gpa, s) catch util.oom();
        }
    }.f;
    push(&argv, "--keep-true-parents");
    for (keep_pack_list.items) |k| push(&argv, util.concat(&.{ "--keep-pack=", k }));
    push(&argv, "--non-empty");
    if (geometric == 0) {
        push(&argv, "--all");
        push(&argv, "--reflog");
        push(&argv, "--indexed-objects");
    }
    if (!midx) {
        if (write_bitmaps > 0) push(&argv, "--write-bitmap-index") else if (write_bitmaps < 0) push(&argv, "--write-bitmap-index-quiet");
    }
    if (@import("../promisor.zig").hasRemote()) push(&argv, "--exclude-promisor-objects");
    if (delta_islands) push(&argv, "--delta-islands");

    var names: std.ArrayList([]const u8) = .empty;
    const has_non_kept = existing.non_kept.items.len > 0 or existing.cruft.items.len > 0;
    if (pack_everything & ALL_INTO_ONE != 0) {
        repackPromisorObjects(packtmp, &names, if (drop_filtered and !dry_run) &drop_oids else null);
        if (has_non_kept and delete_redundant and pack_everything & PACK_CRUFT == 0) {
            for (names.items) |n| push(&argv, util.fmt("--keep-pack={s}-{s}.pack", .{ packtmp_name, n }));
        }
        if (has_non_kept and delete_redundant and pack_everything & PACK_CRUFT == 0) {
            if (unpack_unreachable) |u| {
                push(&argv, util.concat(&.{ "--unpack-unreachable=", u }));
            } else if (pack_everything & LOOSEN_UNREACHABLE != 0) {
                push(&argv, "--unpack-unreachable");
            } else if (keep_unreachable) {
                push(&argv, "--keep-unreachable");
            }
        }
        if (keep_unreachable and delete_redundant and pack_everything & PACK_CRUFT == 0)
            push(&argv, "--pack-loose-unreachable");
    } else if (geometric != 0) {
        push(&argv, if (midx_must_contain_cruft) "--stdin-packs" else "--stdin-packs=follow");
        push(&argv, "--unpacked");
    } else {
        push(&argv, "--unpacked");
        push(&argv, "--incremental");
    }
    if (filter) |f| push(&argv, util.concat(&.{ "--filter=", f })) else if (filter_to != null)
        util.die("option '{s}' can only be used along with '{s}'", .{ "--filter-to", "--filter" });

    var geo_in: ?[]const u8 = null;
    if (geometric != 0) {
        var in: std.ArrayList(u8) = .empty;
        const mp = midxPacks();
        for (geometry.packs.items[0..geometry.split]) |p| util.bufPrint(&in, "{s}\n", .{p.bn});
        for (geometry.packs.items[geometry.split..]) |p| {
            const marker: u8 = if (!midx_must_contain_cruft and !hasName(mp, p.bn)) '!' else '^';
            util.bufPrint(&in, "{c}{s}\n", .{ marker, p.bn });
        }
        geo_in = in.items;
    }
    if (!finishPackObjects(argv.items, geo_in, &names, true)) return 1;

    if (names.items.len == 0) {
        if (!quiet) util.outf("Nothing new to pack.\n", .{});
        if (midx_lib.get(objdir) == null) midx_must_contain_cruft = true;
    }

    if (pack_everything & PACK_CRUFT != 0) {
        // the packs just written must be visible to the cruft pack-objects
        const ok = writeCruftPack(packtmp, packtmp_name, packtmp, cruft_expiration, &names, &existing, true);
        if (!ok) return 1;
        if (delete_redundant and expire_to != null) {
            var dummy: std.ArrayList([]const u8) = .empty;
            dummy.appendSlice(gpa, names.items) catch util.oom();
            if (!writeCruftPack(expire_to.?, packtmp_name, packtmp, null, &dummy, &existing, false)) return 1;
        }
    }

    if (filter != null and !drop_filtered) {
        const dest = filter_to orelse packtmp;
        if (!writeFilteredPack(dest, packtmp_name, &names, &existing, util.startsWith(dest, packdir))) return 1;
    }

    std.mem.sort([]const u8, names.items, {}, lessStr);

    // install
    const exts = [_]struct { e: []const u8, opt: bool }{
        .{ .e = ".pack", .opt = false },
        .{ .e = ".rev", .opt = true },
        .{ .e = ".mtimes", .opt = true },
        .{ .e = ".bitmap", .opt = true },
        .{ .e = ".promisor", .opt = true },
        .{ .e = ".idx", .opt = false },
    };
    for (names.items) |n| {
        for (exts) |x| {
            const fname = util.concat(&.{ packdir, "/pack-", n, x.e });
            const old = util.concat(&.{ packtmp, "-", n, x.e });
            if (os.statPath(old)) |st| {
                _ = os.chmod(old, st.mode & 0o7777 & ~@as(u32, 0o222));
                if (!os.rename(old, fname)) util.dieErrno("renaming pack to '{s}' failed", .{fname});
            } else if (!x.opt) {
                util.die("pack-objects did not write a '{s}' file for pack {s}-{s}", .{ x.e, packtmp, n });
            } else {
                if (!os.unlink(fname) and os.errno() != os.ENOENT) util.dieErrno("could not unlink: {s}", .{fname});
            }
        }
    }

    const midx_incremental = if (write_midx) |m| util.eql(m, "incremental") else false;
    if (midx) {
        if (!writeMidxIncludedPacks(&existing, if (geometric != 0) &geometry else null, names.items, packdir, show_progress, write_bitmaps > 0, midx_incremental, delete_redundant and pack_everything & ALL_INTO_ONE != 0))
            return 1;
    }

    if (delete_redundant) {
        if (pack_everything & ALL_INTO_ONE != 0) {
            for ([_][]const []const u8{ existing.non_kept.items, existing.cruft.items }) |list| {
                for (list) |item| {
                    if (item.len < 40) continue;
                    if (hasName(names.items, item[item.len - 40 ..])) continue;
                    // repack_remove_redundant_pack(): drop a MIDX naming it
                    if (midx_lib.get(objdir)) |m| {
                        if (midx_lib.containsPack(m, util.concat(&.{ item, ".pack" }))) {
                            midx_lib.clearMidxFile(objdir);
                            if (!midx_incremental) midx_lib.clearIncrementalMidxFiles(objdir);
                        }
                    }
                    unlinkPackPath(util.concat(&.{ packdir, "/", item }));
                }
            }
        }
        if (geometric != 0) {
            // pack_geometry_remove_redundant()
            for (geometry.packs.items[0..geometry.split]) |p| {
                if (p.base.len >= 40 and hasName(names.items, p.base[p.base.len - 40 ..])) continue;
                if (hasName(existing.kept.items, p.base)) continue;
                if (!p.local) continue;
                const full = util.concat(&.{ packdir, "/", p.base });
                if (os.exists(util.concat(&.{ full, ".keep" }))) continue;
                if (midx_lib.get(objdir)) |m| {
                    if (midx_lib.containsPack(m, p.bn)) {
                        midx_lib.clearMidxFile(objdir);
                        if (!midx_incremental) midx_lib.clearIncrementalMidxFiles(objdir);
                    }
                }
                unlinkPackPath(full);
            }
        }
        var pp: std.ArrayList([]const u8) = .empty;
        pp.append(gpa, proc.gitBinary()) catch util.oom();
        pp.append(gpa, "prune-packed") catch util.oom();
        if (!show_progress) pp.append(gpa, "-q") catch util.oom();
        _ = os.run(pp.items, .{ .no_stdin = true });
    }

    if (run_update_server_info != 0) {
        r.odb().reloadPacks();
        _ = serverinfo.updateServerInfo(false);
    }
    return 0;
}


/// write_filtered_pack() (repack-filtered.c)
fn writeFilteredPack(destination: []const u8, packtmp_name: []const u8, names: *std.ArrayList([]const u8), existing: *const Existing, is_local: bool) bool {
    var argv: std.ArrayList([]const u8) = .empty;
    preparePackObjects(&argv, destination, false);
    argv.append(gpa, "--stdin-packs") catch util.oom();
    for (existing.kept.items) |k| argv.append(gpa, util.concat(&.{ "--keep-pack=", k })) catch util.oom();
    var in: util.Buf = .empty;
    for (names.items) |n| util.bufPrint(&in, "^{s}-{s}.pack\n", .{ packtmp_name, n });
    for (existing.non_kept.items) |n| util.bufPrint(&in, "{s}.pack\n", .{n});
    for (existing.cruft.items) |n| util.bufPrint(&in, "{s}.pack\n", .{n});
    const caret: []const u8 = if (pack_kept_objects != 0) "" else "^";
    for (existing.kept.items) |n| util.bufPrint(&in, "{s}{s}.pack\n", .{ caret, n });
    return finishPackObjects(argv.items, in.items, names, is_local);
}
fn writeCruftPack(destination: []const u8, packtmp_name: []const u8, packtmp: []const u8, expiration: ?[]const u8, names: *std.ArrayList([]const u8), existing: *Existing, is_local: bool) bool {
    _ = packtmp;
    var argv: std.ArrayList([]const u8) = .empty;
    preparePackObjects(&argv, destination, true);
    argv.append(gpa, "--cruft") catch util.oom();
    if (expiration) |e| argv.append(gpa, util.concat(&.{ "--cruft-expiration=", e })) catch util.oom();
    argv.append(gpa, "--non-empty") catch util.oom();
    var in: util.Buf = .empty;
    for (names.items) |n| util.bufPrint(&in, "{s}-{s}.pack\n", .{ packtmp_name, n });
    const combine: u64 = if (combine_cruft_below_size) |s| (std.fmt.parseInt(u64, s, 10) catch 0) else 0;
    if (combine != 0 and expiration == null) {
        const packdir = util.dirname(destination);
        for (existing.cruft.items) |c| {
            const st = os.statPath(util.concat(&.{ packdir, "/", c, ".pack" }));
            const size: u64 = if (st) |s| @intCast(s.size) else 0;
            if (size < combine) util.bufPrint(&in, "-{s}.pack\n", .{c}) else {
                util.bufPrint(&in, "{s}.pack\n", .{c});
                // retained: keep it from being deleted
                existing.kept.append(gpa, c) catch util.oom();
            }
        }
        for (existing.non_kept.items) |n| util.bufPrint(&in, "-{s}.pack\n", .{n});
        // drop retained cruft packs from the deletion candidates
        var keep: std.ArrayList([]const u8) = .empty;
        for (existing.cruft.items) |c| {
            if (!hasName(existing.kept.items, c)) keep.append(gpa, c) catch util.oom();
        }
        existing.cruft = keep;
    } else {
        for (existing.non_kept.items) |n| util.bufPrint(&in, "-{s}.pack\n", .{n});
        for (existing.cruft.items) |n| util.bufPrint(&in, "-{s}.pack\n", .{n});
    }
    for (existing.kept.items) |n| util.bufPrint(&in, "{s}.pack\n", .{n});
    return finishPackObjects(argv.items, in.items, names, is_local);
}

var usi_force = false;
const usi_usage = [_][]const u8{"git update-server-info [-f | --force]"};

pub fn cmdUpdateServerInfo(args: []const []const u8) u8 {
    const opts = [_]po.Opt{
        po.boolean('f', "force", &usi_force, "update the info files from scratch"),
    };
    const rest = po.parse(args[1..], &opts, &usi_usage, .{});
    if (rest.len > 0) po.usageWithOptions(&usi_usage, &opts);
    return if (serverinfo.updateServerInfo(usi_force)) 0 else 1;
}

var drop_oids: hash.OidSet = .empty;
var drop_list: std.ArrayList(hash.Oid) = .empty;

/// enumerate_promisor_blobs(): blobs in promisor packs that the
/// blob:limit filter omits.
fn enumeratePromisorBlobs(fl: *@import("../objfilter.zig").Filter, out: *hash.OidSet) void {
    const odb = repo_mod.repo().odb();
    odb.loadPacks();
    for (odb.packs.items) |p| {
        if (!@import("../promisor.zig").isPromisorPack(p.pack_path)) continue;
        var i: u32 = 0;
        while (i < p.num) : (i += 1) {
            const oid = p.oidAt(i);
            if (out.contains(oid)) continue;
            const o = odb.read(oid) orelse continue;
            if (o.typ != .blob) continue;
            if (o.data.len < fl.limit) continue;
            out.put(gpa, oid, {}) catch util.oom();
            drop_list.append(gpa, oid) catch util.oom();
        }
    }
}

/// The subset of wt_status_get_state() that --drop-filtered refuses.
fn operationInProgress(r: anytype) bool {
    const names = [_][]const u8{ "MERGE_HEAD", "REVERT_HEAD", "CHERRY_PICK_HEAD", "BISECT_LOG", "rebase-apply", "rebase-merge" };
    for (names) |n| if (os.exists(r.gitPath(n))) return true;
    return false;
}
