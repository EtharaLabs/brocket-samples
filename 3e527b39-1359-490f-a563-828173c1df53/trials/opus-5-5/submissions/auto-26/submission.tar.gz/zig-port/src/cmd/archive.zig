//! git archive (port of builtin/archive.c, archive.c, archive-tar.c, archive-zip.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const hash = @import("../hash.zig");
const objects = @import("../objects.zig");
const cn = @import("../commitnode.zig");
const revparse = @import("../revparse.zig");
const attr = @import("../attr.zig");
const convert = @import("../convert.zig");
const pretty = @import("../pretty.zig");
const pathspec = @import("../pathspec.zig");
const index_mod = @import("../index.zig");
const date = @import("../date.zig");
const zlib = @import("../zlib.zig");
const userdiff = @import("../userdiff.zig");
const proc = @import("../proc.zig");
const refs = @import("../refs.zig");
const gpa = util.gpa;
const Buf = util.Buf;
const Oid = hash.Oid;

extern "c" fn deflateInit2_(strm: *zlib.ZStream, level: c_int, method: c_int, windowBits: c_int, memLevel: c_int, strategy: c_int, version: [*:0]const u8, stream_size: c_int) c_int;
extern "c" fn umask(mask: c_uint) c_uint;
extern "c" fn dup2(old: c_int, new: c_int) c_int;

const archive_usage = [_][]const u8{
    "git archive [<options>] <tree-ish> [<path>...]",
    "git archive --list",
    "git archive --remote <repo> [--exec <cmd>] [<options>] <tree-ish> [<path>...]",
    "git archive --remote <repo> [--exec <cmd>] --list",
};

// ---------------------------------------------------------------------------
// archivers

const Kind = enum { tar, filter, zip };

const Archiver = struct {
    name: []const u8,
    kind: Kind,
    command: ?[]const u8 = null,
    levels: bool = false,
    high: bool = false,
    remote: bool = false,
};

const internal_gzip_command = "git archive gzip";

var archivers: std.ArrayList(Archiver) = .empty;
var tar_umask: u32 = 0o002;

fn findFilter(filters: *std.ArrayList(Archiver), name: []const u8) *Archiver {
    for (filters.items) |*a| {
        if (util.eql(a.name, name)) return a;
    }
    filters.append(gpa, .{ .name = util.dupe(name), .kind = .filter, .levels = true, .high = true }) catch util.oom();
    return &filters.items[filters.items.len - 1];
}

fn tarFilterConfig(filters: *std.ArrayList(Archiver), key: []const u8, value: ?[]const u8) void {
    const rest = util.skipPrefix(key, "tar.") orelse return;
    const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse return;
    const name = rest[0..dot];
    const typ = rest[dot + 1 ..];
    const a = findFilter(filters, name);
    if (util.eql(typ, "command")) {
        const v = value orelse util.die("missing value for '{s}'", .{key});
        a.command = v;
    } else if (util.eql(typ, "remote")) {
        a.remote = @import("../config.zig").configBool(key, value);
    }
}

fn initArchivers() void {
    archivers.append(gpa, .{ .name = "tar", .kind = .tar, .remote = true }) catch util.oom();
    var filters: std.ArrayList(Archiver) = .empty;
    tarFilterConfig(&filters, "tar.tgz.command", internal_gzip_command);
    tarFilterConfig(&filters, "tar.tgz.remote", "true");
    tarFilterConfig(&filters, "tar.tar.gz.command", internal_gzip_command);
    tarFilterConfig(&filters, "tar.tar.gz.remote", "true");
    if (repo_mod.repo_ != null or true) {
        for (repo_mod.cfg.entries.items) |e| {
            if (util.eql(e.key, "tar.umask")) {
                if (e.value != null and util.eql(e.value.?, "user")) {
                    const m = umask(0);
                    _ = umask(m);
                    tar_umask = m;
                } else {
                    const v = e.value orelse "";
                    tar_umask = @truncate(@as(u64, @bitCast(@import("../config.zig").parseInt(v) orelse util.die("bad numeric config value '{s}' for 'tar.umask': invalid unit", .{v}))));
                }
                continue;
            }
            if (util.startsWith(e.key, "tar.")) tarFilterConfig(&filters, e.key, e.value);
        }
    }
    for (filters.items) |f| {
        if (f.command != null) archivers.append(gpa, f) catch util.oom();
    }
    archivers.append(gpa, .{ .name = "zip", .kind = .zip, .levels = true, .remote = true }) catch util.oom();
}

fn lookupArchiver(name: []const u8) ?*Archiver {
    for (archivers.items) |*a| {
        if (util.eql(a.name, name)) return a;
    }
    return null;
}

fn matchExtension(filename: []const u8, ext: []const u8) bool {
    if (filename.len < ext.len + 2) return false;
    const prefixlen = filename.len - ext.len;
    if (filename[prefixlen - 1] != '.') return false;
    return util.eql(filename[prefixlen..], ext);
}

fn formatFromFilename(filename: []const u8) ?[]const u8 {
    for (archivers.items) |a| {
        if (matchExtension(filename, a.name)) return a.name;
    }
    return null;
}

// ---------------------------------------------------------------------------
// options

const ExtraFile = struct {
    path: []const u8,
    base: ?[]const u8,
    content: ?[]const u8,
    mode: u32,
};

var opt_base: ?[]const u8 = null;
var opt_prefix: []const u8 = "";
var extra_files: std.ArrayList(ExtraFile) = .empty;
var compression_level: i32 = -1;

fn prefixFilename(p: []const u8) []const u8 {
    if (p.len > 0 and p[0] == '/') return p;
    return util.concat(&.{ opt_prefix, p });
}

fn addFileCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        extra_files.items.len = 0;
        return;
    }
    const a = arg orelse return;
    const path = prefixFilename(a);
    const st = os.statPath(path) orelse util.die("File not found: {s}", .{path});
    if (!st.isReg()) util.die("Not a regular file: {s}", .{path});
    const mode: u32 = 0o100000 | @as(u32, if (st.mode & 0o100 != 0) 0o755 else 0o644);
    extra_files.append(gpa, .{ .path = path, .base = opt_base, .content = null, .mode = mode }) catch util.oom();
}

fn addVirtualFileCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        extra_files.items.len = 0;
        return;
    }
    const a = arg orelse return;
    var path: []const u8 = undefined;
    var p: []const u8 = undefined;
    if (a.len > 0 and a[0] == '"') {
        const r = util.cunquote(a) orelse util.die("unclosed quote: '{s}'", .{a});
        path = r.value;
        p = r.rest;
        if (p.len == 0 or p[0] != ':') util.die("missing colon: '{s}'", .{a});
    } else {
        const ci = std.mem.indexOfScalar(u8, a, ':') orelse util.die("missing colon: '{s}'", .{a});
        if (ci == 0) util.die("empty file name: '{s}'", .{a});
        path = a[0..ci];
        p = a[ci..];
    }
    if (opt_prefix.len > 0) path = prefixFilename(path);
    extra_files.append(gpa, .{ .path = path, .base = opt_base, .content = util.dupe(p[1..]), .mode = 0o100644 }) catch util.oom();
}

fn numberCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    compression_level = std.fmt.parseInt(i32, arg orelse "0", 10) catch std.math.maxInt(i32);
}

// ---------------------------------------------------------------------------
// archive state

const Args = struct {
    base: []const u8 = "",
    prefix: []const u8 = "",
    verbose: bool = false,
    convert: bool = false,
    commit: ?*cn.Commit = null,
    commit_oid: ?Oid = null,
    tree: Oid = undefined,
    time: u64 = 0,
    level: i32 = -1,
    pspec: pathspec.Pathspec = .{},
    kind: Kind = .tar,
    ctx: pretty.Context = .{},
};

var args_g: Args = .{};
var describe_budget: usize = 1;

const Pending = struct { oid: Oid, path: []const u8, mode: u32 };
var pending: std.ArrayList(Pending) = .empty;

fn isDirMode(m: u32) bool {
    return m & 0o170000 == 0o040000;
}
fn isGitlink(m: u32) bool {
    return m & 0o170000 == 0o160000;
}
fn isReg(m: u32) bool {
    return m & 0o170000 == 0o100000;
}
fn isLnk(m: u32) bool {
    return m & 0o170000 == 0o120000;
}

fn writeEntry(oid: Oid, path: []const u8, mode: u32, data: []const u8) bool {
    return switch (args_g.kind) {
        .zip => zipEntry(oid, path, mode, data),
        else => tarEntry(oid, path, mode, data),
    };
}

fn formatSubst(commit: *cn.Commit, src0: []const u8) []const u8 {
    var b: Buf = .empty;
    var src = src0;
    while (true) {
        const bi = std.mem.indexOf(u8, src, "$Format:") orelse break;
        const ci = std.mem.indexOfScalarPos(u8, src, bi + 8, '$') orelse break;
        util.bufAppend(&b, src[0..bi]);
        pretty.formatCommitMessage(commit, src[bi + 8 .. ci], &b, &args_g.ctx);
        src = src[ci + 1 ..];
    }
    util.bufAppend(&b, src);
    return b.items;
}

/// write_archive_entry(); returns false on error, true otherwise.
fn writeArchiveEntry(oid: Oid, rel: []const u8, mode: u32) bool {
    const a = &args_g;
    a.convert = false;
    const is_dirish = isDirMode(mode) or isGitlink(mode);
    var pwp: []const u8 = if (is_dirish) util.concat(&.{ rel, "/" }) else rel;
    if (!isDirMode(mode)) {
        const vals = attr.check(pwp, &.{ "export-ignore", "export-subst" });
        if (vals[0] == .set) return true;
        a.convert = vals[1] == .set;
    }
    if (a.prefix.len > 0) {
        const r = util.relativePath(pwp, a.prefix);
        if (util.eql(r, "./") or util.startsWith(r, "../")) return true;
        pwp = r;
    }
    const path = util.concat(&.{ a.base, pwp });
    if (a.verbose) util.eprint("{s}\n", .{path});
    if (is_dirish) return writeEntry(oid, path, mode, "");
    const obj = repo_mod.repo().odb().read(oid) orelse {
        util.err("cannot read '{s}'", .{hash.hex(oid)});
        return false;
    };
    var data: []const u8 = obj.data;
    if (isReg(mode)) {
        data = convert.toWorktree(pwp, data);
        if (a.convert) {
            if (a.commit) |c| data = formatSubst(c, data);
        }
    }
    return writeEntry(oid, path, mode, data);
}

fn flushPending() bool {
    for (pending.items) |d| {
        if (!writeArchiveEntry(d.oid, d.path, d.mode)) {
            pending.items.len = 0;
            return false;
        }
    }
    pending.items.len = 0;
    return true;
}

fn walkTree(tree: Oid, base: []const u8) bool {
    const entries = objects.readTree(tree) orelse return true;
    const ps = &args_g.pspec;
    for (entries) |te| {
        const full = util.concat(&.{ base, te.name });
        if (isDirMode(te.mode)) {
            if (!ps.isEmpty() and !ps.couldMatchUnder(full)) continue;
            const vals = attr.check(util.concat(&.{ full, "/" }), &.{ "export-ignore", "export-subst" });
            if (vals[0] == .set) continue;
            const saved = pending.items.len;
            pending.append(gpa, .{ .oid = te.oid, .path = full, .mode = te.mode }) catch util.oom();
            if (!walkTree(te.oid, util.concat(&.{ full, "/" }))) return false;
            if (pending.items.len > saved) pending.items.len = saved;
        } else {
            if (!ps.isEmpty() and !ps.matches(full, false)) continue;
            if (!flushPending()) return false;
            if (!writeArchiveEntry(te.oid, full, te.mode)) return false;
        }
    }
    return true;
}

fn writeArchiveEntries() bool {
    const a = &args_g;
    if (a.base.len > 0 and a.base[a.base.len - 1] == '/') {
        var len = a.base.len;
        while (len > 1 and a.base[len - 2] == '/') len -= 1;
        if (a.verbose) util.eprint("{s}\n", .{a.base[0..len]});
        if (!writeEntry(a.tree, a.base[0..len], 0o40777, "")) return false;
    }
    pending.items.len = 0;
    if (!walkTree(a.tree, "")) return false;
    pending.items.len = 0;
    for (extra_files.items, 0..) |ef, i| {
        var fake: Oid = @splat(0);
        std.mem.writeInt(u64, fake[0..8], @intCast(i + 1), .big);
        if (ef.content) |content| {
            if (!writeEntry(fake, ef.path, ef.mode, content)) return false;
        } else {
            const pia = util.concat(&.{ ef.base orelse "", util.basename(ef.path) });
            const data = os.readFile(ef.path) orelse {
                util.err("cannot read '{s}': {s}", .{ ef.path, os.strErr(os.errno()) });
                return false;
            };
            if (!writeEntry(fake, pia, ef.mode, data)) return false;
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// output

fn writeOut(data: []const u8) void {
    os.writeAll(1, data) catch util.dieErrno("write error", .{});
}

fn deflateRaw(data: []const u8, level: i32) ?[]u8 {
    var s = zlib.ZStream{};
    if (deflateInit2_(&s, level, 8, -15, 8, 0, zlib.zlibVersion(), @sizeOf(zlib.ZStream)) != zlib.Z_OK) return null;
    const bound = zlib.deflateBound(&s, data.len);
    const outbuf = gpa.alloc(u8, bound + 64) catch util.oom();
    s.next_in = data.ptr;
    s.avail_in = @intCast(data.len);
    s.next_out = outbuf.ptr;
    s.avail_out = @intCast(outbuf.len);
    var r: c_int = zlib.Z_OK;
    while (r == zlib.Z_OK) r = zlib.deflate(&s, zlib.Z_FINISH);
    if (r != zlib.Z_STREAM_END) {
        _ = zlib.deflateEnd(&s);
        return null;
    }
    const n = s.total_out;
    _ = zlib.deflateEnd(&s);
    return outbuf[0..n];
}

// ---------------------------------------------------------------------------
// tar

const RECORDSIZE = 512;
const BLOCKSIZE = RECORDSIZE * 20;
const USTAR_MAX_SIZE: u64 = 0o77777777777;
const USTAR_MAX_MTIME: u64 = 0o77777777777;

var tar_out: Buf = .empty;

fn writeBlocked(data: []const u8) void {
    util.bufAppend(&tar_out, data);
    const tail = tar_out.items.len % RECORDSIZE;
    if (tail != 0) tar_out.appendNTimes(gpa, 0, RECORDSIZE - tail) catch util.oom();
}

fn appendExtHeader(sb: *Buf, keyword: []const u8, value: []const u8) void {
    var len: usize = 1 + 1 + keyword.len + 1 + value.len + 1;
    var tmp: usize = 1;
    while (len / 10 >= tmp) : (tmp *= 10) len += 1;
    util.bufPrint(sb, "{d} {s}=", .{ len, keyword });
    util.bufAppend(sb, value);
    util.bufByte(sb, '\n');
}

fn putOctal(field: []u8, v: u64) void {
    _ = std.fmt.bufPrint(field[0 .. field.len - 1], "{o:0>[1]}", .{ v, field.len - 1 }) catch {};
}

fn prepareHeader(h: *[512]u8, mode: u32, size: u64) void {
    putOctal(h[100..108], mode & 0o7777);
    putOctal(h[124..136], if (isReg(mode)) size else 0);
    putOctal(h[136..148], args_g.time);
    putOctal(h[108..116], 0);
    putOctal(h[116..124], 0);
    @memcpy(h[265..269], "root");
    @memcpy(h[297..301], "root");
    putOctal(h[329..337], 0);
    putOctal(h[337..345], 0);
    @memcpy(h[257..263], "ustar\x00");
    @memcpy(h[263..265], "00");
    var sum: u32 = 0;
    for (h, 0..) |b, i| {
        sum += if (i >= 148 and i < 156) ' ' else b;
    }
    putOctal(h[148..156], sum);
}

fn writeExtendedHeader(oid: Oid, buf: []const u8) void {
    var h: [512]u8 = @splat(0);
    h[156] = 'x';
    const hx = hash.hex(oid);
    _ = std.fmt.bufPrint(h[0..100], "{s}.paxheader", .{&hx}) catch {};
    prepareHeader(&h, 0o100666, buf.len);
    writeBlocked(&h);
    writeBlocked(buf);
}

fn getPathPrefix(path: []const u8, maxlen: usize) usize {
    var i = path.len;
    if (i > 1 and path[i - 1] == '/') i -= 1;
    if (i > maxlen) i = maxlen;
    while (true) {
        i -= 1;
        if (!(i > 0 and path[i] != '/')) break;
    }
    return i;
}

fn tarEntry(oid: Oid, path: []const u8, mode0: u32, data: []const u8) bool {
    var h: [512]u8 = @splat(0);
    var ext: Buf = .empty;
    var mode = mode0;
    if (isDirMode(mode) or isGitlink(mode)) {
        h[156] = '5';
        mode = (mode | 0o777) & ~tar_umask;
    } else if (isLnk(mode)) {
        h[156] = '2';
        mode |= 0o777;
    } else if (isReg(mode)) {
        h[156] = '0';
        mode = (mode | @as(u32, if (mode & 0o100 != 0) 0o777 else 0o666)) & ~tar_umask;
    } else {
        util.err("unsupported file mode: 0{o} (SHA1: {s})", .{ mode, hash.hex(oid) });
        return false;
    }
    const hx = hash.hex(oid);
    if (path.len > 100) {
        const plen = getPathPrefix(path, 155);
        const rest = path.len -% plen -% 1;
        if (plen > 0 and rest <= 100) {
            @memcpy(h[345 .. 345 + plen], path[0..plen]);
            @memcpy(h[0..rest], path[plen + 1 ..]);
        } else {
            _ = std.fmt.bufPrint(h[0..100], "{s}.data", .{&hx}) catch {};
            appendExtHeader(&ext, "path", path);
        }
    } else @memcpy(h[0..path.len], path);

    if (isLnk(mode)) {
        if (data.len > 100) {
            _ = std.fmt.bufPrint(h[157..257], "see {s}.paxheader", .{&hx}) catch {};
            appendExtHeader(&ext, "linkpath", data);
        } else @memcpy(h[157 .. 157 + data.len], data);
    }
    var size_in_header: u64 = data.len;
    if (isReg(mode) and data.len > USTAR_MAX_SIZE) {
        size_in_header = 0;
        appendExtHeader(&ext, "size", util.fmt("{d}", .{data.len}));
    }
    prepareHeader(&h, mode, size_in_header);
    if (ext.items.len > 0) writeExtendedHeader(oid, ext.items);
    writeBlocked(&h);
    if (isReg(mode) and data.len > 0) writeBlocked(data);
    return true;
}

fn writeGlobalExtendedHeader() void {
    var ext: Buf = .empty;
    if (args_g.commit_oid) |o| {
        const hx = hash.hex(o);
        appendExtHeader(&ext, "comment", &hx);
    }
    if (args_g.time > USTAR_MAX_MTIME) {
        appendExtHeader(&ext, "mtime", util.fmt("{d}", .{args_g.time}));
        args_g.time = USTAR_MAX_MTIME;
    }
    if (ext.items.len == 0) return;
    var h: [512]u8 = @splat(0);
    h[156] = 'g';
    @memcpy(h[0..17], "pax_global_header");
    prepareHeader(&h, 0o100666, ext.items.len);
    writeBlocked(&h);
    writeBlocked(ext.items);
}

fn writeTarTrailer() void {
    const offset = tar_out.items.len % BLOCKSIZE;
    const tail = BLOCKSIZE - offset;
    tar_out.appendNTimes(gpa, 0, tail) catch util.oom();
    if (tail < 2 * RECORDSIZE) tar_out.appendNTimes(gpa, 0, BLOCKSIZE) catch util.oom();
}

fn writeTarArchive() bool {
    writeGlobalExtendedHeader();
    const ok = writeArchiveEntries();
    if (ok) writeTarTrailer();
    return ok;
}

fn gzipData(data: []const u8, level: i32) []const u8 {
    const lvl: i32 = if (level == -1) 6 else level;
    const body = deflateRaw(data, level) orelse util.die("unable to deflate", .{});
    var b: Buf = .empty;
    const xfl: u8 = if (lvl == 9) 2 else if (lvl < 2) 4 else 0;
    util.bufAppend(&b, &[_]u8{ 0x1f, 0x8b, 8, 0, 0, 0, 0, 0, xfl, 3 });
    util.bufAppend(&b, body);
    var t: [8]u8 = undefined;
    std.mem.writeInt(u32, t[0..4], zlib.crc(0, data), .little);
    std.mem.writeInt(u32, t[4..8], @truncate(data.len), .little);
    util.bufAppend(&b, &t);
    return b.items;
}

fn writeTarFilterArchive(ar: *const Archiver) bool {
    const cmd = ar.command.?;
    if (util.eql(cmd, internal_gzip_command)) {
        const ok = writeTarArchive();
        writeOut(gzipData(tar_out.items, args_g.level));
        return ok;
    }
    var full: []const u8 = cmd;
    if (args_g.level >= 0) full = util.fmt("{s} -{d}", .{ cmd, args_g.level });
    const ok = writeTarArchive();
    const r = os.run(&.{full}, .{ .stdin_data = tar_out.items, .use_shell = true });
    if (r.status != 0) util.die("'{s}' filter reported error", .{full});
    return ok;
}

// ---------------------------------------------------------------------------
// zip

var zip_out: Buf = .empty;
var zip_dir: Buf = .empty;
var zip_dir_entries: u64 = 0;
var zip_date: u16 = 0;
var zip_time: u16 = 0;
var max_creator_version: u32 = 0;

fn le(b: *Buf, size: usize, n0: u64) void {
    var n = n0;
    var i: usize = 0;
    while (i < size) : (i += 1) {
        util.bufByte(b, @truncate(n));
        n >>= 8;
    }
}

fn clamp32(n: u64) u64 {
    return if (n < 0xffffffff) n else 0xffffffff;
}

fn bufferIsBinary(data: []const u8) bool {
    const n = @min(data.len, 8000);
    return std.mem.indexOfScalar(u8, data[0..n], 0) != null;
}

fn entryIsBinary(path: []const u8, data: []const u8) bool {
    var drv = userdiff.findByPath(path);
    if (drv == null) drv = userdiff.findByName("default");
    if (drv) |d| {
        if (d.binary != -1) return d.binary != 0;
    }
    return bufferIsBinary(data);
}

fn zipEntry(oid: Oid, path: []const u8, mode: u32, data: []const u8) bool {
    const offset: u64 = zip_out.items.len;
    var flags: u16 = 0;
    var creator_version: u32 = 0;
    var version_needed: u32 = 10;
    var method: u16 = 0;
    var attr2: u64 = 0;
    var compressed_size: u64 = 0;
    var crc: u32 = 0;
    var is_binary: i32 = -1;
    var out: []const u8 = "";
    const size: u64 = data.len;

    var ascii = true;
    for (path) |ch| {
        if (ch >= 0x80) ascii = false;
    }
    if (!ascii) {
        if (pretty.isUtf8(path)) flags |= 1 << 11 else util.warn("path is not valid UTF-8: {s}", .{path});
    }
    if (path.len > 0xffff) {
        util.err("path too long ({d} chars, SHA1: {s}): {s}", .{ path.len, hash.hex(oid), path });
        return false;
    }
    if (isDirMode(mode) or isGitlink(mode)) {
        attr2 = 16;
    } else if (isReg(mode) or isLnk(mode)) {
        attr2 = if (isLnk(mode)) (@as(u64, mode | 0o777) << 16) else if (mode & 0o111 != 0) (@as(u64, mode) << 16) else 0;
        if (isLnk(mode) or mode & 0o111 != 0) creator_version = 0x0317;
        if (isReg(mode) and args_g.level != 0 and size > 0) method = 8;
        crc = zlib.crc(0, data);
        const pwp = if (path.len >= args_g.base.len) path[args_g.base.len..] else path;
        is_binary = if (entryIsBinary(pwp, data)) 1 else 0;
        out = data;
        compressed_size = if (method == 0) size else 0;
    } else {
        util.err("unsupported file mode: 0{o} (SHA1: {s})", .{ mode, hash.hex(oid) });
        return false;
    }
    if (creator_version > max_creator_version) max_creator_version = creator_version;
    if (method == 8) {
        const d = deflateRaw(data, args_g.level);
        if (d == null or d.?.len >= size) {
            out = data;
            method = 0;
            compressed_size = size;
        } else {
            out = d.?;
            compressed_size = d.?.len;
        }
    }
    var extra: Buf = .empty;
    le(&extra, 2, 0x5455);
    le(&extra, 2, 5);
    util.bufByte(&extra, 1);
    le(&extra, 4, args_g.time & 0xffffffff);

    const need64 = size > 0xffffffff or compressed_size > 0xffffffff;
    if (need64) version_needed = 45;
    const b = &zip_out;
    le(b, 4, 0x04034b50);
    le(b, 2, version_needed);
    le(b, 2, flags);
    le(b, 2, method);
    le(b, 2, zip_time);
    le(b, 2, zip_date);
    le(b, 4, crc);
    if (need64) {
        le(b, 4, 0xffffffff);
        le(b, 4, 0xffffffff);
    } else {
        le(b, 4, compressed_size);
        le(b, 4, size);
    }
    le(b, 2, path.len);
    le(b, 2, extra.items.len + @as(usize, if (need64) 20 else 0));
    util.bufAppend(b, path);
    util.bufAppend(b, extra.items);
    if (need64) {
        le(b, 2, 1);
        le(b, 2, 16);
        le(b, 8, size);
        le(b, 8, compressed_size);
    }
    if (compressed_size > 0) util.bufAppend(b, out[0..compressed_size]);

    var zip64_payload: u64 = 0;
    var dir_extra_size: u64 = extra.items.len;
    if (compressed_size > 0xffffffff or size > 0xffffffff or offset > 0xffffffff) {
        if (compressed_size >= 0xffffffff) zip64_payload += 8;
        if (size >= 0xffffffff) zip64_payload += 8;
        if (offset >= 0xffffffff) zip64_payload += 8;
        dir_extra_size += 4 + zip64_payload;
    }
    const d = &zip_dir;
    le(d, 4, 0x02014b50);
    le(d, 2, creator_version);
    le(d, 2, version_needed);
    le(d, 2, flags);
    le(d, 2, method);
    le(d, 2, zip_time);
    le(d, 2, zip_date);
    le(d, 4, crc);
    le(d, 4, clamp32(compressed_size));
    le(d, 4, clamp32(size));
    le(d, 2, path.len);
    le(d, 2, dir_extra_size);
    le(d, 2, 0);
    le(d, 2, 0);
    le(d, 2, if (is_binary == 0) 1 else 0);
    le(d, 4, attr2);
    le(d, 4, clamp32(offset));
    util.bufAppend(d, path);
    util.bufAppend(d, extra.items);
    if (zip64_payload != 0) {
        le(d, 2, 1);
        le(d, 2, zip64_payload);
        if (size >= 0xffffffff) le(d, 8, size);
        if (compressed_size >= 0xffffffff) le(d, 8, compressed_size);
        if (offset >= 0xffffffff) le(d, 8, offset);
    }
    zip_dir_entries += 1;
    return true;
}

fn writeZipTrailer() void {
    const zip_offset: u64 = zip_out.items.len;
    var clamped = false;
    if (zip_dir_entries > 0xffff or zip_offset > 0xffffffff) clamped = true;
    util.bufAppend(&zip_out, zip_dir.items);
    const b = &zip_out;
    if (clamped) {
        le(b, 4, 0x06064b50);
        le(b, 8, 44);
        le(b, 2, max_creator_version);
        le(b, 2, 45);
        le(b, 4, 0);
        le(b, 4, 0);
        le(b, 8, zip_dir_entries);
        le(b, 8, zip_dir_entries);
        le(b, 8, zip_dir.items.len);
        le(b, 8, zip_offset);
        le(b, 4, 0x07064b50);
        le(b, 4, 0);
        le(b, 8, zip_offset + zip_dir.items.len);
        le(b, 4, 1);
    }
    le(b, 4, 0x06054b50);
    le(b, 2, 0);
    le(b, 2, 0);
    le(b, 2, @min(zip_dir_entries, 0xffff));
    le(b, 2, @min(zip_dir_entries, 0xffff));
    le(b, 4, zip_dir.items.len);
    le(b, 4, @min(zip_offset, 0xffffffff));
    le(b, 2, if (args_g.commit_oid != null) 40 else 0);
    if (args_g.commit_oid) |o| {
        const hx = hash.hex(o);
        util.bufAppend(b, &hx);
    }
}

fn writeZipArchive() bool {
    const t: i64 = @intCast(@min(args_g.time, @as(u64, std.math.maxInt(i64))));
    if (date.dateOverflows(t)) util.die("timestamp too large for this system: {d}", .{args_g.time});
    const tm = os.localtime(t);
    zip_date = @truncate(@as(u32, @bitCast(tm.mday + (tm.mon + 1) * 32 + (tm.year + 1900 - 1980) * 512)));
    zip_time = @truncate(@as(u32, @bitCast(@divTrunc(tm.sec, 2) + tm.min * 32 + tm.hour * 2048)));
    const ok = writeArchiveEntries();
    if (ok) writeZipTrailer();
    writeOut(zip_out.items);
    return ok;
}

// ---------------------------------------------------------------------------
// setup

fn parseTreeish(name: []const u8, worktree_attributes: bool, mtime_option: ?[]const u8) void {
    const a = &args_g;
    const oid = revparse.getOid(name) orelse util.die("not a valid object name: {s}", .{name});
    if (cn.lookupCommitReference(oid)) |c| {
        _ = cn.parse(c);
        a.commit = c;
        a.commit_oid = c.obj.oid;
        a.time = c.date;
    } else {
        a.time = @intCast(@max(os.now(), 0));
    }
    if (mtime_option) |m| a.time = @bitCast(date.approxidate(m));
    const tree = objects.peelTo(oid, .tree) orelse util.die("not a tree object: {s}", .{hash.hex(oid)});
    a.tree = tree;
    if (!worktree_attributes) {
        const idx = gpa.create(index_mod.Index) catch util.oom();
        idx.* = .{};
        index_mod.addTreeRecursive(idx, tree, "", 0);
        std.mem.sort(index_mod.Entry, idx.entries.items, {}, index_mod.entryLess);
        _ = index_mod.swapCurrent(idx);
        attr.setDirection(.index);
    }
}

const ExistsCtx = struct { ps: *const pathspec.Pathspec };

fn rejectOutside(tree: Oid, base: []const u8, ps: *const pathspec.Pathspec) bool {
    const entries = objects.readTree(tree) orelse return false;
    for (entries) |te| {
        const full = util.concat(&.{ base, te.name });
        if (isDirMode(te.mode)) {
            if (!ps.couldMatchUnder(full)) continue;
            if (rejectOutside(te.oid, util.concat(&.{ full, "/" }), ps)) return true;
        } else {
            if (!ps.matches(full, false)) continue;
            if (util.startsWith(util.relativePath(full, args_g.prefix), "../")) return true;
        }
    }
    return false;
}

fn pathExistsWalk(tree: Oid, base: []const u8, ps: *const pathspec.Pathspec) bool {
    const entries = objects.readTree(tree) orelse return false;
    for (entries) |te| {
        const full = util.concat(&.{ base, te.name });
        if (isDirMode(te.mode)) {
            if (!ps.couldMatchUnder(full)) continue;
            if (ps.matches(full, true)) return true;
            if (pathExistsWalk(te.oid, util.concat(&.{ full, "/" }), ps)) return true;
        } else {
            if (ps.matches(full, false)) return true;
        }
    }
    return false;
}

fn pathExists(p: []const u8) bool {
    const ps = pathspec.parse(args_g.prefix, &.{p}, .{ .prefer_cwd = true });
    if (args_g.prefix.len > 0 and rejectOutside(args_g.tree, "", &ps))
        util.die("pathspec '{s}' matches files outside the current directory", .{p});
    return pathExistsWalk(args_g.tree, "", &ps);
}

pub fn cmdArchive(args: []const []const u8) u8 {
    var format: ?[]const u8 = null;
    var remote: ?[]const u8 = null;
    var exec: ?[]const u8 = null;
    var output: ?[]const u8 = null;
    var mtime_option: ?[]const u8 = null;
    var verbose: i32 = 0;
    var list = false;
    var worktree_attributes = false;
    var is_remote = false;

    opt_prefix = if (repo_mod.repo_) |r| r.prefix else "";
    po.prefix = opt_prefix;

    const opts = [_]po.Opt{
        po.group(""),
        po.string(0, "format", &format, "fmt", "archive format"),
        po.string(0, "prefix", &opt_base, "prefix", "prepend prefix to each pathname in the archive"),
        po.callback(0, "add-file", addFileCb, "file", "add untracked file to archive"),
        po.callback(0, "add-virtual-file", addVirtualFileCb, "path:content", "add untracked file to archive"),
        po.filename('o', "output", &output, "file", "write the archive to this file"),
        po.boolean(0, "worktree-attributes", &worktree_attributes, "read .gitattributes in working directory"),
        po.counter('v', "verbose", &verbose, "report archived files on stderr"),
        .{ .long = "mtime", .kind = .string, .s = &mtime_option, .argh = "time", .help = "set modification time of archive entries", .noneg = true },
        .{ .kind = .number, .cb = numberCb, .help = "set compression level" },
        po.group(""),
        po.boolean('l', "list", &list, "list supported archive formats"),
        po.group(""),
        po.string(0, "remote", &remote, "repo", "retrieve the archive from remote repository <repo>"),
        po.string(0, "exec", &exec, "command", "path to the remote git-upload-archive command"),
        .{ .long = "internal-upload-archive", .kind = .boolean, .b = &is_remote, .hidden = true, .noneg = true },
    };

    // builtin/archive.c parses -o/--remote/--exec first; emulate the
    // early output file creation by scanning the parsed result.
    const rest = po.parse(args[1..], &opts, &archive_usage, .{});

    initArchivers();

    if (output) |o| {
        const fd = os.openFile(o, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o666);
        if (fd < 0) util.dieErrno("could not open '{s}' for writing", .{o});
        if (fd != 1) {
            if (dup2(fd, 1) < 0) util.dieErrno("could not redirect output", .{});
            os.close(fd);
        }
    }

    if (remote) |r| return runRemote(r, exec, output, args[1..]);
    if (is_remote and extra_files.items.len > 0) util.die("options '{s}' and '{s}' cannot be used together", .{ "--add-file", "--remote" });
    if (exec != null) util.die("the option '{s}' requires '{s}'", .{ "--exec", "--remote" });

    if (list) {
        if (rest.len > 0) util.die("extra command line parameter '{s}'", .{rest[0]});
        for (archivers.items) |a| if (!is_remote or a.remote) util.outf("{s}\n", .{a.name});
        util.flushStdout();
        return 0;
    }

    if (format == null) {
        if (output) |o| format = formatFromFilename(o);
    }
    const fmt_name = format orelse "tar";
    if (rest.len < 1) po.usageWithOptions(&archive_usage, &opts);
    const ar = lookupArchiver(fmt_name) orelse util.die("Unknown archive format '{s}'", .{fmt_name});
    if (is_remote and !ar.remote) util.die("Unknown archive format '{s}'", .{fmt_name});

    const a = &args_g;
    a.level = -1;
    if (compression_level != -1) {
        if (ar.levels and (compression_level <= 9 or ar.high)) {
            a.level = compression_level;
        } else util.die("Argument not supported for format '{s}': -{d}", .{ fmt_name, compression_level });
    }
    a.verbose = verbose > 0;
    a.base = opt_base orelse "";
    a.kind = ar.kind;
    a.prefix = opt_prefix;
    a.ctx = .{ .fmt = .userformat, .abbrev = revparse.defaultAbbrev(), .describe_max_invocations = &describe_budget };

    if (repo_mod.repo_ == null) repo_mod.setup(false);

    if (is_remote and !(repo_mod.cfg.getBool("uploadarchive.allowunreachable") orelse false)) {
        const nm = rest[0];
        const refpart = nm[0 .. std.mem.indexOfScalar(u8, nm, ':') orelse nm.len];
        if (refs.dwimRef(refpart) == null) util.die("no such ref: {s}", .{refpart});
    }
    parseTreeish(rest[0], worktree_attributes, mtime_option);

    a.pspec = pathspec.parse(a.prefix, rest[1..], .{ .prefer_cwd = true });
    for (rest[1..]) |p| {
        if (p.len > 0 and !pathExists(p)) util.die("pathspec '{s}' did not match any files", .{p});
    }

    const ok = switch (ar.kind) {
        .tar => blk: {
            const r = writeTarArchive();
            writeOut(tar_out.items);
            break :blk r;
        },
        .filter => writeTarFilterArchive(ar),
        .zip => writeZipArchive(),
    };
    return if (ok) 0 else 255;
}

// ---------------------------------------------------------------------------
// --remote (local repositories only): run the archiver inside the remote
// repository, with the restrictions git-upload-archive applies.

fn runRemote(remote: []const u8, exec: ?[]const u8, output: ?[]const u8, argv: []const []const u8) u8 {
    const transport = @import("../transport.zig");
    const pkt = @import("../pktline.zig");
    const rem = transport.remoteGet(remote) orelse util.die("bad repository '{s}'", .{remote});
    const t = transport.transportGet(rem, null);
    var cmdv: std.ArrayList([]const u8) = .empty;
    const prog = exec orelse "git-upload-archive";
    if (util.eql(prog, "git-upload-archive")) {
        cmdv.appendSlice(gpa, &.{ proc.gitBinary(), "upload-archive", t.path }) catch util.oom();
    } else {
        var b: Buf = .empty;
        util.bufAppend(&b, prog);
        util.bufByte(&b, ' ');
        util.sqQuote(&b, t.path);
        cmdv.appendSlice(gpa, &.{ "/bin/sh", "-c", b.items }) catch util.oom();
    }
    const ch = proc.spawn(cmdv.items, .{ .pipe_in = true, .pipe_out = true, .unset_env = &transport.local_repo_env });
    if (output) |o| {
        if (formatFromFilename(o)) |f| pkt.writeFmt(ch.in, "argument --format={s}\n", .{f});
    }
    var i: usize = 0;
    while (i < argv.len) : (i += 1) {
        const x = argv[i];
        if (util.eql(x, "--remote") or util.eql(x, "--exec") or util.eql(x, "-o") or util.eql(x, "--output")) {
            i += 1;
            continue;
        }
        if (util.eql(x, "--")) {
            for (argv[i..]) |y| pkt.writeFmt(ch.in, "argument {s}\n", .{y});
            break;
        }
        if (util.startsWith(x, "--remote=") or util.startsWith(x, "--exec=") or util.startsWith(x, "--output=")) continue;
        if (util.startsWith(x, "-o") and x.len > 2) continue;
        pkt.writeFmt(ch.in, "argument {s}\n", .{x});
    }
    pkt.flush(ch.in);
    var r = pkt.Reader.init(ch.out);
    r.chomp = true;
    r.gentle_eof = true;
    const st = r.read();
    if (st == .eof) transport.dieInitialContact(false);
    if (st != .normal) util.die("git archive: expected ACK/NAK, got a flush packet", .{});
    if (r.line.len > 0 and r.line[0] == 3) util.die("remote error: {s}", .{r.line[1..]});
    if (!util.eql(r.line, "ACK")) {
        if (util.skipPrefix(r.line, "NACK ")) |m| util.die("git archive: NACK {s}", .{m});
        util.die("git archive: protocol error", .{});
    }
    if (r.read() != .flush) util.die("git archive: expected a flush", .{});
    r.chomp = false;
    var d: pkt.Demux = .{};
    var failed = false;
    while (true) {
        _ = r.read();
        if (r.status == .normal and r.line.len > 0 and r.line[0] == 3) {
            d.finish();
            var msg = r.line[1..];
            if (msg.len > 0 and msg[msg.len - 1] == '\n') msg = msg[0 .. msg.len - 1];
            util.eprint("remote: {s}\n", .{msg});
            failed = true;
            break;
        }
        switch (d.handle(&r, "archive")) {
            .data => |data| writeOut(data),
            .consumed => {},
            .end => break,
        }
    }
    os.close(ch.in);
    const rc = proc.wait(ch.pid);
    return if (rc != 0 or failed) 1 else 0;
}
