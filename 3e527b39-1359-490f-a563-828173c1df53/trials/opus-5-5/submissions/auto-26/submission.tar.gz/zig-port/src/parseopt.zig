//! Port of git's parse-options: declarative option tables.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const gpa = util.gpa;

pub const Kind = enum { boolean, counter, set_int, bit, negbit, string, int, uint, list, callback, number, group, filename };

pub const Callback = *const fn (arg: ?[]const u8, unset: bool) void;

pub const Opt = struct {
    short: u8 = 0,
    long: []const u8 = "",
    kind: Kind,
    b: ?*bool = null,
    i: ?*i32 = null,
    s: ?*?[]const u8 = null,
    l: ?*std.ArrayList([]const u8) = null,
    cb: ?Callback = null,
    val: i32 = 1,
    def: ?[]const u8 = null,
    argh: []const u8 = "",
    help: []const u8 = "",
    optarg: bool = false,
    noneg: bool = false,
    hidden: bool = false,
    noarg: bool = false,
    literal_argh: bool = false,
    lastarg_default: bool = false,
    /// PARSE_OPT_NODASH: matched as a bare one-char argument (e.g. "(")
    nodash: bool = false,
    /// callback receiving the option itself (used by rev-parse --parseopt)
    cbx: ?*const fn (o: *const Opt, arg: ?[]const u8, unset: bool) void = null,
};

pub fn boolean(short: u8, long: []const u8, b: *bool, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .boolean, .b = b, .help = help };
}
pub fn counter(short: u8, long: []const u8, i: *i32, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .counter, .i = i, .help = help };
}
pub fn setInt(short: u8, long: []const u8, i: *i32, v: i32, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .set_int, .i = i, .val = v, .help = help };
}
pub fn bit(short: u8, long: []const u8, i: *i32, v: i32, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .bit, .i = i, .val = v, .help = help };
}
pub fn string(short: u8, long: []const u8, s: *?[]const u8, argh: []const u8, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .string, .s = s, .argh = argh, .help = help };
}
pub fn filename(short: u8, long: []const u8, s: *?[]const u8, argh: []const u8, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .filename, .s = s, .argh = argh, .help = help };
}
pub fn optString(short: u8, long: []const u8, s: *?[]const u8, def: []const u8, argh: []const u8, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .string, .s = s, .def = def, .optarg = true, .argh = argh, .help = help };
}
pub fn integer(short: u8, long: []const u8, i: *i32, argh: []const u8, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .int, .i = i, .argh = argh, .help = help };
}
pub fn list(short: u8, long: []const u8, l: *std.ArrayList([]const u8), argh: []const u8, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .list, .l = l, .argh = argh, .help = help };
}
pub fn callback(short: u8, long: []const u8, cb: Callback, argh: []const u8, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .callback, .cb = cb, .argh = argh, .help = help };
}
pub fn callbackNoArg(short: u8, long: []const u8, cb: Callback, help: []const u8) Opt {
    return .{ .short = short, .long = long, .kind = .callback, .cb = cb, .noarg = true, .help = help };
}
pub fn group(title: []const u8) Opt {
    return .{ .kind = .group, .help = title };
}
pub fn quiet(i: *i32) Opt {
    return .{ .short = 'q', .long = "quiet", .kind = .counter, .i = i, .val = -1, .help = "be more quiet" };
}
pub fn verbose(i: *i32) Opt {
    return .{ .short = 'v', .long = "verbose", .kind = .counter, .i = i, .help = "be more verbose" };
}

pub const Flags = struct {
    stop_at_non_option: bool = false,
    keep_dashdash: bool = false,
    keep_unknown: bool = false,
    no_internal_help: bool = false,
    one_shot: bool = false,
};

const Err = error{ Usage, UsageStdout };

const Ctx = struct {
    args: []const []const u8,
    idx: usize,
    opt: ?[]const u8 = null, // remaining short cluster / long =value
    opts: []const Opt,
};

fn optname(o: *const Opt, short: bool, unset: bool) []const u8 {
    if (short) return util.fmt("switch `{c}'", .{o.short});
    if (unset) return util.fmt("option `no-{s}'", .{o.long});
    return util.fmt("option `{s}'", .{o.long});
}

fn getArg(c: *Ctx, o: *const Opt, short: bool, unset: bool) ![]const u8 {
    if (c.opt) |v| {
        c.opt = null;
        return v;
    }
    if (c.idx + 1 == c.args.len and o.lastarg_default) return o.def orelse "";
    if (c.idx + 1 < c.args.len) {
        c.idx += 1;
        return c.args[c.idx];
    }
    util.err("{s} requires a value", .{optname(o, short, unset)});
    return error.Usage;
}

pub fn parseIntArg(s: []const u8) ?i64 {
    if (s.len == 0) return null;
    var num = s;
    var factor: i64 = 1;
    const last = std.ascii.toLower(s[s.len - 1]);
    if (last == 'k' or last == 'm' or last == 'g') {
        num = s[0 .. s.len - 1];
        factor = if (last == 'k') 1024 else if (last == 'm') 1024 * 1024 else 1024 * 1024 * 1024;
    }
    const v = std.fmt.parseInt(i64, num, 0) catch return null;
    return v * factor;
}

fn getValue(c: *Ctx, o: *const Opt, short: bool, unset: bool) !void {
    if (unset and c.opt != null) {
        util.err("{s} takes no value", .{optname(o, short, unset)});
        return error.Usage;
    }
    if (unset and o.noneg) {
        util.err("{s} isn't available", .{optname(o, short, unset)});
        return error.Usage;
    }
    const takes_no_arg = switch (o.kind) {
        .boolean, .counter, .set_int, .bit, .negbit => true,
        .callback => o.noarg,
        else => false,
    };
    if (!short and c.opt != null and takes_no_arg) {
        util.err("{s} takes no value", .{optname(o, short, unset)});
        return error.Usage;
    }
    switch (o.kind) {
        .boolean => o.b.?.* = !unset,
        .counter => {
            if (unset) o.i.?.* = 0 else if (o.val < 0) o.i.?.* -= 1 else {
                if (o.i.?.* < 0) o.i.?.* = 0;
                o.i.?.* += 1;
            }
            if (unset) return;
        },
        .set_int => o.i.?.* = if (unset) 0 else o.val,
        .bit => {
            if (unset) o.i.?.* &= ~o.val else o.i.?.* |= o.val;
        },
        .negbit => {
            if (unset) o.i.?.* |= o.val else o.i.?.* &= ~o.val;
        },
        .string, .filename => {
            if (unset) {
                o.s.?.* = null;
            } else if (o.optarg and c.opt == null) {
                o.s.?.* = o.def orelse "";
            } else {
                var v = try getArg(c, o, short, unset);
                if (o.kind == .filename) v = fixFilename(v);
                o.s.?.* = v;
            }
        },
        .list => {
            if (unset) {
                o.l.?.clearRetainingCapacity();
            } else {
                const v = try getArg(c, o, short, unset);
                o.l.?.append(gpa, v) catch util.oom();
            }
        },
        .int, .uint => {
            if (unset) {
                o.i.?.* = 0;
                return;
            }
            if (o.optarg and c.opt == null) {
                o.i.?.* = o.val;
                return;
            }
            const v = try getArg(c, o, short, unset);
            const n = parseIntArg(v) orelse {
                util.err("{s} expects a numerical value", .{optname(o, short, unset)});
                return error.Usage;
            };
            if (o.kind == .uint and n < 0) {
                util.err("{s} expects a non-negative integer value with an optional k/m/g suffix", .{optname(o, short, unset)});
                return error.Usage;
            }
            o.i.?.* = @intCast(std.math.clamp(n, std.math.minInt(i32), std.math.maxInt(i32)));
        },
        .callback => {
            cb_short = short;
            if (o.cbx) |f| {
                if (unset or o.noarg) {
                    f(o, null, unset);
                } else if (o.optarg and c.opt == null) {
                    f(o, null, false);
                } else {
                    f(o, try getArg(c, o, short, unset), false);
                }
                return;
            }
            if (unset or o.noarg) {
                o.cb.?(null, unset);
            } else if (o.optarg and c.opt == null) {
                o.cb.?(o.def, false);
            } else {
                const v = try getArg(c, o, short, unset);
                o.cb.?(v, false);
            }
        },
        .number, .group => {},
    }
}

pub var prefix: []const u8 = "";
/// Whether the option currently being handled by a callback was given in
/// its short form (for callers that need to name it in messages).
pub var cb_short: bool = false;

fn fixFilename(f: []const u8) []const u8 {
    if (f.len == 0) return f;
    if (util.eql(f, "-")) return f;
    if (f[0] == '/') return f;
    if (prefix.len == 0) return f;
    return util.concat(&.{ prefix, f });
}

fn parseShort(c: *Ctx) !bool {
    const s = c.opt.?;
    var numopt: ?*const Opt = null;
    for (c.opts) |*o| {
        if (o.kind == .group) continue;
        if (o.short != 0 and o.short == s[0]) {
            c.opt = if (s.len > 1) s[1..] else null;
            try getValue(c, o, true, false);
            return true;
        }
        if (o.kind == .number) numopt = o;
    }
    if (numopt) |no| {
        if (std.ascii.isDigit(s[0])) {
            var len: usize = 1;
            while (len < s.len and std.ascii.isDigit(s[len])) len += 1;
            const arg = s[0..len];
            c.opt = if (len < s.len) s[len..] else null;
            if (no.cb) |cb| cb(arg, false) else if (no.i) |ip| ip.* = std.fmt.parseInt(i32, arg, 10) catch std.math.maxInt(i32);
            return true;
        }
    }
    return false;
}

const Abbrev = struct { o: ?*const Opt = null, unset: bool = false };

fn parseLong(c: *Ctx, arg: []const u8) !bool {
    const eqpos = std.mem.indexOfScalar(u8, arg, '=');
    const arg_end = eqpos orelse arg.len;
    var start = arg;
    var unset_flag = false;
    var no_no = false;
    if (util.skipPrefix(start, "no-")) |r| {
        start = r;
        if (util.skipPrefix(start, "no-")) |r2| {
            start = r2;
            no_no = true;
        } else unset_flag = true;
    }
    var abbrev = Abbrev{};
    var ambiguous = Abbrev{};
    for (c.opts) |*o| {
        if (o.kind == .group or o.long.len == 0) continue;
        var long_name = o.long;
        var opt_unset = false;
        const allow_unset = !o.noneg;
        if (util.skipPrefix(long_name, "no-")) |r| {
            long_name = r;
            opt_unset = true;
        } else if (no_no) continue;
        if ((unset_flag != opt_unset) and !allow_unset) continue;
        if (util.startsWith(start, long_name)) {
            const rest = start[long_name.len..];
            if (rest.len > 0 and rest[0] == '=') {
                c.opt = rest[1..];
            } else if (rest.len > 0) {
                continue;
            }
            try getValue(c, o, false, unset_flag != opt_unset);
            return true;
        }
        _ = abbrevCheck(c, o, long_name, arg, start, arg_end, unset_flag, opt_unset, allow_unset, &abbrev, &ambiguous);
    }
    if (ambiguous.o) |amb| {
        util.err("ambiguous option: {s} (could be --{s}{s} or --{s}{s})", .{
            arg,
            if (ambiguous.unset) "no-" else "",
            amb.long,
            if (abbrev.unset) "no-" else "",
            abbrev.o.?.long,
        });
        return error.Usage;
    }
    if (abbrev.o) |ab| {
        if (arg_end < arg.len) c.opt = arg[arg_end + 1 ..];
        try getValue(c, ab, false, abbrev.unset);
        return true;
    }
    return false;
}

fn abbrevCheck(c: *Ctx, o: *const Opt, long_name: []const u8, arg: []const u8, start: []const u8, arg_end: usize, unset_flag: bool, opt_unset: bool, allow_unset: bool, abbrev: *Abbrev, ambiguous: *Abbrev) bool {
    _ = c;
    const start_off = arg.len - start.len;
    const alen = if (arg_end >= start_off) arg_end - start_off else 0;
    if (alen <= long_name.len and std.mem.eql(u8, long_name[0..alen], start[0..alen])) {
        register(o, unset_flag != opt_unset, abbrev, ambiguous);
    }
    if (allow_unset and util.startsWith("no-", arg)) {
        register(o, !opt_unset, abbrev, ambiguous);
    }
    return false;
}

fn register(o: *const Opt, unset: bool, abbrev: *Abbrev, ambiguous: *Abbrev) void {
    if (abbrev.o) |prev| {
        if (prev != o or abbrev.unset != unset) {
            ambiguous.* = abbrev.*;
        }
    }
    abbrev.* = .{ .o = o, .unset = unset };
}

fn checkTypos(arg: []const u8, opts: []const Opt) void {
    if (arg.len < 3) return;
    if (util.startsWith(arg, "no-")) {
        util.err("did you mean `--{s}` (with two dashes)?", .{arg});
        os.exit(129);
    }
    for (opts) |o| {
        if (o.long.len == 0) continue;
        if (util.startsWith(o.long, arg)) {
            util.err("did you mean `--{s}` (with two dashes)?", .{arg});
            os.exit(129);
        }
    }
}

/// Parse options. Returns remaining (non-option) arguments. On error prints usage and exits 129.
/// `args` excludes the command name.
pub fn parse(args: []const []const u8, opts: []const Opt, usage: []const []const u8, flags: Flags) [][]const u8 {
    var c = Ctx{ .args = args, .idx = 0, .opts = opts };
    var outl: std.ArrayList([]const u8) = .empty;
    while (c.idx < args.len) : (c.idx += 1) {
        const arg = args[c.idx];
        c.opt = null;
        if (arg.len < 2 or arg[0] != '-') {
            if (arg.len == 1) {
                var hit = false;
                for (opts) |*o| {
                    if (o.nodash and o.short == arg[0]) {
                        if (o.cb) |cb| cb(null, false);
                        hit = true;
                        break;
                    }
                }
                if (hit) continue;
            }
            if (flags.stop_at_non_option) break;
            outl.append(gpa, arg) catch util.oom();
            continue;
        }
        if (!flags.no_internal_help and args.len == 1 and util.eql(arg, "-h")) usageExit(usage, opts, false);
        if (arg[1] != '-') {
            c.opt = arg[1..];
            const ok = parseShort(&c) catch usageExit(usage, opts, true);
            if (!ok) {
                if (c.opt != null) checkTypos(arg[1..], opts);
                if (!flags.no_internal_help and c.opt.?[0] == 'h') usageExit(usage, opts, false);
                if (flags.keep_unknown) {
                    outl.append(gpa, arg) catch util.oom();
                    continue;
                }
                util.err("unknown switch `{c}'", .{c.opt.?[0]});
                usageExit(usage, opts, true);
            }
            if (c.opt != null) checkTypos(arg[1..], opts);
            while (c.opt) |rest| {
                const ok2 = parseShort(&c) catch usageExit(usage, opts, true);
                if (!ok2) {
                    if (!flags.no_internal_help and rest[0] == 'h') usageExit(usage, opts, false);
                    if (flags.keep_unknown) {
                        outl.append(gpa, util.concat(&.{ "-", rest })) catch util.oom();
                        break;
                    }
                    util.err("unknown switch `{c}'", .{rest[0]});
                    usageExit(usage, opts, true);
                }
            }
            continue;
        }
        if (arg.len == 2) {
            if (flags.keep_dashdash) {
                outl.appendSlice(gpa, args[c.idx..]) catch util.oom();
            } else {
                outl.appendSlice(gpa, args[c.idx + 1 ..]) catch util.oom();
            }
            return outl.items;
        }
        if (util.eql(arg, "--end-of-options")) {
            if (flags.keep_unknown) {
                outl.appendSlice(gpa, args[c.idx..]) catch util.oom();
            } else outl.appendSlice(gpa, args[c.idx + 1 ..]) catch util.oom();
            return outl.items;
        }
        if (!flags.no_internal_help and (util.eql(arg, "--help-all") or util.eql(arg, "--help"))) usageExit(usage, opts, false);
        const ok = parseLong(&c, arg[2..]) catch usageExit(usage, opts, true);
        if (!ok) {
            if (flags.keep_unknown) {
                outl.append(gpa, arg) catch util.oom();
                continue;
            }
            util.err("unknown option `{s}'", .{arg[2..]});
            usageExit(usage, opts, true);
        }
    }
    if (c.idx < args.len) outl.appendSlice(gpa, args[c.idx..]) catch util.oom();
    return outl.items;
}

pub fn usageExit(usage: []const []const u8, opts: []const Opt, to_err: bool) noreturn {
    printUsage(usage, opts, to_err);
    // C 2.56 parse-options.c: PARSE_OPT_HELP (-h) -> exit(0); usage errors -> 129.
    // Do NOT change this to always 129 (verified against git-src/parse-options.c:1207).
    os.exit(if (to_err) 129 else 0);
}

pub fn usageWithOptions(usage: []const []const u8, opts: []const Opt) noreturn {
    usageExit(usage, opts, true);
}

/// PARSE_OPT_SHELL_EVAL: wrap help output in a shell here-doc
pub var shell_eval = false;

pub fn printUsage(usage: []const []const u8, opts: []const Opt, to_err: bool) void {
    var b: util.Buf = .empty;
    if (!to_err and shell_eval) util.bufAppend(&b, "cat <<\\EOF\n");
    var first = true;
    var saw_empty = false;
    for (usage) |str| {
        if (!saw_empty and str.len == 0) saw_empty = true;
        var it = std.mem.splitScalar(u8, str, '\n');
        var j: usize = 0;
        while (it.next()) |line| : (j += 1) {
            if (saw_empty and line.len > 0) {
                util.bufPrint(&b, "    {s}\n", .{line});
            } else if (saw_empty) {
                util.bufByte(&b, '\n');
            } else if (j == 0) {
                util.bufPrint(&b, "{s}{s}\n", .{ if (first) "usage: " else "   or: ", line });
            } else {
                util.bufPrint(&b, "       {s}\n", .{line});
            }
        }
        first = false;
    }
    var need_newline = true;
    for (opts) |o| {
        if (o.hidden) continue;
        if (o.kind == .group) {
            util.bufByte(&b, '\n');
            need_newline = false;
            if (o.help.len > 0) util.bufPrint(&b, "{s}\n", .{o.help});
            continue;
        }
        if (need_newline) {
            util.bufByte(&b, '\n');
            need_newline = false;
        }
        const start = b.items.len;
        util.bufAppend(&b, "    ");
        if (o.short != 0) util.bufPrint(&b, "{s}{c}", .{ if (o.nodash) "" else "-", o.short });
        if (o.short != 0 and o.long.len > 0) util.bufAppend(&b, ", ");
        var positive: ?[]const u8 = null;
        if (o.long.len > 0) {
            if (o.noneg or util.startsWith(o.long, "no-")) {
                util.bufPrint(&b, "--{s}", .{o.long});
                if (util.startsWith(o.long, "no-") and !o.noneg) positive = o.long[3..];
            } else util.bufPrint(&b, "--[no-]{s}", .{o.long});
        }
        if (o.kind == .number) util.bufAppend(&b, "-NUM");
        const takes_arg = switch (o.kind) {
            .string, .filename, .int, .uint, .list => true,
            .callback => !o.noarg,
            else => false,
        };
        if (takes_arg or o.literal_argh) {
            const argh = if (o.argh.len > 0) o.argh else "...";
            const literal = o.literal_argh or o.argh.len == 0 or std.mem.indexOfAny(u8, argh, "()<>[]|") != null;
            if (o.optarg) {
                if (o.long.len > 0) {
                    if (literal) util.bufPrint(&b, "[={s}]", .{argh}) else util.bufPrint(&b, "[=<{s}>]", .{argh});
                } else {
                    if (literal) util.bufPrint(&b, "[{s}]", .{argh}) else util.bufPrint(&b, "[<{s}>]", .{argh});
                }
            } else {
                if (literal) util.bufPrint(&b, " {s}", .{argh}) else util.bufPrint(&b, " <{s}>", .{argh});
            }
        }
        var pos = b.items.len - start;
        var it = std.mem.splitScalar(u8, o.help, '\n');
        var any = false;
        while (it.next()) |line| {
            if (any) util.bufByte(&b, '\n');
            pad(&b, pos);
            util.bufAppend(&b, line);
            pos = 0;
            any = true;
        }
        util.bufByte(&b, '\n');
        if (positive) |p| {
            var found = false;
            for (opts) |o2| {
                if (util.eql(o2.long, p)) found = true;
            }
            if (!found) {
                const s2 = b.items.len;
                util.bufPrint(&b, "    --{s}", .{p});
                pad(&b, b.items.len - s2);
                util.bufPrint(&b, "opposite of --no-{s}\n", .{p});
            }
        }
    }
    util.bufByte(&b, '\n');
    if (!to_err and shell_eval) util.bufAppend(&b, "EOF\nexit 0\n");
    if (to_err) {
        util.ewrite(b.items);
    } else {
        util.out(b.items);
    }
}

fn pad(b: *util.Buf, pos: usize) void {
    if (pos < 26) {
        b.appendNTimes(gpa, ' ', 26 - pos) catch util.oom();
    } else {
        util.bufByte(b, '\n');
        b.appendNTimes(gpa, ' ', 26) catch util.oom();
    }
}

/// die with "options 'a' and 'b' cannot be used together"
pub fn dieExclusive(a: []const u8, b: []const u8) noreturn {
    util.die("options '{s}' and '{s}' cannot be used together", .{ a, b });
}
