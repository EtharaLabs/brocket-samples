//! git fetch (port of builtin/fetch.c, local transports only)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const tp = @import("../transport.zig");
const fetchpack = @import("../fetchpack.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const repo_mod = @import("../repo.zig");
const objects = @import("../objects.zig");
const commitreach = @import("../commitreach.zig");
const revparse = @import("../revparse.zig");
const column = @import("../column.zig");
const logtree = @import("../logtree.zig");
const branchcreate = @import("../branchcreate.zig");
const advice = @import("../advice.zig");
const proc = @import("../proc.zig");
const th = @import("../transport_helper.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Ref = tp.Ref;
const Refspec = tp.Refspec;
const RefList = std.ArrayList(*Ref);

const TAGS_UNSET: i32 = 0;
const TAGS_DEFAULT: i32 = 1;
const TAGS_SET: i32 = 2;
const TAG_REFSPEC = "refs/tags/*:refs/tags/*";

const DisplayFormat = enum { full, compact, porcelain };

const usage = [_][]const u8{
    "git fetch [<options>] [<repository> [<refspec>...]]",
    "git fetch [<options>] <group>",
    "git fetch --multiple [<options>] [(<repository>|<group>)...]",
    "git fetch --all [<options>]",
};

var family: i32 = 0;
var verbosity: i32 = 0;
var all: i32 = -1;
var set_upstream = false;
var append = false;
var atomic_fetch = false;
var upload_pack: ?[]const u8 = null;
var force = false;
var multiple = false;
var tags: i32 = TAGS_DEFAULT;
var max_jobs: i32 = -1;
var prefetch = false;
var prune: i32 = -1;
var prune_tags: i32 = -1;
const sf = @import("../submodule_fetch.zig");
var recurse_cli: sf.Recurse = .default;
/// resolved config.recurse_submodules (config, .gitmodules, command line)
var cfg_recurse: sf.Recurse = .default;
var submodule_fetch_jobs: i32 = -1;
var dry_run = false;
var porcelain = false;
var write_fetch_head = true;
var keep = false;
var update_head_ok = false;
var progress: i32 = -1;
var depth: ?[]const u8 = null;
var deepen_since: ?[]const u8 = null;
var deepen_not: std.ArrayList([]const u8) = .empty;
var deepen_relative: i32 = 0;
var unshallow: i32 = 0;
var refetch: i32 = 0;
var submodule_prefix: ?[]const u8 = null;
var recurse_default: sf.Recurse = .on_demand;

fn recurseCb(arg: ?[]const u8, unset: bool) void {
    recurse_cli = if (unset) .off else if (arg) |v| sf.parseFetchRecurseArg("recurse-submodules", v) else .on;
}

fn recurseDefaultCb(arg: ?[]const u8, unset: bool) void {
    recurse_default = if (unset) .off else if (arg) |v| sf.parseFetchRecurseArg("recurse-submodules-default", v) else .on;
}
var update_shallow = false;
var deepen = false;
var depth_num: i32 = 0;
var refmap: Refspec = .{ .fetch = true };
var server_options: std.ArrayList([]const u8) = .empty;
var negotiation_tips: std.ArrayList([]const u8) = .empty;
var negotiation_include: std.ArrayList([]const u8) = .empty;
var negotiate_only = false;
var filter: ?[]const u8 = null;
var no_filter = false;
var filter_expanded: ?[]const u8 = null;

fn cbFilter(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        filter = null;
        no_filter = true;
        return;
    }
    const a = arg orelse return;
    no_filter = false;
    if (filter) |old| {
        filter = if (util.startsWith(old, "combine:")) util.fmt("{s}+{s}", .{ old, a }) else util.fmt("combine:{s}+{s}", .{ old, a });
    } else filter = a;
}

/// fetch_one_setup_partial()
fn setupPartial(remote: *tp.Remote) void {
    const promisor = @import("../promisor.zig");
    if (filter) |f| {
        if (no_filter) return;
        filter_expanded = promisor.expandSpec(f);
        promisor.register(remote.name, filter_expanded.?);
        return;
    }
    if (no_filter or !promisor.hasRemote()) return;
    if (!promisor.isPromisorRemote(remote.name)) return;
    if (promisor.partialCloneFilter(remote.name)) |f| filter_expanded = promisor.expandSpec(f);
}
var auto_gc = true;
var show_forced_updates: i32 = -1;
var write_commit_graph: i32 = -1;
var stdin_refspecs = false;

var default_rla: util.Buf = .empty;

fn cbVerbose(_: ?[]const u8, unset: bool) void {
    if (unset) {
        verbosity = 0;
    } else if (verbosity >= 0) {
        verbosity += 1;
    } else verbosity = 1;
}

fn cbQuiet(_: ?[]const u8, unset: bool) void {
    if (unset) {
        verbosity = 0;
    } else if (verbosity <= 0) {
        verbosity -= 1;
    } else verbosity = -1;
}

fn cbRefmap(arg: ?[]const u8, _: bool) void {
    refmap.append(arg orelse "");
}

const options = [_]po.Opt{
    po.callbackNoArg('v', "verbose", cbVerbose, "be more verbose"),
    po.callbackNoArg('q', "quiet", cbQuiet, "be more quiet"),
    po.setInt(0, "all", &all, 1, "fetch from all remotes"),
    po.boolean(0, "set-upstream", &set_upstream, "set upstream for git pull/fetch"),
    po.boolean('a', "append", &append, "append to .git/FETCH_HEAD instead of overwriting"),
    po.boolean(0, "atomic", &atomic_fetch, "use atomic transaction to update references"),
    po.string(0, "upload-pack", &upload_pack, "path", "path to upload pack on remote end"),
    po.boolean('f', "force", &force, "force overwrite of local reference"),
    po.boolean('m', "multiple", &multiple, "fetch from multiple remotes"),
    po.setInt('t', "tags", &tags, TAGS_SET, "fetch all tags and associated objects"),
    .{ .short = 'n', .kind = .set_int, .i = &tags, .val = TAGS_UNSET, .help = "do not fetch all tags (--no-tags)" },
    po.integer('j', "jobs", &max_jobs, "n", "number of submodules fetched in parallel"),
    po.boolean(0, "prefetch", &prefetch, "modify the refspec to place all refs within refs/prefetch/"),
    po.setInt('p', "prune", &prune, 1, "prune remote-tracking branches no longer on remote"),
    po.setInt('P', "prune-tags", &prune_tags, 1, "prune local tags no longer on remote and clobber changed tags"),
    .{ .long = "recurse-submodules", .kind = .callback, .cb = recurseCb, .optarg = true, .argh = "on-demand", .help = "control recursive fetching of submodules" },
    po.boolean(0, "dry-run", &dry_run, "dry run"),
    po.boolean(0, "porcelain", &porcelain, "machine-readable output"),
    po.boolean(0, "write-fetch-head", &write_fetch_head, "write fetched references to the FETCH_HEAD file"),
    po.boolean('k', "keep", &keep, "keep downloaded pack"),
    po.boolean('u', "update-head-ok", &update_head_ok, "allow updating of HEAD ref"),
    po.setInt(0, "progress", &progress, 1, "force progress reporting"),
    po.string(0, "depth", &depth, "depth", "deepen history of shallow clone"),
    po.string(0, "shallow-since", &deepen_since, "time", "deepen history of shallow repository based on time"),
    po.list(0, "shallow-exclude", &deepen_not, "ref", "deepen history of shallow clone, excluding ref"),
    po.integer(0, "deepen", &deepen_relative, "n", "deepen history of shallow clone"),
    .{ .long = "unshallow", .kind = .set_int, .i = &unshallow, .val = 1, .noneg = true, .help = "convert to a complete repository" },
    .{ .long = "refetch", .kind = .set_int, .i = &refetch, .val = 1, .noneg = true, .help = "re-fetch without negotiating common commits" },
    .{ .long = "submodule-prefix", .kind = .string, .s = &submodule_prefix, .argh = "dir", .help = "prepend this to submodule path output", .hidden = true },
    .{ .long = "recurse-submodules-default", .kind = .callback, .cb = recurseDefaultCb, .argh = "on-demand", .help = "default for recursive fetching of submodules (lower priority than config files)", .hidden = true },
    po.boolean(0, "update-shallow", &update_shallow, "accept refs that update .git/shallow"),
    .{ .long = "refmap", .kind = .callback, .cb = cbRefmap, .argh = "refmap", .noneg = true, .help = "specify fetch refmap" },
    po.list('o', "server-option", &server_options, "server-specific", "option to transmit"),
    .{ .short = '4', .long = "ipv4", .kind = .set_int, .i = &family, .val = 4, .help = "use IPv4 addresses only", .noneg = true },
    .{ .short = '6', .long = "ipv6", .kind = .set_int, .i = &family, .val = 6, .help = "use IPv6 addresses only", .noneg = true },
    po.list(0, "negotiation-restrict", &negotiation_tips, "revision", "report that we have only objects reachable from this object"),
    .{ .long = "negotiation-tip", .kind = .list, .l = &negotiation_tips, .argh = "revision", .help = "alias of --negotiation-restrict", .from_alias = true },
    po.list(0, "negotiation-include", &negotiation_include, "revision", "ensure this ref is always sent as a negotiation have"),
    po.boolean(0, "negotiate-only", &negotiate_only, "do not fetch a packfile; instead, print ancestors of negotiation tips"),
    po.callback(0, "filter", cbFilter, "args", "object filtering"),
    po.boolean(0, "auto-maintenance", &auto_gc, "run 'maintenance --auto' after fetching"),
    po.boolean(0, "auto-gc", &auto_gc, "run 'maintenance --auto' after fetching"),
    po.setInt(0, "show-forced-updates", &show_forced_updates, 1, "check for forced-updates on all updated branches"),
    po.setInt(0, "write-commit-graph", &write_commit_graph, 1, "write the commit-graph after fetching"),
    po.boolean(0, "stdin", &stdin_refspecs, "accept refspecs from stdin"),
};

// ---------------- config ----------------

const FetchConfig = struct {
    display_format: DisplayFormat = .full,
    follow_remote_head: tp.FollowHead = .unconfigured,
    all: bool = false,
    prune: i32 = -1,
    prune_tags: i32 = -1,
    show_forced_updates: bool = true,
};

fn readConfig() FetchConfig {
    const cfg = &repo_mod.cfg;
    var fc = FetchConfig{};
    for (cfg.entries.items) |e| {
        if (util.eql(e.key, "submodule.recurse")) {
            cfg_recurse = if (@import("../config.zig").configBool(e.key, e.value)) .on else .off;
        } else if (util.eql(e.key, "submodule.fetchjobs")) {
            submodule_fetch_jobs = sf.parseFetchJobs(e.key, e.value);
        } else if (util.eql(e.key, "fetch.recursesubmodules")) {
            cfg_recurse = sf.parseFetchRecurseArg(e.key, e.value);
        }
    }
    if (cfg.getBool("fetch.all")) |b| fc.all = b;
    if (cfg.getBool("fetch.prune")) |b| fc.prune = @intFromBool(b);
    if (cfg.getBool("fetch.prunetags")) |b| fc.prune_tags = @intFromBool(b);
    if (cfg.getBool("fetch.showforcedupdates")) |b| fc.show_forced_updates = b;
    if (cfg.getEntry("fetch.output")) |e| {
        const v = e.value orelse util.die("missing value for '{s}'", .{"fetch.output"});
        if (std.ascii.eqlIgnoreCase(v, "full")) {
            fc.display_format = .full;
        } else if (std.ascii.eqlIgnoreCase(v, "compact")) {
            fc.display_format = .compact;
        } else util.die("invalid value for '{s}': '{s}'", .{ "fetch.output", v });
    }
    if (cfg.getEntry("fetch.followremotehead")) |e| {
        if (e.value) |v| {
            if (util.eql(v, "never")) {
                fc.follow_remote_head = .never;
            } else if (util.eql(v, "create")) {
                fc.follow_remote_head = .create;
            } else if (util.eql(v, "warn")) {
                fc.follow_remote_head = .warn;
            } else if (util.eql(v, "always")) {
                fc.follow_remote_head = .always;
            } else util.warn("unrecognized fetch.followRemoteHEAD value '{s}' ignored", .{v});
        } else util.err("missing value for '{s}'", .{"fetch.followRemoteHEAD"});
    }
    return fc;
}

// ---------------- display ----------------

const Display = struct {
    url: []const u8,
    url_len: usize,
    refcol_width: usize = 0,
    format: DisplayFormat,
    shown_url: bool = false,
};

const Info = struct {
    failed: bool = false,
    success_code: u8,
    fail_code: u8,
    summary: []const u8,
    success_detail: ?[]const u8,
    fail_detail: ?[]const u8,
    ref: []const u8,
    remote: []const u8,
    old_oid: Oid,
    new_oid: Oid,
};

var display_array: std.ArrayList(*Info) = .empty;

fn infoAppend(sc: u8, fc: u8, summary: []const u8, sd: ?[]const u8, fd: ?[]const u8, ref: []const u8, remote: []const u8, old: Oid, new: Oid) *Info {
    const i = gpa.create(Info) catch util.oom();
    i.* = .{
        .success_code = sc,
        .fail_code = fc,
        .summary = util.dupe(summary),
        .success_detail = sd,
        .fail_detail = fd,
        .ref = util.dupe(ref),
        .remote = util.dupe(remote),
        .old_oid = old,
        .new_oid = new,
    };
    display_array.append(gpa, i) catch util.oom();
    return i;
}

fn refcolWidth(ref_map: []const *Ref, compact: bool) usize {
    var width: usize = 10;
    var max: i64 = column.termColumns();
    if (compact) max = @divTrunc(max * 2, 3);
    for (ref_map) |r| {
        const peer = r.peer_ref orelse continue;
        if (util.eql(r.name, "HEAD")) continue;
        if (verbosity <= 0 and hash.eql(peer.old_oid, r.old_oid)) continue;
        const rlen = std.unicode.utf8CountCodepoints(logtree.prettifyRefname(r.name)) catch logtree.prettifyRefname(r.name).len;
        var llen: usize = 0;
        if (!compact) llen = std.unicode.utf8CountCodepoints(logtree.prettifyRefname(peer.name)) catch logtree.prettifyRefname(peer.name).len;
        const len: i64 = @intCast(21 + rlen + 4 + llen);
        if (len >= max) continue;
        if (width < rlen) width = rlen;
    }
    return width;
}

fn displayInit(ref_map: []const *Ref, raw_url: []const u8, format: DisplayFormat) Display {
    const url = tp.anonymizeUrl(raw_url);
    var d = Display{ .url = url, .url_len = url.len, .format = format };
    var i: isize = @as(isize, @intCast(url.len)) - 1;
    while (i >= 0 and url[@intCast(i)] == '/') i -= 1;
    d.url_len = @intCast(i + 1);
    if (4 < i and std.mem.eql(u8, url[@intCast(i - 3)..@intCast(i + 1)], ".git")) d.url_len = @intCast(i - 3);
    if (verbosity < 0) return d;
    switch (format) {
        .full, .compact => d.refcol_width = refcolWidth(ref_map, format == .compact),
        .porcelain => {},
    }
    return d;
}

fn pad(b: *util.Buf, s: []const u8, width: usize) void {
    util.bufAppend(b, s);
    var n = std.unicode.utf8CountCodepoints(s) catch s.len;
    while (n < width) : (n += 1) util.bufByte(b, ' ');
}

fn printRemoteToLocal(d: *Display, b: *util.Buf, remote: []const u8, local: []const u8) void {
    pad(b, remote, d.refcol_width);
    util.bufAppend(b, " -> ");
    util.bufAppend(b, local);
}

fn findAndReplace(haystack: []const u8, needle: []const u8, placeholder: []const u8) ?[]const u8 {
    var p: ?usize = null;
    if (util.endsWith(haystack, needle)) {
        p = haystack.len - needle.len;
    } else p = std.mem.indexOf(u8, haystack, needle);
    const pos = p orelse return null;
    if (pos > 0 and haystack[pos - 1] != '/') return null;
    const plen = haystack.len - pos;
    if (plen > needle.len and haystack[pos + needle.len] != '/') return null;
    return util.concat(&.{ haystack[0..pos], placeholder, haystack[pos + needle.len ..] });
}

fn printCompact(d: *Display, b: *util.Buf, remote: []const u8, local: []const u8) void {
    if (util.eql(remote, local)) {
        pad(b, remote, d.refcol_width);
        util.bufAppend(b, " -> *");
        return;
    }
    var r = remote;
    var l = local;
    if (findAndReplace(r, local, "*")) |nr| {
        r = nr;
    } else if (findAndReplace(l, remote, "*")) |nl| l = nl;
    printRemoteToLocal(d, b, r, l);
}

fn displayRefUpdate(d: *Display, code: u8, summary: []const u8, err_: ?[]const u8, remote0: []const u8, local0: []const u8, old: Oid, new: Oid, summary_width: usize) void {
    if (verbosity < 0) return;
    var b: util.Buf = .empty;
    switch (d.format) {
        .full, .compact => {
            if (!d.shown_url) {
                util.bufPrint(&b, "From {s}\n", .{d.url[0..d.url_len]});
                d.shown_url = true;
            }
            const remote = logtree.prettifyRefname(remote0);
            const local = logtree.prettifyRefname(local0);
            util.bufPrint(&b, " {c} ", .{code});
            pad(&b, summary, summary_width);
            util.bufByte(&b, ' ');
            if (d.format != .compact) {
                printRemoteToLocal(d, &b, remote, local);
            } else printCompact(d, &b, remote, local);
            if (err_) |e| util.bufPrint(&b, "  ({s})", .{e});
            util.bufByte(&b, '\n');
            util.ewrite(b.items);
        },
        .porcelain => {
            util.bufPrint(&b, "{c} {s} {s} {s}\n", .{ code, hash.hex(old), hash.hex(new), local0 });
            util.out(b.items);
        },
    }
}

fn infoDisplay(i: *Info, d: *Display, summary_width: usize) void {
    displayRefUpdate(d, if (i.failed) i.fail_code else i.success_code, i.summary, if (i.failed) i.fail_detail else i.success_detail, i.remote, i.ref, i.old_oid, i.new_oid, summary_width);
}

fn summaryWidth(list: []const *Ref) usize {
    var maxw: usize = 0;
    var any = false;
    for (list) |r| {
        const a = revparse.abbrev(r.old_oid, 0).len;
        const b = revparse.abbrev(r.new_oid, 0).len;
        maxw = @max(maxw, @max(a, b));
        any = true;
    }
    if (!any) maxw = 7;
    return 2 * maxw + 3;
}

// ---------------- ref map ----------------

fn odbHas(oid: Oid) bool {
    return repo_mod.repo().odb().has(oid);
}

/// Approximation of check_connected(): every commit reachable from the
/// fetched tips (stopping at local ref tips and shallow boundaries) must exist.
fn historyComplete(ref_map: []const *Ref) bool {
    var tips: hash.OidSet = .empty;
    for (refs.iterate("", .{ .check_objects = false })) |lr| tips.put(gpa, lr.oid, {}) catch util.oom();
    var seen: hash.OidSet = .empty;
    var stack: std.ArrayList(Oid) = .empty;
    for (ref_map) |r| {
        const c_oid = objects.peelTo(r.old_oid, .commit) orelse continue;
        stack.append(gpa, c_oid) catch util.oom();
    }
    while (stack.pop()) |o| {
        if (seen.contains(o) or tips.contains(o)) continue;
        seen.put(gpa, o, {}) catch util.oom();
        const cm = objects.readCommit(o) orelse return false;
        for (cm.parents) |p| stack.append(gpa, p) catch util.oom();
    }
    return true;
}

fn isCommitish(oid: Oid) bool {
    if (!odbHas(oid)) return false;
    return objects.peelTo(oid, .commit) != null;
}

fn existingRefs() std.StringHashMap(Oid) {
    var m = std.StringHashMap(Oid).init(gpa);
    for (refs.iterate("", .{ .check_objects = false })) |r| m.put(r.name, r.oid) catch util.oom();
    return m;
}

fn findNonLocalTags(remote_refs: []const *Ref, tx: ?*refs.Transaction, head: []const *Ref, out: *RefList) void {
    var existing = existingRefs();
    if (tx) |t| {
        for (t.updates.items) |u| {
            if (util.startsWith(u.refname, "refs/tags/") and u.flags & refs.F_HAVE_NEW != 0)
                existing.put(u.refname, u.new_oid) catch util.oom();
        }
    }
    var fetch_oids: hash.OidSet = .empty;
    for (head) |r| fetch_oids.put(gpa, r.old_oid, {}) catch util.oom();

    const Item = struct { oid: Oid, ignore: bool = false };
    var remote_map = std.StringHashMap(*Item).init(gpa);
    var names: std.ArrayList([]const u8) = .empty;
    var item: ?*Item = null;
    for (remote_refs) |r| {
        if (!util.startsWith(r.name, "refs/tags/")) continue;
        if (util.endsWith(r.name, "^{}")) {
            if (item) |it| {
                if (!odbHas(r.old_oid) and !fetch_oids.contains(r.old_oid) and
                    !odbHas(it.oid) and !fetch_oids.contains(it.oid)) it.ignore = true;
            }
            item = null;
            continue;
        }
        if (item) |it| {
            if (!odbHas(it.oid) and !fetch_oids.contains(it.oid)) it.ignore = true;
        }
        item = null;
        if (remote_map.contains(r.name) or existing.contains(r.name)) continue;
        const ni = gpa.create(Item) catch util.oom();
        ni.* = .{ .oid = r.old_oid };
        remote_map.put(r.name, ni) catch util.oom();
        names.append(gpa, r.name) catch util.oom();
        item = ni;
    }
    if (item) |it| {
        if (!odbHas(it.oid) and !fetch_oids.contains(it.oid)) it.ignore = true;
    }
    util.sortStrings(names.items);
    for (names.items) |n| {
        const it = remote_map.get(n).?;
        if (it.ignore) continue;
        const rm = tp.allocRef(n);
        rm.peer_ref = tp.allocRef(n);
        rm.old_oid = it.oid;
        out.append(gpa, rm) catch util.oom();
    }
}

fn filterPrefetchRefspec(rs: *Refspec) void {
    if (!prefetch) return;
    var i: usize = 0;
    while (i < rs.items.items.len) {
        var it = &rs.items.items[i];
        if (it.negative) {
            i += 1;
            continue;
        }
        if (it.dst == null or (it.src != null and util.startsWith(it.src.?, "refs/tags/"))) {
            _ = rs.items.orderedRemove(i);
            continue;
        }
        const old = it.dst.?;
        const sub = util.skipPrefix(old, "refs/") orelse old;
        it.dst = util.concat(&.{ "refs/prefetch/", sub });
        it.force = true;
        i += 1;
    }
}

fn handleDuplicate(r1: *Ref, r2: *Ref) void {
    if (util.eql(r1.name, r2.name)) return;
    const ig1 = r1.fetch_head_status == .ignore;
    const ig2 = r2.fetch_head_status == .ignore;
    if (!ig1 and !ig2) {
        util.die("Cannot fetch both {s} and {s} to {s}", .{ r1.name, r2.name, r2.peer_ref.?.name });
    } else if (!ig1 and ig2) {
        util.warn("{s} usually tracks {s}, not {s}", .{ r2.peer_ref.?.name, r2.name, r1.name });
    } else if (ig1 and ig2) {
        util.die("{s} tracks both {s} and {s}", .{ r2.peer_ref.?.name, r1.name, r2.name });
    } else util.die("BUG: Internal error", .{});
}

fn removeDuplicates(list: []const *Ref) []*Ref {
    var out: RefList = .empty;
    var seen = std.StringHashMap(*Ref).init(gpa);
    for (list) |r| {
        if (r.peer_ref) |p| {
            if (seen.get(p.name)) |prev| {
                handleDuplicate(prev, r);
                continue;
            }
            seen.put(p.name, r) catch util.oom();
        }
        out.append(gpa, r) catch util.oom();
    }
    return out.items;
}

fn getRefMap(remote: *tp.Remote, remote_refs: []const *Ref, rs: *Refspec, tags_mode: i32, autotags: *bool) []*Ref {
    var ref_map: RefList = .empty;
    var orefs: RefList = .empty;
    filterPrefetchRefspec(rs);
    filterPrefetchRefspec(&remote.fetch);

    if (rs.items.items.len > 0) {
        for (rs.items.items) |it| {
            tp.getFetchMap(remote_refs, it, &ref_map, false);
            if (it.dst != null and it.dst.?.len > 0) autotags.* = true;
        }
        for (ref_map.items) |rm| rm.fetch_head_status = .merge;
        const fetch_refspec = if (refmap.items.items.len > 0) &refmap else &remote.fetch;
        for (fetch_refspec.items.items) |it| tp.getFetchMap(ref_map.items, it, &orefs, true);
    } else if (refmap.items.items.len > 0) {
        util.die("--refmap option is only meaningful with command-line refspec(s)", .{});
    } else {
        const branch = tp.branchGet(null);
        const has_merge = branch != null and branch.?.merge.items.len > 0;
        const merge_here = has_merge and branch.?.remote_name != null and util.eql(branch.?.remote_name.?, remote.name);
        if (remote.fetch.items.items.len > 0 or merge_here) {
            for (remote.fetch.items.items, 0..) |it, i| {
                tp.getFetchMap(remote_refs, it, &ref_map, false);
                if (it.dst != null and it.dst.?.len > 0) autotags.* = true;
                if (i == 0 and !has_merge and ref_map.items.len > 0 and !remote.fetch.items.items[0].pattern)
                    ref_map.items[0].fetch_head_status = .merge;
            }
            if (merge_here) {
                const b = branch.?;
                for (b.merge.items, 0..) |m, i| {
                    var found = false;
                    for (ref_map.items) |rm| {
                        if (tp.branchMergeMatches(b, i, rm.name)) {
                            rm.fetch_head_status = .merge;
                            found = true;
                            break;
                        }
                    }
                    if (found) continue;
                    const old_len = ref_map.items.len;
                    tp.getFetchMap(remote_refs, .{ .src = m }, &ref_map, true);
                    for (ref_map.items[old_len..]) |rm| rm.fetch_head_status = .merge;
                }
            }
        } else if (!prefetch) {
            const h = tp.findRefByNameAbbrev(remote_refs, "HEAD") orelse util.die("couldn't find remote ref HEAD", .{});
            const c = tp.copyRef(h);
            c.fetch_head_status = .merge;
            ref_map.append(gpa, c) catch util.oom();
        }
    }

    if (tags_mode == TAGS_SET) {
        const tag_spec = tp.parseRefspec(TAG_REFSPEC, false).?;
        tp.getFetchMap(remote_refs, tag_spec, &ref_map, false);
    } else if (tags_mode == TAGS_DEFAULT and autotags.*) {
        findNonLocalTags(remote_refs, null, ref_map.items, &ref_map);
    }

    for (orefs.items) |rm| {
        rm.fetch_head_status = .ignore;
        ref_map.append(gpa, rm) catch util.oom();
    }

    // negative refspecs
    const neg = if (rs.items.items.len > 0) rs else &remote.fetch;
    var filtered: RefList = .empty;
    for (ref_map.items) |rm| {
        if (neg.matchesNegative(rm.name)) continue;
        filtered.append(gpa, rm) catch util.oom();
    }
    const result = removeDuplicates(filtered.items);

    var existing: ?std.StringHashMap(Oid) = null;
    for (result) |rm| {
        const p = rm.peer_ref orelse continue;
        if (existing == null) existing = existingRefs();
        if (existing.?.get(p.name)) |o| p.old_oid = o;
    }
    return result;
}

// ---------------- ref updates ----------------

fn sUpdateRef(action: []const u8, ref: *Ref, tx: *refs.Transaction, check_old: bool) bool {
    if (dry_run) return false;
    const rla = os.getenv("GIT_REFLOG_ACTION") orelse default_rla.items;
    const msg = util.fmt("{s}: {s}", .{ rla, action });
    const e = tx.update(ref.name, ref.new_oid, if (check_old) ref.old_oid else null, null, null, 0, msg);
    if (e != .ok) {
        util.err("{s}", .{tx.errMsg()});
        return true;
    }
    return false;
}

fn quickref(a: Oid, b: Oid, sep: []const u8) []const u8 {
    return util.concat(&.{ revparse.abbrev(a, 0), sep, revparse.abbrev(b, 0) });
}

fn updateLocalRef(ref: *Ref, tx: *refs.Transaction, remote_ref: *const Ref, fc: *const FetchConfig) bool {
    if (!odbHas(ref.new_oid)) util.die("object {s} not found", .{hash.hex(ref.new_oid)});
    if (hash.eql(ref.old_oid, ref.new_oid)) {
        if (verbosity > 0)
            _ = infoAppend('=', '=', "[up to date]", null, null, ref.name, remote_ref.name, ref.old_oid, ref.new_oid);
        return false;
    }
    if (!update_head_ok and !hash.isZero(ref.old_oid) and branchcreate.branchCheckedOut(ref.name) != null) {
        const i = infoAppend('!', '!', "[rejected]", null, "can't fetch into checked-out branch", ref.name, remote_ref.name, ref.old_oid, ref.new_oid);
        i.failed = true;
        return true;
    }
    if (!hash.isZero(ref.old_oid) and util.startsWith(ref.name, "refs/tags/")) {
        if (force or ref.force) {
            const r = sUpdateRef("updating tag", ref, tx, false);
            const i = infoAppend('t', '!', "[tag update]", null, "unable to update local ref", ref.name, remote_ref.name, ref.old_oid, ref.new_oid);
            if (r) i.failed = true;
            return r;
        }
        const i = infoAppend('!', '!', "[rejected]", null, "would clobber existing tag", ref.name, remote_ref.name, ref.old_oid, ref.new_oid);
        i.failed = true;
        return true;
    }
    const current = if (hash.isZero(ref.old_oid)) null else objects.peelTo(ref.old_oid, .commit);
    const updated = objects.peelTo(ref.new_oid, .commit);
    if (current == null or updated == null) {
        var msg: []const u8 = undefined;
        var what: []const u8 = undefined;
        if (util.startsWith(remote_ref.name, "refs/tags/")) {
            msg = "storing tag";
            what = "[new tag]";
        } else if (util.startsWith(remote_ref.name, "refs/heads/")) {
            msg = "storing head";
            what = "[new branch]";
        } else {
            msg = "storing ref";
            what = "[new ref]";
        }
        const r = sUpdateRef(msg, ref, tx, false);
        const i = infoAppend('*', '!', what, null, "unable to update local ref", ref.name, remote_ref.name, ref.old_oid, ref.new_oid);
        if (r) i.failed = true;
        return r;
    }
    const fast_forward = if (fc.show_forced_updates) commitreach.refNewer(updated.?, current.?) else true;
    if (fast_forward) {
        const q = quickref(current.?, ref.new_oid, "..");
        const r = sUpdateRef("fast-forward", ref, tx, true);
        const i = infoAppend(' ', '!', q, null, "unable to update local ref", ref.name, remote_ref.name, ref.old_oid, ref.new_oid);
        if (r) i.failed = true;
        return r;
    } else if (force or ref.force) {
        const q = quickref(current.?, ref.new_oid, "...");
        const r = sUpdateRef("forced-update", ref, tx, true);
        const i = infoAppend('+', '!', q, "forced update", "unable to update local ref", ref.name, remote_ref.name, ref.old_oid, ref.new_oid);
        if (r) i.failed = true;
        return r;
    }
    const i = infoAppend('!', '!', "[rejected]", null, "non-fast-forward", ref.name, remote_ref.name, ref.old_oid, ref.new_oid);
    i.failed = true;
    return true;
}

const FetchHead = struct {
    open: bool = false,
    path: []const u8 = "",
    buf: util.Buf = .empty,

    fn add(self: *FetchHead, oid: Oid, status: @TypeOf(@as(Ref, undefined).fetch_head_status), note: []const u8, url: []const u8) void {
        if (!self.open) return;
        const marker: []const u8 = switch (status) {
            .not_for_merge => "not-for-merge",
            .merge => "",
            .ignore => return,
        };
        util.bufPrint(&self.buf, "{s}\t{s}\t{s}", .{ hash.hex(oid), marker, note });
        for (url) |ch| {
            if (ch == '\n') util.bufAppend(&self.buf, "\\n") else util.bufByte(&self.buf, ch);
        }
        util.bufByte(&self.buf, '\n');
        if (!atomic_fetch) self.flush();
    }

    fn flush(self: *FetchHead) void {
        if (self.buf.items.len == 0) return;
        os.appendFile(self.path, self.buf.items) catch {};
        self.buf.clearRetainingCapacity();
    }

    fn commit(self: *FetchHead) void {
        if (!self.open or !atomic_fetch) return;
        self.flush();
    }
};

fn storeUpdatedRefs(d: *Display, tx: *refs.Transaction, ref_map: []const *Ref, fh: *FetchHead, fc: *const FetchConfig) bool {
    var rc = false;
    const statuses = [_]@TypeOf(@as(Ref, undefined).fetch_head_status){ .merge, .not_for_merge, .ignore };
    for (statuses) |want| {
        for (ref_map) |rm| {
            if (rm.status == .reject_shallow) {
                if (want == .merge) util.warn("rejected {s} because shallow roots are not allowed to be updated", .{if (rm.peer_ref) |p| p.name else rm.name});
                continue;
            }
            if (fh.open) {
                if (!isCommitish(rm.old_oid)) rm.fetch_head_status = .not_for_merge;
            }
            if (rm.fetch_head_status != want) continue;
            var ref: ?*Ref = null;
            if (rm.peer_ref) |p| {
                const r = tp.allocRef(p.name);
                r.old_oid = p.old_oid;
                r.new_oid = rm.old_oid;
                r.force = p.force;
                ref = r;
            }
            if (cfg_recurse != .off and (ref == null or !std.mem.eql(u8, &ref.?.old_oid, &ref.?.new_oid)))
                sf.checkForNewSubmoduleCommits(rm.old_oid);
            var kind: []const u8 = "";
            var what: []const u8 = "";
            if (util.eql(rm.name, "HEAD")) {} else if (util.skipPrefix(rm.name, "refs/heads/")) |w| {
                kind = "branch";
                what = w;
            } else if (util.skipPrefix(rm.name, "refs/tags/")) |w| {
                kind = "tag";
                what = w;
            } else if (util.skipPrefix(rm.name, "refs/remotes/")) |w| {
                kind = "remote-tracking branch";
                what = w;
            } else what = rm.name;
            var note: util.Buf = .empty;
            if (what.len > 0) {
                if (kind.len > 0) util.bufPrint(&note, "{s} ", .{kind});
                util.bufPrint(&note, "'{s}' of ", .{what});
            }
            fh.add(rm.old_oid, rm.fetch_head_status, note.items, d.url[0..d.url_len]);
            if (ref) |r| {
                if (updateLocalRef(r, tx, rm, fc)) rc = true;
            } else if (write_fetch_head or dry_run) {
                _ = infoAppend('*', '*', if (kind.len > 0) kind else "branch", null, null, "FETCH_HEAD", rm.name, rm.new_oid, rm.old_oid);
            }
        }
    }
    if (advice.enabled("fetchShowForcedUpdates") and !fc.show_forced_updates) {
        util.warn("fetch normally indicates which branches had a forced update,\n" ++
            "but that check has been disabled; to re-enable, use '--show-forced-updates'\n" ++
            "flag or run 'git config fetch.showForcedUpdates true'", .{});
    }
    return rc;
}

fn transportFetchRefs(t: *tp.Transport, ref_map: []const *Ref, follow_tags: bool) void {
    var heads: RefList = .empty;
    for (ref_map) |rm| {
        if (rm.peer_ref) |p| {
            if (!hash.isZero(rm.old_oid) and hash.eql(p.old_oid, rm.old_oid)) continue;
        }
        heads.append(gpa, rm) catch util.oom();
    }
    const list: []const *Ref = if (heads.items.len == 0) ref_map else heads.items;
    fetchpack.fetchPack(t, list, .{
        .quiet = t.quiet,
        .no_progress = !t.progress,
        .include_tag = follow_tags,
        .keep_pack = t.keep,
        .filter = filter_expanded,
        .from_promisor = filter_expanded != null,
    });
}

fn fetchAndConsumeRefs(d: *Display, t: *tp.Transport, tx: *refs.Transaction, ref_map: []const *Ref, fh: *FetchHead, fc: *const FetchConfig, follow_tags: bool) bool {
    var need = refetch != 0 or deepen;
    for (ref_map) |r| {
        if (!odbHas(r.old_oid)) need = true;
    }
    if (!need and !historyComplete(ref_map)) need = true;
    const t2 = @import("../trace2.zig");
    if (need) {
        t2.regionEnter("fetch", "fetch_refs", true);
        transportFetchRefs(t, ref_map, follow_tags);
        t2.regionLeave("fetch", "fetch_refs", true);
        if (t.fetch_failed) return true;
    }
    t2.regionEnter("fetch", "consume_refs", true);
    const ok = storeUpdatedRefs(d, tx, ref_map, fh, fc);
    t2.regionLeave("fetch", "consume_refs", true);
    return ok;
}

fn warnDanglingSymrefsStderr(indent: []const u8, dry: bool, deleted: []const []const u8) void {
    for (refs.iterate("", .{ .include_broken = true, .check_objects = false })) |lr| {
        if (lr.flags & refs.REF_ISSYMREF == 0) continue;
        const target = refs.readSymbolic(lr.name) orelse continue;
        var hit = false;
        for (deleted) |dn| {
            if (util.eql(dn, target)) hit = true;
        }
        if (!hit) continue;
        if (dry) {
            util.ewrite(util.fmt("{s}{s} will become dangling after {s} is deleted\n", .{ indent, lr.name, target }));
        } else util.ewrite(util.fmt("{s}{s} has become dangling after {s} was deleted\n", .{ indent, lr.name, target }));
    }
}

fn pruneRefs(d: *Display, rs: *const Refspec, tx: ?*refs.Transaction, ref_map: []const *Ref) bool {
    var result = false;
    const stale = tp.getStaleHeads(rs, ref_map);
    var names: std.ArrayList([]const u8) = .empty;
    for (stale) |r| names.append(gpa, r.name) catch util.oom();
    if (!dry_run) {
        if (tx) |t| {
            for (stale) |r| {
                if (t.delete(r.name, null, null, 0, "fetch: prune") != .ok) return true;
            }
        } else {
            result = !refs.deleteRefs(names.items, 0, "fetch: prune");
        }
    }
    if (verbosity >= 0) {
        const sw = summaryWidth(stale);
        for (stale) |r| displayRefUpdate(d, '-', "[deleted]", null, "(none)", r.name, r.new_oid, r.old_oid, sw);
        util.sortStrings(names.items);
        warnDanglingSymrefsStderr("   ", dry_run, names.items);
    }
    return result;
}

fn checkNotCurrentBranch(ref_map: []const *Ref) void {
    for (ref_map) |rm| {
        const p = rm.peer_ref orelse continue;
        if (!util.startsWith(p.name, "refs/heads/")) continue;
        if (branchcreate.branchCheckedOut(p.name)) |path|
            util.die("refusing to fetch into branch '{s}' checked out at '{s}'", .{ p.name, path });
    }
}

fn truncateFetchHead() bool {
    const path = repo_mod.repo().gitPath("FETCH_HEAD");
    os.writeFile(path, "", 0o666) catch {
        util.err("cannot open '{s}': {s}", .{ path, os.lastErr() });
        return false;
    };
    return true;
}

fn setHeadAdvice(remote: []const u8, head_name: []const u8) void {
    advice.adviseIfEnabled("fetchRemoteHEADWarn", util.fmt(
        "Run 'git remote set-head {s} {s}' to follow the change, or modify\n" ++
            "either of the 'remote.{s}.followRemoteHEAD' or 'fetch.followRemoteHEAD'\n" ++
            "configuration variables to handle the situation differently.\n\n" ++
            "Using this specific setting\n\n" ++
            "    git config set remote.{s}.followRemoteHEAD warn-if-not-{s}\n\n" ++
            "will suppress the warning until the remote changes HEAD to something else.",
        .{ remote, head_name, remote, remote, head_name },
    ));
}

fn warnSetHead(remote: []const u8, head_name: []const u8, prev: []const u8, was_detached: bool) void {
    const pfx = util.fmt("refs/remotes/{s}/", .{remote});
    const prev_head = util.skipPrefix(prev, pfx);
    if (prev_head != null and !util.eql(prev_head.?, head_name)) {
        util.outf("'HEAD' at '{s}' is '{s}', but we have '{s}' locally.\n", .{ remote, head_name, prev_head.? });
        setHeadAdvice(remote, head_name);
    } else if (was_detached and prev.len > 0) {
        util.outf("'HEAD' at '{s}' is '{s}', but we have a detached HEAD pointing to '{s}' locally.\n", .{ remote, head_name, prev });
        setHeadAdvice(remote, head_name);
    }
}

fn setHead(remote_refs: []const *Ref, remote: *tp.Remote, follow: tp.FollowHead) void {
    var fetch_map: RefList = .empty;
    tp.getFetchMap(remote_refs, .{ .pattern = true, .src = "refs/heads/*", .dst = "refs/heads/*" }, &fetch_map, false);
    const matches = tp.guessRemoteHead(tp.findRefByName(remote_refs, "HEAD"), fetch_map.items, true);
    if (matches.len != 1) return;
    const head_name = util.skipPrefix(matches[0].name, "refs/heads/") orelse matches[0].name;
    const baremirror = repo_mod.repo().bare and remote.mirror;
    const create_only = if (follow == .always) false else !baremirror;
    var b_head: []const u8 = undefined;
    var b_remote_head: []const u8 = undefined;
    if (baremirror) {
        b_head = "HEAD";
        b_remote_head = util.fmt("refs/heads/{s}", .{head_name});
    } else {
        b_head = util.fmt("refs/remotes/{s}/HEAD", .{remote.name});
        b_remote_head = util.fmt("refs/remotes/{s}/{s}", .{ remote.name, head_name });
    }
    if (!baremirror and !refs.exists(b_remote_head)) return;
    var prev: []const u8 = "";
    var was_detached = false;
    var exists = false;
    switch (refs.readRawFull(b_head)) {
        .symref => |s| {
            prev = s;
            exists = true;
        },
        .oid => |o| {
            prev = util.dupe(&hash.hex(o));
            was_detached = true;
            exists = true;
        },
        else => {},
    }
    if (!(create_only and exists)) {
        refs.writeSymref(b_head, b_remote_head, "fetch") catch {
            util.err("{s}", .{refs.last_error});
            return;
        };
    }
    if (verbosity >= 0 and follow == .warn and (remote.no_warn_branch == null or !util.eql(remote.no_warn_branch.?, head_name)))
        warnSetHead(remote.name, head_name, prev, was_detached);
}

fn commitRefTransaction(tx: *refs.Transaction, is_atomic: bool, remote_name: []const u8, rejected: *std.StringHashMap(void), errbuf: *util.Buf) u8 {
    const e = tx.commit();
    if (e != .ok) {
        util.bufAppend(errbuf, tx.errMsg());
        return 1;
    }
    var retcode: u8 = 0;
    if (!is_atomic) {
        var conflict_shown = false;
        for (tx.rejected()) |u| {
            if (u.rejection == .name_conflict and !conflict_shown) {
                util.err("some local refs could not be updated; try running\n 'git remote prune {s}' to remove any old, conflicting branches", .{remote_name});
                conflict_shown = true;
            } else if (u.rejection_details.len > 0) {
                util.err("{s}", .{u.rejection_details});
            } else {
                util.err("fetching ref {s} failed: {s}", .{ u.refname, u.rejection.msg() });
            }
            rejected.put(u.refname, {}) catch util.oom();
            retcode = 1;
        }
    }
    return retcode;
}

fn doFetch(t: *tp.Transport, rs: *Refspec, fc: *const FetchConfig) u8 {
    const remote = t.remote;
    var autotags = remote.fetch_tags == 1;
    var retcode: u8 = 0;
    var do_set_head = false;
    var summary_width: usize = 0;
    var errbuf: util.Buf = .empty;
    var rejected = std.StringHashMap(void).init(gpa);
    var fh = FetchHead{};
    var tx: ?*refs.Transaction = null;
    var ref_map: []*Ref = &.{};
    var remote_refs: []*Ref = &.{};
    var display = Display{ .url = "", .url_len = 0, .format = fc.display_format };

    if (tags == TAGS_DEFAULT) {
        if (remote.fetch_tags == 2) tags = TAGS_SET;
        if (remote.fetch_tags == -1) tags = TAGS_UNSET;
    }

    main: {
        if (!append and write_fetch_head) {
            if (!truncateFetchHead()) {
                retcode = 1;
                break :main;
            }
        }
        const follow: tp.FollowHead = if (remote.follow_remote_head != .unconfigured)
            remote.follow_remote_head
        else if (fc.follow_remote_head != .unconfigured)
            fc.follow_remote_head
        else
            .create;

        var prefixes: std.ArrayList([]const u8) = .empty;
        if (rs.items.items.len > 0) {
            rs.refPrefixes(&prefixes);
        } else {
            const branch = tp.branchGet(null);
            if (remote.fetch.items.items.len > 0) {
                remote.fetch.refPrefixes(&prefixes);
                if (follow != .never) do_set_head = true;
            }
            if (branch) |b| {
                if (b.merge.items.len > 0 and b.remote_name != null and util.eql(b.remote_name.?, remote.name)) {
                    for (b.merge.items) |m| prefixes.append(gpa, m) catch util.oom();
                }
            }
            if (prefixes.items.len == 0) prefixes.append(gpa, "HEAD") catch util.oom();
        }
        if (tags == TAGS_SET or tags == TAGS_DEFAULT) prefixes.append(gpa, "refs/tags/") catch util.oom();
        if (do_set_head) prefixes.append(gpa, "HEAD") catch util.oom();
        if (prefixes.items.len > 0) {
            @import("../trace2.zig").regionEnter("fetch", "remote_refs", true);
            remote_refs = tp.getRemoteRefs(t, prefixes.items);
            @import("../trace2.zig").regionLeave("fetch", "remote_refs", true);
        }

        ref_map = getRefMap(remote, remote_refs, rs, tags, &autotags);
        if (!update_head_ok) checkNotCurrentBranch(ref_map);

        if (write_fetch_head) {
            fh.open = true;
            fh.path = repo_mod.repo().gitPath("FETCH_HEAD");
        }
        display = displayInit(ref_map, t.url, fc.display_format);

        if (atomic_fetch) tx = refs.Transaction.init();

        const follow_tags = tags == TAGS_DEFAULT and autotags;
        if (follow_tags) th.transportSetOption(t, "followtags", "1");
        if (prune != 0) {
            const prs: *const Refspec = if (rs.items.items.len > 0) rs else &remote.fetch;
            if (pruneRefs(&display, prs, tx, ref_map)) retcode = 1;
        }
        if (tx == null) {
            tx = refs.Transaction.init();
            tx.?.allow_failures = true;
        }
        if (fetchAndConsumeRefs(&display, t, tx.?, ref_map, &fh, fc, follow_tags)) {
            retcode = 1;
            break :main;
        }
        if (tags == TAGS_DEFAULT and autotags) {
            var tags_map: RefList = .empty;
            findNonLocalTags(remote_refs, tx, &.{}, &tags_map);
            if (tags_map.items.len > 0) {
                t.depth = 0;
                th.transportSetOption(t, "followtags", null);
                th.transportSetOption(t, "depth", "0");
                th.transportSetOption(t, "deepen-relative", null);
                t.deepen_relative = false;
                t.deepen_since = null;
                t.deepen_not = &.{};
                if (fetchAndConsumeRefs(&display, t, tx.?, tags_map.items, &fh, fc, false)) retcode = 1;
            }
        }
        if (retcode != 0) break :main;

        if (verbosity >= 0) summary_width = summaryWidth(ref_map);

        retcode = commitRefTransaction(tx.?, atomic_fetch, remote.name, &rejected, &errbuf);
        tx = null;
        if (retcode != 0 and atomic_fetch) break :main;

        fh.commit();

        if (set_upstream) upstream: {
            const branch = tp.branchGet("HEAD");
            var source_ref: ?*Ref = null;
            for (ref_map) |rm| {
                if (rm.peer_ref == null) {
                    if (source_ref != null) {
                        util.warn("multiple branches detected, incompatible with --set-upstream", .{});
                        break :main;
                    }
                    source_ref = rm;
                }
            }
            const src = source_ref orelse {
                util.warn("no source branch found;\nyou need to specify exactly one branch with the --set-upstream option", .{});
                break :upstream;
            };
            const b = branch orelse {
                const short = util.skipPrefix(src.name, "refs/heads/") orelse src.name;
                util.warn("could not set upstream of HEAD to '{s}' from '{s}' when it does not point to any branch.", .{ short, remote.name });
                break :main;
            };
            if (util.eql(src.name, "HEAD") or util.startsWith(src.name, "refs/heads/")) {
                _ = branchcreate.installBranchConfig(false, b.name, remote.name, src.name);
            } else if (util.startsWith(src.name, "refs/remotes/")) {
                util.warn("not setting upstream for a remote remote-tracking branch", .{});
            } else if (util.startsWith(src.name, "refs/tags/")) {
                util.warn("not setting upstream for a remote tag", .{});
            } else util.warn("unknown branch type", .{});
        }
        if (do_set_head) setHead(remote_refs, remote, follow);
    }

    // cleanup
    if (retcode != 0 and !atomic_fetch) {
        if (tx) |x| {
            _ = commitRefTransaction(x, false, remote.name, &rejected, &errbuf);
            tx = null;
        }
    }
    for (display_array.items) |i| {
        if (!i.failed and rejected.contains(i.ref)) i.failed = true;
        infoDisplay(i, &display, summary_width);
    }
    display_array.clearRetainingCapacity();
    if (retcode != 0) {
        if (errbuf.items.len > 0) {
            util.err("{s}", .{errbuf.items});
            errbuf.clearRetainingCapacity();
        }
        if (tx) |x| x.abort();
    }
    return retcode;
}

// ---------------- fetch_one / multiple ----------------

fn hasGlobSpecials(s: []const u8) bool {
    return std.mem.indexOfAny(u8, s, "*?[\\") != null;
}

/// add_negotiation_tips()
fn addNegotiationTips(input: []const []const u8, argname: []const u8) []const Oid {
    var oids: std.ArrayList(Oid) = .empty;
    const odb = repo_mod.repo().odb();
    for (input) |s| {
        if (!hasGlobSpecials(s)) {
            // ignore missing reference; fail on missing object
            const oid = revparse.getOid(s) orelse continue;
            if (!odb.has(oid)) util.die("the object {s} does not exist", .{s});
            oids.append(gpa, oid) catch util.oom();
            continue;
        }
        const pat = if (util.startsWith(s, "refs/")) s else util.concat(&.{ "refs/", s });
        const old_nr = oids.items.len;
        for (refs.iterate("", .{ .check_objects = false })) |r| {
            if (!@import("../wildmatch.zig").match(pat, r.name, 0)) continue;
            oids.append(gpa, r.oid) catch util.oom();
        }
        if (old_nr == oids.items.len) util.warn("ignoring {s}={s} because it does not match any refs", .{ argname, s });
    }
    return oids.items;
}

/// negotiation part of prepare_transport()
fn addAllNegotiationTips(t: *tp.Transport, remote: *tp.Remote) void {
    const smart = !t.is_bundle;
    if (negotiation_tips.items.len > 0) {
        if (smart) {
            t.negotiation_restrict = addNegotiationTips(negotiation_tips.items, "--negotiation-restrict");
        } else util.warn("ignoring {s} because the protocol does not support it", .{"--negotiation-restrict"});
    } else if (remote.negotiation_restrict.items.len > 0) {
        for (remote.negotiation_restrict.items) |s| negotiation_tips.append(gpa, s) catch util.oom();
        if (smart) {
            t.negotiation_restrict = addNegotiationTips(negotiation_tips.items, "--negotiation-restrict");
        } else util.warn("ignoring remote.{s}.negotiationRestrict because the protocol does not support it", .{remote.name});
    }
    if (negotiation_include.items.len > 0) {
        if (smart) {
            t.negotiation_include = addNegotiationTips(negotiation_include.items, "--negotiation-include");
        } else util.warn("ignoring {s} because the protocol does not support it", .{"--negotiation-include"});
    } else if (remote.negotiation_include.items.len > 0) {
        if (smart) {
            t.negotiation_include = addNegotiationTips(remote.negotiation_include.items, "--negotiation-include");
        } else util.warn("ignoring remote.{s}.negotiationInclude because the protocol does not support it", .{remote.name});
    }
}

/// prepare_transport()
fn prepareTransport(remote: *tp.Remote) *tp.Transport {
    const t = tp.transportGet(remote, null);
    t.verbose = if (verbosity <= 1) verbosity else 1;
    t.quiet = verbosity < 0;
    t.progress = if (progress >= 0) progress != 0 else (verbosity >= 0 and os.isatty(2));
    if (upload_pack) |u| t.uploadpack = u;
    t.family = @intCast(family);
    if (keep) t.keep = true;
    t.depth = depth_num;
    if (deepen) t.deepen_since = deepen_since;
    if (deepen) t.deepen_not = deepen_not.items;
    t.deepen_relative = deepen_relative > 0;
    t.update_shallow = update_shallow;
    t.refetch = refetch != 0;
    if (t.helper != null) {
        if (upload_pack) |u| th.transportSetOption(t, "uploadpack", u);
        if (keep) th.transportSetOption(t, "keep", "yes");
        if (depth_num > 0) th.transportSetOption(t, "depth", depth orelse util.fmt("{d}", .{depth_num}));
        if (deepen and deepen_since != null) th.transportSetOption(t, "deepen-since", deepen_since.?);
        if (deepen and deepen_not.items.len > 0) th.transportSetOptionList(t, "deepen-not", deepen_not.items);
        if (deepen_relative > 0) th.transportSetOption(t, "deepen-relative", "yes");
        if (update_shallow) th.transportSetOption(t, "update-shallow", "yes");
        if (refetch != 0) th.transportSetOption(t, "refetch", "yes");
        if (filter_expanded) |fs| {
            th.transportSetOption(t, "filter", fs);
            th.transportSetOption(t, "from-promisor", "1");
        }
    }
    addAllNegotiationTips(t, remote);
    return t;
}

fn fetchOne(remote_opt: ?*tp.Remote, argv: []const []const u8, prune_tags_ok: bool, fc: *const FetchConfig) u8 {
    const remote = remote_opt orelse util.die("no remote repository specified; please specify either a URL or a\nremote name from which new revisions should be fetched", .{});
    const remote_via_config = tp.remoteIsConfigured(remote, false);
    if (remote.urls.items.len == 0) util.die("no path specified; see 'git help pull' for valid url syntax", .{});
    const t = prepareTransport(remote);

    if (prune < 0) {
        if (remote.prune) |p| {
            prune = @intFromBool(p);
        } else if (fc.prune >= 0) {
            prune = fc.prune;
        } else prune = 0;
    }
    if (prune_tags < 0) {
        if (remote.prune_tags) |p| {
            prune_tags = @intFromBool(p);
        } else if (fc.prune_tags >= 0) {
            prune_tags = fc.prune_tags;
        } else prune_tags = 0;
    }
    const maybe_prune_tags = prune_tags_ok and prune_tags != 0;
    if (maybe_prune_tags and remote_via_config) remote.fetch.append(TAG_REFSPEC);
    var rs = Refspec{ .fetch = true };
    if (maybe_prune_tags and (argv.len > 0 or !remote_via_config)) rs.append(TAG_REFSPEC);
    var i: usize = 0;
    while (i < argv.len) : (i += 1) {
        if (util.eql(argv[i], "tag")) {
            i += 1;
            if (i >= argv.len) util.die("you need to specify a tag name", .{});
            rs.append(util.fmt("refs/tags/{s}:refs/tags/{s}", .{ argv[i], argv[i] }));
        } else rs.append(argv[i]);
    }
    if (stdin_refspecs) {
        const data = os.readAllFd(0) catch util.die("could not read from stdin", .{});
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line| {
            if (line.len == 0 and it.peek() == null) break;
            rs.append(line);
        }
    }
    if (server_options.items.len > 0) t.server_options = server_options.items;
    proc.ignoreSigpipe();
    const code = doFetch(t, &rs, fc);
    _ = tp.disconnect(t);
    return code;
}

pub fn addRemoteOrGroup(name: []const u8, list: *std.ArrayList([]const u8)) bool {
    const prev = list.items.len;
    for (repo_mod.cfg.getAll(util.concat(&.{ "remotes.", name }))) |v| {
        var it = std.mem.tokenizeAny(u8, v, " \t\n");
        while (it.next()) |w| list.append(gpa, w) catch util.oom();
    }
    if (list.items.len == prev) {
        const r = tp.remoteGet(name) orelse return false;
        if (!tp.remoteIsConfigured(r, false)) return false;
        list.append(gpa, r.name) catch util.oom();
    }
    return true;
}

fn addOptionsToArgv(argv: *std.ArrayList([]const u8), fc: *const FetchConfig) void {
    const a = struct {
        fn push(l: *std.ArrayList([]const u8), s: []const u8) void {
            l.append(gpa, s) catch util.oom();
        }
    }.push;
    if (dry_run) a(argv, "--dry-run");
    if (prune != -1) a(argv, if (prune != 0) "--prune" else "--no-prune");
    if (prune_tags != -1) a(argv, if (prune_tags != 0) "--prune-tags" else "--no-prune-tags");
    if (update_head_ok) a(argv, "--update-head-ok");
    if (force) a(argv, "--force");
    if (keep) a(argv, "--keep");
    switch (cfg_recurse) {
        .on => a(argv, "--recurse-submodules"),
        .off => a(argv, "--no-recurse-submodules"),
        .on_demand => a(argv, "--recurse-submodules=on-demand"),
        else => {},
    }
    if (tags == TAGS_SET) {
        a(argv, "--tags");
    } else if (tags == TAGS_UNSET) a(argv, "--no-tags");
    if (verbosity >= 2) a(argv, "-v");
    if (verbosity >= 1) {
        a(argv, "-v");
    } else if (verbosity < 0) a(argv, "-q");
    if (family == 4) {
        a(argv, "--ipv4");
    } else if (family == 6) a(argv, "--ipv6");
    if (!write_fetch_head) a(argv, "--no-write-fetch-head");
    if (fc.display_format == .porcelain) a(argv, "--porcelain");
}

fn fetchMultiple(list: []const []const u8, fc: *const FetchConfig) u8 {
    if (!append and write_fetch_head) {
        if (!truncateFetchHead()) return 1;
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ "-c", "fetch.bundleURI=", "fetch", "--append", "--no-auto-gc", "--no-write-commit-graph" }) catch util.oom();
    for (server_options.items) |o| argv.append(gpa, util.fmt("--server-option={s}", .{o})) catch util.oom();
    addOptionsToArgv(&argv, fc);
    var result: u8 = 0;
    for (list) |name| {
        var args: std.ArrayList([]const u8) = .empty;
        args.appendSlice(gpa, argv.items) catch util.oom();
        args.append(gpa, name) catch util.oom();
        if (verbosity >= 0 and fc.display_format != .porcelain) util.outf("Fetching {s}\n", .{name});
        const ch = proc.spawnGit(args.items, .{});
        if (proc.wait(ch.pid) != 0) {
            util.err("could not fetch {s}", .{name});
            result = 1;
        }
    }
    return result;
}

pub fn cmdFetch(args: []const []const u8) u8 {
    // fetch never lazily fetches the objects it is about to download
    @import("../promisor.zig").fetch_if_missing = false;
    @import("../pktline.zig").traceIdentity("fetch");
    util.bufAppend(&default_rla, "fetch");
    for (args[1..]) |a| util.bufPrint(&default_rla, " {s}", .{tp.anonymizeUrl(a)});

    var fc = readConfig();
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (show_forced_updates >= 0) fc.show_forced_updates = show_forced_updates != 0;

    if (recurse_cli != .default) cfg_recurse = recurse_cli;
    if (negotiate_only) {
        if (recurse_cli != .off and recurse_cli != .default)
            util.die("options '{s}' and '{s}' cannot be used together", .{ "--negotiate-only", "--recurse-submodules" });
        cfg_recurse = .off;
    }
    if (cfg_recurse != .off) sf.fetchConfigFromGitmodules(if (submodule_fetch_jobs == -1) &submodule_fetch_jobs else null, if (cfg_recurse == .default) &cfg_recurse else null);
    if (porcelain) {
        if (recurse_cli != .off and recurse_cli != .default)
            util.die("options '{s}' and '{s}' cannot be used together", .{ "--porcelain", "--recurse-submodules" });
        fc.display_format = .porcelain;
    }
    if (porcelain) cfg_recurse = .off;
    if (deepen_relative != 0) {
        if (deepen_relative < 0) util.die("negative depth in --deepen is not supported", .{});
        if (depth != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--deepen", "--depth" });
    }
    if (unshallow != 0) {
        if (depth != null) util.die("options '{s}' and '{s}' cannot be used together", .{ "--depth", "--unshallow" });
        if (!os.exists(repo_mod.repo().gitPath("shallow")))
            util.die("--unshallow on a complete repository does not make sense", .{});
    }
    if (depth) |dv| {
        const n = std.fmt.parseInt(i64, dv, 10) catch 0;
        if (n < 1) util.die("depth {s} is not a positive number", .{dv});
        depth_num = @intCast(@min(n, 0x7fffffff));
    }
    if (deepen_relative > 0) depth_num = deepen_relative;
    if (unshallow != 0) depth_num = 0x7fffffff;
    if (depth_num > 0 or deepen_since != null or deepen_not.items.len > 0) deepen = true;
    if (dry_run) write_fetch_head = false;

    if (repo_mod.cfg.get("fetch.bundleuri")) |bu_uri| {
        if (@import("../bundle_uri.zig").fetchBundleUri(bu_uri, null) != 0)
            util.warn("failed to fetch bundles from '{s}'", .{bu_uri});
    }

    if (all < 0) all =if (rest.len == 0) @intFromBool(fc.all) else 0;

    var list: std.ArrayList([]const u8) = .empty;
    var remote: ?*tp.Remote = null;
    var prune_tags_ok = true;
    var argv = rest;
    if (all != 0) {
        if (rest.len == 1) util.die("fetch --all does not take a repository argument", .{});
        if (rest.len > 1) util.die("fetch --all does not make sense with refspecs", .{});
        for (tp.allRemotes()) |r| {
            if (!r.skip_default_update) list.append(gpa, r.name) catch util.oom();
        }
        if (list.items.len == 1) remote = tp.remoteGet(list.items[0]);
    } else if (rest.len == 0) {
        remote = tp.remoteGet(null);
    } else if (multiple) {
        for (rest) |a| {
            if (!addRemoteOrGroup(a, &list)) util.die("no such remote or remote group: {s}", .{a});
        }
    } else {
        _ = addRemoteOrGroup(rest[0], &list);
        if (list.items.len > 1) {
            if (rest.len > 1) util.die("fetching a group and specifying refspecs does not make sense", .{});
        } else {
            remote = tp.remoteGet(rest[0]);
            prune_tags_ok = rest.len == 1;
            argv = rest[1..];
        }
    }
    // remove adjacent duplicates
    var dedup: std.ArrayList([]const u8) = .empty;
    for (list.items) |n| {
        if (dedup.items.len > 0 and util.eql(dedup.items[dedup.items.len - 1], n)) continue;
        dedup.append(gpa, n) catch util.oom();
    }

    var result: u8 = 0;
    if (negotiate_only) {
        @import("../trace2.zig").regionEnter("fetch", "negotiate-only", true);
        if (remote == null) util.die("must supply remote when using --negotiate-only", .{});
        deepen = true;
        const gt = prepareTransport(remote.?);
        if (gt.is_bundle) {
            util.warn("protocol does not support --negotiate-only, exiting", .{});
            @import("../trace2.zig").regionLeave("fetch", "negotiate-only", true);
            return 1;
        }
        if (gt.negotiation_restrict == null) util.die("{s} needs one or more {s}", .{ "--negotiate-only", "--negotiation-restrict=*" });
        if (server_options.items.len > 0) gt.server_options = server_options.items;
        var acked: std.ArrayList(Oid) = .empty;
        const rc = fetchpack.negotiateOnly(gt, &acked);
        for (acked.items) |a| util.outf("{s}\n", .{hash.hex(a)});
        @import("../trace2.zig").regionLeave("fetch", "negotiate-only", true);
        _ = tp.disconnect(gt);
        return if (rc < 0) 255 else 0;
    } else if (remote != null) {
        setupPartial(remote.?);
        @import("../trace2.zig").regionEnter("fetch", "fetch-one", true);
        result = fetchOne(remote, argv, prune_tags_ok, &fc);
        @import("../trace2.zig").regionLeave("fetch", "fetch-one", true);
    } else {
        if (filter != null) util.die("--filter can only be used with the remote configured in extensions.partialclone", .{});
        if (atomic_fetch) util.die("--atomic can only be used when fetching from one remote", .{});
        if (stdin_refspecs) util.die("--stdin can only be used when fetching from one remote", .{});
        @import("../trace2.zig").regionEnter("fetch", "fetch-multiple", true);
        result = fetchMultiple(dedup.items, &fc);
        @import("../trace2.zig").regionLeave("fetch", "fetch-multiple", true);
    }
    if (result == 0 and remote != null and cfg_recurse != .off) {
        var sopts: std.ArrayList([]const u8) = .empty;
        addOptionsToArgv(&sopts, &fc);
        @import("../trace2.zig").regionEnter("fetch", "recurse-submodule", true);
        result = sf.fetchSubmodules(sopts.items, submodule_prefix orelse "", cfg_recurse, recurse_default, verbosity < 0);
        @import("../trace2.zig").regionLeave("fetch", "recurse-submodule", true);
    }
    afterFetch();
    return result;
}

/// git_config_push_parameter(): export `key=value` to child git processes.
fn pushConfigParameter(key: []const u8, value: []const u8) void {
    var b: util.Buf = .empty;
    if (os.getenv("GIT_CONFIG_PARAMETERS")) |old| {
        if (old.len > 0) {
            b.appendSlice(gpa, old) catch util.oom();
            b.append(gpa, ' ') catch util.oom();
        }
    }
    util.sqQuote(&b, key);
    b.append(gpa, '=') catch util.oom();
    util.sqQuote(&b, value);
    os.setEnv("GIT_CONFIG_PARAMETERS", b.items);
}

/// Tail of cmd_fetch(): write the commit-graph and run auto-maintenance.
fn afterFetch() void {
    const t2 = @import("../trace2.zig");
    const cfg = &repo_mod.cfg;
    if (write_commit_graph > 0 or (write_commit_graph < 0 and (cfg.getBool("fetch.writecommitgraph") orelse false))) {
        const cg = @import("../commitgraph.zig");
        t2.regionEnter("fetch", "write-commit-graph", true);
        const dirs = repo_mod.repo().odb().allDirs();
        _ = cg.writeReachable(dirs[0], .{ .split = true, .progress = progress != 0 });
        t2.regionLeave("fetch", "write-commit-graph", true);
    }
    if (auto_gc) {
        if (refetch != 0) {
            if ((cfg.getInt("gc.autopacklimit") orelse -1) != 0) pushConfigParameter("gc.autoPackLimit", "1");
            if ((cfg.getInt("maintenance.incremental-repack.auto") orelse -1) != 0)
                pushConfigParameter("maintenance.incremental-repack.auto", "-1");
        }
        _ = @import("maintenance.zig").runAutoMaintenance(verbosity < 0);
    }
}
