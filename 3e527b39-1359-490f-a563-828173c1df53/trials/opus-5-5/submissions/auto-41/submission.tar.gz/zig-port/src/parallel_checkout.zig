//! Port of parallel-checkout.c and builtin/checkout--worker.c.
//!
//! Regular files that need no external smudge filter are queued by
//! entry.checkoutEntry() while parallel checkout is accepting entries, and
//! written by run(), either sequentially or by `git checkout--worker`
//! processes talking pkt-lines whose payloads have the same layout as
//! C's struct pc_item_fixed_portion / struct pc_item_result.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const index_mod = @import("index.zig");
const convert = @import("convert.zig");
const entry = @import("entry.zig");
const pkt = @import("pktline.zig");
const proc = @import("proc.zig");
const po = @import("parseopt.zig");
const trace2 = @import("trace2.zig");
const gpa = util.gpa;

const Entry = index_mod.Entry;

extern "c" fn signal(sig: c_int, handler: usize) usize;

fn bug(comptime f: []const u8, args: anytype) noreturn {
    util.flushStdout();
    util.eprint("BUG: parallel-checkout.c: " ++ f ++ "\n", args);
    std.c.abort();
}

pub const Status = enum { uninitialized, accepting_entries, running };

pub const ItemStatus = enum(c_int) { pending = 0, written = 1, collided = 2, failed = 3 };

pub const Item = struct {
    ce: *Entry,
    ca: convert.ConvAttrs,
    /// position in items[] of the main process
    id: usize,
    checkout_counter: ?*usize,
    status: ItemStatus = .pending,
    st: os.Stat = std.mem.zeroes(os.Stat),
};

/// struct pc_item_fixed_portion (x86-64 layout, struct object_id included).
const FixedPortion = extern struct {
    id: usize,
    oid_hash: [32]u8,
    oid_algo: c_int,
    ce_mode: c_uint,
    crlf_action: c_int,
    ident: c_int,
    working_tree_encoding_len: usize,
    name_len: usize,
};

/// struct pc_item_result; `st` is omitted unless status == written.
const ItemResult = extern struct {
    id: usize,
    status: c_int,
    st: os.Stat,
};
const RESULT_BASE_SIZE = @offsetOf(ItemResult, "st");

const LARGE_PACKET_DATA_MAX = 65520 - 4;

var status: Status = .uninitialized;
var items: std.ArrayList(Item) = .empty;
var pc_progress: ?*@import("progress.zig").Progress = null;
var pc_progress_cnt: ?*u64 = null;

/// Progress meter for the next run() (run_parallel_checkout's progress args).
pub fn setProgress(p: ?*@import("progress.zig").Progress, cnt: *u64) void {
    pc_progress = p;
    pc_progress_cnt = cnt;
}

fn advanceProgressMeter() void {
    if (pc_progress) |p| {
        pc_progress_cnt.?.* += 1;
        p.update(pc_progress_cnt.?.*);
    }
}

pub fn parallelCheckoutStatus() Status {
    return status;
}

const DEFAULT_THRESHOLD_FOR_PARALLELISM: i32 = 100;
const DEFAULT_NUM_WORKERS: i32 = 1;

fn onlineCpus() i32 {
    const n = std.Thread.getCpuCount() catch 1;
    return @intCast(@max(n, 1));
}

/// get_parallel_checkout_configs()
pub fn getConfigs() struct { workers: i32, threshold: i32 } {
    if (os.getenv("GIT_TEST_CHECKOUT_WORKERS")) |env| {
        if (env.len > 0) {
            var n = std.fmt.parseInt(i32, env, 10) catch
                util.die("invalid value for '{s}': '{s}'", .{ "GIT_TEST_CHECKOUT_WORKERS", env });
            if (n < 1) n = onlineCpus();
            return .{ .workers = n, .threshold = 0 };
        }
    }
    const cfg = &@import("repo.zig").cfg;
    var workers: i32 = DEFAULT_NUM_WORKERS;
    if (cfg.getInt("checkout.workers")) |v| {
        workers = std.math.cast(i32, v) orelse util.die("bad numeric config value '{d}' for 'checkout.workers': out of range", .{v});
        if (workers < 1) workers = onlineCpus();
    }
    var threshold: i32 = DEFAULT_THRESHOLD_FOR_PARALLELISM;
    if (cfg.getInt("checkout.thresholdForParallelism")) |v| {
        threshold = std.math.cast(i32, v) orelse util.die("bad numeric config value '{d}' for 'checkout.thresholdForParallelism': out of range", .{v});
    }
    return .{ .workers = workers, .threshold = threshold };
}

/// init_parallel_checkout()
pub fn init() void {
    if (status != .uninitialized) bug("parallel checkout already initialized", .{});
    status = .accepting_entries;
}

fn finish() void {
    if (status == .uninitialized) bug("cannot finish parallel checkout: not initialized yet", .{});
    items = .empty;
    status = .uninitialized;
}

fn isEligible(ce: *const Entry, ca: *const convert.ConvAttrs) bool {
    if (ce.mode & os.S_IFMT != os.S_IFREG) return false;
    const packed_size = @sizeOf(FixedPortion) + ce.path.len +
        (if (ca.working_tree_encoding) |e| e.len else 0);
    if (packed_size > LARGE_PACKET_DATA_MAX) return false;
    // classify_conv_attrs(): smudge filters and long-running process
    // filters are not allowed; everything else is in-core or streamable.
    if (ca.drv) |d| {
        if (d.process != null or d.smudge != null) return false;
    }
    return true;
}

/// Should entry.checkoutEntry() compute conversion attributes and try to
/// enqueue? (cheap check so the sequential path costs nothing)
pub fn accepting() bool {
    return status == .accepting_entries;
}

/// enqueue_checkout(): true if the entry was queued.
pub fn enqueue(ce: *Entry, ca: *const convert.ConvAttrs, checkout_counter: ?*usize) bool {
    if (status != .accepting_entries or !isEligible(ce, ca)) return false;
    items.append(gpa, .{ .ce = ce, .ca = ca.*, .id = items.items.len, .checkout_counter = checkout_counter }) catch util.oom();
    return true;
}

pub fn queueSize() usize {
    return items.items.len;
}

/// update_ce_after_write()
fn updateCeAfterWrite(state: *entry.State, ce: *Entry, st: os.Stat) void {
    if (state.refresh_cache) {
        ce.fillStat(st);
        if (st.isReg()) ce.uptodate = true;
        if (state.istate) |ix| ix.changed = true;
    }
}

/// handle_results(): true on errors.
fn handleResults(state: *entry.State) bool {
    var ret = false;
    var have_pending = false;
    for (items.items) |*it| {
        if (it.status == .written) updateCeAfterWrite(state, it.ce, it.st);
    }
    for (items.items) |*it| {
        switch (it.status) {
            .written => {
                if (it.checkout_counter) |n| n.* += 1;
            },
            .collided => {
                // status is .running, so this will not enqueue again
                if (entry.checkoutEntry(it.ce, state, it.checkout_counter)) ret = true;
                advanceProgressMeter();
            },
            .pending => {
                have_pending = true;
                ret = true;
            },
            .failed => ret = true,
        }
    }
    if (have_pending) util.err("parallel checkout finished with pending entries", .{});
    return ret;
}

/// write_pc_item_to_fd(): true on error (already reported).
fn writeItemToFd(it: *Item, fd: c_int, path: []const u8) bool {
    const blob = entry.readBlob(it.ce.oid) orelse {
        util.err("cannot read object {s} '{s}'", .{ &hash.hex(it.ce.oid), it.ce.path });
        return true;
    };
    const data = convert.toWorktreeCa(&it.ca, it.ce.path, blob);
    os.writeAll(fd, data) catch {
        util.err("unable to write file '{s}'", .{path});
        return true;
    };
    return false;
}

/// write_pc_item()
pub fn writeItem(it: *Item, state: *const entry.State) void {
    const mode: c_uint = if (it.ce.mode & 0o100 != 0) 0o777 else 0o666;
    const path = util.concat(&.{ state.base_dir, it.ce.path });

    // The leading dirs were created when the entry was enqueued, but a path
    // collision could have replaced one of them by now.
    if (std.mem.lastIndexOfScalar(u8, path, '/')) |sep| {
        if (!entry.hasDirsOnlyPath(path[0..sep], state.base_dir.len)) {
            it.status = .collided;
            trace2.dataString("pcheckout", false, "collision/dirname", path);
            return;
        }
    }

    const fd = os.openFile(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode);
    if (fd < 0) {
        const e = os.errno();
        if (e == os.EEXIST or e == os.EISDIR) {
            it.status = .collided;
            trace2.dataString("pcheckout", false, "collision/basename", path);
        } else {
            util.err("failed to open file '{s}': {s}", .{ path, os.strErr(e) });
            it.status = .failed;
        }
        return;
    }

    if (writeItemToFd(it, fd, path)) {
        it.status = .failed;
        os.close(fd);
        _ = os.unlink(path);
        return;
    }

    // fstat_checkout_output()
    var fstat_done = false;
    if (state.refresh_cache and state.base_dir.len == 0) {
        if (os.fstatFd(fd)) |s| {
            it.st = s;
            fstat_done = true;
        }
    }
    os.close(fd);

    if (state.refresh_cache and !fstat_done) {
        if (os.lstatPath(path)) |s| {
            it.st = s;
        } else {
            util.err("unable to stat just-written file '{s}': {s}", .{ path, os.lastErr() });
            it.status = .failed;
            return;
        }
    }
    it.status = .written;
}

fn sendOneItem(b: *util.Buf, it: *const Item) void {
    const wte = it.ca.working_tree_encoding orelse "";
    var fp = std.mem.zeroes(FixedPortion);
    fp.id = it.id;
    @memcpy(fp.oid_hash[0..it.ce.oid.len], &it.ce.oid);
    fp.oid_algo = 1;
    fp.ce_mode = it.ce.mode;
    fp.crlf_action = @intCast(@intFromEnum(it.ca.crlf_action));
    fp.ident = @intFromBool(it.ca.ident);
    fp.working_tree_encoding_len = wte.len;
    fp.name_len = it.ce.path.len;
    var data: util.Buf = .empty;
    util.bufAppend(&data, std.mem.asBytes(&fp));
    util.bufAppend(&data, wte);
    util.bufAppend(&data, it.ce.path);
    pkt.bufWrite(b, data.items);
}

fn sendBatch(fd: c_int, start: usize, nr: usize) void {
    var b: util.Buf = .empty;
    for (items.items[start .. start + nr]) |*it| sendOneItem(&b, it);
    util.bufAppend(&b, "0000");
    const old = signal(13, 1); // sigchain_push(SIGPIPE, SIG_IGN)
    os.writeAll(fd, b.items) catch {};
    _ = signal(13, old);
}

const Worker = struct {
    child: proc.Child,
    next_item_to_complete: usize = 0,
    nr_items_to_complete: usize = 0,
};

fn setupWorkers(state: *const entry.State, num_workers: usize) []Worker {
    const workers = gpa.alloc(Worker, num_workers) catch util.oom();
    for (workers) |*w| {
        var args: std.ArrayList([]const u8) = .empty;
        args.append(gpa, "checkout--worker") catch util.oom();
        if (state.base_dir.len > 0) args.append(gpa, util.concat(&.{ "--prefix=", state.base_dir })) catch util.oom();
        w.* = .{ .child = proc.spawnGit(args.items, .{ .pipe_in = true, .pipe_out = true }) };
    }
    const n = items.items.len;
    const base_batch_size = n / num_workers;
    const with_extra = n % num_workers;
    var begin: usize = 0;
    for (workers, 0..) |*w, i| {
        var batch = base_batch_size;
        if (i < with_extra) batch += 1;
        sendBatch(w.child.in, begin, batch);
        w.next_item_to_complete = begin;
        w.nr_items_to_complete = batch;
        begin += batch;
    }
    return workers;
}

fn finishWorkers(workers: []Worker) void {
    for (workers) |*w| {
        proc.closeFd(&w.child.in);
        proc.closeFd(&w.child.out);
    }
    for (workers, 0..) |*w, i| {
        const rc = proc.wait(w.child.pid);
        if (rc > 128) util.err("checkout worker {d} died of signal {d}", .{ i, rc - 128 });
    }
}

fn parseAndSaveResult(buf: []const u8, w: *Worker) void {
    if (buf.len < RESULT_BASE_SIZE)
        bug("too short result from checkout worker (got {d}B, exp >={d}B)", .{ buf.len, RESULT_BASE_SIZE });
    var res = std.mem.zeroes(ItemResult);
    const rb = std.mem.asBytes(&res);
    const st_ok = std.mem.readInt(c_int, buf[@offsetOf(ItemResult, "status")..][0..4], .little) == @intFromEnum(ItemStatus.written);
    const exp: usize = if (st_ok) @sizeOf(ItemResult) else RESULT_BASE_SIZE;
    if (buf.len != exp) bug("wrong result size from checkout worker (got {d}B, exp {d}B)", .{ buf.len, exp });
    @memcpy(rb[0..buf.len], buf);
    if (w.nr_items_to_complete == 0) bug("received result from supposedly finished checkout worker", .{});
    if (res.id != w.next_item_to_complete)
        bug("unexpected item id from checkout worker (got {d}, exp {d})", .{ res.id, w.next_item_to_complete });
    w.next_item_to_complete += 1;
    w.nr_items_to_complete -= 1;
    const it = &items.items[res.id];
    it.status = if (res.status >= 0 and res.status <= 3) @as(ItemStatus, @enumFromInt(res.status)) else .failed;
    if (st_ok) it.st = res.st;
    if (it.status != .collided) advanceProgressMeter();
}

/// gather_results_from_workers(). Workers only start writing results after
/// reading their whole batch, so draining them one after another cannot
/// deadlock; a worker blocked on a full pipe waits for its turn.
fn gatherResults(workers: []Worker) void {
    for (workers) |*w| {
        const r = gpa.create(pkt.Reader) catch util.oom();
        r.* = pkt.Reader.init(w.child.out);
        r.chomp = false;
        r.gentle_eof = true;
        r.die_on_err_packet = false;
        while (true) {
            switch (r.read()) {
                .normal => parseAndSaveResult(r.line, w),
                else => break,
            }
        }
    }
}

fn writeItemsSequentially(state: *const entry.State) void {
    for (items.items) |*it| {
        writeItem(it, state);
        if (it.status != .collided) advanceProgressMeter();
    }
}

/// run_parallel_checkout(): true on errors.
pub fn run(state: *entry.State, num_workers0: i32, threshold: i32) bool {
    if (status != .accepting_entries) bug("cannot run parallel checkout: uninitialized or already running", .{});
    status = .running;
    var num_workers: usize = @intCast(@max(num_workers0, 0));
    if (items.items.len < num_workers) num_workers = items.items.len;
    if (num_workers <= 1 or items.items.len < @as(usize, @intCast(@max(threshold, 0)))) {
        writeItemsSequentially(state);
    } else {
        const workers = setupWorkers(state, num_workers);
        gatherResults(workers);
        finishWorkers(workers);
    }
    const ret = handleResults(state);
    finish();
    pc_progress = null;
    pc_progress_cnt = null;
    return ret;
}

// ---------------------------------------------------------------------------
// git checkout--worker

const worker_usage = [_][]const u8{"git checkout--worker [<options>]"};

fn packetToItem(buf: []const u8) Item {
    if (buf.len < @sizeOf(FixedPortion))
        bug("checkout worker received too short item (got {d}B, exp {d}B)", .{ buf.len, @sizeOf(FixedPortion) });
    var fp: FixedPortion = undefined;
    @memcpy(std.mem.asBytes(&fp), buf[0..@sizeOf(FixedPortion)]);
    if (buf.len - @sizeOf(FixedPortion) != fp.name_len + fp.working_tree_encoding_len)
        bug("checkout worker received corrupted item", .{});
    var variant = buf[@sizeOf(FixedPortion)..];
    var ca = convert.ConvAttrs{};
    if (fp.working_tree_encoding_len > 0) {
        ca.working_tree_encoding = util.dupe(variant[0..fp.working_tree_encoding_len]);
        variant = variant[fp.working_tree_encoding_len..];
    }
    ca.crlf_action = if (fp.crlf_action >= 0 and fp.crlf_action <= 7) @as(convert.CrlfAction, @enumFromInt(fp.crlf_action)) else .binary;
    ca.ident = fp.ident != 0;
    const ce = gpa.create(Entry) catch util.oom();
    ce.* = .{ .path = util.dupe(variant[0..fp.name_len]), .mode = fp.ce_mode };
    @memcpy(&ce.oid, fp.oid_hash[0..ce.oid.len]);
    return .{ .ce = ce, .ca = ca, .id = fp.id, .checkout_counter = null };
}

fn reportResult(b: *util.Buf, it: *const Item) void {
    var res = std.mem.zeroes(ItemResult);
    res.id = it.id;
    res.status = @intFromEnum(it.status);
    var size: usize = RESULT_BASE_SIZE;
    if (it.status == .written) {
        res.st = it.st;
        size = @sizeOf(ItemResult);
    }
    pkt.bufWrite(b, std.mem.asBytes(&res)[0..size]);
}

fn workerLoop(state: *const entry.State) void {
    var queue: std.ArrayList(Item) = .empty;
    const r = gpa.create(pkt.Reader) catch util.oom();
    r.* = pkt.Reader.init(0);
    r.chomp = false;
    r.die_on_err_packet = false;
    while (true) {
        switch (r.read()) {
            .normal => queue.append(gpa, packetToItem(r.line)) catch util.oom(),
            .flush => break,
            else => bug("packet_read() returned negative value", .{}),
        }
    }
    var out: util.Buf = .empty;
    for (queue.items) |*it| {
        writeItem(it, state);
        reportResult(&out, it);
        if (out.items.len >= 32768) {
            os.writeAll(1, out.items) catch util.die("unable to write to checkout parent: {s}", .{os.lastErr()});
            out.clearRetainingCapacity();
        }
    }
    util.bufAppend(&out, "0000");
    os.writeAll(1, out.items) catch util.die("unable to write to checkout parent: {s}", .{os.lastErr()});
}

/// cmd_checkout__worker()
pub fn cmdCheckoutWorker(args: []const []const u8) u8 {
    var base_dir: ?[]const u8 = null;
    const options = [_]po.Opt{
        po.string(0, "prefix", &base_dir, "string", "when creating files, prepend <string>"),
    };
    if (args.len == 2 and util.eql(args[1], "-h")) po.usageExit(&worker_usage, &options, false);
    const rest = po.parse(args[1..], &options, &worker_usage, .{});
    if (rest.len > 0) po.usageWithOptions(&worker_usage, &options);
    // refresh_cache only makes write_pc_item() lstat() the written entries
    // so the stat data can be sent back to the main process.
    const state = entry.State{ .base_dir = base_dir orelse "", .refresh_cache = true };
    workerLoop(&state);
    return 0;
}
