//! References: files backend with packed-refs and reflogs (port of refs.c,
//! refs/files-backend.c, refs/packed-backend.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const ident = @import("ident.zig");
const lockfile = @import("lockfile.zig");
const Oid = hash.Oid;
const gpa = util.gpa;
const rtb = @import("reftable_backend.zig");

/// Does the current repository use the reftable backend?
pub fn isReftable() bool {
    const r = repo_mod.repo_ orelse return false;
    return util.eql(r.ref_storage, "reftable");
}

/// Contents of the HEAD of the repository or worktree at `gitdir`, as a
/// loose HEAD file would hold them. Reads through the reftable stack when
/// `gitdir` uses the reftable format (detected by its HEAD stub).
pub fn headContentsAt(gitdir: []const u8) ?[]const u8 {
    const data = os.readFile(util.concat(&.{ gitdir, "/HEAD" })) orelse return null;
    if (!util.startsWith(data, "ref: refs/heads/.invalid")) return data;
    const dir = util.concat(&.{ gitdir, "/reftable" });
    if (!os.isDir(dir)) return data;
    return rtb.headContents(dir);
}

// ref flags (as in refs.h)
pub const REF_ISSYMREF: u32 = 0x01;
pub const REF_ISPACKED: u32 = 0x02;
pub const REF_ISBROKEN: u32 = 0x04;
pub const REF_BAD_NAME: u32 = 0x08;

pub const Ref = struct {
    name: []const u8,
    oid: Oid,
    symref: ?[]const u8 = null, // target if symbolic
    peeled: ?Oid = null,
    flags: u32 = 0,
};

fn isPerWorktree(name: []const u8) bool {
    if (std.mem.indexOfScalar(u8, name, '/') == null) return true; // HEAD, ORIG_HEAD etc
    return util.startsWith(name, "refs/bisect/") or util.startsWith(name, "refs/worktree/") or util.startsWith(name, "refs/rewritten/");
}

pub fn isPerWorktreeRef(name: []const u8) bool {
    return isPerWorktree(name);
}

pub fn refPath(name: []const u8) []u8 {
    const r = repo_mod.repo();
    if (util.skipPrefix(name, "main-worktree/")) |rest| return r.commonPath(rest);
    if (util.startsWith(name, "worktrees/")) {
        const rest = name["worktrees/".len..];
        if (std.mem.indexOfScalar(u8, rest, '/')) |sl| {
            return util.concat(&.{ r.common_dir, "/worktrees/", rest[0..sl], "/", rest[sl + 1 ..] });
        }
    }
    if (isPerWorktree(name)) return r.gitPath(name);
    return r.commonPath(name);
}

fn logPath(name: []const u8) []u8 {
    const r = repo_mod.repo();
    if (util.skipPrefix(name, "main-worktree/")) |rest| return r.commonPath(util.concat(&.{ "logs/", rest }));
    if (util.startsWith(name, "worktrees/")) {
        const rest = name["worktrees/".len..];
        if (std.mem.indexOfScalar(u8, rest, '/')) |sl| {
            return util.concat(&.{ r.common_dir, "/worktrees/", rest[0..sl], "/logs/", rest[sl + 1 ..] });
        }
    }
    if (isPerWorktree(name)) return r.gitPath(util.concat(&.{ "logs/", name }));
    return r.commonPath(util.concat(&.{ "logs/", name }));
}

fn baseDirFor(name: []const u8) []const u8 {
    const r = repo_mod.repo();
    if (isPerWorktree(name)) return r.git_dir;
    return r.common_dir;
}

// ---------------- refname validation ----------------

pub const ALLOW_ONELEVEL: u32 = 1;
pub const REFSPEC_PATTERN: u32 = 2;

fn disposition(ch: u8) u8 {
    if (ch == '/' or ch == 0) return 1;
    if (ch == '.') return 2;
    if (ch == '{') return 3;
    if (ch < 0x20 or ch == 0x7f or ch == ' ' or ch == '~' or ch == '^' or ch == ':' or ch == '?' or ch == '[' or ch == '\\') return 4;
    if (ch == '*') return 5;
    return 0;
}

/// Returns component length, 0 for empty component, null for invalid.
fn checkComponent(s: []const u8, flags: *u32, sanitized: ?*util.Buf) ?usize {
    var last: u8 = 0;
    var i: usize = 0;
    const comp_start: usize = if (sanitized) |sb| sb.items.len else 0;
    while (i < s.len) : (i += 1) {
        const ch = s[i];
        const disp = disposition(ch);
        if (sanitized) |sb| {
            if (disp != 1) util.bufByte(sb, ch);
        }
        switch (disp) {
            1 => break,
            2 => if (last == '.') {
                if (sanitized) |sb| {
                    sb.items.len -= 1;
                } else return null;
            },
            3 => if (last == '@') {
                if (sanitized) |sb| {
                    sb.items[sb.items.len - 1] = '-';
                } else return null;
            },
            4 => {
                if (sanitized) |sb| {
                    sb.items[sb.items.len - 1] = '-';
                } else return null;
            },
            5 => {
                if (flags.* & REFSPEC_PATTERN == 0) {
                    if (sanitized) |sb| {
                        sb.items[sb.items.len - 1] = '-';
                    } else return null;
                }
                flags.* &= ~REFSPEC_PATTERN;
            },
            else => {},
        }
        last = ch;
    }
    if (i == 0) return 0;
    if (s[0] == '.') {
        if (sanitized) |sb| {
            sb.items[comp_start] = '-';
        } else return null;
    }
    if (i >= 5 and util.eql(s[i - 5 .. i], ".lock")) {
        if (sanitized) |sb| {
            while (util.endsWith(sb.items, ".lock")) sb.items.len -= 5;
        } else return null;
    }
    return i;
}

fn checkOrSanitize(name0: []const u8, flags0: u32, sanitized: ?*util.Buf) bool {
    var flags = flags0;
    var name = name0;
    if (util.eql(name, "@")) {
        if (sanitized) |sb| util.bufByte(sb, '-') else return false;
    }
    var count: usize = 0;
    var clen: usize = 0;
    while (true) {
        if (sanitized) |sb| {
            if (sb.items.len > 0 and sb.items[sb.items.len - 1] != '/') util.bufByte(sb, '/');
        }
        const cl = checkComponent(name, &flags, sanitized);
        if (cl == null) return false;
        clen = cl.?;
        if (sanitized != null and clen == 0) {} else if (clen == 0) return false;
        count += 1;
        if (clen >= name.len) break;
        name = name[clen + 1 ..];
        if (name.len == 0) {
            // trailing slash: an empty last component
            if (sanitized == null) return false;
            break;
        }
    }
    if (clen > 0 and name[clen - 1] == '.') {
        if (sanitized) |sb| {
            if (sb.items.len > 0 and sb.items[sb.items.len - 1] == '.') sb.items.len -= 1;
        } else return false;
    }
    if (flags & ALLOW_ONELEVEL == 0 and count < 2) return false;
    return true;
}

pub fn checkRefnameFormat(name: []const u8, flags: u32) bool {
    if (name.len == 0) return false;
    return checkOrSanitize(name, flags, null);
}

pub fn sanitizeRefnameComponent(name: []const u8) []const u8 {
    var b: util.Buf = .empty;
    _ = checkOrSanitize(name, ALLOW_ONELEVEL, &b);
    return b.items;
}

pub fn refnameIsSafe(name: []const u8) bool {
    if (util.skipPrefix(name, "refs/")) |rest| {
        if (rest.len == 0 or rest[0] == '/' or rest[rest.len - 1] == '/') return false;
        const n = util.normalizePath(rest) orelse return false;
        return util.eql(n, rest);
    }
    if (name.len == 0) return false;
    for (name) |ch| {
        if (!std.ascii.isUpper(ch) and ch != '_') return false;
    }
    return true;
}

pub fn isPseudoRef(name: []const u8) bool {
    return util.eql(name, "FETCH_HEAD") or util.eql(name, "MERGE_HEAD");
}

pub fn isRootRefSyntax(name: []const u8) bool {
    for (name) |ch| {
        if (!std.ascii.isUpper(ch) and ch != '-' and ch != '_') return false;
    }
    return true;
}

pub fn isRootRef(name: []const u8) bool {
    if (!isRootRefSyntax(name) or isPseudoRef(name)) return false;
    if (util.endsWith(name, "_HEAD")) return true;
    for ([_][]const u8{ "HEAD", "AUTO_MERGE", "BISECT_EXPECTED_REV", "NOTES_MERGE_PARTIAL", "NOTES_MERGE_REF", "MERGE_AUTOSTASH" }) |r| {
        if (util.eql(name, r)) return true;
    }
    return false;
}

// ---------------- packed refs ----------------

pub const PackedRef = struct { name: []const u8, oid: Oid, peeled: ?Oid };

var packed_cache: ?[]PackedRef = null;

pub fn invalidatePacked() void {
    packed_cache = null;
}

pub fn packedRefs() []PackedRef {
    if (packed_cache) |p| return p;
    var plist: std.ArrayList(PackedRef) = .empty;
    const r = repo_mod.repo();
    if (os.readFile(r.commonPath("packed-refs"))) |data| {
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line0| {
            var line = line0;
            if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
            if (line.len == 0 or line[0] == '#') continue;
            if (line[0] == '^') {
                if (plist.items.len > 0) plist.items[plist.items.len - 1].peeled = hash.fromHex(line[1..]);
                continue;
            }
            if (line.len < 42) continue;
            const oid = hash.fromHex(line[0..40]) orelse continue;
            plist.append(gpa, .{ .name = line[41..], .oid = oid, .peeled = null }) catch util.oom();
        }
    }
    std.mem.sort(PackedRef, plist.items, {}, struct {
        fn lt(_: void, a: PackedRef, b: PackedRef) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    packed_cache = plist.items;
    return plist.items;
}

pub fn findPacked(name: []const u8) ?PackedRef {
    const items = packedRefs();
    var lo: usize = 0;
    var hi: usize = items.len;
    while (lo < hi) {
        const mid = (lo + hi) / 2;
        switch (std.mem.order(u8, items[mid].name, name)) {
            .eq => return items[mid],
            .lt => lo = mid + 1,
            .gt => hi = mid,
        }
    }
    return null;
}

pub fn formatPacked(entries: []const PackedRef) []u8 {
    var b: util.Buf = .empty;
    util.bufAppend(&b, "# pack-refs with: peeled fully-peeled sorted \n");
    for (entries) |p| {
        util.bufPrint(&b, "{s} {s}\n", .{ hash.hex(p.oid), p.name });
        if (p.peeled) |pe| util.bufPrint(&b, "^{s}\n", .{hash.hex(pe)});
    }
    return b.items;
}

pub fn writePackedFile(path: []const u8, data: []const u8) void {
    const lock = util.concat(&.{ path, ".lock" });
    os.writeFile(lock, data, 0o666) catch return;
    _ = os.rename(lock, path);
    invalidatePacked();
}

/// Write all refs to packed-refs, entries given explicitly.
pub fn writePacked(entries: []const PackedRef) void {
    if (isReftable()) {
        // ref_transaction with REF_TRANSACTION_FLAG_INITIAL (clone)
        const t = Transaction.init();
        for (entries) |p| {
            const e = t.create(p.name, p.oid, null, 0, null);
            if (e != .ok) util.die("{s}", .{t.err.items});
        }
        if (t.commit() != .ok) util.die("{s}", .{t.err.items});
        return;
    }
    const r = repo_mod.repo();
    writePackedFile(r.commonPath("packed-refs"), formatPacked(entries));
}

pub fn peeledOf(oid: Oid) ?Oid {
    const objects = @import("objects.zig");
    const odb = repo_mod.repo().odb();
    const t = odb.readType(oid) orelse return null;
    if (t != .tag) return null;
    const p = objects.peel(oid) orelse return null;
    return p.oid;
}

// ---------------- reading ----------------

pub const RawRef = union(enum) {
    oid: Oid,
    symref: []const u8,
};

pub const RawRead = union(enum) {
    oid: Oid,
    symref: []const u8,
    missing,
    isdir,
    broken,
};

/// Read a ref's raw value from the files backend (loose, then packed).
pub fn readRawFull(name: []const u8) RawRead {
    return readRawFullOpt(name, true);
}

fn readRawFullOpt(name: []const u8, use_packed: bool) RawRead {
    if (isReftable() and !isPseudoRef(name)) return rtb.readRaw(name);
    const path = refPath(name);
    const st = os.lstatPath(path) orelse {
        if (use_packed and !isRootRefSyntax(name)) {
            if (findPacked(name)) |p| return .{ .oid = p.oid };
        }
        return .missing;
    };
    if (st.isLnk()) {
        if (os.readLink(path)) |t| {
            if (util.startsWith(t, "refs/") and checkRefnameFormat(t, 0)) return .{ .symref = t };
        }
    }
    const st2 = os.statPath(path) orelse return .missing;
    if (st2.isDir()) {
        if (use_packed) {
            if (findPacked(name)) |p| return .{ .oid = p.oid };
        }
        return .isdir;
    }
    const data = os.readFile(path) orelse return .missing;
    if (util.skipPrefix(data, "ref:")) |rest| {
        const t = util.trim(rest);
        return .{ .symref = t };
    }
    if (data.len >= 40) {
        if (hash.fromHex(data[0..40])) |o| {
            if (data.len == 40 or std.ascii.isWhitespace(data[40])) return .{ .oid = o };
        }
    }
    return .broken;
}

/// Read a single ref without following symrefs.
pub fn readRaw(name: []const u8) ?RawRef {
    return switch (readRawFull(name)) {
        .oid => |o| .{ .oid = o },
        .symref => |t| .{ .symref = t },
        else => null,
    };
}

pub const Resolved = struct {
    oid: Oid,
    name: []const u8, // final ref name
    symbolic: bool,
};

/// Resolve following symbolic refs. If the final ref doesn't exist, returns null
/// (use resolveTarget for dangling symrefs).
pub fn resolve(name: []const u8) ?Resolved {
    const r = resolveFull(name, true);
    if (r.missing or r.broken) return null;
    return .{ .oid = r.oid, .name = r.name, .symbolic = r.flags & REF_ISSYMREF != 0 };
}

pub const ResolveResult = struct {
    name: []const u8,
    oid: Oid = hash.zero,
    flags: u32 = 0,
    missing: bool = false,
    broken: bool = false, // unresolvable (bad name, loop, broken content)
};

/// Full port of refs_resolve_ref_unsafe. `reading`: missing refs are an error.
pub fn resolveFull(name: []const u8, reading: bool) ResolveResult {
    var res = ResolveResult{ .name = name };
    if (!checkRefnameFormat(name, ALLOW_ONELEVEL)) {
        if (!refnameIsSafe(name)) {
            res.broken = true;
            return res;
        }
        res.flags |= REF_BAD_NAME | REF_ISBROKEN;
    }
    var cur = name;
    var depth: u32 = 0;
    while (depth < 5) : (depth += 1) {
        res.name = cur;
        switch (readRawFull(cur)) {
            .oid => |o| {
                res.oid = o;
                if (findPackedIsLoose(cur)) {} else res.flags |= REF_ISPACKED;
                return res;
            },
            .symref => |t| {
                res.flags |= REF_ISSYMREF;
                if (!checkRefnameFormat(t, ALLOW_ONELEVEL)) {
                    if (!refnameIsSafe(t)) {
                        res.broken = true;
                        return res;
                    }
                    res.flags |= REF_BAD_NAME | REF_ISBROKEN;
                }
                cur = t;
            },
            .missing, .isdir => {
                res.missing = true;
                if (reading) res.broken = true;
                return res;
            },
            .broken => {
                res.flags |= REF_ISBROKEN;
                res.broken = true;
                return res;
            },
        }
    }
    res.broken = true;
    return res;
}

fn findPackedIsLoose(name: []const u8) bool {
    if (isReftable()) return true;
    return os.lstatPath(refPath(name)) != null;
}

/// Follow symbolic refs to the final ref name, even if it doesn't exist.
pub fn resolveTarget(name: []const u8) []const u8 {
    var cur = name;
    var depth: u32 = 0;
    while (depth < 6) : (depth += 1) {
        const raw = readRaw(cur) orelse return cur;
        switch (raw) {
            .oid => return cur,
            .symref => |t| cur = t,
        }
    }
    return cur;
}

pub fn readOid(name: []const u8) ?Oid {
    const r = resolve(name) orelse return null;
    return r.oid;
}

pub fn exists(name: []const u8) bool {
    return resolve(name) != null;
}

/// Is `name` a symbolic ref? Returns its target.
pub fn readSymbolic(name: []const u8) ?[]const u8 {
    return switch (readRawFull(name)) {
        .symref => |t| t,
        else => null,
    };
}

/// Head's symbolic target ("refs/heads/master") or null if detached.
pub fn headSymref() ?[]const u8 {
    const raw = readRaw("HEAD") orelse return null;
    return switch (raw) {
        .symref => |t| t,
        .oid => null,
    };
}

/// Current branch short name or null if detached.
pub fn currentBranch() ?[]const u8 {
    const t = headSymref() orelse return null;
    return util.skipPrefix(t, "refs/heads/") orelse t;
}

/// DWIM ref: expand short name per rev-parse rules. Returns full name and oid.
pub fn dwimRef(short: []const u8) ?struct { name: []const u8, oid: Oid, count: usize } {
    // substitute_branch_name(): interpret @{-N} before expanding the rules.
    if (util.startsWith(short, "@{-") and util.endsWith(short, "}") and short.len > 4) {
        const rp = @import("revparse.zig");
        const nth = std.fmt.parseInt(usize, short[3 .. short.len - 1], 10) catch 0;
        if (nth > 0) {
            if (rp.previousBranch(nth)) |b| {
                if (!util.startsWith(b, "@{-")) return dwimRef(b);
            }
        }
    }
    const rules = [_][]const u8{ "{s}", "refs/{s}", "refs/tags/{s}", "refs/heads/{s}", "refs/remotes/{s}", "refs/remotes/{s}/HEAD" };
    var found: ?Resolved = null;
    var found_name: []const u8 = "";
    var count: usize = 0;
    inline for (rules, 0..) |rule, ri| {
        const full = util.fmt(rule, .{short});
        const ok = if (ri == 0) (isAllCapsOrHead(short) or util.startsWith(short, "refs/")) else true;
        if (ok) {
            if (resolve(full)) |r| {
                if (found == null) {
                    found = r;
                    found_name = full;
                }
                count += 1;
            }
        }
    }
    if (found) |f| return .{ .name = found_name, .oid = f.oid, .count = count };
    return null;
}

fn isAllCapsOrHead(s: []const u8) bool {
    // git checks for a valid pseudoref name: all caps / underscores, or something under refs/
    for (s) |ch| {
        if (!(std.ascii.isUpper(ch) or ch == '_' or ch == '-')) return std.mem.indexOfScalar(u8, s, '/') != null;
    }
    return true;
}

fn collectLoose(dir: []const u8, prefix: []const u8, out: *std.ArrayList([]const u8)) void {
    const ents = os.listDir(dir) orelse return;
    for (ents) |e| {
        if (e.name.len > 0 and e.name[0] == '.') continue;
        const full = util.concat(&.{ dir, "/", e.name });
        const name = util.concat(&.{ prefix, e.name });
        const st = os.statPath(full) orelse (os.lstatPath(full) orelse continue);
        if (st.isDir()) {
            collectLoose(full, util.concat(&.{ name, "/" }), out);
        } else {
            if (util.endsWith(e.name, ".lock")) continue;
            out.append(gpa, name) catch util.oom();
        }
    }
}

fn looseNames() []const []const u8 {
    const r = repo_mod.repo();
    var names: std.ArrayList([]const u8) = .empty;
    var all: std.ArrayList([]const u8) = .empty;
    collectLoose(r.commonPath("refs"), "refs/", &all);
    const separate = !util.eql(r.git_dir, r.common_dir);
    for (all.items) |n| {
        if (separate and isPerWorktree(n)) continue;
        names.append(gpa, n) catch util.oom();
    }
    if (separate) {
        for ([_][]const u8{ "refs/bisect", "refs/worktree", "refs/rewritten" }) |d| {
            collectLoose(r.gitPath(d), util.concat(&.{ d, "/" }), &names);
        }
    }
    return names.items;
}

pub const IterOpts = struct {
    include_broken: bool = false,
    /// report missing objects with "error: %s does not point to a valid object!"
    check_objects: bool = true,
};

/// Iterate over refs (loose and packed) whose names start with prefix, sorted.
pub fn iterate(prefix: []const u8, opts: IterOpts) []Ref {
    if (isReftable()) return rtb.iterate(prefix, opts);
    var map = std.StringHashMap(void).init(gpa);
    var result: std.ArrayList(Ref) = .empty;
    const odb = repo_mod.repo().odb();
    for (looseNames()) |n| {
        if (!util.startsWith(n, prefix)) continue;
        if (map.contains(n)) continue;
        map.put(n, {}) catch util.oom();
        var ref = Ref{ .name = n, .oid = hash.zero };
        // loose_fill_ref_dir_regular_file(): a badly named ref is not even
        // read; a ref whose resolution goes through a bad name is broken.
        const name_ok = checkRefnameFormat(n, ALLOW_ONELEVEL);
        const res = if (name_ok) resolveFull(n, true) else ResolveResult{ .name = n, .broken = true };
        if (res.broken or res.flags & REF_BAD_NAME != 0) {
            ref.flags |= REF_ISBROKEN;
        } else {
            ref.oid = res.oid;
            if (hash.isZero(res.oid)) ref.flags |= REF_ISBROKEN;
        }
        ref.flags |= res.flags & (REF_ISSYMREF);
        if (res.flags & REF_ISSYMREF != 0) {
            ref.symref = readSymbolic(n);
        }
        if (!checkRefnameFormat(n, ALLOW_ONELEVEL)) {
            if (!refnameIsSafe(n)) util.die("loose refname is dangerous: {s}", .{n});
            ref.oid = hash.zero;
            ref.flags |= REF_BAD_NAME | REF_ISBROKEN;
        }
        if (!opts.include_broken) {
            if (ref.flags & REF_ISBROKEN != 0) continue;
            if (opts.check_objects and !odb.has(ref.oid)) {
                util.err("{s} does not point to a valid object!", .{n});
                continue;
            }
        }
        if (ref.flags & REF_ISSYMREF == 0) {
            if (findPacked(n)) |p| {
                if (hash.eql(p.oid, ref.oid)) ref.peeled = p.peeled;
            }
        }
        result.append(gpa, ref) catch util.oom();
    }
    for (packedRefs()) |p| {
        if (!util.startsWith(p.name, prefix)) continue;
        if (map.contains(p.name)) continue;
        if (!opts.include_broken and opts.check_objects and !odb.has(p.oid)) {
            util.err("{s} does not point to a valid object!", .{p.name});
            continue;
        }
        result.append(gpa, .{ .name = p.name, .oid = p.oid, .peeled = p.peeled, .flags = REF_ISPACKED }) catch util.oom();
    }
    std.mem.sort(Ref, result.items, {}, struct {
        fn lt(_: void, a: Ref, b: Ref) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    return result.items;
}

/// List all refs under prefix (e.g. "refs/heads/"), sorted by name. Symrefs are resolved.
pub fn list(prefix: []const u8) []Ref {
    return iterate(prefix, .{ .check_objects = false });
}

/// Root refs in $GIT_DIR (HEAD, ORIG_HEAD, ...), sorted.
pub fn listRootRefs() []Ref {
    if (isReftable()) return rtb.listRootRefs();
    const r = repo_mod.repo();
    var result: std.ArrayList(Ref) = .empty;
    const ents = os.listDir(r.git_dir) orelse return result.items;
    for (ents) |e| {
        if (!isRootRef(e.name)) continue;
        const res = resolveFull(e.name, true);
        if (res.broken) continue;
        var ref = Ref{ .name = e.name, .oid = res.oid, .flags = res.flags };
        if (res.flags & REF_ISSYMREF != 0) ref.symref = readSymbolic(e.name);
        result.append(gpa, ref) catch util.oom();
    }
    std.mem.sort(Ref, result.items, {}, struct {
        fn lt(_: void, a: Ref, b: Ref) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    return result.items;
}

// ---------------- reflogs ----------------

pub fn logAllRefUpdates() enum { unset, none, normal, always } {
    const v = repo_mod.cfg.get("core.logallrefupdates") orelse {
        if (repo_mod.cfg.getEntry("core.logallrefupdates") != null) return .normal; // "[core] logallrefupdates" (no value) == true
        return .unset;
    };
    if (std.ascii.eqlIgnoreCase(v, "always")) return .always;
    const b = @import("config.zig").parseBool(v) orelse false;
    return if (b) .normal else .none;
}

pub fn shouldAutocreateReflog(name: []const u8) bool {
    const r = repo_mod.repo();
    var mode = logAllRefUpdates();
    if (mode == .unset) mode = if (r.bare) .none else .normal;
    return switch (mode) {
        .always => true,
        .normal => util.startsWith(name, "refs/heads/") or util.startsWith(name, "refs/remotes/") or util.startsWith(name, "refs/notes/") or util.eql(name, "HEAD"),
        else => false,
    };
}

pub fn normalizeReflogMsg(msg: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var wasspace = true;
    for (msg) |ch0| {
        var ch = ch0;
        const sp = std.ascii.isWhitespace(ch);
        if (wasspace and sp) continue;
        wasspace = sp;
        if (sp) ch = ' ';
        util.bufByte(&b, ch);
    }
    while (b.items.len > 0 and std.ascii.isWhitespace(b.items[b.items.len - 1])) b.items.len -= 1;
    return b.items;
}

/// Write a reflog entry. Returns an error message on failure.
fn logRefWrite(name: []const u8, old: Oid, new: Oid, committer: ?[]const u8, msg: []const u8, force_create: bool) ?[]const u8 {
    const path = logPath(name);
    var fd: c_int = -1;
    if (force_create or shouldAutocreateReflog(name)) {
        if (!os.mkdirLeading(path)) {
            return util.fmt("unable to create directory for '{s}': {s}", .{ path, os.lastErr() });
        }
        fd = os.openFile(path, os.O_APPEND | os.O_WRONLY | os.O_CREAT, 0o666);
        if (fd < 0) {
            const e = os.errno();
            if (e == os.EISDIR) {
                // try removing empty directories
                if (os.rmdir(path)) {
                    fd = os.openFile(path, os.O_APPEND | os.O_WRONLY | os.O_CREAT, 0o666);
                }
                if (fd < 0) return util.fmt("there are still logs under '{s}'", .{path});
            } else return util.fmt("unable to append to '{s}': {s}", .{ path, os.strErr(e) });
        }
    } else {
        fd = os.openFile(path, os.O_APPEND | os.O_WRONLY, 0);
        if (fd < 0) {
            const e = os.errno();
            if (e == os.ENOENT or e == os.EISDIR) return null;
            return util.fmt("unable to append to '{s}': {s}", .{ path, os.strErr(e) });
        }
    }
    defer os.close(fd);
    var b: util.Buf = .empty;
    util.bufPrint(&b, "{s} {s} {s}", .{ hash.hex(old), hash.hex(new), committer orelse ident.committer() });
    if (msg.len > 0) {
        util.bufByte(&b, '\t');
        util.bufAppend(&b, msg);
    }
    util.bufByte(&b, '\n');
    os.writeAll(fd, b.items) catch return util.fmt("unable to append to '{s}': {s}", .{ path, os.lastErr() });
    return null;
}

pub fn appendReflog(name: []const u8, old: Oid, new: Oid, msg: []const u8, force_create: bool) void {
    if (isReftable()) return rtb.appendReflog(name, old, new, msg);
    _ = logRefWrite(name, old, new, null, normalizeReflogMsg(msg), force_create);
}

/// Create an (empty) reflog for name. Returns error message on failure.
pub fn createReflog(name: []const u8) ?[]const u8 {
    if (isReftable()) return rtb.createReflog(name);
    const path = logPath(name);
    if (!os.mkdirLeading(path)) return util.fmt("unable to create directory for '{s}': {s}", .{ path, os.lastErr() });
    const fd = os.openFile(path, os.O_APPEND | os.O_WRONLY | os.O_CREAT, 0o666);
    if (fd < 0) {
        if (os.errno() == os.EISDIR) return util.fmt("there are still logs under '{s}'", .{path});
        return util.fmt("unable to append to '{s}': {s}", .{ path, os.lastErr() });
    }
    os.close(fd);
    return null;
}

pub fn deleteReflog(name: []const u8) bool {
    if (isReftable()) return rtb.deleteReflog(name);
    const lp = logPath(name);
    if (!os.unlink(lp)) return false;
    removeRefParents(lp, name);
    return true;
}

pub const ReflogEntry = struct {
    old: Oid,
    new: Oid,
    ident: []const u8, // "Name <email> time tz"
    msg: []const u8,
    /// reftable: update_index of the log record (0 for files)
    update_index: u64 = 0,
};

pub fn parseReflogLine(line: []const u8) ?ReflogEntry {
    if (line.len < 83) return null;
    const old = hash.fromHex(line[0..40]) orelse return null;
    if (line[40] != ' ') return null;
    const new = hash.fromHex(line[41..81]) orelse return null;
    if (line[81] != ' ') return null;
    const rest = line[82..];
    var id = rest;
    var msg: []const u8 = "";
    if (std.mem.indexOfScalar(u8, rest, '\t')) |t| {
        id = rest[0..t];
        msg = rest[t + 1 ..];
    }
    return .{ .old = old, .new = new, .ident = id, .msg = msg };
}

pub fn readReflog(name: []const u8) []ReflogEntry {
    if (isReftable()) return rtb.readReflog(name);
    var out: std.ArrayList(ReflogEntry) = .empty;
    const data = os.readFile(logPath(name)) orelse return out.items;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line| {
        const e = parseReflogLine(line) orelse continue;
        out.append(gpa, e) catch util.oom();
    }
    return out.items;
}

pub fn reflogExists(name: []const u8) bool {
    if (isReftable()) return rtb.reflogExists(name);
    return os.isFile(logPath(name));
}

pub fn reflogPath(name: []const u8) []u8 {
    return logPath(name);
}

pub fn formatReflog(entries: []const ReflogEntry) []u8 {
    var b: util.Buf = .empty;
    for (entries) |e| {
        util.bufPrint(&b, "{s} {s} {s}", .{ hash.hex(e.old), hash.hex(e.new), e.ident });
        if (e.msg.len > 0) {
            util.bufByte(&b, '\t');
            util.bufAppend(&b, e.msg);
        }
        util.bufByte(&b, '\n');
    }
    return b.items;
}

pub fn writeReflog(name: []const u8, entries: []const ReflogEntry) void {
    if (isReftable()) {
        _ = rtb.rewriteReflog(name, entries, null);
        return;
    }
    os.writeFile(logPath(name), formatReflog(entries), 0o666) catch {};
}

pub fn renameReflog(old: []const u8, new: []const u8) void {
    const op = logPath(old);
    if (!os.exists(op)) return;
    const np = logPath(new);
    _ = os.mkdirLeading(np);
    _ = os.rename(op, np);
}

/// All refs that have reflogs (names), sorted.
pub fn listReflogs() [][]const u8 {
    if (isReftable()) return rtb.listReflogs();
    const r = repo_mod.repo();
    var names: std.ArrayList([]const u8) = .empty;
    var seen = std.StringHashMap(void).init(gpa);
    const dirs = if (util.eql(r.git_dir, r.common_dir)) &[_][]const u8{r.git_dir} else &[_][]const u8{ r.git_dir, r.common_dir };
    for (dirs, 0..) |d, di| {
        var tmp: std.ArrayList([]const u8) = .empty;
        collectLoose(util.concat(&.{ d, "/logs" }), "", &tmp);
        for (tmp.items) |n| {
            if (dirs.len > 1) {
                // per-worktree logs come from git_dir, shared ones from common dir
                if (di == 0 and !isPerWorktree(n)) continue;
                if (di == 1 and isPerWorktree(n)) continue;
            }
            if (!checkRefnameFormat(n, ALLOW_ONELEVEL)) continue;
            if (seen.contains(n)) continue;
            seen.put(n, {}) catch util.oom();
            names.append(gpa, n) catch util.oom();
        }
    }
    util.sortStrings(names.items);
    return names.items;
}

/// Per-worktree reflogs (HEAD, refs/bisect/... etc.) stored for the worktree
/// `wt_id` (null: the main worktree), as names within that worktree.
pub fn listWorktreeOwnReflogs(wt_id: ?[]const u8) [][]const u8 {
    if (isReftable()) return rtb.listWorktreeOwnReflogs(wt_id);
    const r = repo_mod.repo();
    const base = if (wt_id) |id| util.concat(&.{ r.common_dir, "/worktrees/", id }) else r.common_dir;
    var tmp: std.ArrayList([]const u8) = .empty;
    collectLoose(util.concat(&.{ base, "/logs" }), "", &tmp);
    var names: std.ArrayList([]const u8) = .empty;
    for (tmp.items) |n| {
        if (!isPerWorktree(n) or !checkRefnameFormat(n, ALLOW_ONELEVEL)) continue;
        names.append(gpa, n) catch util.oom();
    }
    util.sortStrings(names.items);
    return names.items;
}

// ---------------- transactions ----------------

pub const F_NO_DEREF: u32 = 1 << 0;
pub const F_FORCE_CREATE_REFLOG: u32 = 1 << 1;
pub const F_HAVE_NEW: u32 = 1 << 2;
pub const F_HAVE_OLD: u32 = 1 << 3;
pub const F_LOG_ONLY: u32 = 1 << 4;
pub const F_DELETING: u32 = 1 << 5;
pub const F_NEEDS_COMMIT: u32 = 1 << 6;
pub const F_UPDATE_VIA_HEAD: u32 = 1 << 7;
pub const F_LOG_VIA_SPLIT: u32 = 1 << 8;
pub const F_SKIP_OID_VERIFICATION: u32 = 1 << 9;
pub const F_SKIP_REFNAME_VERIFICATION: u32 = 1 << 10;
pub const F_SKIP_CREATE_REFLOG: u32 = 1 << 11;
pub const F_IS_PRUNING: u32 = 1 << 12;
pub const F_DELETED_RMDIR: u32 = 1 << 13;
pub const F_LOG_USE_PROVIDED_OIDS: u32 = 1 << 14;

pub const TxErr = enum {
    ok,
    generic,
    name_conflict,
    create_exists,
    nonexistent_ref,
    incorrect_old_value,
    invalid_new_value,
    expected_symref,
    case_conflict,

    pub fn msg(self: TxErr) []const u8 {
        return switch (self) {
            .name_conflict => "refname conflict",
            .create_exists => "reference already exists",
            .nonexistent_ref => "reference does not exist",
            .incorrect_old_value => "incorrect old value provided",
            .invalid_new_value => "invalid new value provided",
            .expected_symref => "expected symref but found regular ref",
            .case_conflict => "reference conflict due to case-insensitive filesystem",
            else => "unknown failure",
        };
    }
};

const RefLock = struct {
    name: []const u8,
    lk: ?*lockfile.Lock,
    old_oid: Oid = hash.zero,
};

pub const Update = struct {
    refname: []const u8,
    flags: u32,
    new_oid: Oid = hash.zero,
    old_oid: Oid = hash.zero,
    new_target: ?[]const u8 = null,
    old_target: ?[]const u8 = null,
    msg: []const u8 = "",
    committer: ?[]const u8 = null,
    parent: ?*Update = null,
    lock: ?*RefLock = null,
    is_symref: bool = false,
    is_packed: bool = false,
    rejection: TxErr = .ok,
    rejection_details: []const u8 = "",
    /// reflog ordering index (ref_transaction_update_reflog)
    index: u64 = 0,
    /// REF_HAVE_PEELED value
    peeled: ?Oid = null,

    pub fn originalName(self: *const Update) []const u8 {
        var u = self;
        while (u.parent) |p| u = p;
        return u.refname;
    }
};

pub const Transaction = struct {
    updates: std.ArrayList(*Update) = .empty,
    state: enum { open, prepared, closed } = .open,
    allow_failures: bool = false,
    err: util.Buf = .empty,
    locks: std.StringHashMapUnmanaged(*RefLock) = .empty,
    packed_deletes: std.ArrayList([]const u8) = .empty,
    packed_lock: ?*lockfile.Lock = null,
    max_index: u64 = 0,
    /// reftable backend data (reftable_backend.TxData)
    rt_data: ?*anyopaque = null,

    pub fn init() *Transaction {
        const t = gpa.create(Transaction) catch util.oom();
        t.* = .{};
        return t;
    }

    pub fn errMsg(self: *const Transaction) []const u8 {
        return self.err.items;
    }

    pub fn setErr(self: *Transaction, comptime f: []const u8, args: anytype) void {
        self.err.clearRetainingCapacity();
        util.bufPrint(&self.err, f, args);
    }

    pub fn refnameValid(self: *Transaction, refname: []const u8, new_oid: ?Oid, flags: u32) bool {
        if (flags & F_SKIP_REFNAME_VERIFICATION != 0) return true;
        if (isPseudoRef(refname)) {
            if (flags & F_LOG_ONLY != 0) {
                self.setErr("refusing to update reflog for pseudoref '{s}'", .{refname});
            } else self.setErr("refusing to update pseudoref '{s}'", .{refname});
            return false;
        }
        const bad = if (new_oid != null and !hash.isZero(new_oid.?)) !checkRefnameFormat(refname, ALLOW_ONELEVEL) else !refnameIsSafe(refname);
        if (bad) {
            if (flags & F_LOG_ONLY != 0) {
                self.setErr("refusing to update reflog with bad name '{s}'", .{refname});
            } else self.setErr("refusing to update ref with bad name '{s}'", .{refname});
            return false;
        }
        return true;
    }

    pub fn addUpdate(self: *Transaction, u: Update) *Update {
        const p = gpa.create(Update) catch util.oom();
        p.* = u;
        self.updates.append(gpa, p) catch util.oom();
        return p;
    }

    /// ref_transaction_update. Returns .ok or an error (message in err).
    pub fn update(self: *Transaction, refname: []const u8, new_oid: ?Oid, old_oid: ?Oid, new_target: ?[]const u8, old_target: ?[]const u8, flags0: u32, msg: ?[]const u8) TxErr {
        var flags = flags0;
        if (flags & F_FORCE_CREATE_REFLOG != 0 and flags & F_SKIP_CREATE_REFLOG != 0) {
            self.setErr("refusing to force and skip creation of reflog", .{});
            return .generic;
        }
        if (!self.refnameValid(refname, new_oid, flags)) return .generic;
        if (new_oid != null or new_target != null) flags |= F_HAVE_NEW;
        if (old_oid != null or old_target != null) flags |= F_HAVE_OLD;
        _ = self.addUpdate(.{
            .refname = refname,
            .flags = flags,
            .new_oid = new_oid orelse hash.zero,
            .old_oid = old_oid orelse hash.zero,
            .new_target = new_target,
            .old_target = old_target,
            .msg = if (flags & F_SKIP_CREATE_REFLOG != 0) "" else normalizeReflogMsg(msg orelse ""),
        });
        return .ok;
    }

    pub fn create(self: *Transaction, refname: []const u8, new_oid: ?Oid, new_target: ?[]const u8, flags: u32, msg: ?[]const u8) TxErr {
        if ((new_oid == null or hash.isZero(new_oid.?)) and new_target == null) {
            self.setErr("'{s}' has neither a valid OID nor a target", .{refname});
            return .generic;
        }
        return self.update(refname, new_oid, hash.zero, new_target, null, flags, msg);
    }

    pub fn delete(self: *Transaction, refname: []const u8, old_oid: ?Oid, old_target: ?[]const u8, flags: u32, msg: ?[]const u8) TxErr {
        return self.update(refname, hash.zero, old_oid, null, old_target, flags, msg);
    }

    pub fn verify(self: *Transaction, refname: []const u8, old_oid: ?Oid, old_target: ?[]const u8, flags: u32) TxErr {
        return self.update(refname, null, old_oid, null, old_target, flags, null);
    }


    /// ref_transaction_update_reflog(): queue a reflog entry with the given
    /// old/new values, committer and ordering index.
    pub fn updateReflog(self: *Transaction, refname: []const u8, new_oid: Oid, old_oid: Oid, committer: ?[]const u8, msg: []const u8, index: u64) TxErr {
        const flags = F_HAVE_OLD | F_HAVE_NEW | F_LOG_ONLY | F_FORCE_CREATE_REFLOG | F_NO_DEREF | F_LOG_USE_PROVIDED_OIDS;
        if (!self.refnameValid(refname, new_oid, flags)) return .generic;
        const u = self.addUpdate(.{
            .refname = refname,
            .flags = flags,
            .new_oid = new_oid,
            .old_oid = old_oid,
            .committer = committer,
            .msg = normalizeReflogMsg(msg),
        });
        u.index = index;
        if (index > self.max_index) self.max_index = index;
        return .ok;
    }
    pub fn hasRefname(self: *Transaction, name: []const u8) bool {
        for (self.updates.items) |u| {
            if (u.flags & F_LOG_ONLY != 0) continue;
            if (u.rejection != .ok) continue;
            if (util.eql(u.refname, name)) return true;
        }
        return false;
    }

    pub fn maybeReject(self: *Transaction, u: *Update, e: TxErr) bool {
        if (!self.allow_failures or e == .generic) return false;
        u.rejection = e;
        u.rejection_details = util.dupe(self.err.items);
        self.err.clearRetainingCapacity();
        return true;
    }

    pub fn prepare(self: *Transaction) TxErr {
        // reject duplicates
        var names: std.ArrayList([]const u8) = .empty;
        for (self.updates.items) |u| {
            if (u.flags & F_LOG_ONLY == 0) names.append(gpa, u.refname) catch util.oom();
        }
        util.sortStrings(names.items);
        var i: usize = 1;
        while (i < names.items.len) : (i += 1) {
            if (util.eql(names.items[i - 1], names.items[i])) {
                self.setErr("multiple updates for ref '{s}' not allowed", .{names.items[i]});
                return .generic;
            }
        }
        if (os.getenv("GIT_QUARANTINE_PATH") != null) {
            self.setErr("ref updates forbidden inside quarantine environment", .{});
            return .generic;
        }
        if (runHook(self, "preparing") != 0) {
            self.abort();
            util.die("in '{s}' phase, update aborted by the reference-transaction hook", .{"preparing"});
        }
        const e = self.backendPrepare();
        if (e != .ok) return e;
        if (runHook(self, "prepared") != 0) {
            self.abort();
            util.die("in '{s}' phase, update aborted by the reference-transaction hook", .{"prepared"});
        }
        return .ok;
    }

    fn backendPrepare(self: *Transaction) TxErr {
        if (isReftable()) return rtb.prepare(self);
        return self.filesPrepare();
    }

    fn filesPrepare(self: *Transaction) TxErr {
        if (self.updates.items.len == 0) {
            self.state = .prepared;
            return .ok;
        }
        var head_ref: ?[]const u8 = null;
        switch (readRawFull("HEAD")) {
            .symref => |t| head_ref = t,
            else => {},
        }
        var to_check: std.ArrayList(*Update) = .empty;
        var i: usize = 0;
        while (i < self.updates.items.len) : (i += 1) {
            const u = self.updates.items[i];
            const e = self.lockRefForUpdate(u, head_ref, &to_check);
            if (e != .ok) {
                if (self.maybeReject(u, e)) continue;
                self.cleanup();
                return e;
            }
            if (u.flags & F_DELETING != 0 and u.flags & F_LOG_ONLY == 0 and u.flags & F_IS_PRUNING == 0) {
                self.packed_deletes.append(gpa, u.refname) catch util.oom();
            }
        }
        // verify availability against packed refs
        var extras: std.ArrayList([]const u8) = .empty;
        for (self.updates.items) |u| {
            if (u.flags & F_LOG_ONLY == 0 and u.rejection == .ok) extras.append(gpa, u.refname) catch util.oom();
        }
        for (to_check.items) |u| {
            if (u.rejection != .ok) continue;
            if (verifyAvailable(u.refname, extras.items, &.{}, .packed_only, &self.err)) |e| {
                if (self.maybeReject(u, e)) {
                    // release its lock
                    if (u.lock) |l| {
                        if (l.lk) |lk| lk.rollback();
                        _ = self.locks.remove(u.refname);
                        u.lock = null;
                    }
                    continue;
                }
                self.cleanup();
                return e;
            }
        }
        // packed refs: lock if we need to delete something from it
        var need_packed = false;
        for (self.packed_deletes.items) |n| {
            if (findPacked(n) != null) need_packed = true;
        }
        if (self.packed_deletes.items.len > 0) {
            const path = repo_mod.repo().commonPath("packed-refs");
            switch (lockfile.tryLock(path)) {
                .ok => |l| self.packed_lock = l,
                .err => |e| {
                    self.err.clearRetainingCapacity();
                    util.bufAppend(&self.err, lockfile.lockMessage(path, e));
                    self.cleanup();
                    return .generic;
                },
            }
            if (!need_packed) {
                // keep it locked but nothing to rewrite
            }
        }
        self.state = .prepared;
        return .ok;
    }

    fn lockRefForUpdate(self: *Transaction, u: *Update, head_ref: ?[]const u8, to_check: *std.ArrayList(*Update)) TxErr {
        const mustexist = u.flags & F_HAVE_OLD != 0 and (u.old_target != null or !hash.isZero(u.old_oid));
        if (u.flags & F_HAVE_NEW != 0 and u.new_target == null and hash.isZero(u.new_oid)) u.flags |= F_DELETING;

        if (head_ref) |hr| {
            if (u.flags & (F_LOG_ONLY | F_SKIP_CREATE_REFLOG | F_IS_PRUNING | F_UPDATE_VIA_HEAD) == 0 and util.eql(u.refname, hr)) {
                if (self.hasRefname("HEAD")) {
                    self.setErr("multiple updates for 'HEAD' (including one via its referent '{s}') are not allowed", .{u.refname});
                    return .name_conflict;
                }
                const nu = self.addUpdate(.{
                    .refname = "HEAD",
                    .flags = u.flags | F_LOG_ONLY | F_NO_DEREF | F_LOG_VIA_SPLIT,
                    .new_oid = u.new_oid,
                    .old_oid = u.old_oid,
                    .msg = u.msg,
                    .committer = u.committer,
                });
                nu.parent = u;
            }
        }

        var referent: []const u8 = "";
        var lock: *RefLock = undefined;
        if (self.locks.get(u.refname)) |l| {
            lock = l;
            // re-read type
            switch (readRawFull(u.refname)) {
                .symref => |t| {
                    u.is_symref = true;
                    referent = t;
                },
                else => {},
            }
        } else {
            const r = self.lockRawRef(u, mustexist, to_check, &referent);
            switch (r) {
                .err => |e| {
                    const reason = util.dupe(self.err.items);
                    self.setErr("cannot lock ref '{s}': {s}", .{ u.originalName(), reason });
                    return e;
                },
                .ok => |l| lock = l,
            }
            self.locks.put(gpa, u.refname, lock) catch util.oom();
        }
        u.lock = lock;

        if (u.flags & F_LOG_VIA_SPLIT != 0) {
            const parent_lock = u.parent.?.lock.?;
            if (!u.is_symref or !util.eql(u.parent.?.refname, referent)) {
                self.setErr("HEAD has been racily updated", .{});
                return .generic;
            }
            if (u.flags & F_HAVE_OLD != 0) {
                lock.old_oid = u.old_oid;
            } else lock.old_oid = parent_lock.old_oid;
        } else if (u.is_symref) {
            if (u.flags & F_NO_DEREF != 0) {
                const rr = resolveFull(referent, true);
                if (rr.broken) {
                    lock.old_oid = hash.zero;
                    if (u.flags & F_HAVE_OLD != 0 and !rr.missing) {
                        self.setErr("cannot lock ref '{s}': error reading reference", .{u.originalName()});
                        return .generic;
                    }
                } else lock.old_oid = rr.oid;
                if (u.old_target) |ot| {
                    const e = checkOldTarget(self, referent, u, ot);
                    if (e != .ok) return e;
                } else {
                    const e = self.checkOldOid(u, lock.old_oid, referent);
                    if (e != .ok) return e;
                }
            } else {
                // split symref update
                if (self.hasRefname(referent)) {
                    self.setErr("multiple updates for '{s}' (including one via symref '{s}') are not allowed", .{ referent, u.refname });
                    return .name_conflict;
                }
                var nf = u.flags;
                if (util.eql(u.refname, "HEAD")) nf |= F_UPDATE_VIA_HEAD;
                const nu = self.addUpdate(.{
                    .refname = referent,
                    .flags = nf,
                    .new_oid = u.new_oid,
                    .old_oid = u.old_oid,
                    .new_target = u.new_target,
                    .old_target = u.old_target,
                    .msg = u.msg,
                });
                nu.parent = u;
                u.flags |= F_LOG_ONLY | F_NO_DEREF;
                u.flags &= ~F_HAVE_OLD;
            }
        } else {
            if (u.old_target) |ot| {
                self.setErr("cannot lock ref '{s}': expected symref with target '{s}': but is a regular ref", .{ u.originalName(), ot });
                return .expected_symref;
            }
            const e = self.checkOldOid(u, lock.old_oid, referent);
            if (e != .ok) return e;
            var p = u.parent;
            while (p) |pu| : (p = pu.parent) {
                if (pu.lock) |pl| pl.old_oid = lock.old_oid;
            }
        }

        if (u.new_target != null and u.flags & F_LOG_ONLY == 0) {
            // write symref to lock file
            if (lock.lk) |lk| {
                lk.write(util.concat(&.{ "ref: ", u.new_target.?, "\n" }));
            }
            u.flags |= F_NEEDS_COMMIT;
        } else if (u.flags & F_HAVE_NEW != 0 and u.flags & F_DELETING == 0 and u.flags & F_LOG_ONLY == 0) {
            if (!u.is_symref and hash.eql(lock.old_oid, u.new_oid)) {
                // already has desired value
            } else {
                if (u.flags & F_SKIP_OID_VERIFICATION == 0) {
                    const t = repo_mod.repo().odb().readType(u.new_oid) orelse {
                        self.setErr("trying to write ref '{s}' with nonexistent object {s}", .{ lock.name, hash.hex(u.new_oid) });
                        return .invalid_new_value;
                    };
                    if (t != .commit and (util.eql(lock.name, "HEAD") or util.startsWith(lock.name, "refs/heads/"))) {
                        self.setErr("trying to write non-commit object {s} to branch '{s}'", .{ hash.hex(u.new_oid), lock.name });
                        return .invalid_new_value;
                    }
                }
                if (lock.lk) |lk| lk.write(util.concat(&.{ &hash.hex(u.new_oid), "\n" }));
                u.flags |= F_NEEDS_COMMIT;
            }
        }
        return .ok;
    }

    const LockResult = union(enum) { ok: *RefLock, err: TxErr };

    fn lockRawRef(self: *Transaction, u: *Update, mustexist: bool, to_check: *std.ArrayList(*Update), referent: *[]const u8) LockResult {
        const refname = u.refname;
        const path = refPath(refname);
        self.err.clearRetainingCapacity();
        if (!os.mkdirLeading(path)) {
            // D/F conflict: a file in the way
            var extras: std.ArrayList([]const u8) = .empty;
            for (self.updates.items) |x| {
                if (x.flags & F_LOG_ONLY == 0 and x.rejection == .ok) extras.append(gpa, x.refname) catch util.oom();
            }
            if (verifyAvailable(refname, extras.items, &.{}, .all, &self.err)) |_| {
                if (mustexist) {
                    self.setErr("unable to resolve reference '{s}'", .{refname});
                    return .{ .err = .nonexistent_ref };
                }
                return .{ .err = .name_conflict };
            }
            self.setErr("unable to create lock file {s}.lock; non-directory in the way", .{path});
            return .{ .err = .generic };
        }
        const lk = switch (lockfile.tryLock(path)) {
            .ok => |l| l,
            .err => |e| {
                self.err.clearRetainingCapacity();
                util.bufAppend(&self.err, lockfile.lockMessage(path, e));
                if (e == os.EEXIST) return .{ .err = .create_exists };
                if (e == os.EISDIR) {
                    // directory named like the lock? treat as generic
                }
                return .{ .err = .generic };
            },
        };
        const lock = gpa.create(RefLock) catch util.oom();
        lock.* = .{ .name = refname, .lk = lk };
        u.is_packed = false;
        switch (readRawFull(refname)) {
            .oid => |o| {
                lock.old_oid = o;
                if (os.lstatPath(path) == null) u.is_packed = true;
            },
            .symref => |t| {
                u.is_symref = true;
                referent.* = t;
            },
            .missing => {
                if (mustexist) {
                    self.setErr("unable to resolve reference '{s}'", .{refname});
                    lk.rollback();
                    return .{ .err = .nonexistent_ref };
                }
                to_check.append(gpa, u) catch util.oom();
            },
            .isdir => {
                if (mustexist) {
                    self.setErr("unable to resolve reference '{s}'", .{refname});
                    lk.rollback();
                    return .{ .err = .nonexistent_ref };
                }
                if (!removeEmptyDirs(path)) {
                    var extras: std.ArrayList([]const u8) = .empty;
                    for (self.updates.items) |x| {
                        if (x.flags & F_LOG_ONLY == 0 and x.rejection == .ok) extras.append(gpa, x.refname) catch util.oom();
                    }
                    if (verifyAvailable(refname, extras.items, &.{}, .all, &self.err) == null) {
                        self.setErr("there is a non-empty directory '{s}' blocking reference '{s}'", .{ path, refname });
                    }
                    lk.rollback();
                    return .{ .err = .name_conflict };
                }
                to_check.append(gpa, u) catch util.oom();
            },
            .broken => {
                self.setErr("unable to resolve reference '{s}': reference broken", .{refname});
                lk.rollback();
                return .{ .err = .generic };
            },
        }
        return .{ .ok = lock };
    }

    fn checkOldOid(self: *Transaction, u: *Update, oid: Oid, referent: []const u8) TxErr {
        if (u.flags & F_LOG_ONLY != 0 or u.flags & F_HAVE_OLD == 0) return .ok;
        if (hash.eql(oid, u.old_oid)) {
            if (u.flags & F_NO_DEREF != 0 and referent.len > 0 and hash.isZero(oid)) {
                self.setErr("cannot lock ref '{s}': dangling symref already exists", .{u.originalName()});
                return .create_exists;
            }
            return .ok;
        }
        if (hash.isZero(u.old_oid)) {
            self.setErr("cannot lock ref '{s}': reference already exists", .{u.originalName()});
            return .create_exists;
        } else if (hash.isZero(oid)) {
            self.setErr("cannot lock ref '{s}': reference is missing but expected {s}", .{ u.originalName(), hash.hex(u.old_oid) });
            return .nonexistent_ref;
        }
        self.setErr("cannot lock ref '{s}': is at {s} but expected {s}", .{ u.originalName(), hash.hex(oid), hash.hex(u.old_oid) });
        return .incorrect_old_value;
    }

    pub fn commit(self: *Transaction) TxErr {
        if (self.state == .open) {
            const e = self.prepare();
            if (e != .ok) return e;
        }
        const e = self.finish();
        if (e == .ok) _ = runHook(self, "committed");
        return e;
    }

    fn finish(self: *Transaction) TxErr {
        defer self.state = .closed;
        if (isReftable()) return rtb.finish(self);
        if (self.updates.items.len == 0) return .ok;
        // updates first
        for (self.updates.items) |u| {
            if (u.rejection != .ok) continue;
            const lock = u.lock orelse continue;
            if (u.flags & F_NEEDS_COMMIT != 0 or u.flags & F_LOG_ONLY != 0) {
                var new = u.new_oid;
                var skip = false;
                if (u.new_target) |nt| {
                    const rr = resolveFull(nt, true);
                    if (rr.broken) skip = true else new = rr.oid;
                }
                if (!skip and u.flags & F_SKIP_CREATE_REFLOG == 0) {
                    if (u.flags & F_DELETING != 0 and u.flags & F_LOG_ONLY == 0) {
                        // reflog will be deleted anyway
                    } else if (logRefWrite(lock.name, lock.old_oid, new, u.committer, u.msg, u.flags & F_FORCE_CREATE_REFLOG != 0)) |m| {
                        self.setErr("cannot update the ref '{s}': {s}", .{ lock.name, m });
                        self.cleanup();
                        return .generic;
                    }
                }
            }
            if (u.flags & F_NEEDS_COMMIT != 0) {
                if (lock.lk) |lk| {
                    if (!lk.commit()) {
                        self.setErr("couldn't set '{s}'", .{lock.name});
                        self.cleanup();
                        return .generic;
                    }
                    lock.lk = null;
                }
            }
        }
        // delete reflogs of deleted refs
        for (self.updates.items) |u| {
            if (u.rejection != .ok) continue;
            if (u.flags & F_DELETING != 0 and u.flags & F_LOG_ONLY == 0 and u.flags & F_IS_PRUNING == 0) {
                const lp = logPath(u.refname);
                if (os.unlink(lp)) {
                    removeRefParents(lp, u.refname);
                }
            }
        }
        // packed deletes
        if (self.packed_lock) |pl| {
            var keep: std.ArrayList(PackedRef) = .empty;
            var changed = false;
            for (packedRefs()) |p| {
                var del = false;
                for (self.updates.items) |u| {
                    if (u.rejection != .ok) continue;
                    if (u.flags & F_DELETING != 0 and u.flags & F_LOG_ONLY == 0 and u.flags & F_IS_PRUNING == 0 and util.eql(u.refname, p.name)) del = true;
                }
                if (del) {
                    changed = true;
                } else keep.append(gpa, p) catch util.oom();
            }
            if (changed) {
                pl.write(formatPacked(keep.items));
                if (!pl.commit()) {
                    self.setErr("unable to overwrite old ref-pack file", .{});
                    self.cleanup();
                    return .generic;
                }
                invalidatePacked();
            } else pl.rollback();
            self.packed_lock = null;
        }
        // delete loose refs
        for (self.updates.items) |u| {
            if (u.rejection != .ok) continue;
            if (u.flags & F_DELETING != 0 and u.flags & F_LOG_ONLY == 0) {
                u.flags |= F_DELETED_RMDIR;
                if (!u.is_packed or u.is_symref) {
                    const p = refPath(if (u.lock) |l| l.name else u.refname);
                    if (!os.unlink(p)) {
                        const e = os.errno();
                        if (e != os.ENOENT) {
                            self.setErr("unable to unlink '{s}': {s}", .{ p, os.strErr(e) });
                            self.cleanup();
                            return .generic;
                        }
                    }
                }
            }
        }
        self.cleanup();
        for (self.updates.items) |u| {
            if (u.flags & F_DELETED_RMDIR != 0) {
                removeRefParents(refPath(u.refname), u.refname);
            }
        }
        return .ok;
    }

    fn cleanup(self: *Transaction) void {
        if (self.rt_data != null) rtb.abort(self);
        for (self.updates.items) |u| {
            if (u.lock) |l| {
                if (l.lk) |lk| {
                    lk.rollback();
                    l.lk = null;
                    // try remove empty parents of the ref (created by us)
                    removeRefParents(refPath(u.refname), u.refname);
                }
            }
        }
        if (self.packed_lock) |pl| {
            pl.rollback();
            self.packed_lock = null;
        }
        self.state = .closed;
    }

    pub fn abort(self: *Transaction) void {
        if (self.state == .prepared) self.cleanup();
        _ = runHook(self, "aborted");
        self.state = .closed;
    }

    pub fn rejected(self: *Transaction) []const *Update {
        var l: std.ArrayList(*Update) = .empty;
        for (self.updates.items) |u| {
            if (u.rejection != .ok) l.append(gpa, u) catch util.oom();
        }
        return l.items;
    }
};

fn checkOldTarget(t: *Transaction, referent: []const u8, u: *Update, ot: []const u8) TxErr {
    if (util.eql(referent, ot)) return .ok;
    if (referent.len == 0) {
        t.setErr("verifying symref target: '{s}': reference is missing but expected {s}", .{ u.originalName(), ot });
        return .nonexistent_ref;
    }
    t.setErr("verifying symref target: '{s}': is at {s} but expected {s}", .{ u.originalName(), referent, ot });
    return .incorrect_old_value;
}

/// Extension for Update used in lockRefForUpdate.
fn isPackedOnlyValue(u: *const Update) bool {
    _ = u;
    return false;
}

fn removeEmptyDirs(path: []const u8) bool {
    const st = os.lstatPath(path) orelse return true;
    if (!st.isDir()) return false;
    if (os.listDir(path)) |ents| {
        for (ents) |e| {
            if (!removeEmptyDirs(util.concat(&.{ path, "/", e.name }))) return false;
        }
    }
    return os.rmdir(path);
}

pub const AvailScope = enum { all, packed_only };

fn refExistsIn(name: []const u8, scope: AvailScope) bool {
    if (isReftable()) return switch (readRawFull(name)) {
        .oid, .symref => true,
        else => false,
    };
    if (scope == .packed_only) return findPacked(name) != null;
    return switch (readRawFull(name)) {
        .oid, .symref, .broken => true,
        else => false,
    };
}

fn refsUnder(dir: []const u8, scope: AvailScope) []const []const u8 {
    if (isReftable()) return rtb.namesUnder(dir);
    var out: std.ArrayList([]const u8) = .empty;
    if (scope == .all) {
        for (looseNames()) |n| {
            if (util.startsWith(n, dir)) out.append(gpa, n) catch util.oom();
        }
    }
    for (packedRefs()) |p| {
        if (util.startsWith(p.name, dir)) out.append(gpa, p.name) catch util.oom();
    }
    util.sortStrings(out.items);
    return out.items;
}

fn inList(l: []const []const u8, s: []const u8) bool {
    for (l) |x| {
        if (util.eql(x, s)) return true;
    }
    return false;
}

/// refs_verify_refname_available: returns error kind and writes message to err.
pub fn verifyAvailable(refname: []const u8, extras: []const []const u8, skip: []const []const u8, scope: AvailScope, err: *util.Buf) ?TxErr {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, refname, i, '/')) |sl| {
        const dir = refname[0..sl];
        i = sl + 1;
        if (inList(skip, dir)) continue;
        if (refExistsIn(dir, scope)) {
            err.clearRetainingCapacity();
            util.bufPrint(err, "'{s}' exists; cannot create '{s}'", .{ dir, refname });
            return .name_conflict;
        }
        if (inList(extras, dir)) {
            err.clearRetainingCapacity();
            util.bufPrint(err, "cannot process '{s}' and '{s}' at the same time", .{ refname, dir });
            return .name_conflict;
        }
    }
    const dirname = util.concat(&.{ refname, "/" });
    for (refsUnder(dirname, scope)) |n| {
        if (inList(skip, n)) continue;
        err.clearRetainingCapacity();
        util.bufPrint(err, "'{s}' exists; cannot create '{s}'", .{ n, refname });
        return .name_conflict;
    }
    // descendant in extras
    var best: ?[]const u8 = null;
    for (extras) |x| {
        if (util.startsWith(x, dirname) and !inList(skip, x)) {
            if (best == null or std.mem.order(u8, x, best.?) == .lt) best = x;
        }
    }
    if (best) |b| {
        err.clearRetainingCapacity();
        util.bufPrint(err, "cannot process '{s}' and '{s}' at the same time", .{ refname, b });
        return .name_conflict;
    }
    return null;
}

// reference-transaction hook
fn runHook(t: *Transaction, state: []const u8) u8 {
    const r = repo_mod.repo();
    const hooks_dir = repo_mod.cfg.getPath("core.hookspath") orelse r.commonPath("hooks");
    const hook = util.concat(&.{ hooks_dir, "/reference-transaction" });
    if (!os.access(hook, 1)) return 0;
    var b: util.Buf = .empty;
    for (t.updates.items) |u| {
        if (u.flags & F_LOG_ONLY != 0) continue;
        if (u.flags & F_HAVE_OLD == 0) {
            util.bufPrint(&b, "{s} ", .{hash.zero_hex});
        } else if (u.old_target) |ot| {
            util.bufPrint(&b, "ref:{s} ", .{ot});
        } else util.bufPrint(&b, "{s} ", .{hash.hex(u.old_oid)});
        if (u.flags & F_HAVE_NEW == 0) {
            util.bufPrint(&b, "{s} ", .{hash.zero_hex});
        } else if (u.new_target) |nt| {
            util.bufPrint(&b, "ref:{s} ", .{nt});
        } else util.bufPrint(&b, "{s} ", .{hash.hex(u.new_oid)});
        util.bufPrint(&b, "{s}\n", .{u.refname});
    }
    const res = os.run(&.{ hook, state }, .{ .stdin_data = b.items, .stdout_to_stderr = true });
    return res.status;
}

// ---------------- simple write API ----------------

pub const UpdateError = error{ LockFailed, Mismatch, WriteFailed, BadName, DirConflict };

pub var last_error: []const u8 = "";

fn txToError(e: TxErr) UpdateError {
    return switch (e) {
        .name_conflict => error.DirConflict,
        .create_exists, .nonexistent_ref, .incorrect_old_value, .expected_symref => error.Mismatch,
        .invalid_new_value => error.BadName,
        else => error.LockFailed,
    };
}

/// Update a ref (following symrefs unless no_deref). old: null = don't check;
/// zero = must not exist. On error, last_error holds git's message.
pub fn update(name: []const u8, new: Oid, old: ?Oid, msg: []const u8, no_deref: bool) UpdateError!void {
    return updateFlags(name, new, old, msg, if (no_deref) F_NO_DEREF else 0);
}

pub fn updateFlags(name: []const u8, new: Oid, old: ?Oid, msg: []const u8, flags: u32) UpdateError!void {
    const t = Transaction.init();
    var e = t.update(name, new, old, null, null, flags, msg);
    if (e == .ok) e = t.commit();
    if (e != .ok) {
        last_error = util.dupe(t.err.items);
        return txToError(e);
    }
}

/// update_ref with UPDATE_REFS_DIE_ON_ERR semantics.
pub fn updateOrDie(msg: []const u8, name: []const u8, new: Oid, old: ?Oid, flags: u32) void {
    updateFlags(name, new, old, msg, flags) catch {
        util.die("update_ref failed for ref '{s}': {s}", .{ name, last_error });
    };
}

/// Write a ref without reflog or checks.
pub fn writeRef(name: []const u8, new: Oid) UpdateError!void {
    return updateFlags(name, new, null, "", F_NO_DEREF | F_SKIP_CREATE_REFLOG | F_SKIP_OID_VERIFICATION);
}

/// Check whether creating `name` conflicts with an existing ref (prefix or child).
pub fn checkDirConflict(name: []const u8) ?[]const u8 {
    var i: usize = 0;
    while (std.mem.indexOfScalarPos(u8, name, i, '/')) |sl| {
        const pre = name[0..sl];
        if (refExistsIn(pre, .all)) return pre;
        i = sl + 1;
    }
    const under = refsUnder(util.concat(&.{ name, "/" }), .all);
    if (under.len > 0) return under[0];
    return null;
}

/// refs_update_symref: point `name` at `target`. msg null = no message (still logs).
pub fn writeSymref(name: []const u8, target: []const u8, msg: ?[]const u8) !void {
    const t = Transaction.init();
    var e = t.update(name, null, null, target, null, F_NO_DEREF, msg);
    if (e == .ok) e = t.commit();
    if (e != .ok) {
        last_error = util.dupe(t.err.items);
        return error.LockFailed;
    }
}

/// Update HEAD of the linked worktree `id` (refs_update_symref() /
/// refs_update_ref() on get_worktree_ref_store()). `target` null: detach to
/// `oid`.
pub fn writeWorktreeHead(id: ?[]const u8, target: ?[]const u8, oid: Oid, msg: ?[]const u8) !void {
    const name = if (id) |i| util.concat(&.{ "worktrees/", i, "/HEAD" }) else "main-worktree/HEAD";
    const t = Transaction.init();
    const fl = F_NO_DEREF | F_SKIP_REFNAME_VERIFICATION;
    var e = if (target) |tg| t.update(name, null, null, tg, null, fl, msg) else t.update(name, oid, null, null, null, fl, msg);
    if (e == .ok) e = t.commit();
    if (e != .ok) {
        last_error = util.dupe(t.err.items);
        return error.LockFailed;
    }
}

/// Delete a ref. old: optional expected value (zero = don't care).
pub fn delete(name: []const u8, old: ?Oid, no_deref: bool) UpdateError!void {
    return deleteRef(name, old, if (no_deref) F_NO_DEREF else 0, null);
}

pub fn deleteRef(name: []const u8, old: ?Oid, flags: u32, msg: ?[]const u8) UpdateError!void {
    const t = Transaction.init();
    const o: ?Oid = if (old != null and !hash.isZero(old.?)) old else null;
    var e = t.delete(name, o, null, flags, msg);
    if (e == .ok) e = t.commit();
    if (e != .ok) {
        last_error = util.dupe(t.err.items);
        return txToError(e);
    }
}

/// refs_delete_refs: delete several refs; prints errors like git. Returns true on success.
pub fn deleteRefs(names: []const []const u8, flags: u32, msg: ?[]const u8) bool {
    if (names.len == 0) return true;
    const t = Transaction.init();
    var failed = false;
    for (names) |n| {
        const e = t.delete(n, null, null, flags, msg);
        if (e != .ok) {
            util.warn("could not delete reference {s}: {s}", .{ n, t.err.items });
            failed = true;
        }
    }
    const e = t.commit();
    if (e != .ok) {
        if (names.len == 1) {
            util.err("could not delete reference {s}: {s}", .{ names[0], t.err.items });
        } else util.err("could not delete references: {s}", .{t.err.items});
        return false;
    }
    return !failed;
}

/// Rename or copy a ref (files_copy_or_rename_ref). Returns true on success; errors printed.
pub fn renameRef(oldname: []const u8, newname: []const u8, logmsg: []const u8, copy: bool) bool {
    if (isReftable()) return rtb.renameRef(oldname, newname, logmsg, copy);
    const old_log = logPath(oldname);
    const tmp_log = repo_mod.repo().commonPath("logs/refs/.tmp-renamed-log");
    var log = false;
    if (os.lstatPath(old_log)) |st| {
        log = true;
        if (st.isLnk()) {
            util.err("reflog for {s} is a symlink", .{oldname});
            return false;
        }
    }
    const raw = readRawFull(oldname);
    const orig_oid = switch (raw) {
        .oid => |o| o,
        .symref => {
            if (copy) {
                util.err("refname {s} is a symbolic ref, copying it is not supported", .{oldname});
            } else util.err("refname {s} is a symbolic ref, renaming it is not supported", .{oldname});
            return false;
        },
        else => {
            util.err("refname {s} not found", .{oldname});
            return false;
        },
    };
    var err: util.Buf = .empty;
    if (verifyAvailable(newname, &.{}, &.{oldname}, .all, &err) != null) {
        util.err("{s}", .{err.items});
        return false;
    }
    if (log) {
        _ = os.mkdirLeading(tmp_log);
        if (copy) {
            const data = os.readFile(old_log) orelse "";
            os.writeFile(tmp_log, data, 0o644) catch {
                util.err("unable to copy logfile logs/{s} to logs/refs/.tmp-renamed-log: {s}", .{ oldname, os.lastErr() });
                return false;
            };
        } else if (!os.rename(old_log, tmp_log)) {
            util.err("unable to move logfile logs/{s} to logs/refs/.tmp-renamed-log: {s}", .{ oldname, os.lastErr() });
            return false;
        }
    }
    var logmoved = false;
    var ok = true;
    blk: {
        if (!copy) {
            deleteRef(oldname, orig_oid, F_NO_DEREF, logmsg) catch {
                util.err("{s}", .{last_error});
                util.err("unable to delete old {s}", .{oldname});
                ok = false;
                break :blk;
            };
        }
        if (!copy) {
            switch (readRawFull(newname)) {
                .oid, .symref => {
                    deleteRef(newname, null, F_NO_DEREF, null) catch {
                        util.err("unable to delete existing {s}", .{newname});
                        ok = false;
                        break :blk;
                    };
                },
                .isdir => {
                    if (!removeEmptyDirs(refPath(newname))) {
                        util.err("Directory not empty: {s}", .{newname});
                        ok = false;
                        break :blk;
                    }
                },
                else => {},
            }
        }
        if (log) {
            const nl = logPath(newname);
            // remove empty directories in the way
            if (os.lstatPath(nl)) |st| {
                if (st.isDir()) _ = removeEmptyDirs(nl);
            }
            if (!os.mkdirLeading(nl) or !os.rename(tmp_log, nl)) {
                util.err("unable to move logfile logs/refs/.tmp-renamed-log to logs/{s}: {s}", .{ newname, os.lastErr() });
                ok = false;
                break :blk;
            }
        }
        logmoved = log;
        // write the new ref + reflog (commit_ref_update)
        const path = refPath(newname);
        if (!os.mkdirLeading(path)) {
            if (copy) {
                util.err("unable to copy '{s}' to '{s}': unable to create directory for {s}", .{ oldname, newname, path });
            } else util.err("unable to rename '{s}' to '{s}': unable to create directory for {s}", .{ oldname, newname, path });
            ok = false;
            break :blk;
        }
        const lk = switch (lockfile.tryLock(path)) {
            .ok => |l| l,
            .err => |e| {
                if (copy) {
                    util.err("unable to copy '{s}' to '{s}': {s}", .{ oldname, newname, lockfile.lockMessage(path, e) });
                } else util.err("unable to rename '{s}' to '{s}': {s}", .{ oldname, newname, lockfile.lockMessage(path, e) });
                ok = false;
                break :blk;
            },
        };
        lk.write(util.concat(&.{ &hash.hex(orig_oid), "\n" }));
        if (logRefWrite(newname, orig_oid, orig_oid, null, normalizeReflogMsg(logmsg), false)) |m| {
            util.err("unable to write current sha1 into {s}: {s}", .{ newname, m });
            lk.rollback();
            ok = false;
            break :blk;
        }
        if (headSymref()) |h| {
            // commit_ref_update(): HEAD is resolved for reading before the
            // new ref is committed, so it is only logged when it exists.
            if (util.eql(h, newname) and !util.eql(newname, "HEAD")) {
                if (resolve(newname)) |cur| {
                    _ = logRefWrite("HEAD", cur.oid, orig_oid, null, normalizeReflogMsg(logmsg), false);
                }
            }
        }
        if (!lk.commit()) {
            util.err("unable to write current sha1 into {s}: couldn't set '{s}'", .{ newname, newname });
            ok = false;
            break :blk;
        }
    }
    if (ok) return true;
    // rollback
    if (!copy) {
        const path = refPath(oldname);
        _ = os.mkdirLeading(path);
        os.writeFile(path, util.concat(&.{ &hash.hex(orig_oid), "\n" }), 0o666) catch {
            util.err("unable to write current sha1 into {s}", .{oldname});
        };
    }
    if (logmoved) {
        _ = os.rename(logPath(newname), old_log);
    } else if (log and !copy) {
        _ = os.rename(tmp_log, old_log);
    }
    return false;
}

// ---------------- pack-refs ----------------

pub const PackOpts = struct {
    includes: []const []const u8 = &.{"refs/tags/*"},
    excludes: []const []const u8 = &.{},
    prune: bool = true,
    auto: bool = false,
};

fn packMatches(opts: PackOpts, n: []const u8) bool {
    const wildmatch = @import("wildmatch.zig");
    for (opts.excludes) |x| {
        if (wildmatch.match(x, n, 0)) return false;
    }
    for (opts.includes) |x| {
        if (wildmatch.match(x, n, 0)) return true;
    }
    return false;
}

/// Whether `pack-refs --auto` would pack (used by maintenance is-needed).
pub fn packRefsRequired(opts: PackOpts) bool {
    if (isReftable()) return rtb.optimizeRequired(opts.auto);
    return shouldPackRefs(opts);
}

fn shouldPackRefs(opts: PackOpts) bool {
    if (!opts.auto) return true;
    const st = os.statPath(repo_mod.repo().commonPath("packed-refs"));
    const size: u64 = if (st) |s| @intCast(s.size) else 0;
    var limit: u64 = 0;
    const q = size / 100;
    if (q > 0) limit = @as(u64, std.math.log2_int(u64, q)) * 5;
    // git's log2u(0) is 0
    if (limit < 16) limit = 16;
    var count: u64 = 0;
    for (looseNames()) |n| {
        if (isPerWorktree(n)) continue;
        switch (readRawFullOpt(n, false)) {
            .oid => {},
            else => continue,
        }
        if (!packMatches(opts, n)) continue;
        count += 1;
        if (count >= limit) return true;
    }
    return false;
}

pub fn packRefs(opts: PackOpts) bool {
    if (isReftable()) return rtb.optimize(opts.auto);
    const wildmatch = @import("wildmatch.zig");
    const r = repo_mod.repo();
    const path = r.commonPath("packed-refs");
    if (!shouldPackRefs(opts)) return true;
    const lk = lockfile.lockOrDie(path);
    invalidatePacked();
    var entries: std.ArrayList(PackedRef) = .empty;
    var map = std.StringHashMap(usize).init(gpa);
    for (packedRefs()) |p| {
        map.put(p.name, entries.items.len) catch util.oom();
        entries.append(gpa, p) catch util.oom();
    }
    var to_prune: std.ArrayList(Ref) = .empty;
    const odb = r.odb();
    for (looseNames()) |n| {
        if (isPerWorktree(n)) continue;
        const raw = readRawFullOpt(n, false);
        const oid = switch (raw) {
            .oid => |o| o,
            else => continue,
        };
        if (!checkRefnameFormat(n, ALLOW_ONELEVEL)) continue;
        if (!odb.has(oid)) {
            util.err("{s} does not point to a valid object!", .{n});
            continue;
        }
        var excluded = false;
        for (opts.excludes) |x| {
            if (wildmatch.match(x, n, 0)) excluded = true;
        }
        if (excluded) continue;
        var included = false;
        for (opts.includes) |x| {
            if (wildmatch.match(x, n, 0)) included = true;
        }
        if (!included) continue;
        const pe = peeledOf(oid);
        if (map.get(n)) |idx| {
            entries.items[idx] = .{ .name = n, .oid = oid, .peeled = pe };
        } else {
            map.put(n, entries.items.len) catch util.oom();
            entries.append(gpa, .{ .name = n, .oid = oid, .peeled = pe }) catch util.oom();
        }
        if (opts.prune) to_prune.append(gpa, .{ .name = n, .oid = oid }) catch util.oom();
    }
    // make sure all peeled values are filled in (fully-peeled)
    for (entries.items) |*e| {
        if (e.peeled == null) e.peeled = peeledOf(e.oid);
    }
    std.mem.sort(PackedRef, entries.items, {}, struct {
        fn lt(_: void, a: PackedRef, b: PackedRef) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    lk.write(formatPacked(entries.items));
    if (!lk.commit()) util.die("unable to overwrite old ref-pack file", .{});
    invalidatePacked();
    // prune loose refs
    for (to_prune.items) |p| {
        const rp = refPath(p.name);
        switch (lockfile.tryLock(rp)) {
            .ok => |l| {
                switch (readRawFullOpt(p.name, false)) {
                    .oid => |o| {
                        if (hash.eql(o, p.oid)) {
                            _ = os.unlink(rp);
                        }
                    },
                    else => {},
                }
                l.rollback();
                removeRefParents(rp, p.name);
            },
            .err => {},
        }
    }
    return true;
}

// ---------------- shortening ----------------

/// Shorten a ref name for display (refs/heads/x -> x), like shorten_unambiguous_ref.
pub fn shorten(name: []const u8) []const u8 {
    if (util.skipPrefix(name, "refs/heads/")) |s| return s;
    if (util.skipPrefix(name, "refs/tags/")) |s| return s;
    if (util.skipPrefix(name, "refs/remotes/")) |s| {
        if (util.endsWith(s, "/HEAD")) return s[0 .. s.len - 5];
        return s;
    }
    if (util.skipPrefix(name, "refs/")) |s| return s;
    return name;
}

/// shorten_unambiguous_ref (strict = core.warnAmbiguousRefs semantics).
pub fn shortenUnambiguous(name: []const u8) []const u8 {
    return shortenUnambiguousStrict(name, true);
}

pub fn shortenUnambiguousStrict(name: []const u8, strict: bool) []const u8 {
    const rules = [_][2][]const u8{
        .{ "", "" },
        .{ "refs/", "" },
        .{ "refs/tags/", "" },
        .{ "refs/heads/", "" },
        .{ "refs/remotes/", "" },
        .{ "refs/remotes/", "/HEAD" },
    };
    var i: usize = rules.len;
    while (i > 0) {
        i -= 1;
        const pre = rules[i][0];
        const suf = rules[i][1];
        if (!util.startsWith(name, pre) or !util.endsWith(name, suf)) continue;
        if (name.len <= pre.len + suf.len) continue;
        const short = name[pre.len .. name.len - suf.len];
        if (i == 0) return name;
        var ambiguous = false;
        var j: usize = 0;
        const rules_to_fail = if (strict) rules.len else i;
        while (j < rules_to_fail) : (j += 1) {
            if (j == i) continue;
            const cand = util.concat(&.{ rules[j][0], short, rules[j][1] });
            if (readRaw(cand) != null) {
                ambiguous = true;
                break;
            }
        }
        if (!ambiguous) return short;
    }
    return name;
}

/// try_remove_empty_parents: remove empty parent directories of a ref (or
/// reflog) file, keeping the first two components ("refs/heads").
pub fn removeRefParents(path: []const u8, refname: []const u8) void {
    if (!util.endsWith(path, refname)) return;
    var p: usize = 0;
    var i: usize = 0;
    while (i < 2) : (i += 1) {
        while (p < refname.len and refname[p] != '/') p += 1;
        while (p < refname.len and refname[p] == '/') p += 1;
    }
    if (p >= refname.len) return;
    const base = path.len - refname.len;
    os.removeEmptyParents(path, base + p - 1);
}
