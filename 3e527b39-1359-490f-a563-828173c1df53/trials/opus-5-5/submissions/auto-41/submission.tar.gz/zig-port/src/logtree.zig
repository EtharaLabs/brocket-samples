//! Log output of a single commit (port of log-tree.c).

const std = @import("std");
const util = @import("util.zig");
const cn = @import("commitnode.zig");
const hash = @import("hash.zig");
const refs = @import("refs.zig");
const revparse = @import("revparse.zig");
const repo_mod = @import("repo.zig");
const color_mod = @import("color.zig");
const wildmatch = @import("wildmatch.zig");
const graph_mod = @import("graph.zig");
const reflogwalk = @import("reflogwalk.zig");
const pretty = @import("pretty.zig");
const objects = @import("objects.zig");
const revision = @import("revision.zig");
const ident_mod = @import("ident.zig");
const RevInfo = revision.RevInfo;
const Commit = cn.Commit;
const Obj = cn.Obj;
const gpa = util.gpa;

pub const DecorationOptions = struct {
    prefix: ?[]const u8 = null,
    suffix: ?[]const u8 = null,
    separator: ?[]const u8 = null,
    pointer: ?[]const u8 = null,
    tag: ?[]const u8 = null,
};

pub const DecorationType = enum(u8) { none = 0, ref_local, ref_remote, ref_tag, ref_stash, ref_head, grafted };

pub const NameDecoration = struct {
    next: ?*NameDecoration,
    typ: DecorationType,
    name: []const u8,
};

pub const DECORATE_SHORT_REFS: i32 = 1;
pub const DECORATE_FULL_REFS: i32 = 2;

/// Pattern list item: `exact` set when the pattern has no glob specials
/// (then prefix matching on '/' boundaries is used).
pub const RefPattern = struct {
    pattern: []const u8,
    exact: bool,
};

pub const DecorationFilter = struct {
    include_ref_pattern: std.ArrayList([]const u8) = .empty,
    exclude_ref_pattern: std.ArrayList([]const u8) = .empty,
    exclude_ref_config_pattern: std.ArrayList([]const u8) = .empty,
};

var name_decoration: hash.OidMap(*NameDecoration) = .empty;
var decoration_loaded = false;
var decoration_flags: i32 = 0;

var decoration_colors = [_][]const u8{
    color_mod.RESET,
    color_mod.BOLD_GREEN,
    color_mod.BOLD_RED,
    color_mod.BOLD_YELLOW,
    color_mod.BOLD_MAGENTA,
    color_mod.BOLD_CYAN,
    color_mod.BOLD_BLUE,
};
const color_decorate_slots = [_][]const u8{ "", "branch", "remoteBranch", "tag", "stash", "HEAD", "grafted" };
var colors_configured = false;

fn configureColors() void {
    if (colors_configured) return;
    colors_configured = true;
    for (color_decorate_slots, 0..) |slot, i| {
        if (i == 0) continue;
        var key: util.Buf = .empty;
        util.bufAppend(&key, "color.decorate.");
        for (slot) |ch| util.bufByte(&key, std.ascii.toLower(ch));
        if (repo_mod.cfg.get(key.items)) |v| {
            if (color_mod.parseColor(v)) |c| decoration_colors[i] = c;
        }
    }
}

/// parse_decorate_color_config: returns true if slot recognized
pub fn parseDecorateColorConfig(slot_name: []const u8, value: []const u8) bool {
    for (color_decorate_slots, 0..) |slot, i| {
        if (i == 0) continue;
        if (std.ascii.eqlIgnoreCase(slot, slot_name)) {
            if (color_mod.parseColor(value)) |c| decoration_colors[i] = c;
            return true;
        }
    }
    return false;
}

fn decorateGetColor(use_color: bool, ix: DecorationType) []const u8 {
    if (!use_color) return "";
    configureColors();
    return decoration_colors[@intFromEnum(ix)];
}

pub fn addNameDecoration(typ: DecorationType, name: []const u8, obj: *Obj) void {
    const res = gpa.create(NameDecoration) catch util.oom();
    const gop = name_decoration.getOrPut(gpa, obj.oid) catch util.oom();
    res.* = .{ .next = if (gop.found_existing) gop.value_ptr.* else null, .typ = typ, .name = util.dupe(name) };
    gop.value_ptr.* = res;
}

pub fn getNameDecoration(obj: *const Obj) ?*NameDecoration {
    loadRefDecorations(null, DECORATE_SHORT_REFS);
    return name_decoration.get(obj.oid);
}

/// used by --simplify-by-decoration
pub fn hasNameDecoration(obj: *const Obj) bool {
    return getNameDecoration(obj) != null;
}

fn matchRefPattern(refname: []const u8, pat: []const u8) bool {
    if (wildmatch.hasGlobChars(pat)) {
        return wildmatch.match(pat, refname, 0);
    }
    const rest = util.skipPrefix(refname, pat) orelse return false;
    return rest.len == 0 or rest[0] == '/';
}

fn refFilterMatch(refname: []const u8, f: *const DecorationFilter) bool {
    for (f.exclude_ref_pattern.items) |p| if (matchRefPattern(refname, p)) return false;
    if (f.include_ref_pattern.items.len > 0) {
        for (f.include_ref_pattern.items) |p| if (matchRefPattern(refname, p)) return true;
        return false;
    }
    for (f.exclude_ref_config_pattern.items) |p| if (matchRefPattern(refname, p)) return false;
    return true;
}

const NsInfo = struct { ref: []const u8, deco: DecorationType, exact: bool = false };
pub const ref_namespace = [_]NsInfo{
    .{ .ref = "HEAD", .deco = .ref_head, .exact = true },
    .{ .ref = "refs/heads/", .deco = .ref_local },
    .{ .ref = "refs/tags/", .deco = .ref_tag },
    .{ .ref = "refs/remotes/", .deco = .ref_remote },
    .{ .ref = "refs/stash", .deco = .ref_stash, .exact = true },
    .{ .ref = "refs/replace/", .deco = .grafted },
};

fn addRefDecoration(name: []const u8, oid: hash.Oid, filter: ?*const DecorationFilter) void {
    if (filter) |f| if (!refFilterMatch(name, f)) return;
    if (util.skipPrefix(name, "refs/replace/")) |rest| {
        if (os_getenv("GIT_NO_REPLACE_OBJECTS") != null) return;
        const orig = hash.fromHex(rest) orelse {
            util.warn("invalid replace ref {s}", .{name});
            return;
        };
        if (cn.parseObject(orig)) |o| addNameDecoration(.grafted, "replaced", o);
        return;
    }
    const typ = repo_mod.repo().odb().readType(oid) orelse return;
    var obj = cn.lookup(oid, typ) orelse return;
    var deco: DecorationType = .none;
    for (ref_namespace) |info| {
        if (info.exact) {
            if (util.eql(name, info.ref)) {
                deco = info.deco;
                break;
            }
        } else if (util.startsWith(name, info.ref)) {
            deco = info.deco;
            break;
        }
    }
    addNameDecoration(deco, name, obj);
    while (obj.typ == .tag) {
        const data = repo_mod.repo().odb().read(obj.oid) orelse break;
        const tag = objects.parseTag(data.data) orelse break;
        obj = cn.parseObject(tag.object) orelse cn.lookupAny(tag.object) orelse break;
        addNameDecoration(.ref_tag, name, obj);
    }
}

fn os_getenv(n: []const u8) ?[]const u8 {
    return @import("os.zig").getenv(n);
}

fn normalizeGlobRef(pattern: []const u8) []const u8 {
    var b: util.Buf = .empty;
    if (!util.startsWith(pattern, "refs/") and !util.eql(pattern, "HEAD")) util.bufAppend(&b, "refs/");
    util.bufAppend(&b, pattern);
    if (b.items.len > 0 and b.items[b.items.len - 1] == '/') b.items.len -= 1;
    return b.items;
}

/// load_ref_decorations
pub fn loadRefDecorations(filter: ?*DecorationFilter, flags: i32) void {
    if (decoration_loaded) return;
    if (filter) |f| {
        for ([_]*std.ArrayList([]const u8){ &f.exclude_ref_pattern, &f.include_ref_pattern, &f.exclude_ref_config_pattern }) |l| {
            for (l.items) |*it| it.* = normalizeGlobRef(it.*);
        }
    }
    decoration_loaded = true;
    decoration_flags = flags;
    for (refs.iterate("", .{ .check_objects = false })) |r| {
        if (r.flags & refs.REF_ISBROKEN != 0) continue;
        if (!util.startsWith(r.name, "refs/")) continue;
        addRefDecoration(r.name, r.oid, filter);
    }
    const head = refs.resolveFull("HEAD", true);
    if (!head.missing and !head.broken and !hash.isZero(head.oid))
        addRefDecoration("HEAD", head.oid, filter);
    // grafts
    if (os_getenv("GIT_GRAFT_FILE")) |_| {} else {}
    const graft_path = repo_mod.repo().commonPath("info/grafts");
    if (@import("os.zig").readFile(graft_path)) |data| {
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line| {
            if (line.len < 40 or line[0] == '#') continue;
            const oid = hash.fromHex(line[0..40]) orelse continue;
            if (cn.lookupCommit(oid)) |c| addNameDecoration(.grafted, "grafted", &c.obj);
        }
    }
}

/// load_ref_decorations with default filter (used by %d/%D when decorations not loaded yet).
pub fn loadRefDecorationsDefault() void {
    loadRefDecorations(null, DECORATE_SHORT_REFS);
}

/// load_branch_decorations
pub fn loadBranchDecorations() void {
    if (decoration_loaded) return;
    var f = DecorationFilter{};
    f.include_ref_pattern.append(gpa, "refs/heads/") catch util.oom();
    loadRefDecorations(&f, 0);
}

pub fn prettifyRefname(name: []const u8) []const u8 {
    if (util.skipPrefix(name, "refs/heads/")) |n| return n;
    if (util.skipPrefix(name, "refs/tags/")) |n| return n;
    if (util.skipPrefix(name, "refs/remotes/")) |n| return n;
    return name;
}

fn currentPointedByHead(decoration: *NameDecoration) ?*NameDecoration {
    var head: ?*NameDecoration = null;
    var l: ?*NameDecoration = decoration;
    while (l) |x| : (l = x.next) {
        if (x.typ == .ref_head) {
            head = x;
            break;
        }
    }
    if (head == null) return null;
    const res = refs.resolveFull("HEAD", false);
    if (res.broken or res.flags & refs.REF_ISSYMREF == 0) return null;
    const branch_name = res.name;
    if (!util.startsWith(branch_name, "refs/")) return null;
    l = decoration;
    while (l) |x| : (l = x.next) {
        if (x.typ == .ref_local and util.eql(branch_name, x.name)) return x;
    }
    return null;
}

fn showName(sb: *util.Buf, d: *const NameDecoration) void {
    if (decoration_flags == DECORATE_SHORT_REFS) {
        util.bufAppend(sb, prettifyRefname(d.name));
    } else util.bufAppend(sb, d.name);
}

/// default diff colors when no diff machinery is installed
fn defaultDiffColor(slot: []const u8) []const u8 {
    const key = util.concat(&.{ "color.diff.", slot });
    if (repo_mod.cfg.get(key)) |v| {
        if (color_mod.parseColor(v)) |c| return c;
    }
    if (util.eql(slot, "commit")) return color_mod.YELLOW;
    if (util.eql(slot, "reset")) return color_mod.RESET;
    if (util.eql(slot, "frag")) return color_mod.CYAN;
    if (util.eql(slot, "whitespace")) return "\x1b[41m";
    return "";
}

pub fn diffColor(revs: ?*RevInfo, use_color: bool, slot: []const u8) []const u8 {
    if (!use_color) return "";
    if (revs) |r| if (r.diff_ops) |ops| return ops.get_color(r, slot);
    return defaultDiffColor(slot);
}

/// format_decorations: append " (HEAD -> main, tag: v1)" style decorations for commit.
pub fn formatDecorations(b: *util.Buf, commit: *const cn.Commit, use_color: bool, opts: ?*const DecorationOptions) void {
    var decoration = getNameDecoration(&commit.obj) orelse return;
    var prefix: []const u8 = " (";
    var suffix: []const u8 = ")";
    var separator: []const u8 = ", ";
    var pointer: []const u8 = " -> ";
    var tag: []const u8 = "tag: ";
    if (opts) |o| {
        if (o.prefix) |p| prefix = p;
        if (o.suffix) |p| suffix = p;
        if (o.separator) |p| separator = p;
        if (o.pointer) |p| pointer = p;
        if (o.tag) |p| tag = p;
    }
    const color_commit = diffColor(null, use_color, "commit");
    const color_reset = decorateGetColor(use_color, .none);
    const current_and_head = currentPointedByHead(decoration);
    var d: ?*NameDecoration = decoration;
    while (d) |x| : (d = x.next) {
        decoration = x;
        if (current_and_head != null and x == current_and_head.?) continue;
        const color = decorateGetColor(use_color, x.typ);
        if (prefix.len > 0) {
            util.bufAppend(b, color_commit);
            util.bufAppend(b, prefix);
            util.bufAppend(b, color_reset);
        }
        if (tag.len > 0 and x.typ == .ref_tag) {
            util.bufAppend(b, color);
            util.bufAppend(b, tag);
            util.bufAppend(b, color_reset);
        }
        util.bufAppend(b, color);
        showName(b, x);
        util.bufAppend(b, color_reset);
        if (current_and_head != null and x.typ == .ref_head) {
            util.bufAppend(b, color_commit);
            util.bufAppend(b, pointer);
            util.bufAppend(b, color_reset);
            util.bufAppend(b, decorateGetColor(use_color, current_and_head.?.typ));
            showName(b, current_and_head.?);
            util.bufAppend(b, color_reset);
        }
        prefix = separator;
    }
    if (suffix.len > 0) {
        util.bufAppend(b, color_commit);
        util.bufAppend(b, suffix);
        util.bufAppend(b, color_reset);
    }
}

/// show_decorations
pub fn showDecorations(revs: *RevInfo, commit: *Commit) void {
    if (revs.sources) |s| {
        if (s.peek(commit)) |slot| {
            if (slot.*) |name| util.outf("\t{s}", .{name});
        }
    }
    if (!revs.show_decorations) return;
    var sb: util.Buf = .empty;
    formatDecorations(&sb, commit, revs.use_color, null);
    util.out(sb.items);
}

/// find_unique_abbrev; 0 or >= 40 means full hex
pub fn abbrevOid(oid: hash.Oid, n: usize) []const u8 {
    if (n == 0 or n >= 40) return hash.hexAlloc(oid);
    return revparse.abbrev(oid, n);
}

fn showParents(commit: *Commit, abbrev: usize) void {
    var p = commit.parents;
    while (p) |x| : (p = x.next) util.outf(" {s}", .{abbrevOid(x.item.obj.oid, abbrev)});
}

fn showChildren(revs: *RevInfo, commit: *Commit, abbrev: usize) void {
    var p = revision.getChildren(revs, commit);
    while (p) |x| : (p = x.next) util.outf(" {s}", .{abbrevOid(x.item.obj.oid, abbrev)});
}

fn isMail(f: revision.CmitFmt) bool {
    return f == .email or f == .mboxrd;
}

fn decimalWidth(n: i32) usize {
    var v: u32 = @intCast(@max(n, 0));
    var w: usize = 1;
    while (v >= 10) : (w += 1) v /= 10;
    return w;
}

/// log_write_email_headers; returns extra headers (after_subject) and need_8bit_cte
pub fn logWriteEmailHeaders(revs: *RevInfo, commit: *Commit, need_8bit_cte: *i32, maybe_multipart: bool) ?[]const u8 {
    var headers: util.Buf = .empty;
    const name: []const u8 = if (revs.zero_commit) hash.zero_hex else hash.hexAlloc(commit.obj.oid);
    need_8bit_cte.* = 0;
    if (revs.extra_headers) |h| util.bufAppend(&headers, h);
    util.outf("From {s} Mon Sep 17 00:00:00 2001\n", .{name});
    graph_mod.showOneline(revs.graph);
    if (revs.message_id) |m| {
        util.outf("Message-ID: <{s}>\n", .{m});
        graph_mod.showOneline(revs.graph);
    }
    const ids = revs.ref_message_ids.items;
    if (ids.len > 0) {
        util.outf("In-Reply-To: <{s}>\n", .{ids[ids.len - 1]});
        for (ids, 0..) |id, i| util.outf("{s}<{s}>\n", .{ if (i > 0) "\t" else "References: ", id });
        graph_mod.showOneline(revs.graph);
    }
    if (revs.mime_boundary != null and maybe_multipart) {
        const mb = revs.mime_boundary.?;
        const leader = "------------";
        need_8bit_cte.* = -1;
        util.bufPrint(&headers, "MIME-Version: 1.0\nContent-Type: multipart/mixed; boundary=\"{s}{s}\"\n\nThis is a multi-part message in MIME format.\n--{s}{s}\nContent-Type: text/plain; charset=UTF-8; format=fixed\nContent-Transfer-Encoding: 8bit\n\n", .{ leader, mb, leader, mb });
        var filename: util.Buf = .empty;
        if (revs.numbered_files) {
            util.bufPrint(&filename, "{d}", .{revs.nr});
        } else fmtOutputCommit(&filename, commit, revs);
        var buffer: util.Buf = .empty;
        util.bufPrint(&buffer, "\n--{s}{s}\nContent-Type: text/x-patch; name=\"{s}\"\nContent-Transfer-Encoding: 8bit\nContent-Disposition: {s}; filename=\"{s}\"\n\n", .{ leader, mb, filename.items, if (revs.no_inline) "attachment" else "inline", filename.items });
        revs.stat_sep = buffer.items;
    }
    return if (headers.items.len > 0) headers.items else null;
}

pub fn fmtOutputSubject(filename: *util.Buf, subject: []const u8, revs: *RevInfo) void {
    const suffix = revs.patch_suffix;
    const start_len = filename.items.len;
    const max_len = start_len + revs.patch_name_max -| (suffix.len + 1);
    if (revs.reroll_count) |rc| {
        pretty.formatSanitizedSubject(filename, util.fmt("v{s}", .{rc}));
        util.bufAppend(filename, "-");
    }
    util.bufPrint(filename, "{d:0>4}-{s}", .{ @as(u32, @intCast(@max(revs.nr, 0))), subject });
    if (max_len < filename.items.len) filename.items.len = max_len;
    util.bufAppend(filename, suffix);
}

pub fn fmtOutputCommit(filename: *util.Buf, commit: *Commit, revs: *RevInfo) void {
    var ctx = pretty.Context{};
    var subject: util.Buf = .empty;
    pretty.formatCommitMessage(commit, "%f", &subject, &ctx);
    fmtOutputSubject(filename, subject.items, revs);
}

fn nextCommentaryBlock(revs: *RevInfo, sb: ?*util.Buf) void {
    const x: []const u8 = if (revs.shown_dashes) "\n" else "---\n";
    if (sb) |b| util.bufAppend(b, x) else util.out(x);
    revs.shown_dashes = true;
}

/// Display notes hook (format_display_notes); set by notes integration.
pub var display_notes_hook: ?*const fn (oid: hash.Oid, sb: *util.Buf, encoding: []const u8, raw: bool) void = null;
/// load_display_notes hook (called once before the first display_notes_hook call).
pub var load_display_notes_hook: ?*const fn (revs: *RevInfo) void = null;
/// Signature verification hook (show_signature/show_mergetag).
pub var show_signature_hook: ?*const fn (revs: *RevInfo, commit: *Commit) void = null;
/// append_signoff hook used by format-patch -s
pub var append_signoff_hook: ?*const fn (sb: *util.Buf) void = null;

/// show_log
pub fn showLog(revs: *RevInfo) void {
    const log = revs.loginfo orelse return;
    const commit = log.commit;
    const parent = log.parent;
    const abbrev_commit: usize = if (revs.abbrev_commit) revs.abbrev else 40;
    revs.loginfo = null;

    if (!revs.verbose_header) {
        graph_mod.showCommit(revs.graph);
        if (revs.graph == null) revision.putRevisionMark(revs, commit);
        util.out(abbrevOid(commit.obj.oid, abbrev_commit));
        if (revs.print_parents) showParents(commit, abbrev_commit);
        if (revs.children_enabled) showChildren(revs, commit, abbrev_commit);
        showDecorations(revs, commit);
        if (revs.graph != null and !graph_mod.isCommitFinished(revs.graph.?)) {
            util.out("\n");
            _ = graph_mod.showRemainder(revs.graph);
        }
        util.out(&[_]u8{revs.line_termination});
        return;
    }

    if (revs.shown_one and !revs.use_terminator) {
        if (revs.line_termination == '\n' and !revs.missing_newline)
            graph_mod.showPadding(revs.graph);
        util.out(&[_]u8{revs.line_termination});
    }
    revs.shown_one = true;

    graph_mod.showCommit(revs.graph);

    var ctx = pretty.Context{};
    if (isMail(revs.commit_format)) {
        ctx.after_subject = logWriteEmailHeaders(revs, commit, &ctx.need_8bit_cte, true);
        ctx.rev = revs;
    } else if (revs.commit_format != .userformat) {
        util.out(diffColor(revs, revs.use_color, "commit"));
        if (revs.commit_format != .oneline) util.out("commit ");
        if (revs.graph == null) revision.putRevisionMark(revs, commit);
        util.out(abbrevOid(commit.obj.oid, abbrev_commit));
        if (revs.print_parents) showParents(commit, abbrev_commit);
        if (revs.children_enabled) showChildren(revs, commit, abbrev_commit);
        if (parent) |p| util.outf(" (from {s})", .{abbrevOid(p.obj.oid, abbrev_commit)});
        util.out(diffColor(revs, revs.use_color, "reset"));
        showDecorations(revs, commit);
        if (revs.commit_format == .oneline) {
            util.out(" ");
        } else {
            util.out("\n");
            graph_mod.showOneline(revs.graph);
        }
        if (revs.reflog_info) |ri| {
            reflogwalk.showReflogMessage(ri, revs.commit_format == .oneline, revs.date_mode, revs.date_mode_explicit);
            if (revs.commit_format == .oneline) return;
        }
    }

    if (revs.show_signature) {
        if (show_signature_hook) |h| h(revs, commit) else {
            showSignature(revs, commit);
            showMergetags(revs, commit);
        }
    }

    if (revs.show_notes) {
        if (display_notes_hook) |h| {
            if (load_display_notes_hook) |lh| lh(revs);
            var notebuf: util.Buf = .empty;
            h(commit.obj.oid, &notebuf, pretty.logOutputEncoding(), revs.commit_format == .userformat);
            ctx.notes_message = notebuf.items;
        }
    }

    if (ctx.need_8bit_cte >= 0 and revs.add_signoff) {
        const full = ident_mod.committer();
        const gt = std.mem.lastIndexOfScalar(u8, full, '>') orelse full.len - 1;
        ctx.need_8bit_cte = @intFromBool(pretty.hasNonAscii(full[0 .. gt + 1]));
    }
    ctx.date_mode = revs.date_mode;
    ctx.date_mode_explicit = revs.date_mode_explicit;
    ctx.abbrev = revs.abbrev;
    ctx.preserve_subject = revs.preserve_subject;
    ctx.encode_email_headers = revs.encode_email_headers;
    ctx.reflog_info = revs.reflog_info;
    ctx.fmt = revs.commit_format;
    ctx.mailmap = revs.mailmap;
    ctx.color = revs.use_color;
    ctx.expand_tabs_in_log = revs.expand_tabs_in_log;
    ctx.output_encoding = pretty.logOutputEncoding();
    ctx.rev = revs;
    ctx.from_ident = revs.from_ident;
    if (revs.graph) |g| ctx.graph_width = graph_mod.width(g);
    var msgbuf: util.Buf = .empty;
    pretty.prettyPrintCommit(&ctx, commit, &msgbuf);

    if (revs.add_signoff) {
        if (append_signoff_hook) |h| h(&msgbuf);
    }
    if (ctx.fmt != .userformat) {
        if (ctx.notes_message) |nm| {
            if (nm.len > 0) {
                if (isMail(ctx.fmt)) nextCommentaryBlock(revs, &msgbuf);
                util.bufAppend(&msgbuf, nm);
            }
        }
    }
    if (revs.show_log_size) {
        util.outf("log size {d}\n", .{msgbuf.items.len});
        graph_mod.showOneline(revs.graph);
    }
    revs.missing_newline = msgbuf.items.len == 0 or msgbuf.items[msgbuf.items.len - 1] != '\n';
    graph_mod.showCommitMsg(revs.graph, msgbuf.items);
    if (revs.use_terminator and !pretty.commitFormatIsEmpty(revs.commit_format)) {
        if (!revs.missing_newline) graph_mod.showPadding(revs.graph);
        util.out(&[_]u8{revs.line_termination});
    }
}

/// log_tree_diff_flush: returns true if something was queued
pub fn logTreeDiffFlush(revs: *RevInfo) bool {
    const ops = revs.diff_ops orelse return false;
    revs.shown_dashes = false;
    if (!ops.diffcore(revs)) {
        ops.discard(revs);
        return false;
    }
    if (revs.loginfo != null and !revs.no_commit_id) {
        showLog(revs);
        if ((revs.output_format & ~revision.DIFF_FORMAT_NO_OUTPUT) != 0 and revs.verbose_header and
            revs.commit_format != .oneline and !pretty.commitFormatIsEmpty(revs.commit_format))
        {
            const pch = revision.DIFF_FORMAT_DIFFSTAT | revision.DIFF_FORMAT_PATCH;
            util.out(ops.line_prefix(revs));
            if (!revs.shown_dashes and (pch & revs.output_format) == pch) util.out("---");
            util.out("\n");
        }
    }
    ops.flush(revs);
    return true;
}

fn logTreeDiff(revs: *RevInfo, commit: *Commit, log: *revision.LogInfo) bool {
    const ops = revs.diff_ops orelse return false;
    const all_need_diff = revs.diff or ops.exit_with_status(revs);
    if (!all_need_diff and !revs.merges_need_diff) return false;
    if (revs.line_level_traverse) {
        if (revs.line_log_ops) |llo| llo.queue_pairs(revs, commit);
        _ = logTreeDiffFlush(revs);
        return revs.loginfo == null;
    }
    cn.parseOrDie(commit);
    const oid = commit.tree;
    var parents = revision.getSavedParents(revs, commit);
    const is_merge = parents != null and parents.?.next != null;
    if (!is_merge and !all_need_diff) return false;

    if (parents == null) {
        if (revs.show_root_diff) {
            ops.diff_tree(revs, null, oid);
            _ = logTreeDiffFlush(revs);
        }
        return revs.loginfo == null;
    }
    if (is_merge) {
        const octopus = parents.?.next.?.next != null;
        if (revs.remerge_diff) {
            if (octopus) {
                showLog(revs);
                util.out("diff: warning: Skipping remerge-diff for octopus merges.\n");
                return true;
            }
            if (ops.remerge) |rf| return rf(revs, commit);
            // no remerge implementation: fall back to dense combined
            ops.combined_merge(revs, commit);
            return revs.loginfo == null;
        }
        if (revs.combine_merges) {
            ops.combined_merge(revs, commit);
            return revs.loginfo == null;
        }
        if (revs.separate_merges) {
            if (!revs.first_parent_merges) log.parent = parents.?.item;
        } else return false;
    }
    var showed_log = false;
    while (true) {
        const parent = parents.?.item;
        cn.parseOrDie(parent);
        ops.diff_tree(revs, parent.tree, oid);
        _ = logTreeDiffFlush(revs);
        showed_log = showed_log or revs.loginfo == null;
        parents = parents.?.next;
        if (parents == null or revs.first_parent_merges) break;
        log.parent = parents.?.item;
        revs.loginfo = log;
    }
    return showed_log;
}

/// log_tree_commit: returns true if something was shown
pub fn logTreeCommit(revs: *RevInfo, commit: *Commit) bool {
    var log = revision.LogInfo{ .commit = commit };
    revs.loginfo = &log;
    if (revs.track_linear and !revs.linear and !revs.reverse_output_stage)
        util.outf("\n{s}\n", .{revs.break_bar});
    var shown = logTreeDiff(revs, commit, &log);
    if (!shown and revs.loginfo != null and revs.always_show_header) {
        log.parent = null;
        showLog(revs);
        shown = true;
    }
    if (revs.track_linear and !revs.linear and revs.reverse_output_stage)
        util.outf("\n{s}\n", .{revs.break_bar});
    revs.loginfo = null;
    return shown;
}

// ---------------------------------------------------------------------------
// --show-signature (log-tree.c show_signature / show_mergetag)

const gpg = @import("gpg.zig");

fn showSigLines(revs: *RevInfo, status: i32, text: []const u8) void {
    const color = diffColor(revs, revs.use_color, if (status != 0) "whitespace" else "frag");
    const reset = diffColor(revs, revs.use_color, "reset");
    var bol = text;
    while (bol.len > 0) {
        const eol = std.mem.indexOfScalar(u8, bol, '\n');
        const line = bol[0 .. eol orelse bol.len];
        util.outf("{s}{s}{s}{s}", .{ color, line, reset, if (eol != null) "\n" else "" });
        graph_mod.showOneline(revs.graph);
        bol = if (eol) |e| bol[e + 1 ..] else bol[bol.len..];
    }
}

fn showSignature(revs: *RevInfo, commit: *Commit) void {
    _ = cn.parse(commit);
    var payload: util.Buf = .empty;
    var sig: util.Buf = .empty;
    if (!gpg.parseBufferSignedByHeader(commit.buffer, &payload, &sig)) return;
    var sigc: gpg.SigCheck = .{ .payload_type = .commit, .payload = payload.items };
    const status = gpg.checkSignature(&sigc, sig.items);
    if (status != 0 and sigc.output == null)
        showSigLines(revs, status, "No signature\n")
    else
        showSigLines(revs, status, sigc.output orelse "");
}

/// parse_tag_buffer() subset: tagged oid and tag name.
fn parseMergetag(buf: []const u8) ?struct { tagged: hash.Oid, name: []const u8 } {
    if (buf.len < 40 + 24) return null;
    if (!util.startsWith(buf, "object ")) return null;
    const oid = hash.fromHex(buf[7..47]) orelse return null;
    var p: usize = 47;
    if (buf[p] != '\n') return null;
    p += 1;
    if (!util.startsWith(buf[p..], "type ")) return null;
    p += 5;
    const nl = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse return null;
    if (nl - p >= 20) return null;
    const t = buf[p..nl];
    if (!(util.eql(t, "blob") or util.eql(t, "tree") or util.eql(t, "commit") or util.eql(t, "tag"))) {
        util.err("unknown tag type '{s}' in {s}", .{ t, &hash.hex(objects_hash(buf)) });
        util.err("bad tag pointer to {s} in {s}", .{ &hash.hex(oid), &hash.hex(objects_hash(buf)) });
        return null;
    }
    p = nl + 1;
    if (!(p + 4 < buf.len and util.startsWith(buf[p..], "tag "))) return null;
    p += 4;
    const nl2 = std.mem.indexOfScalarPos(u8, buf, p, '\n') orelse return null;
    return .{ .tagged = oid, .name = buf[p..nl2] };
}

fn objects_hash(buf: []const u8) hash.Oid {
    return @import("odb.zig").hashObject(.tag, buf);
}

fn showOneMergetag(revs: *RevInfo, commit: *Commit, value: []const u8) void {
    var msg: util.Buf = .empty;
    const nparents = blk: {
        var n: usize = 0;
        var it = commit.parents;
        while (it) |l| : (it = l.next) n += 1;
        break :blk n;
    };
    if (parseMergetag(value)) |t| {
        if (nparents == 2 and hash.eql(t.tagged, commit.parents.?.next.?.item.obj.oid)) {
            util.bufPrint(&msg, "merged tag '{s}'\n", .{t.name});
        } else {
            var nth: i32 = -1;
            var i: i32 = 0;
            var it = commit.parents;
            while (it) |l| : (it = l.next) {
                if (hash.eql(l.item.obj.oid, t.tagged)) {
                    nth = i;
                    break;
                }
                i += 1;
            }
            if (nth < 0)
                util.bufPrint(&msg, "tag {s} names a non-parent {s}\n", .{ t.name, &hash.hex(t.tagged) })
            else
                util.bufPrint(&msg, "parent #{d}, tagged '{s}'\n", .{ nth + 1, t.name });
        }
    } else util.bufAppend(&msg, "malformed mergetag\n");
    var status: i32 = -1;
    var payload: util.Buf = .empty;
    var sig: util.Buf = .empty;
    if (gpg.parseSignature(value, &payload, &sig)) {
        var sigc: gpg.SigCheck = .{ .payload_type = .tag, .payload = payload.items };
        status = gpg.checkSignature(&sigc, sig.items);
        util.bufAppend(&msg, sigc.output orelse "No signature\n");
    }
    showSigLines(revs, status, msg.items);
}

/// read_commit_extra_header_lines() restricted to "mergetag".
fn showMergetags(revs: *RevInfo, commit: *Commit) void {
    _ = cn.parse(commit);
    const buf = commit.buffer;
    var pos: usize = 0;
    var cur: ?util.Buf = null;
    while (pos < buf.len) {
        const eol = std.mem.indexOfScalarPos(u8, buf, pos, '\n');
        const next = if (eol) |e| e + 1 else buf.len;
        const line = buf[pos..next];
        if (line.len == 0 or line[0] == '\n') break;
        if (line[0] == ' ') {
            if (cur) |*b| util.bufAppend(b, line[1..]);
            pos = next;
            continue;
        }
        if (cur) |b| showOneMergetag(revs, commit, b.items);
        cur = null;
        if (util.startsWith(line, "mergetag ")) {
            var b: util.Buf = .empty;
            util.bufAppend(&b, line["mergetag ".len..]);
            cur = b;
        }
        pos = next;
    }
    if (cur) |b| showOneMergetag(revs, commit, b.items);
}
