//! git clean

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const dir_mod = @import("../dir.zig");
const config = @import("../config.zig");
const gpa = util.gpa;

extern "c" fn rmdir(path: [*:0]const u8) c_int;
extern "c" fn unlink(path: [*:0]const u8) c_int;

const usage = [_][]const u8{"git clean [-d] [-f] [-i] [-n] [-q] [-e <pattern>] [-x | -X] [--] [<pathspec>...]"};

var exclude_list: std.ArrayList([]const u8) = .empty;

fn excludeCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    exclude_list.append(gpa, arg.?) catch util.oom();
}

const REMOVE_DIR_KEEP_NESTED_GIT: u32 = 2;

var g_prefix: []const u8 = "";
var real_ocwd: ?[]const u8 = null;

fn quotePath(path: []const u8, prefix: []const u8) []const u8 {
    const rel = if (prefix.len > 0) util.relativePath(path, prefix) else path;
    return util.cquote(rel);
}

fn doRmdir(p: []const u8) bool {
    return rmdir(os.z(p)) == 0;
}
fn doUnlink(p: []const u8) bool {
    return unlink(os.z(p)) == 0;
}

fn warnErrno(comptime msg: []const u8, arg: []const u8) void {
    const e = os.errno();
    util.warn(msg ++ ": {s}", .{ arg, os.strErr(e) });
}

fn removeDirs(path0: []const u8, prefix: []const u8, force_flag: u32, dry_run: bool, quiet: bool, dir_gone: *bool) bool {
    var ret = false;
    dir_gone.* = true;
    var dels: std.ArrayList([]const u8) = .empty;

    if (force_flag & REMOVE_DIR_KEEP_NESTED_GIT != 0 and dir_mod.isNonbareRepositoryDir(path0)) {
        if (!quiet) {
            const q = quotePath(path0, prefix);
            if (dry_run) util.outf("Would skip repository {s}\n", .{q}) else util.outf("Skipping repository {s}\n", .{q});
        }
        dir_gone.* = false;
        return false;
    }

    const ents = os.listDir(path0) orelse {
        const ok = dry_run or doRmdir(path0);
        if (!ok) {
            warnErrno("failed to remove {s}", quotePath(path0, prefix));
            dir_gone.* = false;
            return true;
        }
        return false;
    };

    const base = if (path0.len > 0 and path0[path0.len - 1] != '/') util.concat(&.{ path0, "/" }) else path0;
    // readdir order is unspecified; git uses readdir order. Sort for determinism.
    std.mem.sort(os.DirEntry, ents, {}, struct {
        fn lt(_: void, a: os.DirEntry, b: os.DirEntry) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    for (ents) |de| {
        const name = de.name;
        const p = util.concat(&.{ base, name });
        const st = os.lstatPath(p) orelse {
            util.warn("could not lstat {s}\n: {s}", .{ p, os.strErr(os.errno()) });
            dir_gone.* = false;
            ret = true;
            break;
        };
        if (st.isDir()) {
            var gone = true;
            if (removeDirs(p, prefix, force_flag, dry_run, quiet, &gone)) ret = true;
            if (gone) {
                dels.append(gpa, quotePath(p, prefix)) catch util.oom();
            } else dir_gone.* = false;
            continue;
        }
        const ok = dry_run or doUnlink(p);
        if (ok) {
            dels.append(gpa, quotePath(p, prefix)) catch util.oom();
        } else {
            warnErrno("failed to remove {s}", quotePath(p, prefix));
            dir_gone.* = false;
            ret = true;
        }
    }

    if (dir_gone.*) {
        const rp = os.realPath(path0);
        if (real_ocwd != null and rp != null and util.eql(rp.?, real_ocwd.?)) {
            util.out(if (dry_run) "Would refuse to remove current working directory\n" else "Refusing to remove current working directory\n");
            dir_gone.* = false;
        } else {
            const ok = dry_run or doRmdir(path0);
            if (ok) {
                dir_gone.* = true;
            } else {
                warnErrno("failed to remove {s}", quotePath(path0, prefix));
                dir_gone.* = false;
                ret = true;
            }
        }
    }

    if (!dir_gone.* and !quiet) {
        for (dels.items) |d| {
            if (dry_run) util.outf("Would remove {s}\n", .{d}) else util.outf("Removing {s}\n", .{d});
        }
    }
    return ret;
}

fn containsEntry(out: []const u8, in: []const u8) bool {
    return out.len < in.len and out[out.len - 1] == '/' and std.mem.eql(u8, out, in[0..out.len]);
}

/// correct_untracked_entries()
fn correctUntracked(entries: []dir_mod.Entry, ignored: []const dir_mod.Entry) []dir_mod.Entry {
    var out: std.ArrayList(dir_mod.Entry) = .empty;
    var src: usize = 0;
    var ign: usize = 0;
    while (src < entries.len) : (src += 1) {
        while (ign < ignored.len and std.mem.order(u8, entries[src].name, ignored[ign].name) != .lt) ign += 1;
        if (ign < ignored.len and containsEntry(entries[src].name, ignored[ign].name)) {
            continue;
        }
        const ent = entries[src];
        src += 1;
        out.append(gpa, ent) catch util.oom();
        while (src < entries.len and containsEntry(ent.name, entries[src].name)) src += 1;
        src -= 1;
    }
    return out.items;
}

pub fn cmdClean(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    @import("../sparse_index.zig").commandIsSparseAware();
    const prefix = r.prefix;
    var quiet: i32 = 0;
    var dry_run = false;
    var force: i32 = 0;
    var interactive = false;
    var remove_directories = false;
    var ignored = false;
    var ignored_only = false;
    var rm_flags: u32 = REMOVE_DIR_KEEP_NESTED_GIT;
    const opts = [_]po.Opt{
        .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet, .help = "do not print names of files removed" },
        po.boolean('n', "dry-run", &dry_run, "dry run"),
        po.noComplete(po.counter('f', "force", &force, "force")),
        po.boolean('i', "interactive", &interactive, "interactive cleaning"),
        po.boolean('d', "", &remove_directories, "remove whole directories"),
        .{ .short = 'e', .long = "exclude", .kind = .callback, .cb = excludeCb, .argh = "pattern", .help = "add <pattern> to ignore rules", .noneg = true },
        po.boolean('x', "", &ignored, "remove ignored files, too"),
        po.boolean('X', "", &ignored_only, "remove only ignored files"),
    };

    var require_force: i32 = -1;
    if (repo_mod.cfg.getEntry("clean.requireforce")) |e| {
        if (e.value) |v| {
            require_force = if (config.parseBool(v) orelse util.die("bad boolean config value '{s}' for 'clean.requireforce'", .{v})) 1 else 0;
        } else require_force = 1;
    }

    po.prefix = prefix;
    const argv = po.parse(args[1..], &opts, &usage, .{});

    if (require_force != 0 and force == 0 and !interactive and !dry_run)
        util.die("clean.requireForce is true and -f not given: refusing to clean", .{});

    var d = dir_mod.Dir.init();
    if (force > 1) {
        rm_flags = 0;
    } else d.flags.skip_nested_git = true;
    d.flags.show_other_directories = true;

    if (ignored and ignored_only) util.die("options '{s}' and '{s}' cannot be used together", .{ "-x", "-X" });
    if (!ignored) d.setupStandardExcludes();
    if (ignored_only) d.flags.show_ignored = true;

    if (argv.len > 0) remove_directories = true;

    if (remove_directories and !ignored_only) {
        d.flags.show_ignored_too = true;
        if (!ignored) d.flags.show_ignored_too_mode_matching = true;
        d.flags.keep_untracked_contents = true;
    }

    const idx = index_mod.get();
    {
        const pl = d.addPatternList(dir_mod.EXC_CMDL, "--exclude option");
        for (exclude_list.items) |p| d.addPatternSrcpos(pl, p, 0);
    }

    const ps = pathspec_mod.parse(prefix, argv, .{ .prefer_cwd = true });

    if (prefix.len > 0) real_ocwd = os.realPath(prefix[0 .. prefix.len - 1]);

    _ = d.fill(idx, &ps);
    const entries = correctUntracked(d.entries.items, d.ignored.items);

    var del_list: std.ArrayList([]const u8) = .empty;
    for (entries) |ent| {
        if (!dir_mod.indexNameIsOther(idx, ent.name)) continue;
        var nm = ent.name;
        const st = os.lstatPath(nm) orelse blk: {
            if (nm.len > 1 and nm[nm.len - 1] == '/') nm = nm[0 .. nm.len - 1];
            break :blk os.lstatPath(nm) orelse util.die("Cannot lstat '{s}': {s}", .{ ent.name, os.strErr(os.errno()) });
        };
        if (st.isDir() and !remove_directories) continue;
        const rel = if (prefix.len > 0) util.relativePath(ent.name, prefix) else ent.name;
        del_list.append(gpa, rel) catch util.oom();
    }

    if (interactive and del_list.items.len > 0) interactiveMainLoop(&del_list, idx);

    var errors: usize = 0;
    for (del_list.items) |item| {
        const abs_path = util.concat(&.{ prefix, item });
        const st = os.lstatPath(abs_path) orelse continue;
        if (st.isDir()) {
            var gone = true;
            if (removeDirs(abs_path, prefix, rm_flags, dry_run, quiet != 0, &gone)) errors += 1;
            if (gone and quiet == 0) {
                const q = util.cquote(item);
                if (dry_run) util.outf("Would remove {s}\n", .{q}) else util.outf("Removing {s}\n", .{q});
            }
        } else {
            const ok = dry_run or doUnlink(abs_path);
            if (!ok) {
                warnErrno("failed to remove {s}", util.cquote(item));
                errors += 1;
            } else if (quiet == 0) {
                const q = util.cquote(item);
                if (dry_run) util.outf("Would remove {s}\n", .{q}) else util.outf("Removing {s}\n", .{q});
            }
        }
    }
    return if (errors != 0) 1 else 0;
}

// ---------------- interactive clean (builtin/clean.c) ----------------

const color = @import("../color.zig");
const column = @import("../column.zig");
const add_patch = @import("../add_patch.zig");

const ColorSlot = enum(u8) { reset, plain, prompt, header, help, err };
var clean_colors = [_][]const u8{ color.RESET, "", color.BOLD_BLUE, color.BOLD, color.BOLD_RED, color.BOLD_RED };
var clean_use_color = false;
var colopts: u32 = 0;
var g_del: *std.ArrayList([]const u8) = undefined;
var g_idx: ?*index_mod.Index = null;

fn initInteractiveConfig() void {
    var cb: color.ColorBool = .unknown;
    const slot_names = [_][]const u8{ "reset", "plain", "prompt", "header", "help", "error" };
    for (repo_mod.cfg.entries.items) |e| {
        if (util.eql(e.key, "color.interactive")) {
            cb = color.configColorBool("color.interactive", e.value);
        } else if (util.startsWith(e.key, "color.interactive.")) {
            const slot = e.key["color.interactive.".len..];
            for (slot_names, 0..) |sn, i| {
                if (!std.ascii.eqlIgnoreCase(sn, slot)) continue;
                const v = e.value orelse util.die("missing value for '{s}'", .{e.key});
                clean_colors[i] = color.parseColor(v) orelse util.die("invalid color value: {s}", .{v});
            }
        }
    }
    if (cb == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| cb = color.configColorBool("color.ui", e.value);
    }
    clean_use_color = color.wantColorBool(cb, null);
    column.applyRepoConfig("clean", &colopts);
}

fn getColor(ix: ColorSlot) []const u8 {
    return if (clean_use_color) clean_colors[@intFromEnum(ix)] else "";
}

fn printColor(ix: ColorSlot) void {
    util.out(getColor(ix));
}

fn prettyPrintDels() void {
    var list: std.ArrayList([]const u8) = .empty;
    for (g_del.items) |item| list.append(gpa, util.cquote(item)) catch util.oom();
    colopts = (colopts & ~column.COL_ENABLE_MASK) | column.COL_ENABLED;
    column.printColumns(list.items, colopts, .{ .indent = "  ", .padding = 2 });
}

fn prettyPrintMenus(list: []const []const u8) void {
    column.printColumns(list, column.COL_ENABLED | column.COL_ROW, .{ .indent = "  ", .padding = 2 });
}

fn promptHelpCmd(singleton: bool) void {
    printColor(.help);
    util.out(if (singleton)
        "Prompt help:\n" ++
            "1          - select a numbered item\n" ++
            "foo        - select item based on unique prefix\n" ++
            "           - (empty) select nothing\n"
    else
        "Prompt help:\n" ++
            "1          - select a single item\n" ++
            "3-5        - select a range of items\n" ++
            "2-3,6-9    - select multiple ranges\n" ++
            "foo        - select item based on unique prefix\n" ++
            "-...       - unselect specified items\n" ++
            "*          - choose all items\n" ++
            "           - (empty) finish selecting\n");
    printColor(.reset);
}

const MenuItem = struct { hotkey: u8, title: []const u8 };

const MenuStuff = union(enum) {
    strings: []const []const u8,
    menu: []const MenuItem,

    fn nr(self: MenuStuff) usize {
        return switch (self) {
            .strings => |s| s.len,
            .menu => |m| m.len,
        };
    }
};

fn printHighlightMenuStuff(stuff: MenuStuff, chosen: []i32) void {
    var list: std.ArrayList([]const u8) = .empty;
    switch (stuff) {
        .menu => |items| for (items, 0..) |mi, i| {
            if (chosen[i] < 0) chosen[i] = 0;
            var b: util.Buf = .empty;
            b.print(gpa, "{s}{d:>2}: ", .{ if (chosen[i] != 0) "*" else " ", i + 1 }) catch util.oom();
            var highlighted = false;
            for (mi.title) |ch| {
                if (!highlighted and ch == mi.hotkey) {
                    b.appendSlice(gpa, getColor(.prompt)) catch util.oom();
                    b.append(gpa, ch) catch util.oom();
                    b.appendSlice(gpa, getColor(.reset)) catch util.oom();
                    highlighted = true;
                } else b.append(gpa, ch) catch util.oom();
            }
            list.append(gpa, b.items) catch util.oom();
        },
        .strings => |items| for (items, 0..) |s, i| {
            if (chosen[i] < 0) chosen[i] = 0;
            list.append(gpa, util.fmt("{s}{d:>2}: {s}", .{ if (chosen[i] != 0) "*" else " ", i + 1, s })) catch util.oom();
        },
    }
    prettyPrintMenus(list.items);
}

fn prefixMatchIcase(choice: []const u8, s: []const u8) bool {
    return choice.len <= s.len and std.ascii.eqlIgnoreCase(choice, s[0..choice.len]);
}

fn findUnique(choice: []const u8, stuff: MenuStuff) i64 {
    var found: i64 = 0;
    switch (stuff) {
        .menu => |items| for (items, 0..) |mi, i| {
            if (choice.len == 1 and choice[0] == mi.hotkey) {
                found = @intCast(i + 1);
                break;
            }
            if (prefixMatchIcase(choice, mi.title)) {
                if (found != 0) {
                    if (choice.len == 1) {
                        found = -1;
                    } else {
                        found = 0;
                        break;
                    }
                } else found = @intCast(i + 1);
            }
        },
        .strings => |items| for (items, 0..) |s, i| {
            if (prefixMatchIcase(choice, s)) {
                if (found != 0) {
                    found = 0;
                    break;
                }
                found = @intCast(i + 1);
            }
        },
    }
    return found;
}

fn atoi(s: []const u8) i64 {
    var v: i64 = 0;
    for (s) |c| {
        if (!std.ascii.isDigit(c)) break;
        v = v *| 10 +| (c - '0');
    }
    return v;
}

fn parseChoice(stuff: MenuStuff, is_single: bool, input: []const u8, chosen: []i32) usize {
    const nr: i64 = @intCast(stuff.nr());
    var it = std.mem.splitAny(u8, input, if (is_single) "\n" else ", ");
    while (it.next()) |piece| {
        var string = std.mem.trim(u8, piece, " \t\n\r\x0b\x0c");
        if (string.len == 0) continue;
        var choose: i32 = 1;
        if (string[0] == '-') {
            choose = 0;
            string = string[1..];
        }
        var is_range = false;
        var is_number = true;
        for (string) |c| {
            if (c == '-') {
                if (!is_range) {
                    is_range = true;
                    is_number = false;
                } else {
                    is_number = false;
                    is_range = false;
                    break;
                }
            } else if (!std.ascii.isDigit(c)) {
                is_number = false;
                is_range = false;
                break;
            }
        }
        var bottom: i64 = 0;
        var top: i64 = 0;
        if (is_number) {
            bottom = atoi(string);
            top = bottom;
        } else if (is_range) {
            bottom = atoi(string);
            const dash = std.mem.indexOfScalar(u8, string, '-').?;
            top = if (dash + 1 == string.len) nr else atoi(string[dash + 1 ..]);
        } else if (util.eql(string, "*")) {
            bottom = 1;
            top = nr;
        } else {
            bottom = findUnique(string, stuff);
            top = bottom;
        }
        if (top <= 0 or bottom <= 0 or top > nr or bottom > top or (is_single and bottom != top)) {
            printColor(.err);
            util.outf("Huh ({s})?\n", .{string});
            printColor(.reset);
            continue;
        }
        var i = bottom;
        while (i <= top) : (i += 1) chosen[@intCast(i - 1)] = choose;
    }
    var total: usize = 0;
    for (chosen) |c| total += @intCast(c);
    return total;
}

/// list_and_choose(): returns null on EOF, else the chosen indices.
fn listAndChoose(header: ?[]const u8, prompt: []const u8, singleton: bool, stuff: MenuStuff) ?[]usize {
    const n = stuff.nr();
    const chosen = gpa.alloc(i32, n) catch util.oom();
    @memset(chosen, -1);
    var choice: util.Buf = .empty;
    while (true) {
        if (header) |h| util.outf("{s}{s}{s}\n", .{ getColor(.header), h, getColor(.reset) });
        printHighlightMenuStuff(stuff, chosen);
        util.outf("{s}{s}{s}{s}", .{ getColor(.prompt), prompt, if (singleton) "> " else ">> ", getColor(.reset) });
        if (!add_patch.readLine(&choice)) return null;
        if (util.eql(choice.items, "?")) {
            promptHelpCmd(singleton);
            continue;
        }
        if (!singleton and choice.items.len == 0) break;
        const nr = parseChoice(stuff, singleton, choice.items, chosen);
        if (singleton and nr != 0) break;
    }
    var result: std.ArrayList(usize) = .empty;
    for (chosen, 0..) |c, i| {
        if (c != 0) result.append(gpa, i) catch util.oom();
    }
    return result.items;
}

fn removeEmpty() void {
    var j: usize = 0;
    for (g_del.items) |s| {
        if (s.len == 0) continue;
        g_del.items[j] = s;
        j += 1;
    }
    g_del.items.len = j;
}

fn filterByPatternsCmd() void {
    var changed: i64 = -1;
    var confirm: util.Buf = .empty;
    while (g_del.items.len > 0) {
        if (changed != 0) prettyPrintDels();
        printColor(.prompt);
        util.out("Input ignore patterns>> ");
        printColor(.reset);
        if (!add_patch.readLine(&confirm)) util.out("\n");
        if (confirm.items.len == 0) break;

        var d = dir_mod.Dir.init();
        d.idx = g_idx;
        const pl = d.addPatternList(dir_mod.EXC_CMDL, "manual exclude");
        var it = std.mem.splitScalar(u8, confirm.items, ' ');
        while (it.next()) |piece| {
            const p = std.mem.trim(u8, piece, " \t\n\r\x0b\x0c");
            if (p.len == 0) continue;
            d.addPatternSrcpos(pl, p, 0);
        }
        changed = 0;
        for (g_del.items) |*item| {
            var dtype: u8 = dir_mod.DT_UNKNOWN;
            if (d.isExcluded(item.*, &dtype)) {
                item.* = "";
                changed += 1;
            }
        }
        if (changed != 0) {
            removeEmpty();
        } else {
            printColor(.err);
            util.outf("WARNING: Cannot find items matched by: {s}\n", .{confirm.items});
            printColor(.reset);
        }
    }
}

fn selectByNumbersCmd() void {
    const chosen = listAndChoose(null, "Select items to delete", false, .{ .strings = g_del.items }) orelse &[_]usize{};
    var j: usize = 0;
    for (g_del.items, 0..) |*item, i| {
        if (j < chosen.len and chosen[j] == i) {
            j += 1;
        } else item.* = "";
    }
    removeEmpty();
}

fn askEachCmd() void {
    var confirm: util.Buf = .empty;
    var eof = false;
    for (g_del.items) |*item| {
        if (!eof) {
            util.outf("Remove {s} [y/N]? ", .{util.cquote(item.*)});
            if (!add_patch.readLine(&confirm)) {
                util.out("\n");
                eof = true;
            }
        }
        if (!prefixMatchIcase(confirm.items, "yes") or confirm.items.len == 0) item.* = "";
    }
    removeEmpty();
}

fn quitCmd() void {
    g_del.clearRetainingCapacity();
    util.out("Bye.\n");
}

fn helpCmd() void {
    printColor(.help);
    util.out("clean               - start cleaning\n" ++
        "filter by pattern   - exclude items from deletion\n" ++
        "select by numbers   - select items to be deleted by numbers\n" ++
        "ask each            - confirm each deletion (like \"rm -i\")\n" ++
        "quit                - stop cleaning\n" ++
        "help                - this screen\n" ++
        "?                   - help for prompt selection\n");
    printColor(.reset);
}

fn interactiveMainLoop(del: *std.ArrayList([]const u8), idx: *index_mod.Index) void {
    g_del = del;
    g_idx = idx;
    initInteractiveConfig();
    const menus = [_]MenuItem{
        .{ .hotkey = 'c', .title = "clean" },
        .{ .hotkey = 'f', .title = "filter by pattern" },
        .{ .hotkey = 's', .title = "select by numbers" },
        .{ .hotkey = 'a', .title = "ask each" },
        .{ .hotkey = 'q', .title = "quit" },
        .{ .hotkey = 'h', .title = "help" },
    };
    while (del.items.len > 0) {
        printColor(.header);
        util.out(if (del.items.len == 1) "Would remove the following item:\n" else "Would remove the following items:\n");
        printColor(.reset);
        prettyPrintDels();
        const chosen = listAndChoose("*** Commands ***", "What now", true, .{ .menu = &menus }) orelse {
            quitCmd();
            break;
        };
        switch (chosen[0]) {
            0 => break,
            1 => filterByPatternsCmd(),
            2 => selectByNumbersCmd(),
            3 => {
                askEachCmd();
                break;
            },
            4 => {
                quitCmd();
                break;
            },
            else => helpCmd(),
        }
        if (del.items.len == 0) {
            printColor(.err);
            util.out("No more files to clean, exiting.\n");
            printColor(.reset);
            break;
        }
    }
}
