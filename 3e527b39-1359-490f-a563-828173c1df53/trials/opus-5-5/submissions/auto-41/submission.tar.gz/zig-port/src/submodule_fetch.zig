//! Recursive fetching of submodules (submodule.c fetch_submodules() and
//! friends), used by `git fetch --recurse-submodules`.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const config = @import("config.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const refs = @import("refs.zig");
const objects = @import("objects.zig");
const revision = @import("revision.zig");
const revparse = @import("revparse.zig");
const treediff = @import("treediff.zig");
const diff = @import("diff.zig");
const pathspec_mod = @import("pathspec.zig");
const h = @import("cmd/submodule.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

pub const Recurse = enum { err, none, on_demand, off, default, on };

fn parseFetchRecurse(opt: []const u8, arg: ?[]const u8, die_on_error: bool) Recurse {
    return switch (config.parseMaybeBool(arg)) {
        1 => .on,
        0 => .off,
        else => {
            if (util.eql(arg.?, "on-demand")) return .on_demand;
            if (die_on_error) util.die("bad {s} argument: {s}", .{ opt, arg.? });
            return .err;
        },
    };
}

/// parse_fetch_recurse_submodules_arg()
pub fn parseFetchRecurseArg(opt: []const u8, arg: ?[]const u8) Recurse {
    return parseFetchRecurse(opt, arg, true);
}

/// parse_submodule_fetchjobs()
pub fn parseFetchJobs(key: []const u8, value: ?[]const u8) i32 {
    const v = value orelse util.die("missing value for '{s}'", .{key});
    const n = config.parseInt(v) orelse util.die("bad numeric config value '{s}' for '{s}': invalid unit", .{ v, key });
    if (n < 0) util.die("negative values not allowed for submodule.fetchJobs", .{});
    if (n == 0) return @intCast(std.Thread.getCpuCount() catch 1);
    return @intCast(@min(n, std.math.maxInt(i32)));
}

// ---------------------------------------------------------------------------
// .gitmodules lookups by treeish (submodule-config.c subset)

const SubCfg = struct {
    name: []const u8,
    path: ?[]const u8 = null,
    fetch_recurse: Recurse = .none,
};

const GmCache = struct {
    subs: std.ArrayList(*SubCfg) = .empty,
    /// submodules in the order their path was (last) set
    paths: std.ArrayList(*SubCfg) = .empty,

    fn byName(self: *GmCache, name: []const u8) ?*SubCfg {
        for (self.subs.items) |s| {
            if (util.eql(s.name, name)) return s;
        }
        return null;
    }

    fn byPath(self: *GmCache, path: ?[]const u8) ?*SubCfg {
        var i = self.paths.items.len;
        while (i > 0) {
            i -= 1;
            const s = self.paths.items[i];
            const want = path orelse return s;
            if (s.path) |p| {
                if (util.eql(p, want)) return s;
            }
        }
        return null;
    }
};

var worktree_cache: ?*GmCache = null;
var tree_caches: std.AutoHashMapUnmanaged(Oid, *GmCache) = .empty;

fn parseInto(c: *GmCache, cf: *const config.Config, die_on_error: bool) void {
    for (cf.entries.items) |e| {
        const rest = util.skipPrefix(e.key, "submodule.") orelse continue;
        const dot = std.mem.lastIndexOfScalar(u8, rest, '.') orelse continue;
        const name = rest[0..dot];
        const item = rest[dot + 1 ..];
        if (!h.checkSubmoduleName(name)) {
            util.warn("ignoring suspicious submodule name: {s}", .{name});
            continue;
        }
        const sub = c.byName(name) orelse blk: {
            const s = gpa.create(SubCfg) catch util.oom();
            s.* = .{ .name = util.dupe(name) };
            c.subs.append(gpa, s) catch util.oom();
            break :blk s;
        };
        if (util.eql(item, "path")) {
            const v = e.value orelse continue;
            if (v.len > 0 and v[0] == '-') continue;
            var i: usize = 0;
            while (i < c.paths.items.len) {
                if (c.paths.items[i] == sub) {
                    _ = c.paths.orderedRemove(i);
                } else i += 1;
            }
            sub.path = v;
            c.paths.append(gpa, sub) catch util.oom();
        } else if (util.eql(item, "fetchrecursesubmodules")) {
            sub.fetch_recurse = parseFetchRecurse(e.key, e.value, die_on_error);
        }
    }
}

fn gitmodulesUnmerged(idx: *index_mod.Index) bool {
    for (idx.entries.items) |*e| {
        if (e.removed) continue;
        if (util.eql(e.path, ".gitmodules") and e.stage() != 0) return true;
    }
    return false;
}

/// config_from_gitmodules(): the worktree .gitmodules, else the index or
/// HEAD version.
fn readWorktreeGitmodules(cf: *config.Config) bool {
    const r = repo_mod.repo();
    const wt = r.work_tree orelse return false;
    const idx = index_mod.get();
    if (gitmodulesUnmerged(idx)) return false;
    const file = util.concat(&.{ wt, "/.gitmodules" });
    if (os.lstatPath(file) != null) return config.readFileInto(cf, file, .local);
    var oid: ?Oid = null;
    if (idx.get(".gitmodules")) |e| {
        if (e.stage() == 0 and !e.removed) oid = e.oid;
    }
    if (oid == null) oid = revparse.getOid("HEAD:.gitmodules");
    const o = oid orelse return false;
    const obj = r.odb().read(o) orelse return false;
    return config.readBlobInto(cf, obj.data, ".gitmodules", .local);
}

fn cacheFor(treeish: ?Oid) *GmCache {
    if (treeish) |t| {
        if (tree_caches.get(t)) |c| return c;
        const c = gpa.create(GmCache) catch util.oom();
        c.* = .{};
        tree_caches.put(gpa, t, c) catch util.oom();
        const blob = revparse.getOid(util.concat(&.{ &hash.hex(t), ":.gitmodules" })) orelse return c;
        const obj = repo_mod.repo().odb().read(blob) orelse return c;
        var cf: config.Config = .{};
        _ = config.readBlobInto(&cf, obj.data, ".gitmodules", .local);
        parseInto(c, &cf, false);
        return c;
    }
    if (worktree_cache) |c| return c;
    const c = gpa.create(GmCache) catch util.oom();
    c.* = .{};
    worktree_cache = c;
    var cf: config.Config = .{};
    if (readWorktreeGitmodules(&cf)) parseInto(c, &cf, true);
    return c;
}

/// fetch_config_from_gitmodules(): submodule.fetchJobs and
/// fetch.recurseSubmodules from .gitmodules.
pub fn fetchConfigFromGitmodules(max_children: ?*i32, recurse: ?*Recurse) void {
    var cf: config.Config = .{};
    if (!readWorktreeGitmodules(&cf)) return;
    for (cf.entries.items) |e| {
        if (util.eql(e.key, "submodule.fetchjobs")) {
            if (max_children) |m| m.* = parseFetchJobs(e.key, e.value);
        } else if (util.eql(e.key, "fetch.recursesubmodules")) {
            if (recurse) |r| r.* = parseFetchRecurseArg(e.key, e.value);
        }
    }
}

/// default_name_or_path()
fn defaultNameOrPath(path: []const u8) ?[]const u8 {
    if (!@import("submodule.zig").isPopulatedGently(worktreePath(path), true)) return null;
    return path;
}

fn worktreePath(path: []const u8) []const u8 {
    const wt = repo_mod.repo().work_tree orelse return path;
    return util.concat(&.{ wt, "/", path });
}

/// is_tree_submodule_active()
fn isTreeSubmoduleActive(treeish: ?Oid, path: []const u8) bool {
    const sub = cacheFor(treeish).byPath(path) orelse return false;
    const cfg = &repo_mod.cfg;
    const key = util.concat(&.{ "submodule.", sub.name, ".active" });
    if (cfg.getEntry(key)) |e| return config.configBool(e.key, e.value);
    const pats = cfg.getAll("submodule.active");
    if (pats.len > 0) {
        const ps = pathspec_mod.parse("", pats, .{});
        return ps.matches(path, true);
    }
    return cfg.get(util.concat(&.{ "submodule.", sub.name, ".url" })) != null;
}

/// repo_submodule_init(): the submodule's gitdir (absolute), or null.
fn submoduleGitdir(path: []const u8, treeish: ?Oid) ?[]const u8 {
    const dotgit = worktreePath(util.concat(&.{ path, "/.git" }));
    if (repo_mod.isGitDirectory(dotgit)) return os.realPath(dotgit) orelse dotgit;
    var e: repo_mod.GitfileErr = .none;
    if (repo_mod.readGitfileGently(dotgit, &e)) |gd| return gd;
    const sub = cacheFor(treeish).byPath(path) orelse return null;
    const gd = h.nameToGitdir(sub.name);
    if (!repo_mod.isGitDirectory(gd)) return null;
    return os.realPath(gd) orelse gd;
}

// ---------------------------------------------------------------------------
// changed submodule collection

const Changed = struct {
    name: []const u8,
    super_oid: Oid,
    path: []const u8,
    new_commits: std.ArrayList(Oid) = .empty,
};

var ref_tips_before: std.ArrayList(Oid) = .empty;
var ref_tips_after: std.ArrayList(Oid) = .empty;
var initialized_tips = false;

/// check_for_new_submodule_commits()
pub fn checkForNewSubmoduleCommits(oid: Oid) void {
    if (!initialized_tips) {
        for (refs.iterate("refs/", .{})) |r| ref_tips_before.append(gpa, r.oid) catch util.oom();
        initialized_tips = true;
    }
    ref_tips_after.append(gpa, oid) catch util.oom();
}

fn uniqueSorted(list: []const Oid) []Oid {
    const out = gpa.dupe(Oid, list) catch util.oom();
    std.mem.sort(Oid, out, {}, struct {
        fn lt(_: void, a: Oid, b: Oid) bool {
            return std.mem.order(u8, &a, &b) == .lt;
        }
    }.lt);
    var n: usize = 0;
    for (out) |o| {
        if (n > 0 and std.mem.eql(u8, &out[n - 1], &o)) continue;
        out[n] = o;
        n += 1;
    }
    return out[0..n];
}

const CollectCtx = struct {
    changed: *std.ArrayList(*Changed),
    commit_oid: Oid,
};

fn lookupChanged(list: []*Changed, name: []const u8) ?*Changed {
    for (list) |c| {
        if (util.eql(c.name, name)) return c;
    }
    return null;
}

fn collectCb(ctx_: ?*anyopaque, opt: *diff.DiffOptions, p: *treediff.CombinePath) bool {
    _ = opt;
    const ctx: *CollectCtx = @ptrCast(@alignCast(ctx_.?));
    if (p.mode & 0o170000 != 0o160000) return false;
    const cache = cacheFor(ctx.commit_oid);
    var name: ?[]const u8 = null;
    if (cache.byPath(p.path)) |s| {
        name = s.name;
    } else {
        name = defaultNameOrPath(p.path);
        if (name) |n| {
            if (cache.byName(n) != null) {
                util.warn("Submodule in commit {s} at path: '{s}' collides with a submodule named the same. Skipping it.", .{ hash.hex(ctx.commit_oid), p.path });
                name = null;
            }
        }
    }
    const n = name orelse return false;
    const cs = lookupChanged(ctx.changed.items, n) orelse blk: {
        const c = gpa.create(Changed) catch util.oom();
        c.* = .{ .name = util.dupe(n), .super_oid = ctx.commit_oid, .path = util.dupe(p.path) };
        ctx.changed.append(gpa, c) catch util.oom();
        break :blk c;
    };
    cs.new_commits.append(gpa, p.oid) catch util.oom();
    return false;
}

/// collect_changed_submodules()
fn collectChangedSubmodules(changed: *std.ArrayList(*Changed), argv: []const []const u8) void {
    var revs = revision.RevInfo.init("");
    _ = revision.setupRevisions(&revs, argv, .{ .assume_dashdash = true });
    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    while (revision.getRevision(&revs)) |commit| {
        var parents: std.ArrayList(?Oid) = .empty;
        var pl = commit.parents;
        while (pl) |l| : (pl = l.next) parents.append(gpa, l.item.obj.oid) catch util.oom();
        var dopt = diff.DiffOptions.initBasic();
        dopt.flags.recursive = true;
        dopt.output_format = diff.FMT_NO_OUTPUT;
        dopt.setupDone();
        var ctx = CollectCtx{ .changed = changed, .commit_oid = commit.obj.oid };
        _ = treediff.diffTreePaths(commit.obj.oid, parents.items, "", &dopt, collectCb, &ctx);
    }
    revision.resetRevisionWalk();
}

/// submodule_has_commits()
fn submoduleHasCommits(path: []const u8, commits: []const Oid) bool {
    h.validatePathOrExit(path);
    const uniq = uniqueSorted(commits);
    const gd = submoduleGitdir(path, null) orelse return false;
    var in: util.Buf = .empty;
    for (uniq) |o| util.bufPrint(&in, "{s}\n", .{hash.hex(o)});
    const r = h.git(&.{ "cat-file", "--batch-check=%(objectname) %(objecttype)" }, .{
        .cwd = gd,
        .set_git_dir = false,
        .extra_env = &.{.{ "GIT_DIR", "." }},
        .capture = true,
        .stdin_data = in.items,
    });
    var result = true;
    var lines = std.mem.splitScalar(u8, r.stdout, '\n');
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        const sp = std.mem.indexOfScalar(u8, line, ' ') orelse continue;
        const typ = line[sp + 1 ..];
        if (util.eql(typ, "commit")) continue;
        if (util.eql(typ, "missing") or util.eql(typ, "ambiguous")) {
            result = false;
            continue;
        }
        util.die("submodule entry '{s}' ({s}) is a {s}, not a commit", .{ path, line[0..sp], typ });
    }
    if (!h.ok(r)) result = false;
    if (result) {
        var args: std.ArrayList([]const u8) = .empty;
        args.appendSlice(gpa, &.{ "rev-list", "-n", "1" }) catch util.oom();
        for (uniq) |o| args.append(gpa, util.dupe(&hash.hex(o))) catch util.oom();
        args.appendSlice(gpa, &.{ "--not", "--all" }) catch util.oom();
        const wp = worktreePath(path);
        if (os.statPath(wp) == null) return false;
        const rl = h.git(args.items, .{ .cwd = wp, .capture = true, .no_stdin = true });
        if (!h.ok(rl) or rl.stdout.len > 0) result = false;
    }
    return result;
}

/// calculate_changed_submodule_paths()
fn calculateChangedSubmodulePaths(changed: *std.ArrayList(*Changed)) void {
    defer {
        ref_tips_before = .empty;
        ref_tips_after = .empty;
        initialized_tips = false;
    }
    const modules = repo_mod.repo().gitPath("modules/");
    const has_absorbed = os.exists(modules) and !h.isEmptyDir(modules);
    if (cacheFor(null).byPath(null) == null and !has_absorbed) return;

    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "--") catch util.oom();
    for (uniqueSorted(ref_tips_after.items)) |o| argv.append(gpa, util.dupe(&hash.hex(o))) catch util.oom();
    argv.append(gpa, "--not") catch util.oom();
    for (uniqueSorted(ref_tips_before.items)) |o| argv.append(gpa, util.dupe(&hash.hex(o))) catch util.oom();

    collectChangedSubmodules(changed, argv.items);

    var keep: std.ArrayList(*Changed) = .empty;
    for (changed.items) |cs| {
        const path = if (cacheFor(null).byName(cs.name)) |s| s.path else defaultNameOrPath(cs.name);
        if (path) |p| {
            if (submoduleHasCommits(p, cs.new_commits.items)) continue;
        }
        keep.append(gpa, cs) catch util.oom();
    }
    changed.* = keep;
}

// ---------------------------------------------------------------------------
// the fetch loop (run sequentially, like run_processes_parallel with one job)

const Task = struct {
    gitdir: []const u8,
    name: []const u8,
    path: []const u8,
    default_argv: []const u8 = "",
    commits: ?*std.ArrayList(Oid) = null,
};

const Spf = struct {
    args: std.ArrayList([]const u8) = .empty,
    command_line_option: Recurse,
    default_option: Recurse,
    quiet: bool,
    prefix: []const u8,
    result: u8 = 0,
    changed: std.ArrayList(*Changed) = .empty,
    seen: std.StringHashMapUnmanaged(void) = .empty,
    oid_tasks: std.ArrayList(*Task) = .empty,
    errors: util.Buf = .empty,
};

/// get_fetch_recurse_config()
fn getFetchRecurseConfig(name: []const u8, fetch_recurse: Recurse, spf: *Spf) Recurse {
    if (spf.command_line_option != .default) return spf.command_line_option;
    var fr = fetch_recurse;
    const key = util.concat(&.{ "submodule.", name, ".fetchRecurseSubmodules" });
    if (repo_mod.cfg.getEntry(key)) |e| {
        if (e.value) |v| fr = parseFetchRecurseArg(key, v);
    }
    if (fr != .none) return fr;
    return spf.default_option;
}

/// fetch_task_create(); returns null when the submodule is skipped. A task
/// whose gitdir is "" means the submodule repository could not be opened.
fn taskCreate(spf: *Spf, path: []const u8, treeish: ?Oid) ?*Task {
    h.validatePathOrExit(path);
    var name: []const u8 = undefined;
    var fetch_recurse: Recurse = .off;
    var sub_path: []const u8 = path;
    if (cacheFor(treeish).byPath(path)) |s| {
        name = s.name;
        fetch_recurse = s.fetch_recurse;
        sub_path = s.path orelse path;
    } else {
        // no .gitmodules entry: a plain repository at a gitlink
        name = defaultNameOrPath(path) orelse return null;
    }
    if (spf.seen.contains(name)) return null;
    var default_argv: []const u8 = undefined;
    switch (getFetchRecurseConfig(name, fetch_recurse, spf)) {
        .on => default_argv = "yes",
        .off => return null,
        else => {
            if (lookupChanged(spf.changed.items, name) == null) return null;
            default_argv = "on-demand";
        },
    }
    const t = gpa.create(Task) catch util.oom();
    t.* = .{ .gitdir = submoduleGitdir(path, treeish) orelse "", .name = name, .path = sub_path, .default_argv = default_argv };
    return t;
}

fn runTask(spf: *Spf, t: *Task, pre: []const []const u8, tail: []const []const u8) void {
    var args: std.ArrayList([]const u8) = .empty;
    args.appendSlice(gpa, pre) catch util.oom();
    args.appendSlice(gpa, spf.args.items) catch util.oom();
    args.appendSlice(gpa, tail) catch util.oom();
    const r = h.git(args.items, .{
        .cwd = t.gitdir,
        .set_git_dir = false,
        .extra_env = &.{.{ "GIT_DIR", "." }},
        .stdout_to_stderr = true,
    });
    fetchFinish(spf, t, if (h.ok(r)) 0 else 1);
}

fn commitInSub(gitdir: []const u8, commits: []const Oid) []bool {
    var in: util.Buf = .empty;
    for (commits) |o| util.bufPrint(&in, "{s}\n", .{hash.hex(o)});
    const r = h.git(&.{ "cat-file", "--batch-check=%(objecttype)" }, .{
        .cwd = gitdir,
        .set_git_dir = false,
        .extra_env = &.{.{ "GIT_DIR", "." }},
        .capture = true,
        .stdin_data = in.items,
    });
    const out = gpa.alloc(bool, commits.len) catch util.oom();
    @memset(out, false);
    var lines = std.mem.splitScalar(u8, r.stdout, '\n');
    var i: usize = 0;
    while (lines.next()) |line| : (i += 1) {
        if (i >= out.len) break;
        out[i] = util.eql(line, "commit");
    }
    return out;
}

/// fetch_finish()
fn fetchFinish(spf: *Spf, t: *Task, retvalue: u8) void {
    if (retvalue != 0) {
        spf.result = 1;
        util.bufPrint(&spf.errors, "\t{s}\n", .{t.name});
    }
    if (t.commits != null) return;
    const cs = lookupChanged(spf.changed.items, t.name) orelse return;
    const have = commitInSub(t.gitdir, cs.new_commits.items);
    var n: usize = 0;
    for (cs.new_commits.items, 0..) |o, i| {
        if (have[i]) continue;
        cs.new_commits.items[n] = o;
        n += 1;
    }
    cs.new_commits.items.len = n;
    if (n > 0) {
        t.commits = &cs.new_commits;
        spf.oid_tasks.append(gpa, t) catch util.oom();
    }
}

fn prefixArg(spf: *const Spf, path: []const u8) []const u8 {
    return util.concat(&.{ "--submodule-prefix=", spf.prefix, path, "/" });
}

/// fetch_submodules()
pub fn fetchSubmodules(options: []const []const u8, prefix: []const u8, command_line_option: Recurse, default_option: Recurse, quiet: bool) u8 {
    var spf = Spf{ .command_line_option = command_line_option, .default_option = default_option, .quiet = quiet, .prefix = prefix };
    const wt = repo_mod.repo().work_tree orelse return 0;
    const idx = index_mod.get();
    spf.args.append(gpa, "fetch") catch util.oom();
    spf.args.appendSlice(gpa, options) catch util.oom();
    spf.args.append(gpa, "--recurse-submodules-default") catch util.oom();

    calculateChangedSubmodulePaths(&spf.changed);
    std.mem.sort(*Changed, spf.changed.items, {}, struct {
        fn lt(_: void, a: *Changed, b: *Changed) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);

    // submodules in the index
    for (idx.entries.items) |*ce| {
        if (ce.removed) continue;
        if (ce.mode & 0o170000 != 0o160000) continue;
        const t = taskCreate(&spf, ce.path, null) orelse continue;
        if (t.gitdir.len == 0) {
            if (!h.isEmptyDir(util.concat(&.{ wt, "/", ce.path, "/" }))) {
                spf.result = 1;
                util.eprint("Could not access submodule '{s}'\n", .{ce.path});
            }
            continue;
        }
        if (!spf.quiet) util.eprint("Fetching submodule {s}{s}\n", .{ spf.prefix, ce.path });
        spf.seen.put(gpa, t.name, {}) catch util.oom();
        runTask(&spf, t, &.{}, &.{ t.default_argv, prefixArg(&spf, t.path) });
    }

    // submodules changed by the fetched superproject commits
    var i: usize = 0;
    while (i < spf.changed.items.len) : (i += 1) {
        const cs = spf.changed.items[i];
        if (!isTreeSubmoduleActive(cs.super_oid, cs.path)) continue;
        const t = taskCreate(&spf, cs.path, cs.super_oid) orelse continue;
        const ab = revparse.abbrev(cs.super_oid, revparse.defaultAbbrev());
        if (t.gitdir.len == 0) {
            util.eprint("Could not access submodule '{s}' at commit {s}\n", .{ cs.path, ab });
            continue;
        }
        if (!spf.quiet) util.eprint("Fetching submodule {s}{s} at commit {s}\n", .{ spf.prefix, t.path, ab });
        spf.seen.put(gpa, t.name, {}) catch util.oom();
        runTask(&spf, t, &.{"--work-tree=."}, &.{ t.default_argv, prefixArg(&spf, t.path) });
    }

    // second pass: fetch commits that are still missing by oid
    while (spf.oid_tasks.pop()) |t| {
        var tail: std.ArrayList([]const u8) = .empty;
        tail.appendSlice(gpa, &.{ "on-demand", prefixArg(&spf, t.path) }) catch util.oom();
        const rr = h.git(&.{ "submodule--helper", "get-default-remote", t.path }, .{ .sub_env = false, .capture = true, .cwd = wt });
        if (h.ok(rr)) {
            tail.append(gpa, std.mem.trimEnd(u8, rr.stdout, "\n")) catch util.oom();
        } else tail.append(gpa, "origin") catch util.oom();
        for (uniqueSorted(t.commits.?.items)) |o| tail.append(gpa, util.dupe(&hash.hex(o))) catch util.oom();
        runTask(&spf, t, &.{}, tail.items);
    }

    if (spf.errors.items.len > 0) util.eprint("Errors during submodule fetch:\n{s}", .{spf.errors.items});
    return spf.result;
}

// ---------------------------------------------------------------------------
// push --recurse-submodules (submodule.c find/push_unpushed_submodules)

pub const PushRecurse = enum { default, off, check, on_demand, only };

/// parse_push_recurse_submodules_arg()
pub fn parsePushRecurseArg(opt: []const u8, arg: ?[]const u8) PushRecurse {
    return switch (config.parseMaybeBool(arg)) {
        1 => util.die("bad {s} argument: {s}", .{ opt, arg orelse "" }),
        0 => .off,
        else => {
            const a = arg orelse util.die("bad {s} argument: {s}", .{ opt, "" });
            if (util.eql(a, "on-demand")) return .on_demand;
            if (util.eql(a, "check")) return .check;
            if (util.eql(a, "only")) return .only;
            util.die("bad {s} argument: {s}", .{ opt, a });
        },
    };
}

/// for_each_remote_ref_submodule(path, has_remote) > 0
fn submoduleHasRemoteRefs(path: []const u8) bool {
    const wp = worktreePath(path);
    if (os.statPath(wp) == null) return false;
    const r = h.git(&.{ "for-each-ref", "--count=1", "--format=%(refname)", "refs/remotes/" }, .{ .cwd = wp, .capture = true, .no_stdin = true, .no_stderr = true });
    return h.ok(r) and r.stdout.len > 0;
}

/// submodule_needs_pushing()
fn submoduleNeedsPushing(path: []const u8, commits: []const Oid) bool {
    if (!submoduleHasCommits(path, commits)) return false;
    if (!submoduleHasRemoteRefs(path)) return false;
    var args: std.ArrayList([]const u8) = .empty;
    args.append(gpa, "rev-list") catch util.oom();
    for (uniqueSorted(commits)) |o| args.append(gpa, util.dupe(&hash.hex(o))) catch util.oom();
    args.appendSlice(gpa, &.{ "--not", "--remotes", "-n", "1" }) catch util.oom();
    const r = h.git(args.items, .{ .cwd = worktreePath(path), .capture = true, .no_stdin = true });
    if (r.signaled) util.die("Could not run 'git rev-list <commits> --not --remotes -n 1' command in submodule {s}", .{path});
    return r.stdout.len > 0;
}

/// find_unpushed_submodules(): sorted, unique paths
pub fn findUnpushedSubmodules(commits: []const Oid, remote_name: []const u8) [][]const u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, "--") catch util.oom();
    for (uniqueSorted(commits)) |o| argv.append(gpa, util.dupe(&hash.hex(o))) catch util.oom();
    argv.append(gpa, "--not") catch util.oom();
    argv.append(gpa, util.concat(&.{ "--remotes=", remote_name })) catch util.oom();
    var changed: std.ArrayList(*Changed) = .empty;
    collectChangedSubmodules(&changed, argv.items);
    var out: std.ArrayList([]const u8) = .empty;
    for (changed.items) |cs| {
        const path = if (cacheFor(null).byName(cs.name)) |s| (s.path orelse continue) else (defaultNameOrPath(cs.name) orelse continue);
        if (!submoduleNeedsPushing(path, cs.new_commits.items)) continue;
        var dup = false;
        for (out.items) |p| {
            if (util.eql(p, path)) dup = true;
        }
        if (!dup) out.append(gpa, path) catch util.oom();
    }
    util.sortStrings(out.items);
    return out.items;
}

/// die_with_unpushed_submodules()
pub fn dieWithUnpushedSubmodules(paths: []const []const u8) noreturn {
    util.eprint("The following submodule paths contain changes that can\nnot be found on any remote:\n", .{});
    for (paths) |p| util.eprint("  {s}\n", .{p});
    util.eprint("\nPlease try\n\n\tgit push --recurse-submodules=on-demand\n\nor cd to the path and use\n\n\tgit push\n\nto push them to a remote.\n\n", .{});
    util.die("Aborting.", .{});
}

/// push_unpushed_submodules(); `remote_configured` is
/// remote->origin != REMOTE_UNCONFIGURED, `raw_refspecs` the rs->items[].raw.
pub fn pushUnpushedSubmodules(commits: []const Oid, remote_name: []const u8, remote_configured: bool, raw_refspecs: []const []const u8, push_options: []const []const u8, dry_run: bool) bool {
    const needs = findUnpushedSubmodules(commits, remote_name);
    if (needs.len == 0) return true;
    if (remote_configured) {
        const head: []const u8 = refs.headSymref() orelse blk: {
            if (refs.resolve("HEAD") == null) util.die("Failed to resolve HEAD as a valid ref.", .{});
            break :blk "HEAD";
        };
        for (needs) |p| {
            h.validatePathOrExit(p);
            var args: std.ArrayList([]const u8) = .empty;
            args.appendSlice(gpa, &.{ "submodule--helper", "push-check", head, remote_name }) catch util.oom();
            args.appendSlice(gpa, raw_refspecs) catch util.oom();
            const r = h.git(args.items, .{ .cwd = worktreePath(p), .no_stdin = true, .capture = true });
            if (!h.ok(r)) util.die("process for submodule '{s}' failed", .{p});
        }
    }
    var ret = true;
    for (needs) |p| {
        util.eprint("Pushing submodule '{s}'\n", .{p});
        h.validatePathOrExit(p);
        var okp = true;
        if (submoduleHasRemoteRefs(p)) {
            var args: std.ArrayList([]const u8) = .empty;
            args.appendSlice(gpa, &.{ "push", "--recurse-submodules=only-is-on-demand" }) catch util.oom();
            if (dry_run) args.append(gpa, "--dry-run") catch util.oom();
            for (push_options) |o| args.append(gpa, util.concat(&.{ "--push-option=", o })) catch util.oom();
            if (remote_configured) {
                args.append(gpa, remote_name) catch util.oom();
                args.appendSlice(gpa, raw_refspecs) catch util.oom();
            }
            okp = h.ok(h.git(args.items, .{ .cwd = worktreePath(p), .no_stdin = true }));
        }
        if (!okp) {
            util.eprint("Unable to push submodule '{s}'\n", .{p});
            ret = false;
        }
    }
    return ret;
}

/// submodule--helper push-check <superproject-head> <remote> [<refspec>...]
pub fn cmdPushCheck(args: []const []const u8) u8 {
    if (args.len < 3) util.die("submodule--helper push-check requires at least 2 arguments", .{});
    const tp = @import("transport.zig");
    const superproject_head = args[1];
    const sym = refs.headSymref();
    if (sym == null and refs.resolve("HEAD") == null) util.die("Failed to resolve HEAD as a valid ref.", .{});
    const detached = sym == null;
    const head = sym orelse "HEAD";
    const remote = tp.pushremoteGet(args[2]);
    if (remote == null or !(remote.?.from_config or remote.?.configured)) util.die("remote '{s}' not configured", .{args[2]});
    if (args.len > 3) {
        const local_refs = tp.getLocalHeads();
        var rs: tp.Refspec = .{ .fetch = false };
        for (args[3..]) |s| rs.append(s);
        for (rs.items.items) |it| {
            if (it.pattern or it.matching) continue;
            const src = it.src orelse "";
            var m: ?*tp.Ref = null;
            switch (tp.countRefspecMatch(src, local_refs, &m)) {
                1 => {},
                0 => {
                    if (util.eql(src, "HEAD")) {
                        if (!detached and util.eql(head, superproject_head)) continue;
                        util.die("HEAD does not match the named branch in the superproject", .{});
                    }
                    util.die("src refspec '{s}' must name a ref", .{src});
                },
                else => util.die("src refspec '{s}' must name a ref", .{src}),
            }
        }
    }
    return 0;
}
