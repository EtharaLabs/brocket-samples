//! git grep (port of builtin/grep.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const dir_mod = @import("../dir.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const color = @import("../color.zig");
const config = @import("../config.zig");
const commands = @import("../commands.zig");
const main = @import("../main.zig");
const grep = @import("../grep.zig");
const gpa = util.gpa;

const usage = [_][]const u8{"git grep [<options>] [-e] <pattern> [<rev>...] [[--] <path>...]"};

var g: grep.Opt = .{};
var cached = false;
var untracked = false;
var opt_exclude: i32 = -1;
var use_index: i32 = 1;
var recurse_submodules = false;
var pattern_type: i32 = 0;
var quiet: i32 = 0;
var num_threads: i32 = 0;
var dummy = false;
var ext_grep = false;
var show_in_pager: ?[]const u8 = null;
const default_pager: []const u8 = "dummy";
var grep_prefix: []const u8 = "";

fn contextCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        g.pre_context = 0;
        g.post_context = 0;
        return;
    }
    const a = arg orelse "";
    const v = parseLeadingInt(a) orelse {
        util.err("switch `C' expects a numerical value", .{});
        os.exit(129);
    };
    g.pre_context = v;
    g.post_context = v;
}

fn parseLeadingInt(s: []const u8) ?i32 {
    // strtol(): leading whitespace, optional sign, digits; whole string must be consumed
    var i: usize = 0;
    while (i < s.len and std.ascii.isWhitespace(s[i])) i += 1;
    var neg = false;
    if (i < s.len and (s[i] == '+' or s[i] == '-')) {
        neg = s[i] == '-';
        i += 1;
    }
    var v: i64 = 0;
    while (i < s.len and std.ascii.isDigit(s[i])) : (i += 1) {
        v = v * 10 + (s[i] - '0');
        if (v > std.math.maxInt(i32)) v = std.math.maxInt(i32);
    }
    if (i != s.len) return null;
    return @intCast(if (neg) -v else v);
}

fn fileCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse "";
    var filename = a;
    if (a.len > 0 and !util.eql(a, "-") and a[0] != '/' and grep_prefix.len > 0)
        filename = util.concat(&.{ grep_prefix, a });
    const data = if (util.eql(filename, "-"))
        (os.readAllFd(0) catch util.dieErrno("cannot open '{s}'", .{a}))
    else
        (os.readFile(filename) orelse util.dieErrno("cannot open '{s}'", .{a}));
    var lno: u32 = 0;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        var line = line0;
        if (it.index == null and line.len == 0) break;
        if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
        if (line.len == 0) continue;
        lno += 1;
        g.appendPattern(line, a, lno, .pattern);
    }
}

fn patternCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    g.appendPattern(arg orelse "", "-e option", 0, .pattern);
}
fn andCb(_: ?[]const u8, _: bool) void {
    g.appendPattern("--and", "command line", 0, .and_);
}
fn notCb(_: ?[]const u8, _: bool) void {
    g.appendPattern("--not", "command line", 0, .not_);
}
fn openCb(_: ?[]const u8, _: bool) void {
    g.appendPattern("(", "command line", 0, .open_paren);
}
fn closeCb(_: ?[]const u8, _: bool) void {
    g.appendPattern(")", "command line", 0, .close_paren);
}
fn colorCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        g.color = .never;
        return;
    }
    const v = color.configColorBool(null, arg orelse "always");
    if (v == .unknown) {
        util.err("option `color' expects \"always\", \"auto\", or \"never\"", .{});
        os.exit(129);
    }
    g.color = v;
}

const options = [_]po.Opt{
    po.boolean(0, "cached", &cached, "search in index instead of in the work tree"),
    .{ .long = "no-index", .kind = .negbit, .i = &use_index, .val = 1, .help = "find in contents not managed by git" },
    po.boolean(0, "untracked", &untracked, "search in both tracked and untracked files"),
    po.setInt(0, "exclude-standard", &opt_exclude, 1, "ignore files specified via '.gitignore'"),
    po.boolean(0, "recurse-submodules", &recurse_submodules, "recursively search in each submodule"),
    po.group(""),
    po.boolean('v', "invert-match", &g.invert, "show non-matching lines"),
    po.boolean('i', "ignore-case", &g.ignore_case, "case insensitive matching"),
    po.boolean('w', "word-regexp", &g.word_regexp, "match patterns only at word boundaries"),
    po.setInt('a', "text", &g.binary, 2, "process binary files as text"),
    po.setInt('I', "", &g.binary, 1, "don't match patterns in binary files"),
    po.boolean(0, "textconv", &g.allow_textconv, "process binary files with textconv filters"),
    po.setInt('r', "recursive", &g.max_depth, -1, "search in subdirectories (default)"),
    .{ .long = "max-depth", .kind = .int, .i = &g.max_depth, .argh = "depth", .noneg = true, .help = "descend at most <n> levels" },
    po.group(""),
    po.setInt('E', "extended-regexp", &pattern_type, 2, "use extended POSIX regular expressions"),
    po.setInt('G', "basic-regexp", &pattern_type, 1, "use basic POSIX regular expressions (default)"),
    po.setInt('F', "fixed-strings", &pattern_type, 3, "interpret patterns as fixed strings"),
    po.setInt('P', "perl-regexp", &pattern_type, 4, "use Perl-compatible regular expressions"),
    po.group(""),
    po.boolean('n', "line-number", &g.linenum, "show line numbers"),
    po.boolean(0, "column", &g.columnnum, "show column number of first match"),
    .{ .short = 'h', .kind = .negbit, .i = &g.pathname, .val = 1, .help = "don't show filenames" },
    po.bit('H', "", &g.pathname, 1, "show filenames"),
    .{ .long = "full-name", .kind = .negbit, .i = &g.relative, .val = 1, .help = "show filenames relative to top directory" },
    po.boolean('l', "files-with-matches", &g.name_only, "show only filenames instead of matching lines"),
    po.boolean(0, "name-only", &g.name_only, "synonym for --files-with-matches"),
    po.boolean('L', "files-without-match", &g.unmatch_name_only, "show only the names of files without match"),
    po.noComplete(po.boolean('z', "null", &g.null_following_name, "print NUL after filenames")),
    po.boolean('o', "only-matching", &g.only_matching, "show only matching parts of a line"),
    po.boolean('c', "count", &g.count, "show the number of matches instead of matching lines"),
    .{ .long = "color", .kind = .callback, .cb = colorCb, .optarg = true, .def = "always", .argh = "when", .help = "highlight matches" },
    po.boolean(0, "break", &g.file_break, "print empty line between matches from different files"),
    po.boolean(0, "heading", &g.heading, "show filename only once above matches from same file"),
    po.group(""),
    po.callback('C', "context", contextCb, "n", "show <n> context lines before and after matches"),
    .{ .short = 'B', .long = "before-context", .kind = .uint, .i = &g.pre_context, .argh = "n", .help = "show <n> context lines before matches" },
    .{ .short = 'A', .long = "after-context", .kind = .uint, .i = &g.post_context, .argh = "n", .help = "show <n> context lines after matches" },
    po.integer(0, "threads", &num_threads, "n", "use <n> worker threads"),
    .{ .kind = .number, .cb = contextCb, .help = "shortcut for -C NUM" },
    po.boolean('p', "show-function", &g.funcname, "show a line with the function name before matches"),
    po.boolean('W', "function-context", &g.funcbody, "show the surrounding function"),
    po.group(""),
    po.callback('f', "", fileCb, "file", "read patterns from file"),
    .{ .short = 'e', .kind = .callback, .cb = patternCb, .argh = "pattern", .noneg = true, .help = "match <pattern>" },
    .{ .long = "and", .kind = .callback, .cb = andCb, .noarg = true, .noneg = true, .help = "combine patterns specified with -e" },
    .{ .long = "or", .kind = .boolean, .b = &dummy, .noneg = true, .help = "" },
    .{ .long = "not", .kind = .callback, .cb = notCb, .noarg = true, .noneg = true, .help = "" },
    .{ .short = '(', .kind = .callback, .cb = openCb, .noarg = true, .noneg = true, .nodash = true, .help = "" },
    .{ .short = ')', .kind = .callback, .cb = closeCb, .noarg = true, .noneg = true, .nodash = true, .help = "" },
    .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet, .help = "indicate hit with exit status without output" },
    po.boolean(0, "all-match", &g.all_match, "show only matches from files that match all patterns"),
    po.group(""),
    .{ .short = 'O', .long = "open-files-in-pager", .kind = .string, .s = &show_in_pager, .def = default_pager, .optarg = true, .argh = "pager", .help = "show matching files in the pager", .nocomplete = true },
    po.noComplete(po.boolean(0, "ext-grep", &ext_grep, "allow calling of grep(1) (ignored by this build)")),
    po.integer('m', "max-count", &g.max_count, "n", "maximum number of results per file"),
};

fn badConfig(e: config.Entry) noreturn {
    if (e.origin_type == .cmdline or e.origin.len == 0)
        util.die("unable to parse '{s}' from command-line config", .{e.key});
    util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
}

fn setColorSlot(e: config.Entry, slot: []const u8) void {
    for (grep.color_slots, 0..) |name, i| {
        if (std.ascii.eqlIgnoreCase(name, slot)) {
            const v = e.value orelse {
                util.err("missing value for '{s}'", .{e.key});
                badConfig(e);
            };
            g.colors[i] = color.parseColorOrError(v) orelse badConfig(e);
            return;
        }
    }
    badConfig(e);
}

fn readConfig() void {
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        if (util.eql(k, "grep.extendedregexp")) {
            g.extended_regexp_option = config.configBool(k, e.value);
        } else if (util.eql(k, "grep.patterntype")) {
            const v = e.value orelse {
                util.err("missing value for '{s}'", .{k});
                badConfig(e);
            };
            if (util.eql(v, "default")) {
                pattern_type = 0;
            } else if (util.eql(v, "basic")) {
                pattern_type = 1;
            } else if (util.eql(v, "extended")) {
                pattern_type = 2;
            } else if (util.eql(v, "fixed")) {
                pattern_type = 3;
            } else if (util.eql(v, "perl")) {
                pattern_type = 4;
            } else util.die("bad {s} argument: {s}", .{ k, v });
        } else if (util.eql(k, "grep.linenumber")) {
            g.linenum = config.configBool(k, e.value);
        } else if (util.eql(k, "grep.column")) {
            g.columnnum = config.configBool(k, e.value);
        } else if (util.eql(k, "grep.fullname")) {
            g.relative = if (config.configBool(k, e.value)) 0 else 1;
        } else if (util.eql(k, "color.grep")) {
            g.color = color.configColorBool(k, e.value);
        } else if (util.eql(k, "color.grep.match")) {
            setColorSlot(e, "matchContext");
            setColorSlot(e, "matchSelected");
        } else if (util.skipPrefix(k, "color.grep.")) |slot| {
            setColorSlot(e, slot);
        } else if (util.eql(k, "grep.threads")) {
            const kv = e.kvi();
            num_threads = config.configInt(k, e.value, &kv);
            if (num_threads < 0) util.die("invalid number of threads specified ({d}) for {s}", .{ num_threads, k });
        } else if (util.eql(k, "submodule.recurse")) {
            recurse_submodules = config.configBool(k, e.value);
        }
    }
}

fn sourceName(filename: []const u8, tn_len: usize) []const u8 {
    const tn = filename[0..tn_len];
    const rest = filename[tn_len..];
    if (g.null_following_name) {
        if (g.relative != 0 and grep_prefix.len > 0)
            return util.concat(&.{ tn, util.relativePath(rest, grep_prefix) });
        return filename;
    }
    const q = if (g.relative != 0 and grep_prefix.len > 0)
        util.cquote(util.relativePath(rest, grep_prefix))
    else
        util.cquote(rest);
    if (tn_len == 0) return q;
    return util.concat(&.{ tn, q });
}

fn grepOid(oid: hash.Oid, filename: []const u8, tn_len: usize, path: ?[]const u8) bool {
    var gs = grep.Source{ .kind = .oid, .name = sourceName(filename, tn_len), .path = path, .oid = oid };
    return grep.grepSource(&g, &gs);
}

fn grepFile(filename: []const u8) bool {
    var gs = grep.Source{ .kind = .file, .name = sourceName(filename, 0), .path = filename, .file = filename };
    return grep.grepSource(&g, &gs);
}

fn isReg(mode: u32) bool {
    return mode & 0o170000 == 0o100000;
}

/// Per-repository context (the superproject or a submodule) used by
/// grep_cache()/grep_tree()/grep_submodule().
const SubRepo = struct {
    /// submodule_prefix: path of this repository relative to the superproject top ("" for it)
    prefix: []const u8 = "",
    gitdir: []const u8 = "",
    /// worktree relative to the superproject top, null if not populated
    worktree: ?[]const u8 = "",
    cfg: *const config.Config,
    gm: ?*config.Config = null,
    index: ?*index_mod.Index = null,
};

var super_repo: SubRepo = .{ .cfg = &repo_mod.cfg };

fn repoIndex(r: *SubRepo) *index_mod.Index {
    if (r.index) |i| return i;
    if (r.prefix.len == 0) {
        r.index = index_mod.get();
    } else {
        const idx = gpa.create(index_mod.Index) catch util.oom();
        idx.* = .{};
        idx.readFile(util.concat(&.{ r.gitdir, "/index" }));
        r.index = idx;
    }
    return r.index.?;
}

/// config_from_gitmodules(): worktree file, else the index blob, else HEAD:.gitmodules
fn repoGitmodules(r: *SubRepo) *config.Config {
    if (r.gm) |c| return c;
    const c = gpa.create(config.Config) catch util.oom();
    c.* = .{};
    r.gm = c;
    if (r.worktree) |wt| {
        const file = if (wt.len == 0) ".gitmodules" else util.concat(&.{ wt, "/.gitmodules" });
        if (os.exists(file)) {
            _ = config.readFileInto(c, file, .local);
            return c;
        }
    }
    if (repoIndex(r).get(".gitmodules")) |e| {
        if (repo_mod.repo().odb().read(e.oid)) |obj| _ = config.readBlobInto(c, obj.data, ":.gitmodules", .local);
        return c;
    }
    if (r.prefix.len == 0) {
        if (revparse.getOid("HEAD:.gitmodules")) |oid| {
            if (repo_mod.repo().odb().read(oid)) |obj| _ = config.readBlobInto(c, obj.data, "HEAD:.gitmodules", .local);
        }
    }
    return c;
}

/// gitmodules_config_oid(): load .gitmodules of the given commit/tree into the superproject cache
fn loadGitmodulesFromRev(oid: hash.Oid) void {
    const c = gpa.create(config.Config) catch util.oom();
    c.* = .{};
    super_repo.gm = c;
    const tree = objects.peelTo(oid, .tree) orelse return;
    const ents = objects.readTree(tree) orelse return;
    for (ents) |e| {
        if (!util.eql(e.name, ".gitmodules")) continue;
        if (repo_mod.repo().odb().read(e.oid)) |obj| {
            const rev = util.concat(&.{ &hash.hex(oid), ":.gitmodules" });
            _ = config.readBlobInto(c, obj.data, rev, .local);
        }
        return;
    }
}

fn submoduleNameForPath(r: *SubRepo, path: []const u8) ?[]const u8 {
    const c = repoGitmodules(r);
    var found: ?[]const u8 = null;
    for (c.entries.items) |e| {
        const rest = util.skipPrefix(e.key, "submodule.") orelse continue;
        if (!util.endsWith(rest, ".path")) continue;
        const v = e.value orelse continue;
        if (util.eql(v, path)) found = rest[0 .. rest.len - ".path".len];
    }
    return found;
}

/// is_submodule_active()
fn isSubmoduleActive(r: *SubRepo, path: []const u8) bool {
    const name = submoduleNameForPath(r, path) orelse return false;
    if (r.cfg.getEntry(util.concat(&.{ "submodule.", name, ".active" }))) |e| return config.configBool(e.key, e.value);
    const pats = r.cfg.getAll("submodule.active");
    if (pats.len > 0) {
        const ps = pathspec_mod.parse("", pats, .{});
        return ps.matches(path, true);
    }
    return r.cfg.getEntry(util.concat(&.{ "submodule.", name, ".url" })) != null;
}

/// repo_submodule_init()
fn submoduleInit(r: *SubRepo, path: []const u8) ?*SubRepo {
    var gitdir: ?[]const u8 = null;
    var worktree: ?[]const u8 = null;
    if (r.worktree) |wt| {
        const sub_wt = if (wt.len == 0) path else util.concat(&.{ wt, "/", path });
        if (repo_mod.resolveGitdir(util.concat(&.{ sub_wt, "/.git" }))) |gd| {
            gitdir = gd;
            worktree = sub_wt;
        }
    }
    if (gitdir == null) {
        const name = submoduleNameForPath(r, path) orelse return null;
        const common = if (r.prefix.len == 0) repo_mod.repo().common_dir else repo_mod.getCommonDirNoenv(r.gitdir).dir;
        const gd = util.concat(&.{ common, "/modules/", name });
        if (!repo_mod.isGitDirectory(gd)) return null;
        gitdir = gd;
    }
    const cfg = gpa.create(config.Config) catch util.oom();
    cfg.* = .{};
    _ = config.readFileInto(cfg, util.concat(&.{ repo_mod.getCommonDirNoenv(gitdir.?).dir, "/config" }), .local);
    const s = gpa.create(SubRepo) catch util.oom();
    s.* = .{
        .prefix = util.concat(&.{ r.prefix, path, "/" }),
        .gitdir = gitdir.?,
        .worktree = worktree,
        .cfg = cfg,
    };
    return s;
}

/// grep_submodule()
fn grepSubmodule(r: *SubRepo, ps: *const pathspec_mod.Pathspec, oid: ?hash.Oid, filename: []const u8, path: []const u8) bool {
    if (!isSubmoduleActive(r, path)) return false;
    const sub = submoduleInit(r, path) orelse return false;

    // add objects to alternates
    const odb = repo_mod.repo().odb();
    const objdir = util.concat(&.{ repo_mod.getCommonDirNoenv(sub.gitdir).dir, "/objects" });
    const real = os.realPath(objdir) orelse objdir;
    var known = false;
    for (odb.allDirs()) |d| {
        if (util.eql(d, real) or util.eql(d, objdir)) known = true;
    }
    if (!known) {
        odb.alternates.append(gpa, real) catch util.oom();
        odb.reloadPacks();
    }

    if (oid) |o| {
        const typ = odb.readType(o);
        const tree = objects.peelTo(o, .tree) orelse util.die("unable to read tree ({s})", .{&hash.hex(o)});
        var base: util.Buf = .empty;
        util.bufAppend(&base, filename);
        util.bufByte(&base, '/');
        return grepTree(sub, ps, tree, &base, base.items.len, typ == .commit);
    }
    return grepCache(sub, ps);
}

fn grepCache(r: *SubRepo, ps: *const pathspec_mod.Pathspec) bool {
    const idx = repoIndex(r);
    var hit = false;
    const entries = idx.entries.items;
    var nr: usize = 0;
    while (nr < entries.len) : (nr += 1) {
        const ce = &entries[nr];
        if (!cached and ce.skipWorktree()) continue;
        const name = if (r.prefix.len == 0) ce.path else util.concat(&.{ r.prefix, ce.path });
        if (ce.mode == 0o040000 and r.prefix.len == 0) {
            // sparse directory: grep its tree instead of expanding the index
            var base: util.Buf = .empty;
            util.bufAppend(&base, ce.path);
            if (grepTree(r, ps, ce.oid, &base, 0, false)) hit = true;
        } else if (isReg(ce.mode) and ps.matches(name, false)) {
            if (cached or ce.assumeValid()) {
                if (ce.stage() != 0 or ce.intentToAdd()) continue;
                if (grepOid(ce.oid, name, 0, name)) hit = true;
            } else {
                if (grepFile(name)) hit = true;
            }
        } else if (recurse_submodules and ce.mode == 0o160000 and
            ps.matchFlags(name, 0, null, pathspec_mod.DO_MATCH_DIRECTORY | pathspec_mod.DO_MATCH_LEADING_PATHSPEC) != 0)
        {
            if (grepSubmodule(r, ps, null, name, ce.path)) hit = true;
        } else continue;
        if (ce.stage() != 0) {
            const p = ce.path;
            nr += 1;
            while (nr < entries.len and util.eql(p, entries[nr].path)) nr += 1;
            nr -= 1;
        }
        if (hit and g.status_only) break;
    }
    return hit;
}

fn grepTree(r: *SubRepo, ps: *const pathspec_mod.Pathspec, tree_oid: hash.Oid, base: *util.Buf, tn_len: usize, check_attr: bool) bool {
    var hit = false;
    const ents = objects.readTree(tree_oid) orelse util.die("unable to read tree ({s})", .{&hash.hex(tree_oid)});
    const old_len = base.items.len;
    for (ents) |e| {
        util.bufAppend(base, e.name);
        const full = if (r.prefix.len == 0) base.items[tn_len..] else util.concat(&.{ r.prefix, base.items[tn_len..] });
        if (isReg(e.mode)) {
            if (ps.matches(full, false)) {
                const name = util.dupe(base.items);
                if (grepOid(e.oid, name, tn_len, if (check_attr) name[tn_len..] else null)) hit = true;
            }
        } else if (e.isDir()) {
            if (ps.couldMatchUnder(full) or ps.matches(full, true)) {
                util.bufByte(base, '/');
                if (grepTree(r, ps, e.oid, base, tn_len, check_attr)) hit = true;
            }
        } else if (recurse_submodules and e.mode == 0o160000) {
            if (ps.couldMatchUnder(full) or ps.matches(full, true)) {
                const name = util.dupe(base.items);
                if (grepSubmodule(r, ps, e.oid, name, name[tn_len..])) hit = true;
            }
        }
        base.shrinkRetainingCapacity(old_len);
        if (hit and g.status_only) break;
    }
    return hit;
}

const ObjEntry = struct { oid: hash.Oid, name: []const u8, path: ?[]const u8 };

fn grepObject(ps: *const pathspec_mod.Pathspec, oid: hash.Oid, typ: anytype, name: []const u8, path: ?[]const u8) bool {
    switch (typ) {
        .blob => return grepOid(oid, name, 0, path),
        .commit, .tree => {
            const tree = objects.peelTo(oid, .tree) orelse util.die("unable to read tree ({s})", .{&hash.hex(oid)});
            var base: util.Buf = .empty;
            if (name.len > 0) {
                util.bufAppend(&base, name);
                util.bufByte(&base, ':');
            }
            const tn = base.items.len;
            return grepTree(&super_repo, ps, tree, &base, tn, typ == .commit);
        },
        else => util.die("unable to grep from object of type {s}", .{@tagName(typ)}),
    }
}

fn grepObjects(ps: *const pathspec_mod.Pathspec, list: []const ObjEntry) bool {
    var hit = false;
    for (list) |it| {
        const real = objects.peel(it.oid) orelse util.die("invalid object '{s}' given.", .{it.name});
        if (recurse_submodules) loadGitmodulesFromRev(real.oid);
        if (grepObject(ps, real.oid, real.typ, it.name, it.path)) {
            hit = true;
            if (g.status_only) break;
        }
    }
    return hit;
}

fn grepDirectory(ps: *const pathspec_mod.Pathspec, exc_std: bool, with_index: bool) bool {
    var d = dir_mod.Dir.init();
    if (!with_index) d.flags.no_gitlinks = true;
    if (exc_std) d.setupStandardExcludes();
    var empty_index = index_mod.Index{};
    _ = d.fill(&empty_index, ps);
    var hit = false;
    for (d.entries.items) |e| {
        if (grepFile(e.name)) hit = true;
        if (hit and g.status_only) break;
    }
    return hit;
}

fn gitPager() ?[]const u8 {
    const p = os.getenv("GIT_PAGER") orelse repo_mod.cfg.get("core.pager") orelse os.getenv("PAGER") orelse "less";
    if (p.len == 0 or util.eql(p, "cat")) return null;
    return p;
}

fn dieIncompatible3(a: bool, an: []const u8, b: bool, bn: []const u8, c: bool, cn: []const u8) void {
    var names: [3][]const u8 = undefined;
    var n: usize = 0;
    if (a) {
        names[n] = an;
        n += 1;
    }
    if (b) {
        names[n] = bn;
        n += 1;
    }
    if (c) {
        names[n] = cn;
        n += 1;
    }
    if (n == 3) util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ names[0], names[1], names[2] });
    if (n == 2) util.die("options '{s}' and '{s}' cannot be used together", .{ names[0], names[1] });
}

pub fn cmdGrep(args: []const []const u8) u8 {
    if (repo_mod.repo_) |r| grep_prefix = r.prefix;
    readConfig();
    const rest = po.parse(args[1..], &options, &usage, .{ .keep_dashdash = true, .stop_at_non_option = true });
    g.status_only = quiet != 0;
    if (pattern_type != 0) g.pattern_type_option = @enumFromInt(@as(u3, @intCast(pattern_type)));

    if (use_index != 0 and repo_mod.repo_ == null) {
        const fallback = repo_mod.cfg.getBool("grep.fallbacktonoindex") orelse false;
        if (fallback) use_index = 0 else repo_mod.setup(false);
    }
    if (use_index == 0) recurse_submodules = false;
    if (repo_mod.repo_ != null) @import("../sparse_index.zig").commandIsSparseAware();

    var argv = rest;
    if (argv.len > 0 and g.patterns.items.len == 0 and util.eql(argv[0], "--")) argv = argv[1..];
    if (argv.len > 0 and g.patterns.items.len == 0) {
        g.appendPattern(argv[0], "command line", 0, .pattern);
        argv = argv[1..];
    }

    var path_list: std.ArrayList([]const u8) = .empty;
    if (show_in_pager) |sp| {
        if (sp.ptr == default_pager.ptr) show_in_pager = gitPager();
    }
    if (show_in_pager) |sp| {
        g.color = .never;
        g.name_only = true;
        g.null_following_name = true;
        g.collect = &path_list;
        path_list.append(gpa, sp) catch util.oom();
    }
    if (g.patterns.items.len == 0) util.die("no pattern given", .{});
    if (g.invert) g.only_matching = false;

    var seen_dashdash = false;
    for (argv) |a| {
        if (util.eql(a, "--")) {
            seen_dashdash = true;
            break;
        }
    }

    var list: std.ArrayList(ObjEntry) = .empty;
    const allow_revs = use_index != 0 and !untracked;
    var i: usize = 0;
    while (i < argv.len) : (i += 1) {
        const arg = argv[i];
        if (util.eql(arg, "--")) {
            i += 1;
            break;
        }
        if (!allow_revs) {
            if (seen_dashdash) util.die("--no-index or --untracked cannot be used with revs", .{});
            break;
        }
        const res = revparse.resolve(arg, .{ .quiet = true }) orelse {
            if (seen_dashdash) util.die("unable to resolve revision: {s}", .{arg});
            break;
        };
        if (objects.typeOf(res.oid) == null) util.die("unable to parse object: {s}", .{arg});
        if (!seen_dashdash) revparse.verifyNonFilename(grep_prefix, arg);
        list.append(gpa, .{ .oid = res.oid, .name = arg, .path = res.path }) catch util.oom();
    }
    if (!seen_dashdash) {
        var j = i;
        while (j < argv.len) : (j += 1) revparse.verifyFilename(grep_prefix, argv[j], j == i and allow_revs);
    }

    var ps = pathspec_mod.parse(grep_prefix, argv[i..], .{
        .prefer_cwd = true,
        .maxdepth_valid = g.max_depth != -1,
        .no_repository = repo_mod.repo_ == null,
    });
    ps.max_depth = g.max_depth;
    ps.recursive = true;

    if (recurse_submodules and untracked) util.die("--untracked not supported with --recurse-submodules", .{});

    if (g.max_count == 0) return 1;

    if (show_in_pager != null) {
        if (num_threads > 1) util.warn("invalid option combination, ignoring --threads", .{});
        num_threads = 1;
    } else if (num_threads < 0) util.die("invalid number of threads specified ({d})", .{num_threads});

    grep.compilePatterns(&g);

    if (show_in_pager != null and (cached or list.items.len > 0))
        util.die("--open-files-in-pager only works on the worktree", .{});
    if (show_in_pager != null and g.patterns.items.len == 1) {
        var pager = path_list.items[0];
        if (pager.len > 4 and pager[pager.len - 5] == '/') pager = pager[pager.len - 4 ..];
        if (g.ignore_case and util.eql(pager, "less")) path_list.append(gpa, "-I") catch util.oom();
        if (util.eql(pager, "less") or util.eql(pager, "vi")) {
            path_list.append(gpa, util.fmt("+/{s}{s}", .{ if (util.eql(pager, "less")) "*" else "", g.patterns.items[0].pattern })) catch util.oom();
        }
    }

    if (show_in_pager == null and !g.status_only) {
        if (main.use_pager == null and (repo_mod.cfg.getBool("pager.grep") orelse true)) commands.setupPager();
    }

    // want_color(): GIT_COLOR_UNKNOWN falls back to color.ui
    var cb = g.color;
    if (cb == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| cb = color.configColorBool("color.ui", e.value);
    }
    g.use_color = color.wantColorBool(cb, null);

    dieIncompatible3(use_index == 0, "--no-index", untracked, "--untracked", cached, "--cached");

    var hit = false;
    if (use_index == 0 or untracked) {
        const use_exclude = if (opt_exclude < 0) use_index != 0 else opt_exclude != 0;
        hit = grepDirectory(&ps, use_exclude, use_index != 0);
    } else if (opt_exclude >= 0) {
        util.die("--[no-]exclude-standard cannot be used for tracked contents", .{});
    } else if (list.items.len == 0) {
        if (!cached) _ = repo_mod.requireWorkTree("grep");
        hit = grepCache(&super_repo, &ps);
    } else {
        if (cached) util.die("both --cached and trees are given", .{});
        hit = grepObjects(&ps, list.items);
    }

    if (hit and show_in_pager != null) {
        const r = os.run(path_list.items, .{ .use_shell = true, .cwd = if (grep_prefix.len > 0) grep_prefix else null });
        if (r.status != 0) os.exit(r.status);
    }
    return if (hit) 0 else 1;
}
