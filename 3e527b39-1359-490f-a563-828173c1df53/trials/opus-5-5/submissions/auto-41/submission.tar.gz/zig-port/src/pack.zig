//! Packfile writing and parsing helpers (pack-write.c, diff-delta.c, the
//! stream-parsing half of builtin/index-pack.c).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const zlib = @import("zlib.zig");
const odb_mod = @import("odb.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

// ---------------------------------------------------------------- misc

/// pack_name_hash() from pack-objects.h
pub fn nameHash(name: []const u8) u32 {
    var h: u32 = 0;
    for (name) |ch| {
        if (std.ascii.isWhitespace(ch)) continue;
        h = (h >> 2) +% (@as(u32, ch) << 24);
    }
    return h;
}

/// Encode a pack entry header (type + size) into buf; returns length.
pub fn encodeEntryHeader(buf: *[16]u8, typ: ObjType, size0: usize) usize {
    var size = size0;
    var c: u8 = (@as(u8, @intFromEnum(typ)) << 4) | @as(u8, @intCast(size & 15));
    size >>= 4;
    var n: usize = 0;
    while (size != 0) {
        buf[n] = c | 0x80;
        n += 1;
        c = @intCast(size & 0x7f);
        size >>= 7;
    }
    buf[n] = c;
    return n + 1;
}

/// Encode an OFS_DELTA negative offset; returns slice into buf.
pub fn encodeOfs(buf: *[16]u8, ofs0: u64) []const u8 {
    var ofs = ofs0;
    var pos: usize = buf.len - 1;
    buf[pos] = @intCast(ofs & 127);
    ofs >>= 7;
    while (ofs != 0) {
        ofs -= 1;
        pos -= 1;
        buf[pos] = 128 | @as(u8, @intCast(ofs & 127));
        ofs >>= 7;
    }
    return buf[pos..];
}

pub fn packCompressionLevel() c_int {
    const cfg = &@import("repo.zig").cfg;
    if (cfg.getInt("pack.compression")) |v| return @intCast(if (v == -1) 6 else v);
    if (cfg.getInt("core.compression")) |v| return @intCast(if (v == -1) 6 else v);
    return 6;
}

// ---------------------------------------------------------------- delta

const BLK: usize = 16;
const P: u64 = 0x100000001b3;
const P15: u64 = blk: {
    var r: u64 = 1;
    var i: usize = 0;
    while (i < BLK - 1) : (i += 1) r *%= P;
    break :blk r;
};

fn blockHash(d: []const u8) u64 {
    var h: u64 = 0;
    for (d[0..BLK]) |b| h = h *% P +% b;
    return h;
}

fn bucketOf(h: u64, mask: u64) usize {
    return @intCast((h ^ (h >> 29) ^ (h >> 47)) & mask);
}

pub const DeltaIndex = struct {
    src: []const u8,
    heads: []u32,
    next: []u32,
    offs: []u32,
    mask: u64,

    pub fn init(src: []const u8) DeltaIndex {
        const nblocks = if (src.len >= BLK) src.len / BLK else 0;
        var sz: usize = 16;
        while (sz < nblocks) sz <<= 1;
        const heads = gpa.alloc(u32, sz) catch util.oom();
        @memset(heads, 0);
        const next = gpa.alloc(u32, nblocks + 1) catch util.oom();
        const offs = gpa.alloc(u32, nblocks + 1) catch util.oom();
        var di = DeltaIndex{ .src = src, .heads = heads, .next = next, .offs = offs, .mask = sz - 1 };
        // insert from the end so earlier blocks are found first
        var k: usize = nblocks;
        while (k > 0) {
            k -= 1;
            const off = k * BLK;
            const b = bucketOf(blockHash(src[off..]), di.mask);
            di.offs[k + 1] = @intCast(off);
            di.next[k + 1] = di.heads[b];
            di.heads[b] = @intCast(k + 1);
        }
        return di;
    }

    pub fn deinit(self: *DeltaIndex) void {
        gpa.free(self.heads);
        gpa.free(self.next);
        gpa.free(self.offs);
    }
};

fn putVarint(out: *util.Buf, v0: usize) void {
    var v = v0;
    while (v >= 0x80) {
        util.bufByte(out, @as(u8, @intCast(v & 0x7f)) | 0x80);
        v >>= 7;
    }
    util.bufByte(out, @intCast(v));
}

fn flushLiteral(out: *util.Buf, lit: []const u8) void {
    var l = lit;
    while (l.len > 0) {
        const n = @min(l.len, 127);
        util.bufByte(out, @intCast(n));
        util.bufAppend(out, l[0..n]);
        l = l[n..];
    }
}

fn emitCopy(out: *util.Buf, off0: usize, len0: usize) void {
    var off = off0;
    var len = len0;
    while (len > 0) {
        const n = @min(len, 0x10000);
        var tmp: [8]u8 = undefined;
        var t: usize = 0;
        var op: u8 = 0x80;
        inline for (0..4) |k| {
            const b: u8 = @intCast((off >> (8 * k)) & 0xff);
            if (b != 0) {
                op |= 1 << k;
                tmp[t] = b;
                t += 1;
            }
        }
        if (n != 0x10000) {
            inline for (0..3) |k| {
                const b: u8 = @intCast((n >> (8 * k)) & 0xff);
                if (b != 0) {
                    op |= 0x10 << k;
                    tmp[t] = b;
                    t += 1;
                }
            }
        }
        util.bufByte(out, op);
        util.bufAppend(out, tmp[0..t]);
        off += n;
        len -= n;
    }
}

/// Create a git delta transforming index.src into trg. Returns null when the
/// delta would exceed max_size (0 = unlimited).
pub fn createDelta(di: *const DeltaIndex, trg: []const u8, max_size: usize) ?[]u8 {
    const src = di.src;
    var out: util.Buf = .empty;
    putVarint(&out, src.len);
    putVarint(&out, trg.len);
    var i: usize = 0;
    var lit_start: usize = 0;
    var h: u64 = if (trg.len >= BLK) blockHash(trg) else 0;
    const have_blocks = di.offs.len > 1;
    while (i < trg.len) {
        var best_len: usize = 0;
        var best_off: usize = 0;
        if (have_blocks and i + BLK <= trg.len) {
            var e = di.heads[bucketOf(h, di.mask)];
            var tries: usize = 0;
            while (e != 0 and tries < 64) : (tries += 1) {
                const off: usize = di.offs[e];
                e = di.next[e];
                if (!std.mem.eql(u8, src[off..][0..BLK], trg[i..][0..BLK])) continue;
                var l: usize = BLK;
                while (off + l < src.len and i + l < trg.len and src[off + l] == trg[i + l]) l += 1;
                if (l > best_len) {
                    best_len = l;
                    best_off = off;
                }
            }
        }
        if (best_len >= BLK) {
            while (i > lit_start and best_off > 0 and src[best_off - 1] == trg[i - 1]) {
                i -= 1;
                best_off -= 1;
                best_len += 1;
            }
            flushLiteral(&out, trg[lit_start..i]);
            emitCopy(&out, best_off, best_len);
            i += best_len;
            lit_start = i;
            if (i + BLK <= trg.len) h = blockHash(trg[i..]);
        } else {
            if (i + BLK < trg.len) {
                h = (h -% @as(u64, trg[i]) *% P15) *% P +% trg[i + BLK];
            }
            i += 1;
        }
        if (max_size != 0 and out.items.len + (i - lit_start) > max_size + 8) {
            out.deinit(gpa);
            return null;
        }
    }
    flushLiteral(&out, trg[lit_start..]);
    if (max_size != 0 and out.items.len > max_size) {
        out.deinit(gpa);
        return null;
    }
    return out.items;
}

// ---------------------------------------------------------------- index writing

pub const IdxEntry = struct {
    oid: Oid,
    offset: u64,
    crc: u32,
};

fn idxLess(_: void, a: IdxEntry, b: IdxEntry) bool {
    return hash.order(a.oid, b.oid) == .lt;
}

fn put32(b: *util.Buf, v: u32) void {
    var t: [4]u8 = undefined;
    std.mem.writeInt(u32, &t, v, .big);
    util.bufAppend(b, &t);
}

fn put64(b: *util.Buf, v: u64) void {
    var t: [8]u8 = undefined;
    std.mem.writeInt(u64, &t, v, .big);
    util.bufAppend(b, &t);
}

pub const IdxOpts = struct {
    version: u32 = 2,
    off32_limit: u64 = 0x7fffffff,
    strict: bool = false,
    /// offsets < 2^31 stored in the 64-bit table of an existing v2 idx
    anomaly: []const u64 = &.{},
};

fn needLargeOffset(off: u64, opts: IdxOpts) bool {
    if ((off >> 31) != 0 or opts.off32_limit < off) return true;
    // anomaly is sorted ascending
    var lo: usize = 0;
    var hi: usize = opts.anomaly.len;
    while (lo < hi) {
        const mid = (lo + hi) / 2;
        if (opts.anomaly[mid] == off) return true;
        if (opts.anomaly[mid] < off) lo = mid + 1 else hi = mid;
    }
    return false;
}

/// Build .idx file contents. `entries` is sorted in place by oid.
pub fn buildIdx(entries: []IdxEntry, pack_sha: Oid, opts: IdxOpts) []u8 {
    std.mem.sort(IdxEntry, entries, {}, idxLess);
    var last_off: u64 = 0;
    for (entries) |e| last_off = @max(last_off, e.offset);
    const version: u32 = if (needLargeOffset(last_off, opts)) 2 else opts.version;
    var b: util.Buf = .empty;
    if (version >= 2) {
        util.bufAppend(&b, "\xfftOc");
        put32(&b, version);
    }
    var j: usize = 0;
    var i: usize = 0;
    while (i < 256) : (i += 1) {
        while (j < entries.len and entries[j].oid[0] == i) j += 1;
        put32(&b, @intCast(j));
    }
    for (entries, 0..) |e, k| {
        if (version < 2) put32(&b, @intCast(e.offset));
        util.bufAppend(&b, &e.oid);
        if (opts.strict and k > 0 and hash.eql(entries[k - 1].oid, e.oid))
            util.die("The same object {s} appears twice in the pack", .{hash.hex(e.oid)});
    }
    if (version >= 2) {
        for (entries) |e| put32(&b, e.crc);
        var nbig: u32 = 0;
        for (entries) |e| {
            if (needLargeOffset(e.offset, opts)) {
                put32(&b, 0x80000000 | nbig);
                nbig += 1;
            } else put32(&b, @intCast(e.offset));
        }
        for (entries) |e| {
            if (needLargeOffset(e.offset, opts)) put64(&b, e.offset);
        }
    }
    util.bufAppend(&b, &pack_sha);
    const sum = hash.hashData(b.items);
    util.bufAppend(&b, &sum);
    return b.items;
}

/// Build .rev contents; `sorted` must be sorted by oid (as left by buildIdx).
pub fn buildRev(sorted: []const IdxEntry, pack_sha: Oid) []u8 {
    const order = gpa.alloc(u32, sorted.len) catch util.oom();
    for (order, 0..) |*o, i| o.* = @intCast(i);
    const Ctx = struct {
        e: []const IdxEntry,
        fn less(ctx: @This(), a: u32, b: u32) bool {
            return ctx.e[a].offset < ctx.e[b].offset;
        }
    };
    std.mem.sort(u32, order, Ctx{ .e = sorted }, Ctx.less);
    var b: util.Buf = .empty;
    util.bufAppend(&b, "RIDX");
    put32(&b, 1);
    put32(&b, 1);
    for (order) |o| put32(&b, o);
    util.bufAppend(&b, &pack_sha);
    const sum = hash.hashData(b.items);
    util.bufAppend(&b, &sum);
    return b.items;
}

pub fn writeNewFile(path: []const u8, data: []const u8, mode: c_uint) void {
    _ = os.unlink(path);
    const fd = os.openFile(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600);
    if (fd < 0) util.dieErrno("unable to create '{s}'", .{path});
    os.writeAll(fd, data) catch util.dieErrno("unable to write {s}", .{path});
    os.close(fd);
    _ = os.chmod(path, mode);
}

// ---------------------------------------------------------------- pack writing

/// Streaming pack writer: hashes and counts while writing to an fd.
pub const Writer = struct {
    fd: c_int,
    hasher: hash.Hasher = hash.Hasher.init(.{}),
    offset: u64 = 0,
    buf: util.Buf = .empty,
    crc: u32 = 0,

    pub fn write(self: *Writer, data: []const u8) void {
        self.hasher.update(data);
        self.crc = zlib.crc(self.crc, data);
        self.offset += data.len;
        util.bufAppend(&self.buf, data);
        if (self.buf.items.len >= 1 << 16) self.flush();
    }

    pub fn flush(self: *Writer) void {
        if (self.buf.items.len == 0) return;
        os.writeAll(self.fd, self.buf.items) catch util.dieErrno("write error", .{});
        self.buf.clearRetainingCapacity();
    }

    pub fn header(self: *Writer, nr: u32) void {
        var h: [12]u8 = undefined;
        @memcpy(h[0..4], "PACK");
        std.mem.writeInt(u32, h[4..8], 2, .big);
        std.mem.writeInt(u32, h[8..12], nr, .big);
        self.write(&h);
    }

    pub fn beginEntry(self: *Writer) u64 {
        self.crc = 0;
        return self.offset;
    }

    /// Writes trailer and flushes; returns the pack checksum.
    pub fn finish(self: *Writer) Oid {
        var sum: Oid = undefined;
        self.hasher.final(&sum);
        util.bufAppend(&self.buf, &sum);
        self.offset += sum.len;
        self.flush();
        return sum;
    }
};

// ---------------------------------------------------------------- pack parsing

/// Incremental input: keeps everything read so far in `data`.
pub const Input = struct {
    fd: c_int,
    data: util.Buf = .empty,
    pos: usize = 0,
    eof: bool = false,
    /// index-pack fill(): display_throughput() on every read
    throughput: ?*@import("progress.zig").Progress = null,

    pub fn fromBytes(bytes: []const u8) Input {
        var in = Input{ .fd = -1, .eof = true };
        in.data.appendSlice(gpa, bytes) catch util.oom();
        return in;
    }

    fn readMore(self: *Input) bool {
        if (self.eof) return false;
        // C uses a 4096-byte input_buffer and reads (4096 - input_len).
        var tmp: [4096]u8 = undefined;
        const left = self.data.items.len - @min(self.pos, self.data.items.len);
        const want: usize = if (left < tmp.len) tmp.len - left else tmp.len;
        while (true) {
            const n = std.c.read(self.fd, &tmp, want);
            if (n < 0) {
                if (os.errno() == os.EINTR) continue;
                util.dieErrno("read error on input", .{});
            }
            if (n == 0) {
                self.eof = true;
                return false;
            }
            self.data.appendSlice(gpa, tmp[0..@intCast(n)]) catch util.oom();
            if (self.throughput) |p| p.displayThroughput(self.data.items.len);
            return true;
        }
    }

    pub fn fill(self: *Input, n: usize) void {
        while (self.data.items.len < self.pos + n) {
            if (!self.readMore()) util.die("early EOF", .{});
        }
    }

    pub fn byte(self: *Input) u8 {
        self.fill(1);
        const b = self.data.items[self.pos];
        self.pos += 1;
        return b;
    }


    /// get_data() of unpack-objects: inflate exactly `size` bytes; on a zlib
    /// error returns null data and the zlib return code.
    pub fn inflateGently(self: *Input, size: usize) struct { data: ?[]u8, ret: c_int } {
        var s = zlib.ZStream{};
        if (zlib.inflateInit_(&s, zlib.zlibVersion(), @sizeOf(zlib.ZStream)) != zlib.Z_OK) util.die("inflateInit failed", .{});
        defer _ = zlib.inflateEnd(&s);
        const out = gpa.alloc(u8, size + 1) catch util.oom();
        while (true) {
            self.fill(1);
            const avail = self.data.items.len - self.pos;
            s.next_in = self.data.items.ptr + self.pos;
            s.avail_in = @intCast(@min(avail, std.math.maxInt(c_uint)));
            s.next_out = out.ptr + s.total_out;
            s.avail_out = @intCast(size - s.total_out);
            const before_in = s.avail_in;
            const r = zlib.inflate(&s, zlib.Z_NO_FLUSH);
            self.pos += before_in - s.avail_in;
            if (s.total_out == size and r == zlib.Z_STREAM_END) break;
            if (r != zlib.Z_OK) return .{ .data = null, .ret = r };
        }
        return .{ .data = out[0..size], .ret = zlib.Z_STREAM_END };
    }
    /// Inflate a zlib stream at pos, expecting `size` output bytes.
    pub fn inflate(self: *Input, size: usize, offset: u64) []u8 {
        var s = zlib.ZStream{};
        if (zlib.inflateInit_(&s, zlib.zlibVersion(), @sizeOf(zlib.ZStream)) != zlib.Z_OK) util.die("inflateInit failed", .{});
        defer _ = zlib.inflateEnd(&s);
        const out = gpa.alloc(u8, size + 1) catch util.oom();
        if (self.data.items.len <= self.pos) _ = self.readMore();
        while (true) {
            const avail = self.data.items.len - self.pos;
            s.next_in = self.data.items.ptr + self.pos;
            s.avail_in = @intCast(@min(avail, std.math.maxInt(c_uint)));
            s.next_out = out.ptr + s.total_out;
            s.avail_out = @intCast(out.len - s.total_out);
            const before_in = s.avail_in;
            const r = zlib.inflate(&s, zlib.Z_NO_FLUSH);
            self.pos += before_in - s.avail_in;
            if (r == zlib.Z_STREAM_END) break;
            if (r != zlib.Z_OK and r != zlib.Z_BUF_ERROR)
                util.die("pack has bad object at offset {d}: inflate returned {d}", .{ offset, r });
            if (s.avail_out == 0 and s.total_out > size)
                util.die("pack has bad object at offset {d}: inflate returned {d}", .{ offset, r });
            if (s.avail_in == 0) {
                if (!self.readMore()) util.die("early EOF", .{});
            }
        }
        if (s.total_out != size)
            util.die("pack has bad object at offset {d}: inflate returned {d}", .{ offset, @as(i32, 1) });
        return out[0..size];
    }
};

pub const RawEntry = struct {
    offset: u64,
    end: u64 = 0,
    typ: ObjType,
    size: usize,
    base_ofs: u64 = 0,
    base_oid: Oid = hash.zero,
    data: []u8,
    crc: u32 = 0,
};

pub const Header = struct { version: u32, nr: u32 };

pub fn readHeader(in: *Input) Header {
    in.fill(12);
    const d = in.data.items[in.pos..][0..12];
    if (!std.mem.eql(u8, d[0..4], "PACK")) util.die("pack signature mismatch", .{});
    const ver = std.mem.readInt(u32, d[4..8], .big);
    if (ver != 2 and ver != 3) util.die("pack version {d} unsupported", .{ver});
    const nr = std.mem.readInt(u32, d[8..12], .big);
    in.pos += 12;
    return .{ .version = ver, .nr = nr };
}

/// Read one pack entry from the input stream (unpack_raw_entry).
pub fn readEntry(in: *Input) RawEntry {
    const start = in.pos;
    var c = in.byte();
    const t: u3 = @intCast((c >> 4) & 7);
    var size: usize = c & 15;
    var shift: u6 = 4;
    while (c & 0x80 != 0) {
        c = in.byte();
        if (shift > 57) util.die("pack has bad object at offset {d}: object size too large", .{start});
        size |= @as(usize, c & 0x7f) << shift;
        shift += 7;
    }
    var e = RawEntry{ .offset = start, .typ = @enumFromInt(t), .size = size, .data = &.{} };
    switch (e.typ) {
        .ofs_delta => {
            c = in.byte();
            var ofs: u64 = c & 127;
            while (c & 128 != 0) {
                ofs += 1;
                if (ofs == 0 or (ofs >> 57) != 0)
                    util.die("pack has bad object at offset {d}: offset value overflow for delta base object", .{start});
                c = in.byte();
                ofs = (ofs << 7) + (c & 127);
            }
            if (ofs == 0 or ofs > start)
                util.die("pack has bad object at offset {d}: delta base offset is out of bound", .{start});
            e.base_ofs = start - ofs;
        },
        .ref_delta => {
            in.fill(20);
            e.base_oid = in.data.items[in.pos..][0..20].*;
            in.pos += 20;
        },
        .commit, .tree, .blob, .tag => {},
        else => util.die("pack has bad object at offset {d}: unknown object type {d}", .{ start, t }),
    }
    e.data = in.inflate(size, start);
    e.end = in.pos;
    e.crc = zlib.crc(0, in.data.items[start..in.pos]);
    return e;
}

/// Verify the trailing checksum; returns pack sha.
pub fn readTrailer(in: *Input) Oid {
    const sum = hash.hashData(in.data.items[0..in.pos]);
    in.fill(20);
    if (!std.mem.eql(u8, in.data.items[in.pos..][0..20], &sum)) util.die("pack is corrupted (SHA1 mismatch)", .{});
    in.pos += 20;
    return sum;
}

pub fn deltaSizes(delta: []const u8) struct { src: usize, dst: usize } {
    var pos: usize = 0;
    var r: [2]usize = .{ 0, 0 };
    for (&r) |*v| {
        var shift: u6 = 0;
        while (pos < delta.len) {
            const ch = delta[pos];
            pos += 1;
            v.* |= @as(usize, ch & 0x7f) << shift;
            shift +|= 7;
            if (ch & 0x80 == 0) break;
        }
    }
    return .{ .src = r[0], .dst = r[1] };
}

// ---------------------------------------------------------------- resolution (index-pack core)

pub const Resolved = struct {
    entries: []RawEntry,
    oids: []Oid,
    real_types: []ObjType,
    depth: []u32,
    base_idx: []u32,
    nr_deltas: u32,
    nr_ofs: u32,
    nr_ref: u32,
    unresolved: u32,
};

/// Resolve all deltas in a list of entries parsed sequentially from a pack.
/// `external` is used to look up REF_DELTA bases not in the pack (thin packs);
/// when it returns an object, `appended` collects them.
pub const Resolver = struct {
    entries: std.ArrayList(RawEntry) = .empty,
    oids: std.ArrayList(Oid) = .empty,
    types: std.ArrayList(ObjType) = .empty,
    done: std.ArrayList(bool) = .empty,
    full: std.ArrayList(?[]u8) = .empty,
    depth: std.ArrayList(u32) = .empty,
    base_idx: std.ArrayList(u32) = .empty,
    by_oid: hash.OidMap(u32) = .empty,

    pub fn add(self: *Resolver, e: RawEntry) void {
        self.entries.append(gpa, e) catch util.oom();
        self.oids.append(gpa, hash.zero) catch util.oom();
        self.types.append(gpa, e.typ) catch util.oom();
        self.done.append(gpa, false) catch util.oom();
        self.full.append(gpa, null) catch util.oom();
        self.depth.append(gpa, 0) catch util.oom();
        self.base_idx.append(gpa, 0) catch util.oom();
    }

    fn findOffset(self: *Resolver, off: u64) ?u32 {
        var lo: usize = 0;
        var hi: usize = self.entries.items.len;
        while (lo < hi) {
            const mid = (lo + hi) / 2;
            const o = self.entries.items[mid].offset;
            if (o == off) return @intCast(mid);
            if (o < off) lo = mid + 1 else hi = mid;
        }
        return null;
    }

    fn finishObj(self: *Resolver, i: u32, typ: ObjType, data: []u8) void {
        self.types.items[i] = typ;
        self.full.items[i] = data;
        self.oids.items[i] = odb_mod.hashObject(typ, data);
        self.done.items[i] = true;
        self.by_oid.put(gpa, self.oids.items[i], i) catch util.oom();
    }

    /// Get object data for entry i (resolving it if needed). null = unresolvable now.
    pub fn get(self: *Resolver, i: u32) ?[]u8 {
        if (self.done.items[i]) {
            if (self.full.items[i]) |d| return d;
        }
        const e = self.entries.items[i];
        switch (e.typ) {
            .commit, .tree, .blob, .tag => {
                if (!self.done.items[i]) {
                    self.finishObj(i, e.typ, e.data);
                } else self.full.items[i] = e.data;
                return e.data;
            },
            .ofs_delta, .ref_delta => {
                var bi: u32 = undefined;
                if (e.typ == .ofs_delta) {
                    bi = self.findOffset(e.base_ofs) orelse
                        util.die("pack has bad object at offset {d}: delta base offset is out of bound", .{e.offset});
                } else {
                    bi = self.by_oid.get(e.base_oid) orelse return null;
                }
                const base = self.get(bi) orelse return null;
                const res = odb_mod.applyDelta(base, e.data) orelse
                    util.die("pack has bad object at offset {d}: failed to apply delta", .{e.offset});
                self.base_idx.items[i] = bi;
                self.depth.items[i] = self.depth.items[bi] + 1;
                self.finishObj(i, self.types.items[bi], res);
                return res;
            },
            else => unreachable,
        }
    }

    /// Resolve everything possible. Returns number of unresolved deltas.
    pub fn resolveAll(self: *Resolver) u32 {
        // full objects first
        for (self.entries.items, 0..) |e, i| {
            if (!isDelta(e.typ) and !self.done.items[i]) {
                _ = self.get(@intCast(i));
            }
        }
        while (true) {
            var progress = false;
            var unresolved: u32 = 0;
            for (self.entries.items, 0..) |e, i| {
                if (self.done.items[i] or !isDelta(e.typ)) continue;
                if (self.get(@intCast(i)) != null) progress = true else unresolved += 1;
            }
            if (unresolved == 0 or !progress) return unresolved;
        }
    }


    /// Append an object from outside the pack (thin pack base); returns index.
    pub fn addExternal(self: *Resolver, typ: ObjType, data: []u8) u32 {
        var off: u64 = 0;
        if (self.entries.items.len > 0) off = self.entries.items[self.entries.items.len - 1].offset + 1;
        self.add(.{ .offset = off, .typ = typ, .size = data.len, .data = data });
        const i: u32 = @intCast(self.entries.items.len - 1);
        _ = self.get(i);
        return i;
    }

    /// First unresolved REF_DELTA (in pack order) whose base is not in the pack.
    pub fn firstMissingBase(self: *Resolver, skip: *const hash.OidSet) ?Oid {
        for (self.entries.items, 0..) |e, i| {
            if (self.done.items[i] or e.typ != .ref_delta) continue;
            if (self.by_oid.contains(e.base_oid)) continue;
            if (skip.contains(e.base_oid)) continue;
            return e.base_oid;
        }
        return null;
    }
    pub fn dropCache(self: *Resolver) void {
        for (self.full.items) |*f| f.* = null;
    }
};

pub fn isDelta(t: ObjType) bool {
    return t == .ofs_delta or t == .ref_delta;
}

/// Build a full pack entry (non-delta) for an object; returns bytes.
pub fn encodeFullEntry(typ: ObjType, data: []const u8, level: c_int) []u8 {
    var hb: [16]u8 = undefined;
    const hl = encodeEntryHeader(&hb, typ, data.len);
    const comp = zlib.compress(data, level);
    return util.concat(&.{ hb[0..hl], comp });
}

/// parse_pack_header_option(): "<version>,<entries>" -> 12-byte header.
pub fn parsePackHeaderOption(in: []const u8) ?[12]u8 {
    const comma = std.mem.indexOfScalar(u8, in, ',') orelse return null;
    const v = parseStrtoul(in[0..comma]) orelse return null;
    const n = parseStrtoul(in[comma + 1 ..]) orelse return null;
    var h: [12]u8 = undefined;
    @memcpy(h[0..4], "PACK");
    std.mem.writeInt(u32, h[4..8], v, .big);
    std.mem.writeInt(u32, h[8..12], n, .big);
    return h;
}

fn parseStrtoul(s: []const u8) ?u32 {
    var v: u64 = 0;
    for (s) |ch| {
        if (ch < '0' or ch > '9') return null;
        v = v *% 10 +% (ch - '0');
    }
    return @truncate(v);
}
