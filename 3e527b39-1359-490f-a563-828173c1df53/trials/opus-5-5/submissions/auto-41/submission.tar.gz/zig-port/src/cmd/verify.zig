//! git verify-tag / git verify-commit (builtin/verify-tag.c, builtin/verify-commit.c,
//! gpg_verify_tag() from tag.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const revparse = @import("../revparse.zig");
const gpg = @import("../gpg.zig");
const rf = @import("../reffilter.zig");
const Oid = [20]u8;

const FLAG_VERBOSE: i32 = @intCast(gpg.VERIFY_VERBOSE);
const FLAG_RAW: i32 = @intCast(gpg.VERIFY_RAW);
const FLAG_OMIT_STATUS: i32 = @intCast(gpg.VERIFY_OMIT_STATUS);

/// run_gpg_verify() of tag.c
fn runGpgVerifyTag(buf: []const u8, flags: u32) i32 {
    var payload: util.Buf = .empty;
    var sig: util.Buf = .empty;
    if (!gpg.parseSignature(buf, &payload, &sig)) {
        if (flags & gpg.VERIFY_VERBOSE != 0) {
            util.flushStdout();
            util.out(buf);
            util.flushStdout();
        }
        util.err("no signature found", .{});
        return -1;
    }
    var sigc: gpg.SigCheck = .{ .payload_type = .tag, .payload = payload.items };
    const ret = gpg.checkSignature(&sigc, sig.items);
    if (flags & gpg.VERIFY_OMIT_STATUS == 0) gpg.printSignatureBuffer(&sigc, flags);
    return ret;
}

/// gpg_verify_tag()
pub fn gpgVerifyTag(oid: Oid, name_to_report: ?[]const u8, flags: u32) i32 {
    const odb = repo_mod.repo().odb();
    const obj = odb.read(oid);
    if (obj == null or obj.?.typ != .tag) {
        const tn = if (obj) |o| o.typ.name() else "bad";
        util.err("{s}: cannot verify a non-tag object of type {s}.", .{ name_to_report orelse revparse.abbrev(oid, 0), tn });
        return -1;
    }
    return runGpgVerifyTag(obj.?.data, flags);
}

const tag_usage = [_][]const u8{"git verify-tag [-v | --verbose] [--format=<format>] [--raw] <tag>..."};
const commit_usage = [_][]const u8{"git verify-commit [-v | --verbose] [--raw] <commit>..."};

pub fn cmdVerifyTag(args: []const []const u8) u8 {
    var verbose: i32 = 0;
    var flags: i32 = 0;
    var format_s: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.counter('v', "verbose", &verbose, "print tag contents"),
        po.bit(0, "raw", &flags, FLAG_RAW, "print raw gpg status output"),
        po.string(0, "format", &format_s, "format", "format to use for the output"),
    };
    const rest = po.parse(args[1..], &opts, &tag_usage, .{});
    if (rest.len == 0) po.usageWithOptions(&tag_usage, &opts);
    if (verbose != 0) flags |= FLAG_VERBOSE;
    var format: rf.Format = .{};
    if (format_s) |f| {
        format.format = f;
        if (!rf.verifyFormat(&format)) po.usageWithOptions(&tag_usage, &opts);
        flags |= FLAG_OMIT_STATUS;
    }
    var had_error: u8 = 0;
    for (rest) |name| {
        const oid = revparse.getOid(name) orelse {
            util.err("tag '{s}' not found.", .{name});
            had_error = 1;
            continue;
        };
        if (gpgVerifyTag(oid, name, @intCast(flags)) != 0) {
            had_error = 1;
            continue;
        }
        if (format_s != null) rf.prettyPrintRef(name, oid, null, &format);
    }
    return had_error;
}

pub fn cmdVerifyCommit(args: []const []const u8) u8 {
    var verbose: i32 = 0;
    var flags: i32 = 0;
    const opts = [_]po.Opt{
        po.counter('v', "verbose", &verbose, "print commit contents"),
        po.bit(0, "raw", &flags, FLAG_RAW, "print raw gpg status output"),
    };
    const rest = po.parse(args[1..], &opts, &commit_usage, .{});
    if (rest.len == 0) po.usageWithOptions(&commit_usage, &opts);
    if (verbose != 0) flags |= FLAG_VERBOSE;
    os.ignoreSigpipe();
    const odb = repo_mod.repo().odb();
    var had_error: u8 = 0;
    for (rest) |name| {
        const oid = revparse.getOid(name) orelse {
            util.err("commit '{s}' not found.", .{name});
            had_error = 1;
            continue;
        };
        const obj = odb.read(oid) orelse {
            util.err("{s}: unable to read file.", .{name});
            had_error = 1;
            continue;
        };
        if (obj.typ != .commit) {
            util.err("{s}: cannot verify a non-commit object of type {s}.", .{ name, obj.typ.name() });
            had_error = 1;
            continue;
        }
        var sigc: gpg.SigCheck = .{};
        const ret = gpg.verifyCommitBuffer(obj.data, &sigc);
        gpg.printSignatureBuffer(&sigc, @intCast(flags));
        if (ret != 0) had_error = 1;
    }
    return had_error;
}
