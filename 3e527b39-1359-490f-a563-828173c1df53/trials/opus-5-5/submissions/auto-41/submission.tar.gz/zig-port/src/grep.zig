//! Port of git's grep.c: pattern compilation, expression evaluation and
//! per-source line matching/output used by `git grep`.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const regex = @import("regex.zig");
const color = @import("color.zig");
const userdiff = @import("userdiff.zig");
const xdiff = @import("xdiff.zig");
const repo_mod = @import("repo.zig");
const hash = @import("hash.zig");
const gpa = util.gpa;

pub const Oid = hash.Oid;

pub const Token = enum { pattern, and_, open_paren, close_paren, not_, or_ };

pub const PatternType = enum { unspecified, bre, ere, fixed, pcre };

pub const BinaryMode = enum(i32) { default = 0, nomatch = 1, text = 2 };

pub const Pat = struct {
    pattern: []const u8,
    origin: []const u8,
    no: u32,
    token: Token,
    re: ?regex.Regex = null,
    word_regexp: bool = false,
    ignore_case: bool = false,
    fixed: bool = false,
    is_fixed: bool = false,
};

const NodeKind = enum { true_, atom, not_, and_, or_ };

pub const Node = struct {
    kind: NodeKind,
    atom: ?*Pat = null,
    left: ?*Node = null,
    right: ?*Node = null,
    hit: bool = false,
};

pub const COLOR_CONTEXT = 0;
pub const COLOR_FILENAME = 1;
pub const COLOR_FUNCTION = 2;
pub const COLOR_LINENO = 3;
pub const COLOR_COLUMNNO = 4;
pub const COLOR_MATCH_CONTEXT = 5;
pub const COLOR_MATCH_SELECTED = 6;
pub const COLOR_SELECTED = 7;
pub const COLOR_SEP = 8;

pub const color_slots = [_][]const u8{ "context", "filename", "function", "lineNumber", "column", "matchContext", "matchSelected", "selected", "separator" };

pub const Opt = struct {
    patterns: std.ArrayList(*Pat) = .empty,
    expr: ?*Node = null,

    linenum: bool = false,
    columnnum: bool = false,
    invert: bool = false,
    ignore_case: bool = false,
    status_only: bool = false,
    name_only: bool = false,
    unmatch_name_only: bool = false,
    count: bool = false,
    word_regexp: bool = false,
    all_match: bool = false,
    binary: i32 = 0,
    allow_textconv: bool = false,
    extended_regexp_option: bool = false,
    pattern_type_option: PatternType = .unspecified,
    relative: i32 = 1,
    pathname: i32 = 1,
    null_following_name: bool = false,
    only_matching: bool = false,
    file_break: bool = false,
    heading: bool = false,
    funcname: bool = false,
    funcbody: bool = false,
    max_depth: i32 = -1,
    max_count: i32 = -1,
    pre_context: i32 = 0,
    post_context: i32 = 0,

    color: color.ColorBool = .unknown,
    use_color: bool = false,
    colors: [9][]const u8 = .{ "", color.MAGENTA, "", color.GREEN, color.GREEN, color.BOLD_RED, color.BOLD_RED, "", color.CYAN },

    last_shown: u32 = 0,
    show_hunk_mark: bool = false,

    /// -O: collect output chunks (paths) instead of writing them
    collect: ?*std.ArrayList([]const u8) = null,

    pub fn appendPattern(self: *Opt, pat: []const u8, origin: []const u8, no: u32, t: Token) void {
        const p = gpa.create(Pat) catch util.oom();
        p.* = .{ .pattern = pat, .origin = origin, .no = no, .token = t };
        if (t != .pattern) {
            self.patterns.append(gpa, p) catch util.oom();
            return;
        }
        // split at newlines into multiple patterns (in order)
        var it = std.mem.splitScalar(u8, pat, '\n');
        var first = true;
        while (it.next()) |piece| {
            if (first) {
                p.pattern = piece;
                self.patterns.append(gpa, p) catch util.oom();
                first = false;
            } else {
                const q = gpa.create(Pat) catch util.oom();
                q.* = .{ .pattern = piece, .origin = origin, .no = no, .token = t };
                self.patterns.append(gpa, q) catch util.oom();
            }
        }
    }
};

// ---------------- compilation ----------------

fn compileRegexpFailed(p: *const Pat, msg: []const u8) noreturn {
    if (p.no != 0)
        util.die("In '{s}' at {d}, '{s}': {s}", .{ p.origin, p.no, p.pattern, msg });
    util.die("{s}, '{s}': {s}", .{ p.origin, p.pattern, msg });
}

fn isRegexSpecial(ch: u8) bool {
    return std.mem.indexOfScalar(u8, "$()*+.?[\\^{|", ch) != null;
}

fn isFixed(s: []const u8) bool {
    for (s) |ch| if (isRegexSpecial(ch)) return false;
    return true;
}

pub fn basicRegexQuote(b: *util.Buf, src0: []const u8) void {
    var src = src0;
    if (src.len > 0 and src[0] == '^') {
        util.bufByte(b, '\\');
        util.bufByte(b, '^');
        src = src[1..];
    }
    if (src.len > 0 and src[0] == '*') {
        util.bufByte(b, '*');
        src = src[1..];
    }
    for (src, 0..) |ch, i| {
        switch (ch) {
            '[', '.', '\\', '*' => {
                util.bufByte(b, '\\');
                util.bufByte(b, ch);
            },
            '$' => {
                if (i + 1 == src.len) util.bufByte(b, '\\');
                util.bufByte(b, ch);
            },
            else => util.bufByte(b, ch),
        }
    }
}

fn compileRegexp(p: *Pat, o: *Opt) void {
    if (o.pattern_type_option == .unspecified)
        o.pattern_type_option = if (o.extended_regexp_option) .ere else .bre;
    p.word_regexp = o.word_regexp;
    p.ignore_case = o.ignore_case;
    p.fixed = o.pattern_type_option == .fixed;
    if (o.pattern_type_option != .pcre and std.mem.indexOfScalar(u8, p.pattern, 0) != null)
        util.die("given pattern contains NULL byte (via -f <file>). This is only supported with -P under PCRE v2", .{});
    p.is_fixed = isFixed(p.pattern);
    if (p.fixed or p.is_fixed) {
        var b: util.Buf = .empty;
        basicRegexQuote(&b, p.pattern);
        switch (regex.Regex.compile(b.items, .{ .icase = o.ignore_case })) {
            .ok => |re| p.re = re,
            .err => |e| compileRegexpFailed(p, e),
        }
        return;
    }
    if (o.pattern_type_option == .pcre)
        util.die("cannot use Perl-compatible regexes when not compiled with USE_LIBPCRE", .{});
    switch (regex.Regex.compile(p.pattern, .{ .newline = true, .icase = p.ignore_case, .extended = o.pattern_type_option == .ere })) {
        .ok => |re| p.re = re,
        .err => |e| compileRegexpFailed(p, e),
    }
}

fn newNode(kind: NodeKind, l: ?*Node, r: ?*Node) *Node {
    const z = gpa.create(Node) catch util.oom();
    z.* = .{ .kind = kind, .left = l, .right = r };
    return z;
}

const Cursor = struct {
    items: []*Pat,
    i: usize = 0,
    fn cur(self: *Cursor) ?*Pat {
        return if (self.i < self.items.len) self.items[self.i] else null;
    }
    fn hasNext(self: *Cursor) bool {
        return self.i + 1 < self.items.len;
    }
};

fn compileAtom(c: *Cursor) ?*Node {
    const p = c.cur() orelse return null;
    switch (p.token) {
        .pattern => {
            const x = newNode(.atom, null, null);
            x.atom = p;
            c.i += 1;
            return x;
        },
        .open_paren => {
            c.i += 1;
            const x = compileOr(c);
            const q = c.cur();
            if (q == null or q.?.token != .close_paren) util.die("unmatched ( for expression group", .{});
            c.i += 1;
            return x;
        },
        else => return null,
    }
}

fn compileNot(c: *Cursor) ?*Node {
    const p = c.cur() orelse return null;
    if (p.token == .not_) {
        if (!c.hasNext()) util.die("--not not followed by pattern expression", .{});
        c.i += 1;
        const x = compileNot(c) orelse util.die("--not followed by non pattern expression", .{});
        return newNode(.not_, x, null);
    }
    return compileAtom(c);
}

fn compileAnd(c: *Cursor) ?*Node {
    const x = compileNot(c);
    const p = c.cur();
    if (p != null and p.?.token == .and_) {
        if (x == null) util.die("--and not preceded by pattern expression", .{});
        if (!c.hasNext()) util.die("--and not followed by pattern expression", .{});
        c.i += 1;
        const y = compileAnd(c) orelse util.die("--and not followed by pattern expression", .{});
        return newNode(.and_, x, y);
    }
    return x;
}

fn compileOr(c: *Cursor) ?*Node {
    const x = compileAnd(c);
    const p = c.cur();
    if (x != null and p != null and p.?.token != .close_paren) {
        const y = compileOr(c) orelse util.die("not a pattern expression {s}", .{p.?.pattern});
        return newNode(.or_, x, y);
    }
    return x;
}

pub fn compilePatterns(o: *Opt) void {
    var extended = false;
    for (o.patterns.items) |p| {
        if (p.token == .pattern) compileRegexp(p, o) else extended = true;
    }
    if (o.all_match) extended = true else if (!extended) return;
    var c = Cursor{ .items = o.patterns.items };
    if (c.cur() != null) o.expr = compileOr(&c);
    if (c.cur()) |p| util.die("incomplete pattern expression group: {s}", .{p.pattern});
}

// ---------------- matching ----------------

fn wordChar(ch: u8) bool {
    return std.ascii.isAlphanumeric(ch) or ch == '_';
}

/// headerless_match_one_pattern(): offsets are relative to `line`.
fn matchOnePattern(p: *const Pat, line: []const u8, eflags0: c_int) ?regex.Match {
    if (p.token != .pattern) return null;
    const re = p.re orelse return null;
    var start: usize = 0;
    var eflags = eflags0;
    while (true) {
        const sub = line[start..];
        var m = re.exec(sub, eflags) orelse return null;
        var hit = true;
        if (p.word_regexp) {
            const so: usize = @intCast(m.so);
            const eo: usize = @intCast(m.eo);
            if (!((so == 0 or !wordChar(sub[so - 1])) and (eo == sub.len or !wordChar(sub[eo])))) hit = false;
            if (so == eo) hit = false;
            if (!hit and start + so + 1 < line.len) {
                var nb = start + so + 1;
                while (wordChar(line[nb - 1]) and nb < line.len) nb += 1;
                eflags |= regex.REG_NOTBOL;
                if (nb < line.len) {
                    start = nb;
                    continue;
                }
            }
        }
        if (!hit) return null;
        m.so += @intCast(start);
        m.eo += @intCast(start);
        return m;
    }
}

fn matchExprEval(o: *Opt, x: *Node, line: []const u8, col: *isize, icol: *isize, collect_hits: bool) bool {
    var h = false;
    switch (x.kind) {
        .true_ => h = true,
        .atom => {
            if (matchOnePattern(x.atom.?, line, 0)) |m| {
                h = true;
                if (col.* < 0 or m.so < col.*) col.* = m.so;
            }
        },
        .not_ => h = !matchExprEval(o, x.left.?, line, icol, col, false),
        .and_ => {
            h = matchExprEval(o, x.left.?, line, col, icol, false);
            if (h or o.columnnum) {
                const r = matchExprEval(o, x.right.?, line, col, icol, false);
                h = h and r;
            }
        },
        .or_ => {
            if (!(collect_hits or o.columnnum)) {
                return matchExprEval(o, x.left.?, line, col, icol, false) or
                    matchExprEval(o, x.right.?, line, col, icol, false);
            }
            h = matchExprEval(o, x.left.?, line, col, icol, false);
            if (collect_hits) x.left.?.hit = x.left.?.hit or h;
            const r = matchExprEval(o, x.right.?, line, col, icol, collect_hits);
            h = h or r;
        },
    }
    if (collect_hits) x.hit = x.hit or h;
    return h;
}

fn matchLine(o: *Opt, line: []const u8, col: *isize, icol: *isize, collect_hits: bool) bool {
    if (o.expr) |x| return matchExprEval(o, x, line, col, icol, collect_hits);
    var hit = false;
    for (o.patterns.items) |p| {
        if (matchOnePattern(p, line, 0)) |m| {
            hit = true;
            if (!o.columnnum) break;
            if (col.* < 0 or m.so < col.*) col.* = m.so;
        }
    }
    return hit;
}

/// grep_next_match(): earliest (then shortest) match among all patterns.
fn nextMatch(o: *Opt, line: []const u8, eflags: c_int) ?regex.Match {
    var best: ?regex.Match = null;
    if (line.len == 0) return null;
    for (o.patterns.items) |p| {
        if (p.token != .pattern) continue;
        const m = matchOnePattern(p, line, eflags) orelse continue;
        if (m.so < 0 or m.eo < 0) continue;
        if (best) |b| {
            if (m.so > b.so) continue;
            if (m.so == b.so and m.eo < b.eo) continue;
        }
        best = m;
    }
    return best;
}

// ---------------- output ----------------

fn output(o: *Opt, data: []const u8) void {
    if (o.collect) |l| {
        if (data.len == 1 and data[0] == 0) return;
        l.append(gpa, util.dupe(data)) catch util.oom();
        return;
    }
    util.out(data);
}

fn outputColor(o: *Opt, data: []const u8, c: []const u8) void {
    if (o.use_color and c.len > 0) {
        output(o, c);
        output(o, data);
        output(o, color.RESET);
    } else output(o, data);
}

fn outputSep(o: *Opt, sign: u8) void {
    if (o.null_following_name) {
        output(o, "\x00");
    } else {
        const s = [1]u8{sign};
        outputColor(o, &s, o.colors[COLOR_SEP]);
    }
}

fn showName(o: *Opt, name: []const u8) void {
    outputColor(o, name, o.colors[COLOR_FILENAME]);
    output(o, if (o.null_following_name) "\x00" else "\n");
}

fn showLineHeader(o: *Opt, name: []const u8, lno: u32, cno: isize, sign: u8) void {
    if (o.heading and o.last_shown == 0) {
        outputColor(o, name, o.colors[COLOR_FILENAME]);
        output(o, "\n");
    }
    o.last_shown = lno;
    if (!o.heading and o.pathname != 0) {
        outputColor(o, name, o.colors[COLOR_FILENAME]);
        outputSep(o, sign);
    }
    if (o.linenum) {
        outputColor(o, util.fmt("{d}", .{lno}), o.colors[COLOR_LINENO]);
        outputSep(o, sign);
    }
    if (o.columnnum and cno != 0) {
        outputColor(o, util.fmt("{d}", .{cno}), o.colors[COLOR_COLUMNNO]);
        outputSep(o, sign);
    }
}

fn showLine(o: *Opt, line0: []const u8, name: []const u8, lno: u32, cno0: isize, sign: u8) void {
    var cno = cno0;
    if (o.file_break and o.last_shown == 0) {
        if (o.show_hunk_mark) output(o, "\n");
    } else if (o.pre_context != 0 or o.post_context != 0 or o.funcbody) {
        if (o.last_shown == 0) {
            if (o.show_hunk_mark) {
                outputColor(o, "--", o.colors[COLOR_SEP]);
                output(o, "\n");
            }
        } else if (lno > o.last_shown + 1) {
            outputColor(o, "--", o.colors[COLOR_SEP]);
            output(o, "\n");
        }
    }
    if (!o.only_matching) showLineHeader(o, name, lno, cno, sign);
    var line = line0;
    var line_color: []const u8 = "";
    if (o.use_color or o.only_matching) {
        var match_color: []const u8 = "";
        if (o.use_color) {
            match_color = if (sign == ':') o.colors[COLOR_MATCH_SELECTED] else o.colors[COLOR_MATCH_CONTEXT];
            line_color = switch (sign) {
                ':' => o.colors[COLOR_SELECTED],
                '-' => o.colors[COLOR_CONTEXT],
                '=' => o.colors[COLOR_FUNCTION],
                else => "",
            };
        }
        var eflags: c_int = 0;
        var consumed: usize = 0;
        while (nextMatch(o, line, eflags)) |m| {
            if (m.so == m.eo) break;
            const so: usize = @intCast(m.so);
            const eo: usize = @intCast(m.eo);
            cno = @intCast(consumed + so + 1);
            if (o.only_matching)
                showLineHeader(o, name, lno, cno, sign)
            else
                outputColor(o, line[0..so], line_color);
            outputColor(o, line[so..eo], match_color);
            if (o.only_matching) output(o, "\n");
            line = line[eo..];
            consumed += eo;
            eflags = regex.REG_NOTBOL;
        }
    }
    if (!o.only_matching) {
        outputColor(o, line, line_color);
        output(o, "\n");
    }
}

// ---------------- sources ----------------

pub const SourceKind = enum { file, oid };

pub const Source = struct {
    kind: SourceKind,
    /// display name
    name: []const u8,
    /// path used for attribute lookup (may be null)
    path: ?[]const u8,
    /// worktree file path (kind == .file)
    file: []const u8 = "",
    oid: Oid = hash.zero,
    buf: ?[]const u8 = null,
    driver: ?*userdiff.Driver = null,
};

fn loadDriver(gs: *Source) void {
    if (gs.driver != null) return;
    if (gs.path) |p| gs.driver = userdiff.findByPath(p);
    if (gs.driver == null) gs.driver = userdiff.findByName("default");
}

fn sourceLoad(gs: *Source) bool {
    if (gs.buf != null) return true;
    switch (gs.kind) {
        .file => {
            const st = os.lstatPath(gs.file) orelse {
                const e = os.errno();
                if (e != os.ENOENT) util.err("failed to stat '{s}': {s}", .{ gs.file, os.strErr(e) });
                return false;
            };
            if (!st.isReg()) return false;
            const data = os.readFile(gs.file) orelse return false;
            gs.buf = data;
            return true;
        },
        .oid => {
            const obj = repo_mod.repo().odb().read(gs.oid) orelse {
                util.err("'{s}': unable to read {s}", .{ gs.name, &hash.hex(gs.oid) });
                return false;
            };
            gs.buf = obj.data;
            return true;
        },
    }
}

fn sourceIsBinary(gs: *Source) bool {
    loadDriver(gs);
    if (gs.driver.?.binary != -1) return gs.driver.?.binary == 1;
    if (sourceLoad(gs)) {
        const b = gs.buf.?;
        const n = @min(b.len, 8000);
        return std.mem.indexOfScalar(u8, b[0..n], 0) != null;
    }
    return false;
}

fn fillTextconv(driver: ?*userdiff.Driver, gs: *Source) bool {
    const d = driver orelse return sourceLoad(gs);
    if (d.textconv == null) return sourceLoad(gs);
    // fill_textconv_grep(): go through diff.c fill_textconv() (temp files, notes cache)
    const diff = @import("diff.zig");
    const df = switch (gs.kind) {
        .file => diff.allocFilespec(gs.file, hash.zero, false, 0o100644),
        .oid => diff.allocFilespec(gs.path orelse gs.name, gs.oid, true, 0o100644),
    };
    gs.buf = diff.fillTextconv(d, df);
    return true;
}

// funcname matching state (xecfg) per grep_source_1 call
const FfState = enum { unset, none, have };

var ff_state: FfState = .unset;
var ff: xdiff.FindFunc = undefined;
var ff_cache: std.AutoHashMapUnmanaged(*userdiff.Driver, *xdiff.RegexFindFunc) = .empty;

fn matchFuncname(gs: *Source, line: []const u8) bool {
    if (ff_state == .unset) {
        loadDriver(gs);
        const d = gs.driver.?;
        if (d.funcname) |pat| {
            const rf = ff_cache.get(d) orelse blk: {
                const n = xdiff.RegexFindFunc.init(pat, .{ .extended = d.funcname_extended, .icase = d.funcname_icase });
                ff_cache.put(gpa, d, n) catch util.oom();
                break :blk n;
            };
            ff = rf.findFunc();
            ff_state = .have;
        } else ff_state = .none;
    }
    if (ff_state == .have) {
        var b: [1]u8 = undefined;
        return ff.func(ff.ctx, line, &b) >= 0;
    }
    if (line.len == 0) return false;
    const ch = line[0];
    return std.ascii.isAlphabetic(ch) or ch == '_' or ch == '$';
}

fn byteAt(buf: []const u8, i: usize) u8 {
    return if (i < buf.len) buf[i] else 0;
}

fn isEmptyLine(buf: []const u8, bol0: usize, eol: usize) bool {
    var bol = bol0;
    while (bol < eol and std.ascii.isWhitespace(byteAt(buf, bol))) bol += 1;
    return bol == eol;
}

fn lineAt(buf: []const u8, bol: usize, eol: usize) []const u8 {
    const e = @min(eol, buf.len);
    const b = @min(bol, e);
    return buf[b..e];
}

fn showFuncnameLine(o: *Opt, gs: *Source, bol0: usize, lno0: u32) void {
    const buf = gs.buf.?;
    var bol = bol0;
    var lno = lno0;
    while (bol > 0) {
        bol -= 1;
        const eol = bol;
        while (bol > 0 and buf[bol - 1] != '\n') bol -= 1;
        lno -= 1;
        if (lno <= o.last_shown) break;
        if (matchFuncname(gs, buf[bol..eol])) {
            showLine(o, buf[bol..eol], gs.name, lno, 0, '=');
            break;
        }
    }
}

fn showPreContext(o: *Opt, gs: *Source, bol0: usize, end: usize, lno: u32) void {
    const buf = gs.buf.?;
    var bol = bol0;
    var cur = lno;
    var from: u32 = 1;
    var funcname_lno: u32 = 0;
    var funcname_needed = o.funcname;
    var comment_needed = false;
    const pre: u32 = @bitCast(o.pre_context);
    if (pre < lno) from = lno - pre;
    if (from <= o.last_shown) from = o.last_shown + 1;
    const orig_from = from;
    if (o.funcbody) {
        if (matchFuncname(gs, lineAt(buf, bol, end)))
            comment_needed = true
        else
            funcname_needed = true;
        from = o.last_shown + 1;
    }
    // Rewind.
    while (bol > 0 and cur > from) {
        const next_bol = bol;
        bol -= 1;
        const eol = bol;
        while (bol > 0 and buf[bol - 1] != '\n') bol -= 1;
        cur -= 1;
        if (comment_needed and (isEmptyLine(buf, bol, eol) or matchFuncname(gs, buf[bol..eol]))) {
            comment_needed = false;
            from = orig_from;
            if (cur < from) {
                cur += 1;
                bol = next_bol;
                break;
            }
        }
        if (funcname_needed and matchFuncname(gs, buf[bol..eol])) {
            funcname_lno = cur;
            funcname_needed = false;
            if (o.funcbody)
                comment_needed = true
            else
                from = orig_from;
        }
    }
    if (o.funcname and funcname_needed) showFuncnameLine(o, gs, bol, cur);
    // Back forward.
    while (cur < lno) {
        var eol = bol;
        while (buf[eol] != '\n') eol += 1;
        const sign: u8 = if (cur == funcname_lno) '=' else '-';
        showLine(o, buf[bol..eol], gs.name, cur, 0, sign);
        bol = eol + 1;
        cur += 1;
    }
}

fn shouldLookahead(o: *Opt) bool {
    if (o.expr != null) return false;
    if (o.invert) return false;
    for (o.patterns.items) |p| if (p.token != .pattern) return false;
    return true;
}

/// look_ahead(): 1 = no more hits, 0 = moved to the line of the next possible hit.
fn lookAhead(o: *Opt, buf: []const u8, left: *usize, lno: *u32, bol: *usize) i32 {
    var earliest: isize = -1;
    const region = buf[bol.*..@min(buf.len, bol.* + left.*)];
    for (o.patterns.items) |p| {
        const m = p.re.?.exec(region, 0) orelse continue;
        if (m.so < 0 or m.eo < 0) continue;
        if (earliest < 0 or m.so < earliest) earliest = m.so;
    }
    if (earliest < 0) {
        bol.* += left.*;
        left.* = 0;
        return 1;
    }
    var sp: usize = bol.* + @as(usize, @intCast(earliest));
    while (bol.* < sp and buf[sp - 1] != '\n') sp -= 1;
    const last_bol = sp;
    var n = lno.*;
    for (buf[bol.*..last_bol]) |ch| {
        if (ch == '\n') n += 1;
    }
    left.* -= last_bol - bol.*;
    bol.* = last_bol;
    lno.* = n;
    return 0;
}

fn endOfLine(buf: []const u8, cp0: usize, left: *usize) usize {
    var l = left.*;
    var cp = cp0;
    while (l > 0 and byteAt(buf, cp) != '\n') {
        l -= 1;
        cp += 1;
    }
    left.* = l;
    return cp;
}

fn grepSource1(o: *Opt, gs: *Source, collect_hits: bool) bool {
    var last_hit: u32 = 0;
    var binary_match_only = false;
    var count: u32 = 0;
    var show_function = false;
    var textconv: ?*userdiff.Driver = null;

    if (o.pre_context != 0 or o.post_context != 0 or o.file_break or o.funcbody) {
        if (o.last_shown != 0) o.show_hunk_mark = true;
    }
    o.last_shown = 0;

    if (o.allow_textconv) {
        loadDriver(gs);
        textconv = userdiff.getTextconv(gs.driver.?);
    }
    if (textconv == null) {
        switch (o.binary) {
            0 => {
                if (sourceIsBinary(gs)) binary_match_only = true;
            },
            1 => {
                if (sourceIsBinary(gs)) return false;
            },
            else => {},
        }
    }
    ff_state = .unset;
    var try_lookahead = shouldLookahead(o);
    if (!fillTextconv(textconv, gs)) return false;
    const buf = gs.buf.?;
    var bol: usize = 0;
    var left: usize = buf.len;
    var lno: u32 = 1;
    var peek_bol: ?usize = null;
    const post: u32 = @bitCast(o.post_context);

    while (left > 0) {
        var col: isize = -1;
        var icol: isize = -1;
        if (try_lookahead and !(last_hit != 0 and (show_function or lno <= last_hit +% post))) {
            const r = lookAhead(o, buf, &left, &lno, &bol);
            if (r < 0) {
                try_lookahead = false;
            } else if (r == 1) break;
        }
        const eol = endOfLine(buf, bol, &left);
        const line = lineAt(buf, bol, eol);
        var hit = matchLine(o, line, &col, &icol, collect_hits);
        if (!collect_hits) blk: {
            if (o.invert) hit = !hit;
            if (o.unmatch_name_only) {
                if (hit) return false;
                break :blk;
            }
            if (hit and (o.max_count < 0 or count < @as(u32, @intCast(o.max_count)))) {
                count += 1;
                if (o.status_only) return true;
                if (o.name_only) {
                    showName(o, gs.name);
                    return true;
                }
                if (o.count) break :blk;
                if (binary_match_only) {
                    output(o, "Binary file ");
                    outputColor(o, gs.name, o.colors[COLOR_FILENAME]);
                    output(o, " matches\n");
                    return true;
                }
                if (o.pre_context != 0 or o.funcbody)
                    showPreContext(o, gs, bol, eol, lno)
                else if (o.funcname)
                    showFuncnameLine(o, gs, bol, lno);
                var cno = if (o.invert) icol else col;
                if (cno < 0) cno = 0;
                showLine(o, line, gs.name, lno, cno + 1, ':');
                last_hit = lno;
                if (o.funcbody) show_function = true;
                break :blk;
            }
            if (show_function and (peek_bol == null or peek_bol.? < bol)) {
                var peek_left = left;
                var peek_eol = eol;
                var pb = bol;
                while (pb <= buf.len and isEmptyLine(buf, pb, peek_eol)) {
                    pb = peek_eol + 1;
                    peek_eol = endOfLine(buf, pb, &peek_left);
                }
                peek_bol = pb;
                if (pb >= buf.len or matchFuncname(gs, lineAt(buf, pb, peek_eol)))
                    show_function = false;
            }
            if (show_function or (last_hit != 0 and lno <= last_hit +% post)) {
                showLine(o, line, gs.name, lno, col + 1, '-');
            }
        }
        // next_line
        bol = eol + 1;
        if (left == 0) break;
        left -= 1;
        lno += 1;
    }
    if (collect_hits) return false;
    if (o.status_only) return o.unmatch_name_only;
    if (o.unmatch_name_only) {
        showName(o, gs.name);
        return true;
    }
    if (o.count and count != 0) {
        if (o.pathname != 0) {
            outputColor(o, gs.name, o.colors[COLOR_FILENAME]);
            outputSep(o, ':');
        }
        output(o, util.fmt("{d}\n", .{count}));
        return true;
    }
    return last_hit != 0;
}

fn clrHitMarker(x0: *Node) void {
    var x = x0;
    while (true) {
        x.hit = false;
        if (x.kind != .or_) return;
        x.left.?.hit = false;
        x = x.right.?;
    }
}

fn chkHitMarker(x0: *Node) bool {
    var x = x0;
    while (true) {
        if (x.kind != .or_) return x.hit;
        if (!x.left.?.hit) return false;
        x = x.right.?;
    }
}

pub fn grepSource(o: *Opt, gs: *Source) bool {
    if (!o.all_match) return grepSource1(o, gs, false);
    if (o.expr) |x| {
        clrHitMarker(x);
        _ = grepSource1(o, gs, true);
        if (!chkHitMarker(x)) return false;
    }
    return grepSource1(o, gs, false);
}
