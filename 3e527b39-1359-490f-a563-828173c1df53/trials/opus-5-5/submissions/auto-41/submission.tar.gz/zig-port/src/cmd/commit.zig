//! git commit

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const sparse_index = @import("../sparse_index.zig");
const pathspec_mod = @import("../pathspec.zig");
const lockfile = @import("../lockfile.zig");
const advice = @import("../advice.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const ident = @import("../ident.zig");
const date = @import("../date.zig");
const hook = @import("../hook.zig");
const editor = @import("../editor.zig");
const commit_mod = @import("../commit.zig");
const wtstatus = @import("../wtstatus.zig");
const summary = @import("../summary.zig");
const cn = @import("../commitnode.zig");
const commitreach = @import("../commitreach.zig");
const pretty = @import("../pretty.zig");
const trailer = @import("../pretty_trailer.zig");
const add_patch = @import("../add_patch.zig");
const Oid = hash.Oid;
const gpa = util.gpa;

const usage = [_][]const u8{
    "git commit [-a | --interactive | --patch] [-s] [-v] [-u[<mode>]] [--amend]\n" ++
        "           [--dry-run] [(-c | -C | --squash) <commit> | --fixup [(amend|reword):]<commit>]\n" ++
        "           [-F <file> | -m <msg>] [--reset-author] [--allow-empty]\n" ++
        "           [--allow-empty-message] [--no-verify] [-e] [--author=<author>]\n" ++
        "           [--date=<date>] [--cleanup=<mode>] [--[no-]status]\n" ++
        "           [-i | -o] [--pathspec-from-file=<file> [--pathspec-file-nul]]\n" ++
        "           [(--trailer <token>[(=|:)<value>])...] [-S[<keyid>]]\n" ++
        "           [--] [<pathspec>...]",
};

const empty_amend_advice =
    "You asked to amend the most recent commit, but doing so would make\n" ++
    "it empty. You can repeat your command with --allow-empty, or you can\n" ++
    "remove the commit entirely with \"git reset HEAD^\".\n";

const empty_cherry_pick_advice =
    "The previous cherry-pick is now empty, possibly due to conflict resolution.\n" ++
    "If you wish to commit it anyway, use:\n" ++
    "\n" ++
    "    git commit --allow-empty\n" ++
    "\n";

const empty_rebase_pick_advice = "Otherwise, please use 'git rebase --skip'\n";
const empty_cherry_pick_advice_single = "Otherwise, please use 'git cherry-pick --skip'\n";
const empty_cherry_pick_advice_multi =
    "and then use:\n" ++
    "\n" ++
    "    git cherry-pick --continue\n" ++
    "\n" ++
    "to resume cherry-picking the remaining commits.\n" ++
    "If you wish to skip this commit, use:\n" ++
    "\n" ++
    "    git cherry-pick --skip\n" ++
    "\n";

const CommitStyle = enum { as_is, normal, partial };
pub const Cleanup = enum { none, space, all, scissors };
const Whence = wtstatus.Whence;

var commit_style: CommitStyle = .as_is;
var index_lock: ?*lockfile.Lock = null;
var false_lock: ?*lockfile.Lock = null;

var force_author: ?[]const u8 = null;
var logfile: ?[]const u8 = null;
var template_file: ?[]const u8 = null;
var author_message: ?[]const u8 = null;
var author_message_buffer: []const u8 = "";
var edit_message: ?[]const u8 = null;
var use_message: ?[]const u8 = null;
var use_message_buffer: []const u8 = "";
var fixup_message: ?[]const u8 = null;
var fixup_commit: []const u8 = "";
var fixup_prefix: []const u8 = "";
var squash_message: ?[]const u8 = null;
var all = false;
var also = false;
var interactive = false;
var patch_interactive = false;
var only = false;
var amend = false;
var signoff = false;
var edit_flag: i32 = -1;
var quiet: i32 = 0;
var verbose: i32 = -1;
var no_verify = false;
var allow_empty = false;
var dry_run = false;
var renew_authorship = false;
var config_commit_verbose: i32 = -1;
var no_post_rewrite = false;
var allow_empty_message = false;
var pathspec_file_nul = false;
var untracked_files_arg: ?[]const u8 = null;
var force_date: ?[]const u8 = null;
var sign_commit: ?[]const u8 = null;
var pathspec_from_file: ?[]const u8 = null;
var trailer_args: std.ArrayList([]const u8) = .empty;
var cleanup_arg: ?[]const u8 = null;
var cleanup_config: ?[]const u8 = null;
var cleanup_mode: Cleanup = .all;
var whence: Whence = .commit;
var use_editor = true;
var include_status = true;
var have_option_m = false;
var message: util.Buf = .empty;
var status_format: i32 = -1; // -1 = unspecified (wtstatus.Format)
var show_branch: i32 = -1;
var ahead_behind: i32 = -1;
var null_termination = false;
var unified: i32 = -1;
var inter_hunk: i32 = -1;
var opt_include_status: i32 = -1;

const FMT_SHORT: i32 = @intFromEnum(wtstatus.Format.short);
const FMT_PORCELAIN: i32 = @intFromEnum(wtstatus.Format.porcelain);
const FMT_LONG: i32 = @intFromEnum(wtstatus.Format.long);
const FMT_NONE: i32 = @intFromEnum(wtstatus.Format.none);

fn optM(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        have_option_m = false;
        message.clearRetainingCapacity();
        return;
    }
    have_option_m = true;
    if (message.items.len > 0) util.bufByte(&message, '\n');
    util.bufAppend(&message, arg.?);
    if (message.items.len > 0 and message.items[message.items.len - 1] != '\n') util.bufByte(&message, '\n');
}

fn optStatus(_: ?[]const u8, unset: bool) void {
    opt_include_status = if (unset) 0 else 1;
}

const options = [_]po.Opt{
    .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet, .help = "suppress summary after successful commit" },
    .{ .short = 'v', .long = "verbose", .kind = .counter, .i = &verbose, .help = "show diff in commit message template" },
    po.group("Commit message options"),
    po.filename('F', "file", &logfile, "file", "read message from file"),
    po.string(0, "author", &force_author, "author", "override author for commit"),
    po.string(0, "date", &force_date, "date", "override date for commit"),
    po.callback('m', "message", optM, "message", "commit message"),
    po.string('c', "reedit-message", &edit_message, "commit", "reuse and edit message from specified commit"),
    po.string('C', "reuse-message", &use_message, "commit", "reuse message from specified commit"),
    po.string(0, "fixup", &fixup_message, "[(amend|reword):]commit", "use autosquash formatted message to fixup or amend/reword specified commit"),
    po.string(0, "squash", &squash_message, "commit", "use autosquash formatted message to squash specified commit"),
    po.boolean(0, "reset-author", &renew_authorship, "the commit is authored by me now (used with -C/-c/--amend)"),
    po.list(0, "trailer", &trailer_args, "trailer", "add custom trailer(s)"),
    po.boolean('s', "signoff", &signoff, "add a Signed-off-by trailer"),
    po.filename('t', "template", &template_file, "file", "use specified template file"),
    .{ .short = 'e', .long = "edit", .kind = .set_int, .i = &edit_flag, .val = 1, .help = "force edit of commit" },
    po.string(0, "cleanup", &cleanup_arg, "mode", "how to strip spaces and #comments from message"),
    .{ .long = "status", .kind = .set_int, .i = &opt_include_status, .val = 1, .help = "include status in commit message template" },
    po.optString('S', "gpg-sign", &sign_commit, "", "key-id", "GPG sign commit"),
    po.group("Commit contents options"),
    po.boolean('a', "all", &all, "commit all changed files"),
    po.boolean('i', "include", &also, "add specified files to index for commit"),
    po.boolean(0, "interactive", &interactive, "interactively add files"),
    po.boolean('p', "patch", &patch_interactive, "interactively add changes"),
    .{ .short = 'U', .long = "unified", .kind = .int, .i = &unified, .argh = "n", .noneg = true, .help = "generate diffs with <n> lines context" },
    .{ .long = "inter-hunk-context", .kind = .int, .i = &inter_hunk, .argh = "n", .noneg = true, .help = "show context between diff hunks up to the specified number of lines" },
    po.boolean('o', "only", &only, "commit only specified files"),
    po.boolean('n', "no-verify", &no_verify, "bypass pre-commit and commit-msg hooks"),
    po.boolean(0, "dry-run", &dry_run, "show what would be committed"),
    po.setInt(0, "short", &status_format, FMT_SHORT, "show status concisely"),
    po.setInt(0, "branch", &show_branch, 1, "show branch information"),
    po.setInt(0, "ahead-behind", &ahead_behind, 1, "compute full ahead/behind values"),
    po.setInt(0, "porcelain", &status_format, FMT_PORCELAIN, "machine-readable output"),
    po.setInt(0, "long", &status_format, FMT_LONG, "show status in long format (default)"),
    po.boolean('z', "null", &null_termination, "terminate entries with NUL"),
    po.boolean(0, "amend", &amend, "amend previous commit"),
    po.boolean(0, "no-post-rewrite", &no_post_rewrite, "bypass post-rewrite hook"),
    po.optString('u', "untracked-files", &untracked_files_arg, "all", "mode", "show untracked files, optional modes: all, normal, no. (Default: all)"),
    po.filename(0, "pathspec-from-file", &pathspec_from_file, "file", "read pathspec from file"),
    po.boolean(0, "pathspec-file-nul", &pathspec_file_nul, "with --pathspec-from-file, pathspec elements are separated with NUL character"),
    .{ .long = "allow-empty", .kind = .boolean, .b = &allow_empty, .hidden = true, .help = "ok to record an empty change" },
    .{ .long = "allow-empty-message", .kind = .boolean, .b = &allow_empty_message, .hidden = true, .help = "ok to record a change with an empty message" },
};

// ---------------------------------------------------------------------------

fn isFromCherryPick(w: Whence) bool {
    return w == .cherry_pick_single or w == .cherry_pick_multi;
}
fn isFromRebase(w: Whence) bool {
    return w == .rebase_pick;
}

fn determineWhence() Whence {
    const r = repo_mod.repo();
    if (os.exists(r.gitPath("MERGE_HEAD"))) return .merge;
    if (refs.exists("CHERRY_PICK_HEAD")) {
        if (os.exists(r.gitPath("rebase-merge")) or os.exists(r.gitPath("rebase-apply"))) {
            const rh = revparse.getOid("REBASE_HEAD");
            const ch = revparse.getOid("CHERRY_PICK_HEAD");
            if (rh != null and ch != null and hash.eql(rh.?, ch.?)) return .rebase_pick;
        }
        if (os.exists(r.gitPath("sequencer"))) return .cherry_pick_multi;
        return .cherry_pick_single;
    }
    return .commit;
}

fn rollbackIndexFiles() void {
    switch (commit_style) {
        .as_is => {},
        .normal => if (index_lock) |l| l.rollback(),
        .partial => {
            if (index_lock) |l| l.rollback();
            if (false_lock) |l| l.rollback();
        },
    }
}

fn commitIndexFiles() bool {
    var ok = true;
    switch (commit_style) {
        .as_is => {},
        .normal => if (index_lock) |l| {
            ok = l.commit();
        },
        .partial => {
            if (index_lock) |l| ok = l.commit();
            if (false_lock) |l| l.rollback();
        },
    }
    return ok;
}

fn refreshOrDie(idx: *index_mod.Index, flags: u32) void {
    if (index_mod.refresh(idx, flags | index_mod.REFRESH_IN_PORCELAIN, @as(?*const pathspec_mod.Pathspec, null), null))
        advice.dieResolveConflict("commit");
}

const PartialItem = struct { path: []const u8, skip_worktree: bool };

fn listPaths(list: *std.ArrayList(PartialItem), idx: *index_mod.Index, head_tree: ?Oid, ps: *const pathspec_mod.Pathspec) bool {
    if (ps.items.len == 0) return false;
    // list_paths(): "TODO: audit for interaction with sparse-index."
    sparse_index.ensureFull(idx);
    const seen = ps.newSeen();
    var names: std.ArrayList(PartialItem) = .empty;
    for (idx.entries.items) |*e| {
        names.append(gpa, .{ .path = e.path, .skip_worktree = e.skipWorktree() }) catch util.oom();
    }
    if (head_tree) |t| {
        var flat: std.ArrayList(objects.FlatEntry) = .empty;
        objects.flattenTree(t, "", &flat);
        for (flat.items) |fe| {
            if (idx.firstPos(fe.path) < idx.entries.items.len and util.eql(idx.entries.items[idx.firstPos(fe.path)].path, fe.path)) continue;
            names.append(gpa, .{ .path = fe.path, .skip_worktree = false }) catch util.oom();
        }
    }
    for (names.items) |n| {
        if (ps.matchSeen(n.path, false, seen) == 0) continue;
        var dup = false;
        for (list.items) |*x| {
            if (util.eql(x.path, n.path)) {
                if (n.skip_worktree) x.skip_worktree = true;
                dup = true;
                break;
            }
        }
        if (!dup) list.append(gpa, n) catch util.oom();
    }
    return ps.reportPathError(seen) != 0;
}

fn addRemoveFiles(idx: *index_mod.Index, list: []const PartialItem) void {
    for (list) |p| {
        if (p.skip_worktree) continue;
        if (os.lstatPath(p.path)) |st| {
            if (index_mod.addToIndex(idx, p.path, st, 0)) util.die("updating files failed", .{});
        } else {
            index_mod.removeFileWithFlags(idx, p.path, 0);
        }
    }
}

fn headTree(head: ?Oid) ?Oid {
    const h = head orelse return null;
    const c = objects.readCommit(h) orelse util.die("could not parse HEAD commit", .{});
    return c.tree;
}

/// Returns the path of the index file to commit.
fn prepareIndex(args: []const []const u8, current_head: ?Oid, is_status: bool) []const u8 {
    const r = repo_mod.repo();
    if (unified < -1) util.die("'{s}' cannot be negative", .{"--unified"});
    if (inter_hunk < -1) util.die("'{s}' cannot be negative", .{"--inter-hunk-context"});
    var refresh_flags: u32 = index_mod.REFRESH_QUIET;
    if (is_status) refresh_flags |= index_mod.REFRESH_UNMERGED;
    const ps_flags = pathspec_mod.Flags{ .prefer_full = true };
    var ps = pathspec_mod.parse(r.prefix, args, ps_flags);
    if (pathspec_from_file) |pf| {
        if (interactive) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "--interactive/--patch" });
        if (all) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "-a" });
        if (ps.items.len > 0) util.die("'{s}' and pathspec arguments cannot be used together", .{"--pathspec-from-file"});
        ps = pathspec_mod.parse(r.prefix, pathspec_mod.readPathspecFile(pf, pathspec_file_nul), ps_flags);
    } else if (pathspec_file_nul) {
        util.die("the option '{s}' requires '{s}'", .{ "--pathspec-file-nul", "--pathspec-from-file" });
    }
    if (ps.items.len == 0 and (also or (only and !allow_empty and
        (!amend or (fixup_message != null and !util.eql(fixup_prefix, "amend"))))))
        util.die("No paths with --include/--only does not make sense.", .{});

    if (interactive) {
        const idx = index_mod.lockAndRead();
        index_lock = idx.lock;
        refreshOrDie(idx, refresh_flags);
        idx.writeToLock();
        const lock = idx.lock.?;
        const ips = pathspec_mod.parse(r.prefix, args, .{ .prefer_full = true, .symlink_leading_path = true, .prefix_origin = true });
        const iopts = add_patch.Options{ .context = unified, .interhunkcontext = inter_hunk };
        const saved_cwd = os.getcwd();
        add_patch.index_override = lock.lock_path;
        const rc = if (patch_interactive) add_patch.runPathspec(.add, iopts, null, &ips, 0) else @import("../add_interactive.zig").run(&ips, iopts);
        add_patch.index_override = null;
        if (!util.eql(os.getcwd(), saved_cwd)) _ = repo_mod.chdirNotify(saved_cwd);
        if (rc != 0) util.die("interactive add failed", .{});
        const nidx = index_mod.readFrom(lock.lock_path);
        nidx.lock = lock;
        if (nidx.writeTree(true) != null) {
            // reopen_lock_file(): the children replaced the lock file
            if (lock.fd >= 0) os.close(lock.fd);
            lock.fd = os.openFile(lock.lock_path, os.O_WRONLY | os.O_TRUNC | os.O_CLOEXEC, 0);
            if (lock.fd < 0) util.die("unable to write index file", .{});
            nidx.writeToLock();
        } else util.warn("Failed to update main cache tree", .{});
        commit_style = .normal;
        return lock.lock_path;
    } else {
        if (unified != -1) util.die("the option '{s}' requires '{s}'", .{ "--unified", "--interactive/--patch" });
        if (inter_hunk != -1) util.die("the option '{s}' requires '{s}'", .{ "--inter-hunk-context", "--interactive/--patch" });
    }

    if (all or (also and ps.items.len > 0)) {
        const idx = index_mod.lockAndRead();
        index_lock = idx.lock;
        const seen = ps.newSeen();
        _ = index_mod.addFilesToCache(idx, @as(?*const pathspec_mod.Pathspec, &ps), seen, 0);
        if (!all and ps.reportPathError(seen) != 0) os.exit(128);
        refreshOrDie(idx, refresh_flags);
        _ = idx.writeTree(true);
        idx.writeToLock();
        commit_style = .normal;
        return idx.lock.?.lock_path;
    }

    if (!only and ps.items.len == 0) {
        const idx = index_mod.lockAndRead();
        refreshOrDie(idx, refresh_flags);
        _ = idx.writeTree(true);
        idx.write();
        commit_style = .as_is;
        return r.indexPath();
    }

    commit_style = .partial;
    if (whence != .commit) {
        if (whence == .merge) util.die("cannot do a partial commit during a merge.", .{});
        if (isFromCherryPick(whence)) util.die("cannot do a partial commit during a cherry-pick.", .{});
        if (isFromRebase(whence)) util.die("cannot do a partial commit during a rebase.", .{});
    }
    var partial: std.ArrayList(PartialItem) = .empty;
    {
        const ro = index_mod.readFrom(r.indexPath());
        if (listPaths(&partial, ro, headTree(current_head), &ps)) os.exit(1);
    }
    std.mem.sort(PartialItem, partial.items, {}, struct {
        fn lt(_: void, a: PartialItem, b: PartialItem) bool {
            return std.mem.order(u8, a.path, b.path) == .lt;
        }
    }.lt);

    const idx = index_mod.lockAndRead();
    index_lock = idx.lock;
    addRemoveFiles(idx, partial.items);
    _ = index_mod.refresh(idx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
    _ = idx.writeTree(true);
    idx.writeToLock();

    const fpath = r.gitPath(util.fmt("next-index-{d}", .{std.c.getpid()}));
    const fidx = gpa.create(index_mod.Index) catch util.oom();
    fidx.* = .{};
    fidx.path = fpath;
    fidx.lock = lockfile.lockOrDie(fpath);
    false_lock = fidx.lock;
    index_mod.resetToTree(fidx, headTree(current_head));
    addRemoveFiles(fidx, partial.items);
    _ = index_mod.refresh(fidx, index_mod.REFRESH_QUIET, @as(?*const pathspec_mod.Pathspec, null), null);
    fidx.writeToLock();
    return fidx.lock.?.lock_path;
}

// ---------------------------------------------------------------------------
// status

fn setupStatus(s: *wtstatus.Status) void {
    s.commit_template = true;
    s.whence = whence;
    // handle_untracked_files_arg()
    if (untracked_files_arg) |u| {
        const m = wtstatus.parseUntrackedSetting(u);
        if (m == .err) util.die("Invalid untracked files mode '{s}'", .{u});
        s.show_untracked_files = m;
    }
}

fn runStatus(out: *util.Out, index_file: []const u8, nowarn: bool, s: *wtstatus.Status) void {
    const r = repo_mod.repo();
    if (s.relative_paths) s.prefix = r.prefix;
    if (amend) {
        s.amend = true;
        s.reference = "HEAD^1";
    }
    s.verbose = verbose;
    s.index_file = index_file;
    s.out = out;
    s.nowarn = nowarn;
    if (revparse.getOid(s.reference)) |o| {
        s.is_initial = false;
        s.oid_commit = o;
    } else s.is_initial = true;
    s.status_format = @enumFromInt(status_format);
    wtstatus.collect(s);
    wtstatus.print(s);
    out.flush();
}

/// index_differs_from / initial-commit check: is there anything to commit?
fn computeCommittable(index_file: []const u8) bool {
    const idx = index_mod.readFrom(index_file);
    const parent = if (amend) "HEAD^1" else "HEAD";
    const poid = revparse.getCommit(parent) orelse {
        var n: usize = 0;
        for (idx.entries.items) |*e| {
            if (!e.intentToAdd()) n += 1;
        }
        return n > 0;
    };
    const c = objects.readCommit(poid) orelse return true;
    var flat: std.ArrayList(objects.FlatEntry) = .empty;
    // sparse index: equal sparse directories are skipped on both sides,
    // differing ones are compared at the file level
    sparse_index.flattenTreeSparse(idx, c.tree, "", &flat);
    var i: usize = 0;
    var j: usize = 0;
    const ents = sparse_index.virtualEntries(idx, c.tree);
    while (true) {
        while (i < ents.len and ents[i].intentToAdd() and ents[i].stage() == 0) i += 1;
        if (i >= ents.len or j >= flat.items.len) return i < ents.len or j < flat.items.len;
        const e = &ents[i];
        if (e.stage() != 0) return true;
        const fe = flat.items[j];
        if (!util.eql(e.path, fe.path)) return true;
        if (e.mode != fe.mode or !hash.eql(e.oid, fe.oid)) return true;
        i += 1;
        j += 1;
    }
}

// ---------------------------------------------------------------------------
// messages

fn commentStr() []const u8 {
    return trailer.commentLineStr();
}

pub fn getCleanupMode(cleanup: ?[]const u8, editor_used: bool) Cleanup {
    const c = cleanup orelse return if (editor_used) .all else .space;
    if (util.eql(c, "default")) return if (editor_used) .all else .space;
    if (util.eql(c, "verbatim")) return .none;
    if (util.eql(c, "whitespace")) return .space;
    if (util.eql(c, "strip")) return .all;
    if (util.eql(c, "scissors")) return if (editor_used) .scissors else .space;
    util.die("Invalid cleanup mode {s}", .{c});
}

const sign_off_header = "Signed-off-by: ";

fn restIsEmpty(sb: []const u8, start: usize) bool {
    var i = start;
    while (i < sb.len) : (i += 1) {
        const eol = std.mem.indexOfScalarPos(u8, sb, i, '\n') orelse sb.len;
        if (sign_off_header.len <= eol - i and util.startsWith(sb[i..], sign_off_header)) {
            i = eol;
            continue;
        }
        while (i < eol) {
            if (!std.ascii.isWhitespace(sb[i])) return false;
            i += 1;
        }
    }
    return true;
}

fn messageIsEmpty(sb: []const u8, mode: Cleanup) bool {
    if (mode == .none and sb.len > 0) return false;
    return restIsEmpty(sb, 0);
}

fn templateUntouched(sb: []const u8, tmpl_file: ?[]const u8, mode: Cleanup) bool {
    if (mode == .none and sb.len > 0) return false;
    const tf = tmpl_file orelse return false;
    const raw = os.readFile(tf) orelse return false;
    if (raw.len == 0) return false;
    const tmpl = util.stripspace(raw, if (mode == .all) commentStr() else null);
    const start: usize = if (util.startsWith(sb, tmpl)) tmpl.len else 0;
    return restIsEmpty(sb, start);
}

pub fn cleanupMessage(sb: []const u8, mode: Cleanup, verb: i32) []const u8 {
    var m = sb;
    if (verb != 0 or mode == .scissors) m = m[0..wtstatus.locateEnd(m)];
    if (mode != .none) return util.stripspace(m, if (mode == .all) commentStr() else null);
    return m;
}

pub fn hasConformingFooter(sb: []const u8, sob: []const u8, ignore_footer: usize) u8 {
    var it = trailer.Iterator.init(sb[0 .. sb.len - ignore_footer]);
    var i: usize = 0;
    var found_sob: usize = 0;
    while (it.next()) {
        i += 1;
        var raw = it.raw;
        if (!util.endsWith(raw, "\n")) raw = util.concat(&.{ raw, "\n" });
        if (util.startsWith(raw, sob)) found_sob = i;
    }
    if (i == 0) return 0;
    if (found_sob == i) return 3;
    if (found_sob != 0) return 2;
    return 1;
}

/// append_signoff (sequencer.c) without dedup.
pub fn appendSignoff(msg: *util.Buf, ignore_footer: usize, dedup: bool) void {
    const name = ident.sanitize(ident.getName(.committer) orelse "");
    const email = ident.sanitize(ident.getEmail(.committer) orelse "");
    _ = ident.committerStrict();
    const sob = util.fmt("{s}{s} <{s}>\n", .{ sign_off_header, name, email });
    if (ignore_footer == 0 and msg.items.len > 0 and msg.items[msg.items.len - 1] != '\n') util.bufByte(msg, '\n');
    var has_footer: u8 = undefined;
    if (msg.items.len - ignore_footer == sob.len and util.startsWith(msg.items, sob))
        has_footer = 3
    else
        has_footer = hasConformingFooter(msg.items, sob, ignore_footer);
    if (has_footer == 0) {
        const len = msg.items.len - ignore_footer;
        var nl: []const u8 = "";
        if (len == 0) nl = "\n\n" else if (len == 1) nl = "\n" else if (msg.items[len - 2] != '\n') nl = "\n";
        msg.insertSlice(gpa, len, nl) catch util.oom();
    }
    if (has_footer != 3 and (!dedup or has_footer != 2))
        msg.insertSlice(gpa, msg.items.len - ignore_footer, sob) catch util.oom();
}

fn rawCommitBuffer(oid: Oid) []const u8 {
    const o = repo_mod.repo().odb().read(oid) orelse return "";
    return o.data;
}

fn readCommitMessage(name: []const u8) []const u8 {
    const oid = revparse.getCommit(name) orelse util.die("could not lookup commit '{s}'", .{name});
    return rawCommitBuffer(oid);
}

fn lookupCommitByName(name: []const u8) *cn.Commit {
    const oid = revparse.getCommit(name) orelse util.die("could not lookup commit '{s}'", .{name});
    const c = cn.lookupCommit(oid) orelse util.die("could not lookup commit '{s}'", .{name});
    _ = cn.parse(c);
    return c;
}

fn formatCommit(c: *cn.Commit, f: []const u8, sb: *util.Buf) void {
    const ctx = pretty.Context{};
    pretty.formatCommitMessage(c, f, sb, &ctx);
}

fn findHeader(buf: []const u8, key: []const u8) ?[]const u8 {
    var it = std.mem.splitScalar(u8, buf, '\n');
    while (it.next()) |line| {
        if (line.len == 0) return null;
        if (util.startsWith(line, key) and line.len > key.len and line[key.len] == ' ') return line[key.len + 1 ..];
    }
    return null;
}

// ---------------------------------------------------------------------------
// author

fn findAuthorByNickname(name: []const u8) []const u8 {
    // walk all refs, newest first, looking for an author matching name (case-insensitive)
    var queue: std.ArrayList(*cn.Commit) = .empty;
    const lname = util.lower(name);
    var starts: std.ArrayList(Oid) = .empty;
    if (revparse.getCommit("HEAD")) |h| starts.append(gpa, h) catch util.oom();
    for (refs.list("refs/")) |rf| {
        if (objects.peelTo(rf.oid, .commit)) |o| starts.append(gpa, o) catch util.oom();
    }
    const SEEN: u32 = 1 << 27;
    for (starts.items) |o| {
        const c = cn.lookupCommit(o) orelse continue;
        if (c.obj.flags & SEEN != 0) continue;
        c.obj.flags |= SEEN;
        _ = cn.parse(c);
        queue.append(gpa, c) catch util.oom();
    }
    while (queue.items.len > 0) {
        var best: usize = 0;
        for (queue.items, 0..) |c, k| {
            if (c.date > queue.items[best].date) best = k;
        }
        const c = queue.orderedRemove(best);
        if (findHeader(c.buffer, "author")) |a| {
            if (std.mem.indexOf(u8, util.lower(a), lname) != null) {
                var b: util.Buf = .empty;
                formatCommit(c, "%aN <%aE>", &b);
                return b.items;
            }
        }
        var p = c.parents;
        while (p) |pl| : (p = pl.next) {
            if (pl.item.obj.flags & SEEN != 0) continue;
            pl.item.obj.flags |= SEEN;
            _ = cn.parse(pl.item);
            queue.append(gpa, pl.item) catch util.oom();
        }
    }
    util.die("--author '{s}' is not 'Name <email>' and matches no existing author", .{name});
}

fn parseForceDate(in: []const u8) ?[]const u8 {
    if (date.parseDateString(in)) |d| return util.concat(&.{ "@", d });
    var errors = false;
    const t = date.approxidateCareful(in, &errors);
    if (errors) return null;
    return util.fmt("@{d}", .{t});
}

fn determineAuthorInfo() []const u8 {
    var name: ?[]const u8 = os.getenv("GIT_AUTHOR_NAME");
    var email: ?[]const u8 = os.getenv("GIT_AUTHOR_EMAIL");
    var dt: ?[]const u8 = os.getenv("GIT_AUTHOR_DATE");
    if (author_message) |am| {
        const a = findHeader(author_message_buffer, "author") orelse util.die("commit '{s}' lacks author header", .{am});
        const sp = ident.split(a) orelse util.die("commit '{s}' has malformed author line", .{am});
        name = sp.name;
        email = sp.email;
        if (sp.date.len > 0) dt = util.concat(&.{ "@", sp.date });
    }
    if (force_author) |fa| {
        const sp = ident.split(fa) orelse util.die("malformed --author parameter", .{});
        name = sp.name;
        email = sp.email;
    }
    if (force_date) |fd| {
        dt = parseForceDate(fd) orelse util.die("invalid date format: {s}", .{fd});
    }
    if (name) |n| os.setEnv("GIT_AUTHOR_NAME", n);
    if (email) |e| os.setEnv("GIT_AUTHOR_EMAIL", e);
    if (dt) |d| os.setEnv("GIT_AUTHOR_DATE", d);
    const author_ident = ident.authorStrict();
    const sp = ident.split(author_ident).?;
    os.setEnv("GIT_AUTHOR_NAME", sp.name);
    os.setEnv("GIT_AUTHOR_EMAIL", sp.email);
    os.setEnv("GIT_AUTHOR_DATE", util.concat(&.{ "@", sp.date }));
    return author_ident;
}

fn authorDateIsInteresting() bool {
    return author_message != null or force_date != null;
}

// ---------------------------------------------------------------------------

fn runHook(index_file: []const u8, invoked: ?*bool, name: []const u8, a1: ?[]const u8, a2: ?[]const u8, a3: ?[]const u8) bool {
    var args: std.ArrayList([]const u8) = .empty;
    for ([_]?[]const u8{ a1, a2, a3 }) |a| {
        const v = a orelse break;
        args.append(gpa, v) catch util.oom();
    }
    return hook.runCommitHook(use_editor, index_file, invoked, name, args.items) != 0;
}

fn prepareToCommit(index_file: []const u8, current_head: ?Oid, s: *wtstatus.Status, author_ident_out: *[]const u8) bool {
    const r = repo_mod.repo();
    var hook_arg1: ?[]const u8 = null;
    var hook_arg2: ?[]const u8 = null;
    var clean_message_contents = cleanup_mode != .none;
    var invoked_hook = false;

    const author_ident = determineAuthorInfo();
    author_ident_out.* = author_ident;

    if (!no_verify and runHook(index_file, &invoked_hook, "pre-commit", null, null, null)) return false;

    var sb: util.Buf = .empty;
    if (squash_message) |sq| {
        if (use_message != null and util.eql(use_message.?, sq)) {
            util.bufAppend(&sb, "squash! ");
        } else {
            const c = lookupCommitByName(sq);
            formatCommit(c, "squash! %s\n\n", &sb);
        }
    }

    const merge_msg_path = r.gitPath("MERGE_MSG");
    const squash_msg_path = r.gitPath("SQUASH_MSG");
    if (have_option_m and fixup_message == null) {
        util.bufAppend(&sb, message.items);
        hook_arg1 = "message";
    } else if (logfile != null and util.eql(logfile.?, "-")) {
        if (os.isatty(0)) util.eprint("(reading log message from standard input)\n", .{});
        const data = os.readAllFd(0) catch util.dieErrno("could not read log from standard input", .{});
        util.bufAppend(&sb, data);
        hook_arg1 = "message";
    } else if (logfile) |lf| {
        const data = os.readFile(lf) orelse util.dieErrno("could not read log file '{s}'", .{lf});
        util.bufAppend(&sb, data);
        hook_arg1 = "message";
    } else if (use_message) |um| {
        if (std.mem.indexOf(u8, use_message_buffer, "\n\n")) |p| {
            util.bufAppend(&sb, use_message_buffer[pretty.skipBlankLines(use_message_buffer, p + 2)..]);
        }
        hook_arg1 = "commit";
        hook_arg2 = um;
    } else if (fixup_message != null) {
        const c = lookupCommitByName(fixup_commit);
        formatCommit(c, util.fmt("{s}! %s\n\n", .{fixup_prefix}), &sb);
        hook_arg1 = "message";
        if (have_option_m and util.eql(fixup_prefix, "fixup")) util.bufAppend(&sb, message.items);
        if (util.eql(fixup_prefix, "amend")) {
            if (have_option_m) util.die("options '{s}' and '{s}:{s}' cannot be used together", .{ "-m", "--fixup", fixup_message.? });
            const subj = pretty.findCommitSubject(c.buffer);
            formatCommit(c, if (util.startsWith(subj, "amend!")) "%b" else "%B", &sb);
        }
    } else if (os.statPath(merge_msg_path) != null) {
        if (os.statPath(squash_msg_path) != null) {
            util.bufAppend(&sb, os.readFile(squash_msg_path) orelse util.dieErrno("could not read SQUASH_MSG", .{}));
            hook_arg1 = "squash";
        } else hook_arg1 = "merge";
        const start = sb.items.len;
        util.bufAppend(&sb, os.readFile(merge_msg_path) orelse util.dieErrno("could not read MERGE_MSG", .{}));
        if (cleanup_mode == .scissors and wtstatus.locateEnd(sb.items[start..]) < sb.items.len - start)
            s.added_cut_line = true;
    } else if (os.statPath(squash_msg_path) != null) {
        util.bufAppend(&sb, os.readFile(squash_msg_path) orelse util.dieErrno("could not read SQUASH_MSG", .{}));
        hook_arg1 = "squash";
    } else if (template_file) |tf| {
        const data = os.readFile(tf) orelse util.dieErrno("could not read '{s}'", .{tf});
        util.bufAppend(&sb, data);
        hook_arg1 = "template";
        clean_message_contents = false;
    } else if (whence == .merge) {
        hook_arg1 = "merge";
    } else if (isFromCherryPick(whence) or whence == .rebase_pick) {
        hook_arg1 = "commit";
        hook_arg2 = "CHERRY_PICK_HEAD";
    }

    if (squash_message != null) {
        hook_arg1 = "message";
        hook_arg2 = "";
    }

    const editmsg = r.gitPath("COMMIT_EDITMSG");
    const fd = os.openFile(editmsg, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_CLOEXEC, 0o666);
    if (fd < 0) util.dieErrno("could not open '{s}'", .{editmsg});
    var fout = util.Out{ .fd = fd };

    const old_display_comment_prefix = s.display_comment_prefix;
    s.display_comment_prefix = true;
    s.hints = false;

    var msg = sb;
    if (clean_message_contents) {
        const st = util.stripspace(msg.items, null);
        msg = .empty;
        util.bufAppend(&msg, st);
    }
    if (signoff) appendSignoff(&msg, trailer.ignoredLogMessageBytes(msg.items, msg.items.len), false);
    fout.write(msg.items);

    const committer_ident = ident.committerStrict();
    var committable: bool = undefined;
    if (use_editor and include_status) {
        s.out = &fout;
        const cs = commentStr();
        if (whence != .commit) {
            if (cleanup_mode == .scissors) wtstatus.addCutLine(s);
            if (whence == .merge)
                wtstatus.printfLn(s, "", "\nIt looks like you may be committing a merge.\nIf this is not correct, please run\n\tgit update-ref -d MERGE_HEAD\nand try again.\n", .{})
            else
                wtstatus.printfLn(s, "", "\nIt looks like you may be committing a cherry-pick.\nIf this is not correct, please run\n\tgit update-ref -d CHERRY_PICK_HEAD\nand try again.\n", .{});
        }
        fout.write("\n");
        if (cleanup_mode == .all) {
            if (allow_empty_message)
                wtstatus.printf(s, "", "Please enter the commit message for your changes. Lines starting\nwith '{s}' will be ignored.\n", .{cs})
            else
                wtstatus.printf(s, "", "Please enter the commit message for your changes. Lines starting\nwith '{s}' will be ignored, and an empty message aborts the commit.\n", .{cs});
        } else if (cleanup_mode == .scissors) {
            if (whence == .commit) wtstatus.addCutLine(s);
        } else {
            if (allow_empty_message)
                wtstatus.printf(s, "", "Please enter the commit message for your changes. Lines starting\nwith '{s}' will be kept; you may remove them yourself if you want to.\n", .{cs})
            else
                wtstatus.printf(s, "", "Please enter the commit message for your changes. Lines starting\nwith '{s}' will be kept; you may remove them yourself if you want to.\nAn empty message aborts the commit.\n", .{cs});
        }
        const ai = ident.split(author_ident).?;
        const ci = ident.split(committer_ident).?;
        var ident_shown = false;
        if (!util.eql(ai.name, ci.name) or !util.eql(ai.email, ci.email)) {
            wtstatus.printfLn(s, "", "{s}Author:    {s} <{s}>", .{ if (ident_shown) "" else "\n", ai.name, ai.email });
            ident_shown = true;
        }
        if (authorDateIsInteresting()) {
            wtstatus.printfLn(s, "", "{s}Date:      {s}", .{ if (ident_shown) "" else "\n", date.showDate(ai.time, date.tzMinutesToHhmm(ai.tz), .{}) });
            ident_shown = true;
        }
        if (!summary.committerIdentSufficientlyGiven()) {
            wtstatus.printfLn(s, "", "{s}Committer: {s} <{s}>", .{ if (ident_shown) "" else "\n", ci.name, ci.email });
            ident_shown = true;
        }
        wtstatus.printfLn(s, "", "{s}", .{""});
        const saved_color = s.use_color;
        s.use_color = false;
        s.committable = false;
        runStatus(&fout, index_file, true, s);
        committable = s.committable;
        s.use_color = saved_color;
    } else committable = computeCommittable(index_file);
    fout.flush();
    os.close(fd);

    if (trailer_args.items.len > 0) {
        if (@import("../trailer.zig").amendFile(editmsg, trailer_args.items)) util.die("unable to pass trailers to --trailers", .{});
    }

    if (!committable and whence != .merge and !allow_empty and !(amend and isAMerge(current_head))) {
        s.hints = advice.enabled("statusHints");
        s.display_comment_prefix = old_display_comment_prefix;
        runStatus(&util.stdout, index_file, false, s);
        if (amend) {
            util.ewrite(empty_amend_advice);
        } else if (isFromCherryPick(whence) or whence == .rebase_pick) {
            util.ewrite(empty_cherry_pick_advice);
            if (whence == .cherry_pick_single) util.ewrite(empty_cherry_pick_advice_single) else if (whence == .cherry_pick_multi) util.ewrite(empty_cherry_pick_advice_multi) else util.ewrite(empty_rebase_pick_advice);
        }
        return false;
    }

    // cache_tree_update on the index being committed
    {
        const idx = index_mod.readFrom(index_file);
        if (idx.unmerged() or idx.writeTree(false) == null) {
            util.err("Error building trees", .{});
            return false;
        }
        built_tree = idx.writeTree(false).?;
    }

    if (runHook(index_file, null, "prepare-commit-msg", editmsg, hook_arg1, hook_arg2)) return false;

    if (use_editor) {
        const env = [_][2][]const u8{.{ "GIT_INDEX_FILE", index_file }};
        if (editor.launch(editmsg, &env)) {
            util.ewrite("Please supply the message using either -m or -F option.\n");
            os.exit(1);
        }
    }

    if (!no_verify and runHook(index_file, null, "commit-msg", editmsg, null, null)) return false;
    return true;
}

var built_tree: Oid = hash.zero;

fn isAMerge(head: ?Oid) bool {
    const h = head orelse return false;
    const c = objects.readCommit(h) orelse return false;
    return c.parents.len > 1;
}

fn readCommitExtraHeaders(buf: []const u8) []const u8 {
    var b: util.Buf = .empty;
    var it = std.mem.splitScalar(u8, buf, '\n');
    var keep = false;
    while (it.next()) |line| {
        if (line.len == 0) break;
        if (line[0] == ' ') {
            if (keep) {
                util.bufAppend(&b, line);
                util.bufByte(&b, '\n');
            }
            continue;
        }
        const sp = std.mem.indexOfScalar(u8, line, ' ') orelse line.len;
        const key = line[0..sp];
        keep = !(util.eql(key, "tree") or util.eql(key, "parent") or util.eql(key, "author") or
            util.eql(key, "committer") or util.eql(key, "encoding") or util.eql(key, "gpgsig") or util.eql(key, "gpgsig-sha256"));
        if (keep) {
            util.bufAppend(&b, line);
            util.bufByte(&b, '\n');
        }
    }
    return b.items;
}

fn validateOptions(rest: []const []const u8, current_head: ?Oid) void {
    if (force_author) |fa| {
        if (std.mem.indexOfScalar(u8, fa, '>') == null) force_author = findAuthorByNickname(fa);
    }
    if (force_author != null and renew_authorship)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--reset-author", "--author" });
    if (logfile != null or have_option_m or use_message != null) use_editor = false;
    if (amend and current_head == null) util.die("You have nothing to amend.", .{});
    if (amend and whence != .commit) {
        if (whence == .merge) util.die("You are in the middle of a merge -- cannot amend.", .{});
        if (isFromCherryPick(whence)) util.die("You are in the middle of a cherry-pick -- cannot amend.", .{});
        if (whence == .rebase_pick) util.die("You are in the middle of a rebase -- cannot amend.", .{});
    }
    if (fixup_message != null and squash_message != null)
        util.die("options '{s}' and '{s}' cannot be used together", .{ "--squash", "--fixup" });
    dieIncompatible4(use_message != null, "-C", edit_message != null, "-c", logfile != null, "-F", fixup_message != null, "--fixup");
    dieIncompatible4(have_option_m, "-m", edit_message != null, "-c", use_message != null, "-C", logfile != null, "-F");
    if (use_message != null or edit_message != null or logfile != null or fixup_message != null or have_option_m)
        template_file = null;
    if (edit_message) |em| use_message = em;
    if (amend and use_message == null and fixup_message == null) use_message = "HEAD";
    if (use_message == null and !isFromCherryPick(whence) and !isFromRebase(whence) and renew_authorship)
        util.die("--reset-author can be used only with -C, -c or --amend.", .{});
    if (use_message) |um| {
        use_message_buffer = readCommitMessage(um);
        if (!renew_authorship) {
            author_message = um;
            author_message_buffer = use_message_buffer;
        }
    }
    if ((isFromCherryPick(whence) or whence == .rebase_pick) and !renew_authorship) {
        author_message = "CHERRY_PICK_HEAD";
        author_message_buffer = readCommitMessage("CHERRY_PICK_HEAD");
    }
    if (patch_interactive) interactive = true;
    dieIncompatible4(also, "-i/--include", only, "-o/--only", all, "-a/--all", interactive, "--interactive/-p/--patch");
    if (fixup_message) |fm| {
        var p: usize = 0;
        while (p < fm.len and std.ascii.isAlphabetic(fm[p])) p += 1;
        if (p > 0 and p < fm.len and fm[p] == ':') {
            const sub = fm[0..p];
            fixup_commit = fm[p + 1 ..];
            if (util.eql(sub, "amend") or util.eql(sub, "reword")) {
                fixup_prefix = "amend";
                allow_empty = true;
                if (sub[0] == 'r') {
                    if (whence != .commit) {
                        if (whence == .merge) util.die("You are in the middle of a merge -- cannot reword.", .{});
                        if (isFromCherryPick(whence)) util.die("You are in the middle of a cherry-pick -- cannot reword.", .{});
                    }
                    if (rest.len > 0) util.die("reword option of '{s}' and path '{s}' cannot be used together", .{ "--fixup", rest[0] });
                    if (patch_interactive or interactive or all or also or only)
                        util.die("reword option of '{s}' and '{s}' cannot be used together", .{ "--fixup", "--patch/--interactive/--all/--include/--only" });
                    only = true;
                }
            } else {
                util.die("unknown option: --fixup={s}:{s}", .{ sub, fixup_commit });
            }
            fixup_message = sub;
        } else {
            fixup_commit = fm;
            fixup_prefix = "fixup";
            use_editor = false;
        }
    }
    if (edit_flag >= 0) use_editor = edit_flag != 0;
    if (all and rest.len > 0) util.die("paths '{s} ...' with -a does not make sense", .{rest[0]});
    if (status_format != FMT_NONE) dry_run = true;
}

fn dieIncompatible4(o1: bool, n1: []const u8, o2: bool, n2: []const u8, o3: bool, n3: []const u8, o4: bool, n4: []const u8) void {
    var names: [4][]const u8 = undefined;
    var n: usize = 0;
    if (o1) {
        names[n] = n1;
        n += 1;
    }
    if (o2) {
        names[n] = n2;
        n += 1;
    }
    if (o3) {
        names[n] = n3;
        n += 1;
    }
    if (o4) {
        names[n] = n4;
        n += 1;
    }
    switch (n) {
        4 => util.die("options '{s}', '{s}', '{s}', and '{s}' cannot be used together", .{ n1, n2, n3, n4 }),
        3 => util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ names[0], names[1], names[2] }),
        2 => util.die("options '{s}' and '{s}' cannot be used together", .{ names[0], names[1] }),
        else => {},
    }
}

fn loadConfig() void {
    const cfg = &repo_mod.cfg;
    if (cfg.getPath("commit.template")) |t| template_file = t;
    if (cfg.getBool("commit.status")) |b| include_status = b;
    if (cfg.get("commit.cleanup")) |c| cleanup_config = c;
    if (cfg.getBool("commit.gpgsign")) |b| sign_commit = if (b) "" else null;
    if (cfg.getEntry("commit.verbose")) |e| {
        var is_bool = false;
        const kvi = e.kvi();
        config_commit_verbose = @import("../config.zig").configBoolOrInt(e.key, e.value, &kvi, &is_bool);
    }
}

pub fn cmdCommit(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    sparse_index.commandIsSparseAware();
    var s = wtstatus.prepare();
    loadConfig();
    // status_init_config(&s, git_commit_config): git_status_config part
    wtstatus.initConfig(&s);
    whence = determineWhence();
    s.whence = whence;
    s.commit_template = true;
    status_format = FMT_NONE; // ignore status.short

    var current_head: ?Oid = null;
    if (revparse.getOid("HEAD")) |h| {
        if (objects.readCommit(h) == null) util.die("could not parse HEAD commit", .{});
        current_head = h;
    }
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (opt_include_status >= 0) include_status = opt_include_status != 0;
    // finalize_deferred_config
    if (show_branch >= 0) s.show_branch = show_branch;
    if (ahead_behind >= 0) s.ahead_behind_flags = if (ahead_behind != 0) .full else .quick;
    s.null_termination = null_termination;
    wtstatus.finalizeDeferredConfig(&s, if (status_format < 0) .unspecified else @enumFromInt(status_format));
    status_format = @intFromEnum(s.status_format);
    setupStatus(&s);
    validateOptions(rest, current_head);

    if (verbose == -1) verbose = if (config_commit_verbose < 0) 0 else config_commit_verbose;
    if (cleanup_arg) |c| cleanup_config = c;
    cleanup_mode = getCleanupMode(cleanup_config, use_editor);

    if (dry_run) {
        const index_file = prepareIndex(rest, current_head, true);
        runStatus(&util.stdout, index_file, false, &s);
        const committable = s.committable;
        rollbackIndexFiles();
        return if (committable) 0 else 1;
    }

    const index_file = prepareIndex(rest, current_head, false);
    var author_ident: []const u8 = "";
    if (!prepareToCommit(index_file, current_head, &s, &author_ident)) {
        rollbackIndexFiles();
        return 1;
    }

    var reflog_msg: ?[]const u8 = os.getenv("GIT_REFLOG_ACTION");
    var parents: std.ArrayList(Oid) = .empty;
    if (current_head == null) {
        if (reflog_msg == null) reflog_msg = "commit (initial)";
    } else if (amend) {
        if (reflog_msg == null) reflog_msg = "commit (amend)";
        const c = objects.readCommit(current_head.?).?;
        parents.appendSlice(gpa, c.parents) catch util.oom();
    } else if (whence == .merge) {
        if (reflog_msg == null) reflog_msg = "commit (merge)";
        parents.append(gpa, current_head.?) catch util.oom();
        const mh = os.readFile(r.gitPath("MERGE_HEAD")) orelse util.dieErrno("could not open '{s}' for reading", .{r.gitPath("MERGE_HEAD")});
        var it = std.mem.splitScalar(u8, mh, '\n');
        while (it.next()) |line| {
            if (line.len == 0) continue;
            const o = hash.fromHex(line) orelse util.die("Corrupt MERGE_HEAD file ({s})", .{line});
            const p = objects.peelTo(o, .commit) orelse util.die("Corrupt MERGE_HEAD file ({s})", .{line});
            parents.append(gpa, p) catch util.oom();
        }
        var allow_ff = true;
        if (os.readFile(r.gitPath("MERGE_MODE"))) |mm| {
            if (util.eql(mm, "no-ff")) allow_ff = false;
        }
        if (allow_ff) reduceParents(&parents);
    } else {
        if (reflog_msg == null) reflog_msg = if (isFromCherryPick(whence)) "commit (cherry-pick)" else if (isFromRebase(whence)) "commit (rebase)" else "commit";
        parents.append(gpa, current_head.?) catch util.oom();
    }

    const editmsg = r.gitPath("COMMIT_EDITMSG");
    const raw_msg = os.readFile(editmsg) orelse {
        rollbackIndexFiles();
        util.dieErrno("could not read commit message", .{});
    };
    const msg = cleanupMessage(raw_msg, cleanup_mode, verbose);
    if (messageIsEmpty(msg, cleanup_mode) and !allow_empty_message) {
        rollbackIndexFiles();
        util.ewrite("Aborting commit due to empty commit message.\n");
        os.exit(1);
    }
    if (templateUntouched(msg, template_file, cleanup_mode) and !allow_empty_message) {
        rollbackIndexFiles();
        util.ewrite("Aborting commit; you did not edit the message.\n");
        os.exit(1);
    }
    if (fixup_message != null and util.startsWith(msg, "amend! ") and !allow_empty_message) {
        const nl = std.mem.indexOf(u8, msg, "\n\n");
        const body = if (nl) |p| msg[p..] else "";
        if (messageIsEmpty(body, cleanup_mode)) {
            rollbackIndexFiles();
            util.ewrite("Aborting commit due to empty commit message body.\n");
            os.exit(1);
        }
    }

    var extra: []const u8 = "";
    if (amend) extra = readCommitExtraHeaders(rawCommitBuffer(current_head.?));

    const oid = commit_mod.tryCreate(.{
        .tree = built_tree,
        .parents = parents.items,
        .message = msg,
        .author = author_ident,
        .extra_headers = extra,
        .sign = sign_commit,
    }) orelse {
        rollbackIndexFiles();
        util.die("failed to write commit object", .{});
    };

    {
        var rmsg: util.Buf = .empty;
        util.bufPrint(&rmsg, "{s}: ", .{reflog_msg.?});
        const nl = std.mem.indexOfScalar(u8, msg, '\n');
        util.bufAppend(&rmsg, if (nl) |p| msg[0..p] else msg);
        refs.update("HEAD", oid, current_head orelse hash.zero, rmsg.items, false) catch {
            rollbackIndexFiles();
            util.die("{s}", .{refs.last_error});
        };
    }

    // sequencer_post_commit_cleanup
    @import("../branchstate.zig").sequencerPostCommitCleanup(false);
    _ = os.unlink(r.gitPath("MERGE_HEAD"));
    _ = os.unlink(r.gitPath("MERGE_MSG"));
    _ = os.unlink(r.gitPath("MERGE_MODE"));
    _ = os.unlink(r.gitPath("SQUASH_MSG"));

    if (!commitIndexFiles())
        util.die("repository has been updated, but unable to write\nnew index file. Check that disk is not full and quota is\nnot exceeded, and then \"git restore --staged :/\" to recover.", .{});

    _ = @import("../rerere.zig").rerere(0);

    _ = hook.runCommitHook(use_editor, r.indexPath(), null, "post-commit", &.{});
    if (amend and !no_post_rewrite) {
        const data = util.fmt("{s} {s}\n", .{ hash.hex(current_head.?), hash.hex(oid) });
        _ = hook.run("post-rewrite", &.{"amend"}, .{ .stdin_data = data });
    }
    if (quiet == 0) {
        var flags: u32 = 0;
        if (current_head == null) flags |= summary.SUMMARY_INITIAL_COMMIT;
        if (authorDateIsInteresting()) flags |= summary.SUMMARY_SHOW_AUTHOR_DATE;
        summary.printCommitSummary(oid, flags);
    }
    return 0;
}

fn reduceParents(parents: *std.ArrayList(Oid)) void {
    // remove duplicates and parents reachable from other parents
    var list: ?*cn.CommitList = null;
    var tail: *?*cn.CommitList = &list;
    for (parents.items) |p| {
        const c = cn.lookupCommit(p) orelse continue;
        tail = cn.listAppend(c, tail);
    }
    const reduced = commitreach.reduceHeads(list);
    parents.clearRetainingCapacity();
    var it = reduced;
    while (it) |n| : (it = n.next) parents.append(gpa, n.item.obj.oid) catch util.oom();
}
