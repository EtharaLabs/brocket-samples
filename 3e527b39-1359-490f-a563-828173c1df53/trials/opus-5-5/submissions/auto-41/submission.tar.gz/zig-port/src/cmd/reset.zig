//! git reset (builtin/reset.c)

const std = @import("std");
const add_patch = @import("../add_patch.zig");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const objects = @import("../objects.zig");
const revparse = @import("../revparse.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const advice = @import("../advice.zig");
const cn = @import("../commitnode.zig");
const pretty = @import("../pretty.zig");
const ut = @import("../unpacktrees.zig");
const branchstate = @import("../branchstate.zig");
const submodule = @import("../submodule.zig");
const sparse = @import("../sparse.zig");
const sparse_index_mod = @import("../sparse_index.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

const usage = [_][]const u8{
    "git reset [--mixed | --soft | --hard | --merge | --keep] [-q] [<commit>]",
    "git reset [-q] [<tree-ish>] [--] <pathspec>...",
    "git reset [-q] [--pathspec-from-file [--pathspec-file-nul]] [<tree-ish>]",
    "git reset --patch [<tree-ish>] [--] [<pathspec>...]",
};

const MIXED = 0;
const SOFT = 1;
const HARD = 2;
const MERGE = 3;
const KEEP = 4;
const NONE = 5;
const type_names = [_][]const u8{ "mixed", "soft", "hard", "merge", "keep" };

fn isMerge() bool {
    return os.exists(repo_mod.repo().gitPath("MERGE_HEAD"));
}

/// reset_index(); returns true on error.
fn resetIndex(idx: *index_mod.Index, oid: Oid, rtype: i32, quiet: bool) bool {
    var o = ut.Options{};
    o.head_idx = 1;
    o.src_index = idx;
    o.dst_index = idx;
    o.func = &ut.onewayMerge;
    o.merge = true;
    o.verbose_update = !quiet;
    switch (rtype) {
        KEEP, MERGE => {
            o.update = true;
            o.preserve_ignored = false;
        },
        HARD => {
            o.update = true;
            o.reset = .overwrite_untracked;
            o.skip_cache_tree_update = true;
        },
        MIXED => {
            o.reset = .protect_untracked;
            o.skip_cache_tree_update = true;
        },
        else => unreachable,
    }
    _ = ut.readIndexUnmerged(idx);
    var trees: [2]Oid = undefined;
    var nr: usize = 0;
    if (rtype == KEEP) {
        const head = revparse.getOid("HEAD") orelse {
            util.err("You do not have a valid HEAD.", .{});
            return true;
        };
        trees[nr] = objects.peelTo(head, .tree) orelse {
            util.err("Failed to find tree of HEAD.", .{});
            return true;
        };
        nr += 1;
        o.func = &ut.twowayMerge;
    }
    trees[nr] = objects.peelTo(oid, .tree) orelse {
        util.err("Failed to find tree of {s}.", .{&hash.hex(oid)});
        return true;
    };
    nr += 1;
    if (ut.unpackTrees(trees[0..nr], &o) != 0) return true;
    if (rtype == MIXED or rtype == HARD) {
        index_mod.primeCacheTree(idx, trees[nr - 1]);
    }
    return false;
}

fn printNewHeadLine(oid: Oid) void {
    const c = cn.lookupCommitReference(oid) orelse return;
    util.outf("HEAD is now at {s}", .{revparse.abbrev(oid, revparse.defaultAbbrev())});
    var buf: util.Buf = .empty;
    pretty.ppCommitEasy(.oneline, c, &buf);
    if (buf.items.len > 0) util.outf(" {s}", .{buf.items});
    util.out("\n");
}

const FlatMap = std.StringHashMap(objects.FlatEntry);

/// flattenTree() that does not descend into directories the index holds
/// as sparse directory entries.
fn flattenTreeSkipSparse(idx: *index_mod.Index, tree: Oid, prefix: []const u8, out: *std.ArrayList(objects.FlatEntry)) void {
    const entries = objects.readTree(tree) orelse return;
    for (entries) |e| {
        const p = if (prefix.len == 0) util.dupe(e.name) else util.concat(&.{ prefix, "/", e.name });
        if (e.isDir()) {
            if (idx.sparse_index) switch (idx.posNoExpand(util.concat(&.{ p, "/" }), 0)) {
                .found => |k| if (sparse_index_mod.isSparseDir(&idx.entries.items[k])) continue,
                .missing => {},
            };
            flattenTreeSkipSparse(idx, e.oid, p, out);
        } else out.append(gpa, .{ .path = p, .mode = e.mode, .oid = e.oid }) catch util.oom();
    }
}

/// Would diffing `tree` against the sparse directory entry `e` report any
/// path matching `ps`?
fn sparseDirDiffers(e: *const index_mod.Entry, tree: Oid, ps: *const pathspec_mod.Pathspec) bool {
    var sub: ?Oid = null;
    if (objects.treeLookup(tree, e.path)) |te| {
        if (te.isDir()) sub = te.oid;
    }
    if (sub) |s| {
        if (hash.eql(s, e.oid)) return false;
    }
    const base = e.path[0 .. e.path.len - 1];
    var a: std.ArrayList(objects.FlatEntry) = .empty;
    objects.flattenTree(e.oid, base, &a);
    var b: std.ArrayList(objects.FlatEntry) = .empty;
    if (sub) |s| objects.flattenTree(s, base, &b);
    var bm = FlatMap.init(gpa);
    for (b.items) |fe| bm.put(fe.path, fe) catch util.oom();
    for (a.items) |fe| {
        const other = bm.fetchRemove(fe.path);
        if (other) |o| {
            if (o.value.mode == fe.mode and hash.eql(o.value.oid, fe.oid)) continue;
        }
        if (ps.matches(fe.path, false)) return true;
    }
    var it = bm.keyIterator();
    while (it.next()) |k| {
        if (ps.matches(k.*, false)) return true;
    }
    return false;
}

/// read_from_tree(): diff tree vs index (cached) limited to pathspec and
/// update the index entries accordingly.
fn readFromTree(idx: *index_mod.Index, ps: *const pathspec_mod.Pathspec, tree0: Oid, intent_to_add: bool) void {
    const tree = objects.peelTo(tree0, .tree) orelse tree0;
    if (ps.items.len > 0 and sparse_index_mod.pathspecNeedsExpandedIndex(idx, ps))
        sparse_index_mod.ensureFull(idx);
    // a sparse directory whose files differ from the tree (within the
    // pathspec) is updated file by file, which expands the index
    // (index_name_pos() in update_index_from_diff())
    if (idx.sparse_index) {
        for (idx.entries.items) |*e| {
            if (!sparse_index_mod.isSparseDir(e)) continue;
            if (sparseDirDiffers(e, tree, ps)) {
                sparse_index_mod.ensureFull(idx);
                break;
            }
        }
    }
    var flat: std.ArrayList(objects.FlatEntry) = .empty;
    flattenTreeSkipSparse(idx, tree, "", &flat);
    var tmap = FlatMap.init(gpa);
    for (flat.items) |fe| tmap.put(fe.path, fe) catch util.oom();

    // collect paths (sorted, unique)
    var paths: std.ArrayList([]const u8) = .empty;
    var seen = std.StringHashMap(void).init(gpa);
    for (flat.items) |fe| {
        if (!ps.matches(fe.path, false)) continue;
        if ((seen.fetchPut(fe.path, {}) catch util.oom()) == null) paths.append(gpa, fe.path) catch util.oom();
    }
    for (idx.entries.items) |*e| {
        // remaining sparse directories match the tree (within the pathspec)
        if (sparse_index_mod.isSparseDir(e)) continue;
        if (!ps.matches(e.path, false)) continue;
        if ((seen.fetchPut(e.path, {}) catch util.oom()) == null) paths.append(gpa, e.path) catch util.oom();
    }
    std.mem.sort([]const u8, paths.items, {}, util.strLess);

    for (paths.items) |p| {
        const te = tmap.get(p);
        // find index entry
        const first = idx.firstPos(p);
        var ie: ?*index_mod.Entry = null;
        var unmerged = false;
        if (first < idx.entries.items.len and util.eql(idx.entries.items[first].path, p)) {
            ie = &idx.entries.items[first];
            unmerged = ie.?.stage() != 0;
        }
        if (!unmerged) {
            if (te) |t| {
                if (ie) |e| {
                    if (e.mode == t.mode and std.mem.eql(u8, &e.oid, &t.oid)) continue;
                }
            } else if (ie == null) continue;
        }
        if (te == null and !intent_to_add) {
            _ = idx.removePath(p);
            continue;
        }
        const was_skip = if (ie) |e| e.skipWorktree() else false;
        var n = index_mod.Entry{ .path = p, .mode = undefined };
        if (te) |t| {
            n.mode = index_mod.canonMode(t.mode);
            n.oid = t.oid;
        } else {
            n.mode = 0o100644;
            n.oid = hash.fromHex(hash.empty_blob_hex).?;
            n.ext_flags |= index_mod.CE_INTENT_TO_ADD;
        }
        // skip-worktree is kept, and given to new paths outside the
        // sparse-checkout definition
        const at_stage0 = ie != null and !unmerged;
        if ((at_stage0 and was_skip) or (!at_stage0 and !sparse.pathInSparseCheckout(p))) n.ext_flags |= index_mod.CE_SKIP_WORKTREE;
        _ = idx.add(n, .{});
        idx.invalidatePath(p);
    }
}

fn setReflogMessage(action: []const u8, rev: ?[]const u8) []const u8 {
    if (os.getenv("GIT_REFLOG_ACTION")) |rla| return util.fmt("{s}: {s}", .{ rla, action });
    if (rev) |r| return util.fmt("reset: moving to {s}", .{r});
    return util.fmt("reset: {s}", .{action});
}

fn resetRefs(rev: []const u8, oid: Oid) u8 {
    const old_orig = revparse.getOid("ORIG_HEAD");
    const orig = revparse.getOid("HEAD");
    if (orig) |o| {
        refs.update("ORIG_HEAD", o, old_orig, setReflogMessage("updating ORIG_HEAD", null), false) catch {
            util.err("{s}", .{refs.last_error});
        };
    } else if (old_orig) |oo| {
        refs.delete("ORIG_HEAD", oo, false) catch {};
    }
    refs.update("HEAD", oid, orig orelse hash.zero, setReflogMessage("updating HEAD", rev), false) catch {
        util.err("{s}", .{refs.last_error});
        return 1;
    };
    return 0;
}

var reset_type: i32 = NONE;
fn recurseCb(arg: ?[]const u8, unset: bool) void {
    submodule.optWorktreeUpdater(arg, unset);
}

pub fn run(args: []const []const u8) u8 {
    var quiet: i32 = 0;
    var no_refresh = false;
    var patch_mode = false;
    var auto_advance = true;
    var unified: i32 = -1;
    var inter_hunk: i32 = -1;
    var intent_to_add = false;
    var pathspec_from_file: ?[]const u8 = null;
    var pathspec_file_nul = false;
    const options = [_]po.Opt{
        po.counter('q', "quiet", &quiet, "be quiet, only report errors"),
        po.boolean(0, "no-refresh", &no_refresh, "skip refreshing the index after reset"),
        .{ .kind = .set_int, .long = "mixed", .i = &reset_type, .val = MIXED, .noneg = true, .help = "reset HEAD and index" },
        .{ .kind = .set_int, .long = "soft", .i = &reset_type, .val = SOFT, .noneg = true, .help = "reset only HEAD" },
        .{ .kind = .set_int, .long = "hard", .i = &reset_type, .val = HARD, .noneg = true, .help = "reset HEAD, index and working tree" },
        .{ .kind = .set_int, .long = "merge", .i = &reset_type, .val = MERGE, .noneg = true, .help = "reset HEAD, index and working tree" },
        .{ .kind = .set_int, .long = "keep", .i = &reset_type, .val = KEEP, .noneg = true, .help = "reset HEAD but keep local changes" },
        .{ .kind = .callback, .long = "recurse-submodules", .cb = recurseCb, .argh = "reset", .optarg = true, .help = "control recursive updating of submodules" },
        po.boolean('p', "patch", &patch_mode, "select hunks interactively"),
        po.boolean(0, "auto-advance", &auto_advance, "auto advance to the next file when selecting hunks interactively"),
        po.noNeg(po.integer('U', "unified", &unified, "n", "generate diffs with <n> lines context")),
        po.noNeg(po.integer(0, "inter-hunk-context", &inter_hunk, "n", "show context between diff hunks up to the specified number of lines")),
        po.boolean('N', "intent-to-add", &intent_to_add, "record only the fact that removed paths will be added later"),
        po.filename(0, "pathspec-from-file", &pathspec_from_file, "file", "read pathspec from file"),
        po.boolean(0, "pathspec-file-nul", &pathspec_file_nul, "with --pathspec-from-file, pathspec elements are separated with NUL character"),
    };
    submodule.loadRecurseConfig();
    var argv = po.parse(args[1..], &options, &usage, .{ .keep_dashdash = true });
    sparse_index_mod.commandIsSparseAware();
    const r = repo_mod.repo();
    const prefix = r.prefix;

    // parse_args()
    var rev: []const u8 = "HEAD";
    if (argv.len > 0) {
        if (util.eql(argv[0], "--")) {
            argv = argv[1..];
        } else if (argv.len > 1 and util.eql(argv[1], "--")) {
            rev = argv[0];
            argv = argv[2..];
        } else if ((argv.len == 1 and revparse.getOidCommittish(argv[0]) != null) or
            (argv.len > 1 and revparse.getTreeish(argv[0]) != null))
        {
            revparse.verifyNonFilename(prefix, argv[0]);
            rev = argv[0];
            argv = argv[1..];
        } else {
            revparse.verifyFilename(prefix, argv[0], true);
        }
    }
    if (util.eql(rev, "@")) rev = "HEAD";
    const ps_flags = pathspec_mod.Flags{ .prefer_full = true, .prefix_origin = patch_mode };
    var ps = pathspec_mod.parse(prefix, argv, ps_flags);

    if (pathspec_from_file) |pf| {
        if (patch_mode) util.die("options '{s}' and '{s}' cannot be used together", .{ "--pathspec-from-file", "--patch" });
        if (ps.items.len > 0) util.die("'{s}' and pathspec arguments cannot be used together", .{"--pathspec-from-file"});
        ps = pathspec_mod.parse(prefix, pathspec_mod.readPathspecFile(pf, pathspec_file_nul), ps_flags);
    } else if (pathspec_file_nul) {
        util.die("the option '{s}' requires '{s}'", .{ "--pathspec-file-nul", "--pathspec-from-file" });
    }
    const has_ps = ps.items.len > 0;

    var oid: Oid = undefined;
    var unborn = false;
    if (util.eql(rev, "HEAD") and revparse.getOid("HEAD") == null) {
        unborn = true;
        oid = hash.fromHex(hash.empty_tree_hex).?;
    } else if (!has_ps and !patch_mode) {
        const o = revparse.getOidCommittish(rev) orelse util.die("Failed to resolve '{s}' as a valid revision.", .{rev});
        const c = cn.lookupCommitReference(o) orelse util.die("Could not parse object '{s}'.", .{rev});
        oid = c.oid();
    } else {
        const o = revparse.getTreeish(rev) orelse util.die("Failed to resolve '{s}' as a valid tree.", .{rev});
        oid = objects.peelTo(o, .tree) orelse util.die("Could not parse object '{s}'.", .{rev});
    }

    if (unified < -1) util.die("'{s}' cannot be negative", .{"--unified"});
    if (inter_hunk < -1) util.die("'{s}' cannot be negative", .{"--inter-hunk-context"});

    if (patch_mode) {
        if (reset_type != NONE) util.die("options '{s}' and '{s}' cannot be used together", .{ "--patch", "--{hard,mixed,soft}" });
        return if (add_patch.runPathspec(.reset, .{ .context = unified, .interhunkcontext = inter_hunk, .auto_advance = auto_advance }, rev, &ps, 0) != 0) 1 else 0;
    } else {
        if (unified != -1) util.die("the option '{s}' requires '{s}'", .{ "--unified", "--patch" });
        if (inter_hunk != -1) util.die("the option '{s}' requires '{s}'", .{ "--inter-hunk-context", "--patch" });
        if (!auto_advance) util.die("the option '{s}' requires '{s}'", .{ "--no-auto-advance", "--patch" });
    }

    if (has_ps) {
        if (reset_type == MIXED) {
            util.warn("--mixed with paths is deprecated; use 'git reset -- <paths>' instead.", .{});
        } else if (reset_type != NONE) {
            util.die("Cannot do {s} reset with paths.", .{type_names[@intCast(reset_type)]});
        }
    }
    if (reset_type == NONE) reset_type = MIXED;

    if (reset_type != SOFT and (reset_type != MIXED or r.work_tree != null)) {
        if (r.work_tree == null) util.die("this operation must be run in a work tree", .{});
        _ = repo_mod.requireWorkTree("reset");
    }
    if (reset_type == MIXED and r.work_tree == null and r.bare)
        util.die("{s} reset is not allowed in a bare repository", .{type_names[@intCast(reset_type)]});
    if (intent_to_add and reset_type != MIXED)
        util.die("the option '{s}' requires '{s}'", .{ "-N", "--mixed" });

    var status: u8 = 0;
    if (reset_type == SOFT or reset_type == KEEP) {
        const idx0 = index_mod.get();
        if (isMerge() or idx0.unmerged())
            util.die("Cannot do a {s} reset in the middle of a merge.", .{type_names[@intCast(reset_type)]});
    }

    if (reset_type != SOFT) {
        const idx = index_mod.lockAndRead();
        if (reset_type == MIXED) {
            const flags: u32 = if (quiet > 0) index_mod.REFRESH_QUIET else index_mod.REFRESH_IN_PORCELAIN;
            readFromTree(idx, &ps, oid, intent_to_add);
            if (!no_refresh and r.work_tree != null) {
                _ = index_mod.refresh(idx, flags, @as(?*const pathspec_mod.Pathspec, null), "Unstaged changes after reset:");
            }
        } else {
            var err = resetIndex(idx, oid, reset_type, quiet > 0);
            if (reset_type == KEEP and !err) err = resetIndex(idx, oid, MIXED, quiet > 0);
            if (err) util.die("Could not reset index file to revision '{s}'.", .{rev});
        }
        idx.writeToLock();
        const l = idx.lock.?;
        if (!l.commit()) util.die("Could not write new index file.", .{});
        idx.lock = null;
    }

    if (!has_ps and !unborn) {
        status = resetRefs(rev, oid);
        if (reset_type == HARD and status == 0 and quiet == 0) printNewHeadLine(oid);
    }
    if (!has_ps) branchstate.removeBranchState(false);
    return status;
}
