//! git sparse-checkout (builtin/sparse-checkout.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const index_mod = @import("../index.zig");
const lockfile = @import("../lockfile.zig");
const revparse = @import("../revparse.zig");
const sparse = @import("../sparse.zig");
const sparse_index_mod = @import("../sparse_index.zig");
const gpa = util.gpa;

const Patterns = sparse.Patterns;

const main_usage = [_][]const u8{"git sparse-checkout (init | list | set | add | reapply | disable | check-rules | clean) [<options>]"};

// in-memory copies of core.sparseCheckout / core.sparseCheckoutCone
var g_apply = false;
var g_cone = false;

fn setupWorkTree() void {
    if (repo_mod.repo().work_tree == null) util.die("this operation must be run in a work tree", .{});
}

// ---------------------------------------------------------------------------
// config

fn setWorktreeConfig(key: []const u8, value: []const u8) bool {
    const r = repo_mod.repo();
    const path = if (r.worktree_config) r.gitPath("config.worktree") else r.commonPath("config");
    return config.setInFileGently(path, key, null, value) == 0;
}

fn initWorktreeConfig() bool {
    const r = repo_mod.repo();
    if (r.worktree_config) return true;
    const common = r.commonPath("config");
    if (config.setInFileGently(common, "extensions.worktreeConfig", null, "true") != 0) {
        util.err("failed to set extensions.worktreeConfig setting", .{});
        return false;
    }
    const main_wt = r.commonPath("config.worktree");
    var cs: config.Config = .{};
    _ = config.readFileInto(&cs, common, .local);
    if (cs.getBool("core.bare") orelse false) {
        if (config.setInFileGently(main_wt, "core.bare", null, "true") != 0) return false;
        if (config.setInFileGently(common, "core.bare", null, null) < 0) return false;
    }
    if (cs.get("core.worktree")) |wt| {
        if (config.setInFileGently(main_wt, "core.worktree", null, wt) != 0) return false;
        if (config.setInFileGently(common, "core.worktree", null, null) < 0) return false;
    }
    r.worktree_config = true;
    return true;
}

const Mode = enum { none, all, cone };

/// set_config(); returns true on error
fn setConfig(mode: Mode) bool {
    if (!initWorktreeConfig()) {
        util.err("failed to initialize worktree config", .{});
        return true;
    }
    if (!setWorktreeConfig("core.sparseCheckout", if (mode != .none) "true" else "false") or
        !setWorktreeConfig("core.sparseCheckoutCone", if (mode == .cone) "true" else "false"))
        return true;
    if (mode == .none) {
        sparse_index_mod.setSetting(false);
        return !setWorktreeConfig("index.sparse", "false");
    }
    return false;
}

fn updateConeMode(cone_mode: *i32) Mode {
    if (cone_mode.* == -1 and g_apply) cone_mode.* = @intFromBool(g_cone);
    g_apply = true;
    if (cone_mode.* == 1 or cone_mode.* == -1) {
        g_cone = true;
        return .cone;
    }
    g_cone = false;
    return .all;
}

/// update_modes(); returns true on error
fn updateModes(cone_mode: *i32, sparse_index: i32) bool {
    const record_mode = cone_mode.* != -1 or !g_apply;
    const mode = updateConeMode(cone_mode);
    if (record_mode and setConfig(mode)) return true;
    if (sparse_index >= 0) {
        if (!setWorktreeConfig("index.sparse", if (sparse_index != 0) "true" else "false"))
            util.die("failed to modify sparse-index config", .{});
        sparse_index_mod.setSetting(sparse_index != 0);
    }
    return false;
}

// ---------------------------------------------------------------------------
// patterns <-> file

fn escapedPattern(p: []const u8) []const u8 {
    var b: util.Buf = .empty;
    for (p) |ch| {
        if (ch == '*' or ch == '?' or ch == '[' or ch == '\\') util.bufByte(&b, '\\');
        util.bufByte(&b, ch);
    }
    return b.items;
}

fn lessStr(_: void, a: []const u8, b: []const u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

fn sortedUnique(list: *std.ArrayList([]const u8)) []const []const u8 {
    std.mem.sort([]const u8, list.items, {}, lessStr);
    var out: std.ArrayList([]const u8) = .empty;
    for (list.items) |s| {
        if (out.items.len > 0 and util.eql(out.items[out.items.len - 1], s)) continue;
        out.append(gpa, s) catch util.oom();
    }
    return out.items;
}

fn writeCone(b: *util.Buf, pl: *Patterns) void {
    var sl: std.ArrayList([]const u8) = .empty;
    var it = pl.parent.keyIterator();
    while (it.next()) |k| {
        if (pl.recursive.contains(k.*)) continue;
        if (!sparse.containsParent(&pl.recursive, k.*)) sl.append(gpa, k.*) catch util.oom();
    }
    util.bufAppend(b, "/*\n!/*/\n");
    for (sortedUnique(&sl)) |s| {
        const p = escapedPattern(s);
        if (p.len > 0) util.bufPrint(b, "{s}/\n!{s}/*/\n", .{ p, p });
    }
    var sl2: std.ArrayList([]const u8) = .empty;
    var it2 = pl.recursive.keyIterator();
    while (it2.next()) |k| {
        if (!sparse.containsParent(&pl.recursive, k.*)) sl2.append(gpa, k.*) catch util.oom();
    }
    for (sortedUnique(&sl2)) |s| util.bufPrint(b, "{s}/\n", .{escapedPattern(s)});
}

fn writePatterns(b: *util.Buf, pl: *Patterns) void {
    for (pl.pl.patterns.items) |p| {
        if (p.flags & @import("../dir.zig").PATTERN_FLAG_NEGATIVE != 0) util.bufByte(b, '!');
        util.bufAppend(b, p.pattern);
        if (p.flags & @import("../dir.zig").PATTERN_FLAG_MUSTBEDIR != 0) util.bufByte(b, '/');
        util.bufByte(b, '\n');
    }
}

fn exitCode(r: sparse.Result) u8 {
    const v: i32 = @intFromEnum(r);
    return @intCast(v & 0xff);
}

/// update_working_directory()
fn updateWorkingDirectory(pl0: ?*Patterns) sparse.Result {
    var idx = index_mod.get();
    if (idx.entries.items.len == 0 and !idx.loaded_from_disk) return .success;
    setupWorkTree();
    index_mod.discard();
    idx = index_mod.lockAndRead();
    const pl = pl0 orelse (sparse.loadFile(sparse.sparseFilename(), g_cone) orelse Patterns.init(g_cone));
    sparse_index_mod.apply_override = g_apply;
    sparse_index_mod.cone_override = g_cone;
    sparse_index_mod.patterns_override = pl;
    defer sparse_index_mod.patterns_override = null;
    var result = sparse.updateSparsity(idx, pl);
    if (result == .warnings) result = .success;
    if (result == .success) idx.write() else idx.rollback();
    if (g_apply and g_cone) sparse.cleanTrackedSparseDirectories(idx, pl);
    return result;
}

/// write_patterns_and_update()
fn writePatternsAndUpdate(pl: *Patterns) sparse.Result {
    const fname = sparse.sparseFilename();
    if (!os.mkdirLeading(fname)) util.die("failed to create directory for sparse-checkout file", .{});
    const lk = lockfile.lockOrDie(fname);
    const result = updateWorkingDirectory(pl);
    if (result != .success) {
        lk.rollback();
        _ = updateWorkingDirectory(null);
        return result;
    }
    var b: util.Buf = .empty;
    if (g_cone) writeCone(&b, pl) else writePatterns(&b, pl);
    lk.write(b.items);
    if (!lk.commit()) util.dieErrno("unable to write {s}", .{fname});
    return result;
}

fn splitLines(data: []const u8, term: u8) []const []const u8 {
    var out: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, data, term);
    while (it.next()) |l0| {
        if (it.index == null and l0.len == 0) break;
        var l = l0;
        if (term == '\n' and l.len > 0 and l[l.len - 1] == '\r') l = l[0 .. l.len - 1];
        out.append(gpa, l) catch util.oom();
    }
    return out.items;
}

fn readStdinLines(term: u8) []const []const u8 {
    const data = os.readAllFd(0) catch "";
    return splitLines(data, term);
}

fn toConePattern(pl: *Patterns, line0: []const u8) void {
    var line: []const u8 = util.trim(line0);
    while (line.len > 0 and line[line.len - 1] == '/') line = line[0 .. line.len - 1];
    const norm = util.normalizePath(line) orelse util.die("could not normalize path {s}", .{line});
    if (norm.len == 0) return;
    const p = if (norm[0] != '/') util.concat(&.{ "/", norm }) else norm;
    pl.insertRecursive(p);
}

/// add_patterns_from_input()
fn addPatternsFromInput(pl: *Patterns, args: []const []const u8, file: ?[]const []const u8) void {
    if (g_cone) {
        pl.use_cone = true;
        if (file) |lines| {
            for (lines) |l| {
                var line = l;
                if (line.len > 0 and line[0] == '"') {
                    const u = util.cunquote(line) orelse util.die("unable to unquote C-style string '{s}'", .{line});
                    line = u.value;
                }
                toConePattern(pl, line);
            }
        } else for (args) |a| toConePattern(pl, a);
    } else {
        const src = file orelse args;
        for (src) |l| pl.add(l);
    }
}

const Modify = enum { replace, add };

fn modifyPatternList(args: []const []const u8, use_stdin: bool, m: Modify) sparse.Result {
    const pl = Patterns.init(false);
    const input: ?[]const []const u8 = if (use_stdin) readStdinLines('\n') else null;
    switch (m) {
        .add => {
            if (g_cone) {
                addPatternsFromInput(pl, args, input);
                const existing = sparse.loadFile(sparse.sparseFilename(), g_cone) orelse
                    util.die("unable to load existing sparse-checkout patterns", .{});
                if (!existing.use_cone) util.die("existing sparse-checkout patterns do not use cone mode", .{});
                var it = existing.recursive.keyIterator();
                while (it.next()) |k| {
                    if (!sparse.containsParent(&pl.recursive, k.*) or !sparse.containsParent(&pl.parent, k.*))
                        pl.insertRecursive(k.*);
                }
            } else {
                const data = os.readFile(sparse.sparseFilename()) orelse
                    util.die("unable to load existing sparse-checkout patterns", .{});
                pl.addBuffer(data);
                addPatternsFromInput(pl, args, input);
            }
        },
        .replace => addPatternsFromInput(pl, args, input),
    }
    var changed_config = false;
    if (!g_apply) {
        _ = setConfig(.all);
        g_apply = true;
        changed_config = true;
    }
    const result = writePatternsAndUpdate(pl);
    if (result != .success and changed_config) _ = setConfig(.none);
    return result;
}

fn sanitizePaths(args: [][]const u8, skip_checks: bool) void {
    if (args.len == 0) return;
    const prefix = repo_mod.repo().prefix;
    if (prefix.len > 0 and g_cone) {
        for (args) |*a| {
            a.* = repo_mod.prefixPath(a.*) orelse
                util.die("'{s}' is outside repository at '{s}'", .{ a.*, repo_mod.repo().work_tree orelse "" });
        }
    }
    if (skip_checks) return;
    if (prefix.len > 0 and !g_cone) util.die("please run from the toplevel directory in non-cone mode", .{});
    if (g_cone) {
        for (args) |a| {
            if (a.len > 0 and a[0] == '/') util.die("specify directories rather than patterns (no leading slash)", .{});
            if (a.len > 0 and a[0] == '!') util.die("specify directories rather than patterns.  If your directory starts with a '!', pass --skip-checks", .{});
            if (std.mem.indexOfAny(u8, a, "*?[]") != null)
                util.die("specify directories rather than patterns.  If your directory really has any of '*?[]\\' in it, pass --skip-checks", .{});
        }
    }
    const idx = index_mod.get();
    for (args) |a| {
        const pos = idx.findPos(a) orelse continue;
        if (idx.entries.items[pos].stage() != 0) continue;
        if (g_cone)
            util.die("'{s}' is not a directory; to treat it as a directory anyway, rerun with --skip-checks", .{a})
        else
            util.warn("pass a leading slash before paths such as '{s}' if you want a single file (see NON-CONE PROBLEMS in the git-sparse-checkout manual).", .{a});
    }
}

// ---------------------------------------------------------------------------
// subcommands

fn cmdList(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git sparse-checkout list"};
    const opts = [_]po.Opt{};
    setupWorkTree();
    if (!g_apply) util.die("this worktree is not sparse", .{});
    _ = po.parse(args[1..], &opts, &usage, .{});
    const pl = sparse.loadFile(sparse.sparseFilename(), g_cone) orelse {
        util.warn("this worktree is not sparse (sparse-checkout file may not exist)", .{});
        return 0;
    };
    if (pl.use_cone) {
        var sl: std.ArrayList([]const u8) = .empty;
        var it = pl.recursive.keyIterator();
        while (it.next()) |k| sl.append(gpa, k.*[1..]) catch util.oom();
        for (sortedUnique(&sl)) |s| util.outf("{s}\n", .{util.cquote(s)});
    } else {
        var b: util.Buf = .empty;
        writePatterns(&b, pl);
        util.out(b.items);
    }
    return 0;
}

fn cmdInit(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git sparse-checkout init [--cone] [--[no-]sparse-index]"};
    var cone: i32 = -1;
    var sparse_index: i32 = -1;
    const opts = [_]po.Opt{
        po.setInt(0, "cone", &cone, 1, "initialize the sparse-checkout in cone mode"),
        po.setInt(0, "sparse-index", &sparse_index, 1, "toggle the use of a sparse index"),
    };
    setupWorkTree();
    _ = index_mod.get();
    _ = po.parse(args[1..], &opts, &usage, .{});
    if (updateModes(&cone, sparse_index)) return 1;
    const fname = sparse.sparseFilename();
    if (os.readFile(fname) != null) return exitCode(updateWorkingDirectory(null));
    if (revparse.getOid("HEAD") == null) {
        if (!os.mkdirLeading(fname)) util.die("unable to create leading directories of {s}", .{fname});
        os.writeFile(fname, "/*\n!/*/\n", 0o666) catch util.die("failed to open '{s}'", .{fname});
        return 0;
    }
    const pl = Patterns.init(false);
    pl.add("/*");
    pl.add("!/*/");
    pl.use_cone = cone != 0;
    return exitCode(writePatternsAndUpdate(pl));
}

fn cmdSet(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git sparse-checkout set [--[no-]cone] [--[no-]sparse-index] [--skip-checks] (--stdin | <patterns>)"};
    var cone: i32 = -1;
    var sparse_index: i32 = -1;
    var skip_checks = false;
    var use_stdin = false;
    var opts = [_]po.Opt{
        po.setInt(0, "cone", &cone, 1, "initialize the sparse-checkout in cone mode"),
        po.setInt(0, "sparse-index", &sparse_index, 1, "toggle the use of a sparse index"),
        po.boolean(0, "skip-checks", &skip_checks, "skip some sanity checks on the given paths that might give false positives"),
        po.boolean(0, "stdin", &use_stdin, "read patterns from standard in"),
    };
    opts[2].noneg = true;
    opts[3].noneg = true;
    setupWorkTree();
    _ = index_mod.get();
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (updateModes(&cone, sparse_index)) return 1;
    var patterns: [][]const u8 = undefined;
    if (!g_cone and !use_stdin and rest.len == 0) {
        patterns = gpa.dupe([]const u8, &.{ "/*", "!/*/" }) catch util.oom();
    } else {
        patterns = gpa.dupe([]const u8, rest) catch util.oom();
        sanitizePaths(patterns, skip_checks);
    }
    return exitCode(modifyPatternList(patterns, use_stdin, .replace));
}

fn cmdAdd(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git sparse-checkout add [--skip-checks] (--stdin | <patterns>)"};
    var skip_checks = false;
    var use_stdin = false;
    var opts = [_]po.Opt{
        po.boolean(0, "skip-checks", &skip_checks, "skip some sanity checks on the given paths that might give false positives"),
        po.boolean(0, "stdin", &use_stdin, "read patterns from standard in"),
    };
    opts[0].noneg = true;
    setupWorkTree();
    if (!g_apply) util.die("no sparse-checkout to add to", .{});
    _ = index_mod.get();
    const rest = po.parse(args[1..], &opts, &usage, .{});
    const patterns = gpa.dupe([]const u8, rest) catch util.oom();
    sanitizePaths(patterns, skip_checks);
    return exitCode(modifyPatternList(patterns, use_stdin, .add));
}

fn cmdReapply(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git sparse-checkout reapply [--[no-]cone] [--[no-]sparse-index]"};
    var cone: i32 = -1;
    var sparse_index: i32 = -1;
    const opts = [_]po.Opt{
        po.setInt(0, "cone", &cone, 1, "initialize the sparse-checkout in cone mode"),
        po.setInt(0, "sparse-index", &sparse_index, 1, "toggle the use of a sparse index"),
    };
    setupWorkTree();
    if (!g_apply) util.die("must be in a sparse-checkout to reapply sparsity patterns", .{});
    _ = po.parse(args[1..], &opts, &usage, .{});
    _ = index_mod.get();
    if (updateModes(&cone, sparse_index)) return 1;
    return exitCode(updateWorkingDirectory(null));
}

fn listFilesIn(msg_dry: bool, path: []const u8) void {
    const ents = os.listDir(path) orelse return;
    var names: std.ArrayList([]const u8) = .empty;
    for (ents) |e| names.append(gpa, e.name) catch util.oom();
    std.mem.sort([]const u8, names.items, {}, lessStr);
    for (names.items) |n| {
        const p = util.concat(&.{ path, "/", n });
        if (os.isDir(p)) {
            listFilesIn(msg_dry, p);
        } else util.outf("{s} {s}\n", .{ if (msg_dry) "Would remove" else "Removing", p });
    }
}

fn cmdClean(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git sparse-checkout clean [-n|--dry-run]"};
    var force: i32 = 0;
    var dry_run = false;
    var verbose: i32 = 0;
    const opts = [_]po.Opt{
        po.boolean('n', "dry-run", &dry_run, "dry run"),
        po.noComplete(po.counter('f', "force", &force, "force")),
        po.verbose(&verbose),
    };
    setupWorkTree();
    if (!g_apply) util.die("must be in a sparse-checkout to clean directories", .{});
    if (!g_cone) util.die("must be in a cone-mode sparse-checkout to clean directories", .{});
    _ = po.parse(args[1..], &opts, &usage, .{});
    const require_force = repo_mod.cfg.getBool("clean.requireforce") orelse true;
    if (require_force and force == 0 and !dry_run)
        util.die("for safety, refusing to clean without one of --force or --dry-run", .{});
    const idx = index_mod.get();
    const pl = sparse.loadFile(sparse.sparseFilename(), g_cone);
    const dirs = blk: {
        if (pl == null or idx.entries.items.len == 0) break :blk null;
        break :blk sparse.sparseDirectories(idx, pl.?);
    } orelse util.die("failed to convert index to a sparse index; resolve merge conflicts and try again", .{});
    for (dirs) |d| {
        if (!os.isDir(d)) continue;
        if (verbose > 0) {
            listFilesIn(dry_run, d[0 .. d.len - 1]);
        } else util.outf("{s} {s}\n", .{ if (dry_run) "Would remove" else "Removing", d });
        if (!dry_run) {
            os.removeTree(d[0 .. d.len - 1]);
            if (os.lstatPath(d) != null) util.warn("failed to remove '{s}': {s}", .{ d, os.lastErr() });
        }
    }
    return 0;
}

fn cmdDisable(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git sparse-checkout disable"};
    const opts = [_]po.Opt{};
    setupWorkTree();
    _ = po.parse(args[1..], &opts, &usage, .{});
    _ = index_mod.get();
    const pl = Patterns.init(false);
    g_apply = true;
    pl.add("/*");
    sparse_index_mod.setSetting(false);
    if (updateWorkingDirectory(pl) != .success) util.die("error while refreshing working directory", .{});
    return @intFromBool(setConfig(.none));
}

fn cmdCheckRules(args: []const []const u8) u8 {
    const usage = [_][]const u8{"git sparse-checkout check-rules [-z] [--skip-checks][--[no-]cone] [--rules-file <file>]"};
    var nul = false;
    var cone: i32 = -1;
    var rules_file: ?[]const u8 = null;
    const opts = [_]po.Opt{
        po.boolean('z', "", &nul, "terminate input and output files by a NUL character"),
        po.setInt(0, "cone", &cone, 1, "when used with --rules-file interpret patterns as cone mode patterns"),
        po.filename(0, "rules-file", &rules_file, "file", "use patterns in <file> instead of the current ones."),
    };
    const rest = po.parse(args[1..], &opts, &usage, .{});
    if (rules_file != null and cone < 0) cone = 1;
    _ = updateConeMode(&cone);
    var pl: *Patterns = undefined;
    if (rules_file) |rf| {
        const data = os.readFile(rf) orelse util.dieErrno("could not open '{s}' for reading", .{rf});
        pl = Patterns.init(g_cone);
        addPatternsFromInput(pl, rest, splitLines(data, '\n'));
    } else {
        pl = sparse.loadFile(sparse.sparseFilename(), g_cone) orelse
            util.die("unable to load existing sparse-checkout patterns", .{});
    }
    const term: u8 = if (nul) 0 else '\n';
    for (readStdinLines(term)) |line| {
        var path = line;
        if (!nul and line.len > 0 and line[0] == '"') {
            const u = util.cunquote(line) orelse util.die("unable to unquote C-style string '{s}'", .{line});
            path = u.value;
        }
        if (pl.pathIn(path, @import("../dir.zig").DT_REG)) {
            if (nul) util.outf("{s}\x00", .{path}) else util.outf("{s}\n", .{util.cquote(path)});
        }
    }
    return 0;
}

pub fn cmdSparseCheckout(args: []const []const u8) u8 {
    po.checkGitcomp(args[1..], &@import("../gitcomp_tables.zig").sparse_checkout);
    const opts = [_]po.Opt{};
    sparse_index_mod.commandIsSparseAware();
    g_apply = sparse.configApply();
    g_cone = sparse.configCone();
    if (args.len < 2) {
        util.err("need a subcommand", .{});
        po.usageWithOptions(&main_usage, &opts);
    }
    const sub = args[1];
    const rest = args[1..];
    if (util.eql(sub, "-h")) po.usageExit(&main_usage, &opts, false);
    if (util.eql(sub, "list")) return cmdList(rest);
    if (util.eql(sub, "init")) return cmdInit(rest);
    if (util.eql(sub, "set")) return cmdSet(rest);
    if (util.eql(sub, "add")) return cmdAdd(rest);
    if (util.eql(sub, "reapply")) return cmdReapply(rest);
    if (util.eql(sub, "clean")) return cmdClean(rest);
    if (util.eql(sub, "disable")) return cmdDisable(rest);
    if (util.eql(sub, "check-rules")) return cmdCheckRules(rest);
    if (sub.len > 0 and sub[0] == '-') {
        util.err("unknown option `{s}'", .{std.mem.trimStart(u8, sub, "-")});
    } else util.err("unknown subcommand: `{s}'", .{sub});
    po.usageWithOptions(&main_usage, &opts);
}
