//! Port of ref-filter.c (formatting/filtering/sorting of refs), versioncmp.c,
//! the remote tracking helpers needed by %(upstream)/%(push) (subset of remote.c),
//! get_head_description() and builtin/for-each-ref.c.
//!
//! Public API (used by for-each-ref, branch, tag):
//!   Filter, Format, Item, Sorting, Branch
//!   FILTER_REFS_* constants, QUOTE_* constants, SORT_* flags
//!   verifyFormat(*Format) bool               verify_ref_format (false: malformed)
//!   sortingOptions([]const []const u8) ?*Sorting   ref_sorting_options
//!   setSortFlagsAll(?*Sorting, mask, on)
//!   filterRefs(*Filter, kind) []*Item        filter_refs
//!   filterAheadBehind([]*Item) / filterIsBase([]*Item)
//!   sortItems(?*Sorting, []*Item)            ref_array_sort
//!   formatItem(*Item, *Format, *Buf)         format_ref_array_item (dies on error)
//!   formatItemErr(*Item, *Format, *Buf, *[]const u8) bool
//!   printFormattedArray([]*Item, *Format)    print_formatted_ref_array
//!   filterAndFormat(*Filter, kind, ?*Sorting, *Format)
//!   prettyPrintRef(name, oid, ?peeled, *Format)
//!   newItem(name, oid) *Item
//!   refKindFromRefname(name) u32
//!   forkedAdd(*Filter, arg) bool
//!   parseOptMergeFilter / parseOptCommits / parseOptPointsAt helpers
//!   versioncmp(a, b) i32
//!   getHeadDescription() []const u8
//!   branchGet(name) *Branch, branchGetUpstream, branchGetPush, statTrackingInfo,
//!   remoteForBranch, pushremoteForBranch, applyRefspecs
//!   forEachRefMain(args, is_refs_list) u8
const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const Oid = hash.Oid;
const refs = @import("refs.zig");
const repo_mod = @import("repo.zig");
const odb_mod = @import("odb.zig");
const objects = @import("objects.zig");
const cn = @import("commitnode.zig");
const reach = @import("commitreach.zig");
const color_mod = @import("color.zig");
const po = @import("parseopt.zig");
const pretty = @import("pretty.zig");
const trailer_mod = @import("pretty_trailer.zig");
const mailmap_mod = @import("mailmap.zig");
const date_mod = @import("date.zig");
const wildmatch = @import("wildmatch.zig");
const revparse = @import("revparse.zig");
const config_mod = @import("config.zig");

const gpa = util.gpa;
const Buf = util.Buf;

// ---------------------------------------------------------------------------
// constants

pub const FILTER_REFS_TAGS: u32 = 0x0002;
pub const FILTER_REFS_BRANCHES: u32 = 0x0004;
pub const FILTER_REFS_REMOTES: u32 = 0x0008;
pub const FILTER_REFS_OTHERS: u32 = 0x0010;
pub const FILTER_REFS_REGULAR: u32 = FILTER_REFS_TAGS | FILTER_REFS_BRANCHES | FILTER_REFS_REMOTES | FILTER_REFS_OTHERS;
pub const FILTER_REFS_DETACHED_HEAD: u32 = 0x0020;
pub const FILTER_REFS_PSEUDOREFS: u32 = 0x0040;
pub const FILTER_REFS_ROOT_REFS: u32 = 0x0080;
pub const FILTER_REFS_KIND_MASK: u32 = FILTER_REFS_REGULAR | FILTER_REFS_DETACHED_HEAD | FILTER_REFS_PSEUDOREFS | FILTER_REFS_ROOT_REFS;

pub const QUOTE_NONE: i32 = 0;
pub const QUOTE_SHELL: i32 = 1;
pub const QUOTE_PERL: i32 = 2;
pub const QUOTE_PYTHON: i32 = 4;
pub const QUOTE_TCL: i32 = 8;

pub const SORT_REVERSE: u32 = 1;
pub const SORT_ICASE: u32 = 2;
pub const SORT_VERSION: u32 = 4;
pub const SORT_DETACHED_HEAD_FIRST: u32 = 8;

fn chAt(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

fn cstr(s: []const u8) []const u8 {
    if (std.mem.indexOfScalar(u8, s, 0)) |i| return s[0..i];
    return s;
}

// ---------------------------------------------------------------------------
// atoms

const AtomType = enum {
    refname,
    objecttype,
    objectsize,
    objectname,
    deltabase,
    tree,
    parent,
    numparent,
    object,
    type,
    tag,
    author,
    authorname,
    authoremail,
    authordate,
    committer,
    committername,
    committeremail,
    committerdate,
    tagger,
    taggername,
    taggeremail,
    taggerdate,
    creator,
    creatordate,
    describe,
    subject,
    body,
    trailers,
    contents,
    signature,
    raw,
    upstream,
    push,
    symref,
    flag,
    head,
    color,
    worktreepath,
    @"align",
    end,
    @"if",
    then,
    @"else",
    rest,
    ahead_behind,
    is_base,
};

const Source = enum { none, obj, other };
const CmpType = enum { str, ulong, time };
const Parser = enum {
    none,
    refname,
    objecttype,
    objectsize,
    oid,
    deltabase,
    person_name,
    person_email,
    describe,
    subject,
    body,
    trailers,
    contents,
    signature,
    raw,
    remote_ref,
    head,
    color,
    @"align",
    @"if",
    rest,
    ahead_behind,
    is_base,
};

const AtomInfo = struct { name: []const u8, source: Source, cmp: CmpType = .str, parser: Parser = .none };

const valid_atom = [_]AtomInfo{
    .{ .name = "refname", .source = .none, .parser = .refname },
    .{ .name = "objecttype", .source = .other, .parser = .objecttype },
    .{ .name = "objectsize", .source = .other, .cmp = .ulong, .parser = .objectsize },
    .{ .name = "objectname", .source = .other, .parser = .oid },
    .{ .name = "deltabase", .source = .other, .parser = .deltabase },
    .{ .name = "tree", .source = .obj, .parser = .oid },
    .{ .name = "parent", .source = .obj, .parser = .oid },
    .{ .name = "numparent", .source = .obj, .cmp = .ulong },
    .{ .name = "object", .source = .obj },
    .{ .name = "type", .source = .obj },
    .{ .name = "tag", .source = .obj },
    .{ .name = "author", .source = .obj },
    .{ .name = "authorname", .source = .obj, .parser = .person_name },
    .{ .name = "authoremail", .source = .obj, .parser = .person_email },
    .{ .name = "authordate", .source = .obj, .cmp = .time },
    .{ .name = "committer", .source = .obj },
    .{ .name = "committername", .source = .obj, .parser = .person_name },
    .{ .name = "committeremail", .source = .obj, .parser = .person_email },
    .{ .name = "committerdate", .source = .obj, .cmp = .time },
    .{ .name = "tagger", .source = .obj },
    .{ .name = "taggername", .source = .obj, .parser = .person_name },
    .{ .name = "taggeremail", .source = .obj, .parser = .person_email },
    .{ .name = "taggerdate", .source = .obj, .cmp = .time },
    .{ .name = "creator", .source = .obj },
    .{ .name = "creatordate", .source = .obj, .cmp = .time },
    .{ .name = "describe", .source = .obj, .parser = .describe },
    .{ .name = "subject", .source = .obj, .parser = .subject },
    .{ .name = "body", .source = .obj, .parser = .body },
    .{ .name = "trailers", .source = .obj, .parser = .trailers },
    .{ .name = "contents", .source = .obj, .parser = .contents },
    .{ .name = "signature", .source = .obj, .parser = .signature },
    .{ .name = "raw", .source = .obj, .parser = .raw },
    .{ .name = "upstream", .source = .none, .parser = .remote_ref },
    .{ .name = "push", .source = .none, .parser = .remote_ref },
    .{ .name = "symref", .source = .none, .parser = .refname },
    .{ .name = "flag", .source = .none },
    .{ .name = "HEAD", .source = .none, .parser = .head },
    .{ .name = "color", .source = .none, .parser = .color },
    .{ .name = "worktreepath", .source = .none },
    .{ .name = "align", .source = .none, .parser = .@"align" },
    .{ .name = "end", .source = .none },
    .{ .name = "if", .source = .none, .parser = .@"if" },
    .{ .name = "then", .source = .none },
    .{ .name = "else", .source = .none },
    .{ .name = "rest", .source = .none, .parser = .rest },
    .{ .name = "ahead-behind", .source = .other, .parser = .ahead_behind },
    .{ .name = "is-base", .source = .other, .parser = .is_base },
};

const RefnameOpt = struct {
    option: enum { normal, short, lstrip, rstrip } = .normal,
    lstrip: i32 = 0,
    rstrip: i32 = 0,
};

const RemoteRefOpt = struct {
    option: enum { ref, track, trackshort, remotename, remoteref } = .ref,
    refname: RefnameOpt = .{},
    nobracket: bool = false,
    push: bool = false,
    push_remote: bool = false,
};

const AlignPos = enum { left, middle, right };
const Align = struct { position: AlignPos = .left, width: usize = 0 };

const CmpStatus = enum { none, equal, unequal };

const ContentsOpt = enum { bare, body_dep, body, signature, sub, sub_sanitize, trailers, lines, length };

const SigOpt = enum { bare, signer, grade, key, fingerprint, primarykeyfingerprint, trustlevel };

const EO_TRIM: u32 = 1;
const EO_LOCALPART: u32 = 2;
const EO_MAILMAP: u32 = 4;

const UsedAtom = struct {
    atom_type: AtomType,
    name: []const u8,
    typ: CmpType,
    source: Source,
    refname: RefnameOpt = .{},
    rr: RemoteRefOpt = .{},
    color: []const u8 = "",
    @"align": Align = .{},
    if_cmp: CmpStatus = .none,
    if_str: ?[]const u8 = null,
    contents: ContentsOpt = .bare,
    nlines: usize = 0,
    trailer_opts: trailer_mod.Options = .{},
    oid_opt: enum { full, short, length } = .full,
    oid_len: usize = 0,
    name_mailmap: bool = false,
    email_opt: u32 = 0,
    objectsize_disk: bool = false,
    raw_length: bool = false,
    sig_opt: SigOpt = .bare,
    describe_args: std.ArrayList([]const u8) = .empty,
    head: ?[]const u8 = null,
    base_commit: ?*cn.Commit = null,
    base_name: []const u8 = "",
};

const Need = struct {
    content: bool = false,
    typ: bool = false,
    size: bool = false,
    disk: bool = false,
    delta: bool = false,
    fn any(n: Need) bool {
        return n.content or n.typ or n.size or n.disk or n.delta;
    }
};

var used_atom: std.ArrayList(UsedAtom) = .empty;
var need_tagged = false;
var need_symref = false;
var oi_need: Need = .{};
var oi_deref_need: Need = .{};

/// Number of atoms parsed so far (for callers that need to know).
pub fn usedAtomCount() usize {
    return used_atom.items.len;
}

// ---------------------------------------------------------------------------
// public types

pub const Filter = struct {
    name_patterns: []const []const u8 = &.{},
    start_after: ?[]const u8 = null,
    exclude: std.ArrayList([]const u8) = .empty,
    forked: std.ArrayList([]const u8) = .empty,
    points_at: std.ArrayList(Oid) = .empty,
    with_commit: ?*cn.CommitList = null,
    no_commit: ?*cn.CommitList = null,
    reachable_from: ?*cn.CommitList = null,
    unreachable_from: ?*cn.CommitList = null,
    with_commit_tag_algo: bool = false,
    match_as_path: bool = false,
    ignore_case: bool = false,
    detached: bool = false,
    kind: u32 = 0,
    lines: i32 = 0,
    abbrev: i32 = 0,
    verbose: i32 = 0,
    contains_cache: reach.ContainsCache = undefined,
    no_contains_cache: reach.ContainsCache = undefined,
};

pub const Format = struct {
    format: []const u8 = "",
    rest: ?[]const u8 = null,
    quote_style: i32 = 0,
    use_color: color_mod.ColorBool = .unknown,
    need_color_reset_at_eol: bool = false,
    max_count: i32 = 0,
    omit_empty: bool = false,
};

const Handler = enum { append, @"align", end, @"if", then, @"else" };

const AtomValue = struct {
    s: ?[]const u8 = null,
    s_size: ?usize = null,
    handler: Handler = .append,
    value: u64 = 0,
    atom: usize = 0,
};

pub const Item = struct {
    refname: []const u8,
    objectname: Oid,
    peeled: ?Oid = null,
    flag: u32 = 0,
    kind: u32 = 0,
    symref: ?[]const u8 = null,
    commit: ?*cn.Commit = null,
    value: ?[]AtomValue = null,
    counts: ?[]reach.AheadBehindCount = null,
    is_base: ?[]?[]const u8 = null,
    rest: ?[]const u8 = null,
};

pub const Sorting = struct {
    next: ?*Sorting = null,
    atom: usize = 0,
    flags: u32 = 0,
};

pub fn newItem(name: []const u8, oid: Oid) *Item {
    const it = gpa.create(Item) catch util.oom();
    it.* = .{ .refname = util.dupe(name), .objectname = oid };
    return it;
}

// ---------------------------------------------------------------------------
// atom argument parsers

const ParseErr = struct { msg: []const u8 = "" };

fn errNoArg(e: *ParseErr, name: []const u8) bool {
    const n = name[0 .. std.mem.indexOfScalar(u8, name, ':') orelse name.len];
    e.msg = util.fmt("%({s}) does not take arguments", .{n});
    return false;
}

fn errBadArg(e: *ParseErr, name: []const u8, arg: []const u8) bool {
    const n = name[0 .. std.mem.indexOfScalar(u8, name, ':') orelse name.len];
    e.msg = util.fmt("unrecognized %({s}) argument: {s}", .{ n, arg });
    return false;
}

fn strtolI(s: []const u8) ?i32 {
    // strtol_i: whole string must be a valid int
    if (s.len == 0) return null;
    var t = s;
    while (t.len > 0 and std.ascii.isWhitespace(t[0])) t = t[1..];
    return std.fmt.parseInt(i32, t, 10) catch null;
}

fn strtoulUi(s: []const u8) ?u32 {
    if (std.mem.indexOfScalar(u8, s, '-') != null) return null;
    var t = s;
    while (t.len > 0 and std.ascii.isWhitespace(t[0])) t = t[1..];
    if (t.len > 0 and t[0] == '+') t = t[1..];
    if (t.len == 0) return null;
    return std.fmt.parseInt(u32, t, 10) catch null;
}

fn refnameParserInternal(o: *RefnameOpt, arg: ?[]const u8, name: []const u8, e: *ParseErr) bool {
    const a = arg orelse {
        o.option = .normal;
        return true;
    };
    if (util.eql(a, "short")) {
        o.option = .short;
    } else if (util.skipPrefix(a, "lstrip=") orelse util.skipPrefix(a, "strip=")) |v| {
        o.option = .lstrip;
        o.lstrip = strtolI(v) orelse {
            e.msg = util.fmt("Integer value expected refname:lstrip={s}", .{v});
            return false;
        };
    } else if (util.skipPrefix(a, "rstrip=")) |v| {
        o.option = .rstrip;
        o.rstrip = strtolI(v) orelse {
            e.msg = util.fmt("Integer value expected refname:rstrip={s}", .{v});
            return false;
        };
    } else return errBadArg(e, name, a);
    return true;
}

/// match_atom_arg_value
fn matchAtomArgValue(to_parse: []const u8, candidate: []const u8, end: *[]const u8, value: *?[]const u8) bool {
    var rest = util.skipPrefix(to_parse, candidate) orelse return false;
    if (rest.len > 0 and rest[0] == '=') {
        const vs = rest[1..];
        const comma = std.mem.indexOfScalar(u8, vs, ',') orelse vs.len;
        value.* = vs[0..comma];
        rest = vs[comma..];
    } else if (rest.len > 0 and rest[0] != ',') {
        return false;
    } else {
        value.* = null;
    }
    if (rest.len > 0 and rest[0] == ',') rest = rest[1..];
    end.* = rest;
    return true;
}

fn matchAtomBoolArg(to_parse: []const u8, candidate: []const u8, end: *[]const u8, val: *bool) bool {
    var v: ?[]const u8 = null;
    if (!matchAtomArgValue(to_parse, candidate, end, &v)) return false;
    const s = v orelse {
        val.* = true;
        return true;
    };
    const r = config_mod.parseMaybeBool(s);
    if (r < 0) return false;
    val.* = r != 0;
    return true;
}

fn wantColorFormat(f: *const Format) bool {
    return color_mod.wantColorBool(f.use_color, null);
}

fn parseAlignPosition(s: []const u8) ?AlignPos {
    if (util.eql(s, "right")) return .right;
    if (util.eql(s, "middle")) return .middle;
    if (util.eql(s, "left")) return .left;
    return null;
}

fn lookupCommitByName(name: []const u8) ?*cn.Commit {
    const oid = revparse.getOid(name) orelse return null;
    return cn.lookupCommitReference(oid);
}

fn runParser(format: *const Format, a: *UsedAtom, parser: Parser, arg: ?[]const u8, e: *ParseErr) bool {
    const deref = a.name.len > 0 and a.name[0] == '*';
    switch (parser) {
        .none => return true,
        .color => {
            const v = arg orelse {
                e.msg = "expected format: %(color:<color>)";
                return false;
            };
            a.color = color_mod.parseColor(v) orelse {
                e.msg = util.fmt("unrecognized color: %(color:{s})", .{v});
                return false;
            };
            if (!wantColorFormat(format)) a.color = "";
            return true;
        },
        .refname => return refnameParserInternal(&a.refname, arg, a.name, e),
        .remote_ref => {
            if (util.eql(a.name, "push") or util.startsWith(a.name, "push:")) a.rr.push = true;
            const ar = arg orelse {
                a.rr.option = .ref;
                return refnameParserInternal(&a.rr.refname, null, a.name, e);
            };
            a.rr.nobracket = false;
            var it = std.mem.splitScalar(u8, ar, ',');
            while (it.next()) |s| {
                if (util.eql(s, "track")) {
                    a.rr.option = .track;
                } else if (util.eql(s, "trackshort")) {
                    a.rr.option = .trackshort;
                } else if (util.eql(s, "nobracket")) {
                    a.rr.nobracket = true;
                } else if (util.eql(s, "remotename")) {
                    a.rr.option = .remotename;
                    a.rr.push_remote = true;
                } else if (util.eql(s, "remoteref")) {
                    a.rr.option = .remoteref;
                    a.rr.push_remote = true;
                } else {
                    a.rr.option = .ref;
                    if (!refnameParserInternal(&a.rr.refname, ar, a.name, e)) return false;
                }
            }
            return true;
        },
        .objecttype => {
            if (arg != null) return errNoArg(e, "objecttype");
            if (deref) oi_deref_need.typ = true else oi_need.typ = true;
            return true;
        },
        .objectsize => {
            if (arg) |v| {
                if (util.eql(v, "disk")) {
                    a.objectsize_disk = true;
                    if (deref) oi_deref_need.disk = true else oi_need.disk = true;
                } else return errBadArg(e, "objectsize", v);
            } else {
                if (deref) oi_deref_need.size = true else oi_need.size = true;
            }
            return true;
        },
        .deltabase => {
            if (arg != null) return errNoArg(e, "deltabase");
            if (deref) oi_deref_need.delta = true else oi_need.delta = true;
            return true;
        },
        .body => {
            if (arg != null) return errNoArg(e, "body");
            a.contents = .body_dep;
            return true;
        },
        .subject => {
            if (arg) |v| {
                if (util.eql(v, "sanitize")) a.contents = .sub_sanitize else return errBadArg(e, "subject", v);
            } else a.contents = .sub;
            return true;
        },
        .signature => {
            a.sig_opt = parseSignatureOption(arg) orelse return errBadArg(e, "signature", arg.?);
            return true;
        },
        .trailers => return trailersParser(a, arg, e),
        .contents => {
            const v = arg orelse {
                a.contents = .bare;
                return true;
            };
            if (util.eql(v, "body")) {
                a.contents = .body;
            } else if (util.eql(v, "size")) {
                a.typ = .ulong;
                a.contents = .length;
            } else if (util.eql(v, "signature")) {
                a.contents = .signature;
            } else if (util.eql(v, "subject")) {
                a.contents = .sub;
            } else if (util.eql(v, "trailers")) {
                return trailersParser(a, null, e);
            } else if (util.skipPrefix(v, "trailers:")) |t| {
                return trailersParser(a, t, e);
            } else if (util.skipPrefix(v, "lines=")) |n| {
                a.contents = .lines;
                a.nlines = strtoulUi(n) orelse {
                    e.msg = util.fmt("positive value expected contents:lines={s}", .{n});
                    return false;
                };
            } else return errBadArg(e, "contents", v);
            return true;
        },
        .describe => {
            var cur: []const u8 = arg orelse return true;
            while (cur.len > 0) {
                const bad = cur;
                var end: []const u8 = cur;
                var bval = false;
                var val: ?[]const u8 = null;
                if (matchAtomBoolArg(cur, "tags", &end, &bval)) {
                    a.describe_args.append(gpa, if (bval) "--tags" else "--no-tags") catch util.oom();
                } else if (matchAtomArgValue(cur, "abbrev", &end, &val)) {
                    const v = val orelse "";
                    if (v.len == 0) {
                        e.msg = "argument expected for describe:abbrev";
                        return false;
                    }
                    // strtol semantics
                    var i: usize = 0;
                    while (i < v.len and std.ascii.isWhitespace(v[i])) i += 1;
                    var neg = false;
                    if (i < v.len and (v[i] == '-' or v[i] == '+')) {
                        neg = v[i] == '-';
                        i += 1;
                    }
                    const ds = i;
                    var num: i64 = 0;
                    while (i < v.len and std.ascii.isDigit(v[i])) : (i += 1) num = num *| 10 +| (v[i] - '0');
                    const consumed: usize = if (i == ds) 0 else i;
                    if (neg and num > 0) {
                        e.msg = util.fmt("positive value expected describe:abbrev={s}", .{bad[std.mem.indexOfScalar(u8, bad, '=').? + 1 ..]});
                        return false;
                    }
                    if (consumed != v.len) {
                        e.msg = util.fmt("cannot fully parse describe:abbrev={s}", .{bad[std.mem.indexOfScalar(u8, bad, '=').? + 1 ..]});
                        return false;
                    }
                    a.describe_args.append(gpa, util.fmt("--abbrev={s}", .{v})) catch util.oom();
                } else if (matchAtomArgValue(cur, "match", &end, &val)) {
                    const v = val orelse "";
                    if (v.len == 0) {
                        e.msg = "value expected describe:match=";
                        return false;
                    }
                    a.describe_args.append(gpa, util.fmt("--match={s}", .{v})) catch util.oom();
                } else if (matchAtomArgValue(cur, "exclude", &end, &val)) {
                    const v = val orelse "";
                    if (v.len == 0) {
                        e.msg = "value expected describe:exclude=";
                        return false;
                    }
                    a.describe_args.append(gpa, util.fmt("--exclude={s}", .{v})) catch util.oom();
                } else {
                    return errBadArg(e, "describe", bad);
                }
                cur = end;
            }
            return true;
        },
        .raw => {
            if (arg) |v| {
                if (util.eql(v, "size")) {
                    a.typ = .ulong;
                    a.raw_length = true;
                } else return errBadArg(e, "raw", v);
            }
            return true;
        },
        .oid => {
            const v = arg orelse {
                a.oid_opt = .full;
                return true;
            };
            if (util.eql(v, "short")) {
                a.oid_opt = .short;
            } else if (util.skipPrefix(v, "short=")) |n| {
                a.oid_opt = .length;
                const l = strtoulUi(n);
                if (l == null or l.? == 0) {
                    e.msg = util.fmt("positive value expected '{s}' in %({s})", .{ n, a.name });
                    return false;
                }
                a.oid_len = if (l.? < 4) 4 else l.?;
            } else return errBadArg(e, a.name, v);
            return true;
        },
        .person_name => {
            if (arg) |v| {
                if (util.eql(v, "mailmap")) a.name_mailmap = true else return errBadArg(e, a.name, v);
            }
            return true;
        },
        .person_email => {
            var cur = arg orelse return true;
            while (true) {
                const bad = cur;
                var opt: u32 = 0;
                if (util.skipPrefix(cur, "trim")) |r| {
                    opt = EO_TRIM;
                    cur = r;
                } else if (util.skipPrefix(cur, "localpart")) |r| {
                    opt = EO_LOCALPART;
                    cur = r;
                } else if (util.skipPrefix(cur, "mailmap")) |r| {
                    opt = EO_MAILMAP;
                    cur = r;
                }
                if (opt == 0) return errBadArg(e, a.name, bad);
                a.email_opt |= opt;
                if (cur.len == 0) break;
                if (cur[0] == ',') {
                    cur = cur[1..];
                } else return errBadArg(e, a.name, bad);
            }
            return true;
        },
        .@"align" => {
            const v = arg orelse {
                e.msg = "expected format: %(align:<width>,<position>)";
                return false;
            };
            a.@"align".position = .left;
            var width: ?u32 = null;
            var it = std.mem.splitScalar(u8, v, ',');
            while (it.next()) |s| {
                if (util.skipPrefix(s, "position=")) |pv| {
                    a.@"align".position = parseAlignPosition(pv) orelse {
                        e.msg = util.fmt("unrecognized position:{s}", .{pv});
                        return false;
                    };
                } else if (util.skipPrefix(s, "width=")) |w| {
                    width = strtoulUi(w) orelse {
                        e.msg = util.fmt("unrecognized width:{s}", .{w});
                        return false;
                    };
                } else if (strtoulUi(s)) |w| {
                    width = w;
                } else if (parseAlignPosition(s)) |p| {
                    a.@"align".position = p;
                } else {
                    e.msg = util.fmt("unrecognized %(align) argument: {s}", .{s});
                    return false;
                }
            }
            const w = width orelse {
                e.msg = "positive width expected with the %(align) atom";
                return false;
            };
            if (w == std.math.maxInt(u32)) {
                e.msg = "positive width expected with the %(align) atom";
                return false;
            }
            a.@"align".width = w;
            return true;
        },
        .@"if" => {
            if (arg) |v| {
                if (util.skipPrefix(v, "equals=")) |s| {
                    a.if_cmp = .equal;
                    a.if_str = s;
                } else if (util.skipPrefix(v, "notequals=")) |s| {
                    a.if_cmp = .unequal;
                    a.if_str = s;
                } else return errBadArg(e, "if", v);
            } else a.if_cmp = .none;
            return true;
        },
        .rest => {
            if (arg != null) return errNoArg(e, "rest");
            return true;
        },
        .ahead_behind, .is_base => {
            const v = arg orelse {
                e.msg = if (parser == .ahead_behind) "expected format: %(ahead-behind:<committish>)" else "expected format: %(is-base:<committish>)";
                return false;
            };
            a.base_name = v;
            a.base_commit = lookupCommitByName(v) orelse util.die("failed to find '{s}'", .{v});
            return true;
        },
        .head => {
            if (arg != null) return errNoArg(e, "HEAD");
            const r = refs.resolveFull("HEAD", true);
            a.head = if (r.missing or r.broken) null else r.name;
            return true;
        },
    }
}

fn parseSignatureOption(arg: ?[]const u8) ?SigOpt {
    const a = arg orelse return .bare;
    if (util.eql(a, "signer")) return .signer;
    if (util.eql(a, "grade")) return .grade;
    if (util.eql(a, "key")) return .key;
    if (util.eql(a, "fingerprint")) return .fingerprint;
    if (util.eql(a, "primarykeyfingerprint")) return .primarykeyfingerprint;
    if (util.eql(a, "trustlevel")) return .trustlevel;
    return null;
}

fn trailersParser(a: *UsedAtom, arg: ?[]const u8, e: *ParseErr) bool {
    a.trailer_opts.no_divider = true;
    if (arg) |v| {
        const argbuf = util.concat(&.{ v, ")" });
        var invalid: []const u8 = "";
        if (pretty.setTrailersOptions(&a.trailer_opts, argbuf, &invalid) == null) {
            if (invalid.len == 0) {
                e.msg = "expected %(trailers:key=<value>)";
            } else {
                e.msg = util.fmt("unknown %(trailers) argument: {s}", .{invalid});
            }
            return false;
        }
    }
    a.contents = .trailers;
    return true;
}

/// parse_ref_filter_atom: returns atom index or null with e.msg set.
fn parseRefFilterAtom(format: *const Format, atom: []const u8, e: *ParseErr) ?usize {
    var sp: usize = 0;
    if (atom.len > 0 and atom[0] == '*') sp = 1;
    if (atom.len <= sp) {
        e.msg = util.fmt("malformed field name: {s}", .{atom});
        return null;
    }
    const body = atom[sp..];
    const colon = std.mem.indexOfScalar(u8, body, ':');
    const atom_name = body[0 .. colon orelse body.len];

    for (used_atom.items, 0..) |ua, i| {
        if (util.eql(ua.name, atom)) return i;
    }
    var idx: ?usize = null;
    for (valid_atom, 0..) |va, i| {
        if (util.eql(va.name, atom_name)) {
            idx = i;
            break;
        }
    }
    const vi = idx orelse {
        e.msg = util.fmt("unknown field name: {s}", .{atom});
        return null;
    };
    const info = valid_atom[vi];
    if (info.source != .none and !haveGitDir()) {
        e.msg = util.fmt("not a git repository, but the field '{s}' requires access to object data", .{atom});
        return null;
    }
    const at_idx = used_atom.items.len;
    used_atom.append(gpa, .{
        .atom_type = @enumFromInt(vi),
        .name = util.dupe(atom),
        .typ = info.cmp,
        .source = info.source,
    }) catch util.oom();
    const a = &used_atom.items[at_idx];
    if (info.source == .obj) {
        if (atom[0] == '*') oi_deref_need.content = true else oi_need.content = true;
    }
    var arg: ?[]const u8 = null;
    if (colon) |c| {
        const s = a.name[sp + c + 1 ..];
        if (s.len > 0) arg = s;
    }
    if (!runParser(format, a, info.parser, arg, e)) return null;
    if (atom[0] == '*') need_tagged = true;
    if (a.atom_type == .symref) need_symref = true;
    return at_idx;
}

fn haveGitDir() bool {
    return repo_mod.repo_ != null;
}

// ---------------------------------------------------------------------------
// format verification

fn findNext(s: []const u8, from: usize) ?usize {
    var i = from;
    while (i < s.len) {
        if (s[i] == '%') {
            if (chAt(s, i + 1) == '(') return i;
            if (chAt(s, i + 1) == '%') i += 1;
        }
        i += 1;
    }
    return null;
}

/// verify_ref_format: parses atoms; returns false (after printing an error)
/// on a malformed format string. Dies on atom errors.
pub fn verifyFormat(format: *Format) bool {
    const f = format.format;
    format.need_color_reset_at_eol = false;
    var cp: usize = 0;
    while (cp < f.len) {
        const sp = findNext(f, cp) orelse break;
        const ep = std.mem.indexOfScalarPos(u8, f, sp, ')') orelse {
            util.err("malformed format string {s}", .{f[sp..]});
            return false;
        };
        var e = ParseErr{};
        const at_idx = parseRefFilterAtom(format, f[sp + 2 .. ep], &e) orelse util.die("{s}", .{e.msg});
        const a = &used_atom.items[at_idx];
        if (a.atom_type == .rest and format.rest == null and !rest_allowed)
            util.die("this command reject atom %({s})", .{f[sp + 2 .. ep]});
        if ((format.quote_style == QUOTE_PYTHON or format.quote_style == QUOTE_SHELL or format.quote_style == QUOTE_TCL) and
            a.atom_type == .raw and !a.raw_length)
            util.die("--format={s} cannot be used with --python, --shell, --tcl", .{f[sp + 2 .. ep]});
        cp = ep + 1;
        if (util.skipPrefix(a.name, "color:")) |c| format.need_color_reset_at_eol = !util.eql(c, "reset");
    }
    if (format.need_color_reset_at_eol and !wantColorFormat(format)) format.need_color_reset_at_eol = false;
    return true;
}

/// Set by callers that support %(rest) (cat-file style); for-each-ref rejects it.
pub var rest_allowed: bool = false;

// ---------------------------------------------------------------------------
// show_ref / refname helpers

fn lstripRefComponents(refname: []const u8, len_in: i32) []const u8 {
    var remaining: i64 = len_in;
    var start: []const u8 = refname;
    if (remaining < 0) {
        var i: i64 = 0;
        for (refname) |ch| {
            if (ch == '/') i += 1;
        }
        // "+1" because refname has one more component than slashes
        remaining = i + remaining + 1;
        if (remaining < 0) remaining = 0;
    }
    while (remaining > 0) {
        if (start.len == 0) return "";
        const sl = std.mem.indexOfScalar(u8, start, '/') orelse return "";
        start = start[sl + 1 ..];
        remaining -= 1;
    }
    return start;
}

fn rstripRefComponents(refname: []const u8, len_in: i32) []const u8 {
    var remaining: i64 = len_in;
    var s: []const u8 = refname;
    if (remaining < 0) {
        var i: i64 = 0;
        for (refname) |ch| {
            if (ch == '/') i += 1;
        }
        remaining = i + remaining + 1;
        if (remaining < 0) remaining = 0;
    }
    while (remaining > 0) {
        remaining -= 1;
        const sl = std.mem.lastIndexOfScalar(u8, s, '/') orelse return "";
        s = s[0..sl];
    }
    return s;
}

fn showRef(o: *const RefnameOpt, refname: []const u8) []const u8 {
    return switch (o.option) {
        .short => refs.shortenUnambiguousStrict(refname, warnAmbiguous()),
        .lstrip => lstripRefComponents(refname, o.lstrip),
        .rstrip => rstripRefComponents(refname, o.rstrip),
        .normal => refname,
    };
}

fn warnAmbiguous() bool {
    return repo_mod.cfg.getBool("core.warnambiguousrefs") orelse true;
}

// ---------------------------------------------------------------------------
// remote / branch tracking helpers (subset of remote.c)

pub const Branch = struct {
    name: []const u8,
    refname: []const u8,
    remote_name: ?[]const u8 = null,
    pushremote_name: ?[]const u8 = null,
    merge_names: []const []const u8 = &.{},
    /// merge[i].dst after set_merge (null when not stored as remote-tracking)
    merge_dst: []?[]const u8 = &.{},
};

var branch_cache: std.StringHashMapUnmanaged(*Branch) = .empty;

pub fn branchGet(name: []const u8) *Branch {
    if (branch_cache.get(name)) |b| return b;
    const cfg = &repo_mod.cfg;
    const b = gpa.create(Branch) catch util.oom();
    b.* = .{ .name = util.dupe(name), .refname = util.concat(&.{ "refs/heads/", name }) };
    b.remote_name = cfg.get(util.concat(&.{ "branch.", name, ".remote" }));
    b.pushremote_name = cfg.get(util.concat(&.{ "branch.", name, ".pushremote" }));
    b.merge_names = cfg.getAll(util.concat(&.{ "branch.", name, ".merge" }));
    // set_merge
    if (b.remote_name != null and b.merge_names.len > 0) {
        const dsts = gpa.alloc(?[]const u8, b.merge_names.len) catch util.oom();
        const fetch = remoteRefspecs(b.remote_name.?, "fetch");
        for (b.merge_names, 0..) |m, i| {
            dsts[i] = queryRefspecs(fetch, m);
            if (dsts[i] != null or !util.eql(b.remote_name.?, ".")) continue;
            if (refs.dwimRef(m)) |d| {
                dsts[i] = if (d.count == 1) d.name else m;
            } else dsts[i] = m;
        }
        b.merge_dst = dsts;
    } else {
        b.merge_names = &.{};
    }
    branch_cache.put(gpa, b.name, b) catch util.oom();
    return b;
}

const Refspec = struct {
    force: bool = false,
    negative: bool = false,
    pattern: bool = false,
    src: []const u8 = "",
    dst: ?[]const u8 = null,
};

fn parseRefspec(s0: []const u8) Refspec {
    var r = Refspec{};
    var s = s0;
    if (s.len > 0 and s[0] == '+') {
        r.force = true;
        s = s[1..];
    } else if (s.len > 0 and s[0] == '^') {
        r.negative = true;
        s = s[1..];
    }
    if (std.mem.lastIndexOfScalar(u8, s, ':')) |c| {
        r.src = s[0..c];
        r.dst = s[c + 1 ..];
    } else r.src = s;
    r.pattern = std.mem.indexOfScalar(u8, r.src, '*') != null;
    return r;
}

fn remoteRefspecs(remote: []const u8, kind: []const u8) []Refspec {
    var l: std.ArrayList(Refspec) = .empty;
    for (repo_mod.cfg.getAll(util.concat(&.{ "remote.", remote, ".", kind }))) |v| {
        l.append(gpa, parseRefspec(v)) catch util.oom();
    }
    return l.items;
}

fn matchRefnameWithPattern(key: []const u8, name: []const u8, value: ?[]const u8) ?[]const u8 {
    const kstar = std.mem.indexOfScalar(u8, key, '*') orelse return null;
    const kpre = key[0..kstar];
    const ksuf = key[kstar + 1 ..];
    if (!util.startsWith(name, kpre) or name.len < kpre.len + ksuf.len or !util.endsWith(name, ksuf)) return null;
    const v = value orelse return "";
    const vstar = std.mem.indexOfScalar(u8, v, '*') orelse util.die("value '{s}' of pattern has no '*'", .{v});
    return util.concat(&.{ v[0..vstar], name[kpre.len .. name.len - ksuf.len], v[vstar + 1 ..] });
}

/// query_refspecs/apply_refspecs: map `name` (as source) to destination.
fn queryRefspecs(rs: []const Refspec, name: []const u8) ?[]const u8 {
    // negative refspecs exclude
    for (rs) |r| {
        if (!r.negative) continue;
        if (r.pattern) {
            if (matchRefnameWithPattern(r.src, name, null) != null) return null;
        } else if (util.eql(r.src, name)) return null;
    }
    for (rs) |r| {
        if (r.dst == null or r.negative) continue;
        if (r.pattern) {
            if (matchRefnameWithPattern(r.src, name, r.dst)) |res| return res;
        } else if (util.eql(name, r.src)) return r.dst.?;
    }
    return null;
}

pub fn applyRefspecs(remote: []const u8, kind: []const u8, name: []const u8) ?[]const u8 {
    return queryRefspecs(remoteRefspecs(remote, kind), name);
}

/// branch_get_upstream. On failure returns null and sets *errmsg (if given).
pub fn branchGetUpstream(b: *Branch, errmsg: ?*[]const u8) ?[]const u8 {
    if (b.merge_names.len == 0) {
        if (errmsg) |e| e.* = util.fmt("no upstream configured for branch '{s}'", .{b.name});
        return null;
    }
    if (b.merge_dst[0] == null) {
        if (errmsg) |e| e.* = util.fmt("upstream branch '{s}' not stored as a remote-tracking branch", .{b.merge_names[0]});
        return null;
    }
    return b.merge_dst[0];
}

pub fn remoteForBranch(b: ?*Branch, explicit: *bool) []const u8 {
    if (b) |br| {
        if (br.remote_name) |r| {
            explicit.* = true;
            return r;
        }
    }
    explicit.* = false;
    return "origin";
}

pub fn pushremoteForBranch(b: ?*Branch, explicit: *bool) []const u8 {
    if (b) |br| {
        if (br.pushremote_name) |r| {
            explicit.* = true;
            return r;
        }
    }
    if (repo_mod.cfg.get("remote.pushdefault")) |r| {
        explicit.* = true;
        return r;
    }
    return remoteForBranch(b, explicit);
}

fn trackingForPushDest(remote: []const u8, refname: []const u8, errmsg: ?*[]const u8) ?[]const u8 {
    const r = applyRefspecs(remote, "fetch", refname);
    if (r == null) {
        if (errmsg) |e| e.* = util.fmt("push destination '{s}' on remote '{s}' has no local tracking branch", .{ refname, remote });
    }
    return r;
}

/// branch_get_push
pub fn branchGetPush(b: *Branch, errmsg: ?*[]const u8) ?[]const u8 {
    var explicit = false;
    const remote = pushremoteForBranch(b, &explicit);
    const push = remoteRefspecs(remote, "push");
    if (push.len > 0) {
        const dst = queryRefspecs(push, b.refname) orelse {
            if (errmsg) |e| e.* = util.fmt("push refspecs for '{s}' do not include '{s}'", .{ remote, b.name });
            return null;
        };
        return trackingForPushDest(remote, dst, errmsg);
    }
    if (repo_mod.cfg.getBool(util.concat(&.{ "remote.", remote, ".mirror" })) orelse false)
        return trackingForPushDest(remote, b.refname, errmsg);
    const pd = repo_mod.cfg.get("push.default") orelse "simple";
    if (util.eql(pd, "nothing")) {
        if (errmsg) |e| e.* = "push.default is \"nothing\"";
        return null;
    }
    if (util.eql(pd, "matching") or util.eql(pd, "current")) return trackingForPushDest(remote, b.refname, errmsg);
    if (util.eql(pd, "upstream") or util.eql(pd, "tracking")) return branchGetUpstream(b, errmsg);
    const up = branchGetUpstream(b, errmsg) orelse return null;
    const cur = trackingForPushDest(remote, b.refname, errmsg) orelse return null;
    if (!util.eql(cur, up)) {
        if (errmsg) |e| e.* = "cannot resolve 'simple' push to a single destination";
        return null;
    }
    return cur;
}

pub const Tracking = struct {
    /// -1: no base / gone; 0: same; 1: differ
    result: i32,
    ours: usize = 0,
    theirs: usize = 0,
    upstream: ?[]const u8 = null,
};

/// stat_tracking_info (AHEAD_BEHIND_FULL)
pub fn statTrackingInfo(b: *Branch, for_push: bool) Tracking {
    const base = if (for_push) branchGetPush(b, null) else branchGetUpstream(b, null);
    var t = Tracking{ .result = -1, .upstream = base };
    const bs = base orelse return t;
    const toid = refs.readOid(bs) orelse return t;
    const theirs = cn.lookupCommitReference(toid) orelse return t;
    const ooid = refs.readOid(b.refname) orelse return t;
    const ours = cn.lookupCommitReference(ooid) orelse return t;
    if (theirs == ours) {
        t.result = 0;
        return t;
    }
    const ab = reach.countAheadBehind(ours, theirs);
    t.ours = ab.ahead;
    t.theirs = ab.behind;
    t.result = 1;
    return t;
}

/// remote_ref_for_branch
fn remoteRefForBranch(b: *Branch, for_push: bool) ?[]const u8 {
    if (!for_push) {
        if (b.merge_names.len > 0) return b.merge_names[0];
    } else {
        var explicit = false;
        const remote = pushremoteForBranch(b, &explicit);
        const push = remoteRefspecs(remote, "push");
        if (push.len > 0) {
            if (queryRefspecs(push, b.refname)) |d| return d;
        }
    }
    return null;
}

fn fillRemoteRefDetails(a: *const UsedAtom, refname: ?[]const u8, b: *Branch) []const u8 {
    switch (a.rr.option) {
        .ref => return showRef(&a.rr.refname, refname orelse ""),
        .track => {
            const t = statTrackingInfo(b, a.rr.push);
            var s: []const u8 = undefined;
            if (t.result < 0) {
                s = "gone";
            } else if (t.ours == 0 and t.theirs == 0) {
                s = "";
            } else if (t.ours == 0) {
                s = util.fmt("behind {d}", .{t.theirs});
            } else if (t.theirs == 0) {
                s = util.fmt("ahead {d}", .{t.ours});
            } else s = util.fmt("ahead {d}, behind {d}", .{ t.ours, t.theirs });
            if (!a.rr.nobracket and s.len > 0) s = util.fmt("[{s}]", .{s});
            return s;
        },
        .trackshort => {
            const t = statTrackingInfo(b, a.rr.push);
            if (t.result < 0) return "";
            if (t.ours == 0 and t.theirs == 0) return "=";
            if (t.ours == 0) return "<";
            if (t.theirs == 0) return ">";
            return "<>";
        },
        .remotename => {
            var explicit = false;
            const r = if (a.rr.push) pushremoteForBranch(b, &explicit) else remoteForBranch(b, &explicit);
            return if (explicit) r else "";
        },
        .remoteref => return remoteRefForBranch(b, a.rr.push) orelse "",
    }
}

// ---------------------------------------------------------------------------
// HEAD description (wt-status state)

fn getBranchFromFile(path: []const u8) ?[]const u8 {
    const data = os.readFile(repo_mod.repo().gitPath(path)) orelse return null;
    var s: []const u8 = data;
    while (s.len > 0 and s[s.len - 1] == '\n') s = s[0 .. s.len - 1];
    if (s.len == 0) return null;
    if (util.skipPrefix(s, "refs/heads/")) |b| return b;
    if (util.startsWith(s, "refs/")) return s;
    if (s.len >= 40) {
        if (hash.fromHex(s[0..40])) |o| {
            if (s.len == 40 or true) return revparse.abbrev(o, 0);
        }
    }
    if (util.eql(s, "detached HEAD")) return null;
    return s;
}

pub const HeadState = struct {
    rebase_in_progress: bool = false,
    bisect_in_progress: bool = false,
    branch: ?[]const u8 = null,
    bisecting_from: ?[]const u8 = null,
    detached_from: ?[]const u8 = null,
    detached_at: bool = false,
};

pub fn getHeadState() HeadState {
    var st = HeadState{};
    const r = repo_mod.repo();
    if (os.statPath(r.gitPath("rebase-apply")) != null) {
        if (os.statPath(r.gitPath("rebase-apply/applying")) == null) {
            st.rebase_in_progress = true;
            st.branch = getBranchFromFile("rebase-apply/head-name");
        }
    } else if (os.statPath(r.gitPath("rebase-merge")) != null) {
        st.rebase_in_progress = true;
        st.branch = getBranchFromFile("rebase-merge/head-name");
    }
    if (os.statPath(r.gitPath("BISECT_LOG")) != null) {
        st.bisect_in_progress = true;
        st.bisecting_from = getBranchFromFile("BISECT_START");
    }
    // detached from
    const entries = refs.readReflog("HEAD");
    var i = entries.len;
    while (i > 0) {
        i -= 1;
        const e = entries[i];
        const m = util.skipPrefix(e.msg, "checkout: moving from ") orelse continue;
        const tpos = std.mem.indexOf(u8, m, " to ") orelse continue;
        var target = m[tpos + 4 ..];
        if (std.mem.indexOfScalar(u8, target, '\n')) |nl| target = target[0..nl];
        if (util.eql(target, "HEAD")) target = revparse.abbrev(e.new, 0);
        var from: []const u8 = revparse.abbrev(e.new, 0);
        if (refs.dwimRef(target)) |d| {
            if (d.count == 1) {
                var ok = hash.eql(d.oid, e.new);
                if (!ok) {
                    if (cn.lookupCommitReference(d.oid)) |c| ok = hash.eql(c.oid(), e.new);
                }
                if (ok) {
                    from = util.skipPrefix(d.name, "refs/tags/") orelse util.skipPrefix(d.name, "refs/remotes/") orelse d.name;
                }
            }
        }
        st.detached_from = from;
        if (revparse.getOid("HEAD")) |h| st.detached_at = hash.eql(h, e.new);
        break;
    }
    return st;
}

/// get_head_description()
pub fn getHeadDescription() []const u8 {
    const st = getHeadState();
    if (st.rebase_in_progress) {
        if (st.branch) |b| return util.fmt("(no branch, rebasing {s})", .{b});
        return util.fmt("(no branch, rebasing detached HEAD {s})", .{st.detached_from orelse "(null)"});
    }
    if (st.bisect_in_progress) return util.fmt("(no branch, bisect started on {s})", .{st.bisecting_from orelse "(null)"});
    if (st.detached_from) |d| {
        if (st.detached_at) return util.fmt("(HEAD detached at {s})", .{d});
        return util.fmt("(HEAD detached from {s})", .{d});
    }
    return "(no branch)";
}

// ---------------------------------------------------------------------------
// worktree map (for %(worktreepath))

var worktree_map: ?std.StringHashMapUnmanaged([]const u8) = null;

fn readHeadSymref(gitdir: []const u8) ?[]const u8 {
    const data = refs.headContentsAt(gitdir) orelse return null;
    const t = util.trim(data);
    return util.skipPrefix(t, "ref: ");
}

fn stripSuffix(s: []const u8, suf: []const u8) []const u8 {
    if (util.endsWith(s, suf)) return s[0 .. s.len - suf.len];
    return s;
}

fn worktreePathFor(refname: []const u8) []const u8 {
    if (worktree_map == null) {
        var m: std.StringHashMapUnmanaged([]const u8) = .empty;
        const r = repo_mod.repo();
        const common = r.common_dir;
        var main_path: []const u8 = os.realPath(common) orelse common;
        main_path = stripSuffix(main_path, "/.git");
        main_path = stripSuffix(main_path, "/.");
        if (readHeadSymref(common)) |h| {
            m.put(gpa, h, main_path) catch util.oom();
        }
        const wdir = util.concat(&.{ common, "/worktrees" });
        if (os.listDir(wdir)) |ents| {
            for (ents) |e| {
                const base = util.concat(&.{ wdir, "/", e.name });
                const gd = os.readFile(util.concat(&.{ base, "/gitdir" })) orelse continue;
                var p: []const u8 = util.trimRight(gd);
                p = stripSuffix(p, "/.git");
                if (readHeadSymref(base)) |h| {
                    if (!m.contains(h)) m.put(gpa, h, p) catch util.oom();
                }
            }
        }
        worktree_map = m;
    }
    return worktree_map.?.get(refname) orelse "";
}

// ---------------------------------------------------------------------------
// object data grabbing

const ObjData = struct {
    oid: Oid,
    typ: odb_mod.ObjType = .none,
    content: []const u8 = "",
    size: u64 = 0,
    disk_size: u64 = 0,
    delta_base: Oid = hash.zero,
};

fn packDiskInfo(oid: Oid, d: *ObjData) bool {
    const odb = repo_mod.repo().odb();
    const loc = odb.findPacked(oid) orelse return false;
    const p = loc.pack;
    if (p.pack == null) p.pack = os.readFile(p.pack_path);
    const data = p.pack orelse return false;
    const off = p.offsetAt(loc.idx);
    var next: u64 = if (data.len >= 20) data.len - 20 else data.len;
    var i: u32 = 0;
    while (i < p.num) : (i += 1) {
        const o = p.offsetAt(i);
        if (o > off and o < next) next = o;
    }
    d.disk_size = next - off;
    const hdr = odb_mod.parseEntryHeader(data, @intCast(off)) orelse return true;
    var pos: usize = @as(usize, @intCast(off)) + hdr.hdr_len;
    switch (@intFromEnum(hdr.typ)) {
        6 => {
            const rel = odb_mod.parseOfsDelta(data, &pos);
            const base_off = off - rel;
            var j: u32 = 0;
            while (j < p.num) : (j += 1) {
                if (p.offsetAt(j) == base_off) {
                    d.delta_base = p.oidAt(j);
                    break;
                }
            }
        },
        7 => {
            if (pos + 20 <= data.len) @memcpy(&d.delta_base, data[pos .. pos + 20]);
        },
        else => {},
    }
    return true;
}

fn readObjData(oid: Oid, need: Need, refname: []const u8) ObjData {
    var d = ObjData{ .oid = oid };
    const odb = repo_mod.repo().odb();
    const obj = odb.read(oid) orelse util.die("missing object {s} for {s}", .{ hash.hex(oid), refname });
    d.typ = obj.typ;
    d.content = obj.data;
    d.size = obj.data.len;
    if (need.disk or need.delta) {
        if (!packDiskInfo(oid, &d)) {
            for (odb.allDirs()) |dir| {
                if (os.statPath(odb.looseObjectPath(dir, oid))) |st| {
                    d.disk_size = @intCast(st.size);
                    break;
                }
            }
        }
    }
    return d;
}

fn isDeref(name: []const u8) bool {
    return name.len > 0 and name[0] == '*';
}

fn doGrabOid(oid: Oid, a: *const UsedAtom) []const u8 {
    return switch (a.oid_opt) {
        .full => hash.hexAlloc(oid),
        .length => revparse.abbrev(oid, a.oid_len),
        .short => revparse.abbrev(oid, 0),
    };
}

fn grabCommonValues(val: []AtomValue, deref: bool, d: *const ObjData) void {
    for (used_atom.items, 0..) |*a, i| {
        if (deref != isDeref(a.name)) continue;
        const v = &val[i];
        switch (a.atom_type) {
            .objecttype => v.s = d.typ.name(),
            .objectsize => {
                if (a.objectsize_disk) {
                    v.value = d.disk_size;
                } else v.value = d.size;
                v.s = util.fmt("{d}", .{v.value});
            },
            .deltabase => v.s = hash.hexAlloc(d.delta_base),
            .objectname => if (deref) {
                v.s = doGrabOid(d.oid, a);
            },
            else => {},
        }
    }
}

fn grabTagValues(val: []AtomValue, deref: bool, d: *const ObjData) void {
    var tag: ?objects.Tag = null;
    for (used_atom.items, 0..) |*a, i| {
        if (deref != isDeref(a.name)) continue;
        if (tag == null) tag = objects.parseTag(d.content) orelse util.die("parse_object_buffer failed on {s}", .{hash.hex(d.oid)});
        const v = &val[i];
        switch (a.atom_type) {
            .tag => v.s = tag.?.tag,
            .type => v.s = tag.?.typ.name(),
            .object => v.s = hash.hexAlloc(tag.?.object),
            else => {},
        }
    }
}

fn grabCommitValues(val: []AtomValue, deref: bool, d: *const ObjData) void {
    var commit: ?*cn.Commit = null;
    for (used_atom.items, 0..) |*a, i| {
        if (deref != isDeref(a.name)) continue;
        if (commit == null) {
            commit = cn.lookupCommit(d.oid) orelse util.die("parse_object_buffer failed on {s}", .{hash.hex(d.oid)});
            _ = cn.parse(commit.?);
        }
        const c = commit.?;
        const v = &val[i];
        switch (a.atom_type) {
            .tree => v.s = doGrabOid(c.tree, a),
            .numparent => {
                v.value = cn.listCount(c.parents);
                v.s = util.fmt("{d}", .{v.value});
            },
            .parent => {
                var s: Buf = .empty;
                var p = c.parents;
                var first = true;
                while (p) |n| : (p = n.next) {
                    if (!first) util.bufByte(&s, ' ');
                    first = false;
                    util.bufAppend(&s, doGrabOid(n.item.oid(), a));
                }
                v.s = s.items;
            },
            else => {},
        }
    }
}

/// find_wholine: returns slice starting at the value (rest of buffer), or "".
fn findWholine(who: []const u8, buf: []const u8) []const u8 {
    var pos: usize = 0;
    while (pos < buf.len) {
        const line = buf[pos..];
        if (util.startsWith(line, who) and chAt(line, who.len) == ' ') return line[who.len + 1 ..];
        const nl = std.mem.indexOfScalar(u8, line, '\n') orelse return "";
        pos += nl + 1;
        if (chAt(buf, pos) == '\n') return "";
    }
    return "";
}

fn copyLine(buf: []const u8) []const u8 {
    return buf[0 .. std.mem.indexOfScalar(u8, buf, '\n') orelse buf.len];
}

fn copyName(buf: []const u8) []const u8 {
    var i: usize = 0;
    while (i < buf.len and buf[i] != '\n') : (i += 1) {
        if (util.startsWith(buf[i..], " <")) return buf[0..i];
    }
    return "";
}

fn copyEmail(buf: []const u8, opt: u32) []const u8 {
    var email = buf[std.mem.indexOfScalar(u8, buf, '<') orelse return ""..];
    if (opt & (EO_LOCALPART | EO_TRIM) != 0) email = email[1..];
    var end: usize = undefined;
    if (opt & EO_LOCALPART != 0) {
        end = std.mem.indexOfScalar(u8, email, '@') orelse (std.mem.indexOfScalar(u8, email, '>') orelse return "");
    } else if (opt & EO_TRIM != 0) {
        end = std.mem.indexOfScalar(u8, email, '>') orelse return "";
    } else {
        end = (std.mem.indexOfScalar(u8, email, '>') orelse return "") + 1;
    }
    return email[0..end];
}

fn grabDate(buf: []const u8, v: *AtomValue, atomname: []const u8) void {
    var mode = date_mod.DateMode.of(.normal);
    if (std.mem.indexOfScalar(u8, atomname, ':')) |c| {
        mode = date_mod.parseDateFormatOrDie(atomname[c + 1 ..]);
        used_atom.items[v.atom].typ = .str;
    }
    const eo = std.mem.indexOf(u8, buf, "> ") orelse {
        v.s = "";
        v.value = 0;
        return;
    };
    var p = eo + 2;
    while (p < buf.len and std.ascii.isWhitespace(buf[p])) p += 1;
    const ts_start = p;
    while (p < buf.len and std.ascii.isDigit(buf[p])) p += 1;
    const ts: u64 = std.fmt.parseInt(u64, buf[ts_start..p], 10) catch 0;
    // tz
    while (p < buf.len and (buf[p] == ' ' or buf[p] == '\t')) p += 1;
    var tz: i32 = 0;
    var q = p;
    var neg = false;
    if (q < buf.len and (buf[q] == '+' or buf[q] == '-')) {
        neg = buf[q] == '-';
        q += 1;
    }
    const tzs = q;
    while (q < buf.len and std.ascii.isDigit(buf[q])) q += 1;
    if (q > tzs) {
        const n = std.fmt.parseInt(i64, buf[tzs..q], 10) catch 0;
        tz = @intCast(std.math.clamp(if (neg) -n else n, -100000000, 100000000));
    }
    v.s = date_mod.showDate(@intCast(@min(ts, std.math.maxInt(i64))), tz, mode);
    v.value = ts;
}

fn applyMailmapToHeader(buf: []const u8) []const u8 {
    const m = mailmap_mod.readMailmap();
    var out: Buf = .empty;
    var pos: usize = 0;
    var in_header = true;
    while (pos < buf.len) {
        const nl = std.mem.indexOfScalarPos(u8, buf, pos, '\n');
        const end = if (nl) |n| n + 1 else buf.len;
        const line = buf[pos..end];
        pos = end;
        if (!in_header) {
            util.bufAppend(&out, line);
            continue;
        }
        if (line.len == 1 and line[0] == '\n') {
            in_header = false;
            util.bufAppend(&out, line);
            continue;
        }
        var done = false;
        for ([_][]const u8{ "author ", "committer ", "tagger " }) |hdr| {
            if (!util.startsWith(line, hdr)) continue;
            const id = line[hdr.len..];
            const lt = std.mem.indexOfScalar(u8, id, '<') orelse break;
            const gt = std.mem.indexOfScalarPos(u8, id, lt, '>') orelse break;
            var name = id[0..lt];
            while (name.len > 0 and name[name.len - 1] == ' ') name = name[0 .. name.len - 1];
            const email = id[lt + 1 .. gt];
            if (mailmap_mod.mapUser(m, name, email)) |mp| {
                util.bufAppend(&out, hdr);
                util.bufAppend(&out, mp.name);
                util.bufAppend(&out, " <");
                util.bufAppend(&out, mp.email);
                util.bufAppend(&out, id[gt..]);
                done = true;
            }
            break;
        }
        if (!done) util.bufAppend(&out, line);
    }
    return out.items;
}

fn grabPerson(who: []const u8, val: []AtomValue, deref: bool, buf: []const u8) void {
    var wholine: ?[]const u8 = null;
    for (used_atom.items, 0..) |*a, i| {
        var name = a.name;
        if (deref != isDeref(name)) continue;
        if (deref) name = name[1..];
        if (!util.startsWith(name, who)) continue;
        const rest = name[who.len..];
        if (rest.len != 0 and !util.startsWith(rest, "name") and !util.startsWith(rest, "email") and !util.startsWith(rest, "date")) continue;
        const v = &val[i];
        if ((util.startsWith(rest, "name") and a.name_mailmap) or (util.startsWith(rest, "email") and a.email_opt & EO_MAILMAP != 0)) {
            wholine = findWholine(who, applyMailmapToHeader(buf));
        } else {
            wholine = findWholine(who, buf);
        }
        const wl = wholine.?;
        if (rest.len == 0) {
            v.s = copyLine(wl);
        } else if (util.startsWith(rest, "name")) {
            v.s = copyName(wl);
        } else if (util.startsWith(rest, "email")) {
            v.s = copyEmail(wl, a.email_opt);
        } else if (util.startsWith(rest, "date")) {
            grabDate(wl, v, name);
        }
    }
    if (!util.eql(who, "tagger") and !util.eql(who, "committer")) return;
    const wl = wholine orelse findWholine(who, buf);
    for (used_atom.items, 0..) |*a, i| {
        var name = a.name;
        if (deref != isDeref(name)) continue;
        if (deref) name = name[1..];
        const v = &val[i];
        if (a.atom_type == .creatordate) {
            grabDate(wl, v, name);
        } else if (a.atom_type == .creator) {
            v.s = copyLine(wl);
        }
    }
}

fn isSigStart(line: []const u8) bool {
    return util.startsWith(line, "-----BEGIN PGP SIGNATURE-----") or
        util.startsWith(line, "-----BEGIN PGP MESSAGE-----") or
        util.startsWith(line, "-----BEGIN SIGNED MESSAGE-----") or
        util.startsWith(line, "-----BEGIN SSH SIGNATURE-----");
}

fn parseSignedBuffer(buf: []const u8) usize {
    var len: usize = 0;
    var match: usize = buf.len;
    while (len < buf.len) {
        if (isSigStart(buf[len..])) match = len;
        const nl = std.mem.indexOfScalarPos(u8, buf, len, '\n');
        len = if (nl) |n| n + 1 else buf.len;
    }
    return match;
}

const SubPos = struct {
    sub: []const u8,
    body: []const u8,
    nonsiglen: usize,
    sig: []const u8,
    subpos_to_end: []const u8,
    subpos_to_sig: []const u8,
    subpos_to_nonsig_end: []const u8,
};

fn findSubpos(full: []const u8) SubPos {
    const b0 = cstr(full);
    var p: usize = 0;
    while (p < b0.len and b0[p] != '\n') {
        const nl = std.mem.indexOfScalarPos(u8, b0, p, '\n');
        p = if (nl) |n| n + 1 else b0.len;
    }
    while (p < b0.len and b0[p] == '\n') p += 1;
    const buf = b0[p..];
    const sigstart = parseSignedBuffer(buf);
    var eol: usize = sigstart;
    if (std.mem.indexOf(u8, buf, "\n\n") orelse std.mem.indexOf(u8, buf, "\r\n\r\n")) |e| {
        eol = @min(e, sigstart);
    }
    var sublen = eol;
    while (sublen > 0 and (buf[sublen - 1] == '\n' or buf[sublen - 1] == '\r')) sublen -= 1;
    var bp = eol;
    while (bp < buf.len and (buf[bp] == '\n' or buf[bp] == '\r')) bp += 1;
    // nonsiglen = sigstart - bodypos (may be "negative" in theory; clamp)
    const nonsig: usize = if (sigstart >= bp) sigstart - bp else 0;
    return .{
        .sub = buf[0..sublen],
        .body = buf[bp..],
        .nonsiglen = nonsig,
        .sig = buf[sigstart..],
        .subpos_to_end = buf,
        .subpos_to_sig = buf[0..sigstart],
        .subpos_to_nonsig_end = buf[0 .. bp + nonsig],
    };
}

fn copySubject(s: []const u8) []const u8 {
    var out: Buf = .empty;
    var i: usize = 0;
    while (i < s.len) : (i += 1) {
        if (s[i] == '\r' and i + 1 < s.len and s[i + 1] == '\n') continue;
        util.bufByte(&out, if (s[i] == '\n') ' ' else s[i]);
    }
    return out.items;
}

fn appendLines(out: *Buf, buf: []const u8, lines: usize) void {
    var sp: usize = 0;
    var i: usize = 0;
    while (i < lines and sp < buf.len) : (i += 1) {
        if (i > 0) util.bufAppend(out, "\n    ");
        const nl = std.mem.indexOfScalarPos(u8, buf, sp, '\n');
        const end = nl orelse buf.len;
        util.bufAppend(out, buf[sp..end]);
        if (nl == null) break;
        sp = end + 1;
    }
}

fn grabSubBodyContents(val: []AtomValue, deref: bool, d: *const ObjData) void {
    var sp: ?SubPos = null;
    for (used_atom.items, 0..) |*a, i| {
        var name = a.name;
        if (deref != isDeref(name)) continue;
        if (deref) name = name[1..];
        const v = &val[i];
        if (a.atom_type == .raw) {
            if (a.raw_length) {
                v.value = d.size;
                v.s = util.fmt("{d}", .{v.value});
            } else {
                v.s = d.content;
                v.s_size = d.content.len;
            }
            continue;
        }
        if ((d.typ != .tag and d.typ != .commit) or
            (!util.eql(name, "body") and !util.startsWith(name, "subject") and !util.startsWith(name, "trailers") and !util.startsWith(name, "contents")))
            continue;
        if (sp == null) sp = findSubpos(d.content);
        const s = sp.?;
        switch (a.contents) {
            .sub => v.s = copySubject(s.sub),
            .sub_sanitize => {
                var sb: Buf = .empty;
                pretty.formatSanitizedSubject(&sb, s.sub);
                v.s = sb.items;
            },
            .body_dep => v.s = s.body,
            .length => {
                v.value = s.subpos_to_end.len;
                v.s = util.fmt("{d}", .{v.value});
            },
            .body => v.s = s.body[0..@min(s.nonsiglen, s.body.len)],
            .signature => v.s = s.sig,
            .lines => {
                var out: Buf = .empty;
                appendLines(&out, s.subpos_to_nonsig_end, a.nlines);
                v.s = out.items;
            },
            .trailers => {
                var out: Buf = .empty;
                const msg = if (s.sig.len > 0) s.subpos_to_sig else s.subpos_to_end;
                trailer_mod.formatTrailersFromCommit(&a.trailer_opts, msg, &out);
                v.s = out.items;
            },
            .bare => v.s = s.subpos_to_end,
        }
    }
}

fn grabSignature(val: []AtomValue, deref: bool, d: *const ObjData) void {
    const gpg = @import("gpg.zig");
    var sigc: gpg.SigCheck = .{};
    var checked = false;
    for (used_atom.items, 0..) |*a, i| {
        var name = a.name;
        if (deref != isDeref(name)) continue;
        if (deref) name = name[1..];
        const rest = util.skipPrefix(name, "signature") orelse continue;
        if (rest.len > 0 and rest[0] != ':') continue;
        const v = &val[i];
        if (!checked) {
            _ = gpg.verifyCommitBuffer(d.content, &sigc);
            checked = true;
        }
        v.s = switch (a.sig_opt) {
            .bare => sigc.output orelse "",
            .signer => sigc.signer orelse "",
            .grade => switch (sigc.result) {
                'G' => if (sigc.trust_level == .undefined or sigc.trust_level == .never) "U" else "G",
                'B' => "B",
                'E' => "E",
                'N' => "N",
                'X' => "X",
                'Y' => "Y",
                'R' => "R",
                else => "",
            },
            .key => sigc.key orelse "",
            .fingerprint => sigc.fingerprint orelse "",
            .primarykeyfingerprint => sigc.primary_key_fingerprint orelse "",
            .trustlevel => gpg.trustLevelStr(sigc.trust_level),
        };
    }
}

fn grabDescribeValues(val: []AtomValue, deref: bool, d: *const ObjData) void {
    for (used_atom.items, 0..) |*a, i| {
        if (deref != isDeref(a.name)) continue;
        if (a.atom_type != .describe) continue;
        var argv: std.ArrayList([]const u8) = .empty;
        argv.appendSlice(gpa, &.{ os.readLink("/proc/self/exe") orelse "git", "describe" }) catch util.oom();
        argv.appendSlice(gpa, a.describe_args.items) catch util.oom();
        argv.append(gpa, hash.hexAlloc(d.oid)) catch util.oom();
        util.flushStdout();
        const r = os.run(argv.items, .{ .capture_stdout = true, .no_stdin = true, .no_stderr = true });
        val[i].s = util.trimRight(r.stdout);
    }
}

fn grabValues(val: []AtomValue, deref: bool, d: *const ObjData) void {
    switch (d.typ) {
        .tag => {
            grabTagValues(val, deref, d);
            grabSubBodyContents(val, deref, d);
            grabPerson("tagger", val, deref, d.content);
            grabDescribeValues(val, deref, d);
        },
        .commit => {
            grabCommitValues(val, deref, d);
            grabSubBodyContents(val, deref, d);
            grabPerson("author", val, deref, d.content);
            grabPerson("committer", val, deref, d.content);
            grabSignature(val, deref, d);
            grabDescribeValues(val, deref, d);
        },
        .tree, .blob => grabSubBodyContents(val, deref, d),
        else => util.die("Eh?  Object of type {d}?", .{@intFromEnum(d.typ)}),
    }
}

fn getObject(ref: *Item, deref: bool, oid: Oid, need: Need) ObjData {
    const d = readObjData(oid, need, ref.refname);
    if (need.content) grabValues(ref.value.?, deref, &d);
    grabCommonValues(ref.value.?, deref, &d);
    return d;
}

fn populateValue(ref: *Item) void {
    const n = used_atom.items.len;
    const vals = gpa.alloc(AtomValue, n) catch util.oom();
    for (vals) |*v| v.* = .{};
    ref.value = vals;

    if (need_symref and ref.flag & refs.REF_ISSYMREF != 0 and ref.symref == null) {
        const r = refs.resolveFull(ref.refname, true);
        ref.symref = if (r.missing or r.broken) "" else r.name;
    }

    var ahead_behind_atoms: usize = 0;
    var is_base_atoms: usize = 0;
    for (used_atom.items, 0..) |*a, i| {
        var name = a.name;
        const v = &vals[i];
        v.atom = i;
        var deref = false;
        if (isDeref(name)) {
            deref = true;
            name = name[1..];
        }
        var refname: []const u8 = undefined;
        switch (a.atom_type) {
            .refname => {
                refname = if (ref.kind & FILTER_REFS_DETACHED_HEAD != 0) getHeadDescription() else showRef(&a.refname, ref.refname);
            },
            .worktreepath => {
                v.s = if (ref.kind == FILTER_REFS_BRANCHES) worktreePathFor(ref.refname) else "";
                continue;
            },
            .symref => {
                refname = if (ref.symref) |s| showRef(&a.refname, s) else "";
            },
            .upstream => {
                const bn = util.skipPrefix(ref.refname, "refs/heads/") orelse {
                    v.s = "";
                    continue;
                };
                const b = branchGet(bn);
                if (branchGetUpstream(b, null)) |up| {
                    v.s = fillRemoteRefDetails(a, up, b);
                } else v.s = "";
                continue;
            },
            .push => {
                if (!a.rr.push) continue;
                v.s = "";
                const bn = util.skipPrefix(ref.refname, "refs/heads/") orelse continue;
                const b = branchGet(bn);
                var rn: ?[]const u8 = null;
                if (!a.rr.push_remote) {
                    rn = branchGetPush(b, null) orelse continue;
                }
                v.s = fillRemoteRefDetails(a, rn, b);
                continue;
            },
            .color => {
                v.s = a.color;
                continue;
            },
            .flag => {
                var b: Buf = .empty;
                if (ref.flag & refs.REF_ISSYMREF != 0) util.bufAppend(&b, ",symref");
                if (ref.flag & refs.REF_ISPACKED != 0) util.bufAppend(&b, ",packed");
                v.s = if (b.items.len == 0) "" else b.items[1..];
                continue;
            },
            .objectname => {
                if (!deref and util.startsWith(name, "objectname")) {
                    v.s = doGrabOid(ref.objectname, a);
                }
                continue;
            },
            .head => {
                v.s = if (a.head != null and util.eql(ref.refname, a.head.?)) "*" else " ";
                continue;
            },
            .@"align" => {
                v.handler = .@"align";
                v.s = "";
                continue;
            },
            .end => {
                v.handler = .end;
                v.s = "";
                continue;
            },
            .@"if" => {
                v.s = util.skipPrefix(name, "if:") orelse "";
                v.handler = .@"if";
                continue;
            },
            .then => {
                v.handler = .then;
                v.s = "";
                continue;
            },
            .@"else" => {
                v.handler = .@"else";
                v.s = "";
                continue;
            },
            .rest => {
                v.s = ref.rest orelse "";
                continue;
            },
            .ahead_behind => {
                if (ref.counts) |c| {
                    const cnt = c[ahead_behind_atoms];
                    ahead_behind_atoms += 1;
                    v.s = util.fmt("{d} {d}", .{ cnt.ahead, cnt.behind });
                } else v.s = "";
                continue;
            },
            .is_base => {
                if (ref.is_base) |ib| {
                    if (is_base_atoms < ib.len and ib[is_base_atoms] != null) {
                        v.s = util.fmt("({s})", .{ib[is_base_atoms].?});
                    } else v.s = "";
                } else v.s = "";
                is_base_atoms += 1;
                continue;
            },
            else => continue,
        }
        v.s = if (!deref) refname else util.fmt("{s}^{{}}", .{refname});
    }

    for (used_atom.items, 0..) |a, i| {
        if (vals[i].s == null and a.source == .none)
            util.die("missing object {s} for {s}", .{ hash.hex(ref.objectname), ref.refname });
    }

    var need = oi_need;
    if (need_tagged) need.content = true;
    if (!need.any() and !oi_deref_need.any()) return;

    const d = getObject(ref, false, ref.objectname, need);
    if (!need_tagged or d.typ != .tag) return;
    var deref_oid: Oid = undefined;
    if (ref.peeled) |p| {
        deref_oid = p;
    } else if (objects.peel(ref.objectname)) |p| {
        deref_oid = p.oid;
    } else util.die("bad tag", .{});
    _ = getObject(ref, true, deref_oid, oi_deref_need);
}

fn getRefAtomValue(ref: *Item, atom: usize) *AtomValue {
    if (ref.value == null or ref.value.?.len < used_atom.items.len) {
        populateValue(ref);
        for (ref.value.?) |*v| {
            if (v.s == null) v.s = "";
        }
    }
    return &ref.value.?[atom];
}

// ---------------------------------------------------------------------------
// formatting

const AtEnd = enum { none, @"align", ite };

const Ite = struct {
    cmp: CmpStatus = .none,
    str: ?[]const u8 = null,
    then_seen: bool = false,
    else_seen: bool = false,
    satisfied: bool = false,
};

const StackElem = struct {
    output: Buf = .empty,
    at_end: AtEnd = .none,
    al: Align = .{},
    ite: ?*Ite = null,
};

const FmtState = struct {
    stack: std.ArrayList(*StackElem) = .empty,
    quote_style: i32 = 0,

    fn top(s: *FmtState) *StackElem {
        return s.stack.items[s.stack.items.len - 1];
    }
    fn push(s: *FmtState) *StackElem {
        const e = gpa.create(StackElem) catch util.oom();
        e.* = .{};
        s.stack.append(gpa, e) catch util.oom();
        return e;
    }
    fn pop(s: *FmtState) void {
        const cur = s.stack.pop().?;
        if (s.stack.items.len > 0) util.bufAppend(&s.top().output, cur.output.items);
    }
};

fn sqQuoteC(b: *Buf, s: []const u8) void {
    util.sqQuote(b, cstr(s));
}

fn quoteFormatting(b: *Buf, s: []const u8, raw_len: ?usize, style: i32) void {
    switch (style) {
        QUOTE_SHELL => sqQuoteC(b, s),
        QUOTE_PERL => {
            const src = if (raw_len != null) s else cstr(s);
            util.bufByte(b, '\'');
            for (src) |c| {
                if (c == '\'' or c == '\\') util.bufByte(b, '\\');
                util.bufByte(b, c);
            }
            util.bufByte(b, '\'');
        },
        QUOTE_PYTHON => {
            util.bufByte(b, '\'');
            for (cstr(s)) |c| {
                if (c == '\n') {
                    util.bufAppend(b, "\\n");
                    continue;
                }
                if (c == '\'' or c == '\\') util.bufByte(b, '\\');
                util.bufByte(b, c);
            }
            util.bufByte(b, '\'');
        },
        QUOTE_TCL => {
            util.bufByte(b, '"');
            for (cstr(s)) |c| {
                switch (c) {
                    '[', ']', '{', '}', '$', '\\', '"' => {
                        util.bufByte(b, '\\');
                        util.bufByte(b, c);
                    },
                    0x0c => util.bufAppend(b, "\\f"),
                    '\r' => util.bufAppend(b, "\\r"),
                    '\n' => util.bufAppend(b, "\\n"),
                    '\t' => util.bufAppend(b, "\\t"),
                    0x0b => util.bufAppend(b, "\\v"),
                    else => util.bufByte(b, c),
                }
            }
            util.bufByte(b, '"');
        },
        else => {
            if (raw_len != null) util.bufAppend(b, s) else util.bufAppend(b, cstr(s));
        },
    }
}

fn appendAtom(v: *const AtomValue, st: *FmtState) void {
    const s = v.s orelse "";
    if (st.stack.items.len == 1) {
        quoteFormatting(&st.top().output, s, v.s_size, st.quote_style);
    } else if (v.s_size == null) {
        util.bufAppend(&st.top().output, cstr(s));
    } else util.bufAppend(&st.top().output, s);
}

fn utf8Align(out: *Buf, pos: AlignPos, width: usize, s: []const u8) void {
    const dw_i = pretty.utf8Strnwidth(s, true);
    const display: usize = if (dw_i < 0) s.len else @intCast(dw_i);
    if (width <= display) {
        util.bufAppend(out, s);
        return;
    }
    const pad = width - display;
    switch (pos) {
        .left => {
            util.bufAppend(out, s);
            out.appendNTimes(gpa, ' ', pad) catch util.oom();
        },
        .middle => {
            const left = pad / 2;
            out.appendNTimes(gpa, ' ', left) catch util.oom();
            util.bufAppend(out, s);
            out.appendNTimes(gpa, ' ', pad - left) catch util.oom();
        },
        .right => {
            out.appendNTimes(gpa, ' ', pad) catch util.oom();
            util.bufAppend(out, s);
        },
    }
}

fn isEmptyOutput(b: []const u8) bool {
    for (b) |c| {
        if (!std.ascii.isWhitespace(c)) return false;
    }
    return true;
}

fn runAtEnd(st: *FmtState) void {
    const cur = st.top();
    switch (cur.at_end) {
        .none => {},
        .@"align" => {
            var s: Buf = .empty;
            utf8Align(&s, cur.al.position, cur.al.width, cur.output.items);
            cur.output = s;
        },
        .ite => {
            const ite = cur.ite.?;
            if (!ite.then_seen) util.die("format: %(if) atom used without a %(then) atom", .{});
            if (ite.else_seen) {
                const prev = st.stack.items[st.stack.items.len - 2];
                if (ite.satisfied) {
                    cur.output.clearRetainingCapacity();
                    st.pop();
                } else {
                    const tmp = cur.output;
                    cur.output = prev.output;
                    prev.output = tmp;
                    cur.output.clearRetainingCapacity();
                    st.pop();
                }
            } else if (!ite.satisfied) {
                cur.output.clearRetainingCapacity();
            }
        },
    }
}

fn handleAtom(v: *const AtomValue, st: *FmtState, e: *ParseErr) bool {
    switch (v.handler) {
        .append => appendAtom(v, st),
        .@"align" => {
            const ne = st.push();
            ne.at_end = .@"align";
            ne.al = used_atom.items[v.atom].@"align";
        },
        .@"if" => {
            const ite = gpa.create(Ite) catch util.oom();
            const a = &used_atom.items[v.atom];
            ite.* = .{ .cmp = a.if_cmp, .str = a.if_str };
            const ne = st.push();
            ne.at_end = .ite;
            ne.ite = ite;
        },
        .then => {
            const cur = st.top();
            const ite = (if (cur.at_end == .ite) cur.ite else null) orelse {
                e.msg = "format: %(then) atom used without a %(if) atom";
                return false;
            };
            if (ite.then_seen) {
                e.msg = "format: %(then) atom used more than once";
                return false;
            }
            if (ite.else_seen) {
                e.msg = "format: %(then) atom used after %(else)";
                return false;
            }
            ite.then_seen = true;
            const out = cur.output.items;
            switch (ite.cmp) {
                .equal => {
                    if (util.eql(ite.str orelse "", out)) ite.satisfied = true;
                },
                .unequal => {
                    if (!util.eql(ite.str orelse "", out)) ite.satisfied = true;
                },
                .none => {
                    if (out.len > 0 and !isEmptyOutput(out)) ite.satisfied = true;
                },
            }
            cur.output.clearRetainingCapacity();
        },
        .@"else" => {
            const prev = st.top();
            const ite = (if (prev.at_end == .ite) prev.ite else null) orelse {
                e.msg = "format: %(else) atom used without a %(if) atom";
                return false;
            };
            if (!ite.then_seen) {
                e.msg = "format: %(else) atom used without a %(then) atom";
                return false;
            }
            if (ite.else_seen) {
                e.msg = "format: %(else) atom used more than once";
                return false;
            }
            ite.else_seen = true;
            const ne = st.push();
            ne.at_end = prev.at_end;
            ne.ite = prev.ite;
        },
        .end => {
            if (st.top().at_end == .none) {
                e.msg = "format: %(end) atom used without corresponding atom";
                return false;
            }
            runAtEnd(st);
            const cur = st.top();
            if (st.stack.items.len == 2) {
                var s: Buf = .empty;
                quoteFormatting(&s, cur.output.items, cur.output.items.len, st.quote_style);
                cur.output = s;
            }
            st.pop();
        },
    }
    return true;
}

fn hexVal(c: u8) ?u8 {
    return std.fmt.charToDigit(c, 16) catch null;
}

fn appendLiteral(s: []const u8, st: *FmtState) void {
    const out = &st.top().output;
    var i: usize = 0;
    while (i < s.len and s[i] != 0) {
        if (s[i] == '%') {
            if (chAt(s, i + 1) == '%') {
                i += 1;
            } else if (hexVal(chAt(s, i + 1))) |h| {
                if (hexVal(chAt(s, i + 2))) |l| {
                    util.bufByte(out, h * 16 + l);
                    i += 3;
                    continue;
                }
            }
        }
        util.bufByte(out, s[i]);
        i += 1;
    }
}

/// format_ref_array_item. Returns false with errmsg on error.
pub fn formatItemErr(info: *Item, format: *const Format, final: *Buf, errmsg: *[]const u8) bool {
    var st = FmtState{ .quote_style = format.quote_style };
    _ = st.push();
    const f = format.format;
    var cp: usize = 0;
    while (cp < f.len) {
        const sp = findNext(f, cp) orelse break;
        const ep = std.mem.indexOfScalarPos(u8, f, sp, ')') orelse break;
        if (cp < sp) appendLiteral(f[cp..sp], &st);
        var e = ParseErr{};
        const pos = parseRefFilterAtom(format, f[sp + 2 .. ep], &e) orelse {
            errmsg.* = e.msg;
            return false;
        };
        const v = getRefAtomValue(info, pos);
        if (!handleAtom(v, &st, &e)) {
            errmsg.* = e.msg;
            return false;
        }
        cp = ep + 1;
    }
    if (cp < f.len) appendLiteral(f[cp..], &st);
    if (format.need_color_reset_at_eol) {
        const rv = AtomValue{ .s = color_mod.RESET };
        appendAtom(&rv, &st);
    }
    if (st.stack.items.len > 1) {
        errmsg.* = "format: %(end) atom missing";
        return false;
    }
    util.bufAppend(final, st.top().output.items);
    return true;
}

pub fn formatItem(info: *Item, format: *const Format, final: *Buf) void {
    var msg: []const u8 = "";
    if (!formatItemErr(info, format, final, &msg)) util.die("{s}", .{msg});
}

pub fn printFormattedArray(items: []*Item, format: *const Format) void {
    var total: usize = items.len;
    if (format.max_count > 0 and @as(usize, @intCast(format.max_count)) < total) total = @intCast(format.max_count);
    var out: Buf = .empty;
    for (items[0..total]) |it| {
        out.clearRetainingCapacity();
        formatItem(it, format, &out);
        if (out.items.len > 0 or !format.omit_empty) {
            util.out(out.items);
            util.out("\n");
        }
    }
}

/// pretty_print_ref
pub fn prettyPrintRef(name: []const u8, oid: Oid, peeled: ?Oid, format: *const Format) void {
    const it = newItem(name, oid);
    it.peeled = peeled;
    it.kind = refKindFromRefname(name);
    var out: Buf = .empty;
    formatItem(it, format, &out);
    util.out(out.items);
    util.out("\n");
}

// ---------------------------------------------------------------------------
// sorting

pub fn parseSortingAtom(atom: []const u8) usize {
    const dummy = Format{};
    var e = ParseErr{};
    return parseRefFilterAtom(&dummy, atom, &e) orelse util.die("{s}", .{e.msg});
}

/// ref_sorting_options: the last option becomes the primary key.
pub fn sortingOptions(options: []const []const u8) ?*Sorting {
    var head: ?*Sorting = null;
    for (options) |opt| {
        const s = gpa.create(Sorting) catch util.oom();
        s.* = .{ .next = head };
        head = s;
        var arg = opt;
        if (arg.len > 0 and arg[0] == '-') {
            s.flags |= SORT_REVERSE;
            arg = arg[1..];
        }
        if (util.skipPrefix(arg, "version:") orelse util.skipPrefix(arg, "v:")) |r| {
            s.flags |= SORT_VERSION;
            arg = r;
        }
        s.atom = parseSortingAtom(arg);
    }
    return head;
}

pub fn setSortFlagsAll(sorting: ?*Sorting, mask: u32, on: bool) void {
    var s = sorting;
    while (s) |x| : (s = x.next) {
        if (on) x.flags |= mask else x.flags &= ~mask;
    }
}

fn strcasecmpZ(a: []const u8, b: []const u8) i32 {
    const n = @min(a.len, b.len);
    var i: usize = 0;
    while (i < n) : (i += 1) {
        const ca = std.ascii.toLower(a[i]);
        const cb = std.ascii.toLower(b[i]);
        if (ca != cb) return @as(i32, ca) - @as(i32, cb);
    }
    if (a.len == b.len) return 0;
    return if (a.len < b.len) -1 else 1;
}

fn strcmpZ(a: []const u8, b: []const u8) i32 {
    return switch (std.mem.order(u8, a, b)) {
        .lt => -1,
        .eq => 0,
        .gt => 1,
    };
}

fn cmpRefSorting(s: *const Sorting, a: *Item, b: *Item) i32 {
    const va = getRefAtomValue(a, s.atom);
    const vb = getRefAtomValue(b, s.atom);
    const cmp_type = used_atom.items[s.atom].typ;
    var cmp: i32 = 0;
    var detached_cmp = false;
    if (s.flags & SORT_DETACHED_HEAD_FIRST != 0 and ((a.kind | b.kind) & FILTER_REFS_DETACHED_HEAD) != 0) {
        if (a.kind & FILTER_REFS_DETACHED_HEAD != 0) cmp = -1 else if (b.kind & FILTER_REFS_DETACHED_HEAD != 0) cmp = 1;
        detached_cmp = true;
    } else if (s.flags & SORT_VERSION != 0) {
        cmp = versioncmp(cstr(va.s.?), cstr(vb.s.?));
    } else if (cmp_type == .str) {
        const sa = if (va.s_size == null) cstr(va.s.?) else va.s.?;
        const sb = if (vb.s_size == null) cstr(vb.s.?) else vb.s.?;
        cmp = if (s.flags & SORT_ICASE != 0) strcasecmpZ(sa, sb) else strcmpZ(sa, sb);
    } else {
        cmp = if (va.value < vb.value) -1 else if (va.value == vb.value) 0 else 1;
    }
    return if (s.flags & SORT_REVERSE != 0 and !detached_cmp) -cmp else cmp;
}

fn compareRefs(sorting: ?*Sorting, a: *Item, b: *Item) i32 {
    var s = sorting;
    while (s) |x| : (s = x.next) {
        const c = cmpRefSorting(x, a, b);
        if (c != 0) return c;
    }
    if (sorting != null and sorting.?.flags & SORT_ICASE != 0) return strcasecmpZ(a.refname, b.refname);
    return strcmpZ(a.refname, b.refname);
}

pub fn sortItems(sorting: ?*Sorting, items: []*Item) void {
    // populate all values first (sorting may change atom types, e.g. dates with formats)
    if (sorting != null) {
        for (items) |it| _ = getRefAtomValue(it, sorting.?.atom);
    }
    std.sort.insertion(*Item, items, sorting, struct {
        fn lt(ctx: ?*Sorting, a: *Item, b: *Item) bool {
            return compareRefs(ctx, a, b) < 0;
        }
    }.lt);
}

// ---------------------------------------------------------------------------
// versioncmp

var prereleases: ?[]const []const u8 = null;
var vc_initialized = false;

const S_N: u8 = 0x0;
const S_I: u8 = 0x3;
const S_F: u8 = 0x6;
const S_Z: u8 = 0x9;
const VC_CMP: i8 = 2;
const VC_LEN: i8 = 3;

const SuffixMatch = struct { conf_pos: i64, start: i64, len: i64 };

fn findBetterMatchingSuffix(tagname: []const u8, suffix: []const u8, start: i64, conf_pos: i64, m: *SuffixMatch) void {
    const suffix_len: i64 = @intCast(suffix.len);
    const end = if (m.len < suffix_len) m.start else m.start - 1;
    var i = start;
    while (i <= end) : (i += 1) {
        const ui: usize = @intCast(i);
        if (ui <= tagname.len and util.startsWith(tagname[ui..], suffix)) {
            m.conf_pos = conf_pos;
            m.start = i;
            m.len = suffix_len;
            break;
        }
    }
}

fn swapPrereleases(s1: []const u8, s2: []const u8, off: i64, diff: *i32) bool {
    var m1 = SuffixMatch{ .conf_pos = -1, .start = off, .len = -1 };
    var m2 = SuffixMatch{ .conf_pos = -1, .start = off, .len = -1 };
    for (prereleases.?, 0..) |suffix, i| {
        const sl: i64 = @intCast(suffix.len);
        const start: i64 = if (sl < off) off - sl else 0;
        findBetterMatchingSuffix(s1, suffix, start, @intCast(i), &m1);
        findBetterMatchingSuffix(s2, suffix, start, @intCast(i), &m2);
    }
    if (m1.conf_pos == -1 and m2.conf_pos == -1) return false;
    if (m1.conf_pos == m2.conf_pos) return false;
    if (m1.conf_pos >= 0 and m2.conf_pos >= 0) {
        diff.* = @intCast(m1.conf_pos - m2.conf_pos);
    } else if (m1.conf_pos >= 0) {
        diff.* = -1;
    } else diff.* = 1;
    return true;
}

fn digitClass(c: u8) u8 {
    return @as(u8, @intFromBool(c == '0')) + @as(u8, @intFromBool(std.ascii.isDigit(c)));
}

/// versioncmp() from versioncmp.c
pub fn versioncmp(s1: []const u8, s2: []const u8) i32 {
    const next_state = [_]u8{
        S_N, S_I, S_Z,
        S_N, S_I, S_I,
        S_N, S_F, S_F,
        S_N, S_F, S_Z,
    };
    const result_type = [_]i8{
        VC_CMP, VC_CMP, VC_CMP, VC_CMP, VC_LEN, VC_CMP, VC_CMP, VC_CMP, VC_CMP,
        VC_CMP, -1,     -1,     1,      VC_LEN, VC_LEN, 1,      VC_LEN, VC_LEN,
        VC_CMP, VC_CMP, VC_CMP, VC_CMP, VC_CMP, VC_CMP, VC_CMP, VC_CMP, VC_CMP,
        VC_CMP, 1,      1,      -1,     VC_CMP, VC_CMP, -1,     VC_CMP, VC_CMP,
    };
    var p1: usize = 0;
    var p2: usize = 0;
    var c1 = chAt(s1, p1);
    p1 += 1;
    var c2 = chAt(s2, p2);
    p2 += 1;
    var state: u8 = S_N + digitClass(c1);
    var diff: i32 = @as(i32, c1) - @as(i32, c2);
    while (diff == 0) {
        if (c1 == 0) return 0;
        state = next_state[state];
        c1 = chAt(s1, p1);
        p1 += 1;
        c2 = chAt(s2, p2);
        p2 += 1;
        state += digitClass(c1);
        diff = @as(i32, c1) - @as(i32, c2);
    }
    if (!vc_initialized) {
        const newl = repo_mod.cfg.getAll("versionsort.suffix");
        const oldl = repo_mod.cfg.getAll("versionsort.prereleasesuffix");
        if (newl.len > 0 and oldl.len > 0)
            util.warn("ignoring versionsort.prereleasesuffix because versionsort.suffix is set", .{});
        if (newl.len > 0) {
            prereleases = newl;
        } else if (oldl.len > 0) prereleases = oldl;
        vc_initialized = true;
    }
    if (prereleases != null) {
        var d: i32 = diff;
        if (swapPrereleases(s1, s2, @as(i64, @intCast(p1)) - 1, &d)) return d;
    }
    const rt = result_type[@as(usize, state) * 3 + digitClass(c2)];
    switch (rt) {
        VC_CMP => return diff,
        VC_LEN => {
            while (true) {
                const a = chAt(s1, p1);
                p1 += 1;
                if (!std.ascii.isDigit(a)) break;
                const b = chAt(s2, p2);
                p2 += 1;
                if (!std.ascii.isDigit(b)) return 1;
            }
            return if (std.ascii.isDigit(chAt(s2, p2))) -1 else diff;
        },
        else => return rt,
    }
}

// ---------------------------------------------------------------------------
// filtering

pub fn refKindFromRefname(refname: []const u8) u32 {
    if (util.eql(refname, "HEAD")) return FILTER_REFS_DETACHED_HEAD;
    if (util.startsWith(refname, "refs/heads/")) return FILTER_REFS_BRANCHES;
    if (util.startsWith(refname, "refs/remotes/")) return FILTER_REFS_REMOTES;
    if (util.startsWith(refname, "refs/tags/")) return FILTER_REFS_TAGS;
    if (refs.isPseudoRef(refname)) return FILTER_REFS_PSEUDOREFS;
    if (refs.isRootRef(refname)) return FILTER_REFS_ROOT_REFS;
    return FILTER_REFS_OTHERS;
}

fn filterRefKind(filter: *const Filter, refname: []const u8) u32 {
    if (filter.kind == FILTER_REFS_BRANCHES or filter.kind == FILTER_REFS_REMOTES or filter.kind == FILTER_REFS_TAGS)
        return filter.kind;
    return refKindFromRefname(refname);
}

fn matchPattern(patterns: []const []const u8, refname0: []const u8, icase: bool) bool {
    const flags: u32 = if (icase) wildmatch.CASEFOLD else 0;
    const refname = util.skipPrefix(refname0, "refs/tags/") orelse util.skipPrefix(refname0, "refs/heads/") orelse
        util.skipPrefix(refname0, "refs/remotes/") orelse util.skipPrefix(refname0, "refs/") orelse refname0;
    for (patterns) |p| {
        if (wildmatch.match(p, refname, flags)) return true;
    }
    return false;
}

fn matchNameAsPath(patterns: []const []const u8, refname: []const u8, icase: bool) bool {
    var flags: u32 = wildmatch.PATHNAME;
    if (icase) flags |= wildmatch.CASEFOLD;
    for (patterns) |p| {
        if (p.len <= refname.len and util.startsWith(refname, p) and
            (refname.len == p.len or refname[p.len] == '/' or (p.len > 0 and p[p.len - 1] == '/')))
            return true;
        if (wildmatch.match(p, refname, flags)) return true;
    }
    return false;
}

fn filterPatternMatch(filter: *const Filter, refname: []const u8) bool {
    if (filter.name_patterns.len == 0) return true;
    if (filter.match_as_path) return matchNameAsPath(filter.name_patterns, refname, filter.ignore_case);
    return matchPattern(filter.name_patterns, refname, filter.ignore_case);
}

fn filterExcludeMatch(filter: *const Filter, refname: []const u8) bool {
    if (filter.exclude.items.len == 0) return false;
    if (filter.match_as_path) return matchNameAsPath(filter.exclude.items, refname, filter.ignore_case);
    return matchPattern(filter.exclude.items, refname, filter.ignore_case);
}

fn oidInList(l: []const Oid, o: Oid) bool {
    for (l) |x| {
        if (hash.eql(x, o)) return true;
    }
    return false;
}

fn matchPointsAt(points_at: []const Oid, oid: Oid, refname: []const u8) bool {
    if (oidInList(points_at, oid)) return true;
    const odb = repo_mod.repo().odb();
    var cur = oid;
    var obj = odb.read(cur);
    while (obj != null and obj.?.typ == .tag) {
        const t = objects.parseTag(obj.?.data) orelse {
            obj = null;
            break;
        };
        if (oidInList(points_at, t.object)) return true;
        cur = t.object;
        obj = odb.read(cur);
    }
    if (obj == null) util.die("malformed object at '{s}'", .{refname});
    return false;
}

fn shortUpstreamName(full: []const u8) []const u8 {
    return util.skipPrefix(full, "refs/heads/") orelse util.skipPrefix(full, "refs/remotes/") orelse full;
}

fn filterForkedMatch(filter: *const Filter, refname: []const u8) bool {
    const short = util.skipPrefix(refname, "refs/heads/") orelse return false;
    const b = branchGet(short);
    const up = branchGetUpstream(b, null) orelse return false;
    for (filter.forked.items) |p| {
        if (wildmatch.hasGlobChars(p)) {
            if (wildmatch.match(p, shortUpstreamName(up), wildmatch.PATHNAME)) return true;
        } else if (util.eql(p, up)) return true;
    }
    return false;
}

/// ref_filter_forked_add: false on failure.
pub fn forkedAdd(filter: *Filter, arg: []const u8) bool {
    if (wildmatch.hasGlobChars(arg)) {
        filter.forked.append(gpa, arg) catch util.oom();
        return true;
    }
    if (refs.dwimRef(arg)) |d| {
        if (d.count == 1 and (util.startsWith(d.name, "refs/heads/") or util.startsWith(d.name, "refs/remotes/"))) {
            filter.forked.append(gpa, d.name) catch util.oom();
            return true;
        }
    }
    return false;
}

fn commitContains(filter: *Filter, commit: *cn.Commit, list: ?*cn.CommitList, cache: *reach.ContainsCache) bool {
    return reach.commitContains(commit, list, cache, filter.with_commit_tag_algo);
}

const RawRef = struct {
    name: []const u8,
    oid: Oid,
    peeled: ?Oid = null,
    flags: u32 = 0,
    target: ?[]const u8 = null,
};

fn applyRefFilter(r: RawRef, filter: *Filter) ?*Item {
    if (r.flags & refs.REF_BAD_NAME != 0) {
        util.warn("ignoring ref with broken name {s}", .{r.name});
        return null;
    }
    if (r.flags & refs.REF_ISBROKEN != 0) {
        util.warn("ignoring broken ref {s}", .{r.name});
        return null;
    }
    var kind = filterRefKind(filter, r.name);
    if (filter.kind & FILTER_REFS_ROOT_REFS != 0 and kind == FILTER_REFS_DETACHED_HEAD) {
        kind = FILTER_REFS_ROOT_REFS;
    } else if (kind & filter.kind == 0) return null;

    if (!filterPatternMatch(filter, r.name)) return null;
    if (filterExcludeMatch(filter, r.name)) return null;
    if (filter.points_at.items.len > 0 and !matchPointsAt(filter.points_at.items, r.oid, r.name)) return null;
    if (filter.forked.items.len > 0 and !filterForkedMatch(filter, r.name)) return null;

    var commit: ?*cn.Commit = null;
    if (filter.reachable_from != null or filter.unreachable_from != null or
        filter.with_commit != null or filter.no_commit != null or filter.verbose != 0)
    {
        commit = cn.lookupCommitReference(r.oid) orelse return null;
        if (filter.with_commit != null and !commitContains(filter, commit.?, filter.with_commit, &filter.contains_cache)) return null;
        if (filter.no_commit != null and commitContains(filter, commit.?, filter.no_commit, &filter.no_contains_cache)) return null;
    }
    const it = newItem(r.name, r.oid);
    it.peeled = r.peeled;
    it.commit = commit;
    it.flag = r.flags;
    it.kind = kind;
    it.symref = r.target;
    return it;
}

fn collectIter(prefix: []const u8, out: *std.ArrayList(RawRef)) void {
    for (refs.iterate(prefix, .{ .include_broken = true, .check_objects = false })) |r| {
        // omit dangling symrefs
        if (r.flags & refs.REF_ISSYMREF != 0 and r.flags & refs.REF_ISBROKEN != 0) continue;
        if (r.flags & refs.REF_ISSYMREF != 0 and hash.isZero(r.oid)) continue;
        out.append(gpa, .{ .name = r.name, .oid = r.oid, .peeled = r.peeled, .flags = r.flags, .target = r.symref }) catch util.oom();
    }
}

fn collectRefs(filter: *Filter) []RawRef {
    var l: std.ArrayList(RawRef) = .empty;
    var prefix: ?[]const u8 = null;
    if (filter.kind == FILTER_REFS_BRANCHES) {
        prefix = "refs/heads/";
    } else if (filter.kind == FILTER_REFS_REMOTES) {
        prefix = "refs/remotes/";
    } else if (filter.kind == FILTER_REFS_TAGS) prefix = "refs/tags/";

    if (prefix) |p| {
        collectIter(if (filter.start_after != null) "refs/" else p, &l);
    } else if (filter.kind & FILTER_REFS_REGULAR != 0) {
        if (filter.kind & FILTER_REFS_ROOT_REFS != 0) {
            for (refs.listRootRefs()) |r| {
                if (r.flags & refs.REF_ISSYMREF != 0 and hash.isZero(r.oid)) continue;
                l.append(gpa, .{ .name = r.name, .oid = r.oid, .flags = r.flags, .target = r.symref }) catch util.oom();
            }
        }
        collectIter("refs/", &l);
        std.mem.sort(RawRef, l.items, {}, struct {
            fn lt(_: void, a: RawRef, b: RawRef) bool {
                return std.mem.order(u8, a.name, b.name) == .lt;
            }
        }.lt);
    }
    if (filter.start_after) |sa| {
        const marker = util.concat(&.{ sa, "\x01" });
        var kept: std.ArrayList(RawRef) = .empty;
        for (l.items) |r| {
            if (std.mem.order(u8, r.name, marker) != .lt) kept.append(gpa, r) catch util.oom();
        }
        l = kept;
    }
    if (filter.kind & FILTER_REFS_ROOT_REFS == 0 and filter.kind & FILTER_REFS_DETACHED_HEAD != 0) {
        const r = refs.resolveFull("HEAD", true);
        if (!r.missing and !r.broken) {
            l.append(gpa, .{ .name = "HEAD", .oid = r.oid, .flags = r.flags }) catch util.oom();
        }
    }
    return l.items;
}

fn initFilterKind(filter: *Filter, typ: u32) void {
    filter.kind = typ & FILTER_REFS_KIND_MASK;
    filter.contains_cache = reach.newContainsCache();
    filter.no_contains_cache = reach.newContainsCache();
    if (filter.kind == 0) util.die("filter_refs: invalid type", .{});
}

fn reachFilter(items: *std.ArrayList(*Item), check: *?*cn.CommitList, include_reached: bool) void {
    if (check.* == null) return;
    const to_clear = gpa.alloc(*cn.Commit, items.items.len) catch util.oom();
    for (items.items, 0..) |it, i| to_clear[i] = it.commit.?;
    reach.tipsReachableFromBases(check.*, to_clear, cn.UNINTERESTING);
    var kept: std.ArrayList(*Item) = .empty;
    for (items.items) |it| {
        const merged = it.commit.?.obj.flags & cn.UNINTERESTING != 0;
        if (merged == include_reached) kept.append(gpa, it) catch util.oom();
    }
    cn.clearCommitMarksMany(to_clear, cn.ALL_REV_FLAGS);
    while (cn.popCommit(check)) |c| cn.clearCommitMarks(c, cn.ALL_REV_FLAGS);
    items.* = kept;
}

/// filter_refs
pub fn filterRefs(filter: *Filter, typ: u32) []*Item {
    initFilterKind(filter, typ);
    var items: std.ArrayList(*Item) = .empty;
    for (collectRefs(filter)) |r| {
        if (applyRefFilter(r, filter)) |it| items.append(gpa, it) catch util.oom();
    }
    reachFilter(&items, &filter.reachable_from, true);
    reachFilter(&items, &filter.unreachable_from, false);
    return items.items;
}

pub fn filterAheadBehind(items: []*Item) void {
    if (items.len == 0) return;
    var bases_nr: usize = 0;
    for (used_atom.items) |a| {
        if (a.atom_type == .ahead_behind) bases_nr += 1;
    }
    if (bases_nr == 0) return;
    var commits: std.ArrayList(*cn.Commit) = .empty;
    for (used_atom.items) |a| {
        if (a.atom_type == .ahead_behind) commits.append(gpa, a.base_commit.?) catch util.oom();
    }
    var counts: std.ArrayList(reach.AheadBehindCount) = .empty;
    const starts = gpa.alloc(?usize, items.len) catch util.oom();
    for (items, 0..) |it, i| {
        starts[i] = null;
        const c = lookupCommitByName(it.refname) orelse continue;
        const tip_index = commits.items.len;
        commits.append(gpa, c) catch util.oom();
        starts[i] = counts.items.len;
        var j: usize = 0;
        while (j < bases_nr) : (j += 1) {
            counts.append(gpa, .{ .tip_index = tip_index, .base_index = j }) catch util.oom();
        }
    }
    reach.aheadBehind(commits.items, counts.items);
    for (items, 0..) |it, i| {
        if (starts[i]) |s| it.counts = counts.items[s .. s + bases_nr];
    }
}

pub fn filterIsBase(items: []*Item) void {
    if (items.len == 0) return;
    var n: usize = 0;
    for (used_atom.items) |a| {
        if (a.atom_type == .is_base) n += 1;
    }
    if (n == 0) return;
    var back: std.ArrayList(*Item) = .empty;
    var bases: std.ArrayList(*cn.Commit) = .empty;
    for (items) |it| {
        const arr = gpa.alloc(?[]const u8, n) catch util.oom();
        for (arr) |*x| x.* = null;
        it.is_base = arr;
        const c = lookupCommitByName(it.refname) orelse continue;
        back.append(gpa, it) catch util.oom();
        bases.append(gpa, c) catch util.oom();
    }
    var j: usize = 0;
    for (used_atom.items) |a| {
        if (a.atom_type != .is_base) continue;
        const bi = reach.getBranchBaseForTip(a.base_commit.?, bases.items);
        if (bi < 0) continue;
        back.items[@intCast(bi)].is_base.?[j] = a.base_name;
        j += 1;
    }
}

fn canDoIterative(filter: *const Filter, sorting: ?*Sorting) bool {
    if (sorting) |s| {
        if (s.next != null or s.flags != 0 or used_atom.items[s.atom].atom_type != .refname) return false;
    }
    for (used_atom.items) |a| {
        if (a.atom_type == .ahead_behind or a.atom_type == .is_base) return false;
    }
    return filter.reachable_from == null and filter.unreachable_from == null;
}

/// filter_and_format_refs
pub fn filterAndFormat(filter: *Filter, typ: u32, sorting: ?*Sorting, format: *const Format) void {
    if (canDoIterative(filter, sorting)) {
        initFilterKind(filter, typ);
        var count: i32 = 0;
        var out: Buf = .empty;
        for (collectRefs(filter)) |r| {
            const it = applyRefFilter(r, filter) orelse continue;
            out.clearRetainingCapacity();
            formatItem(it, format, &out);
            if (out.items.len > 0 or !format.omit_empty) {
                util.out(out.items);
                util.out("\n");
            }
            count += 1;
            if (format.max_count > 0 and count >= format.max_count) break;
        }
    } else {
        const items = filterRefs(filter, typ);
        filterAheadBehind(items);
        filterIsBase(items);
        sortItems(sorting, items);
        printFormattedArray(items, format);
    }
}

/// Like filterAndFormat but returns the formatted lines (without newlines),
/// honoring max_count and omit_empty (used for column output).
pub fn filterAndFormatCollect(filter: *Filter, typ: u32, sorting: ?*Sorting, format: *const Format) [][]const u8 {
    const items = filterRefs(filter, typ);
    filterAheadBehind(items);
    filterIsBase(items);
    sortItems(sorting, items);
    var total: usize = items.len;
    if (format.max_count > 0 and @as(usize, @intCast(format.max_count)) < total) total = @intCast(format.max_count);
    var lines: std.ArrayList([]const u8) = .empty;
    for (items[0..total]) |it| {
        var out: Buf = .empty;
        formatItem(it, format, &out);
        if (out.items.len > 0 or !format.omit_empty) lines.append(gpa, out.items) catch util.oom();
    }
    return lines.items;
}

// ---------------------------------------------------------------------------
// option callbacks (operate on `cur_filter`)

pub var cur_filter: *Filter = undefined;

fn lookupCommitLoud(oid: Oid) ?*cn.Commit {
    if (cn.lookupCommitReference(oid)) |c| return c;
    if (repo_mod.repo().odb().read(oid)) |o| {
        var typ = o.typ;
        var cur_oid = oid;
        // deref tags to report final type
        var data = o.data;
        while (typ == .tag) {
            const t = objects.parseTag(data) orelse break;
            cur_oid = t.object;
            const o2 = repo_mod.repo().odb().read(cur_oid) orelse break;
            typ = o2.typ;
            data = o2.data;
        }
        if (typ != .commit) util.err("object {s} is a {s}, not a commit", .{ hash.hex(cur_oid), typ.name() });
    }
    return null;
}

/// parse_opt_merge_filter: --merged / --no-merged
pub fn parseOptMergeFilter(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse "HEAD";
    const oid = revparse.getOid(a) orelse util.die("malformed object name {s}", .{a});
    const c = lookupCommitLoud(oid) orelse {
        util.err("option `{s}' must point to a commit", .{o.long});
        os.exit(129);
    };
    if (util.startsWith(o.long, "no")) {
        _ = cn.listInsert(c, &cur_filter.unreachable_from);
    } else {
        _ = cn.listInsert(c, &cur_filter.reachable_from);
    }
}

/// parse_opt_commits: --contains/--with (with_commit), --no-contains/--without (no_commit)
pub fn parseOptCommits(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = unset;
    const a = arg orelse os.exit(129);
    const oid = revparse.getOid(a) orelse {
        util.err("malformed object name {s}", .{a});
        os.exit(129);
    };
    const c = lookupCommitLoud(oid) orelse {
        util.err("no such commit {s}", .{a});
        os.exit(129);
    };
    if (util.eql(o.long, "no-contains") or util.eql(o.long, "without")) {
        _ = cn.listInsert(c, &cur_filter.no_commit);
    } else {
        _ = cn.listInsert(c, &cur_filter.with_commit);
    }
}

/// parse_opt_object_name for --points-at
pub fn parseOptPointsAt(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    _ = o;
    if (unset) {
        cur_filter.points_at.clearRetainingCapacity();
        return;
    }
    const a = arg orelse os.exit(129);
    const oid = revparse.getOid(a) orelse {
        util.err("malformed object name '{s}'", .{a});
        os.exit(129);
    };
    cur_filter.points_at.append(gpa, oid) catch util.oom();
}

pub var cur_color: *color_mod.ColorBool = undefined;

/// parse_opt_color_flag_cb
pub fn parseOptColor(o: *const po.Opt, arg: ?[]const u8, unset: bool) void {
    const a = arg orelse (if (unset) "never" else (o.def orelse "always"));
    const v = color_mod.configColorBool(null, a);
    if (v == .unknown) {
        util.err("option `{s}' expects \"always\", \"auto\", or \"never\"", .{o.long});
        os.exit(129);
    }
    cur_color.* = v;
}

pub fn mergedOpt(long: []const u8, help: []const u8) po.Opt {
    return .{ .long = long, .kind = .callback, .cbx = parseOptMergeFilter, .argh = "commit", .help = help, .lastarg_default = true, .def = "HEAD", .noneg = true };
}

pub fn containsOpt(long: []const u8, help: []const u8, hidden: bool) po.Opt {
    return .{ .long = long, .kind = .callback, .cbx = parseOptCommits, .argh = "commit", .help = help, .lastarg_default = true, .def = "HEAD", .noneg = true, .hidden = hidden };
}

pub fn pointsAtOpt(help: []const u8) po.Opt {
    return .{ .long = "points-at", .kind = .callback, .cbx = parseOptPointsAt, .argh = "object", .help = help };
}

pub fn colorOpt(help: []const u8) po.Opt {
    return .{ .long = "color", .kind = .callback, .cbx = parseOptColor, .argh = "when", .help = help, .optarg = true, .def = "always" };
}

// ---------------------------------------------------------------------------
// for-each-ref

const common_usage = "[--count=<count>] [--shell|--perl|--python|--tcl]\n" ++
    "                         [(--sort=<key>)...] [--format=<format>]\n" ++
    "                         [--include-root-refs] [--points-at=<object>]\n" ++
    "                         [--merged[=<object>]] [--no-merged[=<object>]]\n" ++
    "                         [--contains[=<object>]] [--no-contains[=<object>]]\n" ++
    "                         [(--exclude=<pattern>)...] [--start-after=<marker>]\n" ++
    "                         [ --stdin | (<pattern>...)]";

pub fn forEachRefMain(args: []const []const u8, is_refs_list: bool) u8 {
    const usage_fer = [_][]const u8{"git for-each-ref " ++ common_usage};
    const usage_rl = [_][]const u8{"git refs list " ++ common_usage};
    const usage: []const []const u8 = if (is_refs_list) &usage_rl else &usage_fer;

    var filter = Filter{};
    var format = Format{ .format = "%(objectname) %(objecttype)\t%(refname)" };
    cur_filter = &filter;
    cur_color = &format.use_color;
    var sort_opts: std.ArrayList([]const u8) = .empty;
    sort_opts.append(gpa, "refname") catch util.oom();
    var icase = false;
    var include_root_refs = false;
    var from_stdin = false;
    var fmt_s: ?[]const u8 = null;
    var start_after: ?[]const u8 = null;

    const opts = [_]po.Opt{
        po.bit('s', "shell", &format.quote_style, QUOTE_SHELL, "quote placeholders suitably for shells"),
        po.bit('p', "perl", &format.quote_style, QUOTE_PERL, "quote placeholders suitably for perl"),
        po.bit(0, "python", &format.quote_style, QUOTE_PYTHON, "quote placeholders suitably for python"),
        po.bit(0, "tcl", &format.quote_style, QUOTE_TCL, "quote placeholders suitably for Tcl"),
        po.boolean(0, "omit-empty", &format.omit_empty, "do not output a newline after empty formatted refs"),
        po.group(""),
        po.integer(0, "count", &format.max_count, "n", "show only <n> matched refs"),
        po.string(0, "format", &fmt_s, "format", "format to use for the output"),
        po.string(0, "start-after", &start_after, "marker", "start iteration after the provided marker"),
        colorOpt("respect format colors"),
        po.list(0, "exclude", &filter.exclude, "pattern", "exclude refs which match pattern"),
        po.list(0, "sort", &sort_opts, "key", "field name to sort on"),
        pointsAtOpt("print only refs which points at the given object"),
        mergedOpt("merged", "print only refs that are merged"),
        mergedOpt("no-merged", "print only refs that are not merged"),
        containsOpt("contains", "print only refs which contain the commit", false),
        containsOpt("no-contains", "print only refs which don't contain the commit", false),
        po.boolean(0, "ignore-case", &icase, "sorting and filtering are case insensitive"),
        po.boolean(0, "stdin", &from_stdin, "read reference patterns from stdin"),
        po.boolean(0, "include-root-refs", &include_root_refs, "also include HEAD ref and pseudorefs"),
    };
    const rest = po.parse(args[1..], &opts, usage, .{});
    if (fmt_s) |f| format.format = f;
    filter.start_after = start_after;

    if (format.max_count < 0) {
        util.err("invalid --count argument: `{d}'", .{format.max_count});
        po.usageWithOptions(usage, &opts);
    }
    if (@popCount(@as(u32, @bitCast(format.quote_style))) > 1) {
        util.err("more than one quoting style?", .{});
        po.usageWithOptions(usage, &opts);
    }
    if (!verifyFormat(&format)) po.usageWithOptions(usage, &opts);

    if (filter.start_after != null and sort_opts.items.len > 1)
        util.die("cannot use --start-after with custom sort options", .{});

    const sorting = sortingOptions(sort_opts.items);
    setSortFlagsAll(sorting, SORT_ICASE, icase);
    filter.ignore_case = icase;

    if (from_stdin) {
        if (rest.len > 0) util.die("unknown arguments supplied with --stdin", .{});
        const data = os.readAllFd(0) catch "";
        var pats: std.ArrayList([]const u8) = .empty;
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |line0| {
            if (it.index == null and line0.len == 0) break;
            var line = line0;
            if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
            pats.append(gpa, line) catch util.oom();
        }
        filter.name_patterns = pats.items;
    } else {
        filter.name_patterns = rest;
    }

    if (filter.start_after != null and filter.name_patterns.len > 0)
        util.die("cannot use --start-after with patterns", .{});

    var flags: u32 = FILTER_REFS_REGULAR;
    if (include_root_refs) flags |= FILTER_REFS_ROOT_REFS | FILTER_REFS_DETACHED_HEAD;
    filter.match_as_path = true;
    filterAndFormat(&filter, flags, sorting, &format);
    return 0;
}

// ---------------------------------------------------------------------------
// repo_interpret_branch_name() / copy_branchname() (object-name.c, refs.c)

pub const INTERPRET_BRANCH_LOCAL: u32 = 1 << 0;
pub const INTERPRET_BRANCH_REMOTE: u32 = 1 << 1;
pub const INTERPRET_BRANCH_HEAD: u32 = 1 << 2;

pub const Interpreted = struct { used: isize, buf: []const u8 };

fn atMark(s: []const u8, suffixes: []const []const u8) usize {
    for (suffixes) |suf| {
        if (suf.len <= s.len and std.ascii.eqlIgnoreCase(s[0..suf.len], suf)) return suf.len;
    }
    return 0;
}

fn branchInterpretAllowed(refname: []const u8, allowed: u32) bool {
    if (allowed == 0) return true;
    if (allowed & INTERPRET_BRANCH_LOCAL != 0 and util.startsWith(refname, "refs/heads/")) return true;
    if (allowed & INTERPRET_BRANCH_REMOTE != 0 and util.startsWith(refname, "refs/remotes/")) return true;
    return false;
}

fn interpretBranchMark(name: []const u8, at: usize, push: bool, allowed: u32, nonfatal: bool) ?Interpreted {
    const marks: []const []const u8 = if (push) &.{"@{push}"} else &.{ "@{upstream}", "@{u}" };
    const len = atMark(name[at..], marks);
    if (len == 0) return null;
    if (std.mem.indexOfScalar(u8, name[0..at], ':') != null) return null;
    var bname: ?[]const u8 = null;
    if (at > 0 and !util.eql(name[0..at], "HEAD")) {
        bname = name[0..at];
    } else if (refs.headSymref()) |h| {
        if (util.skipPrefix(h, "refs/heads/")) |s| bname = s;
    }
    var errmsg: []const u8 = "HEAD does not point to a branch";
    var value: ?[]const u8 = null;
    if (bname) |bn| {
        const b = branchGet(bn);
        if (!push and b.merge_names.len == 0 and !refs.exists(b.refname)) {
            errmsg = util.fmt("no such branch: '{s}'", .{bn});
        } else {
            value = if (push) branchGetPush(b, &errmsg) else branchGetUpstream(b, &errmsg);
        }
    }
    const v = value orelse {
        if (nonfatal) return null;
        util.die("{s}", .{errmsg});
    };
    if (!branchInterpretAllowed(v, allowed)) return null;
    return .{ .used = @intCast(len + at), .buf = refs.shortenUnambiguous(v) };
}

fn reinterpretBranch(name: []const u8, len: usize, buf: []const u8, allowed: u32, nonfatal: bool) Interpreted {
    const joined = util.concat(&.{ buf, name[len..] });
    const r = interpretBranchNameOpts(joined, allowed, nonfatal);
    if (r.used < 0) return .{ .used = @intCast(len), .buf = buf };
    return .{ .used = r.used - @as(isize, @intCast(buf.len)) + @as(isize, @intCast(len)), .buf = r.buf };
}

/// repo_interpret_branch_name(): used < 0 means not interpreted; used == 0
/// means valid @{-N} syntax but not enough branch switches.
pub fn interpretBranchNameOpts(name: []const u8, allowed: u32, nonfatal: bool) Interpreted {
    if (allowed == 0 or allowed & INTERPRET_BRANCH_LOCAL != 0) nth: {
        if (name.len < 4 or !util.startsWith(name, "@{-")) break :nth;
        const brace = std.mem.indexOfScalar(u8, name, '}') orelse break :nth;
        const nth = std.fmt.parseInt(usize, name[3..brace], 10) catch break :nth;
        if (nth == 0) break :nth;
        const b = revparse.previousBranch(nth) orelse return .{ .used = 0, .buf = "" };
        const len = brace + 1;
        if (len == name.len) return .{ .used = @intCast(len), .buf = b };
        return reinterpretBranch(name, len, b, allowed, nonfatal);
    }
    var start: usize = 0;
    while (std.mem.indexOfScalarPos(u8, name, start, '@')) |at| : (start = at + 1) {
        if (allowed == 0 or allowed & INTERPRET_BRANCH_HEAD != 0) empty: {
            // interpret_empty_at(): a lone "@" or "@@{...}"
            if (at != 0 or (name.len > 1 and name[1] == '{')) break :empty;
            const next = std.mem.indexOfScalarPos(u8, name, 1, '@');
            if (next) |nx| {
                if (nx + 1 >= name.len or name[nx + 1] != '{') break :empty;
            }
            if ((next orelse name.len) != 1) break :empty;
            return reinterpretBranch(name, 1, "HEAD", allowed, nonfatal);
        }
        if (interpretBranchMark(name, at, false, allowed, nonfatal)) |r| return r;
        if (interpretBranchMark(name, at, true, allowed, nonfatal)) |r| return r;
    }
    return .{ .used = -1, .buf = "" };
}

/// copy_branchname()
pub fn copyBranchname(name: []const u8, allowed: u32) []const u8 {
    const r = interpretBranchNameOpts(name, allowed, false);
    const used: usize = if (r.used < 0) 0 else @intCast(r.used);
    if (used == 0) return name;
    return util.concat(&.{ r.buf, name[used..] });
}
