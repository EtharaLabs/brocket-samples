//! Port of progress.c.  The SIGALRM interval timer is emulated with a
//! monotonic clock: "progress_update" becomes set once per elapsed second
//! since the meter was started (checked whenever the meter is touched).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const gpa = util.gpa;

const TP_IDX_MAX = 8;

const Throughput = struct {
    curr_total: u64 = 0,
    prev_total: u64 = 0,
    prev_ns: u64 = 0,
    avg_bytes: u32 = 0,
    avg_misecs: u32 = 0,
    last_bytes: [TP_IDX_MAX]u32 = @splat(0),
    last_misecs: [TP_IDX_MAX]u32 = @splat(0),
    idx: u32 = 0,
    display: util.Buf = .empty,
};

/// progress_testing / progress_test_ns (test-tool progress)
pub var testing: bool = false;
pub var test_ns: u64 = 0;

var progress_update: bool = false;
var timer_start_ns: u64 = 0;
var timer_ticks: u64 = 0;
var timer_active: bool = false;

const Timespec = extern struct { sec: i64, nsec: i64 };
extern "c" fn clock_gettime(clk: c_int, ts: *Timespec) c_int;
extern "c" fn tcgetpgrp(fd: c_int) c_int;
extern "c" fn getpgid(pid: c_int) c_int;

fn getnanotime() u64 {
    var ts: Timespec = .{ .sec = 0, .nsec = 0 };
    _ = clock_gettime(1, &ts); // CLOCK_MONOTONIC
    return @as(u64, @intCast(ts.sec)) * 1000000000 + @as(u64, @intCast(ts.nsec));
}

/// Emulates the 1-second itimer: sets progress_update when a tick elapsed.
fn pollTimer() void {
    if (testing or !timer_active) return;
    const ticks = (getnanotime() -| timer_start_ns) / 1000000000;
    if (ticks > timer_ticks) {
        timer_ticks = ticks;
        progress_update = true;
    }
}

fn setProgressSignal() void {
    if (testing) return;
    progress_update = false;
    timer_start_ns = getnanotime();
    timer_ticks = 0;
    timer_active = true;
}

fn clearProgressSignal() void {
    if (testing) return;
    timer_active = false;
    progress_update = false;
}

/// progress_test_force_update()
pub fn testForceUpdate() void {
    progress_update = true;
}

fn isForegroundFd(fd: c_int) bool {
    const tpgrp = tcgetpgrp(fd);
    return tpgrp < 0 or tpgrp == getpgid(0);
}

/// strbuf_humanise_bytes() / strbuf_humanise_rate()
pub fn humaniseBytes(b: *util.Buf, bytes: u64, rate: bool) void {
    if (bytes > 1 << 30) {
        util.bufPrint(b, "{d}.{d:0>2} {s}", .{ bytes >> 30, @as(u32, @truncate(bytes & ((1 << 30) - 1))) / 10737419, if (rate) "GiB/s" else "GiB" });
    } else if (bytes > 1 << 20) {
        const x: u32 = @truncate(bytes + 5243);
        util.bufPrint(b, "{d}.{d:0>2} {s}", .{ x >> 20, ((x & ((1 << 20) - 1)) *% 100) >> 20, if (rate) "MiB/s" else "MiB" });
    } else if (bytes > 1 << 10) {
        const x: u32 = @truncate(bytes + 5);
        util.bufPrint(b, "{d}.{d:0>2} {s}", .{ x >> 10, ((x & ((1 << 10) - 1)) * 100) >> 10, if (rate) "KiB/s" else "KiB" });
    } else {
        const unit = if (rate) (if (bytes == 1) "byte/s" else "bytes/s") else (if (bytes == 1) "byte" else "bytes");
        util.bufPrint(b, "{d} {s}", .{ @as(u32, @truncate(bytes)), unit });
    }
}

fn termColumns() usize {
    const c = @import("pretty.zig").termColumns();
    return if (c > 0) @intCast(c) else 80;
}

pub const Progress = struct {
    title: []const u8,
    total: u64,
    last_value: i64 = -1,
    last_percent: i64 = -1,
    delay: u64 = 0,
    sparse: bool = false,
    throughput: ?*Throughput = null,
    start_ns: u64 = 0,
    counters: util.Buf = .empty,
    title_len: usize = 0,
    split: bool = false,
    stopped: bool = false,

    fn nanotime(self: *Progress) u64 {
        if (testing) return self.start_ns + test_ns;
        return getnanotime();
    }

    fn display(self: *Progress, n: u64, done: ?[]const u8) void {
        pollTimer();
        const upd = progress_update;
        const last_count_len = self.counters.items.len;
        progress_update = false;

        if (self.delay != 0) {
            if (!upd) return;
            self.delay -= 1;
            if (self.delay != 0) return;
        }

        self.last_value = @intCast(n);
        const tp: []const u8 = if (self.throughput) |t| t.display.items else "";
        var show = false;
        if (self.total != 0) {
            const percent: i64 = @intCast(@as(u32, @truncate(n *% 100 / self.total)));
            if (percent != self.last_percent or upd) {
                self.last_percent = percent;
                self.counters.clearRetainingCapacity();
                util.bufPrint(&self.counters, "{d: >3}% ({d}/{d}){s}", .{ @as(u64, @intCast(percent)), n, self.total, tp });
                show = true;
            }
        } else if (upd) {
            self.counters.clearRetainingCapacity();
            util.bufPrint(&self.counters, "{d}{s}", .{ n, tp });
            show = true;
        }
        if (!show) return;
        if (!(isForegroundFd(2) or done != null)) return;

        const eol = done orelse "\r";
        const cnt = self.counters.items;
        var clear_len: usize = if (cnt.len < last_count_len) last_count_len - cnt.len + 1 else 0;
        const line_len = self.title_len + cnt.len + 2;
        const cols = termColumns();
        var line: util.Buf = .empty;
        if (self.split) {
            util.bufPrint(&line, "  {s}", .{cnt});
            padded(&line, eol, clear_len);
        } else if (done == null and cols < line_len) {
            clear_len = if (self.title_len + 1 < cols) cols - self.title_len - 1 else 0;
            util.bufPrint(&line, "{s}:", .{self.title});
            line.appendNTimes(gpa, ' ', clear_len) catch util.oom();
            util.bufPrint(&line, "\n  {s}{s}", .{ cnt, eol });
            self.split = true;
        } else {
            util.bufPrint(&line, "{s}: {s}", .{ self.title, cnt });
            padded(&line, eol, clear_len);
        }
        util.ewrite(line.items);
    }

    /// printf("%*s", width, s): right-aligned in a field of `width`.
    fn padded(line: *util.Buf, s: []const u8, width: usize) void {
        if (width > s.len) line.appendNTimes(gpa, ' ', width - s.len) catch util.oom();
        util.bufAppend(line, s);
    }

    pub fn update(self: *Progress, n: u64) void {
        self.display(n, null);
    }

    /// display_throughput()
    pub fn displayThroughput(self: *Progress, total: u64) void {
        const now_ns = self.nanotime();
        const t = self.throughput orelse {
            const nt = gpa.create(Throughput) catch util.oom();
            nt.* = .{ .prev_total = total, .curr_total = total, .prev_ns = now_ns };
            self.throughput = nt;
            return;
        };
        t.curr_total = total;
        if (now_ns -% t.prev_ns <= 500000000) return;
        const misecs: u32 = @truncate(((now_ns -% t.prev_ns) *% 4398) >> 32);
        const count: u32 = @truncate(total -% t.prev_total);
        t.prev_total = total;
        t.prev_ns = now_ns;
        t.avg_bytes +%= count;
        t.avg_misecs +%= misecs;
        const rate: u32 = if (t.avg_misecs != 0) t.avg_bytes / t.avg_misecs else 0;
        t.avg_bytes -%= t.last_bytes[t.idx];
        t.avg_misecs -%= t.last_misecs[t.idx];
        t.last_bytes[t.idx] = count;
        t.last_misecs[t.idx] = misecs;
        t.idx = (t.idx + 1) % TP_IDX_MAX;
        throughputString(&t.display, total, rate);
        pollTimer();
        if (self.last_value != -1 and progress_update) self.display(@intCast(self.last_value), null);
    }

    pub fn stop(self: *Progress) void {
        self.stopMsg("done");
    }

    /// stop_progress_msg()
    pub fn stopMsg(self: *Progress, msg: []const u8) void {
        if (self.stopped) return;
        self.stopped = true;
        // finish_if_sparse()
        if (self.sparse and self.last_value != @as(i64, @intCast(self.total))) self.display(self.total, null);
        if (self.last_value != -1) {
            // force_last_update()
            if (self.throughput) |t| {
                const now_ns = self.nanotime();
                const misecs: u32 = @truncate(((now_ns -% self.start_ns) *% 4398) >> 32);
                const rate: u32 = @truncate(t.curr_total / (if (misecs != 0) misecs else 1));
                throughputString(&t.display, t.curr_total, rate);
            }
            progress_update = true;
            self.display(@intCast(self.last_value), util.fmt(", {s}.\n", .{msg}));
        }
        // log_trace2()
        const t2 = @import("trace2.zig");
        t2.dataInt("progress", true, "total_objects", @intCast(self.total));
        if (self.throughput) |t| t2.dataInt("progress", true, "total_bytes", @intCast(t.curr_total));
        t2.regionLeave("progress", self.title, true);
        clearProgressSignal();
    }
};

fn throughputString(b: *util.Buf, total: u64, rate: u32) void {
    b.clearRetainingCapacity();
    util.bufAppend(b, ", ");
    humaniseBytes(b, total, false);
    util.bufAppend(b, " | ");
    humaniseBytes(b, @as(u64, rate *% 1024), true);
}

var default_delay: ?u64 = null;

/// get_default_delay(): git_env_ulong("GIT_PROGRESS_DELAY", 1)
fn getDefaultDelay() u64 {
    if (default_delay) |d| return d;
    var d: u64 = 1;
    if (os.getenv("GIT_PROGRESS_DELAY")) |v| {
        const n = @import("config.zig").parseInt(v) orelse util.die("failed to parse {s}", .{"GIT_PROGRESS_DELAY"});
        if (n < 0 or std.mem.indexOfScalar(u8, v, '-') != null) util.die("failed to parse {s}", .{"GIT_PROGRESS_DELAY"});
        d = @intCast(n);
    }
    default_delay = d;
    return d;
}

fn startDelay(title: []const u8, total: u64, delay: u64, sparse: bool) *Progress {
    const p = gpa.create(Progress) catch util.oom();
    p.* = .{
        .title = title,
        .total = total,
        .delay = delay,
        .sparse = sparse,
        .start_ns = getnanotime(),
        .title_len = @intCast(@max(0, @import("pretty.zig").utf8Strwidth(title))),
    };
    setProgressSignal();
    @import("trace2.zig").regionEnter("progress", title, true);
    return p;
}

pub fn start(title: []const u8, total: u64) *Progress {
    return startDelay(title, total, 0, false);
}

pub fn startSparse(title: []const u8, total: u64) *Progress {
    return startDelay(title, total, 0, true);
}

/// start_delayed_progress()
pub fn startDelayed(title: []const u8, total: u64) *Progress {
    return startDelay(title, total, getDefaultDelay(), false);
}

/// start_delayed_sparse_progress()
pub fn startDelayedSparse(title: []const u8, total: u64) *Progress {
    return startDelay(title, total, getDefaultDelay(), true);
}

pub fn update(p: ?*Progress, n: u64) void {
    if (p) |x| x.update(n);
}

pub fn displayThroughput(p: ?*Progress, total: u64) void {
    if (p) |x| x.displayThroughput(total);
}

pub fn stop(p: *?*Progress) void {
    if (p.*) |x| x.stop();
    p.* = null;
}

pub fn stopMsg(p: *?*Progress, msg: []const u8) void {
    if (p.*) |x| x.stopMsg(msg);
    p.* = null;
}
