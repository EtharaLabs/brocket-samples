//! Reference database consistency checks (`git refs verify`): refs_fsck()
//! in refs.c, files_fsck() in refs/files-backend.c and packed_fsck() in
//! refs/packed-backend.c. The reftable checks live in reftable_backend.zig
//! but report through `report()` here.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const refs = @import("refs.zig");
const fsck = @import("fsck.zig");
const Oid = hash.Oid;

pub const Ctx = struct {
    o: fsck.Options = .{},
    verbose: bool = false,
};

/// fsck_options_init(FSCK_OPTIONS_REFS) + git_fsck_config.
pub fn init(verbose: bool, strict: bool) Ctx {
    var c = Ctx{ .verbose = verbose };
    c.o.strict = strict;
    fsck.applyConfig(&c.o);
    return c;
}

/// fsck_report_ref() with fsck_refs_error_function(): returns -1 for errors.
pub fn report(c: *Ctx, path: []const u8, id: fsck.MsgId, comptime f: []const u8, args: anytype) i32 {
    var t = fsck.msgTypeOf(&c.o, id);
    if (t == .ignore) return 0;
    if (t == .fatal) t = .err else if (t == .info) t = .warn;
    const msg = util.fmt(f, args);
    if (t == .warn) {
        util.warn("{s}: {s}: {s}", .{ path, fsck.camelName(id), msg });
        return 0;
    }
    util.err("{s}: {s}: {s}", .{ path, fsck.camelName(id), msg });
    return -1;
}

/// refs_fsck_ref()
pub fn checkRef(c: *Ctx, path: []const u8, oid: Oid) i32 {
    if (hash.isZero(oid)) return report(c, path, .bad_ref_oid, "points to invalid object ID '{s}'", .{hash.hex(oid)});
    return 0;
}

fn stripWorktree(name: []const u8) []const u8 {
    if (util.skipPrefix(name, "worktrees/")) |rest| {
        if (std.mem.indexOfScalar(u8, rest, '/')) |sl| {
            if (sl > 0) return rest[sl + 1 ..];
        }
    }
    if (util.skipPrefix(name, "main-worktree/")) |rest| return rest;
    return name;
}

/// refs_fsck_symref()
pub fn checkSymref(c: *Ctx, path: []const u8, refname: []const u8, target: []const u8) i32 {
    if (util.eql(stripWorktree(refname), "HEAD") and !util.startsWith(target, "refs/heads/") and
        report(c, path, .bad_head_target, "HEAD points to non-branch '{s}'", .{target}) != 0)
        return -1;
    if (refs.isRootRef(target)) return 0;
    if (!refs.checkRefnameFormat(target, 0) and
        report(c, path, .bad_referent_name, "points to invalid refname '{s}'", .{target}) != 0)
        return -1;
    if (!util.startsWith(target, "refs/") and !util.startsWith(target, "worktrees/") and
        report(c, path, .symref_target_is_not_a_ref, "points to non-ref target '{s}'", .{target}) != 0)
        return -1;
    return 0;
}

/// refs_fsck() for the worktree `wt_id` (null: main worktree).
pub fn run(c: *Ctx, wt_id: ?[]const u8) i32 {
    if (c.verbose) util.eprint("Checking references consistency\n", .{});
    if (refs.isReftable()) return @import("reftable_backend.zig").fsck(c, wt_id);
    return filesFsck(c, wt_id);
}

// ---------------------------------------------------------------- files

fn isSpace(ch: u8) bool {
    return ch == ' ' or ch == '\t' or ch == '\n' or ch == '\r' or ch == 0x0b or ch == 0x0c;
}

fn rtrim(s: []const u8) []const u8 {
    var e = s.len;
    while (e > 0 and isSpace(s[e - 1])) e -= 1;
    return s[0..e];
}

/// files_fsck_symref_target()
fn symrefTarget(c: *Ctx, path: []const u8, refname: []const u8, referent0: []const u8, symbolic_link: bool) i32 {
    var ret: i32 = 0;
    var referent = referent0;
    if (!symbolic_link and referent0.len > 0) {
        const orig_len = referent0.len;
        const last = referent0[orig_len - 1];
        referent = rtrim(referent0);
        if (referent.len == orig_len or (referent.len < orig_len and last != '\n'))
            ret |= report(c, path, .ref_missing_newline, "misses LF at the end", .{});
        if (referent.len != orig_len and referent.len != orig_len - 1)
            ret |= report(c, path, .trailing_ref_content, "has trailing whitespaces or newlines", .{});
    }
    ret |= checkSymref(c, path, refname, referent);
    return if (ret != 0) -1 else 0;
}

/// strbuf_realpath(): like realpath(3) but the final component of the
/// (link-resolved) path may be missing.
fn lenientRealPath(path: []const u8) ?[]const u8 {
    if (os.realPath(path)) |p| return p;
    var cur: []const u8 = path;
    var depth: usize = 0;
    while (depth < 32) : (depth += 1) {
        const st = os.lstatPath(cur) orelse break;
        if (st.mode & os.S_IFMT != os.S_IFLNK) return os.realPath(cur);
        const t = os.readLink(cur) orelse return null;
        if (t.len > 0 and t[0] == '/') {
            cur = t;
        } else {
            const d = if (std.mem.lastIndexOfScalar(u8, cur, '/')) |i| cur[0..i] else ".";
            cur = util.concat(&.{ d, "/", t });
        }
    }
    const sl = std.mem.lastIndexOfScalar(u8, cur, '/');
    const dir = if (sl) |i| (if (i == 0) "/" else cur[0..i]) else ".";
    const base = if (sl) |i| cur[i + 1 ..] else cur;
    const rd = os.realPath(dir) orelse return null;
    if (rd.len > 0 and rd[rd.len - 1] == '/') return util.concat(&.{ rd, base });
    return util.concat(&.{ rd, "/", base });
}

/// files_fsck_refs_content()
fn refContent(c: *Ctx, name: []const u8, path: []const u8, is_link: bool) i32 {
    if (is_link) {
        var ret = report(c, name, .symlink_ref, "use deprecated symbolic link for symref", .{});
        const r = repo_mod.repo();
        var gd: []const u8 = os.realPath(r.git_dir) orelse r.git_dir;
        if (gd.len == 0 or gd[gd.len - 1] != '/') gd = util.concat(&.{ gd, "/" });
        const real = lenientRealPath(path) orelse util.die("Invalid path '{s}'", .{path});
        const referent = util.skipPrefix(real, gd) orelse real;
        ret |= symrefTarget(c, name, name, referent, true);
        return ret;
    }
    const data = os.readFile(path) orelse {
        if (os.errno() == os.ENOENT) return 0;
        util.err("cannot read ref file '{s}': {s}", .{ path, os.lastErr() });
        return -1;
    };
    // parse_loose_ref_contents()
    if (util.skipPrefix(data, "ref:")) |rest0| {
        var rest = rest0;
        while (rest.len > 0 and isSpace(rest[0])) rest = rest[1..];
        // strbuf_addstr() stops at a NUL
        if (std.mem.indexOfScalar(u8, rest, 0)) |n| rest = rest[0..n];
        return symrefTarget(c, name, name, rest, false);
    }
    const hexsz: usize = 40;
    const oid: ?Oid = if (data.len >= hexsz) hash.fromHex(data[0..hexsz]) else null;
    if (oid == null or (data.len > hexsz and data[hexsz] != 0 and !isSpace(data[hexsz]))) {
        var shown = data;
        if (std.mem.indexOfScalar(u8, shown, 0)) |n| shown = shown[0..n];
        return report(c, name, .bad_ref_content, "{s}", .{rtrim(shown)});
    }
    var trailing = data[hexsz..];
    if (std.mem.indexOfScalar(u8, trailing, 0)) |n| trailing = trailing[0..n];
    if (trailing.len == 0) return report(c, name, .ref_missing_newline, "misses LF at the end", .{});
    if (trailing[0] != '\n' or trailing.len > 1)
        return report(c, name, .trailing_ref_content, "has trailing garbage: '{s}'", .{trailing});
    return checkRef(c, name, oid.?);
}

/// files_fsck_ref()
fn fsckOne(c: *Ctx, name: []const u8, path: []const u8, mode: u32) i32 {
    if (c.verbose) util.eprint("Checking {s}\n", .{name});
    const fmt_ = mode & os.S_IFMT;
    const is_reg = fmt_ == os.S_IFREG;
    const is_link = fmt_ == os.S_IFLNK;
    if (!is_reg and !is_link) {
        return if (report(c, name, .bad_ref_filetype, "unexpected file type", .{}) != 0) -1 else 0;
    }
    var ret: i32 = 0;
    // files_fsck_refs_name()
    if (!refs.isRootRef(name) and !refs.checkRefnameFormat(name, 0)) {
        if (report(c, name, .bad_ref_name, "invalid refname format", .{}) != 0) ret = -1;
    }
    if (refContent(c, name, path, is_link) != 0) ret = -1;
    return ret;
}

fn walkRefsDir(c: *Ctx, dir: []const u8, rel: []const u8, prefix: []const u8, ret: *i32) void {
    const ents = os.listDir(dir) orelse return;
    for (ents) |e| {
        if (util.eql(e.name, ".") or util.eql(e.name, "..")) continue;
        const path = util.concat(&.{ dir, "/", e.name });
        const st = os.lstatPath(path) orelse continue;
        const relp = if (rel.len == 0) e.name else util.concat(&.{ rel, "/", e.name });
        if (st.mode & os.S_IFMT == os.S_IFDIR) {
            walkRefsDir(c, path, relp, prefix, ret);
            continue;
        }
        if (e.name.len > 0 and e.name[0] != '.' and util.endsWith(e.name, ".lock")) continue;
        if (fsckOne(c, util.concat(&.{ prefix, "refs/", relp }), path, st.mode) < 0) ret.* = -1;
    }
}

/// files_fsck()
pub fn filesFsck(c: *Ctx, wt_id: ?[]const u8) i32 {
    const r = repo_mod.repo();
    var ret: i32 = 0;
    const gitdir = if (wt_id) |id| util.concat(&.{ r.common_dir, "/worktrees/", id }) else r.common_dir;
    const prefix = if (wt_id) |id| util.concat(&.{ "worktrees/", id, "/" }) else "";

    // files_fsck_refs_dir()
    const refs_dir = util.concat(&.{ gitdir, "/refs" });
    if (!os.isDir(refs_dir)) {
        if (!(os.errno() == os.ENOENT and wt_id != null)) {
            util.err("cannot open directory {s}: {s}", .{ refs_dir, os.lastErr() });
            ret = -1;
        }
    } else walkRefsDir(c, refs_dir, "", prefix, &ret);

    // for_each_root_ref()
    if (os.listDir(gitdir)) |ents| {
        for (ents) |e| {
            if (e.name.len == 0 or e.name[0] == '.') continue;
            if (util.endsWith(e.name, ".lock")) continue;
            const path = util.concat(&.{ gitdir, "/", e.name });
            const st = os.statPath(path) orelse continue;
            if (st.mode & os.S_IFMT != os.S_IFREG) continue;
            if (!refs.isRootRef(e.name)) continue;
            if (fsckOne(c, util.concat(&.{ prefix, e.name }), path, st.mode) < 0) ret = -1;
        }
    }

    if (packedFsck(c, wt_id) < 0) ret = -1;
    return ret;
}

// ---------------------------------------------------------------- packed-refs

fn lineName(n: usize) []const u8 {
    return util.fmt("packed-refs line {d}", .{n});
}

fn nextLine(c: *Ctx, n: usize, data: []const u8, start: usize, eol: *usize) i32 {
    if (std.mem.indexOfScalarPos(u8, data, start, '\n')) |e| {
        eol.* = e;
        return 0;
    }
    eol.* = data.len;
    return report(c, lineName(n), .packed_ref_entry_not_terminated, "'{s}' is not terminated with a newline", .{data[start..]});
}

fn parseOid(s: []const u8) ?Oid {
    if (s.len < 40) return null;
    return hash.fromHex(s[0..40]);
}

fn mainLine(c: *Ctx, n: usize, line: []const u8, refname: *[]const u8) i32 {
    const oid = parseOid(line) orelse
        return report(c, lineName(n), .bad_packed_ref_entry, "'{s}' has invalid oid", .{line});
    const p = line[40..];
    if (p.len == 0 or !isSpace(p[0]))
        return report(c, lineName(n), .bad_packed_ref_entry, "has no space after oid '{s}' but with '{s}'", .{ hash.hex(oid), p });
    const name = p[1..];
    refname.* = name;
    var ret: i32 = 0;
    if (std.mem.indexOfScalar(u8, name, 0) != null) {
        const shown = name[0..std.mem.indexOfScalar(u8, name, 0).?];
        ret = report(c, lineName(n), .bad_packed_ref_entry, "refname '{s}' contains NULL binaries", .{shown});
    }
    if (!refs.checkRefnameFormat(name, 0))
        ret = report(c, lineName(n), .bad_ref_name, "has bad refname '{s}'", .{name});
    return ret;
}

fn peeledLine(c: *Ctx, n: usize, line0: []const u8) i32 {
    const line = line0[1..];
    _ = parseOid(line) orelse
        return report(c, lineName(n), .bad_packed_ref_entry, "'{s}' has invalid peeled oid", .{line});
    if (line.len != 40)
        return report(c, lineName(n), .bad_packed_ref_entry, "has trailing garbage after peeled oid '{s}'", .{line[40..]});
    return 0;
}

/// cmp_packed_refname(): compare up to the end of line.
fn cmpPacked(a: []const u8, b: []const u8) std.math.Order {
    const ea = std.mem.indexOfScalar(u8, a, '\n') orelse a.len;
    const eb = std.mem.indexOfScalar(u8, b, '\n') orelse b.len;
    return std.mem.order(u8, a[0..ea], b[0..eb]);
}

fn checkSorted(c: *Ctx, data: []const u8) i32 {
    const hexsz: usize = 40;
    var start: usize = 0;
    var n: usize = 1;
    if (data.len > 0 and data[0] == '#') {
        const e = std.mem.indexOfScalar(u8, data, '\n') orelse data.len;
        start = e + 1;
        n += 1;
    }
    var former: ?[]const u8 = null;
    while (start < data.len) : (n += 1) {
        const eol = std.mem.indexOfScalarPos(u8, data, start, '\n') orelse data.len;
        defer start = eol + 1;
        if (data[start] == '^') continue;
        if (start + hexsz + 1 > data.len) continue;
        const cur = data[start + hexsz + 1 ..];
        if (former) |f| {
            if (cmpPacked(f, cur) != .lt) {
                const e1 = std.mem.indexOfScalar(u8, f, '\n') orelse f.len;
                const e2 = std.mem.indexOfScalar(u8, cur, '\n') orelse cur.len;
                return report(c, lineName(n), .packed_ref_unsorted, "refname '{s}' is less than previous refname '{s}'", .{ cur[0..e2], f[0..e1] });
            }
        }
        former = cur;
    }
    return 0;
}

/// packed_fsck()
fn packedFsck(c: *Ctx, wt_id: ?[]const u8) i32 {
    if (wt_id != null) return 0;
    const path = repo_mod.repo().commonPath("packed-refs");
    if (c.verbose) util.eprint("Checking packed-refs file {s}\n", .{path});
    const st = os.lstatPath(path) orelse {
        if (os.errno() == os.ENOENT) return 0;
        util.err("unable to open '{s}': {s}", .{ path, os.lastErr() });
        return -1;
    };
    if (st.mode & os.S_IFMT == os.S_IFLNK)
        return report(c, "packed-refs", .bad_ref_filetype, "not a regular file but a symlink", .{});
    if (st.mode & os.S_IFMT != os.S_IFREG)
        return report(c, "packed-refs", .bad_ref_filetype, "not a regular file", .{});
    const data = os.readFile(path) orelse {
        util.err("unable to open '{s}': {s}", .{ path, os.lastErr() });
        return -1;
    };
    if (data.len == 0) return report(c, "packed-refs", .empty_packed_refs_file, "file is empty", .{});

    // packed_fsck_ref_content()
    var ret: i32 = 0;
    var sorted = false;
    var n: usize = 1;
    var start: usize = 0;
    var eol: usize = 0;
    ret |= nextLine(c, n, data, start, &eol);
    if (data[0] == '#') {
        const line = data[0..eol];
        if (util.skipPrefix(line, "# pack-refs with: ")) |traits| {
            var it = std.mem.splitScalar(u8, traits, ' ');
            while (it.next()) |t| {
                if (util.eql(t, "sorted")) sorted = true;
            }
        } else {
            ret |= report(c, "packed-refs.header", .bad_packed_ref_header, "'{s}' does not start with '# pack-refs with: '", .{line});
        }
        start = eol + 1;
        n += 1;
    }
    var refname: []const u8 = "";
    while (start < data.len) {
        ret |= nextLine(c, n, data, start, &eol);
        ret |= mainLine(c, n, data[start..eol], &refname);
        start = eol + 1;
        n += 1;
        if (start < data.len and data[start] == '^') {
            ret |= nextLine(c, n, data, start, &eol);
            ret |= peeledLine(c, n, data[start..eol]);
            start = eol + 1;
            n += 1;
        }
    }
    if (ret == 0 and sorted) ret = checkSorted(c, data);
    return ret;
}
