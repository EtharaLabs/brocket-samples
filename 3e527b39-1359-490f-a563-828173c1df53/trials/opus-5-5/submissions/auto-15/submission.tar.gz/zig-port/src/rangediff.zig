//! range-diff.c + linear-assignment.c port.
//!
//! API: `show(range1, range2, &Options{...}) u8` (0 on success, 1 on error),
//! `isRangeDiffRange(arg)`.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const diff = @import("diff.zig");
const xdiff = @import("xdiff.zig");
const apply = @import("apply.zig");
const revparse = @import("revparse.zig");
const revision = @import("revision.zig");
const cn = @import("commitnode.zig");
const pretty = @import("pretty.zig");
const userdiff = @import("userdiff.zig");
const gpa = util.gpa;
const Buf = util.Buf;
const Oid = hash.Oid;

pub const CREATION_FACTOR_DEFAULT: i32 = 60;
pub const MAX_MEMORY_DEFAULT: u64 = 4 * 1024 * 1024 * 1024;
pub const COST_MAX: i32 = 1 << 16;

pub const Options = struct {
    creation_factor: i32 = CREATION_FACTOR_DEFAULT,
    dual_color: bool = false,
    left_only: bool = false,
    right_only: bool = false,
    include_merges: bool = false,
    max_memory: u64 = MAX_MEMORY_DEFAULT,
    /// diff options used for the output (null: default porcelain options)
    diffopt: ?*diff.DiffOptions = null,
    /// extra arguments passed to `git log`
    log_arg: []const []const u8 = &.{},
};

const PatchUtil = struct {
    patch: []const u8 = "",
    diff: []const u8 = "",
    i: usize = 0,
    shown: bool = false,
    diffsize: i32 = 0,
    diff_offset: usize = 0,
    matching: i32 = -1,
    oid: Oid = hash.zero,
};

fn selfExe() []const u8 {
    return os.readLink("/proc/self/exe") orelse "git";
}

fn readPatches(range: []const u8, list: *std.ArrayList(*PatchUtil), log_arg: []const []const u8, include_merges: bool) bool {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{
        selfExe(),                         "log",                         "--no-color",                    "-p",
        "--reverse",                       "--date-order",                "--decorate=no",                 "--no-prefix",
        "--submodule=short",               "--output-indicator-new=>",    "--output-indicator-old=<",      "--output-indicator-context=#",
        "--no-abbrev-commit",              "--pretty=medium",             "--show-notes-by-default",
    }) catch util.oom();
    if (!include_merges) argv.append(gpa, "--no-merges") catch util.oom();
    argv.append(gpa, range) catch util.oom();
    argv.appendSlice(gpa, log_arg) catch util.oom();
    const res = os.run(argv.items, .{ .capture_stdout = true, .no_stdin = true });
    if (res.status != 0) return false;
    const contents = res.stdout;

    var buf: Buf = .empty;
    var cur: ?*PatchUtil = null;
    var in_header = true;
    var current_filename: ?[]const u8 = null;
    var pos: usize = 0;
    while (pos < contents.len) {
        const rest = contents[pos..];
        var len: usize = undefined;
        var line: []const u8 = undefined;
        if (std.mem.indexOfScalar(u8, rest, '\n')) |e| {
            line = rest[0..e];
            len = e + 1;
        } else {
            line = rest;
            len = rest.len;
        }
        defer pos += len;

        if (util.skipPrefix(line, "commit ")) |p0| {
            var p = p0;
            if (cur) |u| {
                u.patch = util.dupe(buf.items);
                list.append(gpa, u) catch util.oom();
                buf = .empty;
            }
            const u = gpa.create(PatchUtil) catch util.oom();
            u.* = .{};
            if (include_merges) {
                if (std.mem.indexOf(u8, p, " (from ")) |q| p = p[0..q];
            }
            u.oid = revparse.getOid(p) orelse {
                util.err("could not parse commit '{s}'", .{p});
                return false;
            };
            cur = u;
            in_header = true;
            continue;
        }
        const u = cur orelse {
            util.err("could not parse first line of `log` output: did not start with 'commit ': '{s}'", .{line});
            return false;
        };

        if (util.startsWith(line, "diff --git")) {
            in_header = false;
            util.bufByte(&buf, '\n');
            if (u.diff_offset == 0) u.diff_offset = buf.items.len;
            var patch = apply.Patch{};
            const root: Buf = .empty;
            var linenr: i32 = 0;
            const r = apply.parseGitDiffHeader(&root, null, &linenr, 0, rest, len, rest.len, &patch);
            if (r < 0) {
                util.err("could not parse git header '{s}'", .{rest[0..len]});
                return false;
            }
            len = @intCast(r);
            util.bufAppend(&buf, " ## ");
            const new_name = patch.new_name orelse "";
            const old_name = patch.old_name orelse "";
            if (patch.is_new > 0) {
                util.bufPrint(&buf, "{s} (new)", .{new_name});
            } else if (patch.is_delete > 0) {
                util.bufPrint(&buf, "{s} (deleted)", .{old_name});
            } else if (patch.is_rename) {
                util.bufPrint(&buf, "{s} => {s}", .{ old_name, new_name });
            } else util.bufAppend(&buf, new_name);
            current_filename = if (patch.is_delete > 0) old_name else new_name;
            if (patch.new_mode != 0 and patch.old_mode != 0 and patch.old_mode != patch.new_mode)
                util.bufPrint(&buf, " (mode change {o:0>6} => {o:0>6})", .{ patch.old_mode, patch.new_mode });
            util.bufAppend(&buf, " ##");
        } else if (in_header) {
            if (util.startsWith(line, "Author: ")) {
                util.bufAppend(&buf, " ## Metadata ##\n");
                util.bufAppend(&buf, line);
                util.bufAppend(&buf, "\n\n");
                util.bufAppend(&buf, " ## Commit message ##\n");
            } else if (util.startsWith(line, "Notes") and line[line.len - 1] == ':') {
                util.bufAppend(&buf, "\n\n");
                util.bufPrint(&buf, " ## {s} ##\n", .{line[0 .. line.len - 1]});
            } else if (util.startsWith(line, "    ")) {
                var e = line.len;
                while (e > 0 and std.ascii.isWhitespace(line[e - 1])) e -= 1;
                util.bufAppend(&buf, line[0..e]);
                util.bufByte(&buf, '\n');
            }
            continue;
        } else if (util.skipPrefix(line, "@@ ")) |p0| {
            util.bufAppend(&buf, "@@");
            if (std.mem.indexOf(u8, p0, "@@")) |q| {
                const after = p0[q + 2 ..];
                if (current_filename != null and after.len > 0)
                    util.bufPrint(&buf, " {s}:", .{current_filename.?});
                util.bufAppend(&buf, after);
            }
        } else if (line.len == 0) {
            continue;
        } else if (line[0] == '>') {
            util.bufByte(&buf, '+');
            util.bufAppend(&buf, line[1..]);
        } else if (line[0] == '<') {
            util.bufByte(&buf, '-');
            util.bufAppend(&buf, line[1..]);
        } else if (line[0] == '#') {
            util.bufByte(&buf, ' ');
            util.bufAppend(&buf, line[1..]);
        } else {
            util.bufByte(&buf, ' ');
            util.bufAppend(&buf, line);
        }
        util.bufByte(&buf, '\n');
        u.diffsize += 1;
    }
    if (cur) |u| {
        u.patch = util.dupe(buf.items);
        list.append(gpa, u) catch util.oom();
    }
    return true;
}

fn findExactMatches(a: []*PatchUtil, b: []*PatchUtil) void {
    var in_map = gpa.alloc(bool, a.len) catch util.oom();
    for (a, 0..) |u, i| {
        u.i = i;
        u.diff = u.patch[u.diff_offset..];
        in_map[i] = true;
    }
    for (b, 0..) |u, i| {
        u.i = i;
        u.diff = u.patch[u.diff_offset..];
        // hashmap_add() prepends, so the most recently added entry wins
        var k = a.len;
        while (k > 0) {
            k -= 1;
            if (in_map[k] and util.eql(a[k].diff, u.diff)) {
                in_map[k] = false;
                a[k].matching = @intCast(i);
                u.matching = @intCast(k);
                break;
            }
        }
    }
}

fn diffsizeConsume(ctx: *anyopaque, line: []const u8) void {
    _ = line;
    const c: *i32 = @ptrCast(@alignCast(ctx));
    c.* += 1;
}

fn diffsize(a: []const u8, b: []const u8) i32 {
    var count: i32 = 0;
    const flags = xdiff.Flags{ .indent_heuristic = false };
    if (diff.xdiDiffOutf(a, b, flags, .{ .context = 3, .funcnames = false }, &count, diffsizeConsume)) return count;
    util.err("failed to generate diff", .{});
    return COST_MAX;
}

/// compute_assignment(): cost[j + column_count * i] is the cost of assigning
/// column j to row i.
pub fn computeAssignment(column_count: usize, row_count: usize, cost: []const i32, column2row: []i32, row2column: []i32) void {
    const cc: i32 = @intCast(column_count);
    const COST = struct {
        fn f(c: []const i32, n: usize, col: i32, row: i32) i32 {
            return c[@as(usize, @intCast(col)) + n * @as(usize, @intCast(row))];
        }
    }.f;
    if (column_count < 2) {
        @memset(column2row, 0);
        @memset(row2column, 0);
        return;
    }
    @memset(column2row, -1);
    @memset(row2column, -1);
    const v = gpa.alloc(i32, column_count) catch util.oom();
    const rc: i32 = @intCast(row_count);

    // column reduction
    var j: i32 = cc - 1;
    while (j >= 0) : (j -= 1) {
        var i_1: i32 = 0;
        var i: i32 = 1;
        while (i < rc) : (i += 1) {
            if (COST(cost, column_count, j, i_1) > COST(cost, column_count, j, i)) i_1 = i;
        }
        v[@intCast(j)] = COST(cost, column_count, j, i_1);
        const ri: usize = @intCast(i_1);
        if (row2column[ri] == -1) {
            row2column[ri] = j;
            column2row[@intCast(j)] = i_1;
        } else {
            if (row2column[ri] >= 0) row2column[ri] = -2 - row2column[ri];
            column2row[@intCast(j)] = -1;
        }
    }

    // reduction transfer
    const free_row = gpa.alloc(i32, row_count) catch util.oom();
    var free_count: usize = 0;
    {
        var i: i32 = 0;
        while (i < rc) : (i += 1) {
            const j1 = row2column[@intCast(i)];
            if (j1 == -1) {
                free_row[free_count] = i;
                free_count += 1;
            } else if (j1 < -1) {
                row2column[@intCast(i)] = -2 - j1;
            } else {
                const nj1: i32 = if (j1 == 0) 1 else 0;
                var min = COST(cost, column_count, nj1, i) - v[@intCast(nj1)];
                var jj: i32 = 1;
                while (jj < cc) : (jj += 1) {
                    if (jj != j1 and min > COST(cost, column_count, jj, i) - v[@intCast(jj)])
                        min = COST(cost, column_count, jj, i) - v[@intCast(jj)];
                }
                v[@intCast(j1)] -= min;
            }
        }
    }

    if (free_count == (if (column_count < row_count) row_count - column_count else 0)) return;

    // augmenting row reduction
    var phase: usize = 0;
    while (phase < 2) : (phase += 1) {
        var k: usize = 0;
        const saved_free_count = free_count;
        free_count = 0;
        while (k < saved_free_count) {
            var j1: i32 = 0;
            const i = free_row[k];
            k += 1;
            var u_1 = COST(cost, column_count, j1, i) - v[@intCast(j1)];
            var j2: i32 = -1;
            var u_2: i32 = std.math.maxInt(i32);
            var jj: i32 = 1;
            while (jj < cc) : (jj += 1) {
                const c = COST(cost, column_count, jj, i) - v[@intCast(jj)];
                if (u_2 > c) {
                    if (u_1 < c) {
                        u_2 = c;
                        j2 = jj;
                    } else {
                        u_2 = u_1;
                        u_1 = c;
                        j2 = j1;
                        j1 = jj;
                    }
                }
            }
            if (j2 < 0) {
                j2 = j1;
                u_2 = u_1;
            }
            var i_0 = column2row[@intCast(j1)];
            if (u_1 < u_2) {
                v[@intCast(j1)] -%= u_2 -% u_1;
            } else if (i_0 >= 0) {
                j1 = j2;
                i_0 = column2row[@intCast(j1)];
            }
            if (i_0 >= 0) {
                if (u_1 < u_2) {
                    k -= 1;
                    free_row[k] = i_0;
                } else {
                    free_row[free_count] = i_0;
                    free_count += 1;
                }
            }
            row2column[@intCast(i)] = j1;
            column2row[@intCast(j1)] = i;
        }
    }

    // augmentation
    const saved_free_count = free_count;
    const d = gpa.alloc(i32, column_count) catch util.oom();
    const pred = gpa.alloc(i32, column_count) catch util.oom();
    const col = gpa.alloc(i32, column_count) catch util.oom();
    free_count = 0;
    while (free_count < saved_free_count) : (free_count += 1) {
        const i_1 = free_row[free_count];
        var low: usize = 0;
        var up: usize = 0;
        var last: usize = 0;
        var min: i32 = 0;
        var jx: usize = 0;
        while (jx < column_count) : (jx += 1) {
            d[jx] = COST(cost, column_count, @intCast(jx), i_1) - v[jx];
            pred[jx] = i_1;
            col[jx] = @intCast(jx);
        }
        var jcur: i32 = -1;
        search: while (true) {
            last = low;
            min = d[@intCast(col[up])];
            up += 1;
            var k: usize = up;
            while (k < column_count) : (k += 1) {
                jcur = col[k];
                const c = d[@intCast(jcur)];
                if (c <= min) {
                    if (c < min) {
                        up = low;
                        min = c;
                    }
                    col[k] = col[up];
                    col[up] = jcur;
                    up += 1;
                }
            }
            k = low;
            while (k < up) : (k += 1) {
                // NB: like git, `j` is not updated here
                if (column2row[@intCast(col[k])] == -1) break :search;
            }
            // scan a row
            while (true) {
                const j1 = col[low];
                low += 1;
                const i = column2row[@intCast(j1)];
                const u_1 = COST(cost, column_count, j1, i) - v[@intCast(j1)] - min;
                k = up;
                while (k < column_count) : (k += 1) {
                    jcur = col[k];
                    const c = COST(cost, column_count, jcur, i) - v[@intCast(jcur)] - u_1;
                    if (c < d[@intCast(jcur)]) {
                        d[@intCast(jcur)] = c;
                        pred[@intCast(jcur)] = i;
                        if (c == min) {
                            if (column2row[@intCast(jcur)] == -1) break :search;
                            col[k] = col[up];
                            col[up] = jcur;
                            up += 1;
                        }
                    }
                }
                if (low == up) break;
            }
            if (low != up) break;
        }
        // update
        var k: usize = 0;
        while (k < last) : (k += 1) {
            const j1: usize = @intCast(col[k]);
            v[j1] += d[j1] - min;
        }
        // augmentation
        while (true) {
            if (jcur < 0) util.die("BUG: negative j: {d}", .{jcur});
            const i = pred[@intCast(jcur)];
            column2row[@intCast(jcur)] = i;
            const tmp = row2column[@intCast(i)];
            row2column[@intCast(i)] = jcur;
            jcur = tmp;
            if (i_1 == i) break;
        }
    }
}

fn humaniseBytes(b: *Buf, bytes: u64) void {
    if (bytes > 1 << 30) {
        util.bufPrint(b, "{d}.{d:0>2} GiB", .{ bytes >> 30, @as(u32, @truncate(bytes & ((1 << 30) - 1))) / 10737419 });
    } else if (bytes > 1 << 20) {
        const x: u32 = @truncate(bytes + 5243);
        util.bufPrint(b, "{d}.{d:0>2} MiB", .{ x >> 20, ((x & ((1 << 20) - 1)) * 100) >> 20 });
    } else if (bytes > 1 << 10) {
        const x: u32 = @truncate(bytes + 5);
        util.bufPrint(b, "{d}.{d:0>2} KiB", .{ x >> 10, ((x & ((1 << 10) - 1)) * 100) >> 10 });
    } else {
        util.bufPrint(b, "{d} {s}", .{ bytes, if (bytes == 1) "byte" else "bytes" });
    }
}

fn getCorrespondences(a: []*PatchUtil, b: []*PatchUtil, creation_factor: i32, max_memory: u64) void {
    const n = a.len + b.len;
    const cost_bytes: u64 = @as(u64, n) * @as(u64, n) * 4;
    if (cost_bytes >= max_memory) {
        var cs: Buf = .empty;
        var ms: Buf = .empty;
        humaniseBytes(&cs, cost_bytes);
        humaniseBytes(&ms, max_memory);
        util.die("range-diff: unable to compute the range-diff, since it exceeds the maximum memory for the cost matrix: {s} ({d} bytes) needed, limited to {s} ({d} bytes)", .{ cs.items, cost_bytes, ms.items, max_memory });
    }
    const cost = gpa.alloc(i32, n * n) catch util.oom();
    const a2b = gpa.alloc(i32, n) catch util.oom();
    const b2a = gpa.alloc(i32, n) catch util.oom();
    for (a, 0..) |au, i| {
        for (b, 0..) |bu, j| {
            const c: i32 = if (au.matching == @as(i32, @intCast(j)))
                0
            else if (au.matching < 0 and bu.matching < 0)
                diffsize(au.diff, bu.diff)
            else
                COST_MAX;
            cost[i + n * j] = c;
        }
        const c: i32 = if (au.matching < 0) @divTrunc(au.diffsize * creation_factor, 100) else COST_MAX;
        var j = b.len;
        while (j < n) : (j += 1) cost[i + n * j] = c;
    }
    for (b, 0..) |bu, j| {
        const c: i32 = if (bu.matching < 0) @divTrunc(bu.diffsize * creation_factor, 100) else COST_MAX;
        var i = a.len;
        while (i < n) : (i += 1) cost[i + n * j] = c;
    }
    var i = a.len;
    while (i < n) : (i += 1) {
        var j = b.len;
        while (j < n) : (j += 1) cost[i + n * j] = 0;
    }
    computeAssignment(n, n, cost, a2b, b2a);
    for (a, 0..) |au, k| {
        if (a2b[k] >= 0 and a2b[k] < @as(i32, @intCast(b.len))) {
            const bu = b[@intCast(a2b[k])];
            au.matching = a2b[k];
            bu.matching = @intCast(k);
        }
    }
}

fn abbrevOid(oid: Oid, abbrev: i32) []const u8 {
    if (abbrev == 0) return hash.hexAlloc(oid);
    return revparse.abbrev(oid, if (abbrev < 0) 0 else @intCast(abbrev));
}

fn outputPairHeader(o: *diff.DiffOptions, width: usize, dashes: *Buf, a_util: ?*PatchUtil, b_util: ?*PatchUtil) void {
    const oid = if (a_util) |u| u.oid else b_util.?.oid;
    const color_reset = diff.getColor(o, .reset);
    const color_old = diff.getColor(o, .old);
    const color_new = diff.getColor(o, .new);
    const color_commit = diff.getColor(o, .commit);
    const abbrev = o.abbrev;
    if (dashes.items.len == 0) {
        const l = abbrevOid(oid, abbrev).len;
        for (0..l) |_| util.bufByte(dashes, '-');
    }
    var colr: []const u8 = undefined;
    var status: u8 = undefined;
    if (b_util == null) {
        colr = color_old;
        status = '<';
    } else if (a_util == null) {
        colr = color_new;
        status = '>';
    } else if (!util.eql(a_util.?.patch, b_util.?.patch)) {
        colr = color_commit;
        status = '!';
    } else {
        colr = color_commit;
        status = '=';
    }
    var buf: Buf = .empty;
    util.bufAppend(&buf, if (status == '!') color_old else colr);
    if (a_util) |u| {
        padNum(&buf, width, u.i + 1);
        util.bufPrint(&buf, ":  {s} ", .{abbrevOid(u.oid, abbrev)});
    } else {
        padStr(&buf, width, "-");
        util.bufPrint(&buf, ":  {s} ", .{dashes.items});
    }
    if (status == '!') util.bufPrint(&buf, "{s}{s}", .{ color_reset, colr });
    util.bufByte(&buf, status);
    if (status == '!') util.bufPrint(&buf, "{s}{s}", .{ color_reset, color_new });
    if (b_util) |u| {
        util.bufByte(&buf, ' ');
        padNum(&buf, width, u.i + 1);
        util.bufPrint(&buf, ":  {s}", .{abbrevOid(u.oid, abbrev)});
    } else {
        util.bufByte(&buf, ' ');
        padStr(&buf, width, "-");
        util.bufPrint(&buf, ":  {s}", .{dashes.items});
    }
    if (cn.lookupCommitReference(oid)) |commit| {
        if (status == '!') util.bufPrint(&buf, "{s}{s}", .{ color_reset, colr });
        util.bufByte(&buf, ' ');
        pretty.ppCommitEasy(.oneline, commit, &buf);
    }
    util.bufPrint(&buf, "{s}\n", .{color_reset});
    o.out().write(buf.items);
}

fn padStr(b: *Buf, width: usize, s: []const u8) void {
    var k = s.len;
    while (k < width) : (k += 1) util.bufByte(b, ' ');
    util.bufAppend(b, s);
}

fn padNum(b: *Buf, width: usize, v: usize) void {
    padStr(b, width, util.fmt("{d}", .{v}));
}

var section_headers = userdiff.Driver{
    .name = "range-diff-section-headers",
    .funcname = "^ ## (.*) ##$\n^.?@@ (.*)$",
    .funcname_extended = true,
};

fn getFilespec(name: []const u8, p: []const u8) *diff.Filespec {
    const s = diff.allocFilespec(name, hash.zero, false, 0o100644);
    s.data = p;
    s.size = p.len;
    s.is_stdin = true;
    s.driver = &section_headers;
    return s;
}

fn patchDiff(a: []const u8, b: []const u8, o: *diff.DiffOptions) void {
    _ = diff.queuePair(getFilespec("a", a), getFilespec("b", b));
    diff.diffcoreStd(o);
    diff.flush(o);
}

fn decimalWidth(v: usize) usize {
    var w: usize = 1;
    var x = v;
    while (x >= 10) : (x /= 10) w += 1;
    return w;
}

fn output(a: []*PatchUtil, b: []*PatchUtil, ro: *const Options) void {
    const width = decimalWidth(1 + @max(a.len, b.len));
    var dashes: Buf = .empty;
    var opts: diff.DiffOptions = if (ro.diffopt) |d| d.* else diff.DiffOptions.init();
    if (opts.output_format == 0) opts.output_format = diff.FMT_PATCH;
    opts.flags.suppress_diff_headers = true;
    opts.flags.dual_color_diffed_diffs = ro.dual_color;
    opts.flags.suppress_hunk_header_line_count = true;
    opts.line_prefix = "    ";
    opts.setupDone();

    var i: usize = 0;
    var j: usize = 0;
    while (i < a.len or j < b.len) {
        while (i < a.len and a[i].shown) i += 1;
        if (i < a.len and a[i].matching < 0) {
            if (!ro.right_only) outputPairHeader(&opts, width, &dashes, a[i], null);
            i += 1;
            continue;
        }
        while (j < b.len and b[j].matching < 0) {
            if (!ro.left_only) outputPairHeader(&opts, width, &dashes, null, b[j]);
            j += 1;
        }
        if (j < b.len) {
            const au = a[@intCast(b[j].matching)];
            outputPairHeader(&opts, width, &dashes, au, b[j]);
            if (opts.output_format & diff.FMT_NO_OUTPUT == 0)
                patchDiff(au.patch, b[j].patch, &opts);
            au.shown = true;
            j += 1;
        }
    }
}

/// show_range_diff(): returns 0 on success, 1 on error (error already printed)
pub fn show(range1: []const u8, range2: []const u8, ro: *const Options) u8 {
    if (ro.left_only and ro.right_only) {
        util.err("options '{s}' and '{s}' cannot be used together", .{ "--left-only", "--right-only" });
        return 1;
    }
    var b1: std.ArrayList(*PatchUtil) = .empty;
    var b2: std.ArrayList(*PatchUtil) = .empty;
    if (!readPatches(range1, &b1, ro.log_arg, ro.include_merges)) {
        util.err("could not parse log for '{s}'", .{range1});
        return 1;
    }
    if (!readPatches(range2, &b2, ro.log_arg, ro.include_merges)) {
        util.err("could not parse log for '{s}'", .{range2});
        return 1;
    }
    findExactMatches(b1.items, b2.items);
    getCorrespondences(b1.items, b2.items, ro.creation_factor, ro.max_memory);
    output(b1.items, b2.items, ro);
    return 0;
}

/// is_range_diff_range()
pub fn isRangeDiffRange(arg: []const u8) bool {
    var revs = revision.RevInfo.init("");
    const argv = [_][]const u8{ "", arg, "--" };
    var positive: usize = 0;
    var negative: usize = 0;
    const left = revision.setupRevisions(&revs, &argv, .{});
    if (left.len == 1) {
        for (revs.pending.items) |p| {
            if (p.item.flags & cn.UNINTERESTING != 0) negative += 1 else positive += 1;
        }
        for (revs.pending.items) |p| {
            if (p.item.typ == .commit) cn.clearCommitMarks(cn.Commit.fromObj(p.item), cn.ALL_REV_FLAGS);
        }
    }
    return negative > 0 and positive > 0;
}
