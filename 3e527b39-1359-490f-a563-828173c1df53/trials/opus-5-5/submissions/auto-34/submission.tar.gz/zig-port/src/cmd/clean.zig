//! git clean

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const index_mod = @import("../index.zig");
const pathspec_mod = @import("../pathspec.zig");
const dir_mod = @import("../dir.zig");
const config = @import("../config.zig");
const gpa = util.gpa;

extern "c" fn rmdir(path: [*:0]const u8) c_int;
extern "c" fn unlink(path: [*:0]const u8) c_int;

const usage = [_][]const u8{"git clean [-d] [-f] [-i] [-n] [-q] [-e <pattern>] [-x | -X] [--] [<pathspec>...]"};

var exclude_list: std.ArrayList([]const u8) = .empty;

fn excludeCb(arg: ?[]const u8, unset: bool) void {
    _ = unset;
    exclude_list.append(gpa, arg.?) catch util.oom();
}

const REMOVE_DIR_KEEP_NESTED_GIT: u32 = 2;

var g_prefix: []const u8 = "";
var real_ocwd: ?[]const u8 = null;

fn quotePath(path: []const u8, prefix: []const u8) []const u8 {
    const rel = if (prefix.len > 0) util.relativePath(path, prefix) else path;
    return util.cquote(rel);
}

fn doRmdir(p: []const u8) bool {
    return rmdir(os.z(p)) == 0;
}
fn doUnlink(p: []const u8) bool {
    return unlink(os.z(p)) == 0;
}

fn warnErrno(comptime msg: []const u8, arg: []const u8) void {
    const e = os.errno();
    util.warn(msg ++ ": {s}", .{ arg, os.strErr(e) });
}

fn removeDirs(path0: []const u8, prefix: []const u8, force_flag: u32, dry_run: bool, quiet: bool, dir_gone: *bool) bool {
    var ret = false;
    dir_gone.* = true;
    var dels: std.ArrayList([]const u8) = .empty;

    if (force_flag & REMOVE_DIR_KEEP_NESTED_GIT != 0 and dir_mod.isNonbareRepositoryDir(path0)) {
        if (!quiet) {
            const q = quotePath(path0, prefix);
            if (dry_run) util.outf("Would skip repository {s}\n", .{q}) else util.outf("Skipping repository {s}\n", .{q});
        }
        dir_gone.* = false;
        return false;
    }

    const ents = os.listDir(path0) orelse {
        const ok = dry_run or doRmdir(path0);
        if (!ok) {
            warnErrno("failed to remove {s}", quotePath(path0, prefix));
            dir_gone.* = false;
            return true;
        }
        return false;
    };

    const base = if (path0.len > 0 and path0[path0.len - 1] != '/') util.concat(&.{ path0, "/" }) else path0;
    // readdir order is unspecified; git uses readdir order. Sort for determinism.
    std.mem.sort(os.DirEntry, ents, {}, struct {
        fn lt(_: void, a: os.DirEntry, b: os.DirEntry) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    for (ents) |de| {
        const name = de.name;
        const p = util.concat(&.{ base, name });
        const st = os.lstatPath(p) orelse {
            util.warn("could not lstat {s}\n: {s}", .{ p, os.strErr(os.errno()) });
            dir_gone.* = false;
            ret = true;
            break;
        };
        if (st.isDir()) {
            var gone = true;
            if (removeDirs(p, prefix, force_flag, dry_run, quiet, &gone)) ret = true;
            if (gone) {
                dels.append(gpa, quotePath(p, prefix)) catch util.oom();
            } else dir_gone.* = false;
            continue;
        }
        const ok = dry_run or doUnlink(p);
        if (ok) {
            dels.append(gpa, quotePath(p, prefix)) catch util.oom();
        } else {
            warnErrno("failed to remove {s}", quotePath(p, prefix));
            dir_gone.* = false;
            ret = true;
        }
    }

    if (dir_gone.*) {
        const rp = os.realPath(path0);
        if (real_ocwd != null and rp != null and util.eql(rp.?, real_ocwd.?)) {
            util.out(if (dry_run) "Would refuse to remove current working directory\n" else "Refusing to remove current working directory\n");
            dir_gone.* = false;
        } else {
            const ok = dry_run or doRmdir(path0);
            if (ok) {
                dir_gone.* = true;
            } else {
                warnErrno("failed to remove {s}", quotePath(path0, prefix));
                dir_gone.* = false;
                ret = true;
            }
        }
    }

    if (!dir_gone.* and !quiet) {
        for (dels.items) |d| {
            if (dry_run) util.outf("Would remove {s}\n", .{d}) else util.outf("Removing {s}\n", .{d});
        }
    }
    return ret;
}

fn containsEntry(out: []const u8, in: []const u8) bool {
    return out.len < in.len and out[out.len - 1] == '/' and std.mem.eql(u8, out, in[0..out.len]);
}

/// correct_untracked_entries()
fn correctUntracked(entries: []dir_mod.Entry, ignored: []const dir_mod.Entry) []dir_mod.Entry {
    var out: std.ArrayList(dir_mod.Entry) = .empty;
    var src: usize = 0;
    var ign: usize = 0;
    while (src < entries.len) : (src += 1) {
        while (ign < ignored.len and std.mem.order(u8, entries[src].name, ignored[ign].name) != .lt) ign += 1;
        if (ign < ignored.len and containsEntry(entries[src].name, ignored[ign].name)) {
            continue;
        }
        const ent = entries[src];
        src += 1;
        out.append(gpa, ent) catch util.oom();
        while (src < entries.len and containsEntry(ent.name, entries[src].name)) src += 1;
        src -= 1;
    }
    return out.items;
}

pub fn cmdClean(args: []const []const u8) u8 {
    const r = repo_mod.repo();
    const prefix = r.prefix;
    var quiet: i32 = 0;
    var dry_run = false;
    var force: i32 = 0;
    var interactive = false;
    var remove_directories = false;
    var ignored = false;
    var ignored_only = false;
    var rm_flags: u32 = REMOVE_DIR_KEEP_NESTED_GIT;
    const opts = [_]po.Opt{
        .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet, .help = "do not print names of files removed" },
        po.boolean('n', "dry-run", &dry_run, "dry run"),
        po.noComplete(po.counter('f', "force", &force, "force")),
        po.boolean('i', "interactive", &interactive, "interactive cleaning"),
        po.boolean('d', "", &remove_directories, "remove whole directories"),
        .{ .short = 'e', .long = "exclude", .kind = .callback, .cb = excludeCb, .argh = "pattern", .help = "add <pattern> to ignore rules", .noneg = true },
        po.boolean('x', "", &ignored, "remove ignored files, too"),
        po.boolean('X', "", &ignored_only, "remove only ignored files"),
    };

    var require_force: i32 = -1;
    if (repo_mod.cfg.getEntry("clean.requireforce")) |e| {
        if (e.value) |v| {
            require_force = if (config.parseBool(v) orelse util.die("bad boolean config value '{s}' for 'clean.requireforce'", .{v})) 1 else 0;
        } else require_force = 1;
    }

    po.prefix = prefix;
    const argv = po.parse(args[1..], &opts, &usage, .{});

    if (require_force != 0 and force == 0 and !interactive and !dry_run)
        util.die("clean.requireForce is true and -f not given: refusing to clean", .{});

    var d = dir_mod.Dir.init();
    if (force > 1) {
        rm_flags = 0;
    } else d.flags.skip_nested_git = true;
    d.flags.show_other_directories = true;

    if (ignored and ignored_only) util.die("options '{s}' and '{s}' cannot be used together", .{ "-x", "-X" });
    if (!ignored) d.setupStandardExcludes();
    if (ignored_only) d.flags.show_ignored = true;

    if (argv.len > 0) remove_directories = true;

    if (remove_directories and !ignored_only) {
        d.flags.show_ignored_too = true;
        if (!ignored) d.flags.show_ignored_too_mode_matching = true;
        d.flags.keep_untracked_contents = true;
    }

    const idx = index_mod.get();
    {
        const pl = d.addPatternList(dir_mod.EXC_CMDL, "--exclude option");
        for (exclude_list.items) |p| d.addPatternSrcpos(pl, p, 0);
    }

    const ps = pathspec_mod.parse(prefix, argv, .{ .prefer_cwd = true });

    if (prefix.len > 0) real_ocwd = os.realPath(prefix[0 .. prefix.len - 1]);

    _ = d.fill(idx, &ps);
    const entries = correctUntracked(d.entries.items, d.ignored.items);

    var del_list: std.ArrayList([]const u8) = .empty;
    for (entries) |ent| {
        if (!dir_mod.indexNameIsOther(idx, ent.name)) continue;
        var nm = ent.name;
        const st = os.lstatPath(nm) orelse blk: {
            if (nm.len > 1 and nm[nm.len - 1] == '/') nm = nm[0 .. nm.len - 1];
            break :blk os.lstatPath(nm) orelse util.die("Cannot lstat '{s}': {s}", .{ ent.name, os.strErr(os.errno()) });
        };
        if (st.isDir() and !remove_directories) continue;
        const rel = if (prefix.len > 0) util.relativePath(ent.name, prefix) else ent.name;
        del_list.append(gpa, rel) catch util.oom();
    }

    if (interactive and del_list.items.len > 0) {
        util.die("interactive clean is not supported", .{});
    }

    var errors: usize = 0;
    for (del_list.items) |item| {
        const abs_path = util.concat(&.{ prefix, item });
        const st = os.lstatPath(abs_path) orelse continue;
        if (st.isDir()) {
            var gone = true;
            if (removeDirs(abs_path, prefix, rm_flags, dry_run, quiet != 0, &gone)) errors += 1;
            if (gone and quiet == 0) {
                const q = util.cquote(item);
                if (dry_run) util.outf("Would remove {s}\n", .{q}) else util.outf("Removing {s}\n", .{q});
            }
        } else {
            const ok = dry_run or doUnlink(abs_path);
            if (!ok) {
                warnErrno("failed to remove {s}", util.cquote(item));
                errors += 1;
            } else if (quiet == 0) {
                const q = util.cquote(item);
                if (dry_run) util.outf("Would remove {s}\n", .{q}) else util.outf("Removing {s}\n", .{q});
            }
        }
    }
    return if (errors != 0) 1 else 0;
}
