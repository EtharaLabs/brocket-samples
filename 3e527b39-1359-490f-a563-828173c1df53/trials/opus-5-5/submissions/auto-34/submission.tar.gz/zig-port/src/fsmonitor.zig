//! fsmonitor integration (fsmonitor.c, fsmonitor-settings.c): the FSMN index
//! extension, core.fsmonitor hook protocol v1/v2 and the IPC hand-off to the
//! builtin daemon (fsmonitor_daemon.zig).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const ewah = @import("ewah.zig");
const index_mod = @import("index.zig");
const untracked_cache = @import("untracked_cache.zig");
const gpa = util.gpa;

const Index = index_mod.Index;
const Entry = index_mod.Entry;

pub const Mode = enum(i8) { incompatible = -1, disabled = 0, hook = 1, ipc = 2 };
const Reason = enum { untested, ok, bare };

const Settings = struct {
    mode: Mode = .disabled,
    reason: Reason = .untested,
    hook_path: ?[]const u8 = null,
};

var settings: ?Settings = null;

fn checkIncompatible() Reason {
    const r = repo_mod.repo_ orelse return .bare;
    if (r.work_tree == null) return .bare;
    return .ok;
}

fn setHook(path: []const u8) Settings {
    const reason = checkIncompatible();
    if (reason != .ok) return .{ .mode = .incompatible, .reason = reason };
    return .{ .mode = .hook, .reason = .ok, .hook_path = path };
}

fn setIpc() Settings {
    const reason = checkIncompatible();
    if (reason != .ok) return .{ .mode = .incompatible, .reason = reason };
    return .{ .mode = .ipc, .reason = .ok };
}

/// lookup_fsmonitor_settings()
fn lookup() Settings {
    if (repo_mod.repo_ == null) return .{ .mode = .disabled, .reason = .ok };
    var hook: ?[]const u8 = null;
    if (repo_mod.cfg.getEntry("core.fsmonitor")) |e| {
        if (e.value == null) return setIpc();
        if (config.parseBool(e.value.?)) |b| {
            if (b) return setIpc();
            return .{ .mode = .disabled, .reason = .ok };
        }
        hook = repo_mod.cfg.getPath("core.fsmonitor");
    } else {
        hook = os.getenv("GIT_TEST_FSMONITOR");
    }
    if (hook) |h| {
        if (h.len > 0) return setHook(h);
    }
    return .{ .mode = .disabled, .reason = .ok };
}

fn get() Settings {
    if (settings == null) settings = lookup();
    return settings.?;
}

/// fsm_settings__get_mode()
pub fn fsmMode() Mode {
    return get().mode;
}

fn enabled() bool {
    return @intFromEnum(fsmMode()) > @intFromEnum(Mode.disabled);
}

/// Message for fsm_settings__get_incompatible_msg(), or null.
pub fn incompatibleMsg() ?[]const u8 {
    return switch (get().reason) {
        .untested, .ok => null,
        .bare => util.concat(&.{ "bare repository '", os.getcwd(), "' is incompatible with fsmonitor" }),
    };
}

/// fsmonitor_hook_version()
fn hookVersion() i32 {
    const v = repo_mod.cfg.getInt("core.fsmonitorhookversion") orelse return -1;
    if (v == 1 or v == 2) return @intCast(v);
    util.warn("Invalid hook version '{d}' in core.fsmonitorhookversion. Must be 1 or 2.", .{v});
    return -1;
}

fn getNanoTime() u64 {
    return @as(u64, @intCast(os.nowMicros())) * 1000;
}

// ---------------- extension ----------------

/// read_fsmonitor_extension()
pub fn readExtension(idx: *Index, data: []const u8) void {
    if (data.len < 4 + 1 + 4) {
        util.err("corrupt fsmonitor extension (too short)", .{});
        return;
    }
    const hdr_version = std.mem.readInt(u32, data[0..4], .big);
    var p: usize = 4;
    var last: []const u8 = undefined;
    if (hdr_version == 1) {
        if (data.len < p + 8 + 4) {
            util.err("corrupt fsmonitor extension (too short)", .{});
            return;
        }
        const ts = std.mem.readInt(u64, data[p..][0..8], .big);
        last = util.fmt("{d}", .{ts});
        p += 8;
    } else if (hdr_version == 2) {
        const nul = std.mem.indexOfScalarPos(u8, data, p, 0) orelse data.len;
        last = util.dupe(data[p..nul]);
        p = nul + 1;
    } else {
        util.err("bad fsmonitor version {d}", .{hdr_version});
        return;
    }
    idx.fsmonitor_last_update = last;
    if (data.len < p + 4) {
        util.err("failed to parse ewah bitmap reading fsmonitor index extension", .{});
        return;
    }
    const ewah_size = std.mem.readInt(u32, data[p..][0..4], .big);
    p += 4;
    const r = ewah.Bitmap.read(data[p..@min(data.len, p + ewah_size)]);
    if (r == null or r.?.len != ewah_size) {
        util.err("failed to parse ewah bitmap reading fsmonitor index extension", .{});
        return;
    }
    idx.fsmonitor_dirty = r.?.bm;
    if (idx.split == null and idx.fsmonitor_dirty.?.bit_size > idx.entries.items.len)
        util.die("BUG: " ++ "fsmonitor_dirty has more entries than the index ({d} > {d})", .{ idx.fsmonitor_dirty.?.bit_size, idx.entries.items.len });
    @import("trace2.zig").dataString("index", false, "extension/fsmn/read/token", last);
}

/// fill_fsmonitor_bitmap() + write_fsmonitor_extension()
pub fn writeExtension(idx: *Index, b: *util.Buf) void {
    var bm = ewah.Bitmap.init();
    var skipped: usize = 0;
    for (idx.entries.items, 0..) |e, i| {
        if (e.removed) {
            skipped += 1;
        } else if (!e.fsmonitor_valid) bm.set(i - skipped);
    }
    var t4: [4]u8 = undefined;
    std.mem.writeInt(u32, &t4, 2, .big);
    util.bufAppend(b, &t4);
    util.bufAppend(b, idx.fsmonitor_last_update.?);
    util.bufByte(b, 0);
    var eb: util.Buf = .empty;
    bm.serialize(&eb);
    std.mem.writeInt(u32, &t4, @intCast(eb.items.len), .big);
    util.bufAppend(b, &t4);
    util.bufAppend(b, eb.items);
    @import("trace2.zig").dataString("index", false, "extension/fsmn/write/token", idx.fsmonitor_last_update.?);
}

// ---------------- entry marking ----------------

/// mark_fsmonitor_valid()
pub fn markValid(idx: *Index, e: *Entry) void {
    if (enabled() and !e.fsmonitor_valid) {
        if (e.mode & os.S_IFMT == os.S_IFGITLINK) return;
        idx.changed = true;
        e.fsmonitor_valid = true;
    }
}

/// mark_fsmonitor_invalid()
pub fn markInvalid(idx: *Index, e: *Entry) void {
    if (enabled()) {
        e.fsmonitor_valid = false;
        untracked_cache.invalidatePath(idx, e.path, true);
    }
}

/// is_fsmonitor_refreshed()
pub fn isRefreshed(idx: *const Index) bool {
    return !enabled() or idx.fsmonitor_has_run_once;
}

// ---------------- querying ----------------

fn queryHook(version: i32, last_update: []const u8, out: *[]const u8) bool {
    const s = get();
    if (s.mode != .hook) return false;
    const t2 = @import("trace2.zig");
    t2.regionEnter("fsm_hook", "query", false);
    const vs = util.fmt("{d}", .{version});
    const res = os.run(&.{ s.hook_path.?, vs, last_update }, .{
        .use_shell = true,
        .capture_stdout = true,
        .cwd = repo_mod.repo().work_tree,
    });
    const ok = !res.signaled and res.status == 0;
    if (!ok) {
        t2.dataInt("fsm_hook", false, "query/failed", if (res.status == 0) -1 else @intCast(res.status));
    } else {
        out.* = res.stdout;
        t2.dataInt("fsm_hook", false, "query/response-length", @intCast(res.stdout.len));
    }
    t2.regionLeave("fsm_hook", "query", false);
    return ok;
}

fn invalidateCe(e: *Entry) void {
    e.fsmonitor_valid = false;
}

fn startsWith(s: []const u8, p: []const u8) bool {
    return std.mem.startsWith(u8, s, p);
}

fn namePos(idx: *Index, name: []const u8) union(enum) { found: usize, missing: usize } {
    return switch (idx.pos(name, 0)) {
        .found => |i| .{ .found = i },
        .missing => |i| .{ .missing = i },
    };
}

/// handle_path_with_trailing_slash()
fn handleWithSlash(idx: *Index, name: []const u8, start: usize) usize {
    untracked_cache.invalidateTrimmedPath(idx, name, false);
    var n: usize = 0;
    var i = start;
    while (i < idx.entries.items.len) : (i += 1) {
        const e = &idx.entries.items[i];
        if (!startsWith(e.path, name)) break;
        invalidateCe(e);
        n += 1;
    }
    return n;
}

fn posStart(p: anytype) usize {
    return switch (p) {
        .found => |i| i,
        .missing => |i| i,
    };
}

/// fsmonitor_refresh_callback()
fn refreshCallback(idx: *Index, name: []const u8) void {
    if (name.len == 0) return;
    const p = namePos(idx, name);
    var n: usize = 0;
    if (name[name.len - 1] == '/') {
        n = handleWithSlash(idx, name, posStart(p));
    } else {
        untracked_cache.invalidateTrimmedPath(idx, name, false);
        switch (p) {
            .found => |i| {
                invalidateCe(&idx.entries.items[i]);
                n = 1;
            },
            .missing => {
                const wp = util.concat(&.{ name, "/" });
                n = handleWithSlash(idx, wp, posStart(namePos(idx, wp)));
            },
        }
    }
    if (n == 0 and (repo_mod.cfg.getBool("core.ignorecase") orelse false)) {
        // case-insensitive fallback (name-hash / dir-name-hash)
        var slash = name;
        if (slash[slash.len - 1] == '/') slash = slash[0 .. slash.len - 1];
        for (idx.entries.items) |*e| {
            if (std.ascii.eqlIgnoreCase(e.path, slash)) {
                untracked_cache.invalidateTrimmedPath(idx, e.path, false);
                invalidateCe(e);
                return;
            }
        }
        var found_dir: ?[]const u8 = null;
        for (idx.entries.items) |*e| {
            if (e.path.len > slash.len and e.path[slash.len] == '/' and std.ascii.eqlIgnoreCase(e.path[0..slash.len], slash)) {
                found_dir = util.concat(&.{ e.path[0..slash.len], "/" });
                break;
            }
        }
        if (found_dir) |d| _ = handleWithSlash(idx, d, posStart(namePos(idx, d)));
    }
}

const IpcResult = struct { token: []const u8, trivial: bool, paths: []const []const u8 };

/// fsmonitor_ipc__send_query(): null when the builtin daemon is unavailable.
fn ipcQuery(last_token: []const u8) ?IpcResult {
    _ = last_token;
    return null;
}

const force_update_threshold = 100;
var warn_once = false;

/// refresh_fsmonitor()
pub fn refresh(idx: *Index) void {
    const s = get();
    if (!warn_once and s.reason != .ok and s.reason != .untested) {
        warn_once = true;
        if (incompatibleMsg()) |m| util.warn("{s}", .{m});
    }
    if (@intFromEnum(s.mode) <= @intFromEnum(Mode.disabled) or idx.fsmonitor_has_run_once) return;
    idx.fsmonitor_has_run_once = true;

    var query_success = false;
    var result: []const u8 = "";
    var bol: usize = 0;
    var token: []const u8 = "";
    var is_trivial = false;

    if (s.mode == .ipc) {
        const q = ipcQuery(idx.fsmonitor_last_update orelse "builtin:fake");
        if (q) |qr| {
            query_success = true;
            token = qr.token;
            is_trivial = qr.trivial;
            if (!is_trivial) {
                var b: util.Buf = .empty;
                util.bufAppend(&b, token);
                util.bufByte(&b, 0);
                for (qr.paths) |pth| {
                    util.bufAppend(&b, pth);
                    util.bufByte(&b, 0);
                }
                result = b.items;
                bol = token.len + 1;
            }
        } else token = "builtin:fake";
    } else {
        var hook_version = hookVersion();
        const last_update = getNanoTime();
        if (hook_version == 1) token = util.fmt("{d}", .{last_update});
        if (idx.fsmonitor_last_update) |lu| {
            if (hook_version == -1 or hook_version == 2) {
                query_success = queryHook(2, lu, &result);
                if (query_success) {
                    if (hook_version < 0) hook_version = 2;
                    const nul = std.mem.indexOfScalar(u8, result, 0) orelse result.len;
                    token = result[0..nul];
                    if (token.len == 0) {
                        util.warn("Empty last update token.", .{});
                        query_success = false;
                    } else {
                        bol = token.len + 1;
                        is_trivial = bol < result.len and result[bol] == '/';
                    }
                } else if (hook_version < 0) {
                    hook_version = 1;
                    if (token.len == 0) token = util.fmt("{d}", .{last_update});
                }
            }
            if (hook_version == 1) {
                query_success = queryHook(1, lu, &result);
                if (query_success) is_trivial = result.len > 0 and result[0] == '/';
            }
            if (is_trivial) @import("trace2.zig").dataInt("fsm_hook", false, "query/trivial-response", 1);
        }
    }

    if (query_success and !is_trivial) {
        var count: usize = 0;
        var i = bol;
        while (i < result.len) : (i += 1) {
            if (result[i] != 0) continue;
            refreshCallback(idx, result[bol..i]);
            bol = i + 1;
            count += 1;
        }
        if (bol < result.len) {
            refreshCallback(idx, result[bol..]);
            count += 1;
        }
        if (idx.untracked) |u| u.use_fsmonitor = true;
        if (count > force_update_threshold) idx.changed = true;
    } else {
        var changed = false;
        for (idx.entries.items) |*e| {
            if (e.fsmonitor_valid) {
                changed = true;
                e.fsmonitor_valid = false;
            }
        }
        if (changed) idx.changed = true;
        if (idx.untracked) |u| u.use_fsmonitor = false;
    }
    idx.fsmonitor_last_update = util.dupe(token);
}

/// add_fsmonitor()
pub fn add(idx: *Index) void {
    if (idx.fsmonitor_last_update != null) return;
    idx.changed = true;
    idx.fsmonitor_last_update = util.fmt("{d}", .{getNanoTime()});
    for (idx.entries.items) |*e| e.fsmonitor_valid = false;
    if (idx.untracked) |u| {
        untracked_cache.add(idx);
        u.use_fsmonitor = true;
        if (idx.untracked) |nu| nu.use_fsmonitor = true;
    }
    refresh(idx);
}

/// remove_fsmonitor()
pub fn remove(idx: *Index) void {
    if (idx.fsmonitor_last_update != null) {
        idx.changed = true;
        idx.fsmonitor_last_update = null;
    }
}

/// tweak_fsmonitor()
pub fn tweak(idx: *Index) void {
    const en = enabled();
    if (idx.fsmonitor_dirty) |dirty| {
        if (en) {
            applyBitmap(idx, &dirty);
            refresh(idx);
        }
        idx.fsmonitor_dirty = null;
    }
    if (en) add(idx) else remove(idx);
}

/// Mark all entries valid except those in the dirty bitmap.
pub fn applyBitmap(idx: *Index, dirty: *const ewah.Bitmap) void {
    for (idx.entries.items) |*e| {
        if (e.mode & os.S_IFMT == os.S_IFGITLINK) continue;
        e.fsmonitor_valid = true;
    }
    if (dirty.bit_size > idx.entries.items.len)
        util.die("BUG: " ++ "fsmonitor_dirty has more entries than the index ({d} > {d})", .{ dirty.bit_size, idx.entries.items.len });
    for (dirty.bits()) |b| {
        if (b >= idx.entries.items.len) util.die("BUG: " ++ "fsmonitor_dirty has more entries than the index ({d} > {d})", .{ b + 1, idx.entries.items.len });
        idx.entries.items[b].fsmonitor_valid = false;
    }
}
