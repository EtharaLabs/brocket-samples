//! git upload-pack (port of builtin/upload-pack.c, upload-pack.c, serve.c, ls-refs.c)

const std = @import("std");
const c = std.c;
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const objects = @import("../objects.zig");
const pkt = @import("../pktline.zig");
const proc = @import("../proc.zig");
const main = @import("../main.zig");
const gpa = util.gpa;
const Oid = hash.Oid;

// ---------------- shared server helpers ----------------

extern "c" fn uname(buf: *[6][65]u8) c_int;

pub fn userAgent() []const u8 {
    return os.getenv("GIT_USER_AGENT") orelse "git/" ++ main.version;
}

fn redact(s: []const u8) []u8 {
    const t = util.dupe(util.trim(s));
    for (t) |*ch| {
        if (ch.* < 32 or ch.* > 126 or ch.* == ' ') ch.* = '.';
    }
    return t;
}

var agent_cache: ?[]const u8 = null;

/// git_user_agent_sanitized()
pub fn agentSanitized() []const u8 {
    if (agent_cache) |a| return a;
    var b: util.Buf = .empty;
    util.bufAppend(&b, userAgent());
    if (os.getenv("GIT_USER_AGENT") == null) {
        var u: [6][65]u8 = undefined;
        if (uname(&u) == 0) {
            const n = std.mem.indexOfScalar(u8, &u[0], 0) orelse 65;
            util.bufByte(&b, '-');
            util.bufAppend(&b, redact(u[0][0..n]));
        }
    }
    const a = redact(b.items);
    agent_cache = a;
    return a;
}

/// enter_repo(): chdir into the repository and set it up. Returns false if
/// `path` is not a repository.
pub fn enterRepo(path_in: []const u8, strict: bool) bool {
    var path = path_in;
    var target: []const u8 = path;
    if (!strict) {
        var len = path.len;
        while (len > 1 and path[len - 1] == '/') len -= 1;
        path = path[0..len];
        if (path.len > 0 and path[0] == '~') {
            if (os.getenv("HOME")) |h| {
                if (path.len == 1 or path[1] == '/') path = util.concat(&.{ h, path[1..] });
            }
        }
        const suffixes = [_][]const u8{ "/.git", "", ".git/.git", ".git" };
        var found: ?[]const u8 = null;
        for (suffixes) |s| {
            const p = util.concat(&.{ path, s });
            if (os.statPath(p)) |st| {
                if (st.isReg() or (st.isDir() and repo_mod.isGitDirectory(p))) {
                    found = p;
                    break;
                }
            }
        }
        target = found orelse return false;
    }
    if (os.statPath(target)) |st| {
        if (st.isReg()) target = repo_mod.readGitfile(target) orelse return false;
    }
    if (!os.chdir(target)) return false;
    if (!repo_mod.isGitDirectory(".")) return false;
    os.setEnv("GIT_DIR", ".");
    os.unsetEnv("GIT_WORK_TREE");
    os.setEnv("GIT_IMPLICIT_WORK_TREE", "0");
    repo_mod.setup(false);
    os.unsetEnv("GIT_IMPLICIT_WORK_TREE");
    return true;
}

pub fn protocolVersionServer() u32 {
    var version: u32 = 0;
    const gp = os.getenv("GIT_PROTOCOL") orelse return 0;
    var it = std.mem.splitScalar(u8, gp, ':');
    while (it.next()) |item| {
        if (util.skipPrefix(item, "version=")) |v| {
            const n = util.parseInt(u32, v) orelse continue;
            if (n <= 2 and n > version) version = n;
        }
    }
    return version;
}

/// Is a ref hidden by transfer.hideRefs / <section>.hideRefs?
pub fn refIsHidden(section: []const u8, name: []const u8) bool {
    var hidden = false;
    var keys = [_][]const u8{ "transfer.hiderefs", util.concat(&.{ section, ".hiderefs" }) };
    for (&keys) |k| {
        for (repo_mod.cfg.getAll(k)) |v0| {
            var v = v0;
            var neg = false;
            if (v.len > 0 and v[0] == '!') {
                neg = true;
                v = v[1..];
            }
            var subject = name;
            if (v.len > 0 and v[0] == '^') {
                v = v[1..];
                subject = name;
            }
            var vv = v;
            while (vv.len > 0 and vv[vv.len - 1] == '/') vv = vv[0 .. vv.len - 1];
            if (util.startsWith(subject, vv) and (subject.len == vv.len or subject[vv.len] == '/')) {
                hidden = !neg;
            }
        }
    }
    return hidden;
}

pub fn peeledOf(r: refs.Ref) ?Oid {
    if (r.peeled) |p| return p;
    const odb = repo_mod.repo().odb();
    const t = odb.readType(r.oid) orelse return null;
    if (t != .tag) return null;
    const p = objects.peel(r.oid) orelse return null;
    return p.oid;
}

// ---------------- upload-pack state ----------------

var want_list: std.ArrayList(Oid) = .empty;
var want_set: hash.OidSet = undefined;
var have_list: std.ArrayList(Oid) = .empty;
var have_set: hash.OidSet = undefined;
var our_refs: hash.OidSet = undefined;

var multi_ack: u8 = 0; // 0 none, 1 multi_ack, 2 detailed
var no_done = false;
var use_thin = false;
var use_ofs = false;
var use_sideband: usize = 0;
var no_progress = false;
var include_tag = false;
var done = false;
var wait_for_done = false;
var stateless_rpc = false;

var allow_tip = false;
var allow_reachable = false;
var allow_any = false;
var allow_filter = false;
var allow_ref_in_want = false;

fn loadConfig() void {
    const cfg = &repo_mod.cfg;
    if (cfg.getBool("uploadpack.allowtipsha1inwant") orelse false) allow_tip = true;
    if (cfg.getBool("uploadpack.allowreachablesha1inwant") orelse false) allow_reachable = true;
    if (cfg.getBool("uploadpack.allowanysha1inwant") orelse false) {
        allow_any = true;
        allow_tip = true;
        allow_reachable = true;
    }
    allow_filter = cfg.getBool("uploadpack.allowfilter") orelse false;
    allow_ref_in_want = cfg.getBool("uploadpack.allowrefinwant") orelse false;
}

fn initSets() void {
    want_set = .empty;
    have_set = .empty;
    our_refs = .empty;
}

const AdvRef = struct { name: []const u8, oid: Oid, peeled: ?Oid, symref: ?[]const u8 };

fn collectRefs(section: []const u8) []AdvRef {
    var l: std.ArrayList(AdvRef) = .empty;
    if (refs.resolve("HEAD")) |h| {
        if (!refIsHidden(section, "HEAD")) {
            var sym: ?[]const u8 = null;
            if (h.symbolic) sym = h.name;
            const pr = peeledOf(.{ .name = "HEAD", .oid = h.oid });
            l.append(gpa, .{ .name = "HEAD", .oid = h.oid, .peeled = pr, .symref = sym }) catch util.oom();
        }
    }
    for (refs.iterate("refs/", .{})) |r| {
        if (refIsHidden(section, r.name)) continue;
        var sym: ?[]const u8 = null;
        if (r.flags & refs.REF_ISSYMREF != 0) {
            if (refs.resolve(r.name)) |res| sym = res.name;
        }
        l.append(gpa, .{ .name = r.name, .oid = r.oid, .peeled = peeledOf(r), .symref = sym }) catch util.oom();
    }
    return l.items;
}

fn advertiseV0(advrefs: []const AdvRef) void {
    var caps: util.Buf = .empty;
    util.bufAppend(&caps, "multi_ack thin-pack side-band side-band-64k ofs-delta shallow deepen-since deepen-not deepen-relative no-progress include-tag multi_ack_detailed");
    if (allow_tip) util.bufAppend(&caps, " allow-tip-sha1-in-want");
    if (allow_reachable) util.bufAppend(&caps, " allow-reachable-sha1-in-want");
    if (stateless_rpc) util.bufAppend(&caps, " no-done");
    // symrefs, sorted by name
    var syms: std.ArrayList(AdvRef) = .empty;
    for (advrefs) |r| {
        if (r.symref != null) syms.append(gpa, r) catch util.oom();
    }
    std.mem.sort(AdvRef, syms.items, {}, struct {
        fn lt(_: void, a: AdvRef, b: AdvRef) bool {
            return std.mem.order(u8, a.name, b.name) == .lt;
        }
    }.lt);
    for (syms.items) |s| util.bufPrint(&caps, " symref={s}:{s}", .{ s.name, s.symref.? });
    if (allow_filter) util.bufAppend(&caps, " filter");
    util.bufPrint(&caps, " object-format=sha1 agent={s}", .{agentSanitized()});

    var first = true;
    for (advrefs) |r| {
        our_refs.put(gpa, r.oid, {}) catch util.oom();
        if (r.peeled) |p| our_refs.put(gpa, p, {}) catch util.oom();
        if (first) {
            pkt.writeFmt(1, "{s} {s}\x00{s}\n", .{ hash.hex(r.oid), r.name, caps.items });
            first = false;
        } else {
            pkt.writeFmt(1, "{s} {s}\n", .{ hash.hex(r.oid), r.name });
        }
        if (r.peeled) |p| pkt.writeFmt(1, "{s} {s}^{{}}\n", .{ hash.hex(p), r.name });
    }
    if (first) {
        pkt.writeFmt(1, "{s} capabilities^{{}}\x00{s}\n", .{ hash.zero_hex, caps.items });
    }
    for (objects.shallowList()) |s| pkt.writeFmt(1, "shallow {s}\n", .{hash.hex(s)});
    pkt.flush(1);
}

fn hasCap(caps: []const u8, name: []const u8) bool {
    var it = std.mem.tokenizeScalar(u8, caps, ' ');
    while (it.next()) |w| {
        if (util.eql(w, name)) return true;
        if (util.startsWith(w, name) and w.len > name.len and w[name.len] == '=') return true;
    }
    return false;
}

fn errAndDie(comptime f: []const u8, args: anytype) noreturn {
    const msg = util.fmt(f, args);
    pkt.writeFmt(1, "ERR {s}", .{msg});
    util.die("git upload-pack: {s}", .{msg});
}

fn addWant(oid: Oid) void {
    if (want_set.contains(oid)) return;
    want_set.put(gpa, oid, {}) catch util.oom();
    want_list.append(gpa, oid) catch util.oom();
}

fn receiveNeedsV0(rd: *pkt.Reader) void {
    var first = true;
    while (true) {
        const st = rd.read();
        if (st != .normal) break;
        const line = rd.line;
        if (processShallowArgs(line)) continue;
        if (util.skipPrefix(line, "filter ")) |fs| {
            if (!filter_cap_requested) util.die("git upload-pack: filtering capability not negotiated", .{});
            setFilter(fs);
            continue;
        }
        const rest = util.skipPrefix(line, "want ") orelse
            util.die("git upload-pack: protocol error, expected to get object ID, not '{s}'", .{line});
        if (rest.len < 40) util.die("git upload-pack: protocol error, expected to get object ID, not '{s}'", .{line});
        const oid = hash.fromHex(rest[0..40]) orelse
            util.die("git upload-pack: protocol error, expected to get object ID, not '{s}'", .{line});
        const caps = rest[40..];
        if (first) {
            first = false;
            if (hasCap(caps, "deepen-relative")) deepen_relative = true;
            if (hasCap(caps, "multi_ack_detailed")) {
                multi_ack = 2;
            } else if (hasCap(caps, "multi_ack")) multi_ack = 1;
            if (hasCap(caps, "no-done")) no_done = true;
            if (hasCap(caps, "thin-pack")) use_thin = true;
            if (hasCap(caps, "ofs-delta")) use_ofs = true;
            if (hasCap(caps, "side-band-64k")) {
                use_sideband = pkt.LARGE_PACKET_MAX;
            } else if (hasCap(caps, "side-band")) use_sideband = 1000;
            if (hasCap(caps, "no-progress")) no_progress = true;
            if (hasCap(caps, "include-tag")) include_tag = true;
            if (allow_filter and hasCap(caps, "filter")) filter_cap_requested = true;
        }
        if (!repo_mod.repo().odb().has(oid)) {
            pkt.writeFmt(1, "ERR upload-pack: not our ref {s}", .{hash.hex(oid)});
            util.die("git upload-pack: not our ref {s}", .{hash.hex(oid)});
        }
        if (!allow_any and !allow_tip and !allow_reachable and !our_refs.contains(oid)) {
            pkt.writeFmt(1, "ERR upload-pack: not our ref {s}", .{hash.hex(oid)});
            util.die("git upload-pack: not our ref {s}", .{hash.hex(oid)});
        }
        addWant(oid);
    }
    if (depth == 0 and !deepen_rev_list and client_shallows.items.len == 0) return;
    if (sendShallowList()) pkt.flush(1);
}

const cn = @import("../commitnode.zig");
const THEY_HAVE: u32 = 1 << 11;
const COMMON_KNOWN: u32 = 1 << 14;
var oldest_have: u64 = 0;

/// do_got_oid() / got_oid(): -1 if we do not have it, 1 if it is a new
/// "have", 0 if it was already implied by an earlier one.
fn gotOid(oid: Oid) i32 {
    if (!repo_mod.repo().odb().has(oid)) return -1;
    const o = cn.parseObject(oid) orelse util.die("oops ({s})", .{hash.hex(oid)});
    if (o.typ == .commit) {
        const cm = cn.Commit.fromObj(o);
        if (oldest_have == 0 or cm.date < oldest_have) oldest_have = cm.date;
        var p = cm.parents;
        while (p) |pl| : (p = pl.next) pl.item.obj.flags |= THEY_HAVE;
    }
    if (o.flags & THEY_HAVE != 0) return 0;
    o.flags |= THEY_HAVE;
    have_set.put(gpa, oid, {}) catch util.oom();
    have_list.append(gpa, oid) catch util.oom();
    return 1;
}

/// ok_to_give_up(): can every want reach something they have?
fn okToGiveUp() bool {
    if (have_list.items.len == 0) return false;
    var from: std.ArrayList(*cn.Obj) = .empty;
    defer from.deinit(gpa);
    for (want_list.items) |w| {
        const o = cn.parseObject(w) orelse continue;
        from.append(gpa, o) catch util.oom();
    }
    return @import("../commitreach.zig").canAllFromReachWithFlag(from.items, THEY_HAVE, COMMON_KNOWN, oldest_have, 0);
}

fn getCommonCommits(rd: *pkt.Reader) bool {
    var got_common = false;
    var got_other = false;
    var sent_ready = false;
    var last_hex: [40]u8 = undefined;
    while (true) {
        const st = rd.read();
        if (st != .normal) {
            if (multi_ack == 2 and got_common and !got_other and okToGiveUp()) {
                sent_ready = true;
                pkt.writeFmt(1, "ACK {s} ready\n", .{last_hex});
            }
            if (have_list.items.len == 0 or multi_ack != 0) pkt.write(1, "NAK\n");
            if (no_done and sent_ready) {
                pkt.writeFmt(1, "ACK {s}\n", .{last_hex});
                return true;
            }
            if (stateless_rpc) os.exit(0);
            got_common = false;
            got_other = false;
            continue;
        }
        const line = rd.line;
        if (util.skipPrefix(line, "have ")) |h| {
            const oid = hash.fromHex(if (h.len >= 40) h[0..40] else h) orelse
                util.die("git upload-pack: expected SHA1 object, got '{s}'", .{h});
            if (gotOid(oid) >= 0) {
                got_common = true;
                last_hex = hash.hex(oid);
                if (multi_ack == 2) {
                    pkt.writeFmt(1, "ACK {s} common\n", .{last_hex});
                } else if (multi_ack == 1) {
                    pkt.writeFmt(1, "ACK {s} continue\n", .{last_hex});
                } else if (have_list.items.len == 1) {
                    pkt.writeFmt(1, "ACK {s}\n", .{last_hex});
                }
            } else {
                got_other = true;
                if (multi_ack != 0 and okToGiveUp()) {
                    const hx = hash.hex(oid);
                    if (multi_ack == 2) {
                        sent_ready = true;
                        pkt.writeFmt(1, "ACK {s} ready\n", .{hx});
                    } else {
                        pkt.writeFmt(1, "ACK {s} continue\n", .{hx});
                    }
                }
            }
            continue;
        }
        if (util.eql(line, "done")) {
            if (have_list.items.len > 0) {
                if (multi_ack != 0) pkt.writeFmt(1, "ACK {s}\n", .{last_hex});
                return true;
            }
            pkt.write(1, "NAK\n");
            return true;
        }
        util.die("git upload-pack: expected SHA1 list, got '{s}'", .{line});
    }
}

// ---------------- shallow support (upload-pack.c / shallow.c) ----------------

const INFINITE_DEPTH: i32 = 0x7fffffff;

var client_shallows: std.ArrayList(Oid) = .empty;
var client_shallow_set: hash.OidSet = .empty;
var not_shallow_set: hash.OidSet = .empty;
var extra_edge: std.ArrayList(Oid) = .empty;
var depth: i32 = 0;
var deepen_since: i64 = 0;
var deepen_not: std.ArrayList(Oid) = .empty;
var deepen_rev_list = false;
var deepen_relative = false;
var shallow_nr: usize = 0;

var filter_spec: ?[]const u8 = null;
var filter_cap_requested = false;

/// die_if_using_banned_filter() (uploadpackfilter.* config)
fn checkBannedFilter(spec: []const u8) void {
    const objfilter = @import("../objfilter.zig");
    const f = objfilter.parse(spec);
    const default_allow = repo_mod.cfg.getBool("uploadpackfilter.allow") orelse true;
    var bad: ?[]const u8 = null;
    checkOne(f, default_allow, &bad);
    if (bad) |msg| {
        pkt.writeFmt(1, "ERR {s}", .{msg});
        util.die("{s}", .{msg});
    }
}

fn checkOne(f: *@import("../objfilter.zig").Filter, default_allow: bool, bad: *?[]const u8) void {
    if (bad.* != null) return;
    const cfg = &repo_mod.cfg;
    const name: []const u8 = switch (f.kind) {
        .blob_none => "blob:none",
        .blob_limit => "blob:limit",
        .tree_depth => "tree",
        .sparse_oid => "sparse:oid",
        .object_type => "object:type",
        .combine => "combine",
    };
    var allowed = cfg.getBool(util.fmt("uploadpackfilter.{s}.allow", .{name})) orelse default_allow;
    if (f.kind == .tree_depth and cfg.getBool("uploadpackfilter.tree.allow") == null and cfg.get("uploadpackfilter.tree.maxdepth") != null) allowed = true;
    if (!allowed) {
        bad.* = util.fmt("filter '{s}' not supported", .{name});
        return;
    }
    if (f.kind == .tree_depth) {
        if (cfg.get("uploadpackfilter.tree.maxdepth")) |v| {
            const maxd: u64 = @intCast(@max(0, @import("../config.zig").parseInt(v) orelse 0));
            if (f.depth > maxd) {
                bad.* = util.fmt("tree filter allows max depth {d}, but got {d}", .{ maxd, f.depth });
                return;
            }
        }
    }
    if (f.kind == .combine) {
        for (f.subs) |*s| checkOne(s, default_allow, bad);
    }
}

fn setFilter(spec: []const u8) void {
    if (filter_spec != null) util.die("multiple filter-specs cannot be combined", .{});
    checkBannedFilter(spec);
    filter_spec = @import("../objfilter.zig").expandSpec(@import("../objfilter.zig").parse(util.dupe(spec)));
}

fn resetShallowState() void {
    filter_spec = null;
    client_shallows = .empty;
    client_shallow_set = .empty;
    not_shallow_set = .empty;
    extra_edge = .empty;
    depth = 0;
    deepen_since = 0;
    deepen_not = .empty;
    deepen_rev_list = false;
    deepen_relative = false;
    shallow_nr = 0;
}

fn processShallow(line: []const u8) bool {
    const arg = util.skipPrefix(line, "shallow ") orelse return false;
    const oid = (if (arg.len >= 40) hash.fromHex(arg[0..40]) else null) orelse util.die("invalid shallow line: {s}", .{line});
    const t = repo_mod.repo().odb().readType(oid) orelse return true;
    if (t != .commit) util.die("invalid shallow object {s}", .{hash.hex(oid)});
    if (!client_shallow_set.contains(oid)) {
        client_shallow_set.put(gpa, oid, {}) catch util.oom();
        client_shallows.append(gpa, oid) catch util.oom();
    }
    return true;
}

fn parseCLong(s: []const u8) ?i64 {
    if (s.len == 0) return null;
    var neg = false;
    var r = s;
    if (r[0] == '-' or r[0] == '+') {
        neg = r[0] == '-';
        r = r[1..];
    }
    var base: u8 = 10;
    if (r.len > 1 and r[0] == '0' and (r[1] == 'x' or r[1] == 'X')) {
        base = 16;
        r = r[2..];
    } else if (r.len > 1 and r[0] == '0') {
        base = 8;
        r = r[1..];
    }
    const v = std.fmt.parseInt(i64, r, base) catch return null;
    return if (neg) -v else v;
}

fn processDeepen(line: []const u8) bool {
    const arg = util.skipPrefix(line, "deepen ") orelse return false;
    const v = parseCLong(arg) orelse util.die("Invalid deepen: {s}", .{line});
    if (v <= 0 or v > std.math.maxInt(i32)) util.die("Invalid deepen: {s}", .{line});
    depth = @intCast(v);
    return true;
}

fn processDeepenSince(line: []const u8) bool {
    const arg = util.skipPrefix(line, "deepen-since ") orelse return false;
    const v = std.fmt.parseInt(i64, arg, 10) catch util.die("Invalid deepen-since: {s}", .{line});
    if (v == -1) util.die("Invalid deepen-since: {s}", .{line});
    deepen_since = v;
    deepen_rev_list = true;
    return true;
}

fn processDeepenNot(line: []const u8) bool {
    const arg = util.skipPrefix(line, "deepen-not ") orelse return false;
    const r = refs.dwimRef(arg);
    const cnt: usize = if (r) |x| x.count else 0;
    if (cnt > 1) util.die("git upload-pack: ambiguous deepen-not: {s}", .{line});
    if (cnt < 1) util.die("git upload-pack: deepen-not is not a ref: {s}", .{line});
    deepen_not.append(gpa, r.?.oid) catch util.oom();
    deepen_rev_list = true;
    return true;
}

fn processShallowArgs(line: []const u8) bool {
    return processShallow(line) or processDeepen(line) or processDeepenSince(line) or processDeepenNot(line);
}

/// get_shallows_or_depth()
fn getShallowsOrDepth(heads: []const Oid, shallows: ?[]const Oid, max_cur_depth: ?*i32, want_depth: i32, shallow_flag: ?*hash.OidSet) []Oid {
    var result: std.ArrayList(Oid) = .empty;
    var stack: std.ArrayList(Oid) = .empty;
    var depths: hash.OidMap(i32) = .empty;
    var cur_depth: i32 = 0;
    var cur_depth_shallow: i32 = 0;
    var i: usize = 0;
    var commit: ?Oid = null;
    while (commit != null or i < heads.len or stack.items.len > 0) {
        if (commit == null) {
            if (i < heads.len) {
                const p = objects.peel(heads[i]);
                i += 1;
                if (p == null or p.?.typ != .commit) continue;
                commit = p.?.oid;
                depths.put(gpa, commit.?, 0) catch util.oom();
                cur_depth = 0;
            } else {
                commit = stack.pop().?;
                cur_depth = depths.get(commit.?) orelse 0;
            }
        }
        const cid = commit.?;
        const cm = objects.readCommit(cid) orelse util.die("unable to parse commit {s}", .{hash.hex(cid)});
        cur_depth += 1;
        const graft_shallow = cm.parents.len == 0 and objects.isShallow(cid);
        if (shallows) |sl| {
            for (sl) |s| {
                if (std.mem.eql(u8, &s, &cid)) {
                    if (cur_depth_shallow == 0 or cur_depth < cur_depth_shallow) cur_depth_shallow = cur_depth;
                }
            }
            if (graft_shallow) {
                commit = null;
                continue;
            }
        } else {
            if ((want_depth != INFINITE_DEPTH and cur_depth >= want_depth) or graft_shallow) {
                result.append(gpa, cid) catch util.oom();
                if (shallow_flag) |sf| sf.put(gpa, cid, {}) catch util.oom();
                commit = null;
                continue;
            }
            not_shallow_set.put(gpa, cid, {}) catch util.oom();
        }
        commit = null;
        for (cm.parents, 0..) |p, pi| {
            if (depths.getPtr(p)) |slot| {
                if (cur_depth >= slot.*) continue;
                slot.* = cur_depth;
            } else depths.put(gpa, p, cur_depth) catch util.oom();
            if (pi + 1 < cm.parents.len) {
                stack.append(gpa, p) catch util.oom();
            } else {
                commit = p;
                cur_depth = depths.get(p).?;
            }
        }
    }
    if (shallows != null) {
        if (max_cur_depth) |m| m.* = cur_depth_shallow;
    }
    std.mem.reverse(Oid, result.items);
    return result.items;
}

fn sendShallow(result: []const Oid) void {
    for (result) |o| {
        if (client_shallow_set.contains(o) or not_shallow_set.contains(o)) continue;
        pkt.writeFmt(1, "shallow {s}\n", .{hash.hex(o)});
        objects.registerShallow(o);
        shallow_nr += 1;
    }
}

fn sendUnshallow() void {
    for (client_shallows.items) |o| {
        if (not_shallow_set.contains(o)) {
            pkt.writeFmt(1, "unshallow {s}\n", .{hash.hex(o)});
            _ = client_shallow_set.remove(o);
            _ = objects.unregisterShallow(o);
            const cm = objects.readCommit(o) orelse util.die("could not parse commit {s}", .{hash.hex(o)});
            for (cm.parents) |p| want_list.append(gpa, p) catch util.oom();
            extra_edge.append(gpa, o) catch util.oom();
        }
        objects.registerShallow(o);
    }
}

fn deepen(d: i32) void {
    if (d == INFINITE_DEPTH and objects.shallowList().len == 0) {
        for (client_shallows.items) |o| not_shallow_set.put(gpa, o, {}) catch util.oom();
    } else {
        var dd = d;
        var skip = false;
        if (deepen_relative) {
            var cur: i32 = 0;
            _ = getShallowsOrDepth(want_list.items, client_shallows.items, &cur, 0, null);
            if (cur != 0) {
                dd +|= cur;
            } else skip = true;
        }
        if (!skip) {
            var sf: hash.OidSet = .empty;
            const result = getShallowsOrDepth(want_list.items, null, null, dd, &sf);
            sendShallow(result);
        }
    }
    sendUnshallow();
}

fn deepenByRevList() void {
    var av: std.ArrayList([]const u8) = .empty;
    av.append(gpa, "rev-list") catch util.oom();
    if (deepen_since != 0) av.append(gpa, util.fmt("--max-age={d}", .{deepen_since})) catch util.oom();
    if (deepen_not.items.len > 0) {
        av.append(gpa, "--not") catch util.oom();
        var seen: hash.OidSet = .empty;
        for (deepen_not.items) |o| {
            if (seen.contains(o)) continue;
            seen.put(gpa, o, {}) catch util.oom();
            av.append(gpa, util.dupe(&hash.hex(o))) catch util.oom();
        }
        av.append(gpa, "--not") catch util.oom();
    }
    for (want_list.items) |w| av.append(gpa, util.dupe(&hash.hex(w))) catch util.oom();
    var ch = proc.spawnGit(av.items, .{ .pipe_out = true });
    var out: util.Buf = .empty;
    var buf: [65536]u8 = undefined;
    while (true) {
        const n = c.read(ch.out, &buf, buf.len);
        if (n <= 0) break;
        util.bufAppend(&out, buf[0..@intCast(n)]);
    }
    proc.closeFd(&ch.out);
    if (proc.wait(ch.pid) != 0) util.die("revision walk setup failed", .{});
    var list: std.ArrayList(Oid) = .empty;
    var it = std.mem.tokenizeScalar(u8, out.items, '\n');
    while (it.next()) |l| {
        if (hash.fromHex(l)) |o| list.append(gpa, o) catch util.oom();
    }
    if (list.items.len == 0) util.die("no commits selected for shallow requests", .{});
    for (list.items) |o| not_shallow_set.put(gpa, o, {}) catch util.oom();
    var result: std.ArrayList(Oid) = .empty;
    for (list.items) |o| {
        const cm = objects.readCommit(o) orelse util.die("unable to parse commit {s}", .{hash.hex(o)});
        for (cm.parents) |p| {
            if (!not_shallow_set.contains(p)) {
                result.append(gpa, o) catch util.oom();
                break;
            }
        }
    }
    for (result.items) |o| _ = not_shallow_set.remove(o);
    sendShallow(result.items);
    sendUnshallow();
}

/// send_shallow_list(): returns true if a shallow list was sent
fn sendShallowList() bool {
    var ret = false;
    if (depth > 0 and deepen_rev_list)
        util.die("git upload-pack: deepen and deepen-since (or deepen-not) cannot be used together", .{});
    if (depth > 0) {
        deepen(depth);
        ret = true;
    } else if (deepen_rev_list) {
        deepenByRevList();
        ret = true;
    } else {
        for (client_shallows.items) |o| objects.registerShallow(o);
    }
    shallow_nr += client_shallows.items.len;
    return ret;
}

fn sendShallowInfoV2() void {
    const repo_shallow = objects.shallowList().len > 0;
    if (depth == 0 and !deepen_rev_list and client_shallows.items.len == 0 and !repo_shallow) return;
    pkt.write(1, "shallow-info\n");
    if (!sendShallowList() and repo_shallow) deepen(INFINITE_DEPTH);
    pkt.delim(1);
}

extern "c" fn poll(fds: [*]PollFd, n: c_ulong, timeout: c_int) c_int;
const PollFd = extern struct { fd: c_int, events: i16, revents: i16 };

fn sendClientData(band: u8, data: []const u8) void {
    if (use_sideband > 0) {
        pkt.sendSideband(1, band, data, use_sideband);
        return;
    }
    if (band == 2) {
        os.writeAll(2, data) catch {};
        return;
    }
    os.writeAll(1, data) catch util.die("write error", .{});
}

fn createPackFile() void {
    var argv: std.ArrayList([]const u8) = .empty;
    const shallows: []const Oid = if (shallow_nr > 0) objects.shallowList() else &.{};
    if (shallows.len > 0) argv.appendSlice(gpa, &.{ "--shallow-file", "" }) catch util.oom();
    argv.appendSlice(gpa, &.{ "pack-objects", "--revs", "--stdout" }) catch util.oom();
    if (use_thin) argv.append(gpa, "--thin") catch util.oom();
    if (shallow_nr > 0) argv.append(gpa, "--shallow") catch util.oom();
    if (use_ofs) argv.append(gpa, "--delta-base-offset") catch util.oom();
    if (include_tag) argv.append(gpa, "--include-tag") catch util.oom();
    if (filter_spec) |fs| argv.append(gpa, util.concat(&.{ "--filter=", fs })) catch util.oom();
    argv.append(gpa, if (no_progress) "--quiet" else "--progress") catch util.oom();
    var input: util.Buf = .empty;
    for (shallows) |s| util.bufPrint(&input, "--shallow {s}\n", .{hash.hex(s)});
    for (want_list.items) |w| util.bufPrint(&input, "{s}\n", .{hash.hex(w)});
    util.bufAppend(&input, "--not\n");
    for (have_list.items) |h| util.bufPrint(&input, "{s}\n", .{hash.hex(h)});
    for (extra_edge.items) |h| util.bufPrint(&input, "{s}\n", .{hash.hex(h)});
    util.bufAppend(&input, "\n");

    var ch = proc.spawnGit(argv.items, .{ .pipe_in = true, .pipe_out = true, .pipe_err = true });
    os.writeAll(ch.in, input.items) catch {};
    proc.closeFd(&ch.in);

    var buf: [8193]u8 = undefined;
    var keep: ?u8 = null;
    var out_open = true;
    var err_open = true;
    var sent_any = false;
    while (out_open or err_open) {
        var fds: [2]PollFd = undefined;
        var n: usize = 0;
        if (out_open) {
            fds[n] = .{ .fd = ch.out, .events = 1, .revents = 0 };
            n += 1;
        }
        if (err_open) {
            fds[n] = .{ .fd = ch.err, .events = 1, .revents = 0 };
            n += 1;
        }
        const r = poll(&fds, n, -1);
        if (r < 0) {
            if (os.errno() == 4) continue;
            break;
        }
        for (fds[0..n]) |f| {
            if (f.revents == 0) continue;
            if (f.fd == ch.err) {
                const got = c.read(ch.err, &buf, buf.len - 1);
                if (got <= 0) {
                    err_open = false;
                    continue;
                }
                const data = buf[0..@intCast(got)];
                if (!no_progress) sendClientData(2, data);
            } else {
                var off: usize = 0;
                if (keep) |k| {
                    buf[0] = k;
                    off = 1;
                }
                const got = c.read(ch.out, buf[off..].ptr, buf.len - 1 - off);
                if (got <= 0) {
                    out_open = false;
                    continue;
                }
                const total = off + @as(usize, @intCast(got));
                sent_any = true;
                if (total > 1) {
                    keep = buf[total - 1];
                    sendClientData(1, buf[0 .. total - 1]);
                } else {
                    keep = buf[0];
                }
            }
        }
    }
    const status = proc.wait(ch.pid);
    if (status != 0) {
        sendClientData(3, "aborting due to possible repository corruption on the remote side.\n");
        util.die("git upload-pack: git-pack-objects died with error.", .{});
    }
    if (keep) |k| sendClientData(1, &.{k});
    if (use_sideband > 0) pkt.flush(1);
}

fn uploadPackV0(advertise_only: bool) void {
    const advrefs = collectRefs("uploadpack");
    if (advertise_only or !stateless_rpc) advertiseV0(advrefs) else {
        // check_ref(): mark refs as ours without advertising them
        for (advrefs) |r| our_refs.put(gpa, r.oid, {}) catch util.oom();
    }
    if (advertise_only) return;
    var rd = pkt.Reader.init(0);
    rd.gentle_eof = true;
    receiveNeedsV0(&rd);
    if (want_list.items.len == 0) return;
    if (!getCommonCommits(&rd)) return;
    createPackFile();
}

// ---------------- protocol v2 ----------------

fn advertiseV2() void {
    pkt.write(1, "version 2\n");
    pkt.writeFmt(1, "agent={s}\n", .{agentSanitized()});
    pkt.write(1, "ls-refs=unborn\n");
    if (allow_filter) {
        pkt.write(1, "fetch=shallow wait-for-done filter\n");
    } else pkt.write(1, "fetch=shallow wait-for-done\n");
    pkt.write(1, "server-option\n");
    pkt.write(1, "object-format=sha1\n");
    pkt.flush(1);
}

fn refMatch(prefixes: []const []const u8, name: []const u8) bool {
    if (prefixes.len == 0) return true;
    for (prefixes) |p| {
        if (util.startsWith(name, p)) return true;
    }
    return false;
}

fn lsRefs(rd: *pkt.Reader) void {
    var peel = false;
    var symrefs = false;
    var unborn = false;
    var prefixes: std.ArrayList([]const u8) = .empty;
    while (rd.read() == .normal) {
        const arg = rd.line;
        if (util.eql(arg, "peel")) {
            peel = true;
        } else if (util.eql(arg, "symrefs")) {
            symrefs = true;
        } else if (util.skipPrefix(arg, "ref-prefix ")) |p| {
            prefixes.append(gpa, util.dupe(p)) catch util.oom();
        } else if (util.eql(arg, "unborn")) {
            unborn = true;
        } else util.die("unexpected line: '{s}'", .{arg});
    }
    if (rd.status != .flush) util.die("expected flush after ls-refs arguments", .{});
    if (prefixes.items.len > 10) prefixes.clearRetainingCapacity();
    if (refMatch(prefixes.items, "HEAD")) {
        const res = refs.resolveFull("HEAD", true);
        if (!res.broken and !res.missing and !hash.isZero(res.oid)) {
            var b: util.Buf = .empty;
            util.bufPrint(&b, "{s} HEAD", .{hash.hex(res.oid)});
            if (symrefs and res.flags & refs.REF_ISSYMREF != 0) util.bufPrint(&b, " symref-target:{s}", .{res.name});
            if (peel) {
                if (peeledOf(.{ .name = "HEAD", .oid = res.oid })) |p| util.bufPrint(&b, " peeled:{s}", .{hash.hex(p)});
            }
            util.bufByte(&b, '\n');
            pkt.write(1, b.items);
        } else if (symrefs and unborn and res.flags & refs.REF_ISSYMREF != 0) {
            pkt.writeFmt(1, "unborn HEAD symref-target:{s}\n", .{refs.resolveTarget("HEAD")});
        }
    }
    for (refs.iterate("refs/", .{})) |r| {
        if (!refMatch(prefixes.items, r.name)) continue;
        if (refIsHidden("uploadpack", r.name)) continue;
        var b: util.Buf = .empty;
        util.bufPrint(&b, "{s} {s}", .{ hash.hex(r.oid), r.name });
        if (symrefs and r.flags & refs.REF_ISSYMREF != 0) {
            if (refs.resolve(r.name)) |res| util.bufPrint(&b, " symref-target:{s}", .{res.name});
        }
        if (peel) {
            if (peeledOf(r)) |p| util.bufPrint(&b, " peeled:{s}", .{hash.hex(p)});
        }
        util.bufByte(&b, '\n');
        pkt.write(1, b.items);
    }
    pkt.flush(1);
}

fn fetchV2(rd: *pkt.Reader) void {
    resetShallowState();
    cn.clearAllObjectFlags(THEY_HAVE | COMMON_KNOWN);
    oldest_have = 0;
    want_list = .empty;
    have_list = .empty;
    initSets();
    use_thin = false;
    use_ofs = false;
    no_progress = false;
    include_tag = false;
    done = false;
    wait_for_done = false;
    use_sideband = pkt.LARGE_PACKET_MAX;
    const odb = repo_mod.repo().odb();
    var wanted_refs: std.ArrayList([2][]const u8) = .empty;
    while (rd.read() == .normal) {
        const arg = rd.line;
        if (util.skipPrefix(arg, "want ")) |h| {
            const oid = hash.fromHex(h) orelse {
                pkt.writeFmt(1, "ERR protocol error, expected to get oid, not '{s}'", .{arg});
                util.die("git upload-pack: protocol error, expected to get oid, not '{s}'", .{arg});
            };
            if (!odb.has(oid)) {
                pkt.writeFmt(1, "ERR upload-pack: not our ref {s}", .{hash.hex(oid)});
                util.die("git upload-pack: not our ref {s}", .{hash.hex(oid)});
            }
            addWant(oid);
            continue;
        }
        if (allow_ref_in_want) {
            if (util.skipPrefix(arg, "want-ref ")) |name| {
                const oid = refs.readOid(name) orelse {
                    pkt.writeFmt(1, "ERR unknown ref {s}", .{name});
                    util.die("unknown ref {s}", .{name});
                };
                wanted_refs.append(gpa, .{ util.dupe(name), util.dupe(&hash.hex(oid)) }) catch util.oom();
                addWant(oid);
                continue;
            }
        }
        if (util.skipPrefix(arg, "have ")) |h| {
            const oid = hash.fromHex(h) orelse util.die("git upload-pack: expected SHA1 object, got '{s}'", .{h});
            _ = gotOid(oid);
            seen_haves = true;
            continue;
        }
        if (util.eql(arg, "thin-pack")) {
            use_thin = true;
        } else if (util.eql(arg, "ofs-delta")) {
            use_ofs = true;
        } else if (util.eql(arg, "no-progress")) {
            no_progress = true;
        } else if (util.eql(arg, "include-tag")) {
            include_tag = true;
        } else if (util.eql(arg, "done")) {
            done = true;
        } else if (util.eql(arg, "wait-for-done")) {
            wait_for_done = true;
        } else if (processShallowArgs(arg)) {
        } else if (util.eql(arg, "deepen-relative")) {
            deepen_relative = true;
        } else if (allow_filter and util.startsWith(arg, "filter ")) {
            setFilter(arg["filter ".len..]);
        } else util.die("unexpected line: '{s}'", .{arg});
    }
    if (rd.status != .flush) util.die("expected flush after fetch arguments", .{});
    defer seen_haves = false;
    if (want_list.items.len == 0 and !wait_for_done) return;
    if (seen_haves) {
        if (!done) {
            pkt.write(1, "acknowledgments\n");
            if (have_list.items.len == 0) pkt.write(1, "NAK\n");
            for (have_list.items) |h| pkt.writeFmt(1, "ACK {s}\n", .{hash.hex(h)});
            if (!wait_for_done and okToGiveUp()) {
                pkt.write(1, "ready\n");
                pkt.delim(1);
            } else {
                pkt.flush(1);
                return;
            }
        }
    }
    if (wanted_refs.items.len > 0) {
        pkt.write(1, "wanted-refs\n");
        for (wanted_refs.items) |wr| pkt.writeFmt(1, "{s} {s}\n", .{ wr[1], wr[0] });
        pkt.delim(1);
    }
    sendShallowInfoV2();
    pkt.write(1, "packfile\n");
    createPackFile();
}

var seen_haves = false;

fn serveLoop() void {
    var rd = pkt.Reader.init(0);
    rd.gentle_eof = true;
    while (true) {
        var command: ?[]const u8 = null;
        var st = rd.read();
        if (st == .eof) return;
        if (st == .flush) {
            continue;
        }
        while (st == .normal) {
            const line = rd.line;
            if (util.skipPrefix(line, "command=")) |cmd| {
                if (command != null) util.die("command '{s}' requested after already requesting command '{s}'", .{ cmd, command.? });
                if (!util.eql(cmd, "ls-refs") and !util.eql(cmd, "fetch") and !util.eql(cmd, "object-info")) {
                    util.die("invalid command '{s}'", .{cmd});
                }
                command = util.dupe(cmd);
            } else {
                const known = [_][]const u8{ "agent", "object-format", "server-option", "session-id" };
                var ok = false;
                for (known) |k| {
                    if (util.eql(line, k) or (util.startsWith(line, k) and line.len > k.len and line[k.len] == '=')) ok = true;
                }
                if (!ok) util.die("unknown capability '{s}'", .{line});
                if (util.skipPrefix(line, "object-format=")) |f| {
                    if (!util.eql(f, "sha1")) util.die("mismatched object format: server {s}; client {s}", .{ "sha1", f });
                }
            }
            st = rd.read();
        }
        if (st == .eof) return;
        if (st == .flush) {
            if (command == null) return; // client sent flush: end
            util.die("expected delim or flush", .{});
        }
        if (st != .delim) util.die("expected delim", .{});
        const cmd = command orelse util.die("no command requested", .{});
        if (util.eql(cmd, "ls-refs")) {
            lsRefs(&rd);
        } else if (util.eql(cmd, "fetch")) {
            fetchV2(&rd);
        } else {
            while (rd.read() == .normal) {}
            pkt.flush(1);
        }
    }
}

// ---------------- command ----------------

var opt_stateless = false;
var opt_advertise = false;
var opt_strict = false;
var opt_timeout: i32 = 0;

const usage = [_][]const u8{"git-upload-pack [--[no-]strict] [--timeout=<n>] [--stateless-rpc]\n                [--advertise-refs] <directory>"};
const options = [_]po.Opt{
    po.boolean(0, "stateless-rpc", &opt_stateless, "quit after a single request/response exchange"),
    .{ .long = "http-backend-info-refs", .kind = .boolean, .b = &opt_advertise, .hidden = true, .help = "serve up the info/refs for git-http-backend" },
    .{ .long = "advertise-refs", .kind = .boolean, .b = &opt_advertise, .hidden = true, .from_alias = true, .help = "serve up the info/refs for git-http-backend" },
    po.boolean(0, "strict", &opt_strict, "do not try <directory>/.git/ if <directory> is no Git directory"),
    po.integer(0, "timeout", &opt_timeout, "n", "interrupt transfer after <n> seconds of inactivity"),
};

pub fn cmdUploadPack(args: []const []const u8) u8 {
    if (os.getenv("GIT_NO_LAZY_FETCH") == null) os.setEnv("GIT_NO_LAZY_FETCH", "1");
    @import("../pktline.zig").traceIdentity("upload-pack");
    const rest = po.parse(args[1..], &options, &usage, .{});
    if (rest.len != 1) po.usageWithOptions(&usage, &options);
    proc.ignoreSigpipe();
    const dir = rest[0];
    if (!enterRepo(dir, opt_strict)) util.die("'{s}' does not appear to be a git repository", .{dir});
    stateless_rpc = opt_stateless;
    loadConfig();
    initSets();
    switch (protocolVersionServer()) {
        2 => {
            if (opt_advertise) {
                advertiseV2();
            } else {
                if (!stateless_rpc) advertiseV2();
                serveLoop();
            }
        },
        1 => {
            if (opt_advertise or !stateless_rpc) pkt.write(1, "version 1\n");
            uploadPackV0(opt_advertise);
        },
        else => uploadPackV0(opt_advertise),
    }
    return 0;
}
