//! Port of wt-status.c (status machinery) from git v2.56.1.
//!
//! Public API (used by `git status` and `git commit`):
//!   prepare() Status                 wt_status_prepare
//!   initConfig(*Status)              git_status_config + determine_whence + hints
//!   finalizeDeferredConfig(*Status, Format)  builtin/commit.c finalize_deferred_config
//!   collect(*Status)                 wt_status_collect
//!   print(*Status)                   wt_status_print
//!   printfLn / printf                status_printf_ln / status_printf
//!   addCutLine / appendCutLine / locateEnd
//!   determineWhence() Whence
//!   getState(get_detached_from) State   wt_status_get_state
//!   hasUnstagedChanges / hasUncommittedChanges / requireCleanWorkTree

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const pathspec_mod = @import("pathspec.zig");
const hash = @import("hash.zig");
const index_mod = @import("index.zig");
const dir_mod = @import("dir.zig");
const refs = @import("refs.zig");
const revparse = @import("revparse.zig");
const objects = @import("objects.zig");
const cn = @import("commitnode.zig");
const commitreach = @import("commitreach.zig");
const color_mod = @import("color.zig");
const advice = @import("advice.zig");
const config = @import("config.zig");
const lockfile = @import("lockfile.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Index = index_mod.Index;

pub const Format = enum { unspecified, none, long, short, porcelain, porcelain_v2 };
pub const Whence = enum { commit, merge, cherry_pick_single, cherry_pick_multi, rebase_pick };
pub const UntrackedMode = enum(u8) { err, no, normal, all };
pub const IgnoredMode = enum(u8) { no, traditional, matching };
pub const AheadBehind = enum { unspecified, quick, full };

pub const DIRTY_SUBMODULE_UNTRACKED: u32 = 1;
pub const DIRTY_SUBMODULE_MODIFIED: u32 = 2;

pub const DETECT_RENAME: i32 = 1;
pub const DETECT_COPY: i32 = 2;

const cut_line = "------------------------ >8 ------------------------\n";

pub const Slot = enum(u8) { header = 0, updated, changed, untracked, nobranch, unmerged, local_branch, remote_branch, onbranch };
const NIL = "NIL";

const default_palette = [9][]const u8{
    "", // header (GIT_COLOR_NORMAL)
    color_mod.GREEN, // updated
    color_mod.RED, // changed
    color_mod.RED, // untracked
    color_mod.RED, // nobranch
    color_mod.RED, // unmerged
    color_mod.GREEN, // local branch
    color_mod.RED, // remote branch
    NIL, // onbranch
};

/// struct wt_status_change_data
pub const Change = struct {
    path: []const u8,
    worktree_status: u8 = 0,
    index_status: u8 = 0,
    stagemask: u32 = 0,
    mode_head: u32 = 0,
    mode_index: u32 = 0,
    mode_worktree: u32 = 0,
    oid_head: Oid = hash.zero,
    oid_index: Oid = hash.zero,
    rename_status: u8 = 0,
    rename_score: i32 = 0,
    rename_source: ?[]const u8 = null,
    dirty_submodule: u32 = 0,
    new_submodule_commits: bool = false,
};

/// struct wt_status_state
pub const State = struct {
    merge_in_progress: bool = false,
    am_in_progress: bool = false,
    am_empty_patch: bool = false,
    rebase_in_progress: bool = false,
    rebase_interactive_in_progress: bool = false,
    cherry_pick_in_progress: bool = false,
    bisect_in_progress: bool = false,
    revert_in_progress: bool = false,
    detached_at: bool = false,
    branch: ?[]const u8 = null,
    onto: ?[]const u8 = null,
    detached_from: ?[]const u8 = null,
    bisecting_from: ?[]const u8 = null,
    detached_oid: Oid = hash.zero,
    revert_head_oid: Oid = hash.zero,
    cherry_pick_head_oid: Oid = hash.zero,
    /// -1: disabled, -2: sparse index, else percentage
    sparse_checkout_percentage: i32 = -1,
};

pub const Status = struct {
    is_initial: bool = false,
    /// full ref of HEAD ("refs/heads/x"), "HEAD" if detached, null if unresolvable
    branch: ?[]const u8 = null,
    reference: []const u8 = "HEAD",
    pathspec: pathspec_mod.Pathspec = .{},
    verbose: i32 = 0,
    amend: bool = false,
    whence: Whence = .commit,
    nowarn: bool = false,
    /// false disables color entirely (commit sets it when writing to a file)
    use_color: bool = true,
    /// status.color / color.status config value
    color_bool: color_mod.ColorBool = .unknown,
    no_gettext: bool = false,
    display_comment_prefix: bool = false,
    relative_paths: bool = true,
    submodule_summary: i32 = 0,
    show_ignored_mode: IgnoredMode = .no,
    show_untracked_files: UntrackedMode = .normal,
    ignore_submodule_arg: ?[]const u8 = null,
    color_palette: [9][]const u8 = default_palette,
    colopts: u32 = 0,
    null_termination: bool = false,
    commit_template: bool = false,
    show_branch: i32 = -1,
    show_stash: bool = false,
    hints: bool = true,
    ahead_behind_flags: AheadBehind = .unspecified,
    detect_rename: i32 = -1,
    rename_score: i32 = -1,
    rename_limit: i32 = -1,
    status_format: Format = .unspecified,
    state: State = .{},
    added_cut_line: bool = false,
    oid_commit: Oid = hash.zero,
    committable: bool = false,
    workdir_dirty: bool = false,
    index_file: []const u8 = "",
    out: *util.Out = &util.stdout,
    /// true when `out` is the real stdout (C: s->fp == stdout)
    out_is_stdout: bool = true,
    prefix: ?[]const u8 = null,
    untracked_in_ms: u64 = 0,
    /// index to inspect; if null, collect() loads it (from index_file if set)
    idx: ?*Index = null,

    // deferred config (builtin/commit.c status_deferred_config), set by initConfig
    deferred_format: Format = .unspecified,
    deferred_show_branch: i32 = -1,
    deferred_ahead_behind: AheadBehind = .unspecified,

    change: std.ArrayList(*Change) = .empty,
    change_map: std.StringHashMapUnmanaged(*Change) = .empty,
    untracked: std.ArrayList([]const u8) = .empty,
    ignored: std.ArrayList([]const u8) = .empty,
};

// ---------------------------------------------------------------------------
// colors and printing

fn wantColor(cb0: color_mod.ColorBool) bool {
    var cb = cb0;
    if (cb == .unknown) {
        if (repo_mod.cfg.getEntry("color.ui")) |e| cb = color_mod.configColorBool("color.ui", e.value);
    }
    return color_mod.wantColorBool(cb, null);
}

fn color(slot: Slot, s: *Status) []const u8 {
    var c: []const u8 = "";
    if (s.use_color and wantColor(s.color_bool)) c = s.color_palette[@intFromEnum(slot)];
    if (slot == .onbranch and util.eql(c, NIL)) c = s.color_palette[@intFromEnum(Slot.header)];
    if (util.eql(c, NIL)) c = "";
    return c;
}

fn colorWrite(o: *util.Out, col: []const u8, text: []const u8) void {
    if (col.len > 0) o.write(col);
    o.write(text);
    if (col.len > 0) o.write(color_mod.RESET);
}

/// color_fprintf_ln: colored text followed by a newline.
fn colorWriteLn(o: *util.Out, col: []const u8, text: []const u8) void {
    colorWrite(o, col, text);
    o.write("\n");
}

/// The comment string (core.commentChar / core.commentString), default "#".
pub fn commentStr() []const u8 {
    const v = repo_mod.cfg.get("core.commentstring") orelse repo_mod.cfg.get("core.commentchar") orelse return "#";
    if (v.len == 0) return "#";
    if (util.eql(v, "auto")) return "#";
    return v;
}

fn vprintf(s: *Status, at_bol0: bool, col: []const u8, text: []const u8, trail: ?[]const u8) void {
    var at_bol = at_bol0;
    const o = s.out;
    if (text.len == 0) {
        var sb: util.Buf = .empty;
        if (s.display_comment_prefix) {
            util.bufAppend(&sb, commentStr());
            if (trail == null) util.bufByte(&sb, ' ');
        }
        colorWrite(o, col, sb.items);
        if (trail) |t| o.write(t);
        return;
    }
    var line_start: usize = 0;
    var linebuf: util.Buf = .empty;
    while (line_start < text.len) {
        const line = text[line_start..];
        const eol = std.mem.indexOfScalar(u8, line, '\n');
        linebuf.clearRetainingCapacity();
        if (at_bol and s.display_comment_prefix) {
            util.bufAppend(&linebuf, commentStr());
            if (line[0] != '\n' and line[0] != '\t') util.bufByte(&linebuf, ' ');
        }
        if (eol) |e| util.bufAppend(&linebuf, line[0..e]) else util.bufAppend(&linebuf, line);
        colorWrite(o, col, linebuf.items);
        if (eol) |e| {
            o.write("\n");
            line_start += e + 1;
        } else break;
        at_bol = true;
    }
    if (trail) |t| o.write(t);
}

pub fn printfLn(s: *Status, col: []const u8, comptime f: []const u8, args: anytype) void {
    vprintf(s, true, col, util.fmt(f, args), "\n");
}

pub fn printf(s: *Status, col: []const u8, comptime f: []const u8, args: anytype) void {
    vprintf(s, true, col, util.fmt(f, args), null);
}

fn printfMore(s: *Status, col: []const u8, comptime f: []const u8, args: anytype) void {
    vprintf(s, false, col, util.fmt(f, args), null);
}

fn lineOut(s: *Status, col: []const u8, text: []const u8) void {
    vprintf(s, true, col, text, "\n");
}

// ---------------------------------------------------------------------------
// prepare / config

/// wt_status_prepare()
pub fn prepare() Status {
    var s = Status{};
    s.branch = resolveHeadRefdup();
    s.reference = "HEAD";
    s.index_file = repo_mod.repo().indexPath();
    return s;
}

/// refs_resolve_refdup("HEAD", 0): full ref name HEAD points to (even if
/// unborn), "HEAD" when detached, null on error.
fn resolveHeadRefdup() ?[]const u8 {
    var name: []const u8 = "HEAD";
    var depth: usize = 0;
    while (depth < 6) : (depth += 1) {
        switch (refs.readRawFull(name)) {
            .symref => |t| name = t,
            .oid => return name,
            .missing => return if (util.eql(name, "HEAD")) null else name,
            else => return null,
        }
    }
    return null;
}

fn parseStatusSlot(slot: []const u8) ?Slot {
    const names = [_]struct { n: []const u8, s: Slot }{
        .{ .n = "header", .s = .header },
        .{ .n = "updated", .s = .updated },
        .{ .n = "changed", .s = .changed },
        .{ .n = "untracked", .s = .untracked },
        .{ .n = "nobranch", .s = .nobranch },
        .{ .n = "unmerged", .s = .unmerged },
        .{ .n = "localbranch", .s = .local_branch },
        .{ .n = "remotebranch", .s = .remote_branch },
        .{ .n = "branch", .s = .onbranch },
        .{ .n = "added", .s = .updated },
    };
    for (names) |n| if (std.ascii.eqlIgnoreCase(slot, n.n)) return n.s;
    return null;
}

fn configBool(k: []const u8, v: ?[]const u8) bool {
    const val = v orelse return true;
    return config.parseBool(val) orelse util.die("bad boolean config value '{s}' for '{s}'", .{ val, k });
}

fn configInt(k: []const u8, v: ?[]const u8) i32 {
    const val = v orelse util.die("bad numeric config value '' for '{s}': invalid unit", .{k});
    const n = config.parseInt(val) orelse util.die("bad numeric config value '{s}' for '{s}': invalid unit", .{ val, k });
    return @intCast(std.math.clamp(n, std.math.minInt(i32), std.math.maxInt(i32)));
}

/// git_config_rename()
pub fn configRename(k: []const u8, v: ?[]const u8) i32 {
    const val = v orelse return DETECT_RENAME;
    if (std.ascii.eqlIgnoreCase(val, "copies") or std.ascii.eqlIgnoreCase(val, "copy")) return DETECT_COPY;
    return if (configBool(k, val)) DETECT_RENAME else 0;
}

/// parse_untracked_setting_name()
fn parseUntrackedSettingOpt(name: ?[]const u8) UntrackedMode {
    var u: []const u8 = name orelse "";
    switch (config.parseMaybeBool(name)) {
        0 => u = "no",
        1 => u = "normal",
        else => {},
    }
    if (util.eql(u, "no")) return .no;
    if (util.eql(u, "normal")) return .normal;
    if (util.eql(u, "all")) return .all;
    return .err;
}

pub fn parseUntrackedSetting(name: []const u8) UntrackedMode {
    return parseUntrackedSettingOpt(name);
}

/// Apply one config entry (git_status_config). Returns false for unknown keys.
fn dieBadConfig(e: *const config.Entry) noreturn {
    if (e.origin_type == .cmdline) util.die("unable to parse '{s}' from command-line config", .{e.key});
    util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
}

pub fn applyConfig(s: *Status, e: *const config.Entry) bool {
    const k = e.key;
    const v = e.value;
    const kvi = e.kvi();
    if (util.startsWith(k, "column.")) {
        columnConfig(s, e);
        return true;
    }
    if (util.eql(k, "status.submodulesummary")) {
        var is_bool = false;
        s.submodule_summary = config.configBoolOrInt(k, v, &kvi, &is_bool);
        if (is_bool and s.submodule_summary != 0) s.submodule_summary = -1;
        return true;
    }
    if (util.eql(k, "status.short")) {
        s.deferred_format = if (configBool(k, v)) .short else .none;
        return true;
    }
    if (util.eql(k, "status.branch")) {
        s.deferred_show_branch = if (configBool(k, v)) 1 else 0;
        return true;
    }
    if (util.eql(k, "status.aheadbehind")) {
        s.deferred_ahead_behind = if (configBool(k, v)) .full else .quick;
        return true;
    }
    if (util.eql(k, "status.showstash")) {
        s.show_stash = configBool(k, v);
        return true;
    }
    if (util.eql(k, "status.color") or util.eql(k, "color.status")) {
        s.color_bool = color_mod.configColorBool(k, v);
        return true;
    }
    if (util.eql(k, "status.displaycommentprefix")) {
        s.display_comment_prefix = configBool(k, v);
        return true;
    }
    const slot_name = util.skipPrefix(k, "status.color.") orelse util.skipPrefix(k, "color.status.");
    if (slot_name) |sn| {
        const slot = parseStatusSlot(sn) orelse return true;
        const val = v orelse {
            util.err("missing value for '{s}'", .{k});
            dieBadConfig(e);
        };
        const c = color_mod.parseColorOrError(val) orelse dieBadConfig(e);
        s.color_palette[@intFromEnum(slot)] = c;
        return true;
    }
    if (util.eql(k, "status.relativepaths")) {
        s.relative_paths = configBool(k, v);
        return true;
    }
    if (util.eql(k, "status.showuntrackedfiles")) {
        const u = parseUntrackedSettingOpt(v);
        if (u == .err) {
            util.err("Invalid untracked files mode '{s}'", .{v orelse ""});
            dieBadConfig(e);
        }
        s.show_untracked_files = u;
        return true;
    }
    if (util.eql(k, "diff.renamelimit")) {
        if (s.rename_limit == -1) s.rename_limit = config.configInt(k, v, &kvi);
        return true;
    }
    if (util.eql(k, "status.renamelimit")) {
        s.rename_limit = config.configInt(k, v, &kvi);
        return true;
    }
    if (util.eql(k, "diff.renames")) {
        if (s.detect_rename == -1) s.detect_rename = configRename(k, v);
        return true;
    }
    if (util.eql(k, "status.renames")) {
        s.detect_rename = configRename(k, v);
        return true;
    }
    return false;
}

/// status_init_config() minus wt_status_prepare: read config into s,
/// determine whence, and set hints.
pub fn initConfig(s: *Status) void {
    for (repo_mod.cfg.entries.items) |e| {
        _ = applyConfig(s, &e);
    }
    s.whence = determineWhence();
    s.hints = advice.enabled("statusHints");
}

/// finalize_deferred_config() from builtin/commit.c; `fmt` is the format
/// selected on the command line (or .unspecified). Sets s.status_format.
pub fn finalizeDeferredConfig(s: *Status, fmt0: Format) void {
    var fmt = fmt0;
    const use_deferred = fmt != .porcelain and fmt != .porcelain_v2 and !s.null_termination;
    if (s.null_termination) {
        if (fmt == .none or fmt == .unspecified) {
            fmt = .porcelain;
        } else if (fmt == .long) {
            util.die("options '{s}' and '{s}' cannot be used together", .{ "--long", "-z" });
        }
    }
    if (use_deferred and fmt == .unspecified) fmt = s.deferred_format;
    if (fmt == .unspecified) fmt = .none;
    if (use_deferred and s.show_branch < 0) s.show_branch = s.deferred_show_branch;
    if (s.show_branch < 0) s.show_branch = 0;
    if (use_deferred and s.ahead_behind_flags == .unspecified) s.ahead_behind_flags = s.deferred_ahead_behind;
    if (s.ahead_behind_flags == .unspecified) s.ahead_behind_flags = .full;
    s.status_format = fmt;
}

/// determine_whence() + sequencer_determine_whence()
pub fn determineWhence() Whence {
    const r = repo_mod.repo();
    if (os.exists(r.gitPath("MERGE_HEAD"))) return .merge;
    if (refs.exists("CHERRY_PICK_HEAD")) {
        var w: Whence = .cherry_pick_single;
        if (os.exists(r.gitPath("sequencer"))) w = .cherry_pick_multi;
        const rebase_head = revparse.getOid("REBASE_HEAD");
        const cp_head = revparse.getOid("CHERRY_PICK_HEAD");
        if (os.exists(r.gitPath("rebase-merge")) and rebase_head != null and cp_head != null and hash.eql(rebase_head.?, cp_head.?)) {
            w = .rebase_pick;
        } else w = .cherry_pick_single;
        return w;
    }
    return .commit;
}

// ---------------------------------------------------------------------------
// column support (port of the parts of column.c used by status)

const COL_LAYOUT_MASK: u32 = 0x000F;
const COL_COLUMN: u32 = 0;
const COL_ROW: u32 = 1;
const COL_PLAIN: u32 = 15;
const COL_ENABLE_MASK: u32 = 0x0030;
const COL_ENABLED: u32 = 0x0010;
const COL_AUTO: u32 = 0x0020;
const COL_DISABLED: u32 = 0x0000;
const COL_PARSEOPT: u32 = 0x0040;
const COL_DENSE: u32 = 0x0080;

fn columnActive(colopts: u32) bool {
    return colopts & COL_ENABLE_MASK == COL_ENABLED;
}

/// parse_option() / parse_config() for column options; returns false on error.
pub fn parseColumnOption(value: []const u8, colopts: *u32) bool {
    var it = std.mem.tokenizeAny(u8, value, " ,");
    var group_set: u32 = 0;
    while (it.next()) |word0| {
        var word = word0;
        var set = true;
        if (util.skipPrefix(word, "no")) |r| {
            if (util.eql(r, "dense")) {
                set = false;
                word = r;
            }
        }
        const Entry = struct { n: []const u8, mask: u32, v: u32 };
        const table = [_]Entry{
            .{ .n = "always", .mask = COL_ENABLE_MASK, .v = COL_ENABLED },
            .{ .n = "never", .mask = COL_ENABLE_MASK, .v = COL_DISABLED },
            .{ .n = "auto", .mask = COL_ENABLE_MASK, .v = COL_AUTO },
            .{ .n = "plain", .mask = COL_LAYOUT_MASK, .v = COL_PLAIN },
            .{ .n = "column", .mask = COL_LAYOUT_MASK, .v = COL_COLUMN },
            .{ .n = "row", .mask = COL_LAYOUT_MASK, .v = COL_ROW },
            .{ .n = "dense", .mask = COL_DENSE, .v = COL_DENSE },
        };
        var found = false;
        for (table) |t| {
            if (!util.eql(word, t.n)) continue;
            found = true;
            if (t.mask == COL_DENSE) {
                if (set) colopts.* |= COL_DENSE else colopts.* &= ~COL_DENSE;
            } else {
                if (t.mask == COL_LAYOUT_MASK) group_set |= 1;
                if (t.mask == COL_ENABLE_MASK) group_set |= 2;
                colopts.* = (colopts.* & ~t.mask) | t.v;
            }
        }
        if (!found) {
            util.err("unsupported option '{s}'", .{word0});
            return false;
        }
    }
    // a layout option implies "always" when no enable option was given
    if (group_set & 1 != 0 and group_set & 2 == 0) colopts.* = (colopts.* & ~COL_ENABLE_MASK) | COL_ENABLED;
    return true;
}

fn columnConfig(s: *Status, e: *const config.Entry) void {
    const k = e.key;
    const v = e.value;
    const name = k["column.".len..];
    if (util.eql(name, "ui") or util.eql(name, "status")) {
        const val = v orelse {
            util.err("missing value for '{s}'", .{k});
            dieBadConfig(e);
        };
        if (!parseColumnOption(val, &s.colopts)) {
            util.err("invalid column.{s} mode {s}", .{ name, val });
            dieBadConfig(e);
        }
    }
}

/// finalize_colopts(): resolve "auto" against stdout being a terminal.
pub fn finalizeColopts(colopts: *u32, stdout_is_tty: i32) void {
    if (colopts.* & COL_ENABLE_MASK == COL_AUTO) {
        var tty = stdout_is_tty;
        if (tty < 0) tty = if (os.isatty(1)) 1 else 0;
        colopts.* &= ~COL_ENABLE_MASK;
        if (tty != 0 or color_mod.pagerInUse()) colopts.* |= COL_ENABLED;
    }
}

extern "c" fn ioctl(fd: c_int, req: c_ulong, ...) c_int;

fn termColumns() usize {
    if (os.getenv("COLUMNS")) |c| {
        if (std.fmt.parseInt(usize, c, 10)) |n| {
            if (n > 0) return n;
        } else |_| {}
    }
    var ws: [4]u16 = .{ 0, 0, 0, 0 };
    if (ioctl(1, 0x5413, &ws) == 0 and ws[1] > 0) return ws[1];
    return 80;
}

fn strWidth(str: []const u8) usize {
    // utf8_strwidth, ignoring ANSI color sequences
    var w: usize = 0;
    var i: usize = 0;
    while (i < str.len) {
        const ch = str[i];
        if (ch == 0x1b and i + 1 < str.len and str[i + 1] == '[') {
            i += 2;
            while (i < str.len and (std.ascii.isDigit(str[i]) or str[i] == ';')) i += 1;
            if (i < str.len and str[i] == 'm') i += 1;
            continue;
        }
        if (ch < 0x80) {
            w += 1;
            i += 1;
            continue;
        }
        const len = std.unicode.utf8ByteSequenceLength(ch) catch {
            w += 1;
            i += 1;
            continue;
        };
        if (i + len > str.len) {
            w += 1;
            i += 1;
            continue;
        }
        const cp = std.unicode.utf8Decode(str[i .. i + len]) catch {
            w += 1;
            i += 1;
            continue;
        };
        w += if (isWide(cp)) 2 else 1;
        i += len;
    }
    return w;
}

fn isWide(cp: u21) bool {
    return (cp >= 0x1100 and cp <= 0x115f) or (cp >= 0x2e80 and cp <= 0xa4cf and cp != 0x303f) or
        (cp >= 0xac00 and cp <= 0xd7a3) or (cp >= 0xf900 and cp <= 0xfaff) or (cp >= 0xfe30 and cp <= 0xfe6f) or
        (cp >= 0xff00 and cp <= 0xff60) or (cp >= 0xffe0 and cp <= 0xffe6) or (cp >= 0x20000 and cp <= 0x3fffd);
}

const ColumnOpts = struct { width: usize = 0, padding: usize = 1, indent: []const u8 = "", nl: []const u8 = "\n" };

const ColData = struct {
    n: usize,
    layout: u32,
    rows: usize = 0,
    cols: usize = 0,
    len: []usize,
    width: ?[]usize = null,
    fn linear(d: *const ColData, x: usize, y: usize) usize {
        if (d.layout == COL_COLUMN) return x * d.rows + y;
        return y * d.cols + x;
    }
    fn computeColumnWidth(d: *ColData) void {
        const w = d.width.?;
        for (0..d.cols) |x| {
            w[x] = d.linear(x, 0);
            for (0..d.rows) |y| {
                const i = d.linear(x, y);
                if (i < d.n and d.len[w[x]] < d.len[i]) w[x] = i;
            }
        }
    }
};

/// print_columns() (column.c)
fn printColumns(o: *util.Out, list: []const []const u8, colopts: u32, copts: ColumnOpts) void {
    if (list.len == 0) return;
    const width: usize = if (copts.width > 0) copts.width else termColumns() - 1;
    if (!columnActive(colopts)) {
        for (list) |item| {
            o.write(item);
            o.write("\n");
        }
        return;
    }
    const layout = colopts & COL_LAYOUT_MASK;
    if (layout == COL_PLAIN) {
        for (list) |item| {
            o.write(copts.indent);
            o.write(item);
            o.write(copts.nl);
        }
        return;
    }
    var d = ColData{ .n = list.len, .layout = layout, .len = gpa.alloc(usize, list.len) catch util.oom() };
    for (list, 0..) |item, i| d.len[i] = strWidth(item);
    // layout()
    var initial_width: usize = 0;
    for (d.len) |l| if (initial_width < l) {
        initial_width = l;
    };
    initial_width += copts.padding;
    const avail: usize = if (width > copts.indent.len) width - copts.indent.len else 0;
    d.cols = avail / initial_width;
    if (d.cols == 0) d.cols = 1;
    d.rows = (d.n + d.cols - 1) / d.cols;
    if (colopts & COL_DENSE != 0) {
        // shrink_columns()
        d.width = gpa.alloc(usize, d.cols) catch util.oom();
        while (d.rows > 1) {
            const rows = d.rows;
            const cols = d.cols;
            d.rows -= 1;
            d.cols = (d.n + d.rows - 1) / d.rows;
            if (d.cols != cols) d.width = gpa.realloc(d.width.?, d.cols) catch util.oom();
            d.computeColumnWidth();
            var total: usize = copts.indent.len;
            for (0..d.cols) |x| total += d.len[d.width.?[x]] + copts.padding;
            if (total > width) {
                d.rows = rows;
                d.cols = cols;
                break;
            }
        }
        if (d.width.?.len < d.cols) d.width = gpa.realloc(d.width.?, d.cols) catch util.oom();
        d.computeColumnWidth();
    }
    for (0..d.rows) |y| {
        for (0..d.cols) |x| {
            // display_cell()
            const i = d.linear(x, y);
            if (i >= d.n) break;
            var len: isize = @intCast(d.len[i]);
            if (d.width) |w| {
                const cw = d.len[w[x]];
                if (cw < initial_width) {
                    len += @as(isize, @intCast(initial_width - cw));
                    len -= @as(isize, @intCast(copts.padding));
                }
            }
            const newline = if (layout == COL_COLUMN) i + d.rows >= d.n else (x == d.cols - 1 or i == d.n - 1);
            if (x == 0) o.write(copts.indent);
            o.write(list[i]);
            if (newline) {
                o.write(copts.nl);
            } else {
                var pad: isize = @as(isize, @intCast(initial_width)) - len;
                while (pad > 0) : (pad -= 1) o.byte(' ');
            }
        }
    }
}

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// minimal diff machinery: diff-files, diff-index --cached, exact renames
// (diff-lib.c, diff.c, diffcore-rename.c, submodule.c)

pub const MAX_SCORE: i32 = 60000;

const Spec = struct {
    path: []const u8,
    mode: u32 = 0,
    oid: Oid = hash.zero,
    oid_valid: bool = false,
    dirty_submodule: u32 = 0,
    rename_used: i32 = 0,
};

const Pair = struct {
    one: *Spec,
    two: *Spec,
    status: u8 = 0,
    score: i32 = 0,
    renamed: bool = false,
    unmerged: bool = false,
};

fn specValid(sp: *const Spec) bool {
    return sp.mode != 0;
}

fn newSpec(path: []const u8) *Spec {
    const sp = gpa.create(Spec) catch util.oom();
    sp.* = .{ .path = path };
    return sp;
}

fn fillSpec(sp: *Spec, oid: Oid, oid_valid: bool, mode: u32) void {
    sp.mode = index_mod.canonMode(mode);
    sp.oid = oid;
    sp.oid_valid = oid_valid;
}

const SubFlags = struct {
    ignore_submodules: bool = false,
    ignore_dirty: bool = false,
    ignore_untracked: bool = false,
    set: bool = false,
};

const DiffOpts = struct {
    detect_rename: i32 = DETECT_RENAME,
    rename_score: i32 = 0,
    rename_limit: i32 = 0,
    flags: SubFlags = .{},
    override_submodule_config: bool = false,
    dirty_submodules: bool = false,
    ita_invisible: bool = false,
    quick: bool = false,
    has_changes: bool = false,
    pathspec: ?*const pathspec_mod.Pathspec = null,
    queue: std.ArrayList(*Pair) = .empty,
};

/// handle_ignore_submodules_arg()
fn handleIgnoreSubmodulesArg(f: *SubFlags, arg: []const u8) void {
    f.set = true;
    f.ignore_submodules = false;
    f.ignore_untracked = false;
    f.ignore_dirty = false;
    if (util.eql(arg, "all")) {
        f.ignore_submodules = true;
    } else if (util.eql(arg, "untracked")) {
        f.ignore_untracked = true;
    } else if (util.eql(arg, "dirty")) {
        f.ignore_dirty = true;
    } else if (!util.eql(arg, "none")) {
        util.die("bad --ignore-submodules argument: {s}", .{arg});
    }
}

/// Initialize diff options the way repo_diff_setup() + git_diff_ui_config do
/// for the bits status cares about.
fn diffSetup() DiffOpts {
    var o = DiffOpts{};
    // diff.renames (diff_detect_rename_default)
    if (repo_mod.cfg.getEntry("diff.renames")) |e| o.detect_rename = configRename(e.key, e.value);
    if (repo_mod.cfg.getEntry("diff.renamelimit")) |e| {
        const kvi = e.kvi();
        o.rename_limit = config.configInt(e.key, e.value, &kvi);
    }
    if (repo_mod.cfg.get("diff.ignoresubmodules")) |v| handleIgnoreSubmodulesArg(&o.flags, v);
    return o;
}

var gitmodules_cfg: ?config.Config = null;

fn gitmodulesConfig() *config.Config {
    if (gitmodules_cfg == null) {
        var c: config.Config = .{};
        if (os.lstatPath(".gitmodules") != null) {
            _ = config.readFileInto(&c, ".gitmodules", .local);
        } else if (index_mod.get().get(".gitmodules")) |e| {
            if (repo_mod.repo().odb().read(e.oid)) |obj| {
                _ = config.readBlobInto(&c, obj.data, ":.gitmodules", .local);
            }
        }
        gitmodules_cfg = c;
    }
    return &gitmodules_cfg.?;
}


/// Name of the submodule at `path` according to .gitmodules, or null.
pub fn submoduleNameForPath(path: []const u8) ?[]const u8 {
    const c = gitmodulesConfig();
    var i = c.entries.items.len;
    while (i > 0) {
        i -= 1;
        const e = c.entries.items[i];
        const rest = util.skipPrefix(e.key, "submodule.") orelse continue;
        if (!util.endsWith(rest, ".path")) continue;
        const v = e.value orelse continue;
        if (util.eql(v, path)) return rest[0 .. rest.len - ".path".len];
    }
    return null;
}

fn isGitmodulesUnmerged() bool {
    const idx = index_mod.get();
    switch (idx.pos(".gitmodules", 0)) {
        .found => return false,
        .missing => |p| {
            if (p < idx.entries.items.len and util.eql(idx.entries.items[p].path, ".gitmodules")) return true;
            return false;
        },
    }
}

/// set_diffopt_flags_from_submodule_config()
fn setFlagsFromSubmoduleConfig(f: *SubFlags, path: []const u8) void {
    const name = submoduleNameForPath(path) orelse return;
    const key = util.concat(&.{ "submodule.", name, ".ignore" });
    var ignore: ?[]const u8 = repo_mod.cfg.get(key);
    if (ignore == null) {
        if (gitmodulesConfig().get(key)) |v| {
            if (util.eql(v, "untracked") or util.eql(v, "dirty") or util.eql(v, "all") or util.eql(v, "none")) {
                ignore = v;
            } else util.warn("Invalid parameter '{s}' for config option 'submodule.{s}.ignore'", .{ v, name });
        }
    }
    if (ignore) |v| {
        handleIgnoreSubmodulesArg(f, v);
    } else if (isGitmodulesUnmerged()) f.ignore_submodules = true;
}

fn isSubmoduleIgnored(o: *DiffOpts, path: []const u8) bool {
    var f = o.flags;
    if (!o.override_submodule_config) setFlagsFromSubmoduleConfig(&f, path);
    return f.ignore_submodules;
}

const local_repo_env = [_][]const u8{
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CONFIG",           "GIT_OBJECT_DIRECTORY",
    "GIT_DIR",                          "GIT_WORK_TREE",        "GIT_IMPLICIT_WORK_TREE",
    "GIT_GRAFT_FILE",                   "GIT_INDEX_FILE",       "GIT_NO_REPLACE_OBJECTS",
    "GIT_REPLACE_REF_BASE",             "GIT_PREFIX",           "GIT_SHALLOW_FILE",
    "GIT_COMMON_DIR",
};

fn selfExe() []const u8 {
    return os.readLink("/proc/self/exe") orelse "git";
}

/// is_submodule_modified()
pub fn isSubmoduleModified(path: []const u8, ignore_untracked: bool) u32 {
    const dotgit = util.concat(&.{ path, "/.git" });
    const git_dir = repo_mod.readGitfile(dotgit) orelse dotgit;
    if (!repo_mod.isGitDirectory(git_dir)) {
        if (os.isDir(git_dir)) util.die("'{s}' not recognized as a git repository", .{git_dir});
        return 0;
    }
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ selfExe(), "status", "--porcelain=2" }) catch util.oom();
    if (ignore_untracked) argv.append(gpa, "-uno") catch util.oom();
    const r = os.run(argv.items, .{
        .capture_stdout = true,
        .no_stdin = true,
        .cwd = path,
        .env = &.{.{ "GIT_DIR", ".git" }},
        .unset_env = &local_repo_env,
    });
    var dirty: u32 = 0;
    var ignore_exit = false;
    var it = std.mem.splitScalar(u8, r.stdout, '\n');
    while (it.next()) |line| {
        if (line.len == 0) continue;
        if (line[0] == '?') dirty |= DIRTY_SUBMODULE_UNTRACKED;
        if (line[0] == 'u' or line[0] == '1' or line[0] == '2') {
            if (line.len >= 9) {
                if (line[5] == 'S' and line[8] == 'U') dirty |= DIRTY_SUBMODULE_UNTRACKED;
                if (line[0] == 'u' or line[0] == '2' or !std.mem.eql(u8, line[5..9], "S..U"))
                    dirty |= DIRTY_SUBMODULE_MODIFIED;
            }
        }
        if (dirty & DIRTY_SUBMODULE_MODIFIED != 0 and (dirty & DIRTY_SUBMODULE_UNTRACKED != 0 or ignore_untracked)) {
            ignore_exit = true;
            break;
        }
    }
    if (r.status != 0 and !ignore_exit) util.die("'git status --porcelain=2' failed in submodule {s}", .{path});
    return dirty;
}

fn queuePair(o: *DiffOpts, one: *Spec, two: *Spec) *Pair {
    const p = gpa.create(Pair) catch util.oom();
    p.* = .{ .one = one, .two = two };
    o.queue.append(gpa, p) catch util.oom();
    return p;
}

/// diff_addremove()
fn diffAddremove(o: *DiffOpts, addremove: u8, mode: u32, oid: Oid, oid_valid: bool, path: []const u8, dirty: u32) void {
    if (mode & os.S_IFMT == os.S_IFGITLINK and isSubmoduleIgnored(o, path)) return;
    const one = newSpec(path);
    const two = newSpec(path);
    if (addremove != '+') fillSpec(one, oid, oid_valid, mode);
    if (addremove != '-') {
        fillSpec(two, oid, oid_valid, mode);
        two.dirty_submodule = dirty;
    }
    _ = queuePair(o, one, two);
    o.has_changes = true;
}

/// diff_change()
fn diffChange(o: *DiffOpts, old_mode: u32, new_mode: u32, old_oid: Oid, new_oid: Oid, old_valid: bool, new_valid: bool, path: []const u8, old_dirty: u32, new_dirty: u32) void {
    if (old_mode & os.S_IFMT == os.S_IFGITLINK and new_mode & os.S_IFMT == os.S_IFGITLINK and isSubmoduleIgnored(o, path)) return;
    const one = newSpec(path);
    const two = newSpec(path);
    fillSpec(one, old_oid, old_valid, old_mode);
    fillSpec(two, new_oid, new_valid, new_mode);
    one.dirty_submodule = old_dirty;
    two.dirty_submodule = new_dirty;
    _ = queuePair(o, one, two);
    o.has_changes = true;
}

/// diff_unmerge()
fn diffUnmerge(o: *DiffOpts, path: []const u8) *Pair {
    const p = queuePair(o, newSpec(path), newSpec(path));
    p.unmerged = true;
    return p;
}

fn isDirMode(mode: u32) bool {
    const t = mode & os.S_IFMT;
    return t == os.S_IFDIR or t == os.S_IFGITLINK;
}

fn cePathMatch(o: *DiffOpts, e: *const index_mod.Entry) bool {
    const ps = o.pathspec orelse return true;
    return ps.matches(e.path, isDirMode(e.mode));
}

const Removed = union(enum) { present: os.Stat, removed, failed };

/// check_removed()
fn checkRemoved(e: *const index_mod.Entry) Removed {
    const st = os.lstatPath(e.path) orelse {
        const er = os.errno();
        if (er != os.ENOENT and er != os.ENOTDIR) return .failed;
        return .removed;
    };
    if (pathspec_mod.hasSymlinkLeadingPath(e.path)) return .removed;
    if (st.isDir()) {
        if (e.mode & os.S_IFMT != os.S_IFGITLINK and index_mod.gitlinkHead(e.path) == null) return .removed;
    }
    return .{ .present = st };
}

/// match_stat_with_submodule()
fn matchStatWithSubmodule(o: *DiffOpts, idx: *Index, e: *const index_mod.Entry, st: os.Stat, dirty: *u32) u32 {
    var changed = idx.matchStat(e, st, false);
    if (e.mode & os.S_IFMT == os.S_IFGITLINK) {
        var f = o.flags;
        if (!o.override_submodule_config) setFlagsFromSubmoduleConfig(&f, e.path);
        if (f.ignore_submodules) {
            changed = 0;
        } else if (!f.ignore_dirty and (changed == 0 or o.dirty_submodules)) {
            dirty.* = isSubmoduleModified(e.path, f.ignore_untracked);
        }
    }
    return changed;
}

/// run_diff_files() (without diffcore/flush)
fn runDiffFiles(o: *DiffOpts, idx: *Index) void {
    const ents = idx.entries.items;
    var i: usize = 0;
    while (i < ents.len) : (i += 1) {
        if (o.quick and o.has_changes) break;
        var ce = &ents[i];
        if (!cePathMatch(o, ce)) continue;
        if (ce.stage() != 0) {
            var wt_mode: u32 = 0;
            switch (checkRemoved(ce)) {
                .present => |st| wt_mode = index_mod.ceModeFromStat(ce, st),
                .removed => wt_mode = 0,
                .failed => {
                    util.eprint("{s}: {s}\n", .{ ce.path, os.lastErr() });
                    continue;
                },
            }
            const name = ce.path;
            while (i < ents.len) {
                const nce = &ents[i];
                if (!util.eql(name, nce.path)) break;
                if (nce.stage() == 2) ce = nce;
                i += 1;
            }
            i -= 1;
            const pair = diffUnmerge(o, ce.path);
            if (wt_mode != 0) pair.two.mode = wt_mode;
            if (ce.stage() != 2) continue;
        }
        if (ce.uptodate or ce.skipWorktree()) continue;
        var changed: u32 = 0;
        var newmode: u32 = 0;
        var dirty: u32 = 0;
        if (ce.assumeValid()) {
            newmode = ce.mode;
        } else {
            switch (checkRemoved(ce)) {
                .failed => {
                    util.eprint("{s}: {s}\n", .{ ce.path, os.lastErr() });
                    continue;
                },
                .removed => {
                    diffAddremove(o, '-', ce.mode, ce.oid, !hash.isZero(ce.oid), ce.path, 0);
                    continue;
                },
                .present => |st| {
                    if (o.ita_invisible and ce.intentToAdd()) {
                        newmode = index_mod.ceModeFromStat(ce, st);
                        diffAddremove(o, '+', newmode, hash.zero, false, ce.path, 0);
                        continue;
                    }
                    changed = matchStatWithSubmodule(o, idx, ce, st, &dirty);
                    newmode = index_mod.ceModeFromStat(ce, st);
                },
            }
        }
        if (changed == 0 and dirty == 0) {
            ce.uptodate = true;
            continue;
        }
        const new_oid = if (changed != 0) hash.zero else ce.oid;
        diffChange(o, ce.mode, newmode, ce.oid, new_oid, !hash.isZero(ce.oid), !hash.isZero(new_oid), ce.path, 0, dirty);
    }
}

fn pairLess(_: void, a: *Pair, b: *Pair) bool {
    return std.mem.order(u8, a.two.path, b.two.path) == .lt;
}

/// run_diff_index(DIFF_INDEX_CACHED) against `tree` (null: empty tree)
fn runDiffIndexCached(o: *DiffOpts, idx: *Index, tree: ?Oid) void {
    var tree_map: std.StringHashMapUnmanaged(objects.FlatEntry) = .empty;
    var tree_list: std.ArrayList(objects.FlatEntry) = .empty;
    if (tree) |t| objects.flattenTree(t, "", &tree_list);
    for (tree_list.items) |te| {
        if (o.pathspec) |ps| if (!ps.matches(te.path, isDirMode(te.mode))) continue;
        tree_map.put(gpa, te.path, te) catch util.oom();
    }
    const ents = idx.entries.items;
    var i: usize = 0;
    while (i < ents.len) : (i += 1) {
        if (o.quick and o.has_changes) break;
        const ce = &ents[i];
        if (!cePathMatch(o, ce)) {
            _ = tree_map.remove(ce.path);
            continue;
        }
        const te = tree_map.get(ce.path);
        if (te != null) _ = tree_map.remove(ce.path);
        if (ce.stage() != 0) {
            while (i + 1 < ents.len and util.eql(ents[i + 1].path, ce.path)) i += 1;
            const pair = diffUnmerge(o, ce.path);
            if (te) |t| fillSpec(pair.one, t.oid, true, t.mode);
            continue;
        }
        const visible = !(o.ita_invisible and ce.intentToAdd());
        if (te) |t| {
            if (!visible) {
                diffAddremove(o, '-', t.mode, t.oid, true, t.path, 0);
            } else if (t.mode != ce.mode or !hash.eql(t.oid, ce.oid)) {
                diffChange(o, t.mode, ce.mode, t.oid, ce.oid, true, true, ce.path, 0, 0);
            }
        } else if (visible) {
            diffAddremove(o, '+', ce.mode, ce.oid, true, ce.path, 0);
        }
    }
    var it = tree_map.valueIterator();
    while (it.next()) |t| diffAddremove(o, '-', t.mode, t.oid, true, t.path, 0);
    std.mem.sort(*Pair, o.queue.items, {}, pairLess);
}

fn isEmptyBlob(oid: Oid) bool {
    return util.eql(&hash.hex(oid), hash.empty_blob_hex);
}

/// hash_filespec(): make sure `sp.oid` holds the content hash.
fn hashSpec(sp: *Spec) void {
    if (sp.oid_valid) return;
    if (sp.mode & os.S_IFMT == os.S_IFGITLINK) return;
    const st = os.lstatPath(sp.path) orelse return;
    if (index_mod.hashWorktreeFile(sp.path, st, sp.mode)) |h| sp.oid = h;
}

fn basenameSame(src: []const u8, dst: []const u8) bool {
    var sl = src.len;
    var dl = dst.len;
    while (sl > 0 and dl > 0) {
        sl -= 1;
        dl -= 1;
        const c1 = src[sl];
        const c2 = dst[dl];
        if (c1 != c2) return false;
        if (c1 == '/') return true;
    }
    return (sl == 0 or src[sl - 1] == '/') and (dl == 0 or dst[dl - 1] == '/');
}

/// Optional inexact rename hook: set by a diff module if available.
pub var inexact_rename_hook: ?*const fn (srcs: []const *Spec, dsts: []const *Spec, dst_done: []bool, minimum_score: i32, want_copies: bool, out_src: []i32, out_score: []i32) void = null;

/// diffcore_rename() — exact matches only (plus optional inexact hook)
fn diffcoreRename(o: *DiffOpts) void {
    const want_copies = o.detect_rename == DETECT_COPY;
    var minimum_score = o.rename_score;
    if (minimum_score == 0) minimum_score = 30000; // DEFAULT_RENAME_SCORE
    var srcs: std.ArrayList(*Pair) = .empty;
    var dsts: std.ArrayList(*Pair) = .empty;
    for (o.queue.items) |p| {
        if (!specValid(p.one)) {
            if (!specValid(p.two)) continue;
            dsts.append(gpa, p) catch util.oom();
        } else if (!p.unmerged and !specValid(p.two)) {
            srcs.append(gpa, p) catch util.oom();
        } else if (want_copies) {
            p.one.rename_used += 1;
            srcs.append(gpa, p) catch util.oom();
        }
    }
    if (dsts.items.len > 0 and srcs.items.len > 0) {
        for (srcs.items) |sp| hashSpec(sp.one);
        for (dsts.items) |dp| {
            const target = dp.two;
            hashSpec(target);
            var best: ?*Pair = null;
            var best_score: i32 = -1;
            var budget: usize = 100;
            for (srcs.items) |sp| {
                const source = sp.one;
                if (!hash.eql(source.oid, target.oid)) continue;
                if (source.mode & os.S_IFMT != os.S_IFREG or target.mode & os.S_IFMT != os.S_IFREG) {
                    if (source.mode != target.mode) continue;
                }
                var score: i32 = if (source.rename_used == 0) 1 else 0;
                if (source.rename_used != 0 and !want_copies) continue;
                if (basenameSame(source.path, target.path)) score += 1;
                if (score > best_score) {
                    best = sp;
                    best_score = score;
                    if (score == 2) break;
                }
                budget -= 1;
                if (budget == 0) break;
            }
            if (best) |b| recordRenamePair(dp, b, MAX_SCORE);
        }
        if (minimum_score != MAX_SCORE) {
            if (inexact_rename_hook) |hook| {
                var src_specs: std.ArrayList(*Spec) = .empty;
                for (srcs.items) |sp| {
                    if (sp.one.rename_used != 0 and !want_copies) continue;
                    src_specs.append(gpa, sp.one) catch util.oom();
                }
                var dst_specs: std.ArrayList(*Spec) = .empty;
                var dst_pairs: std.ArrayList(*Pair) = .empty;
                for (dsts.items) |dp| {
                    if (dp.renamed) continue;
                    dst_specs.append(gpa, dp.two) catch util.oom();
                    dst_pairs.append(gpa, dp) catch util.oom();
                }
                if (src_specs.items.len > 0 and dst_specs.items.len > 0) {
                    const n = dst_specs.items.len;
                    const done = gpa.alloc(bool, n) catch util.oom();
                    @memset(done, false);
                    const out_src = gpa.alloc(i32, n) catch util.oom();
                    @memset(out_src, -1);
                    const out_score = gpa.alloc(i32, n) catch util.oom();
                    hook(src_specs.items, dst_specs.items, done, minimum_score, want_copies, out_src, out_score);
                    for (dst_pairs.items, 0..) |dp, k| {
                        if (out_src[k] < 0) continue;
                        const sspec = src_specs.items[@intCast(out_src[k])];
                        for (srcs.items) |sp| {
                            if (sp.one == sspec) {
                                recordRenamePair(dp, sp, out_score[k]);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    // write back
    var outq: std.ArrayList(*Pair) = .empty;
    for (o.queue.items) |p| {
        if (p.unmerged) {
            outq.append(gpa, p) catch util.oom();
        } else if (!specValid(p.one) and specValid(p.two)) {
            outq.append(gpa, p) catch util.oom();
        } else if (specValid(p.one) and !specValid(p.two)) {
            if (p.one.rename_used == 0) outq.append(gpa, p) catch util.oom();
        } else if (!unmodifiedPair(p)) {
            outq.append(gpa, p) catch util.oom();
        }
    }
    o.queue = outq;
}

fn recordRenamePair(dst: *Pair, src: *Pair, score: i32) void {
    src.one.rename_used += 1;
    dst.one = src.one;
    dst.renamed = true;
    dst.score = score;
}

/// diff_unmodified_pair()
fn unmodifiedPair(p: *const Pair) bool {
    if (p.unmerged) return false;
    const one = p.one;
    const two = p.two;
    if (specValid(one) != specValid(two) or one.mode != two.mode or !util.eql(one.path, two.path)) return false;
    if (one.oid_valid and two.oid_valid and hash.eql(one.oid, two.oid) and one.dirty_submodule == 0 and two.dirty_submodule == 0) return true;
    if (!one.oid_valid and !two.oid_valid) return true;
    return false;
}

/// diffcore_std() for our purposes: rename detection + diff_resolve_rename_copy
fn diffcoreStd(o: *DiffOpts) void {
    if (o.detect_rename != 0) diffcoreRename(o);
    for (o.queue.items) |p| {
        p.status = 0;
        if (p.unmerged) {
            p.status = 'U';
        } else if (!specValid(p.one)) {
            p.status = 'A';
        } else if (!specValid(p.two)) {
            p.status = 'D';
        } else if (p.one.mode & os.S_IFMT != p.two.mode & os.S_IFMT) {
            p.status = 'T';
        } else if (p.renamed) {
            if (util.eql(p.one.path, p.two.path)) {
                p.status = 'M';
            } else {
                p.one.rename_used -= 1;
                p.status = if (p.one.rename_used > 0) 'C' else 'R';
            }
        } else if (!hash.eql(p.one.oid, p.two.oid) or p.one.mode != p.two.mode or p.one.dirty_submodule != 0 or p.two.dirty_submodule != 0 or hash.isZero(p.one.oid)) {
            p.status = 'M';
        } else {
            util.err("feeding unmodified {s} to diffcore", .{p.one.path});
            p.status = 'X';
        }
    }
    o.has_changes = o.queue.items.len > 0;
}

// ---------------------------------------------------------------------------
// collection (wt_status_collect)

fn statusIndex(s: *Status) *Index {
    if (s.idx) |i| return i;
    const def = repo_mod.repo().indexPath();
    const idx = if (s.index_file.len > 0 and !util.eql(s.index_file, def)) index_mod.readFrom(s.index_file) else index_mod.get();
    s.idx = idx;
    return idx;
}

fn getChange(s: *Status, path: []const u8) *Change {
    const gop = s.change_map.getOrPut(gpa, path) catch util.oom();
    if (!gop.found_existing) {
        const d = gpa.create(Change) catch util.oom();
        d.* = .{ .path = path };
        gop.value_ptr.* = d;
        s.change.append(gpa, d) catch util.oom();
    }
    return gop.value_ptr.*;
}

fn shortSubmoduleStatus(d: *const Change) u8 {
    if (d.new_submodule_commits) return 'M';
    if (d.dirty_submodule & DIRTY_SUBMODULE_MODIFIED != 0) return 'm';
    if (d.dirty_submodule & DIRTY_SUBMODULE_UNTRACKED != 0) return '?';
    return d.worktree_status;
}

fn renameScorePct(score: i32) i32 {
    return @divTrunc(score * 100, MAX_SCORE);
}

fn collectChangedCb(s: *Status, q: []const *Pair) void {
    if (q.len == 0) return;
    s.workdir_dirty = true;
    for (q) |p| {
        const d = getChange(s, p.two.path);
        if (d.worktree_status == 0) d.worktree_status = p.status;
        if (p.two.mode & os.S_IFMT == os.S_IFGITLINK) {
            d.dirty_submodule = p.two.dirty_submodule;
            d.new_submodule_commits = !hash.eql(p.one.oid, p.two.oid);
            if (s.status_format == .short) d.worktree_status = shortSubmoduleStatus(d);
        }
        switch (p.status) {
            'A' => d.mode_worktree = p.two.mode,
            'D' => {
                d.mode_index = p.one.mode;
                d.oid_index = p.one.oid;
            },
            'C', 'R', 'M', 'T', 'U' => {
                if (p.status == 'C' or p.status == 'R') {
                    d.rename_source = p.one.path;
                    d.rename_score = renameScorePct(p.score);
                    d.rename_status = p.status;
                }
                d.mode_index = p.one.mode;
                d.mode_worktree = p.two.mode;
                d.oid_index = p.one.oid;
            },
            else => util.die("BUG: unhandled diff-files status '{c}'", .{p.status}),
        }
    }
}

fn unmergedMask(idx: *Index, path: []const u8) u32 {
    switch (idx.pos(path, 0)) {
        .found => return 0,
        .missing => |p0| {
            var p = p0;
            var mask: u32 = 0;
            while (p < idx.entries.items.len) : (p += 1) {
                const ce = &idx.entries.items[p];
                if (!util.eql(ce.path, path) or ce.stage() == 0) break;
                mask |= @as(u32, 1) << @intCast(ce.stage() - 1);
            }
            return mask;
        },
    }
}

fn collectUpdatedCb(s: *Status, idx: *Index, q: []const *Pair) void {
    for (q) |p| {
        const d = getChange(s, p.two.path);
        if (d.index_status == 0) d.index_status = p.status;
        switch (p.status) {
            'A' => {
                d.mode_index = p.two.mode;
                d.oid_index = p.two.oid;
                s.committable = true;
            },
            'D' => {
                d.mode_head = p.one.mode;
                d.oid_head = p.one.oid;
                s.committable = true;
            },
            'C', 'R', 'M', 'T' => {
                if (p.status == 'C' or p.status == 'R') {
                    d.rename_source = p.one.path;
                    d.rename_score = renameScorePct(p.score);
                    d.rename_status = p.status;
                }
                d.mode_head = p.one.mode;
                d.mode_index = p.two.mode;
                d.oid_head = p.one.oid;
                d.oid_index = p.two.oid;
                s.committable = true;
            },
            'U' => d.stagemask = unmergedMask(idx, p.two.path),
            else => util.die("BUG: unhandled diff-index status '{c}'", .{p.status}),
        }
    }
}

fn applyRenameOpts(s: *Status, o: *DiffOpts) void {
    if (s.detect_rename >= 0) o.detect_rename = s.detect_rename;
    if (s.rename_limit >= 0) o.rename_limit = s.rename_limit;
    if (s.rename_score >= 0) o.rename_score = s.rename_score;
}

fn collectChangesWorktree(s: *Status, idx: *Index) void {
    var o = diffSetup();
    o.dirty_submodules = true;
    o.ita_invisible = true;
    if (s.show_untracked_files == .no) o.flags.ignore_untracked = true;
    if (s.ignore_submodule_arg) |arg| {
        o.override_submodule_config = true;
        handleIgnoreSubmodulesArg(&o.flags, arg);
    } else if (!o.flags.set and s.show_untracked_files != .no) {
        handleIgnoreSubmodulesArg(&o.flags, "none");
    }
    applyRenameOpts(s, &o);
    o.pathspec = &s.pathspec;
    runDiffFiles(&o, idx);
    diffcoreStd(&o);
    collectChangedCb(s, o.queue.items);
}

fn referenceTree(s: *Status) ?Oid {
    if (s.is_initial) return null;
    return revparse.getTreeish(s.reference) orelse util.die("bad revision '{s}'", .{s.reference});
}

fn collectChangesIndex(s: *Status, idx: *Index) void {
    var o = diffSetup();
    o.override_submodule_config = true;
    o.ita_invisible = true;
    handleIgnoreSubmodulesArg(&o.flags, s.ignore_submodule_arg orelse "dirty");
    applyRenameOpts(s, &o);
    o.pathspec = &s.pathspec;
    runDiffIndexCached(&o, idx, referenceTree(s));
    diffcoreStd(&o);
    collectUpdatedCb(s, idx, o.queue.items);
}

fn collectChangesInitial(s: *Status, idx: *Index) void {
    for (idx.entries.items) |*ce| {
        if (!s.pathspec.matches(ce.path, isDirMode(ce.mode))) continue;
        if (ce.intentToAdd()) continue;
        const d = getChange(s, ce.path);
        if (ce.stage() != 0) {
            d.index_status = 'U';
            d.stagemask |= @as(u32, 1) << @intCast(ce.stage() - 1);
            s.committable = true;
        } else {
            d.index_status = 'A';
            d.mode_index = ce.mode;
            d.oid_index = ce.oid;
            s.committable = true;
        }
    }
}

fn strSortUniq(l: *std.ArrayList([]const u8)) void {
    util.sortStrings(l.items);
    if (l.items.len == 0) return;
    var w: usize = 1;
    for (l.items[1..]) |x| {
        if (!util.eql(x, l.items[w - 1])) {
            l.items[w] = x;
            w += 1;
        }
    }
    l.items.len = w;
}

fn collectUntracked(s: *Status, idx: *Index) void {
    if (s.show_untracked_files == .no) return;
    const t_begin = os.nowMicros();
    var d = Dir.init();
    if (s.show_untracked_files != .all) {
        d.flags.show_other_directories = true;
        d.flags.hide_empty_directories = true;
    }
    if (s.show_ignored_mode != .no) {
        d.flags.show_ignored_too = true;
        if (s.show_ignored_mode == .matching) d.flags.show_ignored_too_mode_matching = true;
    }
    d.setupStandardExcludes();
    _ = d.fill(idx, &s.pathspec);
    for (d.entries.items) |ent| {
        if (dir_mod.indexNameIsOther(idx, ent.name)) s.untracked.append(gpa, ent.name) catch util.oom();
    }
    strSortUniq(&s.untracked);
    for (d.ignored.items) |ent| {
        if (dir_mod.indexNameIsOther(idx, ent.name)) s.ignored.append(gpa, ent.name) catch util.oom();
    }
    strSortUniq(&s.ignored);
    if (advice.enabled("statusUoption")) {
        const el = os.nowMicros() - t_begin;
        s.untracked_in_ms = @intCast(@divTrunc(@max(el, 0), 1000));
    }
}

const Dir = dir_mod.Dir;

fn changeLess(_: void, a: *Change, b: *Change) bool {
    return std.mem.order(u8, a.path, b.path) == .lt;
}

/// wt_status_collect()
pub fn collect(s: *Status) void {
    const idx = statusIndex(s);
    collectChangesWorktree(s, idx);
    if (s.is_initial) collectChangesInitial(s, idx) else collectChangesIndex(s, idx);
    collectUntracked(s, idx);
    std.mem.sort(*Change, s.change.items, {}, changeLess);
    s.state = getStateIdx(s.branch != null and util.eql(s.branch.?, "HEAD"), idx);
    if (s.state.merge_in_progress and !hasUnmerged(s)) s.committable = true;
}

fn hasUnmerged(s: *Status) bool {
    for (s.change.items) |d| if (d.stagemask != 0) return true;
    return false;
}

// ---------------------------------------------------------------------------
// state (wt_status_get_state)

fn gitPathExists(name: []const u8) bool {
    return os.statPath(repo_mod.repo().gitPath(name)) != null;
}

/// get_branch()
fn getBranch(path: []const u8) ?[]const u8 {
    const data = os.readFile(repo_mod.repo().gitPath(path)) orelse return null;
    var sb: []const u8 = data;
    while (sb.len > 0 and sb[sb.len - 1] == '\n') sb = sb[0 .. sb.len - 1];
    if (sb.len == 0) return null;
    if (util.skipPrefix(sb, "refs/heads/")) |b| return b;
    if (util.startsWith(sb, "refs/")) return sb;
    if (sb.len >= hash.HEXSZ) {
        if (hash.fromHex(sb[0..hash.HEXSZ])) |oid| return revparse.abbrev(oid, 0);
    }
    if (util.eql(sb, "detached HEAD")) return null;
    return sb;
}

/// wt_status_check_rebase()
pub fn checkRebase(st: *State) bool {
    if (gitPathExists("rebase-apply")) {
        if (gitPathExists("rebase-apply/applying")) {
            st.am_in_progress = true;
            if (os.statPath(repo_mod.repo().gitPath("rebase-apply/patch"))) |pst| {
                if (pst.size == 0) st.am_empty_patch = true;
            }
        } else {
            st.rebase_in_progress = true;
            st.branch = getBranch("rebase-apply/head-name");
            st.onto = getBranch("rebase-apply/onto");
        }
    } else if (gitPathExists("rebase-merge")) {
        if (gitPathExists("rebase-merge/interactive")) {
            st.rebase_interactive_in_progress = true;
        } else st.rebase_in_progress = true;
        st.branch = getBranch("rebase-merge/head-name");
        st.onto = getBranch("rebase-merge/onto");
    } else return false;
    return true;
}

/// wt_status_check_bisect()
pub fn checkBisect(st: *State) bool {
    if (gitPathExists("BISECT_LOG")) {
        st.bisect_in_progress = true;
        st.bisecting_from = getBranch("BISECT_START");
        return true;
    }
    return false;
}

fn isTodoCommand(bol: []const u8, long: []const u8, short: u8) ?[]const u8 {
    if (util.skipPrefix(bol, long)) |r| {
        if (r.len == 0 or r[0] == ' ' or r[0] == '\t' or r[0] == '\n' or r[0] == '\r') return r;
    }
    if (bol.len >= 1 and bol[0] == short and (bol.len == 1 or bol[1] == ' ' or bol[1] == '\t' or bol[1] == '\n' or bol[1] == '\r')) return bol[1..];
    return null;
}

const ReplayAction = enum { pick, revert };

/// sequencer_get_last_command()
fn sequencerLastCommand() ?ReplayAction {
    const data = os.readFile(repo_mod.repo().gitPath("sequencer/todo")) orelse return null;
    var i: usize = 0;
    while (i < data.len and (data[i] == ' ' or data[i] == '\t' or data[i] == '\r' or data[i] == '\n')) i += 1;
    const bol = data[i..];
    if (isTodoCommand(bol, "pick", 'p')) |r| {
        if (r.len > 0 and (r[0] == ' ' or r[0] == '\t')) return .pick;
        return null;
    }
    if (util.startsWith(bol, "revert")) {
        const r = bol["revert".len..];
        if (r.len > 0 and (r[0] == ' ' or r[0] == '\t')) return .revert;
    }
    return null;
}

/// wt_status_get_detached_from()
fn getDetachedFrom(st: *State) void {
    const log = refs.readReflog("HEAD");
    var target: ?[]const u8 = null;
    var noid: Oid = hash.zero;
    var i = log.len;
    while (i > 0) {
        i -= 1;
        const msg0 = util.skipPrefix(log[i].msg, "checkout: moving from ") orelse continue;
        const pos = std.mem.indexOf(u8, msg0, " to ") orelse continue;
        var t = msg0[pos + 4 ..];
        if (std.mem.indexOfScalar(u8, t, '\n')) |nl| t = t[0..nl];
        noid = log[i].new;
        if (util.eql(t, "HEAD")) t = revparse.abbrev(noid, 0);
        target = t;
        break;
    }
    const tgt = target orelse return;
    var from: ?[]const u8 = null;
    if (refs.dwimRef(tgt)) |d| {
        if (d.count == 1) {
            var ok = hash.eql(noid, d.oid);
            if (!ok) {
                if (cn.lookupCommitReference(d.oid)) |c| ok = hash.eql(noid, c.obj.oid);
            }
            if (ok) {
                var f = d.name;
                if (util.skipPrefix(f, "refs/tags/")) |x| {
                    f = x;
                } else if (util.skipPrefix(f, "refs/remotes/")) |x| f = x;
                from = f;
            }
        }
    }
    st.detached_from = from orelse revparse.abbrev(noid, 0);
    st.detached_oid = noid;
    st.detached_at = if (revparse.getOid("HEAD")) |h| hash.eql(h, noid) else false;
}

fn checkSparseCheckout(st: *State, idx: *Index) void {
    const sparse = if (repo_mod.cfg.getBool("core.sparsecheckout")) |b| b else false;
    if (!sparse or idx.entries.items.len == 0) {
        st.sparse_checkout_percentage = -1;
        return;
    }
    var skip: usize = 0;
    for (idx.entries.items) |*e| {
        if (e.skipWorktree()) skip += 1;
    }
    const nr = idx.entries.items.len;
    st.sparse_checkout_percentage = 100 - @as(i32, @intCast((100 * skip) / nr));
}

fn getStateIdx(get_detached_from: bool, idx: *Index) State {
    var st = State{};
    if (gitPathExists("MERGE_HEAD")) {
        _ = checkRebase(&st);
        st.merge_in_progress = true;
    } else if (checkRebase(&st)) {
        // all set
    } else if (refs.exists("CHERRY_PICK_HEAD")) {
        if (revparse.getOid("CHERRY_PICK_HEAD")) |oid| {
            st.cherry_pick_in_progress = true;
            st.cherry_pick_head_oid = oid;
        }
    }
    _ = checkBisect(&st);
    if (refs.exists("REVERT_HEAD")) {
        if (revparse.getOid("REVERT_HEAD")) |oid| {
            st.revert_in_progress = true;
            st.revert_head_oid = oid;
        }
    }
    if (sequencerLastCommand()) |action| {
        if (action == .pick and !st.cherry_pick_in_progress) {
            st.cherry_pick_in_progress = true;
            st.cherry_pick_head_oid = hash.zero;
        } else if (action == .revert and !st.revert_in_progress) {
            st.revert_in_progress = true;
            st.revert_head_oid = hash.zero;
        }
    }
    if (get_detached_from) getDetachedFrom(&st);
    checkSparseCheckout(&st, idx);
    return st;
}

/// wt_status_get_state()
pub fn getState(get_detached_from: bool) State {
    return getStateIdx(get_detached_from, index_mod.get());
}

// ---------------------------------------------------------------------------
pub fn print(s: *Status) void {
    _ = s;
}
pub fn addCutLine(s: *Status) void {
    if (s.added_cut_line) return;
    s.added_cut_line = true;
    var sb: util.Buf = .empty;
    appendCutLine(&sb);
    s.out.write(sb.items);
}
pub fn appendCutLine(buf: *util.Buf) void {
    const explanation = "Do not modify or remove the line above.\nEverything below it will be ignored.";
    const cs = commentStr();
    addCommentedLines(buf, cs, cut_line);
    addCommentedLines(buf, cs, explanation);
}

/// strbuf_add_commented_lines()
pub fn addCommentedLines(buf: *util.Buf, cs: []const u8, text: []const u8) void {
    var it = text;
    while (it.len > 0) {
        const nl = std.mem.indexOfScalar(u8, it, '\n');
        const line = if (nl) |n| it[0..n] else it;
        util.bufAppend(buf, cs);
        if (line.len > 0 and line[0] != '\t') util.bufByte(buf, ' ');
        util.bufAppend(buf, line);
        util.bufByte(buf, '\n');
        it = if (nl) |n| it[n + 1 ..] else it[it.len..];
    }
}

/// wt_status_locate_end()
pub fn locateEnd(buf: []const u8) usize {
    const pattern = util.concat(&.{ "\n", commentStr(), " ", cut_line });
    if (util.startsWith(buf, pattern[1..])) return 0;
    if (std.mem.indexOf(u8, buf, pattern)) |p| {
        if (p + 1 < buf.len) return p + 1;
    }
    return buf.len;
}
