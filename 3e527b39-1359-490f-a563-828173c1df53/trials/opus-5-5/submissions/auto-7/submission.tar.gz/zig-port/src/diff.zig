//! Port of git's diff machinery (diff.c, ws.c, diff-lib.c, parts of diffcore).
//!
//! Stable API (used by other commands):
//!
//!   var o = diff.DiffOptions.init();       // porcelain defaults (diff.* UI config, renames)
//!   var o = diff.DiffOptions.initBasic();  // plumbing defaults (basic config only)
//!   o.output_format = diff.FMT_PATCH | diff.FMT_DIFFSTAT ...;  (FMT_RAW, FMT_DIFFSTAT,
//!       FMT_NUMSTAT, FMT_SUMMARY, FMT_PATCH, FMT_SHORTSTAT, FMT_DIRSTAT, FMT_NAME,
//!       FMT_NAME_STATUS, FMT_CHECKDIFF, FMT_NO_OUTPUT)
//!   o.detect_rename = diff.DETECT_RENAME / DETECT_COPY; o.pathspec = ...;
//!   o.flags.recursive / .reverse / .quick / .exit_with_status ...
//!   o.file: ?*util.Out (default &util.stdout; null = no output)
//!   const n = o.parseOpt(args, i);   // consume diff options at args[i] (0 = not a diff option)
//!   o.setupDone();                    // diff_setup_done
//!
//!   diff.diffTree(&o, old_tree_or_null, new_tree_or_null, base)  // queue tree changes
//!   diff.runDiffIndex(&o, tree_oid, cached)                      // queue tree vs index/worktree
//!   diff.runDiffFiles(&o)                                        // queue index vs worktree
//!   diff.flush(&o)            // diffcore_std + diff_flush (prints and clears the queue)
//!   diff.diffcoreStd(&o) then inspect diff.queue.items (*FilePair{status, score,
//!       one/two: *Filespec{path, oid, mode, oid_valid}}) then diff.clearQueue()
//!   diff.hasChanges(&o) / diff.resultCode(&o)
//!   diff.treesSame(old, new, &pathspec) bool
//!   diff.diffCombined(&o, commit_oid, parents, dense)
//!   diff.printStatSummary(out, files, ins, del)
//!   diff.setupRevDiff(revs) / diff.revResultCode(revs): install diff hooks for log & co.
//!   ws.c: parseWhitespaceRule, whitespaceRule, wsErrorString, wsCheck, wsCheckEmit,
//!       wsBlankLine, wsFixCopy (WS_* constants).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const config = @import("config.zig");
const color = @import("color.zig");
const attr = @import("attr.zig");
const pathspec_mod = @import("pathspec.zig");
const xdiff = @import("xdiff.zig");
const regex = @import("regex.zig");
const userdiff = @import("userdiff.zig");
const index_mod = @import("index.zig");
const objects = @import("objects.zig");
const convert = @import("convert.zig");
const revparse = @import("revparse.zig");
const pretty = @import("pretty.zig");
const odb_mod = @import("odb.zig");
const revision = @import("revision.zig");
const graph_mod = @import("graph.zig");
const cn = @import("commitnode.zig");
pub const diffcore = @import("diffcore.zig");
pub const treediff = @import("treediff.zig");

const gpa = util.gpa;
const Oid = hash.Oid;
const Buf = util.Buf;

// ---------------------------------------------------------------------------
// constants (diff.h, ws.h, diffcore.h)

pub const FMT_RAW: u32 = 0x0001;
pub const FMT_DIFFSTAT: u32 = 0x0002;
pub const FMT_NUMSTAT: u32 = 0x0004;
pub const FMT_SUMMARY: u32 = 0x0008;
pub const FMT_PATCH: u32 = 0x0010;
pub const FMT_SHORTSTAT: u32 = 0x0020;
pub const FMT_DIRSTAT: u32 = 0x0040;
pub const FMT_NAME: u32 = 0x0100;
pub const FMT_NAME_STATUS: u32 = 0x0200;
pub const FMT_CHECKDIFF: u32 = 0x0400;
pub const FMT_NO_OUTPUT: u32 = 0x0800;
pub const FMT_CALLBACK: u32 = 0x1000;

pub const DETECT_RENAME: u8 = 1;
pub const DETECT_COPY: u8 = 2;

pub const MAX_SCORE: u32 = 60000;
pub const DEFAULT_RENAME_SCORE: u32 = 30000;
pub const DEFAULT_BREAK_SCORE: u32 = 30000;
pub const DEFAULT_MERGE_SCORE: u32 = 36000;
pub const MINIMUM_BREAK_SIZE: usize = 400;

pub const PICKAXE_ALL: u32 = 1;
pub const PICKAXE_REGEX: u32 = 2;
pub const PICKAXE_KIND_S: u32 = 4;
pub const PICKAXE_KIND_G: u32 = 8;
pub const PICKAXE_KIND_OBJFIND: u32 = 16;
pub const PICKAXE_KINDS_MASK: u32 = PICKAXE_KIND_S | PICKAXE_KIND_G | PICKAXE_KIND_OBJFIND;
pub const PICKAXE_IGNORE_CASE: u32 = 32;

pub const WS_BLANK_AT_EOL: u32 = 1 << 6;
pub const WS_SPACE_BEFORE_TAB: u32 = 1 << 7;
pub const WS_INDENT_WITH_NON_TAB: u32 = 1 << 8;
pub const WS_CR_AT_EOL: u32 = 1 << 9;
pub const WS_BLANK_AT_EOF: u32 = 1 << 10;
pub const WS_TAB_IN_INDENT: u32 = 1 << 11;
pub const WS_INCOMPLETE_LINE: u32 = 1 << 12;
pub const WS_TRAILING_SPACE: u32 = WS_BLANK_AT_EOL | WS_BLANK_AT_EOF;
pub const WS_DEFAULT_RULE: u32 = WS_TRAILING_SPACE | WS_SPACE_BEFORE_TAB | 8;
pub const WS_TAB_WIDTH_MASK: u32 = (1 << 6) - 1;
pub const WS_RULE_MASK: u32 = (1 << 16) - 1;

pub const WSEH_NEW: u32 = 1 << 16;
pub const WSEH_CONTEXT: u32 = 1 << 17;
pub const WSEH_OLD: u32 = 1 << 18;
const SYM_BLANK_LINE_EOF: u32 = 1 << 19;
const SYM_MOVED_LINE: u32 = 1 << 20;
const SYM_MOVED_LINE_ALT: u32 = 1 << 21;
const SYM_MOVED_LINE_UNINTERESTING: u32 = 1 << 22;
const SYM_CONTENT_WS_MASK: u32 = WSEH_NEW | WSEH_OLD | WSEH_CONTEXT | WS_RULE_MASK;

pub const STATUS_ADDED: u8 = 'A';
pub const STATUS_COPIED: u8 = 'C';
pub const STATUS_DELETED: u8 = 'D';
pub const STATUS_MODIFIED: u8 = 'M';
pub const STATUS_RENAMED: u8 = 'R';
pub const STATUS_TYPE_CHANGED: u8 = 'T';
pub const STATUS_UNKNOWN: u8 = 'X';
pub const STATUS_UNMERGED: u8 = 'U';
pub const STATUS_FILTER_AON: u8 = '*';
pub const STATUS_FILTER_BROKEN: u8 = 'B';

const status_letters = "ACDMRTXU*B";

pub fn filterBit(status: u8) u32 {
    for (status_letters, 0..) |c, i| {
        if (c == status) return @as(u32, 1) << @intCast(i);
    }
    return 0;
}

pub const WordDiff = enum { none, porcelain, plain, color };

pub const ColorMoved = enum(u8) { no = 0, plain = 1, blocks = 2, zebra = 3, zebra_dim = 4 };
pub const COLOR_MOVED_DEFAULT = ColorMoved.zebra;
pub const COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE: u32 = 1 << 5;
pub const COLOR_MOVED_WS_ERROR: u32 = 1 << 0;

pub const SubmoduleFormat = enum { short, log, inline_diff };

const OUTPUT_INDICATOR_NEW = 0;
const OUTPUT_INDICATOR_OLD = 1;
const OUTPUT_INDICATOR_CONTEXT = 2;

pub fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r';
}
fn isDigit(c: u8) bool {
    return c >= '0' and c <= '9';
}

fn sIsDir(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFDIR;
}
fn sIsReg(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFREG;
}
fn sIsLnk(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFLNK;
}
fn sIsGitlink(mode: u32) bool {
    return mode & os.S_IFMT == os.S_IFGITLINK;
}

// ---------------------------------------------------------------------------
// ws.c

pub var whitespace_rule_cfg: u32 = WS_DEFAULT_RULE;
var whitespace_cfg_loaded = false;

const WsRuleName = struct { name: []const u8, bits: u32, loosens_error: bool = false, exclude_default: bool = false };
const whitespace_rule_names = [_]WsRuleName{
    .{ .name = "trailing-space", .bits = WS_TRAILING_SPACE },
    .{ .name = "space-before-tab", .bits = WS_SPACE_BEFORE_TAB },
    .{ .name = "indent-with-non-tab", .bits = WS_INDENT_WITH_NON_TAB },
    .{ .name = "cr-at-eol", .bits = WS_CR_AT_EOL, .loosens_error = true },
    .{ .name = "blank-at-eol", .bits = WS_BLANK_AT_EOL },
    .{ .name = "blank-at-eof", .bits = WS_BLANK_AT_EOF },
    .{ .name = "tab-in-indent", .bits = WS_TAB_IN_INDENT, .exclude_default = true },
    .{ .name = "incomplete-line", .bits = WS_INCOMPLETE_LINE },
};

pub fn wsTabWidth(rule: u32) u32 {
    return rule & WS_TAB_WIDTH_MASK;
}

/// parse_whitespace_rule()
pub fn parseWhitespaceRule(string0: []const u8) u32 {
    var rule: u32 = WS_DEFAULT_RULE;
    var s = string0;
    while (true) {
        var k: usize = 0;
        while (k < s.len and (s[k] == ',' or s[k] == ' ' or s[k] == '\t' or s[k] == '\n' or s[k] == '\r')) k += 1;
        s = s[k..];
        const ep = std.mem.indexOfScalar(u8, s, ',') orelse s.len;
        var item = s[0..ep];
        var negated = false;
        if (item.len > 0 and item[0] == '-') {
            negated = true;
            item = item[1..];
        }
        if (item.len == 0) break;
        for (whitespace_rule_names) |r| {
            if (!std.mem.startsWith(u8, r.name, item)) continue;
            if (negated) rule &= ~r.bits else rule |= r.bits;
            break;
        }
        if (util.skipPrefix(s, "tabwidth=")) |arg| {
            var n: u32 = 0;
            var j: usize = 0;
            while (j < arg.len and isDigit(arg[j])) : (j += 1) n = n *| 10 +| (arg[j] - '0');
            if (0 < n and n < 0o100) {
                rule &= ~WS_TAB_WIDTH_MASK;
                rule |= n;
            } else {
                const arg_end = std.mem.indexOfScalar(u8, arg, ',') orelse arg.len;
                util.warn("tabwidth {s} out of range", .{arg[0..arg_end]});
            }
        }
        if (ep >= s.len) break;
        s = s[ep..];
    }
    if (rule & WS_TAB_IN_INDENT != 0 and rule & WS_INDENT_WITH_NON_TAB != 0)
        util.die("cannot enforce both tab-in-indent and indent-with-non-tab", .{});
    return rule;
}

fn loadWhitespaceCfg() void {
    if (whitespace_cfg_loaded) return;
    whitespace_cfg_loaded = true;
    if (repo_mod.cfg.getEntry("core.whitespace")) |e| {
        const v = e.value orelse util.die("missing value for '{s}'", .{e.key});
        whitespace_rule_cfg = parseWhitespaceRule(v);
    }
}

/// whitespace_rule(): rule for a path (attribute "whitespace" + core.whitespace)
pub fn whitespaceRule(path: []const u8) u32 {
    loadWhitespaceCfg();
    const v: attr.Value = if (repo_mod.repo_ != null) attr.get(path, "whitespace") else .unspecified;
    switch (v) {
        .set => {
            var all_rule = wsTabWidth(whitespace_rule_cfg);
            for (whitespace_rule_names) |r| {
                if (!r.loosens_error and !r.exclude_default) all_rule |= r.bits;
            }
            return all_rule;
        },
        .unset => return wsTabWidth(whitespace_rule_cfg),
        .unspecified => return whitespace_rule_cfg,
        .value => |s| return parseWhitespaceRule(s),
    }
}

/// whitespace_error_string()
pub fn wsErrorString(ws: u32) []const u8 {
    var err: Buf = .empty;
    if (ws & WS_TRAILING_SPACE == WS_TRAILING_SPACE) {
        util.bufAppend(&err, "trailing whitespace");
    } else {
        if (ws & WS_BLANK_AT_EOL != 0) util.bufAppend(&err, "trailing whitespace");
        if (ws & WS_BLANK_AT_EOF != 0) {
            if (err.items.len > 0) util.bufAppend(&err, ", ");
            util.bufAppend(&err, "new blank line at EOF");
        }
    }
    if (ws & WS_SPACE_BEFORE_TAB != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "space before tab in indent");
    }
    if (ws & WS_INDENT_WITH_NON_TAB != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "indent with spaces");
    }
    if (ws & WS_TAB_IN_INDENT != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "tab in indent");
    }
    if (ws & WS_INCOMPLETE_LINE != 0) {
        if (err.items.len > 0) util.bufAppend(&err, ", ");
        util.bufAppend(&err, "no newline at the end of file");
    }
    return err.items;
}

fn wsCheckEmit1(line: []const u8, ws_rule: u32, stream: ?*Buf, set: []const u8, reset: []const u8, ws: []const u8) u32 {
    var result: u32 = 0;
    var written: usize = 0;
    var trailing_whitespace: ?usize = null;
    var trailing_newline = false;
    var trailing_cr = false;
    var len = line.len;
    if (len > 0 and line[len - 1] == '\n') {
        trailing_newline = true;
        len -= 1;
    }
    if (ws_rule & WS_CR_AT_EOL != 0 and len > 0 and line[len - 1] == '\r') {
        trailing_cr = true;
        len -= 1;
    }
    if (ws_rule & WS_BLANK_AT_EOL != 0) {
        var i: usize = len;
        while (i > 0) {
            i -= 1;
            if (isSpace(line[i])) {
                trailing_whitespace = i;
                result |= WS_BLANK_AT_EOL;
            } else break;
        }
    }
    const tw = trailing_whitespace orelse len;
    if (!trailing_newline and ws_rule & WS_INCOMPLETE_LINE != 0) result |= WS_INCOMPLETE_LINE;

    var i: usize = 0;
    while (i < tw) : (i += 1) {
        if (line[i] == ' ') continue;
        if (line[i] != '\t') break;
        if (ws_rule & WS_SPACE_BEFORE_TAB != 0 and written < i) {
            result |= WS_SPACE_BEFORE_TAB;
            if (stream) |st| {
                util.bufAppend(st, ws);
                util.bufAppend(st, line[written..i]);
                util.bufAppend(st, reset);
                util.bufAppend(st, line[i .. i + 1]);
            }
        } else if (ws_rule & WS_TAB_IN_INDENT != 0) {
            result |= WS_TAB_IN_INDENT;
            if (stream) |st| {
                util.bufAppend(st, line[written..i]);
                util.bufAppend(st, ws);
                util.bufAppend(st, line[i .. i + 1]);
                util.bufAppend(st, reset);
            }
        } else if (stream) |st| {
            util.bufAppend(st, line[written .. i + 1]);
        }
        written = i + 1;
    }
    if (ws_rule & WS_INDENT_WITH_NON_TAB != 0 and i >= written and i - written >= wsTabWidth(ws_rule)) {
        result |= WS_INDENT_WITH_NON_TAB;
        if (stream) |st| {
            util.bufAppend(st, ws);
            util.bufAppend(st, line[written..i]);
            util.bufAppend(st, reset);
        }
        written = i;
    }
    if (stream) |st| {
        if (tw > written) {
            util.bufAppend(st, set);
            util.bufAppend(st, line[written..tw]);
            util.bufAppend(st, reset);
        }
        if (tw != len) {
            util.bufAppend(st, ws);
            util.bufAppend(st, line[tw..len]);
            util.bufAppend(st, reset);
        }
        if (trailing_cr) util.bufByte(st, '\r');
        if (trailing_newline) util.bufByte(st, '\n');
    }
    return result;
}

/// ws_check_emit(): append the line with whitespace errors highlighted to `stream`.
pub fn wsCheckEmit(line: []const u8, ws_rule: u32, stream: *Buf, set: []const u8, reset: []const u8, ws: []const u8) void {
    _ = wsCheckEmit1(line, ws_rule, stream, set, reset, ws);
}

/// ws_check()
pub fn wsCheck(line: []const u8, ws_rule: u32) u32 {
    return wsCheckEmit1(line, ws_rule, null, "", "", "");
}

/// ws_blank_line()
pub fn wsBlankLine(line: []const u8) bool {
    for (line) |c| {
        if (!isSpace(c)) return false;
    }
    return true;
}

/// ws_fix_copy(): append src to dst fixing whitespace errors per ws_rule.
pub fn wsFixCopy(dst: *Buf, src0: []const u8, ws_rule: u32, error_count: ?*usize) void {
    var src = src0;
    var len = src.len;
    var add_nl_to_tail = false;
    var add_cr_to_tail = false;
    var fixed = false;
    var last_tab_in_indent: isize = -1;
    var last_space_in_indent: isize = -1;
    var need_fix_leading_space = false;
    const tabw: isize = @intCast(wsTabWidth(ws_rule));

    if (ws_rule & WS_INCOMPLETE_LINE != 0) {
        if (0 < len and src[len - 1] != '\n') {
            fixed = true;
            add_nl_to_tail = true;
        }
    }
    if (ws_rule & WS_BLANK_AT_EOL != 0) {
        if (0 < len and src[len - 1] == '\n') {
            add_nl_to_tail = true;
            len -= 1;
            if (0 < len and src[len - 1] == '\r') {
                add_cr_to_tail = ws_rule & WS_CR_AT_EOL != 0;
                len -= 1;
            }
        }
        if (0 < len and isSpace(src[len - 1])) {
            while (0 < len and isSpace(src[len - 1])) len -= 1;
            fixed = true;
        }
    }
    var i: usize = 0;
    while (i < len) : (i += 1) {
        const ch = src[i];
        const ii: isize = @intCast(i);
        if (ch == '\t') {
            last_tab_in_indent = ii;
            if (ws_rule & WS_SPACE_BEFORE_TAB != 0 and 0 <= last_space_in_indent)
                need_fix_leading_space = true;
        } else if (ch == ' ') {
            last_space_in_indent = ii;
            if (ws_rule & WS_INDENT_WITH_NON_TAB != 0 and tabw <= ii - last_tab_in_indent)
                need_fix_leading_space = true;
        } else break;
    }
    if (need_fix_leading_space) {
        var consecutive_spaces: isize = 0;
        var last: usize = @intCast(last_tab_in_indent + 1);
        if (ws_rule & WS_INDENT_WITH_NON_TAB != 0) {
            if (last_tab_in_indent < last_space_in_indent)
                last = @intCast(last_space_in_indent + 1)
            else
                last = @intCast(last_tab_in_indent + 1);
        }
        i = 0;
        while (i < last) : (i += 1) {
            const ch = src[i];
            if (ch != ' ') {
                consecutive_spaces = 0;
                util.bufByte(dst, ch);
            } else {
                consecutive_spaces += 1;
                if (consecutive_spaces == tabw) {
                    util.bufByte(dst, '\t');
                    consecutive_spaces = 0;
                }
            }
        }
        while (consecutive_spaces > 0) : (consecutive_spaces -= 1) util.bufByte(dst, ' ');
        len -= last;
        src = src[last..];
        fixed = true;
    } else if (ws_rule & WS_TAB_IN_INDENT != 0 and last_tab_in_indent >= 0) {
        const start = dst.items.len;
        const last: usize = @intCast(last_tab_in_indent + 1);
        i = 0;
        while (i < last) : (i += 1) {
            if (src[i] == '\t') {
                while (true) {
                    util.bufByte(dst, ' ');
                    if ((dst.items.len - start) % @as(usize, @intCast(tabw)) == 0) break;
                }
            } else util.bufByte(dst, src[i]);
        }
        len -= last;
        src = src[last..];
        fixed = true;
    }
    util.bufAppend(dst, src[0..len]);
    if (add_cr_to_tail) util.bufByte(dst, '\r');
    if (add_nl_to_tail) util.bufByte(dst, '\n');
    if (fixed) {
        if (error_count) |ec| ec.* += 1;
    }
}

// ---------------------------------------------------------------------------
// colors

pub const Slot = enum(u8) {
    reset = 0,
    context,
    metainfo,
    fraginfo,
    old,
    new,
    commit,
    whitespace,
    funcinfo,
    old_moved,
    old_moved_alt,
    old_moved_dim,
    old_moved_alt_dim,
    new_moved,
    new_moved_alt,
    new_moved_dim,
    new_moved_alt_dim,
    context_dim,
    old_dim,
    new_dim,
    context_bold,
    old_bold,
    new_bold,
};

var diff_colors = [_][]const u8{
    color.RESET,
    "", // CONTEXT
    color.BOLD, // METAINFO
    color.CYAN, // FRAGINFO
    color.RED, // OLD
    color.GREEN, // NEW
    color.YELLOW, // COMMIT
    "\x1b[41m", // WHITESPACE
    "", // FUNCINFO
    color.BOLD_MAGENTA,
    color.BOLD_BLUE,
    color.FAINT,
    "\x1b[2;3m",
    color.BOLD_CYAN,
    color.BOLD_YELLOW,
    color.FAINT,
    "\x1b[2;3m",
    color.FAINT,
    "\x1b[2;31m",
    "\x1b[2;32m",
    color.BOLD,
    color.BOLD_RED,
    color.BOLD_GREEN,
};

const color_slot_names = [_][]const u8{
    "",                    "context",                   "meta",           "frag",
    "old",                 "new",                       "commit",         "whitespace",
    "func",                "oldMoved",                  "oldMovedAlternative", "oldMovedDimmed",
    "oldMovedAlternativeDimmed", "newMoved",            "newMovedAlternative", "newMovedDimmed",
    "newMovedAlternativeDimmed", "contextDimmed",       "oldDimmed",      "newDimmed",
    "contextBold",         "oldBold",                   "newBold",
};

fn parseDiffColorSlot(name: []const u8) ?usize {
    if (std.ascii.eqlIgnoreCase(name, "plain")) return @intFromEnum(Slot.context);
    for (color_slot_names, 0..) |n, i| {
        if (i == 0) continue;
        if (std.ascii.eqlIgnoreCase(n, name)) return i;
    }
    return null;
}

/// Slot lookup by name as used by log-tree's get_color hook ("commit", "reset", ...).
pub fn slotByName(name: []const u8) ?Slot {
    if (util.eql(name, "reset")) return .reset;
    const i = parseDiffColorSlot(name) orelse return null;
    return @enumFromInt(i);
}

var stdout_tty: ?bool = null;
pub fn wantColor(cb: color.ColorBool) bool {
    var v = cb;
    if (v == .unknown) v = git_use_color_default;
    if (v == .auto) {
        if (stdout_tty == null) stdout_tty = color.wantColorBool(.auto, null);
        return stdout_tty.?;
    }
    return v == .always;
}

pub fn getColor(o: *const DiffOptions, slot: Slot) []const u8 {
    if (wantColor(o.use_color)) return diff_colors[@intFromEnum(slot)];
    return "";
}

fn getColorCb(cb: color.ColorBool, slot: Slot) []const u8 {
    if (wantColor(cb)) return diff_colors[@intFromEnum(slot)];
    return "";
}

// ---------------------------------------------------------------------------
// configuration (git_diff_basic_config / git_diff_ui_config)

var basic_loaded = false;
var ui_loaded = false;

var diff_use_color_default: color.ColorBool = .unknown;
var git_use_color_default: color.ColorBool = .auto;
var diff_color_moved_default: ColorMoved = .no;
var diff_color_moved_ws_default: u32 = 0;
var diff_context_default: i32 = 3;
var diff_interhunk_context_default: i32 = 0;
var diff_word_regex_cfg: ?[]const u8 = null;
var external_diff_cfg: ?[]const u8 = null;
var external_diff_trust_cfg = false;
var diff_order_file_cfg: ?[]const u8 = null;
pub var diff_auto_refresh_index = true;
var diff_mnemonic_prefix = false;
var diff_no_prefix = false;
var diff_src_prefix: ?[]const u8 = null;
var diff_dst_prefix: ?[]const u8 = null;
var diff_relative = false;
var diff_stat_name_width: i32 = 0;
var diff_stat_graph_width: i32 = 0;
var diff_dirstat_permille_default: i32 = 30;
var diff_dirstat_flags_default: DirstatFlags = .{};
var diff_algorithm: u64 = 0;
var ws_error_highlight_default: u32 = WSEH_NEW;
var diff_detect_rename_default: u8 = 0;
var diff_rename_limit_default: i32 = 1000;
var diff_suppress_blank_empty = false;
var diff_indent_heuristic = true;
var diff_submodule_format_default: SubmoduleFormat = .short;
var diff_ignore_submodules_default: ?[]const u8 = null;

const DirstatFlags = struct { by_line: bool = false, by_file: bool = false, cumulative: bool = false };

fn cfgInt(e: config.Entry) i32 {
    const kv = e.kvi();
    return config.configInt(e.key, e.value, &kv);
}

/// config_error_nonbool + die (git dies on config callback errors)
fn cfgNonbool(e: config.Entry) []const u8 {
    return e.value orelse {
        util.err("missing value for '{s}'", .{e.key});
        badConfigDie(e);
    };
}

fn badConfigDie(e: config.Entry) noreturn {
    if (e.origin_type == .cmdline or e.origin.len == 0)
        util.die("unable to parse '{s}' from command-line config", .{e.key});
    util.die("bad config variable '{s}' in file '{s}' at line {d}", .{ e.key, e.origin, e.line });
}

fn parseAlgorithmValue(value: ?[]const u8) ?u64 {
    const v = value orelse return null;
    if (std.ascii.eqlIgnoreCase(v, "myers") or std.ascii.eqlIgnoreCase(v, "default")) return 0;
    if (std.ascii.eqlIgnoreCase(v, "minimal")) return xdiff.XDF_NEED_MINIMAL;
    if (std.ascii.eqlIgnoreCase(v, "patience")) return xdiff.XDF_PATIENCE_DIFF;
    if (std.ascii.eqlIgnoreCase(v, "histogram")) return xdiff.XDF_HISTOGRAM_DIFF;
    return null;
}

/// git_config_rename()
fn configRename(key: []const u8, value: ?[]const u8) u8 {
    const v = value orelse return DETECT_RENAME;
    if (std.ascii.eqlIgnoreCase(v, "copies") or std.ascii.eqlIgnoreCase(v, "copy")) return DETECT_COPY;
    return if (config.configBool(key, v)) DETECT_RENAME else 0;
}

fn parseOneToken(arg: *[]const u8, token: []const u8) bool {
    if (util.skipPrefix(arg.*, token)) |rest| {
        if (rest.len == 0 or rest[0] == ',') {
            arg.* = rest;
            return true;
        }
    }
    return false;
}

/// parse_ws_error_highlight(): value, or error offset (-1 - offset)
fn parseWsErrorHighlight(arg0: []const u8) i64 {
    var arg = arg0;
    var val: u32 = 0;
    while (arg.len > 0) {
        if (parseOneToken(&arg, "none")) {
            val = 0;
        } else if (parseOneToken(&arg, "default")) {
            val = WSEH_NEW;
        } else if (parseOneToken(&arg, "all")) {
            val = WSEH_NEW | WSEH_OLD | WSEH_CONTEXT;
        } else if (parseOneToken(&arg, "new")) {
            val |= WSEH_NEW;
        } else if (parseOneToken(&arg, "old")) {
            val |= WSEH_OLD;
        } else if (parseOneToken(&arg, "context")) {
            val |= WSEH_CONTEXT;
        } else {
            return -1 - @as(i64, @intCast(arg0.len - arg.len));
        }
        if (arg.len > 0) arg = arg[1..];
    }
    return val;
}

fn parseColorMoved(arg: ?[]const u8) ?ColorMoved {
    switch (config.parseMaybeBool(arg)) {
        0 => return .no,
        1 => return COLOR_MOVED_DEFAULT,
        else => {},
    }
    const a = arg orelse return null;
    if (util.eql(a, "no")) return .no;
    if (util.eql(a, "plain")) return .plain;
    if (util.eql(a, "blocks")) return .blocks;
    if (util.eql(a, "zebra")) return .zebra;
    if (util.eql(a, "default")) return COLOR_MOVED_DEFAULT;
    if (util.eql(a, "dimmed-zebra") or util.eql(a, "dimmed_zebra")) return .zebra_dim;
    util.err("color moved setting must be one of 'no', 'default', 'blocks', 'zebra', 'dimmed-zebra', 'plain'", .{});
    return null;
}

fn parseColorMovedWs(arg: []const u8) u32 {
    var ret: u32 = 0;
    var it = std.mem.splitScalar(u8, arg, ',');
    while (it.next()) |raw| {
        const s = util.trim(raw);
        if (util.eql(s, "no")) {
            ret = 0;
        } else if (util.eql(s, "ignore-space-change")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE_CHANGE);
        } else if (util.eql(s, "ignore-space-at-eol")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE_AT_EOL);
        } else if (util.eql(s, "ignore-all-space")) {
            ret |= @intCast(xdiff.XDF_IGNORE_WHITESPACE);
        } else if (util.eql(s, "allow-indentation-change")) {
            ret |= COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE;
        } else {
            ret |= COLOR_MOVED_WS_ERROR;
            util.err("unknown color-moved-ws mode '{s}', possible values are 'ignore-space-change', 'ignore-space-at-eol', 'ignore-all-space', 'allow-indentation-change'", .{s});
        }
    }
    if (ret & COLOR_MOVED_WS_ALLOW_INDENTATION_CHANGE != 0 and ret & @as(u32, @intCast(xdiff.XDF_WHITESPACE_FLAGS)) != 0) {
        util.err("color-moved-ws: allow-indentation-change cannot be combined with other whitespace modes", .{});
        ret |= COLOR_MOVED_WS_ERROR;
    }
    return ret;
}

/// parse_dirstat_params(): returns error text (empty if ok)
fn parseDirstatParams(o: *DiffOptions, params: []const u8) []const u8 {
    var errmsg: Buf = .empty;
    if (params.len == 0) return "";
    var it = std.mem.splitScalar(u8, params, ',');
    while (it.next()) |p| {
        if (util.eql(p, "changes")) {
            o.flags.dirstat_by_line = false;
            o.flags.dirstat_by_file = false;
        } else if (util.eql(p, "lines")) {
            o.flags.dirstat_by_line = true;
            o.flags.dirstat_by_file = false;
        } else if (util.eql(p, "files")) {
            o.flags.dirstat_by_line = false;
            o.flags.dirstat_by_file = true;
        } else if (util.eql(p, "noncumulative")) {
            o.flags.dirstat_cumulative = false;
        } else if (util.eql(p, "cumulative")) {
            o.flags.dirstat_cumulative = true;
        } else if (p.len > 0 and isDigit(p[0])) {
            var j: usize = 0;
            var n: i32 = 0;
            while (j < p.len and isDigit(p[j])) : (j += 1) n = n *% 10 +% @as(i32, p[j] - '0');
            var permille = n *% 10;
            if (j < p.len and p[j] == '.' and j + 1 < p.len and isDigit(p[j + 1])) {
                j += 1;
                permille += p[j] - '0';
                j += 1;
                while (j < p.len and isDigit(p[j])) j += 1;
            } else if (j < p.len and p[j] == '.') {
                j += 1;
            }
            if (j == p.len) {
                o.dirstat_permille = permille;
            } else {
                util.bufPrint(&errmsg, "  Failed to parse dirstat cut-off percentage '{s}'\n", .{p});
            }
        } else {
            util.bufPrint(&errmsg, "  Unknown dirstat parameter '{s}'\n", .{p});
        }
    }
    return errmsg.items;
}

fn loadBasicConfig() void {
    if (basic_loaded) return;
    basic_loaded = true;
    loadWhitespaceCfg();
    userdiff.loadConfig();
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        if (util.eql(k, "diff.renamelimit")) {
            diff_rename_limit_default = cfgInt(e);
        } else if (util.skipPrefix(k, "diff.color.") orelse util.skipPrefix(k, "color.diff.")) |name| {
            const slot = parseDiffColorSlot(name) orelse continue;
            const v = cfgNonbool(e);
            diff_colors[slot] = color.parseColor(v) orelse {
                util.err("invalid color value: {s}", .{v});
                badConfigDie(e);
            };
        } else if (util.eql(k, "diff.wserrorhighlight")) {
            const v = cfgNonbool(e);
            const val = parseWsErrorHighlight(v);
            if (val < 0) {
                util.err("unknown value for config '{s}': {s}", .{ k, v });
                badConfigDie(e);
            }
            ws_error_highlight_default = @intCast(val);
        } else if (util.eql(k, "diff.suppressblankempty") or util.eql(k, "diff.suppress-blank-empty")) {
            diff_suppress_blank_empty = config.configBool(k, e.value);
        } else if (util.eql(k, "diff.dirstat")) {
            const v = cfgNonbool(e);
            var tmp = DiffOptions.zero();
            tmp.dirstat_permille = diff_dirstat_permille_default;
            tmp.flags.dirstat_by_line = diff_dirstat_flags_default.by_line;
            tmp.flags.dirstat_by_file = diff_dirstat_flags_default.by_file;
            tmp.flags.dirstat_cumulative = diff_dirstat_flags_default.cumulative;
            const em = parseDirstatParams(&tmp, v);
            if (em.len > 0) util.warn("Found errors in 'diff.dirstat' config variable:\n{s}", .{em});
            diff_dirstat_permille_default = tmp.dirstat_permille;
            diff_dirstat_flags_default = .{ .by_line = tmp.flags.dirstat_by_line, .by_file = tmp.flags.dirstat_by_file, .cumulative = tmp.flags.dirstat_cumulative };
        } else if (util.eql(k, "diff.indentheuristic")) {
            diff_indent_heuristic = config.configBool(k, e.value);
        }
    }
}

fn loadUiConfig() void {
    loadBasicConfig();
    if (ui_loaded) return;
    ui_loaded = true;
    diff_detect_rename_default = DETECT_RENAME;
    for (repo_mod.cfg.entries.items) |e| {
        const k = e.key;
        const v = e.value;
        if (util.eql(k, "diff.color") or util.eql(k, "color.diff")) {
            diff_use_color_default = color.configColorBool(k, v);
        } else if (util.eql(k, "color.ui")) {
            git_use_color_default = color.configColorBool(k, v);
        } else if (util.eql(k, "diff.colormoved")) {
            diff_color_moved_default = parseColorMoved(v) orelse badConfigDie(e);
        } else if (util.eql(k, "diff.colormovedws")) {
            const s = cfgNonbool(e);
            const cm = parseColorMovedWs(s);
            if (cm & COLOR_MOVED_WS_ERROR != 0) badConfigDie(e);
            diff_color_moved_ws_default = cm;
        } else if (util.eql(k, "diff.context")) {
            const val = cfgInt(e);
            if (val < 0) badConfigDie(e);
            diff_context_default = val;
        } else if (util.eql(k, "diff.interhunkcontext")) {
            const val = cfgInt(e);
            if (val < 0) badConfigDie(e);
            diff_interhunk_context_default = val;
        } else if (util.eql(k, "diff.renames")) {
            diff_detect_rename_default = configRename(k, v);
        } else if (util.eql(k, "diff.autorefreshindex")) {
            diff_auto_refresh_index = config.configBool(k, v);
        } else if (util.eql(k, "diff.mnemonicprefix")) {
            diff_mnemonic_prefix = config.configBool(k, v);
        } else if (util.eql(k, "diff.noprefix")) {
            diff_no_prefix = config.configBool(k, v);
        } else if (util.eql(k, "diff.srcprefix")) {
            diff_src_prefix = cfgNonbool(e);
        } else if (util.eql(k, "diff.dstprefix")) {
            diff_dst_prefix = cfgNonbool(e);
        } else if (util.eql(k, "diff.relative")) {
            diff_relative = config.configBool(k, v);
        } else if (util.eql(k, "diff.statnamewidth")) {
            diff_stat_name_width = cfgInt(e);
        } else if (util.eql(k, "diff.statgraphwidth")) {
            diff_stat_graph_width = cfgInt(e);
        } else if (util.eql(k, "diff.external")) {
            external_diff_cfg = cfgNonbool(e);
        } else if (util.eql(k, "diff.trustexitcode")) {
            external_diff_trust_cfg = config.configBool(k, v);
        } else if (util.eql(k, "diff.wordregex")) {
            diff_word_regex_cfg = cfgNonbool(e);
        } else if (util.eql(k, "diff.orderfile")) {
            _ = cfgNonbool(e);
            diff_order_file_cfg = repo_mod.cfg.getPath(k);
        } else if (util.eql(k, "diff.ignoresubmodules")) {
            diff_ignore_submodules_default = cfgNonbool(e);
        } else if (util.eql(k, "diff.submodule")) {
            const s = cfgNonbool(e);
            if (util.eql(s, "log")) {
                diff_submodule_format_default = .log;
            } else if (util.eql(s, "short")) {
                diff_submodule_format_default = .short;
            } else if (util.eql(s, "diff")) {
                diff_submodule_format_default = .inline_diff;
            } else util.warn("Unknown value for 'diff.submodule' config variable: '{s}'", .{s});
        } else if (util.eql(k, "diff.algorithm")) {
            const s = cfgNonbool(e);
            diff_algorithm = parseAlgorithmValue(s) orelse {
                util.err("unknown value for config '{s}': {s}", .{ k, s });
                badConfigDie(e);
            };
        }
    }
}

/// Make the porcelain ("UI") diff configuration effective (git_diff_ui_config).
pub fn useUiConfig() void {
    loadUiConfig();
}

/// external_diff(): GIT_EXTERNAL_DIFF or diff.external
fn externalDiff() ?[]const u8 {
    if (os.getenv("GIT_EXTERNAL_DIFF")) |e| return e;
    return external_diff_cfg;
}

// ---------------------------------------------------------------------------
// diff_options

pub const DiffFlags = struct {
    recursive: bool = false,
    tree_in_recursive: bool = false,
    binary: bool = false,
    text: bool = false,
    full_index: bool = false,
    silent_on_remove: bool = false,
    find_copies_harder: bool = false,
    follow_renames: bool = false,
    rename_empty: bool = true,
    has_changes: bool = false,
    quick: bool = false,
    no_index: bool = false,
    allow_external: bool = false,
    exit_with_status: bool = false,
    reverse: bool = false,
    check_failed: bool = false,
    relative_name: bool = false,
    ignore_submodules: bool = false,
    dirstat_cumulative: bool = false,
    dirstat_by_file: bool = false,
    allow_textconv: bool = false,
    textconv_set_via_cmdline: bool = false,
    diff_from_contents: bool = false,
    dirty_submodules: bool = false,
    ignore_untracked_in_submodules: bool = false,
    ignore_dirty_submodules: bool = false,
    override_submodule_config: bool = false,
    dirstat_by_line: bool = false,
    funccontext: bool = false,
    default_follow_renames: bool = false,
    stat_with_summary: bool = false,
    suppress_diff_headers: bool = false,
    dual_color_diffed_diffs: bool = false,
    suppress_hunk_header_line_count: bool = false,
    ignore_submodule_set: bool = false,
};

pub const DiffOptions = struct {
    output_format: u32 = 0,
    flags: DiffFlags = .{},
    /// output stream; null = discard
    file: ?*util.Out = &util.stdout,
    close_file: bool = false,
    pathspec: pathspec_mod.Pathspec = .{},
    a_prefix: ?[]const u8 = null,
    b_prefix: ?[]const u8 = null,
    line_prefix: ?[]const u8 = null,
    /// --relative prefix (path relative to top, ending with '/')
    prefix: ?[]const u8 = null,
    prefix_length: usize = 0,
    stat_sep: ?[]const u8 = null,
    xdl_opts: u64 = 0,
    ignore_driver_algorithm: bool = false,
    ignore_regex: std.ArrayList(regex.Regex) = .empty,
    anchors: std.ArrayList([]const u8) = .empty,
    ws_error_highlight: u32 = WSEH_NEW,
    context: i32 = 3,
    interhunkcontext: i32 = 0,
    break_opt: i32 = -1,
    detect_rename: u8 = 0,
    irreversible_delete: bool = false,
    skip_stat_unmatch: i32 = 0,
    line_termination: u8 = '\n',
    output_indicators: [3]u8 = .{ '+', '-', ' ' },
    pickaxe: ?[]const u8 = null,
    pickaxe_opts: u32 = 0,
    pickaxe_re: ?regex.Regex = null,
    filter: u32 = 0,
    filter_not: u32 = 0,
    orderfile: ?[]const u8 = null,
    rotate_to: ?[]const u8 = null,
    skip_instead_of_rotate: bool = false,
    objfind: ?*hash.OidSet = null,
    /// -1 = default abbreviation, 0 = full
    abbrev: i32 = -1,
    rename_score: u32 = 0,
    rename_limit: i32 = -1,
    needed_rename_limit: i32 = 0,
    degraded_cc_to_c: bool = false,
    show_rename_progress: bool = false,
    use_color: color.ColorBool = .unknown,
    color_moved: ColorMoved = .no,
    color_moved_ws_handling: u32 = 0,
    stat_width: i32 = 0,
    stat_name_width: i32 = 0,
    stat_graph_width: i32 = 0,
    stat_count: i32 = 0,
    word_regex: ?[]const u8 = null,
    word_diff: WordDiff = .none,
    submodule_format: SubmoduleFormat = .short,
    dirstat_permille: i32 = 30,
    found_changes: bool = false,
    found_follow: bool = false,
    graph: ?*graph_mod.Graph = null,
    ita_invisible_in_index: bool = false,
    max_depth: i32 = -1,
    max_depth_valid: bool = false,
    diff_path_counter: usize = 0,
    /// set when the options come from a porcelain (init())
    porcelain: bool = false,
    /// --no-index: paths are not repository paths
    no_index_paths: bool = false,
    /// rev_info for log-tree callbacks (setupRevDiff)
    revs: ?*revision.RevInfo = null,

    /// all zero, no config consulted
    pub fn zero() DiffOptions {
        return .{};
    }

    /// repo_diff_setup() after git_diff_basic_config (plumbing)
    pub fn initBasic() DiffOptions {
        loadBasicConfig();
        var o = DiffOptions{};
        o.setupDefaults();
        return o;
    }

    /// repo_diff_setup() after git_diff_ui_config (porcelain)
    pub fn init() DiffOptions {
        loadUiConfig();
        var o = DiffOptions{};
        o.porcelain = true;
        o.setupDefaults();
        return o;
    }

    fn setupDefaults(o: *DiffOptions) void {
        o.file = &util.stdout;
        o.output_indicators = .{ '+', '-', ' ' };
        o.abbrev = -1;
        o.line_termination = '\n';
        o.break_opt = -1;
        o.rename_limit = -1;
        o.dirstat_permille = diff_dirstat_permille_default;
        o.flags.dirstat_by_line = diff_dirstat_flags_default.by_line;
        o.flags.dirstat_by_file = diff_dirstat_flags_default.by_file;
        o.flags.dirstat_cumulative = diff_dirstat_flags_default.cumulative;
        o.context = diff_context_default;
        o.interhunkcontext = diff_interhunk_context_default;
        o.ws_error_highlight = ws_error_highlight_default;
        o.flags.rename_empty = true;
        o.flags.relative_name = diff_relative;
        o.use_color = diff_use_color_default;
        o.detect_rename = diff_detect_rename_default;
        o.xdl_opts |= diff_algorithm;
        if (diff_indent_heuristic) o.xdl_opts |= xdiff.XDF_INDENT_HEURISTIC;
        o.orderfile = diff_order_file_cfg;
        if (!o.flags.ignore_submodule_set) o.flags.ignore_untracked_in_submodules = true;
        if (diff_no_prefix) {
            o.setNoprefix();
        } else if (!diff_mnemonic_prefix) {
            o.setDefaultPrefix();
        }
        o.color_moved = diff_color_moved_default;
        o.color_moved_ws_handling = diff_color_moved_ws_default;
        o.submodule_format = diff_submodule_format_default;
        if (repo_mod.repo_) |r| {
            if (r.prefix.len > 0) {
                o.prefix = r.prefix;
                o.prefix_length = r.prefix.len;
            }
        }
        if (diff_ignore_submodules_default) |v| {
            if (util.eql(v, "all")) o.flags.ignore_submodules = true;
        }
    }

    pub fn setNoprefix(o: *DiffOptions) void {
        o.a_prefix = "";
        o.b_prefix = "";
    }

    pub fn setDefaultPrefix(o: *DiffOptions) void {
        o.a_prefix = diff_src_prefix orelse "a/";
        o.b_prefix = diff_dst_prefix orelse "b/";
    }

    /// diff_set_mnemonic_prefix(): only fills unset prefixes
    pub fn setMnemonicPrefix(o: *DiffOptions, a: []const u8, b: []const u8) void {
        if (o.a_prefix == null) o.a_prefix = a;
        if (o.b_prefix == null) o.b_prefix = b;
    }

    /// handle_ignore_submodules_arg()
    pub fn handleIgnoreSubmodulesArg(o: *DiffOptions, arg: []const u8) void {
        o.flags.ignore_submodule_set = true;
        o.flags.ignore_submodules = false;
        o.flags.ignore_untracked_in_submodules = false;
        o.flags.ignore_dirty_submodules = false;
        if (util.eql(arg, "all")) {
            o.flags.ignore_submodules = true;
        } else if (util.eql(arg, "untracked")) {
            o.flags.ignore_untracked_in_submodules = true;
        } else if (util.eql(arg, "dirty")) {
            o.flags.ignore_dirty_submodules = true;
        } else if (!util.eql(arg, "none")) {
            util.die("bad --ignore-submodules argument: {s}", .{arg});
        }
    }

    pub fn setAlgorithm(o: *DiffOptions, alg: []const u8) bool {
        const v = parseAlgorithmValue(alg) orelse return false;
        o.xdl_opts &= ~xdiff.XDF_DIFF_ALGORITHM_MASK;
        o.xdl_opts |= v;
        return true;
    }

    /// Parse one diff option at args[i]. Returns the number of args consumed,
    /// 0 when args[i] is not a diff option. Usage errors exit 129.
    pub fn parseOpt(o: *DiffOptions, args: []const []const u8, i: usize) usize {
        return parseDiffOpt(o, args, i);
    }

    /// diff_setup_done()
    pub fn setupDone(o: *DiffOptions) void {
        setupDoneImpl(o);
    }

    pub fn out(o: *DiffOptions) *util.Out {
        return o.file orelse &null_out;
    }
};

var null_out = util.Out{ .fd = -1, .broken = true };

fn hasMultiBits(x: u32) bool {
    return x & (x -% 1) != 0;
}

fn setupDoneImpl(o: *DiffOptions) void {
    const check_mask = FMT_NAME | FMT_NAME_STATUS | FMT_CHECKDIFF | FMT_NO_OUTPUT;
    if (hasMultiBits(o.output_format & check_mask))
        util.die("options '{s}', '{s}', '{s}', and '{s}' cannot be used together", .{ "--name-only", "--name-status", "--check", "-s" });
    if (hasMultiBits(o.pickaxe_opts & PICKAXE_KINDS_MASK))
        util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ "-G", "-S", "--find-object" });
    if (hasMultiBits(o.pickaxe_opts & (PICKAXE_KIND_G | PICKAXE_REGEX)))
        util.die("options '{s}' and '{s}' cannot be used together, use '{s}' with '{s}'", .{ "-G", "--pickaxe-regex", "--pickaxe-regex", "-S" });
    if (hasMultiBits(o.pickaxe_opts & (PICKAXE_ALL | PICKAXE_KIND_OBJFIND)))
        util.die("options '{s}' and '{s}' cannot be used together, use '{s}' with '{s}' and '{s}'", .{ "--pickaxe-all", "--find-object", "--pickaxe-all", "-G", "-S" });

    o.flags.diff_from_contents = (o.xdl_opts & xdiff.XDF_WHITESPACE_FLAGS) != 0 or o.ignore_regex.items.len > 0;
    if (o.flags.find_copies_harder) o.detect_rename = DETECT_COPY;
    if (!o.flags.relative_name) o.prefix = null;
    o.prefix_length = if (o.prefix) |p| p.len else 0;

    if (o.output_format & (FMT_NAME | FMT_NAME_STATUS | FMT_CHECKDIFF | FMT_NO_OUTPUT) != 0)
        o.output_format &= ~(FMT_RAW | FMT_NUMSTAT | FMT_DIFFSTAT | FMT_SHORTSTAT | FMT_DIRSTAT | FMT_SUMMARY | FMT_PATCH);
    if (o.output_format & (FMT_PATCH | FMT_NUMSTAT | FMT_DIFFSTAT | FMT_SHORTSTAT | FMT_DIRSTAT | FMT_SUMMARY | FMT_CHECKDIFF) != 0)
        o.flags.recursive = true;
    if (o.pickaxe_opts & PICKAXE_KINDS_MASK != 0) o.flags.recursive = true;
    if (o.output_format & FMT_PATCH != 0) o.flags.dirty_submodules = true;
    if (o.detect_rename != 0 and o.rename_limit < 0) o.rename_limit = diff_rename_limit_default;
    if (40 < o.abbrev) o.abbrev = 40;
    if (o.flags.quick) {
        o.output_format = FMT_NO_OUTPUT;
        o.flags.exit_with_status = true;
        o.detect_rename = 0;
        o.flags.find_copies_harder = false;
    }
    if (o.flags.allow_external and o.flags.exit_with_status) o.flags.diff_from_contents = true;
    o.diff_path_counter = 0;
    if (o.flags.follow_renames) _ = checkFollowPathspec(&o.pathspec, true);
    if (o.flags.allow_external and externalDiff() != null) o.color_moved = .no;
    if (o.filter_not != 0) {
        if (o.filter == 0) o.filter = ~filterBit(STATUS_FILTER_AON);
        o.filter &= ~o.filter_not;
    }
    if (o.pathspec.has_wildcard and o.max_depth_valid)
        util.die("max-depth cannot be used with wildcard pathspecs", .{});
}

/// diff_check_follow_pathspec()
pub fn checkFollowPathspec(ps: *const pathspec_mod.Pathspec, die_on_error: bool) bool {
    if (ps.items.len != 1) {
        if (die_on_error) util.die("--follow requires exactly one pathspec", .{});
        return false;
    }
    const forbidden = ps.items[0].magic & ~(pathspec_mod.MAGIC_FROMTOP | pathspec_mod.MAGIC_LITERAL);
    if (forbidden != 0) {
        if (die_on_error) util.die("pathspec magic not supported by --follow: {s}", .{pathspec_mod.magicNames(forbidden)});
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------
// option parsing (add_diff_options + parse-options ONE_SHOT|KEEP_UNKNOWN_OPT)

const ArgKind = enum { none, req, opt };
const OptId = enum {
    patch,
    no_patch,
    u,
    unified,
    function_context,
    raw,
    patch_with_raw,
    patch_with_stat,
    numstat,
    shortstat,
    dirstat,
    cumulative,
    dirstat_by_file,
    check,
    summary,
    name_only,
    name_status,
    stat,
    stat_width,
    stat_name_width,
    stat_graph_width,
    stat_count,
    compact_summary,
    binary,
    full_index,
    color,
    ws_error_highlight,
    z,
    abbrev,
    src_prefix,
    dst_prefix,
    line_prefix,
    no_prefix,
    default_prefix,
    inter_hunk_context,
    output_indicator_new,
    output_indicator_old,
    output_indicator_context,
    break_rewrites,
    find_renames,
    irreversible_delete,
    find_copies,
    find_copies_harder,
    no_renames,
    rename_empty,
    follow,
    rename_limit,
    minimal,
    ignore_all_space,
    ignore_space_change,
    ignore_space_at_eol,
    ignore_cr_at_eol,
    ignore_blank_lines,
    ignore_matching_lines,
    indent_heuristic,
    patience,
    histogram,
    diff_algorithm,
    anchored,
    word_diff,
    word_diff_regex,
    color_words,
    color_moved,
    color_moved_ws,
    relative,
    text,
    reverse,
    exit_code,
    quiet,
    ext_diff,
    textconv,
    ignore_submodules,
    submodule,
    ita_invisible,
    ita_visible,
    pickaxe_s,
    pickaxe_g,
    pickaxe_all,
    pickaxe_regex,
    orderfile,
    rotate_to,
    skip_to,
    find_object,
    diff_filter,
    max_depth,
    output,
};

const OptDef = struct {
    short: u8 = 0,
    long: []const u8 = "",
    arg: ArgKind = .none,
    noneg: bool = false,
    id: OptId,
};

const opt_defs = [_]OptDef{
    .{ .short = 'p', .long = "patch", .noneg = true, .id = .patch },
    .{ .short = 's', .long = "no-patch", .id = .no_patch },
    .{ .short = 'u', .noneg = true, .id = .u },
    .{ .short = 'U', .long = "unified", .arg = .opt, .noneg = true, .id = .unified },
    .{ .short = 'W', .long = "function-context", .id = .function_context },
    .{ .long = "raw", .noneg = true, .id = .raw },
    .{ .long = "patch-with-raw", .noneg = true, .id = .patch_with_raw },
    .{ .long = "patch-with-stat", .noneg = true, .id = .patch_with_stat },
    .{ .long = "numstat", .noneg = true, .id = .numstat },
    .{ .long = "shortstat", .noneg = true, .id = .shortstat },
    .{ .short = 'X', .long = "dirstat", .arg = .opt, .noneg = true, .id = .dirstat },
    .{ .long = "cumulative", .noneg = true, .id = .cumulative },
    .{ .long = "dirstat-by-file", .arg = .opt, .noneg = true, .id = .dirstat_by_file },
    .{ .long = "check", .noneg = true, .id = .check },
    .{ .long = "summary", .noneg = true, .id = .summary },
    .{ .long = "name-only", .noneg = true, .id = .name_only },
    .{ .long = "name-status", .noneg = true, .id = .name_status },
    .{ .long = "stat", .arg = .opt, .noneg = true, .id = .stat },
    .{ .long = "stat-width", .arg = .req, .noneg = true, .id = .stat_width },
    .{ .long = "stat-name-width", .arg = .req, .noneg = true, .id = .stat_name_width },
    .{ .long = "stat-graph-width", .arg = .req, .noneg = true, .id = .stat_graph_width },
    .{ .long = "stat-count", .arg = .req, .noneg = true, .id = .stat_count },
    .{ .long = "compact-summary", .id = .compact_summary },
    .{ .long = "binary", .noneg = true, .id = .binary },
    .{ .long = "full-index", .id = .full_index },
    .{ .long = "color", .arg = .opt, .id = .color },
    .{ .long = "ws-error-highlight", .arg = .req, .noneg = true, .id = .ws_error_highlight },
    .{ .short = 'z', .id = .z },
    .{ .long = "abbrev", .arg = .opt, .id = .abbrev },
    .{ .long = "src-prefix", .arg = .req, .noneg = true, .id = .src_prefix },
    .{ .long = "dst-prefix", .arg = .req, .noneg = true, .id = .dst_prefix },
    .{ .long = "line-prefix", .arg = .req, .noneg = true, .id = .line_prefix },
    .{ .long = "no-prefix", .noneg = true, .id = .no_prefix },
    .{ .long = "default-prefix", .noneg = true, .id = .default_prefix },
    .{ .long = "inter-hunk-context", .arg = .req, .id = .inter_hunk_context },
    .{ .long = "output-indicator-new", .arg = .req, .noneg = true, .id = .output_indicator_new },
    .{ .long = "output-indicator-old", .arg = .req, .noneg = true, .id = .output_indicator_old },
    .{ .long = "output-indicator-context", .arg = .req, .noneg = true, .id = .output_indicator_context },
    .{ .short = 'B', .long = "break-rewrites", .arg = .opt, .noneg = true, .id = .break_rewrites },
    .{ .short = 'M', .long = "find-renames", .arg = .opt, .noneg = true, .id = .find_renames },
    .{ .short = 'D', .long = "irreversible-delete", .noneg = true, .id = .irreversible_delete },
    .{ .short = 'C', .long = "find-copies", .arg = .opt, .noneg = true, .id = .find_copies },
    .{ .long = "find-copies-harder", .id = .find_copies_harder },
    .{ .long = "no-renames", .noneg = true, .id = .no_renames },
    .{ .long = "rename-empty", .id = .rename_empty },
    .{ .long = "follow", .id = .follow },
    .{ .short = 'l', .arg = .req, .id = .rename_limit },
    .{ .long = "minimal", .noneg = true, .id = .minimal },
    .{ .short = 'w', .long = "ignore-all-space", .noneg = true, .id = .ignore_all_space },
    .{ .short = 'b', .long = "ignore-space-change", .noneg = true, .id = .ignore_space_change },
    .{ .long = "ignore-space-at-eol", .noneg = true, .id = .ignore_space_at_eol },
    .{ .long = "ignore-cr-at-eol", .noneg = true, .id = .ignore_cr_at_eol },
    .{ .long = "ignore-blank-lines", .noneg = true, .id = .ignore_blank_lines },
    .{ .short = 'I', .long = "ignore-matching-lines", .arg = .req, .id = .ignore_matching_lines },
    .{ .long = "indent-heuristic", .id = .indent_heuristic },
    .{ .long = "patience", .noneg = true, .id = .patience },
    .{ .long = "histogram", .noneg = true, .id = .histogram },
    .{ .long = "diff-algorithm", .arg = .req, .noneg = true, .id = .diff_algorithm },
    .{ .long = "anchored", .arg = .req, .noneg = true, .id = .anchored },
    .{ .long = "word-diff", .arg = .opt, .noneg = true, .id = .word_diff },
    .{ .long = "word-diff-regex", .arg = .req, .noneg = true, .id = .word_diff_regex },
    .{ .long = "color-words", .arg = .opt, .noneg = true, .id = .color_words },
    .{ .long = "color-moved", .arg = .opt, .id = .color_moved },
    .{ .long = "color-moved-ws", .arg = .req, .id = .color_moved_ws },
    .{ .long = "relative", .arg = .opt, .id = .relative },
    .{ .short = 'a', .long = "text", .id = .text },
    .{ .short = 'R', .id = .reverse },
    .{ .long = "exit-code", .id = .exit_code },
    .{ .long = "quiet", .id = .quiet },
    .{ .long = "ext-diff", .id = .ext_diff },
    .{ .long = "textconv", .id = .textconv },
    .{ .long = "ignore-submodules", .arg = .opt, .noneg = true, .id = .ignore_submodules },
    .{ .long = "submodule", .arg = .opt, .noneg = true, .id = .submodule },
    .{ .long = "ita-invisible-in-index", .noneg = true, .id = .ita_invisible },
    .{ .long = "ita-visible-in-index", .noneg = true, .id = .ita_visible },
    .{ .short = 'S', .arg = .req, .id = .pickaxe_s },
    .{ .short = 'G', .arg = .req, .id = .pickaxe_g },
    .{ .long = "pickaxe-all", .noneg = true, .id = .pickaxe_all },
    .{ .long = "pickaxe-regex", .noneg = true, .id = .pickaxe_regex },
    .{ .short = 'O', .arg = .req, .id = .orderfile },
    .{ .long = "rotate-to", .arg = .req, .noneg = true, .id = .rotate_to },
    .{ .long = "skip-to", .arg = .req, .noneg = true, .id = .skip_to },
    .{ .long = "find-object", .arg = .req, .noneg = true, .id = .find_object },
    .{ .long = "diff-filter", .arg = .req, .noneg = true, .id = .diff_filter },
    .{ .long = "max-depth", .arg = .req, .noneg = true, .id = .max_depth },
    .{ .long = "output", .arg = .req, .noneg = true, .id = .output },
};

fn optError(comptime f: []const u8, args: anytype) noreturn {
    util.err(f, args);
    os.exit(129);
}

fn optName(d: *const OptDef, short: bool, unset: bool) []const u8 {
    if (short) return util.fmt("switch `{c}'", .{d.short});
    if (unset) return util.fmt("option `no-{s}'", .{d.long});
    return util.fmt("option `{s}'", .{d.long});
}

const ParseState = struct {
    args: []const []const u8,
    i: usize,
    consumed: usize = 1,
};

fn checkTypos(arg: []const u8) void {
    if (arg.len < 3) return;
    if (util.startsWith(arg, "no-")) optError("did you mean `--{s}` (with two dashes)?", .{arg});
    for (opt_defs) |d| {
        if (d.long.len == 0) continue;
        if (util.startsWith(d.long, arg)) optError("did you mean `--{s}` (with two dashes)?", .{arg});
    }
}

fn parseDiffOpt(o: *DiffOptions, args: []const []const u8, i: usize) usize {
    if (i >= args.len) return 0;
    const arg = args[i];
    if (arg.len < 2 or arg[0] != '-') return 0;
    var st = ParseState{ .args = args, .i = i };
    if (arg[1] != '-') {
        // short option(s)
        var rest: []const u8 = arg[1..];
        var first = true;
        while (rest.len > 0) {
            const c = rest[0];
            var found: ?*const OptDef = null;
            for (&opt_defs) |*d| {
                if (d.short == c) {
                    found = d;
                    break;
                }
            }
            const d = found orelse {
                if (first and rest.len > 0) checkTypos(arg[1..]);
                return 0;
            };
            rest = rest[1..];
            var value: ?[]const u8 = null;
            switch (d.arg) {
                .none => {},
                .opt => {
                    if (rest.len > 0) value = rest;
                    rest = "";
                },
                .req => {
                    if (rest.len > 0) {
                        value = rest;
                    } else if (i + 1 < args.len) {
                        value = args[i + 1];
                        st.consumed = 2;
                    } else optError("{s} requires a value", .{optName(d, true, false)});
                    rest = "";
                },
            }
            applyOpt(o, d, value, false, true, &st);
            if (first and rest.len > 0) checkTypos(arg[1..]);
            first = false;
        }
        return st.consumed;
    }
    if (arg.len == 2) return 0; // "--"
    const body = arg[2..];
    if (util.eql(body, "end-of-options")) return 0;
    var arg_start = body;
    var flags_unset = false;
    var no_no = false;
    if (util.skipPrefix(arg_start, "no-")) |r| {
        arg_start = r;
        if (util.skipPrefix(arg_start, "no-")) |r2| {
            arg_start = r2;
            no_no = true;
        } else flags_unset = true;
    }
    for (&opt_defs) |*d| {
        if (d.long.len == 0) continue;
        var long_name = d.long;
        var opt_unset = false;
        if (util.skipPrefix(long_name, "no-")) |r| {
            long_name = r;
            opt_unset = true;
        } else if (no_no) continue;
        const unset = flags_unset != opt_unset;
        if (unset and d.noneg) continue;
        const rest = util.skipPrefix(arg_start, long_name) orelse continue;
        var value: ?[]const u8 = null;
        var has_eq = false;
        if (rest.len > 0) {
            if (rest[0] != '=') continue;
            value = rest[1..];
            has_eq = true;
        }
        if (unset and has_eq) optError("{s} takes no value", .{optName(d, false, true)});
        if (d.arg == .none and has_eq) optError("{s} takes no value", .{optName(d, false, false)});
        if (d.arg == .req and !has_eq and !unset) {
            if (i + 1 < args.len) {
                value = args[i + 1];
                st.consumed = 2;
            } else optError("{s} requires a value", .{optName(d, false, false)});
        }
        applyOpt(o, d, value, unset, false, &st);
        return st.consumed;
    }
    return 0;
}

fn strtoulPrefix(s: []const u8) struct { v: i64, rest: []const u8 } {
    var j: usize = 0;
    while (j < s.len and isSpace(s[j])) j += 1;
    if (j < s.len and s[j] == '+') j += 1;
    const start = j;
    var v: i64 = 0;
    while (j < s.len and isDigit(s[j])) : (j += 1) v = v *% 10 +% (s[j] - '0');
    if (j == start) return .{ .v = 0, .rest = s };
    return .{ .v = v, .rest = s[j..] };
}

fn strtolPrefix(s: []const u8) struct { v: i64, rest: []const u8 } {
    var j: usize = 0;
    while (j < s.len and isSpace(s[j])) j += 1;
    var neg = false;
    if (j < s.len and (s[j] == '+' or s[j] == '-')) {
        neg = s[j] == '-';
        j += 1;
    }
    const start = j;
    var v: i64 = 0;
    while (j < s.len and isDigit(s[j])) : (j += 1) v = v *% 10 +% (s[j] - '0');
    if (j == start) return .{ .v = 0, .rest = s };
    return .{ .v = if (neg) -v else v, .rest = s[j..] };
}

/// parse_rename_score(): returns score and the unparsed rest
pub fn parseRenameScore(s: []const u8, rest_out: *[]const u8) u32 {
    var num: u64 = 0;
    var scale: u64 = 1;
    var dot = false;
    var j: usize = 0;
    while (j < s.len) {
        const ch = s[j];
        if (!dot and ch == '.') {
            scale = 1;
            dot = true;
        } else if (ch == '%') {
            scale = if (dot) scale * 100 else 100;
            j += 1;
            break;
        } else if (isDigit(ch)) {
            if (scale < 100000) {
                scale *= 10;
                num = num * 10 + (ch - '0');
            }
        } else break;
        j += 1;
    }
    rest_out.* = s[j..];
    if (num >= scale) return MAX_SCORE;
    return @intCast(MAX_SCORE * num / scale);
}

fn userPrefix() []const u8 {
    if (repo_mod.repo_) |r| return r.prefix;
    return "";
}

fn prefixFilename(arg: []const u8) []const u8 {
    if (arg.len > 0 and arg[0] == '/') return arg;
    const p = userPrefix();
    if (p.len == 0) return arg;
    return util.concat(&.{ p, arg });
}

fn parseDirstatOpt(o: *DiffOptions, params: []const u8) void {
    const em = parseDirstatParams(o, params);
    if (em.len > 0) util.die("Failed to parse --dirstat/-X option parameter:\n{s}", .{em});
    o.output_format &= ~FMT_NO_OUTPUT;
    o.output_format |= FMT_DIRSTAT;
}

fn enablePatchOutput(o: *DiffOptions) void {
    o.output_format &= ~FMT_NO_OUTPUT;
    o.output_format |= FMT_PATCH;
}

fn bitop(o: *DiffOptions, set: u32) void {
    o.output_format &= ~FMT_NO_OUTPUT;
    o.output_format |= set;
}

fn applyOpt(o: *DiffOptions, d: *const OptDef, value: ?[]const u8, unset: bool, short: bool, st: *ParseState) void {
    _ = st;
    switch (d.id) {
        .patch, .u => bitop(o, FMT_PATCH),
        .no_patch => o.output_format = if (unset) 0 else FMT_NO_OUTPUT,
        .unified => {
            if (value) |v| {
                const r = strtolPrefix(v);
                if (r.rest.len != 0 or (v.len == 0)) {
                    if (r.rest.len != 0) optError("{s} expects a numerical value", .{"--unified"});
                }
                if (r.v < 0) optError("{s} expects a non-negative integer", .{"--unified"});
                o.context = @intCast(@min(r.v, std.math.maxInt(i32)));
            }
            enablePatchOutput(o);
        },
        .function_context => o.flags.funccontext = !unset,
        .raw => bitop(o, FMT_RAW),
        .patch_with_raw => bitop(o, FMT_PATCH | FMT_RAW),
        .patch_with_stat => bitop(o, FMT_PATCH | FMT_DIFFSTAT),
        .numstat => bitop(o, FMT_NUMSTAT),
        .shortstat => bitop(o, FMT_SHORTSTAT),
        .dirstat => parseDirstatOpt(o, value orelse ""),
        .cumulative => parseDirstatOpt(o, "cumulative"),
        .dirstat_by_file => {
            parseDirstatOpt(o, "files");
            parseDirstatOpt(o, value orelse "");
        },
        .check => o.output_format |= FMT_CHECKDIFF,
        .summary => bitop(o, FMT_SUMMARY),
        .name_only => o.output_format |= FMT_NAME,
        .name_status => o.output_format |= FMT_NAME_STATUS,
        .stat, .stat_width, .stat_name_width, .stat_graph_width, .stat_count => {
            var width = o.stat_width;
            var name_width = o.stat_name_width;
            var graph_width = o.stat_graph_width;
            var count = o.stat_count;
            if (d.id == .stat) {
                if (value) |v| {
                    var r = strtoulPrefix(v);
                    width = @truncate(r.v);
                    if (r.rest.len > 0 and r.rest[0] == ',') {
                        r = strtoulPrefix(r.rest[1..]);
                        name_width = @truncate(r.v);
                    }
                    if (r.rest.len > 0 and r.rest[0] == ',') {
                        r = strtoulPrefix(r.rest[1..]);
                        count = @truncate(r.v);
                    }
                    if (r.rest.len > 0) optError("invalid --stat value: {s}", .{v});
                }
            } else {
                const v = value.?;
                const r = strtoulPrefix(v);
                if (r.rest.len > 0) optError("{s} expects a numerical value", .{d.long});
                const n: i32 = @truncate(r.v);
                switch (d.id) {
                    .stat_width => width = n,
                    .stat_name_width => name_width = n,
                    .stat_graph_width => graph_width = n,
                    else => count = n,
                }
            }
            bitop(o, FMT_DIFFSTAT);
            o.stat_name_width = name_width;
            o.stat_graph_width = graph_width;
            o.stat_width = width;
            o.stat_count = count;
        },
        .compact_summary => {
            if (unset) {
                o.flags.stat_with_summary = false;
            } else {
                o.flags.stat_with_summary = true;
                bitop(o, FMT_DIFFSTAT);
            }
        },
        .binary => {
            enablePatchOutput(o);
            o.flags.binary = true;
        },
        .full_index => o.flags.full_index = !unset,
        .color => {
            const a = value orelse (if (unset) "never" else "always");
            const v = color.configColorBool(null, a);
            if (v == .unknown) optError("option `{s}' expects \"always\", \"auto\", or \"never\"", .{"color"});
            o.use_color = v;
        },
        .ws_error_highlight => {
            const v = value.?;
            const val = parseWsErrorHighlight(v);
            if (val < 0) {
                const n: usize = @intCast(-1 - val);
                optError("unknown value after ws-error-highlight={s}", .{v[0..@min(n, v.len)]});
            }
            o.ws_error_highlight = @intCast(val);
        },
        .z => o.line_termination = if (unset) '\n' else 0,
        .abbrev => {
            if (value) |v| {
                if (v.len == 0) optError("option `{s}' expects a numerical value", .{"abbrev"});
                const r = strtolPrefix(v);
                if (r.rest.len > 0) optError("option `{s}' expects a numerical value", .{"abbrev"});
                var n: i32 = @truncate(r.v);
                if (n != 0 and n < 4) n = 4;
                o.abbrev = n;
            } else {
                o.abbrev = if (unset) 0 else -1;
            }
        },
        .src_prefix => o.a_prefix = value.?,
        .dst_prefix => o.b_prefix = value.?,
        .line_prefix => {
            o.line_prefix = value.?;
            graph_mod.line_prefix = value.?;
        },
        .no_prefix => o.setNoprefix(),
        .default_prefix => {
            diff_src_prefix = null;
            diff_dst_prefix = null;
            o.setDefaultPrefix();
        },
        .inter_hunk_context => {
            if (unset) {
                o.interhunkcontext = 0;
            } else {
                const v = value.?;
                if (v.len == 0) optError("{s} expects a numerical value", .{optName(d, short, false)});
                if (v[0] == '-') optError("{s} expects a non-negative integer value with an optional k/m/g suffix", .{optName(d, short, false)});
                switch (config.parseSigned(v, std.math.maxInt(i32))) {
                    .ok => |n| {
                        if (n < 0) optError("{s} expects a non-negative integer value with an optional k/m/g suffix", .{optName(d, short, false)});
                        o.interhunkcontext = @intCast(n);
                    },
                    .err => |e| {
                        if (e == .out_of_range) optError("value {s} for {s} not in range [0,{d}]", .{ v, optName(d, short, false), std.math.maxInt(u32) });
                        optError("{s} expects a non-negative integer value with an optional k/m/g suffix", .{optName(d, short, false)});
                    },
                }
            }
        },
        .output_indicator_new, .output_indicator_old, .output_indicator_context => {
            const v = value.?;
            if (v.len != 1) optError("{s} expects a character, got '{s}'", .{ d.long, v });
            const idx: usize = switch (d.id) {
                .output_indicator_new => OUTPUT_INDICATOR_NEW,
                .output_indicator_old => OUTPUT_INDICATOR_OLD,
                else => OUTPUT_INDICATOR_CONTEXT,
            };
            o.output_indicators[idx] = v[0];
        },
        .break_rewrites => {
            const a = value orelse "";
            var rest: []const u8 = undefined;
            const opt1 = parseRenameScore(a, &rest);
            var opt2: u32 = 0;
            if (rest.len != 0) {
                if (rest[0] != '/') optError("{s} expects <n>/<m> form", .{d.long});
                opt2 = parseRenameScore(rest[1..], &rest);
            }
            if (rest.len != 0) optError("{s} expects <n>/<m> form", .{d.long});
            o.break_opt = @bitCast(opt1 | (opt2 << 16));
        },
        .find_renames => {
            var rest: []const u8 = undefined;
            o.rename_score = parseRenameScore(value orelse "", &rest);
            if (rest.len != 0) optError("invalid argument to {s}", .{d.long});
            o.detect_rename = DETECT_RENAME;
        },
        .irreversible_delete => o.irreversible_delete = true,
        .find_copies => {
            var rest: []const u8 = undefined;
            o.rename_score = parseRenameScore(value orelse "", &rest);
            if (rest.len != 0) optError("invalid argument to {s}", .{d.long});
            if (o.detect_rename == DETECT_COPY) {
                o.flags.find_copies_harder = true;
            } else o.detect_rename = DETECT_COPY;
        },
        .find_copies_harder => o.flags.find_copies_harder = !unset,
        .no_renames => o.detect_rename = 0,
        .rename_empty => o.flags.rename_empty = !unset,
        .follow => {
            if (unset) {
                o.flags.follow_renames = false;
                o.flags.default_follow_renames = false;
            } else o.flags.follow_renames = true;
        },
        .rename_limit => {
            if (unset) {
                o.rename_limit = 0;
            } else {
                const v = value.?;
                if (v.len == 0) optError("{s} expects a numerical value", .{optName(d, short, false)});
                switch (config.parseSigned(v, std.math.maxInt(i32))) {
                    .ok => |n| o.rename_limit = @intCast(n),
                    .err => |e| {
                        if (e == .out_of_range) optError("value {s} for {s} not in range [{d},{d}]", .{ v, optName(d, short, false), std.math.minInt(i32), std.math.maxInt(i32) });
                        optError("{s} expects an integer value with an optional k/m/g suffix", .{optName(d, short, false)});
                    },
                }
            }
        },
        .minimal, .histogram => {
            _ = o.setAlgorithm(d.long);
            o.ignore_driver_algorithm = true;
        },
        .ignore_all_space => o.xdl_opts |= xdiff.XDF_IGNORE_WHITESPACE,
        .ignore_space_change => o.xdl_opts |= xdiff.XDF_IGNORE_WHITESPACE_CHANGE,
        .ignore_space_at_eol => o.xdl_opts |= xdiff.XDF_IGNORE_WHITESPACE_AT_EOL,
        .ignore_cr_at_eol => o.xdl_opts |= xdiff.XDF_IGNORE_CR_AT_EOL,
        .ignore_blank_lines => o.xdl_opts |= xdiff.XDF_IGNORE_BLANK_LINES,
        .ignore_matching_lines => {
            if (unset) optError("{s} isn't available", .{optName(d, short, true)});
            const v = value.?;
            switch (regex.Regex.compile(v, .{ .extended = true, .newline = true })) {
                .ok => |re| o.ignore_regex.append(gpa, re) catch util.oom(),
                .err => optError("invalid regex given to -I: '{s}'", .{v}),
            }
        },
        .indent_heuristic => {
            if (unset) o.xdl_opts &= ~xdiff.XDF_INDENT_HEURISTIC else o.xdl_opts |= xdiff.XDF_INDENT_HEURISTIC;
        },
        .patience => {
            o.anchors.clearRetainingCapacity();
            o.ignore_driver_algorithm = true;
            _ = o.setAlgorithm("patience");
        },
        .diff_algorithm => {
            if (!o.setAlgorithm(value.?))
                optError("option diff-algorithm accepts \"myers\", \"minimal\", \"patience\" and \"histogram\"", .{});
            o.ignore_driver_algorithm = true;
        },
        .anchored => {
            o.xdl_opts = (o.xdl_opts & ~xdiff.XDF_DIFF_ALGORITHM_MASK) | xdiff.XDF_PATIENCE_DIFF;
            o.anchors.append(gpa, value.?) catch util.oom();
        },
        .word_diff => {
            if (value) |v| {
                if (util.eql(v, "plain")) {
                    o.word_diff = .plain;
                } else if (util.eql(v, "color")) {
                    o.use_color = .always;
                    o.word_diff = .color;
                } else if (util.eql(v, "porcelain")) {
                    o.word_diff = .porcelain;
                } else if (util.eql(v, "none")) {
                    o.word_diff = .none;
                } else optError("bad --word-diff argument: {s}", .{v});
            } else if (o.word_diff == .none) o.word_diff = .plain;
        },
        .word_diff_regex => {
            if (o.word_diff == .none) o.word_diff = .plain;
            o.word_regex = value.?;
        },
        .color_words => {
            o.use_color = .always;
            o.word_diff = .color;
            o.word_regex = value;
        },
        .color_moved => {
            if (unset) {
                o.color_moved = .no;
            } else if (value) |v| {
                o.color_moved = parseColorMoved(v) orelse optError("bad --color-moved argument: {s}", .{v});
            } else {
                if (diff_color_moved_default != .no) o.color_moved = diff_color_moved_default;
                if (o.color_moved == .no) o.color_moved = COLOR_MOVED_DEFAULT;
            }
        },
        .color_moved_ws => {
            if (unset) {
                o.color_moved_ws_handling = 0;
            } else {
                const cm = parseColorMovedWs(value.?);
                if (cm & COLOR_MOVED_WS_ERROR != 0) optError("invalid mode '{s}' in --color-moved-ws", .{value.?});
                o.color_moved_ws_handling = cm;
            }
        },
        .relative => {
            o.flags.relative_name = !unset;
            if (value) |v| o.prefix = v;
        },
        .text => o.flags.text = !unset,
        .reverse => o.flags.reverse = !unset,
        .exit_code => o.flags.exit_with_status = !unset,
        .quiet => o.flags.quick = !unset,
        .ext_diff => o.flags.allow_external = !unset,
        .textconv => {
            if (unset) {
                o.flags.allow_textconv = false;
            } else {
                o.flags.allow_textconv = true;
                o.flags.textconv_set_via_cmdline = true;
            }
        },
        .ignore_submodules => {
            o.flags.override_submodule_config = true;
            o.handleIgnoreSubmodulesArg(value orelse "all");
        },
        .submodule => {
            const v = value orelse "log";
            if (util.eql(v, "log")) {
                o.submodule_format = .log;
            } else if (util.eql(v, "short")) {
                o.submodule_format = .short;
            } else if (util.eql(v, "diff")) {
                o.submodule_format = .inline_diff;
            } else optError("failed to parse --submodule option parameter: '{s}'", .{v});
        },
        .ita_invisible => o.ita_invisible_in_index = true,
        .ita_visible => o.ita_invisible_in_index = false,
        .pickaxe_s, .pickaxe_g => {
            if (unset) optError("{s} isn't available", .{optName(d, short, true)});
            o.pickaxe = value;
            o.pickaxe_opts |= if (d.id == .pickaxe_s) PICKAXE_KIND_S else PICKAXE_KIND_G;
            if (value.?.len == 0) {
                if (d.id == .pickaxe_s) optError("-S requires a non-empty argument", .{});
                optError("-G requires a non-empty argument", .{});
            }
        },
        .pickaxe_all => o.pickaxe_opts |= PICKAXE_ALL,
        .pickaxe_regex => o.pickaxe_opts |= PICKAXE_REGEX,
        .orderfile => {
            if (unset) {
                o.orderfile = null;
            } else {
                const v = value.?;
                o.orderfile = if (v.len == 0) null else if (util.eql(v, "-")) v else prefixFilename(v);
            }
        },
        .rotate_to, .skip_to => {
            o.skip_instead_of_rotate = d.id == .skip_to;
            o.rotate_to = value.?;
        },
        .find_object => {
            const v = value.?;
            if (repo_mod.repo_ == null) optError("--find-object requires a git repository", .{});
            const oid = revparse.getOid(v) orelse optError("unable to resolve '{s}'", .{v});
            if (o.objfind == null) {
                const set = gpa.create(hash.OidSet) catch util.oom();
                set.* = .{};
                o.objfind = set;
            }
            o.pickaxe_opts |= PICKAXE_KIND_OBJFIND;
            o.flags.recursive = true;
            o.flags.tree_in_recursive = true;
            o.objfind.?.put(gpa, oid, {}) catch util.oom();
        },
        .diff_filter => {
            const v = value.?;
            for (v) |ch0| {
                var ch = ch0;
                var negate = false;
                if (ch >= 'a' and ch <= 'z') {
                    negate = true;
                    ch = ch - 'a' + 'A';
                }
                const b = filterBit(ch);
                if (b == 0) optError("unknown change class '{c}' in --diff-filter={s}", .{ ch0, v });
                if (negate) o.filter_not |= b else o.filter |= b;
            }
        },
        .max_depth => {
            const v = value.?;
            const n = switch (config.parseSigned(v, std.math.maxInt(i32))) {
                .ok => |n| n,
                .err => optError("invalid value for '{s}': '{s}'", .{ "--max-depth", v }),
            };
            o.max_depth = @intCast(n);
            o.flags.recursive = true;
            o.max_depth_valid = o.max_depth >= 0;
        },
        .output => {
            const path = prefixFilename(value.?);
            const fd = os.openFile(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o666);
            if (fd < 0) util.die("could not open '{s}' for writing: {s}", .{ path, os.lastErr() });
            const f = gpa.create(util.Out) catch util.oom();
            f.* = .{ .fd = fd };
            o.file = f;
            o.close_file = true;
            if (o.use_color != .always) o.use_color = .never;
        },
    }
}
