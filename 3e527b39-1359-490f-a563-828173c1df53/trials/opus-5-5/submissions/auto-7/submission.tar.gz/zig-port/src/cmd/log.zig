//! git log / show / whatchanged / rev-list / shortlog (port of builtin/log.c,
//! builtin/rev-list.c and builtin/shortlog.c).

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const config = @import("../config.zig");
const hash = @import("../hash.zig");
const objects = @import("../objects.zig");
const cn = @import("../commitnode.zig");
const revision = @import("../revision.zig");
const logtree = @import("../logtree.zig");
const findbisect = @import("../findbisect.zig");
const pretty = @import("../pretty.zig");
const graph_mod = @import("../graph.zig");
const color = @import("../color.zig");
const date = @import("../date.zig");
const mailmap = @import("../mailmap.zig");
const reflogwalk = @import("../reflogwalk.zig");
const commitreach = @import("../commitreach.zig");
const ident_mod = @import("../ident.zig");
const trailer = @import("../pretty_trailer.zig");
const revparse = @import("../revparse.zig");
const gpa = util.gpa;
const RevInfo = revision.RevInfo;
const Commit = cn.Commit;

const builtin_log_usage = [_][]const u8{
    "git log [<options>] [<revision-range>] [[--] <path>...]",
    "git show [<options>] <object>...",
};

// ---------------------------------------------------------------------------
// diff integration (fallback until diff.zig provides setupRevDiff)

const has_diff = @hasDecl(@This(), "diff_mod");

fn fallbackDiffParse(revs: *RevInfo, argv: []const []const u8) usize {
    const arg = argv[0];
    if (util.eql(arg, "--color")) {
        revs.use_color = true;
        return 1;
    }
    if (util.skipPrefix(arg, "--color=")) |v| {
        if (util.eql(v, "always")) {
            revs.use_color = true;
        } else if (util.eql(v, "never")) {
            revs.use_color = false;
        } else if (util.eql(v, "auto")) {
            revs.use_color = color.wantColorBool(.auto, null);
        } else util.die("option `color' expects \"always\", \"auto\", or \"never\"", .{});
        return 1;
    }
    if (util.eql(arg, "--no-color")) {
        revs.use_color = false;
        return 1;
    }
    if (util.eql(arg, "-z")) {
        revs.line_termination = 0;
        return 1;
    }
    if (util.eql(arg, "-p") or util.eql(arg, "-u") or util.eql(arg, "--patch")) {
        revs.output_format |= revision.DIFF_FORMAT_PATCH;
        return 1;
    }
    if (util.eql(arg, "--raw")) {
        revs.output_format |= revision.DIFF_FORMAT_RAW;
        return 1;
    }
    if (util.eql(arg, "--stat") or util.startsWith(arg, "--stat=")) {
        revs.output_format |= revision.DIFF_FORMAT_DIFFSTAT;
        return 1;
    }
    if (util.eql(arg, "--name-only")) {
        revs.output_format |= revision.DIFF_FORMAT_NAME;
        return 1;
    }
    if (util.eql(arg, "--name-status")) {
        revs.output_format |= revision.DIFF_FORMAT_NAME_STATUS;
        return 1;
    }
    if (util.eql(arg, "-s") or util.eql(arg, "--no-patch")) {
        revs.output_format |= revision.DIFF_FORMAT_NO_OUTPUT;
        return 1;
    }
    if (util.eql(arg, "--quiet")) {
        revs.output_format |= revision.DIFF_FORMAT_NO_OUTPUT;
        quick = true;
        return 1;
    }
    if (util.eql(arg, "-r")) {
        revs.diff_recursive = true;
        return 1;
    }
    if (util.eql(arg, "-t")) {
        revs.diff_recursive = true;
        revs.diff_tree_in_recursive = true;
        return 1;
    }
    if (util.eql(arg, "--root")) {
        revs.show_root_diff = true;
        return 1;
    }
    if (util.eql(arg, "--no-renames") or util.eql(arg, "-M") or util.eql(arg, "-C") or
        util.eql(arg, "--find-renames") or util.eql(arg, "--full-index") or util.eql(arg, "--binary") or
        util.eql(arg, "--no-prefix") or util.eql(arg, "--text") or util.eql(arg, "-a"))
        return 1;
    if (util.eql(arg, "--follow")) {
        revs.follow_renames = true;
        return 1;
    }
    return 0;
}

var quick = false;

fn setupDiff(revs: *RevInfo) void {
    revs.use_color = color.wantColorFor("color.diff");
    revs.diff_parse = fallbackDiffParse;
}

fn diffResultCode(revs: *RevInfo) u8 {
    _ = revs;
    return 0;
}

// ---------------------------------------------------------------------------
// log config

const LogConfig = struct {
    default_abbrev_commit: bool = false,
    default_show_root: bool = true,
    default_follow: bool = false,
    default_show_signature: bool = false,
    default_encode_email_headers: bool = true,
    decoration_style: i32 = 0,
    decoration_given: bool = false,
    use_mailmap_config: bool = true,
    fmt_patch_subject_prefix: []const u8 = "PATCH",
    fmt_patch_name_max: i32 = 64,
    fmt_pretty: ?[]const u8 = null,
    default_date_mode: ?[]const u8 = null,
    i_still_use_this: bool = false,
};

fn autoDecorationStyle() i32 {
    return if (os.isatty(1) or color.pagerInUse()) logtree.DECORATE_SHORT_REFS else 0;
}

fn parseDecorationStyle(value: []const u8) i32 {
    if (config.parseBool(value)) |b| return if (b) logtree.DECORATE_SHORT_REFS else 0;
    if (util.eql(value, "full")) return logtree.DECORATE_FULL_REFS;
    if (util.eql(value, "short")) return logtree.DECORATE_SHORT_REFS;
    if (util.eql(value, "auto")) return autoDecorationStyle();
    return -1;
}

fn cfgBool(v: ?[]const u8) bool {
    const s = v orelse return true;
    return config.parseBool(s) orelse false;
}

fn logConfigInit() LogConfig {
    var c = LogConfig{};
    c.decoration_style = autoDecorationStyle();
    const cfg = &repo_mod.cfg;
    for (cfg.entries.items) |e| {
        const k = e.key;
        const v = e.value;
        if (util.eql(k, "format.pretty")) {
            c.fmt_pretty = v;
        } else if (util.eql(k, "format.subjectprefix")) {
            if (v) |s| c.fmt_patch_subject_prefix = s;
        } else if (util.eql(k, "format.filenamemaxlength")) {
            if (v) |s| c.fmt_patch_name_max = @intCast(config.parseInt(s) orelse 64);
        } else if (util.eql(k, "format.encodeemailheaders")) {
            c.default_encode_email_headers = cfgBool(v);
        } else if (util.eql(k, "log.abbrevcommit")) {
            c.default_abbrev_commit = cfgBool(v);
        } else if (util.eql(k, "log.date")) {
            c.default_date_mode = v;
        } else if (util.eql(k, "log.decorate")) {
            c.decoration_style = if (v) |s| parseDecorationStyle(s) else logtree.DECORATE_SHORT_REFS;
            if (c.decoration_style < 0) c.decoration_style = 0;
        } else if (util.eql(k, "log.diffmerges")) {
            if (v) |s| {
                if (!revision.diffMergesConfig(s)) util.die("unknown value for config '{s}': {s}", .{ "log.diffmerges", s });
            } else util.die("missing value for '{s}'", .{"log.diffMerges"});
        } else if (util.eql(k, "log.showroot")) {
            c.default_show_root = cfgBool(v);
        } else if (util.eql(k, "log.follow")) {
            c.default_follow = cfgBool(v);
        } else if (util.skipPrefix(k, "color.decorate.")) |slot| {
            if (v) |s| _ = logtree.parseDecorateColorConfig(slot, s);
        } else if (util.eql(k, "log.mailmap")) {
            c.use_mailmap_config = cfgBool(v);
        } else if (util.eql(k, "log.showsignature")) {
            c.default_show_signature = cfgBool(v);
        }
    }
    return c;
}

fn cmdLogInitDefaults(revs: *RevInfo, cfg: *LogConfig) void {
    if (cfg.fmt_pretty) |f| pretty.getCommitFormat(f, revs);
    revs.verbose_header = true;
    revs.diff_recursive = true;
    revs.abbrev_commit = cfg.default_abbrev_commit;
    revs.show_root_diff = cfg.default_show_root;
    revs.subject_prefix = cfg.fmt_patch_subject_prefix;
    revs.patch_name_max = @intCast(@max(cfg.fmt_patch_name_max, 0));
    revs.show_signature = cfg.default_show_signature;
    revs.encode_email_headers = cfg.default_encode_email_headers;
    if (cfg.default_date_mode) |d| revs.date_mode = date.parseDateFormatOrDie(d);
}

var use_default_decoration_filter = true;
var decorate_refs_exclude: std.ArrayList([]const u8) = .empty;
var decorate_refs_include: std.ArrayList([]const u8) = .empty;
var opt_cfg: *LogConfig = undefined;

fn clearDecorationsCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    decorate_refs_include.clearRetainingCapacity();
    decorate_refs_exclude.clearRetainingCapacity();
    use_default_decoration_filter = false;
}

fn decorateCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        opt_cfg.decoration_style = 0;
    } else if (arg) |a| {
        opt_cfg.decoration_style = parseDecorationStyle(a);
    } else opt_cfg.decoration_style = logtree.DECORATE_SHORT_REFS;
    if (opt_cfg.decoration_style < 0) util.die("invalid --decorate option: {s}", .{arg.?});
    opt_cfg.decoration_given = true;
}

var line_range_given = false;
fn lineRangeCb(arg: ?[]const u8, unset: bool) void {
    _ = arg;
    _ = unset;
    line_range_given = true;
}

fn setDefaultDecorationFilter(f: *logtree.DecorationFilter) void {
    for (repo_mod.cfg.getAll("log.excludedecoration")) |v| f.exclude_ref_config_pattern.append(gpa, v) catch util.oom();
    if (use_default_decoration_filter) {
        if (repo_mod.cfg.get("log.initialdecorationset")) |v| {
            if (util.eql(v, "all")) use_default_decoration_filter = false;
        }
    }
    if (!use_default_decoration_filter or f.exclude_ref_pattern.items.len > 0 or
        f.include_ref_pattern.items.len > 0 or f.exclude_ref_config_pattern.items.len > 0) return;
    for (logtree.ref_namespace) |ns| {
        if (ns.deco == .none) continue;
        f.include_ref_pattern.append(gpa, ns.ref) catch util.oom();
    }
}

fn cmdLogInitFinish(args: []const []const u8, revs: *RevInfo, opt: revision.SetupOpt, cfg: *LogConfig) void {
    var quiet_v: i32 = 0;
    var source = false;
    var use_mm = cfg.use_mailmap_config;
    opt_cfg = cfg;
    const options = [_]po.Opt{
        .{ .short = 'q', .long = "quiet", .kind = .counter, .i = &quiet_v, .help = "suppress diff output" },
        po.boolean(0, "source", &source, "show source"),
        po.boolean(0, "use-mailmap", &use_mm, "use mail map file"),
        .{ .long = "i-still-use-this", .kind = .boolean, .b = &cfg.i_still_use_this, .hidden = true, .help = "<use this deprecated command>" },
        .{ .long = "mailmap", .kind = .boolean, .b = &use_mm, .help = "alias of --use-mailmap" },
        .{ .long = "clear-decorations", .kind = .callback, .cb = clearDecorationsCb, .noarg = true, .noneg = true, .help = "clear all previously-defined decoration filters" },
        po.list(0, "decorate-refs", &decorate_refs_include, "pattern", "only decorate refs that match <pattern>"),
        po.list(0, "decorate-refs-exclude", &decorate_refs_exclude, "pattern", "do not decorate refs that match <pattern>"),
        .{ .long = "decorate", .kind = .callback, .cb = decorateCb, .optarg = true, .help = "decorate options" },
        po.callback('L', "", lineRangeCb, "range:file", "trace the evolution of line range <start>,<end> or function :<funcname> in <file>"),
    };
    const rest = po.parse(args[1..], &options, &builtin_log_usage, .{ .keep_dashdash = true, .keep_unknown = true });
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, args[0]) catch util.oom();
    argv.appendSlice(gpa, rest) catch util.oom();

    if (quiet_v != 0) revs.output_format |= revision.DIFF_FORMAT_NO_OUTPUT;
    const left = revision.setupRevisions(revs, argv.items, opt);
    if (left.len > 1) util.die("unrecognized argument: {s}", .{left[1]});
    if (line_range_given) util.die("-L<range>:<file> is not supported", .{});

    const w = pretty.userformatFindRequirements(null);
    if (!revs.show_notes_given and (!revs.pretty_given or w.notes)) revs.show_notes = true;

    if (revs.diff_wants_diff or revs.follow_renames) revs.always_show_header = false;

    if (source or w.source) {
        const s = gpa.create(cn.Slab(?[]const u8)) catch util.oom();
        s.* = cn.Slab(?[]const u8).init(null);
        revs.sources = s;
    }
    if (use_mm) {
        revs.use_mailmap = true;
        revs.mailmap = mailmap.readMailmap();
    }
    if (revs.pretty_given and revs.commit_format == .raw) {
        if (!cfg.decoration_given) cfg.decoration_style = 0;
        if (!revs.abbrev_commit_given) revs.abbrev_commit = false;
    }
    if (revs.commit_format == .userformat) {
        if (!w.decorate) {
            cfg.decoration_style = 0;
        } else if (cfg.decoration_style == 0) cfg.decoration_style = logtree.DECORATE_SHORT_REFS;
    }
    if (cfg.decoration_style != 0 or revs.simplify_by_decoration) {
        const f = gpa.create(logtree.DecorationFilter) catch util.oom();
        f.* = .{ .include_ref_pattern = decorate_refs_include, .exclude_ref_pattern = decorate_refs_exclude };
        setDefaultDecorationFilter(f);
        if (cfg.decoration_style != 0) revs.show_decorations = true;
        logtree.loadRefDecorations(f, cfg.decoration_style);
    }
}

fn cmdLogInit(args: []const []const u8, revs: *RevInfo, opt: revision.SetupOpt, cfg: *LogConfig) void {
    cmdLogInitDefaults(revs, cfg);
    cmdLogInitFinish(args, revs, opt, cfg);
}

fn initRevs() RevInfo {
    var revs = RevInfo.init(repo_mod.repo().prefix);
    revs.format_hook = pretty.getCommitFormatOpt;
    revs.grep.config(&repo_mod.cfg);
    setupDiff(&revs);
    return revs;
}

fn cmdLogWalkNoFree(revs: *RevInfo) u8 {
    if (!revision.prepareRevisionWalk(revs)) util.die("revision walk setup failed", .{});
    while (revision.getRevision(revs)) |commit| {
        if (!logtree.logTreeCommit(revs, commit) and revs.max_count >= 0) revs.max_count += 1;
    }
    return diffResultCode(revs);
}

fn cmdLogWalk(revs: *RevInfo) u8 {
    const r = cmdLogWalkNoFree(revs);
    util.flushStdout();
    return r;
}

fn logSetupRevisionsTweak(revs: *RevInfo) void {
    if (log_default_follow and revs.prune_data.items.len == 1) revs.follow_renames = true;
    if (revs.first_parent_only) revision.diffMergesDefaultToFirstParent(revs);
}
var log_default_follow = false;

pub fn cmdLog(args: []const []const u8) u8 {
    var cfg = logConfigInit();
    var revs = initRevs();
    revs.always_show_header = true;
    log_default_follow = cfg.default_follow;
    cmdLogInit(args, &revs, .{ .def = "HEAD", .revarg_opt = revision.REVARG_COMMITTISH, .tweak = logSetupRevisionsTweak }, &cfg);
    return cmdLogWalk(&revs);
}

const whatchanged_hint =
    "\n" ++
    "hint: You can replace 'git whatchanged <opts>' with:\n" ++
    "hint:\tgit log <opts> --raw --no-merges\n" ++
    "hint: Or make an alias:\n" ++
    "hint:\tgit config set --global alias.whatchanged 'log --raw --no-merges'\n" ++
    "\n";

pub fn youStillUseThat(command_name: []const u8, hint: ?[]const u8) noreturn {
    util.flushStdout();
    util.eprint("'{s}' will be removed soon.\n", .{command_name});
    if (hint) |h| util.eprint("{s}", .{h});
    var enc: util.Buf = .empty;
    for (command_name) |ch| {
        if (std.ascii.isAlphanumeric(ch) or ch == '-' or ch == '_' or ch == '.' or ch == '~') {
            util.bufByte(&enc, ch);
        } else util.bufPrint(&enc, "%{X:0>2}", .{ch});
    }
    util.eprint("If you need a replacement:\n\n- Read https://git-scm.com/docs/BreakingChanges.html.\n\n- Check what others on the mailing list suggest as a replacement:\n  https://lore.kernel.org/git/?q={s}\n\n- Send an email to <git@vger.kernel.org> asking for help, only if\n  suggestions by others do not work for you.\n\n", .{enc.items});
    util.die("refusing to run without --i-still-use-this", .{});
}

pub fn cmdWhatchanged(args: []const []const u8) u8 {
    var cfg = logConfigInit();
    var revs = initRevs();
    revs.diff = true;
    revs.simplify_history = false;
    cmdLogInit(args, &revs, .{ .def = "HEAD", .revarg_opt = revision.REVARG_COMMITTISH }, &cfg);
    if (!cfg.i_still_use_this) youStillUseThat("git whatchanged", whatchanged_hint);
    if (revs.output_format == 0) revs.output_format = revision.DIFF_FORMAT_RAW;
    return cmdLogWalk(&revs);
}

fn showSetupRevisionsTweak(revs: *RevInfo) void {
    if (revs.first_parent_only) {
        revision.diffMergesDefaultToFirstParent(revs);
    } else revision.diffMergesDefaultToDenseCombined(revs);
    if (revs.output_format == 0) revs.output_format = revision.DIFF_FORMAT_PATCH;
}

fn showTagger(buf: []const u8, revs: *RevInfo) void {
    var ctx = pretty.Context{};
    ctx.fmt = revs.commit_format;
    ctx.date_mode = revs.date_mode;
    var out: util.Buf = .empty;
    pretty.ppUserInfo(&ctx, "Tagger", &out, buf, pretty.logOutputEncoding());
    util.out(out.items);
}

fn showTagObject(oid: hash.Oid, revs: *RevInfo) bool {
    const obj = repo_mod.repo().odb().read(oid) orelse {
        util.err("could not read object {s}", .{hash.hexAlloc(oid)});
        return false;
    };
    const buf = obj.data;
    var offset: usize = 0;
    while (offset < buf.len and buf[offset] != '\n') {
        var new_offset = offset + 1;
        while (new_offset < buf.len) {
            new_offset += 1;
            if (buf[new_offset - 1] == '\n') break;
        }
        if (util.skipPrefix(buf[offset..], "tagger ")) |id| showTagger(id, revs);
        offset = new_offset;
    }
    if (offset < buf.len) util.out(buf[offset..]);
    return true;
}

pub fn cmdShow(args: []const []const u8) u8 {
    var cfg = logConfigInit();
    var revs = initRevs();
    revs.diff = true;
    revs.always_show_header = true;
    revs.no_walk = true;
    cmdLogInit(args, &revs, .{ .def = "HEAD", .tweak = showSetupRevisionsTweak }, &cfg);
    if (!revs.no_walk) return cmdLogWalk(&revs);

    var ret: u8 = 0;
    const pending = revs.pending.items;
    revs.pending = .empty;
    var i: usize = 0;
    var cur: ?*cn.Obj = null;
    while (i < pending.len and ret == 0) {
        const o = cur orelse pending[i].item;
        const name = pending[i].name;
        cur = null;
        switch (o.typ) {
            .blob => {
                const obj = repo_mod.repo().odb().read(o.oid) orelse util.die("unable to read {s}", .{hash.hexAlloc(o.oid)});
                util.out(obj.data);
            },
            .tag => {
                const obj = repo_mod.repo().odb().read(o.oid) orelse {
                    util.err("could not read object {s}", .{hash.hexAlloc(o.oid)});
                    ret = 1;
                    break;
                };
                const t = objects.parseTag(obj.data) orelse {
                    util.err("could not read object {s}", .{hash.hexAlloc(o.oid)});
                    ret = 1;
                    break;
                };
                if (revs.shown_one) util.out("\n");
                util.outf("{s}tag {s}{s}\n", .{ logtree.diffColor(&revs, revs.use_color, "commit"), t.tag, logtree.diffColor(&revs, revs.use_color, "reset") });
                if (!showTagObject(o.oid, &revs)) {
                    ret = 1;
                    break;
                }
                revs.shown_one = true;
                cur = cn.parseObject(t.object) orelse {
                    util.err("could not read object {s}", .{hash.hexAlloc(t.object)});
                    ret = 1;
                    break;
                };
                continue;
            },
            .tree => {
                if (revs.shown_one) util.out("\n");
                util.outf("{s}tree {s}{s}\n\n", .{ logtree.diffColor(&revs, revs.use_color, "commit"), name, logtree.diffColor(&revs, revs.use_color, "reset") });
                if (objects.readTree(o.oid)) |entries| {
                    for (entries) |e| util.outf("{s}{s}\n", .{ e.name, if (e.mode & 0o170000 == 0o040000) "/" else "" });
                }
                revs.shown_one = true;
            },
            .commit => {
                revs.pending = .empty;
                revs.pending.append(gpa, .{ .item = o, .name = name }) catch util.oom();
                ret = cmdLogWalkNoFree(&revs);
            },
            else => {
                util.err("unknown type: {d}", .{@intFromEnum(o.typ)});
                ret = 1;
            },
        }
        i += 1;
    }
    util.flushStdout();
    return ret;
}

/// git log -g --abbrev-commit --pretty=oneline (git reflog show)
pub fn cmdLogReflog(args: []const []const u8) u8 {
    var cfg = logConfigInit();
    var revs = initRevs();
    revs.reflog_info = reflogwalk.init();
    revs.verbose_header = true;
    cmdLogInitDefaults(&revs, &cfg);
    revs.abbrev_commit = true;
    revs.commit_format = .oneline;
    revs.use_terminator = true;
    revs.always_show_header = true;
    cmdLogInitFinish(args, &revs, .{ .def = "HEAD" }, &cfg);
    return cmdLogWalk(&revs);
}

// ---------------------------------------------------------------------------
// rev-list

const rev_list_usage =
    "git rev-list [<options>] <commit>... [--] [<path>...]\n" ++
    "\n" ++
    "  limiting output:\n" ++
    "    --max-count=<n>\n" ++
    "    --max-age=<epoch>\n" ++
    "    --min-age=<epoch>\n" ++
    "    --sparse\n" ++
    "    --no-merges\n" ++
    "    --min-parents=<n>\n" ++
    "    --no-min-parents\n" ++
    "    --max-parents=<n>\n" ++
    "    --no-max-parents\n" ++
    "    --remove-empty\n" ++
    "    --all\n" ++
    "    --branches\n" ++
    "    --tags\n" ++
    "    --remotes\n" ++
    "    --stdin\n" ++
    "    --exclude-hidden=[fetch|receive|uploadpack]\n" ++
    "    --quiet\n" ++
    "  ordering output:\n" ++
    "    --topo-order\n" ++
    "    --date-order\n" ++
    "    --reverse\n" ++
    "  formatting output:\n" ++
    "    --parents\n" ++
    "    --children\n" ++
    "    --objects | --objects-edge\n" ++
    "    --disk-usage[=human]\n" ++
    "    --unpacked\n" ++
    "    --header | --pretty\n" ++
    "    --[no-]object-names\n" ++
    "    --abbrev=<n> | --no-abbrev\n" ++
    "    --abbrev-commit\n" ++
    "    --left-right\n" ++
    "    --count\n" ++
    "    -z\n" ++
    "  special purpose:\n" ++
    "    --bisect\n" ++
    "    --bisect-vars\n" ++
    "    --bisect-all";

fn revListUsage() noreturn {
    util.flushStdout();
    util.eprint("usage: {s}\n", .{rev_list_usage});
    os.exit(129);
}

const RevListInfo = struct {
    revs: *RevInfo,
    quiet: bool = false,
    show_timestamp: bool = false,
    hdr_termination: u8 = 0,
    header_prefix: ?[]const u8 = null,
    include_header: bool = true,
    line_term: u8 = '\n',
    info_term: u8 = ' ',
    show_object_names: bool = true,
    disk_usage: bool = false,
    total_disk_usage: u64 = 0,
};

fn objectDiskUsage(oid: hash.Oid) u64 {
    const path = repo_mod.repo().gitPath(util.fmt("objects/{s}/{s}", .{ hash.hexAlloc(oid)[0..2], hash.hexAlloc(oid)[2..] }));
    if (os.statPath(path)) |st| return @intCast(st.size);
    return 0;
}

fn revListShowCommit(commit: *Commit, data: ?*anyopaque) void {
    const info: *RevListInfo = @ptrCast(@alignCast(data.?));
    const revs = info.revs;
    if (info.disk_usage) info.total_disk_usage += objectDiskUsage(commit.obj.oid);
    if (info.quiet) return;
    graph_mod.showCommit(revs.graph);
    if (revs.count) {
        if (commit.obj.flags & cn.PATCHSAME != 0) {
            revs.count_same += 1;
        } else if (commit.obj.flags & cn.SYMMETRIC_LEFT != 0) {
            revs.count_left += 1;
        } else revs.count_right += 1;
        return;
    }
    if (info.show_timestamp) util.outf("{d} ", .{commit.date});
    if (info.header_prefix) |hp| util.out(hp);
    if (info.include_header) {
        if (revs.graph == null and info.line_term != 0) util.out(revision.getRevisionMark(revs, commit));
        if (revs.abbrev_commit and revs.abbrev != 0) {
            util.out(revparse.abbrev(commit.obj.oid, revs.abbrev));
        } else util.out(&commit.hex());
        if (info.line_term == 0 and commit.obj.flags & cn.BOUNDARY != 0)
            util.outf("{c}boundary=yes", .{info.info_term});
    }
    if (revs.print_parents) {
        var p = commit.parents;
        while (p) |x| : (p = x.next) util.outf(" {s}", .{&x.item.hex()});
    }
    if (revs.children_enabled) {
        var p = revision.getChildren(revs, commit);
        while (p) |x| : (p = x.next) util.outf(" {s}", .{&x.item.hex()});
    }
    logtree.showDecorations(revs, commit);
    if (revs.commit_format == .oneline) {
        util.out(" ");
    } else if (info.include_header) util.out(&[_]u8{info.line_term});

    if (revs.verbose_header) {
        var buf: util.Buf = .empty;
        var ctx = pretty.Context{};
        ctx.abbrev = revs.abbrev;
        ctx.date_mode = revs.date_mode;
        ctx.date_mode_explicit = revs.date_mode_explicit;
        ctx.fmt = revs.commit_format;
        ctx.output_encoding = pretty.logOutputEncoding();
        ctx.color = revs.use_color;
        ctx.rev = revs;
        pretty.prettyPrintCommit(&ctx, commit, &buf);
        if (buf.items.len > 0) {
            if (revs.commit_format != .oneline) graph_mod.showOneline(revs.graph);
            graph_mod.showCommitMsg(revs.graph, buf.items);
            if (buf.items[buf.items.len - 1] == '\n') graph_mod.showPadding(revs.graph);
            util.out(&[_]u8{info.hdr_termination});
        } else {
            if (graph_mod.showRemainder(revs.graph)) util.out("\n");
            if (revs.commit_format == .oneline) util.out("\n");
        }
    } else {
        if (graph_mod.showRemainder(revs.graph)) util.out("\n");
    }
}

fn revListShowObject(obj: *cn.Obj, name: []const u8, data: ?*anyopaque) void {
    const info: *RevListInfo = @ptrCast(@alignCast(data.?));
    const revs = info.revs;
    if (!repo_mod.repo().odb().has(obj.oid)) {
        util.die("missing {s} object '{s}'", .{ @tagName(obj.typ), hash.hexAlloc(obj.oid) });
    }
    if (info.disk_usage) info.total_disk_usage += objectDiskUsage(obj.oid);
    if (info.quiet) return;
    if (revs.count) {
        revs.count_right += 1;
        return;
    }
    util.out(&hash.hex(obj.oid));
    if (info.show_object_names) {
        if (info.line_term != 0) {
            util.out(&[_]u8{info.info_term});
            const nl = std.mem.indexOfScalar(u8, name, '\n') orelse name.len;
            util.out(name[0..nl]);
        } else if (name.len > 0) {
            util.outf("{c}path={s}", .{ info.info_term, name });
        }
    }
    util.out(&[_]u8{info.line_term});
}

fn revListShowEdge(commit: *Commit) void {
    util.outf("-{s}\n", .{&commit.hex()});
}

fn humaniseBytes(b: *util.Buf, bytes: u64) void {
    if (bytes > 1 << 30) {
        const x = bytes + 5368709;
        util.bufPrint(b, "{d}.{d:0>2} GiB", .{ x >> 30, (x & ((1 << 30) - 1)) / 10737419 });
    } else if (bytes > 1 << 20) {
        const x = bytes + 5243;
        util.bufPrint(b, "{d}.{d:0>2} MiB", .{ x >> 20, ((x & ((1 << 20) - 1)) * 100) >> 20 });
    } else if (bytes > 1 << 10) {
        const x = bytes + 5;
        util.bufPrint(b, "{d}.{d:0>2} KiB", .{ x >> 10, ((x & ((1 << 10) - 1)) * 100) >> 10 });
    } else {
        util.bufPrint(b, "{d} {s}", .{ bytes, if (bytes == 1) "byte" else "bytes" });
    }
}

fn prepareMaximalIndependent(revs: *RevInfo) void {
    if (!revs.maximal_only) return;
    var c = revs.commits;
    while (c) |x| : (c = x.next) if (x.item.obj.flags & cn.UNINTERESTING != 0) return;
    if (revs.limited or revs.topo_order or revs.first_parent_only or revs.reverse or revs.max_count >= 0 or
        revs.skip_count >= 0 or revs.min_age != revision.UNSET_TIME or revs.max_age != revision.UNSET_TIME or
        revs.min_parents > 0 or revs.max_parents >= 0 or revs.prune_data.items.len > 0 or revs.count or
        revs.left_right or revs.boundary != 0 or revs.tag_objects or revs.tree_objects or revs.blob_objects or
        revs.reflog_info != null or revs.diff or !revs.grep.isEmpty() or revs.verbose_header or
        revs.print_parents or revs.edge_hint or revs.unpacked or revs.line_level_traverse) return;
    revs.commits = commitreach.reduceHeads(revs.commits);
    revs.no_walk = true;
}

pub fn cmdRevList(args: []const []const u8) u8 {
    if (args.len == 2 and util.eql(args[1], "-h")) {
        util.outf("usage: {s}\n", .{rev_list_usage});
        util.flushStdout();
        return 0;
    }
    var revs = initRevs();
    revs.abbrev = revparse.defaultAbbrev();
    revs.commit_format = .unspecified;
    var info = RevListInfo{ .revs = &revs };
    for (args[1..]) |a| {
        if (util.eql(a, "-z")) {
            info.line_term = 0;
            info.info_term = 0;
        }
    }
    const left = revision.setupRevisions(&revs, args, .{});
    var bisect_list = revs.bisect;
    var bisect_find_all = false;
    var bisect_show_vars = false;
    var human = false;
    if (quick) info.quiet = true;
    for (left[1..]) |arg0| {
        var arg = arg0;
        if (util.eql(arg, "--header")) {
            revs.verbose_header = true;
        } else if (util.eql(arg, "--timestamp")) {
            info.show_timestamp = true;
        } else if (util.eql(arg, "--bisect")) {
            bisect_list = true;
        } else if (util.eql(arg, "--bisect-all")) {
            bisect_list = true;
            bisect_find_all = true;
            revs.show_decorations = true;
        } else if (util.eql(arg, "--bisect-vars")) {
            bisect_list = true;
            bisect_show_vars = true;
        } else if (util.eql(arg, "--use-bitmap-index") or util.eql(arg, "--filter-provided-objects") or
            util.eql(arg, "--filter-print-omitted") or util.eql(arg, "--exclude-promisor-objects") or
            util.eql(arg, "--missing-only") or util.startsWith(arg, "--progress=") or util.startsWith(arg, "--missing="))
        {
            continue;
        } else if (util.eql(arg, "--no-object-names")) {
            info.show_object_names = false;
        } else if (util.eql(arg, "--object-names")) {
            info.show_object_names = true;
        } else if (util.eql(arg, "--commit-header")) {
            info.include_header = true;
        } else if (util.eql(arg, "--no-commit-header")) {
            info.include_header = false;
        } else if (util.skipPrefix(arg, "--disk-usage")) |rest| {
            arg = rest;
            if (arg.len > 0 and arg[0] == '=') {
                if (util.eql(arg[1..], "human")) {
                    human = true;
                } else util.die("invalid value for '{s}': '{s}', the only allowed format is '{s}'", .{ "--disk-usage=<format>", arg[1..], "human" });
            } else if (arg.len > 0) revListUsage();
            info.disk_usage = true;
            info.quiet = true;
        } else revListUsage();
    }
    if (info.line_term == 0) {
        if (revs.graph != null or revs.verbose_header or info.disk_usage or info.show_timestamp or
            info.header_prefix != null or bisect_list or revs.edge_hint or revs.left_right or revs.cherry_mark)
            util.die("-z option used with unsupported option", .{});
    }
    if (revs.commit_format != .userformat) info.include_header = true;
    if (revs.commit_format != .unspecified) {
        info.hdr_termination = '\n';
        if (revs.commit_format == .oneline or !info.include_header) {
            info.header_prefix = "";
        } else info.header_prefix = "commit ";
    } else if (revs.verbose_header) revs.commit_format = .raw;

    if ((revs.commits == null and reflogwalk.walkEmpty(revs.reflog_info) and
        (!(revs.tag_objects or revs.tree_objects or revs.blob_objects) and revs.pending.items.len == 0) and
        !revs.rev_input_given and revs.read_from_stdin == 0) or revs.diff)
        revListUsage();
    if (revs.show_notes) util.die("rev-list does not support display of notes", .{});
    if (revs.count and (revs.tag_objects or revs.tree_objects or revs.blob_objects) and (revs.left_right or revs.cherry_mark))
        util.die("marked counting and '{s}' cannot be used together", .{"--objects"});
    if (bisect_list) revs.limited = true;

    if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
    prepareMaximalIndependent(&revs);
    if (revs.tree_objects) revision.markEdgesUninteresting(&revs, revListShowEdge);
    if (bisect_list) {
        var reaches: i32 = 0;
        var all: i32 = 0;
        var bflags: u32 = 0;
        if (bisect_find_all) bflags |= findbisect.FIND_BISECTION_ALL;
        if (revs.first_parent_only) bflags |= findbisect.FIND_BISECTION_FIRST_PARENT_ONLY;
        findbisect.findBisection(&revs.commits, &reaches, &all, bflags);
        if (bisect_show_vars) {
            if (revs.commits == null) return 1;
            const hx = if (revs.commits) |cl| hash.hexAlloc(cl.item.obj.oid) else "";
            if (bisect_find_all) {
                revision.traverseCommitList(&revs, revListShowCommit, revListShowObject, &info);
                util.out("------\n");
            }
            var cnt = all - reaches;
            if (cnt < reaches) cnt = reaches;
            util.outf("bisect_rev='{s}'\nbisect_nr={d}\nbisect_good={d}\nbisect_bad={d}\nbisect_all={d}\nbisect_steps={d}\n", .{ hx, cnt - 1, all - reaches - 1, reaches - 1, all, findbisect.estimateBisectSteps(all) });
            return 0;
        }
    }
    revision.traverseCommitList(&revs, revListShowCommit, revListShowObject, &info);

    if (revs.count) {
        if (revs.left_right and revs.cherry_mark) {
            util.outf("{d}\t{d}\t{d}\n", .{ revs.count_left, revs.count_right, revs.count_same });
        } else if (revs.left_right) {
            util.outf("{d}\t{d}\n", .{ revs.count_left, revs.count_right });
        } else if (revs.cherry_mark) {
            util.outf("{d}\t{d}\n", .{ revs.count_left + revs.count_right, revs.count_same });
        } else util.outf("{d}\n", .{revs.count_left + revs.count_right});
    }
    if (info.disk_usage) {
        var sb: util.Buf = .empty;
        if (human) humaniseBytes(&sb, info.total_disk_usage) else util.bufPrint(&sb, "{d}", .{info.total_disk_usage});
        util.outf("{s}\n", .{sb.items});
    }
    util.flushStdout();
    return 0;
}

// ---------------------------------------------------------------------------
// shortlog

const shortlog_usage = [_][]const u8{
    "git shortlog [<options>] [<revision-range>] [[--] <path>...]",
    "git log --pretty=short | git shortlog [<options>]",
};

const GROUP_AUTHOR: i32 = 1 << 0;
const GROUP_COMMITTER: i32 = 1 << 1;
const GROUP_TRAILER: i32 = 1 << 2;
const GROUP_FORMAT: i32 = 1 << 3;

const ShortlogEntry = struct {
    name: []const u8,
    count: usize = 0,
    onelines: std.ArrayList([]const u8) = .empty,
};

const Shortlog = struct {
    list: std.ArrayList(*ShortlogEntry) = .empty,
    index: std.StringHashMapUnmanaged(*ShortlogEntry) = .empty,
    summary: bool = false,
    email: bool = false,
    sort_by_number: bool = false,
    wrap_lines: bool = false,
    wrap: i64 = 76,
    in1: i64 = 6,
    in2: i64 = 9,
    user_format: bool = false,
    abbrev: usize = 0,
    date_mode: date.DateMode = .{},
    groups: i32 = 0,
    trailers: std.ArrayList([]const u8) = .empty,
    format: std.ArrayList([]const u8) = .empty,
    mailmap: *mailmap.Map = undefined,
};

var sl: Shortlog = .{};

fn insertOneRecord(log: *Shortlog, ident: []const u8, oneline0: []const u8) void {
    const gop = log.index.getOrPut(gpa, ident) catch util.oom();
    if (!gop.found_existing) {
        const e = gpa.create(ShortlogEntry) catch util.oom();
        e.* = .{ .name = util.dupe(ident) };
        gop.key_ptr.* = e.name;
        gop.value_ptr.* = e;
        log.list.append(gpa, e) catch util.oom();
    }
    const item = gop.value_ptr.*;
    if (log.summary) {
        item.count += 1;
        return;
    }
    var oneline = oneline0;
    while (oneline.len > 0 and std.ascii.isWhitespace(oneline[0])) oneline = oneline[1..];
    const eol = std.mem.indexOfScalar(u8, oneline, '\n') orelse oneline.len;
    if (util.startsWith(oneline, "[PATCH")) {
        if (std.mem.indexOfScalar(u8, oneline, ']')) |eob| {
            if (eob < eol) oneline = oneline[eob + 1 ..];
        }
    }
    while (oneline.len > 0 and std.ascii.isWhitespace(oneline[0]) and oneline[0] != '\n') oneline = oneline[1..];
    var subject: util.Buf = .empty;
    _ = pretty.formatSubject(&subject, oneline, 0, " ");
    item.onelines.append(gpa, subject.items) catch util.oom();
}

fn parseIdent(log: *Shortlog, out: *util.Buf, in: []const u8) bool {
    const sp = ident_mod.split(in) orelse return false;
    var name = sp.name;
    var mail = sp.email;
    if (log.mailmap.mapUser(name, mail)) |m| {
        name = m.name;
        mail = m.email;
    }
    util.bufAppend(out, name);
    if (log.email) util.bufPrint(out, " <{s}>", .{mail});
    return true;
}

fn needsDedup(log: *const Shortlog) bool {
    const g = log.groups;
    return (g & (g - 1)) != 0 or log.format.items.len > 1 or log.trailers.items.len > 0;
}

fn readFromStdin(log: *Shortlog) void {
    const g = log.groups;
    if ((g & (g - 1)) != 0) util.die("using multiple --group options with stdin is not supported", .{});
    var match: [2][]const u8 = undefined;
    if (g == GROUP_AUTHOR) {
        match = .{ "Author: ", "author " };
    } else if (g == GROUP_COMMITTER) {
        match = .{ "Commit: ", "committer " };
    } else if (g == GROUP_TRAILER) {
        util.die("using {s} with stdin is not supported", .{"--group=trailer"});
    } else util.die("using {s} with stdin is not supported", .{"--group=format"});
    const data = os.readAllFd(0) catch "";
    var lines: std.ArrayList([]const u8) = .empty;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |l| lines.append(gpa, l) catch util.oom();
    if (data.len > 0 and data[data.len - 1] == '\n') _ = lines.pop();
    var i: usize = 0;
    while (i < lines.items.len) {
        const line = lines.items[i];
        i += 1;
        const v = util.skipPrefix(line, match[0]) orelse util.skipPrefix(line, match[1]) orelse continue;
        var oneline: []const u8 = "";
        while (i < lines.items.len) {
            oneline = lines.items[i];
            i += 1;
            if (oneline.len == 0) break;
        }
        while (i < lines.items.len) {
            oneline = lines.items[i];
            i += 1;
            if (oneline.len != 0) break;
        }
        var mapped: util.Buf = .empty;
        if (!parseIdent(log, &mapped, v)) continue;
        insertOneRecord(log, mapped.items, oneline);
    }
}

fn hasTrailerKey(log: *const Shortlog, key: []const u8) bool {
    for (log.trailers.items) |t| if (std.ascii.eqlIgnoreCase(t, key)) return true;
    return false;
}

fn shortlogAddCommit(log: *Shortlog, commit: *Commit) void {
    var oneline: util.Buf = .empty;
    var dups: std.StringHashMapUnmanaged(void) = .empty;
    var ctx = pretty.Context{};
    ctx.fmt = .userformat;
    ctx.abbrev = log.abbrev;
    ctx.date_mode = log.date_mode;
    ctx.output_encoding = pretty.logOutputEncoding();
    if (!log.summary) {
        if (log.user_format) {
            pretty.prettyPrintCommit(&ctx, commit, &oneline);
        } else pretty.formatCommitMessage(commit, "%s", &oneline, &ctx);
    }
    const oneline_str: []const u8 = if (oneline.items.len > 0) oneline.items else "<none>";

    if (log.trailers.items.len > 0) {
        const msg = pretty.logmsgReencode(commit, pretty.logOutputEncoding()).msg;
        if (std.mem.indexOf(u8, msg, "\n\n")) |bpos| {
            const body = msg[bpos..];
            var items: std.ArrayList(trailer.Item) = .empty;
            const topts = trailer.Options{ .no_divider = true, .only_trailers = true, .unfold = true };
            _ = trailer.parseTrailers(&topts, body, &items);
            for (items.items) |it| {
                const key = it.token orelse continue;
                if (!hasTrailerKey(log, key)) continue;
                var idb: util.Buf = .empty;
                var value = it.value;
                if (parseIdent(log, &idb, value)) value = idb.items;
                const gop = dups.getOrPut(gpa, value) catch util.oom();
                if (gop.found_existing) continue;
                insertOneRecord(log, value, oneline_str);
            }
        }
    }
    for (log.format.items) |f| {
        var buf: util.Buf = .empty;
        pretty.formatCommitMessage(commit, f, &buf, &ctx);
        if (!needsDedup(log)) {
            insertOneRecord(log, buf.items, oneline_str);
        } else {
            const gop = dups.getOrPut(gpa, buf.items) catch util.oom();
            if (!gop.found_existing) insertOneRecord(log, buf.items, oneline_str);
        }
    }
}

fn parseUint(arg: *[]const u8, comma: u8, defval: i64) i64 {
    var i: usize = 0;
    const s = arg.*;
    while (i < s.len and std.ascii.isDigit(s[i])) i += 1;
    if (i < s.len and s[i] != comma) return -1;
    const v: i64 = if (i == 0) defval else (std.fmt.parseInt(i64, s[0..i], 10) catch return -1);
    if (v > std.math.maxInt(i32)) return -1;
    arg.* = if (i < s.len) s[i + 1 ..] else s[i..];
    return v;
}

var wrap_error = false;
fn wrapCb(arg: ?[]const u8, unset: bool) void {
    sl.wrap_lines = !unset;
    if (unset) return;
    var a = arg orelse {
        sl.wrap = 76;
        sl.in1 = 6;
        sl.in2 = 9;
        return;
    };
    sl.wrap = parseUint(&a, ',', 76);
    sl.in1 = parseUint(&a, ',', 6);
    sl.in2 = parseUint(&a, 0, 9);
    if (sl.wrap < 0 or sl.in1 < 0 or sl.in2 < 0 or
        (sl.wrap != 0 and ((sl.in1 != 0 and sl.wrap <= sl.in1) or (sl.in2 != 0 and sl.wrap <= sl.in2))))
    {
        util.err("-w[<width>[,<indent1>[,<indent2>]]]", .{});
        wrap_error = true;
    }
}

var group_error = false;
fn groupCb(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        sl.groups = 0;
        sl.trailers = .empty;
        sl.format = .empty;
        return;
    }
    const a = arg.?;
    if (std.ascii.eqlIgnoreCase(a, "author")) {
        sl.groups |= GROUP_AUTHOR;
    } else if (std.ascii.eqlIgnoreCase(a, "committer")) {
        sl.groups |= GROUP_COMMITTER;
    } else if (util.skipPrefix(a, "trailer:")) |f| {
        sl.groups |= GROUP_TRAILER;
        sl.trailers.append(gpa, f) catch util.oom();
    } else if (util.skipPrefix(a, "format:")) |f| {
        sl.groups |= GROUP_FORMAT;
        sl.format.append(gpa, f) catch util.oom();
    } else if (std.mem.indexOfScalar(u8, a, '%') != null) {
        sl.groups |= GROUP_FORMAT;
        sl.format.append(gpa, a) catch util.oom();
    } else {
        util.err("unknown group type: {s}", .{a});
        group_error = true;
    }
}

fn entryLess(_: void, a: *ShortlogEntry, b: *ShortlogEntry) bool {
    return std.mem.order(u8, a.name, b.name) == .lt;
}
fn countLess(_: void, a: *ShortlogEntry, b: *ShortlogEntry) bool {
    const ca = if (sl.summary) a.count else a.onelines.items.len;
    const cb = if (sl.summary) b.count else b.onelines.items.len;
    return ca > cb;
}

fn shortlogOutput(log: *Shortlog) void {
    std.mem.sort(*ShortlogEntry, log.list.items, {}, entryLess);
    if (log.sort_by_number) std.mem.sort(*ShortlogEntry, log.list.items, {}, countLess);
    for (log.list.items) |item| {
        if (log.summary) {
            util.outf("{d: >6}\t{s}\n", .{ item.count, item.name });
        } else {
            util.outf("{s} ({d}):\n", .{ item.name, item.onelines.items.len });
            var j = item.onelines.items.len;
            while (j >= 1) : (j -= 1) {
                const msg = item.onelines.items[j - 1];
                if (log.wrap_lines) {
                    var sb: util.Buf = .empty;
                    pretty.addWrappedText(&sb, msg, log.in1, log.in2, log.wrap);
                    util.bufByte(&sb, '\n');
                    util.out(sb.items);
                } else util.outf("      {s}\n", .{msg});
            }
            util.out("\n");
        }
    }
}

pub fn cmdShortlog(args: []const []const u8) u8 {
    const nongit = repo_mod.repo_ == null;
    sl = .{};
    sl.mailmap = mailmap.readMailmap();
    var committer_bits: i32 = 0;
    const options = [_]po.Opt{
        po.bit('c', "committer", &committer_bits, GROUP_COMMITTER, "group by committer rather than author"),
        po.boolean('n', "numbered", &sl.sort_by_number, "sort output according to the number of commits per author"),
        po.boolean('s', "summary", &sl.summary, "suppress commit descriptions, only provides commit count"),
        po.boolean('e', "email", &sl.email, "show the email address of each author"),
        .{ .short = 'w', .kind = .callback, .cb = wrapCb, .optarg = true, .argh = "<w>[,<i1>[,<i2>]]", .literal_argh = true, .help = "linewrap output" },
        po.callback(0, "group", groupCb, "field", "group by field"),
    };
    var revs = if (nongit) RevInfo{} else initRevs();
    // parse shortlog options mixed with revision options
    const rest = po.parse(args[1..], &options, &shortlog_usage, .{ .keep_dashdash = true, .keep_unknown = true });
    if (wrap_error or group_error) os.exit(129);
    sl.groups |= committer_bits;
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, args[0]) catch util.oom();
    argv.appendSlice(gpa, rest) catch util.oom();
    if (nongit) {
        if (argv.items.len > 1) {
            util.err("too many arguments given outside repository", .{});
            po.usageWithOptions(&shortlog_usage, &options);
        }
    } else {
        const left = revision.setupRevisions(&revs, argv.items, .{});
        if (left.len != 1) {
            util.err("unrecognized argument: {s}", .{left[1]});
            po.usageWithOptions(&shortlog_usage, &options);
        }
    }
    sl.user_format = revs.commit_format == .userformat;
    sl.abbrev = revs.abbrev;
    sl.date_mode = revs.date_mode;
    if (sl.groups == 0) sl.groups = GROUP_AUTHOR;
    if (sl.groups & GROUP_AUTHOR != 0) sl.format.append(gpa, if (sl.email) "%aN <%aE>" else "%aN") catch util.oom();
    if (sl.groups & GROUP_COMMITTER != 0) sl.format.append(gpa, if (sl.email) "%cN <%cE>" else "%cN") catch util.oom();

    if (!nongit and revs.pending.items.len == 0 and os.isatty(0)) revision.addHeadToPending(&revs);
    if (revs.pending.items.len == 0) {
        if (os.isatty(0)) util.eprint("(reading log message from standard input)\n", .{});
        readFromStdin(&sl);
    } else {
        if (!revision.prepareRevisionWalk(&revs)) util.die("revision walk setup failed", .{});
        while (revision.getRevision(&revs)) |c| shortlogAddCommit(&sl, c);
    }
    shortlogOutput(&sl);
    util.flushStdout();
    return 0;
}
