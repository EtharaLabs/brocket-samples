//! Port of apply.c: parse and apply patches (git apply / git am backend).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const odb_mod = @import("odb.zig");
const diff = @import("diff.zig");
const zlib = @import("zlib.zig");
const wildmatch = @import("wildmatch.zig");
const xdiff = @import("xdiff.zig");
const entry_mod = @import("entry.zig");
const convert = @import("convert.zig");
const pathspec = @import("pathspec.zig");
const revparse = @import("revparse.zig");

const gpa = util.gpa;
const Buf = util.Buf;
const Oid = hash.Oid;

pub const WsErrorAction = enum { nowarn, warn, die, correct };
pub const WsIgnore = enum { none, change };

pub const VERBOSITY_SILENT: i32 = -1;
pub const VERBOSITY_NORMAL: i32 = 0;
pub const VERBOSITY_VERBOSE: i32 = 1;

pub const APPLY_OPT_INACCURATE_EOF: u32 = 1 << 0;
pub const APPLY_OPT_RECOUNT: u32 = 1 << 1;

const MAX_APPLY_SIZE: usize = 1024 * 1024 * 1023;

const BINARY_DELTA_DEFLATED: i64 = 1;
const BINARY_LITERAL_DEFLATED: i64 = 2;

pub const Fragment = struct {
    leading: i64 = 0, // also binary_patch_method
    trailing: i64 = 0,
    oldpos: i64 = 0,
    oldlines: i64 = 0,
    newpos: i64 = 0,
    newlines: i64 = 0,
    patch: []const u8 = "",
    rejected: bool = false,
    linenr: i32 = 0,
    next: ?*Fragment = null,
};

pub const Patch = struct {
    new_name: ?[]const u8 = null,
    old_name: ?[]const u8 = null,
    def_name: ?[]const u8 = null,
    old_mode: u32 = 0,
    new_mode: u32 = 0,
    is_new: i32 = 0,
    is_delete: i32 = 0,
    rejected: bool = false,
    ws_rule: u32 = 0,
    lines_added: i32 = 0,
    lines_deleted: i32 = 0,
    score: i32 = 0,
    extension_linenr: i32 = 0,
    is_toplevel_relative: bool = false,
    inaccurate_eof: bool = false,
    is_binary: bool = false,
    is_copy: bool = false,
    is_rename: bool = false,
    recount: bool = false,
    conflicted_threeway: bool = false,
    direct_to_threeway: bool = false,
    crlf_in_old: bool = false,
    fragments: ?*Fragment = null,
    result: []const u8 = "",
    old_oid_prefix: []const u8 = "",
    new_oid_prefix: []const u8 = "",
    next: ?*Patch = null,
    threeway_stage: [3]Oid = .{ hash.zero, hash.zero, hash.zero },
};

const NameLimit = struct { pattern: []const u8, include: bool };

const FnItem = union(enum) {
    patch: *Patch,
    to_be_deleted,
    was_deleted,
};

pub const State = struct {
    prefix: ?[]const u8 = null,

    apply: bool = true,
    cached: bool = false,
    check: bool = false,
    check_index: bool = false,
    update_index: bool = false,
    ita_only: bool = false,

    diffstat: bool = false,
    numstat: bool = false,
    summary: bool = false,

    allow_overlap: bool = false,
    apply_in_reverse: bool = false,
    apply_with_reject: bool = false,
    no_add: bool = false,
    threeway: bool = false,
    unidiff_zero: bool = false,
    unsafe_paths: bool = false,
    allow_empty: bool = false,

    index_file: ?[]const u8 = null,
    apply_verbosity: i32 = VERBOSITY_NORMAL,
    merge_variant: xdiff.MergeFavor = .none,
    fake_ancestor: ?[]const u8 = null,
    patch_input_file: []const u8 = "",
    line_termination: u8 = '\n',
    root: Buf = .empty,
    p_value: i32 = 1,
    p_value_known: bool = false,
    p_context: u32 = std.math.maxInt(u32),

    limit_by_name: std.ArrayList(NameLimit) = .empty,
    has_include: bool = false,

    linenr: i32 = 1,
    removed_symlinks: std.StringHashMapUnmanaged(void) = .empty,
    kept_symlinks: std.StringHashMapUnmanaged(void) = .empty,

    max_change: i32 = 0,
    max_len: i32 = 0,

    fn_table: std.StringHashMapUnmanaged(FnItem) = .empty,

    ws_error_action: WsErrorAction = .warn,
    ws_ignore_action: WsIgnore = .none,
    whitespace_option: ?[]const u8 = null,
    whitespace_error: i32 = 0,
    squelch_whitespace_errors: i32 = 5,
    applied_after_fixing_ws: i32 = 0,

    // config-derived
    cfg_default_whitespace: ?[]const u8 = null,
    cfg_default_ignorewhitespace: ?[]const u8 = null,

    // index in use
    istate: ?*index_mod.Index = null,
    index_locked: bool = false,
};

// ---------------------------------------------------------------------------
// error reporting (muted in silent mode, like set_error_routine(mute_routine))

pub var muted: bool = false;

fn errorf(comptime f: []const u8, args: anytype) i32 {
    if (!muted) util.err(f, args);
    return -1;
}
fn warnf(comptime f: []const u8, args: anytype) void {
    if (!muted) util.warn(f, args);
}

// ---------------------------------------------------------------------------
// small helpers

fn at(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

fn isSpace(c: u8) bool {
    return c == ' ' or c == '\t' or c == '\n' or c == '\r' or c == 11 or c == 12;
}

fn isDigit(c: u8) bool {
    return c >= '0' and c <= '9';
}

const Strtoul = struct { val: u64, len: usize };

fn strtoul(s: []const u8, base: u8) Strtoul {
    var i: usize = 0;
    while (i < s.len and isSpace(s[i])) i += 1;
    if (i < s.len and s[i] == '+') i += 1;
    const start = i;
    var v: u64 = 0;
    while (i < s.len) {
        const c = s[i];
        const d: u64 = if (c >= '0' and c <= '9') c - '0' else if (c >= 'a' and c <= 'z') c - 'a' + 10 else if (c >= 'A' and c <= 'Z') c - 'A' + 10 else 99;
        if (d >= base) break;
        v = v *% base +% d;
        i += 1;
    }
    if (i == start) return .{ .val = 0, .len = 0 };
    return .{ .val = v, .len = i };
}

fn linelen(buffer: []const u8, size: usize) usize {
    var len: usize = 0;
    const n = @min(size, buffer.len);
    while (len < n) {
        len += 1;
        if (buffer[len - 1] == '\n') break;
    }
    return len;
}

fn isDevNull(s: []const u8) bool {
    return util.startsWith(s, "/dev/null") and isSpace(at(s, 9));
}

const TERM_SPACE: u32 = 1;
const TERM_TAB: u32 = 2;

fn nameTerminate(c: u8, terminate: u32) bool {
    if (c == ' ' and terminate & TERM_SPACE == 0) return false;
    if (c == '\t' and terminate & TERM_TAB == 0) return false;
    return true;
}

fn squashSlash(name: ?[]const u8) ?[]const u8 {
    const n = name orelse return null;
    var b: Buf = .empty;
    var i: usize = 0;
    while (i < n.len) {
        const c = n[i];
        util.bufByte(&b, c);
        i += 1;
        if (c == '/') {
            while (i < n.len and n[i] == '/') i += 1;
        }
    }
    return b.items;
}

fn findNameGnu(root: *const Buf, line: []const u8, p_value0: i32) ?[]const u8 {
    const uq = util.cunquote(line) orelse return null;
    const name = uq.value;
    var cp: usize = 0;
    var p_value = p_value0;
    while (p_value > 0) : (p_value -= 1) {
        const k = std.mem.indexOfScalarPos(u8, name, cp, '/') orelse return null;
        cp = k + 1;
    }
    return squashSlash(util.concat(&.{ root.items, name[cp..] }));
}

fn saneTzLen(line: []const u8, len: usize) usize {
    if (len < 6 or line[len - 6] != ' ') return 0;
    const tz = len - 6;
    if (line[tz + 1] != '+' and line[tz + 1] != '-') return 0;
    var p = tz + 2;
    while (p != len) : (p += 1) {
        if (!isDigit(line[p])) return 0;
    }
    return len - tz;
}

fn tzWithColonLen(line: []const u8, len: usize) usize {
    if (len < 7 or line[len - 3] != ':') return 0;
    const tz = len - 7;
    if (line[tz] != ' ' or (line[tz + 1] != '+' and line[tz + 1] != '-')) return 0;
    const p = tz + 2;
    if (!isDigit(line[p]) or !isDigit(line[p + 1]) or line[p + 2] != ':' or
        !isDigit(line[p + 3]) or !isDigit(line[p + 4])) return 0;
    return len - tz;
}

fn dateLen(line: []const u8, len: usize) usize {
    if (len < 8 or line[len - 3] != '-') return 0;
    var date = len - 8;
    const p = date;
    if (!isDigit(line[p]) or !isDigit(line[p + 1]) or line[p + 2] != '-' or
        !isDigit(line[p + 3]) or !isDigit(line[p + 4]) or line[p + 5] != '-' or
        !isDigit(line[p + 6]) or !isDigit(line[p + 7])) return 0;
    if (date >= 2 and isDigit(line[date - 1]) and isDigit(line[date - 2])) date -= 2;
    return len - date;
}

fn shortTimeLen(line: []const u8, len: usize) usize {
    if (len < 9 or line[len - 3] != ':') return 0;
    const t = len - 9;
    const p = t;
    if (line[p] != ' ' or
        !isDigit(line[p + 1]) or !isDigit(line[p + 2]) or line[p + 3] != ':' or
        !isDigit(line[p + 4]) or !isDigit(line[p + 5]) or line[p + 6] != ':' or
        !isDigit(line[p + 7]) or !isDigit(line[p + 8])) return 0;
    return len - t;
}

fn fractionalTimeLen(line: []const u8, len: usize) usize {
    if (len == 0 or !isDigit(line[len - 1])) return 0;
    var p = len - 1;
    while (p > 0 and isDigit(line[p])) p -= 1;
    if (line[p] != '.') return 0;
    const n = shortTimeLen(line, p);
    if (n == 0) return 0;
    return len - p + n;
}

fn trailingSpacesLen(line: []const u8, len: usize) usize {
    if (len == 0 or line[len - 1] != ' ') return 0;
    var p = len;
    while (p != 0) {
        p -= 1;
        if (line[p] != ' ') return len - (p + 1);
    }
    return len;
}

fn diffTimestampLen(line: []const u8, len: usize) usize {
    var end = len;
    if (len == 0 or !isDigit(line[end - 1])) return 0;
    var n = saneTzLen(line, end);
    if (n == 0) n = tzWithColonLen(line, end);
    end -= n;
    n = shortTimeLen(line, end);
    if (n == 0) n = fractionalTimeLen(line, end);
    end -= n;
    n = dateLen(line, end);
    if (n == 0) return 0;
    end -= n;
    if (end == 0) return 0;
    if (line[end - 1] == '\t') {
        end -= 1;
        return len - end;
    }
    if (line[end - 1] != ' ') return 0;
    end -= trailingSpacesLen(line, end);
    return len - end;
}

/// find_name_common; `end` is an optional limit (index into line)
fn findNameCommon(root: *const Buf, line: []const u8, def: ?[]const u8, p_value0: i32, end: ?usize, terminate: u32) ?[]const u8 {
    var p_value = p_value0;
    var start: ?usize = null;
    if (p_value == 0) start = 0;
    var i: usize = 0;
    while (true) {
        if (end) |e| {
            if (i == e) break;
        } else if (i >= line.len) break;
        const c = line[i];
        if (end == null and isSpace(c)) {
            if (c == '\n') break;
            if (nameTerminate(c, terminate)) break;
        }
        i += 1;
        if (c == '/') {
            p_value -= 1;
            if (p_value == 0) start = i;
        }
    }
    const s = start orelse return squashSlash(if (def) |d| util.dupe(d) else null);
    const len = i - s;
    if (len == 0) return squashSlash(if (def) |d| util.dupe(d) else null);
    if (def) |d| {
        if (d.len < len and std.mem.eql(u8, line[s .. s + d.len], d)) return squashSlash(util.dupe(d));
    }
    return squashSlash(util.concat(&.{ root.items, line[s .. s + len] }));
}

fn findName(root: *const Buf, line: []const u8, def: ?[]const u8, p_value: i32, terminate: u32) ?[]const u8 {
    if (at(line, 0) == '"') {
        if (findNameGnu(root, line, p_value)) |n| return n;
    }
    return findNameCommon(root, line, def, p_value, null, terminate);
}

fn findNameTraditional(root: *const Buf, line: []const u8, def: ?[]const u8, p_value: i32) ?[]const u8 {
    if (at(line, 0) == '"') {
        if (findNameGnu(root, line, p_value)) |n| return n;
    }
    var len = std.mem.indexOfScalar(u8, line, '\n') orelse line.len;
    const dl = diffTimestampLen(line, len);
    if (dl == 0) return findNameCommon(root, line, def, p_value, null, TERM_TAB);
    len -= dl;
    return findNameCommon(root, line, def, p_value, len, 0);
}

fn countSlashes(s: []const u8) i32 {
    var n: i32 = 0;
    for (s) |c| {
        if (c == '/') n += 1;
    }
    return n;
}

fn guessPValue(state: *State, nameline: []const u8) i32 {
    if (isDevNull(nameline)) return -1;
    const name = findNameTraditional(&state.root, nameline, null, 0) orelse return -1;
    var val: i32 = -1;
    const cp = std.mem.indexOfScalar(u8, name, '/');
    if (cp == null) {
        val = 0;
    } else if (state.prefix) |prefix| {
        if (util.startsWith(name, prefix)) {
            val = countSlashes(prefix);
        } else {
            if (util.startsWith(name[cp.? + 1 ..], prefix)) val = countSlashes(prefix) + 1;
        }
    }
    return val;
}

/// has_epoch_timestamp: "^[0-2][0-9]:([0-5][0-9]):00(\.0+)? ([-+][0-2][0-9]:?[0-5][0-9])\n"
fn hasEpochTimestamp(nameline: []const u8) bool {
    var ts: ?usize = null;
    var i: usize = 0;
    while (i < nameline.len and nameline[i] != '\n') : (i += 1) {
        if (nameline[i] == '\t') ts = i + 1;
    }
    var t = nameline[ts orelse return false ..];
    var epoch_hour: i32 = 0;
    if (util.skipPrefix(t, "1969-12-31 ")) |r| {
        epoch_hour = 24;
        t = r;
    } else if (util.skipPrefix(t, "1970-01-01 ")) |r| {
        epoch_hour = 0;
        t = r;
    } else return false;
    // match regexp manually
    if (t.len < 8) return false;
    if (!(t[0] >= '0' and t[0] <= '2') or !isDigit(t[1]) or t[2] != ':') return false;
    if (!(t[3] >= '0' and t[3] <= '5') or !isDigit(t[4]) or t[5] != ':') return false;
    if (t[6] != '0' or t[7] != '0') return false;
    var p: usize = 8;
    if (at(t, p) == '.' and at(t, p + 1) == '0') {
        p += 1;
        while (at(t, p) == '0') p += 1;
    }
    if (at(t, p) != ' ') return false;
    p += 1;
    const zs = p;
    if (at(t, p) != '-' and at(t, p) != '+') return false;
    p += 1;
    if (!(at(t, p) >= '0' and at(t, p) <= '2') or !isDigit(at(t, p + 1))) return false;
    p += 2;
    var has_colon = false;
    if (at(t, p) == ':') {
        has_colon = true;
        p += 1;
    }
    if (!(at(t, p) >= '0' and at(t, p) <= '5') or !isDigit(at(t, p + 1))) return false;
    p += 2;
    if (at(t, p) != '\n') return false;

    const hour: i32 = (t[0] - '0') * 10 + (t[1] - '0');
    const minute: i32 = (t[3] - '0') * 10 + (t[4] - '0');
    const zh: i32 = (t[zs + 1] - '0') * 10 + (t[zs + 2] - '0');
    var zoneoffset: i32 = undefined;
    if (has_colon) {
        zoneoffset = zh * 60 + (t[zs + 4] - '0') * 10 + (t[zs + 5] - '0');
    } else {
        const v = zh * 100 + (t[zs + 3] - '0') * 10 + (t[zs + 4] - '0');
        zoneoffset = @divTrunc(v, 100) * 60 + @rem(v, 100);
    }
    if (t[zs] == '-') zoneoffset = -zoneoffset;
    return hour * 60 + minute - zoneoffset == epoch_hour * 60;
}

fn parseTraditionalPatch(state: *State, first0: []const u8, second0: []const u8, patch: *Patch) i32 {
    const first = first0[4..];
    const second = second0[4..];
    if (!state.p_value_known) {
        var p = guessPValue(state, first);
        const q = guessPValue(state, second);
        if (p < 0) p = q;
        if (0 <= p and p == q) {
            state.p_value = p;
            state.p_value_known = true;
        }
    }
    var name: ?[]const u8 = null;
    if (isDevNull(first)) {
        patch.is_new = 1;
        patch.is_delete = 0;
        name = findNameTraditional(&state.root, second, null, state.p_value);
        patch.new_name = name;
    } else if (isDevNull(second)) {
        patch.is_new = 0;
        patch.is_delete = 1;
        name = findNameTraditional(&state.root, first, null, state.p_value);
        patch.old_name = name;
    } else {
        const first_name = findNameTraditional(&state.root, first, null, state.p_value);
        name = findNameTraditional(&state.root, second, first_name, state.p_value);
        if (hasEpochTimestamp(first)) {
            patch.is_new = 1;
            patch.is_delete = 0;
            patch.new_name = name;
        } else if (hasEpochTimestamp(second)) {
            patch.is_new = 0;
            patch.is_delete = 1;
            patch.old_name = name;
        } else {
            patch.old_name = name;
            patch.new_name = name;
        }
    }
    if (name == null)
        return errorf("unable to find filename in patch at {s}:{d}", .{ state.patch_input_file, state.linenr });
    return 0;
}

// ---------------------------------------------------------------------------
// git diff header parsing

const GitdiffData = struct {
    root: *const Buf,
    patch_input_file: ?[]const u8,
    linenr: i32,
    p_value: i32,
};

const DIFF_OLD_NAME = 0;
const DIFF_NEW_NAME = 1;

fn gitdiffVerifyName(st: *GitdiffData, line: []const u8, isnull: bool, name: *?[]const u8, side: u32) i32 {
    if (name.* == null and !isnull) {
        name.* = findName(st.root, line, null, st.p_value, TERM_TAB);
        return 0;
    }
    if (name.*) |n| {
        if (isnull) {
            if (st.patch_input_file) |f|
                return errorf("git apply: bad git-diff - expected /dev/null, got {s} at {s}:{d}", .{ n, f, st.linenr });
            return errorf("git apply: bad git-diff - expected /dev/null, got {s} on line {d}", .{ n, st.linenr });
        }
        const another = findName(st.root, line, null, st.p_value, TERM_TAB);
        if (another == null or !util.eql(another.?, n)) {
            if (st.patch_input_file) |f| {
                if (side == DIFF_NEW_NAME)
                    return errorf("git apply: bad git-diff - inconsistent new filename at {s}:{d}", .{ f, st.linenr });
                return errorf("git apply: bad git-diff - inconsistent old filename at {s}:{d}", .{ f, st.linenr });
            }
            if (side == DIFF_NEW_NAME)
                return errorf("git apply: bad git-diff - inconsistent new filename on line {d}", .{st.linenr});
            return errorf("git apply: bad git-diff - inconsistent old filename on line {d}", .{st.linenr});
        }
    } else {
        if (!isDevNull(line)) {
            if (st.patch_input_file) |f|
                return errorf("git apply: bad git-diff - expected /dev/null at {s}:{d}", .{ f, st.linenr });
            return errorf("git apply: bad git-diff - expected /dev/null on line {d}", .{st.linenr});
        }
    }
    return 0;
}

fn parseModeLine(line: []const u8, patch_input_file: ?[]const u8, linenr: i32, mode: *u32) i32 {
    const r = strtoul(line, 8);
    if (r.len == 0 or !isSpace(at(line, r.len))) {
        const l = std.mem.trimEnd(u8, line, "\n");
        if (patch_input_file) |f|
            return errorf("invalid mode at {s}:{d}: {s}\n", .{ f, linenr, l });
        return errorf("invalid mode on line {d}: {s}\n", .{ linenr, l });
    }
    mode.* = index_mod.canonMode(@truncate(r.val));
    return 0;
}

const HdrOp = enum { hdrend, oldname, newname, oldmode, newmode, delete, newfile, copysrc, copydst, renamesrc, renamedst, similarity, dissimilarity, index, unrecognized };

const optable = [_]struct { str: []const u8, op: HdrOp }{
    .{ .str = "@@ -", .op = .hdrend },
    .{ .str = "--- ", .op = .oldname },
    .{ .str = "+++ ", .op = .newname },
    .{ .str = "old mode ", .op = .oldmode },
    .{ .str = "new mode ", .op = .newmode },
    .{ .str = "deleted file mode ", .op = .delete },
    .{ .str = "new file mode ", .op = .newfile },
    .{ .str = "copy from ", .op = .copysrc },
    .{ .str = "copy to ", .op = .copydst },
    .{ .str = "rename old ", .op = .renamesrc },
    .{ .str = "rename new ", .op = .renamedst },
    .{ .str = "rename from ", .op = .renamesrc },
    .{ .str = "rename to ", .op = .renamedst },
    .{ .str = "similarity index ", .op = .similarity },
    .{ .str = "dissimilarity index ", .op = .dissimilarity },
    .{ .str = "index ", .op = .index },
    .{ .str = "", .op = .unrecognized },
};

fn runHdrOp(st: *GitdiffData, op: HdrOp, line: []const u8, patch: *Patch) i32 {
    const pv1 = if (st.p_value != 0) st.p_value - 1 else 0;
    switch (op) {
        .hdrend, .unrecognized => return 1,
        .oldname => return gitdiffVerifyName(st, line, patch.is_new != 0, &patch.old_name, DIFF_OLD_NAME),
        .newname => return gitdiffVerifyName(st, line, patch.is_delete != 0, &patch.new_name, DIFF_NEW_NAME),
        .oldmode => return parseModeLine(line, st.patch_input_file, st.linenr, &patch.old_mode),
        .newmode => return parseModeLine(line, st.patch_input_file, st.linenr, &patch.new_mode),
        .delete => {
            patch.is_delete = 1;
            patch.old_name = patch.def_name;
            return parseModeLine(line, st.patch_input_file, st.linenr, &patch.old_mode);
        },
        .newfile => {
            patch.is_new = 1;
            patch.new_name = patch.def_name;
            return parseModeLine(line, st.patch_input_file, st.linenr, &patch.new_mode);
        },
        .copysrc => {
            patch.is_copy = true;
            patch.old_name = findName(st.root, line, null, pv1, 0);
            return 0;
        },
        .copydst => {
            patch.is_copy = true;
            patch.new_name = findName(st.root, line, null, pv1, 0);
            return 0;
        },
        .renamesrc => {
            patch.is_rename = true;
            patch.old_name = findName(st.root, line, null, pv1, 0);
            return 0;
        },
        .renamedst => {
            patch.is_rename = true;
            patch.new_name = findName(st.root, line, null, pv1, 0);
            return 0;
        },
        .similarity, .dissimilarity => {
            const v = strtoul(line, 10).val;
            if (v <= 100) patch.score = @intCast(v);
            return 0;
        },
        .index => {
            const hexsz: usize = hash.HEXSZ;
            const dot = std.mem.indexOfScalar(u8, line, '.') orelse return 0;
            if (at(line, dot + 1) != '.' or hexsz < dot) return 0;
            patch.old_oid_prefix = util.dupe(line[0..dot]);
            const rest = line[dot + 2 ..];
            const eol = std.mem.indexOfScalar(u8, rest, '\n') orelse rest.len;
            var p = std.mem.indexOfScalar(u8, rest, ' ') orelse eol;
            if (eol < p) p = eol;
            if (hexsz < p) return 0;
            patch.new_oid_prefix = util.dupe(rest[0..p]);
            if (at(rest, p) == ' ') return parseModeLine(rest[p + 1 ..], st.patch_input_file, st.linenr, &patch.old_mode);
            return 0;
        },
    }
}

fn skipTreePrefix(p_value: i32, line: []const u8) ?usize {
    if (p_value == 0) return if (line.len > 0 and line[0] == '/') null else 0;
    var nslash = p_value;
    for (line, 0..) |c, i| {
        if (c == '/') {
            nslash -= 1;
            if (nslash <= 0) return if (i == 0) null else i + 1;
        }
    }
    return null;
}

fn gitHeaderName(p_value: i32, line0: []const u8) ?[]const u8 {
    const line = line0["diff --git ".len..];
    const llen = line.len;
    if (at(line, 0) == '"') {
        const uq = util.cunquote(line) orelse return null;
        const first0 = uq.value;
        const cp0 = skipTreePrefix(p_value, first0) orelse return null;
        const first = first0[cp0..];
        var second: usize = llen - uq.rest.len;
        while (second < llen and isSpace(line[second])) second += 1;
        if (llen <= second) return null;
        if (line[second] == '"') {
            const uq2 = util.cunquote(line[second..]) orelse return null;
            const cp = skipTreePrefix(p_value, uq2.value) orelse return null;
            if (!util.eql(uq2.value[cp..], first)) return null;
            return first;
        }
        const sec = line[second..];
        const cp = skipTreePrefix(p_value, sec) orelse return null;
        if (!util.eql(sec[cp..], first)) return null;
        return first;
    }

    const name_off = skipTreePrefix(p_value, line) orelse return null;
    const name = line[name_off..];
    // a dq, if exists, must be the beginning of the second name
    for (name, 0..) |c, si| {
        if (c == '"') {
            const uq = util.cunquote(name[si..]) orelse return null;
            const np = skipTreePrefix(p_value, uq.value) orelse return null;
            const npv = uq.value[np..];
            const len = npv.len;
            if (len < si and std.mem.eql(u8, npv, name[0..len]) and isSpace(name[len])) return util.dupe(npv);
            return null;
        }
    }
    const nl = std.mem.indexOfScalar(u8, name, '\n') orelse return null;
    const line_len = nl;
    var len: usize = 0;
    while (true) : (len += 1) {
        const c = at(name, len);
        switch (c) {
            '\n' => return null,
            '\t', ' ' => {
                if (at(name, len + 1) == 0) return null;
                if (len + 1 > line_len) continue;
                const sec_slice = name[len + 1 .. line_len];
                const so = skipTreePrefix(p_value, sec_slice) orelse continue;
                const secv = name[len + 1 + so ..];
                if (at(secv, len) == '\n' and std.mem.eql(u8, name[0..len], secv[0..@min(len, secv.len)]) and secv.len >= len) return util.dupe(name[0..len]);
            },
            0 => {
                if (len >= name.len) return null;
            },
            else => {},
        }
    }
}

fn checkHeaderLine(linenr: i32, patch: *Patch) i32 {
    const extensions = @as(i32, @intFromBool(patch.is_delete == 1)) + @intFromBool(patch.is_new == 1) +
        @intFromBool(patch.is_rename) + @intFromBool(patch.is_copy);
    if (extensions > 1)
        return errorf("inconsistent header lines {d} and {d}", .{ patch.extension_linenr, linenr });
    if (extensions != 0 and patch.extension_linenr == 0) patch.extension_linenr = linenr;
    return 0;
}

/// parse_git_diff_header(); `buf` starts at the "diff --git" line, len is its length
pub fn parseGitDiffHeader(root: *const Buf, patch_input_file: ?[]const u8, linenr: *i32, p_value: i32, buf: []const u8, len0: usize, size0: usize, patch: *Patch) i32 {
    patch.is_new = 0;
    patch.is_delete = 0;
    patch.def_name = gitHeaderName(p_value, buf[0..len0]);
    if (patch.def_name != null and root.items.len > 0) {
        patch.def_name = util.concat(&.{ root.items, patch.def_name.? });
    }
    var line = buf[len0..];
    var size = size0 - len0;
    linenr.* += 1;
    var st = GitdiffData{ .root = root, .patch_input_file = patch_input_file, .linenr = linenr.*, .p_value = p_value };
    var offset: usize = len0;
    var len: usize = len0;
    outer: while (size > 0) : ({
        offset += len;
        size -= len;
        line = line[len..];
        linenr.* += 1;
    }) {
        len = linelen(line, size);
        if (len == 0 or line[len - 1] != '\n') break;
        for (optable) |p| {
            const oplen = p.str.len;
            if (len < oplen or !std.mem.eql(u8, p.str, line[0..oplen])) continue;
            st.linenr = linenr.*;
            const res = runHdrOp(&st, p.op, line[oplen..len], patch);
            if (res < 0) return -1;
            if (checkHeaderLine(linenr.*, patch) != 0) return -1;
            if (res > 0) break :outer;
            break;
        }
    }

    if (patch.old_name == null and patch.new_name == null) {
        if (patch.def_name == null) {
            const comp = if (st.p_value == 1) "component" else "components";
            if (patch_input_file) |f| {
                _ = errorf("git diff header lacks filename information when removing {d} leading pathname {s} at {s}:{d}", .{ st.p_value, comp, f, linenr.* });
            } else {
                _ = errorf("git diff header lacks filename information when removing {d} leading pathname {s} (line {d})", .{ st.p_value, comp, linenr.* });
            }
            return -128;
        }
        patch.old_name = patch.def_name;
        patch.new_name = patch.def_name;
    }
    if ((patch.new_name == null and patch.is_delete == 0) or (patch.old_name == null and patch.is_new == 0)) {
        if (patch_input_file) |f| {
            _ = errorf("git diff header lacks filename information at {s}:{d}", .{ f, linenr.* });
        } else {
            _ = errorf("git diff header lacks filename information (line {d})", .{linenr.*});
        }
        return -128;
    }
    patch.is_toplevel_relative = true;
    return @intCast(offset);
}

fn parseNum(line: []const u8, p: *i64) usize {
    if (!isDigit(at(line, 0))) return 0;
    const r = strtoul(line, 10);
    if (r.val > std.math.maxInt(i64)) return 0;
    p.* = @intCast(r.val);
    return r.len;
}

fn parseRange(line0: []const u8, len0: usize, offset0: i64, expect: []const u8, p1: *i64, p2: *i64) i64 {
    if (offset0 < 0 or offset0 >= @as(i64, @intCast(len0))) return -1;
    var offset: usize = @intCast(offset0);
    var line = line0[offset..len0];
    var digits = parseNum(line, p1);
    if (digits == 0) return -1;
    offset += digits;
    line = line[digits..];
    p2.* = 1;
    if (at(line, 0) == ',') {
        digits = parseNum(line[1..], p2);
        if (digits == 0) return -1;
        offset += digits + 1;
        line = line[digits + 1 ..];
    }
    if (expect.len > line.len) return -1;
    if (!std.mem.eql(u8, line[0..expect.len], expect)) return -1;
    return @intCast(offset + expect.len);
}

fn recountDiff(line0: []const u8, size0: usize, fragment: *Fragment) void {
    var oldlines: i64 = 0;
    var newlines: i64 = 0;
    var size: i64 = @intCast(size0);
    var line = line0;
    if (size < 1) {
        warnf("recount: ignore empty hunk", .{});
        return;
    }
    while (true) {
        const len = linelen(line, @intCast(size));
        size -= @intCast(len);
        line = line[len..];
        if (size < 1) break;
        var ret = false;
        switch (line[0]) {
            ' ', '\n' => {
                newlines += 1;
                oldlines += 1;
                continue;
            },
            '-' => {
                oldlines += 1;
                continue;
            },
            '+' => {
                newlines += 1;
                continue;
            },
            '\\' => continue,
            '@' => ret = size < 3 or !util.startsWith(line, "@@ "),
            'd' => ret = size < 5 or !util.startsWith(line, "diff "),
            else => ret = true,
        }
        if (ret) {
            const l = linelen(line, @intCast(size));
            warnf("recount: unexpected line: {s}", .{line[0..l]});
            return;
        }
        break;
    }
    fragment.oldlines = oldlines;
    fragment.newlines = newlines;
}

fn parseFragmentHeader(line: []const u8, len: usize, fragment: *Fragment) i64 {
    if (len == 0 or line[len - 1] != '\n') return -1;
    var offset = parseRange(line, len, 4, " +", &fragment.oldpos, &fragment.oldlines);
    offset = parseRange(line, len, offset, " @@", &fragment.newpos, &fragment.newlines);
    return offset;
}

/// find_header: returns offset of header, -1 if not found, -128 on error
fn findHeader(state: *State, buf: []const u8, size0: usize, hdrsize: *usize, patch: *Patch) i64 {
    patch.is_toplevel_relative = false;
    patch.is_rename = false;
    patch.is_copy = false;
    patch.is_new = -1;
    patch.is_delete = -1;
    patch.old_mode = 0;
    patch.new_mode = 0;
    patch.old_name = null;
    patch.new_name = null;
    var offset: usize = 0;
    var size = size0;
    var line = buf;
    var len: usize = 0;
    while (size > 0) : ({
        offset += len;
        size -= len;
        line = line[len..];
        state.linenr += 1;
    }) {
        len = linelen(line, size);
        if (len == 0) break;
        if (len < 6) continue;
        if (std.mem.eql(u8, line[0..4], "@@ -")) {
            var dummy = Fragment{};
            if (parseFragmentHeader(line, len, &dummy) < 0) continue;
            _ = errorf("patch fragment without header at {s}:{d}: {s}", .{ state.patch_input_file, state.linenr, line[0 .. len - 1] });
            return -128;
        }
        if (size < len + 6) break;
        if (util.startsWith(line[0..len], "diff --git ")) {
            const git_hdr_len = parseGitDiffHeader(&state.root, state.patch_input_file, &state.linenr, state.p_value, line, len, size, patch);
            if (git_hdr_len < 0) return -128;
            if (git_hdr_len <= len) continue;
            hdrsize.* = @intCast(git_hdr_len);
            return @intCast(offset);
        }
        if (!std.mem.eql(u8, line[0..4], "--- ") or !std.mem.eql(u8, line[len .. len + 4], "+++ ")) continue;
        const nextlen = linelen(line[len..], size - len);
        if (size < nextlen + 14 or !std.mem.eql(u8, line[len + nextlen .. len + nextlen + 4], "@@ -")) continue;
        if (parseTraditionalPatch(state, line, line[len..], patch) != 0) return -128;
        hdrsize.* = len + nextlen;
        state.linenr += 2;
        return @intCast(offset);
    }
    return -1;
}

fn recordWsError(state: *State, result: u32, line: []const u8, len0: usize, linenr: i32) void {
    if (result == 0) return;
    state.whitespace_error += 1;
    if (state.squelch_whitespace_errors != 0 and state.squelch_whitespace_errors < state.whitespace_error) return;
    var len = len0;
    if (result & diff.WS_INCOMPLETE_LINE != 0) len += 1;
    const e = diff.wsErrorString(result);
    if (state.apply_verbosity > VERBOSITY_SILENT)
        util.eprint("{s}:{d}: {s}.\n{s}\n", .{ state.patch_input_file, linenr, e, line[0..@min(len, line.len)] });
}

fn checkWhitespace(state: *State, line: []const u8, len: usize, ws_rule: u32) void {
    const result = diff.wsCheck(line[1..len], ws_rule);
    recordWsError(state, result, line[1..], if (len >= 2) len - 2 else 0, state.linenr);
}

fn checkOldForCrlf(patch: *Patch, line: []const u8, len: usize) void {
    if (len >= 2 and line[len - 1] == '\n' and line[len - 2] == '\r') {
        patch.ws_rule |= diff.WS_CR_AT_EOL;
        patch.crlf_in_old = true;
    }
}

fn adjustIncomplete(line: []const u8, len: usize, size: usize) usize {
    const c = line[0];
    if (c != '\n' and c != ' ' and c != '+' and c != '-') return 0;
    if (size - len < 12 or !std.mem.eql(u8, line[len .. len + 2], "\\ ")) return 0;
    const nextlen = linelen(line[len..], size - len);
    if (nextlen < 12) return 0;
    return nextlen;
}

fn parseFragment(state: *State, line0: []const u8, size0: usize, patch: *Patch, fragment: *Fragment) i64 {
    var line = line0;
    var size = size0;
    var len = linelen(line, size);
    if (patch.ws_rule & diff.WS_INCOMPLETE_LINE != 0) {
        const mode = if (state.apply_in_reverse) patch.old_mode else if (patch.new_mode != 0) patch.new_mode else patch.old_mode;
        if (mode != 0 and mode & 0o170000 == 0o120000) patch.ws_rule &= ~diff.WS_INCOMPLETE_LINE;
    }
    var offset = parseFragmentHeader(line, len, fragment);
    if (offset < 0) return -1;
    if (offset > 0 and patch.recount) {
        const o: usize = @intCast(offset);
        recountDiff(line[o..], size - o, fragment);
    }
    var oldlines = fragment.oldlines;
    var newlines = fragment.newlines;
    var leading: i64 = 0;
    var trailing: i64 = 0;

    line = line[len..];
    size -= len;
    state.linenr += 1;
    var added: i32 = 0;
    var deleted: i32 = 0;
    offset = @intCast(len);
    while (0 < size) : ({
        offset += @intCast(len);
        size -= len;
        line = line[len..];
        state.linenr += 1;
    }) {
        if (oldlines == 0 and newlines == 0) break;
        len = linelen(line, size);
        if (len == 0 or line[len - 1] != '\n') return -1;
        var skip_len = adjustIncomplete(line, len, size);
        if (skip_len != 0) {
            len -= 1;
            skip_len += 1;
        }
        switch (line[0]) {
            '\n', ' ' => {
                oldlines -= 1;
                newlines -= 1;
                if (deleted == 0 and added == 0) leading += 1;
                trailing += 1;
                checkOldForCrlf(patch, line, len);
                if (!state.apply_in_reverse and state.ws_error_action == .correct) {
                    if (line[0] == '\n') {
                        checkWhitespace(state, " \n", 2, patch.ws_rule);
                    } else checkWhitespace(state, line, len, patch.ws_rule);
                }
            },
            '-' => {
                if (!state.apply_in_reverse) checkOldForCrlf(patch, line, len);
                if (state.apply_in_reverse and state.ws_error_action != .nowarn)
                    checkWhitespace(state, line, len, patch.ws_rule);
                deleted += 1;
                oldlines -= 1;
                trailing = 0;
            },
            '+' => {
                if (state.apply_in_reverse) checkOldForCrlf(patch, line, len);
                if (!state.apply_in_reverse and state.ws_error_action != .nowarn)
                    checkWhitespace(state, line, len, patch.ws_rule);
                added += 1;
                newlines -= 1;
                trailing = 0;
            },
            else => return -1,
        }
        if (skip_len != 0) {
            len += skip_len;
            state.linenr += 1;
        }
    }
    if (oldlines != 0 or newlines != 0) return -1;
    if (!patch.recount and deleted == 0 and added == 0) return -1;

    fragment.leading = leading;
    fragment.trailing = trailing;
    patch.lines_added += added;
    patch.lines_deleted += deleted;

    if (0 < patch.is_new and oldlines != 0) return errorf("new file depends on old contents", .{});
    if (0 < patch.is_delete and newlines != 0) return errorf("deleted file still has contents", .{});
    return offset;
}

fn parseSinglePatch(state: *State, line0: []const u8, size0: usize, patch: *Patch) i64 {
    var line = line0;
    var size = size0;
    var offset: usize = 0;
    var oldlines: i64 = 0;
    var newlines: i64 = 0;
    var context: i64 = 0;
    var tail: *?*Fragment = &patch.fragments;
    while (size > 4 and std.mem.eql(u8, line[0..4], "@@ -")) {
        const fragment = gpa.create(Fragment) catch util.oom();
        fragment.* = .{};
        fragment.linenr = state.linenr;
        const len = parseFragment(state, line, size, patch, fragment);
        if (len <= 0) {
            return errorf("corrupt patch at {s}:{d}", .{ state.patch_input_file, state.linenr });
        }
        const ulen: usize = @intCast(len);
        fragment.patch = line[0..ulen];
        oldlines += fragment.oldlines;
        newlines += fragment.newlines;
        context += fragment.leading + fragment.trailing;
        tail.* = fragment;
        tail = &fragment.next;
        offset += ulen;
        line = line[ulen..];
        size -= ulen;
    }
    const multi = patch.fragments != null and patch.fragments.?.next != null;
    if (patch.is_new < 0 and (oldlines != 0 or multi)) patch.is_new = 0;
    if (patch.is_delete < 0 and (newlines != 0 or multi)) patch.is_delete = 0;

    if (0 < patch.is_new and oldlines != 0)
        return errorf("new file {s} depends on old contents", .{patch.new_name orelse "(null)"});
    if (0 < patch.is_delete and newlines != 0)
        return errorf("deleted file {s} still has contents", .{patch.old_name orelse "(null)"});
    if (patch.is_delete == 0 and newlines == 0 and context != 0 and state.apply_verbosity > VERBOSITY_SILENT)
        util.eprint("** warning: file {s} becomes empty but is not deleted\n", .{patch.new_name orelse "(null)"});
    return @intCast(offset);
}

fn metadataChanges(patch: *const Patch) bool {
    return patch.is_rename or patch.is_copy or patch.is_new > 0 or patch.is_delete != 0 or
        (patch.old_mode != 0 and patch.new_mode != 0 and patch.old_mode != patch.new_mode);
}

fn inflateIt(data: []const u8, inflated_size: usize) ?[]const u8 {
    const r = zlib.decompress(data, inflated_size) orelse return null;
    if (r.data.len != inflated_size) return null;
    return r.data;
}

// base85 decoding
const en85 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~";

fn de85(ch: u8) i32 {
    const i = std.mem.indexOfScalar(u8, en85, ch) orelse return -1;
    return @intCast(i);
}

fn decode85(dst: []u8, buffer: []const u8, len0: usize) bool {
    var len = len0;
    var bi: usize = 0;
    var di: usize = 0;
    while (len > 0) {
        var acc: u32 = 0;
        var cnt: u32 = 4;
        while (cnt > 0) : (cnt -= 1) {
            const ch = at(buffer, bi);
            bi += 1;
            const de = de85(ch);
            if (de < 0) {
                _ = errorf("invalid base85 alphabet {c}", .{ch});
                return false;
            }
            acc = acc *% 85 +% @as(u32, @intCast(de));
        }
        const ch = at(buffer, bi);
        bi += 1;
        const de = de85(ch);
        if (de < 0) {
            _ = errorf("invalid base85 alphabet {c}", .{ch});
            return false;
        }
        if (0xffffffff / 85 < acc or 0xffffffff - @as(u32, @intCast(de)) < acc * 85) {
            _ = errorf("invalid base85 sequence {s}", .{buffer[bi - 5 .. bi]});
            return false;
        }
        acc = acc * 85 + @as(u32, @intCast(de));
        cnt = if (len < 4) @intCast(len) else 4;
        len -= cnt;
        while (cnt > 0) : (cnt -= 1) {
            acc = (acc << 8) | (acc >> 24);
            dst[di] = @truncate(acc);
            di += 1;
        }
    }
    return true;
}

const BinHunk = struct { frag: ?*Fragment, status: i32, used: usize, rest: []const u8, size: usize };

fn parseBinaryHunk(state: *State, buf0: []const u8, size0: usize) BinHunk {
    var buffer = buf0;
    var size = size0;
    var llen = linelen(buffer, size);
    var used = llen;
    var patch_method: i64 = 0;
    var origlen: u64 = 0;
    var data: Buf = .empty;
    var error_msg: ?[]const u8 = null;

    if (util.startsWith(buffer[0..llen], "delta ")) {
        patch_method = BINARY_DELTA_DEFLATED;
        origlen = strtoul(buffer[6..llen], 10).val;
    } else if (util.startsWith(buffer[0..llen], "literal ")) {
        patch_method = BINARY_LITERAL_DEFLATED;
        origlen = strtoul(buffer[8..llen], 10).val;
    } else return .{ .frag = null, .status = 0, .used = 0, .rest = buffer, .size = size };

    corrupt: {
        if (origlen >= MAX_APPLY_SIZE) {
            error_msg = "patch too large";
            break :corrupt;
        }
        state.linenr += 1;
        buffer = buffer[llen..];
        size -= llen;
        while (true) {
            llen = linelen(buffer, size);
            used += llen;
            state.linenr += 1;
            if (llen == 1) {
                buffer = buffer[1..];
                size -= 1;
                break;
            }
            if (llen < 7 or (llen - 2) % 5 != 0) break :corrupt;
            const max_byte_length = (llen - 2) / 5 * 4;
            var byte_length: usize = buffer[0];
            if ('A' <= byte_length and byte_length <= 'Z') {
                byte_length = byte_length - 'A' + 1;
            } else if ('a' <= byte_length and byte_length <= 'z') {
                byte_length = byte_length - 'a' + 27;
            } else break :corrupt;
            if (max_byte_length < byte_length or byte_length + 4 <= max_byte_length) break :corrupt;
            const old = data.items.len;
            data.resize(gpa, old + byte_length) catch util.oom();
            if (!decode85(data.items[old..], buffer[1..], byte_length)) break :corrupt;
            buffer = buffer[llen..];
            size -= llen;
        }
        const frag = gpa.create(Fragment) catch util.oom();
        frag.* = .{};
        frag.patch = inflateIt(data.items, @intCast(origlen)) orelse break :corrupt;
        frag.leading = patch_method;
        return .{ .frag = frag, .status = 0, .used = used, .rest = buffer, .size = size };
    }
    if (error_msg) |m| {
        _ = errorf("{s}", .{m});
    } else {
        const l = if (llen > 0) llen - 1 else 0;
        _ = errorf("corrupt binary patch at {s}:{d}: {s}", .{ state.patch_input_file, state.linenr - 1, buffer[0..@min(l, buffer.len)] });
    }
    return .{ .frag = null, .status = -1, .used = used, .rest = buffer, .size = size };
}

fn parseBinary(state: *State, buffer: []const u8, size: usize, patch: *Patch) i64 {
    const fwd = parseBinaryHunk(state, buffer, size);
    if (fwd.frag == null and fwd.status == 0)
        return errorf("unrecognized binary patch at {s}:{d}", .{ state.patch_input_file, state.linenr - 1 });
    if (fwd.status != 0) return fwd.status;
    var used = fwd.used;
    const rev = parseBinaryHunk(state, fwd.rest, fwd.size);
    if (rev.frag != null) {
        used += rev.used;
    } else if (rev.status != 0) return rev.status;
    fwd.frag.?.next = rev.frag;
    patch.fragments = fwd.frag;
    patch.is_binary = true;
    return @intCast(used);
}

fn prefixFilename(prefix: []const u8, name: []const u8) []const u8 {
    if (name.len > 0 and name[0] == '/') return name;
    return util.concat(&.{ prefix, name });
}

fn prefixPatch(state: *State, p: *Patch) void {
    const prefix = state.prefix orelse return;
    if (p.is_toplevel_relative) return;
    if (p.new_name) |n| p.new_name = prefixFilename(prefix, n);
    if (p.old_name) |n| p.old_name = prefixFilename(prefix, n);
}

fn usePatch(state: *State, p: *const Patch) bool {
    const pathname = p.new_name orelse p.old_name orelse "";
    if (state.prefix) |prefix| {
        if (prefix.len > 0) {
            const rest = util.skipPrefix(pathname, prefix) orelse return false;
            if (rest.len == 0) return false;
        }
    }
    for (state.limit_by_name.items) |it| {
        if (wildmatch.match(it.pattern, pathname, 0)) return it.include;
    }
    return !state.has_include;
}

/// parse_chunk: returns bytes consumed, -1 if no header / binary failure, -128 on other errors
fn parseChunk(state: *State, buffer: []const u8, size: usize, patch: *Patch) i64 {
    var hdrsize: usize = 0;
    const offset = findHeader(state, buffer, size, &hdrsize, patch);
    if (offset < 0) return offset;
    prefixPatch(state, patch);
    if (!usePatch(state, patch)) {
        patch.ws_rule = 0;
    } else if (patch.new_name) |n| {
        patch.ws_rule = diff.whitespaceRule(n);
    } else {
        patch.ws_rule = diff.whitespaceRule(patch.old_name.?);
    }
    const uoff: usize = @intCast(offset);
    const hd = uoff + hdrsize;
    var patchsize = parseSinglePatch(state, buffer[hd..], size - hd, patch);
    if (patchsize < 0) return -128;
    if (patchsize == 0) {
        const git_binary = "GIT binary patch\n";
        const llen = linelen(buffer[hd..], size - hd);
        if (llen == git_binary.len and std.mem.eql(u8, buffer[hd .. hd + llen], git_binary)) {
            state.linenr += 1;
            const used = parseBinary(state, buffer[hd + llen ..], size - hd - llen, patch);
            if (used < 0) return -1;
            patchsize = if (used != 0) used + @as(i64, @intCast(llen)) else 0;
        } else if (llen >= 8 and std.mem.eql(u8, buffer[hd + llen - 8 .. hd + llen], " differ\n")) {
            const binhdr = [_][]const u8{ "Binary files ", "Files " };
            for (binhdr) |h| {
                if (h.len < size - hd and std.mem.eql(u8, buffer[hd .. hd + h.len], h)) {
                    state.linenr += 1;
                    patch.is_binary = true;
                    patchsize = @intCast(llen);
                    break;
                }
            }
        }
        if ((state.apply or state.check) and (!patch.is_binary and !metadataChanges(patch))) {
            _ = errorf("patch with only garbage at {s}:{d}", .{ state.patch_input_file, state.linenr });
            return -128;
        }
    }
    return offset + @as(i64, @intCast(hdrsize)) + patchsize;
}

fn reversePatches(p0: ?*Patch) void {
    var p = p0;
    while (p) |pp| : (p = pp.next) {
        std.mem.swap(?[]const u8, &pp.new_name, &pp.old_name);
        if (pp.new_mode != 0 or pp.is_delete != 0) std.mem.swap(u32, &pp.new_mode, &pp.old_mode);
        std.mem.swap(i32, &pp.is_new, &pp.is_delete);
        std.mem.swap(i32, &pp.lines_added, &pp.lines_deleted);
        std.mem.swap([]const u8, &pp.old_oid_prefix, &pp.new_oid_prefix);
        var frag = pp.fragments;
        while (frag) |f| : (frag = f.next) {
            std.mem.swap(i64, &f.newpos, &f.oldpos);
            std.mem.swap(i64, &f.newlines, &f.oldlines);
        }
    }
}

// ---------------------------------------------------------------------------
// diffstat-like output

const pluses = "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
const minuses = "----------------------------------------------------------------------";

fn padRight(b: *Buf, s: []const u8, width: usize) void {
    util.bufAppend(b, s);
    var n = s.len;
    while (n < width) : (n += 1) util.bufByte(b, ' ');
}

fn showStats(state: *State, patch: *Patch) void {
    const cp = patch.new_name orelse patch.old_name.?;
    var qname: Buf = .empty;
    util.bufAppend(&qname, util.cquote(cp));
    var max: usize = @intCast(@max(state.max_len, 0));
    if (max > 50) max = 50;
    if (qname.items.len > max) {
        const startpos = qname.items.len + 3 - max;
        const slash = std.mem.indexOfScalarPos(u8, qname.items, startpos, '/');
        const cut = slash orelse startpos;
        var nb: Buf = .empty;
        util.bufAppend(&nb, "...");
        util.bufAppend(&nb, qname.items[cut..]);
        qname = nb;
    }
    var line: Buf = .empty;
    util.bufByte(&line, ' ');
    padRight(&line, qname.items, max);
    if (patch.is_binary) {
        util.bufAppend(&line, " |  Bin\n");
        util.out(line.items);
        return;
    }
    util.bufAppend(&line, " |");
    const mc: i64 = state.max_change;
    const imax: i64 = @intCast(max);
    const smax: i64 = if (imax + mc > 70) 70 - imax else mc;
    var add: i64 = patch.lines_added;
    var del: i64 = patch.lines_deleted;
    if (mc > 0) {
        const total = @divTrunc((add + del) * smax + @divTrunc(mc, 2), mc);
        add = @divTrunc(add * smax + @divTrunc(mc, 2), mc);
        del = total - add;
    }
    util.bufPrint(&line, "{d:>5} {s}{s}\n", .{ patch.lines_added + patch.lines_deleted, pluses[0..@intCast(@max(add, 0))], minuses[0..@intCast(@max(del, 0))] });
    util.out(line.items);
}

// ---------------------------------------------------------------------------
// images

const LINE_COMMON: u8 = 1;
const LINE_PATCHED: u8 = 2;

const Line = struct { len: usize, hash: u32, flag: u8 };

const Image = struct {
    buf: Buf = .empty,
    lines: std.ArrayList(Line) = .empty,

    fn nr(self: *const Image) usize {
        return self.lines.items.len;
    }
    fn clear(self: *Image) void {
        self.buf = .empty;
        self.lines = .empty;
    }
};

fn hashLine(cp: []const u8) u32 {
    var h: u32 = 0;
    for (cp) |c| {
        if (!isSpace(c)) h = h *% 3 +% c;
    }
    return h & 0xffffff;
}

fn imageAddLine(img: *Image, bol: []const u8, flag: u8) void {
    img.lines.append(gpa, .{ .len = bol.len, .hash = hashLine(bol), .flag = flag }) catch util.oom();
}

fn imagePrepare(img: *Image, data: []const u8, prepare_linetable: bool) void {
    img.clear();
    util.bufAppend(&img.buf, data);
    if (!prepare_linetable) return;
    const b = img.buf.items;
    var cp: usize = 0;
    while (cp < b.len) {
        var next = cp;
        while (next < b.len and b[next] != '\n') next += 1;
        if (next < b.len) next += 1;
        imageAddLine(img, b[cp..next], 0);
        cp = next;
    }
}

fn imageRemoveFirstLine(img: *Image) void {
    const l = img.lines.items[0].len;
    std.mem.copyForwards(u8, img.buf.items[0 .. img.buf.items.len - l], img.buf.items[l..]);
    img.buf.items.len -= l;
    _ = img.lines.orderedRemove(0);
}

fn imageRemoveLastLine(img: *Image) void {
    const l = img.lines.items[img.lines.items.len - 1].len;
    img.buf.items.len -= l;
    img.lines.items.len -= 1;
}

fn updatePrePostImages(preimage: *Image, postimage: *Image, data: []const u8) void {
    var fixed_preimage = Image{};
    imagePrepare(&fixed_preimage, data, true);
    for (fixed_preimage.lines.items, 0..) |*l, i| {
        l.flag = if (i < preimage.lines.items.len) preimage.lines.items[i].flag else 0;
    }
    preimage.* = fixed_preimage;
    var fixed: usize = 0;
    var insert_pos: usize = 0;
    var ctx: usize = 0;
    var reduced: usize = 0;
    var i: usize = 0;
    while (i < postimage.lines.items.len) : (i += 1) {
        var l_len = postimage.lines.items[i].len;
        if (postimage.lines.items[i].flag & LINE_COMMON == 0) {
            insert_pos += l_len;
            continue;
        }
        while (ctx < preimage.lines.items.len and preimage.lines.items[ctx].flag & LINE_COMMON == 0) {
            fixed += preimage.lines.items[ctx].len;
            ctx += 1;
        }
        if (preimage.lines.items.len <= ctx) {
            reduced += 1;
            continue;
        }
        l_len = preimage.lines.items[ctx].len;
        postimage.buf.replaceRange(gpa, insert_pos, postimage.lines.items[i].len, preimage.buf.items[fixed .. fixed + l_len]) catch util.oom();
        insert_pos += l_len;
        fixed += l_len;
        postimage.lines.items[i].len = l_len;
        ctx += 1;
    }
    postimage.lines.items.len -= reduced;
}

fn fuzzyMatchlines(a: []const u8, b: []const u8) bool {
    var end1 = a.len;
    var end2 = b.len;
    while (end1 > 0 and (a[end1 - 1] == '\r' or a[end1 - 1] == '\n')) end1 -= 1;
    while (end2 > 0 and (b[end2 - 1] == '\r' or b[end2 - 1] == '\n')) end2 -= 1;
    var s1: usize = 0;
    var s2: usize = 0;
    while (s1 < end1 and s2 < end2) {
        if (isSpace(a[s1])) {
            if (!isSpace(b[s2])) return false;
            while (s1 < end1 and isSpace(a[s1])) s1 += 1;
            while (s2 < end2 and isSpace(b[s2])) s2 += 1;
        } else {
            if (a[s1] != b[s2]) return false;
            s1 += 1;
            s2 += 1;
        }
    }
    return s1 == end1 and s2 == end2;
}

fn lineByLineFuzzyMatch(img: *Image, preimage: *Image, postimage: *Image, current: usize, current_lno: usize, preimage_limit: usize) bool {
    var imgoff: usize = 0;
    var preoff: usize = 0;
    var i: usize = 0;
    while (i < preimage_limit) : (i += 1) {
        const prelen = preimage.lines.items[i].len;
        const imglen = img.lines.items[current_lno + i].len;
        if (!fuzzyMatchlines(img.buf.items[current + imgoff .. current + imgoff + imglen], preimage.buf.items[preoff .. preoff + prelen])) return false;
        imgoff += imglen;
        preoff += prelen;
    }
    const preimage_eof = preoff;
    while (i < preimage.lines.items.len) : (i += 1) preoff += preimage.lines.items[i].len;
    const preimage_end = preoff;
    for (preimage.buf.items[preimage_eof..preimage_end]) |c| {
        if (!isSpace(c)) return false;
    }
    var fixed: Buf = .empty;
    util.bufAppend(&fixed, img.buf.items[current .. current + imgoff]);
    util.bufAppend(&fixed, preimage.buf.items[preimage_eof..preimage_end]);
    updatePrePostImages(preimage, postimage, fixed.items);
    return true;
}

fn matchFragment(state: *State, img: *Image, preimage: *Image, postimage: *Image, current: usize, current_lno: usize, ws_rule: u32, match_beginning: bool, match_end: bool) bool {
    var preimage_limit: usize = undefined;
    const pre_nr = preimage.lines.items.len;
    const img_nr = img.lines.items.len;
    if (pre_nr + current_lno <= img_nr) {
        preimage_limit = pre_nr;
        if (match_end and pre_nr + current_lno != img_nr) return false;
    } else if (state.ws_error_action == .correct and ws_rule & diff.WS_BLANK_AT_EOF != 0) {
        preimage_limit = img_nr - current_lno;
    } else return false;

    if (match_beginning and current_lno != 0) return false;

    var i: usize = 0;
    while (i < preimage_limit) : (i += 1) {
        const il = img.lines.items[current_lno + i];
        if (il.flag & LINE_PATCHED != 0 or preimage.lines.items[i].hash != il.hash) return false;
    }

    if (preimage_limit == pre_nr) {
        const plen = preimage.buf.items.len;
        const ok = if (match_end) current + plen == img.buf.items.len else current + plen <= img.buf.items.len;
        if (ok and std.mem.eql(u8, img.buf.items[current .. current + plen], preimage.buf.items)) return true;
    } else {
        var buf_end: usize = 0;
        i = 0;
        while (i < preimage_limit) : (i += 1) buf_end += preimage.lines.items[i].len;
        var b: usize = 0;
        while (b < buf_end) : (b += 1) {
            if (!isSpace(preimage.buf.items[b])) break;
        }
        if (b == buf_end) return false;
    }

    if (state.ws_ignore_action == .change)
        return lineByLineFuzzyMatch(img, preimage, postimage, current, current_lno, preimage_limit);

    if (state.ws_error_action != .correct) return false;

    var fixed: Buf = .empty;
    var orig: usize = 0;
    var target: usize = current;
    i = 0;
    while (i < preimage_limit) : (i += 1) {
        const oldlen = preimage.lines.items[i].len;
        const tgtlen = img.lines.items[current_lno + i].len;
        const fixstart = fixed.items.len;
        diff.wsFixCopy(&fixed, preimage.buf.items[orig .. orig + oldlen], ws_rule, null);
        var tgtfix: Buf = .empty;
        diff.wsFixCopy(&tgtfix, img.buf.items[target .. target + tgtlen], ws_rule, null);
        if (!std.mem.eql(u8, tgtfix.items, fixed.items[fixstart..])) return false;
        orig += oldlen;
        target += tgtlen;
    }
    while (i < pre_nr) : (i += 1) {
        const fixstart = fixed.items.len;
        const oldlen = preimage.lines.items[i].len;
        diff.wsFixCopy(&fixed, preimage.buf.items[orig .. orig + oldlen], ws_rule, null);
        for (fixed.items[fixstart..]) |c| {
            if (!isSpace(c)) return false;
        }
        orig += oldlen;
    }
    updatePrePostImages(preimage, postimage, fixed.items);
    return true;
}

fn findPos(state: *State, img: *Image, preimage: *Image, postimage: *Image, line0: i64, ws_rule: u32, match_beginning0: bool, match_end: bool) i64 {
    var match_beginning = match_beginning0;
    const img_nr = img.lines.items.len;
    if (state.allow_overlap and match_beginning and match_end and img_nr != preimage.lines.items.len)
        match_beginning = false;
    var line = line0;
    if (match_beginning) {
        line = 0;
    } else if (match_end) {
        line = @as(i64, @intCast(img_nr)) - @as(i64, @intCast(preimage.lines.items.len));
    }
    if (line < 0 or line > @as(i64, @intCast(img_nr))) line = @intCast(img_nr);
    const uline: usize = @intCast(line);
    var current: usize = 0;
    for (img.lines.items[0..uline]) |l| current += l.len;

    var backwards = current;
    var backwards_lno = uline;
    var forwards = current;
    var forwards_lno = uline;
    var current_lno = uline;

    var i: usize = 0;
    while (true) : (i += 1) {
        if (matchFragment(state, img, preimage, postimage, current, current_lno, ws_rule, match_beginning, match_end))
            return @intCast(current_lno);
        while (true) {
            if (backwards_lno == 0 and forwards_lno == img_nr) return -1;
            if (i & 1 != 0) {
                if (backwards_lno == 0) {
                    i += 1;
                    continue;
                }
                backwards_lno -= 1;
                backwards -= img.lines.items[backwards_lno].len;
                current = backwards;
                current_lno = backwards_lno;
            } else {
                if (forwards_lno == img_nr) {
                    i += 1;
                    continue;
                }
                forwards += img.lines.items[forwards_lno].len;
                forwards_lno += 1;
                current = forwards;
                current_lno = forwards_lno;
            }
            break;
        }
    }
}

fn updateImage(state: *State, img: *Image, applied_pos: usize, preimage: *Image, postimage: *Image) void {
    var preimage_limit = preimage.lines.items.len;
    const img_nr = img.lines.items.len;
    if (preimage_limit > img_nr - applied_pos) preimage_limit = img_nr - applied_pos;
    var applied_at: usize = 0;
    for (img.lines.items[0..applied_pos]) |l| applied_at += l.len;
    var remove_count: usize = 0;
    for (img.lines.items[applied_pos .. applied_pos + preimage_limit]) |l| remove_count += l.len;
    img.buf.replaceRange(gpa, applied_at, remove_count, postimage.buf.items) catch util.oom();
    img.lines.replaceRange(gpa, applied_pos, preimage_limit, postimage.lines.items) catch util.oom();
    if (!state.allow_overlap) {
        for (img.lines.items[applied_pos .. applied_pos + postimage.lines.items.len]) |*l| l.flag |= LINE_PATCHED;
    }
}

fn applyOneFragment(state: *State, img: *Image, frag: *Fragment, inaccurate_eof: bool, ws_rule: u32, nth_fragment: i32) bool {
    var patch = frag.patch;
    var size: usize = patch.len;
    var oldlines: Buf = .empty;
    var newlines: Buf = .empty;
    var new_blank_lines_at_end: i32 = 0;
    var found_new_blank_lines_at_end: i32 = 0;
    var hunk_linenr = frag.linenr;
    var preimage = Image{};
    var postimage = Image{};
    var applied_pos: i64 = -1;

    while (size > 0) {
        const len = linelen(patch, size);
        if (len == 0) break;
        var plen: i64 = @as(i64, @intCast(len)) - 1;
        if (len < size and patch[len] == '\\') plen -= 1;
        var first = patch[0];
        if (state.apply_in_reverse) {
            if (first == '-') {
                first = '+';
            } else if (first == '+') first = '-';
        }
        var added_blank_line = false;
        var is_blank_context = false;
        const pl: usize = if (plen < 0) 0 else @intCast(plen);
        const body = if (len >= 1) patch[1 .. 1 + pl] else patch[0..0];
        switch (first) {
            '\n' => {
                if (plen >= 0) {
                    util.bufByte(&oldlines, '\n');
                    util.bufByte(&newlines, '\n');
                    imageAddLine(&preimage, "\n", LINE_COMMON);
                    imageAddLine(&postimage, "\n", LINE_COMMON);
                    is_blank_context = true;
                }
            },
            ' ', '-', '+' => {
                if (first == ' ' and pl != 0 and ws_rule & diff.WS_BLANK_AT_EOF != 0 and diff.wsBlankLine(body))
                    is_blank_context = true;
                if (first != '+') {
                    util.bufAppend(&oldlines, body);
                    imageAddLine(&preimage, body, if (first == ' ') LINE_COMMON else 0);
                }
                if (first != '-' and !(first == '+' and state.no_add)) {
                    const start = newlines.items.len;
                    if (first != '+' or state.whitespace_error == 0 or state.ws_error_action != .correct) {
                        util.bufAppend(&newlines, body);
                    } else {
                        var cnt: usize = @intCast(state.applied_after_fixing_ws);
                        diff.wsFixCopy(&newlines, body, ws_rule, &cnt);
                        state.applied_after_fixing_ws = @intCast(cnt);
                    }
                    imageAddLine(&postimage, newlines.items[start..], if (first == '+') 0 else LINE_COMMON);
                    if (first == '+' and ws_rule & diff.WS_BLANK_AT_EOF != 0 and diff.wsBlankLine(body))
                        added_blank_line = true;
                }
            },
            '@', '\\' => {},
            else => {
                if (state.apply_verbosity > VERBOSITY_NORMAL)
                    _ = errorf("invalid start of line: '{c}'", .{first});
                return true;
            },
        }
        if (added_blank_line) {
            if (new_blank_lines_at_end == 0) found_new_blank_lines_at_end = hunk_linenr;
            new_blank_lines_at_end += 1;
        } else if (is_blank_context) {} else new_blank_lines_at_end = 0;
        patch = patch[len..];
        size -= len;
        hunk_linenr += 1;
    }
    if (inaccurate_eof and oldlines.items.len > 0 and oldlines.items[oldlines.items.len - 1] == '\n' and
        newlines.items.len > 0 and newlines.items[newlines.items.len - 1] == '\n')
    {
        oldlines.items.len -= 1;
        newlines.items.len -= 1;
        preimage.lines.items[preimage.lines.items.len - 1].len -= 1;
        postimage.lines.items[postimage.lines.items.len - 1].len -= 1;
    }

    var leading = frag.leading;
    var trailing = frag.trailing;
    var match_beginning = frag.oldpos == 0 or (frag.oldpos == 1 and !state.unidiff_zero);
    var match_end = !state.unidiff_zero and trailing == 0;
    var pos: i64 = if (frag.newpos != 0) frag.newpos - 1 else 0;
    util.bufAppend(&preimage.buf, oldlines.items);
    postimage.buf = newlines;

    while (true) {
        applied_pos = findPos(state, img, &preimage, &postimage, pos, ws_rule, match_beginning, match_end);
        if (applied_pos >= 0) break;
        if (leading <= state.p_context and trailing <= state.p_context) break;
        if (match_beginning or match_end) {
            match_beginning = false;
            match_end = false;
            continue;
        }
        if (leading >= trailing) {
            imageRemoveFirstLine(&preimage);
            imageRemoveFirstLine(&postimage);
            pos -= 1;
            leading -= 1;
        }
        if (trailing > leading) {
            imageRemoveLastLine(&preimage);
            imageRemoveLastLine(&postimage);
            trailing -= 1;
        }
    }

    if (applied_pos >= 0) {
        const ap: usize = @intCast(applied_pos);
        if (new_blank_lines_at_end != 0 and preimage.lines.items.len + ap >= img.lines.items.len and
            ws_rule & diff.WS_BLANK_AT_EOF != 0 and state.ws_error_action != .nowarn)
        {
            recordWsError(state, diff.WS_BLANK_AT_EOF, "+", 1, found_new_blank_lines_at_end);
            if (state.ws_error_action == .correct) {
                while (new_blank_lines_at_end > 0) : (new_blank_lines_at_end -= 1) imageRemoveLastLine(&postimage);
            }
            if (state.ws_error_action == .die) state.apply = false;
        }
        if (state.apply_verbosity > VERBOSITY_NORMAL and applied_pos != pos) {
            var offset = applied_pos - pos;
            if (state.apply_in_reverse) offset = 0 - offset;
            if (offset == 1 or offset == -1) {
                util.eprint("Hunk #{d} succeeded at {d} (offset {d} line).\n", .{ nth_fragment, applied_pos + 1, offset });
            } else util.eprint("Hunk #{d} succeeded at {d} (offset {d} lines).\n", .{ nth_fragment, applied_pos + 1, offset });
        }
        if ((leading != frag.leading or trailing != frag.trailing) and state.apply_verbosity > VERBOSITY_SILENT)
            util.eprint("Context reduced to ({d}/{d}) to apply fragment at {d}\n", .{ leading, trailing, applied_pos + 1 });
        updateImage(state, img, ap, &preimage, &postimage);
    } else {
        if (state.apply_verbosity > VERBOSITY_NORMAL)
            _ = errorf("while searching for:\n{s}", .{oldlines.items});
    }
    return applied_pos < 0;
}

fn applyBinaryFragment(state: *State, img: *Image, patch: *Patch) i32 {
    var fragment = patch.fragments orelse
        return errorf("missing binary patch data for '{s}'", .{patch.new_name orelse patch.old_name.?});
    if (state.apply_in_reverse) {
        fragment = fragment.next orelse
            return errorf("cannot reverse-apply a binary patch without the reverse hunk to '{s}'", .{patch.new_name orelse patch.old_name.?});
    }
    switch (fragment.leading) {
        BINARY_DELTA_DEFLATED => {
            const dst = odb_mod.applyDelta(img.buf.items, fragment.patch) orelse return -1;
            img.clear();
            util.bufAppend(&img.buf, dst);
            return 0;
        },
        BINARY_LITERAL_DEFLATED => {
            img.clear();
            util.bufAppend(&img.buf, fragment.patch);
            return 0;
        },
        else => return -1,
    }
}

fn applyBinary(state: *State, img: *Image, patch: *Patch) i32 {
    const name = patch.old_name orelse patch.new_name.?;
    if (patch.old_oid_prefix.len != hash.HEXSZ or patch.new_oid_prefix.len != hash.HEXSZ or
        hash.fromHex(patch.old_oid_prefix) == null or hash.fromHex(patch.new_oid_prefix) == null)
        return errorf("cannot apply binary patch to '{s}' without full index line", .{name});
    if (patch.old_name != null) {
        const oid = odb_mod.hashObject(.blob, img.buf.items);
        const hx = hash.hex(oid);
        if (!util.eql(&hx, patch.old_oid_prefix))
            return errorf("the patch applies to '{s}' ({s}), which does not match the current contents.", .{ name, &hx });
    } else {
        if (img.buf.items.len != 0)
            return errorf("the patch applies to an empty '{s}' but it is not empty", .{name});
    }
    const oid = hash.fromHex(patch.new_oid_prefix).?;
    if (hash.isZero(oid)) {
        img.clear();
        return 0;
    }
    const odb = repo_mod.repo().odb();
    if (odb.has(oid)) {
        const obj = odb.read(oid) orelse
            return errorf("the necessary postimage {s} for '{s}' cannot be read", .{ patch.new_oid_prefix, name });
        img.clear();
        util.bufAppend(&img.buf, obj.data);
    } else {
        if (applyBinaryFragment(state, img, patch) != 0)
            return errorf("binary patch does not apply to '{s}'", .{name});
        const got = odb_mod.hashObject(.blob, img.buf.items);
        const hx = hash.hex(got);
        if (!util.eql(&hx, patch.new_oid_prefix))
            return errorf("binary patch to '{s}' creates incorrect result (expecting {s}, got {s})", .{ name, patch.new_oid_prefix, &hx });
    }
    return 0;
}

fn applyFragments(state: *State, img: *Image, patch: *Patch) i32 {
    const name = patch.old_name orelse patch.new_name.?;
    if (patch.is_binary) return applyBinary(state, img, patch);
    var frag = patch.fragments;
    var nth: i32 = 0;
    while (frag) |f| : (frag = f.next) {
        nth += 1;
        if (applyOneFragment(state, img, f, patch.inaccurate_eof, patch.ws_rule, nth)) {
            _ = errorf("patch failed: {s}:{d}", .{ name, f.oldpos });
            if (!state.apply_with_reject) return -1;
            f.rejected = true;
        }
    }
    return 0;
}

fn readBlobObject(buf: *Buf, oid: Oid, mode: u32) i32 {
    if (mode & 0o170000 == 0o160000) {
        util.bufPrint(buf, "Subproject commit {s}\n", .{&hash.hex(oid)});
    } else {
        const obj = repo_mod.repo().odb().read(oid) orelse return -1;
        util.bufAppend(buf, obj.data);
    }
    return 0;
}
