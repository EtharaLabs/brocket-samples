//! Port of unpack-trees.c (unpack_trees, merge functions, porcelain error
//! messages, worktree verification and update) plus the WRITE_TREE_REPAIR
//! cache-tree update from cache-tree.c that unpack_trees performs afterwards.
//!
//! Tree traversal is emulated by flattening all trees into a sorted list of
//! paths (files and directories) and walking it in path order, computing the
//! directory/file conflict masks that traverse_trees() would have produced.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const index_mod = @import("index.zig");
const objects = @import("objects.zig");
const odb_mod = @import("odb.zig");
const dir_mod = @import("dir.zig");
const advice = @import("advice.zig");
const sparse_mod = @import("sparse.zig");
const sparse_index_mod = @import("sparse_index.zig");
const submodule = @import("submodule.zig");
pub const entry = @import("entry.zig");
const gpa = util.gpa;

const Oid = hash.Oid;
const Entry = index_mod.Entry;
const Index = index_mod.Index;
const CacheTree = index_mod.CacheTree;

pub const MAX_UNPACK_TREES = 8;

// in-core flags kept in Entry.uflags
pub const CE_UPDATE: u32 = 1 << 0;
pub const CE_REMOVE: u32 = 1 << 1;
pub const CE_WT_REMOVE: u32 = 1 << 2;
pub const CE_CONFLICTED: u32 = 1 << 3;
pub const CE_ADDED: u32 = 1 << 4;
pub const CE_UNPACKED: u32 = 1 << 5;
pub const CE_NEW_SKIP_WORKTREE: u32 = 1 << 6;

pub const ErrorType = enum(u8) {
    would_overwrite = 0,
    not_uptodate_file,
    not_uptodate_dir,
    cwd_in_the_way,
    would_lose_untracked_overwritten,
    would_lose_untracked_removed,
    bind_overlap,
    would_lose_submodule,
    warning_sparse_not_uptodate,
    warning_sparse_unmerged,
    warning_sparse_orphaned,
};
pub const NB_ERRORS = 8;
const NB_ALL = 11;

const plumbing_errors = [NB_ALL][]const u8{
    "Entry '%s' would be overwritten by merge. Cannot merge.",
    "Entry '%s' not uptodate. Cannot merge.",
    "Updating '%s' would lose untracked files in it",
    "Refusing to remove '%s' since it is the current working directory.",
    "Untracked working tree file '%s' would be overwritten by merge.",
    "Untracked working tree file '%s' would be removed by merge.",
    "Entry '%s' overlaps with '%s'.  Cannot bind.",
    "Submodule '%s' cannot checkout new HEAD.",
    "Path '%s' not uptodate; will not remove from working tree.",
    "Path '%s' unmerged; will not remove from working tree.",
    "Path '%s' already present; will not overwrite with sparse update.",
};

pub const ResetType = enum { none, protect_untracked, overwrite_untracked };

pub const MergeFn = *const fn (src: []const ?*const Entry, o: *Options) i32;

/// Sentinel passed to merge functions for a directory/file conflict.
pub var df_conflict_entry: Entry = .{ .path = "" };

pub fn isDf(e: ?*const Entry) bool {
    return e != null and e.? == &df_conflict_entry;
}

pub const Options = struct {
    merge: bool = false,
    update: bool = false,
    skip_sparse_checkout: bool = false,
    preserve_ignored: bool = false,
    clone: bool = false,
    index_only: bool = false,
    trivial_merges_only: bool = false,
    verbose_update: bool = false,
    aggressive: bool = false,
    skip_unmerged: bool = false,
    initial_checkout: bool = false,
    quiet: bool = false,
    exiting_early: bool = false,
    dry_run: bool = false,
    skip_cache_tree_update: bool = false,
    reset: ResetType = .none,
    prefix: ?[]const u8 = null,
    super_prefix: ?[]const u8 = null,
    func: ?MergeFn = null,
    head_idx: usize = 0,
    src_index: ?*Index = null,
    dst_index: ?*Index = null,
    unpack_data: ?*anyopaque = null,
    /// checkout metadata for process filters (init_checkout_metadata)
    meta: @import("convert.zig").Meta = .{},

    // ---- internal ----
    nontrivial_merge: bool = false,
    show_all_errors: bool = false,
    merge_size: usize = 0,
    msgs: [NB_ALL]?[]const u8 = @splat(null),
    rejects: [NB_ALL]std.ArrayList([]const u8) = @splat(.empty),
    result: Index = .{},
    dir: ?*dir_mod.Dir = null,
};

// ---------------- messages ----------------

fn errorMsg(o: *const Options, e: ErrorType) []const u8 {
    return o.msgs[@intFromEnum(e)] orelse plumbing_errors[@intFromEnum(e)];
}

/// Substitute successive "%s" in tmpl with args ("%%" -> "%").
fn subst(tmpl: []const u8, args: []const []const u8) []u8 {
    var b: util.Buf = .empty;
    var i: usize = 0;
    var k: usize = 0;
    while (i < tmpl.len) {
        if (tmpl[i] == '%' and i + 1 < tmpl.len and tmpl[i + 1] == 's') {
            if (k < args.len) util.bufAppend(&b, args[k]);
            k += 1;
            i += 2;
        } else if (tmpl[i] == '%' and i + 1 < tmpl.len and tmpl[i + 1] == '%') {
            util.bufByte(&b, '%');
            i += 2;
        } else {
            util.bufByte(&b, tmpl[i]);
            i += 1;
        }
    }
    return b.items;
}

fn superPrefixed(o: *const Options, path: []const u8) []const u8 {
    if (o.super_prefix) |sp| return util.concat(&.{ sp, path });
    return path;
}

/// setup_unpack_trees_porcelain()
pub fn setupPorcelain(o: *Options, cmd: []const u8) void {
    const adv = advice.enabled("commitBeforeMerge");
    const action: []const u8 = if (util.eql(cmd, "checkout")) "switch branches" else cmd;
    const ow = util.concat(&.{
        "Your local changes to the following files would be overwritten by ", cmd, ":\n%s",
        if (adv) util.concat(&.{ "Please commit your changes or stash them before you ", action, "." }) else "",
    });
    o.msgs[@intFromEnum(ErrorType.would_overwrite)] = ow;
    o.msgs[@intFromEnum(ErrorType.not_uptodate_file)] = ow;
    o.msgs[@intFromEnum(ErrorType.not_uptodate_dir)] = "Updating the following directories would lose untracked files in them:\n%s";
    o.msgs[@intFromEnum(ErrorType.cwd_in_the_way)] = "Refusing to remove the current working directory:\n%s";
    const tail = if (adv) util.concat(&.{ "Please move or remove them before you ", action, "." }) else "";
    o.msgs[@intFromEnum(ErrorType.would_lose_untracked_removed)] = util.concat(&.{
        "The following untracked working tree files would be removed by ", cmd, ":\n%s", tail,
    });
    o.msgs[@intFromEnum(ErrorType.would_lose_untracked_overwritten)] = util.concat(&.{
        "The following untracked working tree files would be overwritten by ", cmd, ":\n%s", tail,
    });
    o.msgs[@intFromEnum(ErrorType.bind_overlap)] = "Entry '%s' overlaps with '%s'.  Cannot bind.";
    o.msgs[@intFromEnum(ErrorType.would_lose_submodule)] = "Cannot update submodule:\n%s";
    o.msgs[@intFromEnum(ErrorType.warning_sparse_not_uptodate)] = "The following paths are not up to date and were left despite sparse patterns:\n%s";
    o.msgs[@intFromEnum(ErrorType.warning_sparse_unmerged)] = "The following paths are unmerged and thus cannot be updated despite sparse patterns:\n%s";
    o.msgs[@intFromEnum(ErrorType.warning_sparse_orphaned)] = "The following paths were already present and thus not updated despite sparse patterns:\n%s";
    o.show_all_errors = true;
}

fn addRejectedPath(o: *Options, e: ErrorType, path: []const u8) i32 {
    if (o.quiet) return -1;
    if (!o.show_all_errors) {
        util.err("{s}", .{subst(errorMsg(o, e), &.{superPrefixed(o, path)})});
        return -1;
    }
    o.rejects[@intFromEnum(e)].append(gpa, util.dupe(path)) catch util.oom();
    return -1;
}

fn displayErrorMsgs(o: *Options) void {
    var shown = false;
    for (0..NB_ERRORS) |e| {
        const list = &o.rejects[e];
        if (list.items.len > 0) {
            shown = true;
            var b: util.Buf = .empty;
            for (list.items) |p| util.bufPrint(&b, "\t{s}\n", .{p});
            util.err("{s}", .{subst(errorMsg(o, @enumFromInt(e)), &.{superPrefixed(o, b.items)})});
        }
        list.clearRetainingCapacity();
    }
    if (shown) util.ewrite("Aborting\n");
}

fn unpackFailed(o: *Options, message: ?[]const u8) i32 {
    o.result = .{};
    if (!o.quiet and !o.exiting_early) {
        if (message) |m| util.err("{s}", .{m});
    }
    return -1;
}

// ---------------- cache-tree helpers ----------------

/// cache_tree_invalidate_path(): also drops a subtree named like the leaf.
pub fn cacheTreeInvalidate(t: ?*CacheTree, path: []const u8) void {
    const it = t orelse return;
    it.entry_count = -1;
    if (std.mem.indexOfScalar(u8, path, '/')) |sl| {
        if (it.find(path[0..sl])) |c| cacheTreeInvalidate(c, path[sl + 1 ..]);
    } else {
        for (it.children.items, 0..) |c, i| {
            if (util.eql(c.name, path)) {
                _ = it.children.orderedRemove(i);
                break;
            }
        }
    }
}

fn invalidateCePath(o: *Options, path: []const u8) void {
    cacheTreeInvalidate(o.src_index.?.cache_tree, path);
}

var empty_tree_oid: ?Oid = null;
var empty_blob_oid: ?Oid = null;

fn odbHas(oid: Oid) bool {
    if (empty_tree_oid == null) {
        empty_tree_oid = hash.fromHex(hash.empty_tree_hex).?;
        empty_blob_oid = hash.fromHex(hash.empty_blob_hex).?;
    }
    if (hash.eql(oid, empty_tree_oid.?) or hash.eql(oid, empty_blob_oid.?)) return true;
    return repo_mod.repo().odb().has(oid);
}

fn fullyValid(t: ?*CacheTree) bool {
    const it = t orelse return false;
    if (it.entry_count < 0 or !odbHas(it.oid)) return false;
    for (it.children.items) |c| {
        if (!fullyValid(c)) return false;
    }
    return true;
}

/// cache_tree_update(istate, WRITE_TREE_SILENT | WRITE_TREE_REPAIR):
/// recompute tree oids without writing objects; records an oid only when
/// the tree object already exists. Returns false on failure.
pub fn cacheTreeUpdateRepair(idx: *Index) bool {
    for (idx.entries.items) |e| {
        if (e.stage() != 0) return false;
    }
    if (idx.cache_tree == null) {
        const t = gpa.create(CacheTree) catch util.oom();
        t.* = .{};
        idx.cache_tree = t;
    }
    const r = updateOne(idx.cache_tree.?, idx.entries.items, "");
    if (r < 0) return false;
    idx.changed = true;
    return true;
}

fn updateOne(it: *CacheTree, ents: []const Entry, base: []const u8) i32 {
    if (it.entry_count >= 0 and odbHas(it.oid)) return it.entry_count;
    // a sparse directory entry is a leaf of the cache tree
    if (base.len > 0 and ents.len > 0 and sparse_index_mod.isSparseDir(&ents[0]) and std.mem.eql(u8, ents[0].path, base)) {
        it.entry_count = 1;
        it.oid = ents[0].oid;
        return 1;
    }

    var used: std.ArrayList(*CacheTree) = .empty;
    var counts: std.ArrayList(usize) = .empty;
    var i: usize = 0;
    while (i < ents.len) {
        const p = ents[i].path;
        if (p.len <= base.len or !util.startsWith(p, base)) break;
        const rest = p[base.len..];
        const sl = std.mem.indexOfScalar(u8, rest, '/') orelse {
            i += 1;
            continue;
        };
        const sub = it.findOrCreate(rest[0..sl]);
        const subcnt = updateOne(sub, ents[i..], p[0 .. base.len + sl + 1]);
        if (subcnt < 0) return subcnt;
        if (subcnt == 0) util.die("index cache-tree records empty sub-tree", .{});
        i += @intCast(subcnt);
        used.append(gpa, sub) catch util.oom();
        counts.append(gpa, @intCast(subcnt)) catch util.oom();
    }
    // discard unused subtrees
    var ci: usize = 0;
    while (ci < it.children.items.len) {
        const c = it.children.items[ci];
        if (std.mem.indexOfScalar(*CacheTree, used.items, c) == null) {
            _ = it.children.orderedRemove(ci);
        } else ci += 1;
    }

    var tes: std.ArrayList(objects.TreeEntry) = .empty;
    var to_invalidate = false;
    i = 0;
    while (i < ents.len) {
        const e = &ents[i];
        const p = e.path;
        if (p.len <= base.len or !util.startsWith(p, base)) break;
        const rest = p[base.len..];
        var oid: Oid = undefined;
        var mode: u32 = undefined;
        var entlen: usize = undefined;
        var is_sub = false;
        var contains_ita = false;
        var expected_missing = false;
        if (std.mem.indexOfScalar(u8, rest, '/')) |sl| {
            entlen = sl;
            const sub = it.find(rest[0..sl]) orelse util.die("cache-tree.c: '{s}' in '{s}' not found", .{ rest[0..sl], p });
            const k = std.mem.indexOfScalar(*CacheTree, used.items, sub).?;
            i += counts.items[k];
            oid = sub.oid;
            mode = os.S_IFDIR;
            is_sub = true;
            contains_ita = sub.entry_count < 0;
            if (contains_ita) {
                to_invalidate = true;
                expected_missing = true;
            }
        } else {
            oid = e.oid;
            mode = e.mode;
            entlen = rest.len;
            i += 1;
        }
        const missing_ok = mode == os.S_IFGITLINK or (!is_sub and e.skipWorktree() and @import("promisor.zig").hasRemote());
        if (hash.isZero(oid) or (!missing_ok and !odbHas(oid))) {
            if (expected_missing) return -1;
            util.err("invalid object {o:0>6} {s} for '{s}'", .{ mode, &hash.hex(oid), p[0 .. base.len + entlen] });
            return -1;
        }
        if (e.uflags & CE_REMOVE != 0) continue;
        if (!is_sub and e.intentToAdd()) {
            to_invalidate = true;
            continue;
        }
        if (contains_ita and hash.eql(oid, empty_tree_oid.?)) continue;
        tes.append(gpa, .{ .mode = mode, .name = rest[0..entlen], .oid = oid }) catch util.oom();
    }
    const toid = odb_mod.hashObject(.tree, objects.formatTree(tes.items));
    if (odbHas(toid)) it.oid = toid else to_invalidate = true;
    it.entry_count = if (to_invalidate) -1 else @intCast(i);
    return @intCast(i);
}

// ---------------- result index ----------------

/// add_index_entry(result, ce, ADD_CACHE_OK_TO_ADD|ADD_CACHE_OK_TO_REPLACE)
fn addResult(idx: *Index, ce: Entry) bool {
    const stg = ce.stage();
    // set_index_entry(): a sparse directory entry makes the index sparse
    defer if (sparse_index_mod.isSparseDir(&ce)) {
        idx.sparse_index = true;
        idx.sparse_partial = false;
    };
    var at: usize = switch (idx.pos(ce.path, stg)) {
        .found => |i| {
            idx.entries.items[i] = ce;
            return true;
        },
        .missing => |i| i,
    };
    if (stg == 0) {
        while (at < idx.entries.items.len and util.eql(idx.entries.items[at].path, ce.path)) {
            _ = idx.entries.orderedRemove(at);
        }
    }
    if (!verifyPathFull(ce.path, ce.mode)) {
        util.err("invalid path '{s}'", .{ce.path});
        return false;
    }
    // check_file_directory_conflict(): "I am going away" entries skip the D/F checks
    if (ce.uflags & CE_REMOVE != 0) {
        idx.entries.insert(gpa, at, ce) catch util.oom();
        return true;
    }
    // has_file_name(): entries "path/..." at the same stage
    var removed_any = false;
    {
        var k = at;
        while (k < idx.entries.items.len) {
            const p = &idx.entries.items[k];
            if (ce.path.len >= p.path.len or !util.startsWith(p.path, ce.path)) break;
            if (p.stage() != stg or p.path[ce.path.len] != '/' or p.uflags & CE_REMOVE != 0) {
                k += 1;
                continue;
            }
            _ = idx.entries.orderedRemove(k);
            removed_any = true;
        }
    }
    // has_dir_name(): leading directories present as entries
    var s: usize = 0;
    while (std.mem.indexOfScalarPos(u8, ce.path, s, '/')) |sl| {
        switch (idx.pos(ce.path[0..sl], stg)) {
            .found => |i| {
                if (idx.entries.items[i].uflags & CE_REMOVE == 0) {
                    _ = idx.entries.orderedRemove(i);
                    removed_any = true;
                }
            },
            .missing => {},
        }
        s = sl + 1;
    }
    if (removed_any) {
        at = switch (idx.pos(ce.path, stg)) {
            .found => |i| i,
            .missing => |i| i,
        };
    }
    idx.entries.insert(gpa, at, ce) catch util.oom();
    return true;
}

/// do_add_entry(): set flags, optionally clear the stage, add to result.
fn doAddEntry(o: *Options, ce0: Entry, set0: u32, clear_stage: bool) bool {
    var ce = ce0;
    var set = set0;
    if (set & CE_REMOVE != 0) set |= CE_WT_REMOVE;
    ce.uflags |= set;
    if (clear_stage) ce.setStage(0);
    return addResult(&o.result, ce);
}

fn addEntry(o: *Options, ce: *const Entry, set: u32, clear_stage: bool) void {
    var c = ce.*;
    c.uflags &= ~CE_UNPACKED;
    _ = doAddEntry(o, c, set, clear_stage);
}

fn resultFind(o: *Options, name: []const u8) ?*Entry {
    const i = o.result.firstPos(name);
    if (i < o.result.entries.items.len and util.eql(o.result.entries.items[i].path, name)) return &o.result.entries.items[i];
    return null;
}

fn markCeUsed(ce: *const Entry) void {
    @constCast(ce).uflags |= CE_UNPACKED;
}

fn markCeUsedSameName(o: *Options, ce: *const Entry) void {
    const src = o.src_index.?;
    var i = src.firstPosNoExpand(ce.path);
    while (i < src.entries.items.len and util.eql(src.entries.items[i].path, ce.path)) : (i += 1) {
        src.entries.items[i].uflags |= CE_UNPACKED;
    }
}

fn addSameUnmerged(o: *Options, ce: *const Entry) void {
    const src = o.src_index.?;
    var i = src.firstPosNoExpand(ce.path);
    while (i < src.entries.items.len and util.eql(src.entries.items[i].path, ce.path)) : (i += 1) {
        addEntry(o, &src.entries.items[i], 0, false);
        src.entries.items[i].uflags |= CE_UNPACKED;
    }
}

// ---------------- verification ----------------

fn originalCwdIs(name: []const u8) bool {
    const cwd = entry.originalCwd() orelse return false;
    return util.eql(cwd, name);
}

/// check_submodule_move_head()
fn checkSubmoduleMoveHead(ce: *const Entry, old_id: ?[]const u8, new_id: ?[]const u8, o: *Options) i32 {
    if (submodule.fromCe(ce) == null) return 0;
    var flags: u32 = submodule.MOVE_HEAD_DRY_RUN;
    if (o.reset != .none) flags |= submodule.MOVE_HEAD_FORCE;
    if (submodule.moveHead(ce.path, old_id, new_id, flags) != 0) return addRejectedPath(o, .would_lose_submodule, ce.path);
    return 0;
}

fn verifyUptodate1(ce: *const Entry, o: *Options, et: ErrorType) i32 {
    if (o.index_only) return 0;
    if (!(ce.assumeValid() or ce.skipWorktree())) {
        if (o.reset != .none or ce.uptodate) return 0;
    }
    if (os.lstatPath(ce.path)) |st| {
        const changed = entry.matchStatIgnoreValid(o.src_index, ce, st);
        if (submodule.fromCe(ce) != null) {
            const hx = hash.hex(ce.oid);
            if (checkSubmoduleMoveHead(ce, "HEAD", &hx, o) != 0) return addRejectedPath(o, et, ce.path);
            return 0;
        }
        if (changed == 0) return 0;
        if (ce.mode & os.S_IFMT == os.S_IFGITLINK) return 0;
    } else if (os.errno() == os.ENOENT) return 0;
    return addRejectedPath(o, et, ce.path);
}

/// verify_uptodate()
pub fn verifyUptodate(ce: *const Entry, o: *Options) i32 {
    if (!o.skip_sparse_checkout and ce.skipWorktree() and ce.uflags & CE_NEW_SKIP_WORKTREE != 0) return 0;
    return verifyUptodate1(ce, o, .not_uptodate_file);
}

const AbsentType = enum { completely, any_directory };

fn ceToDtype(ce: *const Entry) u8 {
    return switch (ce.mode & os.S_IFMT) {
        os.S_IFREG => dir_mod.DT_REG,
        os.S_IFLNK => dir_mod.DT_LNK,
        os.S_IFDIR, os.S_IFGITLINK => dir_mod.DT_DIR,
        else => dir_mod.DT_UNKNOWN,
    };
}

fn verifyCleanSubdirectory(ce: *const Entry, o: *Options) i32 {
    if (ce.mode & os.S_IFMT == os.S_IFGITLINK) {
        const sub_head = index_mod.gitlinkHead(ce.path);
        if (sub_head != null and hash.eql(sub_head.?, ce.oid)) return 0;
        if (submodule.fromCe(ce) == null) return 0;
        const new_hx = hash.hex(ce.oid);
        if (sub_head) |sh| {
            const old_hx = hash.hex(sh);
            return checkSubmoduleMoveHead(ce, &old_hx, &new_hx, o);
        }
        return checkSubmoduleMoveHead(ce, null, &new_hx, o);
    }
    const src = o.src_index.?;
    const name = ce.path;
    var cnt: i32 = 0;
    var i = src.firstPos(name);
    while (i < src.entries.items.len) : (i += 1) {
        const ce2 = &src.entries.items[i];
        if (ce2.path.len < name.len + 1 or !util.startsWith(ce2.path, name) or ce2.path[name.len] != '/') break;
        if (ce2.stage() == 0) {
            if (verifyUptodate(ce2, o) != 0) return -1;
            addEntry(o, ce2, CE_REMOVE, false);
            invalidateCePath(o, name);
            markCeUsed(ce2);
        }
        cnt += 1;
    }
    var d = dir_mod.Dir.init();
    if (o.dir != null) d.setupStandardExcludes();
    const n = d.readDirectory(src, util.concat(&.{ name, "/" }), null);
    if (n > 0) return addRejectedPath(o, .not_uptodate_dir, name);
    if (originalCwdIs(name)) return addRejectedPath(o, .cwd_in_the_way, name);
    return cnt;
}

fn checkOkToRemove(name: []const u8, dtype0: u8, ce: ?*const Entry, st: os.Stat, et: ErrorType, absent: AbsentType, o: *Options) i32 {
    if (o.dir) |d| {
        var dt = dtype0;
        if (d.isExcluded(name, &dt)) return 0;
    }
    if (st.isDir()) {
        if (ce) |c| {
            if (verifyCleanSubdirectory(c, o) < 0) return -1;
        }
        return 0;
    }
    if (absent == .any_directory) return 0;
    if (resultFind(o, name)) |r| {
        if (r.uflags & CE_REMOVE != 0) return 0;
    }
    return addRejectedPath(o, et, name);
}

fn verifyAbsent1(ce: *const Entry, et: ErrorType, absent: AbsentType, o: *Options) i32 {
    if (o.index_only or !o.update) return 0;
    if (o.reset == .overwrite_untracked) {
        if (originalCwdIs(ce.path)) return addRejectedPath(o, .cwd_in_the_way, ce.path);
        return 0;
    }
    const len = entry.checkLeadingPath(ce.path, false);
    if (len == 0) return 0;
    if (len > 0) {
        const path = ce.path[0..@intCast(len)];
        const st = os.lstatPath(path) orelse {
            util.err("cannot stat '{s}': {s}", .{ path, os.lastErr() });
            return -1;
        };
        if (submodule.fromCe(ce) != null) {
            const hx = hash.hex(ce.oid);
            return checkSubmoduleMoveHead(ce, &hx, null, o);
        }
        return checkOkToRemove(path, dir_mod.DT_UNKNOWN, null, st, et, absent, o);
    }
    const st = os.lstatPath(ce.path) orelse {
        const e = os.errno();
        if (e != os.ENOENT) {
            util.err("cannot stat '{s}': {s}", .{ ce.path, os.strErr(e) });
            return -1;
        }
        return 0;
    };
    if (submodule.fromCe(ce) != null) {
        const hx = hash.hex(ce.oid);
        return checkSubmoduleMoveHead(ce, &hx, null, o);
    }
    return checkOkToRemove(ce.path, ceToDtype(ce), ce, st, et, absent, o);
}

pub fn verifyAbsent(ce: *const Entry, et: ErrorType, o: *Options) i32 {
    if (!o.skip_sparse_checkout and ce.uflags & CE_NEW_SKIP_WORKTREE != 0) return 0;
    return verifyAbsent1(ce, et, .completely, o);
}

fn verifyAbsentIfDirectory(ce: *const Entry, et: ErrorType, o: *Options) i32 {
    if (!o.skip_sparse_checkout and ce.uflags & CE_NEW_SKIP_WORKTREE != 0) return 0;
    return verifyAbsent1(ce, et, .any_directory, o);
}

// ---------------- merge primitives ----------------

pub fn same(a: ?*const Entry, b: ?*const Entry) bool {
    if ((a == null) != (b == null)) return false;
    if (a == null) return true;
    if ((a.?.uflags | b.?.uflags) & CE_CONFLICTED != 0) return false;
    return a.?.mode == b.?.mode and hash.eql(a.?.oid, b.?.oid);
}

pub fn rejectMerge(ce: *const Entry, o: *Options) i32 {
    return addRejectedPath(o, .would_overwrite, ce.path);
}

pub fn mergedEntry(ce: *const Entry, old: ?*const Entry, o: *Options) i32 {
    var update: u32 = CE_UPDATE;
    var merge = ce.*;
    merge.uflags &= ~CE_UNPACKED;
    if (old == null) {
        update |= CE_ADDED;
        merge.uflags |= CE_NEW_SKIP_WORKTREE;
        if (verifyAbsent(&merge, .would_lose_untracked_overwritten, o) != 0) return -1;
        invalidateCePath(o, merge.path);
        if (submodule.fromCe(ce) != null and os.exists(ce.path)) {
            const hx = hash.hex(ce.oid);
            const ret = checkSubmoduleMoveHead(ce, null, &hx, o);
            if (ret != 0) return ret;
        }
    } else if (old.?.uflags & CE_CONFLICTED == 0) {
        const od = old.?;
        if (same(od, &merge)) {
            const p = merge.path;
            merge = od.*;
            merge.path = p;
            merge.uflags &= ~CE_UNPACKED;
            update = 0;
        } else {
            if (verifyUptodate(od, o) != 0) return -1;
            if (od.skipWorktree()) merge.ext_flags |= index_mod.CE_SKIP_WORKTREE;
            merge.uflags |= od.uflags & CE_NEW_SKIP_WORKTREE;
            invalidateCePath(o, od.path);
        }
        if (submodule.fromCe(ce) != null and os.exists(ce.path)) {
            const ohx = hash.hex(od.oid);
            const nhx = hash.hex(ce.oid);
            const ret = checkSubmoduleMoveHead(ce, &ohx, &nhx, o);
            if (ret != 0) return ret;
        }
    } else {
        if (verifyAbsentIfDirectory(&merge, .would_lose_untracked_overwritten, o) != 0) return -1;
        invalidateCePath(o, old.?.path);
    }
    if (!doAddEntry(o, merge, update, true)) return -1;
    return 1;
}

pub fn deletedEntry(ce: *const Entry, old: ?*const Entry, o: *Options) i32 {
    if (old == null) {
        if (verifyAbsent(ce, .would_lose_untracked_removed, o) != 0) return -1;
        return 0;
    } else if (verifyAbsentIfDirectory(ce, .would_lose_untracked_removed, o) != 0) {
        return -1;
    }
    if (old.?.uflags & CE_CONFLICTED == 0 and verifyUptodate(old.?, o) != 0) return -1;
    addEntry(o, ce, CE_REMOVE, false);
    invalidateCePath(o, ce.path);
    return 1;
}

pub fn keepEntry(ce: *const Entry, o: *Options) i32 {
    addEntry(o, ce, 0, false);
    if (ce.stage() != 0) invalidateCePath(o, ce.path);
    return 1;
}

// ---------------- merge functions ----------------

pub fn threewayMerge(stages: []const ?*const Entry, o: *Options) i32 {
    const hi = o.head_idx;
    var remote = stages[hi + 1];
    var head = stages[hi];
    const index = stages[0];
    var head_match: usize = 0;
    var remote_match: usize = 0;
    var df_conflict_head = false;
    var df_conflict_remote = false;
    var any_anc_missing = false;
    var no_anc_exists = true;

    var i: usize = 1;
    while (i < hi) : (i += 1) {
        if (stages[i] == null or isDf(stages[i])) any_anc_missing = true else no_anc_exists = false;
    }
    if (isDf(head)) {
        df_conflict_head = true;
        head = null;
    }
    if (isDf(remote)) {
        df_conflict_remote = true;
        remote = null;
    }

    if (!same(remote, head)) {
        i = 1;
        while (i < hi) : (i += 1) {
            if (same(stages[i], head)) head_match = i;
            if (same(stages[i], remote)) remote_match = i;
        }
    }

    // #14, #14ALT, #2ALT
    if (remote != null and !df_conflict_head and head_match != 0 and remote_match == 0) {
        if (index != null and !same(index, remote) and !same(index, head)) {
            if (sparse_index_mod.isSparseDir(index.?)) return mergedSparseDir(stages, 4, o);
            return rejectMerge(index.?, o);
        }
        return mergedEntry(remote.?, index, o);
    }
    if (index != null and !same(index, head)) {
        if (sparse_index_mod.isSparseDir(index.?)) return mergedSparseDir(stages, 4, o);
        return rejectMerge(index.?, o);
    }

    if (head) |h| {
        // #5ALT, #15
        if (same(h, remote)) return mergedEntry(h, index, o);
        // #13, #3ALT
        if (!df_conflict_remote and remote_match != 0 and head_match == 0) return mergedEntry(h, index, o);
    }

    // #1
    if (head == null and remote == null and any_anc_missing) return 0;

    if (o.aggressive) {
        const head_deleted = head == null;
        const remote_deleted = remote == null;
        var ce: ?*const Entry = null;
        if (index != null) {
            ce = index;
        } else if (head != null) {
            ce = head;
        } else if (remote != null) {
            ce = remote;
        } else {
            i = 1;
            while (i < hi) : (i += 1) {
                if (stages[i] != null and !isDf(stages[i])) {
                    ce = stages[i];
                    break;
                }
            }
        }
        if ((head_deleted and remote_deleted) or
            (head_deleted and remote != null and remote_match != 0) or
            (remote_deleted and head != null and head_match != 0))
        {
            if (index) |ix| return deletedEntry(ix, ix, o);
            if (ce != null and !head_deleted) {
                if (verifyAbsent(ce.?, .would_lose_untracked_removed, o) != 0) return -1;
            }
            return 0;
        }
        if (no_anc_exists and head != null and remote != null and same(head, remote))
            return mergedEntry(head.?, index, o);
    }

    if (index) |ix| {
        // "edit/edit" inside a sparse directory: merge its contents
        if (sparse_index_mod.isSparseDir(ix)) return mergedSparseDir(stages, 4, o);
        if (verifyUptodate(ix, o) != 0) return -1;
    }

    o.nontrivial_merge = true;

    var count: i32 = 0;
    if (head_match == 0 or remote_match == 0) {
        i = 1;
        while (i < hi) : (i += 1) {
            if (stages[i] != null and !isDf(stages[i])) {
                _ = keepEntry(stages[i].?, o);
                count += 1;
                break;
            }
        }
    }
    if (head) |h| count += keepEntry(h, o);
    if (remote) |r| count += keepEntry(r, o);
    return count;
}

pub fn twowayMerge(src: []const ?*const Entry, o: *Options) i32 {
    const current = src[0];
    var oldtree = src[1];
    var newtree = src[2];
    if (o.merge_size != 2) {
        util.err("Cannot do a twoway merge of {d} trees", .{o.merge_size});
        return -1;
    }
    if (isDf(oldtree)) oldtree = null;
    if (isDf(newtree)) newtree = null;

    if (current) |cur| {
        if (cur.uflags & CE_CONFLICTED != 0) {
            if (same(oldtree, newtree) or o.reset != .none) {
                if (newtree == null) return deletedEntry(cur, cur, o);
                return mergedEntry(newtree.?, cur, o);
            }
            return rejectMerge(cur, o);
        } else if ((oldtree == null and newtree == null) or
            (oldtree == null and newtree != null and same(cur, newtree)) or
            (oldtree != null and newtree != null and same(oldtree, newtree)) or
            (oldtree != null and newtree != null and !same(oldtree, newtree) and same(cur, newtree)))
        {
            return keepEntry(cur, o);
        } else if (oldtree != null and newtree == null and same(cur, oldtree)) {
            return deletedEntry(oldtree.?, cur, o);
        } else if (oldtree != null and newtree != null and same(cur, oldtree) and !same(cur, newtree)) {
            return mergedEntry(newtree.?, cur, o);
        } else if (oldtree == null and newtree != null and
            sparse_index_mod.isSparseDir(cur) != sparse_index_mod.isSparseDir(newtree.?) and cur.stage() == 0)
        {
            // directory/file conflict across the sparse-index boundary
            return mergedEntry(newtree.?, cur, o);
        } else if (sparse_index_mod.isSparseDir(cur)) {
            // differing sparse directories: merge them file-by-file
            return mergedSparseDir(src, 3, o);
        } else return rejectMerge(cur, o);
    } else if (newtree) |nt| {
        if (oldtree != null and !o.initial_checkout) {
            if (same(oldtree, nt)) return 1;
            return rejectMerge(oldtree.?, o);
        }
        return mergedEntry(nt, null, o);
    }
    return deletedEntry(oldtree.?, null, o);
}

pub fn bindMerge(src: []const ?*const Entry, o: *Options) i32 {
    const old = src[0];
    const a = src[1];
    if (o.merge_size != 1) {
        util.err("Cannot do a bind merge of {d} trees", .{o.merge_size});
        return -1;
    }
    if (a != null and old != null) {
        if (o.quiet) return -1;
        util.err("{s}", .{subst(errorMsg(o, .bind_overlap), &.{ superPrefixed(o, a.?.path), superPrefixed(o, old.?.path) })});
        return -1;
    }
    if (a == null) return keepEntry(old.?, o);
    return mergedEntry(a.?, null, o);
}

pub fn onewayMerge(src: []const ?*const Entry, o: *Options) i32 {
    const old = src[0];
    const a = src[1];
    if (o.merge_size != 1) {
        util.err("Cannot do a oneway merge of {d} trees", .{o.merge_size});
        return -1;
    }
    if (a == null or isDf(a)) return deletedEntry(old.?, old, o);
    if (old != null and same(old, a)) {
        const od = old.?;
        var update: u32 = 0;
        if (o.reset != .none and o.update and !od.uptodate and !od.skipWorktree()) {
            if (os.lstatPath(od.path)) |st| {
                if (entry.matchStatIgnoreValid(o.src_index, od, st) != 0) update |= CE_UPDATE;
            } else update |= CE_UPDATE;
        }
        if (o.update and od.mode & os.S_IFMT == os.S_IFGITLINK and submodule.shouldUpdate() and verifyUptodate(od, o) == 0)
            update |= CE_UPDATE;
        addEntry(o, od, update, true);
        return 0;
    }
    return mergedEntry(a.?, old, o);
}

// ---------------- traversal ----------------

const TEnt = struct { mode: u32, oid: Oid };

const TreeMap = struct {
    files: std.StringHashMapUnmanaged(TEnt) = .empty,
    dirs: std.StringHashMapUnmanaged(Oid) = .empty,
};

/// Does the (sparse) index stand for the directory `p` with a sparse
/// directory entry "p/" (and no file "p")? The traversal never descends
/// into such a directory.
fn srcHasSparseDir(src: *Index, p: []const u8) bool {
    if (!src.sparse_index) return false;
    const i = src.firstPosNoExpand(p);
    if (i < src.entries.items.len and util.eql(src.entries.items[i].path, p)) return false;
    switch (src.posNoExpand(util.concat(&.{ p, "/" }), 0)) {
        .found => |k| return sparse_index_mod.isSparseDir(&src.entries.items[k]),
        .missing => return false,
    }
}

fn walkTree(oid: Oid, base: []const u8, tm: *TreeMap, names: *std.StringHashMapUnmanaged(void), sparse_src: ?*Index) void {
    const ents = objects.readTree(oid) orelse util.die("unable to read tree ({s})", .{&hash.hex(oid)});
    for (ents) |te| {
        const p = util.concat(&.{ base, te.name });
        names.put(gpa, p, {}) catch util.oom();
        if (te.isDir()) {
            tm.dirs.put(gpa, p, te.oid) catch util.oom();
            if (sparse_src) |s| {
                if (srcHasSparseDir(s, p)) continue;
            }
            walkTree(te.oid, util.concat(&.{ p, "/" }), tm, names, sparse_src);
        } else {
            tm.files.put(gpa, p, .{ .mode = index_mod.canonMode(te.mode), .oid = te.oid }) catch util.oom();
        }
    }
}

/// One level of a tree (merged_sparse_dir() never recurses on its own).
fn readTreeLevel(oid: Oid, base: []const u8, tm: *TreeMap, names: *std.StringHashMapUnmanaged(void)) void {
    const ents = objects.readTree(oid) orelse util.die("unable to read tree ({s})", .{&hash.hex(oid)});
    for (ents) |te| {
        const p = util.concat(&.{ base, te.name });
        names.put(gpa, p, {}) catch util.oom();
        if (te.isDir()) {
            tm.dirs.put(gpa, p, te.oid) catch util.oom();
        } else {
            tm.files.put(gpa, p, .{ .mode = index_mod.canonMode(te.mode), .oid = te.oid }) catch util.oom();
        }
    }
}

fn sortedNames(nameset: *std.StringHashMapUnmanaged(void)) [][]const u8 {
    var names: std.ArrayList([]const u8) = .empty;
    var kit = nameset.keyIterator();
    while (kit.next()) |k| names.append(gpa, k.*) catch util.oom();
    std.mem.sort([]const u8, names.items, {}, util.strLess);
    return names.items;
}

/// create_ce_entry(): the entry tree `i` has at `p` (a sparse directory
/// entry "p/" when it is a directory there).
fn treeEntryAt(tm: *const TreeMap, p: []const u8, stage: u32) Entry {
    var e: Entry = undefined;
    if (tm.files.get(p)) |te| {
        e = .{ .path = p, .mode = te.mode, .oid = te.oid };
    } else {
        e = .{
            .path = util.concat(&.{ p, "/" }),
            .mode = os.S_IFDIR,
            .oid = tm.dirs.get(p).?,
            .ext_flags = index_mod.CE_SKIP_WORKTREE,
        };
    }
    e.setStage(stage);
    return e;
}

fn stageFor(o: *const Options, i: usize) u32 {
    if (!o.merge) return 0;
    if (i + 1 < o.head_idx) return 1;
    if (i + 1 > o.head_idx) return 3;
    return 2;
}

/// entry_is_new_sparse_dir(): `p` (a directory in the trees) lies outside
/// the cone and neither it nor anything below it is in the index.
fn entryIsNewSparseDir(src: *Index, p: []const u8) bool {
    const dirpath = util.concat(&.{ p, "/" });
    if (sparse_index_mod.pathInConeMode(dirpath)) return false;
    switch (src.posNoExpand(dirpath, 0)) {
        .found => return false,
        .missing => |pos| {
            if (pos >= src.entries.items.len) return true;
            return !util.startsWith(src.entries.items[pos].path, dirpath);
        },
    }
}

/// merged_sparse_dir(): merge the contents of the sparse directory
/// src[0] one level down, the index side coming from the tree of src[0].
fn mergedSparseDir(src: []const ?*const Entry, n0: usize, o: *Options) i32 {
    const n = @min(n0, src.len);
    const base = src[0].?.path;
    var maps: [MAX_UNPACK_TREES + 1]TreeMap = @splat(.{});
    var nameset: std.StringHashMapUnmanaged(void) = .empty;
    for (0..n) |i| {
        const e = src[i] orelse continue;
        if (isDf(e) or hash.isZero(e.oid)) continue;
        readTreeLevel(e.oid, base, &maps[i], &nameset);
    }
    const sidx = o.src_index.?;
    var ret: i32 = 0;
    for (sortedNames(&nameset)) |p| {
        var mask: u32 = 0;
        var dirmask: u32 = 0;
        for (0..n) |i| {
            const bit = @as(u32, 1) << @intCast(i);
            if (maps[i].files.contains(p)) {
                mask |= bit;
            } else if (maps[i].dirs.contains(p)) {
                mask |= bit;
                dirmask |= bit;
            }
        }
        // unpack_sparse_callback()
        var srcs: [MAX_UNPACK_TREES + 1]?*const Entry = @splat(null);
        var tmp: [MAX_UNPACK_TREES + 1]Entry = undefined;
        if (mask & 1 != 0) {
            tmp[0] = treeEntryAt(&maps[0], p, 0);
            tmp[0].ext_flags |= index_mod.CE_SKIP_WORKTREE;
            tmp[0].uflags |= CE_NEW_SKIP_WORKTREE;
            srcs[0] = &tmp[0];
        }
        // unpack_single_entry(n - 1, mask >> 1, dirmask >> 1, src, names + 1)
        const m1 = mask >> 1;
        const d1 = dirmask >> 1;
        var is_new = false;
        if (m1 == d1 and srcs[0] == null) {
            if (!sidx.sparse_index) continue;
            is_new = entryIsNewSparseDir(sidx, p);
            if (!is_new) continue;
        }
        var conflicts = d1;
        if (m1 == d1 and (is_new or (srcs[0] != null and sparse_index_mod.isSparseDir(srcs[0].?)))) conflicts = 0;
        for (0..n - 1) |i| {
            const bit = @as(u32, 1) << @intCast(i);
            if (conflicts & bit != 0) {
                srcs[i + 1] = &df_conflict_entry;
                continue;
            }
            if (m1 & bit == 0) continue;
            tmp[i + 1] = treeEntryAt(&maps[i + 1], p, stageFor(o, i));
            srcs[i + 1] = &tmp[i + 1];
        }
        const r = callFn(srcs[0 .. o.merge_size + 1], o);
        if (r < 0) {
            ret = r;
            if (!o.show_all_errors) break;
        }
    }
    return ret;
}

fn callFn(src: []const ?*const Entry, o: *Options) i32 {
    const r = o.func.?(src, o);
    return if (r > 0) 0 else r;
}

fn unpackIndexEntry(ce: *const Entry, o: *Options) i32 {
    var src: [MAX_UNPACK_TREES + 1]?*const Entry = @splat(null);
    src[0] = ce;
    markCeUsed(ce);
    if (ce.stage() != 0 and o.skip_unmerged) {
        addEntry(o, ce, 0, false);
        return 0;
    }
    const r = callFn(src[0 .. o.merge_size + 1], o);
    if (ce.stage() != 0) markCeUsedSameName(o, ce);
    return r;
}

fn findUnused(src: *Index, path: []const u8) ?*Entry {
    var i = src.firstPosNoExpand(path);
    while (i < src.entries.items.len and util.eql(src.entries.items[i].path, path)) : (i += 1) {
        if (src.entries.items[i].uflags & CE_UNPACKED == 0) return &src.entries.items[i];
    }
    return null;
}

/// find_cache_entry()'s lookup of a sparse directory entry "path/".
fn findUnusedSparseDir(src: *Index, path: []const u8) ?*Entry {
    switch (src.posNoExpand(util.concat(&.{ path, "/" }), 0)) {
        .found => |i| {
            const e = &src.entries.items[i];
            if (sparse_index_mod.isSparseDir(e) and e.uflags & CE_UNPACKED == 0) return e;
            return null;
        },
        .missing => return null,
    }
}

/// Is some leading directory of `p` (beyond `from`) in `set`?
fn underSkipped(set: *const std.StringHashMapUnmanaged(void), p: []const u8, from: usize) bool {
    if (set.count() == 0) return false;
    var s: usize = from;
    while (std.mem.indexOfScalarPos(u8, p, s, '/')) |sl| {
        if (set.contains(p[0..sl])) return true;
        s = sl + 1;
    }
    return false;
}

/// Returns false if any callback failed.
fn traverse(trees: []const Oid, o: *Options) bool {
    const src = o.src_index.?;
    const n = trees.len;
    const prefix = blk: {
        const p0 = o.prefix orelse "";
        if (p0.len == 0 or p0[p0.len - 1] == '/') break :blk p0;
        break :blk util.concat(&.{ p0, "/" });
    };
    const m: usize = if (o.merge) 1 else 0;
    var maps: [MAX_UNPACK_TREES]TreeMap = @splat(.{});
    var nameset: std.StringHashMapUnmanaged(void) = .empty;
    const sparse_src: ?*Index = if (o.merge and src.sparse_index) src else null;
    for (trees, 0..) |t, i| walkTree(t, prefix, &maps[i], &nameset, sparse_src);
    const names = sortedNames(&nameset);

    // unpack existing index entries that sort before the prefix the tree is
    // spliced into (o.merge is always true in this case)
    if (o.merge and prefix.len > 0) {
        for (src.entries.items) |*ce| {
            if (ce.uflags & CE_UNPACKED != 0) continue;
            if (util.startsWith(ce.path, prefix)) break;
            if (unpackIndexEntry(ce, o) < 0) return false;
        }
    }

    var ok = true;
    // directories not to descend into (skipped unmerged paths, sparse
    // directories handled as a whole)
    var skipped: std.StringHashMapUnmanaged(void) = .empty;
    for (names) |p| {
        if (!ok and !o.show_all_errors) break;
        if (underSkipped(&skipped, p, prefix.len)) continue;
        var mask: u32 = 0;
        var dirmask: u32 = 0;
        for (0..n) |i| {
            const bit = @as(u32, 1) << @intCast(i);
            if (maps[i].files.contains(p)) {
                mask |= bit;
            } else if (maps[i].dirs.contains(p)) {
                mask |= bit;
                dirmask |= bit;
            }
        }
        var srcs: [MAX_UNPACK_TREES + 1]?*const Entry = @splat(null);
        if (o.merge) {
            if (findUnused(src, p)) |ce| {
                if (ce.stage() != 0 and o.skip_unmerged) {
                    addSameUnmerged(o, ce);
                    skipped.put(gpa, p, {}) catch util.oom();
                    continue;
                }
                srcs[0] = ce;
            } else if (src.sparse_index) {
                if (findUnusedSparseDir(src, p)) |ce| srcs[0] = ce;
            }
        }
        const src_is_sparse_dir = srcs[0] != null and sparse_index_mod.isSparseDir(srcs[0].?);
        var is_new_sparse_dir = false;
        if (mask == dirmask and srcs[0] == null) {
            // a sparse index may take a directory outside the cone as a
            // whole instead of descending into it
            if (!src.sparse_index) continue;
            is_new_sparse_dir = entryIsNewSparseDir(src, p);
            if (!is_new_sparse_dir) continue;
        }

        // df conflicts inherited from file entries at leading directories
        var conflicts = dirmask;
        var s: usize = prefix.len;
        while (std.mem.indexOfScalarPos(u8, p, s, '/')) |sl| {
            const anc = p[0..sl];
            for (0..n) |i| {
                if (maps[i].files.contains(anc)) conflicts |= @as(u32, 1) << @intCast(i);
            }
            s = sl + 1;
        }
        // unpacking a sparse directory is not a directory/file conflict
        if (mask == dirmask and (is_new_sparse_dir or src_is_sparse_dir)) conflicts = 0;

        var tmp: [MAX_UNPACK_TREES]Entry = undefined;
        for (0..n) |i| {
            const bit = @as(u32, 1) << @intCast(i);
            if (conflicts & bit != 0) {
                srcs[i + m] = &df_conflict_entry;
                continue;
            }
            if (mask & bit == 0) continue;
            tmp[i] = treeEntryAt(&maps[i], p, stageFor(o, i));
            srcs[i + m] = &tmp[i];
        }
        if (src_is_sparse_dir or is_new_sparse_dir) skipped.put(gpa, p, {}) catch util.oom();
        if (o.merge) {
            if (callFn(srcs[0 .. n + 1], o) < 0) {
                ok = false;
                continue;
            }
            if (srcs[0]) |ce| {
                if (ce.stage() != 0) markCeUsedSameName(o, ce) else markCeUsed(ce);
            }
        } else {
            for (0..n) |i| {
                if (srcs[i]) |e| {
                    if (!isDf(e) and !doAddEntry(o, e.*, 0, false)) {
                        ok = false;
                        break;
                    }
                }
            }
        }
    }
    if (!ok) return false;

    // left-over index entries
    if (o.merge) {
        var i: usize = 0;
        while (i < src.entries.items.len) : (i += 1) {
            const ce = &src.entries.items[i];
            if (ce.uflags & CE_UNPACKED != 0) continue;
            if (unpackIndexEntry(ce, o) < 0) return false;
        }
    }
    return true;
}

// ---------------- worktree update ----------------

fn removeMarked(idx: *Index) void {
    var w: usize = 0;
    for (idx.entries.items) |e| {
        if (e.uflags & CE_REMOVE != 0) continue;
        idx.entries.items[w] = e;
        w += 1;
    }
    idx.entries.items.len = w;
}

/// load_gitmodules_file()
fn loadGitmodulesFile(idx: *Index, state: ?*entry.State) void {
    const i = idx.firstPos(".gitmodules");
    if (i >= idx.entries.items.len or !util.eql(idx.entries.items[i].path, ".gitmodules")) return;
    const ce = &idx.entries.items[i];
    if (state == null and ce.uflags & CE_WT_REMOVE != 0) {
        submodule.reloadGitmodules();
    } else if (state != null and ce.uflags & CE_UPDATE != 0) {
        submodule.reloadGitmodules();
        ce.uflags &= ~CE_UPDATE;
        _ = entry.checkoutEntry(ce, state.?, null);
        submodule.reloadGitmodules();
    }
}

/// prefetch_cache_entries(): batch-fetch blobs about to be checked out.
fn prefetchCacheEntries(idx: anytype) void {
    var want: std.ArrayList(Oid) = .empty;
    for (idx.entries.items) |*e| {
        if (e.uflags & CE_UPDATE == 0 or e.mode == 0o160000) continue;
        want.append(gpa, e.oid) catch util.oom();
    }
    @import("promisor.zig").prefetchMissing(want.items);
}

/// check_updates(); returns true on errors.
fn checkUpdates(o: *Options) bool {
    const idx = &o.result;
    if (!o.update or o.dry_run) {
        removeMarked(idx);
        return false;
    }
    var st = entry.State{ .force = true, .quiet = true, .refresh_cache = true, .istate = idx, .meta = o.meta };
    // get_progress()
    const progress = @import("progress.zig");
    var prog: ?*progress.Progress = null;
    if (o.verbose_update) {
        var total: u64 = 0;
        for (idx.entries.items) |*e| {
            if (e.uflags & (CE_UPDATE | CE_WT_REMOVE) != 0) total += 1;
        }
        prog = progress.startDelayed("Updating files", total);
    }
    const attr = @import("attr.zig");
    attr.checkout_index = idx;
    attr.setDirection(.checkout);
    defer {
        attr.setDirection(.checkin);
        attr.checkout_index = null;
    }
    var cnt: u64 = 0;
    if (submodule.shouldUpdate()) loadGitmodulesFile(idx, null);
    for (idx.entries.items) |*e| {
        if (e.uflags & CE_WT_REMOVE != 0) {
            cnt += 1;
            progress.update(prog, cnt);
            entry.unlinkEntry(e);
        }
    }
    removeMarked(idx);
    entry.removeScheduledDirs();
    if (submodule.shouldUpdate()) loadGitmodulesFile(idx, &st);
    if (@import("promisor.zig").hasRemote()) prefetchCacheEntries(idx);
    var errs = false;
    const pc = @import("parallel_checkout.zig");
    const pc_cfg = pc.getConfigs();
    entry.enableDelayedCheckout(&st);
    if (pc_cfg.workers > 1) pc.init();
    for (idx.entries.items) |*e| {
        if (e.uflags & CE_UPDATE != 0) {
            e.uflags &= ~CE_UPDATE;
            const last_q = pc.queueSize();
            if (entry.checkoutEntry(e, &st, null)) errs = true;
            if (last_q == pc.queueSize()) {
                cnt += 1;
                progress.update(prog, cnt);
            }
        }
    }
    if (pc_cfg.workers > 1) {
        pc.setProgress(prog, &cnt);
        if (pc.run(&st, pc_cfg.workers, pc_cfg.threshold)) errs = true;
    }
    progress.stop(&prog);
    if (entry.finishDelayedCheckout(&st, o.verbose_update)) errs = true;
    return errs;
}

/// unpack_trees(): 0 on success, -1 on merge failure, -2 on worktree update errors.
pub fn unpackTrees(trees: []const Oid, o: *Options) i32 {
    const t2 = @import("trace2.zig");
    if (!t2.enabled) return unpackTreesInner(trees, o);
    t2.regionEnter("unpack_trees", "unpack_trees", true);
    const r = unpackTreesInner(trees, o);
    t2.regionLeave("unpack_trees", "unpack_trees", true);
    return r;
}

fn unpackTreesInner(trees: []const Oid, o: *Options) i32 {
    if (trees.len > MAX_UNPACK_TREES) util.die("unpack_trees takes at most {d} trees", .{MAX_UNPACK_TREES});
    const src = o.src_index.?;
    if (!sparse_index_mod.keep_sparse) {
        sparse_index_mod.ensureFull(src);
        if (o.dst_index) |d| sparse_index_mod.ensureFull(d);
    }
    // update_sparsity_for_prefix()
    if (o.prefix) |pfx0| if (src.sparse_index) {
        const pfx = std.mem.trimEnd(u8, pfx0, "/");
        if (pfx.len > 0) {
            const cp = util.concat(&.{ pfx, "/" });
            if (!sparse_index_mod.pathInConeMode(cp) and switch (src.pos(cp, 0)) {
                .found => true,
                .missing => false,
            }) sparse_index_mod.ensureFull(src);
        }
    };
    var dir_storage = dir_mod.Dir.init();
    if (!o.preserve_ignored) {
        dir_storage.flags.show_ignored = true;
        dir_storage.setupStandardExcludes();
        dir_storage.idx = src;
        o.dir = &dir_storage;
    }
    defer o.dir = null;

    o.result = .{
        .timestamp_s = src.timestamp_s,
        .timestamp_ns = src.timestamp_ns,
        .version = src.version,
    };
    // a never-read index produced by a sparse-aware command starts out sparse
    if (src.fresh and sparse_index_mod.keep_sparse and sparse_index_mod.isAllowed(&o.result, false))
        o.result.sparse_index = true;
    var pl: ?*sparse_mod.Patterns = null;
    if (!o.update) o.skip_sparse_checkout = true;
    if (!o.skip_sparse_checkout) {
        pl = sparse_mod.current();
        if (pl == null) o.skip_sparse_checkout = true;
    }
    o.merge_size = trees.len;
    for (src.entries.items) |*e| e.uflags &= ~CE_UNPACKED;
    if (pl) |p| markNewSkipWorktree(p, src, 0, CE_NEW_SKIP_WORKTREE, false, o.verbose_update);
    defer for (src.entries.items) |*e| {
        e.uflags &= ~CE_NEW_SKIP_WORKTREE;
    };

    const t2 = @import("trace2.zig");
    if (trees.len > 0) t2.regionEnter("unpack_trees", "traverse_trees", true);
    const ok = traverse(trees, o);
    if (trees.len > 0) t2.regionLeave("unpack_trees", "traverse_trees", true);
    for (src.entries.items) |*e| e.uflags &= ~CE_UNPACKED;
    if (!ok) {
        if (o.show_all_errors) displayErrorMsgs(o);
        const r = unpackFailed(o, null);
        return if (o.exiting_early) 0 else r;
    }
    if (o.trivial_merges_only and o.nontrivial_merge) {
        return unpackFailed(o, "Merge requires file-level merging");
    }

    if (pl) |p| {
        markNewSkipWorktree(p, &o.result, CE_ADDED, CE_NEW_SKIP_WORKTREE, true, o.verbose_update);
        var warn = false;
        for (o.result.entries.items) |*e| {
            if (e.uflags & CE_ADDED != 0 and verifyAbsent(e, .warning_sparse_orphaned, o) != 0) warn = true;
            if (applySparseCheckout(e, o) != 0) warn = true;
        }
        if (warn and o.show_all_errors) displayWarningMsgs(o);
    }
    const ret: i32 = if (checkUpdates(o)) -2 else 0;
    if (o.dst_index) |dst| {
        o.result.cache_tree = src.cache_tree;
        src.cache_tree = null;
        if (ret == 0 and !o.skip_cache_tree_update and !fullyValid(o.result.cache_tree)) {
            _ = cacheTreeUpdateRepair(&o.result);
        }
        for (o.result.entries.items) |*e| e.uflags = 0;
        var res = o.result;
        res.path = dst.path;
        res.lock = dst.lock;
        res.loaded_from_disk = dst.loaded_from_disk;
        res.has_split = dst.has_split;
        res.split = src.split;
        res.alt_output = dst.alt_output;
        res.fsmonitor_last_update = src.fsmonitor_last_update;
        res.fsmonitor_has_run_once = src.fsmonitor_has_run_once;
        res.untracked = src.untracked;
        res.changed = true;
        res.updated_workdir = true;
        dst.* = res;
    }
    o.result = .{};
    o.src_index = null;
    return ret;
}

/// read_index_unmerged(): turn unmerged paths into stage-0 CE_CONFLICTED
/// placeholders. Returns true if the index was unmerged.
pub fn readIndexUnmerged(idx: *Index) bool {
    var unmerged = false;
    var i: usize = 0;
    while (i < idx.entries.items.len) : (i += 1) {
        const ce = idx.entries.items[i];
        if (ce.stage() == 0) continue;
        unmerged = true;
        var n = Entry{ .path = ce.path, .mode = ce.mode };
        n.uflags = CE_CONFLICTED;
        _ = idx.add(n, .{ .skip_df_check = true });
    }
    return unmerged;
}

/// mark_new_skip_worktree(): entries of idx (optionally only those with
/// select_flag) get CE_NEW_SKIP_WORKTREE (and CE_SKIP_WORKTREE when
/// also_skip) unless they are unmerged or inside the sparse patterns.
fn markNewSkipWorktree(pl: *sparse_mod.Patterns, idx: *Index, select_flag: u32, comptime flag: u32, also_skip: bool, show_progress: bool) void {
    // clear_ce_flags(): "Updating index flags"
    const progress = @import("progress.zig");
    var prog: ?*progress.Progress = if (show_progress) progress.startDelayed("Updating index flags", idx.entries.items.len) else null;
    defer progress.stop(&prog);
    defer progress.update(prog, idx.entries.items.len);
    for (idx.entries.items, 0..) |*e, pnr| {
        progress.update(prog, pnr);
        if (select_flag != 0 and e.uflags & select_flag == 0) continue;
        const skip = e.stage() == 0 and e.uflags & CE_CONFLICTED == 0 and !pl.pathIn(e.path, ceToDtype(e));
        if (skip) {
            e.uflags |= flag;
            if (also_skip) e.ext_flags |= index_mod.CE_SKIP_WORKTREE;
        } else {
            e.uflags &= ~flag;
            if (also_skip) e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
        }
    }
}

/// apply_sparse_checkout() for one result entry; nonzero on a warning.
fn applySparseCheckout(e: *Entry, o: *Options) i32 {
    const was_skip = e.skipWorktree();
    const now_skip = e.uflags & CE_NEW_SKIP_WORKTREE != 0;
    if (now_skip) e.ext_flags |= index_mod.CE_SKIP_WORKTREE else e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
    if (was_skip and now_skip) {
        e.uflags &= ~CE_UPDATE;
        if (e.uflags & CE_REMOVE != 0) e.uflags &= ~CE_WT_REMOVE;
    }
    if (!was_skip and now_skip) {
        if (e.uflags & CE_UPDATE == 0 and verifyUptodate1(e, o, .warning_sparse_not_uptodate) != 0) {
            e.ext_flags &= ~index_mod.CE_SKIP_WORKTREE;
            return -1;
        }
        e.uflags |= CE_WT_REMOVE;
        e.uflags &= ~CE_UPDATE;
    }
    if (was_skip and !now_skip) {
        if (verifyAbsent1(e, .warning_sparse_orphaned, .completely, o) != 0) return -1;
        e.uflags |= CE_UPDATE;
    }
    return 0;
}

/// display_warning_msgs()
fn displayWarningMsgs(o: *Options) void {
    var shown = false;
    for (NB_ERRORS..NB_ALL) |e| {
        const list = &o.rejects[e];
        if (list.items.len > 0) {
            shown = true;
            var b: util.Buf = .empty;
            for (list.items) |p| util.bufPrint(&b, "\t{s}\n", .{p});
            util.warn("{s}", .{subst(errorMsg(o, @enumFromInt(e)), &.{superPrefixed(o, b.items)})});
        }
        list.clearRetainingCapacity();
    }
    if (shown) util.ewrite("After fixing the above paths, you may want to run `git sparse-checkout reapply`.\n");
}

// ---------------- verify_path (read-cache.c, utf8.c, path.c) ----------------

fn isXplatformDirSep(c: u8) bool {
    return c == '/' or c == '\\';
}

fn chAt(s: []const u8, i: usize) u8 {
    return if (i < s.len) s[i] else 0;
}

/// next_hfs_char(): next code point skipping HFS+-ignored ones; 0 at end or
/// on malformed UTF-8.
fn nextHfsChar(s: []const u8, i: *usize) u21 {
    while (true) {
        if (i.* >= s.len) return 0;
        const n = std.unicode.utf8ByteSequenceLength(s[i.*]) catch return 0;
        if (i.* + n > s.len) return 0;
        const c = std.unicode.utf8Decode(s[i.* .. i.* + n]) catch return 0;
        i.* += n;
        switch (c) {
            0x200c, 0x200d, 0x200e, 0x200f, 0x202a, 0x202b, 0x202c, 0x202d, 0x202e, 0x206a, 0x206b, 0x206c, 0x206d, 0x206e, 0x206f, 0xfeff => continue,
            else => return c,
        }
    }
}

fn isHfsDotGeneric(path: []const u8, needle: []const u8) bool {
    var i: usize = 0;
    if (nextHfsChar(path, &i) != '.') return false;
    for (needle) |nc| {
        const c = nextHfsChar(path, &i);
        if (c > 127) return false;
        if (std.ascii.toLower(@intCast(c)) != nc) return false;
    }
    const c = nextHfsChar(path, &i);
    return c == 0 or c == '/';
}

fn ntfsOnlySpacesAndPeriods(name: []const u8, start: usize) bool {
    var i = start;
    while (true) : (i += 1) {
        const c = chAt(name, i);
        if (c == 0 or c == ':') return true;
        if (c != ' ' and c != '.') return false;
    }
}

fn isNtfsDotGeneric(name: []const u8, dotgit: []const u8, shortname_prefix: []const u8) bool {
    const len = dotgit.len;
    if (chAt(name, 0) == '.' and name.len >= len + 1 and std.ascii.eqlIgnoreCase(name[1 .. len + 1], dotgit))
        return ntfsOnlySpacesAndPeriods(name, len + 1);
    if (name.len >= 8 and std.ascii.eqlIgnoreCase(name[0..6], dotgit[0..6]) and name[6] == '~' and name[7] >= '1' and name[7] <= '4')
        return ntfsOnlySpacesAndPeriods(name, 8);
    var saw_tilde = false;
    var i: usize = 0;
    while (i < 8) : (i += 1) {
        const c = chAt(name, i);
        if (c == 0) return false;
        if (saw_tilde) {
            if (c < '0' or c > '9') return false;
        } else if (c == '~') {
            i += 1;
            const d = chAt(name, i);
            if (d < '1' or d > '9') return false;
            saw_tilde = true;
        } else if (i >= 6) {
            return false;
        } else if (c & 0x80 != 0) {
            return false;
        } else if (std.ascii.toLower(c) != shortname_prefix[i]) return false;
    }
    return ntfsOnlySpacesAndPeriods(name, i);
}

fn isNtfsDotgit(name: []const u8) bool {
    var i: usize = 0;
    const c = chAt(name, 0);
    if (c == 'g' or c == 'G') {
        if (std.ascii.toLower(chAt(name, 1)) != 'i' or std.ascii.toLower(chAt(name, 2)) != 't' or chAt(name, 3) != '~' or chAt(name, 4) != '1') return false;
        i = 5;
    } else if (c == '.') {
        if (std.ascii.toLower(chAt(name, 1)) != 'g' or std.ascii.toLower(chAt(name, 2)) != 'i' or std.ascii.toLower(chAt(name, 3)) != 't') return false;
        i = 4;
    } else return false;
    while (true) : (i += 1) {
        const d = chAt(name, i);
        if (d == 0 or isXplatformDirSep(d) or d == ':') return true;
        if (d != '.' and d != ' ') return false;
    }
}

fn verifyDotfile(rest: []const u8, mode: u32) bool {
    const c0 = chAt(rest, 0);
    if (c0 == 0 or c0 == '/') return false;
    switch (c0) {
        'g', 'G' => {
            if (chAt(rest, 1) != 'i' and chAt(rest, 1) != 'I') return true;
            if (chAt(rest, 2) != 't' and chAt(rest, 2) != 'T') return true;
            if (chAt(rest, 3) == 0 or chAt(rest, 3) == '/') return false;
            if (mode & os.S_IFMT == os.S_IFLNK) {
                const r = rest[3..];
                if (r.len >= 7 and std.ascii.eqlIgnoreCase(r[0..7], "modules") and (r.len == 7 or r[7] == '/')) return false;
            }
        },
        '.' => {
            if (chAt(rest, 1) == 0 or chAt(rest, 1) == '/') return false;
        },
        else => {},
    }
    return true;
}

var protect_loaded = false;
var protect_hfs = false;
var protect_ntfs = true;

/// verify_path() honouring core.protectHFS / core.protectNTFS.
pub fn verifyPathFull(path: []const u8, mode: u32) bool {
    if (!protect_loaded) {
        protect_loaded = true;
        protect_hfs = repo_mod.cfg.getBool("core.protecthfs") orelse false;
        protect_ntfs = repo_mod.cfg.getBool("core.protectntfs") orelse true;
    }
    const is_lnk = mode & os.S_IFMT == os.S_IFLNK;
    var i: usize = 0;
    var comp_start = true;
    while (true) {
        if (comp_start) {
            comp_start = false;
            const p = path[i..];
            if (protect_hfs) {
                if (isHfsDotGeneric(p, "git")) return false;
                if (is_lnk and isHfsDotGeneric(p, "gitmodules")) return false;
            }
            if (protect_ntfs) {
                if (isNtfsDotgit(p)) return false;
                if (is_lnk and isNtfsDotGeneric(p, "gitmodules", "gi7eba")) return false;
            }
            const c = chAt(path, i);
            i += 1;
            if ((c == '.' and !verifyDotfile(path[i..], mode)) or c == '/') return false;
            if (c == 0) return mode & os.S_IFMT == os.S_IFDIR;
            continue;
        }
        const c = chAt(path, i);
        if (c == 0) return true;
        if (c == '/') {
            i += 1;
            comp_start = true;
            continue;
        }
        if (c == '\\' and protect_ntfs) {
            const p = path[i + 1 ..];
            if (isNtfsDotgit(p)) return false;
            if (is_lnk and isNtfsDotGeneric(p, "gitmodules", "gi7eba")) return false;
        }
        i += 1;
    }
}
