//! Running hooks (hook.c): traditional hooks in $GIT_DIR/hooks or core.hooksPath,
//! plus config-based hooks (hook.<name>.command / hook.<name>.event).

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const repo_mod = @import("repo.zig");
const advice = @import("advice.zig");
const config = @import("config.zig");
const gpa = util.gpa;

var advised: std.ArrayList([]const u8) = .empty;

/// hook-list.h (generated from Documentation/githooks.adoc), sorted.
pub const known_hooks = [_][]const u8{
    "applypatch-msg",        "commit-msg",        "fsmonitor-watchman", "p4-changelist",
    "p4-post-changelist",    "p4-pre-submit",     "p4-prepare-changelist", "post-applypatch",
    "post-checkout",         "post-commit",       "post-index-change",  "post-merge",
    "post-receive",          "post-rewrite",      "post-update",        "pre-applypatch",
    "pre-auto-gc",           "pre-commit",        "pre-merge-commit",   "pre-push",
    "pre-rebase",            "pre-receive",       "prepare-commit-msg", "proc-receive",
    "push-to-checkout",      "reference-transaction", "sendemail-validate", "update",
};

pub fn isKnown(name: []const u8) bool {
    for (known_hooks) |h| if (util.eql(h, name)) return true;
    return false;
}

/// find_hook: path of an executable hook, or null.
pub fn find(name: []const u8) ?[]const u8 {
    const r = repo_mod.repo_ orelse return null;
    const dir = repo_mod.cfg.getPath("core.hookspath") orelse r.commonPath("hooks");
    const path = util.concat(&.{ dir, "/", name });
    if (os.access(path, 1)) return path;
    if (os.errno() == 13 and advice.enabled("ignoredHook")) {
        for (advised.items) |a| if (util.eql(a, name)) return null;
        advised.append(gpa, name) catch util.oom();
        advice.advise(util.fmt("The '{s}' hook was ignored because it's not set as executable.\n" ++
            "You can disable this warning with `git config set advice.ignoredHook false`.", .{path}));
    }
    return null;
}

// ---------------------------------------------------------------------------
// config-based hooks

pub const Kind = enum { traditional, configured };

pub const Hook = struct {
    kind: Kind,
    /// traditional: path; configured: friendly name
    name: []const u8,
    command: ?[]const u8 = null,
    scope: config.Scope = .unknown,
    disabled: bool = false,
    event_disabled: bool = false,
    parallel: bool = false,
};

const CfgEntry = struct {
    name: []const u8,
    command: ?[]const u8,
    scope: config.Scope,
    disabled: bool,
    parallel: bool,
};

const EventHooks = struct {
    event: []const u8,
    hooks: std.ArrayList(CfgEntry) = .empty,
};

const Cache = struct {
    events: std.ArrayList(EventHooks) = .empty,
    disabled_events: std.ArrayList([]const u8) = .empty,
    jobs: u32 = 0,
    event_jobs: std.ArrayList(struct { name: []const u8, jobs: u32 }) = .empty,
};

var cache_: ?*Cache = null;

fn onlineCpus() u32 {
    const n = std.Thread.getCpuCount() catch 1;
    return @intCast(n);
}

fn strIndex(l: []const []const u8, s: []const u8) ?usize {
    for (l, 0..) |x, i| if (util.eql(x, s)) return i;
    return null;
}

const NamedList = struct {
    name: []const u8,
    items: std.ArrayList(struct { hook: []const u8, scope: config.Scope }) = .empty,
};

fn buildCache() *Cache {
    if (cache_) |c| return c;
    const c = gpa.create(Cache) catch util.oom();
    c.* = .{};
    var commands: std.ArrayList([2][]const u8) = .empty;
    var events: std.ArrayList(NamedList) = .empty;
    var disabled: std.ArrayList([]const u8) = .empty;
    var parallel: std.ArrayList([]const u8) = .empty;

    for (repo_mod.cfg.entries.items) |e| {
        const pk = config.parseConfigKey(e.key, "hook") orelse continue;
        const subkey = pk.key;
        const name = pk.sub orelse {
            if (util.eql(subkey, "jobs")) {
                if (e.value) |v| {
                    if (std.fmt.parseInt(i32, util.trim(v), 10)) |n| {
                        if (n == -1) {
                            c.jobs = onlineCpus();
                        } else if (n > 0) {
                            c.jobs = @intCast(n);
                        } else util.warn("hook.jobs must be a positive integer or -1, ignoring: '{s}'", .{v});
                    } else |_| util.warn("hook.jobs must be an integer, ignoring: '{s}'", .{v});
                }
            }
            continue;
        };
        const value = e.value orelse {
            util.err("missing value for '{s}'", .{e.key});
            continue;
        };
        if (util.eql(subkey, "event")) {
            if (value.len == 0) {
                for (events.items) |*ev| {
                    var i: usize = 0;
                    while (i < ev.items.items.len) {
                        if (util.eql(ev.items.items[i].hook, name)) {
                            _ = ev.items.orderedRemove(i);
                        } else i += 1;
                    }
                }
            } else {
                if (isKnown(name))
                    util.die("hook friendly-name '{s}' collides with a known event name; please choose a different friendly-name", .{name});
                if (util.eql(name, value))
                    util.warn("hook friendly-name '{s}' is the same as its event; this may cause ambiguity with hook.{s}.enabled", .{ name, name });
                var ev: ?*NamedList = null;
                for (events.items) |*x| {
                    if (util.eql(x.name, value)) ev = x;
                }
                if (ev == null) {
                    events.append(gpa, .{ .name = value }) catch util.oom();
                    ev = &events.items[events.items.len - 1];
                }
                var i: usize = 0;
                while (i < ev.?.items.items.len) {
                    if (util.eql(ev.?.items.items[i].hook, name)) {
                        _ = ev.?.items.orderedRemove(i);
                    } else i += 1;
                }
                ev.?.items.append(gpa, .{ .hook = name, .scope = e.scope }) catch util.oom();
            }
        } else if (util.eql(subkey, "command")) {
            var found = false;
            for (commands.items) |*cmd| {
                if (util.eql(cmd[0], name)) {
                    cmd[1] = value;
                    found = true;
                }
            }
            if (!found) commands.append(gpa, .{ name, value }) catch util.oom();
        } else if (util.eql(subkey, "enabled")) {
            switch (config.parseMaybeBool(value)) {
                0 => if (strIndex(disabled.items, name) == null) disabled.append(gpa, name) catch util.oom(),
                1 => if (strIndex(disabled.items, name)) |i| {
                    _ = disabled.orderedRemove(i);
                },
                else => {},
            }
        } else if (util.eql(subkey, "parallel")) {
            const v = config.parseMaybeBool(value);
            if (v >= 0) {
                if (strIndex(parallel.items, name)) |i| _ = parallel.orderedRemove(i);
                if (v == 1) parallel.append(gpa, name) catch util.oom();
            } else util.warn("hook.{s}.parallel must be a boolean, ignoring: '{s}'", .{ name, value });
        } else if (util.eql(subkey, "jobs")) {
            if (std.fmt.parseInt(i32, util.trim(value), 10)) |n| {
                if (n == -1 or n > 0) {
                    c.event_jobs.append(gpa, .{ .name = name, .jobs = if (n == -1) onlineCpus() else @intCast(n) }) catch util.oom();
                } else util.warn("hook.{s}.jobs must be a positive integer or -1, ignoring: '{s}'", .{ name, value });
            } else |_| util.warn("hook.{s}.jobs must be an integer, ignoring: '{s}'", .{ name, value });
        }
    }

    const isFriendly = struct {
        fn f(cmds: []const [2][]const u8, par: []const []const u8, evs: []const NamedList, n: []const u8) bool {
            for (cmds) |x| if (util.eql(x[0], n)) return true;
            if (strIndex(par, n) != null) return true;
            for (evs) |ev| {
                for (ev.items.items) |it| if (util.eql(it.hook, n)) return true;
            }
            return false;
        }
    }.f;

    for (c.event_jobs.items) |ej| {
        if (isFriendly(commands.items, parallel.items, events.items, ej.name))
            util.warn("hook.{s}.jobs is set but '{s}' looks like a hook friendly-name, not an event name; hook.<event>.jobs uses the event name (e.g. hook.post-receive.jobs), so this setting will be ignored", .{ ej.name, ej.name });
    }

    for (disabled.items) |n| {
        if (!isFriendly(commands.items, parallel.items, events.items, n))
            c.disabled_events.append(gpa, n) catch util.oom();
    }

    for (events.items) |ev| {
        var eh = EventHooks{ .event = ev.name };
        for (ev.items.items) |it| {
            var command: ?[]const u8 = null;
            for (commands.items) |x| if (util.eql(x[0], it.hook)) {
                command = x[1];
            };
            const is_disabled = strIndex(disabled.items, it.hook) != null;
            if (command == null) {
                if (is_disabled) {
                    util.warn("disabled hook '{s}' has no command configured", .{it.hook});
                } else util.die("'hook.{s}.command' must be configured or 'hook.{s}.event' must be removed; aborting.", .{ it.hook, it.hook });
            }
            eh.hooks.append(gpa, .{
                .name = it.hook,
                .command = command,
                .scope = it.scope,
                .disabled = is_disabled,
                .parallel = strIndex(parallel.items, it.hook) != null,
            }) catch util.oom();
        }
        c.events.append(gpa, eh) catch util.oom();
    }
    cache_ = c;
    return c;
}

/// list_hooks(): configured hooks first, then the traditional one.
pub fn list(name: []const u8) []Hook {
    var res: std.ArrayList(Hook) = .empty;
    const c = buildCache();
    const ev_disabled = strIndex(c.disabled_events.items, name) != null;
    for (c.events.items) |ev| {
        if (!util.eql(ev.event, name)) continue;
        for (ev.hooks.items) |h| {
            res.append(gpa, .{
                .kind = .configured,
                .name = h.name,
                .command = h.command,
                .scope = h.scope,
                .disabled = h.disabled,
                .event_disabled = ev_disabled,
                .parallel = h.parallel,
            }) catch util.oom();
        }
    }
    if (find(name)) |p| res.append(gpa, .{ .kind = .traditional, .name = p }) catch util.oom();
    return res.items;
}

/// hook_exists()
pub fn exists(name: []const u8) bool {
    for (list(name)) |h| {
        if (h.kind == .traditional or (!h.disabled and !h.event_disabled)) return true;
    }
    return false;
}

pub const Opts = struct {
    env: []const [2][]const u8 = &.{},
    stdin_data: ?[]const u8 = null,
    invoked: ?*bool = null,
    /// --to-stdin=<path>
    path_to_stdin: ?[]const u8 = null,
    error_if_missing: bool = false,
    stdout_to_stderr: bool = true,
    /// 0 = from config
    jobs: u32 = 0,
    dir: ?[]const u8 = null,
    unset_env: []const []const u8 = &.{},
};

fn hookJobs(name: []const u8, o: *const Opts, hooks: []const Hook) u32 {
    var jobs: u32 = o.jobs;
    if (jobs == 0) {
        jobs = 1;
        const c = buildCache();
        if (c.jobs != 0) jobs = c.jobs;
        for (c.event_jobs.items) |ej| if (util.eql(ej.name, name)) {
            jobs = ej.jobs;
        };
        for (hooks) |h| {
            if (h.kind == .configured and !h.parallel) {
                jobs = 1;
                break;
            }
        }
    }
    if (jobs != 1) {
        for (hooks) |h| {
            if (h.kind == .configured and !h.parallel)
                util.warn("hook '{s}' is not marked as parallel=true, running in parallel anyway due to -j{d}", .{ h.name, jobs });
        }
    }
    return jobs;
}

/// run_hooks_opt: returns the cumulative (OR'ed) exit status (0 when there is no hook).
/// Returns -1 (as 255) when error_if_missing and there is no hook.
pub fn runOpt(name: []const u8, args: []const []const u8, o: Opts) i32 {
    const hooks = list(name);
    if (o.invoked) |p| p.* = false;
    if (hooks.len == 0) {
        if (o.error_if_missing) {
            util.err("cannot find a hook named {s}", .{name});
            return -1;
        }
        return 0;
    }
    const jobs = hookJobs(name, &o, hooks);
    const to_stderr = o.stdout_to_stderr or jobs > 1;
    var rc: u32 = 0;
    for (hooks) |h| {
        if (h.kind == .configured and (h.disabled or h.event_disabled)) continue;
        var argv: std.ArrayList([]const u8) = .empty;
        var stdin_data = o.stdin_data;
        if (o.path_to_stdin) |p| {
            stdin_data = os.readFile(p) orelse util.dieErrno("could not open '{s}'", .{p});
        }
        if (h.kind == .traditional) {
            const path = if (o.dir != null and h.name.len > 0 and h.name[0] != '/')
                util.concat(&.{ os.getcwd(), "/", h.name })
            else
                h.name;
            argv.append(gpa, path) catch util.oom();
        } else {
            argv.append(gpa, h.command.?) catch util.oom();
        }
        argv.appendSlice(gpa, args) catch util.oom();
        const res = os.run(argv.items, .{
            .env = o.env,
            .stdin_data = stdin_data,
            .no_stdin = stdin_data == null,
            .stdout_to_stderr = to_stderr,
            .use_shell = h.kind == .configured,
            .cwd = o.dir,
            .unset_env = o.unset_env,
            .trace2_hook = name,
        });
        rc |= res.status;
        if (o.invoked) |p| p.* = true;
    }
    return @intCast(rc & 0xff);
}

/// run_hooks_opt with the traditional calling convention used by callers.
pub fn run(name: []const u8, args: []const []const u8, o: Opts) u8 {
    const r = runOpt(name, args, o);
    if (r < 0) return 1;
    return @intCast(r);
}

/// run_commit_hook (commit.c)
pub fn runCommitHook(editor_is_used: bool, index_file: []const u8, invoked: ?*bool, name: []const u8, args: []const []const u8) u8 {
    var env: std.ArrayList([2][]const u8) = .empty;
    env.append(gpa, .{ "GIT_INDEX_FILE", index_file }) catch util.oom();
    if (!editor_is_used) env.append(gpa, .{ "GIT_EDITOR", ":" }) catch util.oom();
    return run(name, args, .{ .env = env.items, .invoked = invoked });
}
