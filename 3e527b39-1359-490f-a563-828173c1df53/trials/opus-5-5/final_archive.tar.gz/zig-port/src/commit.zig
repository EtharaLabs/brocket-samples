//! Creating commit objects (commit_tree_extended).

const std = @import("std");
const util = @import("util.zig");
const hash = @import("hash.zig");
const repo_mod = @import("repo.zig");
const ident = @import("ident.zig");
const Oid = hash.Oid;

pub const CreateOpts = struct {
    tree: Oid,
    parents: []const Oid = &.{},
    message: []const u8,
    /// full ident lines; default from environment/config
    author: ?[]const u8 = null,
    committer: ?[]const u8 = null,
    /// extra headers (e.g. "mergetag ...") already formatted, each ending in '\n'
    extra_headers: []const u8 = "",
    /// sign_commit: key id to sign with ("" = default signing key), null = unsigned
    sign: ?[]const u8 = null,
};

/// find_invalid_utf8(): offset of the first invalid sequence (git's rules).
fn findInvalidUtf8(buf: []const u8) ?usize {
    const max_codepoint = [_]u32{ 0x7f, 0x7ff, 0xffff, 0x10ffff };
    var i: usize = 0;
    while (i < buf.len) {
        var c = buf[i];
        const start = i;
        i += 1;
        if (c < 0x80) continue;
        var bytes: usize = 0;
        while (c & 0x40 != 0) {
            c <<= 1;
            bytes += 1;
        }
        if (bytes < 1 or 3 < bytes) return start;
        if (buf.len - i < bytes) return start;
        var cp: u32 = @as(u32, c & 0x7f) >> @intCast(bytes);
        const min_val = max_codepoint[bytes - 1] + 1;
        const max_val = max_codepoint[bytes];
        for (buf[i .. i + bytes]) |cb| {
            cp = (cp << 6) | (cb & 0x3f);
            if (cb & 0xc0 != 0x80) return start;
        }
        i += bytes;
        if (cp < min_val or cp > max_val) return start;
        if (cp & 0x1ff800 == 0xd800) return start;
        if (cp & 0xfffe == 0xfffe) return start;
        if (cp >= 0xfdd0 and cp <= 0xfdef) return start;
    }
    return null;
}

/// ensure_utf8(): treat invalid bytes as Latin-1 and convert them in place.
fn ensureUtf8(b: *util.Buf) bool {
    var ok = true;
    var pos: usize = 0;
    while (findInvalidUtf8(b.items[pos..])) |bad| {
        pos += bad;
        ok = false;
        const c = b.items[pos];
        const rep = [2]u8{ 0xc0 + (c >> 6), 0x80 + (c & 0x3f) };
        b.replaceRange(util.gpa, pos, 1, &rep) catch util.oom();
        pos += 2;
    }
    return ok;
}

pub fn commitEncoding() ?[]const u8 {
    const enc = repo_mod.cfg.get("i18n.commitencoding") orelse return null;
    if (std.ascii.eqlIgnoreCase(enc, "utf-8") or std.ascii.eqlIgnoreCase(enc, "utf8")) return null;
    return enc;
}

pub fn create(o: CreateOpts) Oid {
    return tryCreate(o) orelse util.die("failed to write commit object", .{});
}

/// commit_tree_extended(): null when signing failed (already reported).
pub fn tryCreate(o: CreateOpts) ?Oid {
    var b: util.Buf = .empty;
    util.bufPrint(&b, "tree {s}\n", .{hash.hex(o.tree)});
    for (o.parents) |p| util.bufPrint(&b, "parent {s}\n", .{hash.hex(p)});
    const author = o.author orelse ident.authorStrict();
    const committer = o.committer orelse ident.committerStrict();
    util.bufPrint(&b, "author {s}\ncommitter {s}\n", .{ author, committer });
    const enc = commitEncoding();
    if (enc) |e| util.bufPrint(&b, "encoding {s}\n", .{e});
    util.bufAppend(&b, o.extra_headers);
    util.bufByte(&b, '\n');
    util.bufAppend(&b, o.message);
    if (enc == null and !ensureUtf8(&b)) {
        util.eprint("Warning: commit message did not conform to UTF-8.\nYou may want to amend it after fixing the message, or set the config\nvariable i18n.commitEncoding to the encoding your project uses.\n", .{});
    }
    if (o.sign) |key| {
        if (!@import("gpg.zig").signCommitBuffer(&b, key)) return null;
    }
    return repo_mod.repo().odb().write(.commit, b.items);
}
