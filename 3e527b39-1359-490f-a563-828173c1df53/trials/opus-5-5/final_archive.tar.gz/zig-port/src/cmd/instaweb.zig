//! git instaweb (minimal port of git-instaweb.sh)
//!
//! Handles option parsing, --stop, and httpd resolution with the same
//! messages and exit codes as the script.  Server configuration generation
//! is not supported; if a daemon is found it is launched as the script
//! would, and failures are reported identically.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const proc = @import("../proc.zig");
const qi = @import("quiltimport.zig");
const gpa = util.gpa;

const options_spec =
    \\git instaweb [options] (--start | --stop | --restart)
    \\--
    \\l,local        only bind on 127.0.0.1
    \\p,port=        the port to bind to
    \\d,httpd=       the command to launch
    \\b,browser=     the browser to launch
    \\m,module-path= the module path (only needed for apache2)
    \\ Action
    \\stop           stop the web server
    \\start          start the web server
    \\restart        restart the web server
    \\
;

fn gitArgv(args: []const []const u8) []const []const u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.append(gpa, proc.gitBinary()) catch util.oom();
    argv.appendSlice(gpa, args) catch util.oom();
    return argv.items;
}

fn stripNl(s: []const u8) []const u8 {
    var r = s;
    while (r.len > 0 and r[r.len - 1] == '\n') r = r[0 .. r.len - 1];
    return r;
}

fn cfg(key: []const u8) []const u8 {
    const r = os.run(gitArgv(&.{ "config", "--get", key }), .{ .capture_stdout = true });
    return stripNl(r.stdout);
}

fn usage() noreturn {
    util.flushStdout();
    _ = os.run(gitArgv(&.{ "instaweb", "-h" }), .{});
    os.exit(1);
}

const Ctx = struct {
    git_dir: []const u8,
    httpd: []const u8,
    root: []const u8,
    httpd_only: []const u8 = "",
    full_httpd: []const u8 = "",
};

fn stopHttpd(c: *Ctx) void {
    const pidf = util.fmt("{s}/pid", .{c.git_dir});
    if (os.isFile(pidf)) {
        util.flushStdout();
        _ = os.run(&.{ "/bin/sh", "-c", "kill $(cat \"$1\")", "sh", pidf }, .{});
    }
    _ = os.unlink(pidf);
}

fn inPath(name: []const u8) bool {
    const path = os.getenv("PATH") orelse return false;
    var it = std.mem.splitScalar(u8, path, ':');
    while (it.next()) |d| {
        const dir = if (d.len == 0) "." else d;
        const p = util.fmt("{s}/{s}", .{ dir, name });
        if (os.isFile(p) and os.access(p, 1)) return true;
    }
    return false;
}

fn endsWithDashF(s: []const u8) bool {
    const t = std.mem.trimEnd(u8, s, " ");
    return util.endsWith(t, "-f");
}

fn firstWord(s: []const u8) []const u8 {
    const t = std.mem.trimStart(u8, s, " \t");
    const e = std.mem.indexOfAny(u8, t, " \t") orelse t.len;
    return t[0..e];
}

fn resolveFullHttpd(c: *Ctx) void {
    const h = c.httpd;
    if (std.mem.indexOf(u8, h, "apache2") != null or std.mem.indexOf(u8, h, "lighttpd") != null or
        std.mem.indexOf(u8, h, "httpd") != null)
    {
        if (!endsWithDashF(h)) c.httpd = util.fmt("{s} -f", .{h});
    } else if (std.mem.indexOf(u8, h, "plackup") != null or std.mem.indexOf(u8, h, "webrick") != null or
        std.mem.indexOf(u8, h, "python") != null)
    {
        const script = if (std.mem.indexOf(u8, h, "plackup") != null)
            "gitweb.psgi"
        else if (std.mem.indexOf(u8, h, "webrick") != null)
            "webrick.rb"
        else
            "gitweb.py";
        c.full_httpd = util.fmt("{s}/gitweb/{s}", .{ c.git_dir, script });
        const sp = std.mem.indexOfScalar(u8, h, ' ') orelse h.len;
        c.httpd_only = h[0..sp];
        return;
    }
    c.httpd_only = firstWord(c.httpd);
    const found = if (c.httpd_only.len > 0 and c.httpd_only[0] == '/') true else (c.httpd_only.len > 0 and inPath(c.httpd_only));
    if (found) {
        c.full_httpd = c.httpd;
        return;
    }
    const dirs = [_][]const u8{ "/usr/local/sbin", "/usr/sbin", c.root, util.fmt("{s}/gitweb", .{c.git_dir}) };
    for (dirs) |d| {
        const p = util.fmt("{s}/{s}", .{ d, c.httpd_only });
        if (os.access(p, 1) and !os.isDir(p)) {
            c.full_httpd = util.fmt("{s}/{s}", .{ d, c.httpd });
            return;
        }
    }
    util.flushStdout();
    util.eprint("{s} not found. Install {s} or use --httpd to specify another httpd daemon.\n", .{ c.httpd_only, c.httpd_only });
    os.exit(1);
}

fn startHttpd(c: *Ctx) void {
    if (os.isFile(util.fmt("{s}/pid", .{c.git_dir}))) {
        util.print("Instance already running. Restarting...\n", .{});
        stopHttpd(c);
    }
    resolveFullHttpd(c);
    _ = os.mkdirAll(util.fmt("{s}/gitweb/{s}", .{ c.git_dir, c.httpd_only }));
    const conf = util.fmt("{s}/gitweb/{s}.conf", .{ c.git_dir, c.httpd_only });
    util.flushStdout();
    // don't quote full_httpd, there can be arguments to it (-f)
    const r = os.run(&.{ "/bin/sh", "-c", "$1 \"$2\"", "sh", c.full_httpd, conf }, .{});
    if (r.status != 0) {
        util.print("Could not execute http daemon {s}.\n", .{c.httpd});
        util.flushStdout();
        os.exit(1);
    }
}

pub fn cmdInstaweb(args: []const []const u8) u8 {
    const argv = qi.shParseopt(options_spec, args[1..], false, false);

    const gd = os.run(gitArgv(&.{ "rev-parse", "--git-dir" }), .{ .capture_stdout = true });
    if (gd.status != 0) os.exit(gd.status);
    const gdo = stripNl(gd.stdout);
    const cwd = os.getcwd();
    const git_dir = if (gdo.len > 0 and gdo[0] == '/') gdo else (util.normalizePath(util.joinPath(cwd, gdo)) orelse gdo);

    var httpd = cfg("instaweb.httpd");
    var root = cfg("instaweb.gitwebdir");
    if (httpd.len == 0) httpd = "lighttpd -f";
    if (root.len == 0) root = "/usr/share/gitweb";

    var action: []const u8 = "browse";
    var i: usize = 0;
    while (i < argv.len) : (i += 1) {
        const a = argv[i];
        if (util.eql(a, "--stop") or util.eql(a, "stop")) {
            action = "stop";
        } else if (util.eql(a, "--start") or util.eql(a, "start")) {
            action = "start";
        } else if (util.eql(a, "--restart") or util.eql(a, "restart")) {
            action = "restart";
        } else if (util.eql(a, "-l") or util.eql(a, "--local")) {
            // only affects generated configuration
        } else if (util.eql(a, "-d") or util.eql(a, "--httpd")) {
            i += 1;
            httpd = if (i < argv.len) argv[i] else "";
        } else if (util.eql(a, "-b") or util.eql(a, "--browser") or util.eql(a, "-p") or
            util.eql(a, "--port") or util.eql(a, "-m") or util.eql(a, "--module-path"))
        {
            i += 1;
        } else if (util.eql(a, "--")) {} else usage();
    }

    _ = os.mkdirAll(util.fmt("{s}/gitweb/tmp", .{git_dir}));
    var c = Ctx{ .git_dir = git_dir, .httpd = httpd, .root = root };

    if (util.eql(action, "stop")) {
        stopHttpd(&c);
        return 0;
    }
    if (util.eql(action, "start")) {
        startHttpd(&c);
        return 0;
    }
    if (util.eql(action, "restart")) {
        stopHttpd(&c);
        startHttpd(&c);
        return 0;
    }
    resolveFullHttpd(&c);
    startHttpd(&c);
    return 0;
}
