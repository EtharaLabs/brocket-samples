//! git push (builtin/push.c + transport_push + send-pack.c), local
//! transports only.

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const po = @import("../parseopt.zig");
const repo_mod = @import("../repo.zig");
const refs = @import("../refs.zig");
const hash = @import("../hash.zig");
const pkt = @import("../pktline.zig");
const proc = @import("../proc.zig");
const hook = @import("../hook.zig");
const advice = @import("../advice.zig");
const revparse = @import("../revparse.zig");
const logtree = @import("../logtree.zig");
const branchcreate = @import("../branchcreate.zig");
const tp = @import("../transport.zig");
const th = @import("../transport_helper.zig");
const fetch = @import("fetch.zig");
const up = @import("uploadpack.zig");
const gpa = util.gpa;
const Oid = hash.Oid;
const Ref = tp.Ref;
const Remote = tp.Remote;
const Transport = tp.Transport;

const PUSH_ALL: i32 = 1;
const PUSH_FORCE: i32 = 2;
const PUSH_DRY_RUN: i32 = 4;
const PUSH_MIRROR: i32 = 8;
const PUSH_PORCELAIN: i32 = 16;
const PUSH_SET_UPSTREAM: i32 = 32;
const PUSH_PRUNE: i32 = 128;
const PUSH_NO_HOOK: i32 = 256;
const PUSH_FOLLOW_TAGS: i32 = 512;
const PUSH_ATOMIC: i32 = 1024;
const PUSH_OPTIONS: i32 = 2048;
const PUSH_AUTO_UPSTREAM: i32 = 4096;
const PUSH_FORCE_IF_INCLUDES: i32 = 8192;

const REJECT_NON_FF_HEAD: u32 = 0x01;
const REJECT_NON_FF_OTHER: u32 = 0x02;
const REJECT_ALREADY_EXISTS: u32 = 0x04;
const REJECT_FETCH_FIRST: u32 = 0x08;
const REJECT_NEEDS_FORCE: u32 = 0x10;
const REJECT_REF_NEEDS_UPDATE: u32 = 0x20;

const PushDefault = enum { nothing, matching, simple, upstream, current, unspecified };

var flags: i32 = 0;
var verbosity: i32 = 0;
var deleterefs = false;
var tags = false;
var thin = true;
var progress: i32 = -1;
var family: i32 = 0;
var receivepack: ?[]const u8 = null;
var repo_opt: ?[]const u8 = null;
var push_default: PushDefault = .unspecified;
var push_options_cmdline: std.ArrayList([]const u8) = .empty;
var push_options_config: std.ArrayList([]const u8) = .empty;
var signed: ?[]const u8 = null;
var recurse_submodules: sf.PushRecurse = .default;
const sf = @import("../submodule_fetch.zig");

fn cbRecurse(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        recurse_submodules = .off;
    } else if (util.eql(arg orelse "", "only-is-on-demand")) {
        if (recurse_submodules == .only) {
            util.warn("recursing into submodule with push.recurseSubmodules=only; using on-demand instead", .{});
            recurse_submodules = .on_demand;
        }
    } else recurse_submodules = sf.parsePushRecurseArg("recurse-submodules", arg);
}
var opt_ipv4 = false;
var opt_ipv6 = false;
var rs: tp.Refspec = .{ .fetch = false };

// ---------------- force-with-lease ----------------

const CasEntry = struct { refname: []const u8, expect: Oid = hash.zero, use_tracking: bool = false };
var cas_entries: std.ArrayList(CasEntry) = .empty;
var cas_use_tracking_for_rest = false;
var cas_given: std.ArrayList(?[]const u8) = .empty;

fn cbCas(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        cas_entries.clearRetainingCapacity();
        cas_use_tracking_for_rest = false;
        cas_given.clearRetainingCapacity();
        return;
    }
    cas_given.append(gpa, arg) catch util.oom();
    const a = arg orelse {
        cas_use_tracking_for_rest = true;
        return;
    };
    if (std.mem.indexOfScalar(u8, a, ':')) |colon| {
        var e = CasEntry{ .refname = a[0..colon] };
        const ex = a[colon + 1 ..];
        if (ex.len > 0) {
            e.expect = revparse.getOid(ex) orelse util.die("cannot parse expected object name '{s}'", .{ex});
        }
        cas_entries.append(gpa, e) catch util.oom();
    } else {
        cas_entries.append(gpa, .{ .refname = a, .use_tracking = true }) catch util.oom();
    }
}

fn remoteTracking(remote: *const Remote, refname: []const u8) ?Oid {
    const dst = tp.remoteFindTracking(remote, refname) orelse return null;
    const r = refs.resolve(dst) orelse return null;
    return r.oid;
}

fn reflogTimestamp(ident: []const u8) u64 {
    const gt = std.mem.lastIndexOfScalar(u8, ident, '>') orelse return 0;
    const rest = std.mem.trimStart(u8, ident[gt + 1 ..], " ");
    const sp = std.mem.indexOfScalar(u8, rest, ' ') orelse rest.len;
    return std.fmt.parseInt(u64, rest[0..sp], 10) catch 0;
}

/// is_reachable_in_reflog(): is the remote tip in (or reachable from) the
/// local ref's reflog entries newer than the tracking ref's last update?
fn isReachableInReflog(local: []const u8, remote_old: Oid, tracking_ref: []const u8) bool {
    const cn = @import("../commitnode.zig");
    const cr = @import("../commitreach.zig");
    const commit = cn.lookupCommitReference(remote_old) orelse return false;
    var date: u64 = 0;
    const tl = refs.readReflog(tracking_ref);
    if (tl.len > 0) date = reflogTimestamp(tl[tl.len - 1].ident);
    const ll = refs.readReflog(local);
    var arr: std.ArrayList(*cn.Commit) = .empty;
    var i = ll.len;
    while (i > 0) {
        i -= 1;
        const e = ll[i];
        if (hash.eql(e.new, remote_old)) return true;
        if (cn.lookupCommitReference(e.new)) |c| arr.append(gpa, c) catch util.oom();
        if (reflogTimestamp(e.ident) < date) break;
    }
    var k: usize = 0;
    while (k < arr.items.len) {
        const n = @min(8, arr.items.len - k);
        if (cr.inMergeBasesMany(commit, arr.items[k .. k + n], false)) return true;
        k += n;
    }
    return false;
}

/// get_local_ref()
fn localRefName(name: []const u8) ?[]const u8 {
    if (name.len == 0) return null;
    if (util.startsWith(name, "refs/")) return name;
    if (util.startsWith(name, "heads/") or util.startsWith(name, "tags/") or util.startsWith(name, "remotes/")) return util.concat(&.{ "refs/", name });
    return util.concat(&.{ "refs/heads/", name });
}

fn casTracking(remote: *const Remote, r: *Ref, if_includes: bool) void {
    const dst = tp.remoteFindTracking(remote, r.name) orelse {
        r.old_oid_expect = hash.zero;
        return;
    };
    const rr = refs.resolve(dst) orelse {
        r.old_oid_expect = hash.zero;
        return;
    };
    r.old_oid_expect = rr.oid;
    if (!if_includes) return;
    // check_if_includes_upstream()
    const local = localRefName(r.name) orelse return;
    if (!isReachableInReflog(local, r.old_oid, dst)) r.cas_unreachable = true;
    r.cas_check_reachable = true;
}

fn applyPushCas(remote: *const Remote, list: []const *Ref, if_includes: bool) void {
    for (list) |r| {
        var done = false;
        for (cas_entries.items) |e| {
            if (tp.refnameMatch(e.refname, r.name) == 0) continue;
            r.expect_old_sha1 = true;
            if (!e.use_tracking) {
                r.old_oid_expect = e.expect;
            } else casTracking(remote, r, if_includes);
            done = true;
            break;
        }
        if (done or !cas_use_tracking_for_rest) continue;
        r.expect_old_sha1 = true;
        casTracking(remote, r, if_includes);
    }
}

// ---------------- options ----------------

fn cbVerbose(_: ?[]const u8, unset: bool) void {
    if (unset) {
        verbosity = 0;
    } else if (verbosity >= 0) {
        verbosity += 1;
    } else verbosity = 1;
}

fn cbQuiet(_: ?[]const u8, unset: bool) void {
    if (unset) {
        verbosity = 0;
    } else if (verbosity <= 0) {
        verbosity -= 1;
    } else verbosity = -1;
}

var opt_progress = false;
var progress_seen = false;
fn cbProgress(_: ?[]const u8, unset: bool) void {
    progress = if (unset) 0 else 1;
}

fn cbSigned(arg: ?[]const u8, unset: bool) void {
    if (unset) {
        signed = null;
        return;
    }
    const a = arg orelse "yes";
    if (std.ascii.eqlIgnoreCase(a, "if-asked")) {
        signed = "if-asked";
        return;
    }
    if (@import("../config.zig").parseBool(a)) |b| {
        signed = if (b) "yes" else null;
        return;
    }
    util.die("bad {s} argument: {s}", .{ "signed", a });
}

const usage = [_][]const u8{"git push [<options>] [<repository> [<refspec>...]]"};
const options = [_]po.Opt{
    po.callbackNoArg('v', "verbose", cbVerbose, "be more verbose"),
    po.callbackNoArg('q', "quiet", cbQuiet, "be more quiet"),
    po.string(0, "repo", &repo_opt, "repository", "repository"),
    po.bit(0, "all", &flags, PUSH_ALL, "push all branches"),
    po.fromAlias(po.bit(0, "branches", &flags, PUSH_ALL, "alias of --all")),
    po.bit(0, "mirror", &flags, PUSH_MIRROR | PUSH_FORCE, "mirror all refs"),
    po.boolean('d', "delete", &deleterefs, "delete refs"),
    po.boolean(0, "tags", &tags, "push tags (can't be used with --all or --branches or --mirror)"),
    po.bit('n', "dry-run", &flags, PUSH_DRY_RUN, "dry run"),
    po.bit(0, "porcelain", &flags, PUSH_PORCELAIN, "machine-readable output"),
    po.bit('f', "force", &flags, PUSH_FORCE, "force updates"),
    .{ .long = "force-with-lease", .kind = .callback, .cb = cbCas, .optarg = true, .literal_argh = true, .argh = "<refname>:<expect>", .help = "require old value of ref to be at this value" },
    po.bit(0, "force-if-includes", &flags, PUSH_FORCE_IF_INCLUDES, "require remote updates to be integrated locally"),
    po.callback(0, "recurse-submodules", cbRecurse, "(check|on-demand|no)", "control recursive pushing of submodules"),
    po.noComplete(po.boolean(0, "thin", &thin, "use thin pack")),
    po.string(0, "receive-pack", &receivepack, "receive-pack", "receive pack program"),
    po.string(0, "exec", &receivepack, "receive-pack", "receive pack program"),
    po.bit('u', "set-upstream", &flags, PUSH_SET_UPSTREAM, "set upstream for git pull/status"),
    po.callbackNoArg(0, "progress", cbProgress, "force progress reporting"),
    po.bit(0, "prune", &flags, PUSH_PRUNE, "prune locally removed refs"),
    .{ .long = "no-verify", .kind = .bit, .i = &flags, .val = PUSH_NO_HOOK, .help = "bypass pre-push hook" },
    po.bit(0, "follow-tags", &flags, PUSH_FOLLOW_TAGS, "push missing but relevant tags"),
    .{ .long = "signed", .kind = .callback, .cb = cbSigned, .optarg = true, .argh = "(yes|no|if-asked)", .help = "GPG sign the push" },
    po.bit(0, "atomic", &flags, PUSH_ATOMIC, "request atomic transaction on remote side"),
    po.list('o', "push-option", &push_options_cmdline, "server-specific", "option to transmit"),
    .{ .short = '4', .long = "ipv4", .kind = .set_int, .i = &family, .val = 4, .help = "use IPv4 addresses only", .noneg = true },
    .{ .short = '6', .long = "ipv6", .kind = .set_int, .i = &family, .val = 6, .help = "use IPv6 addresses only", .noneg = true },
};

fn loadConfig() void {
    const cfg = repo_mod.cfg;
    if (cfg.getBool("push.followtags")) |b| {
        if (b) flags |= PUSH_FOLLOW_TAGS else flags &= ~PUSH_FOLLOW_TAGS;
    }
    if (cfg.getBool("push.autosetupremote")) |b| {
        if (b) flags |= PUSH_AUTO_UPSTREAM;
    }
    if (cfg.getBool("push.useforceifincludes")) |b| {
        if (b) flags |= PUSH_FORCE_IF_INCLUDES else flags &= ~PUSH_FORCE_IF_INCLUDES;
    }
    for (cfg.entries.items) |e| {
        if (util.eql(e.key, "push.recursesubmodules")) {
            recurse_submodules = sf.parsePushRecurseArg(e.key, e.value);
        } else if (util.eql(e.key, "submodule.recurse")) {
            recurse_submodules = if (@import("../config.zig").configBool(e.key, e.value)) .on_demand else .off;
        }
    }
    for (cfg.getAll("push.pushoption")) |v| {
        if (v.len == 0) push_options_config.clearRetainingCapacity() else push_options_config.append(gpa, v) catch util.oom();
    }
    if (cfg.get("push.default")) |v| {
        if (util.eql(v, "nothing")) {
            push_default = .nothing;
        } else if (util.eql(v, "matching")) {
            push_default = .matching;
        } else if (util.eql(v, "simple")) {
            push_default = .simple;
        } else if (util.eql(v, "upstream") or util.eql(v, "tracking")) {
            push_default = .upstream;
        } else if (util.eql(v, "current")) {
            push_default = .current;
        } else {
            util.err("malformed value for push.default: {s}", .{v});
            util.err("must be one of nothing, matching, simple, upstream or current", .{});
            util.die("bad config variable 'push.default' in file '.git/config'", .{});
        }
    }
}

// ---------------- refspecs ----------------

fn refspecAppendMapped(ref: []const u8, remote: *Remote, matched: *Ref) void {
    if (remote.push.items.items.len > 0) {
        if (remote.push.findMatch(matched.name, null)) |m| {
            rs.append(util.fmt("{s}{s}:{s}", .{ if (m.force) "+" else "", matched.name, m.value }));
            return;
        }
    }
    if (push_default == .upstream) {
        if (util.skipPrefix(matched.name, "refs/heads/")) |bn| {
            if (tp.branchGet(bn)) |b| {
                if (b.merge.items.len == 1) {
                    rs.append(util.fmt("{s}:{s}", .{ ref, b.merge.items[0] }));
                    return;
                }
            }
        }
    }
    rs.append(ref);
}

fn setRefspecs(list: []const []const u8, remote: *Remote) void {
    var local_refs: ?[]*Ref = null;
    var i: usize = 0;
    while (i < list.len) : (i += 1) {
        var ref = list[i];
        if (util.eql(ref, "tag")) {
            i += 1;
            if (i >= list.len) util.die("tag shorthand without <tag>", .{});
            ref = list[i];
            if (deleterefs) {
                rs.append(util.fmt(":refs/tags/{s}", .{ref}));
            } else rs.append(util.fmt("refs/tags/{s}", .{ref}));
        } else if (deleterefs) {
            if (std.mem.indexOfScalar(u8, ref, ':') != null or ref.len == 0)
                util.die("--delete only accepts plain target ref names", .{});
            rs.append(util.fmt(":{s}", .{ref}));
        } else if (std.mem.indexOfScalar(u8, ref, ':') == null) {
            if (local_refs == null) local_refs = tp.getLocalHeads();
            var matched: ?*Ref = null;
            if (tp.countRefspecMatch(ref, local_refs.?, &matched) != 1) {
                rs.append(ref);
            } else refspecAppendMapped(ref, remote, matched.?);
        } else rs.append(ref);
    }
}

fn dieDetached(remote: *const Remote) noreturn {
    util.die("You are not currently on a branch.\n" ++
        "To push the history leading to the current (detached HEAD)\n" ++
        "state now, use\n" ++
        "\n" ++
        "    git push {s} HEAD:<name-of-remote-branch>\n", .{remote.name});
}

fn dieSimple(branch: *const tp.Branch, remote: *const Remote) noreturn {
    var short_upstream = branch.merge.items[0];
    if (util.skipPrefix(short_upstream, "refs/heads/")) |s| short_upstream = s;
    const a1: []const u8 = if (push_default == .unspecified)
        "\nTo choose either option permanently, see push.default in 'git help config'.\n"
    else
        "";
    const a2: []const u8 = if (branchcreate.configBranchTrack() != .simple)
        "\nTo avoid automatically configuring an upstream branch when its name\n" ++
            "won't match the local branch, see option 'simple' of branch.autoSetupMerge\n" ++
            "in 'git help config'.\n"
    else
        "";
    util.die("The upstream branch of your current branch does not match\n" ++
        "the name of your current branch.  To push to the upstream branch\n" ++
        "on the remote, use\n" ++
        "\n" ++
        "    git push {s} HEAD:{s}\n" ++
        "\n" ++
        "To push to the branch of the same name on the remote, use\n" ++
        "\n" ++
        "    git push {s} HEAD\n" ++
        "{s}{s}", .{ remote.name, short_upstream, remote.name, a1, a2 });
}

fn getUpstreamRef(fl: i32, branch: *const tp.Branch, remote_name: []const u8) []const u8 {
    if (branch.merge.items.len == 0 and fl & PUSH_AUTO_UPSTREAM != 0) return branch.refname;
    if (branch.merge.items.len == 0 or branch.remote_name == null) {
        const a: []const u8 = if (fl & PUSH_AUTO_UPSTREAM == 0)
            "\nTo have this happen automatically for branches without a tracking\n" ++
                "upstream, see 'push.autoSetupRemote' in 'git help config'.\n"
        else
            "";
        util.die("The current branch {s} has no upstream branch.\n" ++
            "To push the current branch and set the remote as upstream, use\n" ++
            "\n" ++
            "    git push --set-upstream {s} {s}\n" ++
            "{s}", .{ branch.name, remote_name, branch.name, a });
    }
    if (branch.merge.items.len != 1)
        util.die("The current branch {s} has multiple upstream branches, refusing to push.", .{branch.name});
    return branch.merge.items[0];
}

fn setupDefaultPushRefspecs(fl: *i32, remote: *Remote) void {
    switch (push_default) {
        .matching => {
            rs.append(":");
            return;
        },
        .nothing => util.die("You didn't specify any refspecs to push, and push.default is \"nothing\".", .{}),
        else => {},
    }
    const branch = tp.branchGet(null) orelse dieDetached(remote);
    var dst = branch.refname;
    const same_remote = util.eql(remote.name, branch.remote_name orelse "origin");
    switch (push_default) {
        .upstream => {
            if (!same_remote)
                util.die("You are pushing to remote '{s}', which is not the upstream of\n" ++
                    "your current branch '{s}', without telling me what to push\n" ++
                    "to update which remote branch.", .{ remote.name, branch.name });
            dst = getUpstreamRef(fl.*, branch, remote.name);
        },
        .current => {},
        else => {
            if (same_remote) {
                if (!util.eql(branch.refname, getUpstreamRef(fl.*, branch, remote.name))) dieSimple(branch, remote);
            }
        },
    }
    if (fl.* & PUSH_AUTO_UPSTREAM != 0 and branch.merge.items.len == 0) fl.* |= PUSH_SET_UPSTREAM;
    rs.append(util.fmt("{s}:{s}", .{ branch.refname, dst }));
}

// ---------------- send-pack ----------------

fn cStatusNum(s: tp.PushStatus) u32 {
    return switch (s) {
        .none => 0,
        .ok => 1,
        .reject_nonfastforward => 2,
        .reject_already_exists => 3,
        .reject_nodelete => 4,
        .reject_fetch_first => 5,
        .reject_needs_force => 6,
        .reject_stale => 7,
        .reject_shallow => 8,
        .reject_remote_updated => 9,
        .uptodate => 10,
        .remote_reject => 11,
        .expecting_report => 12,
        .atomic_push_failed => 13,
    };
}

const SendArgs = struct {
    send_mirror: bool,
    force_update: bool,
    use_thin_pack: bool,
    quiet: bool,
    progress: bool,
    dry_run: bool,
    atomic: bool,
    push_options: ?[]const []const u8,
};

const CheckResult = enum { send, no_push, rejected, uptodate };

fn checkToSendUpdate(r: *const Ref, a: *const SendArgs) CheckResult {
    if (r.peer_ref == null and !a.send_mirror) return .no_push;
    return switch (r.status) {
        .reject_nonfastforward, .reject_already_exists, .reject_fetch_first, .reject_needs_force, .reject_stale, .reject_remote_updated, .reject_nodelete => .rejected,
        .uptodate => .uptodate,
        else => .send,
    };
}

/// Iterates pkt-lines held in a buffer (sideband band-1 payload).
const BufReader = struct {
    data: []const u8,
    pos: usize = 0,

    fn next(self: *BufReader) ?[]const u8 {
        if (self.pos + 4 > self.data.len) return null;
        const len = std.fmt.parseInt(usize, self.data[self.pos .. self.pos + 4], 16) catch return null;
        if (len < 4) {
            pkt.packetTrace(self.data[self.pos .. self.pos + 4], false);
            self.pos += 4;
            return null;
        }
        if (self.pos + len > self.data.len) return null;
        var line = self.data[self.pos + 4 .. self.pos + len];
        self.pos += len;
        if (line.len > 0 and line[line.len - 1] == '\n') line = line[0 .. line.len - 1];
        pkt.packetTrace(line, false);
        if (util.skipPrefix(line, "ERR ")) |e| util.die("remote error: {s}", .{e});
        return line;
    }
};

const StatusSource = struct {
    buf: ?*BufReader,
    rd: *pkt.Reader,

    fn next(self: *StatusSource) ?[]const u8 {
        if (self.buf) |b| return b.next();
        if (self.rd.read() != .normal) return null;
        const l = self.rd.line;
        if (util.skipPrefix(l, "ERR ")) |e| util.die("remote error: {s}", .{e});
        return l;
    }
};

fn receiveStatus(src: *StatusSource, list: []const *Ref) bool {
    var ok = true;
    if (src.next()) |l| {
        if (util.skipPrefix(l, "unpack ")) |st| {
            if (!util.eql(st, "ok")) {
                util.err("remote unpack failed: {s}", .{st});
                ok = false;
            }
        } else {
            util.err("unable to parse remote unpack status: {s}", .{l});
            ok = false;
        }
    } else {
        util.err("unexpected flush packet while reading remote unpack status", .{});
        ok = false;
    }
    var hint: ?*Ref = null;
    var once = false;
    var new_report = false;
    while (src.next()) |l| {
        const sp = std.mem.indexOfScalar(u8, l, ' ') orelse {
            util.err("invalid status line from remote: {s}", .{l});
            ok = false;
            break;
        };
        const head = l[0..sp];
        const rest = l[sp + 1 ..];
        if (util.eql(head, "option")) {
            if (hint == null or !new_report) {
                if (!once) util.err("'option' without a matching 'ok/ng' directive", .{});
                once = true;
                ok = false;
                continue;
            }
            const ksp = std.mem.indexOfScalar(u8, rest, ' ');
            const key = if (ksp) |k| rest[0..k] else rest;
            const val: ?[]const u8 = if (ksp) |k| rest[k + 1 ..] else null;
            const h = hint.?;
            if (util.eql(key, "refname")) {
                if (val) |v| h.name = util.dupe(v);
            } else if (util.eql(key, "old-oid")) {
                if (val) |v| if (hash.fromHex(v)) |o| {
                    h.old_oid = o;
                };
            } else if (util.eql(key, "new-oid")) {
                if (val) |v| if (hash.fromHex(v)) |o| {
                    h.new_oid = o;
                };
            } else if (util.eql(key, "forced-update")) h.forced_update = true;
            continue;
        }
        new_report = false;
        if (!util.eql(head, "ok") and !util.eql(head, "ng")) {
            util.err("invalid ref status from remote: {s}", .{head});
            ok = false;
            break;
        }
        const msp = std.mem.indexOfScalar(u8, rest, ' ');
        const refname = if (msp) |m| rest[0..m] else rest;
        const msg: ?[]const u8 = if (msp) |m| rest[m + 1 ..] else null;
        hint = tp.findRefByName(list, refname);
        const h = hint orelse {
            util.warn("remote reported status on unknown ref: {s}", .{refname});
            continue;
        };
        if (h.status != .expecting_report and h.status != .ok and h.status != .remote_reject) {
            util.warn("remote reported status on unexpected ref: {s}", .{refname});
            continue;
        }
        if (util.eql(head, "ng")) {
            h.status = .remote_reject;
            h.remote_status = util.dupe(msg orelse "failed");
        } else {
            h.status = .ok;
            h.remote_status = if (msg) |m| util.dupe(m) else null;
            new_report = true;
        }
    }
    return ok;
}

fn appendHave(haves: *util.Buf, oid: Oid) void {
    if (!repo_mod.repo().odb().has(oid)) return;
    util.bufPrint(haves, "{s}\n", .{hash.hex(oid)});
}

/// get_commons_through_negotiation() (push.negotiate)
fn commonsThroughNegotiation(t: *Transport, remote_refs: []const *Ref) []const Oid {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ "fetch", "--negotiate-only" }) catch util.oom();
    var nr: usize = 0;
    const restrict = t.remote.negotiation_restrict.items;
    if (restrict.len > 0) {
        for (restrict) |s| argv.append(gpa, util.fmt("--negotiation-restrict={s}", .{s})) catch util.oom();
        nr = restrict.len;
    } else {
        for (remote_refs) |r| {
            if (!hash.isZero(r.new_oid)) {
                argv.append(gpa, util.fmt("--negotiation-restrict={s}", .{hash.hex(r.new_oid)})) catch util.oom();
                nr += 1;
            }
        }
    }
    for (t.remote.negotiation_include.items) |s| argv.append(gpa, util.fmt("--negotiation-include={s}", .{s})) catch util.oom();
    nr += t.remote.negotiation_include.items.len;
    argv.append(gpa, t.url) catch util.oom();
    var commons: std.ArrayList(Oid) = .empty;
    if (nr == 0) return commons.items;
    var ch = proc.spawnGit(argv.items, .{ .no_stdin = true, .pipe_out = true });
    const data = os.readAllFd(ch.out) catch "";
    proc.closeFd(&ch.out);
    var rest = data;
    while (rest.len > 0) {
        if (rest.len < 41) util.die("invalid length read {d}", .{rest.len});
        const oid = hash.fromHex(rest[0..40]) orelse util.die("invalid hash", .{});
        if (rest[40] != '\n') util.die("invalid hash", .{});
        commons.append(gpa, oid) catch util.oom();
        rest = rest[41..];
    }
    if (proc.wait(ch.pid) != 0) util.warn("push negotiation failed; proceeding anyway with push", .{});
    return commons.items;
}

var push_commons: []const Oid = &.{};

/// Run pack-objects writing straight into the remote's stdin.
fn packObjects(t: *Transport, list: []const *Ref, a: *const SendArgs, use_ofs_delta: bool) bool {
    var argv: std.ArrayList([]const u8) = .empty;
    argv.appendSlice(gpa, &.{ "pack-objects", "--revs", "--stdout" }) catch util.oom();
    if (a.use_thin_pack) argv.append(gpa, "--thin") catch util.oom();
    if (use_ofs_delta) argv.append(gpa, "--delta-base-offset") catch util.oom();
    argv.append(gpa, if (a.progress) "--all-progress" else "--quiet") catch util.oom();
    var input: util.Buf = .empty;
    var haves: util.Buf = .empty;
    for (t.remote_refs) |r| appendHave(&haves, r.old_oid);
    for (push_commons) |o| appendHave(&haves, o);
    for (list) |r| {
        if (!hash.isZero(r.old_oid)) appendHave(&haves, r.old_oid);
        if (!hash.isZero(r.new_oid)) util.bufPrint(&input, "{s}\n", .{hash.hex(r.new_oid)});
    }
    util.bufAppend(&input, "--not\n");
    util.bufAppend(&input, haves.items);
    util.bufAppend(&input, "\n");
    proc.ignoreSigpipe();
    var ch = proc.spawnGit(argv.items, .{ .pipe_in = true, .out_fd = t.fd_out });
    proc.closeFd(&t.fd_out);
    var write_ok = true;
    os.writeAll(ch.in, input.items) catch {
        write_ok = false;
    };
    proc.closeFd(&ch.in);
    const rc = proc.wait(ch.pid);
    // git:// connections: let receive-pack see the end of the pack
    proc.shutdownWrite(t.rd.fd);
    if (!write_ok) util.err("error writing to pack-objects", .{});
    if (rc != 0) util.die("git pack-objects failed", .{});
    return write_ok;
}

/// reject_invalid_nonce()
fn rejectInvalidNonce(nonce: []const u8) void {
    if (nonce.len >= 256) util.die("the receiving end asked to sign an invalid nonce <{s}>", .{nonce});
    for (nonce) |ch| {
        if (std.ascii.isAlphanumeric(ch) or ch == '-' or ch == '.' or ch == '/' or ch == '+' or ch == '=' or ch == '_') continue;
        util.die("the receiving end asked to sign an invalid nonce <{s}>", .{nonce});
    }
}

/// generate_push_cert()
fn generatePushCert(req: *util.Buf, list: []const *Ref, args: *const SendArgs, url: []const u8, cap_string: []const u8, nonce: []const u8) bool {
    const gpg = @import("../gpg.zig");
    const signing_key_id = gpg.getSigningKeyId() orelse "";
    const signing_key = gpg.getSigningKey();
    var cert: util.Buf = .empty;
    util.bufAppend(&cert, "certificate version 0.1\n");
    util.bufPrint(&cert, "pusher {s} {s}\n", .{ signing_key_id, @import("../date.zig").datestamp() });
    if (url.len > 0) util.bufPrint(&cert, "pushee {s}\n", .{tp.anonymizeUrl(url)});
    if (nonce.len > 0) util.bufPrint(&cert, "nonce {s}\n", .{nonce});
    if (args.push_options) |po_list| for (po_list) |o| util.bufPrint(&cert, "push-option {s}\n", .{o});
    util.bufAppend(&cert, "\n");
    var update_seen = false;
    for (list) |r| {
        if (checkToSendUpdate(r, args) != .send) continue;
        update_seen = true;
        util.bufPrint(&cert, "{s} {s} {s}\n", .{ hash.hex(r.old_oid), hash.hex(r.new_oid), r.name });
    }
    if (!update_seen) return false;
    var sig: util.Buf = .empty;
    if (gpg.signBuffer(cert.items, &sig, signing_key, false) != 0) util.die("failed to sign the push certificate", .{});
    util.bufAppend(&cert, sig.items);
    pkt.bufFmt(req, "push-cert\x00{s}", .{cap_string});
    var rest: []const u8 = cert.items;
    while (rest.len > 0) {
        const nl = std.mem.indexOfScalar(u8, rest, '\n');
        const n = if (nl) |x| x + 1 else rest.len;
        pkt.bufWrite(req, rest[0..n]);
        rest = rest[n..];
    }
    pkt.bufWrite(req, "push-cert-end\n");
    return true;
}

/// send_pack(); returns false on a protocol-level failure.
fn sendPack(t: *Transport, list: []const *Ref, a: *const SendArgs) bool {
    if (list.len == 0) {
        util.ewrite("No refs in common and none specified; doing nothing.\nPerhaps you should specify a branch.\n");
        return true;
    }
    if (repo_mod.cfg.getBool("push.negotiate") orelse false) {
        const t2 = @import("../trace2.zig");
        t2.regionEnter("send_pack", "push_negotiate", true);
        push_commons = commonsThroughNegotiation(t, list);
        t2.regionLeave("send_pack", "push_negotiate", true);
    }
    var status_report: u8 = 0;
    if (t.serverSupportsV0("report-status-v2")) {
        status_report = 2;
    } else if (t.serverSupportsV0("report-status")) status_report = 1;
    const allow_deleting_refs = t.serverSupportsV0("delete-refs");
    const use_ofs_delta = t.serverSupportsV0("ofs-delta");
    const use_sideband = t.serverSupportsV0("side-band-64k");
    const quiet_supported = t.serverSupportsV0("quiet");
    const agent_supported = t.serverSupportsV0("agent");
    var args = a.*;
    if (t.serverSupportsV0("no-thin")) args.use_thin_pack = false;
    const atomic_supported = t.serverSupportsV0("atomic");
    const push_options_supported = t.serverSupportsV0("push-options");
    var object_format_supported = false;
    if (tp.capValue(t.caps_v0, "object-format")) |f| {
        object_format_supported = true;
        if (!util.eql(f, "sha1")) util.die("the receiving end does not support this repository's hash algorithm", .{});
    }
    var push_cert_nonce: ?[]const u8 = null;
    if (signed) |s| {
        if (tp.capValue(t.caps_v0, "push-cert")) |nonce| {
            rejectInvalidNonce(nonce);
            push_cert_nonce = nonce;
        } else if (util.eql(s, "yes")) {
            util.die("the receiving end does not support --signed push", .{});
        } else util.warn("not sending a push certificate since the receiving end does not support --signed push", .{});
    }
    if (args.atomic and !atomic_supported) util.die("the receiving end does not support --atomic push", .{});
    const use_atomic = atomic_supported and args.atomic;
    if (args.push_options != null and !push_options_supported) util.die("the receiving end does not support push options", .{});
    const use_push_options = push_options_supported and args.push_options != null;

    var cap: util.Buf = .empty;
    if (status_report == 1) util.bufAppend(&cap, " report-status") else if (status_report == 2) util.bufAppend(&cap, " report-status-v2");
    if (use_sideband) util.bufAppend(&cap, " side-band-64k");
    if (quiet_supported and (args.quiet or !args.progress)) util.bufAppend(&cap, " quiet");
    if (use_atomic) util.bufAppend(&cap, " atomic");
    if (use_push_options) util.bufAppend(&cap, " push-options");
    if (object_format_supported) util.bufAppend(&cap, " object-format=sha1");
    if (agent_supported) util.bufPrint(&cap, " agent={s}", .{up.agentSanitized()});

    for (list) |r| {
        if (r.deletion and !allow_deleting_refs) r.status = .reject_nodelete;
    }
    var need_pack_data = false;
    for (list) |r| {
        switch (checkToSendUpdate(r, &args)) {
            .send => {},
            .rejected => {
                if (use_atomic) {
                    for (list) |o| {
                        if (o.peer_ref == null and !args.send_mirror) continue;
                        switch (o.status) {
                            .none, .ok, .expecting_report => o.status = .atomic_push_failed,
                            else => {},
                        }
                    }
                    util.err("atomic push failed for ref {s}. status: {d}", .{ r.name, cStatusNum(r.status) });
                    pkt.flush(t.fd_out);
                    return true;
                }
                continue;
            },
            else => continue,
        }
        if (!r.deletion) need_pack_data = true;
        r.status = if (args.dry_run or status_report == 0) .ok else .expecting_report;
    }
    var req: util.Buf = .empty;
    var cmds_sent = false;
    if (!args.dry_run and push_cert_nonce != null) {
        cmds_sent = generatePushCert(&req, list, &args, t.url, cap.items, push_cert_nonce.?);
    } else if (!args.dry_run) {
        for (list) |r| {
            if (checkToSendUpdate(r, &args) != .send) continue;
            if (!cmds_sent) {
                pkt.bufFmt(&req, "{s} {s} {s}\x00{s}", .{ hash.hex(r.old_oid), hash.hex(r.new_oid), r.name, cap.items });
                cmds_sent = true;
            } else pkt.bufFmt(&req, "{s} {s} {s}", .{ hash.hex(r.old_oid), hash.hex(r.new_oid), r.name });
        }
    }
    if (use_push_options) {
        pkt.bufFlush(&req);
        for (args.push_options.?) |o| pkt.bufWrite(&req, o);
    }
    pkt.bufFlush(&req);
    os.writeAll(t.fd_out, req.items) catch util.die("unable to write to remote: {s}", .{os.lastErr()});

    var ok = true;
    if (need_pack_data and cmds_sent) {
        if (!packObjects(t, list, &args, use_ofs_delta)) ok = false;
    }
    // collect the response
    var bufrd: BufReader = .{ .data = "" };
    var src = StatusSource{ .buf = null, .rd = t.rd };
    t.rd.die_on_err_packet = true;
    if (use_sideband and cmds_sent) {
        var data: util.Buf = .empty;
        var demux: pkt.Demux = .{};
        const saved_chomp = t.rd.chomp;
        t.rd.chomp = false;
        pkt.in_async = true;
        while (true) {
            _ = t.rd.read();
            if (t.rd.status == .eof) {
                demux.finish();
                break;
            }
            switch (demux.handle(t.rd, "send-pack")) {
                .data => |d| util.bufAppend(&data, d),
                .consumed => {},
                .end => break,
            }
        }
        pkt.in_async = false;
        t.rd.chomp = saved_chomp;
        bufrd.data = data.items;
        src.buf = &bufrd;
    }
    if (status_report != 0 and cmds_sent) {
        if (!receiveStatus(&src, list)) ok = false;
    }
    return ok;
}

// ---------------- status output ----------------

fn pushHadErrors(list: []const *Ref) bool {
    for (list) |r| switch (r.status) {
        .none, .uptodate, .ok => {},
        else => return true,
    };
    return false;
}

fn refsPushed(list: []const *Ref) bool {
    for (list) |r| switch (r.status) {
        .none, .uptodate => {},
        else => return true,
    };
    return false;
}

fn printRefStatus(flag: u8, summary: []const u8, to: *const Ref, from: ?*const Ref, msg: ?[]const u8, porcelain: bool, width: usize) void {
    if (porcelain) {
        var b: util.Buf = .empty;
        if (from) |f| {
            util.bufPrint(&b, "{c}\t{s}:{s}\t", .{ flag, f.name, to.name });
        } else util.bufPrint(&b, "{c}\t:{s}\t", .{ flag, to.name });
        if (msg) |m| util.bufPrint(&b, "{s} ({s})\n", .{ summary, m }) else util.bufPrint(&b, "{s}\n", .{summary});
        util.stdout.write(b.items);
        return;
    }
    var b: util.Buf = .empty;
    util.bufPrint(&b, " {c} ", .{flag});
    util.bufAppend(&b, summary);
    var pad = summary.len;
    while (pad < width) : (pad += 1) util.bufByte(&b, ' ');
    util.bufByte(&b, ' ');
    if (from) |f| {
        util.bufPrint(&b, "{s} -> {s}", .{ logtree.prettifyRefname(f.name), logtree.prettifyRefname(to.name) });
    } else util.bufAppend(&b, logtree.prettifyRefname(to.name));
    if (msg) |m| util.bufPrint(&b, " ({s})", .{m});
    util.bufByte(&b, '\n');
    util.ewrite(b.items);
}

fn printOkRefStatus(r: *const Ref, porcelain: bool, width: usize) void {
    if (r.deletion) {
        printRefStatus('-', "[deleted]", r, null, null, porcelain, width);
    } else if (hash.isZero(r.old_oid)) {
        const s: []const u8 = if (util.startsWith(r.name, "refs/tags/"))
            "[new tag]"
        else if (util.startsWith(r.name, "refs/heads/"))
            "[new branch]"
        else
            "[new reference]";
        printRefStatus('*', s, r, r.peer_ref, null, porcelain, width);
    } else {
        const sep: []const u8 = if (r.forced_update) "..." else "..";
        const q = util.concat(&.{ revparse.abbrev(r.old_oid, 0), sep, revparse.abbrev(r.new_oid, 0) });
        printRefStatus(if (r.forced_update) '+' else ' ', q, r, r.peer_ref, if (r.forced_update) "forced update" else null, porcelain, width);
    }
}

fn printOnePushStatus(r: *const Ref, dest: []const u8, count: usize, porcelain: bool, width: usize) void {
    if (count == 0) {
        const line = util.fmt("To {s}\n", .{tp.anonymizeUrl(dest)});
        if (porcelain) util.stdout.write(line) else util.ewrite(line);
    }
    const peer = r.peer_ref;
    switch (r.status) {
        .none => printRefStatus('X', "[no match]", r, null, null, porcelain, width),
        .reject_nodelete => printRefStatus('!', "[rejected]", r, null, "remote does not support deleting refs", porcelain, width),
        .uptodate => printRefStatus('=', "[up to date]", r, peer, null, porcelain, width),
        .reject_nonfastforward => printRefStatus('!', "[rejected]", r, peer, "non-fast-forward", porcelain, width),
        .reject_already_exists => printRefStatus('!', "[rejected]", r, peer, "already exists", porcelain, width),
        .reject_fetch_first => printRefStatus('!', "[rejected]", r, peer, "fetch first", porcelain, width),
        .reject_needs_force => printRefStatus('!', "[rejected]", r, peer, "needs force", porcelain, width),
        .reject_stale => printRefStatus('!', "[rejected]", r, peer, "stale info", porcelain, width),
        .reject_remote_updated => printRefStatus('!', "[rejected]", r, peer, "remote ref updated since checkout", porcelain, width),
        .reject_shallow => printRefStatus('!', "[rejected]", r, peer, "new shallow roots not allowed", porcelain, width),
        .remote_reject => printRefStatus('!', "[remote rejected]", r, if (r.deletion) null else peer, r.remote_status, porcelain, width),
        .expecting_report => printRefStatus('!', "[remote failure]", r, if (r.deletion) null else peer, "remote failed to report status", porcelain, width),
        .atomic_push_failed => printRefStatus('!', "[rejected]", r, peer, "atomic push failed", porcelain, width),
        .ok => printOkRefStatus(r, porcelain, width),
    }
}

fn summaryWidth(list: []const *Ref) usize {
    var maxw: usize = 0;
    var any = false;
    for (list) |r| {
        maxw = @max(maxw, @max(revparse.abbrev(r.old_oid, 0).len, revparse.abbrev(r.new_oid, 0).len));
        any = true;
    }
    if (!any) maxw = 7;
    return 2 * maxw + 3;
}

fn printPushStatus(dest: []const u8, list: []const *Ref, verbose: bool, porcelain: bool, reasons: *u32) void {
    const width = summaryWidth(list);
    const head: ?[]const u8 = if (refs.resolve("HEAD")) |h| h.name else null;
    var n: usize = 0;
    if (verbose) {
        for (list) |r| if (r.status == .uptodate) {
            printOnePushStatus(r, dest, n, porcelain, width);
            n += 1;
        };
    }
    for (list) |r| if (r.status == .ok) {
        printOnePushStatus(r, dest, n, porcelain, width);
        n += 1;
    };
    reasons.* = 0;
    for (list) |r| {
        if (r.status != .none and r.status != .uptodate and r.status != .ok) {
            printOnePushStatus(r, dest, n, porcelain, width);
            n += 1;
        }
        switch (r.status) {
            .reject_nonfastforward => {
                if (head != null and util.eql(head.?, r.name)) {
                    reasons.* |= REJECT_NON_FF_HEAD;
                } else reasons.* |= REJECT_NON_FF_OTHER;
            },
            .reject_already_exists => reasons.* |= REJECT_ALREADY_EXISTS,
            .reject_fetch_first => reasons.* |= REJECT_FETCH_FIRST,
            .reject_needs_force => reasons.* |= REJECT_NEEDS_FORCE,
            .reject_remote_updated => reasons.* |= REJECT_REF_NEEDS_UPDATE,
            else => {},
        }
    }
}

// ---------------- transport_push ----------------

fn runPrePushHook(t: *Transport, list: []const *Ref) bool {
    const path = hook.find("pre-push") orelse return true;
    var input: util.Buf = .empty;
    for (list) |r| {
        switch (r.status) {
            .reject_nonfastforward, .reject_remote_updated, .reject_stale, .uptodate => continue,
            else => {},
        }
        const p = r.peer_ref orelse continue;
        util.bufPrint(&input, "{s} {s} {s} {s}\n", .{ p.name, hash.hex(r.new_oid), r.name, hash.hex(r.old_oid) });
    }
    util.flushStdout();
    const res = os.run(&.{ path, t.remote.name, t.url }, .{ .stdin_data = input.items });
    return res.status == 0;
}

fn setUpstreams(t: *Transport, list: []const *Ref, pretend: bool) void {
    for (list) |r| {
        if (r.status != .ok and r.status != .uptodate) continue;
        const p = r.peer_ref orelse continue;
        if (hash.isZero(r.new_oid)) continue;
        var localname = p.name;
        const remotename = r.name;
        const rr = refs.resolveFull(localname, true);
        if (!rr.missing and !rr.broken and rr.flags & refs.REF_ISSYMREF != 0 and util.startsWith(rr.name, "refs/heads/"))
            localname = rr.name;
        if (!util.startsWith(localname, "refs/heads/")) continue;
        if (!util.startsWith(remotename, "refs/heads/")) continue;
        if (!pretend) {
            _ = branchcreate.installBranchConfig(t.verbose >= 0, localname[11..], t.remote.name, remotename);
        } else if (t.verbose >= 0) {
            util.stdout.print("Would set upstream of '{s}' to '{s}' of '{s}'\n", .{ localname[11..], remotename[11..], t.remote.name });
        }
    }
}

fn remoteForPushTracking(remote: *Remote) *Remote {
    if (remote.configured or remote.from_config) return remote;
    const urls = tp.pushUrls(remote);
    if (urls.len != 1) return remote;
    var first: ?*Remote = null;
    for (tp.allRemotes()) |cand| {
        if (cand == remote or !tp.remoteIsConfigured(cand, false)) continue;
        var has = false;
        for (tp.pushUrls(cand)) |u| {
            if (util.eql(u, urls[0])) has = true;
        }
        if (!has) continue;
        if (first != null) return remote;
        first = cand;
    }
    return first orelse remote;
}

fn updateTrackingRef(remote: *const Remote, r: *const Ref, verbose: bool) void {
    if (r.status != .ok and r.status != .uptodate) return;
    const dst = tp.remoteFindTracking(remote, r.name) orelse return;
    if (verbose) util.ewrite(util.fmt("updating local tracking ref '{s}'\n", .{dst}));
    if (r.deletion) {
        refs.deleteRef(dst, null, 0, null) catch util.err("{s}", .{refs.last_error});
    } else {
        refs.updateFlags(dst, r.new_oid, null, "update by push", 0) catch util.err("{s}", .{refs.last_error});
    }
}

/// transport_push(); returns 0 on success, nonzero on errors.
fn transportPush(t: *Transport, refspec: *tp.Refspec, fl: i32, reasons: *u32) i32 {
    reasons.* = 0;
    const verbose = t.verbose > 0;
    const quiet = t.verbose < 0;
    const porcelain = fl & PUSH_PORCELAIN != 0;
    const pretend = fl & PUSH_DRY_RUN != 0;
    const local_refs = tp.getLocalHeads();
    if (!tp.checkPushRefs(local_refs, refspec)) return -1;
    tp.connect(t, true);
    var remote_refs: std.ArrayList(*Ref) = .empty;
    remote_refs.appendSlice(gpa, t.remote_refs) catch util.oom();
    var match_flags: u32 = 0;
    if (fl & PUSH_ALL != 0) match_flags |= tp.MATCH_REFS_ALL;
    if (fl & PUSH_MIRROR != 0) match_flags |= tp.MATCH_REFS_MIRROR;
    if (fl & PUSH_PRUNE != 0) match_flags |= tp.MATCH_REFS_PRUNE;
    if (fl & PUSH_FOLLOW_TAGS != 0) match_flags |= tp.MATCH_REFS_FOLLOW_TAGS;
    if (!tp.matchPushRefs(local_refs, &remote_refs, refspec, match_flags)) return -1;
    if (cas_entries.items.len > 0 or cas_use_tracking_for_rest) applyPushCas(t.remote, remote_refs.items, fl & PUSH_FORCE_IF_INCLUDES != 0);
    tp.setRefStatusForPush(remote_refs.items, fl & PUSH_MIRROR != 0, fl & PUSH_FORCE != 0);
    if (fl & PUSH_NO_HOOK == 0) {
        if (!runPrePushHook(t, remote_refs.items)) return -1;
    }
    pushSubmodulesIfNeeded(t, refspec, remote_refs.items, fl);
    const args = SendArgs{
        .send_mirror = fl & PUSH_MIRROR != 0,
        .force_update = fl & PUSH_FORCE != 0,
        .use_thin_pack = t.thin,
        .quiet = quiet,
        .progress = t.progress,
        .dry_run = pretend,
        .atomic = fl & PUSH_ATOMIC != 0,
        .push_options = if (fl & PUSH_OPTIONS != 0) t.server_options else null,
    };
    var push_ret: i32 = 0;
    if (recurse_submodules == .only) {
        push_ret = 0;
    } else if (t.hd != null) {
        push_ret = th.pushRefs(t, remote_refs.items, .{
            .force = fl & PUSH_FORCE != 0,
            .mirror = fl & PUSH_MIRROR != 0,
            .atomic = fl & PUSH_ATOMIC != 0,
            .dry_run = pretend,
            .cert = if (signed) |s| (if (util.eql(s, "if-asked")) .if_asked else .always) else .never,
            .force_if_includes = fl & PUSH_FORCE_IF_INCLUDES != 0,
            .push_options = if (fl & PUSH_OPTIONS != 0) t.server_options else null,
        });
    } else {
        push_ret = if (sendPack(t, remote_refs.items, &args)) 0 else -1;
        if (tp.finish(t) != 0) push_ret = -1;
    }
    t.got_remote_heads = false;
    const err = pushHadErrors(remote_refs.items);
    const ret: i32 = push_ret | @as(i32, @intFromBool(err));
    if (!quiet or err) printPushStatus(t.url, remote_refs.items, verbose or porcelain, porcelain, reasons);
    if (fl & PUSH_SET_UPSTREAM != 0) setUpstreams(t, remote_refs.items, pretend);
    if (!pretend and recurse_submodules != .only) {
        const tr = remoteForPushTracking(t.remote);
        for (remote_refs.items) |r| updateTrackingRef(tr, r, verbose);
    }
    if (porcelain and push_ret == 0) {
        util.stdout.write("Done\n");
    } else if (!quiet and ret == 0 and !refsPushed(remote_refs.items)) {
        util.ewrite("Everything up-to-date\n");
    }
    return ret;
}

fn pushSubmodulesIfNeeded(t: *Transport, refspec: *tp.Refspec, list: []const *Ref, fl: i32) void {
    const rsm = recurse_submodules;
    if (rsm != .check and rsm != .on_demand and rsm != .only) return;
    if (repo_mod.repo().work_tree == null) return;
    const pretend = fl & PUSH_DRY_RUN != 0;
    var commits: std.ArrayList(Oid) = .empty;
    for (list) |r| {
        if (!std.mem.eql(u8, &r.new_oid, &hash.zero)) commits.append(gpa, r.new_oid) catch util.oom();
    }
    if (rsm == .on_demand or rsm == .only) {
        var raw: std.ArrayList([]const u8) = .empty;
        for (refspec.items.items) |it| raw.append(gpa, it.raw) catch util.oom();
        const configured = t.remote.from_config or t.remote.configured;
        const popts = if (fl & PUSH_OPTIONS != 0) t.server_options else &.{};
        if (!sf.pushUnpushedSubmodules(commits.items, t.remote.name, configured, raw.items, popts, pretend))
            util.die("failed to push all needed submodules", .{});
    }
    if (rsm == .check or !pretend) {
        const needs = sf.findUnpushedSubmodules(commits.items, t.remote.name);
        if (needs.len > 0) sf.dieWithUnpushedSubmodules(needs);
    }
}

fn adviseGated(key: []const u8, msg: []const u8) void {
    if (!advice.enabled(key)) return;
    if (!advice.enabled("pushUpdateRejected") or !advice.enabled("pushNonFastForward")) return;
    advice.advise(msg);
}

fn pushWithOptions(t: *Transport, refspec: *tp.Refspec, fl: i32) bool {
    const anon = tp.anonymizeUrl(t.url);
    t.verbose = verbosity;
    t.quiet = verbosity < 0;
    t.progress = if (progress >= 0) progress == 1 else (verbosity >= 0 and os.isatty(2));
    if (receivepack) |r| t.receivepack = r;
    t.family = @intCast(family);
    t.thin = thin;
    if (receivepack) |r| th.transportSetOption(t, "receivepack", r);
    th.transportSetOption(t, "thin", if (thin) "yes" else null);
    if (verbosity > 0) util.ewrite(util.fmt("Pushing to {s}\n", .{anon}));
    var reasons: u32 = 0;
    var err = transportPush(t, refspec, fl, &reasons);
    if (err != 0) util.err("failed to push some refs to '{s}'", .{anon});
    if (t.hd != null) {
        if (tp.disconnect(t) != 0) err |= 1;
    } else if (t.child != null) _ = tp.disconnect(t);
    if (err == 0) return true;
    if (reasons & REJECT_NON_FF_HEAD != 0) {
        adviseGated("pushNonFFCurrent", "Updates were rejected because the tip of your current branch is behind\n" ++
            "its remote counterpart. If you want to integrate the remote changes,\n" ++
            "use 'git pull' before pushing again.\n" ++
            "See the 'Note about fast-forwards' in 'git push --help' for details.");
    } else if (reasons & REJECT_NON_FF_OTHER != 0) {
        adviseGated("pushNonFFMatching", "Updates were rejected because a pushed branch tip is behind its remote\n" ++
            "counterpart. If you want to integrate the remote changes, use 'git pull'\n" ++
            "before pushing again.\n" ++
            "See the 'Note about fast-forwards' in 'git push --help' for details.");
    } else if (reasons & REJECT_ALREADY_EXISTS != 0) {
        adviseGated("pushAlreadyExists", "Updates were rejected because the tag already exists in the remote.");
    } else if (reasons & REJECT_FETCH_FIRST != 0) {
        adviseGated("pushFetchFirst", "Updates were rejected because the remote contains work that you do not\n" ++
            "have locally. This is usually caused by another repository pushing to\n" ++
            "the same ref. If you want to integrate the remote changes, use\n" ++
            "'git pull' before pushing again.\n" ++
            "See the 'Note about fast-forwards' in 'git push --help' for details.");
    } else if (reasons & REJECT_NEEDS_FORCE != 0) {
        adviseGated("pushNeedsForce", "You cannot update a remote ref that points at a non-commit object,\n" ++
            "or update a remote ref to make it point at a non-commit object,\n" ++
            "without using the '--force' option.");
    } else if (reasons & REJECT_REF_NEEDS_UPDATE != 0) {
        adviseGated("pushRefNeedsUpdate", "Updates were rejected because the tip of the remote-tracking branch has\n" ++
            "been updated since the last checkout. If you want to integrate the\n" ++
            "remote changes, use 'git pull' before pushing again.\n" ++
            "See the 'Note about fast-forwards' in 'git push --help' for details.");
    }
    return false;
}

fn doPush(fl0: i32, push_options: []const []const u8, remote: *Remote) u8 {
    var fl = fl0;
    if (push_options.len > 0) fl |= PUSH_OPTIONS;
    var refspec = &rs;
    if (rs.items.items.len == 0 and fl & PUSH_ALL == 0) {
        if (remote.push.items.items.len > 0) {
            refspec = &remote.push;
        } else if (fl & PUSH_MIRROR == 0) setupDefaultPushRefspecs(&fl, remote);
    }
    var errs: usize = 0;
    for (tp.pushUrls(remote)) |url| {
        const t = tp.transportGet(remote, url);
        if (fl & PUSH_OPTIONS != 0) t.server_options = push_options;
        if (!pushWithOptions(t, refspec, fl)) errs += 1;
    }
    return if (errs > 0) 1 else 0;
}

fn pushMultiple(list: []const []const u8, push_options: []const []const u8, fl: i32, refspecs: []const []const u8) u8 {
    var argv: std.ArrayList([]const u8) = .empty;
    const add = struct {
        fn f(l: *std.ArrayList([]const u8), s: []const u8) void {
            l.append(gpa, s) catch util.oom();
        }
    }.f;
    add(&argv, "push");
    if (fl & PUSH_FORCE != 0) add(&argv, "--force");
    if (fl & PUSH_DRY_RUN != 0) add(&argv, "--dry-run");
    if (fl & PUSH_PORCELAIN != 0) add(&argv, "--porcelain");
    if (fl & PUSH_PRUNE != 0) add(&argv, "--prune");
    if (fl & PUSH_NO_HOOK != 0) add(&argv, "--no-verify");
    if (fl & PUSH_FOLLOW_TAGS != 0) add(&argv, "--follow-tags");
    if (fl & PUSH_SET_UPSTREAM != 0) add(&argv, "--set-upstream");
    if (fl & PUSH_FORCE_IF_INCLUDES != 0) add(&argv, "--force-if-includes");
    if (fl & PUSH_ALL != 0) add(&argv, "--all");
    if (fl & PUSH_MIRROR != 0) add(&argv, "--mirror");
    if (signed) |s| add(&argv, util.fmt("--signed={s}", .{s}));
    if (!thin) add(&argv, "--no-thin");
    if (deleterefs) add(&argv, "--delete");
    if (receivepack) |r| add(&argv, util.fmt("--receive-pack={s}", .{r}));
    if (verbosity >= 2) add(&argv, "-v");
    if (verbosity >= 1) {
        add(&argv, "-v");
    } else if (verbosity < 0) add(&argv, "-q");
    if (progress > 0) {
        add(&argv, "--progress");
    } else if (progress == 0) add(&argv, "--no-progress");
    switch (recurse_submodules) {
        .check => add(&argv, "--recurse-submodules=check"),
        .on_demand => add(&argv, "--recurse-submodules=on-demand"),
        .only => add(&argv, "--recurse-submodules=only"),
        .off => add(&argv, "--recurse-submodules=no"),
        .default => {},
    }
    if (tags) add(&argv, "--tags");
    for (push_options) |o| add(&argv, util.fmt("--push-option={s}", .{o}));
    for (cas_given.items) |g| {
        if (g) |v| add(&argv, util.fmt("--force-with-lease={s}", .{v})) else add(&argv, "--force-with-lease");
    }
    var result: u8 = 0;
    for (list) |name| {
        var cmd: std.ArrayList([]const u8) = .empty;
        cmd.appendSlice(gpa, argv.items) catch util.oom();
        cmd.append(gpa, name) catch util.oom();
        cmd.appendSlice(gpa, refspecs) catch util.oom();
        if (verbosity >= 0) util.stdout.print("Pushing to {s}\n", .{name});
        util.flushStdout();
        const ch = proc.spawnGit(cmd.items, .{});
        if (proc.wait(ch.pid) != 0) {
            util.err("could not push to {s}", .{name});
            result = 1;
        }
    }
    return result;
}

fn dieIfRepoLooksLikeRef(repo: []const u8) void {
    const slash = std.mem.indexOfScalar(u8, repo, '/') orelse return;
    if (slash + 1 >= repo.len or os.exists(repo)) return;
    const name = repo[0..slash];
    const r = tp.remoteGet(name) orelse return;
    if (!tp.remoteIsConfigured(r, false)) return;
    util.ewrite(util.fmt("fatal: '{s}' is not a valid push target\n", .{repo}));
    advice.adviseIfEnabled("pushRepoLooksLikeRef", util.fmt("Did you mean to use: git push {s} {s}?", .{ name, repo[slash + 1 ..] }));
    os.exit(128);
}

pub fn cmdPush(args: []const []const u8) u8 {
    @import("../pktline.zig").traceIdentity("push");
    loadConfig();
    const rest = po.parse(args[1..], &options, &usage, .{});
    const push_options = if (push_options_cmdline.items.len > 0) push_options_cmdline.items else push_options_config.items;
    if (opt_ipv4 and opt_ipv6) {}
    // die_for_incompatible_opt4
    {
        var names: std.ArrayList([]const u8) = .empty;
        if (deleterefs) names.append(gpa, "--delete") catch util.oom();
        if (tags) names.append(gpa, "--tags") catch util.oom();
        if (flags & PUSH_ALL != 0) names.append(gpa, "--all/--branches") catch util.oom();
        if (flags & PUSH_MIRROR != 0) names.append(gpa, "--mirror") catch util.oom();
        if (names.items.len == 2) {
            util.die("options '{s}' and '{s}' cannot be used together", .{ names.items[0], names.items[1] });
        } else if (names.items.len == 3) {
            util.die("options '{s}', '{s}', and '{s}' cannot be used together", .{ names.items[0], names.items[1], names.items[2] });
        } else if (names.items.len == 4) {
            util.die("options '{s}', '{s}', '{s}', and '{s}' cannot be used together", .{ names.items[0], names.items[1], names.items[2], names.items[3] });
        }
    }
    if (deleterefs and rest.len < 2) util.die("--delete doesn't make sense without any refs", .{});
    var repo = repo_opt;
    if (rest.len > 0) repo = rest[0];
    var group: std.ArrayList([]const u8) = .empty;
    if (repo) |rp| {
        if (!fetch.addRemoteOrGroup(rp, &group)) {
            if (advice.enabled("pushRepoLooksLikeRef")) dieIfRepoLooksLikeRef(rp);
            const r = tp.pushremoteGet(rp) orelse util.die("bad repository '{s}'", .{rp});
            group.append(gpa, r.name) catch util.oom();
        }
    } else {
        const r = tp.pushremoteGet(null) orelse util.die("No configured push destination.\n" ++
            "Either specify the URL from the command-line or configure a remote repository using\n" ++
            "\n" ++
            "    git remote add <name> <url>\n" ++
            "\n" ++
            "and then push using the remote name\n" ++
            "\n" ++
            "    git push <name>\n" ++
            "\n" ++
            "To push to multiple remotes at once, configure a remote group using\n" ++
            "\n" ++
            "    git config remotes.<groupname> \"<remote1> <remote2>\"\n" ++
            "\n" ++
            "and then push using the group name\n" ++
            "\n" ++
            "    git push <groupname>\n", .{});
        group.append(gpa, r.name) catch util.oom();
    }
    for (push_options) |o| {
        if (std.mem.indexOfScalar(u8, o, '\n') != null) util.die("push options must not have new line characters", .{});
    }
    if (group.items.len == 1) {
        var inner = flags;
        const r = tp.pushremoteGet(group.items[0]) orelse util.die("no such remote or remote group: {s}", .{group.items[0]});
        if (r.mirror) inner |= PUSH_MIRROR | PUSH_FORCE;
        if (inner & PUSH_ALL != 0 and rest.len >= 2) util.die("--all can't be combined with refspecs", .{});
        if (inner & PUSH_MIRROR != 0 and rest.len >= 2) util.die("--mirror can't be combined with refspecs", .{});
        rs = .{ .fetch = false };
        if (tags) rs.append("refs/tags/*");
        if (rest.len > 0) setRefspecs(rest[1..], r);
        return doPush(inner, push_options, r);
    }
    if (flags & PUSH_ATOMIC != 0) util.die("--atomic can only be used when pushing to one remote", .{});
    return pushMultiple(group.items, push_options, flags, if (rest.len > 1) rest[1..] else &.{});
}

// ---------------- git send-pack (builtin/send-pack.c) ----------------

const send_pack_usage = [_][]const u8{"git send-pack [--mirror] [--dry-run] [--force]\n" ++
    "              [--receive-pack=<git-receive-pack>]\n" ++
    "              [--verbose] [--thin] [--atomic]\n" ++
    "              [--[no-]signed | --signed=(true|false|if-asked)]\n" ++
    "              [<host>:]<directory> (--all | <ref>...)"};

var sp_verbose: i32 = 0;
var sp_receivepack: ?[]const u8 = null;
var sp_remote_name: ?[]const u8 = null;
var sp_all = false;
var sp_dry_run = false;
var sp_mirror = false;
var sp_force = false;
var sp_push_options: std.ArrayList([]const u8) = .empty;
var sp_progress: i32 = -1;
var sp_thin = false;
var sp_atomic = false;
var sp_stateless_rpc = false;
var sp_stdin = false;
var sp_helper_status = false;
var sp_force_if_includes = false;

fn cbSpProgress(_: ?[]const u8, unset: bool) void {
    sp_progress = if (unset) 0 else 1;
}

const send_pack_options = [_]po.Opt{
    po.verbose(&sp_verbose),
    po.quiet(&sp_verbose),
    po.string(0, "receive-pack", &sp_receivepack, "receive-pack", "receive pack program"),
    po.string(0, "exec", &sp_receivepack, "receive-pack", "receive pack program"),
    po.string(0, "remote", &sp_remote_name, "remote", "remote name"),
    po.boolean(0, "all", &sp_all, "push all refs"),
    po.boolean('n', "dry-run", &sp_dry_run, "dry run"),
    po.boolean(0, "mirror", &sp_mirror, "mirror all refs"),
    po.boolean('f', "force", &sp_force, "force updates"),
    .{ .long = "signed", .kind = .callback, .cb = cbSigned, .optarg = true, .argh = "(yes|no|if-asked)", .help = "GPG sign the push" },
    po.list(0, "push-option", &sp_push_options, "server-specific", "option to transmit"),
    po.callbackNoArg(0, "progress", cbSpProgress, "force progress reporting"),
    po.boolean(0, "thin", &sp_thin, "use thin pack"),
    po.boolean(0, "atomic", &sp_atomic, "request atomic transaction on remote side"),
    po.boolean(0, "stateless-rpc", &sp_stateless_rpc, "use stateless RPC protocol"),
    po.boolean(0, "stdin", &sp_stdin, "read refs from stdin"),
    po.boolean(0, "helper-status", &sp_helper_status, "print status from remote helper"),
    .{ .long = "force-with-lease", .kind = .callback, .cb = cbCas, .optarg = true, .literal_argh = true, .argh = "<refname>:<expect>", .help = "require old value of ref to be at this value" },
    po.boolean(0, "force-if-includes", &sp_force_if_includes, "require remote updates to be integrated locally"),
};

fn printHelperStatus(list: []const *Ref) void {
    var b: util.Buf = .empty;
    for (list) |r| {
        var msg: ?[]const u8 = null;
        var res: []const u8 = "error";
        switch (r.status) {
            .none => msg = "no match",
            .ok => res = "ok",
            .uptodate => {
                res = "ok";
                msg = "up to date";
            },
            .reject_nonfastforward => msg = "non-fast forward",
            .reject_fetch_first => msg = "fetch first",
            .reject_needs_force => msg = "needs force",
            .reject_stale => msg = "stale info",
            .reject_remote_updated => msg = "remote ref updated since checkout",
            .reject_already_exists => msg = "already exists",
            .reject_nodelete, .remote_reject => {},
            .expecting_report => msg = "expecting report",
            else => continue,
        }
        util.bufPrint(&b, "{s} {s}", .{ res, r.name });
        if (r.remote_status) |rs_| msg = rs_;
        if (msg) |m| util.bufPrint(&b, " {s}", .{util.cquote(m)});
        util.bufByte(&b, '\n');
    }
    util.stdout.write(b.items);
}

pub fn cmdSendPack(args: []const []const u8) u8 {
    if (repo_mod.cfg.get("push.gpgsign")) |v| {
        if (@import("../config.zig").parseBool(v)) |bv| {
            signed = if (bv) "yes" else null;
        } else if (std.ascii.eqlIgnoreCase(v, "if-asked")) {
            signed = "if-asked";
        } else util.err("invalid value for '{s}'", .{"push.gpgsign"});
    }
    const rest = po.parse(args[1..], &send_pack_options, &send_pack_usage, .{});
    var refspec: tp.Refspec = .{ .fetch = false };
    if (rest.len == 0) po.usageWithOptions(&send_pack_usage, &send_pack_options);
    const dest = rest[0];
    for (rest[1..]) |s| refspec.append(s);
    if (sp_stdin) {
        const data = os.readAllFd(0) catch "";
        var it = std.mem.splitScalar(u8, data, '\n');
        while (it.next()) |l0| {
            if (l0.len == 0 and it.index == null) break;
            const l = if (l0.len > 0 and l0[l0.len - 1] == '\r') l0[0 .. l0.len - 1] else l0;
            refspec.append(l);
        }
    }
    if ((refspec.items.items.len > 0 and (sp_all or sp_mirror)) or (sp_all and sp_mirror))
        po.usageWithOptions(&send_pack_usage, &send_pack_options);
    var remote_opt: ?*Remote = null;
    if (sp_remote_name) |rn| {
        const r = tp.remoteGet(rn) orelse util.die("Destination {s} is not a uri for {s}", .{ dest, rn });
        var has = false;
        for (r.urls.items) |u| {
            if (util.eql(u, dest)) has = true;
        }
        if (!has) util.die("Destination {s} is not a uri for {s}", .{ dest, rn });
        remote_opt = r;
    }
    const prog = if (sp_progress == -1) os.isatty(2) else sp_progress == 1;

    const remote = gpa.create(Remote) catch util.oom();
    remote.* = .{ .name = dest };
    remote.urls.append(gpa, dest) catch util.oom();
    const t = tp.transportGet(remote, dest);
    t.receivepack = sp_receivepack;
    tp.connect(t, true);
    if (t.version == 2) util.die("support for protocol v2 not implemented yet", .{});
    const local_refs = tp.getLocalHeads();
    var remote_refs: std.ArrayList(*Ref) = .empty;
    remote_refs.appendSlice(gpa, t.remote_refs) catch util.oom();
    var match_flags: u32 = 0;
    if (sp_all) match_flags |= tp.MATCH_REFS_ALL;
    if (sp_mirror) match_flags |= tp.MATCH_REFS_MIRROR;
    if (!tp.matchPushRefs(local_refs, &remote_refs, &refspec, match_flags)) {
        _ = tp.disconnect(t);
        return 255;
    }
    if (cas_entries.items.len > 0 or cas_use_tracking_for_rest) applyPushCas(remote_opt orelse remote, remote_refs.items, false);
    tp.setRefStatusForPush(remote_refs.items, sp_mirror, sp_force);
    const sargs = SendArgs{
        .send_mirror = sp_mirror,
        .force_update = sp_force,
        .use_thin_pack = sp_thin,
        .quiet = false,
        .progress = prog,
        .dry_run = sp_dry_run,
        .atomic = sp_atomic,
        .push_options = if (sp_push_options.items.len > 0) sp_push_options.items else null,
    };
    var ret: u8 = 0;
    if (!sendPack(t, remote_refs.items, &sargs)) ret = 255;
    if (pushHadErrors(remote_refs.items)) ret = 255;
    if (sp_helper_status) printHelperStatus(remote_refs.items);
    if (tp.finish(t) != 0) ret |= 1;
    if (!sp_helper_status) {
        var reasons: u32 = 0;
        printPushStatus(dest, remote_refs.items, sp_verbose != 0, false, &reasons);
    }
    if (!sp_dry_run) {
        if (remote_opt) |ro| {
            for (remote_refs.items) |r| updateTrackingRef(ro, r, sp_verbose != 0);
        }
    }
    if (ret == 0 and !refsPushed(remote_refs.items)) util.ewrite("Everything up-to-date\n");
    return ret;
}
