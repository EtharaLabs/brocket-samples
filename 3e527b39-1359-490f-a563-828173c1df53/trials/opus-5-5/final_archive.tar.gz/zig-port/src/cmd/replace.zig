//! git replace (port of builtin/replace.c)

const std = @import("std");
const util = @import("../util.zig");
const os = @import("../os.zig");
const hash = @import("../hash.zig");
const refs = @import("../refs.zig");
const repo_mod = @import("../repo.zig");
const odb_mod = @import("../odb.zig");
const po = @import("../parseopt.zig");
const revparse = @import("../revparse.zig");
const cn = @import("../commitnode.zig");
const objects = @import("../objects.zig");
const wildmatch = @import("../wildmatch.zig");
const editor = @import("../editor.zig");
const proc = @import("../proc.zig");
const plumbing = @import("plumbing.zig");
const Oid = hash.Oid;
const ObjType = odb_mod.ObjType;
const gpa = util.gpa;

const usage_str = [_][]const u8{
    "git replace [-f] <object> <replacement>",
    "git replace [-f] --edit <object>",
    "git replace [-f] --graft <commit> [<parent>...]",
    "git replace [-f] --convert-graft-file",
    "git replace -d <object>...",
    "git replace [--format=<format>] [-l [<pattern>]]",
};

const Mode = enum(u8) { unspecified, list, delete, edit, graft, convert, replace };

var cmdmode: Mode = .unspecified;
var cmdmode_name: []const u8 = "";
var mode_conflict: ?[2][]const u8 = null;

fn setMode(m: Mode, name: []const u8) void {
    if (cmdmode != .unspecified and cmdmode != m and mode_conflict == null) {
        mode_conflict = .{ name, cmdmode_name };
    }
    cmdmode = m;
    cmdmode_name = name;
}
fn cbList(_: ?[]const u8, _: bool) void {
    setMode(.list, "--list");
}
fn cbDelete(_: ?[]const u8, _: bool) void {
    setMode(.delete, "--delete");
}
fn cbEdit(_: ?[]const u8, _: bool) void {
    setMode(.edit, "--edit");
}
fn cbGraft(_: ?[]const u8, _: bool) void {
    setMode(.graft, "--graft");
}
fn cbConvert(_: ?[]const u8, _: bool) void {
    setMode(.convert, "--convert-graft-file");
}

fn errRet(comptime f: []const u8, args: anytype) i32 {
    util.err(f, args);
    return -1;
}

fn replaceBase() []const u8 {
    return odb_mod.replaceRefBase();
}

fn getOid(name: []const u8) ?Oid {
    return revparse.getOid(name);
}

fn typeOf(oid: Oid) ?ObjType {
    const o = repo_mod.repo().odb().readNoReplace(oid) orelse return null;
    return o.typ;
}

fn typeName(t: ?ObjType) []const u8 {
    return if (t) |x| x.name() else "bad";
}

fn listReplaceRefs(pattern_in: ?[]const u8, format: ?[]const u8) i32 {
    const pattern = pattern_in orelse "*";
    const Fmt = enum { short, medium, long };
    var f: Fmt = .short;
    if (format == null or format.?.len == 0 or util.eql(format.?, "short")) {
        f = .short;
    } else if (util.eql(format.?, "medium")) {
        f = .medium;
    } else if (util.eql(format.?, "long")) {
        f = .long;
    } else {
        return errRet("invalid replace format '{s}'\nvalid formats are 'short', 'medium' and 'long'", .{format.?});
    }
    const base = replaceBase();
    for (refs.iterate(base, .{ .check_objects = false })) |r| {
        const name = r.name[base.len..];
        if (!wildmatch.match(pattern, name, 0)) continue;
        switch (f) {
            .short => util.outf("{s}\n", .{name}),
            .medium => util.outf("{s} -> {s}\n", .{ name, hash.hex(r.oid) }),
            .long => {
                const obj = getOid(name) orelse {
                    util.err("failed to resolve '{s}' as a valid ref", .{name});
                    continue;
                };
                util.outf("{s} ({s}) -> {s} ({s})\n", .{ name, typeName(typeOf(obj)), hash.hex(r.oid), typeName(typeOf(r.oid)) });
            },
        }
    }
    return 0;
}

fn deleteReplaceRefs(names: []const []const u8) i32 {
    var had_error: i32 = 0;
    const base = replaceBase();
    for (names) |n| {
        const oid = getOid(n) orelse {
            util.err("failed to resolve '{s}' as a valid ref", .{n});
            had_error = 1;
            continue;
        };
        const full_hex = hash.hex(oid);
        const ref = util.concat(&.{ base, &full_hex });
        const cur = refs.readOid(ref) orelse {
            util.err("replace ref '{s}' not found", .{&full_hex});
            had_error = 1;
            continue;
        };
        refs.deleteRef(ref, cur, 0, null) catch {
            util.err("{s}", .{refs.last_error});
            had_error = 1;
            continue;
        };
        util.outf("Deleted replace ref '{s}'\n", .{&full_hex});
    }
    return had_error;
}

/// Returns the ref name, or null on error; prev is set to the existing value (or zero).
fn checkRefValid(object: Oid, prev: *Oid, force: bool) ?[]const u8 {
    const ref = util.concat(&.{ replaceBase(), &hash.hex(object) });
    if (!refs.checkRefnameFormat(ref, 0)) {
        util.err("'{s}' is not a valid ref name", .{ref});
        return null;
    }
    if (refs.readOid(ref)) |o| {
        prev.* = o;
        if (!force) {
            util.err("replace ref '{s}' already exists", .{ref});
            return null;
        }
    } else prev.* = hash.zero;
    return ref;
}

fn replaceObjectOid(object_ref: []const u8, object: Oid, replace_ref: []const u8, repl: Oid, force: bool) i32 {
    const obj_type = typeOf(object);
    const repl_type = typeOf(repl);
    if (!force and obj_type != repl_type) {
        return errRet("Objects must be of the same type.\n'{s}' points to a replaced object of type '{s}'\nwhile '{s}' points to a replacement object of type '{s}'.", .{ object_ref, typeName(obj_type), replace_ref, typeName(repl_type) });
    }
    var prev: Oid = hash.zero;
    const ref = checkRefValid(object, &prev, force) orelse return -1;
    const t = refs.Transaction.init();
    var e = t.update(ref, repl, prev, null, null, 0, null);
    if (e == .ok) e = t.commit();
    if (e != .ok) return errRet("{s}", .{t.errMsg()});
    return 0;
}

fn replaceObject(object_ref: []const u8, replace_ref: []const u8, force: bool) i32 {
    const object = getOid(object_ref) orelse return errRet("failed to resolve '{s}' as a valid ref", .{object_ref});
    const repl = getOid(replace_ref) orelse return errRet("failed to resolve '{s}' as a valid ref", .{replace_ref});
    return replaceObjectOid(object_ref, object, replace_ref, repl, force);
}

fn exportObject(oid: Oid, typ: ObjType, raw: bool, filename: []const u8) i32 {
    const h = hash.hex(oid);
    const res = os.run(&.{ proc.gitBinary(), "--no-replace-objects", "cat-file", if (raw) typ.name() else "-p", &h }, .{ .capture_stdout = true });
    if (res.status != 0) return errRet("cat-file reported failure", .{});
    os.writeFile(filename, res.stdout, 0o666) catch {
        return errRet("unable to open {s} for writing: {s}", .{ filename, os.strErr(os.errno()) });
    };
    return 0;
}

fn importObject(oid: *Oid, typ: ObjType, raw: bool, filename: []const u8) i32 {
    const data = os.readFile(filename) orelse return errRet("unable to open {s} for reading: {s}", .{ filename, os.strErr(os.errno()) });
    if (!raw and typ == .tree) {
        const res = os.run(&.{ proc.gitBinary(), "mktree" }, .{ .capture_stdout = true, .stdin_data = data });
        if (res.status != 0) return errRet("mktree reported failure", .{});
        if (res.stdout.len < 40) return errRet("mktree did not return an object name", .{});
        oid.* = hash.fromHex(res.stdout[0..40]) orelse return errRet("mktree did not return an object name", .{});
        return 0;
    }
    if (plumbing.checkObjectFormat(typ, data)) |msg| {
        util.err("{s}", .{msg});
        return errRet("unable to write object to database", .{});
    }
    oid.* = repo_mod.repo().odb().write(typ, data);
    return 0;
}

fn editAndReplace(object_ref: []const u8, force: bool, raw: bool) i32 {
    const old_oid = getOid(object_ref) orelse return errRet("not a valid object name: '{s}'", .{object_ref});
    const typ = typeOf(old_oid) orelse return errRet("unable to get object type for {s}", .{hash.hex(old_oid)});
    var prev: Oid = hash.zero;
    _ = checkRefValid(old_oid, &prev, force) orelse return -1;
    const tmpfile = repo_mod.repo().gitPath("REPLACE_EDITOBJ");
    if (exportObject(old_oid, typ, raw, tmpfile) != 0) return -1;
    if (editor.launch(tmpfile, &.{})) return errRet("editing object file failed", .{});
    var new_oid: Oid = hash.zero;
    if (importObject(&new_oid, typ, raw, tmpfile) != 0) return -1;
    if (hash.eql(old_oid, new_oid)) return errRet("new object is the same as the old one: '{s}'", .{hash.hex(old_oid)});
    return replaceObjectOid(object_ref, old_oid, "replacement", new_oid, force);
}

/// Remove gpgsig / gpgsig-sha256 headers (with continuation lines). Returns true if any removed.
fn removeSignature(buf: *util.Buf) bool {
    var out: util.Buf = .empty;
    const data = buf.items;
    var found = false;
    var pos: usize = 0;
    var in_sig = false;
    var in_header = true;
    while (pos < data.len) {
        const nl = std.mem.indexOfScalarPos(u8, data, pos, '\n');
        const end = if (nl) |n| n + 1 else data.len;
        const line = data[pos..end];
        if (in_header) {
            if (line.len == 1 and line[0] == '\n') {
                in_header = false;
                in_sig = false;
            } else if (in_sig and line[0] == ' ') {
                pos = end;
                continue;
            } else if (util.startsWith(line, "gpgsig ") or util.startsWith(line, "gpgsig-sha256 ")) {
                in_sig = true;
                found = true;
                pos = end;
                continue;
            } else in_sig = false;
        }
        util.bufAppend(&out, line);
        pos = end;
    }
    buf.* = out;
    return found;
}

fn checkMergetags(buffer: []const u8, args: []const []const u8) i32 {
    const ref = args[0];
    const hdr_end = std.mem.indexOf(u8, buffer, "\n\n") orelse buffer.len;
    const hdr = buffer[0..hdr_end];
    var lines = std.mem.splitScalar(u8, hdr, '\n');
    var val: ?util.Buf = null;
    var vals: std.ArrayList([]const u8) = .empty;
    while (lines.next()) |line| {
        if (line.len > 0 and line[0] == ' ' and val != null) {
            util.bufAppend(&val.?, line[1..]);
            util.bufByte(&val.?, '\n');
            continue;
        }
        if (val) |v| vals.append(gpa, v.items) catch util.oom();
        val = null;
        if (util.startsWith(line, "mergetag ")) {
            val = .empty;
            util.bufAppend(&val.?, line[9..]);
            util.bufByte(&val.?, '\n');
        }
    }
    if (val) |v| vals.append(gpa, v.items) catch util.oom();
    for (vals.items) |v| {
        const tag_oid = odb_mod.hashObject(.tag, v);
        const tag = objects.parseTag(v) orelse return errRet("malformed mergetag in commit '{s}'", .{ref});
        var found = false;
        for (args[1..]) |a| {
            const o = getOid(a) orelse return errRet("not a valid object name: '{s}'", .{a});
            if (hash.eql(o, tag.object)) {
                found = true;
                break;
            }
        }
        if (!found) return errRet("original commit '{s}' contains mergetag '{s}' that is discarded; use --edit instead of --graft", .{ ref, hash.hex(tag_oid) });
    }
    return 0;
}

fn createGraft(args: []const []const u8, force: bool, gentle: bool) i32 {
    const old_ref = args[0];
    const old_oid = getOid(old_ref) orelse return errRet("not a valid object name: '{s}'", .{old_ref});
    const commit = cn.lookupCommitReferenceLoud(old_oid) orelse return errRet("could not parse {s}", .{old_ref});
    const commit_oid = commit.obj.oid;
    const obj = repo_mod.repo().odb().readNoReplace(commit_oid) orelse return errRet("could not parse {s}", .{old_ref});
    var buf: util.Buf = .empty;
    util.bufAppend(&buf, obj.data);

    // replace parents
    var new_parents: util.Buf = .empty;
    for (args[1..]) |a| {
        const o = getOid(a) orelse return errRet("not a valid object name: '{s}'", .{a});
        const pc = cn.lookupCommitReferenceLoud(o) orelse return errRet("could not parse {s} as a commit", .{a});
        util.bufPrint(&new_parents, "parent {s}\n", .{hash.hex(pc.obj.oid)});
    }
    const pstart: usize = @min(buf.items.len, 46);
    var pend = pstart;
    while (util.startsWith(buf.items[pend..], "parent ")) pend = @min(buf.items.len, pend + 48);
    var nb: util.Buf = .empty;
    util.bufAppend(&nb, buf.items[0..pstart]);
    util.bufAppend(&nb, new_parents.items);
    util.bufAppend(&nb, buf.items[pend..]);
    buf = nb;

    if (removeSignature(&buf)) {
        util.warn("the original commit '{s}' has a gpg signature", .{old_ref});
        util.warn("the signature will be removed in the replacement commit!", .{});
    }
    if (checkMergetags(obj.data, args) != 0) return -1;

    const new_oid = repo_mod.repo().odb().write(.commit, buf.items);
    if (hash.eql(commit_oid, new_oid)) {
        if (gentle) {
            util.warn("graft for '{s}' unnecessary", .{hash.hex(commit_oid)});
            return 0;
        }
        return errRet("new commit is the same as the old one: '{s}'", .{hash.hex(commit_oid)});
    }
    return replaceObjectOid(old_ref, commit_oid, "replacement", new_oid, force);
}

fn convertGraftFile(force: bool) i32 {
    const r = repo_mod.repo();
    const graft_file = os.getenv("GIT_GRAFT_FILE") orelse r.commonPath("info/grafts");
    const data = os.readFile(graft_file) orelse {
        const e = os.errno();
        if (e != 2 and e != 20) util.warn("unable to access '{s}': {s}", .{ graft_file, os.strErr(e) });
        return -1;
    };
    objects.no_graft_file_deprecated_advice = true;
    var errs: util.Buf = .empty;
    var it = std.mem.splitScalar(u8, data, '\n');
    while (it.next()) |line0| {
        var line = line0;
        if (line.len > 0 and line[line.len - 1] == '\r') line = line[0 .. line.len - 1];
        if (line.len > 0 and line[0] == '#') continue;
        var argv: std.ArrayList([]const u8) = .empty;
        var wi = std.mem.tokenizeAny(u8, line, " \t\n\r\x0b\x0c");
        while (wi.next()) |w| argv.append(gpa, w) catch util.oom();
        if (argv.items.len > 0 and createGraft(argv.items, force, true) != 0) {
            util.bufPrint(&errs, "\n\t{s}", .{line});
        }
    }
    if (errs.items.len == 0) {
        if (!os.unlink(graft_file)) {
            const e = os.errno();
            if (e != 2) util.warn("unable to unlink '{s}': {s}", .{ graft_file, os.strErr(e) });
        }
        return 0;
    }
    util.warn("could not convert the following graft(s):\n{s}", .{errs.items});
    return -1;
}

fn usageMsg(msg: []const u8, opts: []const po.Opt) noreturn {
    util.eprint("fatal: {s}\n\n", .{msg});
    po.usageWithOptions(&usage_str, opts);
}

fn ret(v: i32) u8 {
    return @intCast(v & 0xff);
}

pub fn cmdReplace(args: []const []const u8) u8 {
    var force = false;
    var raw = false;
    var format: ?[]const u8 = null;
    const opts = [_]po.Opt{
        noNeg(po.callbackNoArg('l', "list", cbList, "list replace refs")),
        noNeg(po.callbackNoArg('d', "delete", cbDelete, "delete replace refs")),
        noNeg(po.callbackNoArg('e', "edit", cbEdit, "edit existing object")),
        noNeg(po.callbackNoArg('g', "graft", cbGraft, "change a commit's parents")),
        noNeg(po.callbackNoArg(0, "convert-graft-file", cbConvert, "convert existing graft file")),
        po.noComplete(po.boolean('f', "force", &force, "replace the ref if it exists")),
        po.boolean(0, "raw", &raw, "do not pretty-print contents for --edit"),
        po.string(0, "format", &format, "format", "use this format"),
    };
    odb_mod.disableReplaceRefs();
    const rest = po.parse(args[1..], &opts, &usage_str, .{});
    if (mode_conflict) |mc| {
        util.err("options '{s}' and '{s}' cannot be used together", .{ mc[0], mc[1] });
        os.exit(129);
    }
    if (cmdmode == .unspecified) cmdmode = if (rest.len > 0) .replace else .list;

    if (format != null and cmdmode != .list) usageMsg("--format cannot be used when not listing", &opts);
    if (force and cmdmode != .replace and cmdmode != .edit and cmdmode != .graft and cmdmode != .convert)
        usageMsg("-f only makes sense when writing a replacement", &opts);
    if (raw and cmdmode != .edit) usageMsg("--raw only makes sense with --edit", &opts);

    switch (cmdmode) {
        .delete => {
            if (rest.len < 1) usageMsg("-d needs at least one argument", &opts);
            return ret(deleteReplaceRefs(rest));
        },
        .replace => {
            if (rest.len != 2) usageMsg("bad number of arguments", &opts);
            return ret(replaceObject(rest[0], rest[1], force));
        },
        .edit => {
            if (rest.len != 1) usageMsg("-e needs exactly one argument", &opts);
            return ret(editAndReplace(rest[0], force, raw));
        },
        .graft => {
            if (rest.len < 1) usageMsg("-g needs at least one argument", &opts);
            return ret(createGraft(rest, force, false));
        },
        .convert => {
            if (rest.len != 0) usageMsg("--convert-graft-file takes no argument", &opts);
            return if (convertGraftFile(force) != 0) 1 else 0;
        },
        .list => {
            if (rest.len > 1) usageMsg("only one pattern can be given with -l", &opts);
            return ret(listReplaceRefs(if (rest.len > 0) rest[0] else null, format));
        },
        .unspecified => unreachable,
    }
}

fn noNeg(o: po.Opt) po.Opt {
    var x = o;
    x.noneg = true;
    return x;
}
