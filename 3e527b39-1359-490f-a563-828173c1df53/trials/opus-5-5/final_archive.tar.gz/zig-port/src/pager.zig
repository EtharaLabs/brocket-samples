//! Port of pager.c (git_pager, setup_pager, check_pager_config) and
//! setup_auto_pager() from git.c.

const std = @import("std");
const util = @import("util.zig");
const os = @import("os.zig");
const config = @import("config.zig");

/// repo_config_values()->pager_program override set by pager.<cmd>=<string>
pub var pager_program: ?[]const u8 = null;

fn earlyGet(key: []const u8) ?[]const u8 {
    return @import("help.zig").earlyConfig().get(key);
}

/// git_pager()
pub fn gitPager(stdout_is_tty: bool) ?[]const u8 {
    if (!stdout_is_tty) return null;
    var pager = os.getenv("GIT_PAGER");
    if (pager == null) pager = pager_program orelse earlyGet("core.pager");
    if (pager == null) pager = os.getenv("PAGER");
    const p = pager orelse "less";
    if (p.len == 0 or util.eql(p, "cat")) return null;
    return p;
}

/// setup_pager()
pub fn setupPager() void {
    if (os.pager_pid != 0) return;
    const pager = gitPager(os.isatty(1)) orelse return;
    // grab the terminal size before stdout is redirected
    if (os.getenv("COLUMNS") == null) {
        const cols = @import("column.zig").termColumns();
        var ws: [4]u16 = .{ 0, 0, 0, 0 };
        if (ioctl(1, 0x5413, &ws) == 0 and ws[1] > 0) os.setEnv("COLUMNS", util.fmt("{d}", .{cols}));
    }
    os.setEnv("GIT_PAGER_IN_USE", "true");
    util.flushStdout();
    if (!os.startPager(pager)) util.die("unable to execute pager '{s}'", .{pager});
}

extern "c" fn ioctl(fd: c_int, req: c_ulong, ...) c_int;

/// check_pager_config(): 0 = no pager, 1 = pager, -1 = not specified
pub fn checkPagerConfig(cmd: []const u8) i32 {
    const cfg = @import("help.zig").earlyConfig();
    var want: i32 = -1;
    var value: ?[]const u8 = null;
    for (cfg.entries.items) |e| {
        const rest = util.skipPrefix(e.key, "pager.") orelse continue;
        if (!util.eql(rest, cmd)) continue;
        const b = config.parseMaybeBool(e.value);
        if (b >= 0) {
            want = b;
        } else {
            want = 1;
            value = e.value;
        }
    }
    if (value) |v| pager_program = v;
    return want;
}

pub fn pagerInUse() bool {
    const v = os.getenv("GIT_PAGER_IN_USE") orelse return false;
    return config.parseBool(v) orelse false;
}

/// commit_pager_choice() of git.c
pub fn commitPagerChoice() void {
    const main = @import("main.zig");
    if (main.use_pager) |p| {
        if (p) setupPager() else os.setEnv("GIT_PAGER", "cat");
    }
}

/// setup_auto_pager()
pub fn setupAutoPager(cmd: []const u8, def: bool) void {
    const main = @import("main.zig");
    if (main.use_pager != null or pagerInUse()) return;
    const w = checkPagerConfig(cmd);
    main.use_pager = if (w == -1) def else w == 1;
    commitPagerChoice();
}

/// setup_diff_pager(): no pager for --exit-code/--quiet, honours pager.diff
pub fn setupDiffPager(exit_with_status: bool) void {
    if (!exit_with_status and checkPagerConfig("diff") != 0) setupPager();
}
