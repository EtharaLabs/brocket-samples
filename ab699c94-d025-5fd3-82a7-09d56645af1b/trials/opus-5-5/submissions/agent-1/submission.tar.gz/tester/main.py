#!/usr/bin/env python3
"""Differential tester for rustc's old and next-generation trait solvers."""
import argparse, json, os, sys, time, random, subprocess, re, threading
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_corpus, compile_one, ice_signature, HERE
import gen

MAX_WITNESSES = 3
MAX_SRC = 1500


def log(*a):
    print("[tester]", *a, file=sys.stderr, flush=True)


def write_report(path, witnesses):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"witnesses": witnesses}, f, indent=1)
    os.replace(tmp, path)


def toolchain_date(tc):
    try:
        out = subprocess.run(["rustc", "+" + tc, "-vV"], capture_output=True, text=True, timeout=60).stdout
        m = re.search(r"commit-date: (\d{4}-\d{2}-\d{2})", out)
        if m:
            return m.group(1)
    except Exception:
        pass
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--toolchain", required=True)
    ap.add_argument("--budget", type=float, required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True)
    ap.add_argument("--jobs", type=int, default=0)
    args = ap.parse_args()

    t0 = time.time()
    budget = args.budget
    # leave headroom for verification and report writing
    hard_deadline = t0 + budget * 0.92 - 3
    scan_deadline = t0 + budget * 0.62 - 3
    write_report(args.out, [])

    tc = args.toolchain
    jobs = args.jobs or max(2, min(32, os.cpu_count() or 4))
    date = toolchain_date(tc)
    log("toolchain", tc, "date", date, "jobs", jobs)

    devinfo = {}
    p = os.path.join(HERE, "devinfo.json")
    if os.path.exists(p):
        devinfo = json.load(open(p))

    cands = []
    for e in load_corpus():
        d = devinfo.get(e["name"])
        if d is None or (d.get("split") and not os.environ.get("DT_DEBUG_ALL")):
            continue  # unverified on the reference compiler, or a by-design difference
        if len(e["src"].encode()) > MAX_SRC:
            continue
        e["dev"] = (d["old"], d["next"])
        e["origin"] = "corpus"
        cands.append(e)
    rng = random.Random(args.seed)
    extra = gen.pool(rng, devinfo)
    cands.sort(key=lambda e: -e["prio"])
    cands = cands + extra
    log("candidates", len(cands))

    per_timeout = max(5.0, min(25.0, budget / 20.0))
    results = {}
    lock = threading.Lock()

    def run_pair(e, emit="link"):
        res = {}
        for s in ("old", "next"):
            left = hard_deadline - time.time()
            if left < 2:
                return None
            res[s] = compile_one(tc, e["src"], e["ed"], s, min(per_timeout, left), emit=emit,
                                 want_stderr=True)
        return res

    def scan(e):
        if time.time() > scan_deadline:
            return e, None
        return e, run_pair(e)

    splits = []
    with ThreadPoolExecutor(jobs) as ex:
        futs = [ex.submit(scan, e) for e in cands]
        for fu in as_completed(futs):
            e, r = fu.result()
            if r is None:
                continue
            o, n = r["old"][0], r["next"][0]
            if o != n and "hang" not in (o, n):
                e["obs"] = (o, n)
                e["err"] = {"old": r["old"][1], "next": r["next"][1]}
                splits.append(e)
    log("scan done", round(time.time() - t0, 1), "s; splits:", len(splits))

    # verify: rerun full build and a metadata-only build; outcome must be stable
    def verify(e):
        for emit in ("link", "metadata", "link"):
            r = run_pair(e, emit)
            if r is None:
                return e, False
            if (r["old"][0], r["next"][0]) != e["obs"]:
                return e, False
        return e, True

    verified = []
    order = rank(splits, date)
    # verify in rank order, enough to fill the report after clustering
    with ThreadPoolExecutor(jobs) as ex:
        batch = order[:max(12, 4 * MAX_WITNESSES)]
        for e, ok in ex.map(verify, batch):
            if ok:
                verified.append(e)
    picked = select(rank(verified, date))
    wit = []
    for e in picked:
        wit.append({
            "id": e["name"],
            "source": e["src"],
            "edition": e["ed"],
            "old": e["obs"][0],
            "next": e["obs"][1],
            "mechanism": e["fam"],
        })
    write_report(args.out, wit)
    log("wrote", len(wit), "witnesses in", round(time.time() - t0, 1), "s")


def fix_score(e, date):
    """Smaller is better: corpus entries annotated with a fix month close after the toolchain date."""
    fx = e.get("fix")
    if not fx or not date:
        return 6.0
    try:
        fy, fm = map(int, fx.split("-")[:2])
        ty, tm = map(int, date.split("-")[:2])
    except Exception:
        return 6.0
    diff = (fy * 12 + fm) - (ty * 12 + tm)
    if diff < -1:
        return 20.0  # fixed before this toolchain: odd, keep but deprioritize
    return max(0.0, diff)


def rank(splits, date):
    famcount = {}
    for e in splits:
        famcount[e["fam"]] = famcount.get(e["fam"], 0) + 1

    def key(e):
        o, n = e["obs"]
        ice = 1 if "ice" in (o, n) else 0
        return (fix_score(e, date), -e["prio"], -ice, e["origin"] != "corpus",
                -famcount[e["fam"]], len(e["src"]), e["name"])
    return sorted(splits, key=key)


def signature(e):
    for s in ("next", "old"):
        if e["obs"][0 if s == "old" else 1] == "ice":
            sig = ice_signature(e["err"][s])
            if sig:
                return s + ":" + sig
    return None


def select(ranked):
    out, fams, sigs = [], set(), set()
    for e in ranked:
        if e["fam"] in fams:
            continue
        sig = signature(e)
        if sig and sig in sigs:
            continue
        out.append(e)
        fams.add(e["fam"])
        if sig:
            sigs.add(sig)
        if len(out) >= MAX_WITNESSES:
            break
    return out


if __name__ == "__main__":
    main()
