"""Seeded program pool beyond the hand-written corpus."""


def pool(rng, devinfo):
    return []
