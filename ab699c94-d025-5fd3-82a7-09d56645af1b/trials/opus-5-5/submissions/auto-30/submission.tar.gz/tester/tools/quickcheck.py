#!/usr/bin/env python3
"""Read-only: compile corpus entries from one file on dev under both solvers and print outcomes.
usage: quickcheck.py corpus/x.txt [-v]"""
import sys, os
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common
path = os.path.abspath(sys.argv[1]); verbose = "-v" in sys.argv
ents = [e for e in common.load_corpus() if os.path.abspath(e.get("file", "")) == path] if False else None
txt = open(path).read()
ents = []
for chunk in txt.split("//# ")[1:]:
    hdr, _, src = chunk.partition("\n")
    kv = dict(p.split("=", 1) for p in hdr.split() if "=" in p)
    ents.append({"name": kv["name"], "ed": kv.get("ed", "2021"), "src": src})
    lg = common.legacy_variant(src)
    if lg != src:
        ents.append({"name": kv["name"] + "_lg", "ed": kv.get("ed", "2021"), "src": lg})
def run(e):
    r = {}
    for s in ("old", "next"):
        r[s] = common.compile_one("dev", e["src"], e["ed"], s, 30, emit="link", want_stderr=True)
    return e, r
with ThreadPoolExecutor(8) as ex:
    for e, r in ex.map(run, ents):
        o, n = r["old"][0], r["next"][0]
        print(f"{e['name']:50s} {o:7s} {n:7s} {len(e['src'].encode())}B" + ("  SPLIT" if o != n else "") + ("  TOO_BIG" if len(e['src'].encode()) > 1500 else ""))
        if verbose and (o != "accept" or n != "accept"):
            for s in ("old", "next"):
                errs = [l for l in r[s][1].splitlines() if l.startswith("error")][:3]
                for l in errs: print("     ", s, l)
