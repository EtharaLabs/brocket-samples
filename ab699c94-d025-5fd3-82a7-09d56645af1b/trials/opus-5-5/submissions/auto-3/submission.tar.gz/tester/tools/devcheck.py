#!/usr/bin/env python3
"""Compile every corpus entry on a toolchain (default dev) under both solvers.
Writes devinfo.json with outcomes; entries that split on dev are excluded at runtime."""
import sys, os, json
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import load_corpus, compile_one, HERE

tc = sys.argv[1] if len(sys.argv) > 1 else "dev"
only = sys.argv[2:]
corpus = load_corpus()
if only:
    corpus = [e for e in corpus if any(o in e["name"] for o in only)]

def run(e):
    r = {}
    for emit in ("link", "metadata"):
        for s in ("old", "next"):
            o, err = compile_one(tc, e["src"], e["ed"], s, 30, emit=emit, want_stderr=True)
            r[s + "_" + emit] = o
            if emit == "link":
                r[s + "_err"] = err
    return e, r

info_path = os.path.join(HERE, "devinfo.json")
info = json.load(open(info_path)) if os.path.exists(info_path) and tc == "dev" else {}
with ThreadPoolExecutor(16) as ex:
    for e, r in ex.map(run, corpus):
        split = r["old_link"] != r["next_link"] or r["old_metadata"] != r["next_metadata"]
        inc = r["old_link"] != r["old_metadata"] or r["next_link"] != r["next_metadata"]
        flag = "SPLIT" if split else ("EMITDIFF" if inc else "")
        print(f"{e['name']:40s} {e['fam']:36s} old={r['old_link']:7s} next={r['next_link']:7s} {flag} {len(e['src'])}")
        if "-v" in os.environ.get("DC", ""):
            for s in ("old", "next"):
                errs = [l for l in r[s + "_err"].splitlines() if l.startswith("error")]
                for l in errs[:4]:
                    print("      ", s, l[:150])
        if tc == "dev":
            info[e["name"]] = {"old": r["old_link"], "next": r["next_link"], "split": split or inc,
                               "len": len(e["src"])}
if tc == "dev":
    json.dump(info, open(info_path, "w"), indent=0, sort_keys=True)
