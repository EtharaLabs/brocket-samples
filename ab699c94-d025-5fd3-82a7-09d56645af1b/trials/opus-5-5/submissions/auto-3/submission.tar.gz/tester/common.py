import os, re, subprocess, tempfile, shutil, hashlib, signal

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS_DIR = os.path.join(HERE, "corpus")

SOLVERS = {"old": "-Znext-solver=no", "next": "-Znext-solver=globally"}


def load_corpus():
    """Corpus files hold entries separated by header lines:
    //# name=<id> fam=<label> ed=<edition> [fix=YYYY-MM] [prio=N]
    """
    entries = []
    for fn in sorted(os.listdir(CORPUS_DIR)):
        if not fn.endswith(".txt"):
            continue
        cur = None
        with open(os.path.join(CORPUS_DIR, fn)) as f:
            for line in f:
                if line.startswith("//#"):
                    if cur:
                        entries.append(cur)
                    meta = dict(kv.split("=", 1) for kv in line[3:].split())
                    cur = {"meta": meta, "lines": []}
                elif cur is not None:
                    cur["lines"].append(line)
        if cur:
            entries.append(cur)
    out = []
    seen = set()
    for e in entries:
        m = e["meta"]
        src = "".join(e["lines"]).strip() + "\n"
        name = m["name"]
        assert name not in seen, name
        seen.add(name)
        out.append({
            "name": name,
            "fam": m.get("fam", name),
            "ed": m.get("ed", "2021"),
            "fix": m.get("fix"),
            "prio": int(m.get("prio", "0")),
            "src": src,
        })
        lg = legacy_variant(src)
        if lg and lg != src:
            out.append(dict(out[-1], name=name + "_lg", src=lg))
    return out


def legacy_variant(src):
    """Rewrite newer surface syntax into the forms older nightlies accept."""
    s = src
    if "const_trait_impl" in s:
        s = re.sub(r"\b((?:pub(?:\([^)]*\))?\s+)?)const trait\b", r"#[const_trait] \1trait", s)
        s = re.sub(r"\bconst impl\b", "impl const", s)
        s = s.replace("[const] ", "~const ")
    if "define_opaque" in s:
        s = re.sub(r"[ \t]*#\[define_opaque\([^)]*\)\]\n?", "", s)
    if "async_closure" not in s and re.search(r"\basync\s*(move\s*)?\|", s) or "AsyncFn" in s:
        if "async_closure" not in s:
            s = "#![feature(async_closure)]\n" + s
    return s


def classify(rc, timed_out):
    if timed_out:
        return "hang"
    if rc == 0:
        return "accept"
    if rc == 1:
        return "reject"
    return "ice"


def compile_one(toolchain, src, edition, solver, timeout, emit="metadata", want_stderr=False):
    d = tempfile.mkdtemp(prefix="dt_")
    try:
        p = os.path.join(d, "witness.rs")
        with open(p, "w") as f:
            f.write(src)
        cmd = ["rustc", "+" + toolchain, "--crate-type=lib", "--crate-name=witness",
               "--edition", edition, SOLVERS[solver], "--out-dir", d]
        if emit == "metadata":
            cmd.append("--emit=metadata")
        cmd.append(p)
        env = dict(os.environ)
        env.pop("RUSTFLAGS", None)
        env["RUST_BACKTRACE"] = "0"
        try:
            pr = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                  cwd=d, env=env, start_new_session=True)
            try:
                _, err = pr.communicate(timeout=timeout)
                rc = pr.returncode
                to = False
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(pr.pid, signal.SIGKILL)
                except Exception:
                    pass
                _, err = pr.communicate()
                rc, to = None, True
        except OSError:
            return ("ice", "") if want_stderr else "ice"
        err = err.decode("utf-8", "replace")
        out = classify(rc, to)
        # an ICE that still exits 1 is still an ICE
        if out == "reject" and ("internal compiler error" in err or "panicked at" in err):
            out = "ice"
        return (out, err) if want_stderr else out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def ice_signature(err):
    """Rough location of an ICE, for clustering."""
    m = re.search(r"panicked at ([^\n]*?):(\d+):\d+", err)
    if m:
        return "panic:" + m.group(1)
    m = re.search(r"error: internal compiler error: ([^\n]*?):(\d+):\d+: ([^\n]{0,60})", err)
    if m:
        return "ice:" + m.group(1) + ":" + re.sub(r"[0-9`'].*", "", m.group(3))
    m = re.search(r"internal compiler error: ([^\n]{0,50})", err)
    if m:
        return "icemsg:" + re.sub(r"[`(\[{0-9].*", "", m.group(1)).strip()
    return None
