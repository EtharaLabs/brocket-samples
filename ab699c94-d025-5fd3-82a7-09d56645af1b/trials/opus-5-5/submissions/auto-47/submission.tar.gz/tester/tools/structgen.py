#!/usr/bin/env python3
"""Structural random generator of Rust library-crate programs exercising the trait system.

usage: python3 tools/structgen.py <count> <seed> <outfile>

Each program is preceded by `//# name=sg_<template>_<n> fam=sg-<template> ed=<edition>`.
Programs are library crates (no main, no external crates), <= 1500 bytes.
Deterministic per seed: a master random.Random(seed) derives one sub-seed per program.
A minority of programs are intentionally invalid in exactly one place.
"""
import random
import sys

MAXB = 1500

# ---------------------------------------------------------------- helpers

# (type, value expr, properties)
TYPES = [
    ("u8", "7u8", "copy dbg def eq num"),
    ("u16", "300u16", "copy dbg def eq num"),
    ("u32", "42u32", "copy dbg def eq num"),
    ("i32", "-3i32", "copy dbg def eq num"),
    ("i64", "-5i64", "copy dbg def eq num"),
    ("u64", "9u64", "copy dbg def eq num"),
    ("bool", "true", "copy dbg def eq"),
    ("char", "'z'", "copy dbg def eq"),
    ("()", "()", "copy dbg def eq"),
    ("(u8, bool)", "(1u8, false)", "copy dbg def eq"),
    ("Option<i32>", "Some(3i32)", "copy dbg def eq"),
    ("&'static str", "\"lit\"", "copy dbg def eq"),
    ("String", "String::from(\"s\")", "clone dbg def eq"),
    ("Vec<u16>", "vec![1u16, 2]", "clone dbg def eq"),
    ("[u8; 3]", "[1u8, 2, 3]", "copy dbg def eq"),
    ("Box<u32>", "Box::new(5u32)", "clone dbg def eq"),
]
NUMS = [t for t in TYPES if "num" in t[2]]

TRAIT_NAMES = ["Tr", "Foo", "Bar", "Baz", "Qux", "Lift", "Proj", "Kind", "Shape", "Node", "Step", "Hold"]
STRUCT_NAMES = ["Wrap", "W", "Cell", "Pack", "Hold", "S", "Leaf", "Outer", "Inner", "Bx"]
ASSOC_NAMES = ["A", "Out", "Item", "Assoc", "Target", "Elem", "Ty"]
FN_NAMES = ["f", "go", "run", "test", "check", "make", "use_it", "demo", "probe", "eval"]
LT = ["'a", "'b", "'x", "'l"]


def fill(_tmpl, **kw):
    for k, v in kw.items():
        _tmpl = _tmpl.replace("@" + k + "@", str(v))
    return _tmpl


class Names:
    def __init__(self, r):
        self.r = r
        self.used = set()

    def pick(self, pool):
        c = [p for p in pool if p not in self.used]
        if not c:
            c = [p + str(len(self.used)) for p in pool]
        x = self.r.choice(c)
        self.used.add(x)
        return x

    def tr(self):
        return self.pick(TRAIT_NAMES)

    def st(self):
        return self.pick(STRUCT_NAMES)

    def fn(self):
        return self.pick(FN_NAMES)

    def assoc(self):
        return self.pick(ASSOC_NAMES)


def ty(r, need=""):
    need = need.split()
    c = [t for t in TYPES if all(n in t[2] or (n == "clone" and "copy" in t[2]) for n in need)]
    return r.choice(c)


def render(r, feats, items, shuffle=True):
    items = [i.strip("\n") for i in items if i]
    if shuffle and r.random() < 0.6:
        r.shuffle(items)
    head = "".join("#![feature(%s)]\n" % f for f in sorted(set(feats)))
    if r.random() < 0.3:
        head += "#![allow(dead_code, unused)]\n"
    return head + "\n".join(items) + "\n"


BADV = ("bad", "plain_bad", "guide_bad", "missing", "bad_mismatch", "bad_kind", "fallback_bad", "into_amb", "overlap")


def variant(r, lst, pbad=0.1):
    goods = [x for x in lst if x not in BADV]
    bads = [x for x in lst if x in BADV]
    if bads and r.random() < pbad:
        return r.choice(bads)
    return r.choice(goods)


def bad(r, p=0.08):
    return r.random() < p


# ---------------------------------------------------------------- templates
# each template: fn(r) -> (src, edition)


def t_envimpl(r):
    """where-bound vs impl candidates for trait and projection goals"""
    n = Names(r)
    Tr, Wr, A, f = n.tr(), n.st(), n.assoc(), n.fn()
    X, xv, _ = ty(r, "copy")
    v = variant(r, ["noenv", "envbind", "envbind", "guide_ok", "region", "plain_bad", "guide_bad"])
    items = [
        fill("pub struct @W@<T>(pub T);", W=Wr),
        fill("pub trait @Tr@<X> {\n    type @A@;\n    fn get(&self, x: X) -> Self::@A@;\n}", Tr=Tr, A=A),
        fill("impl<T: Clone> @Tr@<@X@> for @W@<T> {\n    type @A@ = T;\n    fn get(&self, _x: @X@) -> T { self.0.clone() }\n}",
             Tr=Tr, A=A, X=X, W=Wr),
    ]
    feats = []
    if v in ("noenv", "envbind", "plain_bad"):
        wc = {"noenv": "", "envbind": fill("\nwhere\n    @W@<T>: @Tr@<@X@, @A@ = T>,", W=Wr, Tr=Tr, X=X, A=A),
              "plain_bad": fill("\nwhere\n    @W@<T>: @Tr@<@X@>,", W=Wr, Tr=Tr, X=X)}[v]
        gen = r.random() < 0.5
        body = fill("w.get(@xv@)", xv=xv) if r.random() < 0.5 else fill("<@W@<T> as @Tr@<@X@>>::get(&w, @xv@)", W=Wr, Tr=Tr, X=X, xv=xv)
        items.append(fill("pub fn @f@<T: Clone>(w: @W@<T>) -> T@wc@ {\n    let r@ann@ = @body@;\n    r\n}",
                          f=f, W=Wr, wc=wc, body=body, ann=": T" if r.random() < 0.5 else ""))
        if gen:
            E, ev, _ = ty(r, "clone")
            items.append(fill("pub fn caller() -> @E@ {\n    @f@(@W@(@ev@))\n}", E=E, f=f, W=Wr, ev=ev))
    elif v in ("guide_ok", "guide_bad"):
        items = [fill("pub trait @Tr@<T> {\n    fn call_me(&self, x: T) -> T { x }\n}", Tr=Tr)]
        for t in r.sample(["u32", "i32", "u8", "i64"], 2):
            items.append(fill("impl<T> @Tr@<@t@> for T {}", Tr=Tr, t=t))
        if v == "guide_ok":
            arg = r.choice(["u", "u.clone()"])
            items.append(fill("pub fn @f@<T: @Tr@<U>, U: Clone>(x: T, u: U) -> U {\n    x.call_me(@arg@)\n}", f=f, Tr=Tr, arg=arg))
        else:
            items.append(fill("pub fn @f@<T: @Tr@<U>, U>(x: T) {\n    x.call_me(1u32);\n}", f=f, Tr=Tr))
    else:  # region
        items = [fill("pub trait @Tr@<'a> {}", Tr=Tr),
                 fill("impl<T> @Tr@<'static> for T {}", Tr=Tr),
                 fill("fn impls<'a, T: @Tr@<'a>>() {}", Tr=Tr)]
        k = r.randint(1, 3)
        lts = ", ".join("'r%d" % i for i in range(k))
        bounds = " + ".join("@Tr@<'r%d>" % i for i in range(k)).replace("@Tr@", Tr)
        calls = "".join("    impls::<'r%d, T>();\n" % i for i in r.sample(range(k), k))
        if r.random() < 0.12:
            calls += "    impls::<'static, T>();\n"
        items.append(fill("pub fn @f@<@lts@, T: @b@>() {\n@calls@}", f=f, lts=lts, b=bounds, calls=calls))
    return render(r, feats, items), "2021"


def t_globalwb(r):
    """global where-bounds vs impls (trait + projection)"""
    n = Names(r)
    Tr, A, f = n.tr(), n.assoc(), n.fn()
    S, sv, _ = ty(r, "copy")
    O, ov, _ = ty(r, "copy dbg")
    v = variant(r, ["proj", "trait", "mixed", "static", "bad"])
    items = [fill("pub trait @Tr@ {\n    type @A@;\n    fn mk(&self) -> Self::@A@;\n}", Tr=Tr, A=A),
             fill("impl @Tr@ for @S@ {\n    type @A@ = @O@;\n    fn mk(&self) -> @O@ { @ov@ }\n}", Tr=Tr, S=S, A=A, O=O, ov=ov)]
    gen = r.random() < 0.5
    tp = "<T: Copy>" if gen else ""
    if v == "proj":
        wc = fill("@S@: @Tr@<@A@ = @O@>", S=S, Tr=Tr, A=A, O=O)
        ret, body = O, fill("let s: @S@ = @sv@;\n    s.mk()", S=S, sv=sv)
    elif v == "trait":
        wc = fill("@S@: @Tr@", S=S, Tr=Tr)
        ret, body = fill("<@S@ as @Tr@>::@A@", S=S, Tr=Tr, A=A), fill("(@sv@).mk()", sv=sv)
    elif v == "mixed":
        wc = fill("@S@: @Tr@, <@S@ as @Tr@>::@A@: Copy + core::fmt::Debug", S=S, Tr=Tr, A=A)
        ret, body = O, fill("let x = <@S@ as @Tr@>::mk(&@sv@);\n    let _y = x;\n    x", S=S, Tr=Tr, sv=sv)
    elif v == "static":
        items[0] = fill("pub trait @Tr@<'a> {\n    type @A@;\n    fn mk(&self) -> Self::@A@;\n}", Tr=Tr, A=A)
        items[1] = fill("impl<'a> @Tr@<'a> for @S@ {\n    type @A@ = @O@;\n    fn mk(&self) -> @O@ { @ov@ }\n}", Tr=Tr, S=S, A=A, O=O, ov=ov)
        wc = fill("@S@: @Tr@<'static, @A@ = @O@>", S=S, Tr=Tr, A=A, O=O)
        ret, body = O, fill("<@S@ as @Tr@<'static>>::mk(&@sv@)", S=S, Tr=Tr, sv=sv)
    else:
        O2, _, _ = r.choice([t for t in TYPES if t[0] != O])
        wc = fill("@S@: @Tr@<@A@ = @O@>", S=S, Tr=Tr, A=A, O=O)
        ret, body = O2, fill("(@sv@).mk()", sv=sv)
    items.append(fill("pub fn @f@@tp@() -> @ret@\nwhere\n    @wc@,\n{\n    @body@\n}", f=f, tp=tp, ret=ret, wc=wc, body=body))
    if gen and r.random() < 0.6:
        items.append(fill("pub fn call() {\n    let _ = @f@::<u8>();\n}", f=f))
    return render(r, [], items), "2021"


def t_regionwb(r):
    """where-bounds and alias bounds with regions / higher-ranked bounds"""
    n = Names(r)
    B, Tr, f = n.tr(), n.tr(), n.fn()
    v = variant(r, ["alias_hr", "alias_hr", "unnec", "strref", "outlives"])
    if v == "alias_hr":
        k = r.randint(1, 3)
        lts = ", ".join("'l%d" % i for i in range(k))
        calls = "".join("    impls_bound::<'l%d, T::Assoc>();\n" % i for i in range(k))
        hr = r.choice(["for<'hr> T::Assoc: @B@<'hr>", "for<'hr> <T as @Tr@<'a>>::Assoc: @B@<'hr>"])
        items = [fill("pub trait @B@<'a> {}", B=B),
                 fill("pub trait @Tr@<'a> {\n    type Assoc: @B@<'a>;\n}", Tr=Tr, B=B),
                 fill("fn impls_bound<'b, T: @B@<'b>>() {}", B=B),
                 fill("pub fn @f@<'a, @lts@, T>()\nwhere\n    T: @Tr@<'a>,\n    " + hr + ",\n{\n@calls@}",
                      f=f, lts=lts, Tr=Tr, B=B, calls=calls)]
        if r.random() < 0.5:
            items.append(fill("impl<'a> @B@<'a> for u8 {}\nimpl<'a> @Tr@<'a> for () {\n    type Assoc = u8;\n}\npub fn c() {\n    @f@::<()>();\n}", B=B, Tr=Tr, f=f)
                         if k == 1 else None)
    elif v == "unnec":
        items = [fill("pub trait @B@<'a> {}", B=B),
                 fill("pub trait @Tr@<'a> {\n    type Assoc: @B@<'a>;\n}", Tr=Tr, B=B),
                 fill("fn impls_bound<'b, T: @B@<'b>>() {}", B=B),
                 fill("pub fn @f@<'a, 'b, T>()\nwhere\n    T: for<'hr> @Tr@<'hr>,\n    <T as @Tr@<'b>>::Assoc: @B@<'a>,\n{\n    impls_bound::<'@l@, <T as @Tr@<'@l@>>::Assoc>();\n}",
                      f=f, Tr=Tr, B=B, l=r.choice("ab"))]
    elif v == "strref":
        good = not bad(r, 0.1)
        items = [fill("pub trait @Tr@<'a> {}", Tr=Tr),
                 fill("impl<'a> @Tr@<'a> for &'a str {}", Tr=Tr),
                 fill("fn impls_trait<'a, T: @Tr@<'a>>(_: T) {}", Tr=Tr)]
        if good:
            items.append(fill("pub fn @f@<'a, 'b: 'a>(x: &'b str) {\n    impls_trait::<'a, _>(x);\n    impls_trait(x);\n}", f=f, Tr=Tr))
        else:
            items.append(fill("pub fn @f@<'a, 'b>(x: &'b str)\nwhere\n    &'a str: @Tr@<'b>,\n{\n    impls_trait::<'b, _>(x);\n}", f=f, Tr=Tr))
    else:
        items = [fill("pub trait @Tr@<'a>: 'a {\n    fn r(&'a self) -> &'a Self { self }\n}", Tr=Tr),
                 fill("impl<'a, T: 'a> @Tr@<'a> for T {}", Tr=Tr),
                 fill("pub fn @f@<'a, T: @Tr@<'a>>(x: &'a T) -> &'a T {\n    x.r()\n}", f=f, Tr=Tr),
                 fill("pub fn g<'q>(v: &'q Vec<u8>) -> &'q Vec<u8> {\n    @f@(v)\n}", f=f)]
    return render(r, [], items), "2021"


def t_superproj(r):
    """supertrait elaboration of projection bounds through several layers"""
    n = Names(r)
    depth = r.randint(1, 5)
    trs = [n.tr() for _ in range(depth + 1)]
    A, f = n.assoc(), n.fn()
    O, ov, _ = ty(r, "copy")
    bind_at = r.randint(1, depth)  # layer whose supertrait list binds A
    items = [fill("pub trait @T0@ {\n    type @A@;\n    fn get(&self) -> Self::@A@;\n}", T0=trs[0], A=A)]
    for i in range(1, depth + 1):
        sup = trs[i - 1] + (fill("<@A@ = @O@>", A=A, O=O) if i == bind_at and i == 1 else "")
        if i == bind_at and i > 1:
            # bind via where Self: T0<A = O>
            items.append(fill("pub trait @Ti@: @sup@\nwhere\n    Self: @T0@<@A@ = @O@>,\n{}", Ti=trs[i], sup=sup, T0=trs[0], A=A, O=O))
        else:
            items.append(fill("pub trait @Ti@: @sup@ {}", Ti=trs[i], sup=sup))
    top = trs[-1]
    proj = r.choice(["T::@A@", "<T as @T0@>::@A@"]).replace("@T0@", trs[0]).replace("@A@", A)
    outp = r.choice(["in", "out", "both"])
    wrong = bad(r, 0.07)
    retty = O
    if wrong:
        retty = r.choice([t for t in TYPES if t[0] != O])[0]
    if outp == "in":
        sig, body = fill("(x: @P@) -> @O@", P=proj, O=retty), "x"
    elif outp == "out":
        sig, body = fill("(t: &T) -> @O@", O=retty), "t.get()"
    else:
        sig, body = fill("(t: &T, x: @O@) -> @P@", O=O, P=proj), r.choice(["x", "{ let _ = t.get(); x }"])
        if wrong:
            body = fill("@v@", v=r.choice([t for t in TYPES if t[0] != O])[1])
    gen_style = r.choice(["bound", "where", "impl"])
    if gen_style == "bound":
        items.append(fill("pub fn @f@<T: @top@>@sig@ {\n    @body@\n}", f=f, top=top, sig=sig, body=body))
    else:
        items.append(fill("pub fn @f@<T>@sig@\nwhere\n    T: @top@,\n{\n    @body@\n}", f=f, top=top, sig=sig, body=body))
    if r.random() < 0.5:
        S = n.st()
        items.append(fill("pub struct @S@;\nimpl @T0@ for @S@ {\n    type @A@ = @O@;\n    fn get(&self) -> @O@ { @ov@ }\n}", S=S, T0=trs[0], A=A, O=O, ov=ov))
        for t in trs[1:]:
            items.append(fill("impl @t@ for @S@ {}", t=t, S=S))
        if not wrong:
            args = {"in": "(" + ov + ")", "out": "(&" + S + ")", "both": "(&" + S + ", " + ov + ")"}[outp]
            items.append(fill("pub fn call() -> @O@ {\n    @f@::<@S@>@args@\n}", O=O, f=f, S=S, args=args))
    return render(r, [], items), "2021"


def t_aliasbound(r):
    """alias-bound candidates vs param-env candidates, nested item bounds"""
    n = Names(r)
    Tr, B, A, f = n.tr(), n.tr(), n.assoc(), n.fn()
    v = variant(r, ["plain", "env_too", "nested", "nested_atb", "method", "missing"])
    items = [fill("pub trait @B@ {\n    fn bm(&self) -> u32 { 1 }\n}", B=B)]
    if v in ("plain", "env_too", "method", "missing"):
        bnd = r.choice(["@B@", "@B@ + Clone", "Clone + @B@", "@B@ + core::fmt::Debug"]).replace("@B@", B)
        if v == "missing":
            bnd = "Clone"
        items.append(fill("pub trait @Tr@ {\n    type @A@: @bnd@;\n    fn a(&self) -> Self::@A@;\n}", Tr=Tr, A=A, bnd=bnd))
        wc = fill("\nwhere\n    T::@A@: @B@,", A=A, B=B) if v == "env_too" else ""
        if v == "method":
            body = r.choice(["t.a().bm()", fill("@B@::bm(&t.a())", B=B), fill("<T::@A@ as @B@>::bm(&t.a())", A=A, B=B)])
        else:
            body = r.choice(["need(t.a())", fill("need::<T::@A@>(t.a())", A=A), "{ let x = t.a(); need(x) }"])
        items.append(fill("fn need<X: @B@>(x: X) -> u32 {\n    x.bm()\n}", B=B))
        items.append(fill("pub fn @f@<T: @Tr@>(t: T) -> u32@wc@ {\n    @body@\n}", f=f, Tr=Tr, wc=wc, body=body))
        if r.random() < 0.5:
            S, E = n.st(), r.choice(["u8", "bool", "()"])
            items.append(fill("impl @B@ for @E@ {}\npub struct @S@;\nimpl @Tr@ for @S@ {\n    type @A@ = @E@;\n    fn a(&self) -> @E@ { Default::default() }\n}", B=B, E=E, S=S, Tr=Tr, A=A) if v != "missing" or True else None)
    else:
        C = n.tr()
        items.append(fill("pub trait @C@ {\n    type Inner;\n    fn inner(&self) -> Self::Inner;\n}", C=C))
        if v == "nested":
            items.append(fill("pub trait @Tr@ {\n    type @A@: @C@;\n    fn a(&self) -> Self::@A@;\n}", Tr=Tr, A=A, C=C))
            wc = fill("\nwhere\n    <T::@A@ as @C@>::Inner: @B@,", A=A, C=C, B=B)
        else:
            items.append(fill("pub trait @Tr@ {\n    type @A@: @C@<Inner: @B@>;\n    fn a(&self) -> Self::@A@;\n}", Tr=Tr, A=A, C=C, B=B))
            wc = "" if r.random() < 0.7 else fill("\nwhere\n    <T::@A@ as @C@>::Inner: @B@,", A=A, C=C, B=B)
        body = r.choice(["t.a().inner().bm()", "{ let i = t.a().inner(); i.bm() }", fill("@B@::bm(&@C@::inner(&t.a()))", B=B, C=C)])
        items.append(fill("pub fn @f@<T: @Tr@>(t: T) -> u32@wc@ {\n    @body@\n}", f=f, Tr=Tr, wc=wc, body=body))
    return render(r, [], items), "2021"


def t_implhdrproj(r):
    """projections in impl headers, impl where-clauses and fn signatures"""
    n = Names(r)
    Tr, Ot, A, Wr, f = n.tr(), n.tr(), n.assoc(), n.st(), n.fn()
    E1, e1, _ = ty(r, "copy dbg")
    items = [fill("pub trait @Tr@ {\n    type @A@;\n}", Tr=Tr, A=A),
             fill("impl @Tr@ for u8 {\n    type @A@ = @E1@;\n}", Tr=Tr, A=A, E1=E1),
             fill("pub struct @W@<T>(pub T);", W=Wr)]
    v = variant(r, ["param", "self", "where", "nested"])
    if v == "param":
        items.append(fill("pub trait @Ot@<X> {\n    fn o(&self, x: X) -> X { x }\n}", Ot=Ot))
        items.append(fill("impl<T: @Tr@> @Ot@<T::@A@> for @W@<T> {}", T=Tr, Tr=Tr, Ot=Ot, A=A, W=Wr))
        call = fill("@W@(0u8).o(@e1@)", W=Wr, e1=e1)
        ret = E1
    elif v == "self":
        items.append(fill("pub trait @Ot@ {\n    fn o(self) -> Self;\n}", Ot=Ot))
        items.append(fill("impl @Ot@ for @W@<<u8 as @Tr@>::@A@> {\n    fn o(self) -> Self { self }\n}", Ot=Ot, W=Wr, Tr=Tr, A=A))
        call = fill("@W@(@e1@).o().0", W=Wr, e1=e1)
        ret = E1
    elif v == "where":
        items.append(fill("pub trait @Ot@ {\n    type R;\n    fn o(&self) -> Self::R;\n}", Ot=Ot))
        items.append(fill("impl<T> @Ot@ for @W@<T>\nwhere\n    T: @Tr@ + Copy,\n    T::@A@: Default,\n{\n    type R = T::@A@;\n    fn o(&self) -> T::@A@ { Default::default() }\n}", Ot=Ot, W=Wr, Tr=Tr, A=A))
        call = fill("@W@(1u8).o()", W=Wr)
        ret = E1
        if "def" not in dict((t[0], t[2]) for t in TYPES)[E1]:
            ret = E1
    else:
        items.append(fill("impl @Tr@ for @W@<u8> {\n    type @A@ = <u8 as @Tr@>::@A@;\n}", Tr=Tr, W=Wr, A=A))
        items.append(fill("pub trait @Ot@ {\n    fn o(&self) -> u32 { 3 }\n}", Ot=Ot))
        items.append(fill("impl @Ot@ for <@W@<u8> as @Tr@>::@A@ {}", Ot=Ot, W=Wr, Tr=Tr, A=A))
        call = fill("{ let x: <@W@<u8> as @Tr@>::@A@ = @e1@; let _ = x.o(); x }", W=Wr, Tr=Tr, A=A, e1=e1)
        ret = E1
    if bad(r, 0.07):
        ret = r.choice([t for t in TYPES if t[0] != E1])[0]
    items.append(fill("pub fn @f@() -> @ret@ {\n    @call@\n}", f=f, ret=ret, call=call))
    return render(r, [], items), "2021"


def t_idproj(r):
    """identity projections nested, in sigs, fields, impl headers"""
    n = Names(r)
    Id, Tr, f = n.pick(["Id", "Ident", "Same", "Me"]), n.tr(), n.fn()
    depth = r.randint(1, 6)
    E, ev, props = ty(r, "copy")
    unsz = r.random() < 0.4

    def nest(t, d):
        for _ in range(d):
            t = "<%s as %s>::This" % (t, Id)
        return t
    items = [fill("pub trait @Id@@q@ {\n    type This@q2@;\n}", Id=Id, q=": ?Sized" if False else "", q2=": ?Sized" if unsz else ""),
             fill("impl<T@q@> @Id@ for T {\n    type This = T;\n}", q=": ?Sized" if unsz else "", Id=Id)]
    v = variant(r, ["fn", "generic", "field", "impl", "unsized"] if unsz else ["fn", "generic", "field", "impl"])
    if v == "fn":
        a = r.randint(0, depth)
        items.append(fill("pub fn @f@(x: @IN@) -> @OUT@ {\n    @b@\n}", f=f, IN=nest(E, a), OUT=nest(E, depth - a),
                          b=r.choice(["x", "{ let y: %s = x; y }" % nest(E, r.randint(0, depth))])))
    elif v == "generic":
        a = r.randint(0, depth)
        items.append(fill("pub fn @f@<T: Clone>(x: @IN@) -> @OUT@ {\n    x.clone()\n}", f=f, IN="&" + nest("T", a), OUT=nest("T", depth - a)))
        items.append(fill("pub fn g() -> @E@ {\n    @f@::<@E@>(&@ev@)\n}", E=E, f=f, ev=ev))
    elif v == "field":
        S = n.st()
        items.append(fill("pub struct @S@<T> {\n    pub v: @N@,\n}", S=S, N=nest("T", depth)))
        items.append(fill("pub fn @f@<T>(s: @S@<T>) -> T {\n    s.v\n}", S=S, f=f))
        items.append(fill("pub fn g() -> @E@ {\n    @f@(@S@ { v: @ev@ })\n}", E=E, f=f, S=S, ev=ev))
    elif v == "impl":
        items.append(fill("pub trait @Tr@ {\n    fn t(&self) -> u8 { 0 }\n}", Tr=Tr))
        items.append(fill("impl @Tr@ for @N@ {}", Tr=Tr, N=nest(E, depth)))
        items.append(fill("pub fn @f@(x: @E@) -> u8 {\n    x.t()\n}", f=f, E=E))
        if bad(r, 0.15):
            items.append(fill("impl @Tr@ for @E@ {}", Tr=Tr, E=E))
    else:
        items.append(fill("pub fn @f@(x: &@N@) -> usize {\n    x.len()\n}", f=f, N=nest(r.choice(["str", "[u8]"]), depth)))
    if bad(r, 0.05) and v == "fn":
        items[-1] = items[-1].replace("    x\n", "    x as %s\n" % "u8" if "num" not in props else "    ()\n")
    return render(r, [], items), "2021"


def t_hrproj(r):
    """projections under binders: for<'a> <T as Tr<'a>>::Assoc: Bound"""
    n = Names(r)
    Tr, f = n.tr(), n.fn()
    bnd = r.choice(["core::fmt::Debug", "Copy", "Clone", "Sized", "Send"])
    items = [fill("pub trait @Tr@<'a> {\n    type Assoc;\n    fn mk(&'a self) -> Self::Assoc;\n}", Tr=Tr)]
    impls = r.sample(["u8", "String", "Vec<u32>", "bool"], r.randint(1, 3))
    for t in impls:
        items.append(fill("impl<'a> @Tr@<'a> for @t@ {\n    type Assoc = &'a @t@;\n    fn mk(&'a self) -> &'a @t@ { self }\n}", Tr=Tr, t=t))
    form = r.choice(["where", "where", "bound", "fnbound"])
    use = r.choice(["need", "need", "debug"]) if bnd == "core::fmt::Debug" else "need"
    if form == "where":
        items.append(fill("pub fn @f@<T>(t: &T)\nwhere\n    T: for<'a> @Tr@<'a>,\n    for<'a> <T as @Tr@<'a>>::Assoc: @b@,\n{\n    @u@;\n}",
                          f=f, Tr=Tr, b=bnd, u="need(t.mk())" if use == "need" else "let _ = format!(\"{:?}\", t.mk())"))
    elif form == "bound":
        items.append(fill("pub fn @f@<T: for<'a> @Tr@<'a, Assoc: @b@>>(t: &T) {\n    need(t.mk());\n}", f=f, Tr=Tr, b=bnd))
    else:
        items.append(fill("pub fn @f@<T, F>(t: &T, g: F)\nwhere\n    T: for<'a> @Tr@<'a>,\n    F: for<'a> Fn(<T as @Tr@<'a>>::Assoc) -> usize,\n{\n    let _n = g(t.mk());\n}", f=f, Tr=Tr))
        bnd = None
    if bnd:
        items.append(fill("fn need<X: @b@>(_x: X) {}", b=bnd))
    if r.random() < 0.7:
        t = r.choice(impls)
        cl = "|x| { let _ = x; 1 }"
        items.append(fill("pub fn call(v: @t@) {\n    @f@(&v@cl@);\n}", t=t, f=f, cl=(", " + cl) if form == "fnbound" else ""))
    if bnd and bad(r, 0.06):
        items[-1] = items[-1].replace("{\n    ", "{\n    let _: () = t.mk();\n    ", 1)
    return render(r, [], items), "2021"


def t_defeq(r):
    """deferred alias equality: equating two unnormalizable projections"""
    n = Names(r)
    Tr, Tr2, A, f = n.tr(), n.tr(), n.assoc(), n.fn()
    v = variant(r, ["bind", "bind2", "chain", "generic_tr", "bad"])
    items = [fill("pub trait @Tr@ {\n    type @A@;\n    fn a(&self) -> Self::@A@;\n}", Tr=Tr, A=A)]
    if v == "bind":
        items.append(fill("pub fn @f@<T: @Tr@, U: @Tr@<@A@ = T::@A@>>(t: &T, _u: &U) -> U::@A@ {\n    t.a()\n}", f=f, Tr=Tr, A=A))
    elif v == "bind2":
        items.append(fill("pub fn @f@<T, U>(t: &T) -> Vec<<U as @Tr@>::@A@>\nwhere\n    T: @Tr@,\n    U: @Tr@<@A@ = <T as @Tr@>::@A@>,\n{\n    let mut v = Vec::new();\n    v.push(t.a());\n    v\n}", f=f, Tr=Tr, A=A))
    elif v == "chain":
        k = r.randint(2, 5)
        ps = ["P%d" % i for i in range(k)]
        bounds = ["P0: @Tr@".replace("@Tr@", Tr)] + ["P%d: %s<%s = P%d::%s>" % (i, Tr, A, i - 1, A) for i in range(1, k)]
        items.append(fill("pub fn @f@<@ps@>(x: P0::@A@) -> (P@l@::@A@,)\nwhere\n    @b@,\n{\n    (x,)\n}",
                          f=f, ps=", ".join(ps), A=A, l=k - 1, b=",\n    ".join(bounds)))
    elif v == "generic_tr":
        items.append(fill("pub trait @T2@<X> {\n    fn take(&self, x: X) -> X { x }\n}", T2=Tr2))
        items.append(fill("pub fn @f@<T: @Tr@, U: @Tr@, V: @T2@<T::@A@>>(t: T, v: V) -> U::@A@\nwhere\n    U: @Tr@<@A@ = T::@A@>,\n{\n    v.take(t.a())\n}", f=f, Tr=Tr, A=A, T2=Tr2))
    else:
        items.append(fill("pub fn @f@<T: @Tr@, U: @Tr@>(t: &T) -> U::@A@ {\n    t.a()\n}", f=f, Tr=Tr, A=A))
    if v != "bad" and v != "chain" and r.random() < 0.5:
        items.append(fill("impl @Tr@ for u8 {\n    type @A@ = u16;\n    fn a(&self) -> u16 { 1 }\n}\nimpl @Tr@ for bool {\n    type @A@ = u16;\n    fn a(&self) -> u16 { 2 }\n}", Tr=Tr, A=A))
        if v == "bind":
            items.append(fill("pub fn c() -> u16 {\n    @f@(&1u8, &true)\n}", f=f))
        elif v == "bind2":
            items.append(fill("pub fn c() -> Vec<u16> {\n    @f@::<u8, bool>(&1)\n}", f=f))
    return render(r, [], items), "2021"


def t_rpit(r):
    """RPIT in defining scope: recursion, method calls, multiple returns"""
    n = Names(r)
    f = n.fn()
    v = variant(r, ["rec_clone", "rec_iter", "rec_ref", "closure", "multi", "deref", "index", "bad"])
    feats = []
    E, ev, _ = ty(r, "copy dbg")
    if v == "rec_clone":
        meth = r.choice(["let _y = x.clone();", "let _y = Clone::clone(&x);", "let _y: Vec<_> = vec![x];"])
        bounds = r.choice(["Clone", "Clone + core::fmt::Debug", "Sized + Clone"])
        src = fill("pub fn @f@(n: u32) -> impl @b@ {\n    if n > 0 {\n        let x = @f@(n - 1);\n        @m@\n    }\n    @ev@\n}", f=f, b=bounds, m=meth, ev=ev)
    elif v == "rec_iter":
        src = fill("pub fn @f@(n: u32) -> impl Iterator<Item = u32> {\n    let v: Vec<u32> = if n == 0 {\n        vec![1, 2]\n    } else {\n        @f@(n - 1).map(|x| x + 1).collect()\n    };\n    v.into_iter()\n}", f=f)
    elif v == "rec_ref":
        src = fill("pub fn @f@<'a>(x: &'a [u8], d: usize) -> impl Fn(usize) -> u8 + 'a {\n    if d > 0 {\n        let g = @f@(x, d - 1);\n        let _ = g(0);\n    }\n    move |i| x[i % x.len()]\n}", f=f)
    elif v == "closure":
        src = fill("pub fn @f@(k: u32) -> impl Fn(u32) -> u32 {\n    move |x| x * k\n}\npub fn g() -> u32 {\n    let h = @f@(3);\n    let c = |y| h(y) + 1;\n    c(@a@)\n}", f=f, a=r.randint(0, 9))
    elif v == "multi":
        k = r.randint(2, 4)
        arms = "".join("        %d => Box::new(%s),\n" % (i, ev) for i in range(k))
        src = fill("pub fn @f@(n: u8) -> impl core::fmt::Debug {\n    match n {\n@arms@        _ => Box::new(@ev@),\n    }\n}", f=f, arms=arms, ev=ev)
        if r.random() < 0.5:
            src = src.replace("Box::new(%s)" % ev, "%s" % ev)
    elif v == "deref":
        src = fill("pub fn @f@(b: bool) -> impl core::ops::Deref<Target = [u32]> {\n    if b {\n        let v = @f@(false);\n        let _n = v.len();\n    }\n    vec![1u32, 2, 3]\n}", f=f)
    elif v == "index" and r.random() < 0.15:
        src = fill("pub fn @f@(n: usize) -> impl core::ops::Index<usize, Output = u8> {\n    if n > 0 {\n        let a = @f@(n - 1);\n        let _x: u8 = a[0];\n    }\n    vec![0u8; 4]\n}", f=f)
    elif v == "index":
        src = fill("pub fn @f@(n: usize) -> impl core::ops::Index<usize, Output = u8> {\n    vec![n as u8; 4]\n}\npub fn idx(n: usize) -> u8 {\n    let a = @f@(n);\n    let b = &a;\n    a[0] + b[1]\n}", f=f)
    else:
        src = fill("pub fn @f@(n: u32) -> impl Sized {\n    if n > 0 {\n        let x: u32 = @f@(n - 1);\n        return x;\n    }\n    1u64\n}", f=f)
    items = [src]
    if r.random() < 0.4:
        items.append(fill("pub fn user() {\n    let _a = @f@(@arg@);\n}", f=f, arg={"rec_ref": "&[1, 2], 2", "deref": "true", "multi": "1"}.get(v, "2")))
    return render(r, feats, items), "2021"


def t_tait(r):
    """TAIT with #[define_opaque]: multiple defining uses, struct fields, methods"""
    n = Names(r)
    Ty, f, g = n.pick(["Tait", "Opq", "Hidden", "Alias"]), n.fn(), n.fn()
    E, ev, _ = ty(r, "copy dbg")
    feats = ["type_alias_impl_trait"]
    bnd = r.choice(["core::fmt::Debug", "Copy + core::fmt::Debug", "Clone", "Sized"])
    v = variant(r, ["single", "two_defs", "field", "method", "nondef", "fnptr", "bad_mismatch"])
    items = [fill("pub type @Ty@ = impl @b@;", Ty=Ty, b=bnd)]
    if v == "single":
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @f@() -> @Ty@ {\n    @ev@\n}", Ty=Ty, f=f, ev=ev))
    elif v == "two_defs":
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @f@() -> @Ty@ {\n    @ev@\n}", Ty=Ty, f=f, ev=ev))
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @g@(b: bool) -> (@Ty@, u8) {\n    let x: @E@ = @ev@;\n    (x, b as u8)\n}", Ty=Ty, g=g, ev=ev, E=E))
    elif v == "field":
        S = n.st()
        items.append(fill("pub struct @S@ {\n    pub v: @Ty@,\n    pub n: u32,\n}", S=S, Ty=Ty))
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @f@(n: u32) -> @S@ {\n    @S@ { v: @ev@, n }\n}", Ty=Ty, f=f, S=S, ev=ev))
        items.append(fill("pub fn @g@() -> u32 {\n    @f@(4).n\n}", g=g, f=f))
    elif v == "method":
        items[0] = fill("pub type @Ty@ = impl Iterator<Item = u32>;", Ty=Ty)
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @f@(n: u32) -> @Ty@ {\n    (0..n).map(|x| x * 2)\n}", Ty=Ty, f=f))
        items.append(fill("pub fn @g@() -> u32 {\n    @f@(5).@m@\n}", g=g, f=f, m=r.choice(["sum()", "count() as u32", "max().unwrap_or(0)", "last().unwrap_or(1)"])))
    elif v == "nondef":
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @f@() -> @Ty@ {\n    @ev@\n}", Ty=Ty, f=f, ev=ev))
        items.append(fill("pub fn @g@() -> @Ty@ {\n    let x = @f@();\n    x\n}", Ty=Ty, g=g, f=f))
    elif v == "fnptr":
        items[0] = fill("pub type @Ty@ = impl Fn(u32) -> u32;", Ty=Ty)
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @f@(k: u32) -> @Ty@ {\n    move |x| x + k\n}", Ty=Ty, f=f))
        items.append(fill("pub fn @g@() -> u32 {\n    let h = @f@(1);\n    h(2) + @f@(3)(4)\n}", g=g, f=f))
    else:
        E2, ev2, _ = r.choice([t for t in TYPES if t[0] != E and "copy" in t[2]])
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @f@() -> @Ty@ {\n    @ev@\n}", Ty=Ty, f=f, ev=ev))
        items.append(fill("#[define_opaque(@Ty@)]\npub fn @g@() -> @Ty@ {\n    @ev2@\n}", Ty=Ty, g=g, ev2=ev2))
    return render(r, feats, items), "2021"


def t_atpit(r):
    """impl Trait in associated type position"""
    n = Names(r)
    Tr, S, A, f = n.tr(), n.st(), n.assoc(), n.fn()
    feats = ["impl_trait_in_assoc_type"]
    v = variant(r, ["iter", "debug", "fn", "nested", "generic", "bad"])
    if v == "iter":
        items = [fill("pub trait @Tr@ {\n    type @A@: Iterator<Item = u32>;\n    fn it(&self) -> Self::@A@;\n}", Tr=Tr, A=A),
                 fill("pub struct @S@(pub u32);", S=S),
                 fill("impl @Tr@ for @S@ {\n    type @A@ = impl Iterator<Item = u32>;\n    fn it(&self) -> Self::@A@ {\n        (0..self.0).map(|x| x + 1)\n    }\n}", Tr=Tr, S=S, A=A),
                 fill("pub fn @f@(s: &@S@) -> u32 {\n    s.it().@m@\n}", f=f, S=S, m=r.choice(["sum()", "count() as u32", "fold(0, |a, b| a + b)"]))]
    elif v in ("debug", "bad"):
        E, ev, _ = ty(r, "copy dbg")
        items = [fill("pub trait @Tr@ {\n    type @A@;\n    fn get(&self) -> Self::@A@;\n}", Tr=Tr, A=A),
                 fill("pub struct @S@;", S=S),
                 fill("impl @Tr@ for @S@ {\n    type @A@ = impl core::fmt::Debug + Copy;\n    fn get(&self) -> Self::@A@ { @ev@ }\n}", Tr=Tr, S=S, A=A, ev=ev),
                 fill("pub fn @f@() -> String {\n    let v = @S@.get();\n    format!(\"{:?}\", (v, v))\n}", f=f, S=S)]
        if v == "bad":
            items[-1] = fill("pub fn @f@() -> @E@ {\n    @S@.get()\n}", f=f, S=S, E=E)
    elif v == "fn":
        items = [fill("pub trait @Tr@ {\n    type @A@: Fn(u8) -> u8;\n    fn mk(&self) -> Self::@A@;\n}", Tr=Tr, A=A),
                 fill("pub struct @S@(pub u8);", S=S),
                 fill("impl @Tr@ for @S@ {\n    type @A@ = impl Fn(u8) -> u8;\n    fn mk(&self) -> Self::@A@ {\n        let k = self.0;\n        move |x| x.wrapping_add(k)\n    }\n}", Tr=Tr, S=S, A=A),
                 fill("pub fn @f@<T: @Tr@>(t: &T) -> u8 {\n    (t.mk())(1)\n}\npub fn g() -> u8 {\n    @f@(&@S@(2))\n}", f=f, Tr=Tr, S=S)]
    elif v == "nested":
        items = [fill("pub trait @Tr@ {\n    type @A@: IntoIterator<Item = Self::B>;\n    type B: Copy;\n    fn get(&self) -> Self::@A@;\n}", Tr=Tr, A=A),
                 fill("pub struct @S@;", S=S),
                 fill("impl @Tr@ for @S@ {\n    type @A@ = impl IntoIterator<Item = Self::B>;\n    type B = impl Copy;\n    fn get(&self) -> Self::@A@ {\n        vec![1u8, 2]\n    }\n}", Tr=Tr, S=S, A=A),
                 fill("pub fn @f@() -> usize {\n    @S@.get().into_iter().count()\n}", f=f, S=S)]
    else:
        items = [fill("pub trait @Tr@ {\n    type @A@: Clone;\n    fn get(&self) -> Self::@A@;\n}", Tr=Tr, A=A),
                 fill("pub struct @S@<T>(pub T);", S=S),
                 fill("impl<T: Clone> @Tr@ for @S@<T> {\n    type @A@ = impl Clone;\n    fn get(&self) -> Self::@A@ {\n        (self.0.clone(), 1u8)\n    }\n}", Tr=Tr, S=S, A=A),
                 fill("pub fn @f@<T: @Tr@>(t: T) -> (T::@A@, T::@A@) {\n    let a = t.get();\n    (a.clone(), a)\n}\npub fn g() {\n    let _ = @f@(@S@(@ev@));\n}", f=f, Tr=Tr, S=S, A=A, ev=ty(r, "clone")[1])]
    return render(r, feats, items), "2021"


def t_autoleak(r):
    """auto-trait leakage of opaque types across functions"""
    n = Names(r)
    f, g = n.fn(), n.fn()
    at = r.choice(["Send", "Sync", "Unpin", "Send + Sync"])
    good_vals = ["vec![1u8]", "String::new()", "Box::new(3u32)", "std::sync::Arc::new(1u8)", "(1u8, 'c')"]
    bad_vals = {"Send": ["std::rc::Rc::new(1u8)"], "Sync": ["core::cell::Cell::new(1u8)", "std::rc::Rc::new(1u8)"],
                "Unpin": ["core::marker::PhantomPinned"], "Send + Sync": ["std::rc::Rc::new(1u8)"]}[at]
    isbad = bad(r, 0.12)
    val = r.choice(bad_vals if isbad else good_vals)
    tait = r.random() < 0.3
    feats = []
    items = [fill("fn need<T: @at@>(_: &T) {}", at=at)]
    if tait:
        feats.append("type_alias_impl_trait")
        items.append("pub type Leak = impl Sized;")
        items.append(fill("#[define_opaque(Leak)]\npub fn @f@() -> Leak {\n    @v@\n}", f=f, v=val))
        ret = "Leak"
    else:
        items.append(fill("pub fn @f@() -> impl Sized {\n    @v@\n}", f=f, v=val))
    wrap = r.choice(["x", "(x, 1u8)", "[x]", "Some(x)", "Box::new(x)"])
    items.append(fill("pub fn @g@() {\n    let x = @f@();\n    let y = @w@;\n    need(&y);\n}", g=g, f=f, w=wrap))
    if r.random() < 0.4:
        # leakage through another opaque layer
        items.append(fill("pub fn layer() -> impl Sized {\n    (@f@(), 0u8)\n}\npub fn h() {\n    need(&layer());\n}", f=f))
    if r.random() < 0.3 and not tait:
        # cyclic: query auto trait of own opaque in defining scope of another
        items.append(fill("pub fn cyc(n: u8) -> impl Sized {\n    if n > 0 {\n        need(&@f@());\n    }\n    n\n}", f=f))
    return render(r, feats, items), "2021"


def t_closig(r):
    """closure signature deduction from bounds, supertraits, projections, Box<dyn Fn>"""
    n = Names(r)
    Tr, A, f = n.tr(), n.assoc(), n.fn()
    v = variant(r, ["proj", "super", "boxdyn", "ref_hr", "output_proj", "nested", "bad"])
    items = [fill("pub trait @Tr@ {\n    type @A@;\n}", Tr=Tr, A=A),
             fill("impl @Tr@ for u8 {\n    type @A@ = Vec<u32>;\n}", Tr=Tr, A=A)]
    meth = r.choice(["x.len() as u32", "x.iter().sum::<u32>()", "x.first().copied().unwrap_or(0)"])
    if v in ("proj", "bad"):
        items.append(fill("pub fn @f@<T: @Tr@, F: Fn(<T as @Tr@>::@A@) -> u32>(g: F, a: T::@A@) -> u32 {\n    g(a)\n}", f=f, Tr=Tr, A=A))
        call = fill("@f@::<u8, _>(|x| @m@, vec![1, 2])", f=f, m=meth if v == "proj" else "x.chars().count() as u32")
    elif v == "super":
        M = n.tr()
        items.append(fill("pub trait @M@: Fn(<u8 as @Tr@>::@A@) -> u32 {}\nimpl<F: Fn(Vec<u32>) -> u32> @M@ for F {}", M=M, Tr=Tr, A=A))
        items.append(fill("pub fn @f@<F: @M@>(g: F) -> u32 {\n    g(vec![3])\n}", f=f, M=M))
        call = fill("@f@(|x| @m@)", f=f, m=meth)
    elif v == "boxdyn":
        items.append(fill("pub fn @f@(g: Box<dyn Fn(<u8 as @Tr@>::@A@) -> u32>) -> u32 {\n    g(vec![7])\n}", f=f, Tr=Tr, A=A))
        call = fill("@f@(Box::new(|x| @m@))", f=f, m=meth)
    elif v == "ref_hr":
        items.append(fill("pub fn @f@<F>(g: F) -> u32\nwhere\n    F: for<'a> Fn(&'a <u8 as @Tr@>::@A@) -> &'a u32,\n{\n    *g(&vec![5])\n}", f=f, Tr=Tr, A=A))
        call = fill("@f@(|x| &x[0])", f=f)
    elif v == "output_proj":
        items.append(fill("pub fn @f@<T: @Tr@, F: FnOnce() -> T::@A@>(g: F) -> T::@A@ {\n    g()\n}", f=f, Tr=Tr, A=A))
        call = fill("@f@::<u8, _>(|| Vec::new()).len() as u32", f=f)
    else:
        items.append(fill("pub fn @f@<F, G>(g: F) -> u32\nwhere\n    F: Fn(u32) -> G,\n    G: Fn(<u8 as @Tr@>::@A@) -> u32,\n{\n    g(1)(vec![2])\n}", f=f, Tr=Tr, A=A))
        call = fill("@f@(|k| move |x| x.len() as u32 + k)", f=f)
    st = r.choice(["direct", "let"])
    if st == "direct":
        items.append(fill("pub fn call() -> u32 {\n    @c@\n}", c=call))
    else:
        items.append(fill("pub fn call() -> u32 {\n    let r@ann@ = @c@;\n    r\n}", c=call, ann=r.choice(["", ": u32"])))
    return render(r, [], items), "2021"


def t_clokind(r):
    """closure kind inference and closures returned via impl Fn"""
    n = Names(r)
    f = n.fn()
    v = variant(r, ["fnmut", "fnonce", "ret_fn", "ret_fnmut", "ret_nested", "pass_through", "bad_kind"])
    if v == "fnmut":
        items = [fill("fn call_mut<F: FnMut() -> u32>(mut g: F) -> u32 {\n    g() + g()\n}\npub fn @f@() -> u32 {\n    let mut c = 0u32;\n    let r = call_mut(|| { c += 1; c });\n    r + c\n}", f=f)]
    elif v == "fnonce":
        items = [fill("fn once<F: FnOnce() -> String>(g: F) -> String {\n    g()\n}\npub fn @f@() -> String {\n    let s = String::from(\"x\");\n    once(move || s)\n}", f=f)]
    elif v == "ret_fn":
        k = r.randint(1, 4)
        items = [fill("pub fn adder(n: u32) -> impl Fn(u32) -> u32 + Copy {\n    move |x| x + n\n}", )]
        expr = "x"
        for _ in range(k):
            expr = "adder(%d)(%s)" % (r.randint(0, 9), expr)
        items.append(fill("pub fn @f@(x: u32) -> u32 {\n    @e@\n}", f=f, e=expr))
    elif v == "ret_fnmut":
        items = [fill("pub fn counter() -> impl FnMut() -> u32 {\n    let mut c = 0;\n    move || { c += 1; c }\n}\npub fn @f@() -> u32 {\n    let mut g = counter();\n    g();\n    g()\n}", f=f)]
    elif v == "ret_nested":
        items = [fill("pub fn compose<A, B, C>(f: impl Fn(A) -> B, g: impl Fn(B) -> C) -> impl Fn(A) -> C {\n    move |x| g(f(x))\n}\npub fn @f@() -> u64 {\n    let h = compose(|x: u8| x as u32, |y| y as u64 * 2);\n    h(@a@)\n}", f=f, a=r.randint(0, 9))]
    elif v == "pass_through":
        items = [fill("fn ap<F>(g: F) -> F where F: Fn(&str) -> usize { g }\npub fn @f@() -> usize {\n    let g = ap(|s| s.len());\n    g(\"abc\") + ap(str::len)(\"de\")\n}", f=f)]
    else:
        items = [fill("fn call<F: Fn() -> u32>(g: F) -> u32 {\n    g()\n}\npub fn @f@() -> u32 {\n    let mut c = 0u32;\n    call(|| { c += 1; c })\n}", f=f)]
    return render(r, [], items), "2021"


def t_autocycle(r):
    """auto-trait / Sized / Clone cycles through recursive structs"""
    n = Names(r)
    A, B, f = n.st(), n.st(), n.fn()
    at = r.choice(["Send", "Sync", "Unpin", "Send + Sync", "core::panic::UnwindSafe"])
    ptr = r.choice(["Box<@X@>", "Vec<@X@>", "Option<Box<@X@>>", "std::sync::Arc<@X@>"])
    gen = r.random() < 0.5
    tp = "<T>" if gen else ""
    ta = "<T>" if gen else ""
    payload = "T" if gen else r.choice(["u8", "String", "Vec<u32>"])
    bad_field = bad(r, 0.1)
    items = []
    v = variant(r, ["self", "mutual", "triple"])
    if v == "self":
        items.append(fill("pub struct @A@@tp@ {\n    pub v: @p@,\n    pub next: @ptr@,\n}", A=A, tp=tp, p=payload, ptr=ptr.replace("@X@", A + ta)))
        tys = [A]
    elif v == "mutual":
        items.append(fill("pub struct @A@@tp@ {\n    pub v: @p@,\n    pub b: @ptr@,\n}", A=A, tp=tp, p=payload, ptr=ptr.replace("@X@", B + ta)))
        items.append(fill("pub struct @B@@tp@ {\n    pub a: Vec<@A@@ta@>,\n}", A=A, B=B, tp=tp, ta=ta))
        tys = [A, B]
    else:
        C = n.st()
        items.append(fill("pub struct @A@@tp@ {\n    pub v: @p@,\n    pub b: @ptr@,\n}", A=A, tp=tp, p=payload, ptr=ptr.replace("@X@", B + ta)))
        items.append(fill("pub struct @B@@tp@ {\n    pub c: Option<Box<@C@@ta@>>,\n}", B=B, C=C, tp=tp, ta=ta))
        items.append(fill("pub struct @C@@tp@ {\n    pub a: Vec<@A@@ta@>,\n    pub z: (u8, @B2@),\n}", C=C, A=A, tp=tp, ta=ta, B2="Option<Box<%s%s>>" % (B, ta)))
        tys = [A, B, C]
    if bad_field:
        items[0] = items[0].replace("pub v:", "pub bad: std::rc::Rc<u8>,\n    pub v:", 1)
    items.append(fill("fn need<X: ?Sized + @at@>() {}", at=at))
    if gen:
        conc = r.choice(["u8", "String", "(u32, bool)"])
        calls = "".join("    need::<%s<%s>>();\n" % (t, r.choice(["T", conc])) for t in tys)
        items.append(fill("pub fn @f@<T: @at@>() {\n@c@}", f=f, at=at, c=calls))
    else:
        calls = "".join("    need::<%s>();\n" % t for t in r.sample(tys, len(tys)))
        items.append(fill("pub fn @f@() {\n@c@}", f=f, c=calls))
    if bad_field and "Rc" in items[0] and at in ("Unpin",):
        pass  # Rc is Unpin: stays valid
    return render(r, [], items), "2021"


def t_recimpl(r):
    """recursive impls impl<T: Tr> Tr for Wrap<T>, nested to some depth"""
    n = Names(r)
    Tr, Wr, f = n.tr(), n.st(), n.fn()
    depth = r.randint(1, 12)
    E = r.choice(["u8", "u32", "()", "bool"])
    v = variant(r, ["const", "assoc", "method", "env", "bad"])
    if v == "const":
        items = [fill("pub trait @Tr@ {\n    const N: usize;\n}", Tr=Tr),
                 fill("impl @Tr@ for @E@ {\n    const N: usize = 1;\n}", Tr=Tr, E=E),
                 fill("pub struct @W@<T>(pub T);", W=Wr),
                 fill("impl<T: @Tr@> @Tr@ for @W@<T> {\n    const N: usize = T::N + 1;\n}", Tr=Tr, W=Wr)]
    else:
        items = [fill("pub trait @Tr@ {\n    type Out;\n    fn peel(self) -> Self::Out;\n}", Tr=Tr),
                 fill("impl @Tr@ for @E@ {\n    type Out = @E@;\n    fn peel(self) -> @E@ { self }\n}", Tr=Tr, E=E),
                 fill("pub struct @W@<T>(pub T);", W=Wr),
                 fill("impl<T: @Tr@> @Tr@ for @W@<T> {\n    type Out = T::Out;\n    fn peel(self) -> T::Out { self.0.peel() }\n}", Tr=Tr, W=Wr)]
    nested = E
    for _ in range(depth):
        nested = "%s<%s>" % (Wr, nested)
    if v == "const":
        items.append(fill("pub const K: usize = <@N@ as @Tr@>::N;\npub fn @f@() -> [u8; <@N@ as @Tr@>::N] {\n    [0; @d@]\n}", N=nested, Tr=Tr, f=f, d=depth + 1))
    elif v == "assoc":
        items.append(fill("pub fn @f@(x: <@N@ as @Tr@>::Out) -> @E@ {\n    x\n}", N=nested, Tr=Tr, f=f, E=E))
    elif v == "method":
        val = "Default::default()"
        for _ in range(depth):
            val = "%s(%s)" % (Wr, val)
        items.append(fill("pub fn @f@() -> @E@ {\n    let w: @N@ = @val@;\n    w.peel()\n}", N=nested, f=f, E=E, val=val))
    elif v == "env":
        inner = "T"
        for _ in range(r.randint(1, 6)):
            inner = "%s<%s>" % (Wr, inner)
        items.append(fill("pub fn @f@<T: @Tr@>(x: @I@) -> T::Out {\n    x.peel()\n}\npub fn g(x: @I2@) -> @E@ {\n    @f@(x)\n}", f=f, Tr=Tr, I=inner, I2=inner.replace("T", E), E=E))
    else:
        items.append(fill("pub fn @f@(x: <@N@ as @Tr@>::Out) -> @E@ {\n    x\n}", N=nested.replace(E, "char"), Tr=Tr, f=f, E=E))
    return render(r, [], items), "2021"


def t_mutassoc(r):
    """mutually recursive associated type bounds"""
    n = Names(r)
    A, B, f = n.tr(), n.tr(), n.fn()
    X, Y = n.st(), n.st()
    v = variant(r, ["pair", "pair", "self_ref", "env", "bad"])
    if v in ("pair", "env", "bad"):
        items = [fill("pub trait @A@ {\n    type Other: @B@<Back = Self>;\n    fn to(&self) -> Self::Other;\n}", A=A, B=B),
                 fill("pub trait @B@ {\n    type Back: @A@<Other = Self>;\n    fn back(&self) -> Self::Back;\n}", A=A, B=B),
                 fill("pub struct @X@;\npub struct @Y@;", X=X, Y=Y),
                 fill("impl @A@ for @X@ {\n    type Other = @Y@;\n    fn to(&self) -> @Y@ { @Y@ }\n}", A=A, X=X, Y=Y),
                 fill("impl @B@ for @Y@ {\n    type Back = @X@;\n    fn back(&self) -> @X@ { @X@ }\n}", B=B, X=X, Y=Y)]
        if v == "bad":
            items[-1] = items[-1].replace("type Back = %s;" % X, "type Back = %s;" % Y).replace("fn back(&self) -> %s { %s }" % (X, X), "fn back(&self) -> %s { %s }" % (Y, Y))
        k = r.randint(1, 4)
        chain = "t" + ".to().back()" * k
        if v == "env":
            items.append(fill("pub fn @f@<T: @A@>(t: T) -> T {\n    @c@\n}", f=f, A=A, c=chain))
        else:
            items.append(fill("pub fn @f@<T: @A@>(t: T) -> <<T as @A@>::Other as @B@>::Back {\n    @c@\n}\npub fn g() -> @X@ {\n    @f@(@X@)\n}", f=f, A=A, B=B, c=chain, X=X))
    else:
        items = [fill("pub trait @A@ {\n    type Next: @A@<Next = Self>;\n    fn flip(self) -> Self::Next;\n}", A=A),
                 fill("pub struct @X@(pub u8);\npub struct @Y@(pub u8);", X=X, Y=Y),
                 fill("impl @A@ for @X@ {\n    type Next = @Y@;\n    fn flip(self) -> @Y@ { @Y@(self.0) }\n}", A=A, X=X, Y=Y),
                 fill("impl @A@ for @Y@ {\n    type Next = @X@;\n    fn flip(self) -> @X@ { @X@(self.0 + 1) }\n}", A=A, X=X, Y=Y),
                 fill("pub fn @f@<T: @A@>(t: T) -> T {\n    t@c@\n}", f=f, A=A, c=".flip().flip()" * r.randint(1, 4))]
    return render(r, [], items), "2021"


def t_derefproj(r):
    """autoderef through custom Deref whose Target is a projection"""
    n = Names(r)
    Tr, Wr, A, f = n.tr(), n.st(), n.assoc(), n.fn()
    k = r.randint(1, 3)
    items = [fill("use core::ops::Deref;", ),
             fill("pub trait @Tr@ {\n    type @A@;\n}", Tr=Tr, A=A),
             fill("impl @Tr@ for u8 {\n    type @A@ = Vec<u32>;\n}", Tr=Tr, A=A),
             fill("pub struct @W@<T: @Tr@>(pub T::@A@);", W=Wr, Tr=Tr, A=A),
             fill("impl<T: @Tr@> Deref for @W@<T> {\n    type Target = T::@A@;\n    fn deref(&self) -> &T::@A@ { &self.0 }\n}", W=Wr, Tr=Tr, A=A)]
    tyw = "u8"
    for i in range(k - 1):
        items.append(fill("impl<T: @Tr@> @Tr@ for (T, @i@u8) {\n    type @A@ = @W@<T>;\n}".replace("@i@u8", "[u8; %d]" % (i + 1)), Tr=Tr, A=A, W=Wr))
    # build nested type: W<(..(u8,[u8;1]),[u8;2])>
    t = "u8"
    for i in range(k - 1):
        t = "(%s, [u8; %d])" % (t, i + 1)
    meth = r.choice(["w.len()", "w.iter().count()", "w.first().map_or(0, |x| *x as usize)", "w.capacity().min(0)"])
    v = variant(r, ["concrete", "generic", "bad"])
    if v == "concrete":
        items.append(fill("pub fn @f@(w: &@W@<@t@>) -> usize {\n    @m@\n}", f=f, W=Wr, t=t, m=meth))
    elif v == "generic":
        items.append(fill("pub fn @f@<T: @Tr@>(w: &@W@<T>) -> usize\nwhere\n    T::@A@: Deref<Target = [u32]>,\n{\n    w.len()\n}", f=f, W=Wr, Tr=Tr, A=A))
        if k == 1:
            items.append(fill("pub fn g(w: &@W@<u8>) -> usize {\n    @f@(w)\n}", W=Wr, f=f))
    else:
        items.append(fill("pub fn @f@(w: &@W@<@t@>) -> usize {\n    w.chars().count()\n}", f=f, W=Wr, t=t))
    return render(r, [], items, shuffle=False), "2021"


def t_probeamb(r):
    """method probing: inherent vs trait methods with inference variables"""
    n = Names(r)
    Tr, S, f = n.tr(), n.st(), n.fn()
    m = r.choice(["get", "len", "val", "pick"])
    v = variant(r, ["inh_vs_tr", "generic_recv", "infer_arg", "autoref", "dyn", "bad"])
    if v == "inh_vs_tr":
        items = [fill("pub struct @S@<T>(pub T);", S=S),
                 fill("impl<T> @S@<T> {\n    pub fn @m@(&self) -> u8 { 1 }\n}", S=S, m=m),
                 fill("pub trait @Tr@ {\n    fn @m@(&self) -> u16 { 2 }\n}", Tr=Tr, m=m),
                 fill("impl<T> @Tr@ for @S@<T> {}", Tr=Tr, S=S),
                 fill("pub fn @f@() -> (u8, u16) {\n    let s = @S@(Default::default());\n    let a = s.@m@();\n    let _: &@S@<u32> = &s;\n    (a, @Tr@::@m@(&s))\n}", f=f, S=S, m=m, Tr=Tr)]
    elif v == "generic_recv":
        items = [fill("pub trait @Tr@<X> {\n    fn @m@(&self, x: X) -> X { x }\n}", Tr=Tr, m=m),
                 fill("pub struct @S@;", S=S),
                 fill("impl @Tr@<u32> for @S@ {}", Tr=Tr, S=S),
                 fill("pub fn @f@() -> u32 {\n    let y = @S@.@m@(@a@);\n    y\n}", f=f, S=S, m=m, a=r.choice(["5", "5u32", "Default::default()"]))]
        if r.random() < 0.3:
            items.insert(3, fill("impl @Tr@<&'static str> for @S@ {}", Tr=Tr, S=S))
            items[-1] = items[-1].replace(r.choice(["5", "Default::default()"]) + ")", "5u32)")
    elif v == "infer_arg":
        items = [fill("pub trait @Tr@ {\n    fn @m@(&self) -> u8 { 3 }\n}", Tr=Tr, m=m),
                 fill("impl @Tr@ for Vec<u8> {}", Tr=Tr),
                 fill("pub fn @f@() -> u8 {\n    let mut v = Vec::new();\n    @pre@\n    v.@m@()\n}", f=f, m=m, pre=r.choice(["v.push(1u8);", "v.push(Default::default()); let _: &Vec<u8> = &v;", "v.extend([1u8, 2]);"]))]
    elif v == "autoref":
        items = [fill("pub trait @Tr@ {\n    fn @m@(self) -> u8;\n}", Tr=Tr, m=m),
                 fill("impl @Tr@ for &u32 {\n    fn @m@(self) -> u8 { 1 }\n}", Tr=Tr, m=m),
                 fill("impl @Tr@ for &&u32 {\n    fn @m@(self) -> u8 { 2 }\n}", Tr=Tr, m=m),
                 fill("pub fn @f@(x: u32) -> u8 {\n    let r = &x;\n    x.@m@() + r.@m@() + (&r).@m@()\n}", f=f, m=m)]
    elif v == "dyn":
        items = [fill("pub trait @Tr@ {\n    fn @m@(&self) -> u8;\n}", Tr=Tr, m=m),
                 fill("impl @Tr@ for u8 {\n    fn @m@(&self) -> u8 { *self }\n}", Tr=Tr, m=m),
                 fill("impl dyn @Tr@ {\n    pub fn inh(&self) -> u8 { self.@m@() + 1 }\n}", Tr=Tr, m=m),
                 fill("pub fn @f@(b: Box<dyn @Tr@>) -> u8 {\n    b.inh() + b.@m@()\n}", f=f, Tr=Tr, m=m)]
    else:
        items = [fill("pub trait @Tr@ {\n    fn @m@(&self) -> u8 { 3 }\n}", Tr=Tr, m=m),
                 fill("pub trait Other {\n    fn @m@(&self) -> u8 { 4 }\n}", m=m),
                 fill("impl<T> @Tr@ for T {}\nimpl<T> Other for T {}", Tr=Tr),
                 fill("pub fn @f@() -> u8 {\n    0u8.@m@()\n}", f=f, m=m)]
    return render(r, [], items), "2021"


def t_unsize(r):
    """unsizing to dyn with assoc bindings and trait upcasting"""
    n = Names(r)
    Sup, Sub, A, S, f = n.tr(), n.tr(), n.assoc(), n.st(), n.fn()
    E, ev, _ = ty(r, "copy")
    v = variant(r, ["bind", "upcast", "upcast_bind", "iter", "bad"])
    items = [fill("pub trait @Sup@ {\n    type @A@;\n    fn a(&self) -> Self::@A@;\n}", Sup=Sup, A=A),
             fill("pub trait @Sub@: @Sup@ {\n    fn b(&self) -> u8 { 0 }\n}", Sub=Sub, Sup=Sup),
             fill("pub struct @S@;", S=S),
             fill("impl @Sup@ for @S@ {\n    type @A@ = @E@;\n    fn a(&self) -> @E@ { @ev@ }\n}\nimpl @Sub@ for @S@ {}", Sup=Sup, A=A, S=S, E=E, ev=ev, Sub=Sub)]
    ptr = r.choice(["Box<@D@>", "&'static @D@", "std::rc::Rc<@D@>"])
    mk = {"Box<": "Box::new(%s)" % S, "&'st": "&%s" % S, "std:": "std::rc::Rc::new(%s)" % S}[ptr[:4]]
    if v == "bind":
        D = fill("dyn @Sup@<@A@ = @E@>", Sup=Sup, A=A, E=E)
        items.append(fill("pub fn @f@() -> @E@ {\n    let d: @P@ = @mk@;\n    d.a()\n}", f=f, E=E, P=ptr.replace("@D@", D), mk=mk))
    elif v == "upcast":
        D1 = fill("dyn @Sub@<@A@ = @E@>", Sub=Sub, A=A, E=E)
        D2 = fill("dyn @Sup@<@A@ = @E@>", Sup=Sup, A=A, E=E)
        items.append(fill("pub fn @f@(x: @P1@) -> @P2@ {\n    x\n}", f=f, P1=ptr.replace("@D@", D1), P2=ptr.replace("@D@", D2)))
        items.append(fill("pub fn g() -> @E@ {\n    let x: @P1@ = @mk@;\n    @f@(x).a()\n}", E=E, P1=ptr.replace("@D@", D1), mk=mk, f=f))
    elif v == "upcast_bind":
        D1 = fill("dyn @Sub@<@A@ = @E@> + Send", Sub=Sub, A=A, E=E)
        D2 = fill("dyn @Sup@<@A@ = @E@>", Sup=Sup, A=A, E=E)
        items.append(fill("pub fn @f@(x: &(@D1@)) -> @E@ {\n    let y: &@D2@ = x;\n    y.a()\n}", f=f, D1=D1, D2=D2, E=E))
    elif v == "iter":
        items.append(fill("pub fn @f@(v: &[u32]) -> Box<dyn Iterator<Item = u32> + '_> {\n    Box::new(v.iter().map(|x| x + 1))\n}\npub fn g() -> u32 {\n    let it: &mut dyn Iterator<Item = u32> = &mut @f@(&[1, 2]);\n    it.sum()\n}", f=f))
    else:
        E2 = r.choice([t for t in TYPES if t[0] != E])[0]
        D = fill("dyn @Sup@<@A@ = @E2@>", Sup=Sup, A=A, E2=E2)
        items.append(fill("pub fn @f@() {\n    let _d: Box<@D@> = Box::new(@S@);\n}", f=f, D=D, S=S))
    return render(r, [], items), "2021"


def t_fnptr(r):
    """fn item -> fn pointer coercions with higher-ranked lifetimes, LUB of closures/fn items"""
    n = Names(r)
    f = n.fn()
    v = variant(r, ["hr", "lub_items", "lub_closures", "lub_mixed", "generic_item", "bad"])
    items = [fill("fn first<'a>(x: &'a [u8]) -> &'a u8 { &x[0] }\nfn last<'a>(x: &'a [u8]) -> &'a u8 { &x[x.len() - 1] }")]
    if v == "hr":
        items.append(fill("pub fn @f@() -> u8 {\n    let p: for<'a> fn(&'a [u8]) -> &'a u8 = @fi@;\n    let v = vec![1u8, 2];\n    *p(&v)\n}", f=f, fi=r.choice(["first", "last"])))
    elif v == "lub_items":
        k = r.randint(2, 4)
        arms = "".join("        %d => %s,\n" % (i, r.choice(["first", "last"])) for i in range(k - 1))
        items.append(fill("pub fn @f@(n: u8) -> u8 {\n    let p = match n {\n@arms@        _ => last,\n    };\n    *p(&[1, 2, 3])\n}", f=f, arms=arms))
    elif v == "lub_closures":
        k = r.randint(2, 4)
        arms = "".join("        %d => |x: u32| x + %d,\n" % (i, i) for i in range(k - 1))
        items.append(fill("pub fn @f@(n: u8) -> u32 {\n    let c = match n {\n@arms@        _ => |x| x * 2,\n    };\n    c(@a@)\n}", f=f, arms=arms, a=r.randint(0, 9)))
    elif v == "lub_mixed":
        items.append(fill("fn dbl(x: u32) -> u32 { x * 2 }\npub fn @f@(b: bool) -> u32 {\n    let c = if b { dbl } else { |x| x + 1 };\n    @use@\n}", f=f, use=r.choice(["c(3)", "let p: fn(u32) -> u32 = c;\n    p(4)"])))
    elif v == "generic_item":
        items.append(fill("fn id<T>(x: T) -> T { x }\npub fn @f@() -> u32 {\n    let fs: [fn(u32) -> u32; 2] = [id, id::<u32>];\n    let g: for<'a> fn(&'a u8) -> &'a u8 = id;\n    fs[0](*g(&1u8) as u32)\n}", f=f))
    else:
        items.append(fill("fn st(_: &u8) -> &'static u8 { &0 }\npub fn @f@() {\n    let p: for<'a> fn(&'a u8) -> &'static u8 = first;\n}", f=f).replace("first", "st" if False else "first_u8"))
        items.append("fn first_u8<'a>(x: &'a u8) -> &'a u8 { x }")
    return render(r, [], items), "2021"


def t_infer(r):
    """inference with Into/From/collect/sum/int fallback/? conversions"""
    n = Names(r)
    Tr, f = n.tr(), n.fn()
    v = variant(r, ["into", "from_multi", "collect", "sum", "fallback", "question", "fallback_bad", "into_amb"])
    if v == "into":
        T, _, _ = r.choice(NUMS)
        items = [fill("pub fn @f@(x: u8) -> @T@ {\n    let y@ann@ = x.into();\n    y\n}", f=f, T=T if T != "i32" else "u64", ann=r.choice(["", ": %s" % (T if T != "i32" else "u64")]))]
    elif v == "from_multi":
        S = n.st()
        froms = r.sample(["u8", "bool", "char", "&'static str", "()"], r.randint(2, 4))
        items = [fill("pub struct @S@(pub u32);", S=S)]
        for t in froms:
            items.append(fill("impl From<@t@> for @S@ {\n    fn from(_: @t@) -> Self { @S@(1) }\n}", t=t, S=S))
        val = dict((t[0], t[1]) for t in TYPES)[froms[0]]
        items.append(fill("pub fn @f@() -> u32 {\n    let s: @S@ = @v@.into();\n    let t = @S@::from(@v@);\n    s.0 + t.0\n}", f=f, S=S, v=val))
    elif v == "collect":
        tgt = r.choice(["Vec<u32>", "String", "std::collections::HashSet<u32>", "std::collections::BTreeMap<u32, u32>", "Result<Vec<u32>, ()>", "Option<Vec<u32>>"])
        src = {"Vec<u32>": "(0..5u32).map(|x| x * 2)", "String": "['a', 'b'].iter()",
               "std::collections::HashSet<u32>": "vec![1u32, 2].into_iter()",
               "std::collections::BTreeMap<u32, u32>": "(0..3).map(|x| (x, x))",
               "Result<Vec<u32>, ()>": "(0..3).map(Ok)", "Option<Vec<u32>>": "(0..3).map(Some)"}[tgt]
        if r.random() < 0.5:
            items = [fill("pub fn @f@() -> @t@ {\n    @s@.collect()\n}", f=f, t=tgt, s=src)]
        else:
            items = [fill("pub fn @f@() -> usize {\n    let c = @s@.collect::<@t@>();\n    core::mem::size_of_val(&c)\n}", f=f, t=tgt, s=src)]
    elif v == "sum":
        T = r.choice(["u32", "u64", "i32", "f64"])
        src = r.choice(["[1, 2, 3].iter()", "vec![1, 2].into_iter()", "(1..4)"]) if T != "f64" else "[1.0, 2.5].iter()"
        items = [fill("pub fn @f@() -> @T@ {\n    let s@ann@ = @src@.@op@();\n    s\n}", f=f, T=T, src=src, op=r.choice(["sum", "product"]),
                      ann=": " + T if r.random() < 0.5 else ("" if False else ": " + T))]
        if r.random() < 0.5:
            items = [fill("pub fn @f@() -> @T@ {\n    @src@.@op@::<@T@>()\n}", f=f, T=T, src=src, op=r.choice(["sum", "product"]))]
    elif v in ("fallback", "fallback_bad"):
        impls = r.sample(["i32", "u64", "u8", "i64", "f64", "u32"], r.randint(1, 3))
        if v == "fallback" and "i32" not in impls:
            impls.append("i32")
        if v == "fallback_bad":
            impls = [t for t in impls if t not in ("i32",)] or ["u8", "u16"]
            if len(impls) < 2:
                impls.append("u16" if impls[0] != "u16" else "u8")
        items = [fill("pub trait @Tr@ {\n    fn k(&self) -> u8;\n}", Tr=Tr)]
        for i, t in enumerate(impls):
            items.append(fill("impl @Tr@ for @t@ {\n    fn k(&self) -> u8 { @i@ }\n}", Tr=Tr, t=t, i=i))
        items.append(fill("fn take<T: @Tr@>(x: T) -> u8 {\n    x.k()\n}\npub fn @f@() -> u8 {\n    take(1)@m@\n}", Tr=Tr, f=f, m=r.choice(["", " + take(2 + 3)"])))
    elif v == "question":
        E = n.st()
        items = [fill("#[derive(Debug)]\npub struct @E@;\nimpl From<core::num::ParseIntError> for @E@ {\n    fn from(_: core::num::ParseIntError) -> Self { @E@ }\n}", E=E),
                 fill("impl From<core::str::Utf8Error> for @E@ {\n    fn from(_: core::str::Utf8Error) -> Self { @E@ }\n}", E=E),
                 fill("pub fn @f@(b: &[u8]) -> Result<u32, @E@> {\n    let s = core::str::from_utf8(b)?;\n    let n@ann@ = s.parse()?;\n    Ok(n)\n}", f=f, E=E, ann=r.choice(["", ": u32"]))]
    else:
        S = n.st()
        items = [fill("pub struct @S@;\nimpl From<@S@> for u32 {\n    fn from(_: @S@) -> u32 { 1 }\n}\nimpl From<@S@> for u64 {\n    fn from(_: @S@) -> u64 { 2 }\n}", S=S),
                 fill("fn take(_: u32) {}\npub fn @f@() {\n    let x = @S@.into();\n    take(x);\n}", f=f, S=S)]
    return render(r, [], items), "2021"


def t_defproj(r):
    """Default::default() and other inference through projections"""
    n = Names(r)
    Tr, A, f = n.tr(), n.assoc(), n.fn()
    E, ev, props = ty(r, "def")
    v = variant(r, ["concrete", "generic", "bound", "nested", "bad"])
    items = [fill("pub trait @Tr@ {\n    type @A@@b@;\n}", Tr=Tr, A=A, b=": Default" if v in ("bound", "nested") else "")]
    items.append(fill("impl @Tr@ for u8 {\n    type @A@ = @E@;\n}", Tr=Tr, A=A, E=E))
    if v == "concrete":
        items.append(fill("pub fn @f@() -> @E@ {\n    let x: <u8 as @Tr@>::@A@ = Default::default();\n    x\n}", f=f, E=E, Tr=Tr, A=A))
    elif v == "generic":
        items.append(fill("pub fn @f@<T: @Tr@>() -> T::@A@\nwhere\n    T::@A@: Default,\n{\n    Default::default()\n}\npub fn g() -> @E@ {\n    @f@::<u8>()\n}", f=f, Tr=Tr, A=A, E=E))
    elif v == "bound":
        items.append(fill("pub fn @f@<T: @Tr@>() -> (T::@A@, T::@A@) {\n    let a = <T::@A@>::default();\n    (a, Default::default())\n}", f=f, Tr=Tr, A=A))
    elif v == "nested":
        items.append(fill("impl @Tr@ for (u8,) {\n    type @A@ = Vec<<u8 as @Tr@>::@A@>;\n}", Tr=Tr, A=A))
        items.append(fill("pub fn @f@() -> usize {\n    let v: <(u8,) as @Tr@>::@A@ = Default::default();\n    let mut w = v;\n    w.push(Default::default());\n    w.len()\n}", f=f, Tr=Tr, A=A))
    else:
        items.append(fill("pub fn @f@<T: @Tr@>() -> T::@A@ {\n    Default::default()\n}", f=f, Tr=Tr, A=A))
    return render(r, [], items), "2021"


def t_gat(r):
    """GATs with where-clauses"""
    n = Names(r)
    Tr, S, f = n.tr(), n.st(), n.fn()
    v = variant(r, ["lend", "family", "bound", "hr", "bad"])
    if v in ("lend", "bad"):
        items = [fill("pub trait @Tr@ {\n    type Item<'a>\n    where\n        Self: 'a;\n    fn next<'a>(&'a mut self) -> Option<Self::Item<'a>>;\n}", Tr=Tr),
                 fill("pub struct @S@(pub Vec<u8>, pub usize);", S=S),
                 fill("impl @Tr@ for @S@ {\n    type Item<'a> = &'a mut [u8]\n    where\n        Self: 'a;\n    fn next<'a>(&'a mut self) -> Option<&'a mut [u8]> {\n        let n = self.1;\n        self.1 += 1;\n        self.0.get_mut(n..)\n    }\n}", Tr=Tr, S=S),
                 fill("pub fn @f@<T: @Tr@>(t: &mut T) -> usize\nwhere\n    for<'a> T::Item<'a>: AsRef<[u8]>,\n{\n    let mut c = 0;\n    while let Some(x) = t.next() {\n        c += x.as_ref().len();\n    }\n    c\n}", f=f, Tr=Tr)]
        if v == "bad":
            items[-1] = items[-1].replace("    for<'a> T::Item<'a>: AsRef<[u8]>,\n", "")
        elif r.random() < 0.5:
            items.append(fill("pub fn g() -> usize {\n    @f@(&mut @S@(vec![1, 2], 0))\n}", f=f, S=S))
    elif v == "family":
        items = [fill("pub trait @Tr@ {\n    type Of<T>@wc@;\n    fn wrap<T@b@>(t: T) -> Self::Of<T>;\n}", Tr=Tr, wc=r.choice(["", " where T: Clone"]), b=": Clone"),
                 fill("pub struct @S@;", S=S)]
        wc = " where T: Clone" if "where T: Clone" in items[0] else ""
        items.append(fill("impl @Tr@ for @S@ {\n    type Of<T> = Vec<T>@wc@;\n    fn wrap<T: Clone>(t: T) -> Vec<T> { vec![t.clone(), t] }\n}", Tr=Tr, S=S, wc=wc))
        items.append(fill("pub fn @f@<F: @Tr@>() -> F::Of<u8> {\n    F::wrap(1u8)\n}\npub fn g() -> usize {\n    @f@::<@S@>().len()\n}", f=f, Tr=Tr, S=S))
    elif v == "bound":
        items = [fill("pub trait @Tr@ {\n    type G<'a>: Iterator<Item = &'a u32>\n    where\n        Self: 'a;\n    fn g<'a>(&'a self) -> Self::G<'a>;\n}", Tr=Tr),
                 fill("impl @Tr@ for Vec<u32> {\n    type G<'a> = core::slice::Iter<'a, u32>;\n    fn g<'a>(&'a self) -> Self::G<'a> { self.iter() }\n}", Tr=Tr),
                 fill("pub fn @f@<T: @Tr@>(t: &T) -> u32 {\n    t.g().copied().sum()\n}\npub fn h() -> u32 {\n    @f@(&vec![1, 2])\n}", f=f, Tr=Tr)]
    else:
        items = [fill("pub trait @Tr@ {\n    type R<'a>: Copy where Self: 'a;\n    fn r<'a>(&'a self) -> Self::R<'a>;\n}", Tr=Tr),
                 fill("impl<X: 'static> @Tr@ for Box<X> {\n    type R<'a> = &'a X;\n    fn r<'a>(&'a self) -> &'a X { self }\n}", Tr=Tr),
                 fill("pub fn @f@<T, F>(t: &T, g: F) -> usize\nwhere\n    T: @Tr@,\n    F: for<'a> Fn(T::R<'a>) -> usize,\n{\n    g(t.r()) + g(t.r())\n}\npub fn h() -> usize {\n    @f@(&Box::new(3u8), |x| *x as usize)\n}", f=f, Tr=Tr)]
    return render(r, [], items), "2021"


def t_constlen(r):
    """associated consts in array lengths via projections"""
    n = Names(r)
    Tr, A, S, f = n.tr(), n.assoc(), n.st(), n.fn()
    N = r.randint(0, 8)
    v = variant(r, ["direct", "via_assoc", "nested", "repeat", "bad"])
    items = [fill("pub trait @Tr@ {\n    const N: usize;\n    type @A@;\n}", Tr=Tr, A=A),
             fill("pub struct @S@;", S=S),
             fill("impl @Tr@ for @S@ {\n    const N: usize = @N@;\n    type @A@ = [u8; <@S@ as @Tr@>::N];\n}", Tr=Tr, A=A, S=S, N=N)]
    if v == "direct":
        items.append(fill("pub fn @f@() -> [u32; <@S@ as @Tr@>::N] {\n    [0; @N@]\n}", f=f, S=S, Tr=Tr, N=N))
    elif v == "via_assoc":
        items.append(fill("pub fn @f@(x: <@S@ as @Tr@>::@A@) -> [u8; @N@] {\n    x\n}", f=f, S=S, Tr=Tr, A=A, N=N))
    elif v == "nested":
        items.append(fill("impl @Tr@ for u8 {\n    const N: usize = <@S@ as @Tr@>::N * 2;\n    type @A@ = [<@S@ as @Tr@>::@A@; 2];\n}", Tr=Tr, A=A, S=S))
        items.append(fill("pub fn @f@() -> <u8 as @Tr@>::@A@ {\n    [[0; @N@]; <u8 as @Tr@>::N / @d@]\n}", f=f, Tr=Tr, A=A, N=N, d=max(N, 1)) if N > 0 else
                     fill("pub fn @f@() -> <u8 as @Tr@>::@A@ {\n    [[0; 0]; 2]\n}", f=f, Tr=Tr, A=A))
    elif v == "repeat":
        items.append(fill("pub fn @f@() -> usize {\n    let a = [1u8; <@S@ as @Tr@>::N];\n    let b: <@S@ as @Tr@>::@A@ = a;\n    b.len()\n}", f=f, S=S, Tr=Tr, A=A))
    else:
        items.append(fill("pub fn @f@() -> [u32; <@S@ as @Tr@>::N] {\n    [0; @N@]\n}", f=f, S=S, Tr=Tr, N=N + 1))
    return render(r, [], items), "2021"


def t_dynbind(r):
    """dyn types with assoc bindings: projections normalized from object candidates"""
    n = Names(r)
    Tr, A, f = n.tr(), n.assoc(), n.fn()
    E, ev, _ = ty(r, "copy")
    v = variant(r, ["generic", "proj_in_binding", "multi", "super_binding", "bad"])
    items = [fill("pub trait @Tr@ {\n    type @A@;\n    fn get(&self) -> Self::@A@;\n}", Tr=Tr, A=A)]
    if v == "generic":
        items.append(fill("fn through<T: @Tr@ + ?Sized>(t: &T) -> T::@A@ {\n    t.get()\n}\npub fn @f@(d: &dyn @Tr@<@A@ = @E@>) -> @E@ {\n    through(d)\n}", Tr=Tr, A=A, f=f, E=E))
    elif v == "proj_in_binding":
        Id = n.pick(["Id", "Same"])
        items.append(fill("pub trait @Id@ {\n    type This;\n}\nimpl<T> @Id@ for T {\n    type This = T;\n}", Id=Id))
        items.append(fill("pub fn @f@(d: Box<dyn @Tr@<@A@ = <@E@ as @Id@>::This>>) -> @E@ {\n    d.get()\n}", f=f, Tr=Tr, A=A, E=E, Id=Id))
    elif v == "multi":
        B = n.tr()
        items.append(fill("pub trait @B@: @Tr@ {\n    type Two;\n    fn two(&self) -> Self::Two;\n}", B=B, Tr=Tr))
        items.append(fill("pub fn @f@(d: &dyn @B@<@A@ = @E@, Two = u8>) -> (@E@, u8) {\n    (d.get(), d.two())\n}", f=f, B=B, A=A, E=E))
    elif v == "super_binding":
        B = n.tr()
        items.append(fill("pub trait @B@: @Tr@<@A@ = @E@> {}", B=B, Tr=Tr, A=A, E=E))
        items.append(fill("pub fn @f@(d: &dyn @B@) -> @E@ {\n    let x: <dyn @B@ as @Tr@>::@A@ = d.get();\n    x\n}", f=f, B=B, Tr=Tr, A=A, E=E))
    else:
        E2 = r.choice([t for t in TYPES if t[0] != E])[0]
        items.append(fill("pub fn @f@(d: &dyn @Tr@<@A@ = @E@>) -> @E2@ {\n    d.get()\n}", f=f, Tr=Tr, A=A, E=E, E2=E2))
    if v != "bad" and r.random() < 0.5:
        S = n.st()
        items.append(fill("pub struct @S@;\nimpl @Tr@ for @S@ {\n    type @A@ = @E@;\n    fn get(&self) -> @E@ { @ev@ }\n}", S=S, Tr=Tr, A=A, E=E, ev=ev))
    return render(r, [], items), "2021"


def t_cohproj(r):
    """coherence with projections in impl headers (real and fake overlap)"""
    n = Names(r)
    Tr, Ot, A, f = n.tr(), n.tr(), n.assoc(), n.fn()
    t1, t2 = r.sample(["u8", "u16", "u32", "bool", "char", "String"], 2)
    v = variant(r, ["distinct", "distinct", "generic_disjoint", "overlap", "wrapper", "fundamental"])
    items = [fill("pub trait @Tr@ {\n    type @A@;\n}", Tr=Tr, A=A),
             fill("impl @Tr@ for () {\n    type @A@ = @t1@;\n}", Tr=Tr, A=A, t1=t1),
             fill("pub trait @Ot@ {\n    fn o(&self) -> u8;\n}", Ot=Ot)]
    if v == "distinct":
        items.append(fill("impl @Ot@ for <() as @Tr@>::@A@ {\n    fn o(&self) -> u8 { 1 }\n}\nimpl @Ot@ for @t2@ {\n    fn o(&self) -> u8 { 2 }\n}", Ot=Ot, Tr=Tr, A=A, t2=t2))
    elif v == "overlap":
        items.append(fill("impl @Ot@ for <() as @Tr@>::@A@ {\n    fn o(&self) -> u8 { 1 }\n}\nimpl @Ot@ for @t1@ {\n    fn o(&self) -> u8 { 2 }\n}", Ot=Ot, Tr=Tr, A=A, t1=t1))
    elif v == "generic_disjoint":
        W = n.st()
        items.append(fill("pub struct @W@<T>(pub T);", W=W))
        items.append(fill("impl<T: @Tr@<@A@ = @t1@>> @Ot@ for @W@<T> {\n    fn o(&self) -> u8 { 1 }\n}", Ot=Ot, W=W, Tr=Tr, A=A, t1=t1))
        items.append(fill("impl @Ot@ for @W@<@t2@> {\n    fn o(&self) -> u8 { 2 }\n}", Ot=Ot, W=W, t2=t2))
    elif v == "wrapper":
        W = n.st()
        items.append(fill("pub struct @W@<T>(pub T);", W=W))
        items.append(fill("impl @Ot@ for @W@<<() as @Tr@>::@A@> {\n    fn o(&self) -> u8 { 1 }\n}\nimpl<T: Copy> @Ot@ for @W@<(T, <() as @Tr@>::@A@)> {\n    fn o(&self) -> u8 { 2 }\n}", Ot=Ot, W=W, Tr=Tr, A=A))
    else:
        items.append(fill("impl<T: @Tr@> @Ot@ for Box<T> {\n    fn o(&self) -> u8 { 1 }\n}\nimpl @Ot@ for Box<@t2@> {\n    fn o(&self) -> u8 { 2 }\n}", Ot=Ot, Tr=Tr, t2=t2))
    if v in ("distinct", "overlap"):
        val = dict((t[0], t[1]) for t in TYPES)[t1]
        items.append(fill("pub fn @f@() -> u8 {\n    let x: @t1@ = @val@;\n    x.o()\n}", f=f, t1=t1, val=val))
    return render(r, [], items), "2021"


def t_assocdefault(r):
    """where-bounds on trait methods / impl items, orphaned where-bounds and assoc defaults"""
    n = Names(r)
    Tr, A, S, f = n.tr(), n.assoc(), n.st(), n.fn()
    E, ev, _ = ty(r, "copy")
    v = variant(r, ["method_wc", "orphan", "impl_wc", "self_bound"])
    feats = []
    if v == "method_wc":
        items = [fill("pub trait @Tr@ {\n    type @A@;\n    fn conv(&self) -> u32\n    where\n        Self::@A@: Into<u32>,\n        Self: Sized;\n}", Tr=Tr, A=A),
                 fill("pub struct @S@;", S=S),
                 fill("impl @Tr@ for @S@ {\n    type @A@ = u8;\n    fn conv(&self) -> u32 { 7u8.into() }\n}", Tr=Tr, S=S, A=A),
                 fill("pub fn @f@<T: @Tr@<@A@ = u16>>(t: T) -> u32 {\n    t.conv() + @S@.conv()\n}", f=f, Tr=Tr, A=A, S=S)]
    elif v == "orphan":
        feats.append("associated_type_defaults")
        items = [fill("pub trait @Tr@ {\n    type @A@ = @E@;\n}", Tr=Tr, A=A, E=E),
                 fill("impl<T> @Tr@ for T {}", Tr=Tr),
                 fill("pub fn @f@<T: @Tr@<@A@ = @E@>>(x: <T as @Tr@>::@A@) -> @E@ {\n    x\n}", f=f, Tr=Tr, A=A, E=E),
                 fill("pub fn g() -> @E@ {\n    @f@::<u8>(@ev@)\n}", f=f, E=E, ev=ev)]
    elif v == "impl_wc":
        items = [fill("pub trait @Tr@ {\n    type @A@;\n    fn get(self) -> Self::@A@;\n}", Tr=Tr, A=A),
                 fill("impl<T, U> @Tr@ for (T, U)\nwhere\n    T: Into<U>,\n{\n    type @A@ = U;\n    fn get(self) -> U { self.0.into() }\n}", Tr=Tr, A=A),
                 fill("pub fn @f@(x: u8) -> u64 {\n    @call@\n}", f=f, call=r.choice(["(x, 0u64).get()", "<(u8, u64) as %s>::get((x, 1))" % Tr, "let p: (u8, u64) = (x, 2);\n    p.get()"]))]
    else:
        items = [fill("pub trait @Tr@ {\n    type @A@: @Tr@;\n    fn depth(&self) -> u32 { 0 }\n}", Tr=Tr, A=A),
                 fill("impl @Tr@ for () {\n    type @A@ = ();\n}", Tr=Tr, A=A),
                 fill("pub fn @f@<T: @Tr@>() -> u32\nwhere\n    <<T as @Tr@>::@A@ as @Tr@>::@A@: Default,\n{\n    let x = <<<T as @Tr@>::@A@ as @Tr@>::@A@>::default();\n    x.depth()\n}\npub fn g() -> u32 {\n    @f@::<()>()\n}", f=f, Tr=Tr, A=A)]
    return render(r, feats, items), "2021"


def t_sized(r):
    """?Sized params, Sized builtin vs where-bounds, Box/& wrappers"""
    n = Names(r)
    Tr, f = n.tr(), n.fn()
    v = variant(r, ["unsized_param", "sized_where", "wrapper", "slice_impl", "bad"])
    items = [fill("pub trait @Tr@ {\n    fn sz(&self) -> usize;\n}", Tr=Tr)]
    if v == "unsized_param":
        items.append(fill("impl<T: ?Sized + AsRef<[u8]>> @Tr@ for T {\n    fn sz(&self) -> usize { self.as_ref().len() }\n}", Tr=Tr))
        w = r.choice(["&str", "&[u8]", "Box<[u8]>", "Vec<u8>", "String"])
        items.append(fill("pub fn @f@<T: @Tr@ + ?Sized>(t: &T) -> usize {\n    t.sz()\n}\npub fn g(x: @w@) -> usize {\n    @f@(&x) + @f@(&*x)\n}", f=f, Tr=Tr, w=w))
    elif v == "sized_where":
        items.append(fill("impl<T> @Tr@ for [T] {\n    fn sz(&self) -> usize { self.len() }\n}", Tr=Tr))
        items.append(fill("fn is_sized<T: Sized>(_: &T) {}\npub fn @f@<'a, T: ?Sized>(x: &'a T) -> usize\nwhere\n    &'a T: Sized,\n    (u8, T): @Tr@,\n{\n    is_sized(&x);\n    0\n}", f=f, Tr=Tr))
    elif v == "wrapper":
        S = n.st()
        items.append(fill("pub struct @S@<T: ?Sized>(pub u8, pub T);", S=S))
        items.append(fill("impl<T: ?Sized + @Tr@> @Tr@ for @S@<T> {\n    fn sz(&self) -> usize { self.1.sz() + 1 }\n}\nimpl @Tr@ for [u8] {\n    fn sz(&self) -> usize { self.len() }\n}", S=S, Tr=Tr))
        items.append(fill("pub fn @f@(b: &@S@<[u8; 3]>) -> usize {\n    let u: &@S@<[u8]> = b;\n    u.sz()\n}", f=f, S=S))
    elif v == "slice_impl":
        items.append(fill("impl @Tr@ for str {\n    fn sz(&self) -> usize { self.len() }\n}\nimpl<T: @Tr@ + ?Sized> @Tr@ for &T {\n    fn sz(&self) -> usize { (**self).sz() }\n}\nimpl<T: @Tr@ + ?Sized> @Tr@ for Box<T> {\n    fn sz(&self) -> usize { (**self).sz() }\n}", Tr=Tr))
        items.append(fill("pub fn @f@(s: &str) -> usize {\n    let b: Box<str> = s.into();\n    (&&s).sz() + b.sz() + (&b).sz()\n}", f=f))
    else:
        items.append(fill("pub fn @f@<T: ?Sized>(x: &T) -> T {\n    *x\n}", f=f))
    return render(r, [], items), "2021"


TEMPLATES = [
    ("envimpl", t_envimpl), ("globalwb", t_globalwb), ("regionwb", t_regionwb),
    ("superproj", t_superproj), ("aliasbound", t_aliasbound), ("implhdr", t_implhdrproj),
    ("idproj", t_idproj), ("hrproj", t_hrproj), ("defeq", t_defeq), ("rpit", t_rpit),
    ("tait", t_tait), ("atpit", t_atpit), ("autoleak", t_autoleak), ("closig", t_closig),
    ("clokind", t_clokind), ("autocycle", t_autocycle), ("recimpl", t_recimpl),
    ("mutassoc", t_mutassoc), ("derefproj", t_derefproj), ("probe", t_probeamb),
    ("unsize", t_unsize), ("fnptr", t_fnptr), ("infer", t_infer), ("defproj", t_defproj),
    ("gat", t_gat), ("constlen", t_constlen), ("dynbind", t_dynbind), ("cohproj", t_cohproj),
    ("assocwc", t_assocdefault), ("sized", t_sized),
]


def gen_one(seed, idx):
    r = random.Random(seed)
    name, fn = TEMPLATES[r.randrange(len(TEMPLATES))]
    for _ in range(20):
        src, ed = fn(r)
        if len(src.encode()) <= MAXB:
            break
    return name, src, ed


def main():
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(2)
    count, seed, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
    master = random.Random(seed)
    parts = []
    for i in range(count):
        sub = master.getrandbits(64)
        name, src, ed = gen_one(sub, i)
        parts.append("//# name=sg_%s_%d fam=sg-%s ed=%s\n%s" % (name, i, name, ed, src))
    with open(out, "w") as f:
        f.write("".join(parts))


if __name__ == "__main__":
    main()
