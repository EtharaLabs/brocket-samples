#!/usr/bin/env python3
"""Generate mutants of corpus entries and keep those where both solvers agree on dev.
usage: mkmut.py [per_entry] [seed]"""
import sys, os, json, random, hashlib, time
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import load_corpus, compile_one, HERE, ice_signature
import gen

per = int(sys.argv[1]) if len(sys.argv) > 1 else 10
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 0
info = json.load(open(os.path.join(HERE, "devinfo.json")))
old = json.load(open(gen.MUT_PATH)) if os.path.exists(gen.MUT_PATH) else []
rejected_path = os.path.join(HERE, "tools", "mut_rejected.json")
rejected = set(json.load(open(rejected_path))) if os.path.exists(rejected_path) else set()
seen = set(hashlib.sha1(m["src"].encode()).hexdigest() for m in old) | rejected

cands = []
for e in load_corpus():
    if e["name"] not in info or info[e["name"]]["split"]:
        continue
    rng = random.Random(f"{seed}:{e['name']}")
    for k in range(per):
        ops = [(getattr(gen, o), 1) for o in os.environ["MUT_OPS"].split(",")] if os.environ.get("MUT_OPS") else None
        src = gen.mutate(rng, e["src"], 1 if rng.random() < 0.6 else 2, ops)
        if not src or len(src.encode()) > 1500:
            continue
        h = hashlib.sha1(src.encode()).hexdigest()
        if h in seen:
            continue
        seen.add(h)
        cands.append({"name": f"mu_{h[:10]}", "fam": e["fam"], "parent": e["name"], "ed": e["ed"], "src": src})
print("candidates", len(cands), file=sys.stderr)


def run(c):
    r = {}
    for s in ("old", "next"):
        o, err = compile_one("dev", c["src"], c["ed"], s, 20, emit="link", want_stderr=True)
        r[s] = o
        r[s + "_err"] = err
    if r["old"] == r["next"] and r["old"] != "hang":
        o2 = compile_one("dev", c["src"], c["ed"], "old", 20, emit="metadata")
        n2 = compile_one("dev", c["src"], c["ed"], "next", 20, emit="metadata")
        r["meta_ok"] = (o2, n2) == (r["old"], r["next"])
    return c, r


t = time.time()
kept, nsplit = 0, 0
with ThreadPoolExecutor(16) as ex:
    for c, r in ex.map(run, cands):
        if r["old"] == r["next"] and r["old"] != "hang" and r.get("meta_ok"):
            if r["old"] == "ice":
                rejected.add(hashlib.sha1(c["src"].encode()).hexdigest())
                continue  # an ICE in both solvers on dev is noise
            c["old"], c["next"] = r["old"], r["next"]
            c["k"] = 0 if r["old"] == "accept" else 1
            old.append(c)
            kept += 1
        else:
            nsplit += 1
            rejected.add(hashlib.sha1(c["src"].encode()).hexdigest())
            print("DEVSPLIT", c["name"], c["parent"], r["old"], r["next"],
                  ice_signature(r["old_err"] + r["next_err"]), file=sys.stderr)
print("kept", kept, "dropped", nsplit, "total", len(old), "in", round(time.time() - t), "s", file=sys.stderr)
json.dump(old, open(gen.MUT_PATH, "w"), indent=0)
json.dump(sorted(rejected), open(rejected_path, "w"))
