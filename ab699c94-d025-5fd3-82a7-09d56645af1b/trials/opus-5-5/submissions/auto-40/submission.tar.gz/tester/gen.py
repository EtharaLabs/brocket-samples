"""Seeded program pool beyond the hand-written corpus.

Mutants are error-injected or perturbed variants of corpus entries.  They are
produced by `mutate` (deterministic for a given rng) and prechecked offline by
tools/mkmut.py on the reference toolchain; only the ones where both solvers agree
there are stored in mutants.json.  At runtime the seed decides their order.
"""
import json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
MUT_PATH = os.path.join(HERE, "mutants.json")

KEYWORDS = set("""as async await break const continue crate dyn else enum extern false fn for if impl in
let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where
while yield gen macro_rules union auto default safe""".split())
PRIMS = ["u8", "u32", "i32", "u64", "usize", "bool", "char", "str", "String", "()", "[u8]", "dyn Send",
         "&'static str", "Box<dyn Fn()>", "Vec<u8>", "!", "_"]
IDENT = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*\b")


def _idents(src):
    return [m for m in IDENT.finditer(src) if m.group(0) not in KEYWORDS and not src[:m.start()].endswith("'")]


def _sub_at(src, a, b, rep):
    return src[:a] + rep + src[b:]


def _body_start(src):
    # skip over leading inner attributes so they stay at the top
    m = re.match(r"(\s*#!\[[^\]]*\]\s*)*", src)
    return m.end() if m else 0


def m_undefined_ident(rng, src):
    ids = [m for m in _idents(src) if m.start() >= _body_start(src)]
    if not ids:
        return None
    m = rng.choice(ids)
    return _sub_at(src, m.start(), m.end(), rng.choice(["Missing", "missing", "Missing<u8>"]))


def m_swap_ident(rng, src):
    ids = [m for m in _idents(src) if m.start() >= _body_start(src)]
    names = sorted(set(m.group(0) for m in ids))
    if len(names) < 2:
        return None
    m = rng.choice(ids)
    other = rng.choice([n for n in names if n != m.group(0)])
    return _sub_at(src, m.start(), m.end(), other)


def m_type_replace(rng, src):
    ms = list(re.finditer(r"\b(u8|u16|u32|u64|i32|i64|usize|bool|char|String|str|T|U|Self)\b", src))
    ms = [m for m in ms if m.start() >= _body_start(src)]
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.start(), m.end(), rng.choice(PRIMS))


def m_drop_where(rng, src):
    ms = list(re.finditer(r"\bwhere\b[^{;]*", src))
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.start(), m.end(), " ")


def m_drop_bound(rng, src):
    ms = list(re.finditer(r"(\s*\+\s*|:\s*)(\?Sized|'?[A-Za-z_][A-Za-z0-9_:]*(<[^<>]*>)?)(?=[\s,>{+=])", src))
    ms = [m for m in ms if not src[m.start():m.end()].lstrip().startswith("::")]
    if not ms:
        return None
    m = rng.choice(ms)
    rep = "" if "+" in m.group(1) else ": ?Sized" if rng.random() < 0.3 else ": Sized"
    return _sub_at(src, m.start(), m.end(), rep)


def m_add_bound(rng, src):
    ms = list(re.finditer(r"<([A-Z])\b(?!\s*=)", src))
    if not ms:
        return None
    m = rng.choice(ms)
    b = rng.choice(["?Sized", "Missing", "Iterator<Item = Self>", "Fn() -> Self", "'static", "Copy",
                    "Sized + ?Sized", "Iterator<Item = [u8]>", "Default"])
    return _sub_at(src, m.end(), m.end(), ": " + b)


def m_extra_generic(rng, src):
    ms = list(re.finditer(r"\b([A-Z][A-Za-z0-9_]*)<", src))
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.end(), m.end(), rng.choice(["u8, ", "'_, ", "3, ", "_, "]))


def m_drop_generic(rng, src):
    ms = list(re.finditer(r"<([^<>]{1,40})>", src))
    if not ms:
        return None
    m = rng.choice(ms)
    parts = m.group(1).split(",")
    if len(parts) > 1:
        del parts[rng.randrange(len(parts))]
        return _sub_at(src, m.start(), m.end(), "<" + ",".join(parts) + ">")
    return _sub_at(src, m.start(), m.end(), "")


def m_assoc_value(rng, src):
    ms = list(re.finditer(r"(\btype\s+[A-Za-z_][A-Za-z0-9_]*(<[^>]*>)?\s*)=\s*([^;]+);", src))
    if not ms:
        return None
    m = rng.choice(ms)
    r = rng.random()
    if r < 0.25:
        return _sub_at(src, m.start(), m.end(), m.group(1) + ";")
    v = rng.choice(["[u8]", "Self", "dyn Missing", "<Self as Missing>::A", "Self::Missing", "str",
                    "Box<Self>", "_", "impl Sized", "fn(&u8)", "dyn Fn() -> Self"])
    return _sub_at(src, m.start(), m.end(), m.group(1) + "= " + v + ";")


def m_dup_impl(rng, src):
    ms = list(re.finditer(r"(?m)^\s*impl\b[^\n]*\{", src))
    if not ms:
        return None
    m = rng.choice(ms)
    # find matching brace
    depth, i = 0, m.end() - 1
    while i < len(src):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                break
        i += 1
    block = src[m.start():i + 1]
    if rng.random() < 0.5:
        block = re.sub(r"\bfor\s+([^\s{]+)", lambda x: "for " + rng.choice(["[" + x.group(1) + "]",
                                                                      "&" + x.group(1), "Box<" + x.group(1) + ">",
                                                                      "dyn Missing"]), block, count=1)
    return src[:i + 1] + "\n" + block + src[i + 1:]


def m_drop_line(rng, src):
    lines = src.split("\n")
    idx = [i for i, l in enumerate(lines) if l.strip() and not l.strip().startswith("#![")]
    if not idx:
        return None
    del lines[rng.choice(idx)]
    return "\n".join(lines)


def m_lifetime(rng, src):
    ms = list(re.finditer(r"'([a-z_][a-z0-9_]*)\b(?!')", src))
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.start(), m.end(), rng.choice(["'missing", "'static", "'_"]))


def m_literal(rng, src):
    ms = list(re.finditer(r"\b\d+\b", src))
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.start(), m.end(), rng.choice(["N", "{ N }", "missing()", "()", "Default::default()",
                                                      "todo!()", "0u8", "-1", "\"x\""]))


def m_impl_to_dyn(rng, src):
    ms = list(re.finditer(r"\b(impl|dyn)\s", src))
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.start(), m.end(), ("dyn " if m.group(1) == "impl" else "impl "))


def m_ref_strip(rng, src):
    ms = list(re.finditer(r"&('[a-z_]+\s+)?(mut\s+)?", src))
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.start(), m.end(), rng.choice(["", "*const ", "&mut ", "Box<"[:0]]))


def m_proj_deepen(rng, src):
    ms = list(re.finditer(r"(::[A-Z][A-Za-z0-9_]*|>::[A-Z][A-Za-z0-9_]*)\b(?!\s*[(<{])", src))
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.end(), m.end(), rng.choice(["::Assoc", "::Missing", "::Item", "::Output"]))


def m_expr_hole(rng, src):
    ms = list(re.finditer(r"\blet\s+([a-z_][a-z0-9_]*)\s*(:\s*[^=]+)?=", src))
    if not ms:
        return None
    m = rng.choice(ms)
    return _sub_at(src, m.start(), m.end(), "let " + m.group(1) + ": " + rng.choice(
        ["_", "[_]", "dyn Missing", "impl Sized", "&dyn Fn()", "Missing", "u8"]) + " =")


MIRROR_DEF = "\npub trait MirrorX { type Assoc: ?Sized; }\nimpl<T: ?Sized> MirrorX for T { type Assoc = T; }\n"


def m_mirror(rng, src):
    """Hide a type behind an identity projection: normalization must make this a no-op."""
    ms = [m for m in re.finditer(r"(?<![A-Za-z0-9_:'])(u8|u16|u32|u64|i32|usize|bool|char|String|str|T|U|Self|"
                                 r"Vec<[A-Za-z0-9]+>|\[u8\]|&'a [A-Za-z0-9]+|&[A-Za-z0-9]+)(?![A-Za-z0-9_!])", src)
          if m.start() >= _body_start(src)]
    # not inside `impl X for` headers where an alias would be rejected as self type,
    # and not as the trait name
    ms = [m for m in ms if not re.search(r"\bimpl(<[^>]*>)?\s*$", src[:m.start()])]
    ms = [m for m in ms if not (re.match(r"\s*(:(?!:)|[,>=])", src[m.end():]) and
                                re.search(r"\b(fn|struct|enum|trait|impl|type|union)\s*\w*\s*<[^>]*$", src[:m.start()]))]
    if not ms:
        return None
    m = rng.choice(ms)
    out = _sub_at(src, m.start(), m.end(), "<" + m.group(1) + " as MirrorX>::Assoc")
    if "trait MirrorX" not in out:
        out = out.rstrip("\n") + MIRROR_DEF
    return out


OPS = [(m_mirror, 2), (m_undefined_ident, 3), (m_swap_ident, 3), (m_type_replace, 3), (m_drop_where, 1), (m_drop_bound, 2),
       (m_add_bound, 2), (m_extra_generic, 1), (m_drop_generic, 1), (m_assoc_value, 2), (m_dup_impl, 1),
       (m_drop_line, 2), (m_lifetime, 1), (m_literal, 1), (m_impl_to_dyn, 1), (m_ref_strip, 1),
       (m_proj_deepen, 1), (m_expr_hole, 1)]


def mutate(rng, src, nops=1, ops=None):
    OPS = ops or globals()["OPS"]
    tot = sum(w for _, w in OPS)
    for _ in range(nops):
        for _try in range(8):
            r = rng.uniform(0, tot)
            for op, w in OPS:
                r -= w
                if r <= 0:
                    break
            out = op(rng, src)
            if out and out != src:
                src = out
                break
        else:
            return None
    return src


def pool(rng, devinfo):
    if not os.path.exists(MUT_PATH):
        return []
    items = json.load(open(MUT_PATH))
    out = []
    for it in items:
        out.append({"name": it["name"], "fam": it["fam"], "ed": it["ed"], "fix": None, "prio": -1,
                    "src": it["src"], "origin": "mutant", "parent": it.get("parent"), "dev": (it["old"], it["next"]),
                    "k": it.get("k", 1)})
    rng.shuffle(out)
    return out
