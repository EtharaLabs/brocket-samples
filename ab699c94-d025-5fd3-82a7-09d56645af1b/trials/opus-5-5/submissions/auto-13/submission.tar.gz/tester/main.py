#!/usr/bin/env python3
"""Differential tester for rustc's old and next-generation trait solvers."""
import argparse, json, os, sys, time, random, subprocess, re, threading
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_corpus, compile_one, ice_signature, HERE
import gen

MAX_WITNESSES = 3
MAX_SRC = 1500


def log(*a):
    print("[tester]", *a, file=sys.stderr, flush=True)


def write_report(path, witnesses):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"witnesses": witnesses}, f, indent=1)
    os.replace(tmp, path)


def toolchain_date(tc):
    try:
        out = subprocess.run(["rustc", "+" + tc, "-vV"], capture_output=True, text=True, timeout=60).stdout
        m = re.search(r"commit-date: (\d{4}-\d{2}-\d{2})", out)
        if m:
            return m.group(1)
    except Exception:
        pass
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--toolchain", required=True)
    ap.add_argument("--budget", type=float, required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True)
    ap.add_argument("--jobs", type=int, default=0)
    args = ap.parse_args()

    t0 = time.time()
    budget = args.budget
    # leave headroom for verification and report writing
    hard_deadline = t0 + budget * 0.92 - 3
    scan_deadline = t0 + budget * 0.72 - 3
    write_report(args.out, [])

    tc = args.toolchain
    jobs = args.jobs or max(2, min(32, os.cpu_count() or 4))
    date = toolchain_date(tc)
    log("toolchain", tc, "date", date, "jobs", jobs)

    devinfo = {}
    p = os.path.join(HERE, "devinfo.json")
    if os.path.exists(p):
        devinfo = json.load(open(p))

    cands = []
    for e in load_corpus():
        d = devinfo.get(e["name"])
        if d is None or (d.get("split") and not os.environ.get("DT_DEBUG_ALL")):
            continue  # unverified on the reference compiler, or a by-design difference
        if len(e["src"].encode()) > MAX_SRC:
            continue
        e["dev"] = (d["old"], d["next"])
        e["origin"] = "corpus"
        cands.append(e)
    rng = random.Random(args.seed)
    # interleave corpus files so a scan cut short by the budget still covers every theme
    random.Random(f"corpus:{args.seed}").shuffle(cands)
    extra = gen.pool(rng, devinfo)
    cands.sort(key=lambda e: -e["prio"])
    cands = cands + extra
    log("candidates", len(cands))

    per_timeout = max(5.0, min(25.0, budget / 20.0))
    results = {}
    lock = threading.Lock()

    mut_timeout = max(3.0, min(10.0, budget / 40.0))

    def run_pair(e, emit="link", scanning=False):
        res = {}
        lim = mut_timeout if scanning and e["origin"] != "corpus" else per_timeout
        for s in ("old", "next"):
            left = hard_deadline - time.time()
            if left < 2:
                return None
            res[s] = compile_one(tc, e["src"], e["ed"], s, min(lim, left), emit=emit,
                                 want_stderr=True)
            if scanning and res[s][0] == "hang":
                return {"old": res[s], "next": res[s]}  # hangs are never reported
        return res

    def scan(e):
        if time.time() > scan_deadline:
            return e, None
        return e, run_pair(e, scanning=True)

    done = [None] * len(cands)
    with ThreadPoolExecutor(jobs) as ex:
        futs = {ex.submit(scan, e): i for i, e in enumerate(cands)}
        for fu in as_completed(futs):
            done[futs[fu]] = fu.result()[1]
    # only trust a completed prefix, rounded down so repeated runs see the same set
    k = 0
    while k < len(done) and done[k] is not None:
        k += 1
    if k < len(done):
        k = (k // 200) * 200
    splits = []
    for i in range(k):
        r, e = done[i], cands[i]
        o, n = r["old"][0], r["next"][0]
        if o != n and "hang" not in (o, n):
            e["obs"] = (o, n)
            e["err"] = {"old": r["old"][1], "next": r["next"][1]}
            splits.append(e)
    log("scan done", round(time.time() - t0, 1), "s; scanned", k, "of", len(cands), "splits:", len(splits))

    # verify: rerun full build and a metadata-only build; outcome must be stable
    def verify(e):
        for emit in ("link", "metadata", "link"):
            r = run_pair(e, emit)
            if r is None:
                return e, False
            if (r["old"][0], r["next"][0]) != e["obs"]:
                return e, False
        return e, True

    clusters = cluster(splits, date)
    for key, members in clusters[:10]:
        log("cluster", key, len(members), [m["name"] for m in members[:4]])
    picked = []
    todo = [(ci, e) for ci, (key, members) in enumerate(clusters[:8]) for e in members[:2]]
    ok_by_cluster = {}
    with ThreadPoolExecutor(jobs) as ex:
        for (ci, e), (_, ok) in zip(todo, ex.map(lambda t: verify(t[1]), todo)):
            if ok and ci not in ok_by_cluster:
                ok_by_cluster[ci] = e
    for ci in sorted(ok_by_cluster):
        if len(picked) >= MAX_WITNESSES:
            break
        e = ok_by_cluster[ci]
        e["mech"] = mechanism(clusters[ci][0])
        picked.append(e)
    wit = []
    for e in picked:
        wit.append({
            "id": e["name"],
            "source": e["src"],
            "edition": e["ed"],
            "old": e["obs"][0],
            "next": e["obs"][1],
            "mechanism": e["mech"],
        })
    write_report(args.out, wit)
    log("wrote", len(wit), "witnesses in", round(time.time() - t0, 1), "s")


def fix_score(e, date):
    """Smaller is better: corpus entries annotated with a fix month close after the toolchain date."""
    fx = e.get("fix")
    if not fx or not date:
        return 6.0
    try:
        fy, fm = map(int, fx.split("-")[:2])
        ty, tm = map(int, date.split("-")[:2])
    except Exception:
        return 6.0
    diff = (fy * 12 + fm) - (ty * 12 + tm)
    if diff < -1:
        return 20.0  # fixed before this toolchain: odd, keep but deprioritize
    return max(0.0, diff)


def signature(e):
    for i, s in enumerate(("old", "next")):
        if e["obs"][i] == "ice":
            sig = ice_signature(e["err"][s])
            if sig:
                return s + ":" + sig
    return None


def cluster_key(e):
    sig = signature(e)
    if sig:
        return "ice/" + sig
    # key on how the rejecting solver fails rather than on the corpus family, so one root cause
    # reached from several families still lands in one cluster (one mechanism label per bug)
    o, n = e["obs"]
    side = "next" if n == "reject" else "old" if o == "reject" else None
    code = reject_code(e["err"][side]) if side else "x"
    return "sem/%s-%s/%s-%s" % (side or "na", code, o, n)


def reject_code(err):
    m = re.search(r"^error\[(E\d{4})\]", err, re.M)
    if m:
        return m.group(1)
    m = re.search(r"^error: ([a-z][a-z ]{3,40})", err, re.M)
    if m:
        return re.sub(r"[^a-z]+", "_", m.group(1).strip())[:30]
    return "x"


def mechanism(key):
    if key.startswith("ice/"):
        k = re.sub(r"compiler/|src/|\.rs", "", key[4:])
        return "ice-" + re.sub(r"[^A-Za-z0-9_:/-]+", "-", k)[:80]
    return "sem-" + key.split("/")[1]


def cluster(splits, date):
    """Group splits by likely root cause; widely reproduced causes first."""
    groups = {}
    for e in splits:
        groups.setdefault(cluster_key(e), []).append(e)
    out = []
    for key, mem in groups.items():
        mem.sort(key=lambda e: (e["origin"] != "corpus", fix_score(e, date), -e["prio"], len(e["src"]), e["name"]))
        parents = set(e.get("parent", e["name"]) for e in mem)
        best = mem[0]
        score = (min(fix_score(e, date) for e in mem), -max(e["prio"] for e in mem),
                 -len(parents), not key.startswith("ice/"), best["origin"] != "corpus", key)
        out.append((score, key, mem))
    out.sort(key=lambda x: x[0])
    # one cluster per mechanism label
    res, labels = [], set()
    for _, key, mem in out:
        lab = mechanism(key)
        if lab in labels:
            continue
        labels.add(lab)
        res.append((key, mem))
    return res


if __name__ == "__main__":
    main()
