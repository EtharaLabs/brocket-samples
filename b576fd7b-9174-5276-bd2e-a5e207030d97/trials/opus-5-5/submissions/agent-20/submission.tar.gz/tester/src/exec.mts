import { spawn, fork, type ChildProcess } from "node:child_process";
import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname, delimiter } from "node:path";

export type Outcome = "accept" | "reject" | "crash" | "timeout";
export const OPTIONS = ["--noEmit", "--strict", "--target", "es2022", "--module", "esnext",
  "--moduleResolution", "bundler", "--lib", "es2022", "--pretty", "false"];

export interface RunResult { cls: Outcome; out: string; code: number | null; signal: string | null; }

// `source` is the text of p.ts, or a map of file name to text (all files are passed to the checker).
export function runChecker(tsc: string, source: string | Record<string, string>, timeoutMs = 60000): Promise<RunResult> {
  return new Promise((resolve) => {
    let dir: string;
    try {
      dir = mkdtempSync(join(tmpdir(), "dt-"));
      if (typeof source === "string") writeFileSync(join(dir, "p.ts"), source);
      else for (const [n, t] of Object.entries(source)) writeFileSync(join(dir, n), t);
    } catch (e) {
      resolve({ cls: "crash", out: "infra:" + String(e), code: null, signal: null });
      return;
    }
    const env = { ...process.env, GOMAXPROCS: "2", PATH: dirname(process.execPath) + delimiter + (process.env.PATH ?? "/usr/bin:/bin") };
    let out = "";
    let done = false;
    let timedOut = false;
    const child = spawn(tsc, [...OPTIONS, ...(typeof source === "string" ? ["p.ts"] : Object.keys(source))], { cwd: dir, env, stdio: ["ignore", "pipe", "pipe"], detached: true });
    // kill the whole process group: the launcher may run the checker as a child process
    const timer = setTimeout(() => {
      timedOut = true;
      try { process.kill(-child.pid!, "SIGKILL"); } catch { try { child.kill("SIGKILL"); } catch {} }
    }, timeoutMs);
    const cap = (d: Buffer) => { if (out.length < 8000000) out += d.toString(); };
    child.stdout.on("data", cap);
    child.stderr.on("data", cap);
    const finish = (code: number | null, signal: string | null, err?: unknown) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try { rmSync(dir, { recursive: true, force: true }); } catch {}
      let cls: Outcome;
      if (timedOut) cls = "timeout";
      else if (err) cls = "crash";
      else if (code === 0 && signal === null) cls = "accept";
      else if ((code === 1 || code === 2) && /error TS\d+:/.test(out)) cls = "reject";
      else cls = "crash";
      resolve({ cls, out: err ? "spawn:" + String(err) : out, code, signal });
    };
    child.on("error", (e) => finish(null, null, e));
    child.on("close", (code, signal) => finish(code, signal));
  });
}

export class Pool {
  private active = 0;
  private queue: (() => void)[] = [];
  private size: number;
  constructor(size: number) { this.size = size; }
  async run<T>(fn: () => Promise<T>): Promise<T> {
    if (this.active >= this.size) await new Promise<void>((r) => this.queue.push(r));
    this.active++;
    try { return await fn(); } finally {
      this.active--;
      const n = this.queue.shift();
      if (n) n();
    }
  }
}

// Screening-only runs of the reference compiler through long-lived API worker processes (see
// refworker.mts); falls back to the command line when the package cannot be loaded.
interface Worker { proc: ChildProcess; busy: boolean; }
const workers: Worker[] = [];
let workerBroken = false;
let nextId = 0;
export function refApiAvailable(): boolean { return !workerBroken && !!process.env.DT_WORKER; } // CLI screening by default
export function runRefWorker(tsc: string, source: string | Record<string, string>, timeoutMs: number): Promise<RunResult> {
  if (!refApiAvailable()) return runChecker(tsc, source, timeoutMs);
  return new Promise((resolve) => {
    let dir: string;
    const files = typeof source === "string" ? { "p.ts": source } : source;
    try {
      dir = mkdtempSync(join(tmpdir(), "dt-"));
      for (const [n, t] of Object.entries(files)) writeFileSync(join(dir, n), t);
    } catch (e) {
      resolve({ cls: "crash", out: "infra:" + String(e), code: null, signal: null });
      return;
    }
    let w = workers.find((x) => !x.busy);
    if (!w) {
      const pkg = join(dirname(dirname(tsc)), "typescript");
      const proc = fork(new URL("./refworker.mts", import.meta.url).pathname, [pkg, JSON.stringify(OPTIONS)], { stdio: ["ignore", "ignore", "ignore", "ipc"] });
      w = { proc, busy: false };
      workers.push(w);
      const ww = w;
      proc.on("exit", (code) => { if (code) workerBroken = true; const i = workers.indexOf(ww); if (i >= 0) workers.splice(i, 1); });
      proc.on("error", () => { const i = workers.indexOf(ww); if (i >= 0) workers.splice(i, 1); });
    }
    const worker = w;
    worker.busy = true;
    const id = nextId++;
    let done = false;
    const finish = (r: RunResult) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      worker.proc.off("message", onMsg);
      worker.proc.off("exit", onExit);
      try { rmSync(dir, { recursive: true, force: true }); } catch {}
      resolve(r);
    };
    const onMsg = (m: { id: number; out: string; code: number }) => {
      if (m.id !== id) return;
      worker.busy = false;
      if (m.code === 99 && /^worker:/.test(m.out) && /Cannot find module|ERR_/.test(m.out)) workerBroken = true;
      const cls: Outcome = m.code === 0 ? "accept" : m.code === 2 && /error TS\d+:/.test(m.out) ? "reject" : "crash";
      finish({ cls, out: m.out, code: m.code, signal: null });
    };
    const onExit = () => { finish({ cls: "crash", out: "worker exited", code: null, signal: null }); };
    const timer = setTimeout(() => {
      try { worker.proc.kill("SIGKILL"); } catch {}
      finish({ cls: "timeout", out: "", code: null, signal: "SIGKILL" });
    }, timeoutMs);
    worker.proc.on("message", onMsg);
    worker.proc.on("exit", onExit);
    worker.proc.send({ id, dir, files: Object.keys(files) });
  });
}
export function stopWorkers() { for (const w of workers) try { w.proc.kill("SIGKILL"); } catch {} }
