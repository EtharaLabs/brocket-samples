// Long-lived checker process for screening batches with the reference compiler's API: the standard
// library source files are parsed and bound once and reused across programs. Output mimics the
// command line compiler (`--pretty false`), exit status included.
import { createRequire } from "node:module";
import { join } from "node:path";

const require = createRequire(import.meta.url);
const ts = require(process.argv[2]);
const parsed = ts.parseCommandLine(JSON.parse(process.argv[3]));
const options = parsed.options;
const libCache = new Map<string, unknown>();
process.on("disconnect", () => process.exit(0));

process.on("message", (msg: { id: number; dir: string; files: string[] }) => {
  let out = "", code = 0;
  try {
    const host = ts.createCompilerHost(options);
    const base = host.getSourceFile;
    host.getSourceFile = (fileName: string, lang: unknown, onError: unknown, create: boolean) => {
      if (/[\\/]lib\.[^\\/]*\.d\.ts$/.test(fileName)) {
        let sf = libCache.get(fileName);
        if (!sf) { sf = base.call(host, fileName, lang, onError, create); libCache.set(fileName, sf); }
        return sf;
      }
      return base.call(host, fileName, lang, onError, create);
    };
    host.getCurrentDirectory = () => msg.dir;
    const program = ts.createProgram(msg.files.map((f) => join(msg.dir, f)), options, host);
    const diags: unknown[] = [...program.getConfigFileParsingDiagnostics(), ...program.getSyntacticDiagnostics()];
    if (diags.length === 0) {
      diags.push(...program.getOptionsDiagnostics(), ...program.getGlobalDiagnostics());
      if (diags.length === 0) diags.push(...program.getSemanticDiagnostics());
    }
    const sorted = ts.sortAndDeduplicateDiagnostics(diags);
    const fmtHost = { getCurrentDirectory: () => msg.dir, getCanonicalFileName: (f: string) => f, getNewLine: () => "\n" };
    out = ts.formatDiagnostics(sorted, fmtHost);
    code = sorted.some((d: { category: number }) => d.category === ts.DiagnosticCategory.Error) ? 2 : 0;
  } catch (e) {
    out = "worker:" + String(e && (e as Error).stack || e);
    code = 99;
  }
  process.send!({ id: msg.id, out, code });
});
