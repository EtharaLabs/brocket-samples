import { spawn } from "node:child_process";
import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname, delimiter } from "node:path";

export type Outcome = "accept" | "reject" | "crash" | "timeout";
export const OPTIONS = ["--noEmit", "--strict", "--target", "es2022", "--module", "esnext",
  "--moduleResolution", "bundler", "--lib", "es2022", "--pretty", "false"];

export interface RunResult { cls: Outcome; out: string; code: number | null; signal: string | null; }

export function runChecker(tsc: string, source: string, timeoutMs = 60000): Promise<RunResult> {
  return new Promise((resolve) => {
    let dir: string;
    try {
      dir = mkdtempSync(join(tmpdir(), "dt-"));
      writeFileSync(join(dir, "p.ts"), source);
    } catch (e) {
      resolve({ cls: "crash", out: "infra:" + String(e), code: null, signal: null });
      return;
    }
    const env = { ...process.env, GOMAXPROCS: "2", PATH: dirname(process.execPath) + delimiter + (process.env.PATH ?? "/usr/bin:/bin") };
    let out = "";
    let done = false;
    let timedOut = false;
    const child = spawn(tsc, [...OPTIONS, "p.ts"], { cwd: dir, env, stdio: ["ignore", "pipe", "pipe"], detached: true });
    // kill the whole process group: the launcher may run the checker as a child process
    const timer = setTimeout(() => {
      timedOut = true;
      try { process.kill(-child.pid!, "SIGKILL"); } catch { try { child.kill("SIGKILL"); } catch {} }
    }, timeoutMs);
    const cap = (d: Buffer) => { if (out.length < 8000000) out += d.toString(); };
    child.stdout.on("data", cap);
    child.stderr.on("data", cap);
    const finish = (code: number | null, signal: string | null, err?: unknown) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try { rmSync(dir, { recursive: true, force: true }); } catch {}
      let cls: Outcome;
      if (timedOut) cls = "timeout";
      else if (err) cls = "crash";
      else if (code === 0 && signal === null) cls = "accept";
      else if ((code === 1 || code === 2) && /error TS\d+:/.test(out)) cls = "reject";
      else cls = "crash";
      resolve({ cls, out: err ? "spawn:" + String(err) : out, code, signal });
    };
    child.on("error", (e) => finish(null, null, e));
    child.on("close", (code, signal) => finish(code, signal));
  });
}

export class Pool {
  private active = 0;
  private queue: (() => void)[] = [];
  private size: number;
  constructor(size: number) { this.size = size; }
  async run<T>(fn: () => Promise<T>): Promise<T> {
    if (this.active >= this.size) await new Promise<void>((r) => this.queue.push(r));
    this.active++;
    try { return await fn(); } finally {
      this.active--;
      const n = this.queue.shift();
      if (n) n();
    }
  }
}
