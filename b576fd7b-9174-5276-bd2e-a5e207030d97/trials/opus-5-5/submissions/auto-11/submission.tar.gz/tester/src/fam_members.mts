// Family: structural relations between object types assembled from member lists (optional,
// readonly, index, call/construct signatures, methods, accessors), in declaration, literal,
// heritage and constraint contexts.
import type { Family } from "./family.mts";

// [member text, property name or "" for signatures, literal value text or null]
const MEMS: [string, string, string | null][] = [
  ["", "", null],
  ["a: number", "a", "1"],
  ["a?: number", "a", "1"],
  ["readonly a: number", "a", "1"],
  ["a: string", "a", "\"s\""],
  ["a: number | undefined", "a", "undefined"],
  ["b: string", "b", "\"s\""],
  ["b?: string", "b", "\"s\""],
  ["m(): void", "m", "() => { }"],
  ["m(x: string): void", "m", "(x: string) => { }"],
  ["m?(): void", "m", "() => { }"],
  ["m: (x: \"s\") => void", "m", "(x: \"s\") => { }"],
  ["[k: string]: number", "", null],
  ["[k: string]: unknown", "", null],
  ["(): void", "", null],
  ["c: { d: 1 }", "c", "{ d: 1 }"],
  ["c: { d: 1 | 2 }", "c", "{ d: 2 }"],
  ["c?: never", "c", null],
  ["a: 1", "a", "1"],
  ["e: unknown", "e", "null"],
  ["e?: undefined", "e", "undefined"],
  ["[k: `x${string}`]: string", "", null],
  ["x1: string", "x1", "\"s\""],
];

export const membersFam: Family = {
  name: "member-relation",
  labelOf(k, v) { return /^[st]\d$/.test(k) ? (MEMS[+v][0] || "none") : v; },
  dims: {
    s1: MEMS.map((_, i) => String(i)),
    s2: MEMS.map((_, i) => String(i)),
    t1: MEMS.map((_, i) => String(i)),
    t2: MEMS.map((_, i) => String(i)),
    s3: MEMS.map((_, i) => String(i)),
    ctx: ["assign", "literal", "implements", "extends", "constraint", "satisfies", "generic", "intersection", "union"],
  },
  render(d) {
    const pick = (ks: string[]) => {
      const ms = ks.map((k) => MEMS[+k]).filter((m) => m[0]);
      const names = ms.map((m) => m[1]).filter((n) => n);
      if (new Set(names).size !== names.length) return null;
      if (new Set(ms.map((m) => m[0])).size !== ms.length) return null;
      return ms;
    };
    const S = pick([d.s1, d.s2, d.s3]), T = pick([d.t1, d.t2]);
    if (!S || !T) return null;
    const ty = (ms: typeof S) => `{ ${ms.map((m) => m[0] + ";").join(" ")}${ms.length ? " " : ""}}`;
    const pre = `interface Src ${ty(S)}\ninterface Tgt ${ty(T)}\n`;
    let body: string;
    switch (d.ctx) {
      case "assign": body = "declare const s: Src;\nconst t: Tgt = s;"; break;
      case "literal": {
        if (S.some((m) => m[2] === null && m[1] !== "") || S.some((m) => !m[1])) return null;
        body = `const t: Tgt = { ${S.map((m) => `${m[1]}: ${m[2]}`).join(", ")} };`; break;
      }
      case "implements": if (T.some((m) => !m[1]) || S.some((m) => !m[1])) return null; body = `declare class K implements Tgt { ${S.map((m) => m[0] + ";").join(" ")} }`; break;
      case "extends": body = "interface X extends Tgt, Omit<Src, never> { }\ndeclare const x: X;\nconst t: Tgt = x;"; break;
      case "constraint": body = "declare function f<Q extends Tgt>(q: Q): Q;\ndeclare const s: Src;\nconst r = f(s);"; break;
      case "satisfies": if (S.some((m) => !m[1] || m[2] === null)) return null; body = `const r = { ${S.map((m) => `${m[1]}: ${m[2]}`).join(", ")} } satisfies Tgt;`; break;
      case "generic": body = "function g<P extends Src>(p: P): Tgt {\n  return p;\n}"; break;
      case "intersection": body = "declare const s: Src & { z: 1 };\nconst t: Tgt & { z: 1 } = s;"; break;
      default: body = "declare const s: Src | (Src & { z: 1 });\nconst t: Tgt | { z: 1 } = s;"; break;
    }
    return pre + body + "\n";
  },
};
