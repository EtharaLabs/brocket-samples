// Family: assertion signatures / type guards / never-returning calls resolved through
// various declaration forms and overload sets, consumed by control-flow analysis.
import type { Family } from "./family.mts";

export const assertFam: Family = {
  name: "assertion-signature",
  dims: {
    ovl: ["single", "byTag", "byArg", "mixed", "generic", "genericOverloads", "restTag", "optionalTag"],
    pred: ["is", "truthy", "guard", "never", "thisIs"],
    form: ["declare", "decl", "overloadImpl", "ifaceMethod", "classMethod", "thisMethod", "staticMethod", "namespaceFn",
      "constAnnotated", "constAlias", "callSigIface", "arrowUnannotated", "classMethodNoAnnot", "objLiteralAnnot", "importAlias", "parenCallee", "intersectionCallee",
      "mappedReadonly", "mappedPartialBang", "forOfAsserter", "privateMethod", "superMethod", "thisParamFn", "valueNamespace", "nestedProp",
      "optionalChainCall", "constFnExpr", "typeofAnnot", "letAnnotated", "paramCallee", "destructuredCallee", "genericObjMethod", "unionCallee", "staticThis"],
    sel: ["0", "1"],
    subj: ["param", "prop", "destructured", "elementAccess", "letLocal", "optionalChainProp"],
    pos: ["body", "loop", "loopBefore", "afterBranch", "try", "labeled", "whileTrue", "switchCase", "nestedBlock", "otherCallFirst"],
    wrong: ["no", "yes"],
    pad: ["0", "after3", "before3"],
  },
  render(d) {
    const T = ["string", "number"];
    const sel = +d.sel;
    const truthy = d.pred === "truthy";
    const isThis = d.pred === "thisIs";
    if (isThis && !(d.form === "classMethod" || d.form === "thisMethod" || d.form === "ifaceMethod")) return null;
    if (d.ovl === "byArg" && (d.pred === "never" || truthy)) return null;
    // Return-type text for selection i
    const ret = (i: number, x = "x") => {
      if (d.pred === "never") return i === 0 ? "never" : "void";
      if (d.pred === "guard") return `${x} is ${T[i]}`;
      if (truthy) return `asserts ${x}`;
      if (isThis) return `asserts this is { tag: ${JSON.stringify(T[i])} }`;
      return `asserts ${x} is ${T[i]}`;
    };
    // signatures list (without name), and call args builder
    let sigs: string[] = [];
    let args: string;
    const S = "SUBJ";
    switch (d.ovl) {
      case "single": sigs = [`(x: unknown): ${ret(sel)}`]; args = S; break;
      case "byTag": sigs = [`(x: unknown, t: "s"): ${ret(0)}`, `(x: unknown, t: "n"): ${ret(1)}`]; args = `${S}, ${sel ? '"n"' : '"s"'}`; break;
      case "byArg": sigs = [`(x: string | undefined): ${ret(0)}`, `(x: number | undefined): ${ret(1)}`]; args = S; break;
      case "mixed": sigs = [`(x: unknown, t: "s"): ${ret(0)}`, `(x: unknown, t: "v"): void`]; args = `${S}, ${sel ? '"v"' : '"s"'}`; break;
      case "generic": sigs = [`<T>(x: unknown, sample: T): ${d.pred === "never" ? "never" : d.pred === "guard" ? "x is T" : truthy ? "asserts x" : isThis ? "asserts this is { tag: T }" : "asserts x is T"}`]; args = `${S}, ${sel ? "0" : '""'}`; break;
      case "genericOverloads": sigs = [`<T extends string>(x: unknown, sample: T): ${ret(0)}`, `<T extends number>(x: unknown, sample: T): ${ret(1)}`]; args = `${S}, ${sel ? "0" : '""'}`; break;
      case "restTag": sigs = [`(...a: [x: unknown, t: "s"]): ${ret(0).replace("x is", "a is").replace("asserts x", "asserts a")}`]; if (!/^(never|void)/.test(ret(0)) ) return null; args = `${S}, "s"`; break;
      default: sigs = [`(x: unknown, t?: "s"): ${ret(0)}`, `(x: unknown, t: "n"): ${ret(1)}`]; args = sel ? `${S}, "n"` : S; break;
    }
    if (d.pad !== "0") {
      const pads = [0, 1, 2].map((i) => `(x: symbol, t: "pad${i}", u: symbol): ${i === 1 ? "never" : "void"}`);
      sigs = d.pad === "after3" ? [...sigs, ...pads] : [...pads, ...sigs];
    }
    const inst = (sig: string, name: string) => name + sig;
    let pre = "";
    let callee: string;
    let inClass = false;
    const sigBody = (s: string) => s.replace(/\): ([^;]*)$/, "): $1");
    switch (d.form) {
      case "declare": pre += sigs.map((s) => `declare function check${s};\n`).join(""); callee = "check"; break;
      case "decl": if (sigs.length > 1) return null; pre += `function check${sigs[0]} { ${d.pred === "guard" ? "return true;" : d.pred === "never" && sel === 0 ? "throw 0;" : ""} }\n`; callee = "check"; break;
      case "overloadImpl": pre += sigs.map((s) => `function check${s};\n`).join("") + `function check(...a: any[]): any { }\n`; callee = "check"; break;
      case "ifaceMethod": pre += `interface Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\ndeclare const o: Checker;\n`; callee = "o.check"; break;
      case "classMethod": pre += `declare class Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\nconst c: Checker = new Checker();\n`; callee = "c.check"; break;
      case "classMethodNoAnnot": pre += `declare class Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\nconst c = new Checker();\n`; callee = "c.check"; break;
      case "thisMethod": pre += ""; callee = "this.check"; inClass = true; break;
      case "staticMethod": pre += `declare class Checker {\n${sigs.map((s) => `  static check${s};\n`).join("")}}\n`; callee = "Checker.check"; break;
      case "namespaceFn": pre += `declare namespace NS {\n${sigs.map((s) => `  function check${s};\n`).join("")}}\n`; callee = "NS.check"; break;
      case "constAnnotated": if (sigs.length > 1) return null; pre += `declare const check: ${sigs[0].replace(/\): /, ") => ")};\n`; callee = "check"; break;
      case "constAlias": pre += `type CheckFn = {\n${sigs.map((s) => `  ${s};\n`).join("")}};\ndeclare const check: CheckFn;\n`; callee = "check"; break;
      case "callSigIface": pre += `interface CheckFn {\n${sigs.map((s) => `  ${s};\n`).join("")}}\nconst check: CheckFn = (() => {}) as any;\n`; callee = "check"; break;
      case "arrowUnannotated": if (sigs.length > 1) return null; pre += `const check = ${sigs[0].replace(/\): (.*)$/, "): $1 =>")} { ${d.pred === "guard" ? "return true;" : d.pred === "never" && sel === 0 ? "throw 0;" : ""} };\n`; callee = "check"; break;
      case "objLiteralAnnot": pre += `const o: {\n${sigs.map((s) => `  check${s};\n`).join("")}} = { check: (() => {}) as any };\n`; callee = "o.check"; break;
      case "importAlias": pre += `declare namespace NS {\n${sigs.map((s) => `  function check${s};\n`).join("")}}\nimport check = NS.check;\n`; callee = "check"; break;
      case "parenCallee": pre += sigs.map((s) => `declare function check${s};\n`).join(""); callee = "(check)"; break;
      case "intersectionCallee": pre += `type CheckFn = {\n${sigs.map((s) => `  ${s};\n`).join("")}} & { extra?: number };\ndeclare const check: CheckFn;\n`; callee = "check"; break;
      case "mappedReadonly": pre += `interface Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\ndeclare const o: Readonly<Checker>;\n`; callee = "o.check"; break;
      case "mappedPartialBang": pre += `interface Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\ndeclare const o: Required<Partial<Checker>>;\n`; callee = "o.check"; break;
      case "forOfAsserter": if (sigs.length > 1) return null; pre += `declare const checks: (${sigs[0].replace(/\): /, ") => ")})[];\n`; callee = "chk"; break;
      case "privateMethod": inClass = true; callee = "this.#check"; break;
      case "superMethod": inClass = true; callee = "super.check"; break;
      case "thisParamFn": pre += `interface Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\n`; callee = "this.check"; break;
      case "valueNamespace": pre += `namespace NS {\n${sigs.map((s) => `  export declare function check${s};\n`).join("")}}\n`; callee = "NS.check"; break;
      case "nestedProp": pre += `interface Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\ndeclare const o: { inner: { c: Checker } };\n`; callee = "o.inner.c.check"; break;
      case "optionalChainCall": pre += `interface Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\ndeclare const o: Checker | undefined;\n`; callee = "o?.check"; break;
      case "constFnExpr": if (sigs.length > 1) return null; pre += `const check = function ${sigs[0]} { ${d.pred === "guard" ? "return true;" : d.pred === "never" && sel === 0 ? "throw 0;" : ""} };\n`; callee = "check"; break;
      case "typeofAnnot": pre += sigs.map((s) => `declare function check0${s};\n`).join("") + `declare const check: typeof check0;\n`; callee = "check"; break;
      case "letAnnotated": pre += `type CheckFn = {\n${sigs.map((s) => `  ${s};\n`).join("")}};\ndeclare let check: CheckFn;\n`; callee = "check"; break;
      case "paramCallee": pre += `type CheckFn = {\n${sigs.map((s) => `  ${s};\n`).join("")}};\n`; callee = "check"; break;
      case "destructuredCallee": pre += `type CheckFn = {\n${sigs.map((s) => `  ${s};\n`).join("")}};\ndeclare const box: { check: CheckFn };\nconst { check } = box;\n`; callee = "check"; break;
      case "genericObjMethod": pre += `interface Checker<Q> {\n  q?: Q;\n${sigs.map((s) => `  check${s};\n`).join("")}}\ndeclare const o: Checker<number>;\n`; callee = "o.check"; break;
      case "unionCallee": pre += `interface Checker {\n${sigs.map((s) => `  check${s};\n`).join("")}}\ninterface Checker2 {\n${sigs.map((s) => `  check${s};\n`).join("")}}\ndeclare const o: Checker | Checker2;\n`; callee = "o.check"; break;
      default: pre += `declare class Checker {\n${sigs.map((s) => `  static check${s};\n`).join("")}}\n`; callee = "this.check"; break;
    }
    // subject
    const baseT = d.ovl === "byArg" ? `${T[sel]} | undefined` : truthy ? `${T[sel]} | undefined` : "string | number | boolean";
    let subj = "x", subjDecl = "", subjParam = `x: ${baseT}`;
    switch (d.subj) {
      case "param": break;
      case "prop": subjParam = `o2: { p: ${baseT} }`; subj = "o2.p"; break;
      case "destructured": subjParam = `o2: { p: ${baseT} }`; subjDecl = "const { p } = o2;\n  "; subj = "p"; break;
      case "elementAccess": subjParam = `o2: { p: ${baseT} }`; subj = `o2["p"]`; break;
      case "letLocal": subjParam = `x0: ${baseT}`; subjDecl = "let x = x0;\n  "; break;
      default: subjParam = `o2: { p: ${baseT} } | undefined`; subj = "o2?.p"; break;
    }
    const callArgs = args.replace("SUBJ", isThis ? "null" : subj);
    const call = `${callee}(${callArgs})`;
    const want = d.wrong === "yes" ? T[1 - sel] : T[sel];
    let use: string;
    const useTarget = isThis ? (d.form === "thisMethod" ? "this" : callee.split(".")[0]) : subj;
    if (isThis) use = `const v: { tag: "${want}" } = ${useTarget};`;
    else use = `const v: ${want} = ${subj};`;
    let stmts: string;
    let retType = "void";
    if (d.pred === "never") {
      // reachability: the function must return string on all paths
      retType = "string";
      const end = d.wrong === "yes" ? "\n  return 1 as any as number;" : "";
      if (end && sel === 1) return null;
      use = "";
      stmts = `if (typeof ${subj} === "string") return ${subj};\n  ${call};${d.wrong === "yes" ? "\n  const z: string = 1 as any as number;" : ""}`;
      // for sel 1 (void) the function lacks a return => error expected
    } else if (d.pred === "guard") {
      stmts = `if (${call}) {\n    ${use}\n  }`;
    } else {
      stmts = `${call};\n  ${use}`;
    }
    let body: string;
    switch (d.pos) {
      case "body": body = stmts; break;
      case "loop": body = d.pred === "never" ? `for (let i = 0; i < 1; i++) { }\n  ${stmts}` : `for (let i = 0; i < 2; i++) {\n    ${stmts}\n  }`; break;
      case "loopBefore": body = d.pred === "guard" || d.pred === "never" ? `${stmts}` : `${call};\n  for (let i = 0; i < 2; i++) {\n    ${use}\n  }`; break;
      case "afterBranch": body = d.pred === "guard" || d.pred === "never" ? `if (Math.random()) { } \n  ${stmts}` : `if (Math.random()) { ${call}; } else { ${call}; }\n  ${use}`; break;
      case "try": body = d.pred === "never" ? `try { } finally { }\n  ${stmts}` : `try {\n    ${stmts}\n  } catch { }`; break;
      case "labeled": body = d.pred === "never" ? stmts : `lbl: {\n    ${stmts}\n  }`; break;
      case "whileTrue": body = d.pred === "never" ? stmts : `while (true) {\n    ${stmts}\n    break;\n  }`; break;
      case "switchCase": body = d.pred === "never" ? stmts : `switch (0 as number) { case 0: {\n    ${stmts}\n  } }`; break;
      case "otherCallFirst": {
        if (d.pred === "never" || isThis) return null;
        const swap: Record<string, string> = { '"n"': '"s"', '"s"': '"n"', '"v"': '"s"', '""': "0", "0": '""' };
        const other = args.replace(/"n"|"s"|"v"|""|\b0\b/, (m) => swap[m]).replace("SUBJ", "z");
        const oc = `${callee}(${other})`;
        body = (d.pred === "guard" ? `if (${oc}) { const oz: unknown = z; }` : `${oc};\n  const oz: unknown = z;`) + `\n  ${stmts}`;
        subjParam += ", z: string | number | boolean";
        break;
      }
      default: body = `{\n    ${stmts}\n  }`; break;
    }
    if (d.form === "forOfAsserter") body = `for (const chk of checks) {\n  ${body}\n  }`;
    if (d.form === "privateMethod") {
      if (sigs.length > 1) return null;
      return pre + `class Checker {\n  #check${sigs[0]} { ${d.pred === "guard" ? "return true;" : d.pred === "never" && sel === 0 ? "throw 0;" : ""} }\n  run(${subjParam}): ${retType} {\n  ${subjDecl}${body}\n  }\n}\n`;
    }
    if (inClass) {
      return pre + `declare class Base {\n${sigs.map((s) => `  check${s};\n`).join("")}}\nclass Checker extends Base {\n  run(${subjParam}): ${retType} {\n  ${subjDecl}${body}\n  }\n}\n`;
    }
    if (d.form === "thisParamFn") return pre + `function run(this: Checker, ${subjParam}): ${retType} {\n  ${subjDecl}${body}\n}\n`;
    if (d.form === "paramCallee") return pre + `function run(check: CheckFn, ${subjParam}): ${retType} {\n  ${subjDecl}${body}\n}\n`;
    if (d.form === "staticThis") return pre + `class Sub extends Checker {\n  static run(${subjParam}): ${retType} {\n  ${subjDecl}${body}\n  }\n}\n`;
    return pre + `function run(${subjParam}): ${retType} {\n  ${subjDecl}${body}\n}\n`;
  },
};
