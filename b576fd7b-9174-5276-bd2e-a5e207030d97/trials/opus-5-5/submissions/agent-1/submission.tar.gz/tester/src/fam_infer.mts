// Family: generic inference from arguments and contextual types.
import type { Family } from "./family.mts";

const VALS = ["1", "\"a\"", "true", "{ a: 1 }", "[1, 2]", "() => 1", "null", "undefined", "(Math.random() ? 1 : \"a\")",
  "{ a: \"x\", b: 2 }", "(x: number) => x", "1n", "Symbol()", "{ a: 1, f() { return 1; } }", "[] as string[]"];
const TYPES = ["number", "string", "1", "\"a\"", "number | string", "{ a: number }", "unknown", "never", "number[]",
  "() => number", "boolean", "{}", "object", "string | undefined", "null", "readonly number[]", "[number, number]",
  "{ a: string; b: number }", "(x: number) => number", "\"a\" | 1", "true", "bigint", "symbol", "undefined"];

interface Sc { decl: string; call: (a: string, b: string) => string; }
const SC: Record<string, Sc> = {
  id: { decl: "declare function f<T>(x: T): T;", call: (a) => `f(${a})` },
  arr: { decl: "declare function f<T>(x: T[]): T;", call: (a, b) => `f([${a}, ${b}])` },
  pair: { decl: "declare function f<T>(a: T, b: T): T;", call: (a, b) => `f(${a}, ${b})` },
  thunk: { decl: "declare function f<T>(g: () => T): T;", call: (a) => `f(() => (${a}))` },
  cb: { decl: "declare function f<T>(x: T, g: (t: T) => void): T;", call: (a) => `f(${a}, (t) => { })` },
  cbRet: { decl: "declare function f<T, U>(x: T, g: (t: T) => U): U;", call: (a) => `f(${a}, (t) => t)` },
  cbFirst: { decl: "declare function f<T>(g: (t: T) => void, x: T): T;", call: (a) => `f((t) => { }, ${a})` },
  constT: { decl: "declare function f<const T>(x: T): T;", call: (a) => `f(${a})` },
  constArr: { decl: "declare function f<const T extends readonly unknown[]>(x: T): T[number];", call: (a, b) => `f([${a}, ${b}])` },
  constrained: { decl: "declare function f<T extends string | number>(x: T): T;", call: (a) => `f(${a})` },
  keyof: { decl: "declare function f<T, K extends keyof T>(o: T, k: K): T[K];", call: (a, b) => `f({ a: ${a}, b: ${b} }, "a")` },
  mappedRev: { decl: "declare function f<T>(o: { [K in keyof T]: () => T[K] }): T[keyof T];", call: (a, b) => `f({ a: () => (${a}), b: () => (${b}) })` },
  mappedBox: { decl: "declare function f<T>(o: { [K in keyof T]: { get(): T[K] } }): T[\"a\" & keyof T];", call: (a, b) => `f({ a: { get: () => (${a}) }, b: { get() { return ${b}; } } })` },
  mappedHomo: { decl: "declare function f<T>(o: { readonly [K in keyof T]: T[K] }): T;", call: (a, b) => `f({ a: ${a}, b: ${b} }).a` },
  mappedKeys: { decl: "declare function f<K extends string, V>(o: { [P in K]: V }): V;", call: (a, b) => `f({ a: ${a}, b: ${b} })` },
  record: { decl: "declare function f<K extends PropertyKey, V>(o: Record<K, V>): V;", call: (a, b) => `f({ x: ${a}, y: ${b} })` },
  union: { decl: "declare function f<T>(x: T | undefined): T;", call: (a) => `f(${a})` },
  unionArr: { decl: "declare function f<T>(x: T | T[]): T;", call: (a) => `f(${a})` },
  unionFn: { decl: "declare function f<T>(x: T | (() => T)): T;", call: (a) => `f(${a})` },
  inter: { decl: "declare function f<T>(x: T & {}): T;", call: (a) => `f(${a})` },
  interObj: { decl: "declare function f<T>(x: T & { a: unknown }): T;", call: (a) => `f({ a: ${a} })` },
  cond: { decl: "declare function f<T>(x: T): T extends string ? \"s\" : T extends number ? 1 : T;", call: (a) => `f(${a})` },
  condDist: { decl: "type W<T> = T extends unknown ? { w: T } : never;\ndeclare function f<T>(x: W<T>): T;", call: (a) => `f({ w: ${a} })` },
  inferArr: { decl: "declare function f<T>(x: T): T extends readonly (infer U)[] ? U : never;", call: (a, b) => `f([${a}, ${b}])` },
  inferFn: { decl: "declare function f<T>(x: T): T extends (...a: any[]) => infer R ? R : never;", call: (a) => `f(() => (${a}))` },
  promise: { decl: "declare function f<T>(x: Promise<T> | T): T;", call: (a) => `f(Promise.resolve(${a}))` },
  noInfer: { decl: "declare function f<T>(a: T, b: NoInfer<T>): T;", call: (a, b) => `f(${a}, ${b})` },
  noInferArr: { decl: "declare function f<T>(a: T[], b: NoInfer<T>): T;", call: (a, b) => `f([${a}], ${b})` },
  callableOv: { decl: "declare const ov: { (x: string): number; (x: number): string };\ndeclare function f<A, R>(g: (a: A) => R, x: unknown): A | R;", call: (a) => `f(ov, ${a})` },
  callableObj: { decl: "declare function f<T>(g: { (): T; extra: number }): T;", call: (a) => `f(Object.assign(() => (${a}), { extra: 1 }))` },
  ctxReturn: { decl: "declare function f<T>(): T;", call: () => `f()` },
  ctxReturnArg: { decl: "declare function f<T>(x?: T): T;", call: (a) => `f(${a})` },
  ctxRest: { decl: "declare function f<T>(...xs: T[]): T;", call: (a, b) => `f(${a}, ${b})` },
  partial: { decl: "declare function f<T>(x: Partial<T>): T;", call: (a) => `f({ a: ${a} })` },
  tupleRest: { decl: "declare function f<T extends unknown[]>(...xs: T): T[0];", call: (a, b) => `f(${a}, ${b})` },
  methodObj: { decl: "declare function f<T>(o: { v: T; m(t: T): void }): T;", call: (a) => `f({ v: ${a}, m(t) { } })` },
  makeUse: { decl: "declare function f<T>(o: { make: () => T; use: (t: T) => void }): T;", call: (a) => `f({ make: () => (${a}), use: (t) => { } })` },
  useMake: { decl: "declare function f<T>(o: { use: (t: T) => void; make: () => T }): T;", call: (a) => `f({ use: (t) => { }, make: () => (${a}) })` },
  makeUseMethod: { decl: "declare function f<T>(o: { make(): T; use(t: T): void }): T;", call: (a) => `f({ make() { return ${a}; }, use(t) { } })` },
  readonlyArr: { decl: "declare function f<T>(x: readonly T[]): T;", call: (a, b) => `f([${a}, ${b}] as const)` },
  curried: { decl: "declare function f<T>(x: T): <U>(y: U) => T | U;", call: (a, b) => `f(${a})(${b})` },
  higherOrder: { decl: "declare function idf<X>(x: X): X;\ndeclare function f<A, B>(g: (a: A) => B, a: A): B;", call: (a) => `f(idf, ${a})` },
  pipe: { decl: "declare function f<A, B, C>(ab: (a: A) => B, bc: (b: B) => C): (a: A) => C;", call: (a) => `f((a: number) => [a, ${a}] as const, (b) => b[1])(0)` },
  interSigs: { decl: "declare function f<T>(g: ((x: T) => void) & ((x: string) => void)): T;", call: (a) => `f((x: ${a === "1" ? "number" : "unknown"}) => { })` },
  thisParam: { decl: "declare function f<T>(o: T & ThisType<T>): T;", call: (a) => `f({ v: ${a}, m() { return this.v; } }).v` },
  defaultTP: { decl: "declare function f<T = string>(x?: T): T;", call: (a) => `f(${a})` },
  tplLit: { decl: "declare function f<T extends string>(x: `pre-${T}`): T;", call: () => `f(\"pre-ab\")` },
  arrayFrom: { decl: "", call: (a, b) => `[${a}, ${b}].map((x) => x)[0]` },
  reduce: { decl: "", call: (a, b) => `[${a}].reduce((acc, x) => acc, ${b})` },
  genericClass: { decl: "declare class Box<T> { constructor(x: T); get(): T; }", call: (a) => `new Box(${a}).get()` },
  overloadPick: { decl: "declare function f<T extends string>(x: T): [T];\ndeclare function f<T>(x: T): T;", call: (a) => `f(${a})` },
};

export const inferFam: Family = {
  name: "generic-inference",
  labelOf(k, v) { return k === "a" || k === "b" ? VALS[+v] : k === "e" ? TYPES[+v] : v; },
  dims: {
    sc: Object.keys(SC),
    a: VALS.map((_, i) => String(i)),
    b: VALS.map((_, i) => String(i)),
    e: TYPES.map((_, i) => String(i)),
    ctx: ["none", "annot", "ret", "arg", "satisfies", "arrowRet"],
  },
  render(d) {
    const sc = SC[d.sc];
    const a = VALS[+d.a], b = VALS[+d.b], E = TYPES[+d.e];
    const call = sc.call(a, b);
    let use: string;
    switch (d.ctx) {
      case "none": use = `const r = ${call};\nconst c: ${E} = r;`; break;
      case "annot": use = `const r: ${E} = ${call};`; break;
      case "ret": use = `function g(): ${E} {\n  return ${call};\n}`; break;
      case "arg": use = `declare function take(x: ${E}): void;\ntake(${call});`; break;
      case "satisfies": use = `const r = ${call} satisfies ${E};`; break;
      default: use = `const g: () => ${E} = () => ${call};`; break;
    }
    return (sc.decl ? sc.decl + "\n" : "") + use + "\n";
  },
};
