// Family: higher-order generic calls whose arguments are themselves generic, overloaded or
// contextually typed functions; the resulting function type and its application are observed.
import type { Family } from "./family.mts";

const HOS: Record<string, [string, number]> = {
  pipe2: ["declare function h<A extends any[], B, C>(ab: (...a: A) => B, bc: (b: B) => C): (...a: A) => C;", 2],
  pipe1: ["declare function h<A, B>(ab: (a: A) => B): (a: A) => B;", 1],
  compose: ["declare function h<A, B, C>(bc: (b: B) => C, ab: (a: A) => B): (a: A) => C;", 2],
  apply: ["declare function h<A, R>(f: (a: A) => R): (a: A) => R[];", 1],
  flip: ["declare function h<A, B, R>(f: (a: A, b: B) => R): (b: B, a: A) => R;", 1],
  methodPipe: ["declare const hh: { h<A, B, C>(ab: (a: A) => B, bc: (b: B) => C): (a: A) => C };\nconst h = hh.h;", 2],
  overloadedHo: ["declare function h<A, B>(ab: (a: A) => B): (a: A) => B;\ndeclare function h<A, B, C>(ab: (a: A) => B, bc: (b: B) => C): (a: A) => C;", 2],
  objArg: ["declare function h<A, B, C>(o: { ab: (a: A) => B; bc: (b: B) => C }): (a: A) => C;", -2],
  constrained: ["declare function h<A extends string | number, B>(ab: (a: A) => B): (a: A) => B;", 1],
  restTuple: ["declare function h<A extends unknown[], R>(f: (...a: A) => R): (...a: A) => R;", 1],
  promiseHo: ["declare function h<A, B>(ab: (a: A) => Promise<B>): (a: A) => B;", 1],
  arrayHo: ["declare function h<A, B>(fs: [(a: A) => B]): (a: A) => B;", -1],
};

const FNS: Record<string, string> = {
  list: "declare const F: <T>(a: T) => T[];",
  box: "declare const F: <V>(v: V) => { v: V };",
  id: "declare function F<T>(x: T): T;",
  len: "declare const F: (s: string) => number;",
  first: "declare const F: <T>(xs: readonly T[]) => T;",
  wrapP: "declare const F: <T>(x: T) => Promise<T>;",
  keys: "declare const F: <O extends object>(o: O) => (keyof O)[];",
  str: "declare const F: (n: number) => string;",
  overloaded: "declare const F: { (x: string): 1; (x: number): 2 };",
  pair: "declare const F: <A, B>(a: A, b: B) => [A, B];",
  constr: "declare const F: <T extends string>(x: T) => { s: T };",
  unbox: "declare const F: <T>(b: { v: T }) => T;",
  arrowInline: "(x) => [x]",
  genArrowInline: "<T,>(x: T) => ({ x })",
  annotInline: "(x: number) => ({ n: x })",
  method: "declare const M: { F<T>(x: T): T[] };\nconst F = M.F;",
  thisFn: "declare const F: <T>(this: void, x: T) => [T];",
  optional: "declare const F: <T>(x?: T) => T | undefined;",
};

const ARGVALS = ["1", "\"s\"", "[1, 2]", "{ v: true }", "null"];

export const hoFam: Family = {
  name: "higher-order-generic",
  dims: {
    ho: Object.keys(HOS),
    f1: Object.keys(FNS),
    f2: Object.keys(FNS),
    arg: ARGVALS,
    use: ["call", "annotCall", "noCall", "returned"],
  },
  render(d) {
    const [decl, n] = HOS[d.ho];
    const fns = [d.f1, d.f2].slice(0, Math.abs(n));
    let pre = "";
    const exprs = fns.map((f, i) => {
      const s = FNS[f];
      if (!s.startsWith("declare")) return s;
      pre += s.replace(/\bF\b/g, `F${i}`).replace(/\bM\b/g, `M${i}`) + "\n";
      return `F${i}`;
    });
    const call = n > 0 ? `h(${exprs.join(", ")})` : n === -1 ? `h([${exprs[0]}])` : `h({ ab: ${exprs[0]}, bc: ${exprs[1]} })`;
    const args = d.ho === "flip" ? `${d.arg}, ${d.arg}` : d.arg;
    let body: string;
    switch (d.use) {
      case "call": body = `const r = ${call};\nconst o: unknown = r;\nconst x = r(${args});\nconst ox: unknown = x;`; break;
      case "annotCall": body = `const x = ${call}(${args});\nconst ox: unknown = x;`; break;
      case "noCall": body = `const r = ${call};\nconst o: unknown = r;`; break;
      default: body = `function g() {\n  return ${call};\n}\nconst r = g();\nconst o: unknown = r;`; break;
    }
    return decl + "\n" + pre + body + "\n";
  },
};
