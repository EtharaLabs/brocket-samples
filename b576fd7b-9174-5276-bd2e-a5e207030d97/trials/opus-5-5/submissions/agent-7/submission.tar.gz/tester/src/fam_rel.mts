// Family: assignability between two composed operator chains (concrete or under a type parameter).
import type { Family } from "./family.mts";
import { OPS, LEAVES, PRELUDE, inst } from "./fam_comp.mts";

const opNames = Object.keys(OPS);
const chains = ["", ...opNames, ...opNames.flatMap((a) => ["arr", "obj", "thunk", "cb", "orUndef", "box", "partial"].map((b) => `${a}.${b}`))];

export const relFam: Family = {
  name: "composed-relation",
  dims: {
    src: chains,
    mut: ["same", "dropOuter", "dropInner", "addOuter", "replaceOuter", "swap"],
    mop: opNames,
    leaf: LEAVES.map((_, i) => String(i)),
    leaf2: ["same", ...LEAVES.map((_, i) => String(i))],
    ctx: ["assign", "generic", "genericConstrained", "conditional", "argument", "returnFn", "genericIndexed"],
  },
  labelOf(k, v) { return k.startsWith("leaf") ? (LEAVES[+v]?.[0] ?? v) : v || "T"; },
  render(d) {
    const s = d.src ? d.src.split(".") : [];
    let t = [...s];
    switch (d.mut) {
      case "dropOuter": if (!t.length) return null; t.shift(); break;
      case "dropInner": if (!t.length) return null; t.pop(); break;
      case "addOuter": t.unshift(d.mop); break;
      case "replaceOuter": if (!t.length) return null; t[0] = d.mop; break;
      case "swap": if (t.length < 2) return null; t = [t[1], t[0]]; break;
    }
    const L1 = LEAVES[+d.leaf][0];
    const L2 = d.leaf2 === "same" ? L1 : LEAVES[+d.leaf2][0];
    let body: string;
    switch (d.ctx) {
      case "assign": body = `declare const s: ${inst(s, L1)};\nconst t: ${inst(t, L2)} = s;`; break;
      case "argument": body = `declare const s: ${inst(s, L1)};\ndeclare function take(t: ${inst(t, L2)}): void;\ntake(s);`; break;
      case "conditional": body = `type Chk = [${inst(s, L1)}] extends [${inst(t, L2)}] ? 1 : 0;\nconst z: Chk = 1;`; break;
      case "returnFn": body = `declare const s: ${inst(s, L1)};\nconst fn: () => ${inst(t, L2)} = () => s;`; break;
      case "generic": if (d.leaf2 !== "same") return null; body = `function g<T>(s: ${inst(s, "T")}): ${inst(t, "T")} {\n  return s;\n}`; break;
      case "genericConstrained": body = `function g<T extends ${L1}>(s: ${inst(s, "T")}): ${inst(t, L2)} {\n  return s;\n}`; break;
      default: body = `function g<O extends { k: ${L1} }>(s: ${inst(s, 'O["k"]')}): ${inst(t, L2)} {\n  return s;\n}`; break;
    }
    return PRELUDE + body + "\n";
  },
};
