// Family: inference from declared source types (unions, intersections, callables, mapped shapes)
// into parameter patterns over a type parameter; the inferred result is observed.
import type { Family } from "./family.mts";

// parameter patterns over T
export const PATS: string[] = [
  "T", "T[]", "T | undefined", "T | null | undefined", "T | string", "T | T[]", "T & {}", "T & { a: unknown }",
  "Promise<T> | T", "{ v: T }", "{ v: T } | T", "(() => T) | T", "() => T", "(x: T) => void", "readonly T[]",
  "[T, T]", "{ [K in keyof T]: T[K] }", "Partial<T>", "Record<string, T>", "{ [k: string]: T }", "Map<string, T>",
  "{ v?: T }", "{ (): T }", "{ m(): T }", "{ m(x: T): void }", "Box<T> | T", "T | Box<T>", "NonNullable<T>",
  "{ readonly [K in keyof T]: Box<T[K]> }", "{ k: \"a\"; v: T } | { k: \"b\"; w: T }", "T | (() => void)",
  "Iterable<T>", "ArrayLike<T>", "T | Promise<T> | undefined", "[T] | T[]", "(T & {}) | null",
  "keyof T", "{ [P in T & PropertyKey]: unknown }", "Record<T & string, number>", "{ [K in keyof T as `x_${K & string}`]: T[K] }",
  "Pick<T, keyof T>", "Readonly<T>", "Required<T>", "{ [K in keyof T]?: T[K] }", "{ -readonly [K in keyof T]-?: T[K] }",
  "{ [K in keyof T]: (x: T[K]) => void }", "T extends string ? { s: T } : { o: T }", "[...T[]]", "readonly [T, ...T[]]",
  "{ a: T } & { b: T }", "(x: T) => T", "new () => T", "{ new (): T }", "(...args: T[]) => void",
];

// declared source types
const SRCS: string[] = [
  "string", "string | undefined", "string | null | undefined", "number[] | undefined", "\"a\" | \"b\"",
  "\"a\" | undefined", "string | number", "{ a: 1 } & { b: 2 }", "string & { __brand: 1 }", "(string & {}) | undefined",
  "Promise<string> | string", "Promise<number> | undefined", "(() => 1) | 1", "() => string", "(x: number) => void",
  "{ v: number }", "{ v: number } | number", "{ v?: number }", "{ v: number } | { v: string }", "Box<string>",
  "Box<number> | number", "Box<string> | undefined", "readonly string[]", "[1, \"x\"]", "number[]", "string[] | number[]",
  "Map<string, boolean>", "Record<\"x\" | \"y\", number>", "{ x: 1; y: \"s\" }", "{ (): string; extra: number }",
  "{ m(): number }", "{ m(x: string): void }", "{ m(): 1 } | { m(): 2 }", "{ k: \"a\"; v: number } | { k: \"b\"; w: string }",
  "{ k: \"b\"; w: boolean }", "any", "unknown", "never", "null", "undefined", "Set<number>", "string | (() => void)",
  "number & {}", "object", "{}", "Iterable<string>", "[number] | number[]", "{ a: string } | null",
  "new () => { a: 1 }", "{ new (): string; (): number }", "(x: string) => number", "((x: string) => void) | ((x: number) => void)",
  "((x: string) => void) & ((x: number) => void)", "{ a: number; b: string }", "{ readonly a?: number }", "{ [k: string]: number }",
  "<U>(x: U) => U", "<U>(x: U) => U[]", "{ <U>(x: U): U; extra: 1 }", "<U extends string>(x: U) => { v: U }", "{ m<U>(x: U): U }",
];

const MODS = ["plain", "constT", "extPrim", "extObj", "extUnknownArr", "default"];
const SHAPES = ["one", "twoSame", "twoBare", "bareFirst", "cbObserve", "returnWrap", "noInfer", "explicitCtx", "methodOf", "retCtx", "retCtxArg", "ctxCb"];

export const srcFam: Family = {
  name: "declared-source-inference",
  weight: 1.5,
  labelOf(k, v) { return k === "pat" ? PATS[+v] : k === "s1" || k === "s2" ? SRCS[+v] : v; },
  dims: {
    pat: PATS.map((_, i) => String(i)),
    s1: SRCS.map((_, i) => String(i)),
    shape: SHAPES,
    s2: SRCS.map((_, i) => String(i)),
    mod: MODS,
  },
  render(d) {
    const P = PATS[+d.pat], S1 = SRCS[+d.s1];
    const usesS2 = ["twoSame", "twoBare", "bareFirst", "noInfer", "explicitCtx", "ctxCb"].includes(d.shape);
    const S2 = usesS2 ? SRCS[+d.s2] : SRCS[0];
    let tp = "T";
    switch (d.mod) {
      case "constT": tp = "const T"; break;
      case "extPrim": tp = "T extends string | number | boolean | null | undefined"; break;
      case "extObj": tp = "T extends object"; break;
      case "extUnknownArr": tp = "T extends {} | null | undefined"; break;
      case "default": tp = "T = never"; break;
    }
    let decl: string, call: string, extra = "";
    switch (d.shape) {
      case "one": decl = `declare function f<${tp}>(x: ${P}): T;`; call = "f(s1)"; break;
      case "twoSame": decl = `declare function f<${tp}>(x: ${P}, y: ${P}): T;`; call = "f(s1, s2)"; break;
      case "twoBare": decl = `declare function f<${tp}>(x: ${P}, y: T): T;`; call = "f(s1, s2)"; break;
      case "bareFirst": decl = `declare function f<${tp}>(y: T, x: ${P}): T;`; call = "f(s2, s1)"; break;
      case "cbObserve": decl = `declare function f<${tp}>(x: ${P}, cb: (t: T) => void): T;`; call = "f(s1, (t) => {\n  const o: unknown = t;\n})"; break;
      case "returnWrap": decl = `declare function f<${tp}>(x: ${P}): [T, ${P}];`; call = "f(s1)"; break;
      case "noInfer": decl = `declare function f<${tp}>(x: ${P}, y: NoInfer<T>): T;`; call = "f(s1, s2)"; break;
      case "explicitCtx": decl = `declare function f<${tp}>(x: ${P}): T;`; call = "f(s1)"; extra = "const e: S2 = f(s1);\n"; break;
      case "retCtx": decl = `declare function f<${tp}>(cb: (t: T) => void): ${P};`; call = "f((t) => {\n  const o: unknown = t;\n})"; extra = `const e: S1 = ${call};\n`; break;
      case "retCtxArg": decl = `declare function f<${tp}>(cb: (t: T) => void): ${P};\ndeclare function take(x: S1): void;`; call = "f((t) => {\n  const o: unknown = t;\n})"; extra = `take(${call});\n`; break;
      case "ctxCb": decl = `declare function f<${tp}>(x: ${P}, cb: (t: T) => void): T;`; call = "f(s1, (t) => {\n  const o: unknown = t;\n})"; extra = `const e: S2 = ${call};\n`; break;
      default: decl = `declare const o: { f<${tp}>(x: ${P}): T };`; call = "o.f(s1)"; break;
    }
    return "interface Box<X> { v: X }\n" + `type S1 = ${S1};\ntype S2 = ${S2};\ndeclare const s1: S1;\ndeclare const s2: S2;\n${decl}\n` +
      `${extra}const r = ${call};\nconst c: unknown = r;\n`;
  },
};
