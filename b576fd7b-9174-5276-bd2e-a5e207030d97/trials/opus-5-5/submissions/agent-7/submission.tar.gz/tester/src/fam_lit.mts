// Family: inference from argument expressions (object/array literals, methods, ternaries, spreads,
// const contexts) into parameter patterns; the inferred result is observed.
import type { Family } from "./family.mts";
import { PATS } from "./fam_src.mts";

const EXPRS: string[] = [
  "{ a: 1, b: \"x\" }",
  "[1, \"x\"]",
  "[1, 2] as const",
  "Math.random() ? 1 : \"x\"",
  "Math.random() ? { a: 1 } : { b: \"x\" }",
  "{ m() { return 1; } }",
  "{ v: 1, w: [true] }",
  "() => 1",
  "(x: number) => x",
  "{ ...{ a: 1 }, b: 2 }",
  "[...[1, 2], \"x\"]",
  "`a${1}`",
  "{ a: 1 } satisfies { a: number }",
  "{ k: \"a\", v: 1 }",
  "[{ k: \"a\" }, { k: \"b\", x: 1 }]",
  "{ v: { v: 1 } }",
  "new Map([[\"k\", 1]])",
  "Promise.resolve(1)",
  "null",
  "undefined",
  "{}",
  "[]",
  "{ a: undefined }",
  "{ get g() { return 1; }, set g(_v: number) { } }",
  "function () { return \"s\"; }",
  "{ f: (x: string) => x.length }",
  "[() => 1, () => \"x\"]",
  "Math.random() ? [1] : undefined",
  "{ [\"c\" + \"d\"]: 1 }",
  "{ 0: \"x\", 1: 2 }",
];

export const litFam: Family = {
  name: "literal-argument-inference",
  labelOf(k, v) { return k === "pat" ? PATS[+v] : k === "e1" || k === "e2" ? EXPRS[+v] : v; },
  dims: {
    pat: PATS.map((_, i) => String(i)),
    e1: EXPRS.map((_, i) => String(i)),
    shape: ["one", "two", "withCb", "objWrap", "annotRet", "method", "spreadArgs"],
    e2: EXPRS.map((_, i) => String(i)),
    mod: ["plain", "constT", "extPrim", "extObj", "extUnknown"],
  },
  render(d) {
    const P = PATS[+d.pat], E1 = EXPRS[+d.e1], E2 = EXPRS[+d.e2];
    let tp = "T";
    switch (d.mod) {
      case "constT": tp = "const T"; break;
      case "extPrim": tp = "T extends string | number | boolean | null | undefined"; break;
      case "extObj": tp = "T extends object"; break;
      case "extUnknown": tp = "T extends unknown"; break;
    }
    let decl: string, call: string, extra = "";
    switch (d.shape) {
      case "one": decl = `declare function f<${tp}>(x: ${P}): T;`; call = `f(${E1})`; break;
      case "two": decl = `declare function f<${tp}>(x: ${P}, y: ${P}): T;`; call = `f(${E1}, ${E2})`; break;
      case "withCb": decl = `declare function f<${tp}>(x: ${P}, cb: (t: T) => void): T;`; call = `f(${E1}, (t) => {\n  const o: unknown = t;\n})`; break;
      case "objWrap": decl = `declare function f<${tp}>(o: { x: ${P} }): T;`; call = `f({ x: ${E1} })`; break;
      case "annotRet": decl = `declare function f<${tp}>(x: ${P}): ${P};`; call = `f(${E1})`; extra = `const e: typeof s = f(${E1});\ndeclare const s: ${P.replace(/\bT\b/g, "number")};\n`; break;
      case "method": decl = `declare const ob: { f<${tp}>(x: ${P}): T };`; call = `ob.f(${E1})`; break;
      default: decl = `declare function f<${tp}>(...xs: (${P})[]): T;`; call = `f(${E1}, ${E2})`; break;
    }
    return "interface Box<X> { v: X }\n" + `${decl}\n${extra}const r = ${call};\nconst c: unknown = r;\n`;
  },
};
