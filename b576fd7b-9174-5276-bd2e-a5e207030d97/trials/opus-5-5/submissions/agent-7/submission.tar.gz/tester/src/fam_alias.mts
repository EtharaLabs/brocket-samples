// Family: narrowing a union-typed reference through an alias of its discriminant
// (const k = obj.kind / const { kind } = obj / aliased condition), then reading another property.
import type { Family } from "./family.mts";

export const aliasFam: Family = {
  name: "discriminant-alias",
  dims: {
    alias: ["destructure", "rename", "propAlias", "elemAlias", "withDefault", "annotatedPattern", "annotatedAlias", "letDestructure",
      "letAlias", "restSibling", "condAlias", "condAliasDestr", "nestedPattern", "computedKey", "arrayPattern", "twoStep"],
    obj: ["param", "constLocal", "propAccess", "thisProp", "elemAccess", "callResult", "letLocal", "reassignedParam", "genericParam", "optionalProp", "nonNull"],
    dk: ["str", "num", "bool", "undef", "enum"],
    check: ["ifEq", "neqReturn", "switch", "else", "ternary", "andAnd", "notNot", "inCallback"],
    use: ["readProp", "destructureAfter", "passObj", "methodCall"],
    wrong: ["no", "yes"],
  },
  render(d) {
    let pre = "";
    let kv: string[];
    switch (d.dk) {
      case "str": kv = ["\"a\"", "\"b\""]; break;
      case "num": kv = ["1", "2"]; break;
      case "bool": kv = ["true", "false"]; break;
      case "undef": kv = ["\"a\"", "undefined"]; break;
      default: pre += "enum K { A, B }\n"; kv = ["K.A", "K.B"]; break;
    }
    const tuple = d.alias === "arrayPattern";
    const U = tuple ? `[${kv[0]}, number] | [${kv[1]}, string]` : `{ kind: ${kv[0]}; payload: number; m0(): 0 } | { kind: ${kv[1]}; payload: string; m1(): 1 }`;
    pre += `type U = ${U};\n`;
    let sig = "", head = "", O = "obj", cls = false, gen = "";
    switch (d.obj) {
      case "param": sig = "obj: U"; break;
      case "constLocal": sig = "o0: U"; head = "const obj = o0;\n  "; break;
      case "propAccess": sig = "h: { obj: U }"; O = "h.obj"; break;
      case "thisProp": cls = true; O = "this.obj"; break;
      case "elemAccess": sig = "h: { obj: U }"; O = "h[\"obj\"]"; break;
      case "callResult": pre += "declare function get(): U;\n"; O = "get()"; break;
      case "letLocal": sig = "o0: U"; head = "let obj = o0;\n  "; break;
      case "reassignedParam": sig = "obj: U"; head = "if (Math.random()) obj = { ...obj };\n  "; if (tuple) return null; break;
      case "genericParam": gen = "<T extends U>"; sig = "obj: T"; break;
      case "optionalProp": sig = "h: { obj?: U }"; O = "h.obj!"; break;
      default: sig = "obj: U | undefined"; O = "obj!"; break;
    }
    const k0 = kv[0];
    const want = d.wrong === "yes" ? "string" : "number";
    let decl: string, K = "k";
    switch (d.alias) {
      case "destructure": decl = `const { kind } = ${O};`; K = "kind"; break;
      case "rename": decl = `const { kind: k } = ${O};`; break;
      case "propAlias": decl = `const k = ${O}.kind;`; break;
      case "elemAlias": decl = `const k = ${O}["kind"];`; break;
      case "withDefault": decl = `const { kind: k = ${k0} } = ${O};`; break;
      case "annotatedPattern": decl = `const { kind: k }: U = ${O};`; break;
      case "annotatedAlias": decl = `const k: U["kind"] = ${O}.kind;`; break;
      case "letDestructure": decl = `let { kind: k } = ${O};`; break;
      case "letAlias": decl = `let k = ${O}.kind;`; break;
      case "restSibling": decl = `const { kind: k, ...rest } = ${O};`; break;
      case "condAlias": decl = `const isA = ${O}.kind === ${k0};`; K = ""; break;
      case "condAliasDestr": decl = `const { kind: k } = ${O};\n  const isA = k === ${k0};`; K = ""; break;
      case "nestedPattern": decl = `const { o: { kind: k } } = { o: ${O} };`; break;
      case "computedKey": decl = `const { ["kind"]: k } = ${O};`; break;
      case "arrayPattern": decl = `const [k] = ${O};`; break;
      default: decl = `const { kind: k0 } = ${O};\n  const k = k0;`; break;
    }
    const P = tuple ? `${O}[1]` : `${O}.payload`;
    let use: string;
    switch (d.use) {
      case "readProp": use = `const v: ${want} = ${P};`; break;
      case "destructureAfter": use = tuple ? `const [, p] = ${O};\n    const v: ${want} = p;` : `const { payload: p } = ${O};\n    const v: ${want} = p;`; break;
      case "passObj": use = tuple ? `const v: [${d.wrong === "yes" ? kv[1] : k0}, ${want}] = ${O};` : `const v: Extract<U, { payload: ${want} }> = ${O};`; break;
      default: if (tuple) return null; use = d.wrong === "yes" ? `${O}.m1();` : `${O}.m0();`; break;
    }
    const test = K ? `${K} === ${k0}` : "isA";
    const ntest = K ? `${K} !== ${k0}` : "!isA";
    let body: string;
    switch (d.check) {
      case "ifEq": body = `if (${test}) {\n    ${use}\n  }`; break;
      case "neqReturn": body = `if (${ntest}) return;\n  ${use}`; break;
      case "switch": if (!K) return null; body = `switch (${K}) {\n    case ${k0}: {\n    ${use}\n    }\n  }`; break;
      case "else": body = `if (${ntest}) { } else {\n    ${use}\n  }`; break;
      case "ternary": body = `const r = ${test} ? (() => {\n    ${use}\n  }) : 0;`; break;
      case "andAnd": body = `if (Math.random() && ${test}) {\n    ${use}\n  }`; break;
      case "notNot": body = `if (!!(${test})) {\n    ${use}\n  }`; break;
      default: body = `if (${test}) {\n    [0].forEach(() => {\n    ${use}\n    });\n  }`; break;
    }
    if (cls) return pre + `class C {\n  constructor(readonly obj: U) { }\n  run() {\n  ${decl}\n  ${body}\n  }\n}\n`;
    return pre + `function f${gen}(${sig}) {\n  ${head}${decl}\n  ${body}\n}\n`;
  },
};
