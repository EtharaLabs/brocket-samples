// Family: flow-sensitive types of mutable locals inside loops, where the assigned values come
// from calls whose signature (overloads, generics, assertions, guards) depends on the flow type.
import type { Family } from "./family.mts";

const CALLEES: Record<string, { decl: string; kind: "value" | "assert" | "guard" | "never" }> = {
  ovSwap: { decl: "declare function f(x: string): number;\ndeclare function f(x: number): string;", kind: "value" },
  ovWiden: { decl: "declare function f(x: number): number;\ndeclare function f(x: string | number): string;", kind: "value" },
  ovUndef: { decl: "declare function f(x: undefined): number;\ndeclare function f(x: number): number | undefined;", kind: "value" },
  generic: { decl: "declare function f<T>(x: T): T;", kind: "value" },
  genericArr: { decl: "declare function f<T>(x: T): T[];", kind: "value" },
  genericUnwrap: { decl: "declare function f<T>(x: T | T[]): T;", kind: "value" },
  genericNonNull: { decl: "declare function f<T>(x: T): NonNullable<T> | number;", kind: "value" },
  plain: { decl: "declare function f(x: unknown): string | number;", kind: "value" },
  assertStr: { decl: "declare function f(x: unknown): asserts x is string;", kind: "assert" },
  assertOv: { decl: "declare function f(x: string | undefined): asserts x is string;\ndeclare function f(x: number | undefined): asserts x is number;", kind: "assert" },
  assertGeneric: { decl: "declare function f<T>(x: T): asserts x is NonNullable<T>;", kind: "assert" },
  assertMixedOv: { decl: "declare function f(x: number): void;\ndeclare function f(x: unknown): asserts x is string;", kind: "assert" },
  guardStr: { decl: "declare function f(x: unknown): x is string;", kind: "guard" },
  guardOv: { decl: "declare function f(x: string | number): x is string;\ndeclare function f(x: unknown): x is number;", kind: "guard" },
  guardGeneric: { decl: "declare function f<T>(x: T | undefined): x is T;", kind: "guard" },
  neverOv: { decl: "declare function f(x: string): never;\ndeclare function f(x: number): number;", kind: "never" },
  neverGeneric: { decl: "declare function f<T extends string>(x: T): never;", kind: "never" },
};

export const loopFam: Family = {
  name: "loop-flow-call",
  dims: {
    callee: Object.keys(CALLEES),
    decl: ["annotated", "auto", "autoInit", "inferredInit", "constCopy", "param"],
    init: ["num", "str", "undef", "union"],
    loop: ["for", "while", "doWhile", "forOf", "nested", "labeledContinue", "forIn", "whileTrueBreak", "none"],
    shape: ["assignCall", "callThenAssign", "tempConst", "condAssign", "compound", "destructAssign", "nullishAssign", "callInCond", "twoVars", "closureRead"],
    use: ["afterLoop", "inLoop", "afterLoopTypeof", "returnValue"],
    exp: ["string", "number", "string | number", "undefined", "number | undefined", "string | number | undefined", "never", "unknown", "number[]"],
  },
  render(d) {
    const c = CALLEES[d.callee];
    const INIT: Record<string, string> = { num: "0", str: "\"s\"", undef: "undefined", union: "(Math.random() ? 0 : \"s\")" };
    const iv = INIT[d.init];
    let head: string, sig = "";
    switch (d.decl) {
      case "annotated": head = `let x: string | number | undefined = ${iv};`; break;
      case "auto": head = `let x;\n  x = ${iv};`; break;
      case "autoInit": head = `let x;`; break;
      case "inferredInit": head = `let x = ${iv} as string | number | undefined;`; break;
      case "constCopy": head = `const x0 = ${iv};\n  let x = x0;`; break;
      default: head = ""; sig = `x: string | number | undefined`; break;
    }
    let step: string;
    const isValue = c.kind === "value";
    switch (d.shape) {
      case "assignCall": step = isValue ? `x = f(x);` : `f(x);\n    x = 1;`; break;
      case "callThenAssign": step = isValue ? `f(x);\n    x = f(x);` : `f(x);\n    x = (x as any).length;`; break;
      case "tempConst": step = isValue ? `const y = f(x);\n    x = y;` : `const y = x;\n    f(y);\n    x = y;`; break;
      case "condAssign": step = isValue ? `x = Math.random() ? f(x) : x;` : `if (Math.random()) f(x);`; break;
      case "compound": step = isValue ? `x = x ?? f(x);` : `f(x);\n    x += "";`; break;
      case "destructAssign": step = isValue ? `[x] = [f(x)];` : `f(x);\n    [x] = [x];`; break;
      case "nullishAssign": step = isValue ? `x ??= f(x);` : `x ??= 1;\n    f(x);`; break;
      case "callInCond": step = c.kind === "guard" ? `if (f(x)) { x = 1; } else { x = "s"; }` : isValue ? `if (f(x)) { x = 1; }` : `f(x);`; break;
      case "twoVars": step = isValue ? `const z = x;\n    x = f(z);` : `const z = x;\n    f(z);\n    x = z;`; break;
      default: step = isValue ? `const k = () => x;\n    x = f(k());` : `f(x);\n    const k = () => x;`; break;
    }
    let use: string;
    switch (d.use) {
      case "afterLoop": use = `const v: ${d.exp} = x;`; break;
      case "inLoop": use = `const v: ${d.exp} = x;`; break;
      case "afterLoopTypeof": use = `if (typeof x !== "string") { const v: ${d.exp} = x; }`; break;
      default: use = `return x;`; break;
    }
    let body: string;
    const inner = d.use === "inLoop" ? `${step}\n    ${use}` : step;
    const after = d.use === "inLoop" ? "" : `\n  ${use}`;
    switch (d.loop) {
      case "for": body = `for (let i = 0; i < 3; i++) {\n    ${inner}\n  }${after}`; break;
      case "while": body = `while (Math.random() > 0.5) {\n    ${inner}\n  }${after}`; break;
      case "doWhile": body = `do {\n    ${inner}\n  } while (Math.random() > 0.5);${after}`; break;
      case "forOf": body = `for (const _ of [1, 2]) {\n    ${inner}\n  }${after}`; break;
      case "nested": body = `for (let i = 0; i < 2; i++) {\n    for (let j = 0; j < 2; j++) {\n    ${inner}\n    }\n  }${after}`; break;
      case "labeledContinue": body = `outer: for (let i = 0; i < 3; i++) {\n    if (i) continue outer;\n    ${inner}\n  }${after}`; break;
      case "forIn": body = `for (const k in { a: 1 }) {\n    ${inner}\n  }${after}`; break;
      case "whileTrueBreak": body = `while (true) {\n    ${inner}\n    if (Math.random()) break;\n  }${after}`; break;
      default: body = `${inner}${after}`; break;
    }
    const ret = d.use === "returnValue" ? `: ${d.exp}` : "";
    return `${c.decl}\nfunction g(${sig})${ret} {\n  ${head ? head + "\n  " : ""}${body}\n}\n`;
  },
};
