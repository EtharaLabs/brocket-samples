// Family: structural relations between distinct declarations that share a name (namespaces,
// function scopes, merged declarations, generic instantiations), related directly or through
// containers.
import type { Family } from "./family.mts";

// member list pairs: [source members, target members]
const MEMBERS: Record<string, [string, string]> = {
  same: ["a: number;", "a: number;"],
  extraSrc: ["a: number; b: string;", "a: number;"],
  missingSrc: ["a: number;", "a: number; b: string;"],
  diffType: ["a: number;", "a: string;"],
  optTgt: ["a: number;", "a?: number;"],
  optSrc: ["a?: number;", "a: number;"],
  readonlySrc: ["readonly a: number;", "a: number;"],
  methodParam: ["m(x: string): void;", "m(x: number): void;"],
  propFnParam: ["m: (x: string) => void;", "m: (x: number) => void;"],
  methodNarrowParam: ["m(x: \"s\"): void;", "m(x: string): void;"],
  propFnNarrowParam: ["m: (x: \"s\") => void;", "m: (x: string) => void;"],
  retDiff: ["m(): string;", "m(): number;"],
  litSub: ["a: \"x\";", "a: string;"],
  litSuper: ["a: string;", "a: \"x\";"],
  indexSig: ["[k: string]: number;", "a: number;"],
  indexSigBad: ["[k: string]: string;", "a?: number;"],
  callSig: ["(): number;", "(): string;"],
  genericMethod: ["m<Q>(x: Q): Q;", "m(x: number): string;"],
  nestedDiff: ["a: { b: number };", "a: { b: string };"],
};

const CONTAINERS: Record<string, (t: string) => string> = {
  direct: (t) => t,
  array: (t) => `${t}[]`,
  box: (t) => `Box<${t}>`,
  boxFn: (t) => `BoxFn<${t}>`,
  boxMethod: (t) => `BoxMethod<${t}>`,
  promise: (t) => `Promise<${t}>`,
  fnRet: (t) => `() => ${t}`,
  fnParam: (t) => `(x: ${t}) => void`,
  readonlyArr: (t) => `readonly ${t}[]`,
  union: (t) => `${t} | null`,
  partial: (t) => `Partial<${t}>`,
  tuple: (t) => `[${t}]`,
};

export const namesFam: Family = {
  name: "same-name-structure",
  dims: {
    mem: Object.keys(MEMBERS),
    place: ["namespaces", "functionScopes", "renamedAlias", "classes", "genericInst", "merged", "nestedNamespace", "typeAliases", "classExpr", "genericNs", "sameGenericArgs", "genericAliasNs"],
    cont: Object.keys(CONTAINERS),
    dir: ["fwd", "rev"],
    ctx: ["assign", "argument", "returnStmt", "conditional"],
  },
  render(d) {
    let [ms, mt] = MEMBERS[d.mem];
    if (d.dir === "rev") [ms, mt] = [mt, ms];
    if (d.place === "classes" && (/^\[|^\(/.test(ms) || /^\[|^\(/.test(mt))) return null;
    if (d.place === "classExpr" && (/^\[|^\(/.test(ms) || /^\[|^\(/.test(mt))) return null;
    const C = CONTAINERS[d.cont];
    let pre = "interface Box<X> { v: X }\ninterface BoxFn<X> { f: (x: X) => void }\ninterface BoxMethod<X> { f(x: X): void }\n";
    let S: string, T: string, scoped: ((body: string) => string) | null = null;
    const cls = (m: string) => m.split(";").filter((x) => x.trim()).map((x) => x.trim())
      .map((x) => (/^\w+\??\s*[<(]/.test(x) ? `${x} { return null!; }` : `declare ${x};`)).join(" ");
    switch (d.place) {
      case "namespaces": pre += `namespace A { export interface Foo { ${ms} } }\nnamespace B { export interface Foo { ${mt} } }\n`; S = "A.Foo"; T = "B.Foo"; break;
      case "nestedNamespace": pre += `namespace A.X { export interface Foo { ${ms} } }\nnamespace B.X { export interface Foo { ${mt} } }\n`; S = "A.X.Foo"; T = "B.X.Foo"; break;
      case "renamedAlias": pre += `namespace A { export interface Foo { ${ms} } }\ninterface Foo { ${mt} }\nimport Foo2 = A.Foo;\n`; S = "Foo2"; T = "Foo"; break;
      case "classes": pre += `declare namespace A { export class Foo { ${ms} } }\ndeclare namespace B { export class Foo { ${mt} } }\n`; S = "A.Foo"; T = "B.Foo"; break;
      case "classExpr": pre += `const A = class Foo { ${cls(ms)} };\nconst B = class Foo { ${cls(mt)} };\n`; S = "InstanceType<typeof A>"; T = "InstanceType<typeof B>"; break;
      case "genericInst": pre += `interface G<P> { p: P; ${ms.replace(/number/g, "P")} }\ninterface H<P> { p: P; ${mt.replace(/number/g, "P")} }\n`; S = "G<number>"; T = "H<number>"; break;
      case "genericNs": pre += `namespace A { export interface Foo<P> { ${ms.replace(/number/g, "P")} } }\nnamespace B { export interface Foo<P> { ${mt.replace(/number/g, "P")} } }\n`; S = "A.Foo<number>"; T = "B.Foo<number>"; break;
      case "sameGenericArgs": if (ms !== mt && !/number/.test(ms + mt)) return null; pre += `interface Foo<P> { ${ms.replace(/number/g, "P")} }\n`; S = "Foo<number>"; T = d.mem === "same" ? "Foo<number>" : "Foo<string>"; if (ms !== MEMBERS[d.mem][0]) return null; break;
      case "genericAliasNs": pre += `namespace A { export type Foo<P> = { ${ms.replace(/number/g, "P")} }; }\nnamespace B { export type Foo<P> = { ${mt.replace(/number/g, "P")} }; }\n`; S = "A.Foo<number>"; T = "B.Foo<number>"; break;
      case "merged": pre += `interface Foo { ${ms} }\nnamespace A { export interface Foo { ${mt} } }\ninterface Foo { z?: 1 }\n`; S = "Foo"; T = "A.Foo"; break;
      case "typeAliases": pre += `namespace A { export type Foo = { ${ms} }; }\nnamespace B { export type Foo = { ${mt} }; }\n`; S = "A.Foo"; T = "B.Foo"; break;
      default: {
        S = "SS"; T = "TT";
        scoped = (body) => `function f1() {\n  interface Foo { ${ms} }\n  return null! as Foo;\n}\nfunction f2() {\n  interface Foo { ${mt} }\n  return null! as Foo;\n}\ntype SS = ReturnType<typeof f1>;\ntype TT = ReturnType<typeof f2>;\n${body}`;
        break;
      }
    }
    const st = C(S), tt = C(T);
    let body: string;
    switch (d.ctx) {
      case "assign": body = `declare const s: ${st};\nconst t: ${tt} = s;`; break;
      case "argument": body = `declare const s: ${st};\ndeclare function take(t: ${tt}): void;\ntake(s);`; break;
      case "returnStmt": body = `declare const s: ${st};\nfunction g(): ${tt} {\n  return s;\n}`; break;
      default: body = `type Chk = [${st}] extends [${tt}] ? 1 : 0;\nconst z: Chk = 1;`; break;
    }
    return scoped ? pre + scoped(body) + "\n" : pre + body + "\n";
  },
};
