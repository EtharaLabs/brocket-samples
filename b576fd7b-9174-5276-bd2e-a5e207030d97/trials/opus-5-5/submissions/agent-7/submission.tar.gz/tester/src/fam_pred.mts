// Family: inferred type predicates (function bodies analysed by control flow) consumed by
// overload resolution (array methods, overloaded user functions) and by narrowing at call sites.
import type { Family } from "./family.mts";

const ELEMS = [
  "string | number | undefined", "{ k: \"a\"; v: 1 } | { k: \"b\"; w: 2 }", "string | null", "unknown", "Date | string",
  "string | number", "\"a\" | \"b\" | 0", "{ k: \"a\"; v: 1 } | { k: \"b\"; w: 2 } | undefined", "string[] | string", "boolean | 0 | null",
];

// predicate expressions over parameter x (E = element type)
const PREDS: string[] = [
  "(x) => x !== undefined",
  "(x) => typeof x === \"string\"",
  "(x) => !!x",
  "(x) => x != null",
  "function (x) { return typeof x === \"number\"; }",
  "(x): x is string => typeof x === \"string\"",
  "(x) => { return x !== undefined; }",
  "(x) => x !== undefined && typeof x !== \"number\"",
  "(x) => Array.isArray(x)",
  "(x) => x instanceof Date",
  "(x) => isStr(x)",
  "(x) => x === \"a\"",
  "(x) => typeof x === \"object\" && x !== null && \"k\" in x && x.k === \"a\"",
  "(x, i) => typeof x === \"string\"",
  "(x) => { if (typeof x === \"string\") return true; return false; }",
  "(x: E) => x !== null",
  "(x) => typeof x !== \"string\"",
  "(x) => x === null || x === undefined",
  "(x) => typeof x === \"string\" || typeof x === \"number\"",
  "(x) => !(typeof x === \"string\")",
  "isDef",
  "isStrDecl",
  "(x) => typeof x === \"string\" ? true : false",
  "(x) => (typeof x === \"string\")",
  "(x) => x as unknown === 1",
];

// annotates the parameters of an inline predicate so it can stand alone
function typed(P: string, E: string): string {
  return P.replace(/^(function )?\(x(, i)?\)/, (_m, f, i) => `${f ?? ""}(x: ${E}${i ? ", i?: number" : ""})`);
}

export const predFam: Family = {
  name: "inferred-predicate",
  labelOf(k, v) { return k === "el" ? ELEMS[+v] : k === "pred" ? PREDS[+v] : v; },
  dims: {
    pred: PREDS.map((_, i) => String(i)),
    el: ELEMS.map((_, i) => String(i)),
    use: ["filter", "find", "every", "findLast", "myFilter", "myFilterOv", "standalone", "standaloneElse", "roFilter", "filterChain", "findIndexThenFilter", "guardParam"],
  },
  render(d) {
    const E = ELEMS[+d.el];
    const P = PREDS[+d.pred].replace(/\bE\b/g, `(${E})`);
    let pre = "declare function isStr(x: unknown): x is string;\n" +
      `const isDef = (x: ${E}) => x !== undefined && x !== null;\n` +
      `function isStrDecl(x: ${E}) {\n  return typeof x === "string";\n}\n` +
      `declare const arr: (${E})[];\ndeclare const ro: readonly (${E})[];\ndeclare const v: ${E};\n`;
    let body: string;
    switch (d.use) {
      case "filter": body = `const r = arr.filter(${P});\nconst o: unknown = r;`; break;
      case "find": body = `const r = arr.find(${P});\nconst o: unknown = r;`; break;
      case "every": body = `if (arr.every(${P})) {\n  const o: unknown = arr;\n}`; break;
      case "findLast": body = `const r = arr.findLast(${P});\nconst o: unknown = r;`; break;
      case "myFilter":
        pre += "declare function myFilter<T, S extends T>(xs: T[], p: (x: T) => x is S): S[];\n";
        body = `const r = myFilter(arr, ${P});\nconst o: unknown = r;`; break;
      case "myFilterOv":
        pre += "declare function myFilter<T, S extends T>(xs: T[], p: (x: T) => x is S): { s: S[] };\ndeclare function myFilter<T>(xs: T[], p: (x: T) => unknown): { t: T[] };\n";
        body = `const r = myFilter(arr, ${P});\nconst o: unknown = r;`; break;
      case "standalone": body = `const g = ${typed(P, E)};\nif (g(v, 0)) {\n  const o: unknown = v;\n}`; break;
      case "standaloneElse": body = `const g = ${typed(P, E)};\nif (g(v, 0)) { } else {\n  const o: unknown = v;\n}`; break;
      case "roFilter": body = `const r = ro.filter(${P});\nconst o: unknown = r;`; break;
      case "filterChain": body = `const r = arr.filter(${P}).map((y) => [y] as const);\nconst o: unknown = r;`; break;
      case "findIndexThenFilter": body = `const r = [v].filter(${P});\nconst o: unknown = r;`; break;
      default: {
        pre += `declare function run<T>(xs: T[], g: (x: T) => boolean): T;\n`;
        body = `const r = run(arr, ${P});\nconst o: unknown = r;`; break;
      }
    }
    return pre + body + "\n";
  },
};
