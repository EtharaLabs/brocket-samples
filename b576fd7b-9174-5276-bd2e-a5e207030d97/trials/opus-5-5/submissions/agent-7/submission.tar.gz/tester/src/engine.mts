import { runChecker, Pool, type Outcome } from "./exec.mts";
import { diagnostics, observed, fingerprint } from "./typed.mts";

export interface Ctx {
  ref: string;
  nat: string;
  pool: Pool;
  deadline: number; // ms epoch after which no new work starts
  screenTimeout?: number;
}

export interface ScreenResult { refErr: boolean; natErr: boolean; natOdd: boolean; refSig: string; natSig: string; }
export interface ScreenItem { src: string; marks?: number[]; }

function sig(diag: Map<number, string[]>, start: number, end: number, marks: number[]): string {
  const abs = new Set(marks.map((l) => start + l));
  let other = false;
  for (const l of diag.keys()) if (l >= start && l <= end && !abs.has(l)) other = true;
  if (other) return "E"; // observed types after an error are recovery artifacts
  return "-" + marks.map((l) => "\u0001" + fingerprint(observed(diag.get(start + l)))).join("");
}

// Observations that one side printed truncated ("~") are not compared.
export function differs(r: ScreenResult | null): boolean {
  if (!r) return false;
  if (r.natOdd) return true;
  if (r.refSig === r.natSig) return false;
  const a = r.refSig.split("\u0001"), b = r.natSig.split("\u0001");
  return a.length !== b.length || a.some((x, i) => x !== b[i] && x !== "~" && b[i] !== "~");
}

export function wrap(srcs: string[]): { text: string; ranges: [number, number][] } {
  let text = "";
  let line = 1;
  const ranges: [number, number][] = [];
  srcs.forEach((s, i) => {
    const body = s.endsWith("\n") ? s : s + "\n";
    const start = line;
    text += `namespace N${i} {\n` + body + "}\n";
    line += 1 + body.split("\n").length - 1 + 1;
    ranges.push([start, line - 1]);
  });
  return { text, ranges };
}

function errLines(out: string): number[] {
  const res: number[] = [];
  const re = /^p\.ts\((\d+),\d+\): error TS\d+:/gm;
  let m;
  while ((m = re.exec(out))) res.push(+m[1]);
  return res;
}

// Lines of TS1xxx errors when they are the only errors reported (syntax errors suppress the
// semantic pass for the whole file).
function synLines(out: string): number[] {
  const res: number[] = [];
  if (/^p\.ts\(\d+,\d+\): error TS[2-9]\d\d\d/m.test(out)) return res;
  const re = /^p\.ts\((\d+),\d+\): error TS1\d\d\d:/gm;
  let m;
  while ((m = re.exec(out))) res.push(+m[1]);
  return res;
}

function mark(lines: number[], ranges: [number, number][]): boolean[] {
  const r = ranges.map(() => false);
  for (const l of lines) {
    const i = ranges.findIndex(([a, b]) => l >= a && l <= b);
    if (i >= 0) r[i] = true;
  }
  return r;
}

// Screens probes in batches; returns per-probe signatures (error presence + observed types) on both checkers.
export async function screen(ctx: Ctx, items: ScreenItem[]): Promise<(ScreenResult | null)[]> {
  if (items.length === 0) return [];
  if (Date.now() > ctx.deadline) return items.map(() => null);
  const { text, ranges } = wrap(items.map((x) => x.src));
  const [a, b] = await Promise.all([
    ctx.pool.run(() => runChecker(ctx.ref, text, ctx.screenTimeout)),
    ctx.pool.run(() => runChecker(ctx.nat, text, ctx.screenTimeout)),
  ]);
  const ok = (c: Outcome) => c === "accept" || c === "reject";
  if (!ok(a.cls) || !ok(b.cls)) {
    if (items.length === 1) return [{ refErr: a.cls !== "accept", natErr: b.cls !== "accept", natOdd: !ok(b.cls) || !ok(a.cls), refSig: a.cls, natSig: b.cls }];
    const mid = items.length >> 1;
    const [l, r] = await Promise.all([screen(ctx, items.slice(0, mid)), screen(ctx, items.slice(mid))]);
    return [...l, ...r];
  }
  // A syntax error anywhere suppresses semantic checking of the whole batch: drop such probes.
  const syn = mark([...synLines(a.out), ...synLines(b.out)], ranges);
  if (syn.some((x) => x)) {
    const rest = items.filter((_, i) => !syn[i]);
    const rr = await screen(ctx, rest);
    let j = 0;
    return items.map((_, i) => (syn[i] ? null : rr[j++]));
  }
  const ra = mark(errLines(a.out), ranges), rb = mark(errLines(b.out), ranges);
  const da = diagnostics(a.out), db = diagnostics(b.out);
  return items.map((it, i) => ({
    refErr: ra[i], natErr: rb[i], natOdd: false,
    refSig: sig(da, ranges[i][0], ranges[i][1], it.marks ?? []),
    natSig: sig(db, ranges[i][0], ranges[i][1], it.marks ?? []),
  }));
}

export interface Measure { ref: Outcome; nat: Outcome; }

export async function measure(ctx: Ctx, src: string): Promise<Measure> {
  const [a, b] = await Promise.all([
    ctx.pool.run(() => runChecker(ctx.ref, src)),
    ctx.pool.run(() => runChecker(ctx.nat, src)),
  ]);
  return { ref: a.cls, nat: b.cls };
}

// Measures twice; returns classes only if stable.
export async function measureStable(ctx: Ctx, src: string): Promise<Measure | null> {
  const m1 = await measure(ctx, src);
  if (m1.ref === m1.nat) return m1;
  const m2 = await measure(ctx, src);
  if (m1.ref !== m2.ref || m1.nat !== m2.nat) return null;
  return m1;
}

// Screens with the reference batched (namespace-wrapped) and the native checker on each probe
// standalone, so behaviour that depends on the probe sitting at file top level is also seen.
export async function screenSolo(ctx: Ctx, items: ScreenItem[]): Promise<(ScreenResult | null)[]> {
  if (items.length === 0) return [];
  if (Date.now() > ctx.deadline) return items.map(() => null);
  const { text, ranges } = wrap(items.map((x) => x.src));
  const ok = (c: Outcome) => c === "accept" || c === "reject";
  const [a, bs] = await Promise.all([
    ctx.pool.run(() => runChecker(ctx.ref, text, ctx.screenTimeout)),
    Promise.all(items.map((it) => ctx.pool.run(() => runChecker(ctx.nat, it.src, ctx.screenTimeout)))),
  ]);
  if (!ok(a.cls)) return items.map(() => null);
  const syn = mark(synLines(a.out), ranges);
  if (syn.some((x) => x)) {
    const rest = items.filter((_, i) => !syn[i]);
    const rr = await screenSolo(ctx, rest);
    let j = 0;
    return items.map((_, i) => (syn[i] ? null : rr[j++]));
  }
  const da = diagnostics(a.out);
  return items.map((it, i) => {
    const b = bs[i];
    if (!ok(b.cls)) return { refErr: true, natErr: true, natOdd: true, refSig: a.cls, natSig: b.cls };
    return {
      refErr: false, natErr: false, natOdd: false,
      refSig: sig(da, ranges[i][0], ranges[i][1], it.marks ?? []),
      natSig: sig(diagnostics(b.out), 0, 1e9, it.marks ?? []),
    };
  });
}
