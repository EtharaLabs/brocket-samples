// Family: discriminated-union narrowing through property access on the union holder.
import type { Family } from "./family.mts";

export const discFam: Family = {
  name: "discriminant-property",
  dims: {
    dk: ["strLit", "numLit", "bool", "litUnion", "optionalUndef", "nullMember", "tplLit", "enumLit", "mixedNonUnit"],
    n: ["2", "3"],
    holder: ["param", "constLocal", "readonlyProp", "thisProp", "genericT", "arrayElem", "letAssigned", "optionalParam", "nestedProp", "indexAccessType", "intersected", "unionOfGenerics"],
    access: ["dot", "element", "optChain", "destructAfter"],
    check: ["ifEq", "ifNeqReturn", "switch", "ternary", "inOp", "typeofDisc", "truthy", "elseBranch", "aliased", "earlyThrowSwitch"],
    use: ["readPayload", "destructurePayload", "passHolder", "callMethod", "assignHolder"],
    wrong: ["no", "yes"],
  },
  render(d) {
    const n = d.dk === "bool" || d.dk === "optionalUndef" || d.dk === "nullMember" ? 2 : +d.n;
    let pre = "";
    let kv: string[]; // discriminant type text per member
    let tv: string[]; // test value for member 0 (expression)
    switch (d.dk) {
      case "strLit": kv = ["\"a\"", "\"b\"", "\"c\""]; break;
      case "numLit": kv = ["0", "1", "2"]; break;
      case "bool": kv = ["true", "false"]; break;
      case "litUnion": kv = ["\"a\" | \"x\"", "\"b\"", "\"c\" | \"y\""]; break;
      case "optionalUndef": kv = ["\"a\"", "undefined"]; break;
      case "nullMember": kv = ["\"a\"", "null"]; break;
      case "tplLit": kv = ["`a${string}`", "\"b\"", "\"c\""]; break;
      case "enumLit": pre += "enum K { A = \"a\", B = \"b\", C = \"c\" }\n"; kv = ["K.A", "K.B", "K.C"]; break;
      default: kv = ["\"a\"", "string", "number"]; break;
    }
    kv = kv.slice(0, n);
    const t0 = d.dk === "tplLit" ? "\"a1\"" : d.dk === "litUnion" ? "\"a\"" : kv[0];
    if (d.check === "typeofDisc" && d.dk !== "mixedNonUnit" && d.dk !== "optionalUndef" && d.dk !== "nullMember") return null;
    if (d.check === "truthy" && !(d.dk === "bool" || d.dk === "optionalUndef" || d.dk === "nullMember")) return null;
    const pay = ["number", "string", "boolean"];
    const field = (i: number) => d.dk === "optionalUndef" && i === 1 ? "kind?" : "kind";
    const members = kv.map((k, i) => `{ ${field(i)}: ${k}; payload: ${pay[i]}; m${i}(): void }`);
    pre += `type U = ${members.join(" | ")};\n`;
    const want = d.wrong === "yes" ? pay[1] : pay[0];
    // holder expression and preamble inside function
    let sig = "", head = "", H = "x", cls = false, generic = "";
    switch (d.holder) {
      case "param": sig = "x: U"; break;
      case "constLocal": sig = "x0: U"; head = "const x = x0;\n  "; break;
      case "readonlyProp": sig = "o: { readonly v: U }"; H = "o.v"; break;
      case "thisProp": cls = true; H = "this.v"; break;
      case "genericT": generic = "<T extends U>"; sig = "x: T"; break;
      case "arrayElem": sig = "arr: readonly U[]"; H = "arr[0]"; break;
      case "letAssigned": sig = "x0: U"; head = `let x: U = x0;\n  if (Math.random()) x = x0;\n  `; break;
      case "optionalParam": sig = "x?: U"; break;
      case "nestedProp": sig = "o: { a: { v: U } }"; H = "o.a.v"; break;
      case "indexAccessType": pre += "type W = { v: U };\n"; sig = "x: W[\"v\"]"; break;
      case "intersected": sig = "x: U & { extra: number }"; break;
      default: generic = "<A extends U, B extends U>"; sig = "x: A | B"; break;
    }
    if (d.check === "inOp" && d.holder === "optionalParam") return null;
    const opt = d.holder === "optionalParam" || d.access === "optChain";
    if (d.access === "optChain" && d.holder !== "optionalParam") {
      // make holder possibly undefined
      if (d.holder !== "param") return null;
      sig = "x: U | undefined";
    }
    const acc = (h: string) => d.access === "element" ? `${h}["kind"]` : opt ? `${h}?.kind` : `${h}.kind`;
    let K = acc(H);
    if (d.access === "destructAfter") K = `${H}.kind`;
    let use: string;
    switch (d.use) {
      case "readPayload": use = `const v: ${want} = ${H}.payload;`; break;
      case "destructurePayload": use = `const { payload } = ${H};\n    const v: ${want} = payload;`; break;
      case "passHolder": pre += `declare function take(h: Extract<U, { payload: ${want} }>): void;\n`; use = `take(${H});`; break;
      case "callMethod": use = d.wrong === "yes" ? `${H}.m1();` : `${H}.m0();`; break;
      default: use = `const h: Extract<U, { payload: ${want} }> = ${H};`; break;
    }
    if (d.access === "destructAfter") use = `const { payload: pp } = ${H};\n    const v: ${want} = pp;`;
    let body: string;
    switch (d.check) {
      case "ifEq": body = `if (${K} === ${t0}) {\n    ${use}\n  }`; break;
      case "ifNeqReturn": body = `if (${K} !== ${t0}) return;\n  ${use}`; break;
      case "switch": body = `switch (${K}) {\n    case ${t0}: {\n    ${use}\n    }\n  }`; break;
      case "ternary": body = `const r = ${K} === ${t0} ? (() => {\n    ${use}\n  })() : 0;`; break;
      case "inOp": body = `if ("m0" in ${H}) {\n    ${use}\n  }`; break;
      case "typeofDisc": body = d.dk === "mixedNonUnit" ? `if (${K} === "a") {\n    ${use}\n  }` : `if (typeof ${K} === "string") {\n    ${use}\n  }`; break;
      case "truthy": body = `if (${K}) {\n    ${use}\n  }`; break;
      case "elseBranch": body = n === 2 ? `if (${K} !== ${t0}) { } else {\n    ${use}\n  }` : `if (${K} === ${kv[1]} || ${K} === ${kv[2]}) { } else {\n    ${use}\n  }`; if (d.dk === "tplLit" || d.dk === "litUnion" || d.dk === "mixedNonUnit") return null; break;
      case "aliased": body = `const isA = ${K} === ${t0};\n  if (isA) {\n    ${use}\n  }`; break;
      default: body = `switch (${K}) {\n    case ${t0}: break;\n    default: throw 0;\n  }\n  ${use}`; break;
    }
    if (cls) return pre + `class C {\n  constructor(readonly v: U) { }\n  run() {\n  ${body}\n  }\n}\n`;
    return pre + `function f${generic}(${sig}) {\n  ${head}${body}\n}\n`;
  },
};
