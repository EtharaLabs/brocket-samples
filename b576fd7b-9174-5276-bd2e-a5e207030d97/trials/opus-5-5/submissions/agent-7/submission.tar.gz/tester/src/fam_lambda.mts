// Family: generic calls with context-sensitive function arguments (partially annotated parameters,
// methods, destructured and rest parameters); parameter and result types are observed.
import type { Family } from "./family.mts";

// [declaration, parameter list of the callback type with T, U]
const SIGS: Record<string, string> = {
  twoSame: "declare function f<T>(cb: (a: T, b: T) => void): T;",
  twoDiff: "declare function f<T, U>(cb: (a: T, b: U) => void): [T, U];",
  retU: "declare function f<T, U>(cb: (a: T, b: T) => U): [T, U];",
  withArg: "declare function f<T>(x: T, cb: (a: T, b: T) => void): T;",
  argAfter: "declare function f<T>(cb: (a: T, b: T) => void, x: T): T;",
  objProp: "declare function f<T>(o: { cb: (a: T, b: T) => void }): T;",
  objTwo: "declare function f<T>(o: { make: (a: T, b: T) => void; use: (t: T) => void }): T;",
  overloaded: "declare function f<T>(cb: (a: T, b: T) => void): T;\ndeclare function f<T>(cb: (a: T, b: T, c: T) => void, x?: 1): T[];",
  unionCb: "declare function f<T>(cb: ((a: T, b: T) => void) | ((a: T, b: T, c: T) => void)): T;",
  interCb: "declare function f<T>(cb: ((a: T, b: T) => void) & { extra?: T }): T;",
  restCb: "declare function f<T extends unknown[]>(cb: (...a: T) => void): T;",
  mappedCb: "declare function f<T>(o: { [K in keyof T]: (a: T[K], b: T[K]) => void }): T;",
  callable: "declare function f<T>(cb: { (a: T, b: T): void }): T;",
  constrained: "declare function f<T extends string | number>(cb: (a: T, b: T) => void): T;",
  defaulted: "declare function f<T = boolean>(cb: (a: T, b: T) => void): T;",
  thisCb: "declare function f<T>(cb: (this: T, a: T, b: T) => void): T;",
  promiseCb: "declare function f<T>(cb: (a: T, b: T) => Promise<T>): T;",
  ctxReturn: "declare function f<T>(cb: (a: T, b: T) => void): (x: T) => T;",
  constraintObj: "declare function f<T extends { cb: (a: string, b: string) => void }>(o: T): T;",
  constraintFn: "declare function f<T extends (a: string, b: string) => void>(cb: T): T;",
  constraintRecord: "declare function f<T extends Record<string, (a: string, b: string) => void>>(o: T): T;",
  constraintUnion: "declare function f<T extends ((a: string, b: string) => void) | string>(cb: T): T;",
  constraintKeyed: "interface H { x: (a: string, b: number) => void; y: (a: number, b: string) => void }\ndeclare function f<K extends keyof H>(k: K, cb: H[K]): K;",
  condCb: "declare function f<T>(cb: (a: T, b: T extends string ? \"s\" : \"o\") => void): T;",
};

const ANN = ["string", "number", "\"lit\"", "{ k: 1 }", "string[]", "unknown", "string | number", "never"];

// callback argument forms; A = annotation type text
const LAMBDAS: Record<string, (A: string) => string> = {
  firstAnn: (A) => "(a: A, b) => {\n  const oa: unknown = a;\n  const ob: unknown = b;\n}".replace(/A\b/, A),
  secondAnn: (A) => "(a, b: A) => {\n  const oa: unknown = a;\n  const ob: unknown = b;\n}".replace(/A\b/, A),
  bothAnn: (A) => `(a: ${A}, b: ${A}) => {\n  const oa: unknown = a;\n  const ob: unknown = b;\n}`,
  noneAnn: () => "(a, b) => {\n  const oa: unknown = a;\n  const ob: unknown = b;\n}",
  fnExprFirstAnn: (A) => `function (a: ${A}, b) {\n  const ob: unknown = b;\n}`,
  destrSecond: (A) => `(a: ${A}, { length }) => {\n  const ol: unknown = length;\n}`,
  defaultSecond: (A) => `(a: ${A}, b = a) => {\n  const ob: unknown = b;\n}`,
  oneParamAnn: (A) => `(a: ${A}) => {\n  const oa: unknown = a;\n}`,
  restAnn: (A) => `(...xs: [${A}, ${A}]) => {\n  const ox: unknown = xs;\n}`,
  exprBodyAnn: (A) => `(a: ${A}, b) => b`,
  asyncFirstAnn: (A) => `async (a: ${A}, b) => {\n  const ob: unknown = b;\n  return b;\n}`,
  thisAnn: (A) => `function (this: ${A}, a, b) {\n  const ob: unknown = b;\n}`,
};

export const lambdaFam: Family = {
  name: "context-sensitive-callback",
  labelOf(k, v) { return k === "ann" ? ANN[+v] : v; },
  dims: {
    sig: Object.keys(SIGS),
    lam: Object.keys(LAMBDAS),
    ann: ANN.map((_, i) => String(i)),
    ctx: ["none", "annot", "argTo", "spreadCall"],
    xv: ["\"s\"", "1", "null!"],
  },
  render(d) {
    const A = ANN[+d.ann];
    const lam = LAMBDAS[d.lam](A);
    const x = d.xv;
    let call: string;
    switch (d.sig) {
      case "withArg": call = `f(${x}, ${lam})`; break;
      case "argAfter": call = `f(${lam}, ${x})`; break;
      case "constraintObj": call = `f({ cb: ${lam} })`; break;
      case "constraintRecord": call = `f({ p: ${lam} })`; break;
      case "constraintKeyed": call = `f("x", ${lam})`; break;
      case "objProp": call = `f({ cb: ${lam} })`; break;
      case "objTwo": call = `f({ make: ${lam}, use: (t) => {\n  const ot: unknown = t;\n} })`; break;
      case "mappedCb": call = `f({ p: ${lam}, q: (a: number, b) => {\n  const oq: unknown = b;\n} })`; break;
      default: call = `f(${lam})`; break;
    }
    let use: string;
    switch (d.ctx) {
      case "none": use = `const r = ${call};\nconst c: unknown = r;`; break;
      case "annot": use = `const r: ${A} = ${call};`; break;
      case "argTo": use = `declare function take(x: ${A}): void;\ntake(${call});`; break;
      default: use = `const r = [${call}] as const;\nconst c: unknown = r;`; break;
    }
    return SIGS[d.sig] + "\n" + use + "\n";
  },
};
