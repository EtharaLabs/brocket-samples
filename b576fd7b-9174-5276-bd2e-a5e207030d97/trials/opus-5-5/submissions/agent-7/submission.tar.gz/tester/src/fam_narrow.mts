// Family: control-flow narrowing of a declared union by a guard, observed by assignment.
import type { Family } from "./family.mts";

const DECLS = [
  "string | number",
  "string | number | undefined",
  "string | null | undefined",
  "{ kind: \"a\"; a: number } | { kind: \"b\"; b: string }",
  "{ kind: \"a\"; a: number } | { kind: \"b\"; b: string } | undefined",
  "number[] | string",
  "Date | RegExp | string",
  "{ a: number } | { b: string }",
  "boolean | 0 | \"\"",
  "unknown",
  "{ tag: 1; v: string } | { tag: 2; v: number } | { tag?: undefined; v: boolean }",
  "readonly [1, string] | readonly [2, number]",
  "Error | { message: string; code: number }",
  "(() => number) | { call: number }",
  "Map<string, number> | Set<string>",
  "\"x\" | \"y\" | 1 | 2",
  "{ ok: true; value: number } | { ok: false; error: string }",
  "string[] | number[]",
  "{ a?: number } | { b?: string }",
];
const GUARDS = [
  "typeof X === \"string\"", "typeof X === \"number\"", "typeof X === \"object\"", "typeof X === \"function\"",
  "X === undefined", "X === null", "X != null", "!X", "X", "X instanceof Date", "Array.isArray(X)",
  "typeof X === \"object\" && X !== null && \"kind\" in X && X.kind === \"a\"", "\"a\" in (X as object)",
  "X?.kind === \"a\"", "(X as any)?.kind === \"a\"", "X === \"x\"", "X === 1", "isStr(X)", "X instanceof Error",
  "typeof X !== \"string\" && typeof X !== \"number\"", "X?.tag === 1", "X?.ok", "X?.[0] === 1", "!(typeof X === \"string\")",
  "typeof X === \"string\" || typeof X === \"undefined\"", "X instanceof Map", "typeof X === \"boolean\"",
  "\"call\" in X", "\"message\" in X", "\"a\" in X", "X?.tag === undefined", "X?.ok === false",
];
const TYPES = ["string", "number", "undefined", "null", "never", "{ kind: \"a\"; a: number }", "{ kind: \"b\"; b: string }",
  "Date", "RegExp", "number[]", "string[]", "object", "{}", "boolean", "false | 0 | \"\"", "true", "Error", "() => number",
  "Map<string, number>", "Set<string>", "\"x\"", "1", "{ a: number }", "{ b: string }", "readonly [1, string]",
  "{ ok: true; value: number }", "{ ok: false; error: string }", "{ tag: 1; v: string }", "string | number", "unknown"];

export const narrowFam: Family = {
  name: "union-narrowing",
  dims: {
    decl: DECLS.map((_, i) => String(i)),
    guard: GUARDS.map((_, i) => String(i)),
    branch: ["then", "else", "after-return", "ternary", "and", "or-else", "while", "assign-then", "closure-const", "switch-true"],
    holder: ["param", "const", "prop", "let", "destructured", "optionalParam"],
    t: TYPES.map((_, i) => String(i)),
  },
  render(d) {
    const U = DECLS[+d.decl];
    const T = TYPES[+d.t];
    let X: string, head: string, sig = "";
    switch (d.holder) {
      case "param": X = "x"; sig = `x: ${U}`; head = ""; break;
      case "const": X = "x"; sig = `x0: ${U}`; head = "const x = x0;\n  "; break;
      case "prop": X = "o.p"; sig = `o: { readonly p: ${U} }`; head = ""; break;
      case "let": X = "x"; sig = `x0: ${U}`; head = "let x = x0;\n  "; break;
      case "destructured": X = "p"; sig = `{ p }: { p: ${U} }`; head = ""; break;
      default: X = "x"; sig = `x?: ${U}`; head = ""; break;
    }
    const g = GUARDS[+d.guard].replaceAll("X", X);
    const use = `const v: ${T} = ${X};`;
    let body: string;
    switch (d.branch) {
      case "then": body = `if (${g}) { ${use} }`; break;
      case "else": body = `if (${g}) { } else { ${use} }`; break;
      case "after-return": body = `if (${g}) return;\n  ${use}`; break;
      case "ternary": body = `const r = (${g}) ? ((v: ${T}) => v)(${X}) : 0;`; break;
      case "and": body = `(${g}) && ((v: ${T}) => v)(${X});`; break;
      case "or-else": body = `(${g}) || ((v: ${T}) => v)(${X});`; break;
      case "while": body = `while (${g}) { ${use} break; }`; break;
      case "assign-then": body = `const ok = ${g};\n  if (ok) { ${use} }`; break;
      case "closure-const": body = `if (${g}) { const k = () => { ${use} }; }`; break;
      default: body = `switch (true) { case ${g}: { ${use} } }`; break;
    }
    return `declare function isStr(x: unknown): x is string;\nfunction f(${sig}) {\n  ${head}${body}\n}\n`;
  },
};
