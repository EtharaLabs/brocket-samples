// Family: composed type-operator stacks over a type parameter. A generic signature is built
// from operator chains; arguments are synthesized to match an instantiation; the result is
// checked against the instantiated return chain (or a perturbed instantiation).
import type { Family } from "./family.mts";

// concrete instantiations: [type text, value text]
export const LEAVES: [string, string][] = [
  ["number", "1"], ["string", "\"s\""], ["\"a\"", "\"a\" as const"], ["boolean", "true"], ["{ a: number }", "{ a: 1 }"],
  ["string[]", "[\"x\"]"], ["null", "null"], ["undefined", "undefined"], ["1 | \"b\"", "(Math.random() ? 1 : \"b\") as 1 | \"b\""],
  ["() => number", "() => 1"], ["unknown", "1 as unknown"], ["never", "null!"], ["{ a: number; b: string }", "{ a: 1, b: \"\" }"],
];

// operator: type wrapper and value wrapper
interface Op { t(x: string): string; v(x: string, tx: string): string | null; }
export const OPS: Record<string, Op> = {
  arr: { t: (x) => `${x}[]`.replace(/^(.*\|.*|.*=>.*)\[\]$/, "($1)[]"), v: (v) => `[${v}]` },
  roarr: { t: (x) => `readonly (${x})[]`, v: (v) => `[${v}] as const` },
  obj: { t: (x) => `{ p: ${x} }`, v: (v) => `{ p: ${v} }` },
  optobj: { t: (x) => `{ p?: ${x} }`, v: (v) => `{ p: ${v} }` },
  roobj: { t: (x) => `{ readonly p: ${x} }`, v: (v) => `{ p: ${v} }` },
  thunk: { t: (x) => `() => ${x}`, v: (v) => `() => (${v})` },
  cb: { t: (x) => `(x: ${x}) => void`, v: (_v, tx) => `(x: ${tx}) => { }` },
  method: { t: (x) => `{ m(x: ${x}): void }`, v: (_v, tx) => `{ m(x: ${tx}) { } }` },
  getter: { t: (x) => `{ get(): ${x} }`, v: (v) => `{ get() { return ${v}; } }` },
  callable: { t: (x) => `{ (): ${x} }`, v: (v) => `(() => (${v}))` },
  orUndef: { t: (x) => `${x} | undefined`, v: (v) => v },
  orNull: { t: (x) => `${x} | null`, v: (v) => v },
  andEmpty: { t: (x) => `${x} & {}`, v: (v) => v },
  promise: { t: (x) => `Promise<${x}>`, v: (v) => `Promise.resolve(${v})` },
  tuple: { t: (x) => `[${x}, string]`, v: (v) => `[${v}, "t"]` },
  box: { t: (x) => `Box<${x}>`, v: (v) => `{ v: ${v} }` },
  alias: { t: (x) => `Id<${x}>`, v: (v) => v },
  partial: { t: (x) => `Partial<{ p: ${x} }>`, v: (v) => `{ p: ${v} }` },
  record: { t: (x) => `Record<"k", ${x}>`, v: (v) => `{ k: ${v} }` },
  readonly: { t: (x) => `Readonly<{ p: ${x} }>`, v: (v) => `{ p: ${v} }` },
  orStr: { t: (x) => `${x} | string`, v: (v) => v },
  set: { t: (x) => `Set<${x}>`, v: (v) => `new Set([${v}])` },
  map: { t: (x) => `Map<string, ${x}>`, v: (v) => `new Map([["k", ${v}]])` },
  rest: { t: (x) => `[...${x}[]]`, v: (v) => `[${v}]` },
  cond: { t: (x) => `Unbox<${x}>`, v: (v) => v },
  nonNull: { t: (x) => `NonNullable<${x}>`, v: (v) => v },
};
export const PRELUDE = "interface Box<X> { v: X }\ntype Id<X> = X;\ntype Unbox<X> = X extends Box<infer Y> ? Y : X;\n";

export function inst(ops: string[], leaf: string): string {
  let t = leaf;
  for (let i = ops.length - 1; i >= 0; i--) t = OPS[ops[i]].t(t.includes("=>") || t.includes("|") ? `(${t})` : t);
  return t;
}
export function val(ops: string[], leaf: [string, string]): string | null {
  let v = leaf[1];
  for (let i = ops.length - 1; i >= 0; i--) {
    const inner = inst(ops.slice(i + 1), leaf[0]);
    const nv = OPS[ops[i]].v(v, inner);
    if (nv === null) return null;
    v = nv;
  }
  return v;
}

const opNames = Object.keys(OPS);
const chainVals = ["", ...opNames, ...opNames.flatMap((a) => ["arr", "obj", "thunk", "cb", "promise", "orUndef", "box"].map((b) => `${a}.${b}`))];

export const compFam: Family = {
  name: "composed-inference",
  weight: 1.5,
  dims: {
    p1: chainVals,
    p2: ["none", ...chainVals],
    ret: chainVals,
    leaf: LEAVES.map((_, i) => String(i)),
    leaf2: ["same", ...LEAVES.map((_, i) => String(i))],
    exp: ["same", ...LEAVES.map((_, i) => String(i))],
    tp: ["plain", "const", "extendsUnknown", "extendsObjOrPrim", "extendsString", "default"],
    ctx: ["none", "annot", "ret", "generic"],
  },
  labelOf(k, v) { return k.startsWith("leaf") || k === "exp" ? (LEAVES[+v]?.[0] ?? v) : v || "T"; },
  render(d) {
    const ch = (s: string) => (s ? s.split(".") : []);
    const p1 = ch(d.p1), ret = ch(d.ret);
    const p2 = d.p2 === "none" ? null : ch(d.p2);
    const L = LEAVES[+d.leaf];
    const L2 = d.leaf2 === "same" ? L : LEAVES[+d.leaf2];
    const E = d.exp === "same" ? L : LEAVES[+d.exp];
    let tp = "T";
    switch (d.tp) {
      case "const": tp = "const T"; break;
      case "extendsUnknown": tp = "T extends unknown"; break;
      case "extendsObjOrPrim": tp = "T extends {} | null | undefined"; break;
      case "extendsString": tp = "T extends string"; break;
      case "default": tp = "T = never"; break;
    }
    const params = [`a: ${inst(p1, "T")}`];
    const v1 = val(p1, L);
    if (v1 === null) return null;
    const argv = [v1];
    if (p2) {
      params.push(`b: ${inst(p2, "T")}`);
      const v2 = val(p2, L2);
      if (v2 === null) return null;
      argv.push(v2);
    }
    const R = inst(ret, "T");
    const ET = inst(ret, E[0]);
    let use: string;
    const call = `f(${argv.join(", ")})`;
    switch (d.ctx) {
      case "annot": use = `const r: ${ET} = ${call};`; break;
      case "ret": use = `function g(): ${ET} {\n  return ${call};\n}`; break;
      case "generic": {
        // relation between the chains under an uninstantiated type parameter
        if (p2) return null;
        use = `function g<${tp}>(a: ${inst(p1, "T")}): ${R} {\n  return f(a);\n}`;
        break;
      }
      default: use = `const r = ${call};\nconst c: ${ET} = r;`; break;
    }
    return `${PRELUDE}declare function f<${tp}>(${params.join(", ")}): ${R};\n${use}\n`;
  },
};
