import { runChecker, Pool, type Outcome } from "./exec.mts";

export interface Ctx {
  ref: string;
  nat: string;
  pool: Pool;
  deadline: number; // ms epoch after which no new work starts
  screenTimeout?: number;
}

export interface ScreenResult { refErr: boolean; natErr: boolean; natOdd: boolean; }

export function wrap(srcs: string[]): { text: string; ranges: [number, number][] } {
  let text = "";
  let line = 1;
  const ranges: [number, number][] = [];
  srcs.forEach((s, i) => {
    const body = s.endsWith("\n") ? s : s + "\n";
    const start = line;
    text += `namespace N${i} {\n` + body + "}\n";
    line += 1 + body.split("\n").length - 1 + 1;
    ranges.push([start, line - 1]);
  });
  return { text, ranges };
}

function errLines(out: string): number[] {
  const res: number[] = [];
  const re = /^p\.ts\((\d+),\d+\): error TS\d+:/gm;
  let m;
  while ((m = re.exec(out))) res.push(+m[1]);
  return res;
}

function mark(lines: number[], ranges: [number, number][]): boolean[] {
  const r = ranges.map(() => false);
  for (const l of lines) {
    const i = ranges.findIndex(([a, b]) => l >= a && l <= b);
    if (i >= 0) r[i] = true;
  }
  return r;
}

// Screens probes in batches; returns per-probe error presence on both checkers.
export async function screen(ctx: Ctx, srcs: string[]): Promise<(ScreenResult | null)[]> {
  if (srcs.length === 0) return [];
  if (Date.now() > ctx.deadline) return srcs.map(() => null);
  const { text, ranges } = wrap(srcs);
  const [a, b] = await Promise.all([
    ctx.pool.run(() => runChecker(ctx.ref, text, ctx.screenTimeout)),
    ctx.pool.run(() => runChecker(ctx.nat, text, ctx.screenTimeout)),
  ]);
  const ok = (c: Outcome) => c === "accept" || c === "reject";
  if (!ok(a.cls) || !ok(b.cls)) {
    if (srcs.length === 1) return [{ refErr: a.cls !== "accept", natErr: b.cls !== "accept", natOdd: !ok(b.cls) || !ok(a.cls) }];
    const mid = srcs.length >> 1;
    const [l, r] = await Promise.all([screen(ctx, srcs.slice(0, mid)), screen(ctx, srcs.slice(mid))]);
    return [...l, ...r];
  }
  const ra = mark(errLines(a.out), ranges), rb = mark(errLines(b.out), ranges);
  return srcs.map((_, i) => ({ refErr: ra[i], natErr: rb[i], natOdd: false }));
}

export interface Measure { ref: Outcome; nat: Outcome; }

export async function measure(ctx: Ctx, src: string): Promise<Measure> {
  const [a, b] = await Promise.all([
    ctx.pool.run(() => runChecker(ctx.ref, src)),
    ctx.pool.run(() => runChecker(ctx.nat, src)),
  ]);
  return { ref: a.cls, nat: b.cls };
}

// Measures twice; returns classes only if stable.
export async function measureStable(ctx: Ctx, src: string): Promise<Measure | null> {
  const m1 = await measure(ctx, src);
  if (m1.ref === m1.nat) return m1;
  const m2 = await measure(ctx, src);
  if (m1.ref !== m2.ref || m1.nat !== m2.nat) return null;
  return m1;
}
