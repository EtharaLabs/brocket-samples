// Family: narrowing of a destructured payload via a destructured discriminant.
import type { Family } from "./family.mts";

const PAY = ["number", "string", "boolean", "number[]", "{ v: number }", "\"x\" | \"y\""];
const PAYVAL = ["0", "\"\"", "false", "[]", "{ v: 0 }", "\"x\""];

export const destr: Family = {
  name: "destructured-discriminant",
  dims: {
    disc: ["str", "num", "bool", "enum", "strenum", "nullish", "mixed", "errTuple", "optionalDisc"],
    members: ["2", "3"],
    shape: ["object", "tuple", "objextra"],
    decl: ["alias", "interfaces", "inline"],
    bind: ["constParam", "paramDestr", "arrowParamDestr", "ctxParamDestr", "restTuple", "ctxRest",
      "topConst", "fromCall", "forOf", "generic", "letBind", "nested", "withDefault", "methodParam", "paramAssigned", "ctxGenericCall"],
    names: ["plain", "renamed"],
    check: ["ifEq", "ifElse", "neqReturn", "switch", "ternary", "and", "reversed", "closure", "looseEq", "switchDefault", "truthy", "nestedIf", "aliasedCond", "switchTrue", "neqThrow", "inOperator", "falsy"],
    use: ["assign", "call", "satisfies", "method", "parent"],
    wrong: ["no", "yes"],
    pay: ["0", "1", "2"],
  },
  render(d) {
    const two = d.disc === "bool" || d.disc === "nullish" || d.disc === "errTuple" || d.disc === "optionalDisc";
    const n = two ? 2 : +d.members;
    const tuple = d.shape === "tuple";
    if ((d.bind === "restTuple" || d.bind === "ctxRest") && !tuple) return null;
    if ((d.check === "truthy" || d.check === "falsy") && !two) return null;
    if (d.check === "inOperator" && d.shape === "tuple") return null;
    if (d.use === "parent" && (d.bind !== "constParam" && d.bind !== "generic")) return null;
    const off = +d.pay;
    const pt = (i: number) => PAY[(i + off) % PAY.length];
    const pv = (i: number) => PAYVAL[(i + off) % PAY.length];
    let pre = "";
    let dv: string[];
    switch (d.disc) {
      case "str": dv = ["\"a\"", "\"b\"", "\"c\""]; break;
      case "num": dv = ["1", "2", "3"]; break;
      case "bool": dv = ["true", "false"]; break;
      case "enum": pre += "enum E { A, B, C }\n"; dv = ["E.A", "E.B", "E.C"]; break;
      case "strenum": pre += "enum E { A = \"a\", B = \"b\", C = \"c\" }\n"; dv = ["E.A", "E.B", "E.C"]; break;
      case "nullish": dv = ["\"a\"", "undefined"]; break;
      case "errTuple": dv = ["undefined", "Error"]; break;
      case "optionalDisc": dv = ["true", "undefined"]; break;
      default: dv = ["\"a\"", "2", "true"]; break;
    }
    dv = dv.slice(0, n);
    const K = d.names === "renamed" ? "k" : "kind";
    const P = d.names === "renamed" ? "p" : "payload";
    const kfield = (i: number) => d.disc === "optionalDisc" && i === 1 ? "kind?" : "kind";
    const memberT = (i: number) => tuple ? `[${dv[i]}, ${pt(i)}]` :
      d.shape === "objextra" ? `{ id: number; ${kfield(i)}: ${dv[i]}; payload: ${pt(i)} }` : `{ ${kfield(i)}: ${dv[i]}; payload: ${pt(i)} }`;
    let U: string;
    if (d.decl === "inline" && !d.bind.startsWith("ctx")) U = dv.map((_, i) => memberT(i)).join(" | ");
    else if (d.decl === "interfaces" && !tuple) {
      for (let i = 0; i < n; i++) pre += `interface M${i} ${memberT(i)}\n`;
      pre += `type U = ${dv.map((_, i) => "M" + i).join(" | ")};\n`;
      U = "U";
    } else {
      pre += `type U = ${dv.map((_, i) => memberT(i)).join(" | ")};\n`;
      U = "U";
    }
    let pat: string;
    if (tuple) pat = `[${K}, ${P}]`;
    else pat = d.names === "renamed" ? `{ kind: k, payload: p }` : `{ kind, payload }`;
    if (d.bind === "withDefault") pat = tuple ? `[${K}, ${P} = ${pv(0)}]` : (d.names === "renamed" ? `{ kind: k, payload: p = ${pv(0)} }` : `{ kind, payload = ${pv(0)} }`);
    // narrowing target member
    const tgt = d.check === "falsy" ? (d.disc === "errTuple" ? 0 : 1) : d.check === "truthy" && d.disc === "errTuple" ? 1 : 0;
    const wrongIdx = 1 - tgt;
    const T = d.wrong === "yes" ? pt(wrongIdx) : pt(tgt);
    let useS: string, useE: string;
    if (d.use === "assign") { useS = `const v: ${T} = ${P};`; useE = `((v: ${T}) => v)(${P})`; }
    else if (d.use === "call") { pre += `declare function take(x: ${T}): void;\n`; useS = `take(${P});`; useE = `take(${P})`; }
    else if (d.use === "satisfies") { useS = `${P} satisfies ${T};`; useE = `(${P} satisfies ${T})`; }
    else if (d.use === "method") { pre += `declare function idt<X>(x: X): X;\n`; useS = `const v: ${T} = idt(${P});`; useE = `idt<${T}>(${P})`; }
    else { const acc = tuple ? "a[1]" : "a.payload"; useS = `const v: ${T} = ${acc};`; useE = `((v: ${T}) => v)(${acc})`; }
    const d0 = dv[tgt];
    let body: string;
    const inFn = !(d.bind === "topConst" || d.bind === "forOf");
    switch (d.check) {
      case "ifEq": body = `if (${K} === ${d0}) { ${useS} }`; break;
      case "ifElse": body = `if (${K} !== ${d0}) { } else { ${useS} }`; break;
      case "neqReturn": body = `if (${K} !== ${d0}) ${inFn ? (d.bind === "forOf" ? "continue" : "return") : "throw 0"};\n  ${useS}`; break;
      case "switch": body = `switch (${K}) { case ${d0}: { ${useS} } break; case ${dv[1]}: break; }`; break;
      case "switchDefault": body = `switch (${K}) { ${dv.slice(1).map((x) => `case ${x}: break;`).join(" ")} default: { ${useS} } }`; break;
      case "ternary": body = `const r = ${K} === ${d0} ? ${useE} : null;`; break;
      case "and": body = `${K} === ${d0} && ${useE};`; break;
      case "reversed": body = `if (${d0} === ${K}) { ${useS} }`; break;
      case "closure": body = `if (${K} === ${d0}) { const g = () => { ${useS} }; g(); }`; break;
      case "looseEq": body = `if (${K} == ${d0}) { ${useS} }`; break;
      case "truthy": body = d.disc === "bool" ? `if (${K}) { ${useS} }` : `if (${K}) { ${useS} }`; break;
      case "nestedIf": body = `if (typeof ${K} !== "symbol") { if (${K} === ${d0}) { ${useS} } }`; break;
      case "aliasedCond": body = `const isT = ${K} === ${d0};\n  if (isT) { ${useS} }`; break;
      case "switchTrue": body = `switch (true) { case ${K} === ${d0}: { ${useS} } }`; break;
      case "neqThrow": body = `if (${K} !== ${d0}) throw new Error();\n  ${useS}`; break;
      case "inOperator": body = `if (${K} === ${d0} && "payload" in a) { ${useS} }`; if (d.bind !== "constParam") return null; break;
      default: body = `if (!${K}) { ${useS} }`; break;
    }
    if (d.bind === "forOf" && d.check === "neqReturn") body = `if (${K} !== ${d0}) continue;\n  ${useS}`;
    let main: string;
    switch (d.bind) {
      case "constParam": main = `function f(a: ${U}) {\n  const ${pat} = a;\n  ${body}\n}`; break;
      case "withDefault": main = `function f(a: ${U}) {\n  const ${pat} = a;\n  ${body}\n}`; break;
      case "paramDestr": main = `function f(${pat}: ${U}) {\n  ${body}\n}`; break;
      case "arrowParamDestr": main = `const f = (${pat}: ${U}) => {\n  ${body}\n};`; break;
      case "methodParam": main = `class C {\n  m(${pat}: ${U}) {\n  ${body}\n  }\n}`; break;
      case "ctxParamDestr": main = `const f: (a: ${U}) => void = (${pat}) => {\n  ${body}\n};`; break;
      case "restTuple": main = `function f(...${pat}: ${U}) {\n  ${body}\n}`; break;
      case "ctxRest": main = `type F = (...args: ${U}) => void;\nconst f: F = (${K}, ${P}) => {\n  ${body}\n};`; break;
      case "ctxGenericCall": main = tuple
        ? `declare function reg(cb: (...args: ${U}) => void): void;\nreg((${K}, ${P}) => {\n  ${body}\n});`
        : `declare function reg(cb: (a: ${U}) => void): void;\nreg((${pat}) => {\n  ${body}\n});`; break;
      case "topConst": main = `declare const a: ${U};\nconst ${pat} = a;\n${body}`; break;
      case "fromCall": main = `declare function get(): ${U};\nfunction f() {\n  const ${pat} = get();\n  ${body}\n}`; break;
      case "forOf": main = `declare const arr: (${U})[];\nfor (const ${pat} of arr) {\n  ${body}\n}`; break;
      case "generic": main = `function f<T extends ${U}>(a: T) {\n  const ${pat} = a;\n  ${body}\n}`; break;
      case "letBind": main = `function f(a: ${U}) {\n  let ${pat} = a;\n  ${body}\n}`; break;
      case "paramAssigned": main = `function f(${pat}: ${U}) {\n  ${body}\n  ${K} = ${d0};\n}`; break;
      case "nested": main = tuple ? `function f(w: { data: ${U} }) {\n  const { data: ${pat} } = w;\n  ${body}\n}`
        : `function f(w: { data: ${U} }) {\n  const { data: ${pat} } = w;\n  ${body}\n}`; break;
      default: return null;
    }
    return pre + main + "\n";
  },
};
