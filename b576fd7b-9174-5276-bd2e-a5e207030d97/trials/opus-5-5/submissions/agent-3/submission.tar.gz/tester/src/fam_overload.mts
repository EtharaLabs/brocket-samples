// Family: overload resolution (declared overloads, method overloads, intersections/unions of
// signatures, constructors) observed through the selected return type.
import type { Family } from "./family.mts";

const SETS: Record<string, { decl: string; callee: string }> = {
  prim: { decl: "declare function f(x: string): 1;\ndeclare function f(x: number): 2;", callee: "f" },
  cbParam: { decl: "declare function f(x: string, cb: (s: string) => void): 1;\ndeclare function f(x: number, cb: (n: number) => void): 2;", callee: "f" },
  genericFirst: { decl: "declare function f<T>(x: T[]): T;\ndeclare function f(x: string): 2;", callee: "f" },
  optional: { decl: "declare function f(): 1;\ndeclare function f(x?: number): 2;", callee: "f" },
  rest: { decl: "declare function f(...xs: number[]): 1;\ndeclare function f(x: string, ...rest: string[]): 2;", callee: "f" },
  objects: { decl: "declare function f(o: { a: number }): 1;\ndeclare function f(o: { b: string }): 2;", callee: "f" },
  arity: { decl: "declare function f(cb: () => void): 1;\ndeclare function f(cb: (x: number) => void): 2;", callee: "f" },
  literal: { decl: "declare function f(x: \"a\"): 1;\ndeclare function f(x: string): 2;", callee: "f" },
  genericConstr: { decl: "declare function f<T extends string>(x: T): 1;\ndeclare function f<T>(x: T): 2;", callee: "f" },
  ifaceMethod: { decl: "interface I { m(x: string): 1; m(x: number): 2; }\ndeclare const i: I;", callee: "i.m" },
  unionIfaces: { decl: "interface I { m(x: string): 1; m(x: number): 2; }\ninterface J { m(x: string): 1; m(x: boolean): 2; }\ndeclare const i: I | J;", callee: "i.m" },
  interFns: { decl: "declare const f: ((x: string) => 1) & ((x: number) => 2);", callee: "f" },
  unionFns: { decl: "declare const f: ((x: string | number) => 1) | ((x: number | boolean) => 2);", callee: "f" },
  tupleRest: { decl: "declare function f(...a: [string] | [number, number]): 1;\ndeclare function f(...a: unknown[]): 2;", callee: "f" },
  ctor: { decl: "declare class C { constructor(x: string); constructor(x: number, y?: number); tag: 1; }", callee: "new C" },
  callSigObj: { decl: "declare const f: { (x: string): 1; (x: number): 2; prop: 0 };", callee: "f" },
  genericCb: { decl: "declare function f<T>(x: T, cb: (t: T) => 1): 1;\ndeclare function f<T>(x: T, cb: (t: T) => 2): 2;", callee: "f" },
  thisParam: { decl: "declare function f(this: void, x: string): 1;\ndeclare function f(this: void, x: number): 2;", callee: "f" },
  booleanOv: { decl: "declare function f(x: true): 1;\ndeclare function f(x: false): 2;\ndeclare function f(x: boolean): 3;", callee: "f" },
  nullableOv: { decl: "declare function f(x: null): 1;\ndeclare function f(x: undefined): 2;\ndeclare function f(x: {}): 3;", callee: "f" },
  keyofOv: { decl: "declare function f<K extends \"a\" | \"b\">(k: K): K;\ndeclare function f(k: string): 2;", callee: "f" },
};
const ARGS = ["\"a\"", "1", "true", "\"a\" as string", "(Math.random() ? \"a\" : 1)", "{ a: 1 }", "{ b: \"\" }", "{ a: 1, b: \"\" }",
  "() => { }", "(x) => { }", "(x: number) => { }", "[1]", "undefined", "", "null", "1, 2", "\"a\", \"b\"", "\"a\", (s) => { }", "1, (n) => { }",
  "1, (t) => 1 as const", "\"x\", (t) => 2 as const", "false", "{}", "[\"a\"]"];
const EXP = ["1", "2", "3", "never", "string", "number", "unknown", "1 | 2", "{ tag: 1 }", "\"a\"", "boolean"];

export const overloadFam: Family = {
  name: "overload-resolution",
  dims: {
    set: Object.keys(SETS),
    arg: ARGS.map((_, i) => String(i)),
    e: EXP.map((_, i) => String(i)),
    ctx: ["none", "annot", "ret", "spread", "narrowedArg"],
  },
  labelOf(k, v) { return k === "arg" ? ARGS[+v] : k === "e" ? EXP[+v] : v; },
  render(d) {
    const s = SETS[d.set];
    const a = ARGS[+d.arg], E = EXP[+d.e];
    let call: string, pre = "";
    if (d.ctx === "spread") { if (!a) return null; call = `${s.callee}(...[${a}] as const)`; }
    else if (d.ctx === "narrowedArg") {
      if (!a || a.includes(",")) return null;
      pre = `declare const u: string | number | boolean | null | undefined | object;\n`;
      call = `(typeof u === typeof (${a}) ? ${s.callee}(u as any as typeof ${a.startsWith("(") || a.startsWith("{") || a.startsWith("[") ? `__v` : `__v`}) : 0)`;
      pre += `const __v = ${a};\n`;
      call = `${s.callee}(__v)`;
    } else call = `${s.callee}(${a})`;
    let use: string;
    switch (d.ctx) {
      case "annot": use = `const r: ${E} = ${call};`; break;
      case "ret": use = `function g(): ${E} {\n  return ${call};\n}`; break;
      default: use = `const r = ${call};\nconst c: ${E} = r;`; break;
    }
    return `${s.decl}\n${pre}${use}\n`;
  },
};
