// Family: generic inference from arguments and contextual types.
import type { Family } from "./family.mts";

const VALS = ["1", "\"a\"", "true", "{ a: 1 }", "[1, 2]", "() => 1", "null", "undefined", "(Math.random() ? 1 : \"a\")",
  "{ a: \"x\", b: 2 }", "(x: number) => x", "1n", "Symbol()", "{ a: 1, f() { return 1; } }", "[] as string[]"];
const TYPES = ["number", "string", "1", "\"a\"", "number | string", "{ a: number }", "unknown", "never", "number[]",
  "() => number", "boolean", "{}", "object", "string | undefined", "null", "readonly number[]", "[number, number]",
  "{ a: string; b: number }", "(x: number) => number", "\"a\" | 1", "true", "bigint", "symbol", "undefined"];

interface Sc { decl: string; call: (a: string, b: string) => string; }
const SC: Record<string, Sc> = {
  id: { decl: "declare function f<T>(x: T): T;", call: (a) => `f(${a})` },
  arr: { decl: "declare function f<T>(x: T[]): T;", call: (a, b) => `f([${a}, ${b}])` },
  pair: { decl: "declare function f<T>(a: T, b: T): T;", call: (a, b) => `f(${a}, ${b})` },
  thunk: { decl: "declare function f<T>(g: () => T): T;", call: (a) => `f(() => (${a}))` },
  cb: { decl: "declare function f<T>(x: T, g: (t: T) => void): T;", call: (a) => `f(${a}, (t) => {\n  const o: unknown = t;\n})` },
  cbRet: { decl: "declare function f<T, U>(x: T, g: (t: T) => U): U;", call: (a) => `f(${a}, (t) => t)` },
  cbFirst: { decl: "declare function f<T>(g: (t: T) => void, x: T): T;", call: (a) => `f((t) => {\n  const o: unknown = t;\n}, ${a})` },
  constT: { decl: "declare function f<const T>(x: T): T;", call: (a) => `f(${a})` },
  constArr: { decl: "declare function f<const T extends readonly unknown[]>(x: T): T[number];", call: (a, b) => `f([${a}, ${b}])` },
  constrained: { decl: "declare function f<T extends string | number>(x: T): T;", call: (a) => `f(${a})` },
  keyof: { decl: "declare function f<T, K extends keyof T>(o: T, k: K): T[K];", call: (a, b) => `f({ a: ${a}, b: ${b} }, "a")` },
  mappedRev: { decl: "declare function f<T>(o: { [K in keyof T]: () => T[K] }): T[keyof T];", call: (a, b) => `f({ a: () => (${a}), b: () => (${b}) })` },
  mappedBox: { decl: "declare function f<T>(o: { [K in keyof T]: { get(): T[K] } }): T[\"a\" & keyof T];", call: (a, b) => `f({ a: { get: () => (${a}) }, b: { get() { return ${b}; } } })` },
  mappedHomo: { decl: "declare function f<T>(o: { readonly [K in keyof T]: T[K] }): T;", call: (a, b) => `f({ a: ${a}, b: ${b} }).a` },
  mappedKeys: { decl: "declare function f<K extends string, V>(o: { [P in K]: V }): V;", call: (a, b) => `f({ a: ${a}, b: ${b} })` },
  record: { decl: "declare function f<K extends PropertyKey, V>(o: Record<K, V>): V;", call: (a, b) => `f({ x: ${a}, y: ${b} })` },
  union: { decl: "declare function f<T>(x: T | undefined): T;", call: (a) => `f(${a})` },
  unionArr: { decl: "declare function f<T>(x: T | T[]): T;", call: (a) => `f(${a})` },
  unionFn: { decl: "declare function f<T>(x: T | (() => T)): T;", call: (a) => `f(${a})` },
  inter: { decl: "declare function f<T>(x: T & {}): T;", call: (a) => `f(${a})` },
  interObj: { decl: "declare function f<T>(x: T & { a: unknown }): T;", call: (a) => `f({ a: ${a} })` },
  cond: { decl: "declare function f<T>(x: T): T extends string ? \"s\" : T extends number ? 1 : T;", call: (a) => `f(${a})` },
  condDist: { decl: "type W<T> = T extends unknown ? { w: T } : never;\ndeclare function f<T>(x: W<T>): T;", call: (a) => `f({ w: ${a} })` },
  inferArr: { decl: "declare function f<T>(x: T): T extends readonly (infer U)[] ? U : never;", call: (a, b) => `f([${a}, ${b}])` },
  inferFn: { decl: "declare function f<T>(x: T): T extends (...a: any[]) => infer R ? R : never;", call: (a) => `f(() => (${a}))` },
  promise: { decl: "declare function f<T>(x: Promise<T> | T): T;", call: (a) => `f(Promise.resolve(${a}))` },
  noInfer: { decl: "declare function f<T>(a: T, b: NoInfer<T>): T;", call: (a, b) => `f(${a}, ${b})` },
  noInferArr: { decl: "declare function f<T>(a: T[], b: NoInfer<T>): T;", call: (a, b) => `f([${a}], ${b})` },
  callableOv: { decl: "declare const ov: { (x: string): number; (x: number): string };\ndeclare function f<A, R>(g: (a: A) => R, x: unknown): A | R;", call: (a) => `f(ov, ${a})` },
  callableObj: { decl: "declare function f<T>(g: { (): T; extra: number }): T;", call: (a) => `f(Object.assign(() => (${a}), { extra: 1 }))` },
  ctxReturn: { decl: "declare function f<T>(): T;", call: () => `f()` },
  ctxReturnArg: { decl: "declare function f<T>(x?: T): T;", call: (a) => `f(${a})` },
  ctxRest: { decl: "declare function f<T>(...xs: T[]): T;", call: (a, b) => `f(${a}, ${b})` },
  partial: { decl: "declare function f<T>(x: Partial<T>): T;", call: (a) => `f({ a: ${a} })` },
  tupleRest: { decl: "declare function f<T extends unknown[]>(...xs: T): T[0];", call: (a, b) => `f(${a}, ${b})` },
  methodObj: { decl: "declare function f<T>(o: { v: T; m(t: T): void }): T;", call: (a) => `f({ v: ${a}, m(t) {\n  const o: unknown = t;\n} })` },
  makeUse: { decl: "declare function f<T>(o: { make: () => T; use: (t: T) => void }): T;", call: (a) => `f({ make: () => (${a}), use: (t) => {\n  const o: unknown = t;\n} })` },
  useMake: { decl: "declare function f<T>(o: { use: (t: T) => void; make: () => T }): T;", call: (a) => `f({ use: (t) => {\n  const o: unknown = t;\n}, make: () => (${a}) })` },
  makeUseMethod: { decl: "declare function f<T>(o: { make(): T; use(t: T): void }): T;", call: (a) => `f({ make() { return ${a}; }, use(t) {\n  const o: unknown = t;\n} })` },
  readonlyArr: { decl: "declare function f<T>(x: readonly T[]): T;", call: (a, b) => `f([${a}, ${b}] as const)` },
  curried: { decl: "declare function f<T>(x: T): <U>(y: U) => T | U;", call: (a, b) => `f(${a})(${b})` },
  higherOrder: { decl: "declare function idf<X>(x: X): X;\ndeclare function f<A, B>(g: (a: A) => B, a: A): B;", call: (a) => `f(idf, ${a})` },
  pipe: { decl: "declare function f<A, B, C>(ab: (a: A) => B, bc: (b: B) => C): (a: A) => C;", call: (a) => `f((a: number) => [a, ${a}] as const, (b) => b[1])(0)` },
  interSigs: { decl: "declare function f<T>(g: ((x: T) => void) & ((x: string) => void)): T;", call: (a) => `f((x: ${a === "1" ? "number" : "unknown"}) => { })` },
  thisParam: { decl: "declare function f<T>(o: T & ThisType<T>): T;", call: (a) => `f({ v: ${a}, m() { return this.v; } }).v` },
  defaultTP: { decl: "declare function f<T = string>(x?: T): T;", call: (a) => `f(${a})` },
  tplLit: { decl: "declare function f<T extends string>(x: `pre-${T}`): T;", call: () => `f(\"pre-ab\")` },
  arrayFrom: { decl: "", call: (a, b) => `[${a}, ${b}].map((x) => x)[0]` },
  reduce: { decl: "", call: (a, b) => `[${a}].reduce((acc, x) => acc, ${b})` },
  genericClass: { decl: "declare class Box<T> { constructor(x: T); get(): T; }", call: (a) => `new Box(${a}).get()` },
  ovTarget2: { decl: "declare const ov: { (x: string): number; (x: number): string };\ndeclare function f<A, B, R, S>(g: { (x: A): R; (y: B): S }): [A, B, R, S];", call: () => `f(ov)[0]` },
  ovTarget2b: { decl: "declare const ov: { (x: string): number; (x: number): string; (x: boolean): null };\ndeclare function f<A, B, R, S>(g: { (x: A): R; (y: B): S }): [A, B, R, S];", call: () => `f(ov)[1]` },
  ovRet: { decl: "declare const ov: { (x: string): number; (x: number): string };\ndeclare function f<R>(g: (x: never) => R): R;", call: () => `f(ov)` },
  ovMethod: { decl: "declare const om: { m(x: string): \"s\"; m(x: number): \"n\" };\ndeclare function f<A, R>(o: { m(x: A): R }): [A, R];", call: () => `f(om)[1]` },
  ovGenericSrc: { decl: "declare function g<X>(x: X): X[];\ndeclare function f<A, R>(fn: (a: A) => R, a: A): R;", call: (a) => `f(g, ${a})` },
  pickKeys: { decl: "declare function f<T, K extends keyof T>(o: T, ...ks: K[]): Pick<T, K>;", call: (a, b) => `f({ a: ${a}, b: ${b} }, \"a\").a` },
  mappedAs: { decl: "declare function f<T>(o: { [K in keyof T as `get_${K & string}`]: () => T[K] }): T;", call: (a) => `f({ get_a: () => (${a}) })` },
  mappedOptional: { decl: "declare function f<T>(o: { [K in keyof T]?: T[K] }): T;", call: (a, b) => `f({ a: ${a}, b: ${b} }).a` },
  keyInfer: { decl: "declare function f<K extends string>(o: { [P in K]: unknown }): K;", call: (a, b) => `f({ a: ${a}, b: ${b} })` },
  keyInferRecord: { decl: "declare function f<K extends PropertyKey, V>(keys: K[], o: Record<K, V>): V;", call: (a, b) => `f([\"a\"], { a: ${a} })` },
  reverseTuple: { decl: "interface Bx<X> { v: X }\ndeclare function f<T extends unknown[]>(x: { [K in keyof T]: Bx<T[K]> }): T[0];", call: (a, b) => `f([{ v: ${a} }, { v: ${b} }])` },
  reverseNested: { decl: "declare function f<T>(o: { [K in keyof T]: { in: (x: T[K]) => void; out: () => T[K] } }): T[keyof T];", call: (a) => `f({ a: { in: (x) => {\n  const o: unknown = x;\n}, out: () => (${a}) } })` },
  interTwo: { decl: "declare function f<T, U>(x: T & U): [T, U];", call: (a) => `f(${a})[0]` },
  interFnObj: { decl: "declare function f<T>(x: ((a: T) => void) & { tag: T }): T;", call: (a) => `f(Object.assign((a: unknown) => { }, { tag: ${a} }))` },
  unionPriority: { decl: "declare function f<T>(x: T | string, y: T): T;", call: (a, b) => `f(${a}, ${b})` },
  unionDiscrim: { decl: "declare function f<T>(x: { k: 1; v: T } | { k: 2; w: T }): T;", call: (a) => `f({ k: 2, w: ${a} })` },
  condInfer2: { decl: "type El<X> = X extends readonly (infer E)[] ? E : X extends Promise<infer P> ? P : never;\ndeclare function f<T>(x: T): El<T>;", call: (a) => `f(Promise.resolve(${a}))` },
  condParam: { decl: "declare function f<T>(x: T extends string ? { s: T } : { o: T }): T;", call: (a) => `f({ o: ${a} })` },
  mappedUnionKeys: { decl: "declare function f<K1 extends string, K2 extends string, V>(o: { [P in K1 | K2]: V }): [K1, K2, V];", call: (a, b) => `f({ a: ${a}, b: ${b} })` },
  mappedKeyofUnion: { decl: "declare function f<A, B>(o: { [P in keyof A | keyof B]: unknown }): [A, B];", call: (a, b) => `f({ a: ${a}, b: ${b} })` },
  mappedKeyPlusLit: { decl: "declare function f<K extends string, V>(o: { [P in K | \"z\"]: V }): [K, V];", call: (a, b) => `f({ a: ${a}, z: ${b} })` },
  mappedKeyInter: { decl: "declare function f<K extends string, V>(o: { [P in K & string]: V }): [K, V];", call: (a, b) => `f({ a: ${a}, b: ${b} })` },
  mappedTwoHomo: { decl: "declare function f<T, U>(o: { [P in keyof T]: T[P] } & { [P in keyof U]: U[P] }): [T, U];", call: (a, b) => `f({ a: ${a}, b: ${b} })` },
  methodBivar: { decl: "declare function f<T>(o: { m(x: T): void; v: T }): T;", call: (a) => `f({ m(x: unknown) { }, v: ${a} })` },
  propFnContra: { decl: "declare function f<T>(o: { m: (x: T) => void; v: T }): T;", call: (a) => `f({ m: (x: unknown) => { }, v: ${a} })` },
  indexFromOptional: { decl: "declare function f<V>(o: { [k: string]: V }): V;\ndeclare function mk<X>(x: X): { a?: X; b: X };", call: (a) => `f(mk(${a}))` },
  recordFromPartial: { decl: "declare function f<V>(o: Record<string, V>): V;\ndeclare function mk<X>(x: X): Partial<X>;", call: (a, b) => `f(mk({ a: ${a}, b: ${b} }))` },
  unionNamedBox: { decl: "interface Bx<X> { v: X }\ndeclare function f<T>(x: T | Bx<T>): T;\ndeclare function mk<A, B>(a: A, b: B): Bx<A> | B;", call: (a, b) => `f(mk(${a}, ${b}))` },
  unionNamedArr: { decl: "declare function f<T>(x: T | ReadonlyArray<T>): T;\ndeclare function mk<A, B>(a: A, b: B): readonly A[] | B;", call: (a, b) => `f(mk(${a}, ${b}))` },
  unionAliasBox: { decl: "type Bx<X> = { v: X };\ndeclare function f<T>(x: T | Bx<T> | undefined): T;\ndeclare function mk<A, B>(a: A, b: B): Bx<A> | B;", call: (a, b) => `f(mk(${a}, ${b}))` },
  unionTwoNamed: { decl: "interface Bx<X> { v: X }\ninterface Cx<X> { c: X }\ndeclare function f<T>(x: Bx<T> | Cx<T>): T;\ndeclare function mk<A, B>(a: A, b: B): Bx<A> | Cx<B>;", call: (a, b) => `f(mk(${a}, ${b}))` },
  constraintRet: { decl: "declare function f<T extends { a: unknown }>(x: T): T[\"a\"];", call: (a) => `f({ a: ${a} })` },
  constraintCtx: { decl: "declare function f<T extends (x: number) => unknown>(g: T): ReturnType<T>;", call: (a) => `f((x) => (${a}))` },
  annotatedCb: { decl: "declare function f<T>(g: (x: T) => void): T;", call: (a) => `f((x: ${a === "1" ? "number" : "string"}) => { })` },
  intraExpr: { decl: "declare function f<T>(o: { produce: (n: number) => T; consume: (x: T) => void }): T;", call: (a) => `f({ produce: (n) => (${a}), consume: (x) => {\n  const o: unknown = x;\n} })` },
  intraExprMethod: { decl: "declare function f<T>(o: { produce(n: number): T; consume(x: T): void }): T;", call: (a) => `f({ produce: (n) => (${a}), consume(x) {\n  const o: unknown = x;\n} })` },
  ctxRetBox: { decl: "interface Bx<X> { v: X }\ndeclare function f<T>(): Bx<T>;", call: () => `f().v` },
  ctxRetFn: { decl: "declare function f<T>(): (x: T) => T;", call: () => `f()(1 as any)` },
  asyncRet: { decl: "declare function f<T>(x: T): Promise<T>;", call: (a) => `(async () => await f(${a}))()` },
  genericCallableMember: { decl: "interface Ev<T> { on(cb: (t: T) => void): void; (x: T): void }\ndeclare function f<T>(e: Ev<T>): T;\ndeclare const ev: Ev<\"evt\">;", call: () => `f(ev)` },
  thisTypeArg: { decl: "declare function f<T>(this: T, x: unknown): T;\ndeclare const o: { f: typeof f; tag: 1 };", call: () => `o.f(0).tag` },
  spreadTuple: { decl: "declare function f<A extends unknown[], R>(g: (...a: A) => R, ...a: A): R;", call: (a) => `f((x: number, y: string) => (${a}), 1, \"y\")` },
  variadic: { decl: "declare function f<T extends unknown[]>(...xs: [...T, number]): T;", call: (a, b) => `f(${a}, ${b}, 1)[0]` },
  defaultInferred: { decl: "declare function f<T, U = T[]>(x: T, y?: U): U;", call: (a) => `f(${a})` },
  overloadPick: { decl: "declare function f<T extends string>(x: T): [T];\ndeclare function f<T>(x: T): T;", call: (a) => `f(${a})` },
};

export const inferFam: Family = {
  name: "generic-inference",
  labelOf(k, v) { return k === "a" || k === "b" ? VALS[+v] : k === "e" ? TYPES[+v] : v; },
  dims: {
    sc: Object.keys(SC),
    a: VALS.map((_, i) => String(i)),
    b: VALS.map((_, i) => String(i)),
    e: TYPES.map((_, i) => String(i)),
    ctx: ["none", "annot", "ret", "arg", "satisfies", "arrowRet"],
  },
  render(d) {
    const sc = SC[d.sc];
    const a = VALS[+d.a], b = VALS[+d.b], E = TYPES[+d.e];
    const call = sc.call(a, b);
    let use: string;
    switch (d.ctx) {
      case "none": use = `const r = ${call};\nconst c: ${E} = r;`; break;
      case "annot": use = `const r: ${E} = ${call};`; break;
      case "ret": use = `function g(): ${E} {\n  return ${call};\n}`; break;
      case "arg": use = `declare function take(x: ${E}): void;\ntake(${call});`; break;
      case "satisfies": use = `const r = ${call} satisfies ${E};`; break;
      default: use = `const g: () => ${E} = () => ${call};`; break;
    }
    return (sc.decl ? sc.decl + "\n" : "") + use + "\n";
  },
};
