// Family: inference of type arguments from the contextual type of a call's return position, combined
// with (or without) argument inferences, across contextual positions and return-type shapes.
import type { Family } from "./family.mts";

const RET: Record<string, string> = {
  box: "Box<T>", bare: "T", arr: "T[]", promise: "Promise<T>", fnParam: "(x: T) => void", orUndef: "T | undefined", obj: "{ a: T }",
  roArr: "readonly T[]", set: "Set<T>", pair: "[T, T]", thunk: "() => T", inter: "Box<T> & { z: 0 }", union2: "Box<T> | null", cond: "T extends string ? Box<T> : Box<T>",
};
const PARAM: Record<string, [string, (l: string) => string]> = {
  none: ["", () => ""],
  opt: ["x?: T", (l) => l],
  plain: ["x: T", (l) => l],
  noArg: ["x?: T", () => ""],
  cb: ["cb: (x: T) => void", () => "(x) => {\n  const o: unknown = x;\n}"],
  box: ["b: Box<T>", (l) => `{ v: ${l} }`],
  arr: ["xs: T[]", (l) => `[${l}]`],
  thunk: ["g: () => T", (l) => `() => ${l}`],
  noInfer: ["x: NoInfer<T>", (l) => l],
};
const CTX = ["string", "\"a\" | \"b\"", "number", "unknown", "{ p: 1 }", "string | number", "1 | 2", "boolean", "\"a\"", "object", "{ p: number; q?: string }", "never[]", "<U>(x: U) => U", "(x: string) => string"];
const LIT = ["\"a\"", "1", "true", "{ p: 1 }", "null", "\"c\""];

export const retCtxFam: Family = {
  name: "return-context-inference",
  dims: {
    ret: Object.keys(RET),
    param: Object.keys(PARAM),
    ctx: CTX.map((_, i) => String(i)),
    lit: LIT.map((_, i) => String(i)),
    pos: ["annot", "return", "arg", "prop", "arrayElem", "ternary", "paren", "assertion", "satisfies", "asyncReturn", "arrowBody", "defaultValue", "assignment", "genericArg", "destrArr", "destrObj", "destrArrDefault"],
    tp: ["plain", "constrained", "const", "default", "twoParams"],
  },
  render(d) {
    const [p, argOf] = PARAM[d.param];
    const C = CTX[+d.ctx];
    let tps = "T";
    switch (d.tp) {
      case "constrained": tps = "T extends string | number | boolean | object | null"; break;
      case "const": tps = "const T"; break;
      case "default": tps = "T = number"; break;
      case "twoParams": tps = "T, U = T"; break;
    }
    const R = RET[d.ret];
    const RC = R.replace(/\bT\b/g, `(${C})`);
    const call = `f(${argOf(LIT[+d.lit])})`;
    const pre = `interface Box<X> { v: X }\ndeclare function f<${tps}>(${p}): ${R};\n`;
    switch (d.pos) {
      case "return": return `${pre}function g(): ${RC} {\n  return ${call};\n}\n`;
      case "arg": return `${pre}declare function use(x: ${RC}): void;\nuse(${call});\n`;
      case "prop": return `${pre}const o: { k: ${RC} } = { k: ${call} };\n`;
      case "arrayElem": return `${pre}const a: (${RC})[] = [${call}];\n`;
      case "ternary": return `${pre}declare const c: boolean;\nconst r: ${RC} = c ? ${call} : ${call};\n`;
      case "paren": return `${pre}const r: ${RC} = (${call});\n`;
      case "assertion": return `${pre}const r = <${RC}>${call};\n`;
      case "satisfies": return `${pre}const r = ${call} satisfies ${RC};\n`;
      case "asyncReturn": return `${pre}async function g(): Promise<${RC}> {\n  return ${call};\n}\n`;
      case "arrowBody": return `${pre}const g: () => ${RC} = () => ${call};\n`;
      case "defaultValue": return `${pre}function g(x: ${RC} = ${call}) { }\n`;
      case "assignment": return `${pre}let r: ${RC};\nr = ${call};\n`;
      case "genericArg": return `${pre}declare function use<Q extends ${RC}>(x: Q): Q;\nuse(${call});\n`;
      case "destrArr": return `${pre}const [r]: [${RC}] = [${call}];\nconst [s] = ${call};\nconst t: ${C} = s;\n`;
      case "destrObj": return `${pre}const { v: r }: { v: ${RC} } = { v: ${call} };\nconst { v: s } = ${call};\nconst t: ${C} = s;\n`;
      case "destrArrDefault": return `${pre}const [s = ${LIT[+d.lit]}] = ${call};\nconst t: ${C} = s;\n`;
      default: return `${pre}const r: ${RC} = ${call};\n`;
    }
  },
};
