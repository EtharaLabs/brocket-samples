import type { Family } from "./family.mts";
import { destr } from "./fam_destr.mts";
import { assertFam } from "./fam_assert.mts";
import { inferFam } from "./fam_infer.mts";
export const FAMILIES: Family[] = [destr, assertFam, inferFam];
