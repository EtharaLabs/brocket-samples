// Family: relations involving private/protected/#private members, which relate by originating
// declaration rather than by member name.
import type { Family } from "./family.mts";

const MEM: Record<string, string> = {
  private: "private x: number = 0;",
  protected: "protected x: number = 0;",
  hash: "#x: number = 0;",
  public: "x: number = 0;",
  privateMethod: "private m(): void { }",
  protectedMethod: "protected m(): void { }",
  privateOpt: "private x?: number;",
  privateGeneric: "private x!: T;",
  protectedGeneric: "protected x!: T;",
  hashGeneric: "#x!: T;",
  privateStatic: "private static s = 0;",
  privateCtor: "private constructor() { }",
  protectedCtor: "protected constructor() { }",
  privateAccessor: "private get x(): number { return 0; }",
};

export const privFam: Family = {
  name: "private-member-relation",
  dims: {
    sm: Object.keys(MEM),
    tm: ["same", ...Object.keys(MEM)],
    shape: ["twoClasses", "derived", "sameClassGeneric", "twin", "interfaceExtendsClass", "base2Derived", "objectLiteral", "sameNameScopes", "derivedOverride", "mixin"],
    rel: ["instance", "ctorType", "array", "union", "argument", "generic", "keyof", "fnParam"],
    extra: ["none", "commonPublic", "srcExtra"],
  },
  render(d) {
    const smv = MEM[d.sm], tmv = d.tm === "same" ? smv : MEM[d.tm];
    const generic = /\bT\b/.test(smv) || /\bT\b/.test(tmv);
    const tp = generic ? "<T>" : "";
    const ex = d.extra === "none" ? "" : " y: string = \"\";";
    const sex = d.extra === "srcExtra" ? " z = 1;" : "";
    const sArg = generic ? "<string>" : "", tArg = generic ? (d.shape === "sameClassGeneric" ? "<number>" : "<string>") : "";
    let pre: string, S: string, Tn: string;
    switch (d.shape) {
      case "twoClasses": pre = `class A${tp} { ${smv}${ex}${sex} }\nclass B${tp} { ${tmv}${ex} }\n`; S = `A${sArg}`; Tn = `B${tArg}`; break;
      case "derived": if (/constructor/.test(smv)) return null; pre = `class B${tp} { ${tmv}${ex} }\nclass A${tp} extends B${tp} {${sex} }\n`; S = `A${sArg}`; Tn = `B${tArg}`; break;
      case "sameClassGeneric": if (!generic) return null; pre = `class A<T> { ${smv}${ex} }\n`; S = "A<string>"; Tn = "A<number>"; break;
      case "twin": pre = `class A${tp} { ${smv}${ex}${sex} }\nclass B${tp} { ${smv}${ex} }\n`; S = `A${sArg}`; Tn = `B${tArg}`; break;
      case "interfaceExtendsClass": if (/constructor|static/.test(tmv)) return null; pre = `class B${tp} { ${tmv}${ex} }\ninterface I${tp} extends B${tp} { }\nclass A${tp} { ${smv}${ex}${sex} }\n`; S = `A${sArg}`; Tn = `I${tArg}`; break;
      case "base2Derived": if (/constructor/.test(tmv)) return null; pre = `class Base${tp} { ${tmv}${ex} }\nclass A${tp} extends Base${tp} {${sex} }\nclass B${tp} extends Base${tp} { w = 0; }\n`; S = `A${sArg}`; Tn = `B${tArg}`; break;
      case "objectLiteral": if (/constructor|static|#/.test(tmv)) return null; pre = `class B${tp} { ${tmv}${ex} }\n`; S = `{ x: ${generic ? "string" : "number"}; m(): void;${ex ? " y: string;" : ""} }`; Tn = `B${tArg}`; break;
      case "sameNameScopes": pre = `namespace N1 { export class C${tp} { ${smv}${ex}${sex} } }\nnamespace N2 { export class C${tp} { ${tmv}${ex} } }\n`; S = `N1.C${sArg}`; Tn = `N2.C${tArg}`; break;
      case "derivedOverride": if (/constructor|static|#|private/.test(tmv) || /constructor|static|#/.test(smv)) return null; pre = `class B${tp} { ${tmv}${ex} }\nclass A${tp} extends B${tp} { ${smv.replace(/^private /, "protected ")}${sex} }\n`; S = `A${sArg}`; Tn = `B${tArg}`; break;
      default: if (/constructor/.test(smv + tmv)) return null; pre = `type Ctor = new (...a: any[]) => object;\nfunction Mix<K extends Ctor>(k: K) {\n  return class extends k { ${smv.replace(/\bT\b/g, "unknown")} };\n}\nclass B0 { }\nconst A = Mix(B0);\nconst B = Mix(B0);\n`; S = "InstanceType<typeof A>"; Tn = "InstanceType<typeof B>"; if (generic) return null; break;
    }
    if (d.rel === "ctorType" && d.shape === "mixin") { S = "typeof A"; Tn = "typeof B"; }
    else if (d.rel === "ctorType") {
      if (d.shape === "objectLiteral" || d.shape === "interfaceExtendsClass" || d.shape === "sameClassGeneric") return null;
      const cls = (x: string) => x.replace(/<.*>$/, "");
      S = `typeof ${cls(S)}`; Tn = `typeof ${cls(Tn)}`;
    }
    let use: string;
    switch (d.rel) {
      case "array": use = `declare const s: ${S}[];\nconst t: readonly ${Tn}[] = s;`; break;
      case "union": use = `declare const s: ${S} | null;\nconst t: ${Tn} | null | undefined = s;`; break;
      case "argument": use = `declare function take(t: ${Tn}): void;\ndeclare const s: ${S};\ntake(s);`; break;
      case "generic": use = `function g<X extends ${S}>(x: X): ${Tn} {\n  return x;\n}`; break;
      case "keyof": use = `declare const s: keyof ${S};\nconst t: keyof ${Tn} = s;`; break;
      case "fnParam": use = `declare const s: (x: ${Tn}) => void;\nconst t: (x: ${S}) => void = s;`; break;
      default: use = `declare const s: ${S};\nconst t: ${Tn} = s;`; break;
    }
    // (anonymous class types print differently between implementations: not observed)
    if (d.shape === "mixin") use = use.replace(/= s;/, "= (s);");
    return pre + use + "\n";
  },
};
