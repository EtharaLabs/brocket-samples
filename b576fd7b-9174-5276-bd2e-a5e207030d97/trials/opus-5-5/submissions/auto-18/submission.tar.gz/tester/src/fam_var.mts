// Family: relations between instantiations of the same generic declaration (variance shortcuts vs
// member-wise structural comparison).
import type { Family } from "./family.mts";

// position of T inside the declaration body (members)
const POS: Record<string, string> = {
  prop: "v: T",
  roProp: "readonly v: T",
  optProp: "v?: T",
  method: "m(x: T): void",
  fnProp: "f: (x: T) => void",
  ret: "g(): T",
  both: "v: T; f: (x: T) => void",
  cbParam: "h(cb: (x: T) => void): void",
  cbCb: "k: (cb: (cb2: (x: T) => void) => void) => void",
  arr: "a: T[]",
  roArr: "a: readonly T[]",
  index: "[key: string]: T",
  keyofT: "k: keyof T",
  mapped: "p: { [K in keyof T]: T[K] }",
  cond: "c: T extends string ? 1 : 0",
  condBoth: "c: T extends string ? T : never",
  tuple: "t: [T, number]",
  promise: "p: Promise<T>",
  unused: "n: number",
  setter: "set s(x: T)",
  getterSetter: "get s(): T; set s(x: T)",
  fnRetFn: "q: () => () => T",
  recursive: "v: T; next: G<T> | null",
  wrapped: "w: { inner: T }",
  record: "r: Record<string, T>",
  methodGeneric: "mg<U extends T>(x: U): U",
  ctorParam: "ctor: new (x: T) => object",
  thisTyped: "self(): this; v: T",
};
// [A, B] pairs: relation G<A> -> G<B>
const PAIRS: [string, string][] = [
  ["\"a\"", "string"], ["string", "\"a\""], ["string", "number"], ["{ x: number; y: string }", "{ x: number }"], ["{ x: number }", "{ x: number; y: string }"],
  ["never", "string"], ["string", "unknown"], ["unknown", "string"], ["any", "string"], ["string", "string | number"], ["string | number", "string"],
  ["{ x: 1 }", "{ x: number }"], ["() => void", "(x: number) => void"], ["(x: number) => void", "() => void"], ["string[]", "readonly string[]"], ["readonly string[]", "string[]"],
  ["{ a?: number }", "{ a: number }"], ["{ a: number }", "{ a?: number }"], ["null", "string"], ["undefined", "void"],
];

export const varFam: Family = {
  name: "instantiation-relation",
  dims: {
    pos: Object.keys(POS),
    pair: PAIRS.map((_, i) => String(i)),
    decl: ["interface", "alias", "class", "aliasIntersection", "interfaceExtends", "classImplements", "aliasUnion", "constrained"],
    ctx: ["assign", "twoWay", "reverseFirst", "argument", "returned", "genericFn", "nested", "array", "structuralFirst", "otherPairFirst", "unionTarget", "inferred", "toBase", "pickWrap", "partialWrap", "omitWrap", "spreadCopy", "readonlyWrap", "crossDecl", "crossDeclTwice"],
  },
  labelOf(k, v) { return k === "pair" ? PAIRS[+v].join(" -> ") : v; },
  render(d) {
    const body = POS[d.pos];
    let [A, B] = PAIRS[+d.pair];
    if (d.pos === "keyofT" || d.pos === "mapped") { if (/=>/.test(A + B) || /^(?:never|null|undefined|any|unknown)$/.test(A) || /^(?:never|null|undefined|any|unknown)$/.test(B)) return null; }
    const isClass = d.decl === "class" || d.decl === "classImplements";
    if (isClass && d.pos === "index") return null;
    const clsBody = () => body.split("; ").map((m) => {
      if (/^(?:get|set) /.test(m)) return m.startsWith("get") ? `${m} { return null!; }` : `${m} { }`;
      if (/^\w+(?:<[^>]*>)?\(/.test(m)) return `${m} { return null!; }`.replace(/: void \{ return null!; \}/, ": void { }");
      if (m.startsWith("[")) return m;
      return `declare ${m}`;
    }).join("\n  ");
    let decl: string;
    switch (d.decl) {
      case "interface": decl = `interface G<T> { ${body} }`; break;
      case "alias": decl = `type G<T> = { ${body} };`; break;
      case "class": decl = `class G<T> {\n  ${clsBody()}\n}`; break;
      case "aliasIntersection": decl = `type G<T> = { ${body} } & { tag: 0 };`; break;
      case "interfaceExtends": decl = `interface Base<T> { ${body} }\ninterface G<T> extends Base<T> { tag: 0 }`; break;
      case "classImplements": decl = `interface Base<T> { ${body} }\nclass G<T> implements Base<T> {\n  ${clsBody()}\n}`; break;
      case "aliasUnion": decl = `type G<T> = { ${body} } | { tag: 0 };`; break;
      default: decl = `interface G<T extends unknown = unknown> { ${body} }`; break;
    }
    const pre = `${decl}\ndeclare const a: G<${A}>;\n`;
    let use: string;
    switch (d.ctx) {
      case "assign": use = `const b: G<${B}> = a;`; break;
      case "twoWay": use = `const b: G<${B}> = a;\ndeclare const a2: G<${B}>;\nconst b2: G<${A}> = a2;`; break;
      case "reverseFirst": use = `declare const a2: G<${B}>;\nconst b2: G<${A}> = a2;\nconst b: G<${B}> = a;`; break;
      case "argument": use = `declare function take(x: G<${B}>): void;\ntake(a);`; break;
      case "returned": use = `function r(): G<${B}> {\n  return a;\n}`; break;
      case "genericFn": use = `function gf<X extends ${B}>(x: G<X>, y: G<${B}>) {\n  const b: G<${B}> = x;\n}\ngf(a, a);`; break;
      case "nested": use = `declare const na: { inner: G<${A}> };\nconst b: { inner: G<${B}> } = na;`; break;
      case "array": use = `declare const aa: G<${A}>[];\nconst b: readonly G<${B}>[] = aa;`; break;
      case "structuralFirst": use = `const s: { [K in keyof G<${B}>]: G<${B}>[K] } = a;\nconst b: G<${B}> = a;`; break;
      case "otherPairFirst": { const [C, D] = PAIRS[(+d.pair + 1) % PAIRS.length]; use = `declare const c: G<${C}>;\nconst e: G<${D}> = c;\nconst b: G<${B}> = a;`; break; }
      case "unionTarget": use = `const b: G<${B}> | G<boolean> = a;`; break;
      case "toBase": {
        if (d.decl === "aliasUnion") return null;
        const hasBase = d.decl === "interfaceExtends" || d.decl === "classImplements";
        use = hasBase ? `const b: Base<${B}> = a;` : `interface D<T> extends G<T> { extra: 0 }\ndeclare const dd: D<${A}>;\nconst b: G<${B}> = dd;`; break;
      }
      case "pickWrap": use = `declare const p: Pick<G<${A}>, keyof G<${A}>>;\nconst b: Pick<G<${B}>, keyof G<${B}>> = p;`; break;
      case "partialWrap": use = `declare const p: Partial<G<${A}>>;\nconst b: Partial<G<${B}>> = p;`; break;
      case "omitWrap": use = `declare const p: Omit<G<${A}>, "zz">;\nconst b: Omit<G<${B}>, "zz"> = p;`; break;
      case "spreadCopy": if (isClass || d.decl === "aliasUnion") return null; use = `const sp = { ...a };\nconst b: G<${B}> = sp;`; break;
      case "readonlyWrap": use = `declare const p: Readonly<G<${A}>>;\nconst b: Readonly<G<${B}>> = p;`; break;
      case "crossDecl": case "crossDeclTwice": {
        const twin = decl.replace(/\bG\b/g, "H").replace(/\bBase\b/g, "Base2");
        use = `${twin}\n${d.ctx === "crossDeclTwice" ? `declare const h0: H<${A}>;\nconst g0: G<${A}> = h0;\n` : ""}const b: H<${B}> = a;`; break;
      }
      default: use = `declare function inf<X>(x: G<X>, y: G<X>): X;\ndeclare const a2: G<${B}>;\nconst b = inf(a, a2);\nconst c: unknown = b;`; break;
    }
    return `${pre}${use}\n`;
  },
};
