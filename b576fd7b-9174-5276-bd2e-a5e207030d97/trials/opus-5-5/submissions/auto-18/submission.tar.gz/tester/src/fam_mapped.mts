// Family: relations between generic mapped types (modifiers, key remapping, templates) and between
// instantiations of aliases whose variance depends on mapped/conditional structure.
import type { Family } from "./family.mts";

const MODS: Record<string, [string, string]> = {
  none: ["", ""], ro: ["readonly ", ""], opt: ["", "?"], minusOpt: ["", "-?"], roOpt: ["readonly ", "?"], minusRo: ["-readonly ", ""],
};
const NAMES: Record<string, string> = {
  none: "", asK: " as K", tplA: " as `a_${K & string}`", tplB: " as `b_${K & string}`", excl: " as Exclude<K, \"x\">", upper: " as Uppercase<K & string>",
};
const TPLS: Record<string, string> = {
  idx: "T[K]", undef: "T[K] | undefined", box: "Box<T[K]>", fn: "() => T[K]", param: "(v: T[K]) => void", str: "string", nonNull: "NonNullable<T[K]>",
};
const PAIRS: [string, string][] = [["{ a: 1; b: 2 }", "{ a: 1 }"], ["{ a: 1 }", "{ a: 1; b: 2 }"], ["{ a: 1 }", "{ a: number }"], ["{ a: number }", "{ a: 1 }"],
  ["{ a?: 1 }", "{ a: 1 }"], ["{ a: 1 }", "{ a?: 1 }"], ["{ a: 1 } | { b: 2 }", "{ a: 1 }"], ["{ readonly a: 1 }", "{ a: 1 }"], ["{ a: 1; x: 2 }", "{ a: 1; x: 3 }"]];
const CONSTR: Record<string, string> = { keyof: "keyof T", keyofStr: "keyof T & string", keyU: "keyof T | keyof U" };

export const mappedFam: Family = {
  name: "generic-mapped-relation",
  dims: {
    sm: Object.keys(MODS), tm: Object.keys(MODS),
    sn: Object.keys(NAMES), tn: Object.keys(NAMES),
    st: Object.keys(TPLS), tt: Object.keys(TPLS),
    sc: Object.keys(CONSTR), tc: Object.keys(CONSTR),
    rel: ["return", "assignGeneric", "concrete", "aliasArgs", "argument", "pairs", "pairsNested"],
    pair: PAIRS.map((_, i) => String(i)),
  },
  render(d) {
    const mk = (m: string, n: string, t: string, c: string) => `{ ${MODS[m][0]}[K in ${CONSTR[c]}${NAMES[n]}]${MODS[m][1]}: ${TPLS[t]} }`;
    const pre = "interface Box<X> { v: X }\n";
    const S = mk(d.sm, d.sn, d.st, d.sc), Tt = mk(d.tm, d.tn, d.tt, d.tc);
    switch (d.rel) {
      case "pairs": case "pairsNested": {
        const [x, y] = PAIRS[+d.pair];
        const w = (a: string) => d.rel === "pairsNested" ? `Box<M<${a}, ${a}>>` : `M<${a}, ${a}>`;
        return `${pre}type M<T, U> = ${Tt};\ndeclare const s: ${w(x)};\nconst t: ${w(y)} = s;\n`;
      }
      case "assignGeneric": return `${pre}function f<T, U>(s: ${S}) {\n  const t: ${Tt} = s;\n}\n`;
      case "concrete": return `${pre}type MS<T, U> = ${S};\ntype MT<T, U> = ${Tt};\ndeclare const s: MS<{ a: 1; x: "s" }, { u: 2 }>;\nconst t: MT<{ a: 1; x: "s" }, { u: 2 }> = s;\n`;
      case "aliasArgs": return `${pre}type M<T, U> = ${Tt};\nfunction f<A extends B, B>(s: M<A, A>) {\n  const t: M<B, B> = s;\n}\n`;
      case "argument": return `${pre}declare function take<T, U>(t: ${Tt}): void;\nfunction f<T, U>(s: ${S}) {\n  take<T, U>(s);\n}\n`;
      default: return `${pre}function f<T, U>(s: ${S}): ${Tt} {\n  return s;\n}\n`;
    }
  },
};
