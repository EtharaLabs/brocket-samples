// Family: type-level operators (conditional types with infer, mapped types with key remapping,
// indexed access, templates) applied to source types directly or through generic instantiation;
// the (expanded) result type is observed.
import type { Family } from "./family.mts";

// type operator bodies over X
const OPS: string[] = [
  "X extends string ? \"s\" : X extends number ? \"n\" : \"o\"",
  "X extends (infer A)[] ? A : never",
  "X extends { v: infer V } ? V : \"no\"",
  "X extends (...a: infer P) => infer R ? [P, R] : 0",
  "X extends [infer H, ...infer T] ? [T, H] : 0",
  "X extends `${infer H}${infer T}` ? [H, T] : 0",
  "X extends `a${infer R}` ? R : 0",
  "{ [K in keyof X]: X[K][] }",
  "{ [K in keyof X as K extends \"a\" ? never : K]: X[K] }",
  "{ [K in keyof X as `get_${K & string}`]: () => X[K] }",
  "keyof X",
  "X[keyof X]",
  "[X] extends [never] ? \"never\" : \"not\"",
  "X extends unknown ? { w: X } : never",
  "X extends infer U extends string ? U : 0",
  "Exclude<X, string>",
  "Extract<X, object>",
  "X extends { k: infer K extends string; v: infer V } ? Record<K, V> : 0",
  "X extends { m(x: infer A): void } ? A : 0",
  "X extends { (): infer R } ? R : 0",
  "X extends (a: infer A) => void ? A : 0",
  "Awaited<X>",
  "(X extends unknown ? (k: X) => void : never) extends (k: infer I) => void ? I : never",
  "{ [K in keyof X]-?: X[K] }",
  "X extends readonly unknown[] ? { [I in keyof X]: Box<X[I]> } : 0",
  "X extends { a: infer A } | { b: infer A } ? A : 0",
  "X extends Box<infer A> | infer A ? A : 0",
  "{ [K in keyof X]: X[K] extends Function ? K : never }[keyof X]",
  "X extends readonly [infer A, infer B] ? [B, A] : X extends readonly [infer A] ? A : 1",
  "X extends { [k: string]: infer V } ? V : 0",
  "{ [K in keyof X as X[K] extends string ? K : never]: 1 }",
  "X extends `${infer N extends number}` ? N : X extends `${infer B extends boolean}` ? B : 0",
  "X extends new (...a: any) => infer I ? I : 0",
  "keyof X extends infer K ? K extends string ? `k_${K}` : never : 0",
  "X extends { readonly a: infer A; b?: infer B } ? [A, B] : 0",
  "NoInfer<X> extends object ? 1 : 0",
];

const ARGS: string[] = [
  "string", "\"a\" | \"b\"", "\"abc\"", "number", "1 | \"x\"", "string[]", "[1, \"s\"]", "readonly [1, 2]",
  "{ a: 1; b: \"s\" }", "{ a?: 1 }", "{ k: \"x\"; v: number } | { k: \"y\"; v: string }", "() => 1",
  "(a: string, b: number) => void", "((a: string) => void) & ((a: number) => void)", "Promise<Promise<1>>",
  "{ m(x: string): void }", "{ (): 1; (x: 1): 2 }", "never", "any", "unknown", "null | undefined",
  "Box<1> | Box<\"s\">", "{ readonly a: 1 }", "`pre${string}`", "Uppercase<\"ab\">", "string & { b: 1 }",
  "{ [k: string]: number }", "Record<\"a\" | \"b\", 1>", "{ a: 1 } & { b: 2 }", "boolean", "\"12\" | \"true\"",
  "{ f(): void; g: () => 1; h: 1 }", "new () => { z: 1 }", "{ a: 1 } | { b: \"s\" }", "[a?: 1, ...b: string[]]",
  "<T>(x: T) => T", "<T extends string>(x: T) => T[]", "{ <T>(x: T): T; (x: 1): 2 }", "{ m<T>(x: T): void }", "abstract new () => 1",
];

export const tlFam: Family = {
  name: "type-operator",
  labelOf(k, v) { return k === "op" || k === "op2" ? (OPS[+v] ?? v) : k.startsWith("arg") ? (ARGS[+v] ?? v) : v; },
  dims: {
    op: OPS.map((_, i) => String(i)),
    arg: ARGS.map((_, i) => String(i)),
    via: ["direct", "genericCall", "union", "nested", "alias", "genericArg", "indexed"],
    arg2: ARGS.map((_, i) => String(i)),
    op2: ["same", ...OPS.map((_, i) => String(i))],
  },
  render(d) {
    const A = ARGS[+d.arg], A2 = ARGS[+d.arg2];
    const op2 = d.op2 === "same" ? d.op : d.op2;
    let pre = `interface Box<V> { v: V }\ntype Exp<E> = E extends infer O ? { [K in keyof O]: O[K] } : never;\ntype Op<X> = ${OPS[+d.op]};\ntype Op2<X> = ${OPS[+op2]};\n`;
    let body: string;
    switch (d.via) {
      case "direct": body = `declare const r: Exp<Op<${A}>>;\nconst o: unknown = r;`; break;
      case "genericCall": body = `declare function g<X>(x: X): Op<X>;\ndeclare const a: ${A};\nconst r = g(a);\nconst o: unknown = r;`; break;
      case "union": body = `declare const r: Exp<Op<(${A}) | (${A2})>>;\nconst o: unknown = r;`; break;
      case "nested": body = `declare const r: Exp<Op2<Op<${A}>>>;\nconst o: unknown = r;`; break;
      case "alias": body = `type In = ${A};\ntype R = Op<In>;\ndeclare const r: Exp<R>;\nconst o: unknown = r;`; break;
      case "genericArg": body = `declare function g<X>(x: X, y: Op<X>): Op2<X>;\ndeclare const a: ${A};\ndeclare const b: Op<${A}>;\nconst r = g(a, b);\nconst o: unknown = r;`; break;
      default: body = `declare const t: { p: ${A} };\ndeclare function g<O, K extends keyof O>(o: O, k: K): Op<O[K]>;\nconst r = g(t, "p");\nconst o: unknown = r;`; break;
    }
    return pre + body + "\n";
  },
};
