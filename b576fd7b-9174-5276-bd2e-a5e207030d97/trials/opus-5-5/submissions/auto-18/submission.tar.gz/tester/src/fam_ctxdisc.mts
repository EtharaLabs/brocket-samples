// Family: discrimination of union contextual types by the members of an object literal (literal,
// shorthand, missing optional discriminants, several discriminants, large unions), observed through the
// contextually typed parameter of a callback member.
import type { Family } from "./family.mts";

const PT = ["string", "number", "boolean", "string[]", "bigint", "symbol", "{ p: 1 }", "{ q: 2 }", "Date", "RegExp", "null", "1n | 2n"];

export const ctxDiscFam: Family = {
  name: "contextual-discrimination",
  dims: {
    tag: ["str", "num", "bool", "enum", "tpl", "nullish", "two", "optionalMissing", "nested"],
    size: ["2", "3", "12"],
    sel: ["0", "1", "last"],
    form: ["literal", "shorthand", "asConst", "omitted", "spreadFirst", "parenthesized"],
    member: ["arrowProp", "method", "fnExpr", "nestedObj", "arrayOfCb", "returnedCb"],
    pos: ["annot", "arg", "genericArg", "ret", "arrayElem", "outerProp", "satisfies", "assign", "defaultParam"],
  },
  render(d) {
    const n = +d.size;
    const sel = d.sel === "last" ? n - 1 : +d.sel;
    if (sel >= n) return null;
    let pre = "";
    if (d.tag === "enum") pre += `enum E { ${Array.from({ length: n }, (_, i) => `M${i}`).join(", ")} }\n`;
    // discriminant members of constituent i, and literal text selecting constituent i
    const tagOf = (i: number): [string, string, string] => {
      switch (d.tag) {
        case "num": return ["k", `${i}`, `${i}`];
        case "bool": if (n > 2) return ["", "", ""]; return ["k", i === 0 ? "true" : "false", i === 0 ? "true" : "false"];
        case "enum": return ["k", `E.M${i}`, `E.M${i}`];
        case "tpl": return ["k", `"t${i}"`, `\`t${i}\``];
        case "nullish": if (n > 3) return ["", "", ""]; return ["k", ["null", "undefined", "\"x\""][i], ["null", "undefined", "\"x\""][i]];
        case "two": return ["k", `"${i >> 1}"`, `"${i >> 1}"`];
        default: return ["k", `"t${i}"`, `"t${i}"`];
      }
    };
    if (tagOf(0)[0] === "") return null;
    const cb = (t: string) => {
      switch (d.member) {
        case "method": return `f(x: ${t}): void`;
        case "nestedObj": return `o: { g: (x: ${t}) => void }`;
        case "arrayOfCb": return `fs: ((x: ${t}) => void)[]`;
        case "returnedCb": return `mk: () => (x: ${t}) => void`;
        default: return `f: (x: ${t}) => void`;
      }
    };
    const cons: string[] = [];
    for (let i = 0; i < n; i++) {
      const [k, ty] = tagOf(i);
      let tagPart = `${k}: ${ty}`;
      if (d.tag === "two") tagPart += `; j: ${i & 1 ? "true" : "false"}`;
      if (d.tag === "optionalMissing" && i === 0) tagPart = `${k}?: undefined`;
      if (d.tag === "nested") tagPart = `${k}: ${ty}`;
      cons.push(`{ ${tagPart}; ${cb(PT[i])} }`);
    }
    pre += `type U = ${cons.join(" | ")};\n`;
    const T = PT[sel];
    const body = `{\n    const o: ${T} = x;\n  }`;
    let mem: string;
    switch (d.member) {
      case "method": mem = `f(x) ${body}`; break;
      case "fnExpr": mem = `f: function (x) ${body}`; break;
      case "nestedObj": mem = `o: { g: (x) => ${body} }`; break;
      case "arrayOfCb": mem = `fs: [(x) => ${body}]`; break;
      case "returnedCb": mem = `mk: () => (x) => ${body}`; break;
      default: mem = `f: (x) => ${body}`; break;
    }
    const [, , lit] = tagOf(sel);
    let tagText: string;
    let local = "";
    const omitTag = d.tag === "optionalMissing" && sel === 0;
    switch (d.form) {
      case "shorthand": local = `const k = ${lit};\n`; tagText = "k"; break;
      case "asConst": tagText = `k: ${lit} as const`; break;
      case "parenthesized": tagText = `k: (${lit})`; break;
      case "omitted": if (!omitTag && d.tag !== "optionalMissing") return null; tagText = ""; break;
      default: tagText = `k: ${lit}`; break;
    }
    if (omitTag) { tagText = ""; local = ""; }
    if (d.tag === "two" && tagText) tagText += `, j: ${sel & 1 ? "true" : "false"}`;
    const parts = [tagText, mem].filter((x) => x);
    if (d.form === "spreadFirst") { if (omitTag) return null; parts.unshift("...{}"); }
    const obj = `{ ${parts.join(", ")} }`;
    switch (d.pos) {
      case "arg": return `${pre}declare function use(u: U): void;\n${local}use(${obj});\n`;
      case "genericArg": return `${pre}declare function use<T extends U>(u: T): T;\n${local}use(${obj});\n`;
      case "ret": return `${pre}function g(): U {\n  ${local}return ${obj};\n}\n`;
      case "arrayElem": return `${pre}${local}const a: U[] = [${obj}];\n`;
      case "outerProp": return `${pre}${local}const w: { u: U } = { u: ${obj} };\n`;
      case "satisfies": return `${pre}${local}const s = ${obj} satisfies U;\n`;
      case "assign": return `${pre}let u: U;\n${local}u = ${obj};\n`;
      case "defaultParam": return `${pre}${local}function g(u: U = ${obj}) { }\n`;
      default: return `${pre}${local}const u: U = ${obj};\n`;
    }
  },
};
