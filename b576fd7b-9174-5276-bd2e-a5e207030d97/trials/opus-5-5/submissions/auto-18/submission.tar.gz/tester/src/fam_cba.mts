// Family: strictBindCallApply — call/apply/bind on declared functions and methods (inference of
// this/argument/return types through CallableFunction members).
import type { Family } from "./family.mts";

const FNS: Record<string, string> = {
  plain: "declare function fn(a: number, b: string): boolean;",
  optional: "declare function fn(a: number, b?: string): boolean;",
  rest: "declare function fn(a: number, ...b: string[]): boolean;",
  generic: "declare function fn<T>(a: T, b: string): T[];",
  genericConstr: "declare function fn<T extends number>(a: T, b: string): T;",
  overloaded: "declare function fn(a: number, b: string): boolean;\ndeclare function fn(a: string): number;",
  thisParam: "declare function fn(this: { k: 1 }, a: number, b: string): boolean;",
  noParams: "declare function fn(): boolean;",
  arrow: "const fn = (a: number, b: string): boolean => true;",
  method: "declare const obj: { k: 1; fn(a: number, b: string): boolean };\nconst fn = obj.fn;",
  ctorLike: "declare class K { constructor(a: number, b: string); m(a: number, b: string): boolean; }\nconst fn = K.prototype.m;",
  union: "declare const fn: ((a: number, b: string) => boolean) | ((a: number) => boolean);",
  defaultT: "declare function fn<T = number>(a?: T, b?: string): T;",
};
const ARGS = ["1, \"s\"", "1", "\"s\"", "", "1, \"s\", \"t\"", "true", "1, 2"];

export const cbaFam: Family = {
  name: "bind-call-apply",
  dims: {
    fn: Object.keys(FNS),
    op: ["call", "apply", "bind", "bindPartial", "bindAll", "callThis", "applyEmpty", "bindThenCall", "reflectApply"],
    args: ARGS.map((_, i) => String(i)),
    thisArg: ["undefined", "obj", "wrongObj", "null"],
    use: ["infer", "annotBool", "annotNum"],
  },
  labelOf(k, v) { return k === "args" ? ARGS[+v] || "none" : v; },
  render(d) {
    const A = ARGS[+d.args];
    const T = d.thisArg === "obj" ? "{ k: 1 as const }" : d.thisArg === "wrongObj" ? "{ k: 2 as const }" : d.thisArg;
    let expr: string;
    const comma = A ? ", " : "";
    switch (d.op) {
      case "call": expr = `fn.call(${T}${comma}${A})`; break;
      case "apply": expr = `fn.apply(${T}, [${A}])`; break;
      case "bind": expr = `fn.bind(${T})(${A})`; break;
      case "bindPartial": { const [first, ...rest] = A.split(", "); if (!A) return null; expr = `fn.bind(${T}, ${first})(${rest.join(", ")})`; break; }
      case "bindAll": expr = `fn.bind(${T}${comma}${A})()`; break;
      case "callThis": expr = `fn.call(${T}${comma}${A}) satisfies unknown`; break;
      case "applyEmpty": expr = `fn.apply(${T})`; break;
      case "bindThenCall": expr = `fn.bind(${T}).call(undefined${comma}${A})`; break;
      default: expr = `Reflect.apply(fn, ${T}, [${A}])`; break;
    }
    let use: string;
    switch (d.use) {
      case "annotBool": use = `const r: boolean = ${expr};`; break;
      case "annotNum": use = `const r: number = ${expr};`; break;
      default: use = `const r = ${expr};\nconst c: unknown = r;`; break;
    }
    return `${FNS[d.fn]}\n${use}\n`;
  },
};
