// Family: property-name identity across key spellings (identifiers, string/numeric literals,
// computed constants, unique symbols, enum members) in relations, literals and lookups.
import type { Family } from "./family.mts";

const PRE = `declare const s1: unique symbol;
declare const s2: unique symbol;
const KA = "a";
const K1 = 1;
enum EK { A = "a", One = 1 }
`;
// key spelling in a type literal / object literal
const KEYS: [string, string][] = [
  ["a", "ident"], ["\"a\"", "str"], ["[KA]", "constStr"], ["[EK.A]", "enumStr"], ["\"\\u0061\"", "escaped"], ["'a'", "single"],
  ["1", "num"], ["\"1\"", "numStr"], ["1.0", "numFloat"], ["0x1", "hex"], ["1e0", "exp"], ["[K1]", "constNum"], ["[EK.One]", "enumNum"],
  ["[s1]", "sym1"], ["[s2]", "sym2"], ["[Symbol.iterator]", "wellKnown"], ["b", "other"], ["\"a \"", "space"], ["[`a`]", "template"],
];

export const keysFam: Family = {
  name: "property-key-identity",
  dims: {
    sk: KEYS.map((_, i) => String(i)),
    tk: KEYS.map((_, i) => String(i)),
    vt: ["sameType", "diffType", "optTarget", "readonlySrc", "method"],
    ctx: ["assign", "literal", "lookup", "keyof", "mapped", "interfaceDecl", "classImpl", "spread", "destructure", "intersection"],
  },
  labelOf(k, v) { return k === "sk" || k === "tk" ? KEYS[+v][1] : v; },
  render(d) {
    const sk = KEYS[+d.sk][0], tk = KEYS[+d.tk][0];
    const tv = d.vt === "diffType" ? "string" : "number";
    const sMem = d.vt === "method" ? `${sk}(): number` : `${d.vt === "readonlySrc" ? "readonly " : ""}${sk}: number`;
    const tMem = d.vt === "method" ? `${tk}(): ${tv}` : `${tk}${d.vt === "optTarget" ? "?" : ""}: ${tv}`;
    const sVal = d.vt === "method" ? `${sk}() { return 1; }` : `${sk}: 1`;
    const keyExpr = (k: string) => k.startsWith("[") ? k.slice(1, -1) : /^[A-Za-z_]/.test(k) ? `"${k}"` : k;
    let use: string;
    switch (d.ctx) {
      case "assign": use = `declare const s: { ${sMem} };\nconst t: { ${tMem} } = s;`; break;
      case "literal": use = `const t: { ${tMem} } = { ${sVal} };`; break;
      case "lookup": use = `declare const s: { ${sMem} };\nconst v = s[${keyExpr(tk)}];\nconst o: number = v;`; break;
      case "keyof": use = `type KS = keyof { ${sMem} };\ntype KT = keyof { ${tMem} };\ndeclare const s: KS;\nconst t: KT = s;`; break;
      case "mapped": use = `type M<O> = { [P in keyof O]: O[P] };\ndeclare const s: M<{ ${sMem} }>;\nconst t: M<{ ${tMem} }> = s;`; break;
      case "interfaceDecl": use = `interface IS { ${sMem} }\ninterface IT { ${tMem} }\ndeclare const s: IS;\nconst t: IT = s;`; break;
      case "classImpl": if (d.vt === "optTarget") return null; use = `interface IT { ${tMem} }\nclass C implements IT {\n  ${d.vt === "method" ? `${sk}() { return 1; }` : `${d.vt === "readonlySrc" ? "readonly " : ""}${sk} = 1;`}\n}`; break;
      case "spread": use = `declare const s: { ${sMem} };\nconst t: { ${tMem} } = { ...s };`; break;
      case "destructure": use = `declare const s: { ${sMem} };\nconst { ${sk.startsWith("[") || !/^[A-Za-z_]/.test(sk) ? `${sk}: dv` : `${sk}: dv`} } = s;\nconst o: number = dv;`; break;
      default: use = `declare const s: { ${sMem} } & { z: 0 };\nconst t: { ${tMem} } & { z: 0 } = s;`; break;
    }
    return PRE + use + "\n";
  },
};
