// Family: relations between enum declarations (same or different names, member names, values,
// const/declare/ambient forms) and between enum members and literals.
import type { Family } from "./family.mts";

// [source members, target members]
const MEMS: Record<string, [string, string]> = {
  same: ["A, B", "A, B"],
  extraSrc: ["A, B, C", "A, B"],
  missingSrc: ["A", "A, B"],
  reordered: ["B, A", "A, B"],
  numDiff: ["A = 1, B = 2", "A = 1, B = 3"],
  numSame: ["A = 1, B = 2", "A = 1, B = 2"],
  strSame: ["A = \"a\", B = \"b\"", "A = \"a\", B = \"b\""],
  strDiff: ["A = \"a\", B = \"b\"", "A = \"a\", B = \"x\""],
  strVsNum: ["A = \"a\", B = \"b\"", "A = 0, B = 1"],
  mixed: ["A = 0, B = \"b\"", "A = 0, B = \"b\""],
  mixedDiff: ["A = 0, B = \"b\"", "A = 0, B = \"c\""],
  renamedSameVal: ["A = 0, C = 1", "A = 0, B = 1"],
  computed: ["A = 1 << 0, B = 1 << 1", "A = 1, B = 2"],
  computedDiff: ["A = 1 << 0, B = 1 << 2", "A = 1, B = 2"],
  single: ["A", "A"],
  singleStr: ["A = \"a\"", "A = \"a\""],
};

export const enumFam: Family = {
  name: "enum-relation",
  dims: {
    mem: Object.keys(MEMS),
    names: ["same", "different", "caseDiff"],
    place: ["namespaces", "functions", "declareNs", "constEnums", "declareEnums", "nested", "mergedSrc", "blocks"],
    rel: ["type", "memberToMember", "memberToEnum", "enumToMember", "union", "array", "box", "fnParam", "fnRet", "record", "literalNum", "literalStr", "keyofTypeof", "switchExhaust"],
    ctx: ["assign", "argument", "return", "generic"],
  },
  render(d) {
    const [sm, tm] = MEMS[d.mem];
    const sn = "E", tn = d.names === "same" ? "E" : d.names === "caseDiff" ? "e" : "F";
    const kw = d.place === "constEnums" ? "const enum" : d.place === "declareEnums" ? "declare enum" : "enum";
    if (d.place === "declareEnums" && /<</.test(sm + tm)) return null;
    const sDecl = `${kw} ${sn} { ${sm} }`, tDecl = `${kw} ${tn} { ${tm} }`;
    // S: qualified prefix for the source enum, T: for the target enum
    let pre: string, S: string, T: string;
    switch (d.place) {
      case "functions": pre = ""; S = sn; T = tn; break;
      case "declareNs": pre = `declare namespace NS { ${sDecl.replace("declare ", "")} }\ndeclare namespace NT { ${tDecl.replace("declare ", "")} }\n`; S = `NS.${sn}`; T = `NT.${tn}`; break;
      case "nested": pre = `namespace NS.Inner { export ${sDecl} }\nnamespace NT.Inner { export ${tDecl} }\n`; S = `NS.Inner.${sn}`; T = `NT.Inner.${tn}`; break;
      case "mergedSrc": {
        const [a, ...rest] = sm.split(", ");
        if (!rest.length || /=/.test(sm)) return null;
        pre = `namespace NS { export ${kw} ${sn} { ${a} } }\nnamespace NS { export ${kw} ${sn} { ${rest.map((r) => `${r} = ${rest.indexOf(r) + 1}`).join(", ")} } }\nnamespace NT { export ${tDecl} }\n`;
        S = `NS.${sn}`; T = `NT.${tn}`; break;
      }
      case "blocks": pre = ""; S = sn; T = tn; break;
      default: pre = `namespace NS { export ${sDecl} }\nnamespace NT { export ${tDecl} }\n`; S = `NS.${sn}`; T = `NT.${tn}`; break;
    }
    const firstS = sm.split(",")[0].split("=")[0].trim();
    const firstT = tm.split(",")[0].split("=")[0].trim();
    let src: string, tgt: string, val: string;
    switch (d.rel) {
      case "type": src = S; tgt = T; break;
      case "memberToMember": src = `${S}.${firstS}`; tgt = `${T}.${firstT}`; break;
      case "memberToEnum": src = `${S}.${firstS}`; tgt = T; break;
      case "enumToMember": src = S; tgt = `${T}.${firstT}`; break;
      case "union": src = `${S} | undefined`; tgt = `${T} | null | undefined`; break;
      case "array": src = `${S}[]`; tgt = `readonly ${T}[]`; break;
      case "box": src = `{ v: ${S} }`; tgt = `{ v: ${T} }`; break;
      case "fnParam": src = `(x: ${T}) => void`; tgt = `(x: ${S}) => void`; break;
      case "fnRet": src = `() => ${S}`; tgt = `() => ${T}`; break;
      case "record": src = `Record<${S}, 1>`; tgt = `Record<${T}, 1>`; break;
      case "literalNum": src = "1"; tgt = T; break;
      case "literalStr": src = "\"a\""; tgt = T; break;
      case "keyofTypeof": src = `keyof typeof ${S}`; tgt = `keyof typeof ${T}`; break;
      default: src = S; tgt = T; break;
    }
    if ((d.place === "constEnums" || d.place === "declareEnums") && d.rel === "keyofTypeof") return null;
    // in nested scopes the target may shadow the source: refer to the source through an outer alias
    const scoped = d.place === "functions" || d.place === "blocks";
    let alias = "";
    if (scoped && src !== "1" && src !== "\"a\"") {
      if (d.rel === "fnParam") { alias = `type Src = ${S};`; src = `(x: ${T}) => void`; tgt = "(x: Src) => void"; }
      else { alias = `type Src = ${src};`; src = "Src"; }
    }
    let use: string;
    if (d.rel === "switchExhaust") {
      const tMembers = tm.split(",").map((x) => x.split("=")[0].trim());
      use = `function sw(x: ${scoped ? "Src" : S}): number {\n  switch (x as unknown as ${T}) {\n${tMembers.map((m, i) => `    case ${T}.${m}: return ${i};`).join("\n")}\n  }\n}`;
    } else {
      val = src === "1" || src === "\"a\"" ? src : `null! as ${src}`;
      switch (d.ctx) {
        case "assign": use = src === "1" || src === "\"a\"" ? `const t: ${tgt} = ${src};` : `${scoped ? `const s = null! as ${src};` : `declare const s: ${src};`}\nconst t: ${tgt} = s;`; break;
        case "argument": use = `${scoped ? "function" : "declare function"} take(t: ${tgt}): void${scoped ? " { }" : ";"}\ntake(${val});`; break;
        case "return": use = `function r(): ${tgt} {\n  return ${val};\n}`; break;
        default: use = `function g<X extends ${src}>(x: X): ${tgt} {\n  return x;\n}`; if (src === "1" || src === "\"a\"") return null; break;
      }
    }
    if (d.place === "functions") return `function fs() {\n  ${sDecl}\n  ${alias}\n  function ft() {\n    ${tDecl}\n    ${use.split("\n").join("\n    ")}\n  }\n}\n`;
    if (d.place === "blocks") return `{\n  ${sDecl}\n  ${alias}\n  {\n    ${tDecl}\n    ${use.split("\n").join("\n    ")}\n  }\n}\n`;
    return pre + use + "\n";
  },
};
