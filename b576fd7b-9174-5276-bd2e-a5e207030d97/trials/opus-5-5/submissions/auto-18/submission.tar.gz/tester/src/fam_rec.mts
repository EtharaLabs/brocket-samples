// Family: recursive types — relations between instantiations of recursive aliases/interfaces,
// structurally identical but distinct recursive declarations, and inference/checks of nested literals.
import type { Family } from "./family.mts";

// [declarations using A (primary) and B (structural twin), value builder for depth n with leaf]
interface Rec { decl: string; val: (n: number, leaf: string) => string; }
const nest = (n: number, f: (inner: string) => string, leaf: string) => { let s = leaf; for (let i = 0; i < n; i++) s = f(s); return s; };
const RECS: Record<string, Rec> = {
  list: { decl: "interface A<T> { v: T; next?: A<T> }\ninterface B<T> { v: T; next?: B<T> }", val: (n, l) => nest(n, (s) => `{ v: ${l}, next: ${s} }`, `{ v: ${l} }`) },
  listAlias: { decl: "type A<T> = { v: T; next: A<T> | null };\ntype B<T> = { v: T; next: B<T> | null };", val: (n, l) => nest(n, (s) => `{ v: ${l}, next: ${s} }`, `{ v: ${l}, next: null }`) },
  tree: { decl: "interface A<T> { v: T; kids: A<T>[] }\ninterface B<T> { v: T; kids: B<T>[] }", val: (n, l) => nest(n, (s) => `{ v: ${l}, kids: [${s}] }`, `{ v: ${l}, kids: [] }`) },
  nestArr: { decl: "type A<T> = T | A<T>[];\ntype B<T> = T | B<T>[];", val: (n, l) => nest(n, (s) => `[${s}]`, l) },
  json: { decl: "type A<T> = T | { [k: string]: A<T> } | A<T>[];\ntype B<T> = T | { [k: string]: B<T> } | B<T>[];", val: (n, l) => nest(n, (s) => `{ k: ${s} }`, l) },
  mutual: { decl: "interface A<T> { v: T; o?: AO<T> }\ninterface AO<T> { w: T; a?: A<T> }\ninterface B<T> { v: T; o?: BO<T> }\ninterface BO<T> { w: T; a?: B<T> }", val: (n, l) => nest(n, (s) => `{ v: ${l}, o: { w: ${l}, a: ${s} } }`, `{ v: ${l} }`) },
  fn: { decl: "interface A<T> { v: T; f(): A<T> }\ninterface B<T> { v: T; f(): B<T> }", val: (n, l) => `{ v: ${l}, f() { return null!; } }` },
  wrapGrow: { decl: "interface A<T> { v: T; next?: A<{ w: T }> }\ninterface B<T> { v: T; next?: B<{ w: T }> }", val: (n, l) => { let s = `{ v: ${l} }`; let leaf = l; const leaves = [l]; for (let i = 0; i < n; i++) { leaf = `{ w: ${leaf} }`; leaves.push(leaf); } s = `{ v: ${leaves[n]} }`; for (let i = n - 1; i >= 0; i--) s = `{ v: ${leaves[i]}, next: ${s} }`; return s; } },
  classRec: { decl: "declare class A<T> { v: T; next?: A<T> }\ndeclare class B<T> { v: T; next?: B<T> }", val: (n, l) => nest(n, (s) => `{ v: ${l}, next: ${s} }`, `{ v: ${l} }`) },
  deepPartial: { decl: "type DP<T> = { [K in keyof T]?: DP<T[K]> };\ninterface N { v: number; n: N }\ntype A<T> = DP<{ v: T; n: N }>;\ntype B<T> = { v?: T; n?: DP<N> };", val: (n, l) => nest(n, (s) => `{ v: ${l}, n: ${s} }`, `{ v: ${l} }`) },
  deepRo: { decl: "type DR<T> = { readonly [K in keyof T]: DR<T[K]> };\ninterface L<T> { v: T; next?: L<T> }\ntype A<T> = DR<L<T>>;\ntype B<T> = L<T>;", val: (n, l) => nest(n, (s) => `{ v: ${l}, next: ${s} }`, `{ v: ${l} }`) },
  fbound: { decl: "interface A<T> { v: T; cmp<S extends A<T>>(o: S): S }\ninterface B<T> { v: T; cmp<S extends B<T>>(o: S): S }", val: (n, l) => `{ v: ${l}, cmp: (o) => o }` },
  tupleRec: { decl: "type A<T> = [T, A<T>?];\ntype B<T> = [T, B<T>?];", val: (n, l) => nest(n, (s) => `[${l}, ${s}]`, `[${l}]`) },
};
// [source arg, target arg]
const ARGS: [string, string][] = [["number", "number"], ["1", "number"], ["number", "1"], ["{ a: 1; b: 2 }", "{ a: 1 }"], ["{ a: 1 }", "{ a: 1; b: 2 }"],
  ["string", "number"], ["1 | 2", "1"], ["never", "string"], ["{ a: number }", "{ a?: number }"], ["{ a?: number }", "{ a: number }"]];
const LEAVES = ["1", "\"s\"", "{ a: 1 }", "null"];

export const recFam: Family = {
  name: "recursive-types",
  dims: {
    rec: Object.keys(RECS),
    rel: ["same", "twin", "twinGeneric", "sameGeneric", "literal", "literalBad", "infer", "inferTwin", "argNested"],
    args: ARGS.map((_, i) => String(i)),
    depth: ["2", "0", "1", "3", "4", "6", "8"],
    leaf: ["0", "1", "2", "3"],
  },
  render(d) {
    const R = RECS[d.rec];
    const [s, t] = ARGS[+d.args];
    const n = +d.depth;
    const pre = R.decl + "\n";
    switch (d.rel) {
      case "twin": return `${pre}declare const s: A<${s}>;\nconst t: B<${t}> = s;\n`;
      case "twinGeneric": return `${pre}function f<X extends Y, Y>(s: A<X>) {\n  const t: B<Y> = s;\n}\n`;
      case "sameGeneric": return `${pre}function f<X extends Y, Y>(s: A<X>, u: A<Y>) {\n  const t: A<Y> = s;\n  const w: A<X> = u;\n}\n`;
      case "literal": return `${pre}const t: A<${t}> = ${R.val(n, LEAVES[+d.leaf])};\n`;
      case "literalBad": {
        const v = R.val(n, LEAVES[+d.leaf]);
        return `${pre}const t: A<${t}> = ${v.replace(/\b1\b(?![\s\S]*\b1\b)/, "\"bad\"")};\n`;
      }
      case "infer": return `${pre}declare function f<T>(x: A<T>): T;\nconst r = f(${R.val(n, LEAVES[+d.leaf])});\n`;
      case "inferTwin": return `${pre}declare function f<T>(x: A<T>): T;\ndeclare const b: B<${s}>;\nconst r = f(b);\n`;
      case "argNested": return `${pre}declare function f<T>(x: A<A<T>>): T;\ndeclare const b: B<B<${s}>>;\nconst r = f(b);\n`;
      default: return `${pre}declare const s: A<${s}>;\nconst t: A<${t}> = s;\n`;
    }
  },
};

// Family: relations between expanding recursive types whose difference only appears at nesting level k,
// exercising the deeply-nested-type cutoff of structural comparison.
const GROW: Record<string, (t: string) => string> = { obj: (t) => `{ w: ${t} }`, arr: (t) => `${t}[]`, box: (t) => `Box<${t}>`, tuple: (t) => `[${t}]`, fn: (t) => `() => ${t}` };
export const recDepthFam: Family = {
  name: "recursive-depth",
  dims: {
    k: ["3", "0", "1", "2", "4", "5", "6"],
    grow: Object.keys(GROW),
    kind: ["interface", "alias", "class", "aliasUnion", "mapped", "partial"],
    diff: ["cond", "condSame", "leafProp", "optional"],
    dir: ["ab", "ba"],
    pos: ["v", "fnRet", "method"],
    wrap: ["none", "union", "array", "generic"],
  },
  render(d) {
    const g = GROW[d.grow], k = +d.k;
    if (k === 2 && (d.kind === "interface" || d.kind === "class")) return null; // cutoff-sensitive at this depth for nominal-identity declarations
    let pat = "unknown";
    for (let i = 0; i < k; i++) pat = g(pat);
    const vA = "T";
    let vB: string, extraB = "";
    switch (d.diff) {
      case "condSame": vB = `T extends ${pat} ? T : T`; break;
      case "leafProp": vB = "T"; extraB = `; x${"?"}: T extends ${pat} ? string : unknown`; break;
      case "optional": vB = "T"; extraB = `; x: T extends ${pat} ? string : unknown`; break;
      default: vB = `T extends ${pat} ? string : T`; break;
    }
    const extraA = d.diff === "leafProp" || d.diff === "optional" ? "; x?: number" : "";
    const P = (v: string) => d.pos === "fnRet" ? `v: () => ${v}` : d.pos === "method" ? `v(): ${v}` : `v: ${v}`;
    const body = (N: string, v: string, extra: string) => `${P(v)}; n?: ${N}<${g("T")}>${extra}`;
    let decl: string;
    switch (d.kind) {
      case "alias": decl = `type A<T> = { ${body("A", vA, extraA)} };\ntype B<T> = { ${body("B", vB, extraB)} };`; break;
      case "class": decl = `declare class A<T> { ${body("A", vA, extraA)} }\ndeclare class B<T> { ${body("B", vB, extraB)} }`; break;
      case "mapped": decl = `type Id<X> = { [P in keyof X]: X[P] };\ntype A<T> = Id<{ ${body("A", vA, extraA)} }>;\ntype B<T> = Id<{ ${body("B", vB, extraB)} }>;`; break;
      case "partial": decl = `type A<T> = Partial<{ ${body("A", vA, extraA)} }>;\ntype B<T> = Partial<{ ${body("B", vB, extraB)} }>;`; break;
      case "aliasUnion": decl = `type A<T> = null | { ${body("A", vA, extraA)} };\ntype B<T> = null | { ${body("B", vB, extraB)} };`; break;
      default: decl = `interface A<T> { ${body("A", vA, extraA)} }\ninterface B<T> { ${body("B", vB, extraB)} }`; break;
    }
    const [S, Tn] = d.dir === "ab" ? ["A", "B"] : ["B", "A"];
    const pre = `interface Box<X> { b: X }\n${decl}\n`;
    switch (d.wrap) {
      case "union": return `${pre}declare const s: ${S}<number> | undefined;\nconst t: ${Tn}<number> | undefined = s;\n`;
      case "array": return `${pre}declare const s: ${S}<number>[];\nconst t: ${Tn}<number>[] = s;\n`;
      case "generic": return `${pre}function f<X extends number>(s: ${S}<X>) {\n  const t: ${Tn}<X> = s;\n}\n`;
      default: return `${pre}declare const s: ${S}<number>;\nconst t: ${Tn}<number> = s;\n`;
    }
  },
};

// Family: recursive conditional types (tail and non-tail recursion over tuples, strings and numbers)
// evaluated at varying sizes, observed through their computed types.
const RCOND: Record<string, { decl: string; use: (n: number) => string }> = {
  buildTail: { decl: "type Build<N extends number, Acc extends unknown[] = []> = Acc[\"length\"] extends N ? Acc : Build<N, [...Acc, 0]>;", use: (n) => `Build<${n}>["length"]` },
  buildNonTail: { decl: "type Build<N extends number, Acc extends unknown[] = []> = Acc[\"length\"] extends N ? Acc : [0, ...Build<N, [...Acc, 0]>];", use: (n) => `Build<${n}>["length"]` },
  reverse: { decl: "type Rev<T extends unknown[], Acc extends unknown[] = []> = T extends [infer H, ...infer R] ? Rev<R, [H, ...Acc]> : Acc;\ntype Rng<N extends number, A extends number[] = []> = A[\"length\"] extends N ? A : Rng<N, [...A, A[\"length\"]]>;", use: (n) => `Rev<Rng<${n}>>[0]` },
  reverseNonTail: { decl: "type Rev<T extends unknown[]> = T extends [infer H, ...infer R] ? [...Rev<R>, H] : [];\ntype Rng<N extends number, A extends number[] = []> = A[\"length\"] extends N ? A : Rng<N, [...A, A[\"length\"]]>;", use: (n) => `Rev<Rng<${n}>>[0]` },
  strLen: { decl: "type Len<S extends string, A extends 0[] = []> = S extends `${string}${infer R}` ? (S extends \"\" ? A[\"length\"] : Len<R, [...A, 0]>) : A[\"length\"];\ntype Rep<N extends number, S extends string = \"\", A extends 0[] = []> = A[\"length\"] extends N ? S : Rep<N, `${S}a`, [...A, 0]>;", use: (n) => `Len<Rep<${n}>>` },
  trim: { decl: "type Trim<S extends string> = S extends ` ${infer R}` ? Trim<R> : S;\ntype Pad<N extends number, S extends string = \"x\", A extends 0[] = []> = A[\"length\"] extends N ? S : Pad<N, ` ${S}`, [...A, 0]>;", use: (n) => `Trim<Pad<${n}>>` },
  flatten: { decl: "type Flat<T> = T extends readonly (infer U)[] ? Flat<U> : T;\ntype Nest<N extends number, T = 1, A extends 0[] = []> = A[\"length\"] extends N ? T : Nest<N, T[], [...A, 0]>;", use: (n) => `Flat<Nest<${n}>>` },
  unionLoop: { decl: "type U<N extends number, A extends unknown[] = []> = A[\"length\"] extends N ? A[\"length\"] : A[\"length\"] | U<N, [...A, 0]>;", use: (n) => `Exclude<U<${n}>, 0>` },
  deepObj: { decl: "type D<N extends number, A extends 0[] = []> = A[\"length\"] extends N ? 1 : { n: D<N, [...A, 0]> };\ntype Get<T> = T extends { n: infer R } ? Get<R> : T;", use: (n) => `Get<D<${n}>>` },
  splitJoin: { decl: "type Split<S extends string> = S extends `${infer H},${infer R}` ? [H, ...Split<R>] : [S];\ntype Rep<N extends number, S extends string = \"a\", A extends 0[] = [0]> = A[\"length\"] extends N ? S : Rep<N, `${S},a`, [...A, 0]>;", use: (n) => `Split<Rep<${n}>>["length"]` },
};
export const recCondFam: Family = {
  name: "recursive-conditional",
  dims: {
    t: Object.keys(RCOND),
    n: ["5", "1", "2", "10", "20", "30", "40", "45", "48", "49", "50", "60", "100", "200", "999"],
    obs: ["typed", "assignNum", "generic"],
  },
  render(d) {
    const R = RCOND[d.t];
    const n = +d.n;
    const pre = R.decl + "\n";
    switch (d.obs) {
      case "assignNum": return `${pre}type X = ${R.use(n)};\ndeclare const x: X;\nconst y: number = x;\n`;
      case "generic": return `${pre}function f<K extends number>(k: K) {\n  type X = ${R.use(n)};\n  const x: X = null!;\n  return x;\n}\nconst q = f(1);\nconst r: unknown = q;\n`;
      default: return `${pre}type X = ${R.use(n)};\ndeclare const x: X;\nconst r: X = x;\n`;
    }
  },
};
