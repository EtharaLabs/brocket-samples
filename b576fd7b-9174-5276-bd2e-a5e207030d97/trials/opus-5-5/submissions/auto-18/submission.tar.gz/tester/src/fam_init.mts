// Family: definite assignment analysis — class property initialization in constructors and
// use-before-assignment of locals — across control-flow shapes, never-returning calls and assertions.
import type { Family } from "./family.mts";

// statement shapes assigning target X (X is `this.x` or `x`); C is a condition
const SHAPES: Record<string, string> = {
  direct: "X = 1;",
  ifOnly: "if (C) X = 1;",
  ifElse: "if (C) X = 1;\nelse X = 2;",
  ifElseThrow: "if (C) X = 1;\nelse throw new Error();",
  ifElseFail: "if (C) X = 1;\nelse fail();",
  ifElseFailObj: "if (C) X = 1;\nelse ns.fail();",
  ifReturn: "if (C) return;\nX = 1;",
  switchDefault: "switch (k) {\n  case 0: X = 1; break;\n  default: X = 2;\n}",
  switchNoDefault: "switch (k) {\n  case 0: X = 1; break;\n  case 1: X = 2; break;\n}",
  switchExhaustive: "switch (b) {\n  case true: X = 1; break;\n  case false: X = 2; break;\n}",
  forLoop: "for (let i = 0; i < 1; i++) X = 1;",
  whileTrue: "while (true) {\n  X = 1;\n  break;\n}",
  doWhile: "do {\n  X = 1;\n} while (C);",
  tryFinally: "try {\n  g();\n} finally {\n  X = 1;\n}",
  tryCatch: "try {\n  X = 1;\n} catch {\n  X = 2;\n}",
  tryOnly: "try {\n  X = 1;\n} catch { }",
  arrowAssign: "const h = () => { X = 1; };\nh();",
  destructure: "[X] = [1];",
  objDestructure: "({ v: X } = { v: 1 });",
  compound: "X ??= 1;",
  logicalAnd: "C && (X = 1);",
  ternary: "C ? (X = 1) : (X = 2);",
  assertCall: "X = 1;\nassertTrue(C);",
  assertThenAssign: "assertTrue(C);\nX = 1;",
  neverConst: "if (C) X = 1;\nelse failConst();",
  labeledBreak: "out: {\n  if (C) break out;\n  X = 1;\n}",
  nested: "if (C) {\n  if (C) X = 1;\n  else X = 2;\n} else X = 3;",
  forOfAssign: "for (const v of [1]) X = v;",
  exhaustiveIfUnion: "if (k === 0) X = 1;\nelse if (k === 1) X = 2;",
  neverSwitchDefault: "switch (k) {\n  case 0: X = 1; break;\n  case 1: X = 2; break;\n  default: fail();\n}",
};

export const initFam: Family = {
  name: "definite-assignment",
  dims: {
    shape: Object.keys(SHAPES),
    target: ["classField", "local", "localUnion", "classFieldUnion", "privateField", "classFieldGeneric", "localConstLater"],
    cond: ["flag", "true", "false", "kIsZero"],
    use: ["read", "readInClosure", "readTypeofNarrow", "none"],
  },
  render(d) {
    const C = d.cond === "flag" ? "flag" : d.cond === "kIsZero" ? "k === 0" : d.cond;
    const pre = `declare function fail(): never;\ndeclare const ns: { fail(): never };\ndeclare function g(): void;\ndeclare function assertTrue(v: unknown): asserts v;\nconst failConst: () => never = () => { throw 0; };\n`;
    const isClass = /^class|^private/.test(d.target);
    const X = d.target === "privateField" ? "this.#x" : isClass ? "this.x" : "x";
    let body = SHAPES[d.shape].replace(/\bX\b/g, X).replace(/\bC\b/g, C);
    if (d.target === "localConstLater" && /\bv\b/.test(body)) return null;
    const ind = (s: string, n: string) => s.split("\n").map((l) => n + l).join("\n");
    const T = d.target === "localUnion" || d.target === "classFieldUnion" ? "number | string" : d.target === "classFieldGeneric" ? "T" : "number";
    if (d.target === "classFieldGeneric") body = body.replace(/= (\d)\b/g, "= $1 as T").replace(/\[1\]/g, "[1 as T]").replace(/\{ v: 1 \}/g, "{ v: 1 as T }").replace(/X = v;/, "X = v as T;").replace(/this\.x = v;/, "this.x = v as T;");
    let use: string;
    const R = X;
    switch (d.use) {
      case "read": use = `const r: ${T} = ${R};`; break;
      case "readInClosure": use = `const r = () => ${R};`; break;
      case "readTypeofNarrow": use = `if (typeof ${R} === "number") { const r: number = ${R}; }`; break;
      default: use = ""; break;
    }
    if (isClass) {
      const decl = d.target === "privateField" ? `#x: ${T};` : `x: ${T};`;
      const tp = d.target === "classFieldGeneric" ? "<T>" : "";
      return `${pre}class K${tp} {\n  ${decl}\n  constructor(flag: boolean, k: 0 | 1, b: boolean) {\n${ind(body, "    ")}${use ? "\n    " + use : ""}\n  }\n}\n`;
    }
    const declLine = d.target === "localConstLater" ? `let x: ${T};` : `let x: ${T};`;
    return `${pre}function f(flag: boolean, k: 0 | 1, b: boolean) {\n  ${declLine}\n${ind(body, "  ")}${use ? "\n  " + use : ""}\n}\n`;
  },
};
