// Type-observation variants: after each check statement `const v: T = <reference>;` a statement
// `const v__o: never = <reference>;` is added on a line of its own, so the type of <reference> at that
// point appears in a diagnostic and can be compared.
const MARK = /const (\w+): (.+?) = ([\w$]+(?:\.[\w$]+|\[\d+\])*);/g;

export interface Typed { src: string; marks: number[]; origin: [number, number][]; } // marks: 1-based lines within src

export function typedVariant(src: string): Typed | null {
  const out: string[] = [];
  const marks: number[] = [];
  const origin: [number, number][] = [];
  src.split("\n").forEach((line, li) => {
    let k = -1, last = 0, cur = "";
    for (const m of line.matchAll(MARK)) {
      k++;
      if (m[2] === "never") continue;
      const end = m.index! + m[0].length;
      out.push(cur + line.slice(last, end));
      out.push(`const ${m[1]}__o: never = ${m[3]};`);
      cur = "";
      marks.push(out.length);
      origin.push([li + 1, k]);
      last = end;
    }
    out.push(cur + line.slice(last));
  });
  return marks.length ? { src: out.join("\n"), marks, origin } : null;
}

// Per-line diagnostics: line -> list of first-line messages.
export function diagnostics(out: string): Map<number, string[]> {
  const m = new Map<number, string[]>();
  const re = /^p\.ts\((\d+),\d+\): error TS\d+: (.*)$/gm;
  let x;
  while ((x = re.exec(out))) {
    const l = +x[1];
    if (!m.has(l)) m.set(l, []);
    m.get(l)!.push(x[2]);
  }
  return m;
}

// Type text reported for a `never` check line, or "" when there is none.
export function observed(msgs: string[] | undefined): string {
  for (const s of msgs ?? []) {
    const mm = /^Type '(.*)' is not assignable to type 'never'\.$/.exec(s);
    if (mm) return mm[1].includes("...") ? "~" : mm[1];
  }
  return "";
}

// Fingerprint insensitive to union member order (not stable between implementations) and to literal
// widening (literal retention in inferred types is not compared; literal checks stay as ordinary checks).
export function fingerprint(t: string): string {
  const w = t.replace(/"(?:[^"\\]|\\.)*"/g, "string").replace(/\b\d+n\b/g, "bigint")
    .replace(/-?\b\d+(?:\.\d+)?\b/g, "number").replace(/\b(?:true|false)\b/g, "boolean").replace(/\breadonly /g, "");
  return fp(w);
}
function fp(w: string): string {
  const members: string[] = [];
  let depth = 0, cur = "";
  for (let i = 0; i < w.length; i++) {
    const ch = w[i];
    if (depth === 0 && w.startsWith("=> ", i)) { cur += "=>{" + fp(w.slice(i + 3)) + "}"; i = w.length; break; }
    if ("([{<".includes(ch)) depth++;
    else if (")]}>".includes(ch) && !(ch === ">" && w[i - 1] === "=")) depth--;
    if (depth === 0 && w.startsWith(" | ", i)) { members.push(cur); cur = ""; i += 2; continue; }
    cur += ch;
  }
  members.push(cur);
  return [...new Set(members.map((m) => m.replace(/[()]/g, "").split("").sort().join("")))].sort().join("|");
}

export const EQ = "type __Eq<A, B> = (<Q>() => Q extends A ? 1 : 2) extends (<Q>() => Q extends B ? 1 : 2) ? true : false;\n";

// Source asserting the observed type `t` exactly at observation `mark` (a typed-variant line) of src.
export function exactWitness(src: string, mark: number, t: string): string | null {
  if (!t || t === "~" || t.includes("...")) return null;
  const tv = typedVariant(src);
  const i = tv ? tv.marks.indexOf(mark) : -1;
  if (i < 0) return null;
  const [line, k] = tv!.origin[i];
  const lines = src.split("\n");
  let n = -1;
  lines[line - 1] = lines[line - 1].replace(MARK, (all, v, _ty, ref) =>
    ++n === k ? `const __t = ${ref};\nconst ${v}: __Eq<typeof __t, ${t}> = true;` : all);
  return EQ + lines.join("\n");
}
