// Family: inference of several related type parameters (keyof constraints, indexed access,
// mapped key sets, dependent constraints) from object, key and callback arguments.
import type { Family } from "./family.mts";

const SIGS: Record<string, [string, string]> = {
  // [declaration, call with O = object arg, K = key arg, F = callback arg]
  getProp: ["declare function f<T, K extends keyof T>(o: T, k: K): T[K];", "f(O, K)"],
  keyFirst: ["declare function f<K extends keyof T, T>(k: K, o: T): T[K];", "f(K, O)"],
  keysToRecord: ["declare function f<K extends string, V>(o: { [P in K]: V }): [K, V];", "f(O)"],
  recordKV: ["declare function f<K extends PropertyKey, V>(o: Record<K, V>): [K, V];", "f(O)"],
  pickKeys: ["declare function f<T, K extends keyof T>(o: T, ...ks: K[]): Pick<T, K>;", "f(O, K)"],
  mapValues: ["declare function f<T, U>(o: T, fn: (v: T[keyof T]) => U): { [P in keyof T]: U };", "f(O, F)"],
  setter: ["declare function f<T, K extends keyof T>(o: T, k: K, v: T[K]): void;", "f(O, K, V)"],
  dependent: ["declare function f<T, U extends T>(a: T, b: U): [T, U];", "f(O, O2)"],
  defaulted: ["declare function f<T, U = T[]>(a: T, b?: U): [T, U];", "f(O)"],
  keyCb: ["declare function f<T, K extends keyof T>(o: T, cb: (k: K) => void): K;", "f(O, F)"],
  partialMerge: ["declare function f<T>(a: T, b: Partial<T>): T;", "f(O, O2)"],
  keyUnion: ["declare function f<T extends object, K extends keyof T = keyof T>(o: T, ks: readonly K[]): K;", "f(O, [K])"],
  eventMap: ["interface EM { a: { x: 1 }; b: { y: \"s\" } }\ndeclare function f<K extends keyof EM>(k: K, cb: (e: EM[K]) => void): K;", "f(K, F)"],
  tupleKeys: ["declare function f<T extends readonly unknown[], I extends keyof T & `${number}`>(t: T, i: I): T[I];", "f(O, K)"],
  inverted: ["declare function f<T extends Record<string, PropertyKey>>(o: T): { [P in keyof T as T[P]]: P };", "f(O)"],
  constPair: ["declare function f<const T, K extends keyof T>(o: T, k: K): [T, K];", "f(O, K)"],
};

const OBJS = ["{ a: 1, b: \"s\" }", "{ a: \"x\", b: \"y\" } as const", "[1, \"s\"] as const", "{}", "{ a: () => 1 }", "{ 0: 1, a: [1] }", "obj", "tup", "Math.random() ? { a: 1 } : { a: \"s\", b: 2 }"];
const KEYS = ["\"a\"", "\"b\"", "\"0\"", "\"c\"", "k", "\"a\" as \"a\" | \"b\""];
const CBS = ["(k) => {\n  const ok: unknown = k;\n}", "(v) => [v]", "(e) => {\n  const oe: unknown = e;\n}", "(x: unknown) => 1"];

export const multiFam: Family = {
  name: "multi-parameter-inference",
  labelOf(k, v) { return k === "o" || k === "o2" ? OBJS[+v] : k === "k" ? KEYS[+v] : k === "cb" ? CBS[+v] : v; },
  dims: {
    sig: Object.keys(SIGS),
    o: OBJS.map((_, i) => String(i)),
    k: KEYS.map((_, i) => String(i)),
    cb: CBS.map((_, i) => String(i)),
    o2: OBJS.map((_, i) => String(i)),
    ctx: ["none", "annotated", "returned"],
  },
  render(d) {
    const [decl, call0] = SIGS[d.sig];
    const call = call0.replace("O2", OBJS[+d.o2]).replace("O", OBJS[+d.o]).replace("K", KEYS[+d.k]).replace("F", CBS[+d.cb]).replace("V", "1");
    const pre = "declare const obj: { a: number; b?: string; readonly c: boolean };\ndeclare const tup: [string, number?];\ndeclare const k: \"a\" | \"c\";\n";
    let body: string;
    switch (d.ctx) {
      case "none": body = `const r = ${call};\nconst o: unknown = r;`; break;
      case "annotated": body = `declare function take<Z>(z: Z): Z;\nconst r = take(${call});\nconst o: unknown = r;`; break;
      default: body = `function g() {\n  return ${call};\n}\nconst r = g();\nconst o: unknown = r;`; break;
    }
    return decl + "\n" + pre + body + "\n";
  },
};
