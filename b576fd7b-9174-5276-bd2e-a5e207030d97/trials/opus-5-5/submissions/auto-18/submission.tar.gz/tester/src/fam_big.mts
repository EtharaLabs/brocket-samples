// Family: discriminated unions of many members (narrowing, contextual discrimination, relations),
// with member counts on both sides of the sizes where checkers switch to keyed lookups.
import type { Family } from "./family.mts";

export const bigFam: Family = {
  name: "large-union",
  dims: {
    n: ["12", "3", "9", "10", "11", "16", "30"],
    disc: ["str", "num", "litUnion", "lastString", "optional", "twoKeys", "bool2", "tpl"],
    op: ["ifEq", "switch", "switchFall", "destr", "destrSwitch", "neqReturn", "assignLit", "assignLitWrong", "excess", "relateObj", "relateObjWrong",
      "relateSub", "extract", "ctxCallback", "genericNarrow", "inOp", "mapIndex", "arrayFind", "ternaryChain", "arrayLit", "relateObjAll", "relateObjSome"],
    at: ["mid", "first", "last"],
    holder: ["param", "const", "prop", "elem", "optChain"],
    decl: ["alias", "interfaces"],
    dup: ["none", "dupTarget", "dupOther"],
  },
  render(d) {
    let n = +d.n;
    if (d.disc === "bool2") n = Math.min(n, 2);
    const idx = d.at === "first" ? 0 : d.at === "last" ? n - 1 : n >> 1;
    const other = (idx + 1) % n;
    const lit = (i: number) => d.disc === "num" ? String(i) : d.disc === "bool2" ? (i === 0 ? "true" : "false") : `"k${i}"`;
    const ktype = (i: number): string => {
      switch (d.disc) {
        case "litUnion": return `${lit(i)} | "x${i}"`;
        case "lastString": return i === n - 1 && i !== idx ? "string" : lit(i);
        case "tpl": return i === n - 1 && i !== idx ? "`z${string}`" : lit(i);
        default: return lit(i);
      }
    };
    const kf = (i: number) => d.disc === "optional" && i === n - 1 && i !== idx ? "kind?: undefined" : `kind: ${ktype(i)}`;
    const extraKey = (i: number) => d.disc === "twoKeys" ? `; sub: ${i % 2 === 0 ? "\"e\"" : "\"o\""}` : "";
    const body = (i: number) => `${kf(i)}${extraKey(i)}; p${i}: { t${i}: ${i} }; cb: (v: { c${i}: ${i} }) => void`;
    let pre = "";
    // optional extra member repeating the discriminant value of another member
    const dupOf = d.dup === "dupTarget" ? idx : d.dup === "dupOther" ? other : -1;
    const bodies = Array.from({ length: n }, (_, i) => body(i));
    if (dupOf >= 0) bodies.push(`${body(dupOf)}; dup: 1`);
    if (d.decl === "alias") pre += `type U = ${bodies.map((b) => `{ ${b} }`).join("\n  | ")};\n`;
    else {
      bodies.forEach((b, i) => { pre += `interface M${i} { ${b} }\n`; });
      pre += `type U = ${bodies.map((_, i) => `M${i}`).join(" | ")};\n`;
    }
    const K = lit(idx), P = `p${idx}`, PT = `{ t${idx}: ${idx} }`;
    const sub = d.disc === "twoKeys" ? `, sub: ${idx % 2 === 0 ? "\"e\"" : "\"o\""}` : "";
    const litVal = (i: number, wrong: boolean) => `{ kind: ${lit(i)}${d.disc === "twoKeys" ? `, sub: ${i % 2 === 0 ? "\"e\"" : "\"o\""}` : ""}, p${i}: { t${i}: ${wrong ? i + 100 : i} }, cb: (v) => {\n    const cv: { c${i}: ${i} } = v;\n  } }`;
    let sig = "x: U", H = "x", head = "";
    switch (d.holder) {
      case "const": sig = "x0: U"; head = "const x = x0;\n  "; break;
      case "prop": sig = "o: { readonly v: U }"; H = "o.v"; break;
      case "elem": sig = "a: readonly U[]"; H = "a[0]"; break;
      case "optChain": sig = "x: U | undefined"; break;
    }
    const dot = d.holder === "optChain" ? "?." : ".";
    const KX = `${H}${dot}kind`;
    const use = `const v: ${PT} = ${H}${d.holder === "optChain" ? "!" : ""}.${P};`;
    const fn = (s: string) => `${pre}function f(${sig}) {\n  ${head}${s}\n}\n`;
    const destrOk = d.holder !== "optChain";
    switch (d.op) {
      case "ifEq": return fn(`if (${KX} === ${K}) {\n    ${use}\n  }`);
      case "switch": return fn(`switch (${KX}) {\n    case ${K}: {\n      ${use}\n      break;\n    }\n  }`);
      case "switchFall": return fn(`switch (${KX}) {\n    case ${lit(other)}:\n    case ${K}: {\n      const v: ${PT} | { t${other}: ${other} } = "${P}" in ${H}${d.holder === "optChain" ? "!" : ""} ? ${H}${d.holder === "optChain" ? "!" : ""}.${P} : ${H}${d.holder === "optChain" ? "!" : ""}.p${other};\n      break;\n    }\n  }`);
      case "destr": if (!destrOk) return null; return fn(`const { kind, ${P}: pv } = ${H} as Extract<U, { kind: ${K} }> | Extract<U, { kind: ${lit(other)} }>;\n  if (kind === ${K}) {\n    const v: ${PT} = pv;\n  }`);
      case "destrSwitch": if (!destrOk) return null; return fn(`const { kind, cb } = ${H};\n  switch (kind) {\n    case ${K}: {\n      cb({ c${idx}: ${idx} });\n      break;\n    }\n  }`);
      case "neqReturn": return fn(`if (${KX} !== ${K}) return;\n  ${use}`);
      case "assignLit": return `${pre}const v: U = ${litVal(idx, false)};\n`;
      case "assignLitWrong": return `${pre}const v: U = ${litVal(idx, true)};\n`;
      case "excess": return `${pre}const v: U = { kind: ${lit(idx)}${sub}, p${idx}: { t${idx}: ${idx} }, cb: () => { }, p${other}: { t${other}: ${other} } };\n`;
      case "relateObj": {
        if (d.disc === "lastString" || d.disc === "tpl" || d.disc === "optional") return null;
        return `${pre}declare const s: { kind: ${lit(idx)} | ${lit(other)}${d.disc === "twoKeys" ? ", sub: \"e\" | \"o\"" : ""}; p${idx}: { t${idx}: ${idx} }; p${other}: { t${other}: ${other} }; cb: (v: any) => void };\nconst v: U = s;\n`.replace(/(kind: [^;]+), sub/, "$1; sub");
      }
      case "relateObjAll": case "relateObjSome": {
        // source object whose discriminant is a union over many members (combination expansion)
        if (d.disc === "lastString" || d.disc === "tpl" || d.disc === "optional" || d.dup !== "none") return null;
        const ks = d.op === "relateObjAll" ? Array.from({ length: n }, (_, i) => i) : [idx, other, (idx + 2) % n, (idx + 3) % n, (idx + 4) % n].filter((v, i, a) => a.indexOf(v) === i);
        const kt = d.disc === "litUnion" ? ks.map((i) => ktype(i)).join(" | ") : ks.map((i) => lit(i)).join(" | ");
        const props = ks.map((i) => `p${i}: { t${i}: ${i} }`).join("; ");
        return `${pre}declare const s: { kind: ${kt}${d.disc === "twoKeys" ? "; sub: \"e\" | \"o\"" : ""}; ${props}; cb: (v: any) => void };\nconst v: U = s;\n`;
      }
      case "relateObjWrong": return `${pre}declare const s: { kind: ${lit(idx)} | ${lit(other)}; p${idx}: { t${idx}: ${idx} }; cb: (v: any) => void };\nconst v: U = s;\n`;
      case "relateSub": return `${pre}declare const s: Extract<U, { kind: ${K} }> | Extract<U, { kind: ${lit(other)} }>;\nconst v: U = s;\nconst w: Exclude<U, { kind: ${K} }> = s;\n`;
      case "extract": return `${pre}declare const s: Extract<U, { kind: ${K} }>;\nconst v: ${PT} = s.${P};\n`;
      case "ctxCallback": return `${pre}declare function take(u: U): void;\ntake({ kind: ${lit(idx)}${sub}, ${P}: { t${idx}: ${idx} }, cb: (v) => {\n  const cv: { c${idx}: ${idx} } = v;\n} });\n`;
      case "genericNarrow": return `${pre}function f<T extends U>(x: T) {\n  if (x.kind === ${K}) {\n    const v: ${PT} = x.${P};\n  }\n}\n`;
      case "inOp": return fn(`if (${d.holder === "optChain" ? `${H} && ` : ""}"${P}" in ${H}) {\n    const v: ${PT} = ${H}.${P};\n  }`);
      case "mapIndex": return `${pre}type ByKind = { [M in U as M["kind"] & PropertyKey]: M };\ndeclare const s: ByKind[${K}];\nconst v: ${PT} = s.${P};\n`;
      case "arrayFind": return `${pre}declare const a: U[];\nconst e = a.find((u): u is Extract<U, { kind: ${K} }> => u.kind === ${K});\nif (e) {\n  const v: ${PT} = e.${P};\n}\n`;
      case "ternaryChain": return fn(`const v: ${PT} | 0 = ${KX} === ${lit(other)} ? 0 : ${KX} === ${K} ? ${H}${d.holder === "optChain" ? "!" : ""}.${P} : 0;`);
      default: return `${pre}const arr: U[] = [${litVal(idx, false)}, ${litVal(other, false)}];\n`;
    }
  },
};
