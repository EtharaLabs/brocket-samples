// Pairwise covering rows over a family's dimension space: every (dim=value, dim'=value') combination
// appears in at least one row (greedy construction, ties broken by the seeded rng).
import type { Family, Dims } from "./family.mts";
import type { Rng } from "./rng.mts";

export function pairwiseRows(fam: Family, rng: Rng, max = Infinity): Dims[] {
  const keys = Object.keys(fam.dims);
  const k = keys.length;
  const nv = keys.map((key) => fam.dims[key].length);
  const off: number[][] = [];
  let total = 0;
  for (let i = 0; i < k; i++) { off.push([]); for (let j = 0; j < k; j++) { off[i].push(total); if (j > i) total += nv[i] * nv[j]; } }
  const id = (i: number, a: number, j: number, b: number) => i < j ? off[i][j] + a * nv[j] + b : off[j][i] + b * nv[i] + a;
  const covered = new Uint8Array(total);
  let left = total;
  // visit pairs in a shuffled order so that row seeds vary with the rng
  const order = Array.from({ length: total }, (_, x) => x);
  for (let x = total - 1; x > 0; x--) { const y = Math.floor(rng() * (x + 1)); [order[x], order[y]] = [order[y], order[x]]; }
  const decode = (p: number): [number, number, number, number] => {
    for (let i = 0; i < k; i++) for (let j = i + 1; j < k; j++) {
      const o = off[i][j];
      if (p >= o && p < o + nv[i] * nv[j]) return [i, Math.floor((p - o) / nv[j]), j, (p - o) % nv[j]];
    }
    throw new Error("bad pair");
  };
  const rows: Dims[] = [];
  let cursor = 0;
  while (left > 0 && rows.length < max) {
    while (covered[order[cursor]]) cursor++;
    const [i, a, j, b] = decode(order[cursor]);
    const row = new Array<number>(k).fill(-1);
    row[i] = a; row[j] = b;
    const rest = keys.map((_, m) => m).filter((m) => m !== i && m !== j);
    for (let x = rest.length - 1; x > 0; x--) { const y = Math.floor(rng() * (x + 1)); [rest[x], rest[y]] = [rest[y], rest[x]]; }
    for (const m of rest) {
      let best = -1, bestV = 0, ties = 0;
      for (let v = 0; v < nv[m]; v++) {
        let g = 0;
        for (let q = 0; q < k; q++) if (row[q] >= 0 && !covered[id(m, v, q, row[q])]) g++;
        if (g > best) { best = g; bestV = v; ties = 1; } else if (g === best && rng() * ++ties < 1) bestV = v;
      }
      row[m] = bestV;
    }
    for (let p = 0; p < k; p++) for (let q = p + 1; q < k; q++) { const c = id(p, row[p], q, row[q]); if (!covered[c]) { covered[c] = 1; left--; } }
    const d: Dims = {};
    keys.forEach((key, m) => { d[key] = fam.dims[key][row[m]]; });
    rows.push(d);
  }
  return rows;
}

// Rows equal to the family defaults except in exactly two dimensions, in rng-shuffled order.
export function defaultPairRows(fam: Family, rng: Rng, max: number): Dims[] {
  const keys = Object.keys(fam.dims);
  const all: [number, number, number, number][] = [];
  for (let i = 0; i < keys.length; i++) for (let j = i + 1; j < keys.length; j++)
    for (let a = 1; a < fam.dims[keys[i]].length; a++) for (let b = 1; b < fam.dims[keys[j]].length; b++) all.push([i, a, j, b]);
  const out: Dims[] = [];
  for (let x = 0; x < all.length && out.length < max; x++) {
    const y = x + Math.floor(rng() * (all.length - x));
    [all[x], all[y]] = [all[y], all[x]];
    const [i, a, j, b] = all[x];
    const d: Dims = {};
    for (const k of keys) d[k] = fam.dims[k][0];
    d[keys[i]] = fam.dims[keys[i]][a];
    d[keys[j]] = fam.dims[keys[j]][b];
    out.push(d);
  }
  return out;
}
