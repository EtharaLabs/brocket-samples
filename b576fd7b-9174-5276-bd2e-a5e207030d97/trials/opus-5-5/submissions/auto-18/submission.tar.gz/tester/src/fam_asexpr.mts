// Family: narrowing by compound condition expressions (||, &&, !) passed to assertion functions,
// type guards and throw-guards, over subjects of union or union-constrained generic type.
import type { Family } from "./family.mts";

// [constituents, guard atoms selecting constituent i]
const DECLS: [string[], string[]][] = [
  [["string", "number", "undefined"], ["typeof X === \"string\"", "typeof X === \"number\"", "X === undefined"]],
  [["{ kind: \"a\"; a: number }", "{ kind: \"b\"; b: string }", "{ kind: \"c\"; c: boolean }"], ["X.kind === \"a\"", "X.kind === \"b\"", "X.kind === \"c\""]],
  [["{ a: number }", "{ b: string }", "{ c: boolean }"], ["\"a\" in X", "\"b\" in X", "\"c\" in X"]],
  [["Date", "RegExp", "string[]"], ["X instanceof Date", "X instanceof RegExp", "Array.isArray(X)"]],
  [["\"x\"", "1", "null"], ["X === \"x\"", "X === 1", "X === null"]],
  [["{ kind: \"a\"; a: number }", "{ kind: \"b\"; b: string }", "{ kind: \"c\"; c: boolean }"], ["X.kind == \"a\"", "X.kind != \"b\" && X.kind != \"c\"", "typeof X.kind === \"string\" && X.kind === \"c\""]],
  [["{ a: number; z?: 1 }", "{ b: string; z?: 1 }", "{ c: boolean }"], ["\"a\" in X", "\"b\" in X", "!(\"z\" in X)"]],
  [["{ kind: \"a\"; a: number }", "{ kind: 1; b: string }", "{ kind: true; c: boolean }"], ["typeof X.kind === \"string\"", "typeof X.kind === \"number\"", "typeof X.kind === \"boolean\""]],
  [["{ kind: \"a\"; a: number }", "{ kind: undefined; b: string }", "{ kind: null; c: boolean }"], ["typeof X.kind === \"string\"", "X.kind === undefined", "X.kind === null"]],
];
const EXPRS = ["g0 || g1", "g0", "g1 || g0", "!(g0 || g1)", "!g2", "(g0 || g1) && !g0", "g0 || g1 || g2", "!(!g0)", "g0 && g0", "(g0) || (g1)", "!(g2 || g0)", "g0 || g1 && g2"];

export const asExprFam: Family = {
  name: "compound-guard",
  dims: {
    decl: DECLS.map((_, i) => String(i)),
    e: EXPRS.map((_, i) => String(i)),
    how: ["assertTruthy", "ifThrow", "guardIf", "guardElse", "assertMsg", "methodAssert", "ternary", "earlyReturn", "while"],
    holder: ["param", "generic", "prop", "const", "genericProp"],
    t: ["0", "1", "2", "01", "12", "02", "all"],
  },
  render(d) {
    const [cs, gs] = DECLS[+d.decl];
    const U = cs.join(" | ");
    let sig: string, X: string;
    switch (d.holder) {
      case "generic": sig = `<V extends ${U}>(x: V)`; X = "x"; break;
      case "prop": sig = `(o: { readonly v: ${U} })`; X = "o.v"; break;
      case "genericProp": sig = `<V extends { readonly v: ${U} }>(o: V)`; X = "o.v"; break;
      case "const": sig = `(x0: ${U})`; X = "x"; break;
      default: sig = `(x: ${U})`; X = "x"; break;
    }
    const E = EXPRS[+d.e].replace(/g(\d)/g, (_, i) => gs[+i].replace(/\bX\b/g, X));
    const T = d.t === "all" ? U : d.t.split("").map((i) => cs[+i]).join(" | ");
    const use = `const v: ${T} = ${X};`;
    let body: string;
    switch (d.how) {
      case "ifThrow": body = `if (!(${E})) throw new Error();\n  ${use}`; break;
      case "guardIf": body = `if (${E}) {\n    ${use}\n  }`; break;
      case "guardElse": body = `if (${E}) {\n  } else {\n    ${use}\n  }`; break;
      case "assertMsg": body = `check(${E}, "m");\n  ${use}`; break;
      case "methodAssert": body = `A.ok(${E});\n  ${use}`; break;
      case "ternary": body = `const r = ${E} ? ${X} : undefined;\n  const w: ${T} | undefined = r;`; break;
      case "earlyReturn": body = `if (!(${E})) return;\n  ${use}`; break;
      case "while": body = `while (${E}) {\n    ${use}\n    break;\n  }`; break;
      default: body = `ok(${E});\n  ${use}`; break;
    }
    const head = d.holder === "const" ? `const x = x0;\n  ` : "";
    return `declare function ok(v: unknown): asserts v;\ndeclare function check(v: unknown, m: string): asserts v;\ndeclare const A: { ok(v: unknown): asserts v };\nfunction f${sig} {\n  ${head}${body}\n}\n`;
  },
};
