// Family: inference order between context-sensitive and context-insensitive function arguments
// (parameter annotations, `this` use, returned lambdas, method vs arrow syntax).
import type { Family } from "./family.mts";

const VALS = ["1", "\"s\"", "{ a: 1 }", "[1, \"x\"] as const", "null"];
// [producer parameter type (T = inferred), producer expression (V = value)]
const PROD: Record<string, [string, string]> = {
  arrow: ["() => T", "() => V"],
  arrowParam: ["(n: number) => T", "(n) => V"],
  arrowAnnot: ["(n: number) => T", "(n: number) => V"],
  method: ["() => T", "M() { return V; }"],
  methodParam: ["(n: number) => T", "M(n) { return V; }"],
  fnExpr: ["() => T", "function () { return V; }"],
  fnExprThis: ["(this: { k: 0 }) => T", "function () { return this.k === 0 ? V : V; }"],
  destrParam: ["(o: { n: number }) => T", "({ n }) => V"],
  defaultParam: ["(n?: number) => T", "(n = 0) => V"],
  restParam: ["(...xs: number[]) => T", "(...xs) => V"],
  asyncArrow: ["() => Promise<T>", "async () => V"],
  genericArrow: ["(x: number) => T", "<X>(x: X) => V"],
  returnsLambda: ["() => (x: number) => T", "() => (x) => V"],
  returnsAnnotLambda: ["() => (x: number) => T", "() => (x: number) => V"],
  paren: ["() => T", "(() => V)"],
  conditional: ["() => T", "Math.random() ? () => V : () => V"],
  unusedParam: ["(n: number) => T", "(_) => V"],
  arrowBlock: ["() => T", "() => { return V; }"],
  generator: ["() => Iterable<T>", "function* () { yield V; }"],
};
const CONS: Record<string, string> = {
  arrow: "(t) => {\n  const ot: unknown = t;\n}",
  method: "M(t) {\n  const ot: unknown = t;\n}",
  fnExpr: "function (t) {\n  const ot: unknown = t;\n}",
  bare: "t => {\n  const ot: unknown = t;\n}",
  destr: "({ ...t }) => {\n  const ot: unknown = t;\n}",
};

export const ctxSensFam: Family = {
  name: "context-sensitivity",
  dims: {
    prod: Object.keys(PROD),
    cons: Object.keys(CONS),
    arr: ["objProdFirst", "objConsFirst", "argsProdFirst", "argsConsFirst", "nested", "twoProducers", "overloaded", "genericMethod"],
    v: VALS.map((_, i) => String(i)),
    ctx: ["none", "annotated", "returned"],
  },
  labelOf(k, v) { return k === "v" ? VALS[+v] : v; },
  render(d) {
    const [pt, pe] = PROD[d.prod];
    const V = VALS[+d.v];
    const consT = d.cons === "destr" ? "(t: T & object) => void" : "(t: T) => void";
    if (d.cons === "destr" && (V === "1" || V === "\"s\"" || V === "null")) return null;
    const isMethodP = pe.startsWith("M("), isMethodC = CONS[d.cons].startsWith("M(");
    const objEntry = (name: string, e: string, isM: boolean) => isM ? e.replace(/^M/, name) : `${name}: ${e}`;
    const P = pe.replace(/\bV\b/g, V), C = CONS[d.cons];
    if ((isMethodP || isMethodC) && /^args|^overloaded/.test(d.arr)) return null;
    let decl: string, call: string;
    switch (d.arr) {
      case "objProdFirst": decl = `declare function f<T>(o: { produce: ${pt}; consume: ${consT} }): T;`; call = `f({ ${objEntry("produce", P, isMethodP)}, ${objEntry("consume", C, isMethodC)} })`; break;
      case "objConsFirst": decl = `declare function f<T>(o: { consume: ${consT}; produce: ${pt} }): T;`; call = `f({ ${objEntry("consume", C, isMethodC)}, ${objEntry("produce", P, isMethodP)} })`; break;
      case "argsProdFirst": decl = `declare function f<T>(produce: ${pt}, consume: ${consT}): T;`; call = `f(${P}, ${C})`; break;
      case "argsConsFirst": decl = `declare function f<T>(consume: ${consT}, produce: ${pt}): T;`; call = `f(${C}, ${P})`; break;
      case "nested": decl = `declare function f<T>(o: { a: { produce: ${pt} }; b: { consume: ${consT} } }): T;`; call = `f({ a: { ${objEntry("produce", P, isMethodP)} }, b: { ${objEntry("consume", C, isMethodC)} } })`; break;
      case "twoProducers": decl = `declare function f<T>(o: { p1: ${pt}; p2: () => T; consume: ${consT} }): T;`; call = `f({ ${objEntry("p1", P, isMethodP)}, p2: () => ${V}, ${objEntry("consume", C, isMethodC)} })`; break;
      case "overloaded": decl = `declare function f<T>(produce: ${pt}, consume: ${consT}): T;\ndeclare function f(x: string): never;`; call = `f(${P}, ${C})`; break;
      default: decl = `declare const h: { f<T>(o: { produce: ${pt}; consume: ${consT} }): T };`; call = `h.f({ ${objEntry("produce", P, isMethodP)}, ${objEntry("consume", C, isMethodC)} })`; break;
    }
    let use: string;
    switch (d.ctx) {
      case "annotated": use = `const r = ${call} satisfies unknown;\nconst c: unknown = r;`; break;
      case "returned": use = `function g() {\n  return ${call};\n}\nconst r = g();\nconst c: unknown = r;`; break;
      default: use = `const r = ${call};\nconst c: unknown = r;`; break;
    }
    return `${decl}\n${use}\n`;
  },
};
