import type { Family } from "./family.mts";
import { destr } from "./fam_destr.mts";
import { assertFam } from "./fam_assert.mts";
import { inferFam } from "./fam_infer.mts";
import { narrowFam } from "./fam_narrow.mts";
import { overloadFam } from "./fam_overload.mts";
export const FAMILIES: Family[] = [destr, assertFam, inferFam, narrowFam, overloadFam];
