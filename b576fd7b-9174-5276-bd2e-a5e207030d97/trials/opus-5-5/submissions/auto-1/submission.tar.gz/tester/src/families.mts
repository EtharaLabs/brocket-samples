import type { Family } from "./family.mts";
import { destr } from "./fam_destr.mts";
export const FAMILIES: Family[] = [destr];
