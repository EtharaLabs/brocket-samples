export type Dims = Record<string, string>;
export interface Family {
  name: string;
  dims: Record<string, string[]>;
  render(d: Dims): string | null;
}
export function defaults(f: Family): Dims {
  const d: Dims = {};
  for (const k of Object.keys(f.dims)) d[k] = f.dims[k][0];
  return d;
}
