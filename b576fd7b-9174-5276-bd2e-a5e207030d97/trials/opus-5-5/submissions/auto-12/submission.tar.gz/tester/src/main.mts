import { writeFileSync, renameSync, existsSync } from "node:fs";
import { availableParallelism } from "node:os";
import { dirname, join, basename } from "node:path";
import { Pool } from "./exec.mts";
import { screen, screenSolo, measureStable, wrap, differs, type Ctx, type Measure, type ScreenItem } from "./engine.mts";
import { runChecker } from "./exec.mts";
import { typedVariant, diagnostics, observed, fingerprint, exactWitness } from "./typed.mts";
import { FAMILIES } from "./families.mts";
import { defaults, type Family, type Dims } from "./family.mts";
import { mulberry32, pick } from "./rng.mts";

const T0 = Date.now();
function parseArgs(argv: string[]) {
  const o: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      if (eq > 0) o[a.slice(2, eq)] = a.slice(eq + 1);
      else o[a.slice(2)] = argv[++i] ?? "";
    }
  }
  return o;
}
const args = parseArgs(process.argv.slice(2));
const OUT = args.out || "report.json";
const BUDGET = Math.max(10, Number(args.budget) || 300);
const SEED = (Number(args.seed) || 0) >>> 0;
const NAME = args.toolchain || "dev";
const HARD_END = T0 + BUDGET * 1000 * 0.97;
const log = (...a: unknown[]) => { if (process.env.DT_DEBUG) console.error(`[${((Date.now() - T0) / 1000).toFixed(1)}s]`, ...a); };

interface Witness { id: string; source: string; reference: string; native: string; mechanism: string; }
const witnesses: Witness[] = [];
function writeReport() {
  const data = JSON.stringify({ witnesses }, null, 1);
  try {
    const tmp = join(dirname(OUT), "." + basename(OUT) + ".tmp" + process.pid);
    writeFileSync(tmp, data);
    renameSync(tmp, OUT);
  } catch {
    try { writeFileSync(OUT, data); } catch {}
  }
}
writeReport();
// Hard stop: whatever is on disk stays.
const killer = setTimeout(() => { writeReport(); process.exit(0); }, Math.max(1000, HARD_END - Date.now()));

const REF = "/opt/compilers/reference/node_modules/.bin/tsc";
const NAT = `${process.env.DT_ROOT || "/opt/compilers"}/${NAME}/node_modules/.bin/tsc`;
const cores = Math.max(2, Math.min(32, availableParallelism()));
const ctx: Ctx = { ref: REF, nat: NAT, pool: new Pool(cores), deadline: T0 + BUDGET * 1000 * 0.80, screenTimeout: 12000 };

type Probe = { fam: Family; d: Dims; src: string };

function sampleProbes(fam: Family, rng: () => number, n: number, seen: Set<string>): Probe[] {
  const out: Probe[] = [];
  let tries = 0;
  while (out.length < n && tries++ < n * 30) {
    const d: Dims = {};
    const keys = Object.keys(fam.dims);
    if (rng() < 0.4) {
      // sparse: defaults except two or three dimensions
      for (const k of keys) d[k] = fam.dims[k][0];
      const m = rng() < 0.6 ? 2 : 3;
      for (let j = 0; j < m; j++) { const k = pick(rng, keys); d[k] = pick(rng, fam.dims[k]); }
    } else for (const k of keys) d[k] = rng() < 0.25 ? fam.dims[k][0] : pick(rng, fam.dims[k]);
    const src = fam.render(d);
    if (!src) continue;
    const key = item({ src }).src;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ fam, d, src });
  }
  return out;
}

function neighbors(fam: Family): Probe[] {
  const base = defaults(fam);
  const out: Probe[] = [];
  const seen = new Set<string>();
  const add = (d: Dims) => { const s = fam.render(d); if (s && !seen.has(item({ src: s }).src)) { seen.add(item({ src: s }).src); out.push({ fam, d, src: s }); } };
  add(base);
  for (const k of Object.keys(fam.dims)) for (const v of fam.dims[k].slice(1)) add({ ...base, [k]: v });
  return out;
}

const BATCH = 200;
function item(p: { src: string }): ScreenItem { return typedVariant(p.src) ?? { src: p.src }; }
const batchOf = new Map<Probe, Probe[]>();
async function screenAll(probes: Probe[], solo = false): Promise<Probe[]> {
  const jobs: Promise<(import("./engine.mts").ScreenResult | null)[]>[] = [];
  for (let i = 0; i < probes.length; i += BATCH) {
    const b = probes.slice(i, i + BATCH);
    if (!solo) for (const p of b) batchOf.set(p, b);
    jobs.push((solo ? screenSolo : screen)(ctx, b.map(item)));
  }
  const res = (await Promise.all(jobs)).flat();
  if (process.env.DT_DEBUG === "2") probes.forEach((p, i) => { if (differs(res[i])) log("diff", p.fam.name, JSON.stringify(p.d), res[i]!.refSig, "<>", res[i]!.natSig); });
  return probes.filter((_, i) => differs(res[i]));
}

// A per-probe difference that does not reproduce standalone: try it inside a namespace, then
// shrink its screening batch to the probes needed for the difference to persist.
async function contextual(p: Probe): Promise<{ src: string; m: Measure } | null> {
  const single = wrap([p.src]).text;
  let m = await confirm({ ...p, src: single });
  if (m) return { src: single, m };
  const batch = batchOf.get(p);
  if (!batch || batch.length < 2) return null;
  const diffAt = async (set: Probe[]) => {
    const r = await screen(ctx, set.map(item));
    return differs(r[set.indexOf(p)]);
  };
  let cur = [...batch];
  if (!(await diffAt(cur))) return null;
  let chunk = cur.length >> 1;
  while (chunk >= 1 && Date.now() < ctx.deadline + 15000) {
    let changed = false;
    for (let start = 0; start < cur.length; start += chunk) {
      const removed = cur.slice(start, start + chunk).filter((x) => x !== p);
      if (!removed.length) continue;
      const cand = cur.filter((x) => !removed.includes(x));
      if (await diffAt(cand)) { cur = cand; changed = true; start -= chunk; }
    }
    if (!changed) chunk >>= 1;
  }
  const text = wrap(cur.map((x) => x.src)).text;
  m = await confirm({ ...p, src: text });
  return m ? { src: text, m } : null;
}

function splits(m: Measure | null): m is Measure { return !!m && m.ref !== m.nat; }

async function confirm(p: Probe): Promise<Measure | null> {
  if (Date.now() > HARD_END - 5000) return null;
  const m = await measureStable(ctx, p.src);
  return splits(m) ? m : null;
}

// A split witness for a probe: the probe itself, or, when an observed type differs, the probe with
// that check made exact against the type one checker reports.
async function realize(p: Probe): Promise<{ src: string; m: Measure } | null> {
  const m = await confirm(p);
  if (m) return { src: p.src, m };
  const tv = typedVariant(p.src);
  if (!tv || Date.now() > HARD_END - 10000) return null;
  const [a, b] = await Promise.all([ctx.pool.run(() => runChecker(ctx.ref, tv.src)), ctx.pool.run(() => runChecker(ctx.nat, tv.src))]);
  if (a.cls !== "reject" || b.cls !== "reject") return null;
  const da = diagnostics(a.out), db = diagnostics(b.out);
  if ([...da.keys(), ...db.keys()].some((l) => !tv.marks.includes(l))) return null;
  for (const line of tv.marks) {
    const tr = observed(da.get(line)), tn = observed(db.get(line));
    if (tr === "~" || tn === "~" || fingerprint(tr) === fingerprint(tn)) continue;
    for (const t of [tr, tn]) {
      const w = exactWitness(p.src, line, t);
      if (!w) continue;
      const wm = await confirm({ ...p, src: w });
      if (wm) return { src: w, m: wm };
    }
  }
  return null;
}

// Canonicalize a confirmed split: smallest set of non-default dimension settings that still split.
async function canonicalize(p: Probe, src: string, m: Measure): Promise<{ d: Dims; src: string; m: Measure }> {
  const fam = p.fam;
  const base = defaults(fam);
  const keys = Object.keys(fam.dims);
  // single-dimension neighbourhood of the default
  const nb = neighbors(fam);
  const cands = await screenAll(nb);
  for (const c of cands) {
    const cr = await realize(c);
    if (cr) return { d: c.d, src: cr.src, m: cr.m };
  }
  // greedy ablation from the found probe
  let cur: Dims = { ...p.d }, curSrc = src, curM = m;
  for (const k of keys) {
    if (cur[k] === base[k]) continue;
    if (Date.now() > ctx.deadline + 20000) break;
    const nd = { ...cur, [k]: base[k] };
    const s = fam.render(nd);
    if (!s) continue;
    const cr = await realize({ fam, d: nd, src: s });
    if (cr) { cur = nd; curSrc = cr.src; curM = cr.m; }
  }
  // move each remaining non-default dimension to its earliest still-splitting value
  for (const k of keys) {
    if (cur[k] === base[k]) continue;
    if (Date.now() > ctx.deadline + 20000) break;
    const vals = fam.dims[k];
    const earlier: Probe[] = [];
    for (const v of vals.slice(1, vals.indexOf(cur[k]))) {
      const nd = { ...cur, [k]: v };
      const s = fam.render(nd);
      if (s) earlier.push({ fam, d: nd, src: s });
    }
    if (!earlier.length) continue;
    for (const c of await screenAll(earlier)) {
      const cr = await realize(c);
      if (cr) { cur = c.d; curSrc = cr.src; curM = cr.m; break; }
    }
  }
  return { d: cur, src: curSrc, m: curM };
}

function label(fam: Family, d: Dims, m: Measure): string {
  const base = defaults(fam);
  const parts = Object.keys(fam.dims).filter((k) => d[k] !== base[k]).map((k) => `${k}=${fam.labelOf ? fam.labelOf(k, d[k]) : d[k]}`);
  const dir = m.nat === "crash" || m.nat === "timeout" ? `native-${m.nat}` : m.nat === "reject" ? "spurious-error" : m.nat === "accept" ? "missed-error" : "diverge";
  return `${fam.name}/${dir}/${parts.length ? parts.join(",") : "base"}`;
}

async function main() {
  // infrastructure check
  const probe = await measureStable(ctx, "export {};\n");
  if (!probe || probe.nat !== "accept" || probe.ref !== "accept") { log("toolchain not runnable", probe); return; }
  const rng = mulberry32(SEED ^ 0x9e3779b9);
  const seen = new Set<string>();
  const found: { fam: Family; p: Probe; src: string; m: Measure; support: number; ctxSrc?: string }[] = [];
  let ctxTries = 0;
  let round = 0;
  // round 0: default neighbourhoods; later rounds: random samples interleaved across families
  while (Date.now() < ctx.deadline && found.length === 0) {
    let probes: Probe[] = [];
    // every sixth round screens the native checker on standalone files
    const solo = round % 6 === 5;
    if (round === 0) {
      for (const f of FAMILIES) for (const p of neighbors(f)) { const k = item(p).src; if (!seen.has(k)) { seen.add(k); probes.push(p); } }
    } else {
      const per = Math.max(solo ? 10 : 50, Math.round(cores * (solo ? 10 : 60)));
      const lists = FAMILIES.map((f) => sampleProbes(f, rng, Math.round(per * (f.weight ?? 1)), seen));
      const mx = Math.max(...lists.map((l) => l.length));
      for (let i = 0; i < mx; i++) for (const l of lists) if (i < l.length) probes.push(l[i]);
    }
    round++;
    const diffs = await screenAll(probes, solo);
    log(`round ${round}${solo ? " solo" : ""} probes=${probes.length} screen-diffs=${diffs.length}`);
    const byFam = new Map<Family, Probe[]>();
    for (const d of diffs) { if (!byFam.has(d.fam)) byFam.set(d.fam, []); byFam.get(d.fam)!.push(d); }
    for (const [fam, ps] of byFam) {
      let conf = 0, first: { p: Probe; src: string; m: Measure } | null = null;
      for (const p of ps.slice(0, 4)) {
        const r = await realize(p);
        if (r) { conf++; if (!first) first = { p, src: r.src, m: r.m }; }
      }
      if (first) found.push({ fam, p: first.p, src: first.src, m: first.m, support: ps.length * conf });
      else if (ctxTries < 3) {
        ctxTries++;
        const c = await contextual(ps[0]);
        if (c) found.push({ fam, p: ps[0], src: c.src, m: c.m, support: 0, ctxSrc: c.src });
      }
    }
  }
  found.sort((a, b) => b.support - a.support || FAMILIES.indexOf(a.fam) - FAMILIES.indexOf(b.fam));
  const labels = new Set<string>();
  for (const f of found.slice(0, MAX_REPORT)) {
    if (Date.now() > HARD_END - 15000) break;
    // timeouts are reported as found: each further measurement costs a full timeout
    const slow = f.m.nat === "timeout";
    const c = f.ctxSrc || slow ? { d: f.p.d, src: f.ctxSrc ?? f.src, m: f.m } : await canonicalize(f.p, f.src, f.m);
    // final re-measurement of the exact source being reported
    const fm = slow ? f.m : await confirm({ fam: f.fam, d: c.d, src: c.src });
    if (!fm) continue;
    const lab = (f.ctxSrc ? "context-dependent/" : "") + label(f.fam, c.d, fm);
    if (labels.has(lab.toLowerCase())) continue;
    labels.add(lab.toLowerCase());
    witnesses.push({ id: `w${witnesses.length + 1}-${f.fam.name}`, source: c.src, reference: fm.ref, native: fm.nat, mechanism: lab });
    writeReport();
    log("witness", lab);
  }
}
const MAX_REPORT = 2;

try { await main(); } catch (e) { log("error", e); }
writeReport();
clearTimeout(killer);
process.exit(0);
