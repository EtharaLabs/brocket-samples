import { writeFileSync, renameSync, existsSync } from "node:fs";
import { availableParallelism } from "node:os";
import { dirname, join, basename } from "node:path";
import { Pool } from "./exec.mts";
import { screen, measureStable, type Ctx, type Measure } from "./engine.mts";
import { FAMILIES } from "./families.mts";
import { defaults, type Family, type Dims } from "./family.mts";
import { mulberry32, pick } from "./rng.mts";

const T0 = Date.now();
function parseArgs(argv: string[]) {
  const o: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      if (eq > 0) o[a.slice(2, eq)] = a.slice(eq + 1);
      else o[a.slice(2)] = argv[++i] ?? "";
    }
  }
  return o;
}
const args = parseArgs(process.argv.slice(2));
const OUT = args.out || "report.json";
const BUDGET = Math.max(10, Number(args.budget) || 300);
const SEED = (Number(args.seed) || 0) >>> 0;
const NAME = args.toolchain || "dev";
const HARD_END = T0 + BUDGET * 1000 * 0.97;
const log = (...a: unknown[]) => { if (process.env.DT_DEBUG) console.error(`[${((Date.now() - T0) / 1000).toFixed(1)}s]`, ...a); };

interface Witness { id: string; source: string; reference: string; native: string; mechanism: string; }
const witnesses: Witness[] = [];
function writeReport() {
  const data = JSON.stringify({ witnesses }, null, 1);
  try {
    const tmp = join(dirname(OUT), "." + basename(OUT) + ".tmp" + process.pid);
    writeFileSync(tmp, data);
    renameSync(tmp, OUT);
  } catch {
    try { writeFileSync(OUT, data); } catch {}
  }
}
writeReport();
// Hard stop: whatever is on disk stays.
const killer = setTimeout(() => { writeReport(); process.exit(0); }, Math.max(1000, HARD_END - Date.now()));

const REF = "/opt/compilers/reference/node_modules/.bin/tsc";
const NAT = `/opt/compilers/${NAME}/node_modules/.bin/tsc`;
const cores = Math.max(2, Math.min(32, availableParallelism()));
const ctx: Ctx = { ref: REF, nat: NAT, pool: new Pool(cores), deadline: T0 + BUDGET * 1000 * 0.80, screenTimeout: 20000 };

type Probe = { fam: Family; d: Dims; src: string };

function sampleProbes(fam: Family, rng: () => number, n: number, seen: Set<string>): Probe[] {
  const out: Probe[] = [];
  let tries = 0;
  while (out.length < n && tries++ < n * 30) {
    const d: Dims = {};
    for (const k of Object.keys(fam.dims)) d[k] = pick(rng, fam.dims[k]);
    const src = fam.render(d);
    if (!src || seen.has(src)) continue;
    seen.add(src);
    out.push({ fam, d, src });
  }
  return out;
}

function neighbors(fam: Family): Probe[] {
  const base = defaults(fam);
  const out: Probe[] = [];
  const seen = new Set<string>();
  const add = (d: Dims) => { const s = fam.render(d); if (s && !seen.has(s)) { seen.add(s); out.push({ fam, d, src: s }); } };
  add(base);
  for (const k of Object.keys(fam.dims)) for (const v of fam.dims[k].slice(1)) add({ ...base, [k]: v });
  return out;
}

const BATCH = 40;
async function screenAll(probes: Probe[]): Promise<Probe[]> {
  const jobs: Promise<(import("./engine.mts").ScreenResult | null)[]>[] = [];
  for (let i = 0; i < probes.length; i += BATCH) jobs.push(screen(ctx, probes.slice(i, i + BATCH).map((p) => p.src)));
  const res = (await Promise.all(jobs)).flat();
  return probes.filter((_, i) => { const r = res[i]; return r && (r.refErr !== r.natErr || r.natOdd); });
}

function splits(m: Measure | null): m is Measure { return !!m && m.ref !== m.nat; }

async function confirm(p: Probe): Promise<Measure | null> {
  if (Date.now() > HARD_END - 5000) return null;
  const m = await measureStable(ctx, p.src);
  return splits(m) ? m : null;
}

// Canonicalize a confirmed split: smallest set of non-default dimension settings that still split.
async function canonicalize(p: Probe, m: Measure): Promise<{ d: Dims; src: string; m: Measure }> {
  const fam = p.fam;
  const base = defaults(fam);
  const keys = Object.keys(fam.dims);
  // single-dimension neighbourhood of the default
  const nb = neighbors(fam);
  const cands = await screenAll(nb);
  for (const c of cands) {
    const cm = await confirm(c);
    if (cm) return { d: c.d, src: c.src, m: cm };
  }
  // greedy ablation from the found probe
  let cur: Dims = { ...p.d }, curSrc = p.src, curM = m;
  for (const k of keys) {
    if (cur[k] === base[k]) continue;
    if (Date.now() > ctx.deadline + 20000) break;
    const nd = { ...cur, [k]: base[k] };
    const s = fam.render(nd);
    if (!s) continue;
    const cm = await confirm({ fam, d: nd, src: s });
    if (cm) { cur = nd; curSrc = s; curM = cm; }
  }
  return { d: cur, src: curSrc, m: curM };
}

function label(fam: Family, d: Dims, m: Measure): string {
  const base = defaults(fam);
  const parts = Object.keys(fam.dims).filter((k) => d[k] !== base[k]).map((k) => `${k}=${fam.labelOf ? fam.labelOf(k, d[k]) : d[k]}`);
  const dir = m.nat === "crash" || m.nat === "timeout" ? `native-${m.nat}` : m.nat === "reject" ? "spurious-error" : m.nat === "accept" ? "missed-error" : "diverge";
  return `${fam.name}/${dir}/${parts.length ? parts.join(",") : "base"}`;
}

async function main() {
  // infrastructure check
  const probe = await measureStable(ctx, "export {};\n");
  if (!probe || probe.nat !== "accept" || probe.ref !== "accept") { log("toolchain not runnable", probe); return; }
  const rng = mulberry32(SEED ^ 0x9e3779b9);
  const seen = new Set<string>();
  const found: { fam: Family; p: Probe; m: Measure; support: number }[] = [];
  let round = 0;
  // round 0: default neighbourhoods; later rounds: random samples interleaved across families
  while (Date.now() < ctx.deadline && found.length === 0) {
    let probes: Probe[] = [];
    if (round === 0) {
      for (const f of FAMILIES) for (const p of neighbors(f)) if (!seen.has(p.src)) { seen.add(p.src); probes.push(p); }
    } else {
      const per = Math.max(50, Math.round(cores * 60));
      const lists = FAMILIES.map((f) => sampleProbes(f, rng, Math.round(per * (f.weight ?? 1)), seen));
      const mx = Math.max(...lists.map((l) => l.length));
      for (let i = 0; i < mx; i++) for (const l of lists) if (i < l.length) probes.push(l[i]);
    }
    round++;
    const diffs = await screenAll(probes);
    log(`round ${round} probes=${probes.length} screen-diffs=${diffs.length}`);
    const byFam = new Map<Family, Probe[]>();
    for (const d of diffs) { if (!byFam.has(d.fam)) byFam.set(d.fam, []); byFam.get(d.fam)!.push(d); }
    for (const [fam, ps] of byFam) {
      let conf = 0, first: { p: Probe; m: Measure } | null = null;
      for (const p of ps.slice(0, 4)) {
        const m = await confirm(p);
        if (m) { conf++; if (!first) first = { p, m }; }
      }
      if (first) found.push({ fam, p: first.p, m: first.m, support: ps.length * conf });
    }
  }
  found.sort((a, b) => b.support - a.support || FAMILIES.indexOf(a.fam) - FAMILIES.indexOf(b.fam));
  const labels = new Set<string>();
  for (const f of found.slice(0, MAX_REPORT)) {
    if (Date.now() > HARD_END - 15000) break;
    const c = await canonicalize(f.p, f.m);
    // final re-measurement of the exact source being reported
    const fm = await confirm({ fam: f.fam, d: c.d, src: c.src });
    if (!fm) continue;
    const lab = label(f.fam, c.d, fm);
    if (labels.has(lab.toLowerCase())) continue;
    labels.add(lab.toLowerCase());
    witnesses.push({ id: `w${witnesses.length + 1}-${f.fam.name}`, source: c.src, reference: fm.ref, native: fm.nat, mechanism: lab });
    writeReport();
    log("witness", lab);
  }
}
const MAX_REPORT = 2;

try { await main(); } catch (e) { log("error", e); }
writeReport();
clearTimeout(killer);
process.exit(0);
