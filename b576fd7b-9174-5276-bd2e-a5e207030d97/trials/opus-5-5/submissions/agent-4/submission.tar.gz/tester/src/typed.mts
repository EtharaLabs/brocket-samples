// Type-observation variants: after each check line `const v: T = <reference>;` a line `const v__o: never = <reference>;`
// is added, so the type of <reference> at that point appears in a diagnostic and can be compared.
const MARK = /^(\s*)const (\w+): (.+) = ([\w$]+(?:\.[\w$]+|\[\d+\])*);\s*$/;

export interface Typed { src: string; marks: number[]; } // marks: 1-based lines within src

export function typedVariant(src: string): Typed | null {
  const out: string[] = [];
  const marks: number[] = [];
  for (const line of src.split("\n")) {
    out.push(line);
    const m = MARK.exec(line);
    if (!m || m[3] === "never") continue;
    out.push(`${m[1]}const ${m[2]}__o: never = ${m[4]};`);
    marks.push(out.length);
  }
  return marks.length ? { src: out.join("\n"), marks } : null;
}

// Per-line diagnostics: line -> list of first-line messages.
export function diagnostics(out: string): Map<number, string[]> {
  const m = new Map<number, string[]>();
  const re = /^p\.ts\((\d+),\d+\): error TS\d+: (.*)$/gm;
  let x;
  while ((x = re.exec(out))) {
    const l = +x[1];
    if (!m.has(l)) m.set(l, []);
    m.get(l)!.push(x[2]);
  }
  return m;
}

// Type text reported for a `never` check line, or "" when there is none.
export function observed(msgs: string[] | undefined): string {
  for (const s of msgs ?? []) {
    const mm = /^Type '(.*)' is not assignable to type 'never'\.$/.exec(s);
    if (mm) return mm[1].includes("...") ? "~" : mm[1];
  }
  return "";
}

// Fingerprint insensitive to union member order (not stable between implementations) and to literal
// widening (literal retention in inferred types is not compared; literal checks stay as ordinary checks).
export function fingerprint(t: string): string {
  const w = t.replace(/"(?:[^"\\]|\\.)*"/g, "string").replace(/\b\d+n\b/g, "bigint")
    .replace(/-?\b\d+(?:\.\d+)?\b/g, "number").replace(/\b(?:true|false)\b/g, "boolean");
  return fp(w);
}
function fp(w: string): string {
  const members: string[] = [];
  let depth = 0, cur = "";
  for (let i = 0; i < w.length; i++) {
    const ch = w[i];
    if (depth === 0 && w.startsWith("=> ", i)) { cur += "=>{" + fp(w.slice(i + 3)) + "}"; i = w.length; break; }
    if ("([{<".includes(ch)) depth++;
    else if (")]}>".includes(ch) && !(ch === ">" && w[i - 1] === "=")) depth--;
    if (depth === 0 && w.startsWith(" | ", i)) { members.push(cur); cur = ""; i += 2; continue; }
    cur += ch;
  }
  members.push(cur);
  return [...new Set(members.map((m) => m.split("").sort().join("")))].sort().join("|");
}

export const EQ = "type __Eq<A, B> = (<Q>() => Q extends A ? 1 : 2) extends (<Q>() => Q extends B ? 1 : 2) ? true : false;\n";

// Source asserting the observed type `t` exactly at mark line `line` of the original src.
export function exactWitness(src: string, line: number, t: string): string | null {
  if (!t || t === "~" || t.includes("...")) return null;
  const lines = src.split("\n");
  line = line - 1 - typedVariant(src)!.marks.filter((x) => x < line).length; // original line of this mark
  const m = MARK.exec(lines[line - 1]);
  if (!m) return null;
  lines[line - 1] = `${m[1]}const __t = ${m[4]};\n${m[1]}const ${m[2]}: __Eq<typeof __t, ${t}> = true;`;
  return EQ + lines.join("\n");
}
