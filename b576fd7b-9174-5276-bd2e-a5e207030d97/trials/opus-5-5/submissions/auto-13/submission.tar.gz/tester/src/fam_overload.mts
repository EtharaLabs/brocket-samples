// Family: overload resolution (declared overloads, method overloads, intersections/unions of
// signatures, constructors) observed through the selected return type.
import type { Family } from "./family.mts";

const SETS: Record<string, { decl: string; callee: string }> = {
  prim: { decl: "declare function f(x: string): 1;\ndeclare function f(x: number): 2;", callee: "f" },
  cbParam: { decl: "declare function f(x: string, cb: (s: string) => void): 1;\ndeclare function f(x: number, cb: (n: number) => void): 2;", callee: "f" },
  genericFirst: { decl: "declare function f<T>(x: T[]): T;\ndeclare function f(x: string): 2;", callee: "f" },
  optional: { decl: "declare function f(): 1;\ndeclare function f(x?: number): 2;", callee: "f" },
  rest: { decl: "declare function f(...xs: number[]): 1;\ndeclare function f(x: string, ...rest: string[]): 2;", callee: "f" },
  objects: { decl: "declare function f(o: { a: number }): 1;\ndeclare function f(o: { b: string }): 2;", callee: "f" },
  arity: { decl: "declare function f(cb: () => void): 1;\ndeclare function f(cb: (x: number) => void): 2;", callee: "f" },
  literal: { decl: "declare function f(x: \"a\"): 1;\ndeclare function f(x: string): 2;", callee: "f" },
  genericConstr: { decl: "declare function f<T extends string>(x: T): 1;\ndeclare function f<T>(x: T): 2;", callee: "f" },
  ifaceMethod: { decl: "interface I { m(x: string): 1; m(x: number): 2; }\ndeclare const i: I;", callee: "i.m" },
  unionIfaces: { decl: "interface I { m(x: string): 1; m(x: number): 2; }\ninterface J { m(x: string): 1; m(x: boolean): 2; }\ndeclare const i: I | J;", callee: "i.m" },
  interFns: { decl: "declare const f: ((x: string) => 1) & ((x: number) => 2);", callee: "f" },
  unionFns: { decl: "declare const f: ((x: string | number) => 1) | ((x: number | boolean) => 2);", callee: "f" },
  tupleRest: { decl: "declare function f(...a: [string] | [number, number]): 1;\ndeclare function f(...a: unknown[]): 2;", callee: "f" },
  ctor: { decl: "declare class C { constructor(x: string); constructor(x: number, y?: number); tag: 1; }", callee: "new C" },
  callSigObj: { decl: "declare const f: { (x: string): 1; (x: number): 2; prop: 0 };", callee: "f" },
  genericCb: { decl: "declare function f<T>(x: T, cb: (t: T) => 1): 1;\ndeclare function f<T>(x: T, cb: (t: T) => 2): 2;", callee: "f" },
  thisParam: { decl: "declare function f(this: void, x: string): 1;\ndeclare function f(this: void, x: number): 2;", callee: "f" },
  booleanOv: { decl: "declare function f(x: true): 1;\ndeclare function f(x: false): 2;\ndeclare function f(x: boolean): 3;", callee: "f" },
  nullableOv: { decl: "declare function f(x: null): 1;\ndeclare function f(x: undefined): 2;\ndeclare function f(x: {}): 3;", callee: "f" },
  genericOvInfer: { decl: "declare function f<T extends string>(x: T): { s: T };\ndeclare function f<T extends number>(x: T): { n: T };\ndeclare function f<T>(x: T): { o: T };", callee: "f" },
  cbReturnOv: { decl: "declare function f(cb: () => string): 1;\ndeclare function f(cb: () => number): 2;\ndeclare function f(x: unknown): 3;", callee: "f" },
  arrayOv: { decl: "declare function f(x: string[]): 1;\ndeclare function f(x: number[]): 2;\ndeclare function f(x: unknown[]): 3;", callee: "f" },
  subtypePass: { decl: "declare function f(o: { a: number }): 1;\ndeclare function f(o: { a: number; b: string }): 2;\ndeclare function f(o: {}): 3;", callee: "f" },
  unionArgOv: { decl: "declare function f(x: string): 1;\ndeclare function f(x: number): 2;\ndeclare function f(x: string | number): 3;", callee: "f" },
  promiseOv: { decl: "declare function f(x: Promise<string>): 1;\ndeclare function f(x: string): 2;\ndeclare function f(x: unknown): 3;", callee: "f" },
  genericCtor: { decl: "declare class C<T> { constructor(x: T); constructor(x: T, y: T); v: T; }", callee: "new C" },
  cbArity: { decl: "declare function f(cb: (a: string, b: number) => void): 1;\ndeclare function f(cb: (a: number) => void): 2;", callee: "f" },
  templateOv: { decl: "declare function f(x: `a${string}`): 1;\ndeclare function f(x: string): 2;\ndeclare function f(x: unknown): 3;", callee: "f" },
  discrimOv: { decl: "declare function f(o: { k: \"a\"; v: number }): 1;\ndeclare function f(o: { k: \"b\"; w: string }): 2;\ndeclare function f(o: unknown): 3;", callee: "f" },
  genericCbOv: { decl: "declare function f<T>(x: T[], cb: (t: T) => string): { s: T };\ndeclare function f<T>(x: T, cb: (t: T) => number): { n: T };", callee: "f" },
  keyofOv: { decl: "declare function f<K extends \"a\" | \"b\">(k: K): K;\ndeclare function f(k: string): 2;", callee: "f" },
};
const ARGS = ["\"a\"", "1", "true", "\"a\" as string", "(Math.random() ? \"a\" : 1)", "{ a: 1 }", "{ b: \"\" }", "{ a: 1, b: \"\" }",
  "() => { }", "(x) => {\n  const ox: unknown = x;\n}", "(x: number) => { }", "[1]", "undefined", "", "null", "1, 2", "\"a\", \"b\"", "\"a\", (s) => {\n  const os: unknown = s;\n}", "1, (n) => {\n  const on: unknown = n;\n}",
  "1, (t) => 1 as const", "\"x\", (t) => 2 as const", "1, (t) => {\n  const ot: unknown = t;\n  return 1 as const;\n}", "false", "{}", "[\"a\"]"];
const EXP = ["1", "2", "3", "never", "string", "number", "unknown", "1 | 2", "{ tag: 1 }", "\"a\"", "boolean"];

export const overloadFam: Family = {
  name: "overload-resolution",
  dims: {
    set: Object.keys(SETS),
    arg: ARGS.map((_, i) => String(i)),
    e: EXP.map((_, i) => String(i)),
    ctx: ["none", "annot", "ret", "spread", "narrowedArg", "narrowIf", "destrArg", "loopArg", "closureArg", "twice"],
    pad: ["0", "before3", "after3", "before8", "split4"],
    nar: ["typeof x === \"string\"", "typeof x === \"number\"", "x !== undefined", "typeof x === \"object\" && x !== null", "x", "!(typeof x === \"boolean\")", "Array.isArray(x)", "typeof x === \"object\" && x !== null && \"k\" in x && x.k === \"a\""],
  },
  labelOf(k, v) { return k === "arg" ? ARGS[+v] : k === "e" ? EXP[+v] : v; },
  render(d) {
    let s = SETS[d.set];
    if (d.pad !== "0") {
      // extra overloads no argument list here can match (only the overload count changes)
      const m = /declare function f\b/.exec(s.decl);
      if (!m) return null;
      const k = d.pad === "before8" ? 8 : d.pad === "split4" ? 4 : 3;
      const pads = Array.from({ length: k }, (_, i) => `declare function f(p${i}: { pad${i}: never }, q: symbol, ...r: symbol[]): ${d.pad === "split4" ? "never" : "0"};`);
      const lines = s.decl.split("\n");
      const fl = lines.map((l, i) => l.startsWith("declare function f") ? i : -1).filter((i) => i >= 0);
      if (d.pad.startsWith("before")) lines.splice(fl[0], 0, ...pads);
      else if (d.pad === "after3") lines.splice(fl[fl.length - 1] + 1, 0, ...pads);
      else { lines.splice(fl[fl.length - 1] + 1, 0, ...pads.slice(2)); lines.splice(fl[0], 0, ...pads.slice(0, 2)); }
      s = { ...s, decl: lines.join("\n") };
    }
    const a = ARGS[+d.arg], E = EXP[+d.e];
    let call: string, pre = "";
    if (d.ctx === "spread") { if (!a) return null; call = `${s.callee}(...[${a}] as const)`; }
    else if (d.ctx === "narrowedArg") {
      if (!a || a.includes(",")) return null;
      pre = `declare const u: string | number | boolean | null | undefined | object;\n`;
      call = `(typeof u === typeof (${a}) ? ${s.callee}(u as any as typeof ${a.startsWith("(") || a.startsWith("{") || a.startsWith("[") ? `__v` : `__v`}) : 0)`;
      pre += `const __v = ${a};\n`;
      call = `${s.callee}(__v)`;
    } else call = `${s.callee}(${a})`;
    const U = "string | number | boolean | undefined | { a: 1 } | number[] | { k: \"a\"; v: number } | { k: \"b\"; w: string }";
    if (d.ctx === "narrowIf" || d.ctx === "destrArg" || d.ctx === "loopArg" || d.ctx === "closureArg") {
      if (/^[{[(]/.test(a)) return null;
      const extra = a.includes(",") ? a.slice(a.indexOf(",")) : "";
      if (a && !extra && !["\"a\"", "1", "true"].includes(a)) return null;
      let body: string;
      const callX = `${s.callee}(x${extra})`;
      switch (d.ctx) {
        case "narrowIf": body = `function g(x: ${U}) {\n  if (${d.nar}) {\n    const r = ${callX};\n    const c: unknown = r;\n  }\n}`; break;
        case "destrArg": body = `function g(o: { x: ${U} }) {\n  const { x } = o;\n  if (${d.nar}) {\n    const r = ${callX};\n    const c: unknown = r;\n  }\n}`; break;
        case "loopArg": body = `function g(x: ${U}) {\n  while (${d.nar}) {\n    const r = ${callX};\n    const c: unknown = r;\n    break;\n  }\n}`; break;
        default: body = `function g(x: ${U}) {\n  if (${d.nar}) {\n    [0].forEach(() => {\n      const r = ${callX};\n      const c: unknown = r;\n    });\n  }\n}`; break;
      }
      return `${s.decl}\n${body}\n`;
    }
    let use: string;
    if (d.ctx === "twice") {
      const other = ARGS[(+d.arg + 1) % ARGS.length];
      pre += `const r0 = ${s.callee}(${other});\nconst c0: unknown = r0;\n`;
    }
    switch (d.ctx) {
      case "annot": use = `const r: ${E} = ${call};`; break;
      case "ret": use = `function g(): ${E} {\n  return ${call};\n}`; break;
      default: use = `const r = ${call};\nconst c: ${E} = r;`; break;
    }
    return `${s.decl}\n${pre}${use}\n`;
  },
};
