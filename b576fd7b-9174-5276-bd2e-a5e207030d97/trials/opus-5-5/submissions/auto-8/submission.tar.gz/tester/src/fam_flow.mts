// Family: statement sequences of narrowing constructs over one reference; the narrowed type is
// observed after every statement.
import type { Family } from "./family.mts";

const DECLS = [
  "string | number", "string | number | null | undefined", "string | string[]", "Date | string", "{ a: 1 } | { b: 2 } | string",
  "unknown", "boolean | number", "\"a\" | \"b\" | 1", "bigint | number | undefined", "{ k: \"a\"; p: number } | { k: \"b\"; q: string } | null",
  "string[] | number[] | undefined", "(() => string) | string", "number | { a: 1 }", "object | string", "{} | null | undefined",
];
const DEFAULTS = ["1", "\"s\"", "null!"];

const STMTS: string[] = [
  "",
  "if (typeof x === \"string\") return;",
  "if (typeof x !== \"number\") throw 0;",
  "if (x === null) return;",
  "if (!x) return;",
  "if (x === undefined) x = DEF;",
  "if (Array.isArray(x)) return;",
  "if (isStr(x)) return;",
  "if (!isStr(x)) return;",
  "assertNum(x);",
  "assertDefined(x);",
  "if (x instanceof Date) return;",
  "if (typeof x === \"object\" && x !== null && \"a\" in x) return;",
  "x ??= DEF;",
  "for (const _ of [1]) { if (typeof x === \"string\") break; }",
  "while (typeof x === \"string\") { x = DEF; }",
  "switch (typeof x) { case \"string\": return; case \"number\": break; default: return; }",
  "if (typeof x === \"object\") return;",
  "const ok = typeof x === \"string\"; if (ok) return;",
  "try { if (typeof x === \"number\") throw 0; } catch { return; }",
  "if (typeof x === \"function\") return;",
  "if (x == null) return;",
  "if (x != undefined) { } else return;",
  "x = Math.random() ? x : DEF;",
  "if (typeof x === \"string\" || typeof x === \"number\") { } else return;",
  "if (isNullish(x)) return;",
  "do { if (typeof x === \"number\") return; } while (false);",
  "if (typeof x === \"object\" && x && \"k\" in x && x.k === \"a\") return;",
  "label: { if (typeof x === \"string\") break label; return; }",
  "if (Math.random()) { if (typeof x !== \"string\") return; } else { if (typeof x !== \"number\") return; }",
  "const y = x; if (typeof y === \"string\") return;",
  "if (typeof x === \"bigint\") return;",
  "if (typeof x === \"boolean\") return;",
  "x = typeof x === \"string\" ? x.length : x;",
  "if (assertOrFalse(x)) { } else return;",
  "check.str(x);",
  "x = ov(x);",
  "while (Math.random()) { x = ov(x); }",
  "for (let i = 0; i < 2; i++) { if (typeof x === \"string\") x = ov(x); }",
  "assertOv(x);",
  "assertIs<string | number>(x);",
  "for (const c of [check]) c.str(x);",
  "if (guardOv(x)) return;",
  "while (Math.random()) { assertDefined(x); x = DEF; }",
  "this_.assertStr(x);",
  "if (typeof x === \"string\") fail();",
  "if (typeof x === \"string\") { obj.fail(); }",
  "if (typeof x === \"string\") failOv(x);",
  "if (typeof x === \"string\") NS.fail();",
  "if (typeof x === \"string\") failArrow();",
  "if (typeof x === \"string\") failUnannot();",
  "if (typeof x === \"string\") failGen<string>();",
  "if (typeof x !== \"string\") return; else fail();",
  "if (x === undefined || x === null) fail();",
  "switch (typeof x) { case \"string\": fail(); default: }",
  "if (typeof x === \"number\") obj.nested.fail();",
  "if (typeof x === \"number\") (fail)();",
  "for (const fn of fails) { if (typeof x === \"string\") fn(); }",
  "if (x instanceof IsStr) return;",
  "if (!(x instanceof IsStr)) return;",
  "if (x instanceof IsStrGen) return;",
  "if (typeof x === \"string\") failAlias();",
  "assertAlias(x);",
  "if (typeof x === \"string\") ExpNS.fail();",
  "ExpNS.assertStr(x);",
];

export const flowFam: Family = {
  name: "narrowing-sequence",
  labelOf(k, v) { return k === "decl" ? DECLS[+v] : k.startsWith("s") ? STMTS[+v] || "none" : v; },
  dims: {
    decl: DECLS.map((_, i) => String(i)),
    s1: STMTS.map((_, i) => String(i)),
    s2: STMTS.map((_, i) => String(i)),
    s3: STMTS.map((_, i) => String(i)),
    def: ["0", "1", "2"],
    holder: ["letParam", "constLocal", "letLocal", "method", "generic"],
  },
  render(d) {
    const D = DECLS[+d.decl], DEF = DEFAULTS[+d.def];
    const pre = [
      "declare function isStr(x: unknown): x is string;",
      "declare function isNullish(x: unknown): x is null | undefined;",
      "declare function assertNum(x: unknown): asserts x is number;",
      "declare function assertDefined<T>(x: T): asserts x is NonNullable<T>;",
      "declare function assertOrFalse(x: unknown): x is string | number;",
      "declare const check: { str(x: unknown): asserts x is string };",
      "declare function ov(x: string): number;\ndeclare function ov(x: number): string;\ndeclare function ov(x: unknown): null;",
      "declare function assertOv(x: string): asserts x is \"s\";\ndeclare function assertOv(x: unknown): asserts x is number;",
      "declare function assertIs<T>(x: unknown): asserts x is T;",
      "declare function guardOv(x: string): x is \"s\";\ndeclare function guardOv(x: unknown): x is number;",
      "declare const this_: { assertStr(x: unknown): asserts x is string };",
      "declare function fail(): never;",
      "declare const obj: { fail(): never; nested: { fail(): never } };",
      "declare function failOv(x: string): never;\ndeclare function failOv(x: number): void;",
      "declare namespace NS { function fail(): never; }",
      "declare const failArrow: () => never;",
      "const failUnannot = (): never => { throw 0; };",
      "declare function failGen<T>(): never;",
      "declare const fails: (() => never)[];",
      "declare const IsStr: { [Symbol.hasInstance](v: unknown): v is string };",
      "declare class IsStrGen { static [Symbol.hasInstance]<T>(this: T, v: unknown): v is string; }",
      "import failAlias = NS.fail;",
      "namespace ANS { export declare function assertStr(x: unknown): asserts x is string; }\nimport assertAlias = ANS.assertStr;",
      "namespace ExpNS { export function fail(): never { throw 0; }\n export function assertStr(x: unknown): asserts x is string { } }",
    ].join("\n") + "\n";
    const stmts = [d.s1, d.s2, d.s3].map((s) => STMTS[+s]).filter((s) => s);
    const assigns = stmts.some((s) => /\bx (\?\?)?= /.test(s));
    let sig: string, head = "", tp = "";
    switch (d.holder) {
      case "letParam": sig = `x: ${D}`; break;
      case "constLocal": if (assigns) return null; sig = `x0: ${D}`; head = "  const x = x0;\n"; break;
      case "letLocal": sig = `x0: ${D}`; head = `  let x: ${D} = x0;\n`; break;
      case "method": sig = `x: ${D}`; break;
      default: if (assigns) return null; tp = `<X extends ${D}>`; sig = "x: X"; break;
    }
    let body = head;
    stmts.forEach((s, i) => {
      body += `  ${s.replace(/DEF/g, DEF)}\n  const v${i}: unknown = x;\n`;
    });
    if (!stmts.length) body += "  const v: unknown = x;\n";
    if (d.holder === "method") return pre + `class C {\n m(${sig}) {\n${body}}\n}\n`;
    return pre + `function f${tp}(${sig}) {\n${body}}\n`;
  },
};
